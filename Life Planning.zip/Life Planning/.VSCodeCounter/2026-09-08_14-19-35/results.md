# Summary

Date : 2026-09-08 14:19:35

Directory g:\\Current Project\\Development\\Life Planning

Total : 112 files,  21185 codes, 96 comments, 400 blanks, all 21681 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 3 | 9,548 | 0 | 3 | 9,551 |
| TypeScript JSX | 20 | 3,760 | 0 | 31 | 3,791 |
| PostCSS | 2 | 3,381 | 2 | 11 | 3,394 |
| TypeScript | 47 | 2,902 | 19 | 112 | 3,033 |
| Python | 5 | 451 | 21 | 53 | 525 |
| YAML | 10 | 290 | 4 | 10 | 304 |
| Prisma | 1 | 171 | 0 | 22 | 193 |
| MS SQL | 1 | 154 | 40 | 50 | 244 |
| Markdown | 9 | 153 | 2 | 82 | 237 |
| Terraform | 5 | 121 | 2 | 11 | 134 |
| JenkinsFile | 1 | 108 | 0 | 1 | 109 |
| Ignore | 2 | 39 | 0 | 3 | 42 |
| Properties | 1 | 30 | 2 | 2 | 34 |
| Docker | 1 | 29 | 2 | 4 | 35 |
| JSON with Comments | 1 | 27 | 0 | 1 | 28 |
| JavaScript | 1 | 15 | 0 | 2 | 17 |
| Shell Script | 1 | 5 | 2 | 1 | 8 |
| XML | 1 | 1 | 0 | 1 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 112 | 21,185 | 96 | 400 | 21,681 |
| . (Files) | 18 | 9,898 | 10 | 47 | 9,955 |
| .github | 1 | 55 | 0 | 1 | 56 |
| .github\\workflows | 1 | 55 | 0 | 1 | 56 |
| docs | 6 | 106 | 0 | 60 | 166 |
| infra | 15 | 371 | 9 | 22 | 402 |
| infra\\jenkins | 1 | 25 | 2 | 1 | 28 |
| infra\\kubernetes | 7 | 190 | 1 | 7 | 198 |
| infra\\nginx | 2 | 35 | 4 | 3 | 42 |
| infra\\terraform | 5 | 121 | 2 | 11 | 134 |
| prisma | 2 | 325 | 40 | 72 | 437 |
| prisma (Files) | 1 | 171 | 0 | 22 | 193 |
| prisma\\migrations | 1 | 154 | 40 | 50 | 244 |
| prisma\\migrations\\20260907070000_initial | 1 | 154 | 40 | 50 | 244 |
| public | 1 | 0 | 1 | 1 | 2 |
| scripts | 6 | 496 | 21 | 55 | 572 |
| src | 54 | 8,516 | 11 | 91 | 8,618 |
| src\\app | 29 | 3,881 | 3 | 40 | 3,924 |
| src\\app (Files) | 6 | 3,434 | 1 | 16 | 3,451 |
| src\\app\\(workspace) | 3 | 51 | 0 | 3 | 54 |
| src\\app\\(workspace) (Files) | 2 | 22 | 0 | 2 | 24 |
| src\\app\\(workspace)\\[module] | 1 | 29 | 0 | 1 | 30 |
| src\\app\\api | 19 | 386 | 2 | 20 | 408 |
| src\\app\\api\\auth | 3 | 79 | 2 | 4 | 85 |
| src\\app\\api\\auth\\login | 1 | 42 | 2 | 2 | 46 |
| src\\app\\api\\auth\\logout | 1 | 11 | 0 | 1 | 12 |
| src\\app\\api\\auth\\password | 1 | 26 | 0 | 1 | 27 |
| src\\app\\api\\budgets | 2 | 43 | 0 | 2 | 45 |
| src\\app\\api\\budgets (Files) | 1 | 21 | 0 | 1 | 22 |
| src\\app\\api\\budgets\\[id] | 1 | 22 | 0 | 1 | 23 |
| src\\app\\api\\daily-plans | 1 | 16 | 0 | 1 | 17 |
| src\\app\\api\\entries | 2 | 47 | 0 | 2 | 49 |
| src\\app\\api\\entries (Files) | 1 | 15 | 0 | 1 | 16 |
| src\\app\\api\\entries\\[id] | 1 | 32 | 0 | 1 | 33 |
| src\\app\\api\\habit-logs | 1 | 32 | 0 | 1 | 33 |
| src\\app\\api\\health | 1 | 5 | 0 | 1 | 6 |
| src\\app\\api\\profile | 1 | 16 | 0 | 1 | 17 |
| src\\app\\api\\ready | 1 | 14 | 0 | 1 | 15 |
| src\\app\\api\\savings | 2 | 39 | 0 | 2 | 41 |
| src\\app\\api\\savings (Files) | 1 | 17 | 0 | 1 | 18 |
| src\\app\\api\\savings\\[id] | 1 | 22 | 0 | 1 | 23 |
| src\\app\\api\\study-sessions | 2 | 29 | 0 | 2 | 31 |
| src\\app\\api\\study-sessions (Files) | 1 | 19 | 0 | 1 | 20 |
| src\\app\\api\\study-sessions\\[id] | 1 | 10 | 0 | 1 | 11 |
| src\\app\\api\\transactions | 2 | 40 | 0 | 2 | 42 |
| src\\app\\api\\transactions (Files) | 1 | 21 | 0 | 1 | 22 |
| src\\app\\api\\transactions\\[id] | 1 | 19 | 0 | 1 | 20 |
| src\\app\\api\\workspace | 1 | 26 | 0 | 1 | 27 |
| src\\app\\login | 1 | 10 | 0 | 1 | 11 |
| src\\components | 12 | 3,647 | 0 | 22 | 3,669 |
| src\\lib | 13 | 988 | 8 | 29 | 1,025 |
| tests | 9 | 1,418 | 4 | 51 | 1,473 |
| tests\\e2e | 3 | 518 | 0 | 21 | 539 |
| tests\\integration | 1 | 581 | 4 | 15 | 600 |
| tests\\unit | 5 | 319 | 0 | 15 | 334 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)