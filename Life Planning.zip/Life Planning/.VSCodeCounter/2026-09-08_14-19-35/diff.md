# Diff Summary

Date : 2026-09-08 14:19:35

Directory g:\\Current Project\\Development\\Life Planning

Total : 40 files,  7176 codes, 5 comments, 50 blanks, all 7231 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript JSX | 19 | 3,427 | 0 | 0 | 3,427 |
| PostCSS | 1 | 3,356 | 0 | 0 | 3,356 |
| TypeScript | 7 | 214 | 1 | 5 | 220 |
| Python | 3 | 67 | 2 | 6 | 75 |
| Markdown | 4 | 57 | 0 | 38 | 95 |
| JenkinsFile | 1 | 33 | 0 | 0 | 33 |
| JavaScript | 1 | 7 | 0 | 0 | 7 |
| JSON with Comments | 1 | 6 | 0 | 0 | 6 |
| Shell Script | 1 | 5 | 2 | 1 | 8 |
| Ignore | 1 | 2 | 0 | 0 | 2 |
| JSON | 1 | 2 | 0 | 0 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 40 | 7,176 | 5 | 50 | 7,231 |
| . (Files) | 7 | 57 | 0 | 0 | 57 |
| docs | 4 | 57 | 0 | 38 | 95 |
| infra | 1 | 5 | 2 | 1 | 8 |
| infra\\nginx | 1 | 5 | 2 | 1 | 8 |
| scripts | 3 | 67 | 2 | 6 | 75 |
| src | 23 | 6,949 | 1 | 1 | 6,951 |
| src\\app | 8 | 3,403 | 0 | 0 | 3,403 |
| src\\app (Files) | 5 | 3,388 | 0 | 0 | 3,388 |
| src\\app\\(workspace) | 3 | 15 | 0 | 0 | 15 |
| src\\app\\(workspace) (Files) | 2 | 12 | 0 | 0 | 12 |
| src\\app\\(workspace)\\[module] | 1 | 3 | 0 | 0 | 3 |
| src\\components | 12 | 3,380 | 0 | 0 | 3,380 |
| src\\lib | 3 | 166 | 1 | 1 | 168 |
| tests | 2 | 41 | 0 | 4 | 45 |
| tests\\e2e | 1 | 16 | 0 | 0 | 16 |
| tests\\unit | 1 | 25 | 0 | 4 | 29 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)