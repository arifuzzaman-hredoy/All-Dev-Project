# Diff Details

Date : 2026-09-08 14:19:35

Directory g:\\Current Project\\Development\\Life Planning

Total : 40 files,  7176 codes, 5 comments, 50 blanks, all 7231 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.prettierignore](/.prettierignore) | Ignore | 2 | 0 | 0 | 2 |
| [Jenkinsfile](/Jenkinsfile) | JenkinsFile | 33 | 0 | 0 | 33 |
| [docs/backup-recovery.md](/docs/backup-recovery.md) | Markdown | 13 | 0 | 11 | 24 |
| [docs/deployment.md](/docs/deployment.md) | Markdown | 26 | 0 | 17 | 43 |
| [docs/operations.md](/docs/operations.md) | Markdown | 16 | 0 | 8 | 24 |
| [docs/testing.md](/docs/testing.md) | Markdown | 2 | 0 | 2 | 4 |
| [eslint.config.mjs](/eslint.config.mjs) | JavaScript | 7 | 0 | 0 | 7 |
| [infra/nginx/renew-life-planning.sh](/infra/nginx/renew-life-planning.sh) | Shell Script | 5 | 2 | 1 | 8 |
| [next.config.ts](/next.config.ts) | TypeScript | 5 | 0 | 0 | 5 |
| [package.json](/package.json) | JSON | 2 | 0 | 0 | 2 |
| [prisma.config.ts](/prisma.config.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [scripts/browser\_checks.py](/scripts/browser_checks.py) | Python | 52 | 2 | 5 | 59 |
| [scripts/operations.py](/scripts/operations.py) | Python | 8 | 0 | 0 | 8 |
| [scripts/test\_operations.py](/scripts/test_operations.py) | Python | 7 | 0 | 1 | 8 |
| [src/app/(workspace)/\[module\]/page.tsx](/src/app/(workspace)/%5Bmodule%5D/page.tsx) | TypeScript JSX | 3 | 0 | 0 | 3 |
| [src/app/(workspace)/layout.tsx](/src/app/(workspace)/layout.tsx) | TypeScript JSX | 4 | 0 | 0 | 4 |
| [src/app/(workspace)/loading.tsx](/src/app/(workspace)/loading.tsx) | TypeScript JSX | 8 | 0 | 0 | 8 |
| [src/app/error.tsx](/src/app/error.tsx) | TypeScript JSX | 14 | 0 | 0 | 14 |
| [src/app/globals.css](/src/app/globals.css) | PostCSS | 3,356 | 0 | 0 | 3,356 |
| [src/app/layout.tsx](/src/app/layout.tsx) | TypeScript JSX | 5 | 0 | 0 | 5 |
| [src/app/not-found.tsx](/src/app/not-found.tsx) | TypeScript JSX | 11 | 0 | 0 | 11 |
| [src/app/page.tsx](/src/app/page.tsx) | TypeScript JSX | 2 | 0 | 0 | 2 |
| [src/components/analytics.tsx](/src/components/analytics.tsx) | TypeScript JSX | 157 | 0 | 0 | 157 |
| [src/components/app-shell.tsx](/src/components/app-shell.tsx) | TypeScript JSX | 236 | 0 | 0 | 236 |
| [src/components/dashboard.tsx](/src/components/dashboard.tsx) | TypeScript JSX | 308 | 0 | 0 | 308 |
| [src/components/entry-collection.tsx](/src/components/entry-collection.tsx) | TypeScript JSX | 585 | 0 | 0 | 585 |
| [src/components/entry-editor.tsx](/src/components/entry-editor.tsx) | TypeScript JSX | 516 | 0 | 0 | 516 |
| [src/components/finance.tsx](/src/components/finance.tsx) | TypeScript JSX | 499 | 0 | 0 | 499 |
| [src/components/habits.tsx](/src/components/habits.tsx) | TypeScript JSX | 245 | 0 | 0 | 245 |
| [src/components/login.tsx](/src/components/login.tsx) | TypeScript JSX | 130 | 0 | 0 | 130 |
| [src/components/planner.tsx](/src/components/planner.tsx) | TypeScript JSX | 215 | 0 | 0 | 215 |
| [src/components/settings.tsx](/src/components/settings.tsx) | TypeScript JSX | 211 | 0 | 0 | 211 |
| [src/components/ui.tsx](/src/components/ui.tsx) | TypeScript JSX | 185 | 0 | 0 | 185 |
| [src/components/workspace.tsx](/src/components/workspace.tsx) | TypeScript JSX | 93 | 0 | 0 | 93 |
| [src/lib/client.ts](/src/lib/client.ts) | TypeScript | 34 | 0 | 0 | 34 |
| [src/lib/database-url.ts](/src/lib/database-url.ts) | TypeScript | 5 | 1 | 1 | 7 |
| [src/lib/modules.ts](/src/lib/modules.ts) | TypeScript | 127 | 0 | 0 | 127 |
| [tests/e2e/workspace.spec.ts](/tests/e2e/workspace.spec.ts) | TypeScript | 16 | 0 | 0 | 16 |
| [tests/unit/database-url.test.ts](/tests/unit/database-url.test.ts) | TypeScript | 25 | 0 | 4 | 29 |
| [tsconfig.json](/tsconfig.json) | JSON with Comments | 6 | 0 | 0 | 6 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details