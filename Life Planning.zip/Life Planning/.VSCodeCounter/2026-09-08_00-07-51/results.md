# Summary

Date : 2026-09-08 00:07:51

Directory g:\\Current Project\\Development\\Life Planning

Total : 106 files,  14009 codes, 91 comments, 350 blanks, all 14450 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 3 | 9,546 | 0 | 3 | 9,549 |
| TypeScript | 46 | 2,688 | 18 | 107 | 2,813 |
| Python | 4 | 384 | 19 | 47 | 450 |
| TypeScript JSX | 20 | 333 | 0 | 31 | 364 |
| YAML | 10 | 290 | 4 | 10 | 304 |
| Prisma | 1 | 171 | 0 | 22 | 193 |
| MS SQL | 1 | 154 | 40 | 50 | 244 |
| Terraform | 5 | 121 | 2 | 11 | 134 |
| Markdown | 6 | 96 | 2 | 44 | 142 |
| JenkinsFile | 1 | 75 | 0 | 1 | 76 |
| Ignore | 2 | 37 | 0 | 3 | 40 |
| Properties | 1 | 30 | 2 | 2 | 34 |
| Docker | 1 | 29 | 2 | 4 | 35 |
| PostCSS | 2 | 25 | 2 | 11 | 38 |
| JSON with Comments | 1 | 21 | 0 | 1 | 22 |
| JavaScript | 1 | 8 | 0 | 2 | 10 |
| XML | 1 | 1 | 0 | 1 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 106 | 14,009 | 91 | 350 | 14,450 |
| . (Files) | 18 | 9,841 | 10 | 47 | 9,898 |
| .github | 1 | 55 | 0 | 1 | 56 |
| .github\\workflows | 1 | 55 | 0 | 1 | 56 |
| docs | 3 | 49 | 0 | 22 | 71 |
| infra | 14 | 366 | 7 | 21 | 394 |
| infra\\jenkins | 1 | 25 | 2 | 1 | 28 |
| infra\\kubernetes | 7 | 190 | 1 | 7 | 198 |
| infra\\nginx | 1 | 30 | 2 | 2 | 34 |
| infra\\terraform | 5 | 121 | 2 | 11 | 134 |
| prisma | 2 | 325 | 40 | 72 | 437 |
| prisma (Files) | 1 | 171 | 0 | 22 | 193 |
| prisma\\migrations | 1 | 154 | 40 | 50 | 244 |
| prisma\\migrations\\20260907070000_initial | 1 | 154 | 40 | 50 | 244 |
| public | 1 | 0 | 1 | 1 | 2 |
| scripts | 5 | 429 | 19 | 49 | 497 |
| src | 54 | 1,567 | 10 | 90 | 1,667 |
| src\\app | 29 | 478 | 3 | 40 | 521 |
| src\\app (Files) | 6 | 46 | 1 | 16 | 63 |
| src\\app\\(workspace) | 3 | 36 | 0 | 3 | 39 |
| src\\app\\(workspace) (Files) | 2 | 10 | 0 | 2 | 12 |
| src\\app\\(workspace)\\[module] | 1 | 26 | 0 | 1 | 27 |
| src\\app\\api | 19 | 386 | 2 | 20 | 408 |
| src\\app\\api\\auth | 3 | 79 | 2 | 4 | 85 |
| src\\app\\api\\auth\\login | 1 | 42 | 2 | 2 | 46 |
| src\\app\\api\\auth\\logout | 1 | 11 | 0 | 1 | 12 |
| src\\app\\api\\auth\\password | 1 | 26 | 0 | 1 | 27 |
| src\\app\\api\\budgets | 2 | 43 | 0 | 2 | 45 |
| src\\app\\api\\budgets (Files) | 1 | 21 | 0 | 1 | 22 |
| src\\app\\api\\budgets\\[id] | 1 | 22 | 0 | 1 | 23 |
| src\\app\\api\\daily-plans | 1 | 16 | 0 | 1 | 17 |
| src\\app\\api\\entries | 2 | 47 | 0 | 2 | 49 |
| src\\app\\api\\entries (Files) | 1 | 15 | 0 | 1 | 16 |
| src\\app\\api\\entries\\[id] | 1 | 32 | 0 | 1 | 33 |
| src\\app\\api\\habit-logs | 1 | 32 | 0 | 1 | 33 |
| src\\app\\api\\health | 1 | 5 | 0 | 1 | 6 |
| src\\app\\api\\profile | 1 | 16 | 0 | 1 | 17 |
| src\\app\\api\\ready | 1 | 14 | 0 | 1 | 15 |
| src\\app\\api\\savings | 2 | 39 | 0 | 2 | 41 |
| src\\app\\api\\savings (Files) | 1 | 17 | 0 | 1 | 18 |
| src\\app\\api\\savings\\[id] | 1 | 22 | 0 | 1 | 23 |
| src\\app\\api\\study-sessions | 2 | 29 | 0 | 2 | 31 |
| src\\app\\api\\study-sessions (Files) | 1 | 19 | 0 | 1 | 20 |
| src\\app\\api\\study-sessions\\[id] | 1 | 10 | 0 | 1 | 11 |
| src\\app\\api\\transactions | 2 | 40 | 0 | 2 | 42 |
| src\\app\\api\\transactions (Files) | 1 | 21 | 0 | 1 | 22 |
| src\\app\\api\\transactions\\[id] | 1 | 19 | 0 | 1 | 20 |
| src\\app\\api\\workspace | 1 | 26 | 0 | 1 | 27 |
| src\\app\\login | 1 | 10 | 0 | 1 | 11 |
| src\\components | 12 | 267 | 0 | 22 | 289 |
| src\\lib | 13 | 822 | 7 | 28 | 857 |
| tests | 8 | 1,377 | 4 | 47 | 1,428 |
| tests\\e2e | 3 | 502 | 0 | 21 | 523 |
| tests\\integration | 1 | 581 | 4 | 15 | 600 |
| tests\\unit | 4 | 294 | 0 | 11 | 305 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)