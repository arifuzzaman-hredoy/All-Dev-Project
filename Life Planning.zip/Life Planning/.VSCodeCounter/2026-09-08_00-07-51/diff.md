# Diff Summary

Date : 2026-09-08 00:07:51

Directory g:\\Current Project\\Development\\Life Planning

Total : 59 files,  1875 codes, 7 comments, 93 blanks, all 1975 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 41 | 1,690 | 3 | 24 | 1,717 |
| Markdown | 6 | 96 | 2 | 44 | 142 |
| Python | 3 | 40 | 1 | 11 | 52 |
| Terraform | 2 | 19 | 2 | 2 | 23 |
| TypeScript JSX | 2 | 10 | 0 | 0 | 10 |
| PostCSS | 1 | 9 | 1 | 0 | 10 |
| JenkinsFile | 1 | 8 | -2 | 0 | 6 |
| Ignore | 1 | 2 | 0 | 1 | 3 |
| XML | 1 | 1 | 0 | 1 | 2 |
| Prisma | 1 | 0 | 0 | 10 | 10 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 59 | 1,875 | 7 | 93 | 1,975 |
| . (Files) | 8 | 83 | 2 | 26 | 111 |
| docs | 3 | 49 | 0 | 22 | 71 |
| infra | 2 | 19 | 2 | 2 | 23 |
| infra\\terraform | 2 | 19 | 2 | 2 | 23 |
| prisma | 1 | 0 | 0 | 10 | 10 |
| scripts | 4 | 65 | 1 | 11 | 77 |
| src | 34 | 648 | 2 | 1 | 651 |
| src\\app | 21 | 180 | 1 | 1 | 182 |
| src\\app (Files) | 2 | 10 | 1 | 1 | 12 |
| src\\app\\api | 19 | 170 | 0 | 0 | 170 |
| src\\app\\api\\auth | 3 | 21 | 0 | 0 | 21 |
| src\\app\\api\\auth\\login | 1 | 9 | 0 | 0 | 9 |
| src\\app\\api\\auth\\logout | 1 | 6 | 0 | 0 | 6 |
| src\\app\\api\\auth\\password | 1 | 6 | 0 | 0 | 6 |
| src\\app\\api\\budgets | 2 | 26 | 0 | 0 | 26 |
| src\\app\\api\\budgets (Files) | 1 | 15 | 0 | 0 | 15 |
| src\\app\\api\\budgets\\[id] | 1 | 11 | 0 | 0 | 11 |
| src\\app\\api\\daily-plans | 1 | 8 | 0 | 0 | 8 |
| src\\app\\api\\entries | 2 | 23 | 0 | 0 | 23 |
| src\\app\\api\\entries (Files) | 1 | 8 | 0 | 0 | 8 |
| src\\app\\api\\entries\\[id] | 1 | 15 | 0 | 0 | 15 |
| src\\app\\api\\habit-logs | 1 | 14 | 0 | 0 | 14 |
| src\\app\\api\\health | 1 | 2 | 0 | 0 | 2 |
| src\\app\\api\\profile | 1 | 11 | 0 | 0 | 11 |
| src\\app\\api\\ready | 1 | 5 | 0 | 0 | 5 |
| src\\app\\api\\savings | 2 | 22 | 0 | 0 | 22 |
| src\\app\\api\\savings (Files) | 1 | 11 | 0 | 0 | 11 |
| src\\app\\api\\savings\\[id] | 1 | 11 | 0 | 0 | 11 |
| src\\app\\api\\study-sessions | 2 | 8 | 0 | 0 | 8 |
| src\\app\\api\\study-sessions (Files) | 1 | 6 | 0 | 0 | 6 |
| src\\app\\api\\study-sessions\\[id] | 1 | 2 | 0 | 0 | 2 |
| src\\app\\api\\transactions | 2 | 19 | 0 | 0 | 19 |
| src\\app\\api\\transactions (Files) | 1 | 15 | 0 | 0 | 15 |
| src\\app\\api\\transactions\\[id] | 1 | 4 | 0 | 0 | 4 |
| src\\app\\api\\workspace | 1 | 11 | 0 | 0 | 11 |
| src\\components | 2 | 10 | 0 | 0 | 10 |
| src\\lib | 11 | 458 | 1 | 0 | 459 |
| tests | 7 | 1,011 | 0 | 21 | 1,032 |
| tests\\e2e | 3 | 502 | 0 | 21 | 523 |
| tests\\integration | 1 | 360 | 0 | 0 | 360 |
| tests\\unit | 3 | 149 | 0 | 0 | 149 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)