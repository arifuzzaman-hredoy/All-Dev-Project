# Diff Details

Date : 2026-09-08 00:07:51

Directory g:\\Current Project\\Development\\Life Planning

Total : 59 files,  1875 codes, 7 comments, 93 blanks, all 1975 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.dockerignore](/.dockerignore) | Ignore | 2 | 0 | 1 | 3 |
| [AGENTS.md](/AGENTS.md) | Markdown | 3 | 2 | 5 | 10 |
| [CLAUDE.md](/CLAUDE.md) | Markdown | 1 | 0 | 1 | 2 |
| [Jenkinsfile](/Jenkinsfile) | JenkinsFile | 8 | -2 | 0 | 6 |
| [README.md](/README.md) | Markdown | 43 | 0 | 16 | 59 |
| [docs/architecture.md](/docs/architecture.md) | Markdown | 18 | 0 | 10 | 28 |
| [docs/security.md](/docs/security.md) | Markdown | 15 | 0 | 6 | 21 |
| [docs/testing.md](/docs/testing.md) | Markdown | 16 | 0 | 6 | 22 |
| [infra/terraform/.terraform.lock.hcl](/infra/terraform/.terraform.lock.hcl) | Terraform | 20 | 2 | 2 | 24 |
| [infra/terraform/main.tf](/infra/terraform/main.tf) | Terraform | -1 | 0 | 0 | -1 |
| [next-env.d.ts](/next-env.d.ts) | TypeScript | 2 | 2 | 1 | 5 |
| [playwright.config.ts](/playwright.config.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [prisma.config.ts](/prisma.config.ts) | TypeScript | 4 | 0 | 0 | 4 |
| [prisma/schema.prisma](/prisma/schema.prisma) | Prisma | 0 | 0 | 10 | 10 |
| [scripts/bootstrap.ts](/scripts/bootstrap.ts) | TypeScript | 25 | 0 | 0 | 25 |
| [scripts/operations.py](/scripts/operations.py) | Python | 1 | 0 | 0 | 1 |
| [scripts/remote\_release.py](/scripts/remote_release.py) | Python | 3 | 0 | 0 | 3 |
| [scripts/test\_operations.py](/scripts/test_operations.py) | Python | 36 | 1 | 11 | 48 |
| [src/app/api/auth/login/route.ts](/src/app/api/auth/login/route.ts) | TypeScript | 9 | 0 | 0 | 9 |
| [src/app/api/auth/logout/route.ts](/src/app/api/auth/logout/route.ts) | TypeScript | 6 | 0 | 0 | 6 |
| [src/app/api/auth/password/route.ts](/src/app/api/auth/password/route.ts) | TypeScript | 6 | 0 | 0 | 6 |
| [src/app/api/budgets/\[id\]/route.ts](/src/app/api/budgets/%5Bid%5D/route.ts) | TypeScript | 11 | 0 | 0 | 11 |
| [src/app/api/budgets/route.ts](/src/app/api/budgets/route.ts) | TypeScript | 15 | 0 | 0 | 15 |
| [src/app/api/daily-plans/route.ts](/src/app/api/daily-plans/route.ts) | TypeScript | 8 | 0 | 0 | 8 |
| [src/app/api/entries/\[id\]/route.ts](/src/app/api/entries/%5Bid%5D/route.ts) | TypeScript | 15 | 0 | 0 | 15 |
| [src/app/api/entries/route.ts](/src/app/api/entries/route.ts) | TypeScript | 8 | 0 | 0 | 8 |
| [src/app/api/habit-logs/route.ts](/src/app/api/habit-logs/route.ts) | TypeScript | 14 | 0 | 0 | 14 |
| [src/app/api/health/route.ts](/src/app/api/health/route.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [src/app/api/profile/route.ts](/src/app/api/profile/route.ts) | TypeScript | 11 | 0 | 0 | 11 |
| [src/app/api/ready/route.ts](/src/app/api/ready/route.ts) | TypeScript | 5 | 0 | 0 | 5 |
| [src/app/api/savings/\[id\]/route.ts](/src/app/api/savings/%5Bid%5D/route.ts) | TypeScript | 11 | 0 | 0 | 11 |
| [src/app/api/savings/route.ts](/src/app/api/savings/route.ts) | TypeScript | 11 | 0 | 0 | 11 |
| [src/app/api/study-sessions/\[id\]/route.ts](/src/app/api/study-sessions/%5Bid%5D/route.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [src/app/api/study-sessions/route.ts](/src/app/api/study-sessions/route.ts) | TypeScript | 6 | 0 | 0 | 6 |
| [src/app/api/transactions/\[id\]/route.ts](/src/app/api/transactions/%5Bid%5D/route.ts) | TypeScript | 4 | 0 | 0 | 4 |
| [src/app/api/transactions/route.ts](/src/app/api/transactions/route.ts) | TypeScript | 15 | 0 | 0 | 15 |
| [src/app/api/workspace/route.ts](/src/app/api/workspace/route.ts) | TypeScript | 11 | 0 | 0 | 11 |
| [src/app/globals.css](/src/app/globals.css) | PostCSS | 9 | 1 | 0 | 10 |
| [src/app/icon.svg](/src/app/icon.svg) | XML | 1 | 0 | 1 | 2 |
| [src/components/app-shell.tsx](/src/components/app-shell.tsx) | TypeScript JSX | -1 | 0 | 0 | -1 |
| [src/components/planner.tsx](/src/components/planner.tsx) | TypeScript JSX | 11 | 0 | 0 | 11 |
| [src/lib/auth.ts](/src/lib/auth.ts) | TypeScript | 26 | 0 | 0 | 26 |
| [src/lib/contracts.ts](/src/lib/contracts.ts) | TypeScript | 93 | 0 | 0 | 93 |
| [src/lib/database-url.ts](/src/lib/database-url.ts) | TypeScript | 1 | 0 | 0 | 1 |
| [src/lib/dates.ts](/src/lib/dates.ts) | TypeScript | 29 | 0 | 0 | 29 |
| [src/lib/db.ts](/src/lib/db.ts) | TypeScript | 6 | 1 | 0 | 7 |
| [src/lib/entries.ts](/src/lib/entries.ts) | TypeScript | 46 | 0 | 0 | 46 |
| [src/lib/errors.ts](/src/lib/errors.ts) | TypeScript | 6 | 0 | 0 | 6 |
| [src/lib/http.ts](/src/lib/http.ts) | TypeScript | 30 | 0 | 0 | 30 |
| [src/lib/password.ts](/src/lib/password.ts) | TypeScript | 9 | 0 | 0 | 9 |
| [src/lib/serialize.ts](/src/lib/serialize.ts) | TypeScript | 24 | 0 | 0 | 24 |
| [src/lib/validation.ts](/src/lib/validation.ts) | TypeScript | 188 | 0 | 0 | 188 |
| [tests/e2e/setup.ts](/tests/e2e/setup.ts) | TypeScript | 32 | 0 | 2 | 34 |
| [tests/e2e/teardown.ts](/tests/e2e/teardown.ts) | TypeScript | 21 | 0 | 2 | 23 |
| [tests/e2e/workspace.spec.ts](/tests/e2e/workspace.spec.ts) | TypeScript | 449 | 0 | 17 | 466 |
| [tests/integration/api.test.ts](/tests/integration/api.test.ts) | TypeScript | 360 | 0 | 0 | 360 |
| [tests/unit/dates.test.ts](/tests/unit/dates.test.ts) | TypeScript | 45 | 0 | 0 | 45 |
| [tests/unit/http.test.ts](/tests/unit/http.test.ts) | TypeScript | 45 | 0 | 0 | 45 |
| [tests/unit/validation.test.ts](/tests/unit/validation.test.ts) | TypeScript | 59 | 0 | 0 | 59 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details