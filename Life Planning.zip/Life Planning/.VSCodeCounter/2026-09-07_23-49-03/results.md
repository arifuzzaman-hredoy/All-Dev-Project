# Summary

Date : 2026-09-07 23:49:03

Directory g:\\Current Project\\Development\\Life Planning

Total : 93 files,  12134 codes, 84 comments, 257 blanks, all 12475 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 3 | 9,546 | 0 | 3 | 9,549 |
| TypeScript | 42 | 998 | 15 | 83 | 1,096 |
| Python | 3 | 344 | 18 | 36 | 398 |
| TypeScript JSX | 20 | 323 | 0 | 31 | 354 |
| YAML | 10 | 290 | 4 | 10 | 304 |
| Prisma | 1 | 171 | 0 | 12 | 183 |
| MS SQL | 1 | 154 | 40 | 50 | 244 |
| Terraform | 4 | 102 | 0 | 9 | 111 |
| JenkinsFile | 1 | 67 | 2 | 1 | 70 |
| Ignore | 2 | 35 | 0 | 2 | 37 |
| Properties | 1 | 30 | 2 | 2 | 34 |
| Docker | 1 | 29 | 2 | 4 | 35 |
| JSON with Comments | 1 | 21 | 0 | 1 | 22 |
| PostCSS | 2 | 16 | 1 | 11 | 28 |
| JavaScript | 1 | 8 | 0 | 2 | 10 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 93 | 12,134 | 84 | 257 | 12,475 |
| . (Files) | 14 | 9,758 | 8 | 21 | 9,787 |
| .github | 1 | 55 | 0 | 1 | 56 |
| .github\\workflows | 1 | 55 | 0 | 1 | 56 |
| infra | 13 | 347 | 5 | 19 | 371 |
| infra\\jenkins | 1 | 25 | 2 | 1 | 28 |
| infra\\kubernetes | 7 | 190 | 1 | 7 | 198 |
| infra\\nginx | 1 | 30 | 2 | 2 | 34 |
| infra\\terraform | 4 | 102 | 0 | 9 | 111 |
| prisma | 2 | 325 | 40 | 62 | 427 |
| prisma (Files) | 1 | 171 | 0 | 12 | 183 |
| prisma\\migrations | 1 | 154 | 40 | 50 | 244 |
| prisma\\migrations\\20260907070000_initial | 1 | 154 | 40 | 50 | 244 |
| public | 1 | 0 | 1 | 1 | 2 |
| scripts | 4 | 364 | 18 | 38 | 420 |
| src | 53 | 919 | 8 | 89 | 1,016 |
| src\\app | 28 | 298 | 2 | 39 | 339 |
| src\\app (Files) | 5 | 36 | 0 | 15 | 51 |
| src\\app\\(workspace) | 3 | 36 | 0 | 3 | 39 |
| src\\app\\(workspace) (Files) | 2 | 10 | 0 | 2 | 12 |
| src\\app\\(workspace)\\[module] | 1 | 26 | 0 | 1 | 27 |
| src\\app\\api | 19 | 216 | 2 | 20 | 238 |
| src\\app\\api\\auth | 3 | 58 | 2 | 4 | 64 |
| src\\app\\api\\auth\\login | 1 | 33 | 2 | 2 | 37 |
| src\\app\\api\\auth\\logout | 1 | 5 | 0 | 1 | 6 |
| src\\app\\api\\auth\\password | 1 | 20 | 0 | 1 | 21 |
| src\\app\\api\\budgets | 2 | 17 | 0 | 2 | 19 |
| src\\app\\api\\budgets (Files) | 1 | 6 | 0 | 1 | 7 |
| src\\app\\api\\budgets\\[id] | 1 | 11 | 0 | 1 | 12 |
| src\\app\\api\\daily-plans | 1 | 8 | 0 | 1 | 9 |
| src\\app\\api\\entries | 2 | 24 | 0 | 2 | 26 |
| src\\app\\api\\entries (Files) | 1 | 7 | 0 | 1 | 8 |
| src\\app\\api\\entries\\[id] | 1 | 17 | 0 | 1 | 18 |
| src\\app\\api\\habit-logs | 1 | 18 | 0 | 1 | 19 |
| src\\app\\api\\health | 1 | 3 | 0 | 1 | 4 |
| src\\app\\api\\profile | 1 | 5 | 0 | 1 | 6 |
| src\\app\\api\\ready | 1 | 9 | 0 | 1 | 10 |
| src\\app\\api\\savings | 2 | 17 | 0 | 2 | 19 |
| src\\app\\api\\savings (Files) | 1 | 6 | 0 | 1 | 7 |
| src\\app\\api\\savings\\[id] | 1 | 11 | 0 | 1 | 12 |
| src\\app\\api\\study-sessions | 2 | 21 | 0 | 2 | 23 |
| src\\app\\api\\study-sessions (Files) | 1 | 13 | 0 | 1 | 14 |
| src\\app\\api\\study-sessions\\[id] | 1 | 8 | 0 | 1 | 9 |
| src\\app\\api\\transactions | 2 | 21 | 0 | 2 | 23 |
| src\\app\\api\\transactions (Files) | 1 | 6 | 0 | 1 | 7 |
| src\\app\\api\\transactions\\[id] | 1 | 15 | 0 | 1 | 16 |
| src\\app\\api\\workspace | 1 | 15 | 0 | 1 | 16 |
| src\\app\\login | 1 | 10 | 0 | 1 | 11 |
| src\\components | 12 | 257 | 0 | 22 | 279 |
| src\\lib | 13 | 364 | 6 | 28 | 398 |
| tests | 5 | 366 | 4 | 26 | 396 |
| tests\\integration | 1 | 221 | 4 | 15 | 240 |
| tests\\unit | 4 | 145 | 0 | 11 | 156 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)