# Details

Date : 2026-09-07 23:49:03

Directory g:\\Current Project\\Development\\Life Planning

Total : 93 files,  12134 codes, 84 comments, 257 blanks, all 12475 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.dockerignore](/.dockerignore) | Ignore | 24 | 0 | 1 | 25 |
| [.github/workflows/ci.yml](/.github/workflows/ci.yml) | YAML | 55 | 0 | 1 | 56 |
| [.prettierignore](/.prettierignore) | Ignore | 11 | 0 | 1 | 12 |
| [.prettierrc.json](/.prettierrc.json) | JSON | 1 | 0 | 1 | 2 |
| [Dockerfile](/Dockerfile) | Docker | 29 | 2 | 4 | 35 |
| [Jenkinsfile](/Jenkinsfile) | JenkinsFile | 67 | 2 | 1 | 70 |
| [compose.yaml](/compose.yaml) | YAML | 20 | 1 | 1 | 22 |
| [eslint.config.mjs](/eslint.config.mjs) | JavaScript | 8 | 0 | 2 | 10 |
| [infra/jenkins/compose.yaml](/infra/jenkins/compose.yaml) | YAML | 25 | 2 | 1 | 28 |
| [infra/kubernetes/configmap.yaml](/infra/kubernetes/configmap.yaml) | YAML | 10 | 0 | 1 | 11 |
| [infra/kubernetes/deployment.yaml](/infra/kubernetes/deployment.yaml) | YAML | 90 | 1 | 1 | 92 |
| [infra/kubernetes/ingress.yaml](/infra/kubernetes/ingress.yaml) | YAML | 21 | 0 | 1 | 22 |
| [infra/kubernetes/kustomization.yaml](/infra/kubernetes/kustomization.yaml) | YAML | 10 | 0 | 1 | 11 |
| [infra/kubernetes/namespace.yaml](/infra/kubernetes/namespace.yaml) | YAML | 8 | 0 | 1 | 9 |
| [infra/kubernetes/networkpolicy.yaml](/infra/kubernetes/networkpolicy.yaml) | YAML | 39 | 0 | 1 | 40 |
| [infra/kubernetes/service.yaml](/infra/kubernetes/service.yaml) | YAML | 12 | 0 | 1 | 13 |
| [infra/nginx/myplan.oxytumzone.com.conf](/infra/nginx/myplan.oxytumzone.com.conf) | Properties | 30 | 2 | 2 | 34 |
| [infra/terraform/main.tf](/infra/terraform/main.tf) | Terraform | 58 | 0 | 2 | 60 |
| [infra/terraform/outputs.tf](/infra/terraform/outputs.tf) | Terraform | 6 | 0 | 1 | 7 |
| [infra/terraform/variables.tf](/infra/terraform/variables.tf) | Terraform | 26 | 0 | 4 | 30 |
| [infra/terraform/versions.tf](/infra/terraform/versions.tf) | Terraform | 12 | 0 | 2 | 14 |
| [next-env.d.ts](/next-env.d.ts) | TypeScript | 0 | 2 | 1 | 3 |
| [next.config.ts](/next.config.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [package-lock.json](/package-lock.json) | JSON | 9,497 | 0 | 1 | 9,498 |
| [package.json](/package.json) | JSON | 48 | 0 | 1 | 49 |
| [prisma.config.ts](/prisma.config.ts) | TypeScript | 6 | 1 | 2 | 9 |
| [prisma/migrations/20260907070000\_initial/migration.sql](/prisma/migrations/20260907070000_initial/migration.sql) | MS SQL | 154 | 40 | 50 | 244 |
| [prisma/schema.prisma](/prisma/schema.prisma) | Prisma | 171 | 0 | 12 | 183 |
| [public/fonts.css](/public/fonts.css) | PostCSS | 0 | 1 | 1 | 2 |
| [scripts/bootstrap.ts](/scripts/bootstrap.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [scripts/deploy.py](/scripts/deploy.py) | Python | 109 | 2 | 12 | 123 |
| [scripts/operations.py](/scripts/operations.py) | Python | 156 | 10 | 18 | 184 |
| [scripts/remote\_release.py](/scripts/remote_release.py) | Python | 79 | 6 | 6 | 91 |
| [src/app/(workspace)/\[module\]/page.tsx](/src/app/(workspace)/%5Bmodule%5D/page.tsx) | TypeScript JSX | 26 | 0 | 1 | 27 |
| [src/app/(workspace)/layout.tsx](/src/app/(workspace)/layout.tsx) | TypeScript JSX | 9 | 0 | 1 | 10 |
| [src/app/(workspace)/loading.tsx](/src/app/(workspace)/loading.tsx) | TypeScript JSX | 1 | 0 | 1 | 2 |
| [src/app/api/auth/login/route.ts](/src/app/api/auth/login/route.ts) | TypeScript | 33 | 2 | 2 | 37 |
| [src/app/api/auth/logout/route.ts](/src/app/api/auth/logout/route.ts) | TypeScript | 5 | 0 | 1 | 6 |
| [src/app/api/auth/password/route.ts](/src/app/api/auth/password/route.ts) | TypeScript | 20 | 0 | 1 | 21 |
| [src/app/api/budgets/\[id\]/route.ts](/src/app/api/budgets/%5Bid%5D/route.ts) | TypeScript | 11 | 0 | 1 | 12 |
| [src/app/api/budgets/route.ts](/src/app/api/budgets/route.ts) | TypeScript | 6 | 0 | 1 | 7 |
| [src/app/api/daily-plans/route.ts](/src/app/api/daily-plans/route.ts) | TypeScript | 8 | 0 | 1 | 9 |
| [src/app/api/entries/\[id\]/route.ts](/src/app/api/entries/%5Bid%5D/route.ts) | TypeScript | 17 | 0 | 1 | 18 |
| [src/app/api/entries/route.ts](/src/app/api/entries/route.ts) | TypeScript | 7 | 0 | 1 | 8 |
| [src/app/api/habit-logs/route.ts](/src/app/api/habit-logs/route.ts) | TypeScript | 18 | 0 | 1 | 19 |
| [src/app/api/health/route.ts](/src/app/api/health/route.ts) | TypeScript | 3 | 0 | 1 | 4 |
| [src/app/api/profile/route.ts](/src/app/api/profile/route.ts) | TypeScript | 5 | 0 | 1 | 6 |
| [src/app/api/ready/route.ts](/src/app/api/ready/route.ts) | TypeScript | 9 | 0 | 1 | 10 |
| [src/app/api/savings/\[id\]/route.ts](/src/app/api/savings/%5Bid%5D/route.ts) | TypeScript | 11 | 0 | 1 | 12 |
| [src/app/api/savings/route.ts](/src/app/api/savings/route.ts) | TypeScript | 6 | 0 | 1 | 7 |
| [src/app/api/study-sessions/\[id\]/route.ts](/src/app/api/study-sessions/%5Bid%5D/route.ts) | TypeScript | 8 | 0 | 1 | 9 |
| [src/app/api/study-sessions/route.ts](/src/app/api/study-sessions/route.ts) | TypeScript | 13 | 0 | 1 | 14 |
| [src/app/api/transactions/\[id\]/route.ts](/src/app/api/transactions/%5Bid%5D/route.ts) | TypeScript | 15 | 0 | 1 | 16 |
| [src/app/api/transactions/route.ts](/src/app/api/transactions/route.ts) | TypeScript | 6 | 0 | 1 | 7 |
| [src/app/api/workspace/route.ts](/src/app/api/workspace/route.ts) | TypeScript | 15 | 0 | 1 | 16 |
| [src/app/error.tsx](/src/app/error.tsx) | TypeScript JSX | 5 | 0 | 1 | 6 |
| [src/app/globals.css](/src/app/globals.css) | PostCSS | 16 | 0 | 10 | 26 |
| [src/app/layout.tsx](/src/app/layout.tsx) | TypeScript JSX | 11 | 0 | 2 | 13 |
| [src/app/login/page.tsx](/src/app/login/page.tsx) | TypeScript JSX | 10 | 0 | 1 | 11 |
| [src/app/not-found.tsx](/src/app/not-found.tsx) | TypeScript JSX | 2 | 0 | 1 | 3 |
| [src/app/page.tsx](/src/app/page.tsx) | TypeScript JSX | 2 | 0 | 1 | 3 |
| [src/components/analytics.tsx](/src/components/analytics.tsx) | TypeScript JSX | 12 | 0 | 1 | 13 |
| [src/components/app-shell.tsx](/src/components/app-shell.tsx) | TypeScript JSX | 24 | 0 | 2 | 26 |
| [src/components/dashboard.tsx](/src/components/dashboard.tsx) | TypeScript JSX | 21 | 0 | 2 | 23 |
| [src/components/entry-collection.tsx](/src/components/entry-collection.tsx) | TypeScript JSX | 45 | 0 | 2 | 47 |
| [src/components/entry-editor.tsx](/src/components/entry-editor.tsx) | TypeScript JSX | 42 | 0 | 2 | 44 |
| [src/components/finance.tsx](/src/components/finance.tsx) | TypeScript JSX | 24 | 0 | 3 | 27 |
| [src/components/habits.tsx](/src/components/habits.tsx) | TypeScript JSX | 16 | 0 | 2 | 18 |
| [src/components/login.tsx](/src/components/login.tsx) | TypeScript JSX | 11 | 0 | 1 | 12 |
| [src/components/planner.tsx](/src/components/planner.tsx) | TypeScript JSX | 14 | 0 | 2 | 16 |
| [src/components/settings.tsx](/src/components/settings.tsx) | TypeScript JSX | 14 | 0 | 1 | 15 |
| [src/components/ui.tsx](/src/components/ui.tsx) | TypeScript JSX | 15 | 0 | 2 | 17 |
| [src/components/workspace.tsx](/src/components/workspace.tsx) | TypeScript JSX | 19 | 0 | 2 | 21 |
| [src/lib/auth.ts](/src/lib/auth.ts) | TypeScript | 43 | 2 | 3 | 48 |
| [src/lib/client.ts](/src/lib/client.ts) | TypeScript | 12 | 0 | 2 | 14 |
| [src/lib/contracts.ts](/src/lib/contracts.ts) | TypeScript | 30 | 0 | 1 | 31 |
| [src/lib/database-url.ts](/src/lib/database-url.ts) | TypeScript | 6 | 1 | 1 | 8 |
| [src/lib/dates.ts](/src/lib/dates.ts) | TypeScript | 47 | 0 | 6 | 53 |
| [src/lib/db.ts](/src/lib/db.ts) | TypeScript | 10 | 0 | 2 | 12 |
| [src/lib/entries.ts](/src/lib/entries.ts) | TypeScript | 61 | 1 | 4 | 66 |
| [src/lib/errors.ts](/src/lib/errors.ts) | TypeScript | 3 | 0 | 1 | 4 |
| [src/lib/http.ts](/src/lib/http.ts) | TypeScript | 45 | 0 | 1 | 46 |
| [src/lib/modules.ts](/src/lib/modules.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/lib/password.ts](/src/lib/password.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [src/lib/serialize.ts](/src/lib/serialize.ts) | TypeScript | 14 | 0 | 1 | 15 |
| [src/lib/validation.ts](/src/lib/validation.ts) | TypeScript | 54 | 2 | 2 | 58 |
| [tests/integration/api.test.ts](/tests/integration/api.test.ts) | TypeScript | 221 | 4 | 15 | 240 |
| [tests/unit/dates.test.ts](/tests/unit/dates.test.ts) | TypeScript | 38 | 0 | 3 | 41 |
| [tests/unit/http.test.ts](/tests/unit/http.test.ts) | TypeScript | 34 | 0 | 2 | 36 |
| [tests/unit/password.test.ts](/tests/unit/password.test.ts) | TypeScript | 28 | 0 | 2 | 30 |
| [tests/unit/validation.test.ts](/tests/unit/validation.test.ts) | TypeScript | 45 | 0 | 4 | 49 |
| [tsconfig.json](/tsconfig.json) | JSON with Comments | 21 | 0 | 1 | 22 |
| [vitest.config.ts](/vitest.config.ts) | TypeScript | 6 | 0 | 2 | 8 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)