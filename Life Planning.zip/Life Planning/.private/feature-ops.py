from pathlib import Path
import sys, json, shlex, subprocess
sys.path.insert(0,'C:/Users/USER/.codex/private/life-planning')
from ops import connect, run
root=Path.cwd()
action=sys.argv[1]
snapshot_code = """
import json,subprocess
names=subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines()
rows=[]
for name in names:
    if name == 'life-planning-app' or name.startswith('buildx_buildkit_life-planning'):continue
    row=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
    rows.append({'name':name,'id':row['Id'],'startedAt':row['State']['StartedAt'],'running':row['State']['Running']})
print(json.dumps(sorted(rows,key=lambda r:r['name'])))
"""
def remote_python(client, code):
    result=run(client,"python3 - <<'PY'\n"+code+"\nPY",120)
    if result['code']:raise RuntimeError('Project operation failed: '+result['stderr'][-1000:])
    return result['stdout']
with connect() as client:
    if action=='snapshot':
        data=json.loads(remote_python(client,snapshot_code))
        dest=root/'.private/pre-feature-containers.json'
        if not dest.exists():dest.write_text(json.dumps(data,indent=2))
        print(json.dumps({'runningOtherContainers':len(data),'baselineSaved':True}))
    elif action=='prepare':
        output=remote_python(client,r"""
from pathlib import Path
from datetime import datetime,timezone
import os,secrets,json,shutil
root=Path('/opt/life-planning'); env=root/'shared/app.env'
s=env.read_text()
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup=root/'backups'/('feature-config-'+stamp); backup.mkdir(mode=0o700)
shutil.copy2(env,backup/'app.env');os.chmod(backup/'app.env',0o600)
if not any(line.startswith('APP_CRON_SECRET=') for line in s.splitlines()):
    s=s.rstrip()+'\nAPP_CRON_SECRET='+secrets.token_urlsafe(48)+'\n'
    temporary=env.with_suffix('.feature-next');temporary.write_text(s);os.chown(temporary,0,1001);os.chmod(temporary,0o640);os.replace(temporary,env)
print(json.dumps({'privateSchedulerTokenConfigured':True,'configBackup':str(backup)}))
""")
        print(output)
    elif action=='install':
        release=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
        if len(release)!=40 or any(c not in '0123456789abcdef' for c in release):raise ValueError('Invalid release')
        script=r"""
from pathlib import Path
from datetime import datetime,timezone
import os,shutil,subprocess,json
root=Path('/opt/life-planning');source=root/'releases'/'RELEASE'
config=source/'infra/nginx/myplan.oxytumzone.com.conf'
if config.read_text().count('server_name myplan.oxytumzone.com;')!=2:raise ValueError('Invalid project vhost')
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup=root/'backups'/('feature-web-'+stamp);backup.mkdir(mode=0o700)
target=Path('/etc/nginx/sites-available/life-planning.conf')
shutil.copy2(target,backup/'life-planning.conf')
shutil.copy2(config,target)
check=subprocess.run(['nginx','-t'],capture_output=True)
if check.returncode:
    shutil.copy2(backup/'life-planning.conf',target)
    raise RuntimeError('Nginx validation failed; previous vhost restored')
subprocess.run(['systemctl','reload','nginx'],check=True)
shutil.copy2(source/'scripts/schedule.py',root/'tools/schedule.py');os.chmod(root/'tools/schedule.py',0o700)
cron=Path('/etc/cron.d/life-planning');shutil.copy2(cron,backup/'life-planning.cron')
text=cron.read_text();line=next(line for line in (source/'infra/cron/life-planning').read_text().splitlines() if 'automations.lock' in line)
if 'automations.lock' not in text:cron.write_text(text.rstrip()+'\n'+line+'\n')
os.chmod(cron,0o644)
result=subprocess.run(['python3',str(root/'tools/schedule.py'),'--env-file',str(root/'shared/app.env')],capture_output=True,text=True)
(root/'state/automations-last.json').write_text(result.stdout)
if result.returncode:raise RuntimeError('Scheduler smoke failed')
print(json.dumps({'nginxValid':True,'scheduler':json.loads(result.stdout),'configBackup':str(backup)}))
""".replace('RELEASE',release)
        print(remote_python(client,script))
    elif action=='verify':
        data=json.loads(remote_python(client,snapshot_code));before=json.loads((root/'.private/pre-feature-containers.json').read_text())
        changed=[row['name'] for row in before if row not in data]
        report={'unrelatedContainerCount':len(before),'unrelatedContainersPreserved':not changed,'changed':changed}
        (root/'.private/feature-preservation-result.json').write_text(json.dumps(report,indent=2))
        print(json.dumps(report))
        if changed:raise SystemExit(1)
