const fs=require('node:fs');
const assert=require('node:assert/strict');
const {chromium}=require('@playwright/test');
const env=require('dotenv').parse(fs.readFileSync('.env'));
const base='https://myplan.oxytumzone.com';
async function main(){
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({baseURL:base,viewport:{width:1440,height:1000}});
 try{
  const login=await context.request.post('/api/auth/login',{headers:{Origin:base},data:{email:env.OWNER_EMAIL,password:env.OWNER_PASSWORD}});
  assert.equal(login.status(),200,'Owner login failed');
  const response=await context.request.get('/api/workspace');assert.equal(response.status(),200);
  const {data}=await response.json();assert.equal(data.user.mustChangePassword,false);
  const before=JSON.parse(fs.readFileSync('.private/pre-feature-enrichment.json','utf8'));
  const indexed=new Map(data.entries.map(e=>[e.id,e]));
  for(const record of before){
   const current=indexed.get(record.id);assert.ok(current,'Existing record missing');
   for(const [key,value] of Object.entries(record)){
    if(['userId','createdAt','updatedAt','recurrenceSourceId','recurrenceGeneratedAt'].includes(key))continue;
    if(key==='details'){for(const [name,detail] of Object.entries(value))assert.deepEqual(current.details[name],detail,'Existing detail changed');}
    else assert.deepEqual(current[key],value,'Existing '+key+' changed');
   }
  }
  const ai=await context.request.get('/api/ai/settings');assert.equal(ai.status(),200);const cfg=(await ai.json()).data;
  assert.equal(Object.keys(cfg).sort().join(','),'configured,model');
  const automation=(await (await context.request.get('/api/automation')).json()).data;
  assert.equal(automation.jobs.length,7);assert.equal(automation.schedulerConfigured,true);
  assert.equal(automation.jobs.some(j=>j.id.includes('exam')),false);
  const page=await context.newPage(),errors=[],pages=[];page.on('pageerror',error=>errors.push(error.message));
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:1000});
   for(const route of ['dashboard','ai-assistant','roadmaps','progress','document-vault','monthly-review','automation','backup','academic','ielts-sat','cloud-devops','ai-automation','portfolio-projects','debate','rover-scout','olympiad-contest','personal-skills','country-strategy','weekly-routine','final-identity','remove-from-life','certificates','final-target-document']){
    const nav=await page.goto('/'+route,{waitUntil:'networkidle'});assert.equal(nav.status(),200,route);
    await page.locator('main h1').waitFor({state:'visible'});
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),route+' overflow '+width);
    assert.equal(await page.locator('.form-error[role="alert"]').count(),0,route+' API error');
    if(['ai-assistant','roadmaps','progress','document-vault'].includes(route))await page.screenshot({path:`artifacts/live-feature-${route}-${width}.png`,fullPage:false});
    pages.push({route,width});
   }
  }
  assert.deepEqual(errors,[]);assert.equal((await context.request.get('/exam-mode')).status(),404);
  const result={ownerLogin:'passed',existingRecordsPreserved:before.length,currentRecords:data.entries.length,aiConfigured:cfg.configured,providerResponseTested:false,schedulerConfigured:true,pagesVerified:pages.length,browserErrors:errors.length};
  fs.writeFileSync('.private/live-feature-verification.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{await context.request.post('/api/auth/logout',{headers:{Origin:base}}).catch(()=>{});await browser.close();}
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
