import 'dotenv/config';
import { readFileSync, writeFileSync } from 'node:fs';
import { db } from '../src/lib/db';
import { importedEntryId } from '../scripts/lib/plan-import';
import { detailsSchema } from '../src/lib/validation';
const reference = JSON.parse(readFileSync('.private/reference-data.json','utf8'));
const bilingual = (value: any): string => typeof value === 'string' ? value : !value ? '' : value.en === value.bn ? value.en : `${value.en}\n${value.bn}`;
const commit = process.argv.includes('--commit');
const planned = new Map<string, Record<string,unknown>>();
for(const c of reference.certificates) planned.set('certificate/'+c.id,{provider:c.provider,cost:c.cost,validity:c.validity,proofType:bilingual(c.proofType),targetYear:String(c.targetYear)});
for(const p of reference.projects) planned.set('project/'+p.id,{stack:p.tools.join(', '),problem:bilingual(p.businessProblem),targetYear:String(p.targetYear),difficulty:p.difficulty});
for(const s of reference.personalSkills) planned.set('skill/'+s.id,{currentLevel:bilingual(s.currentLevel),nextAction:bilingual(s.nextAction),habitTarget:bilingual(s.habitTarget)});
try {
const report = await db.$transaction(async tx => {
  const owner = await tx.user.findUniqueOrThrow({where:{email:process.env.OWNER_EMAIL!},select:{id:true,passwordHash:true}});
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${"entries:"+owner.id}))`;
  const before = await tx.entry.findMany({where:{userId:owner.id},orderBy:{id:'asc'}});
  if(commit) writeFileSync('.private/pre-feature-enrichment.json', JSON.stringify(before,null,2));
  let rows=0, fields=0;
  for(const [key, additions] of planned){
    const id = importedEntryId(owner.id,'my-project-plan-main',key);
    const row = before.find(r=>r.id===id);
    if(!row) continue;
    const details = {...row.details as Record<string,unknown>};
    let changed=false;
    for(const [field,value] of Object.entries(additions)) if(details[field] === undefined || details[field] === '') { details[field]=value; fields++; changed=true; }
    if(!changed)continue;
    detailsSchema.parse(details);
    rows++;
    if(commit) await tx.entry.update({where:{id,userId:owner.id},data:{details}});
  }
  const after=await tx.entry.findMany({where:{userId:owner.id},orderBy:{id:'asc'}});
  const base=(items:typeof before)=>items.map(({details,updatedAt,...rest})=>rest);
  if(JSON.stringify(base(before))!==JSON.stringify(base(after))) throw Error('Existing entry fields changed');
  const current=await tx.user.findUniqueOrThrow({where:{id:owner.id},select:{passwordHash:true}});
  if(owner.passwordHash!==current.passwordHash) throw Error('Password changed');
  return {commit,rows,fields,totalRecords:after.length,baseFieldsPreserved:true,passwordPreserved:true};
},{timeout:120000,maxWait:15000});
writeFileSync('.private/enrichment-result.json',JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
}finally{await db.$disconnect();}
