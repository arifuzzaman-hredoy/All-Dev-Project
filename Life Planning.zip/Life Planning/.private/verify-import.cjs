const fs=require('node:fs');
const assert=require('node:assert/strict');
const {createHash}=require('node:crypto');
const {chromium}=require('@playwright/test');
const env=require('dotenv').parse(fs.readFileSync('.env'));
const manifest=JSON.parse(fs.readFileSync('.private/reference-import.json','utf8'));
const base='https://myplan.oxytumzone.com';
async function main(){
  const browser=await chromium.launch({headless:true});
  const context=await browser.newContext({baseURL:base,viewport:{width:1440,height:1000}});
  try{
    const login=await context.request.post('/api/auth/login',{headers:{Origin:base},data:{email:env.OWNER_EMAIL,password:env.OWNER_PASSWORD}});
    assert.equal(login.status(),200,'Owner login failed');
    const response=await context.request.get('/api/workspace');
    assert.equal(response.status(),200);
    const raw=await response.body();
    const {data}=JSON.parse(raw.toString());
    assert.equal(data.user.mustChangePassword,false);
    const indexed=new Map(data.entries.map(e=>[e.id,e]));
    const id=key=>'import_'+createHash('sha256').update(JSON.stringify([data.user.id,manifest.source,key])).digest('hex');
    for(const record of manifest.records){
      const saved=indexed.get(id(record.key));
      assert.ok(saved,'Missing record '+record.key);
      for(const [key,value] of Object.entries(record.entry)) assert.deepEqual(saved[key],key==='progress'&&record.entry.status==='done'?100:value,record.key+'/'+key);
      for(const [key,value] of Object.entries(record.links)) assert.equal(saved[key+'Id'],id(value),record.key+'/'+key);
    }
    assert.equal(data.entries.filter(e=>e.category==='Exam Mode'||e.tags.includes('exam-mode')).length,0);
    for(const collection of ['habitLogs','studySessions','transactions','budgets','savings','dailyPlans']) assert.equal(data[collection].length,0,'Unexpected fabricated history');
    const page=await context.newPage();
    const errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    const pages=[];
    for(const width of [1440,390]){
      await page.setViewportSize({width,height:1000});
      for(const route of ['dashboard','goals','projects','learning','tasks','habits','timeline','career','notes']){
        const navigation=await page.goto('/'+route,{waitUntil:'networkidle'});
        assert.equal(navigation.status(),200,route+' navigation');
        await page.locator('main h1').waitFor({state:'visible'});
        const statusFilter=page.getByRole('combobox',{name:'Filter by status',exact:true});
        if(await statusFilter.count()) await statusFilter.selectOption('all');
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),true,route+' horizontal overflow at '+width);
        assert.ok(!(await page.locator('body').innerText()).includes('could not be completed'),route+' app error');
        if(route==='projects') assert.equal(await page.locator('.entry-card').count(),40);
        if(route==='learning') assert.equal(await page.locator('.entry-card').count(),110);
        if(route==='goals') assert.equal(await page.locator('.entry-card').count(),11);
        if(route==='notes') assert.equal(await page.locator('.entry-card').count(),42);
        if(route==='notes') {
          await page.getByRole('button',{name:'Edit Start here — your original life plan',exact:true}).click();
          const content=await page.getByRole('dialog').locator('textarea').inputValue();
          assert.ok(content.includes('আপনার দেওয়া My_Project_Plan-main.zip'));
          await page.getByRole('button',{name:'Close dialog',exact:true}).click();
        }
        if(['goals','notes','projects'].includes(route)) await page.screenshot({path:`artifacts/import-${route}-${width}.png`,fullPage:false});
        pages.push({route,width,passed:true});
      }
    }
    assert.deepEqual(errors,[],'Browser runtime errors');
    const result={verifiedRecords:manifest.records.length,allSavedFieldsMatch:true,ownerPasswordChangeRequired:false,examRecords:0,fabricatedHistory:0,workspaceBytes:raw.length,pages,consoleErrors:errors.length};
    fs.writeFileSync('.private/import-live-verification.json',JSON.stringify(result,null,2));
    console.log(JSON.stringify(result,null,2));
  }finally{
    await context.request.post('/api/auth/logout',{headers:{Origin:base}}).catch(()=>{});
    await browser.close();
  }
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
