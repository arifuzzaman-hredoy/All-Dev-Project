# Active feature parity work — 2026-09-09
Owner requested original ZIP features (including AI chatbot), existing app design retained, finished Exam Mode excluded. Owner will enter DeepSeek key in AI Settings.

Committed and pushed: 744f48934bfe9c0440b19739e49459ad0fcd0ea8. Source clean. New feature tables migrated ONLY in CI so far.

Implemented: private encrypted DeepSeek settings, scoped chat with persistent threads and reviewed/idempotent actions, uploads/private previews, automation/scheduler, roadmaps/progress, case-study fields, monthly reviews, backup restore, theme/navigation-language preferences, printable target/motivation. docs/FEATURE_PARITY.md explains limits.

Verification: 55 unit/integration tests passed before latest multipart unit test (new total expected56); lint/types/format/known-secret scan pass, Python7 pass. Production build passed. Browser19 suite:17 passed; failures were global file-header DENY override and duplicate TargetDocument h1. Both FIXED and committed; full retest now via Jenkins. New AI settings/chat/progress/monthly/automation/backup/preferences tests passed. No live DeepSeek response test because key remains with owner.

Jenkins process started hidden PID18212; build queued with BUILD_REMOTE=true DEPLOY=true after commit. Poll private ci/manage.py status/log; pipeline refuses deployment unless all checks pass. Previous successful build5 was old image7af3dfc. Current queue likely build6. If failures, fix/commit/push/requeue (no permission needed).

Fresh pre-migration project database backup: /opt/life-planning/backups/database/life-planning-20260909T141345Z.dump (82281 bytes). Scheduler token provisioned privately in shared/app.env, config backup /opt/life-planning/backups/feature-config-20260909T141442Z. App has not restarted yet to read new token. No secrets printed.

.private/feature-ops.py (ignored) imports pinned SSH helpers from C:/Users/USER/.codex/private/life-planning/ops.py. Modes snapshot (already done), prepare (done), install (AFTER Jenkins deploy: own Nginx26m90s, own schedule.py and append own cron minute line, scheduler smoke), verify (compare 20 unrelated containers with current pre-deploy baseline).
Baseline .private/pre-feature-containers.json saved before any server mutations. Earlier historical check found holy-life-production-app-1 already replaced externally before this work, all20 currently running. Compare the new baseline for preservation.

.private/enrich-reference.ts dry-run successful:97 records,435 missing structured fields, owner278 total, basefields/password preserved. AFTER deployment, run npx tsx .private/enrich-reference.ts --commit (uses root.env production, fills only missing details; snapshot .private/pre-feature-enrichment.json), repeat dryrun expects0. No original data overwrite. Reference-data.json ignored.

Remaining: ensure Jenkins success + deployed commit; run feature-ops install; enrich metadata; production browser checks (disposable accounts exact cleanup), owner read-only login/current password from root.env (NOT stale credentials.json), all278 data/fields preservation, fresh post-feature backup, unrelated20 preservation, final source clean and handover. User retains existing password; never reset it. DeepSeek key/user will enter, do not claim live provider tested.

Permissions changed mid-turn to managed workspace-write; actual project path is outside writable root. tools.apply_patch hung on outside paths and was canceled. Use exec_command require_escalated for authorized edits/tests/network in G:/Current Project/Development/Life Planning; auto review has allowed these. Non-escalated py reports no Python. Explicit escalated py works. Avoid printing any private env or credentials.
