const fs=require('node:fs');
const data=JSON.parse(fs.readFileSync('.private/reference-data.json','utf8'));
const records=[];
const en=value=>typeof value==='string'?value:value?.en??'';
const bilingual=value=>typeof value==='string'?value:!value?'':value.en===value.bn?value.en:`${value.en}\n${value.bn}`;
const list=values=>values.map(value=>`• ${bilingual(value)}`).join('\n');
const status=value=>value==='Completed'?'done':['Learning','In Progress','High Priority'].includes(value)?'active':['Skipped','Archived'].includes(value)?'archived':'planned';
const progress=value=>({'Learning':22,'In Progress':45,'Completed':100,'Optional':8,'High Priority':82})[value]??0;
const priority=value=>value==='Optional'?'low':value===1||value==='Must-have'?'high':value===2||value==='Best extra'?'medium':'low';
const goalsByCategory={'academic':'academic','english-ielts':'ielts','sat':'sat','cloud-devops':'cloud-devops','ai-automation':'ai-automation','portfolio':'portfolio','debate':'debate','rover-scout':'rover','olympiad-contest':'olympiad','personal-skills':'personal-skills'};
function add(key,entry,links={}) {
  records.push({key,entry:{tags:['original-plan'],...entry},links});
}
const goalLink=category=>goalsByCategory[category]?{goal:'goal/'+goalsByCategory[category]}:{};
const origin=(file,id)=>`\n\nOriginal plan: ${file}${id?' · '+id:''}`;
const sourceStatus=value=>`Original status: ${value}`;
for(const f of data.targetFields) add('goal/'+f.id,{
  kind:'goal',title:en(f.title),category:en(f.title),status:status(f.status),priority:f.priority<=3?'high':'medium',progress:f.progress,pinned:true,
  notes:`${bilingual(f.title)}\n\nPurpose\n${bilingual(f.purpose)}\n\nMinimum target\n${bilingual(f.minTarget)}\n\nBest target\n${bilingual(f.bestTarget)}\n\nCertificates\n${list(f.certificates)}\n\nProjects\n${list(f.projects)}\n\nYear focus\n${list(f.yearFocus)}\n\n${sourceStatus(f.status)}; original priority: ${f.priority}`+origin('data/targets.ts',f.id),
});
for(const name of ['SAT','Networking']) {
  const f=data.targetSummary.find(row=>en(row[0])===name);
  add('goal/'+name.toLowerCase(),{kind:'goal',title:name==='SAT'?'SAT — optional USA target':'Build my professional network',category:name==='SAT'?'SAT Optional':'Career',priority:name==='SAT'?'low':'medium',notes:bilingual(f[1])+origin('data/targets.ts','targetSummary/'+name)});
}
add('goal/personal-skills',{kind:'goal',title:'Personal skills and independence',category:'Personal Skills',notes:'Communication & Networking; Dancing; Character + Personality + Maturity; Psychology; Cooking.\n\n'+list(data.personalSkills.map(s=>s.why))+origin('data/personal-skills.ts')});
for(const p of data.projects) add('project/'+p.id,{
  kind:'project',title:en(p.title),category:en(p.categoryLabel),tags:['original-plan','project',String(p.targetYear)],status:status(p.status),priority:priority(p.priority),progress:progress(p.status),
  notes:`Purpose\n${bilingual(p.purpose)}\n\nBusiness problem\n${bilingual(p.businessProblem)}\n\nTools\n${p.tools.join(', ')}\n\nDifficulty: ${p.difficulty}\nTarget year: ${p.targetYear}\n${sourceStatus(p.status)}; original priority: ${p.priority}\n\nProof needed\n${list(p.proofNeeded)}\n\nCase study required: ${p.caseStudyRequired?'Yes':'No'}`+origin('data/projects.ts',p.id),
},goalLink(p.categoryId));
for(const c of data.certificates) add('certificate/'+c.id,{
  kind:'learning',title:en(c.title),category:en(c.categoryLabel),tags:['original-plan','certificate',String(c.targetYear)],status:status(c.status),priority:c.status==='Optional'?'low':priority(c.priority),progress:progress(c.status),
  details:{resourceType:'Certificate / evidence',topic:en(c.categoryLabel)},
  notes:`Level: ${bilingual(c.level)}\nTarget tier: ${c.minOrBest}\nTarget year: ${c.targetYear}\nProvider: ${c.provider}\nCost (original plan): ${c.cost}\nValidity (original plan): ${c.validity}\n${sourceStatus(c.status)}; original priority: ${c.priority}\n\nProof type\n${bilingual(c.proofType)}\n\n${bilingual(c.notes)}`+origin('data/certificates.ts',c.id),
},goalLink(c.categoryId));
for(const d of data.documents) {
  const certificate=data.certificates.find(c=>en(c.title).toLowerCase()===en(d.title).toLowerCase());
  add('document/'+d.id,{kind:'task',title:'Document proof: '+en(d.title),category:'Document Vault',tags:['original-plan','document',d.categoryId],status:status(d.status),progress:d.status==='Completed'?100:0,priority:priority(d.priority),
    notes:`${bilingual(d.title)}\nCategory: ${bilingual(d.categoryLabel)}\nPriority: ${d.priority}\n${sourceStatus(d.status)}\n\n${bilingual(d.notes)}\n\nDocument collection checklist from the original plan. The ZIP contains this checklist, not the actual certificate or proof file.`+origin('data/documents.ts',d.id),
  },goalLink(d.categoryId));
}
for(const skill of data.personalSkills) {
  add('skill/'+skill.id,{kind:'learning',title:en(skill.title),category:'Personal Skills',status:status(skill.status),priority:priority(skill.priority),progress:skill.progress,details:{resourceType:'Personal skill',topic:en(skill.title)},
    notes:`Why\n${bilingual(skill.why)}\n\nCurrent level\n${bilingual(skill.currentLevel)}\n\nNext action\n${bilingual(skill.nextAction)}\n\nHabit target\n${bilingual(skill.habitTarget)}\n\nProof ideas\n${list(skill.proofIdeas)}\n\n${sourceStatus(skill.status)}; original priority: ${skill.priority}`+origin('data/personal-skills.ts',skill.id),
  },goalLink('personal-skills'));
  const weeklyTargets={'communication-networking':3,'dancing':2,'character-personality-maturity':1,'psychology':2,'cooking':1};
  add('skill-habit/'+skill.id,{kind:'habit',title:en(skill.title),category:'Personal Skills',status:'active',period:'weekly',details:{frequency:'weekly',target:weeklyTargets[skill.id]},notes:bilingual(skill.habitTarget)+'\n\n'+bilingual(skill.nextAction)+origin('data/personal-skills.ts',skill.id)},goalLink('personal-skills'));
}
for(const s of data.initialSubjectProgress) add('subject/'+s.name.toLowerCase().replace(/[^a-z0-9]+/g,'-'),{
  kind:'learning',title:s.name,category:'Academic',status:'active',progress:s.progress,priority:s.priority.toLowerCase(),details:{resourceType:'Academic subject',topic:'Regular academic study'},
  notes:`Regular academic subject\nNext action: ${s.nextAction}\n\nOriginal academic studio progress: ${s.progress}%. This is the bundled roadmap value, separate from the excluded Exam Mode.`+origin('components/life-os-features.tsx','initialSubjectProgress'),
},goalLink('academic'));
for(const h of data.defaultHabits) add('habit/'+h.id,{
  kind:'habit',title:h.title,category:en(data.categoryLabels[h.categoryId]),status:'active',period:'weekly',details:{frequency:'weekly',target:h.targetPerWeek},notes:`Target: ${h.targetPerWeek} sessions per week.\nNo completed dates were included in the original project.`+origin('components/life-os-features.tsx',h.id),
},goalLink(h.categoryId));
for(const [i,item] of data.englishDailyChecklist.entries()) add('english-habit/'+i,{kind:'habit',title:en(item),category:'English / IELTS',status:'active',period:'daily',details:{frequency:'daily',target:1},notes:bilingual(item)+origin('data/routines.ts','englishDailyChecklist/'+i)},goalLink('english-ielts'));
for(const item of data.weeklyRoutine) add('weekly/'+en(item.day).toLowerCase(),{kind:'habit',title:en(item.day)+': '+en(item.task),category:'Weekly Routine',status:'active',period:'weekly',details:{frequency:'weekly',target:1},notes:`Day: ${bilingual(item.day)}\nFocus: ${bilingual(item.task)}\n\nFollow the original weekly routine; log one session on the named day.`+origin('data/routines.ts','weeklyRoutine')});
for(const year of data.timeline) add('year/'+year.year,{
  kind:'event',title:`${year.year} — ${en(year.title)}`,category:'Annual Roadmap',tags:['original-plan',String(year.year)],period:'yearly',details:{eventType:'Annual roadmap'},
  notes:`${bilingual(year.title)}\nYear: ${year.year}\n\nFocus\n${list(year.focus)}\n\nTargets\n${list(year.targets)}\n\nEvidence to keep\n${list(year.records)}\n\nThe source specifies a year only; no exact event date has been assigned.`+origin('data/timeline.ts',String(year.year)),
});
for(const c of data.countries) add('country/'+c.name.toLowerCase(),{kind:'career',title:`${c.name} — Plan ${c.planType}`,category:'Country Strategy',priority:c.planType==='A'?'high':c.planType==='D'?'low':'medium',details:{role:'Study abroad and technology career',stage:'Planning'},
  notes:`${bilingual(c.notes)}\n\nOriginal planning ratings (subjective scores, not verified probabilities)\nCost: ${c.cost}\nScholarship: ${c.scholarshipChance}\nJob: ${c.jobChance}\nPR: ${c.prChance}\nLanguage difficulty: ${c.languageDifficulty}\nCulture fit: ${c.cultureFit}\nRisk: ${c.riskLevel}`+origin('data/countries.ts',c.name),
});
add('career/identity',{kind:'career',title:'My future identity',category:'Career Direction',pinned:true,details:{role:'Cloud/DevOps Engineer and AI Automation Builder',stage:'Building skills',skills:['Cloud / DevOps','AI Automation','Communication','Leadership']},notes:bilingual(data.finalIdentity)+'\n\n'+bilingual(data.identityExplanation)+origin('data/profile.ts')},goalLink('cloud-devops'));
const roadCategory={academic:'academic',ielts:'english-ielts',sat:'sat',cloud:'cloud-devops',ai:'ai-automation',debate:'debate',rover:'rover-scout',olympiad:'olympiad-contest'};
for(const [id,page] of Object.entries(data.pageCopy)) {
  add('roadmap/'+id,{kind:'note',title:en(page.title),category:en(data.categoryLabels[roadCategory[id]]),pinned:['cloud','ai'].includes(id),
    notes:bilingual(page.eyebrow)+'\n\n'+bilingual(page.body)+'\n\n'+page.sections.map(s=>bilingual(s.title)+'\n'+list(s.items)).join('\n\n')+origin('components/roadmap-sections.tsx','pageCopy/'+id),
  },goalLink(roadCategory[id]));
  // Make the Cloud and AI skill syllabus directly trackable as learning entries.
  if(['cloud','ai'].includes(id)) for(const [sectionIndex,section] of page.sections.entries()) {
    if(id==='ai'&&sectionIndex!==0) continue;
    for(const [i,item] of section.items.entries()) add('syllabus/'+id+'/'+sectionIndex+'/'+i,{kind:'learning',title:en(item),category:en(data.categoryLabels[roadCategory[id]]),tags:['original-plan','syllabus'],details:{resourceType:'Skill syllabus',topic:en(section.title)},notes:bilingual(section.title)+'\n\n'+bilingual(item)+origin('components/roadmap-sections.tsx','pageCopy/'+id)},goalLink(roadCategory[id]));
  }
}
function note(key,title,category,notes,pinned=false) {add(key,{kind:'note',title,category,notes,pinned});}
note('identity/rules','My 12 life rules','Personal Direction',data.finalRules.en.map((rule,i)=>`${i+1}. ${rule}\n${data.finalRules.bn[i]}`).join('\n\n')+origin('data/profile.ts','finalRules'),true);
note('targets/summary','My minimum and best targets','Master Plan',data.targetSummary.map(row=>bilingual(row[0])+'\n'+bilingual(row[1])).join('\n\n')+origin('data/targets.ts','targetSummary'),true);
note('routine/daily','Daily routine — normal and strong days','Routine','Normal day\n'+list(data.dayPlans.normal)+'\n\nStrong day\n'+list(data.dayPlans.strong)+origin('data/routines.ts','dayPlans'),true);
note('routine/weekly','My weekly routine','Routine',data.weeklyRoutine.map(r=>bilingual(r.day)+' — '+bilingual(r.task)).join('\n')+origin('data/routines.ts','weeklyRoutine'));
note('review/monthly','Monthly review — 10 questions','Review Templates',list(data.monthlyReviewQuestions)+origin('data/routines.ts','monthlyReviewQuestions'),true);
note('life/remove','What I want to remove from my life','Personal Direction',list(data.removeFromLife)+origin('data/routines.ts','removeFromLife'));
note('life/replacements','Habits I want to build instead','Personal Direction',list(data.replacementHabits)+origin('data/routines.ts','replacementHabits'));
const jobs=data.automationJobs.filter(job=>job.id!=='exam_countdown');
note('automation/ideas','Automation ideas from my original plan','Automation Planning','These are planning notes. Importing them does not activate jobs, messages or integrations.\n\n'+jobs.map(j=>`${bilingual(j.title)}\n${j.id==='daily_study_reminder'?'Daily focus from study tasks and current priorities.\nপড়াশোনার task আর priority অনুযায়ী daily focus।':bilingual(j.description)}\nCadence: ${j.cadence}\nTime: ${j.defaultTime}\nCategory: ${j.category}`).join('\n\n')+'\n\nOriginal settings\n'+Object.entries(data.automationDefaultSettings).map(([k,v])=>`${k}: ${v}`).join('\n')+origin('data/automation.ts'));
note('motivation/featured','Featured motivation collection','Motivation',list([...data.featuredMotivationQuotes,...data.motivationBank])+origin('data/motivation-quotes.ts / components/life-os-features.tsx'));
// Keep the full source bank without creating 1,200 separate cards.
for(let offset=0;offset<data.motivationQuotes.length;offset+=50) note('motivation/bank/'+offset,`Motivation collection ${String(offset/50+1).padStart(2,'0')} — ${offset+1}–${Math.min(offset+50,data.motivationQuotes.length)}`,'Motivation',data.motivationQuotes.slice(offset,offset+50).map((q,i)=>`${offset+i+1}. ${bilingual(q)}`).join('\n\n')+origin('data/motivation-quotes.ts','motivationQuotes'));
const counts=records.reduce((acc,r)=>(acc[r.entry.kind]=(acc[r.entry.kind]??0)+1,acc),{});
note('import/guide','Start here — your original life plan','Master Plan',
  'আপনার দেওয়া My_Project_Plan-main.zip-এর পরিকল্পনাগুলো এই workspace-এ যোগ করা হয়েছে।\n\nGoals: ৮টি মূল লক্ষ্য, SAT-এর optional লক্ষ্য, networking এবং personal skills।\nProjects: ৪০টি Cloud/DevOps, AI Automation ও portfolio project।\nLearning: ৫২টি certificate/evidence plan, ৫টি personal skill, ৮টি regular academic subject এবং Cloud/AI syllabus।\nTasks: ৪৪টি document proof checklist।\nHabits: সাপ্তাহিক রুটিন, English practice ও personal skills-এর অভ্যাস।\nTimeline: ২০২৬–২০২৯ সালের পরিকল্পনা।\nCareer: ভবিষ্যৎ পরিচয় ও চারটি দেশের পরিকল্পনা।\nNotes: বিস্তারিত roadmap, target summary, daily routine, monthly review, life rules এবং motivation collection।\n\nআপনার অনুরোধ অনুযায়ী শেষ হয়ে যাওয়া Exam Mode, exam subjects, exam date, countdown এবং final-night checklist বাদ দেওয়া হয়েছে।\n\nফাইলে থাকা status ও progress সংরক্ষণ করা হয়েছে। যেখানে শতাংশ ছিল না, পুরোনো অ্যাপের status-to-progress default ব্যবহার করা হয়েছে। এগুলো ZIP-এর snapshot; পুরোনো browser-এর আলাদা saved changes নয়।\n\nDocument checklist আছে, কিন্তু certificate/uploaded file-এর আসল attachment ZIP-এ নেই। কোনো habit completion, study time, income/expense বা personal journal বানানো হয়নি।\n\nপ্রতিটি imported item-এ original-plan tag আছে। Search এবং category filter দিয়ে খুঁজুন; Edit খুললে সম্পূর্ণ নোট পড়তে ও পরিবর্তন করতে পারবেন।',true);
const manifest={version:1,source:'my-project-plan-main',records};
if(records.some(r=>r.key.includes('exam')||r.entry.category==='Exam Mode'||r.entry.tags?.includes('exam-mode'))) throw Error('Exam data must be excluded');
fs.writeFileSync('.private/reference-import.json',JSON.stringify(manifest,null,2));
console.log(JSON.stringify({total:records.length,byKind:records.reduce((acc,r)=>(acc[r.entry.kind]=(acc[r.entry.kind]??0)+1,acc),{}),maxNotes:Math.max(...records.map(r=>(r.entry.notes??'').length)),examRecords:0},null,2));
