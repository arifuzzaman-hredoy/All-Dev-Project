// Read literal planning data with a restricted AST interpreter. Never load source modules.
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const root = path.resolve('.reference/My_Project_Plan-main');
const modules = new Map();
const closures = new WeakSet();
function moduleFor(file) {
  if (modules.has(file)) return modules.get(file);
  if (!file.startsWith(root + path.sep)) throw Error('Source path escapes reference');
  const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, file.endsWith('tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
  const declarations = new Map(), imports = new Map(), cache = new Map();
  for (const statement of source.statements) {
    if (ts.isVariableStatement(statement)) for (const d of statement.declarationList.declarations) if(ts.isIdentifier(d.name)) declarations.set(d.name.text, d.initializer);
    if (ts.isImportDeclaration(statement) && statement.importClause?.namedBindings && ts.isNamedImports(statement.importClause.namedBindings)) {
      const spec = statement.moduleSpecifier.text;
      if (spec.startsWith('.') || spec.startsWith('@/data/')) for (const el of statement.importClause.namedBindings.elements) imports.set(el.name.text, {file:spec.startsWith('@/')?path.resolve(root,spec.slice(2)+'.ts'):path.resolve(path.dirname(file), spec + '.ts'), name:el.propertyName?.text ?? el.name.text});
    }
  }
  const get = name => {
    if (name === 'undefined') return undefined;
    if (cache.has(name)) return cache.get(name);
    let value;
    if (declarations.has(name)) value = evaluate(declarations.get(name), get);
    else if(imports.has(name)) {const imp=imports.get(name); value=moduleFor(imp.file).get(imp.name);}
    else throw Error(`Unknown data identifier ${name} in ${file}`);
    cache.set(name, value); return value;
  };
  const result={get, declarations}; modules.set(file,result); return result;
}
function evaluate(node, get) {
  if(!node) return undefined;
  if(ts.isStringLiteralLike(node)) return node.text;
  if(ts.isNumericLiteral(node)) return Number(node.text);
  if(node.kind===ts.SyntaxKind.TrueKeyword) return true;
  if(node.kind===ts.SyntaxKind.FalseKeyword) return false;
  if(node.kind===ts.SyntaxKind.NullKeyword) return null;
  if(ts.isIdentifier(node)) return get(node.text);
  if(ts.isParenthesizedExpression(node)||ts.isAsExpression(node)||ts.isSatisfiesExpression(node)) return evaluate(node.expression,get);
  if(ts.isJsxSelfClosingElement(node)) return null; // decorative icon only
  if(ts.isArrayLiteralExpression(node)) return node.elements.flatMap(el=>ts.isSpreadElement(el)?evaluate(el.expression,get):[evaluate(el,get)]);
  if(ts.isObjectLiteralExpression(node)) {
    const result={};
    for(const p of node.properties) {
      if(ts.isSpreadAssignment(p)) Object.assign(result,evaluate(p.expression,get));
      else if(ts.isShorthandPropertyAssignment(p)) result[p.name.text]=get(p.name.text);
      else if(ts.isPropertyAssignment(p)) result[p.name.text]=evaluate(p.initializer,get);
      else throw Error('Unsupported object member');
    }
    return result;
  }
  if(ts.isArrowFunction(node)) {
    if(ts.isBlock(node.body)) throw Error('Statement execution refused');
    const fn=(...args)=>{
      const locals=new Map(); const scope=name=>locals.has(name)?locals.get(name):get(name);
      node.parameters.forEach((p,i)=>{if(!ts.isIdentifier(p.name)) throw Error('Destructuring refused'); locals.set(p.name.text,args[i]===undefined?evaluate(p.initializer,scope):args[i]);});
      return evaluate(node.body,scope);
    };
    closures.add(fn); return fn;
  }
  if(ts.isPropertyAccessExpression(node)||ts.isElementAccessExpression(node)) {
    const obj=evaluate(node.expression,get), key=ts.isPropertyAccessExpression(node)?node.name.text:evaluate(node.argumentExpression,get);
    if(['__proto__','prototype','constructor'].includes(key)) throw Error('Unsafe property');
    if(obj===undefined||obj===null) throw Error('Missing data property');
    return Object.hasOwn(obj,key)?obj[key]:undefined;
  }
  if(ts.isCallExpression(node)) {
    const args=node.arguments.map(a=>evaluate(a,get));
    if(ts.isPropertyAccessExpression(node.expression)) {
      const obj=evaluate(node.expression.expression,get), method=node.expression.name.text;
      if(Array.isArray(obj)&&method==='map'&&closures.has(args[0])) return obj.map(args[0]);
      if(Array.isArray(obj)&&method==='slice') return obj.slice(...args);
      throw Error('Method call refused: '+method);
    }
    const fn=evaluate(node.expression,get);
    if(!closures.has(fn)) throw Error('Nonliteral function call refused');
    return fn(...args);
  }
  if(ts.isTemplateExpression(node)) return node.head.text+node.templateSpans.map(s=>String(evaluate(s.expression,get))+s.literal.text).join('');
  if(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.QuestionQuestionToken) return evaluate(node.left,get)??evaluate(node.right,get);
  if(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.LessThanToken) return evaluate(node.left,get)<evaluate(node.right,get);
  if(ts.isConditionalExpression(node)) return evaluate(evaluate(node.condition,get)?node.whenTrue:node.whenFalse,get);
  throw Error('AST node refused: '+ts.SyntaxKind[node.kind]);
}
const selections={
  'data/categories.ts':['categoryLabels'],
  'data/profile.ts':['finalIdentity','identityExplanation','finalRules'],
  'data/targets.ts':['targetFields','targetSummary'],
  'data/certificates.ts':['certificates'],
  'data/projects.ts':['projects'],
  'data/documents.ts':['documents'],
  'data/countries.ts':['countries'],
  'data/routines.ts':['weeklyRoutine','dayPlans','monthlyReviewQuestions','englishDailyChecklist','removeFromLife','replacementHabits'],
  'data/timeline.ts':['timeline'],
  'data/personal-skills.ts':['personalSkills'],
  'data/automation.ts':['automationJobs','automationDefaultSettings'],
  'components/roadmap-sections.tsx':['pageCopy'],
  'components/life-os-features.tsx':['defaultSubjects','defaultHabits','initialSubjectProgress','motivationBank'],
  'data/motivation-quotes.ts':['featuredMotivationQuotes','focusAreas','actions','closers','mindsetLines'],
};
const data={};
for(const [file, names] of Object.entries(selections)) {
  const mod=moduleFor(path.resolve(root,file));
  for(const name of names) data[name]=mod.get(name);
}
// Reproduce the reviewed deterministic quote generator using literal arrays only.
const generated=[];
for(const f of data.focusAreas) for(const a of data.actions) for(const c of data.closers.slice(0,2)) generated.push({en:`${f.en} ${a.en}. ${c.en}`,bn:`${f.bn} ${a.bn}. ${c.bn}`});
for(const f of data.focusAreas) for(const m of data.mindsetLines) generated.push({en:`${f.en}: ${m.en}`,bn:`${f.bn}: ${m.bn}`});
for(const a of data.actions) for(const c of data.closers) generated.push({en:`${a.en.charAt(0).toUpperCase()}${a.en.slice(1)}. ${c.en}`,bn:`${a.bn}. ${c.bn}`});
data.motivationQuotes=[...data.featuredMotivationQuotes,...generated].slice(0,1200);
fs.writeFileSync('.private/reference-data.json',JSON.stringify(data,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(data).map(([k,v])=>[k,Array.isArray(v)?v.length:typeof v==='object'?Object.keys(v).length:typeof v])),null,2));
