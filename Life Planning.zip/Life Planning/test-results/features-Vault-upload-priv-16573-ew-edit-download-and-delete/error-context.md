# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: features.spec.ts >> Vault: upload, private preview, edit, download and delete
- Location: tests\e2e\features.spec.ts:31:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "SAMEORIGIN"
Received: "DENY"
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - generic [ref=f1e3]:
    - link "Skip to content" [ref=f1e4] [cursor=pointer]:
      - /url: "#main"
    - complementary "Main navigation" [ref=f1e5]:
      - link "Life Planning A little better, every day." [ref=f1e6] [cursor=pointer]:
        - /url: /dashboard
        - generic [ref=f1e11]:
          - text: Life Planning
          - generic [ref=f1e12]: A little better, every day.
      - generic [ref=f1e13]:
        - generic [ref=f1e14]: Q
        - generic [ref=f1e15]: Personal workspace
      - navigation [ref=f1e18]:
        - generic [ref=f1e19]:
          - paragraph [ref=f1e20]: Your day
          - link "AI Assistant" [ref=f1e21] [cursor=pointer]:
            - /url: /ai-assistant
          - link "Overview" [ref=f1e26] [cursor=pointer]:
            - /url: /dashboard
          - link "Daily planner" [ref=f1e33] [cursor=pointer]:
            - /url: /planner
          - link "Tasks" [ref=f1e37] [cursor=pointer]:
            - /url: /tasks
          - link "Habits" [ref=f1e42] [cursor=pointer]:
            - /url: /habits
        - generic [ref=f1e49]:
          - paragraph [ref=f1e50]: Grow & build
          - link "Goals" [ref=f1e51] [cursor=pointer]:
            - /url: /goals
          - link "Learning" [ref=f1e57] [cursor=pointer]:
            - /url: /learning
          - link "Career" [ref=f1e61] [cursor=pointer]:
            - /url: /career
          - link "Projects" [ref=f1e67] [cursor=pointer]:
            - /url: /projects
          - link "My Roadmaps" [ref=f1e71] [cursor=pointer]:
            - /url: /roadmaps
          - link "Progress Center" [ref=f1e75] [cursor=pointer]:
            - /url: /progress
        - generic [ref=f1e80]:
          - paragraph [ref=f1e81]: Life & reflection
          - link "Finance" [ref=f1e82] [cursor=pointer]:
            - /url: /finance
          - link "Notes" [ref=f1e87] [cursor=pointer]:
            - /url: /notes
          - link "Important dates" [ref=f1e92] [cursor=pointer]:
            - /url: /timeline
          - link "Journal" [ref=f1e98] [cursor=pointer]:
            - /url: /journal
          - link "Document Vault" [ref=f1e103] [cursor=pointer]:
            - /url: /document-vault
          - link "Monthly Review" [ref=f1e108] [cursor=pointer]:
            - /url: /monthly-review
        - generic [ref=f1e114]:
          - paragraph [ref=f1e115]: Workspace
          - link "Insights" [ref=f1e116] [cursor=pointer]:
            - /url: /analytics
          - link "Settings" [ref=f1e120] [cursor=pointer]:
            - /url: /settings
          - link "Automation Hub" [ref=f1e125] [cursor=pointer]:
            - /url: /automation
          - link "Backup & Restore" [ref=f1e131] [cursor=pointer]:
            - /url: /backup
      - generic [ref=f1e139]:
        - generic [ref=f1e140]: Q
        - generic [ref=f1e141]:
          - strong [ref=f1e142]: QA workspace
          - generic [ref=f1e143]: Your personal space
        - button "Sign out" [ref=f1e144] [cursor=pointer]
    - generic [ref=f1e148]:
      - banner [ref=f1e149]:
        - generic [ref=f1e150]:
          - generic [ref=f1e151]: My workspace
          - generic [ref=f1e152]: /
          - strong [ref=f1e153]: Document Vault
        - generic [ref=f1e154]:
          - generic [ref=f1e155]: Wed, 9 Sept 2026
          - button "Search anything K" [ref=f1e156] [cursor=pointer]:
            - generic [ref=f1e160]: Search anything
            - generic [ref=f1e161]: K
          - button "Quick add" [ref=f1e164] [cursor=pointer]
      - main [ref=f1e167]:
        - generic [ref=f1e169]:
          - paragraph [ref=f1e170]: Keep your evidence together
          - heading "Document Vault" [level=1] [ref=f1e171]
          - paragraph [ref=f1e172]: A private home for certificates, notes, screenshots, code and supporting documents.
        - generic [ref=f1e173]:
          - heading "Upload files" [level=2] [ref=f1e175]
          - generic [ref=f1e176]:
            - generic [ref=f1e177]:
              - generic [ref=f1e178]: Category
              - combobox "Category" [ref=f1e179]: Cloud / DevOps
            - generic [ref=f1e180]:
              - generic [ref=f1e181]: File type
              - combobox "File type" [ref=f1e182]: document
            - generic [ref=f1e183]:
              - generic [ref=f1e184]: Subjects (comma separated)
              - textbox "Subjects (comma separated)" [ref=f1e185]: Kubernetes, Security
          - generic [ref=f1e186]:
            - generic [ref=f1e187]:
              - text: Choose files
              - button "Choose files" [ref=f1e191]
            - generic [ref=f1e192]: 25 MB per file · 0.00 MB of 250.00 MB
        - generic [ref=f1e193]:
          - textbox "Search vault" [ref=f1e194]:
            - /placeholder: Search your files…
          - combobox "File category" [ref=f1e195] [cursor=pointer]:
            - option "All categories" [selected]
            - option "Cloud / DevOps"
          - combobox "File type filter" [ref=f1e196] [cursor=pointer]:
            - option "All types" [selected]
            - option "certificate"
            - option "document"
            - option "code"
            - option "image"
            - option "other"
          - combobox "Subject filter" [ref=f1e197] [cursor=pointer]:
            - option "All subjects" [selected]
            - option "Kubernetes"
            - option "Security"
          - combobox "Sort files" [ref=f1e198] [cursor=pointer]:
            - option "Newest first" [selected]
            - option "Name"
            - option "Largest first"
        - paragraph [ref=f1e199]: 1 files
        - article [ref=f1e201]:
          - generic [ref=f1e205]: document
          - heading "feature-evidence.txt" [level=3] [ref=f1e206]
          - paragraph
          - paragraph [ref=f1e207]: Cloud / DevOps · 0.00 MB
          - generic [ref=f1e208]:
            - generic [ref=f1e209]: Kubernetes
            - generic [ref=f1e210]: Security
          - generic [ref=f1e211]:
            - button "Preview" [ref=f1e212] [cursor=pointer]
            - link "Download feature-evidence.txt" [ref=f1e216] [cursor=pointer]:
              - /url: /api/files/cmtu69vww0002zsdxy2tk4924/content?download=1
            - button "Edit file feature-evidence.txt" [ref=f1e220] [cursor=pointer]
            - button "Delete file feature-evidence.txt" [ref=f1e224] [cursor=pointer]
        - dialog [ref=f1e228]:
          - generic [ref=f1e229]:
            - heading "feature-evidence.txt" [level=2] [ref=f1e230]
            - button "Close dialog" [active] [ref=f1e231] [cursor=pointer]
          - generic [ref=f1e235]:
            - paragraph [ref=f1e236]: feature-evidence.txt · 0.00 MB
            - generic [ref=f1e237]: Private Kubernetes lab evidence A completed namespace exercise.
            - link "Download original" [ref=f1e238] [cursor=pointer]:
              - /url: /api/files/cmtu69vww0002zsdxy2tk4924/content?download=1
      - contentinfo [ref=f1e242]:
        - generic [ref=f1e243]: Life Planning
        - generic [ref=f1e244]: Your plans, one step at a time.
    - button "Open AI assistant" [ref=f1e245] [cursor=pointer]:
      - generic [ref=f1e249]: Ask AI
  - status [ref=f1e250]:
    - text: Files uploaded to your private vault.
    - button "Dismiss notification" [ref=f1e251] [cursor=pointer]: ×
```

# Test source

```ts
  1   | import { test, expect, type Page } from "@playwright/test";
  2   | import { readFileSync, mkdirSync } from "node:fs";
  3   | 
  4   | async function request(page: Page, path: string, method = "GET", data?: unknown) {
  5   |   return page.evaluate(
  6   |     async ({ path, method, data }) => {
  7   |       const response = await fetch(path, {
  8   |         method,
  9   |         ...(data === undefined
  10  |           ? {}
  11  |           : { headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }),
  12  |       });
  13  |       return { status: response.status, body: await response.json() };
  14  |     },
  15  |     { path, method, data },
  16  |   );
  17  | }
  18  | test.beforeEach(async ({ page }) => {
  19  |   const accounts = JSON.parse(readFileSync(".e2e/account.json", "utf8"));
  20  |   const account = accounts.find(
  21  |     (item: { mustChangePassword: boolean }) => !item.mustChangePassword,
  22  |   );
  23  |   await page.goto("/login");
  24  |   await page.getByLabel("Email address", { exact: true }).fill(account.email);
  25  |   await page.locator('input[name="password"]').fill(account.password);
  26  |   await page.getByRole("button", { name: "Sign in to my workspace" }).click();
  27  |   await expect(page).toHaveURL(/\/dashboard$/);
  28  |   await expect(page.locator("main h1")).toBeVisible();
  29  | });
  30  | 
  31  | test("Vault: upload, private preview, edit, download and delete", async ({ page, browser }) => {
  32  |   await page.goto("/document-vault");
  33  |   await page.getByLabel("Category", { exact: true }).fill("Cloud / DevOps");
  34  |   await page.getByLabel("Subjects (comma separated)").fill("Kubernetes, Security");
  35  |   await page.getByLabel("Choose files").setInputFiles({
  36  |     name: "feature-evidence.txt",
  37  |     mimeType: "text/plain",
  38  |     buffer: Buffer.from("Private Kubernetes lab evidence\nA completed namespace exercise."),
  39  |   });
  40  |   const card = page
  41  |     .locator("article")
  42  |     .filter({ has: page.getByRole("heading", { name: "feature-evidence.txt", exact: true }) });
  43  |   await expect(card).toBeVisible();
  44  |   await card.getByRole("button", { name: "Preview", exact: true }).click();
  45  |   await expect(page.getByRole("dialog").locator("pre")).toContainText(
  46  |     "Private Kubernetes lab evidence",
  47  |   );
  48  |   const files = (await request(page, "/api/files")).body.data.files;
  49  |   const file = files.find(
  50  |     (item: { originalName: string }) => item.originalName === "feature-evidence.txt",
  51  |   );
  52  |   const content = await page.request.get(`/api/files/${file.id}/content`);
  53  |   expect(content.headers()["x-content-type-options"]).toBe("nosniff");
> 54  |   expect(content.headers()["x-frame-options"]).toBe("SAMEORIGIN");
      |                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  55  |   const anonymous = await browser.newContext();
  56  |   expect(
  57  |     (
  58  |       await anonymous.request.get(new URL(`/api/files/${file.id}/content`, page.url()).href)
  59  |     ).status(),
  60  |   ).toBe(401);
  61  |   await anonymous.close();
  62  |   await page.getByRole("dialog").getByRole("button", { name: "Close dialog", exact: true }).click();
  63  |   await card.getByRole("button", { name: "Edit file feature-evidence.txt" }).click();
  64  |   await page.getByLabel("File title").fill("Reviewed lab evidence");
  65  |   await page.getByLabel("Description", { exact: true }).fill("Reviewed certificate evidence");
  66  |   await page.getByRole("button", { name: "Save file details" }).click();
  67  |   await expect(page.getByRole("dialog")).toHaveCount(0);
  68  |   await page.reload();
  69  |   await page.getByLabel("Search vault").fill("Reviewed lab");
  70  |   await expect(page.getByRole("heading", { name: "Reviewed lab evidence" })).toBeVisible();
  71  |   const [download] = await Promise.all([
  72  |     page.waitForEvent("download"),
  73  |     page.getByRole("link", { name: "Download Reviewed lab evidence" }).click(),
  74  |   ]);
  75  |   expect(download.suggestedFilename()).toBe("feature-evidence.txt");
  76  |   page.once("dialog", (dialog) => dialog.accept());
  77  |   await page.getByRole("button", { name: "Delete file Reviewed lab evidence" }).click();
  78  |   await expect(page.getByRole("heading", { name: "Reviewed lab evidence" })).toHaveCount(0);
  79  | });
  80  | 
  81  | test("AI: encrypted key settings, context selection, persistent chat management", async ({
  82  |   page,
  83  | }) => {
  84  |   await page.goto("/ai-assistant");
  85  |   await expect(page.getByText("to start chatting.")).toBeVisible();
  86  |   await page.getByRole("button", { name: "AI Settings", exact: true }).first().click();
  87  |   const dialog = page.getByRole("dialog");
  88  |   await dialog.getByLabel("DeepSeek API key").fill("sk-e2e-placeholder-not-a-provider-key");
  89  |   await dialog.getByRole("button", { name: "Save AI settings" }).click();
  90  |   await expect(dialog.getByText("API key connected")).toBeVisible();
  91  |   expect(JSON.stringify((await request(page, "/api/ai/settings")).body)).not.toContain("sk-e2e");
  92  |   page.once("dialog", (alert) => alert.accept());
  93  |   await dialog.getByRole("button", { name: "Remove key" }).click();
  94  |   await expect(dialog.getByText("API key needed")).toBeVisible();
  95  |   await dialog.getByRole("button", { name: "Close dialog", exact: true }).click();
  96  |   await page.getByRole("button", { name: "New chat", exact: true }).click();
  97  |   await expect(page.locator(".chat-history button")).toHaveCount(1);
  98  |   await page.getByText("Context & attachments", { exact: false }).click();
  99  |   await page.getByLabel("Context to share").selectOption("selected_files");
  100 |   await expect(page.getByLabel("Search vault files")).toBeVisible();
  101 |   await page.getByLabel("Message AI assistant").fill("Please review my selected notes.");
  102 |   await expect(page.getByRole("button", { name: "Send", exact: true })).toBeDisabled();
  103 |   await page.reload();
  104 |   await expect(page.locator(".chat-history button")).toHaveCount(1);
  105 |   page.once("dialog", (alert) => alert.accept());
  106 |   await page.getByRole("button", { name: "Clear", exact: true }).click();
  107 |   page.once("dialog", (alert) => alert.accept());
  108 |   await page.getByRole("button", { name: "Delete conversation" }).click();
  109 |   await expect(page.locator(".chat-history button")).toHaveCount(0);
  110 | });
  111 | 
  112 | test("Progress, monthly review and automation persist real changes", async ({ page }) => {
  113 |   const created = await request(page, "/api/entries", "POST", {
  114 |     kind: "project",
  115 |     title: "Feature QA project",
  116 |     category: "Cloud / DevOps",
  117 |     details: { stack: "Next.js, Kubernetes", problem: "Track deployment evidence" },
  118 |   });
  119 |   expect(created.status).toBe(201);
  120 |   await page.goto("/progress");
  121 |   await page.getByLabel("Stage for Feature QA project").selectOption("Testing");
  122 |   await expect(page.getByLabel("Progress percentage for Feature QA project")).toHaveValue("74");
  123 |   await page.reload();
  124 |   await expect(page.getByLabel("Stage for Feature QA project")).toHaveValue("Testing");
  125 |   await page.getByLabel("Progress percentage for Feature QA project").fill("100");
  126 |   await page.getByLabel("Search progress").click();
  127 |   await expect(page.getByLabel("Stage for Feature QA project")).toHaveValue("Completed");
  128 |   await page.goto("/monthly-review");
  129 |   await page.getByLabel("Review month").fill("2026-09");
  130 |   await page.getByLabel("Month score / 10").fill("8");
  131 |   await page.getByLabel("What did I complete?", { exact: true }).fill("Finished deployment lab");
  132 |   await page.getByLabel("Which skills improved?").fill("Kubernetes troubleshooting");
  133 |   await page.getByRole("button", { name: "Save monthly review" }).click();
  134 |   await expect(page.getByRole("status")).toContainText("Monthly review saved");
  135 |   await page.reload();
  136 |   await expect(page.getByText("Finished deployment lab", { exact: true })).toBeVisible();
  137 |   await page.goto("/automation");
  138 |   await page.getByRole("button", { name: "Test notification" }).click();
  139 |   await expect(page.getByRole("button", { name: "Mark read", exact: true })).toBeVisible();
  140 |   await page.getByRole("button", { name: "Mark all read" }).click();
  141 |   await expect(page.getByRole("button", { name: "Mark read", exact: true })).toHaveCount(0);
  142 |   await page.getByLabel("Morning reminder").fill("08:15");
  143 |   await page.getByRole("button", { name: "Save schedule" }).click();
  144 |   await expect(page.getByRole("status")).toContainText("Automation settings saved");
  145 |   await page.reload();
  146 |   await expect(page.getByLabel("Morning reminder")).toHaveValue("08:15");
  147 |   expect((await request(page, "/api/automation")).body.data.jobs).toHaveLength(7);
  148 | });
  149 | 
  150 | test("Backup preview and restore preserve existing records; preferences survive reload", async ({
  151 |   page,
  152 | }) => {
  153 |   const backup = (await request(page, "/api/backup")).body;
  154 |   await page.goto("/backup");
```