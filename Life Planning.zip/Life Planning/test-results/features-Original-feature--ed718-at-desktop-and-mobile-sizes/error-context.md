# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: features.spec.ts >> Original feature routes and floating assistant work at desktop and mobile sizes
- Location: tests\e2e\features.spec.ts:175:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('main h1')
Expected: visible
Error: strict mode violation: locator('main h1') resolved to 2 elements:
    1) <h1>Target Document</h1> aka getByRole('heading', { name: 'Target Document' })
    2) <h1>My life plan</h1> aka getByRole('heading', { name: 'My life plan' })

Call log:
  - Expect "toBeVisible" locator('main h1') with timeout 15000ms
  - waiting for locator('main h1')

```

# Page snapshot

```yaml
- generic [active] [ref=f22e1]:
  - alert [ref=f22e2]
  - generic [ref=f22e3]:
    - link "Skip to content" [ref=f22e4] [cursor=pointer]:
      - /url: "#main"
    - complementary "Main navigation" [ref=f22e5]:
      - link "Life Planning A little better, every day." [ref=f22e6] [cursor=pointer]:
        - /url: /dashboard
        - generic [ref=f22e11]:
          - text: Life Planning
          - generic [ref=f22e12]: A little better, every day.
      - generic [ref=f22e13]:
        - generic [ref=f22e14]: Q
        - generic [ref=f22e15]: Personal workspace
      - navigation [ref=f22e18]:
        - generic [ref=f22e19]:
          - paragraph [ref=f22e20]: Your day
          - link "AI Assistant" [ref=f22e21] [cursor=pointer]:
            - /url: /ai-assistant
          - link "Overview" [ref=f22e26] [cursor=pointer]:
            - /url: /dashboard
          - link "Daily planner" [ref=f22e33] [cursor=pointer]:
            - /url: /planner
          - link "Tasks" [ref=f22e37] [cursor=pointer]:
            - /url: /tasks
          - link "Habits" [ref=f22e42] [cursor=pointer]:
            - /url: /habits
        - generic [ref=f22e49]:
          - paragraph [ref=f22e50]: Grow & build
          - link "Goals" [ref=f22e51] [cursor=pointer]:
            - /url: /goals
          - link "Learning" [ref=f22e57] [cursor=pointer]:
            - /url: /learning
          - link "Career" [ref=f22e61] [cursor=pointer]:
            - /url: /career
          - link "Projects" [ref=f22e67] [cursor=pointer]:
            - /url: /projects
          - link "My Roadmaps" [ref=f22e71] [cursor=pointer]:
            - /url: /roadmaps
          - link "Progress Center" [ref=f22e75] [cursor=pointer]:
            - /url: /progress
        - generic [ref=f22e80]:
          - paragraph [ref=f22e81]: Life & reflection
          - link "Finance" [ref=f22e82] [cursor=pointer]:
            - /url: /finance
          - link "Notes" [ref=f22e87] [cursor=pointer]:
            - /url: /notes
          - link "Important dates" [ref=f22e92] [cursor=pointer]:
            - /url: /timeline
          - link "Journal" [ref=f22e98] [cursor=pointer]:
            - /url: /journal
          - link "Document Vault" [ref=f22e103] [cursor=pointer]:
            - /url: /document-vault
          - link "Monthly Review" [ref=f22e108] [cursor=pointer]:
            - /url: /monthly-review
        - generic [ref=f22e114]:
          - paragraph [ref=f22e115]: Workspace
          - link "Insights" [ref=f22e116] [cursor=pointer]:
            - /url: /analytics
          - link "Settings" [ref=f22e120] [cursor=pointer]:
            - /url: /settings
          - link "Automation Hub" [ref=f22e125] [cursor=pointer]:
            - /url: /automation
          - link "Backup & Restore" [ref=f22e131] [cursor=pointer]:
            - /url: /backup
      - generic [ref=f22e139]:
        - generic [ref=f22e140]: Q
        - generic [ref=f22e141]:
          - strong [ref=f22e142]: QA workspace
          - generic [ref=f22e143]: Your personal space
        - button "Sign out" [ref=f22e144] [cursor=pointer]
    - generic [ref=f22e148]:
      - banner [ref=f22e149]:
        - generic [ref=f22e150]:
          - generic [ref=f22e151]: My workspace
          - generic [ref=f22e152]: /
          - strong [ref=f22e153]: My workspace
        - generic [ref=f22e154]:
          - generic [ref=f22e155]: Wed, 9 Sept 2026
          - button "Search anything K" [ref=f22e156] [cursor=pointer]:
            - generic [ref=f22e160]: Search anything
            - generic [ref=f22e161]: K
          - button "Quick add" [ref=f22e164] [cursor=pointer]
      - main [ref=f22e167]:
        - generic [ref=f22e169]:
          - paragraph [ref=f22e170]: A clear view of the bigger picture
          - heading "Target Document" [level=1] [ref=f22e171]
          - paragraph [ref=f22e172]: Your saved roadmap, organized into a document you can print or save as PDF.
        - button "Print / save PDF" [ref=f22e173] [cursor=pointer]
        - article [ref=f22e178]:
          - heading "My life plan" [level=1] [ref=f22e179]
          - paragraph [ref=f22e180]: QA workspace
          - heading "My identity" [level=2] [ref=f22e182]
          - heading "Targets" [level=2] [ref=f22e184]
          - generic [ref=f22e185]:
            - heading "Project plan" [level=2] [ref=f22e186]
            - generic [ref=f22e187]:
              - heading "Feature QA project" [level=3] [ref=f22e188]
              - paragraph
          - heading "Annual roadmap" [level=2] [ref=f22e190]
          - heading "Routine and rules" [level=2] [ref=f22e192]
          - heading "Country strategy" [level=2] [ref=f22e194]
      - contentinfo [ref=f22e195]:
        - generic [ref=f22e196]: Life Planning
        - generic [ref=f22e197]: Your plans, one step at a time.
    - button "Open AI assistant" [ref=f22e198] [cursor=pointer]:
      - generic [ref=f22e202]: Ask AI
```

# Test source

```ts
  111 | 
  112 | test("Progress, monthly review and automation persist real changes", async ({ page }) => {
  113 |   const created = await request(page, "/api/entries", "POST", {
  114 |     kind: "project",
  115 |     title: "Feature QA project",
  116 |     category: "Cloud / DevOps",
  117 |     details: { stack: "Next.js, Kubernetes", problem: "Track deployment evidence" },
  118 |   });
  119 |   expect(created.status).toBe(201);
  120 |   await page.goto("/progress");
  121 |   await page.getByLabel("Stage for Feature QA project").selectOption("Testing");
  122 |   await expect(page.getByLabel("Progress percentage for Feature QA project")).toHaveValue("74");
  123 |   await page.reload();
  124 |   await expect(page.getByLabel("Stage for Feature QA project")).toHaveValue("Testing");
  125 |   await page.getByLabel("Progress percentage for Feature QA project").fill("100");
  126 |   await page.getByLabel("Search progress").click();
  127 |   await expect(page.getByLabel("Stage for Feature QA project")).toHaveValue("Completed");
  128 |   await page.goto("/monthly-review");
  129 |   await page.getByLabel("Review month").fill("2026-09");
  130 |   await page.getByLabel("Month score / 10").fill("8");
  131 |   await page.getByLabel("What did I complete?", { exact: true }).fill("Finished deployment lab");
  132 |   await page.getByLabel("Which skills improved?").fill("Kubernetes troubleshooting");
  133 |   await page.getByRole("button", { name: "Save monthly review" }).click();
  134 |   await expect(page.getByRole("status")).toContainText("Monthly review saved");
  135 |   await page.reload();
  136 |   await expect(page.getByText("Finished deployment lab", { exact: true })).toBeVisible();
  137 |   await page.goto("/automation");
  138 |   await page.getByRole("button", { name: "Test notification" }).click();
  139 |   await expect(page.getByRole("button", { name: "Mark read", exact: true })).toBeVisible();
  140 |   await page.getByRole("button", { name: "Mark all read" }).click();
  141 |   await expect(page.getByRole("button", { name: "Mark read", exact: true })).toHaveCount(0);
  142 |   await page.getByLabel("Morning reminder").fill("08:15");
  143 |   await page.getByRole("button", { name: "Save schedule" }).click();
  144 |   await expect(page.getByRole("status")).toContainText("Automation settings saved");
  145 |   await page.reload();
  146 |   await expect(page.getByLabel("Morning reminder")).toHaveValue("08:15");
  147 |   expect((await request(page, "/api/automation")).body.data.jobs).toHaveLength(7);
  148 | });
  149 | 
  150 | test("Backup preview and restore preserve existing records; preferences survive reload", async ({
  151 |   page,
  152 | }) => {
  153 |   const backup = (await request(page, "/api/backup")).body;
  154 |   await page.goto("/backup");
  155 |   await page.getByLabel("Or paste backup JSON").fill(JSON.stringify(backup));
  156 |   await page.getByRole("button", { name: "Preview restore" }).click();
  157 |   await expect(page.locator("pre")).toContainText('"dryRun": true');
  158 |   page.once("dialog", (dialog) => dialog.accept());
  159 |   await page.getByRole("button", { name: "Restore missing records" }).click();
  160 |   await expect(page.locator("pre")).toContainText('"dryRun": false');
  161 |   await page.goto("/settings");
  162 |   await page.getByLabel("Theme", { exact: true }).selectOption("dark");
  163 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  164 |   await page.getByLabel("Language", { exact: true }).selectOption("bn");
  165 |   await expect(page.locator("main h1")).toHaveText("সেটিংস");
  166 |   await page.reload();
  167 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  168 |   await expect(page.getByLabel("Language", { exact: true })).toHaveValue("bn");
  169 |   await page.getByLabel("Language", { exact: true }).selectOption("en");
  170 |   await expect(page.locator("main h1")).toHaveText("Settings");
  171 |   await page.getByLabel("Theme", { exact: true }).selectOption("light");
  172 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  173 | });
  174 | 
  175 | test("Original feature routes and floating assistant work at desktop and mobile sizes", async ({
  176 |   page,
  177 | }) => {
  178 |   test.setTimeout(240000);
  179 |   const errors: string[] = [];
  180 |   page.on("pageerror", (error) => errors.push(error.message));
  181 |   const routes = [
  182 |     "ai-assistant",
  183 |     "document-vault",
  184 |     "roadmaps",
  185 |     "progress",
  186 |     "monthly-review",
  187 |     "automation",
  188 |     "backup",
  189 |     "academic",
  190 |     "ielts-sat",
  191 |     "cloud-devops",
  192 |     "ai-automation",
  193 |     "portfolio-projects",
  194 |     "debate",
  195 |     "rover-scout",
  196 |     "olympiad-contest",
  197 |     "personal-skills",
  198 |     "country-strategy",
  199 |     "weekly-routine",
  200 |     "final-identity",
  201 |     "remove-from-life",
  202 |     "certificates",
  203 |     "final-target-document",
  204 |   ];
  205 |   mkdirSync("artifacts", { recursive: true });
  206 |   for (const width of [1440, 390]) {
  207 |     await page.setViewportSize({ width, height: 900 });
  208 |     for (const route of routes) {
  209 |       const response = await page.goto(`/${route}`);
  210 |       expect(response?.status(), route).toBe(200);
> 211 |       await expect(page.locator("main h1")).toBeVisible();
      |                                             ^ Error: expect(locator).toBeVisible() failed
  212 |       expect(
  213 |         await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1),
  214 |         `${route} horizontal overflow at ${width}`,
  215 |       ).toBe(true);
  216 |       if (["ai-assistant", "roadmaps", "progress"].includes(route))
  217 |         await page.screenshot({
  218 |           path: `artifacts/features-${route}-${width}.png`,
  219 |           fullPage: false,
  220 |         });
  221 |     }
  222 |     await page.getByRole("button", { name: "Open AI assistant", exact: true }).click();
  223 |     await expect(page.getByLabel("Message AI assistant")).toBeVisible();
  224 |     await page.getByRole("button", { name: "Close AI assistant" }).click();
  225 |   }
  226 |   expect(errors).toEqual([]);
  227 |   expect((await page.request.get("/exam-mode")).status()).toBe(404);
  228 | });
  229 | 
```