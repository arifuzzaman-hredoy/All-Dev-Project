CREATE TYPE "ProductDiscountScope" AS ENUM ('PRODUCT', 'CATEGORY', 'SUBCATEGORY');

CREATE TABLE "ProductDiscount" (
    "id" TEXT NOT NULL,
    "scope" "ProductDiscountScope" NOT NULL,
    "percentage" INTEGER NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "productId" TEXT,
    "categoryId" TEXT,
    "startsAt" TIMESTAMP(3),
    "endsAt" TIMESTAMP(3),
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProductDiscount_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "ProductDiscount_scope_idx" ON "ProductDiscount"("scope");
CREATE INDEX "ProductDiscount_productId_idx" ON "ProductDiscount"("productId");
CREATE INDEX "ProductDiscount_categoryId_idx" ON "ProductDiscount"("categoryId");
CREATE INDEX "ProductDiscount_isActive_idx" ON "ProductDiscount"("isActive");
CREATE INDEX "ProductDiscount_startsAt_idx" ON "ProductDiscount"("startsAt");
CREATE INDEX "ProductDiscount_endsAt_idx" ON "ProductDiscount"("endsAt");

ALTER TABLE "ProductDiscount"
ADD CONSTRAINT "ProductDiscount_productId_fkey"
FOREIGN KEY ("productId") REFERENCES "Product"("id")
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ProductDiscount"
ADD CONSTRAINT "ProductDiscount_categoryId_fkey"
FOREIGN KEY ("categoryId") REFERENCES "Category"("id")
ON DELETE CASCADE ON UPDATE CASCADE;