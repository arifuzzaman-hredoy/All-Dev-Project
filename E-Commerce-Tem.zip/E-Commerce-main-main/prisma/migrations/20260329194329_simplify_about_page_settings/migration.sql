-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "aboutFaqs" JSONB;
