-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "aboutUs" TEXT,
ADD COLUMN     "privacyPolicy" TEXT,
ADD COLUMN     "termsConditions" TEXT;
