ALTER TABLE "StoreSettings"
ADD COLUMN "siteFontFamily" TEXT NOT NULL DEFAULT 'Inter',
ADD COLUMN "banglaFontFamily" TEXT NOT NULL DEFAULT 'Noto Sans Bengali';
