ALTER TABLE "Product"
ADD COLUMN "investedAmount" INTEGER;
