-- DropIndex
DROP INDEX "Category_parentId_idx";

-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "imageUrl" TEXT;
