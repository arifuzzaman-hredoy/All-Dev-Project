CREATE TABLE "OrderRevenue" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "deliveryCharge" INTEGER NOT NULL,
    "investedAmount" INTEGER,
    "adminNote" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "OrderRevenue_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "OrderRevenue_orderId_key" ON "OrderRevenue"("orderId");
CREATE INDEX "OrderRevenue_createdAt_idx" ON "OrderRevenue"("createdAt");

ALTER TABLE "OrderRevenue"
ADD CONSTRAINT "OrderRevenue_orderId_fkey"
FOREIGN KEY ("orderId") REFERENCES "Order"("id")
ON DELETE CASCADE ON UPDATE CASCADE;