ALTER TABLE "ProductVariant"
ADD COLUMN "investedAmount" INTEGER;
