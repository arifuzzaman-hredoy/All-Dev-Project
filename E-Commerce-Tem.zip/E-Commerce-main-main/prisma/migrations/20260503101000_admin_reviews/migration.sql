DROP INDEX IF EXISTS "Review_userId_productId_key";

ALTER TABLE "Review" DROP CONSTRAINT IF EXISTS "Review_userId_fkey";

ALTER TABLE "Review" ADD COLUMN "authorName" TEXT;

ALTER TABLE "Review" ALTER COLUMN "userId" DROP NOT NULL;

CREATE INDEX IF NOT EXISTS "Review_userId_idx" ON "Review"("userId");

ALTER TABLE "Review"
ADD CONSTRAINT "Review_userId_fkey"
FOREIGN KEY ("userId") REFERENCES "User"("id")
ON DELETE SET NULL ON UPDATE CASCADE;
