CREATE TABLE "ProductCategory" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ProductCategory_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "ProductCategory_productId_categoryId_key"
ON "ProductCategory"("productId", "categoryId");

CREATE INDEX "ProductCategory_productId_idx"
ON "ProductCategory"("productId");

CREATE INDEX "ProductCategory_categoryId_idx"
ON "ProductCategory"("categoryId");

ALTER TABLE "ProductCategory"
ADD CONSTRAINT "ProductCategory_productId_fkey"
FOREIGN KEY ("productId") REFERENCES "Product"("id")
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ProductCategory"
ADD CONSTRAINT "ProductCategory_categoryId_fkey"
FOREIGN KEY ("categoryId") REFERENCES "Category"("id")
ON DELETE CASCADE ON UPDATE CASCADE;

/* existing single category -> new multi-category links */
INSERT INTO "ProductCategory" ("id", "productId", "categoryId", "createdAt")
SELECT
  gen_random_uuid()::text,
  p."id",
  p."categoryId",
  CURRENT_TIMESTAMP
FROM "Product" p
WHERE p."categoryId" IS NOT NULL
ON CONFLICT ("productId", "categoryId") DO NOTHING;