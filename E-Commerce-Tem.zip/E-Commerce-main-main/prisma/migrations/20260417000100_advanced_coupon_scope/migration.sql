DO $$
BEGIN
  CREATE TYPE "CouponScope" AS ENUM ('ORDER', 'PRODUCTS', 'CATEGORIES');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE "Coupon"
ADD COLUMN IF NOT EXISTS "description" TEXT,
ADD COLUMN IF NOT EXISTS "scope" "CouponScope" NOT NULL DEFAULT 'ORDER',
ADD COLUMN IF NOT EXISTS "productIds" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
ADD COLUMN IF NOT EXISTS "categoryIds" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

UPDATE "Coupon"
SET
  "description" = COALESCE("description", NULL),
  "scope" = COALESCE("scope", 'ORDER'),
  "productIds" = COALESCE("productIds", ARRAY[]::TEXT[]),
  "categoryIds" = COALESCE("categoryIds", ARRAY[]::TEXT[]),
  "updatedAt" = COALESCE("updatedAt", CURRENT_TIMESTAMP);