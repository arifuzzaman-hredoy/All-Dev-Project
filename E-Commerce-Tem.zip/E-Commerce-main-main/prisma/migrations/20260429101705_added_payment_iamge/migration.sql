-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "manualBkashImageUrl" TEXT,
ADD COLUMN     "manualNagadImageUrl" TEXT,
ADD COLUMN     "manualRocketImageUrl" TEXT;
