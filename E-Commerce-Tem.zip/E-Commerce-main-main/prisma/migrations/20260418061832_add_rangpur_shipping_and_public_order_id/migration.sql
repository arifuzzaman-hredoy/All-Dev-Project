-- AlterTable
ALTER TABLE "OrderCounter" ALTER COLUMN "updatedAt" DROP DEFAULT;
