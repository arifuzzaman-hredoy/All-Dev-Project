/*
  Warnings:

  - A unique constraint covering the columns `[idempotencyKey]` on the table `Order` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "bankTranId" TEXT,
ADD COLUMN     "idempotencyKey" TEXT,
ADD COLUMN     "paymentGateway" TEXT,
ADD COLUMN     "paymentGatewayStatus" TEXT,
ADD COLUMN     "paymentMeta" JSONB,
ADD COLUMN     "sslczSessionKey" TEXT,
ADD COLUMN     "sslczValId" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "Order_idempotencyKey_key" ON "Order"("idempotencyKey");

-- CreateIndex
CREATE INDEX "Order_paymentStatus_idx" ON "Order"("paymentStatus");

-- CreateIndex
CREATE INDEX "Order_paymentMethod_idx" ON "Order"("paymentMethod");

-- CreateIndex
CREATE INDEX "Order_trackingId_idx" ON "Order"("trackingId");

-- CreateIndex
CREATE INDEX "Order_bankTranId_idx" ON "Order"("bankTranId");
