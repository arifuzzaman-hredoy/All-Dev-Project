-- AlterTable
ALTER TABLE "Banner" ADD COLUMN     "slot" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "Banner_slot_key" ON "Banner"("slot");
