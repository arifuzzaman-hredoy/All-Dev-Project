ALTER TABLE "Category"
ADD COLUMN "discountPercent" INTEGER;

ALTER TABLE "Product"
ADD COLUMN "discountPercent" INTEGER;