-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "facebookUrl" TEXT,
ADD COLUMN     "instagramUrl" TEXT,
ADD COLUMN     "returnRefundPolicy" TEXT,
ADD COLUMN     "tiktokUrl" TEXT,
ADD COLUMN     "whatsappUrl" TEXT,
ADD COLUMN     "youtubeUrl" TEXT;
