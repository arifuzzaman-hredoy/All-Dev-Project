ALTER TABLE "StoreSettings"
ADD COLUMN IF NOT EXISTS "shippingRangpur" INTEGER NOT NULL DEFAULT 0;

ALTER TABLE "Order"
ADD COLUMN IF NOT EXISTS "publicOrderId" TEXT,
ADD COLUMN IF NOT EXISTS "orderSequence" INTEGER;

CREATE TABLE IF NOT EXISTS "OrderCounter" (
  "key" TEXT NOT NULL,
  "lastValue" INTEGER NOT NULL DEFAULT 0,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "OrderCounter_pkey" PRIMARY KEY ("key")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Order_publicOrderId_key" ON "Order"("publicOrderId");
CREATE UNIQUE INDEX IF NOT EXISTS "Order_orderSequence_key" ON "Order"("orderSequence");
CREATE INDEX IF NOT EXISTS "Order_publicOrderId_idx" ON "Order"("publicOrderId");
CREATE INDEX IF NOT EXISTS "Order_orderSequence_idx" ON "Order"("orderSequence");

INSERT INTO "OrderCounter" ("key", "lastValue", "updatedAt")
VALUES ('order', 0, CURRENT_TIMESTAMP)
ON CONFLICT ("key") DO NOTHING;

WITH ordered AS (
  SELECT
    "id",
    ROW_NUMBER() OVER (ORDER BY "createdAt" ASC, "id" ASC) AS seq
  FROM "Order"
),
updated AS (
  UPDATE "Order" o
  SET
    "orderSequence" = ordered.seq,
    "publicOrderId" = 'SB-' || LPAD(ordered.seq::text, 6, '0')
  FROM ordered
  WHERE o."id" = ordered."id"
    AND (o."orderSequence" IS NULL OR o."publicOrderId" IS NULL)
  RETURNING o."id", o."orderSequence"
)
UPDATE "OrderCounter"
SET "lastValue" = COALESCE(
  (SELECT MAX("orderSequence") FROM "Order"),
  0
),
"updatedAt" = CURRENT_TIMESTAMP
WHERE "key" = 'order';