CREATE TYPE "ProductRequestStatus" AS ENUM ('PENDING', 'CONTACTED', 'FULFILLED', 'REJECTED');

CREATE TABLE "ProductRequest" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "email" TEXT,
    "message" TEXT,
    "status" "ProductRequestStatus" NOT NULL DEFAULT 'PENDING',
    "adminNote" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProductRequest_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "ProductRequest_productId_idx" ON "ProductRequest"("productId");
CREATE INDEX "ProductRequest_status_idx" ON "ProductRequest"("status");
CREATE INDEX "ProductRequest_createdAt_idx" ON "ProductRequest"("createdAt");

ALTER TABLE "ProductRequest"
ADD CONSTRAINT "ProductRequest_productId_fkey"
FOREIGN KEY ("productId") REFERENCES "Product"("id")
ON DELETE CASCADE ON UPDATE CASCADE;