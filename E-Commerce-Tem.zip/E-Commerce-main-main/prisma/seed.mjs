import crypto from "crypto";
import fs from "fs/promises";
import path from "path";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

const rootDir = process.cwd();
dotenv.config({ path: path.join(rootDir, ".env.production") });
dotenv.config({ path: path.join(rootDir, ".env") });

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error("DATABASE_URL is required for prisma seed.");
}

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: databaseUrl }),
});

const BRAND_NAME = process.env.APP_NAME?.trim() || "NexoraMart";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || process.env.NEXT_PUBLIC_BASE_URL || "https://ecommerce.techteamlead.com";
const PRODUCT_IMAGE_BASE = "/uploads/seed/products";
const CATEGORY_IMAGE_BASE = "/uploads/seed/categories";
const BANNER_IMAGE_BASE = "/uploads/seed/banners";
const REVIEW_IMAGE_BASE = "/uploads/seed/reviews";
const LOGO_IMAGE_URL = "/uploads/seed/logos/nexoramart-logo.png";
const cloudinaryCache = new Map();

const categories = [
  { slug: "electronics", name: "Electronics", description: "Chargers, accessories, audio, and daily tech essentials.", discountPercent: 8 },
  { slug: "mens-fashion", name: "Men's Fashion", description: "Smart everyday clothing and wearable essentials.", discountPercent: 10 },
  { slug: "womens-fashion", name: "Women's Fashion", description: "Useful fashion pieces, bags, scarves, and accessories.", discountPercent: 12 },
  { slug: "smart-gadgets", name: "Smart Gadgets", description: "Compact tech products for productivity and daily use.", discountPercent: 7 },
  { slug: "home-living", name: "Home & Living", description: "Storage, kitchen, lighting, and household upgrades.", discountPercent: 6 },
  { slug: "beauty-care", name: "Beauty & Care", description: "Personal care, grooming, and self-care products.", discountPercent: 9 },
  { slug: "sports-outdoor", name: "Sports & Outdoor", description: "Fitness, travel, and outdoor support products.", discountPercent: 5 },
  { slug: "baby-kids", name: "Baby & Kids", description: "Safe, practical essentials for babies and children.", discountPercent: 6 },
  { slug: "groceries", name: "Groceries", description: "Daily food, pantry, and household consumables.", discountPercent: 4 },
  { slug: "books-stationery", name: "Books & Stationery", description: "Study, office, writing, and reading essentials.", discountPercent: 5 },
  { slug: "automotive", name: "Automotive", description: "Bike, car, and ride-care accessories.", discountPercent: 5 },
  { slug: "islamic-items", name: "Islamic Items", description: "Prayer, gift, book, and modest lifestyle products.", discountPercent: 8 },
];

const productNamesByCategory = {
  electronics: [
    "Fast Charge USB-C Cable 1.5m",
    "Compact 20W Travel Charger",
    "Wireless Bluetooth Speaker Mini",
    "Noise Isolation Wired Earphones",
    "10,000mAh Slim Power Bank",
  ],
  "mens-fashion": [
    "Premium Cotton Casual T-Shirt",
    "Classic Slim Fit Polo Shirt",
    "Lightweight Summer Panjabi",
    "Everyday Leather Wallet",
    "Comfort Stretch Denim Jeans",
  ],
  "womens-fashion": [
    "Elegant Printed Hijab Scarf",
    "Daily Carry Shoulder Bag",
    "Soft Cotton Kurti Top",
    "Minimal Gold Tone Bracelet",
    "Comfort Flat Sandal Pair",
  ],
  "smart-gadgets": [
    "Smart Fitness Band Pro",
    "Mini Tripod With Phone Holder",
    "Wireless Charging Pad",
    "Portable LED Desk Lamp",
    "Digital Kitchen Scale",
  ],
  "home-living": [
    "Stackable Kitchen Storage Box",
    "Non-Stick Fry Pan 24cm",
    "Foldable Laundry Basket",
    "LED Night Light Sensor",
    "Premium Microfiber Towel Set",
  ],
  "beauty-care": [
    "Gentle Herbal Face Wash",
    "Vitamin C Brightening Serum",
    "Moisturizing Body Lotion",
    "Hair Care Wooden Comb Set",
    "Matte Finish Lip Tint",
  ],
  "sports-outdoor": [
    "Insulated Sports Water Bottle",
    "Adjustable Hand Grip Strengthener",
    "Yoga Mat Anti Slip 6mm",
    "Travel Organizer Waist Bag",
    "Quick Dry Gym Towel",
  ],
  "baby-kids": [
    "Baby Feeding Bottle BPA Free",
    "Soft Cotton Baby Romper",
    "Kids Learning Drawing Book",
    "Silicone Baby Bib Set",
    "Colorful Building Blocks Set",
  ],
  groceries: [
    "Premium Mixed Nuts Jar",
    "Natural Raw Honey 500g",
    "Organic Chia Seeds Pack",
    "Aromatic Basmati Rice 1kg",
    "Instant Coffee Classic Jar",
  ],
  "books-stationery": [
    "Hardcover Productivity Planner",
    "Smooth Gel Pen Pack 10pcs",
    "A4 Spiral Notebook 200 Pages",
    "Desk Sticky Notes Combo",
    "Beginner English Practice Book",
  ],
  automotive: [
    "Car Phone Holder Dashboard Mount",
    "Motorbike Riding Gloves",
    "Microfiber Car Cleaning Cloth Set",
    "Portable Tire Pressure Gauge",
    "Car Air Freshener Premium",
  ],
  "islamic-items": [
    "Soft Velvet Prayer Mat",
    "Digital Tasbih Counter",
    "Pocket Quran Translation Book",
    "Attar Roll On Fragrance",
    "Modest Gift Box Set",
  ],
};

const wordsToSlug = (value) =>
  value
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

function productImageUrl(index) {
  return `${PRODUCT_IMAGE_BASE}/product-${String(index).padStart(3, "0")}.png`;
}

function categoryImageUrl(slug) {
  return `${CATEGORY_IMAGE_BASE}/${slug}.png`;
}

function reviewImageUrl(index) {
  return `${REVIEW_IMAGE_BASE}/review-${String(index).padStart(2, "0")}.png`;
}

function buildProducts() {
  const products = [];
  for (const category of categories) {
    const names = productNamesByCategory[category.slug] || [];
    names.forEach((name, index) => {
      const globalIndex = products.length + 1;
      const price = 650 + globalIndex * 95;
      products.push({
        name,
        categorySlug: category.slug,
        price,
        offerPrice: index % 2 === 0 ? price - 80 - index * 15 : undefined,
        stock: 20 + ((globalIndex * 7) % 48),
        featured: globalIndex <= 18 || index === 0,
        tags: [category.name, "ready stock", "fast delivery"],
      });
    });
  }
  return products;
}

function sanitizeFolderPart(value) {
  return value
    .split("/")
    .map((part) => part.replace(/[^a-z0-9_-]/gi, "").trim())
    .filter(Boolean)
    .join("/");
}

function signCloudinaryParams(params, apiSecret) {
  const payload = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== "")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("&");

  return crypto.createHash("sha1").update(`${payload}${apiSecret}`).digest("hex");
}

function mimeFromPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  return "application/octet-stream";
}

async function resolveImageUrl(localUrl) {
  const shouldUpload =
    process.env.IMAGE_STORAGE_DRIVER === "cloudinary" &&
    process.env.CLOUDINARY_CLOUD_NAME?.trim() &&
    process.env.CLOUDINARY_API_KEY?.trim() &&
    process.env.CLOUDINARY_API_SECRET?.trim();

  if (!shouldUpload) return localUrl;
  if (cloudinaryCache.has(localUrl)) return cloudinaryCache.get(localUrl);

  const cloudName = process.env.CLOUDINARY_CLOUD_NAME.trim();
  const apiKey = process.env.CLOUDINARY_API_KEY.trim();
  const apiSecret = process.env.CLOUDINARY_API_SECRET.trim();
  const baseFolder = sanitizeFolderPart(process.env.CLOUDINARY_FOLDER || "ecommerce");
  const localPath = path.join(rootDir, "public", localUrl.replace(/^\//, ""));
  const relativeParts = localUrl.replace(/^\/uploads\//, "").split("/");
  const folder = [baseFolder, sanitizeFolderPart(relativeParts.slice(0, -1).join("/"))].filter(Boolean).join("/");
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const paramsToSign = { folder, timestamp };
  const signature = signCloudinaryParams(paramsToSign, apiSecret);
  const bytes = await fs.readFile(localPath);
  const form = new FormData();

  form.append("file", new Blob([new Uint8Array(bytes)], { type: mimeFromPath(localPath) }), path.basename(localPath));
  form.append("api_key", apiKey);
  form.append("timestamp", timestamp);
  form.append("folder", folder);
  form.append("signature", signature);

  const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
    method: "POST",
    body: form,
  });
  const json = await response.json().catch(() => ({}));

  if (!response.ok || !json.secure_url) {
    throw new Error(json.error?.message || `Cloudinary upload failed for ${localUrl}`);
  }

  cloudinaryCache.set(localUrl, json.secure_url);
  return json.secure_url;
}

async function seedUsers() {
  const adminEmail = process.env.ADMIN_EMAIL || "techtemlead@gmail.com";
  const adminPassword = process.env.ADMIN_PASSWORD || "admin12345";
  const adminPasswordHash = await bcrypt.hash(adminPassword, 10);

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {
      name: "Admin",
      password: adminPasswordHash,
      role: "ADMIN",
      blocked: false,
    },
    create: {
      name: "Admin",
      email: adminEmail,
      password: adminPasswordHash,
      role: "ADMIN",
      blocked: false,
    },
  });

  const demoPasswordHash = await bcrypt.hash("Hredoy@12345", 10);
  await prisma.user.upsert({
    where: { email: "arifuzzamanhredoy@gmail.com" },
    update: {
      name: "Hredoy",
      password: demoPasswordHash,
      role: "USER",
      blocked: false,
    },
    create: {
      name: "Hredoy",
      email: "arifuzzamanhredoy@gmail.com",
      password: demoPasswordHash,
      role: "USER",
      blocked: false,
    },
  });
}

async function seedStore() {
  const logoUrl = await resolveImageUrl(LOGO_IMAGE_URL);
  await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {
      storeName: BRAND_NAME,
      logoUrl,
      currency: "BDT",
      shippingInsideDhaka: 80,
      shippingRangpur: 100,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 5000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
      lowStockThreshold: 8,
      facebookUrl: "https://facebook.com/",
      whatsappUrl: "https://wa.me/8801700000000",
      returnRefundPolicy:
        "Products can be returned within 3 days if unused, undamaged, and returned with original packaging. Delivery charge is non-refundable unless the product is defective.",
      aboutUs: `${BRAND_NAME} is a production-ready online store focused on trusted products, clean pricing, quick support, and reliable delivery across Bangladesh.`,
      privacyPolicy: `${BRAND_NAME} respects customer privacy and only uses order information for account, delivery, support, and service improvement purposes.`,
      termsConditions: `By using ${BRAND_NAME}, customers agree to provide accurate delivery details, follow payment instructions, and review product information before ordering.`,
      aboutFaqs: [
        { question: "Do you deliver outside Dhaka?", answer: "Yes, delivery is available across Bangladesh." },
        { question: "Can I pay cash on delivery?", answer: "Yes, COD is enabled for eligible orders." },
      ],
    },
    create: {
      id: "default",
      storeName: BRAND_NAME,
      logoUrl,
      currency: "BDT",
      shippingInsideDhaka: 80,
      shippingRangpur: 100,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 5000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
      lowStockThreshold: 8,
      facebookUrl: "https://facebook.com/",
      whatsappUrl: "https://wa.me/8801700000000",
      returnRefundPolicy:
        "Products can be returned within 3 days if unused, undamaged, and returned with original packaging. Delivery charge is non-refundable unless the product is defective.",
      aboutUs: `${BRAND_NAME} is a production-ready online store focused on trusted products, clean pricing, quick support, and reliable delivery across Bangladesh.`,
      privacyPolicy: `${BRAND_NAME} respects customer privacy and only uses order information for account, delivery, support, and service improvement purposes.`,
      termsConditions: `By using ${BRAND_NAME}, customers agree to provide accurate delivery details, follow payment instructions, and review product information before ordering.`,
      aboutFaqs: [
        { question: "Do you deliver outside Dhaka?", answer: "Yes, delivery is available across Bangladesh." },
        { question: "Can I pay cash on delivery?", answer: "Yes, COD is enabled for eligible orders." },
      ],
    },
  });
}

async function seedCategories() {
  const categoryBySlug = new Map();
  for (const category of categories) {
    const row = await prisma.category.upsert({
      where: { slug: category.slug },
      update: {
        name: category.name,
        imageUrl: await resolveImageUrl(categoryImageUrl(category.slug)),
        discountPercent: category.discountPercent,
        isActive: true,
      },
      create: {
        slug: category.slug,
        name: category.name,
        imageUrl: await resolveImageUrl(categoryImageUrl(category.slug)),
        discountPercent: category.discountPercent,
        isActive: true,
      },
      select: { id: true, name: true },
    });
    categoryBySlug.set(category.slug, row);
  }
  return categoryBySlug;
}

async function seedBanners() {
  const banners = [
    {
      slot: "home-hero-1",
      title: "Launch Week Deals",
      imageUrl: `${BANNER_IMAGE_BASE}/banner-1.png`,
      linkUrl: "/products",
      sortOrder: 1,
    },
    {
      slot: "home-hero-2",
      title: "Premium Everyday Picks",
      imageUrl: `${BANNER_IMAGE_BASE}/banner-2.png`,
      linkUrl: "/categories/electronics",
      sortOrder: 2,
    },
    {
      slot: "home-hero-3",
      title: "Fast Delivery Across Bangladesh",
      imageUrl: `${BANNER_IMAGE_BASE}/banner-3.png`,
      linkUrl: "/checkout",
      sortOrder: 3,
    },
  ];

  for (const banner of banners) {
    await prisma.banner.upsert({
      where: { slot: banner.slot },
      update: {
        title: banner.title,
        imageUrl: await resolveImageUrl(banner.imageUrl),
        linkUrl: banner.linkUrl,
        sortOrder: banner.sortOrder,
        isActive: true,
      },
      create: {
        slot: banner.slot,
        title: banner.title,
        imageUrl: await resolveImageUrl(banner.imageUrl),
        linkUrl: banner.linkUrl,
        sortOrder: banner.sortOrder,
        isActive: true,
      },
    });
  }
}

async function seedCoupons() {
  const now = new Date();
  const nextYear = new Date(now);
  nextYear.setFullYear(now.getFullYear() + 1);

  await prisma.coupon.upsert({
    where: { code: "WELCOME10" },
    update: {
      description: "10% welcome discount for new customers.",
      type: "PERCENT",
      value: 10,
      minSubtotal: 1000,
      maxDiscount: 300,
      startsAt: now,
      endsAt: nextYear,
      isActive: true,
    },
    create: {
      code: "WELCOME10",
      description: "10% welcome discount for new customers.",
      type: "PERCENT",
      value: 10,
      minSubtotal: 1000,
      maxDiscount: 300,
      startsAt: now,
      endsAt: nextYear,
      isActive: true,
    },
  });

  await prisma.coupon.upsert({
    where: { code: "SAVE150" },
    update: {
      description: "Flat 150 BDT discount for larger carts.",
      type: "FIXED",
      value: 150,
      minSubtotal: 2500,
      startsAt: now,
      endsAt: nextYear,
      isActive: true,
    },
    create: {
      code: "SAVE150",
      description: "Flat 150 BDT discount for larger carts.",
      type: "FIXED",
      value: 150,
      minSubtotal: 2500,
      startsAt: now,
      endsAt: nextYear,
      isActive: true,
    },
  });
}

function productDescription(product, categoryName) {
  return `${product.name} from ${BRAND_NAME} is selected for customers who want practical quality, clear pricing, and dependable delivery. Category: ${categoryName}. Key benefits: ${product.tags.join(", ")}. This item is suitable for daily use, gifting, and regular household or personal needs. Package includes the main product, standard protective packaging, and customer support after purchase.`;
}

async function deactivateOldPlaceholderProducts() {
  await prisma.product.updateMany({
    where: {
      slug: { contains: "-product-" },
    },
    data: { isActive: false },
  });
}

async function seedProducts(categoryBySlug) {
  const products = buildProducts();
  let createdOrUpdated = 0;

  for (const [index, product] of products.entries()) {
    const category = categoryBySlug.get(product.categorySlug);
    if (!category) continue;

    const slug = wordsToSlug(product.name);
    const sku = `NEX-${String(index + 1).padStart(4, "0")}`;
    const row = await prisma.product.upsert({
      where: { slug },
      update: {
        name: product.name,
        description: productDescription(product, category.name),
        price: product.price,
        offerPrice: product.offerPrice ?? null,
        investedAmount: Math.floor(product.price * 0.62),
        discountPercent: product.offerPrice ? Math.round(((product.price - product.offerPrice) / product.price) * 100) : null,
        sku,
        stock: product.stock,
        isActive: true,
        isFeatured: !!product.featured,
        categoryId: category.id,
      },
      create: {
        slug,
        name: product.name,
        description: productDescription(product, category.name),
        price: product.price,
        offerPrice: product.offerPrice ?? null,
        investedAmount: Math.floor(product.price * 0.62),
        discountPercent: product.offerPrice ? Math.round(((product.price - product.offerPrice) / product.price) * 100) : null,
        sku,
        stock: product.stock,
        isActive: true,
        isFeatured: !!product.featured,
        categoryId: category.id,
      },
      select: { id: true, name: true },
    });

    await prisma.productCategory.upsert({
      where: { productId_categoryId: { productId: row.id, categoryId: category.id } },
      update: {},
      create: { productId: row.id, categoryId: category.id },
    });

    await prisma.productImage.deleteMany({ where: { productId: row.id } });
    await prisma.productVariant.deleteMany({ where: { productId: row.id } });
    await prisma.review.deleteMany({ where: { productId: row.id } });

    const mainImage = await resolveImageUrl(productImageUrl(index + 1));
    await prisma.productImage.createMany({
      data: [
        { productId: row.id, url: mainImage, alt: `${product.name} front image`, sortOrder: 0 },
        { productId: row.id, url: mainImage, alt: `${product.name} packaging image`, sortOrder: 1 },
      ],
    });

    const variantTypes = product.categorySlug.includes("fashion") ? ["Size", "Color"] : ["Option", "Color"];
    const variants = [
      { type: variantTypes[0], value: product.categorySlug.includes("fashion") ? "M" : "Standard", priceDiff: 0, stock: Math.max(5, Math.floor(product.stock / 2)) },
      { type: variantTypes[0], value: product.categorySlug.includes("fashion") ? "L" : "Premium", priceDiff: 120, stock: Math.max(3, Math.floor(product.stock / 3)) },
      { type: variantTypes[1], value: index % 2 === 0 ? "Black" : "Rose", priceDiff: 0, stock: Math.max(4, Math.floor(product.stock / 4)) },
    ];

    for (const variant of variants) {
      const createdVariant = await prisma.productVariant.create({
        data: {
          productId: row.id,
          type: variant.type,
          value: variant.value,
          priceDiff: variant.priceDiff,
          investedAmount: Math.floor((product.price + variant.priceDiff) * 0.60),
          stock: variant.stock,
        },
      });
      await prisma.productVariantImage.create({
        data: {
          variantId: createdVariant.id,
          url: mainImage,
          alt: `${product.name} ${variant.value}`,
          sortOrder: 0,
        },
      });
    }

    if ((index + 1) % 2 === 0 || index < 12) {
      await prisma.review.create({
        data: {
          productId: row.id,
          authorName: ["Mahin", "Nabila", "Rafi", "Tasnim", "Sakib"][index % 5],
          rating: 4 + (index % 2),
          comment: `Good quality product from ${BRAND_NAME}. Packaging was neat and delivery was smooth.`,
          imageUrls: [await resolveImageUrl(reviewImageUrl((index % 12) + 1))],
          isVerifiedPurchase: true,
        },
      });
    }

    createdOrUpdated++;
  }

  return createdOrUpdated;
}

async function main() {
  console.log(`Seeding ${BRAND_NAME} production catalog...`);
  await seedUsers();
  await seedStore();
  const categoryBySlug = await seedCategories();
  await seedBanners();
  await seedCoupons();
  await deactivateOldPlaceholderProducts();
  const productCount = await seedProducts(categoryBySlug);

  console.log(`Seeded admin account: ${process.env.ADMIN_EMAIL || "techtemlead@gmail.com"}`);
  console.log(`Seeded categories: ${categoryBySlug.size}`);
  console.log(`Seeded products: ${productCount}`);
  console.log(`Image mode: ${process.env.IMAGE_STORAGE_DRIVER === "cloudinary" ? "Cloudinary" : "Local files"}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
