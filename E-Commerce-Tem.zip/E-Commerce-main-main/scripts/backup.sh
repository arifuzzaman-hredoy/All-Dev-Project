#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/ecommerce}"
BACKUP_ROOT="${BACKUP_ROOT:-/opt/backups/ecommerce}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"

mkdir -p "$BACKUP_DIR"
cd "$APP_DIR"

if [ -f .env.production ]; then
  cp .env.production "$BACKUP_DIR/env.production.backup"
  chmod 600 "$BACKUP_DIR/env.production.backup"
fi

docker compose exec -T ecommerce sh -lc 'pg_dump "$DATABASE_URL"' > "$BACKUP_DIR/database.sql"

tar -czf "$BACKUP_ROOT/$TIMESTAMP.tar.gz" -C "$BACKUP_ROOT" "$TIMESTAMP"
rm -rf "$BACKUP_DIR"

find "$BACKUP_ROOT" -name '*.tar.gz' -mtime +14 -delete

echo "Backup created: $BACKUP_ROOT/$TIMESTAMP.tar.gz"
