#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/ecommerce}"
BRANCH="${BRANCH:-main}"
REPO_URL="${REPO_URL:-git@github.com-ecommerce:techtemlead-lab/E-Commerce.git}"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed."
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose plugin is not installed."
  exit 1
fi

if [ ! -d "$APP_DIR/.git" ]; then
  mkdir -p "$(dirname "$APP_DIR")"
  git clone --branch "$BRANCH" "$REPO_URL" "$APP_DIR"
fi

cd "$APP_DIR"

git fetch origin "$BRANCH"
git reset --hard "origin/$BRANCH"

if [ ! -f "$APP_DIR/.env.production" ]; then
  echo "Missing $APP_DIR/.env.production"
  exit 1
fi

chmod +x "$APP_DIR"/scripts/*.sh || true

docker compose pull --ignore-pull-failures || true
docker compose up -d --build --remove-orphans
docker image prune -f

docker compose ps