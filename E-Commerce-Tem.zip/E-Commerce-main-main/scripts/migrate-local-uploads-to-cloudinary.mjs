import crypto from "crypto";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..");

dotenv.config({ path: path.join(rootDir, ".env.production") });
dotenv.config({ path: path.join(rootDir, ".env") });

const uploadsDir = path.resolve(process.env.UPLOADS_DIR || path.join(rootDir, "public", "uploads"));
const onlyReferenced = process.env.MIGRATE_ONLY_REFERENCED === "true";

const required = [
  "DATABASE_URL",
  "CLOUDINARY_CLOUD_NAME",
  "CLOUDINARY_API_KEY",
  "CLOUDINARY_API_SECRET",
];

for (const key of required) {
  if (!process.env[key]?.trim()) {
    console.error(`Missing ${key}`);
    process.exit(1);
  }
}

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});

function sanitizeFolderPart(value) {
  return value
    .split("/")
    .map((part) => part.replace(/[^a-z0-9_-]/gi, "").trim())
    .filter(Boolean)
    .join("/");
}

function signCloudinaryParams(params, apiSecret) {
  const payload = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== "")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("&");

  return crypto.createHash("sha1").update(`${payload}${apiSecret}`).digest("hex");
}

function mimeFromPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  return "application/octet-stream";
}

function isLocalUploadUrl(value) {
  return typeof value === "string" && value.startsWith("/uploads/");
}

function isCloudinaryUrl(value) {
  if (typeof value !== "string") return false;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === "res.cloudinary.com";
  } catch {
    return false;
  }
}

async function walkFiles(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
  const files = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await walkFiles(fullPath)));
    } else if (entry.isFile() && /\.(png|jpe?g|webp)$/i.test(entry.name)) {
      files.push(fullPath);
    }
  }

  return files;
}

async function uploadFileToCloudinary(filePath, localUrl) {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME.trim();
  const apiKey = process.env.CLOUDINARY_API_KEY.trim();
  const apiSecret = process.env.CLOUDINARY_API_SECRET.trim();
  const baseFolder = sanitizeFolderPart(process.env.CLOUDINARY_FOLDER || "ecommerce");
  const relativeParts = localUrl.replace(/^\/uploads\//, "").split("/");
  const localFolder = sanitizeFolderPart(relativeParts.slice(0, -1).join("/")) || "uploads";
  const folder = [baseFolder, localFolder].filter(Boolean).join("/");
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const paramsToSign = { folder, timestamp };
  const signature = signCloudinaryParams(paramsToSign, apiSecret);
  const bytes = await fs.readFile(filePath);
  const form = new FormData();

  form.append("file", new Blob([new Uint8Array(bytes)], { type: mimeFromPath(filePath) }), path.basename(filePath));
  form.append("api_key", apiKey);
  form.append("timestamp", timestamp);
  form.append("folder", folder);
  form.append("signature", signature);

  const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
    method: "POST",
    body: form,
  });
  const json = await response.json().catch(() => ({}));

  if (!response.ok || !json.secure_url) {
    throw new Error(json?.error?.message || `Cloudinary upload failed for ${localUrl}`);
  }

  return json.secure_url;
}

async function collectReferencedLocalUrls() {
  const urls = new Set();

  const [productImages, variantImages, categories, banners, settings, reviews] = await Promise.all([
    prisma.productImage.findMany({ select: { url: true } }),
    prisma.productVariantImage.findMany({ select: { url: true } }),
    prisma.category.findMany({ select: { imageUrl: true } }),
    prisma.banner.findMany({ select: { imageUrl: true } }),
    prisma.storeSettings.findMany({
      select: {
        logoUrl: true,
        manualBkashImageUrl: true,
        manualNagadImageUrl: true,
        manualRocketImageUrl: true,
      },
    }),
    prisma.review.findMany({ select: { imageUrls: true } }),
  ]);

  for (const row of productImages) if (isLocalUploadUrl(row.url)) urls.add(row.url);
  for (const row of variantImages) if (isLocalUploadUrl(row.url)) urls.add(row.url);
  for (const row of categories) if (isLocalUploadUrl(row.imageUrl)) urls.add(row.imageUrl);
  for (const row of banners) if (isLocalUploadUrl(row.imageUrl)) urls.add(row.imageUrl);
  for (const row of settings) {
    for (const value of [row.logoUrl, row.manualBkashImageUrl, row.manualNagadImageUrl, row.manualRocketImageUrl]) {
      if (isLocalUploadUrl(value)) urls.add(value);
    }
  }
  for (const row of reviews) {
    for (const value of row.imageUrls || []) if (isLocalUploadUrl(value)) urls.add(value);
  }

  return urls;
}

async function updateDatabaseUrlReferences(urlMap) {
  let updated = 0;

  const productImages = await prisma.productImage.findMany({ select: { id: true, url: true } });
  for (const row of productImages) {
    const next = urlMap.get(row.url);
    if (!next || isCloudinaryUrl(row.url)) continue;
    await prisma.productImage.update({ where: { id: row.id }, data: { url: next } });
    updated++;
  }

  const variantImages = await prisma.productVariantImage.findMany({ select: { id: true, url: true } });
  for (const row of variantImages) {
    const next = urlMap.get(row.url);
    if (!next || isCloudinaryUrl(row.url)) continue;
    await prisma.productVariantImage.update({ where: { id: row.id }, data: { url: next } });
    updated++;
  }

  const categories = await prisma.category.findMany({ select: { id: true, imageUrl: true } });
  for (const row of categories) {
    const next = row.imageUrl ? urlMap.get(row.imageUrl) : undefined;
    if (!next) continue;
    await prisma.category.update({ where: { id: row.id }, data: { imageUrl: next } });
    updated++;
  }

  const banners = await prisma.banner.findMany({ select: { id: true, imageUrl: true } });
  for (const row of banners) {
    const next = urlMap.get(row.imageUrl);
    if (!next) continue;
    await prisma.banner.update({ where: { id: row.id }, data: { imageUrl: next } });
    updated++;
  }

  const reviews = await prisma.review.findMany({ select: { id: true, imageUrls: true } });
  for (const row of reviews) {
    const nextUrls = (row.imageUrls || []).map((url) => urlMap.get(url) || url);
    if (JSON.stringify(nextUrls) === JSON.stringify(row.imageUrls || [])) continue;
    await prisma.review.update({ where: { id: row.id }, data: { imageUrls: nextUrls } });
    updated++;
  }

  const settings = await prisma.storeSettings.findMany({
    select: {
      id: true,
      logoUrl: true,
      manualBkashImageUrl: true,
      manualNagadImageUrl: true,
      manualRocketImageUrl: true,
    },
  });

  for (const row of settings) {
    const data = {};
    const fields = [
      "logoUrl",
      "manualBkashImageUrl",
      "manualNagadImageUrl",
      "manualRocketImageUrl",
    ];

    for (const field of fields) {
      const current = row[field];
      const next = current ? urlMap.get(current) : undefined;
      if (next) data[field] = next;
    }

    if (Object.keys(data).length) {
      await prisma.storeSettings.update({ where: { id: row.id }, data });
      updated++;
    }
  }

  const fallbackPaymentUpdates = {
    manualBkashImageUrl: urlMap.get("/uploads/payments/bkash.png"),
    manualNagadImageUrl: urlMap.get("/uploads/payments/nagad.png"),
    manualRocketImageUrl: urlMap.get("/uploads/payments/rocket-bgf.png"),
  };
  const nonEmptyFallbacks = Object.fromEntries(
    Object.entries(fallbackPaymentUpdates).filter(([, value]) => !!value),
  );

  if (Object.keys(nonEmptyFallbacks).length) {
    const current = await prisma.storeSettings.findUnique({ where: { id: "default" } });
    const data = {};
    for (const [field, value] of Object.entries(nonEmptyFallbacks)) {
      if (!current?.[field]) data[field] = value;
    }
    if (Object.keys(data).length) {
      await prisma.storeSettings.upsert({
        where: { id: "default" },
        update: data,
        create: { id: "default", ...data },
      });
      updated++;
    }
  }

  return updated;
}

async function main() {
  const allFiles = await walkFiles(uploadsDir);
  const availableLocalUrls = new Map(
    allFiles.map((filePath) => {
      const relative = path.relative(uploadsDir, filePath).split(path.sep).join("/");
      return [`/uploads/${relative}`, filePath];
    }),
  );

  const referencedUrls = await collectReferencedLocalUrls();
  const uploadTargets = onlyReferenced
    ? [...referencedUrls]
    : [...availableLocalUrls.keys()];

  const urlMap = new Map();
  let uploaded = 0;
  let skipped = 0;

  for (const localUrl of uploadTargets) {
    const filePath = availableLocalUrls.get(localUrl);
    if (!filePath) {
      console.warn(`Missing local file for DB URL: ${localUrl}`);
      skipped++;
      continue;
    }

    process.stdout.write(`Uploading ${localUrl} ... `);
    const cloudUrl = await uploadFileToCloudinary(filePath, localUrl);
    urlMap.set(localUrl, cloudUrl);
    uploaded++;
    console.log("done");
  }

  const updated = await updateDatabaseUrlReferences(urlMap);

  console.log("\nCloudinary migration finished.");
  console.log(`Uploaded files: ${uploaded}`);
  console.log(`Skipped missing files: ${skipped}`);
  console.log(`Database rows updated: ${updated}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
