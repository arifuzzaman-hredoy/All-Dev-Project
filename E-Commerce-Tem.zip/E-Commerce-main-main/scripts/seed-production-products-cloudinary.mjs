import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

const BRAND_NAME = "NexoraMart";
const ROOT_DIR = process.cwd();
const GENERATED_IMAGE_DIR = path.join(ROOT_DIR, "scripts", "generated-product-images");

function requiredEnv(name) {
  const value = process.env[name];
  if (!value || value.trim() === "") {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value.trim();
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function money(base, index) {
  return base + index * 37;
}

function svgEscape(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function makeSvg({ title, category, price, index }) {
  const palettes = [
    ["#0f172a", "#e0f2fe", "#38bdf8"],
    ["#111827", "#fce7f3", "#db2777"],
    ["#14532d", "#dcfce7", "#22c55e"],
    ["#4c1d95", "#ede9fe", "#8b5cf6"],
    ["#7c2d12", "#ffedd5", "#f97316"],
    ["#164e63", "#cffafe", "#06b6d4"],
    ["#831843", "#fce7f3", "#ec4899"],
    ["#1e293b", "#f8fafc", "#64748b"],
  ];
  const [dark, light, accent] = palettes[index % palettes.length];

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="1200" height="1200" viewBox="0 0 1200 1200" xmlns="http://www.w3.org/2000/svg">
  <rect width="1200" height="1200" fill="${light}"/>
  <circle cx="990" cy="180" r="190" fill="${accent}" opacity="0.16"/>
  <circle cx="150" cy="1050" r="260" fill="${accent}" opacity="0.14"/>
  <rect x="110" y="120" width="980" height="960" rx="64" fill="#ffffff" opacity="0.92"/>
  <rect x="170" y="190" width="860" height="600" rx="48" fill="${dark}"/>
  <circle cx="600" cy="490" r="180" fill="${accent}" opacity="0.95"/>
  <rect x="435" y="415" width="330" height="150" rx="34" fill="#ffffff" opacity="0.95"/>
  <text x="600" y="485" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="46" font-weight="800" fill="${dark}">
    ${svgEscape(BRAND_NAME)}
  </text>
  <text x="600" y="540" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="26" font-weight="700" fill="${dark}">
    Premium Product
  </text>
  <text x="600" y="865" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="36" font-weight="800" fill="${dark}">
    ${svgEscape(title)}
  </text>
  <text x="600" y="915" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="600" fill="#64748b">
    ${svgEscape(category)}
  </text>
  <text x="600" y="980" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="34" font-weight="900" fill="${accent}">
    ৳${price}
  </text>
</svg>`;
}

async function uploadToCloudinary({ localFilePath, publicId }) {
  const cloudName = requiredEnv("CLOUDINARY_CLOUD_NAME");
  const apiKey = requiredEnv("CLOUDINARY_API_KEY");
  const apiSecret = requiredEnv("CLOUDINARY_API_SECRET");
  const folderRoot = process.env.CLOUDINARY_FOLDER || "ecommerce";

  const fileBuffer = await fs.readFile(localFilePath);
  const fileDataUri = `data:image/svg+xml;base64,${fileBuffer.toString("base64")}`;

  const timestamp = Math.floor(Date.now() / 1000).toString();
  const params = {
    folder: `${folderRoot}/seed-products`,
    overwrite: "true",
    public_id: publicId,
    timestamp,
  };

  const stringToSign =
    Object.keys(params)
      .sort()
      .map((key) => `${key}=${params[key]}`)
      .join("&") + apiSecret;

  const signature = crypto.createHash("sha1").update(stringToSign).digest("hex");

  const formData = new FormData();
  formData.append("file", fileDataUri);
  formData.append("api_key", apiKey);
  formData.append("signature", signature);
  formData.append("timestamp", timestamp);
  formData.append("folder", params.folder);
  formData.append("public_id", params.public_id);
  formData.append("overwrite", params.overwrite);

  const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
    method: "POST",
    body: formData,
  });

  const json = await response.json();

  if (!response.ok || !json.secure_url) {
    throw new Error(`Cloudinary upload failed for ${publicId}: ${JSON.stringify(json)}`);
  }

  return json.secure_url;
}

const categories = [
  { name: "Mobile & Gadgets", slug: "mobile-gadgets", discountPercent: 8 },
  { name: "Electronics", slug: "electronics", discountPercent: 7 },
  { name: "Men Fashion", slug: "men-fashion", discountPercent: 10 },
  { name: "Women Fashion", slug: "women-fashion", discountPercent: 10 },
  { name: "Beauty & Care", slug: "beauty-care", discountPercent: 12 },
  { name: "Home & Living", slug: "home-living", discountPercent: 6 },
  { name: "Sports & Fitness", slug: "sports-fitness", discountPercent: 5 },
  { name: "Baby & Kids", slug: "baby-kids", discountPercent: 5 },
  { name: "Grocery Essentials", slug: "grocery-essentials", discountPercent: 4 },
  { name: "Accessories", slug: "accessories", discountPercent: 9 },
];

const productNames = [
  ["Mobile & Gadgets", "Smart Fitness Band", 1490],
  ["Mobile & Gadgets", "Wireless Bluetooth Earbuds", 1890],
  ["Mobile & Gadgets", "Fast Charging USB-C Cable", 390],
  ["Mobile & Gadgets", "20W USB-C Power Adapter", 790],
  ["Mobile & Gadgets", "Magnetic Phone Holder", 450],
  ["Mobile & Gadgets", "Premium Phone Back Cover", 350],

  ["Electronics", "Mini Portable Speaker", 1650],
  ["Electronics", "LED Desk Lamp", 1250],
  ["Electronics", "Smart Extension Socket", 990],
  ["Electronics", "Rechargeable Table Fan", 2490],
  ["Electronics", "Digital Kitchen Scale", 890],
  ["Electronics", "USB Rechargeable Torch", 690],

  ["Men Fashion", "Premium Cotton T-Shirt", 690],
  ["Men Fashion", "Classic Polo Shirt", 890],
  ["Men Fashion", "Slim Fit Denim Jeans", 1490],
  ["Men Fashion", "Casual Leather Belt", 550],
  ["Men Fashion", "Formal Wallet", 650],
  ["Men Fashion", "Comfort Sports Shorts", 590],

  ["Women Fashion", "Elegant Printed Kurti", 1190],
  ["Women Fashion", "Soft Cotton Scarf", 490],
  ["Women Fashion", "Daily Wear Handbag", 1390],
  ["Women Fashion", "Comfort Leggings", 590],
  ["Women Fashion", "Classic Hair Claw Set", 280],
  ["Women Fashion", "Fashion Jewelry Combo", 750],

  ["Beauty & Care", "Aloe Vera Face Wash", 390],
  ["Beauty & Care", "Vitamin C Serum", 790],
  ["Beauty & Care", "Herbal Hair Oil", 450],
  ["Beauty & Care", "Moisturizing Body Lotion", 620],
  ["Beauty & Care", "Matte Lipstick", 350],
  ["Beauty & Care", "Skin Care Combo Pack", 1290],

  ["Home & Living", "Microfiber Towel Set", 690],
  ["Home & Living", "Non-Stick Fry Pan", 1490],
  ["Home & Living", "Storage Organizer Box", 550],
  ["Home & Living", "Ceramic Coffee Mug", 320],
  ["Home & Living", "Premium Bedsheet", 1790],
  ["Home & Living", "Kitchen Knife Set", 990],

  ["Sports & Fitness", "Yoga Mat", 890],
  ["Sports & Fitness", "Skipping Rope", 290],
  ["Sports & Fitness", "Sports Water Bottle", 390],
  ["Sports & Fitness", "Hand Grip Strengthener", 250],
  ["Sports & Fitness", "Gym Gloves", 450],
  ["Sports & Fitness", "Resistance Band Set", 690],

  ["Baby & Kids", "Kids Learning Puzzle", 390],
  ["Baby & Kids", "Soft Baby Towel", 490],
  ["Baby & Kids", "Cartoon School Bag", 990],
  ["Baby & Kids", "Baby Feeding Bottle", 350],
  ["Baby & Kids", "Kids Drawing Set", 450],
  ["Baby & Kids", "Baby Care Combo", 1190],

  ["Grocery Essentials", "Premium Basmati Rice 5kg", 790],
  ["Grocery Essentials", "Pure Mustard Oil 1L", 330],
  ["Grocery Essentials", "Premium Tea Pack", 280],
  ["Grocery Essentials", "Mixed Dry Fruits", 850],
  ["Grocery Essentials", "Organic Honey", 590],
  ["Grocery Essentials", "Spice Combo Pack", 420],

  ["Accessories", "Classic Sunglasses", 690],
  ["Accessories", "Travel Backpack", 1890],
  ["Accessories", "Minimal Wrist Watch", 1290],
  ["Accessories", "Laptop Sleeve Bag", 850],
  ["Accessories", "Keychain Gift Set", 250],
  ["Accessories", "Premium Cap", 390],
];

async function main() {
  requiredEnv("DATABASE_URL");
  requiredEnv("CLOUDINARY_CLOUD_NAME");
  requiredEnv("CLOUDINARY_API_KEY");
  requiredEnv("CLOUDINARY_API_SECRET");

  await fs.mkdir(GENERATED_IMAGE_DIR, { recursive: true });

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const adapter = new PrismaPg(pool);
  const prisma = new PrismaClient({ adapter });

  try {
    await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: {
        storeName: BRAND_NAME,
        currency: "BDT",
      },
      create: {
        id: "default",
        storeName: BRAND_NAME,
        currency: "BDT",
      },
    });

    const categoryMap = new Map();

    for (let i = 0; i < categories.length; i++) {
      const category = categories[i];
      const imageFile = path.join(GENERATED_IMAGE_DIR, `category-${category.slug}.svg`);
      const svg = makeSvg({
        title: category.name,
        category: BRAND_NAME,
        price: category.discountPercent,
        index: i,
      });
      await fs.writeFile(imageFile, svg, "utf8");

      const imageUrl = await uploadToCloudinary({
        localFilePath: imageFile,
        publicId: `category-${category.slug}`,
      });

      const row = await prisma.category.upsert({
        where: { slug: category.slug },
        update: {
          name: category.name,
          imageUrl,
          discountPercent: category.discountPercent,
          isActive: true,
        },
        create: {
          name: category.name,
          slug: category.slug,
          imageUrl,
          discountPercent: category.discountPercent,
          isActive: true,
        },
      });

      categoryMap.set(category.name, row);
      console.log(`Category ready: ${category.name}`);
    }

    for (let i = 0; i < productNames.length; i++) {
      const [categoryName, productName, basePrice] = productNames[i];
      const category = categoryMap.get(categoryName);

      if (!category) {
        throw new Error(`Missing category: ${categoryName}`);
      }

      const slug = slugify(productName);
      const sku = `NEX-${String(i + 1).padStart(4, "0")}`;
      const price = money(basePrice, i);
      const offerPrice = Math.max(99, Math.round(price * 0.88));
      const discountPercent = Math.round(((price - offerPrice) / price) * 100);
      const stock = 25 + ((i * 7) % 70);

      const imageFile = path.join(GENERATED_IMAGE_DIR, `${slug}.svg`);
      const svg = makeSvg({
        title: productName,
        category: categoryName,
        price: offerPrice,
        index: i,
      });
      await fs.writeFile(imageFile, svg, "utf8");

      const imageUrl = await uploadToCloudinary({
        localFilePath: imageFile,
        publicId: slug,
      });

      const product = await prisma.product.upsert({
        where: { slug },
        update: {
          name: productName,
          description: `${productName} from ${BRAND_NAME}. Premium quality, ready stock, trusted online shopping experience, and suitable for regular daily use.`,
          price,
          offerPrice,
          investedAmount: Math.round(price * 0.62),
          discountPercent,
          sku,
          stock,
          isFeatured: i % 4 === 0,
          isActive: true,
          categoryId: category.id,
        },
        create: {
          name: productName,
          slug,
          description: `${productName} from ${BRAND_NAME}. Premium quality, ready stock, trusted online shopping experience, and suitable for regular daily use.`,
          price,
          offerPrice,
          investedAmount: Math.round(price * 0.62),
          discountPercent,
          sku,
          stock,
          isFeatured: i % 4 === 0,
          isActive: true,
          categoryId: category.id,
        },
      });

      await prisma.productCategory.upsert({
        where: {
          productId_categoryId: {
            productId: product.id,
            categoryId: category.id,
          },
        },
        update: {},
        create: {
          productId: product.id,
          categoryId: category.id,
        },
      });

      await prisma.productImage.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productImage.create({
        data: {
          productId: product.id,
          url: imageUrl,
          alt: productName,
          sortOrder: 0,
        },
      });

      await prisma.productVariant.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productVariant.createMany({
        data: [
          {
            productId: product.id,
            type: "Quality",
            value: "Standard",
            priceDiff: 0,
            investedAmount: Math.round(price * 0.6),
            stock: Math.floor(stock * 0.6),
          },
          {
            productId: product.id,
            type: "Quality",
            value: "Premium",
            priceDiff: Math.round(price * 0.12),
            investedAmount: Math.round(price * 0.68),
            stock: Math.floor(stock * 0.4),
          },
        ],
      });

      console.log(`Product ready: ${productName}`);
    }

    console.log(`Done. Seeded ${productNames.length} products with Cloudinary images.`);
  } finally {
    await prisma.$disconnect();
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
