import "dotenv/config";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@prisma/client";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const BRAND_NAME = "NexoraMart";
const GENERATED_DIR = path.join(__dirname, "..", "public", "showcase-real-images");

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error("DATABASE_URL missing.");

const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
const apiKey = process.env.CLOUDINARY_API_KEY;
const apiSecret = process.env.CLOUDINARY_API_SECRET;
const cloudFolder = process.env.CLOUDINARY_FOLDER || "ecommerce";

if (!cloudName || !apiKey || !apiSecret || cloudName.startsWith("dummy")) {
  throw new Error("Real Cloudinary env missing. Run this on VPS production container with real Cloudinary keys.");
}

const pool = new Pool({ connectionString: DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

function slugify(input) {
  return input
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

function price(base, index) {
  return base + ((index * 149) % 950);
}

function cloudinarySignature(params) {
  const sorted = Object.keys(params)
    .sort()
    .map((key) => `${key}=${params[key]}`)
    .join("&");

  return crypto
    .createHash("sha1")
    .update(sorted + apiSecret)
    .digest("hex");
}

async function downloadRealImage(query, filePath) {
  const safeQuery = encodeURIComponent(query);
  const flickrQuery = encodeURIComponent(query.replace(/\s+/g, ","));

  const urls = [
    `https://source.unsplash.com/1200x1200/?${safeQuery}`,
    `https://loremflickr.com/1200/1200/${flickrQuery}`,
  ];

  let lastError = null;

  for (const url of urls) {
    try {
      const res = await fetch(url, {
        redirect: "follow",
        headers: {
          "user-agent": "Mozilla/5.0 NexoraMart Demo Seeder",
        },
      });

      if (!res.ok) {
        lastError = new Error(`Download failed ${res.status} ${url}`);
        continue;
      }

      const contentType = res.headers.get("content-type") || "";
      if (!contentType.startsWith("image/")) {
        lastError = new Error(`Not image response: ${contentType}`);
        continue;
      }

      const buffer = Buffer.from(await res.arrayBuffer());
      if (buffer.length < 5000) {
        lastError = new Error("Image file too small.");
        continue;
      }

      await fs.writeFile(filePath, buffer);
      return contentType;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error(`Could not download image for ${query}`);
}

async function uploadToCloudinary(filePath, publicId, contentType) {
  const timestamp = Math.floor(Date.now() / 1000);
  const params = {
    folder: `${cloudFolder}/showcase-real`,
    overwrite: "true",
    public_id: publicId,
    timestamp,
  };

  const signature = cloudinarySignature(params);
  const fileBuffer = await fs.readFile(filePath);

  const form = new FormData();
  form.append("file", new Blob([fileBuffer], { type: contentType || "image/jpeg" }), path.basename(filePath));
  form.append("api_key", apiKey);
  form.append("timestamp", String(timestamp));
  form.append("signature", signature);
  form.append("folder", params.folder);
  form.append("public_id", params.public_id);
  form.append("overwrite", params.overwrite);

  const res = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
    method: "POST",
    body: form,
  });

  const json = await res.json();

  if (!res.ok || !json.secure_url) {
    throw new Error(`Cloudinary upload failed: ${JSON.stringify(json)}`);
  }

  return json.secure_url;
}

const categories = [
  {
    name: "Electronics & Gadgets",
    slug: "electronics-gadgets",
    basePrice: 890,
    imageQuery: "electronics gadgets product photography",
    products: [
      "Wireless Earbuds",
      "Fast Charger Adapter",
      "Mini Projector",
      "Fitness Smart Band",
      "RGB Desk Lamp",
      "Power Bank",
      "Type C Cable Pack",
      "WiFi Security Camera",
    ],
  },
  {
    name: "Fashion & Lifestyle",
    slug: "fashion-lifestyle",
    basePrice: 650,
    imageQuery: "fashion accessories lifestyle product photography",
    products: [
      "Travel Backpack",
      "Leather Wallet",
      "Analog Watch",
      "Cotton T Shirt",
      "Running Shoes",
      "Sunglasses",
      "Crossbody Bag",
      "Soft Hoodie",
    ],
  },
  {
    name: "Beauty & Personal Care",
    slug: "beauty-personal-care",
    basePrice: 420,
    imageQuery: "beauty skincare product photography",
    products: [
      "Vitamin C Serum",
      "Face Wash",
      "Herbal Hair Oil",
      "Aloe Vera Gel",
      "Lip Tint",
      "Sunscreen SPF 50",
      "Rose Water Toner",
      "Charcoal Face Mask",
    ],
  },
  {
    name: "Home & Kitchen",
    slug: "home-kitchen",
    basePrice: 550,
    imageQuery: "home kitchen product photography",
    products: [
      "Air Diffuser",
      "Dinner Plate Set",
      "Spice Organizer",
      "Steel Water Bottle",
      "Kitchen Knife Set",
      "Bedsheet Set",
      "LED Night Light",
      "Nonstick Fry Pan",
    ],
  },
  {
    name: "Grocery & Food",
    slug: "grocery-food",
    basePrice: 280,
    imageQuery: "grocery food jar product photography",
    products: [
      "Organic Honey Jar",
      "Black Seed Pack",
      "Pink Salt Jar",
      "Peanut Butter",
      "Green Tea Pack",
      "Dry Fruits Jar",
      "Dates Box",
      "Mustard Oil Bottle",
    ],
  },
  {
    name: "Books & Stationery",
    slug: "books-stationery",
    basePrice: 220,
    imageQuery: "books stationery product photography",
    products: [
      "Productivity Planner",
      "Business Notebook",
      "Sketch Book",
      "Gel Pen Set",
      "Startup Strategy Book",
      "Habit Journal",
      "Desk Organizer",
      "A4 Paper Pack",
    ],
  },
  {
    name: "Islamic Lifestyle",
    slug: "islamic-lifestyle",
    basePrice: 390,
    imageQuery: "islamic gift product photography prayer mat tasbeeh",
    products: [
      "Prayer Mat",
      "Digital Tasbeeh Counter",
      "Attar Gift Set",
      "Islamic Wall Art",
      "Quran Bookmark Set",
      "Modest Gift Box",
      "Quran Stand",
      "Ramadan Decor Light",
    ],
  },
  {
    name: "Art & Craft",
    slug: "art-craft",
    basePrice: 320,
    imageQuery: "art craft supplies product photography",
    products: [
      "Acrylic Color Set",
      "Canvas Board",
      "Brush Kit",
      "DIY Craft Paper Pack",
      "Watercolor Set",
      "Clay Modeling Kit",
      "Calligraphy Pen Set",
      "Wall Decor Frame",
    ],
  },
];

async function getColumns(tableName) {
  const rows = await prisma.$queryRaw`
    SELECT column_name
    FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = ${tableName}
  `;

  return rows.map((row) => row.column_name);
}

async function insertDynamic(tableName, values) {
  const columns = await getColumns(tableName);
  if (!columns.length) return false;

  const entries = Object.entries(values).filter(([key]) => columns.includes(key));
  if (!entries.length) return false;

  const quotedColumns = entries.map(([key]) => `"${key}"`).join(", ");
  const placeholders = entries.map((_, index) => `$${index + 1}`).join(", ");
  const params = entries.map(([, value]) => value);

  await prisma.$executeRawUnsafe(
    `INSERT INTO "${tableName}" (${quotedColumns}) VALUES (${placeholders})`,
    ...params,
  );

  return true;
}

async function seedReviews(products) {
  const reviewColumns = await getColumns("Review");
  if (!reviewColumns.length) return;

  const deleteColumn = reviewColumns.includes("comment")
    ? "comment"
    : reviewColumns.includes("content")
      ? "content"
      : null;

  if (deleteColumn) {
    await prisma.$executeRawUnsafe(
      `DELETE FROM "Review" WHERE "${deleteColumn}" LIKE '%NexoraMart demo review%'`,
    );
  }

  const names = [
    "Rakib Hasan",
    "Nusrat Jahan",
    "Tanvir Ahmed",
    "Sadia Islam",
    "Mahmud Karim",
    "Farhana Akter",
    "Arif Hossain",
    "Nafisa Khan",
  ];

  const texts = [
    "Product quality looks premium and delivery experience was smooth.",
    "The product page feels clean, trustworthy, and easy to understand.",
    "Image, price, stock, and details are presented professionally.",
    "Good demo ecommerce experience with smooth product browsing.",
    "The store looks client-ready and suitable for real business customization.",
  ];

  let count = 0;

  for (let i = 0; i < Math.min(products.length, 32); i++) {
    const now = new Date();
    const text = `${texts[i % texts.length]} NexoraMart demo review.`;

    try {
      const ok = await insertDynamic("Review", {
        id: crypto.randomUUID(),
        productId: products[i].id,
        rating: 4 + (i % 2),
        title: "Verified demo review",
        comment: text,
        content: text,
        body: text,
        authorName: names[i % names.length],
        customerName: names[i % names.length],
        name: names[i % names.length],
        email: `demo.customer.${i + 1}@example.com`,
        isApproved: true,
        approved: true,
        isFeatured: i < 10,
        helpfulCount: 5 + i,
        createdAt: now,
        updatedAt: now,
      });

      if (ok) count++;
    } catch (error) {
      console.warn(`Review skipped: ${products[i].name} - ${error.message}`);
    }
  }

  console.log(`Reviews ready: ${count}`);
}

async function main() {
  await fs.mkdir(GENERATED_DIR, { recursive: true });

  await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {
      storeName: BRAND_NAME,
      logoUrl: "/nexoramart-logo.svg",
      currency: "BDT",
      shippingInsideDhaka: 70,
      shippingRangpur: 90,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 3000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
      facebookUrl: "https://facebook.com/nexoramart",
      instagramUrl: "https://instagram.com/nexoramart",
      youtubeUrl: "https://youtube.com/@nexoramart",
      tiktokUrl: "https://tiktok.com/@nexoramart",
      whatsappUrl: "https://wa.me/8801700000000",
      aboutUs:
        "NexoraMart is a polished ecommerce showcase store built for agency portfolio, client demo, and production-ready ecommerce presentation.",
      returnRefundPolicy:
        "Customers can request return or replacement within 7 days for eligible products. This is demo policy content and should be customized for real clients.",
      privacyPolicy:
        "This is demo privacy policy content for ecommerce showcase purpose. Replace it with client-specific policy before final launch.",
      termsConditions:
        "This is demo terms and conditions content for ecommerce showcase purpose. Replace it before real client launch.",
    },
    create: {
      id: "default",
      storeName: BRAND_NAME,
      logoUrl: "/nexoramart-logo.svg",
      currency: "BDT",
      shippingInsideDhaka: 70,
      shippingRangpur: 90,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 3000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
    },
  });

  await prisma.category.updateMany({
    data: { isActive: false },
  });

  await prisma.product.updateMany({
    data: { isActive: false },
  });

  const createdProducts = [];
  let index = 1;

  for (const cat of categories) {
    const categorySlug = cat.slug;
    const categoryFile = path.join(GENERATED_DIR, `category-${categorySlug}.jpg`);
    const categoryType = await downloadRealImage(cat.imageQuery, categoryFile);
    const categoryImageUrl = await uploadToCloudinary(
      categoryFile,
      `category-${categorySlug}`,
      categoryType,
    );

    const category = await prisma.category.upsert({
      where: { slug: categorySlug },
      update: {
        name: cat.name,
        imageUrl: categoryImageUrl,
        isActive: true,
      },
      create: {
        name: cat.name,
        slug: categorySlug,
        imageUrl: categoryImageUrl,
        isActive: true,
      },
    });

    for (const baseName of cat.products) {
      const productName = `Nexora ${baseName}`;
      const slug = slugify(productName);
      const sku = `NX-${String(index).padStart(4, "0")}`;
      const normalPrice = price(cat.basePrice, index);
      const offerPrice = Math.max(99, Math.round(normalPrice * (0.84 + (index % 4) * 0.02)));
      const discountPercent = Math.max(5, Math.round(((normalPrice - offerPrice) / normalPrice) * 100));
      const stock = 25 + ((index * 11) % 90);
      const investedAmount = Math.round(normalPrice * 0.58);

      const file = path.join(GENERATED_DIR, `${slug}.jpg`);
      const query = `${baseName} product photography white background ecommerce`;
      const contentType = await downloadRealImage(query, file);
      const imageUrl = await uploadToCloudinary(file, `product-${slug}`, contentType);

      const description =
        `${productName} is a realistic demo product for NexoraMart ecommerce showcase. ` +
        `This item includes real product-style photography, clear pricing, offer price, stock, category mapping, variants, wishlist support, cart testing, checkout testing, and product detail page demo content.`;

      const product = await prisma.product.upsert({
        where: { slug },
        update: {
          name: productName,
          description,
          price: normalPrice,
          offerPrice,
          investedAmount,
          discountPercent,
          sku,
          stock,
          isFeatured: index <= 16 || index % 3 === 0,
          isActive: true,
          categoryId: category.id,
        },
        create: {
          name: productName,
          slug,
          description,
          price: normalPrice,
          offerPrice,
          investedAmount,
          discountPercent,
          sku,
          stock,
          isFeatured: index <= 16 || index % 3 === 0,
          isActive: true,
          categoryId: category.id,
        },
      });

      await prisma.productCategory.upsert({
        where: {
          productId_categoryId: {
            productId: product.id,
            categoryId: category.id,
          },
        },
        update: {},
        create: {
          productId: product.id,
          categoryId: category.id,
        },
      });

      await prisma.productImage.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productImage.create({
        data: {
          productId: product.id,
          url: imageUrl,
          alt: productName,
          sortOrder: 0,
        },
      });

      await prisma.productVariant.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productVariant.createMany({
        data: [
          {
            productId: product.id,
            type: "Package",
            value: "Standard",
            priceDiff: 0,
            investedAmount,
            stock: Math.floor(stock * 0.6),
          },
          {
            productId: product.id,
            type: "Package",
            value: "Premium",
            priceDiff: Math.round(normalPrice * 0.12),
            investedAmount: Math.round(normalPrice * 0.66),
            stock: Math.floor(stock * 0.4),
          },
        ],
      });

      createdProducts.push(product);
      console.log(`Ready: ${productName}`);
      index++;
    }
  }

  await prisma.productDiscount.deleteMany({
    where: {
      note: {
        contains: "NexoraMart real demo",
      },
    },
  });

  for (const product of createdProducts.filter((_, i) => i % 5 === 0).slice(0, 16)) {
    await prisma.productDiscount.create({
      data: {
        scope: "PRODUCT",
        percentage: 12,
        isActive: true,
        productId: product.id,
        startsAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
        endsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        note: "NexoraMart real demo limited offer",
      },
    });
  }

  await seedReviews(createdProducts);

  console.log("======================================");
  console.log(`NexoraMart real image seed complete.`);
  console.log(`Categories: ${categories.length}`);
  console.log(`Products: ${createdProducts.length}`);
  console.log(`Local downloaded images: ${GENERATED_DIR}`);
  console.log(`Cloudinary folder: ${cloudFolder}/showcase-real`);
  console.log("======================================");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    await pool.end();
  });
