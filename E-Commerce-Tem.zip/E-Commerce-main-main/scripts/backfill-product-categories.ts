import { config } from "dotenv";
import { resolve } from "path";

config({ path: resolve(process.cwd(), ".env") });

// Minimal fallbacks so src/lib/env.ts validation does not fail
process.env.DATABASE_URL ||= "";
process.env.NEXTAUTH_URL ||= "http://localhost:3000";
process.env.NEXTAUTH_SECRET ||= "local-dev-secret";
process.env.SSLCOMMERZ_STORE_ID ||= "dummy-store-id";
process.env.SSLCOMMERZ_STORE_PASS ||= "dummy-store-pass";
process.env.SSLCOMMERZ_IS_LIVE ||= "false";

async function main() {
  const { prisma } = await import("../src/lib/prisma");

  const products = await prisma.product.findMany({
    select: {
      id: true,
      categoryId: true,
    },
  });

  let ensured = 0;
  let skipped = 0;

  for (const product of products) {
    if (!product.categoryId) {
      skipped += 1;
      continue;
    }

    await prisma.productCategory.upsert({
      where: {
        productId_categoryId: {
          productId: product.id,
          categoryId: product.categoryId,
        },
      },
      update: {},
      create: {
        productId: product.id,
        categoryId: product.categoryId,
      },
    });

    ensured += 1;
  }

  console.log("Done.");
  console.log(`Products scanned: ${products.length}`);
  console.log(`Category links ensured: ${ensured}`);
  console.log(`Skipped: ${skipped}`);

  await prisma.$disconnect();
}

main().catch((error) => {
  console.error("Backfill failed:");
  console.error(error);
  process.exit(1);
});