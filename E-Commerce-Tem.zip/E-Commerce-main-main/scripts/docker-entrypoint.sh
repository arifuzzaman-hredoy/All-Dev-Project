#!/usr/bin/env sh
set -eu

echo "Running Prisma migrations..."
npx prisma migrate deploy

echo "Starting Next.js on port ${PORT:-4050}..."
exec npm run start
