import "dotenv/config";
import crypto from "node:crypto";
import { v2 as cloudinary } from "cloudinary";
import { Pool } from "pg";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@prisma/client";

const BRAND_NAME = "NexoraMart";
const DATABASE_URL = process.env.DATABASE_URL;
const PEXELS_API_KEY = process.env.PEXELS_API_KEY;

if (!DATABASE_URL) throw new Error("DATABASE_URL missing.");
if (!PEXELS_API_KEY) throw new Error("PEXELS_API_KEY missing.");

const pool = new Pool({ connectionString: DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

const cloudFolder = process.env.CLOUDINARY_FOLDER || "ecommerce";

function slugify(input) {
  return input
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

function money(base, index) {
  return base + ((index * 137) % 850);
}

const groups = [
  {
    name: "Electronics & Gadgets",
    slug: "electronics-gadgets",
    basePrice: 890,
    products: [
      ["NovaSound Wireless Earbuds", "wireless earbuds product on white background"],
      ["VoltCharge 20W Fast Charger", "usb c fast charger product"],
      ["PixelView Mini Projector", "mini projector product"],
      ["SmartFit Fitness Band", "fitness band smartwatch product"],
      ["DeskGlow RGB Lamp", "rgb desk lamp product"],
      ["PowerCore 10000mAh Power Bank", "power bank product"],
      ["Type-C Premium Cable Pack", "usb c cable product"],
      ["HomeCam WiFi Security Camera", "wifi security camera product"],
    ],
  },
  {
    name: "Fashion & Lifestyle",
    slug: "fashion-lifestyle",
    basePrice: 650,
    products: [
      ["UrbanFlex Travel Backpack", "travel backpack product"],
      ["Classic Leather Wallet", "leather wallet product"],
      ["Minimalist Analog Watch", "analog wrist watch product"],
      ["Everyday Cotton T-Shirt", "cotton t shirt product"],
      ["ComfortFit Running Shoes", "running shoes product"],
      ["Premium Sunglasses", "sunglasses product"],
      ["Canvas Crossbody Bag", "crossbody bag product"],
      ["Soft Touch Hoodie", "hoodie product"],
    ],
  },
  {
    name: "Beauty & Personal Care",
    slug: "beauty-personal-care",
    basePrice: 420,
    products: [
      ["GlowMist Vitamin C Serum", "vitamin c serum bottle product"],
      ["HydraCare Face Wash", "face wash product bottle"],
      ["Herbal Hair Growth Oil", "hair oil bottle product"],
      ["Aloe Vera Skin Gel", "aloe vera gel product"],
      ["Matte Finish Lip Tint", "lip tint product"],
      ["Daily Sunscreen SPF 50", "sunscreen product bottle"],
      ["Rose Water Toner", "rose water toner bottle"],
      ["Charcoal Deep Clean Mask", "charcoal face mask product"],
    ],
  },
  {
    name: "Home & Kitchen",
    slug: "home-kitchen",
    basePrice: 550,
    products: [
      ["AromaMist Air Diffuser", "aroma diffuser product"],
      ["Ceramic Dinner Plate Set", "ceramic dinner plate set"],
      ["Premium Spice Organizer", "spice organizer product"],
      ["Stainless Steel Water Bottle", "stainless steel water bottle product"],
      ["KitchenPro Knife Set", "kitchen knife set product"],
      ["SoftCloud Bedsheet Set", "bedsheet set product"],
      ["LED Motion Night Light", "led night light product"],
      ["Nonstick Fry Pan", "nonstick frying pan product"],
    ],
  },
  {
    name: "Grocery & Food",
    slug: "grocery-food",
    basePrice: 280,
    products: [
      ["Pure Harvest Organic Honey", "organic honey jar product"],
      ["Premium Black Seed", "black seed jar product"],
      ["Himalayan Pink Salt", "himalayan pink salt product"],
      ["Natural Peanut Butter", "peanut butter jar product"],
      ["Green Tea Detox Pack", "green tea package product"],
      ["Mixed Dry Fruits Jar", "dry fruits jar product"],
      ["Premium Dates Box", "dates box product"],
      ["Cold Pressed Mustard Oil", "mustard oil bottle product"],
    ],
  },
  {
    name: "Books & Stationery",
    slug: "books-stationery",
    basePrice: 220,
    products: [
      ["Productivity Planner 2026", "productivity planner notebook"],
      ["Business Growth Notebook", "business notebook product"],
      ["Creative Sketch Book", "sketch book product"],
      ["Premium Gel Pen Set", "gel pen set product"],
      ["Startup Strategy Book", "business book product"],
      ["Daily Habit Journal", "habit journal notebook"],
      ["Minimal Desk Organizer", "desk organizer product"],
      ["A4 Premium Paper Pack", "a4 paper pack product"],
    ],
  },
  {
    name: "Islamic Lifestyle",
    slug: "islamic-lifestyle",
    basePrice: 390,
    products: [
      ["Premium Prayer Mat", "prayer mat product"],
      ["Digital Tasbeeh Counter", "digital tasbeeh counter product"],
      ["Elegant Attar Gift Set", "attar perfume bottle product"],
      ["Islamic Wall Art Frame", "islamic wall art frame"],
      ["Quran Bookmark Set", "quran bookmark product"],
      ["Modest Gift Box", "premium gift box product"],
      ["Portable Quran Stand", "quran stand product"],
      ["Ramadan Decor Light", "ramadan decor light product"],
    ],
  },
  {
    name: "Art & Craft",
    slug: "art-craft",
    basePrice: 320,
    products: [
      ["Acrylic Color Set", "acrylic paint set product"],
      ["Handmade Canvas Board", "canvas board product"],
      ["Premium Brush Kit", "paint brush kit product"],
      ["DIY Craft Paper Pack", "craft paper pack product"],
      ["Watercolor Starter Set", "watercolor paint set product"],
      ["Clay Modeling Kit", "clay modeling kit product"],
      ["Calligraphy Pen Set", "calligraphy pen set product"],
      ["Wall Decor Craft Frame", "wall decor frame product"],
    ],
  },
];

async function searchPexelsPhoto(query) {
  const url = new URL("https://api.pexels.com/v1/search");
  url.searchParams.set("query", query);
  url.searchParams.set("per_page", "8");
  url.searchParams.set("orientation", "square");

  const res = await fetch(url, {
    headers: {
      Authorization: PEXELS_API_KEY,
    },
  });

  if (!res.ok) {
    throw new Error(`Pexels API failed for "${query}" with status ${res.status}`);
  }

  const data = await res.json();
  const photo = data.photos?.find((item) => item?.src?.large2x || item?.src?.large || item?.src?.original);

  if (!photo) {
    throw new Error(`No Pexels photo found for "${query}"`);
  }

  return {
    imageUrl: photo.src.large2x || photo.src.large || photo.src.original,
    pageUrl: photo.url,
    photographer: photo.photographer,
    alt: photo.alt || query,
  };
}

const photoCache = new Map();

async function getPhoto(query) {
  if (photoCache.has(query)) return photoCache.get(query);
  const photo = await searchPexelsPhoto(query);
  photoCache.set(query, photo);
  return photo;
}

async function uploadPexelsToCloudinary({ query, publicId }) {
  const photo = await getPhoto(query);

  const uploaded = await cloudinary.uploader.upload(photo.imageUrl, {
    folder: `${cloudFolder}/showcase-real-products`,
    public_id: publicId,
    overwrite: true,
    resource_type: "image",
    tags: ["nexoramart", "showcase", "pexels"],
    context: {
      alt: photo.alt,
      caption: `Photo by ${photo.photographer} on Pexels`,
      pexels_url: photo.pageUrl,
    },
  });

  return {
    url: uploaded.secure_url,
    alt: `${photo.alt} - Photo by ${photo.photographer} on Pexels`,
  };
}

async function seedStoreSettings() {
  await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {
      storeName: BRAND_NAME,
      logoUrl: "/nexoramart-logo.svg",
      currency: "BDT",
      shippingInsideDhaka: 70,
      shippingRangpur: 90,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 3000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
      aboutUs:
        "NexoraMart is a polished ecommerce showcase store built for agency portfolio, client demo, and production-ready ecommerce presentation.",
      returnRefundPolicy:
        "Demo policy: Customers can request return or replacement within 7 days for eligible products.",
      privacyPolicy:
        "Demo privacy policy for ecommerce showcase purpose. Replace before real client launch.",
      termsConditions:
        "Demo terms and conditions for ecommerce showcase purpose. Replace before real client launch.",
    },
    create: {
      id: "default",
      storeName: BRAND_NAME,
      logoUrl: "/nexoramart-logo.svg",
      currency: "BDT",
      shippingInsideDhaka: 70,
      shippingRangpur: 90,
      shippingOutsideDhaka: 130,
      shippingDefaultCharge: 120,
      shippingFreeOver: 3000,
      codEnabled: true,
      onlineEnabled: false,
      manualPaymentEnabled: true,
      aboutUs:
        "NexoraMart is a polished ecommerce showcase store built for agency portfolio, client demo, and production-ready ecommerce presentation.",
      returnRefundPolicy:
        "Demo policy: Customers can request return or replacement within 7 days for eligible products.",
      privacyPolicy:
        "Demo privacy policy for ecommerce showcase purpose. Replace before real client launch.",
      termsConditions:
        "Demo terms and conditions for ecommerce showcase purpose. Replace before real client launch.",
    },
  });
}

async function main() {
  await seedStoreSettings();

  const createdProducts = [];
  let index = 1;

  for (const group of groups) {
    const categoryPhoto = await uploadPexelsToCloudinary({
      query: `${group.name} product collection`,
      publicId: `category-${group.slug}`,
    });

    const category = await prisma.category.upsert({
      where: { slug: group.slug },
      update: {
        name: group.name,
        imageUrl: categoryPhoto.url,
        isActive: true,
      },
      create: {
        name: group.name,
        slug: group.slug,
        imageUrl: categoryPhoto.url,
        isActive: true,
      },
    });

    for (const [productName, imageQuery] of group.products) {
      const slug = slugify(productName);
      const sku = `NX-${String(index).padStart(4, "0")}`;
      const price = money(group.basePrice, index);
      const offerPrice = Math.max(99, Math.round(price * (0.84 + (index % 5) * 0.02)));
      const discountPercent = Math.max(5, Math.round(((price - offerPrice) / price) * 100));
      const stock = 20 + ((index * 9) % 85);
      const investedAmount = Math.round(price * 0.58);

      const productPhoto = await uploadPexelsToCloudinary({
        query: imageQuery,
        publicId: `product-${slug}`,
      });

      const description =
        `${productName} from ${BRAND_NAME}. Premium demo product for ecommerce client showcase. ` +
        `Includes real product-style image, pricing, stock, category mapping, variants, wishlist, cart, and checkout testing support.`;

      const product = await prisma.product.upsert({
        where: { slug },
        update: {
          name: productName,
          description,
          price,
          offerPrice,
          investedAmount,
          discountPercent,
          sku,
          stock,
          isFeatured: index % 3 === 0 || index <= 10,
          isActive: true,
          categoryId: category.id,
        },
        create: {
          name: productName,
          slug,
          description,
          price,
          offerPrice,
          investedAmount,
          discountPercent,
          sku,
          stock,
          isFeatured: index % 3 === 0 || index <= 10,
          isActive: true,
          categoryId: category.id,
        },
      });

      await prisma.productCategory.upsert({
        where: {
          productId_categoryId: {
            productId: product.id,
            categoryId: category.id,
          },
        },
        update: {},
        create: {
          productId: product.id,
          categoryId: category.id,
        },
      });

      await prisma.productImage.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productImage.create({
        data: {
          productId: product.id,
          url: productPhoto.url,
          alt: productPhoto.alt,
          sortOrder: 0,
        },
      });

      await prisma.productVariant.deleteMany({
        where: { productId: product.id },
      });

      await prisma.productVariant.createMany({
        data: [
          {
            productId: product.id,
            type: "Package",
            value: "Standard",
            priceDiff: 0,
            investedAmount,
            stock: Math.floor(stock * 0.6),
          },
          {
            productId: product.id,
            type: "Package",
            value: "Premium",
            priceDiff: Math.round(price * 0.12),
            investedAmount: Math.round(price * 0.66),
            stock: Math.floor(stock * 0.4),
          },
        ],
      });

      createdProducts.push(product);
      console.log(`Real image product ready: ${productName}`);
      index++;
    }
  }

  await prisma.productDiscount.deleteMany({
    where: {
      note: {
        contains: "showcase demo",
      },
    },
  });

  for (const product of createdProducts.filter((_, i) => i % 5 === 0).slice(0, 16)) {
    await prisma.productDiscount.create({
      data: {
        scope: "PRODUCT",
        percentage: 12,
        isActive: true,
        productId: product.id,
        startsAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
        endsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        note: "showcase demo limited offer",
      },
    });
  }

  console.log("");
  console.log("======================================");
  console.log(`${BRAND_NAME} real image showcase seed complete.`);
  console.log(`Products: ${createdProducts.length}`);
  console.log("Images: Pexels searched, Cloudinary uploaded");
  console.log("======================================");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    await pool.end();
  });
