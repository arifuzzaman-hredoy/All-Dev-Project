"use client";

import { Card } from "@/components/ui/card";

function formatBDT(value: number) {
  return new Intl.NumberFormat("bn-BD").format(value);
}

export type MonthlyRevenuePoint = {
  month: string; // e.g. "2026-02"
  total: number;
};

export default function MonthlyRevenueChart({
  data,
  title = "Monthly Revenue (Last 12 months)",
}: {
  data: MonthlyRevenuePoint[];
  title?: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.total));

  return (
    <Card className="p-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="text-sm font-semibold">{title}</div>
          <div className="mt-1 text-xs text-black/60">
            Based on non-cancelled orders
          </div>
        </div>
        <div className="text-xs text-black/60">
          Max: ৳ {formatBDT(max)}
        </div>
      </div>

      <div className="mt-5 grid grid-cols-12 gap-2 items-end h-36">
        {data.map((d) => {
          const h = Math.round((d.total / max) * 100);
          return (
            <div key={d.month} className="flex flex-col items-center gap-2">
              <div
                title={`${d.month}: ৳ ${formatBDT(d.total)}`}
                className="w-full rounded-lg bg-black/80"
                style={{ height: `${Math.max(4, h)}%` }}
              />
              <div className="text-[10px] text-black/60">
                {d.month.slice(5)} {/* show MM */}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 grid gap-1 text-xs text-black/70">
        <div className="flex justify-between">
          <span>This month</span>
          <span className="font-semibold">
            ৳ {formatBDT(data[data.length - 1]?.total ?? 0)}
          </span>
        </div>
        <div className="flex justify-between">
          <span>Last month</span>
          <span className="font-semibold">
            ৳ {formatBDT(data[data.length - 2]?.total ?? 0)}
          </span>
        </div>
      </div>
    </Card>
  );
}