"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";

export default function AdminPagination({
  page,
  pages,
  onPageChange,
}: {
  page: number;
  pages: number;
  onPageChange: (page: number) => void;
}) {
  if (pages <= 1) return null;

  const items: number[] = [];
  const add = (n: number) => {
    if (!items.includes(n)) items.push(n);
  };

  add(1);
  add(pages);
  add(page - 1);
  add(page);
  add(page + 1);

  const normalized = items
    .filter((n) => n >= 1 && n <= pages)
    .sort((a, b) => a - b);

  const final: Array<number | "gap"> = [];
  for (let i = 0; i < normalized.length; i++) {
    final.push(normalized[i]);
    if (i < normalized.length - 1 && normalized[i + 1] - normalized[i] > 1) {
      final.push("gap");
    }
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 pt-4">
      <div className="text-xs text-black/60">
        Page {page} of {pages}
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
          className="inline-flex h-10 items-center gap-1 rounded-xl border border-black/10 px-3 text-sm disabled:cursor-not-allowed disabled:opacity-50"
        >
          <ChevronLeft className="h-4 w-4" />
          Prev
        </button>

        <div className="flex items-center gap-1">
          {final.map((item, idx) =>
            item === "gap" ? (
              <span key={`gap-${idx}`} className="px-2 text-black/40">
                ...
              </span>
            ) : (
              <button
                key={item}
                type="button"
                onClick={() => onPageChange(item)}
                className={`min-w-10 rounded-xl px-3 py-2 text-sm ${
                  item === page
                    ? "bg-black text-white"
                    : "border border-black/10 hover:bg-black/5"
                }`}
              >
                {item}
              </button>
            ),
          )}
        </div>

        <button
          type="button"
          onClick={() => onPageChange(page + 1)}
          disabled={page >= pages}
          className="inline-flex h-10 items-center gap-1 rounded-xl border border-black/10 px-3 text-sm disabled:cursor-not-allowed disabled:opacity-50"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
