"use client";

export default function AdminPageSize({
  value,
  onChange,
}: {
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="h-10 rounded-xl border border-black/10 bg-white px-3 text-sm outline-none"
    >
      <option value={10}>10 / page</option>
      <option value={20}>20 / page</option>
      <option value={30}>30 / page</option>
      <option value={50}>50 / page</option>
    </select>
  );
}
