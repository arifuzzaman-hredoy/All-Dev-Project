"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  Edit3,
  ImagePlus,
  PackageSearch,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type ProductOption = {
  id: string;
  name: string;
  slug: string;
  sku?: string;
  images?: { url: string }[];
  category?: {
    name: string;
    parent?: { name: string } | null;
  } | null;
};

type AdminReview = {
  id: string;
  productId: string;
  rating: number;
  comment: string | null;
  imageUrls: string[];
  isVerifiedPurchase: boolean;
  authorName: string | null;
  createdAt: string;
  user: { id: string; name: string | null; email: string } | null;
  product: {
    id: string;
    name: string;
    slug: string;
    imageUrl: string | null;
  };
};

const emptyForm = {
  productId: "",
  authorName: "",
  rating: 5,
  comment: "",
  imageUrlsText: "",
  isVerifiedPurchase: false,
};

const PRODUCT_PICKER_LIMIT = 40;

function parseImageUrls(value: string) {
  return value
    .split(/[\n,]+/)
    .map((url) => url.trim())
    .filter(Boolean)
    .slice(0, 5);
}

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString();
}

function Stars({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, index) => (
        <Star
          key={index}
          className={`h-4 w-4 ${
            index < value
              ? "fill-amber-400 text-amber-400"
              : "fill-slate-100 text-slate-200"
          }`}
        />
      ))}
    </div>
  );
}

function getProductImageUrl(product: ProductOption | undefined) {
  return product?.images?.[0]?.url || null;
}

function getProductCategoryLabel(product: ProductOption) {
  return [product.category?.parent?.name, product.category?.name]
    .filter(Boolean)
    .join(" → ");
}

function ProductSearchSelect({
  products,
  value,
  onChange,
}: {
  products: ProductOption[];
  value: string;
  onChange: (productId: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const rootRef = useRef<HTMLDivElement | null>(null);
  const selectedProduct = useMemo(
    () => products.find((product) => product.id === value),
    [products, value],
  );
  const selectedImageUrl = getProductImageUrl(selectedProduct);

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (!target || rootRef.current?.contains(target)) return;
      setOpen(false);
      setSearch("");
    };

    window.addEventListener("pointerdown", handlePointerDown);
    return () => window.removeEventListener("pointerdown", handlePointerDown);
  }, []);

  const visibleProducts = useMemo(() => {
    const needle = search.trim().toLowerCase();
    const filtered = needle
      ? products.filter((product) => {
          const category = getProductCategoryLabel(product);
          return [product.name, product.sku, product.slug, category]
            .filter((value): value is string => Boolean(value))
            .some((value) => value.toLowerCase().includes(needle));
        })
      : products;

    return filtered.slice(0, PRODUCT_PICKER_LIMIT);
  }, [products, search]);

  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        onClick={() => {
          setOpen((prev) => {
            const nextOpen = !prev;
            if (!nextOpen) setSearch("");
            return nextOpen;
          });
        }}
        className="flex min-h-16 w-full items-center gap-3 rounded-2xl border border-black/10 bg-white/70 px-3 py-2 text-left outline-none transition hover:bg-white focus:border-black/30 focus:ring-2 focus:ring-black/10"
      >
        {selectedImageUrl ? (
          <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-xl border border-pink-100 bg-pink-50">
            <Image
              src={selectedImageUrl}
              alt={selectedProduct?.name || "Selected product"}
              fill
              className="object-contain p-1"
              sizes="44px"
            />
          </div>
        ) : (
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-pink-50 text-pink-600">
            <PackageSearch className="h-5 w-5" />
          </span>
        )}

        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold text-slate-900">
            {selectedProduct?.name || "Select product"}
          </span>
          <span className="mt-0.5 block truncate text-xs text-slate-500">
            {selectedProduct
              ? [selectedProduct.sku, getProductCategoryLabel(selectedProduct)]
                  .filter(Boolean)
                  .join(" • ") || selectedProduct.slug
              : "Search by product name, SKU, slug, or category"}
          </span>
        </span>
      </button>

      {open ? (
        <div className="absolute left-0 right-0 top-[calc(100%+0.5rem)] z-50 overflow-hidden rounded-3xl border border-pink-100 bg-white shadow-xl">
          <div className="border-b border-pink-100 p-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search product..."
                className="pl-9"
                autoFocus
              />
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto p-2">
            {visibleProducts.map((product) => {
              const active = product.id === value;
              const imageUrl = getProductImageUrl(product);
              const categoryLabel = getProductCategoryLabel(product);

              return (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => {
                    onChange(product.id);
                    setOpen(false);
                    setSearch("");
                  }}
                  className={`flex w-full items-center gap-3 rounded-2xl px-3 py-2 text-left transition ${
                    active ? "bg-pink-50 text-pink-700" : "hover:bg-slate-50"
                  }`}
                >
                  {imageUrl ? (
                    <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-pink-100 bg-pink-50">
                      <Image
                        src={imageUrl}
                        alt={product.name}
                        fill
                        className="object-contain p-1"
                        sizes="40px"
                      />
                    </div>
                  ) : (
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-500">
                      <PackageSearch className="h-4 w-4" />
                    </span>
                  )}

                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">
                      {product.name}
                    </span>
                    <span className="mt-0.5 block truncate text-xs text-slate-500">
                      {[product.sku, categoryLabel].filter(Boolean).join(" • ")}
                    </span>
                  </span>

                  {active ? <Check className="h-4 w-4 shrink-0" /> : null}
                </button>
              );
            })}

            {!visibleProducts.length ? (
              <div className="rounded-2xl border border-dashed border-pink-100 p-5 text-center text-sm text-slate-500">
                No product found.
              </div>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default function AdminReviewsClient() {
  const { toast } = useToast();

  const [reviews, setReviews] = useState<AdminReview[]>([]);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [query, setQuery] = useState("");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const load = useCallback(async () => {
    setLoading(true);

    try {
      const [reviewsRes, productsRes] = await Promise.all([
        fetch("/api/admin/reviews", { cache: "no-store" }),
        fetch("/api/admin/products", { cache: "no-store" }),
      ]);

      const reviewsJson = await reviewsRes.json().catch(() => []);
      const productsJson = await productsRes.json().catch(() => []);

      if (!reviewsRes.ok || !productsRes.ok) {
        throw new Error("Failed to load reviews");
      }

      const nextReviews = Array.isArray(reviewsJson)
        ? (reviewsJson as AdminReview[])
        : [];
      const nextProducts = Array.isArray(productsJson)
        ? (productsJson as ProductOption[])
        : [];

      setReviews(nextReviews);
      setProducts(nextProducts);

      if (!form.productId && nextProducts[0]?.id) {
        setForm((prev) => ({ ...prev, productId: nextProducts[0].id }));
      }
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Could not load reviews.",
      });
    } finally {
      setLoading(false);
    }
  }, [form.productId, toast]);

  useEffect(() => {
    void load();
  }, [load]);

  const filteredReviews = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return reviews;

    return reviews.filter((review) => {
      const author = review.authorName || review.user?.name || "";
      return (
        review.product.name.toLowerCase().includes(needle) ||
        author.toLowerCase().includes(needle) ||
        (review.comment || "").toLowerCase().includes(needle)
      );
    });
  }, [query, reviews]);

  const formImageUrls = useMemo(
    () => parseImageUrls(form.imageUrlsText),
    [form.imageUrlsText],
  );

  function setImageUrls(urls: string[]) {
    const uniqueUrls = Array.from(new Set(urls.map((url) => url.trim()))).slice(
      0,
      5,
    );

    setForm((prev) => ({
      ...prev,
      imageUrlsText: uniqueUrls.join("\n"),
    }));
  }

  function appendImageUrls(urls: string[]) {
    setImageUrls([...formImageUrls, ...urls]);
  }

  function removeImageUrl(url: string) {
    setImageUrls(formImageUrls.filter((item) => item !== url));
  }

  function resetForm() {
    setEditingId(null);
    setForm({
      ...emptyForm,
      productId: products[0]?.id || "",
    });
  }

  function startEdit(review: AdminReview) {
    setEditingId(review.id);
    setForm({
      productId: review.productId,
      authorName: review.authorName || review.user?.name || "",
      rating: review.rating,
      comment: review.comment || "",
      imageUrlsText: review.imageUrls.join("\n"),
      isVerifiedPurchase: review.isVerifiedPurchase,
    });
  }

  async function saveReview() {
    if (!form.productId) {
      toast({
        variant: "error",
        title: "Product required",
        description: "Please select a product.",
      });
      return;
    }

    setSaving(true);

    try {
      const url = editingId
        ? `/api/admin/reviews/${editingId}`
        : "/api/admin/reviews";
      const method = editingId ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: form.productId,
          authorName: form.authorName.trim() || "Customer",
          rating: Number(form.rating),
          comment: form.comment.trim() || null,
          imageUrls: parseImageUrls(form.imageUrlsText),
          isVerifiedPurchase: form.isVerifiedPurchase,
        }),
      });

      const json = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(
          (json as { error?: string } | null)?.error || "Save failed",
        );
      }

      toast({
        variant: "success",
        title: editingId ? "Review updated" : "Review added",
      });

      resetForm();
      await load();
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Could not save review.",
      });
    } finally {
      setSaving(false);
    }
  }

  async function deleteReview(review: AdminReview) {
    if (!window.confirm("Delete this review?")) return;

    try {
      const res = await fetch(`/api/admin/reviews/${review.id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const json = await res.json().catch(() => null);
        throw new Error(
          (json as { error?: string } | null)?.error || "Delete failed",
        );
      }

      setReviews((prev) => prev.filter((item) => item.id !== review.id));
      toast({ variant: "success", title: "Review deleted" });
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Could not delete review.",
      });
    }
  }

  async function uploadReviewImages(files: FileList | null) {
    if (!files?.length) return;

    setUploading(true);

    try {
      const remainingSlots = Math.max(0, 5 - formImageUrls.length);
      const selectedFiles = Array.from(files).slice(0, remainingSlots);

      if (!selectedFiles.length) {
        toast({
          variant: "error",
          title: "Image limit reached",
          description: "A review can have up to 5 images.",
        });
        return;
      }

      const uploadedUrls: string[] = [];

      for (const file of selectedFiles) {
        const fd = new FormData();
        fd.append("file", file);

        const res = await fetch("/api/admin/reviews/upload", {
          method: "POST",
          body: fd,
        });

        const json = (await res.json().catch(() => null)) as {
          url?: string;
          error?: string;
        } | null;

        if (!res.ok || !json?.url) {
          throw new Error(json?.error || "Image upload failed");
        }

        uploadedUrls.push(json.url);
      }

      appendImageUrls(uploadedUrls);
      toast({
        variant: "success",
        title: "Images uploaded",
        description: `${uploadedUrls.length} review image(s) added.`,
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Upload failed",
        description:
          error instanceof Error ? error.message : "Could not upload images.",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-950">Reviews</h1>
          <p className="mt-1 text-sm text-slate-500">
            Add, edit, and delete customer reviews shown on the public reviews
            page.
          </p>
        </div>

        <Button
          type="button"
          variant="secondary"
          onClick={() => void load()}
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      <div className="flex flex-col gap-6">
        <section className="rounded-[28px] border border-pink-100 bg-white p-4 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            {editingId ? (
              <Edit3 className="h-5 w-5 text-pink-600" />
            ) : (
              <Plus className="h-5 w-5 text-pink-600" />
            )}
            <h2 className="text-lg font-semibold text-slate-950">
              {editingId ? "Edit Review" : "Add Review"}
            </h2>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Product
              </label>
              <ProductSearchSelect
                products={products}
                value={form.productId}
                onChange={(productId) =>
                  setForm((prev) => ({ ...prev, productId }))
                }
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Reviewer Name
              </label>
              <Input
                value={form.authorName}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, authorName: e.target.value }))
                }
                placeholder="Customer name"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Rating
              </label>
              <select
                value={form.rating}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    rating: Number(e.target.value),
                  }))
                }
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-3 text-sm outline-none focus:border-black/30 focus:ring-2 focus:ring-black/10"
              >
                {[5, 4, 3, 2, 1].map((rating) => (
                  <option key={rating} value={rating}>
                    {rating} star{rating === 1 ? "" : "s"}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Comment
              </label>
              <textarea
                value={form.comment}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, comment: e.target.value }))
                }
                placeholder="Write customer review..."
                className="min-h-32 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none focus:border-black/30 focus:ring-2 focus:ring-black/10"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-3">
                <label className="text-xs font-medium text-slate-600">
                  Review Images
                </label>
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/jpg,image/webp"
                    multiple
                    className="hidden"
                    onChange={(e) => void uploadReviewImages(e.target.files)}
                    disabled={uploading || formImageUrls.length >= 5}
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading || formImageUrls.length >= 5}
                  >
                    <ImagePlus className="h-4 w-4" />
                    {uploading ? "Uploading..." : "Upload Images"}
                  </Button>
                </div>
              </div>

              {formImageUrls.length ? (
                <div className="grid grid-cols-3 gap-2">
                  {formImageUrls.map((url) => (
                    <div
                      key={url}
                      className="group relative aspect-square overflow-hidden rounded-2xl border border-pink-100 bg-pink-50"
                    >
                      <Image
                        src={url}
                        alt="Review upload"
                        fill
                        className="object-cover"
                        sizes="120px"
                      />
                      <button
                        type="button"
                        onClick={() => removeImageUrl(url)}
                        className="absolute right-1.5 top-1.5 grid h-7 w-7 place-items-center rounded-full bg-white/90 text-slate-700 shadow-sm transition hover:bg-red-600 hover:text-white"
                        aria-label="Remove image"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : null}

              <textarea
                value={form.imageUrlsText}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    imageUrlsText: e.target.value,
                  }))
                }
                placeholder="/uploads/reviews/example.jpg"
                className="min-h-24 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none focus:border-black/30 focus:ring-2 focus:ring-black/10"
              />
              <p className="text-[11px] text-slate-500">
                Upload করলে URL এখানে auto set হবে। Manual URL-ও রাখা যাবে,
                max 5 images.
              </p>
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.isVerifiedPurchase}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    isVerifiedPurchase: e.target.checked,
                  }))
                }
              />
              Mark as verified purchase
            </label>

            <div className="flex flex-col gap-2 sm:flex-row">
              <Button
                type="button"
                onClick={() => void saveReview()}
                disabled={saving}
                className="flex-1 bg-pink-600 text-white hover:bg-pink-700"
              >
                {saving
                  ? "Saving..."
                  : editingId
                    ? "Update Review"
                    : "Add Review"}
              </Button>
              {editingId ? (
                <Button
                  type="button"
                  variant="secondary"
                  onClick={resetForm}
                  className="sm:w-auto"
                >
                  Cancel
                </Button>
              ) : null}
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <div className="rounded-[28px] border border-pink-100 bg-white p-4 shadow-sm">
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by product, reviewer, or comment..."
            />
          </div>

          <div className="space-y-3">
            {filteredReviews.map((review) => {
              const author =
                review.authorName || review.user?.name || "Anonymous";

              return (
                <article
                  key={review.id}
                  className="rounded-[28px] border border-pink-100 bg-white p-4 shadow-sm"
                >
                  <div className="flex flex-col gap-4 md:flex-row">
                    <div className="flex gap-3 md:w-72">
                      {review.product.imageUrl ? (
                        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl border border-pink-100 bg-pink-50">
                          <Image
                            src={review.product.imageUrl}
                            alt={review.product.name}
                            fill
                            className="object-contain p-1"
                            sizes="64px"
                          />
                        </div>
                      ) : null}

                      <div className="min-w-0">
                        <Link
                          href={`/products/${review.product.slug}`}
                          target="_blank"
                          className="line-clamp-2 text-sm font-semibold text-slate-950 hover:text-pink-700"
                        >
                          {review.product.name}
                        </Link>
                        <p className="mt-1 text-xs text-slate-500">
                          {formatDate(review.createdAt)}
                        </p>
                      </div>
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-slate-900">
                          {author}
                        </span>
                        <Stars value={review.rating} />
                        {review.isVerifiedPurchase ? (
                          <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                            Verified
                          </span>
                        ) : null}
                      </div>

                      <p className="mt-2 whitespace-pre-line text-sm leading-6 text-slate-600">
                        {review.comment || "No comment."}
                      </p>

                      {review.imageUrls.length ? (
                        <div className="mt-3 flex gap-2 overflow-x-auto">
                          {review.imageUrls.map((url) => (
                            <div
                              key={url}
                              className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border border-pink-100 bg-pink-50"
                            >
                              <Image
                                src={url}
                                alt="Review image"
                                fill
                                className="object-cover"
                                sizes="64px"
                              />
                            </div>
                          ))}
                        </div>
                      ) : null}
                    </div>

                    <div className="flex gap-2 md:flex-col">
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => startEdit(review)}
                      >
                        <Edit3 className="h-4 w-4" />
                        Edit
                      </Button>
                      <Button
                        type="button"
                        variant="danger"
                        size="sm"
                        onClick={() => void deleteReview(review)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </article>
              );
            })}

            {!filteredReviews.length ? (
              <div className="rounded-[28px] border border-dashed border-pink-200 bg-white p-10 text-center">
                <p className="text-sm text-slate-500">No reviews found.</p>
              </div>
            ) : null}
          </div>
        </section>
      </div>
    </div>
  );
}
