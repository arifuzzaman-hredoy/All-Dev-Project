"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Role = "ADMIN" | "STAFF" | "USER";

type UserItem = {
  id: string;
  name: string | null;
  email: string;
  role: Role;
  blocked: boolean;
  createdAt: string;
  ordersCount: number;
};

type ApiResponse = {
  items: UserItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}
function parse(input: unknown): ApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];
  const items: UserItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      name: typeof x.name === "string" ? x.name : null,
      email: safeString(x.email),
      role: safeString(x.role) as Role,
      blocked: Boolean(x.blocked),
      createdAt: safeString(x.createdAt),
      ordersCount: safeNumber(x.ordersCount, 0),
    }))
    .filter((x) => x.id && x.email);

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 20)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export default function AdminUsersClient() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");

  const [q, setQ] = useState("");
  const [role, setRole] = useState<string>("");
  const [page, setPage] = useState(1);

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set("q", q.trim());
    if (role) p.set("role", role);
    p.set("page", String(page));
    p.set("take", "20");
    return p.toString();
  }, [q, role, page]);

  const load = async (): Promise<void> => {
    setLoading(true);
    setErr("");
    try {
      const r = await fetch(`/api/admin/users?${qs}`, { cache: "no-store" });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed");
        setData(null);
        return;
      }
      setData(parse(j));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [qs]);

  const pages = data?.pages ?? 1;
  const currentPage = clamp(data?.page ?? page, 1, pages);

  const patchUser = async (
    id: string,
    body: { blocked?: boolean; role?: Role },
  ): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!r.ok) {
        const j: unknown = await r.json().catch(() => null);
        setErr((j as { error?: string } | null)?.error || "Update failed");
        return;
      }
      await load();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 md:py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
        <div>
          <div className="text-2xl font-semibold">User Management</div>
          <div className="text-sm text-black/60">{data?.total ?? 0} users</div>
        </div>

        <div className="flex gap-2">
          <Link href="/admin/dashboard">
            <Button variant="secondary">Dashboard</Button>
          </Link>
          <Button
            variant="secondary"
            onClick={() => void load()}
            disabled={loading}
          >
            {loading ? "Loading…" : "Refresh"}
          </Button>
        </div>
      </div>

      {err ? (
        <Card className="rounded-3xl p-5 text-sm text-red-600">{err}</Card>
      ) : null}

      <Card className="rounded-3xl p-4">
        <div className="grid gap-3 md:grid-cols-3">
          <Input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Search name/email"
          />
          <select
            className="h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
            value={role}
            onChange={(e) => {
              setRole(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All roles</option>
            <option value="USER">USER</option>
            <option value="STAFF">STAFF</option>
            <option value="ADMIN">ADMIN</option>
          </select>
          <div className="text-sm text-black/60 flex items-center">
            Tip: Only ADMIN can edit users.
          </div>
        </div>
      </Card>

      <div className="mt-4 grid gap-3">
        {(data?.items ?? []).map((u) => (
          <Card key={u.id} className="rounded-3xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-semibold">
                  {u.name ?? "—"}{" "}
                  {u.blocked ? (
                    <span className="ml-2 rounded-full bg-red-50 px-2 py-1 text-xs font-semibold text-red-700">
                      BLOCKED
                    </span>
                  ) : (
                    <span className="ml-2 rounded-full bg-green-50 px-2 py-1 text-xs font-semibold text-green-700">
                      ACTIVE
                    </span>
                  )}
                </div>
                <div className="text-xs text-black/60">{u.email}</div>
                <div className="text-xs text-black/60">
                  Role: <span className="font-semibold">{u.role}</span> •
                  Orders: {u.ordersCount}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <select
                  className="h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
                  value={u.role}
                  onChange={(e) =>
                    void patchUser(u.id, { role: e.target.value as Role })
                  }
                  disabled={loading}
                >
                  <option value="USER">USER</option>
                  <option value="STAFF">STAFF</option>
                  <option value="ADMIN">ADMIN</option>
                </select>

                <Button
                  variant="secondary"
                  onClick={() => void patchUser(u.id, { blocked: !u.blocked })}
                  disabled={loading}
                >
                  {u.blocked ? "Unblock" : "Block"}
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {!loading && (data?.items?.length ?? 0) === 0 ? (
          <Card className="rounded-3xl p-6 text-sm text-black/60">
            No users found.
          </Card>
        ) : null}
      </div>

      <div className="mt-5 flex items-center justify-between">
        <Button
          variant="secondary"
          disabled={currentPage <= 1 || loading}
          onClick={() => setPage((p) => Math.max(1, p - 1))}
        >
          Prev
        </Button>
        <div className="text-sm text-black/60">
          Page {currentPage} of {pages}
        </div>
        <Button
          variant="secondary"
          disabled={currentPage >= pages || loading}
          onClick={() => setPage((p) => p + 1)}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
