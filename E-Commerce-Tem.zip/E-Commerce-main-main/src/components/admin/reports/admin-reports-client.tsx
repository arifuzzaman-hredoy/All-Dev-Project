"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { buildOrderExportRows, ORDER_EXPORT_HEADERS } from "@/lib/order-export";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Area,
  ComposedChart,
  Legend,
} from "recharts";
import {
  TrendingUp,
  Download,
  Package,
  DollarSign,
  ShoppingBag,
  ArrowUpRight,
  BarChart3,
  LineChart as LineChartIcon,
  DownloadCloud,
  Eye,
  EyeOff,
  Clock,
  Star,
  Zap,
  Award,
} from "lucide-react";

type MonthPoint = { month: string; revenue: number; orders: number };
type BestSellingItem = {
  productId: string;
  name: string;
  slug: string;
  qty: number;
  revenue: number;
};
type DayPoint = { day: string; revenue: number; orders: number };

type ApiResponse = {
  ok: true;
  last30Days: { orders: number; revenue: number };
  thisMonth: { orders: number; revenue: number };
  monthly: MonthPoint[];
  bestSelling30: BestSellingItem[];
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parse(input: unknown): ApiResponse | null {
  const o = input as Record<string, unknown>;
  if (o.ok !== true) return null;

  const monthlyRaw = Array.isArray(o.monthly) ? o.monthly : [];
  const monthly: MonthPoint[] = monthlyRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      month: safeString(x.month),
      revenue: safeNumber(x.revenue, 0),
      orders: safeNumber(x.orders, 0),
    }))
    .filter((x) => x.month);

  const bestRaw = Array.isArray(o.bestSelling30) ? o.bestSelling30 : [];
  const bestSelling30: BestSellingItem[] = bestRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      name: safeString(x.name),
      slug: safeString(x.slug),
      qty: safeNumber(x.qty, 0),
      revenue: safeNumber(x.revenue, 0),
    }))
    .filter((x) => x.slug);

  const last30 = (o.last30Days as Record<string, unknown>) ?? {};
  const thisM = (o.thisMonth as Record<string, unknown>) ?? {};

  return {
    ok: true,
    last30Days: {
      orders: safeNumber(last30.orders, 0),
      revenue: safeNumber(last30.revenue, 0),
    },
    thisMonth: {
      orders: safeNumber(thisM.orders, 0),
      revenue: safeNumber(thisM.revenue, 0),
    },
    monthly,
    bestSelling30,
  };
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="max-w-[220px] rounded-2xl border border-gray-100 bg-white/95 p-3 shadow-xl backdrop-blur-md sm:max-w-none sm:p-4">
        <p className="mb-2 text-sm font-semibold text-gray-900">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-gray-600">{entry.name}:</span>
            <span className="font-semibold text-gray-900">
              {entry.name?.toLowerCase().includes("revenue")
                ? `৳ ${Number(entry.value || 0).toLocaleString()}`
                : entry.value}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const StatCard = ({
  title,
  value,
  icon: Icon,
  subtitle,
}: {
  title: string;
  value: string;
  icon: any;
  subtitle?: string;
}) => {
  return (
    <Card className="group relative min-w-0 overflow-hidden rounded-2xl border-0 bg-white shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-linear-to-br from-gray-50 to-gray-100 opacity-50 sm:h-32 sm:w-32" />
      <div className="p-4 sm:p-5 lg:p-6">
        <div className="mb-4 flex items-center justify-between">
          <div className="rounded-xl bg-linear-to-br from-gray-900 to-gray-700 p-3">
            <Icon className="h-5 w-5 text-white" />
          </div>
        </div>
        <p className="mb-1 text-sm text-gray-500">{title}</p>
        <p className="wrap-break-word text-xl font-bold text-gray-900 sm:text-2xl">
          {value}
        </p>
        {subtitle && <p className="mt-2 text-xs text-gray-400">{subtitle}</p>}
      </div>
    </Card>
  );
};

export default function AdminReportsClient() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");
  const [daily, setDaily] = useState<DayPoint[]>([]);
  const [csvFrom, setCsvFrom] = useState<string>("");
  const [csvTo, setCsvTo] = useState<string>("");
  const [csvStatus, setCsvStatus] = useState<string>("");
  const [csvPaymentStatus, setCsvPaymentStatus] = useState<string>("");
  const [timeRange, setTimeRange] = useState<"7" | "14" | "30">("14");
  const [showChartType, setShowChartType] = useState<"line" | "bar">("line");
  const [showValues, setShowValues] = useState(true);

  const load = async (): Promise<void> => {
    setLoading(true);
    setErr("");
    try {
      const r = await fetch("/api/admin/reports/overview", {
        cache: "no-store",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed to load reports");
        setData(null);
        return;
      }
      const parsed = parse(j);
      if (!parsed) {
        setErr("Invalid response");
        setData(null);
        return;
      }
      setData(parsed);

      const dr = await fetch(`/api/admin/reports/daily?days=${timeRange}`, {
        cache: "no-store",
      });
      const dj: unknown = await dr.json().catch(() => null);
      const dobj = dj as Record<string, unknown>;
      if (dr.ok && dobj.ok === true && Array.isArray(dobj.days)) {
        const arr = dobj.days
          .map((x) => x as Record<string, unknown>)
          .map((x) => ({
            day: safeString(x.day),
            revenue: safeNumber(x.revenue, 0),
            orders: safeNumber(x.orders, 0),
          }))
          .filter((x) => x.day);
        setDaily(arr);
      } else {
        setDaily([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [timeRange]);

  const formatCurrency = (value: number) => {
    return `৳ ${value.toLocaleString()}`;
  };

  const totalRevenue = useMemo(() => {
    return (data?.thisMonth.revenue || 0) + (data?.last30Days.revenue || 0);
  }, [data]);

  const totalOrders = useMemo(() => {
    return (data?.thisMonth.orders || 0) + (data?.last30Days.orders || 0);
  }, [data]);

  const pieColors = [
    "#10b981",
    "#6366f1",
    "#f59e0b",
    "#ef4444",
    "#8b5cf6",
    "#ec4899",
  ];

  const handleExportOrders = () => {
    const p = new URLSearchParams();

    if (csvFrom) p.set("from", csvFrom);
    if (csvTo) p.set("to", csvTo);
    if (csvStatus) p.set("status", csvStatus);
    if (csvPaymentStatus) p.set("paymentStatus", csvPaymentStatus);

    window.open(`/api/reports/orders/export?${p.toString()}`, "_blank");
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-linear-to-br from-gray-50 via-white to-gray-50">
      <div className="mx-auto max-w-7xl px-3 py-4 sm:px-4 sm:py-5 lg:px-6">
        {err ? (
          <Card className="mb-6 rounded-2xl border border-red-200 bg-red-50/90 p-4 backdrop-blur-sm sm:p-6">
            <p className="text-red-600">{err}</p>
          </Card>
        ) : null}

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <StatCard
            title="Total Revenue"
            value={formatCurrency(totalRevenue)}
            icon={DollarSign}
            subtitle="Last 30 days"
          />
          <StatCard
            title="Total Orders"
            value={totalOrders.toString()}
            icon={ShoppingBag}
            subtitle="+124 from last month"
          />
          <StatCard
            title="Avg. Order Value"
            value={formatCurrency(
              totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0,
            )}
            icon={Package}
            subtitle="Per transaction"
          />
        </div>

        <div className="mb-8 grid gap-6 lg:grid-cols-3">
          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg transition-all hover:shadow-xl sm:p-5 lg:col-span-2 lg:p-6">
            <div className="mb-5 flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Revenue Overview
                </h3>
                <p className="text-sm text-gray-500">
                  Daily performance with order volume
                </p>
              </div>

              <div className="flex w-full flex-col gap-3 xl:w-auto xl:items-end">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex rounded-xl bg-gray-100 p-1">
                    <button
                      onClick={() => setShowChartType("line")}
                      className={`rounded-lg p-2 transition-all ${
                        showChartType === "line"
                          ? "bg-white shadow-sm"
                          : "text-gray-500"
                      }`}
                    >
                      <LineChartIcon className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setShowChartType("bar")}
                      className={`rounded-lg p-2 transition-all ${
                        showChartType === "bar"
                          ? "bg-white shadow-sm"
                          : "text-gray-500"
                      }`}
                    >
                      <BarChart3 className="h-4 w-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => setShowValues(!showValues)}
                    className="rounded-xl bg-gray-100 p-2 text-gray-600 transition-colors hover:bg-gray-200"
                  >
                    {showValues ? (
                      <Eye className="h-4 w-4" />
                    ) : (
                      <EyeOff className="h-4 w-4" />
                    )}
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {(["7", "14", "30"] as const).map((range) => (
                    <button
                      key={range}
                      onClick={() => setTimeRange(range)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                        timeRange === range
                          ? "bg-gray-900 text-white shadow-lg"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {range}d
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="h-70 min-w-0 sm:h-85 lg:h-90">
              <ResponsiveContainer width="100%" height="100%">
                {showChartType === "line" ? (
                  <ComposedChart
                    data={daily}
                    margin={{ top: 8, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="revenueGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#10b981"
                          stopOpacity={0.2}
                        />
                        <stop
                          offset="95%"
                          stopColor="#10b981"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="ordersGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#6366f1"
                          stopOpacity={0.2}
                        />
                        <stop
                          offset="95%"
                          stopColor="#6366f1"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>

                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />

                    <XAxis
                      dataKey="day"
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      minTickGap={18}
                    />

                    <YAxis
                      yAxisId="revenue"
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      width={50}
                      tickFormatter={(value) => `৳${Math.round(value / 1000)}k`}
                    />

                    <YAxis
                      yAxisId="orders"
                      orientation="right"
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      width={36}
                    />

                    <Tooltip content={<CustomTooltip />} />

                    <Legend
                      wrapperStyle={{
                        fontSize: "12px",
                        paddingTop: "8px",
                      }}
                    />

                    <Area
                      yAxisId="revenue"
                      type="monotone"
                      dataKey="revenue"
                      name="Revenue"
                      stroke="#10b981"
                      strokeWidth={2}
                      fill="url(#revenueGradient)"
                    />

                    <Area
                      yAxisId="orders"
                      type="monotone"
                      dataKey="orders"
                      name="Orders"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fill="url(#ordersGradient)"
                    />
                  </ComposedChart>
                ) : (
                  <BarChart
                    data={daily}
                    margin={{ top: 8, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="barRevenue"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop offset="0%" stopColor="#10b981" stopOpacity={1} />
                        <stop
                          offset="100%"
                          stopColor="#059669"
                          stopOpacity={1}
                        />
                      </linearGradient>
                    </defs>

                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />

                    <XAxis
                      dataKey="day"
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={{ stroke: "#e5e7eb" }}
                      minTickGap={18}
                    />

                    <YAxis
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={{ stroke: "#e5e7eb" }}
                      width={50}
                      tickFormatter={(value) => `৳${Math.round(value / 1000)}k`}
                    />

                    <Tooltip content={<CustomTooltip />} />

                    <Bar
                      dataKey="revenue"
                      name="Revenue"
                      fill="url(#barRevenue)"
                      radius={[8, 8, 0, 0]}
                    />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg transition-all hover:shadow-xl sm:p-5 lg:p-6">
            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-900">
                Monthly Distribution
              </h3>
              <p className="text-sm text-gray-500">Revenue by month</p>
            </div>

            <div className="h-60 min-w-0 sm:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data?.monthly ?? []}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={72}
                    paddingAngle={4}
                    dataKey="revenue"
                  >
                    {(data?.monthly ?? []).map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={pieColors[index % pieColors.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {(data?.monthly ?? []).slice(0, 4).map((item, idx) => (
                <div
                  key={idx}
                  className="flex min-w-0 items-center gap-2 rounded-xl bg-gray-50 px-3 py-2"
                >
                  <div
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{
                      backgroundColor: pieColors[idx % pieColors.length],
                    }}
                  />
                  <span className="truncate text-xs text-gray-600">
                    {item.month}
                  </span>
                  <span className="ml-auto shrink-0 text-xs font-semibold">
                    {formatCurrency(item.revenue)}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg sm:p-5 lg:col-span-2 lg:p-6">
            <div className="mb-6 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Best Selling Products
                </h3>
                <p className="text-sm text-gray-500">
                  Top performers by quantity sold
                </p>
              </div>
            </div>

            <div className="mb-4 space-y-3">
              {(data?.bestSelling30 ?? []).map((item, idx) => (
                <Link
                  key={item.productId}
                  href={`/products/${item.slug}`}
                  className="group block"
                >
                  <div className="rounded-xl bg-gray-50 p-3 transition-all group-hover:bg-linear-to-r group-hover:from-gray-50 group-hover:to-blue-50/30 sm:p-4">
                    <div className="flex items-start gap-3 sm:gap-4">
                      <div
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-bold
                        ${
                          idx === 0
                            ? "bg-linear-to-br from-yellow-400 to-yellow-500 text-white"
                            : idx === 1
                              ? "bg-linear-to-br from-gray-400 to-gray-500 text-white"
                              : idx === 2
                                ? "bg-linear-to-br from-orange-400 to-orange-500 text-white"
                                : "bg-gray-200 text-gray-600"
                        }`}
                      >
                        {idx === 0 ? (
                          <Zap className="h-5 w-5" />
                        ) : idx === 1 ? (
                          <Award className="h-5 w-5" />
                        ) : idx === 2 ? (
                          <Star className="h-5 w-5" />
                        ) : (
                          `#${idx + 1}`
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
                          <p className="truncate font-semibold text-gray-900">
                            {item.name}
                          </p>
                          <p className="shrink-0 text-sm font-semibold text-green-600">
                            {formatCurrency(item.revenue)}
                          </p>
                        </div>

                        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                          <p className="text-xs text-gray-500">
                            Quantity: {item.qty}
                          </p>
                          <p className="text-xs text-gray-500">
                            Avg:{" "}
                            {formatCurrency(
                              Math.round(item.revenue / Math.max(1, item.qty)),
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}

              {(data?.bestSelling30 ?? []).length === 0 && (
                <div className="py-12 text-center text-gray-500">
                  No sales data available
                </div>
              )}
            </div>

            <Link
              href="/admin/orders"
              className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-700"
            >
              View All
              <ArrowUpRight className="ml-1 h-4 w-4" />
            </Link>
          </Card>

          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg sm:p-5 lg:p-6">
            <div className="mb-6 flex items-center gap-3">
              <div className="rounded-xl bg-linear-to-br from-gray-900 to-gray-700 p-2">
                <DownloadCloud className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Export Data
                </h3>
                <p className="text-sm text-gray-500">Download orders as CSV</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Date Range
                </label>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
                  <input
                    value={csvFrom}
                    onChange={(e) => setCsvFrom(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-gray-200 px-4 transition-colors focus:border-gray-400 focus:ring-0"
                    placeholder="From"
                  />
                  <input
                    value={csvTo}
                    onChange={(e) => setCsvTo(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-gray-200 px-4 transition-colors focus:border-gray-400 focus:ring-0"
                    placeholder="To"
                  />
                </div>
              </div>

              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Order Status
                </label>
                <select
                  value={csvStatus}
                  onChange={(e) => setCsvStatus(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-gray-200 bg-white px-4 transition-colors focus:border-gray-400 focus:ring-0"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E")`,
                    backgroundPosition: "right 1rem center",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "1.5em 1.5em",
                    paddingRight: "2.5rem",
                  }}
                >
                  <option value="">All Statuses</option>
                  <option value="PENDING">Pending</option>
                  <option value="PROCESSING">Processing</option>
                  <option value="SHIPPED">Shipped</option>
                  <option value="DELIVERED">Delivered</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Payment Status
                </label>
                <select
                  value={csvPaymentStatus}
                  onChange={(e) => setCsvPaymentStatus(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-gray-200 bg-white px-4 transition-colors focus:border-gray-400 focus:ring-0"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E")`,
                    backgroundPosition: "right 1rem center",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "1.5em 1.5em",
                    paddingRight: "2.5rem",
                  }}
                >
                  <option value="">All Payment Status</option>
                  <option value="UNPAID">Unpaid</option>
                  <option value="PAID">Paid</option>
                  <option value="FAILED">Failed</option>
                  <option value="REFUNDED">Refunded</option>
                </select>
              </div>

              <div className="rounded-xl border border-gray-100 bg-gray-50 p-3 text-xs text-gray-600">
                Export columns:
                <div className="mt-2 flex flex-wrap gap-2">
                  {[
                    "Status",
                    "Serial Number",
                    "Order Date",
                    "Steadfast ID",
                    "Payment Status",
                    "LOT",
                    "Order Price",
                    "Mobile",
                    "Name",
                    "Address",
                    "Products",
                    "Notes",
                  ].map((label) => (
                    <span
                      key={label}
                      className="rounded-full bg-white px-2.5 py-1 text-[11px] text-gray-700 shadow-sm"
                    >
                      {label}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 sm:pt-4">
                <Button
                  onClick={handleExportOrders}
                  className="h-12 w-full rounded-xl bg-linear-to-r from-gray-900 to-gray-800 text-white shadow-lg transition-all hover:from-gray-800 hover:to-gray-700 hover:shadow-xl"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export Orders
                </Button>
              </div>
            </div>

            <div className="mt-6 border-t border-gray-100 pt-6">
              <h4 className="mb-3 text-sm font-semibold text-gray-900">
                Quick Stats
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <Clock className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Avg. Processing
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-gray-900">
                    2.4 hours
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <Package className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Pending Orders
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-gray-900">
                    8
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <TrendingUp className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Growth Rate
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-green-600">
                    +12.5%
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {loading ? (
          <div className="mt-6 text-sm text-gray-500">
            Loading report data...
          </div>
        ) : null}
      </div>
    </div>
  );
}
