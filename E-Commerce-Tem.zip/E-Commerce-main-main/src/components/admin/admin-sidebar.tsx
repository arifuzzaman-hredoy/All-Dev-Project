"use client";

import * as Dialog from "@radix-ui/react-dialog";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  BarChart3,
  Menu,
  LayoutDashboard,
  Megaphone,
  Package2,
  PanelLeft,
  Settings2,
  ShoppingBag,
  Star,
  X,
  Ticket,
  Users,
  Inbox,
} from "lucide-react";
import { cn } from "@/lib/cn";

const navItems = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/categories", label: "Categories", icon: PanelLeft },
  { href: "/admin/products", label: "Products", icon: Package2 },
  { href: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { href: "/admin/review", label: "Reviews", icon: Star },
  { href: "/admin/discounts", label: "Discounts", icon: Ticket },
  { href: "/admin/product-requests", label: "Product Requests", icon: Inbox },
  { href: "/admin/reports", label: "Reports", icon: BarChart3 },
  { href: "/admin/users", label: "Users", icon: Users },
  { href: "/admin/settings", label: "Settings", icon: Settings2 },
  { href: "/admin/banners", label: "Banners", icon: Megaphone },
  { href: "/admin/coupons", label: "Coupons", icon: Ticket },
];

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <nav className="mt-4 flex flex-col gap-1.5">
      {navItems.map((item) => {
        const active =
          pathname === item.href || pathname.startsWith(item.href + "/");
        const Icon = item.icon;

        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "group flex items-center gap-3 rounded-2xl border px-3 py-2.5 text-sm font-medium transition-all duration-150",
              active
                ? "border-pink-200 bg-pink-600 text-white shadow-[0_12px_28px_-18px_rgba(219,39,119,0.9)]"
                : "border-transparent bg-transparent text-slate-700 hover:border-pink-100 hover:bg-pink-50 hover:text-pink-700",
            )}
          >
            <span
              className={cn(
                "grid h-9 w-9 place-items-center rounded-xl transition-all duration-150",
                active
                  ? "bg-white/15 text-white"
                  : "bg-pink-50 text-pink-600 group-hover:bg-white group-hover:text-pink-700",
              )}
            >
              <Icon className="h-4 w-4" />
            </span>
            <span className="flex-1">{item.label}</span>
            {active ? (
              <span
                className="h-2 w-2 rounded-full bg-white"
                aria-hidden="true"
              />
            ) : null}
          </Link>
        );
      })}
    </nav>
  );
}

export default function AdminSidebar() {
  return (
    <div className="h-full rounded-[28px] border border-pink-100 bg-white/85 p-4 shadow-[0_24px_80px_-48px_rgba(190,24,93,0.45)] backdrop-blur-xl">
      <div className="flex items-center gap-3 border-b border-pink-100 pb-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-pink-600 text-white shadow-[0_12px_28px_-18px_rgba(219,39,119,0.9)]">
          <PanelLeft className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-semibold text-slate-900">Admin panel</p>
          <p className="text-xs text-slate-500">Manage catalog and orders</p>
        </div>
      </div>
      <SidebarNav />
    </div>
  );
}

export function AdminSidebarMobileToggle() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <Dialog.Root key={pathname} open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button
          type="button"
          className="inline-flex h-11 items-center gap-2 rounded-2xl border border-pink-100 bg-white/90 px-4 text-sm font-medium text-slate-900 shadow-[0_16px_40px_-24px_rgba(190,24,93,0.35)] backdrop-blur transition-colors hover:bg-pink-50 hover:text-pink-700 lg:hidden"
          aria-label="Open admin sidebar"
        >
          <Menu className="h-4 w-4" />
          Menu
        </button>
      </Dialog.Trigger>

      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-[2px]" />
        <Dialog.Content className="fixed bottom-4 left-0 top-16 z-50 w-[min(20rem,85vw)] border-r border-pink-100 bg-white p-4 shadow-[24px_0_80px_-40px_rgba(15,23,42,0.5)] outline-none">
          <div className="flex items-center justify-between border-b border-pink-100 pb-3">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-2xl bg-pink-600 text-white shadow-[0_12px_28px_-18px_rgba(219,39,119,0.9)]">
                <PanelLeft className="h-4 w-4" />
              </div>
              <div>
                <Dialog.Title className="text-sm font-semibold text-slate-900">
                  Admin menu
                </Dialog.Title>
                <Dialog.Description className="text-xs text-slate-500">
                  Navigate admin sections
                </Dialog.Description>
              </div>
            </div>

            <Dialog.Close asChild>
              <button
                type="button"
                className="grid h-10 w-10 place-items-center rounded-2xl border border-pink-100 text-slate-600 transition-colors hover:bg-pink-50 hover:text-pink-700"
                aria-label="Close admin sidebar"
              >
                <X className="h-4 w-4" />
              </button>
            </Dialog.Close>
          </div>

          <div className="mt-4 max-h-[calc(100dvh-12rem)] overflow-y-auto pb-4 pr-1">
            <SidebarNav onNavigate={() => setOpen(false)} />
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
