"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import SteadfastAutoSync from "@/components/orders/steadfast-auto-sync";

type OrderStatus =
  | "PENDING"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

type PaymentStatus = "UNPAID" | "PAID" | "FAILED" | "REFUNDED";
type PaymentMethod = "COD" | "ONLINE" | "MANUAL";

type ItemMode = "catalog" | "custom";

type OrderItemEditor = {
  rowId: string;
  orderItemId?: string;
  mode: ItemMode;
  productId: string | null;
  variantId: string | null;
  customName: string;
  customSku: string;
  productName: string;
  sku: string;
  unitPrice: number;
  qty: number;
};

type ProductOption = {
  id: string;
  name: string;
  sku: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  variants: Array<{
    id: string;
    type: string;
    value: string;
    priceDiff: number;
    stock: number;
  }>;
};

type OrderDetails = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  name: string;
  phone: string;
  email: string | null;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  couponCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  courierName: string | null;
  trackingId: string | null;
  steadfastConsignmentId: string | null;
  steadfastTrackingCode: string | null;
  steadfastTrackingUrl: string | null;
  manualPayment: {
    provider: string | null;
    paymentNumber: string | null;
    senderPhone: string | null;
    submittedAmount: number | null;
    submittedAt: string | null;
    transactionId: string | null;
  } | null;
  items: Array<{
    id: string;
    productId: string | null;
    variantId: string | null;
    productName: string;
    sku: string;
    unitPrice: number;
    qty: number;
    lineTotal: number;
  }>;
};

type AddItemModalState = {
  open: boolean;
  mode: ItemMode;
  search: string;
  selectedProductId: string;
  selectedVariantId: string;
  qty: number;
  unitPrice: number;
  customName: string;
  customSku: string;
};

function getReadableOrderId(order: {
  id: string;
  publicOrderId?: string | null;
}) {
  return order.publicOrderId?.trim() || order.id;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwareUnitPrice(
  product: ProductOption,
  variant?: ProductOption["variants"][number] | null,
): number {
  const baseOriginalPrice = safeNumber(product.price, 0);

  const baseDiscountedPrice = safeNumber(
    product.offerPrice ?? product.price,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(variant?.priceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  return Math.floor(comparePrice * discountRatio);
}

function createRowId() {
  return Math.random().toString(36).slice(2, 10);
}

function createInitialModalState(
  mode: ItemMode = "catalog",
): AddItemModalState {
  return {
    open: false,
    mode,
    search: "",
    selectedProductId: "",
    selectedVariantId: "",
    qty: 1,
    unitPrice: 0,
    customName: "",
    customSku: "",
  };
}

export default function AdminOrderDetailsClient() {
  const params = useParams();
  const router = useRouter();
  const id = safeString(params?.id);

  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [data, setData] = useState<OrderDetails | null>(null);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [productSearch, setProductSearch] = useState("");

  const [status, setStatus] = useState<OrderStatus>("PENDING");
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>("UNPAID");
  const [courierName, setCourierName] = useState<string>("");
  const [trackingId, setTrackingId] = useState<string>("");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [addressLine1, setAddressLine1] = useState("");
  const [addressLine2, setAddressLine2] = useState("");
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");
  const [note, setNote] = useState("");

  const [shipping, setShipping] = useState(0);
  const [tax, setTax] = useState(0);
  const [discount, setDiscount] = useState(0);

  const [items, setItems] = useState<OrderItemEditor[]>([]);
  const [addModal, setAddModal] = useState<AddItemModalState>(
    createInitialModalState(),
  );

  const { toast } = useToast();

  const loadProducts = async (query = "") => {
    const qs = new URLSearchParams();
    if (query.trim()) qs.set("q", query.trim());

    const r = await fetch(
      `/api/admin/products/order-options?${qs.toString()}`,
      {
        cache: "no-store",
      },
    );
    const j: unknown = await r.json().catch(() => null);

    const productsRaw =
      j &&
      typeof j === "object" &&
      Array.isArray((j as Record<string, unknown>).products)
        ? ((j as Record<string, unknown>).products as unknown[])
        : [];

    const parsedProducts: ProductOption[] = productsRaw
      .map((x) => x as Record<string, unknown>)
      .map((x) => ({
        id: safeString(x.id),
        name: safeString(x.name),
        sku: safeString(x.sku),
        price: safeNumber(x.price, 0),
        offerPrice: typeof x.offerPrice === "number" ? x.offerPrice : null,
        stock: safeNumber(x.stock, 0),
        variants: Array.isArray(x.variants)
          ? (x.variants as Array<Record<string, unknown>>).map((v) => ({
              id: safeString(v.id),
              type: safeString(v.type),
              value: safeString(v.value),
              priceDiff: safeNumber(v.priceDiff, 0),
              stock: safeNumber(v.stock, 0),
            }))
          : [],
      }))
      .filter((x) => x.id);

    setProducts(parsedProducts);
  };

  const load = async (): Promise<void> => {
    if (!id) return;

    setLoading(true);
    try {
      const orderRes = await fetch(`/api/admin/orders/${id}`, {
        cache: "no-store",
      });
      const orderJson: unknown = await orderRes.json().catch(() => null);

      if (!orderRes.ok) {
        setData(null);
        return;
      }

      const o =
        orderJson && typeof orderJson === "object"
          ? (orderJson as Record<string, unknown>)
          : {};

      const itemsRaw = Array.isArray(o.items) ? o.items : [];
      const parsedItems = itemsRaw
        .map((x) => x as Record<string, unknown>)
        .map((x) => ({
          id: safeString(x.id),
          productId: typeof x.productId === "string" ? x.productId : null,
          variantId: typeof x.variantId === "string" ? x.variantId : null,
          productName: safeString(x.productName),
          sku: safeString(x.sku),
          unitPrice: safeNumber(x.unitPrice, 0),
          qty: safeNumber(x.qty, 1),
          lineTotal: safeNumber(x.lineTotal, 0),
        }))
        .filter((x) => x.id);

      const manualPaymentRaw =
        o.manualPayment && typeof o.manualPayment === "object"
          ? (o.manualPayment as Record<string, unknown>)
          : null;

      const parsed: OrderDetails = {
        id: safeString(o.id),
        publicOrderId:
          typeof o.publicOrderId === "string" ? o.publicOrderId : null,
        createdAt: safeString(o.createdAt),
        status: safeString(o.status) as OrderStatus,
        paymentStatus: safeString(o.paymentStatus) as PaymentStatus,
        paymentMethod: safeString(o.paymentMethod) as PaymentMethod,
        name: safeString(o.name),
        phone: safeString(o.phone),
        email: typeof o.email === "string" ? o.email : null,
        addressLine1: safeString(o.addressLine1),
        addressLine2:
          typeof o.addressLine2 === "string" ? o.addressLine2 : null,
        city: safeString(o.city),
        area: typeof o.area === "string" ? o.area : null,
        note: typeof o.note === "string" ? o.note : null,
        couponCode: typeof o.couponCode === "string" ? o.couponCode : null,
        subtotal: safeNumber(o.subtotal, 0),
        discount: safeNumber(o.discount, 0),
        shipping: safeNumber(o.shipping, 0),
        tax: safeNumber(o.tax, 0),
        total: safeNumber(o.total, 0),
        courierName: typeof o.courierName === "string" ? o.courierName : null,
        trackingId: typeof o.trackingId === "string" ? o.trackingId : null,
        steadfastConsignmentId:
          typeof o.steadfastConsignmentId === "string"
            ? o.steadfastConsignmentId
            : null,
        steadfastTrackingCode:
          typeof o.steadfastTrackingCode === "string"
            ? o.steadfastTrackingCode
            : null,
        steadfastTrackingUrl:
          typeof o.steadfastTrackingUrl === "string"
            ? o.steadfastTrackingUrl
            : null,
        manualPayment: manualPaymentRaw
          ? {
              provider:
                typeof manualPaymentRaw.provider === "string"
                  ? manualPaymentRaw.provider
                  : null,
              paymentNumber:
                typeof manualPaymentRaw.paymentNumber === "string"
                  ? manualPaymentRaw.paymentNumber
                  : null,
              senderPhone:
                typeof manualPaymentRaw.senderPhone === "string"
                  ? manualPaymentRaw.senderPhone
                  : null,
              submittedAmount: safeNumber(manualPaymentRaw.submittedAmount, 0),
              submittedAt:
                typeof manualPaymentRaw.submittedAt === "string"
                  ? manualPaymentRaw.submittedAt
                  : null,
              transactionId:
                typeof manualPaymentRaw.transactionId === "string"
                  ? manualPaymentRaw.transactionId
                  : null,
            }
          : null,
        items: parsedItems,
      };

      setData(parsed);

      setStatus(parsed.status);
      setPaymentStatus(parsed.paymentStatus);
      setCourierName(parsed.courierName ?? "");
      setTrackingId(parsed.trackingId ?? "");

      setName(parsed.name);
      setEmail(parsed.email ?? "");
      setPhone(parsed.phone);
      setAddressLine1(parsed.addressLine1);
      setAddressLine2(parsed.addressLine2 ?? "");
      setCity(parsed.city);
      setArea(parsed.area ?? "");
      setNote(parsed.note ?? "");
      setShipping(parsed.shipping);
      setTax(parsed.tax);
      setDiscount(parsed.discount);

      setItems(
        parsed.items.map((item) => ({
          rowId: createRowId(),
          orderItemId: item.id,
          mode: item.productId ? "catalog" : "custom",
          productId: item.productId,
          variantId: item.variantId,
          customName: item.productId ? "" : item.productName,
          customSku: item.productId ? "" : item.sku,
          productName: item.productName,
          sku: item.sku,
          unitPrice: item.unitPrice,
          qty: item.qty,
        })),
      );

      await loadProducts(productSearch);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    const t = setTimeout(() => {
      void loadProducts(productSearch);
    }, 250);

    return () => clearTimeout(t);
  }, [productSearch]);

  const subtotal = useMemo(() => {
    return items.reduce((sum, item) => sum + item.unitPrice * item.qty, 0);
  }, [items]);

  const total = useMemo(() => {
    return Math.max(0, subtotal - discount + shipping + tax);
  }, [subtotal, discount, shipping, tax]);

  const filteredProducts = useMemo(() => {
    const query = addModal.search.trim().toLowerCase();
    if (!query) return products;

    return products.filter((product) => {
      const hay = `${product.name} ${product.sku}`.toLowerCase();
      return hay.includes(query);
    });
  }, [products, addModal.search]);

  const selectedModalProduct = useMemo(() => {
    return (
      products.find((product) => product.id === addModal.selectedProductId) ??
      null
    );
  }, [products, addModal.selectedProductId]);

  const updateItem = (rowId: string, patch: Partial<OrderItemEditor>) => {
    setItems((prev) =>
      prev.map((item) => (item.rowId === rowId ? { ...item, ...patch } : item)),
    );
  };

  const handleModeChange = (rowId: string, mode: ItemMode) => {
    if (mode === "custom") {
      updateItem(rowId, {
        mode: "custom",
        productId: null,
        variantId: null,
        customName: "",
        customSku: "",
        productName: "",
        sku: "CUSTOM",
        unitPrice: 0,
        qty: 1,
      });
      return;
    }

    const firstProduct = products[0] ?? null;

    updateItem(rowId, {
      mode: "catalog",
      productId: firstProduct?.id ?? null,
      variantId: null,
      customName: "",
      customSku: "",
      productName: firstProduct?.name ?? "",
      sku: firstProduct?.sku ?? "",
      unitPrice: firstProduct
        ? (firstProduct.offerPrice ?? firstProduct.price)
        : 0,
      qty: 1,
    });
  };

  const handleProductChange = (rowId: string, productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const unitPrice = product.offerPrice ?? product.price;

    updateItem(rowId, {
      productId: product.id,
      variantId: null,
      productName: product.name,
      sku: product.sku,
      unitPrice,
      qty: 1,
    });
  };

  const handleVariantChange = (rowId: string, variantId: string) => {
    const current = items.find((item) => item.rowId === rowId);
    if (!current || !current.productId) return;

    const product = products.find((p) => p.id === current.productId);
    if (!product) return;

    const variant = product.variants.find((v) => v.id === variantId) ?? null;

    updateItem(rowId, {
      variantId: variant?.id ?? null,
      unitPrice: calculateVariantAwareUnitPrice(product, variant),
    });
  };

  const openAddModal = (mode: ItemMode) => {
    const firstProduct = products[0] ?? null;

    setAddModal({
      open: true,
      mode,
      search: "",
      selectedProductId: mode === "catalog" ? (firstProduct?.id ?? "") : "",
      selectedVariantId: "",
      qty: 1,
      unitPrice:
        mode === "catalog" && firstProduct
          ? (firstProduct.offerPrice ?? firstProduct.price)
          : 0,
      customName: "",
      customSku: "",
    });
  };

  const closeAddModal = () => {
    setAddModal((prev) => ({ ...prev, open: false }));
  };

  const onModalModeChange = (mode: ItemMode) => {
    const firstProduct = products[0] ?? null;

    setAddModal((prev) => ({
      ...prev,
      mode,
      selectedProductId: mode === "catalog" ? (firstProduct?.id ?? "") : "",
      selectedVariantId: "",
      qty: 1,
      unitPrice:
        mode === "catalog" && firstProduct
          ? (firstProduct.offerPrice ?? firstProduct.price)
          : 0,
      customName: "",
      customSku: "",
    }));
  };

  const onModalProductChange = (productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    setAddModal((prev) => ({
      ...prev,
      selectedProductId: product.id,
      selectedVariantId: "",
      unitPrice: product.offerPrice ?? product.price,
      qty: 1,
    }));
  };

  const onModalVariantChange = (variantId: string) => {
    const product =
      products.find((p) => p.id === addModal.selectedProductId) ?? null;
    if (!product) return;

    const variant = product.variants.find((v) => v.id === variantId) ?? null;

    setAddModal((prev) => ({
      ...prev,
      selectedVariantId: variant?.id ?? "",
      unitPrice: calculateVariantAwareUnitPrice(product, variant),
    }));
  };

  const confirmAddModalItem = () => {
    if (addModal.mode === "catalog") {
      const product = products.find((p) => p.id === addModal.selectedProductId);
      if (!product) {
        toast({
          variant: "error",
          title: "Failed",
          description: "Please select a product.",
        });
        return;
      }

      setItems((prev) => [
        ...prev,
        {
          rowId: createRowId(),
          mode: "catalog",
          productId: product.id,
          variantId: addModal.selectedVariantId || null,
          customName: "",
          customSku: "",
          productName: product.name,
          sku: product.sku,
          unitPrice: Math.max(0, Math.floor(addModal.unitPrice || 0)),
          qty: Math.max(1, Math.floor(addModal.qty || 1)),
        },
      ]);

      closeAddModal();
      return;
    }

    if (!addModal.customName.trim()) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Custom item name is required.",
      });
      return;
    }

    setItems((prev) => [
      ...prev,
      {
        rowId: createRowId(),
        mode: "custom",
        productId: null,
        variantId: null,
        customName: addModal.customName.trim(),
        customSku: addModal.customSku.trim(),
        productName: addModal.customName.trim(),
        sku: addModal.customSku.trim() || "CUSTOM",
        unitPrice: Math.max(0, Math.floor(addModal.unitPrice || 0)),
        qty: Math.max(1, Math.floor(addModal.qty || 1)),
      },
    ]);

    closeAddModal();
  };

  const removeItem = (rowId: string) => {
    setItems((prev) => prev.filter((item) => item.rowId !== rowId));
  };

  const save = async (): Promise<void> => {
    if (!id) return;

    if (items.length === 0) {
      toast({
        variant: "error",
        title: "Failed",
        description: "At least one item is required.",
      });
      return;
    }

    if (
      items.some(
        (item) =>
          item.mode === "catalog" &&
          (!item.productId || !item.productId.trim()),
      )
    ) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Please select a product for every catalog item.",
      });
      return;
    }

    if (
      items.some((item) => item.mode === "custom" && !item.customName.trim())
    ) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Please enter a name for every custom item.",
      });
      return;
    }

    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          paymentStatus,
          courierName: courierName.trim() ? courierName.trim() : null,
          trackingId: trackingId.trim() ? trackingId.trim() : null,

          name: name.trim(),
          email: email.trim() ? email.trim() : null,
          phone: phone.trim(),
          addressLine1: addressLine1.trim(),
          addressLine2: addressLine2.trim() ? addressLine2.trim() : null,
          city: city.trim(),
          area: area.trim() ? area.trim() : null,
          note: note.trim() ? note.trim() : null,

          shipping,
          tax,
          discount,

          items: items.map((item) => ({
            mode: item.mode,
            productId: item.mode === "catalog" ? item.productId : null,
            variantId: item.mode === "catalog" ? item.variantId : null,
            customName: item.mode === "custom" ? item.customName.trim() : "",
            customSku:
              item.mode === "custom" ? item.customSku.trim() || null : null,
            unitPrice: item.unitPrice,
            qty: item.qty,
          })),
        }),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        toast({
          variant: "error",
          title: "Save failed",
          description:
            (j as { error?: string } | null)?.error ||
            "Failed to update order.",
        });
        return;
      }

      await load();

      toast({
        variant: "success",
        title: "Order updated",
        description: "Order details saved successfully.",
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteOrder = async (): Promise<void> => {
    if (!id) return;

    const ok = window.confirm(
      "Are you sure you want to delete this order? This will permanently remove it from the database.",
    );
    if (!ok) return;

    setDeleting(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}`, {
        method: "DELETE",
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        toast({
          variant: "error",
          title: "Delete failed",
          description:
            (j as { error?: string } | null)?.error ||
            "Failed to delete order.",
        });
        return;
      }

      toast({
        variant: "success",
        title: "Order deleted",
        description: "The order has been removed from the database.",
      });

      router.push("/admin/orders");
      router.refresh();
    } finally {
      setDeleting(false);
    }
  };

  const bookSteadfast = async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}/steadfast/book`, {
        method: "POST",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        toast({
          variant: "error",
          title: "Booking Failed",
          description:
            (j as { error?: string } | null)?.error ||
            "Steadfast booking failed",
        });
        return;
      }
      await load();
      toast({
        variant: "success",
        title: "Booked in Steadfast ✅",
      });
    } finally {
      setLoading(false);
    }
  };

  const syncSteadfastStatus = async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}/steadfast/status`, {
        method: "POST",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description:
            (j as { error?: string } | null)?.error || "Status sync failed",
        });
        return;
      }
      await load();
      toast({
        variant: "success",
        title: "Successful",
        description: "Steadfast status synced ✅",
      });
    } finally {
      setLoading(false);
    }
  };

  const canRefund =
    data?.paymentStatus === "PAID" && data?.paymentMethod !== "COD";

  if (!id) return null;

  const displayOrderId = data ? getReadableOrderId(data) : id;
  const canAutoSyncSteadfast =
    data?.courierName === "Steadfast" ||
    Boolean(
      data?.trackingId ||
        data?.steadfastTrackingCode ||
        data?.steadfastConsignmentId,
    );

  return (
    <>
      <SteadfastAutoSync
        orderId={id}
        admin={true}
        enabled={canAutoSyncSteadfast}
      />
      <div className="mx-auto max-w-6xl px-3 py-6 sm:px-4 sm:py-10">
        <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="text-xl font-semibold sm:text-2xl">
              Order #{displayOrderId}
            </div>
            <div className="text-sm text-black/60">
              {data?.createdAt ? new Date(data.createdAt).toLocaleString() : ""}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Link
              href="/admin/orders"
              className="text-sm text-black/70 underline"
            >
              Back
            </Link>
            <Link
              href={`/admin/orders/${id}/invoice`}
              className="text-sm text-black/70 underline"
            >
              Invoice
            </Link>
          </div>
        </div>

        {!data ? (
          <Card className="rounded-3xl p-6">
            {loading ? "Loading…" : "Not found"}
          </Card>
        ) : (
          <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
            <div className="space-y-4">
              <Card className="rounded-3xl p-4">
                <div className="text-sm font-semibold">
                  Customer Information
                </div>

                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Customer name"
                  />
                  <Input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Phone"
                  />
                  <Input
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                  />
                  <Input
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="District"
                  />
                  <Input
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    placeholder="Police Station"
                  />
                  <Input
                    value={addressLine2}
                    onChange={(e) => setAddressLine2(e.target.value)}
                    placeholder="Address line 2"
                  />
                  <div className="sm:col-span-2">
                    <Input
                      value={addressLine1}
                      onChange={(e) => setAddressLine1(e.target.value)}
                      placeholder="Address line 1"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Input
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="Customer note"
                    />
                  </div>
                </div>
              </Card>

              <Card className="rounded-3xl p-4">
                <div className="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="text-sm font-semibold">Order Items</div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => openAddModal("catalog")}
                    >
                      Add Product
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => openAddModal("custom")}
                    >
                      Add Custom Item
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  {items.map((item, index) => {
                    const product = item.productId
                      ? (products.find((p) => p.id === item.productId) ?? null)
                      : null;

                    return (
                      <div
                        key={item.rowId}
                        className="rounded-2xl border border-black/10 p-3"
                      >
                        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                          <div className="text-sm font-medium">
                            Item #{index + 1}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <select
                              className="h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
                              value={item.mode}
                              onChange={(e) =>
                                handleModeChange(
                                  item.rowId,
                                  e.target.value as ItemMode,
                                )
                              }
                            >
                              <option value="catalog">Catalog Product</option>
                              <option value="custom">Custom Item</option>
                            </select>

                            <Button
                              type="button"
                              variant="secondary"
                              onClick={() => removeItem(item.rowId)}
                              disabled={items.length === 1}
                            >
                              Remove
                            </Button>
                          </div>
                        </div>

                        {item.mode === "catalog" ? (
                          <div className="grid gap-3 sm:grid-cols-2">
                            <div className="sm:col-span-2">
                              <div className="mb-1 text-xs text-black/60">
                                Product
                              </div>
                              <select
                                className="h-11 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                                value={item.productId ?? ""}
                                onChange={(e) =>
                                  handleProductChange(
                                    item.rowId,
                                    e.target.value,
                                  )
                                }
                              >
                                <option value="">Select product</option>
                                {products.map((productOption) => (
                                  <option
                                    key={productOption.id}
                                    value={productOption.id}
                                  >
                                    {productOption.name} ({productOption.sku}) -
                                    stock: {productOption.stock}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div className="sm:col-span-2">
                              <div className="mb-1 text-xs text-black/60">
                                Variant
                              </div>
                              <select
                                className="h-11 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                                value={item.variantId ?? ""}
                                onChange={(e) =>
                                  handleVariantChange(
                                    item.rowId,
                                    e.target.value,
                                  )
                                }
                                disabled={
                                  !product || product.variants.length === 0
                                }
                              >
                                <option value="">No variant</option>
                                {product?.variants.map((variant) => (
                                  <option key={variant.id} value={variant.id}>
                                    {variant.type}: {variant.value} (stock:{" "}
                                    {variant.stock})
                                  </option>
                                ))}
                              </select>
                            </div>

                            <Input
                              value={item.sku}
                              onChange={(e) =>
                                updateItem(item.rowId, { sku: e.target.value })
                              }
                              placeholder="SKU"
                            />

                            <Input
                              type="number"
                              value={item.unitPrice}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  unitPrice: Math.max(
                                    0,
                                    Math.floor(Number(e.target.value || 0)),
                                  ),
                                })
                              }
                              placeholder="Unit price"
                            />

                            <Input
                              type="number"
                              value={item.qty}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  qty: Math.max(
                                    1,
                                    Math.floor(Number(e.target.value || 1)),
                                  ),
                                })
                              }
                              placeholder="Quantity"
                            />

                            <div className="flex items-center rounded-2xl border border-black/10 px-4 text-sm font-medium">
                              Line Total: ৳ {item.unitPrice * item.qty}
                            </div>
                          </div>
                        ) : (
                          <div className="grid gap-3 sm:grid-cols-2">
                            <Input
                              value={item.customName}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  customName: e.target.value,
                                  productName: e.target.value,
                                })
                              }
                              placeholder="Custom product name"
                            />

                            <Input
                              value={item.customSku}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  customSku: e.target.value,
                                  sku: e.target.value || "CUSTOM",
                                })
                              }
                              placeholder="Custom SKU (optional)"
                            />

                            <Input
                              type="number"
                              value={item.unitPrice}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  unitPrice: Math.max(
                                    0,
                                    Math.floor(Number(e.target.value || 0)),
                                  ),
                                })
                              }
                              placeholder="Unit price"
                            />

                            <Input
                              type="number"
                              value={item.qty}
                              onChange={(e) =>
                                updateItem(item.rowId, {
                                  qty: Math.max(
                                    1,
                                    Math.floor(Number(e.target.value || 1)),
                                  ),
                                })
                              }
                              placeholder="Quantity"
                            />

                            <div className="sm:col-span-2 flex items-center rounded-2xl border border-black/10 px-4 py-3 text-sm font-medium">
                              Line Total: ৳ {item.unitPrice * item.qty}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </Card>

              <Card className="rounded-3xl p-4">
                <div className="text-sm font-semibold">
                  Manual Payment Details
                </div>

                {data.manualPayment ? (
                  <div className="mt-3 grid gap-2 text-sm text-black/70">
                    {data.manualPayment.provider ? (
                      <div>
                        Provider:{" "}
                        <span className="font-medium text-black">
                          {data.manualPayment.provider}
                        </span>
                      </div>
                    ) : null}
                    {data.manualPayment.paymentNumber ? (
                      <div>
                        Payment Number:{" "}
                        <span className="font-medium text-black">
                          {data.manualPayment.paymentNumber}
                        </span>
                      </div>
                    ) : null}
                    {data.manualPayment.senderPhone ? (
                      <div>
                        Sender Number:{" "}
                        <span className="font-medium text-black">
                          {data.manualPayment.senderPhone}
                        </span>
                      </div>
                    ) : null}
                    {data.manualPayment.transactionId ? (
                      <div>
                        Transaction ID:{" "}
                        <span className="font-medium text-black">
                          {data.manualPayment.transactionId}
                        </span>
                      </div>
                    ) : null}
                  </div>
                ) : (
                  <div className="mt-3 text-sm text-black/60">
                    No manual payment information available.
                  </div>
                )}
              </Card>
            </div>

            <Card className="h-fit rounded-3xl p-4">
              <div className="text-sm font-semibold">Order Control</div>

              <div className="mt-3 space-y-3">
                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Status
                  </div>
                  <select
                    className="mt-1 h-10 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                    value={status}
                    onChange={(e) => setStatus(e.target.value as OrderStatus)}
                  >
                    <option value="PENDING">PENDING</option>
                    <option value="PROCESSING">PROCESSING</option>
                    <option value="SHIPPED">SHIPPED</option>
                    <option value="DELIVERED">DELIVERED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Payment Status
                  </div>
                  <select
                    className="mt-1 h-10 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                    value={paymentStatus}
                    onChange={(e) =>
                      setPaymentStatus(e.target.value as PaymentStatus)
                    }
                  >
                    <option value="UNPAID">UNPAID</option>
                    <option value="PAID">PAID</option>
                    <option value="FAILED">FAILED</option>
                    <option value="REFUNDED">REFUNDED</option>
                  </select>
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Courier
                  </div>
                  <Input
                    value={courierName}
                    onChange={(e) => setCourierName(e.target.value)}
                    placeholder="Pathao / RedX / Steadfast"
                  />
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Tracking ID
                  </div>
                  <Input
                    value={trackingId}
                    onChange={(e) => setTrackingId(e.target.value)}
                    placeholder="Tracking ID"
                  />
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Shipping
                  </div>
                  <Input
                    type="number"
                    value={shipping}
                    onChange={(e) =>
                      setShipping(
                        Math.max(0, Math.floor(Number(e.target.value || 0))),
                      )
                    }
                  />
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">Tax</div>
                  <Input
                    type="number"
                    value={tax}
                    onChange={(e) =>
                      setTax(
                        Math.max(0, Math.floor(Number(e.target.value || 0))),
                      )
                    }
                  />
                </div>

                <div>
                  <div className="text-xs font-semibold text-black/60">
                    Discount
                  </div>
                  <Input
                    type="number"
                    value={discount}
                    onChange={(e) =>
                      setDiscount(
                        Math.max(0, Math.floor(Number(e.target.value || 0))),
                      )
                    }
                  />
                </div>

                {(data.steadfastConsignmentId ||
                  data.trackingId ||
                  data.steadfastTrackingCode) && (
                  <div className="rounded-2xl border border-black/10 bg-black/3 p-3 text-sm">
                    <div className="text-xs font-semibold text-black/60">
                      Steadfast Tracking
                    </div>

                    <div className="mt-2 space-y-1 text-sm text-black/70">
                      {data.steadfastConsignmentId ? (
                        <div>
                          Consignment ID:{" "}
                          <span className="font-medium text-black">
                            {data.steadfastConsignmentId}
                          </span>
                        </div>
                      ) : null}

                      {data.steadfastTrackingCode ? (
                        <div>
                          Tracking Code:{" "}
                          <span className="font-medium text-black">
                            {data.steadfastTrackingCode}
                          </span>
                        </div>
                      ) : null}
                    </div>

                    {data.steadfastTrackingUrl ? (
                      <a
                        href={data.steadfastTrackingUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-3 inline-flex text-sm font-medium text-blue-600 underline"
                      >
                        Track parcel on Steadfast
                      </a>
                    ) : null}
                  </div>
                )}

                <div className="pt-1 flex flex-col gap-2">
                  <Button
                    className="w-full"
                    onClick={() => void save()}
                    disabled={loading || deleting}
                  >
                    {loading ? "Saving…" : "Save changes"}
                  </Button>

                  <Button
                    variant="secondary"
                    className="w-full"
                    onClick={() => void bookSteadfast()}
                    disabled={loading || deleting}
                  >
                    Book in Steadfast
                  </Button>

                  <Button
                    variant="secondary"
                    className="w-full"
                    onClick={() => void syncSteadfastStatus()}
                    disabled={loading || deleting}
                  >
                    Sync Steadfast Status
                  </Button>
                </div>

                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={async () => {
                    if (!id) return;
                    setLoading(true);
                    try {
                      await fetch(`/api/admin/orders/${id}/refund`, {
                        method: "POST",
                      });
                      await load();
                    } finally {
                      setLoading(false);
                    }
                  }}
                  disabled={!canRefund || loading || deleting}
                >
                  {data.paymentStatus === "REFUNDED"
                    ? "Already Refunded"
                    : "Mark as REFUNDED"}
                </Button>

                <Button
                  variant="danger"
                  className="w-full"
                  onClick={() => void deleteOrder()}
                  disabled={loading || deleting}
                >
                  {deleting ? "Deleting…" : "Delete Order"}
                </Button>

                <div className="mt-2 grid gap-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-black/60">Subtotal</span>
                    <span>৳ {subtotal}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-black/60">Discount</span>
                    <span>৳ {discount}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-black/60">Shipping</span>
                    <span>৳ {shipping}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-black/60">Tax</span>
                    <span>৳ {tax}</span>
                  </div>

                  <div className="mt-1 flex justify-between border-t border-black/10 pt-3">
                    <span className="font-semibold">Total</span>
                    <span className="font-semibold">৳ {total}</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>

      {addModal.open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4">
          <div className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-4 shadow-2xl sm:max-w-3xl sm:rounded-3xl sm:p-6">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-semibold text-black">
                  Add item to order
                </div>
                <div className="text-sm text-black/60">
                  Add catalog products or custom items from this modal.
                </div>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="rounded-full border border-black/10 px-3 py-1 text-sm text-black/70 hover:bg-black/3"
              >
                Close
              </button>
            </div>

            <div className="mb-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onModalModeChange("catalog")}
                className={`rounded-2xl px-4 py-2 text-sm font-medium transition ${
                  addModal.mode === "catalog"
                    ? "bg-black text-white"
                    : "border border-black/10 bg-white text-black/70"
                }`}
              >
                Catalog Product
              </button>
              <button
                type="button"
                onClick={() => onModalModeChange("custom")}
                className={`rounded-2xl px-4 py-2 text-sm font-medium transition ${
                  addModal.mode === "custom"
                    ? "bg-black text-white"
                    : "border border-black/10 bg-white text-black/70"
                }`}
              >
                Custom Item
              </button>
            </div>

            {addModal.mode === "catalog" ? (
              <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
                <div className="min-w-0 rounded-2xl border border-black/10 p-3">
                  <div className="mb-2 text-sm font-medium">Find product</div>

                  <Input
                    value={addModal.search}
                    onChange={(e) =>
                      setAddModal((prev) => ({
                        ...prev,
                        search: e.target.value,
                      }))
                    }
                    placeholder="Search by product name or SKU"
                  />

                  <div className="mt-3 max-h-80 space-y-2 overflow-y-auto pr-1">
                    {filteredProducts.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
                        No product found.
                      </div>
                    ) : (
                      filteredProducts.map((product) => {
                        const active =
                          addModal.selectedProductId === product.id;
                        return (
                          <button
                            key={product.id}
                            type="button"
                            onClick={() => onModalProductChange(product.id)}
                            className={`w-full rounded-2xl border p-3 text-left transition ${
                              active
                                ? "border-black bg-black text-white"
                                : "border-black/10 bg-white hover:bg-black/3"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <div className="truncate text-sm font-medium">
                                  {product.name}
                                </div>
                                <div
                                  className={`mt-1 text-xs ${
                                    active ? "text-white/75" : "text-black/55"
                                  }`}
                                >
                                  SKU: {product.sku}
                                </div>
                              </div>
                              <div
                                className={`shrink-0 text-xs ${
                                  active ? "text-white/75" : "text-black/55"
                                }`}
                              >
                                stock: {product.stock}
                              </div>
                            </div>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="rounded-2xl border border-black/10 p-3">
                  <div className="mb-3 text-sm font-medium">
                    Selected product
                  </div>

                  {selectedModalProduct ? (
                    <div className="space-y-3">
                      <div className="rounded-2xl border border-black/10 bg-black/2 p-3">
                        <div className="font-medium">
                          {selectedModalProduct.name}
                        </div>
                        <div className="mt-1 text-xs text-black/60">
                          SKU: {selectedModalProduct.sku}
                        </div>
                        <div className="mt-1 text-xs text-black/60">
                          Stock: {selectedModalProduct.stock}
                        </div>
                      </div>

                      <div>
                        <div className="mb-1 text-xs text-black/60">
                          Variant
                        </div>
                        <select
                          className="h-11 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                          value={addModal.selectedVariantId}
                          onChange={(e) => onModalVariantChange(e.target.value)}
                          disabled={selectedModalProduct.variants.length === 0}
                        >
                          <option value="">No variant</option>
                          {selectedModalProduct.variants.map((variant) => (
                            <option key={variant.id} value={variant.id}>
                              {variant.type}: {variant.value} (stock:{" "}
                              {variant.stock})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-2">
                        <div>
                          <div className="mb-1 text-xs text-black/60">
                            Unit price
                          </div>
                          <Input
                            type="number"
                            value={addModal.unitPrice}
                            onChange={(e) =>
                              setAddModal((prev) => ({
                                ...prev,
                                unitPrice: Math.max(
                                  0,
                                  Math.floor(Number(e.target.value || 0)),
                                ),
                              }))
                            }
                          />
                        </div>

                        <div>
                          <div className="mb-1 text-xs text-black/60">
                            Quantity
                          </div>
                          <Input
                            type="number"
                            value={addModal.qty}
                            onChange={(e) =>
                              setAddModal((prev) => ({
                                ...prev,
                                qty: Math.max(
                                  1,
                                  Math.floor(Number(e.target.value || 1)),
                                ),
                              }))
                            }
                          />
                        </div>
                      </div>

                      <div className="rounded-2xl border border-black/10 px-4 py-3 text-sm font-medium">
                        Line Total: ৳ {addModal.unitPrice * addModal.qty}
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
                      Select a product from the left panel.
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-black/10 p-3">
                <div className="grid gap-3 sm:grid-cols-2">
                  <Input
                    value={addModal.customName}
                    onChange={(e) =>
                      setAddModal((prev) => ({
                        ...prev,
                        customName: e.target.value,
                      }))
                    }
                    placeholder="Custom product name"
                  />
                  <Input
                    value={addModal.customSku}
                    onChange={(e) =>
                      setAddModal((prev) => ({
                        ...prev,
                        customSku: e.target.value,
                      }))
                    }
                    placeholder="Custom SKU (optional)"
                  />
                  <div>
                    <label className="text-xs text-black/60 ml-2">
                      Unit Price
                    </label>
                    <Input
                      type="number"
                      value={addModal.unitPrice}
                      onChange={(e) =>
                        setAddModal((prev) => ({
                          ...prev,
                          unitPrice: Math.max(
                            0,
                            Math.floor(Number(e.target.value || 0)),
                          ),
                        }))
                      }
                      placeholder="Unit price"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-black/60 ml-2">
                      Quantity
                    </label>
                    <Input
                      type="number"
                      value={addModal.qty}
                      onChange={(e) =>
                        setAddModal((prev) => ({
                          ...prev,
                          qty: Math.max(
                            1,
                            Math.floor(Number(e.target.value || 1)),
                          ),
                        }))
                      }
                      placeholder="Quantity"
                    />
                  </div>
                  <div className="sm:col-span-2 rounded-2xl border border-black/10 px-4 py-3 text-sm font-medium">
                    Line Total: ৳ {addModal.unitPrice * addModal.qty}
                  </div>
                </div>
              </div>
            )}

            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button type="button" variant="secondary" onClick={closeAddModal}>
                Cancel
              </Button>
              <Button type="button" onClick={confirmAddModalItem}>
                Add to order
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
