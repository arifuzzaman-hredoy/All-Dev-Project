"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Trash2, Loader2, Search, Package2, CreditCard } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import AdminPagination from "@/components/admin/admin-pagination";
import AdminPageSize from "@/components/admin/admin-page-size";

type OrderStatus =
  | "PENDING"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

type PaymentStatus = "UNPAID" | "PAID" | "FAILED" | "REFUNDED";

type AdminOrderListItem = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  itemsCount: number;
  couponCode: string | null;
  courierName: string | null;
  trackingId: string | null;
};

type ApiResponse = {
  items: AdminOrderListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function getReadableOrderId(order: {
  id: string;
  publicOrderId?: string | null;
}) {
  return order.publicOrderId?.trim() || order.id;
}

function parseResponse(input: unknown): ApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const items: AdminOrderListItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      publicOrderId:
        typeof x.publicOrderId === "string" ? x.publicOrderId : null,
      createdAt: safeString(x.createdAt),
      name: safeString(x.name),
      phone: safeString(x.phone),
      total: safeNumber(x.total, 0),
      status: safeString(x.status) as OrderStatus,
      paymentStatus: safeString(x.paymentStatus) as PaymentStatus,
      itemsCount: safeNumber(x.itemsCount, 0),
      couponCode: typeof x.couponCode === "string" ? x.couponCode : null,
      courierName: typeof x.courierName === "string" ? x.courierName : null,
      trackingId: typeof x.trackingId === "string" ? x.trackingId : null,
    }))
    .filter((x) => x.id);

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 20)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

function getOrderStatusStyles(status: OrderStatus): string {
  switch (status) {
    case "PENDING":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "PROCESSING":
      return "border-sky-200 bg-sky-50 text-sky-700";
    case "SHIPPED":
      return "border-violet-200 bg-violet-50 text-violet-700";
    case "DELIVERED":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "CANCELLED":
      return "border-rose-200 bg-rose-50 text-rose-700";
    default:
      return "border-black/10 bg-black/5 text-black/70";
  }
}

function getPaymentStatusStyles(status: PaymentStatus): string {
  switch (status) {
    case "PAID":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "UNPAID":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "FAILED":
      return "border-red-200 bg-red-50 text-red-700";
    case "REFUNDED":
      return "border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700";
    default:
      return "border-black/10 bg-black/5 text-black/70";
  }
}

function StatusBadge({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold tracking-wide ${className}`}
    >
      {children}
    </span>
  );
}

export default function AdminOrdersPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const { toast } = useToast();

  const [loading, setLoading] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);
  const [data, setData] = React.useState<ApiResponse>({
    items: [],
    total: 0,
    page: 1,
    take: 20,
    pages: 1,
  });

  const [q, setQ] = React.useState(sp.get("q") || "");

  const page = Number(sp.get("page") || "1") || 1;
  const take = Number(sp.get("take") || "20") || 20;
  const status = sp.get("status") || "";
  const payment = sp.get("payment") || "";

  const setParam = React.useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(sp.toString());

      if (value.trim()) params.set(key, value.trim());
      else params.delete(key);

      if (key !== "page") params.set("page", "1");

      router.push(`/admin/orders?${params.toString()}`);
    },
    [router, sp],
  );

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/orders?${sp.toString()}`, {
        cache: "no-store",
      });
      const json: unknown = await res.json().catch(() => null);
      setData(parseResponse(json));
    } finally {
      setLoading(false);
    }
  }, [sp]);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const deleteOrder = async (orderDbId: string, displayOrderId: string) => {
    const ok = window.confirm(
      `Are you sure you want to delete order #${displayOrderId}? This will permanently remove it from the database.`,
    );
    if (!ok) return;

    setDeletingId(orderDbId);

    try {
      const res = await fetch(`/api/admin/orders/${orderDbId}`, {
        method: "DELETE",
      });

      const json: unknown = await res.json().catch(() => null);

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Delete failed",
          description:
            (json as { error?: string } | null)?.error ||
            "Failed to delete order.",
        });
        return;
      }

      toast({
        variant: "success",
        title: "Order deleted",
        description: `Order #${displayOrderId} has been removed from the database.`,
      });

      await fetchData();
      router.refresh();
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:py-10">
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-3xl font-bold tracking-tight text-black">
            Admin Orders
          </div>
          <div className="mt-1 text-sm text-black/55">
            Manage and monitor all customer orders
          </div>
        </div>

        <div className="inline-flex w-fit items-center rounded-2xl border border-black/10 bg-white px-4 py-2 shadow-sm">
          <Package2 className="mr-2 h-4 w-4 text-black/60" />
          <span className="text-sm font-medium text-black/70">
            {data.total} orders
          </span>
        </div>
      </div>

      <Card className="rounded-[28px] border border-black/10 bg-white/95 p-4 shadow-sm backdrop-blur">
        <div className="grid gap-3 md:grid-cols-5">
          <div className="relative md:col-span-2">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/40" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search: public ID / id / name / phone / tracking"
              className="h-11 rounded-2xl border-black/10 pl-10 shadow-none focus-visible:ring-1"
            />
          </div>

          <select
            className="h-11 rounded-2xl border border-black/10 bg-white px-3 text-sm outline-none transition focus:border-black/20"
            value={status}
            onChange={(e) => setParam("status", e.target.value)}
          >
            <option value="">All status</option>
            <option value="PENDING">PENDING</option>
            <option value="PROCESSING">PROCESSING</option>
            <option value="SHIPPED">SHIPPED</option>
            <option value="DELIVERED">DELIVERED</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>

          <select
            className="h-11 rounded-2xl border border-black/10 bg-white px-3 text-sm outline-none transition focus:border-black/20"
            value={payment}
            onChange={(e) => setParam("payment", e.target.value)}
          >
            <option value="">All payment</option>
            <option value="UNPAID">UNPAID</option>
            <option value="PAID">PAID</option>
            <option value="FAILED">FAILED</option>
            <option value="REFUNDED">REFUNDED</option>
          </select>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex gap-2">
              <Button
                variant="secondary"
                onClick={() => setParam("q", q)}
                disabled={loading}
                className="rounded-2xl"
              >
                Search
              </Button>

              <Button
                variant="secondary"
                onClick={() => {
                  setQ("");
                  router.push("/admin/orders");
                }}
                disabled={loading}
                className="rounded-2xl"
              >
                Clear
              </Button>
            </div>

            <AdminPageSize
              value={take}
              onChange={(value) => setParam("take", String(value))}
            />
          </div>
        </div>
      </Card>

      <div className="mt-5 grid gap-4">
        {data.items.map((o) => {
          const deletingThis = deletingId === o.id;
          const displayOrderId = getReadableOrderId(o);

          return (
            <Card
              key={o.id}
              className="group rounded-[28px] border border-black/10 bg-white p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
            >
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <Link href={`/admin/orders/${o.id}`} className="min-w-0 flex-1">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="text-base font-bold text-black">
                          #{displayOrderId}
                        </div>

                        <StatusBadge className={getOrderStatusStyles(o.status)}>
                          {o.status}
                        </StatusBadge>

                        <StatusBadge
                          className={getPaymentStatusStyles(o.paymentStatus)}
                        >
                          {o.paymentStatus}
                        </StatusBadge>
                      </div>

                      <div className="mt-2 space-y-1 text-sm text-black/60">
                        <div>
                          {new Date(o.createdAt).toLocaleString()} •{" "}
                          {o.itemsCount} items
                        </div>
                        <div>
                          {o.name} • {o.phone}
                        </div>
                        <div>
                          {o.couponCode
                            ? `Coupon: ${o.couponCode}`
                            : "No coupon"}{" "}
                          •{" "}
                          {o.courierName
                            ? `Courier: ${o.courierName}`
                            : "No courier"}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 text-left lg:text-right">
                      <div className="text-lg font-bold text-black">
                        ৳ {o.total}
                      </div>

                      <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-slate-50 px-3 py-1 text-xs font-medium text-slate-600">
                        <CreditCard className="h-3.5 w-3.5" />
                        {o.trackingId
                          ? `Tracking: ${o.trackingId}`
                          : "No tracking"}
                      </div>
                    </div>
                  </div>
                </Link>

                <div className="flex shrink-0 items-center gap-2">
                  <Link href={`/admin/orders/${o.id}`}>
                    <Button
                      variant="secondary"
                      disabled={!!deletingId}
                      className="rounded-2xl"
                    >
                      View
                    </Button>
                  </Link>

                  <Button
                    variant="danger"
                    onClick={() => void deleteOrder(o.id, displayOrderId)}
                    disabled={loading || !!deletingId}
                    className="rounded-2xl"
                  >
                    {deletingThis ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      <>
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}

        {!loading && data.items.length === 0 ? (
          <Card className="rounded-[28px] border border-dashed border-black/10 p-8 text-center text-sm text-black/60">
            No orders found.
          </Card>
        ) : null}
      </div>

      <div className="mt-6">
        <AdminPagination
          page={page}
          pages={data.pages}
          onPageChange={(nextPage) => setParam("page", String(nextPage))}
        />
      </div>
    </div>
  );
}
