"use client";

import { useState } from "react";

async function waitForImages() {
  const images = Array.from(document.images);

  await Promise.all(
    images.map((img) => {
      if (img.complete) return Promise.resolve();

      return new Promise<void>((resolve) => {
        const done = () => resolve();
        img.addEventListener("load", done, { once: true });
        img.addEventListener("error", done, { once: true });
      });
    }),
  );
}

export default function InvoicePrintButton() {
  const [printing, setPrinting] = useState(false);

  const handlePrint = async () => {
    try {
      setPrinting(true);

      if ("fonts" in document) {
        await document.fonts.ready;
      }

      await waitForImages();
      await new Promise((resolve) => setTimeout(resolve, 150));

      window.print();
    } finally {
      setTimeout(() => setPrinting(false), 300);
    }
  };

  return (
    <button
      type="button"
      onClick={handlePrint}
      disabled={printing}
      className="rounded-xl border border-black/10 px-4 py-2 text-sm hover:bg-black/5 disabled:cursor-not-allowed disabled:opacity-60"
    >
      {printing ? "Preparing..." : "Print / Save PDF"}
    </button>
  );
}
