"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

type Status = "PENDING" | "PROCESSING" | "SHIPPED" | "DELIVERED" | "CANCELLED";

const STATUSES: Status[] = [
  "PENDING",
  "PROCESSING",
  "SHIPPED",
  "DELIVERED",
  "CANCELLED",
];

function label(s: Status) {
  return s.charAt(0) + s.slice(1).toLowerCase();
}

export default function OrderStatusUpdater({
  orderId,
  initialStatus,
}: {
  orderId: string;
  initialStatus: Status;
}) {
  const router = useRouter();
  const [status, setStatus] = React.useState<Status>(initialStatus);
  const [loading, setLoading] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);
  const [ok, setOk] = React.useState<string | null>(null);

  const save = async () => {
    setErr(null);
    setOk(null);
    setLoading(true);

    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status }),
      });

      const data: unknown = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg =
          (data as { error?: string })?.error ||
          "Status update failed.";
        setErr(typeof msg === "string" ? msg : "Status update failed.");
        return;
      }

      setOk("Status updated.");
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
      setTimeout(() => setOk(null), 2000);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-3">
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value as Status)}
        className="h-11 rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
        disabled={loading}
      >
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {label(s)}
          </option>
        ))}
      </select>

      <Button onClick={save} disabled={loading}>
        {loading ? "Updating..." : "Update Status"}
      </Button>

      {err ? <div className="text-sm text-red-600">{err}</div> : null}
      {ok ? <div className="text-sm text-green-700">{ok}</div> : null}
    </div>
  );
}