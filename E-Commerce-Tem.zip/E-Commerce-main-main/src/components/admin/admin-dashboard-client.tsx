"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { buildOrderExportRows, ORDER_EXPORT_HEADERS } from "@/lib/order-export";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Area,
  ComposedChart,
  Legend,
} from "recharts";
import {
  TrendingUp,
  Download,
  Package,
  DollarSign,
  ShoppingBag,
  ArrowUpRight,
  BarChart3,
  LineChart as LineChartIcon,
  DownloadCloud,
  Eye,
  EyeOff,
  Clock,
  Star,
  Zap,
  Award,
  Save,
  RefreshCw,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";

type MonthPoint = { month: string; revenue: number; orders: number };
type BestSellingItem = {
  productId: string;
  name: string;
  slug: string;
  qty: number;
  revenue: number;
};
type DayPoint = { day: string; revenue: number; orders: number };

type RevenueRow = {
  orderId: string;
  publicOrderId: string | null;
  createdAt: string;
  customerName: string;
  phone: string;
  status: string;
  paymentStatus: string;
  sell: number;
  shipping: number;
  deliveryCharge: number;
  grandSellAmount: number;
  investedAmount: number | null;
  revenue: number | null;
  adminNote: string | null;
};

type RevenueReport = {
  year: number;
  month: number;
  rows: RevenueRow[];
  totals: {
    sell: number;
    deliveryCharge: number;
    grandSellAmount: number;
    investedAmount: number;
    revenue: number;
    completedRevenueRows: number;
  };
};

type ApiResponse = {
  ok: true;
  totalSell: number;
  totalOrders: number;
  last30Days: { orders: number; revenue: number };
  thisMonth: { orders: number; revenue: number };
  monthly: MonthPoint[];
  bestSelling30: BestSellingItem[];
  revenueReport: RevenueReport;
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function currentYear() {
  return new Date().getFullYear();
}

function currentMonth() {
  return new Date().getMonth() + 1;
}

function calcGrandSellAmount(sell: number, deliveryCharge: number) {
  return Math.max(0, Math.round(sell - deliveryCharge));
}

function calcRevenue(
  sell: number,
  deliveryCharge: number,
  investedAmount: number | null,
) {
  if (investedAmount === null) return null;
  return Math.round(calcGrandSellAmount(sell, deliveryCharge) - investedAmount);
}

function parseNumberInput(value: string) {
  if (value.trim() === "") return null;
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return Math.max(0, Math.round(n));
}

function parseRevenueReport(input: unknown): RevenueReport {
  const o = (input as Record<string, unknown>) ?? {};
  const rowsRaw = Array.isArray(o.rows) ? o.rows : [];

  const rows: RevenueRow[] = rowsRaw.map((x) => {
    const r = x as Record<string, unknown>;

    return {
      orderId: safeString(r.orderId),
      publicOrderId:
        typeof r.publicOrderId === "string" ? r.publicOrderId : null,
      createdAt: safeString(r.createdAt),
      customerName: safeString(r.customerName),
      phone: safeString(r.phone),
      status: safeString(r.status),
      paymentStatus: safeString(r.paymentStatus),
      sell: safeNumber(r.sell, 0),
      shipping: safeNumber(r.shipping, 0),
      deliveryCharge: safeNumber(r.deliveryCharge, 0),
      grandSellAmount: safeNumber(r.grandSellAmount, 0),
      investedAmount:
        r.investedAmount === null || typeof r.investedAmount === "undefined"
          ? null
          : safeNumber(r.investedAmount, 0),
      revenue:
        r.revenue === null || typeof r.revenue === "undefined"
          ? null
          : safeNumber(r.revenue, 0),
      adminNote:
        typeof r.adminNote === "string" && r.adminNote.trim()
          ? r.adminNote
          : null,
    };
  });

  const totalsRaw = (o.totals as Record<string, unknown>) ?? {};

  return {
    year: safeNumber(o.year, currentYear()),
    month: safeNumber(o.month, currentMonth()),
    rows,
    totals: {
      sell: safeNumber(totalsRaw.sell, 0),
      deliveryCharge: safeNumber(totalsRaw.deliveryCharge, 0),
      grandSellAmount: safeNumber(totalsRaw.grandSellAmount, 0),
      investedAmount: safeNumber(totalsRaw.investedAmount, 0),
      revenue: safeNumber(totalsRaw.revenue, 0),
      completedRevenueRows: safeNumber(totalsRaw.completedRevenueRows, 0),
    },
  };
}

function parse(input: unknown): ApiResponse | null {
  const o = input as Record<string, unknown>;
  if (o.ok !== true) return null;

  const monthlyRaw = Array.isArray(o.monthly) ? o.monthly : [];
  const monthly: MonthPoint[] = monthlyRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      month: safeString(x.month),
      revenue: safeNumber(x.revenue, 0),
      orders: safeNumber(x.orders, 0),
    }))
    .filter((x) => x.month);

  const bestRaw = Array.isArray(o.bestSelling30) ? o.bestSelling30 : [];
  const bestSelling30: BestSellingItem[] = bestRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      name: safeString(x.name),
      slug: safeString(x.slug),
      qty: safeNumber(x.qty, 0),
      revenue: safeNumber(x.revenue, 0),
    }))
    .filter((x) => x.slug);

  const last30 = (o.last30Days as Record<string, unknown>) ?? {};
  const thisM = (o.thisMonth as Record<string, unknown>) ?? {};

  return {
    ok: true,
    totalSell: safeNumber(o.totalSell, 0),
    totalOrders: safeNumber(o.totalOrders, 0),
    last30Days: {
      orders: safeNumber(last30.orders, 0),
      revenue: safeNumber(last30.revenue, 0),
    },
    thisMonth: {
      orders: safeNumber(thisM.orders, 0),
      revenue: safeNumber(thisM.revenue, 0),
    },
    monthly,
    bestSelling30,
    revenueReport: parseRevenueReport(o.revenueReport),
  };
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="max-w-55 rounded-2xl border border-gray-100 bg-white/95 p-3 shadow-xl backdrop-blur-md sm:max-w-none sm:p-4">
        <p className="mb-2 text-sm font-semibold text-gray-900">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-gray-600">{entry.name}:</span>
            <span className="font-semibold text-gray-900">
              {entry.name?.toLowerCase().includes("revenue")
                ? `৳ ${Number(entry.value || 0).toLocaleString()}`
                : entry.value}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const StatCard = ({
  title,
  value,
  icon: Icon,
  subtitle,
}: {
  title: string;
  value: string;
  icon: any;
  subtitle?: string;
}) => {
  return (
    <Card className="group relative min-w-0 overflow-hidden rounded-2xl border-0 bg-white shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-linear-to-br from-gray-50 to-gray-100 opacity-50 sm:h-32 sm:w-32" />
      <div className="p-4 sm:p-5 lg:p-6">
        <div className="mb-4 flex items-center justify-between">
          <div className="rounded-xl bg-linear-to-br from-gray-900 to-gray-700 p-3">
            <Icon className="h-5 w-5 text-white" />
          </div>
        </div>
        <p className="mb-1 text-sm text-gray-500">{title}</p>
        <p className="wrap-break-word text-xl font-bold text-gray-900 sm:text-2xl">
          {value}
        </p>
        {subtitle && <p className="mt-2 text-xs text-gray-400">{subtitle}</p>}
      </div>
    </Card>
  );
};

export default function AdminReportsClient() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");
  const [daily, setDaily] = useState<DayPoint[]>([]);
  const [csvFrom, setCsvFrom] = useState<string>("");
  const [csvTo, setCsvTo] = useState<string>("");
  const [csvStatus, setCsvStatus] = useState<string>("");
  const [csvPaymentStatus, setCsvPaymentStatus] = useState<string>("");
  const [timeRange, setTimeRange] = useState<"7" | "14" | "30">("14");
  const [showChartType, setShowChartType] = useState<"line" | "bar">("line");
  const [showValues, setShowValues] = useState(true);
  const [revenueYear, setRevenueYear] = useState(currentYear());
  const [revenueMonth, setRevenueMonth] = useState(currentMonth());
  const [savingRevenueId, setSavingRevenueId] = useState<string | null>(null);
  const [revenueSearch, setRevenueSearch] = useState("");
  const [revenueStatusFilter, setRevenueStatusFilter] = useState("");
  const [revenuePaymentFilter, setRevenuePaymentFilter] = useState("");
  const [revenueEntryFilter, setRevenueEntryFilter] = useState<
    "" | "pending" | "saved"
  >("");
  const [visibleRevenueCount, setVisibleRevenueCount] = useState(8);

  const load = async (): Promise<void> => {
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams({
        year: String(revenueYear),
        month: String(revenueMonth),
      });

      const r = await fetch(
        `/api/admin/reports/overview?${params.toString()}`,
        {
          cache: "no-store",
        },
      );
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed to load reports");
        setData(null);
        return;
      }
      const parsed = parse(j);
      if (!parsed) {
        setErr("Invalid response");
        setData(null);
        return;
      }
      setData(parsed);

      const dr = await fetch(`/api/admin/reports/daily?days=${timeRange}`, {
        cache: "no-store",
      });
      const dj: unknown = await dr.json().catch(() => null);
      const dobj = dj as Record<string, unknown>;
      if (dr.ok && dobj.ok === true && Array.isArray(dobj.days)) {
        const arr = dobj.days
          .map((x) => x as Record<string, unknown>)
          .map((x) => ({
            day: safeString(x.day),
            revenue: safeNumber(x.revenue, 0),
            orders: safeNumber(x.orders, 0),
          }))
          .filter((x) => x.day);
        setDaily(arr);
      } else {
        setDaily([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeRange, revenueYear, revenueMonth]);

  const formatCurrency = (value: number) => {
    return `৳ ${value.toLocaleString()}`;
  };

  const totalSell = useMemo(() => data?.totalSell ?? 0, [data]);
  const totalOrders = useMemo(() => data?.totalOrders ?? 0, [data]);
  const revenueReport = data?.revenueReport;

  const revenueRows = revenueReport?.rows ?? [];

  const revenueStatuses = useMemo(() => {
    return Array.from(
      new Set(revenueRows.map((row) => row.status).filter(Boolean)),
    );
  }, [revenueRows]);

  const revenuePaymentStatuses = useMemo(() => {
    return Array.from(
      new Set(revenueRows.map((row) => row.paymentStatus).filter(Boolean)),
    );
  }, [revenueRows]);

  const filteredRevenueRows = useMemo(() => {
    const q = revenueSearch.trim().toLowerCase();

    return revenueRows.filter((row) => {
      const matchesSearch = q
        ? [
            row.publicOrderId,
            row.orderId,
            row.customerName,
            row.phone,
            row.adminNote,
            row.status,
            row.paymentStatus,
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase()
            .includes(q)
        : true;

      const matchesStatus = revenueStatusFilter
        ? row.status === revenueStatusFilter
        : true;
      const matchesPayment = revenuePaymentFilter
        ? row.paymentStatus === revenuePaymentFilter
        : true;
      const matchesEntry =
        revenueEntryFilter === "pending"
          ? row.revenue === null
          : revenueEntryFilter === "saved"
            ? row.revenue !== null
            : true;

      return matchesSearch && matchesStatus && matchesPayment && matchesEntry;
    });
  }, [
    revenueRows,
    revenueSearch,
    revenueStatusFilter,
    revenuePaymentFilter,
    revenueEntryFilter,
  ]);

  const visibleRevenueRows = filteredRevenueRows.slice(0, visibleRevenueCount);
  const activeRevenueFilters = Boolean(
    revenueSearch ||
    revenueStatusFilter ||
    revenuePaymentFilter ||
    revenueEntryFilter,
  );

  useEffect(() => {
    setVisibleRevenueCount(8);
  }, [
    revenueSearch,
    revenueStatusFilter,
    revenuePaymentFilter,
    revenueEntryFilter,
    revenueYear,
    revenueMonth,
  ]);

  const clearRevenueFilters = () => {
    setRevenueSearch("");
    setRevenueStatusFilter("");
    setRevenuePaymentFilter("");
    setRevenueEntryFilter("");
  };

  const years = useMemo(() => {
    const y = currentYear();
    return [y - 2, y - 1, y, y + 1];
  }, []);

  const pieColors = [
    "#10b981",
    "#6366f1",
    "#f59e0b",
    "#ef4444",
    "#8b5cf6",
    "#ec4899",
  ];

  const handleExportOrders = () => {
    const p = new URLSearchParams();

    if (csvFrom) p.set("from", csvFrom);
    if (csvTo) p.set("to", csvTo);
    if (csvStatus) p.set("status", csvStatus);
    if (csvPaymentStatus) p.set("paymentStatus", csvPaymentStatus);

    window.open(`/api/reports/orders/export?${p.toString()}`, "_blank");
  };

  // excel csv
  function csvCell(value: unknown) {
    const raw = String(value ?? "");

    // Excel formula injection protection
    const safeRaw = /^[=+\-@]/.test(raw) ? `\t${raw}` : raw;

    return `"${safeRaw.replace(/"/g, '""')}"`;
  }

  function formatCsvDate(value: string) {
    if (!value) return "";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleString("en-GB", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  }

  function downloadCsv(filename: string, rows: Record<string, unknown>[]) {
    if (rows.length === 0) {
      setErr("No visible revenue rows to export");
      return;
    }

    const headers = Object.keys(rows[0]);

    const csv = [
      headers.map(csvCell).join(","),
      ...rows.map((row) =>
        headers.map((header) => csvCell(row[header])).join(","),
      ),
    ].join("\r\n");

    const blob = new Blob(["\uFEFF", csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();

    a.remove();
    URL.revokeObjectURL(url);
  }

  const handleExportVisibleRevenueRows = () => {
    const exportRows = visibleRevenueRows.map((row, index) => ({
      SL: index + 1,
      "Order ID": row.publicOrderId || row.orderId,
      "Created At": formatCsvDate(row.createdAt),
      "Customer Name": row.customerName,
      Phone: row.phone,
      "Order Status": row.status,
      "Payment Status": row.paymentStatus,
      Sell: row.sell,
      Shipping: row.shipping,
      "Delivery Charge": row.deliveryCharge,
      "Grand Sell Amount": row.grandSellAmount,
      "Invested Amount": row.investedAmount ?? "",
      Revenue: row.revenue ?? "Pending",
      Note: row.adminNote ?? "",
    }));

    downloadCsv(
      `visible-revenue-${revenueYear}-${String(revenueMonth).padStart(2, "0")}.csv`,
      exportRows,
    );
  };

  function updateRevenueRow(
    orderId: string,
    patch: Partial<
      Pick<RevenueRow, "deliveryCharge" | "investedAmount" | "adminNote">
    >,
  ) {
    setData((prev) => {
      if (!prev) return prev;

      const rows = prev.revenueReport.rows.map((row) => {
        if (row.orderId !== orderId) return row;

        const nextDelivery =
          typeof patch.deliveryCharge === "number"
            ? patch.deliveryCharge
            : row.deliveryCharge;

        const nextInvested =
          typeof patch.investedAmount !== "undefined"
            ? patch.investedAmount
            : row.investedAmount;

        return {
          ...row,
          ...patch,
          deliveryCharge: nextDelivery,
          investedAmount: nextInvested,
          grandSellAmount: calcGrandSellAmount(row.sell, nextDelivery),
          revenue: calcRevenue(row.sell, nextDelivery, nextInvested),
        };
      });

      const totals = rows.reduce(
        (acc, row) => {
          acc.sell += row.sell;
          acc.deliveryCharge += row.deliveryCharge;
          acc.grandSellAmount += row.grandSellAmount;
          acc.investedAmount += row.investedAmount ?? 0;
          acc.revenue += row.revenue ?? 0;
          acc.completedRevenueRows += row.revenue === null ? 0 : 1;
          return acc;
        },
        {
          sell: 0,
          deliveryCharge: 0,
          grandSellAmount: 0,
          investedAmount: 0,
          revenue: 0,
          completedRevenueRows: 0,
        },
      );

      return {
        ...prev,
        revenueReport: {
          ...prev.revenueReport,
          rows,
          totals,
        },
      };
    });
  }

  async function saveRevenue(row: RevenueRow) {
    setSavingRevenueId(row.orderId);

    try {
      const res = await fetch(`/api/admin/revenue/${row.orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deliveryCharge: row.deliveryCharge,
          investedAmount: row.investedAmount,
          adminNote: row.adminNote,
        }),
      });

      if (!res.ok) {
        setErr("Revenue save failed");
        return;
      }

      await load();
    } finally {
      setSavingRevenueId(null);
    }
  }

  return (
    <div className="min-h-screen overflow-x-hidden bg-linear-to-br from-gray-50 via-white to-gray-50">
      <div className="mx-auto max-w-7xl px-3 py-4 sm:px-4 sm:py-5 lg:px-6">
        {err ? (
          <Card className="mb-6 rounded-2xl border border-red-200 bg-red-50/90 p-4 backdrop-blur-sm sm:p-6">
            <p className="text-red-600">{err}</p>
          </Card>
        ) : null}

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <StatCard
            title="Total Sell"
            value={formatCurrency(totalSell)}
            icon={DollarSign}
            subtitle="Existing non-cancelled orders"
          />
          <StatCard
            title="Total Orders"
            value={totalOrders.toString()}
            icon={ShoppingBag}
            subtitle="+124 from last month"
          />
          <StatCard
            title="Avg. Order Value"
            value={formatCurrency(
              totalOrders > 0 ? Math.round(totalSell / totalOrders) : 0,
            )}
            icon={Package}
            subtitle="Per transaction"
          />
        </div>

        <Card className="mb-8 overflow-hidden rounded-2xl border-0 bg-white shadow-lg">
          <div className="border-b border-gray-100 p-4 sm:p-5 lg:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Total Revenue
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Manage order-wise revenue by updating delivery charge and
                  invested amount. Revenue will be calculated automatically.
                </p>
              </div>

              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-500">
                    Month
                  </label>
                  <select
                    value={revenueMonth}
                    onChange={(e) => setRevenueMonth(Number(e.target.value))}
                    className="h-11 rounded-xl border border-gray-200 bg-white px-3 text-sm"
                  >
                    {Array.from({ length: 12 }).map((_, idx) => (
                      <option key={idx + 1} value={idx + 1}>
                        {idx + 1}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-500">
                    Year
                  </label>
                  <select
                    value={revenueYear}
                    onChange={(e) => setRevenueYear(Number(e.target.value))}
                    className="h-11 rounded-xl border border-gray-200 bg-white px-3 text-sm"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    ))}
                  </select>
                </div>

                <Button
                  type="button"
                  onClick={() => void load()}
                  disabled={loading}
                  className="h-11 rounded-xl bg-gray-900 text-white"
                >
                  <RefreshCw
                    className={`h-4 w-4 ${loading ? "animate-spin" : ""}`}
                  />
                  Refresh
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-3 border-b border-gray-100 p-3 sm:grid-cols-2 sm:p-4 lg:grid-cols-5 lg:p-6">
            <div className="rounded-2xl bg-gray-50 p-3 sm:p-4">
              <div className="text-xs text-gray-500">Sell</div>
              <div className="mt-1 text-base font-bold sm:text-lg">
                {formatCurrency(revenueReport?.totals.sell ?? 0)}
              </div>
            </div>

            <div className="rounded-2xl bg-gray-50 p-3 sm:p-4">
              <div className="text-xs text-gray-500">Delivery Charge</div>
              <div className="mt-1 text-base font-bold sm:text-lg">
                {formatCurrency(revenueReport?.totals.deliveryCharge ?? 0)}
              </div>
            </div>

            <div className="rounded-2xl bg-gray-50 p-3 sm:p-4">
              <div className="text-xs text-gray-500">Grand Sell Amount</div>
              <div className="mt-1 text-base font-bold sm:text-lg">
                {formatCurrency(revenueReport?.totals.grandSellAmount ?? 0)}
              </div>
            </div>

            <div className="rounded-2xl bg-gray-50 p-3 sm:p-4">
              <div className="text-xs text-gray-500">Invested Amount</div>
              <div className="mt-1 text-base font-bold sm:text-lg">
                {formatCurrency(revenueReport?.totals.investedAmount ?? 0)}
              </div>
            </div>

            <div className="rounded-2xl bg-green-50 p-3 sm:p-4">
              <div className="text-xs text-green-700">Revenue</div>
              <div className="mt-1 text-base font-bold text-green-700 sm:text-lg">
                {formatCurrency(revenueReport?.totals.revenue ?? 0)}
              </div>
            </div>
          </div>

          <div className="border-b border-gray-100 bg-white p-3 sm:p-4 lg:p-6">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="relative min-w-0 flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <input
                  value={revenueSearch}
                  onChange={(e) => setRevenueSearch(e.target.value)}
                  placeholder="Search order, customer, phone or note"
                  className="h-12 w-full rounded-2xl border border-gray-200 bg-gray-50 pl-10 pr-4 text-sm outline-none transition focus:border-pink-300 focus:bg-white focus:ring-4 focus:ring-pink-50"
                />
              </div>

              <div className="grid gap-2 sm:grid-cols-3 lg:w-auto">
                <select
                  value={revenueStatusFilter}
                  onChange={(e) => setRevenueStatusFilter(e.target.value)}
                  className="h-12 rounded-2xl border border-gray-200 bg-white px-3 text-sm outline-none focus:border-gray-400"
                >
                  <option value="">All order status</option>
                  {revenueStatuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>

                <select
                  value={revenuePaymentFilter}
                  onChange={(e) => setRevenuePaymentFilter(e.target.value)}
                  className="h-12 rounded-2xl border border-gray-200 bg-white px-3 text-sm outline-none focus:border-gray-400"
                >
                  <option value="">All payment status</option>
                  {revenuePaymentStatuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>

                <select
                  value={revenueEntryFilter}
                  onChange={(e) =>
                    setRevenueEntryFilter(
                      e.target.value as "" | "pending" | "saved",
                    )
                  }
                  className="h-12 rounded-2xl border border-gray-200 bg-white px-3 text-sm outline-none focus:border-gray-400"
                >
                  <option value="">All entries</option>
                  <option value="pending">Pending revenue</option>
                  <option value="saved">Calculated revenue</option>
                </select>
              </div>
            </div>

            <div className="mt-3 flex flex-col gap-2 text-xs text-gray-500 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Showing{" "}
                {Math.min(
                  visibleRevenueRows.length,
                  filteredRevenueRows.length,
                )}{" "}
                of {filteredRevenueRows.length} orders
                {revenueRows.length !== filteredRevenueRows.length
                  ? ` • ${revenueRows.length} total`
                  : ""}
              </div>

              {activeRevenueFilters ? (
                <button
                  type="button"
                  onClick={clearRevenueFilters}
                  className="inline-flex items-center gap-1 font-medium text-pink-700 hover:text-pink-800"
                >
                  <X className="h-3.5 w-3.5" />
                  Clear filters
                </button>
              ) : null}
            </div>
          </div>

          <div className="w-full overflow-x-auto touch-pan-x">
            <table className="min-w-[850px] w-full border border-gray-300 text-xs">
              <thead className="bg-gray-100 text-[10px] uppercase text-gray-600">
                <tr>
                  {[
                    "Order",
                    "Sell",
                    "Delivery",
                    "Grand",
                    "Invested",
                    "Revenue",
                    "Note",
                    "",
                  ].map((h) => (
                    <th
                      key={h}
                      className="border border-gray-300 px-2 py-1 text-left font-semibold"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {visibleRevenueRows.map((row) => {
                  const saving = savingRevenueId === row.orderId;

                  return (
                    <tr
                      key={row.orderId}
                      className={`transition ${
                        row.revenue === null ? "bg-red-50" : "hover:bg-gray-50"
                      }`}
                    >
                      {/* ORDER */}
                      <td className="border border-gray-200 px-2 py-1 align-middle">
                        <Link
                          href={`/admin/orders/${row.orderId}`}
                          className="font-semibold text-pink-700 hover:underline"
                        >
                          #{row.publicOrderId || row.orderId}
                        </Link>

                        <div className="mt-0.5 flex gap-1">
                          <span className="rounded bg-gray-100 px-1 text-[9px]">
                            {row.status}
                          </span>
                          <span className="rounded bg-blue-100 px-1 text-[9px] text-blue-700">
                            {row.paymentStatus}
                          </span>
                        </div>
                      </td>

                      {/* SELL */}
                      <td className="border border-gray-200 px-2 py-1 text-right font-semibold">
                        {formatCurrency(row.sell)}
                      </td>

                      {/* DELIVERY */}
                      <td className="border border-gray-200 px-2 py-1">
                        <input
                          type="number"
                          value={row.deliveryCharge}
                          onChange={(e) =>
                            updateRevenueRow(row.orderId, {
                              deliveryCharge: Math.max(
                                0,
                                Math.round(Number(e.target.value || 0)),
                              ),
                            })
                          }
                          className="h-7 w-full rounded border border-gray-300 px-2 text-right text-xs outline-none focus:border-pink-400 focus:ring-1 focus:ring-pink-100"
                        />
                      </td>

                      {/* GRAND */}
                      <td className="border border-gray-200 px-2 py-1 text-right font-bold">
                        {formatCurrency(row.grandSellAmount)}
                      </td>

                      {/* INVESTED */}
                      <td className="border border-gray-200 px-2 py-1">
                        <input
                          type="number"
                          value={row.investedAmount ?? ""}
                          onChange={(e) =>
                            updateRevenueRow(row.orderId, {
                              investedAmount: parseNumberInput(e.target.value),
                            })
                          }
                          className="h-7 w-full rounded border border-gray-300 px-2 text-right text-xs outline-none focus:border-pink-400 focus:ring-1 focus:ring-pink-100"
                        />
                      </td>

                      {/* REVENUE */}
                      <td className="border border-gray-200 px-2 py-1 text-right">
                        <span
                          className={`font-bold ${
                            row.revenue === null
                              ? "text-red-600"
                              : "text-green-700"
                          }`}
                        >
                          {row.revenue === null
                            ? "Pending"
                            : formatCurrency(row.revenue)}
                        </span>
                      </td>

                      {/* NOTE */}
                      <td className="border border-gray-200 px-2 py-1">
                        <input
                          value={row.adminNote ?? ""}
                          onChange={(e) =>
                            updateRevenueRow(row.orderId, {
                              adminNote: e.target.value || null,
                            })
                          }
                          className="h-7 w-full rounded border border-gray-300 px-2 text-xs outline-none focus:border-pink-400 focus:ring-1 focus:ring-pink-100"
                        />
                      </td>

                      {/* ACTION */}
                      <td className="border border-gray-200 px-2 py-1 text-center">
                        <button
                          disabled={saving}
                          onClick={() => void saveRevenue(row)}
                          className="rounded bg-pink-600 px-2 py-1 text-[11px] text-white hover:bg-pink-700 disabled:opacity-50"
                        >
                          {saving ? "..." : "Save"}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

                          <div className="border-t border-gray-100 bg-gray-50/70 p-3 sm:p-4 lg:p-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  Export Visible Revenue Rows
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Only currently visible table rows will be downloaded as Excel
                  supported CSV.
                </p>
              </div>

              <Button
                type="button"
                onClick={handleExportVisibleRevenueRows}
                disabled={visibleRevenueRows.length === 0}
                className="h-11 rounded-xl bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
              >
                <Download className="mr-2 h-4 w-4" />
                Download CSV
              </Button>
            </div>
          </div>

        </Card>

        <div className="mb-8 grid gap-6 lg:grid-cols-3">
          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg transition-all hover:shadow-xl sm:p-5 lg:col-span-2 lg:p-6">
            <div className="mb-5 flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Revenue Overview
                </h3>
                <p className="text-sm text-gray-500">
                  Daily performance with order volume
                </p>
              </div>

              <div className="flex w-full flex-col gap-3 xl:w-auto xl:items-end">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex rounded-xl bg-gray-100 p-1">
                    <button
                      onClick={() => setShowChartType("line")}
                      className={`rounded-lg p-2 transition-all ${
                        showChartType === "line"
                          ? "bg-white shadow-sm"
                          : "text-gray-500"
                      }`}
                    >
                      <LineChartIcon className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setShowChartType("bar")}
                      className={`rounded-lg p-2 transition-all ${
                        showChartType === "bar"
                          ? "bg-white shadow-sm"
                          : "text-gray-500"
                      }`}
                    >
                      <BarChart3 className="h-4 w-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => setShowValues(!showValues)}
                    className="rounded-xl bg-gray-100 p-2 text-gray-600 transition-colors hover:bg-gray-200"
                  >
                    {showValues ? (
                      <Eye className="h-4 w-4" />
                    ) : (
                      <EyeOff className="h-4 w-4" />
                    )}
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {(["7", "14", "30"] as const).map((range) => (
                    <button
                      key={range}
                      onClick={() => setTimeRange(range)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                        timeRange === range
                          ? "bg-gray-900 text-white shadow-lg"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {range}d
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="h-70 min-w-0 sm:h-85 lg:h-90">
              <ResponsiveContainer width="100%" height="100%">
                {showChartType === "line" ? (
                  <ComposedChart
                    data={daily}
                    margin={{ top: 8, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="revenueGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#10b981"
                          stopOpacity={0.2}
                        />
                        <stop
                          offset="95%"
                          stopColor="#10b981"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="ordersGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#6366f1"
                          stopOpacity={0.2}
                        />
                        <stop
                          offset="95%"
                          stopColor="#6366f1"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>

                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />

                    <XAxis
                      dataKey="day"
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      minTickGap={18}
                    />

                    <YAxis
                      yAxisId="revenue"
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      width={50}
                      tickFormatter={(value) => `৳${Math.round(value / 1000)}k`}
                    />

                    <YAxis
                      yAxisId="orders"
                      orientation="right"
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      width={36}
                    />

                    <Tooltip content={<CustomTooltip />} />

                    <Legend
                      wrapperStyle={{
                        fontSize: "12px",
                        paddingTop: "8px",
                      }}
                    />

                    <Area
                      yAxisId="revenue"
                      type="monotone"
                      dataKey="revenue"
                      name="Revenue"
                      stroke="#10b981"
                      strokeWidth={2}
                      fill="url(#revenueGradient)"
                    />

                    <Area
                      yAxisId="orders"
                      type="monotone"
                      dataKey="orders"
                      name="Orders"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fill="url(#ordersGradient)"
                    />
                  </ComposedChart>
                ) : (
                  <BarChart
                    data={daily}
                    margin={{ top: 8, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="barRevenue"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop offset="0%" stopColor="#10b981" stopOpacity={1} />
                        <stop
                          offset="100%"
                          stopColor="#059669"
                          stopOpacity={1}
                        />
                      </linearGradient>
                    </defs>

                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />

                    <XAxis
                      dataKey="day"
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={{ stroke: "#e5e7eb" }}
                      minTickGap={18}
                    />

                    <YAxis
                      hide={!showValues}
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      tickLine={false}
                      axisLine={{ stroke: "#e5e7eb" }}
                      width={50}
                      tickFormatter={(value) => `৳${Math.round(value / 1000)}k`}
                    />

                    <Tooltip content={<CustomTooltip />} />

                    <Bar
                      dataKey="revenue"
                      name="Revenue"
                      fill="url(#barRevenue)"
                      radius={[8, 8, 0, 0]}
                    />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg transition-all hover:shadow-xl sm:p-5 lg:p-6">
            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-900">
                Monthly Distribution
              </h3>
              <p className="text-sm text-gray-500">Revenue by month</p>
            </div>

            <div className="h-60 min-w-0 sm:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data?.monthly ?? []}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={65}
                    paddingAngle={4}
                    dataKey="revenue"
                  >
                    {(data?.monthly ?? []).map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={pieColors[index % pieColors.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {(data?.monthly ?? []).slice(0, 4).map((item, idx) => (
                <div
                  key={idx}
                  className="flex min-w-0 items-center gap-2 rounded-xl bg-gray-50 px-3 py-2"
                >
                  <div
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{
                      backgroundColor: pieColors[idx % pieColors.length],
                    }}
                  />
                  <span className="truncate text-xs text-gray-600">
                    {item.month}
                  </span>
                  <span className="ml-auto shrink-0 text-xs font-semibold">
                    {formatCurrency(item.revenue)}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg sm:p-5 lg:col-span-2 lg:p-6">
            <div className="mb-6 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Best Selling Products
                </h3>
                <p className="text-sm text-gray-500">
                  Top performers by quantity sold
                </p>
              </div>
            </div>

            <div className="mb-4 space-y-3">
              {(data?.bestSelling30 ?? []).map((item, idx) => (
                <Link
                  key={item.productId}
                  href={`/products/${item.slug}`}
                  className="group block"
                >
                  <div className="rounded-xl bg-gray-50 p-3 transition-all group-hover:bg-linear-to-r group-hover:from-gray-50 group-hover:to-blue-50/30 sm:p-4">
                    <div className="flex items-start gap-3 sm:gap-4">
                      <div
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-bold
                        ${
                          idx === 0
                            ? "bg-linear-to-br from-yellow-400 to-yellow-500 text-white"
                            : idx === 1
                              ? "bg-linear-to-br from-gray-400 to-gray-500 text-white"
                              : idx === 2
                                ? "bg-linear-to-br from-orange-400 to-orange-500 text-white"
                                : "bg-gray-200 text-gray-600"
                        }`}
                      >
                        {idx === 0 ? (
                          <Zap className="h-5 w-5" />
                        ) : idx === 1 ? (
                          <Award className="h-5 w-5" />
                        ) : idx === 2 ? (
                          <Star className="h-5 w-5" />
                        ) : (
                          `#${idx + 1}`
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
                          <p className="truncate font-semibold text-gray-900">
                            {item.name}
                          </p>
                          <p className="shrink-0 text-sm font-semibold text-green-600">
                            {formatCurrency(item.revenue)}
                          </p>
                        </div>

                        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                          <p className="text-xs text-gray-500">
                            Quantity: {item.qty}
                          </p>
                          <p className="text-xs text-gray-500">
                            Avg:{" "}
                            {formatCurrency(
                              Math.round(item.revenue / Math.max(1, item.qty)),
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}

              {(data?.bestSelling30 ?? []).length === 0 && (
                <div className="py-12 text-center text-gray-500">
                  No sales data available
                </div>
              )}
            </div>

            <Link
              href="/admin/orders"
              className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-700"
            >
              View All
              <ArrowUpRight className="ml-1 h-4 w-4" />
            </Link>
          </Card>

          <Card className="min-w-0 rounded-2xl border-0 bg-white p-4 shadow-lg sm:p-5 lg:p-6">
            <div className="mb-6 flex items-center gap-3">
              <div className="rounded-xl bg-linear-to-br from-gray-900 to-gray-700 p-2">
                <DownloadCloud className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <h3 className="text-lg font-semibold text-gray-900">
                  Export Data
                </h3>
                <p className="text-sm text-gray-500">Download orders as CSV</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Date Range
                </label>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
                  <input
                    value={csvFrom}
                    onChange={(e) => setCsvFrom(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-gray-200 px-4 transition-colors focus:border-gray-400 focus:ring-0"
                    placeholder="From"
                  />
                  <input
                    value={csvTo}
                    onChange={(e) => setCsvTo(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-gray-200 px-4 transition-colors focus:border-gray-400 focus:ring-0"
                    placeholder="To"
                  />
                </div>
              </div>

              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Order Status
                </label>
                <select
                  value={csvStatus}
                  onChange={(e) => setCsvStatus(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-gray-200 bg-white px-4 transition-colors focus:border-gray-400 focus:ring-0"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E")`,
                    backgroundPosition: "right 1rem center",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "1.5em 1.5em",
                    paddingRight: "2.5rem",
                  }}
                >
                  <option value="">All Statuses</option>
                  <option value="PENDING">Pending</option>
                  <option value="PROCESSING">Processing</option>
                  <option value="SHIPPED">Shipped</option>
                  <option value="DELIVERED">Delivered</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-xs font-medium text-gray-500">
                  Payment Status
                </label>
                <select
                  value={csvPaymentStatus}
                  onChange={(e) => setCsvPaymentStatus(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-gray-200 bg-white px-4 transition-colors focus:border-gray-400 focus:ring-0"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E")`,
                    backgroundPosition: "right 1rem center",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "1.5em 1.5em",
                    paddingRight: "2.5rem",
                  }}
                >
                  <option value="">All Payment Status</option>
                  <option value="UNPAID">Unpaid</option>
                  <option value="PAID">Paid</option>
                  <option value="FAILED">Failed</option>
                  <option value="REFUNDED">Refunded</option>
                </select>
              </div>

              <div className="rounded-xl border border-gray-100 bg-gray-50 p-3 text-xs text-gray-600">
                Export columns:
                <div className="mt-2 flex flex-wrap gap-2">
                  {[
                    "Status",
                    "Serial Number",
                    "Order Date",
                    "Steadfast ID",
                    "Payment Status",
                    "LOT",
                    "Order Price",
                    "Mobile",
                    "Name",
                    "Address",
                    "Products",
                    "Notes",
                  ].map((label) => (
                    <span
                      key={label}
                      className="rounded-full bg-white px-2.5 py-1 text-[11px] text-gray-700 shadow-sm"
                    >
                      {label}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 sm:pt-4">
                <Button
                  onClick={handleExportOrders}
                  className="h-12 w-full rounded-xl bg-linear-to-r from-gray-900 to-gray-800 text-white shadow-lg transition-all hover:from-gray-800 hover:to-gray-700 hover:shadow-xl"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export Orders
                </Button>
              </div>
            </div>

            <div className="mt-6 border-t border-gray-100 pt-6">
              <h4 className="mb-3 text-sm font-semibold text-gray-900">
                Quick Stats
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <Clock className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Avg. Processing
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-gray-900">
                    2.4 hours
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <Package className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Pending Orders
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-gray-900">
                    8
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <TrendingUp className="h-4 w-4 shrink-0 text-gray-400" />
                    <span className="truncate text-sm text-gray-600">
                      Growth Rate
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-green-600">
                    +12.5%
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {loading ? (
          <div className="mt-6 text-sm text-gray-500">
            Loading report data...
          </div>
        ) : null}
      </div>
    </div>
  );
}
