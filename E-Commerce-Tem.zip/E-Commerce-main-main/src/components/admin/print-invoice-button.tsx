"use client";

export default function PrintInvoiceButton() {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="inline-flex h-11 items-center justify-center rounded-2xl bg-black px-6 text-sm font-medium text-white hover:bg-black/90 transition"
    >
      Print Invoice
    </button>
  );
}