"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Search, X } from "lucide-react";

type SuggestionItem = {
  id: string;
  label: string;
  sublabel?: string;
  href: string;
  type: "product" | "category" | "page";
  image?: string | null;
};

type SuggestResponse = {
  query: string;
  items: SuggestionItem[];
};

function useDebouncedValue<T>(value: T, delay = 250): T {
  const [debounced, setDebounced] = React.useState(value);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);

  return debounced;
}

export default function HeaderSearch({
  className = "",
}: {
  className?: string;
}) {
  const router = useRouter();

  const [query, setQuery] = React.useState("");
  const [items, setItems] = React.useState<SuggestionItem[]>([]);
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [activeIndex, setActiveIndex] = React.useState<number>(-1);
  const [hasInteracted, setHasInteracted] = React.useState(false);

  const rootRef = React.useRef<HTMLDivElement | null>(null);
  const inputRef = React.useRef<HTMLInputElement | null>(null);

  const debouncedQuery = useDebouncedValue(query, 250);

  React.useEffect(() => {
    const onClickOutside = (event: MouseEvent) => {
      if (!rootRef.current) return;
      if (!rootRef.current.contains(event.target as Node)) {
        setOpen(false);
        setActiveIndex(-1);
      }
    };

    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  React.useEffect(() => {
    if (!hasInteracted || !open) return;

    const load = async () => {
      setLoading(true);
      try {
        const res = await fetch(
          `/api/search/suggest?q=${encodeURIComponent(debouncedQuery)}`,
          { cache: "no-store" },
        );

        const json: SuggestResponse = await res.json().catch(() => ({
          query: debouncedQuery,
          items: [],
        }));

        setItems(Array.isArray(json.items) ? json.items : []);
        setActiveIndex(-1);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [debouncedQuery, hasInteracted, open]);

  const submitSearch = React.useCallback(() => {
    const q = query.trim();
    router.push(q ? `/products?q=${encodeURIComponent(q)}` : "/products");
    setOpen(false);
    setActiveIndex(-1);
    inputRef.current?.blur();
  }, [query, router]);

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      setHasInteracted(true);
      setOpen(true);
      return;
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((prev) => Math.min(prev + 1, items.length - 1));
      return;
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((prev) => Math.max(prev - 1, -1));
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();

      if (activeIndex >= 0 && items[activeIndex]) {
        router.push(items[activeIndex].href);
        setOpen(false);
        setActiveIndex(-1);
        inputRef.current?.blur();
        return;
      }

      submitSearch();
      return;
    }

    if (e.key === "Escape") {
      setOpen(false);
      setActiveIndex(-1);
    }
  };

  return (
    <div ref={rootRef} className={`relative w-full ${className}`}>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/40" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setHasInteracted(true);
            setOpen(true);
          }}
          onFocus={() => {
            setHasInteracted(true);
            setOpen(true);
          }}
          onKeyDown={onKeyDown}
          placeholder="Search products, categories..."
          className="h-11 w-full rounded-2xl border border-black/10 bg-white pl-10 pr-11 text-sm outline-none transition focus:border-black/30"
        />

        {query ? (
          <button
            type="button"
            onClick={() => {
              setQuery("");
              setHasInteracted(true);
              setOpen(true);
              inputRef.current?.focus();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-black/40 hover:text-black/70"
          >
            <X className="h-4 w-4" />
          </button>
        ) : null}
      </div>

      {open && hasInteracted ? (
        <div className="absolute left-0 right-0 top-[calc(100%+8px)] z-120 overflow-hidden rounded-2xl border border-black/10 bg-white shadow-xl">
          <div className="border-b border-black/5 px-4 py-3 text-xs text-black/50">
            {loading
              ? "Searching..."
              : query.trim()
                ? `Suggestions for "${query.trim()}"`
                : "Popular shortcuts"}
          </div>

          <div className="max-h-105 overflow-auto">
            {items.length ? (
              <>
                {items.map((item, index) => {
                  const active = activeIndex === index;

                  return (
                    <Link
                      key={item.id}
                      href={item.href}
                      onClick={() => {
                        setOpen(false);
                        setActiveIndex(-1);
                      }}
                      className={`flex items-center gap-3 px-4 py-3 transition ${active ? "bg-black/5" : "hover:bg-black/5"
                        }`}
                    >
                      <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl bg-black/5">
                        {item.image ? (
                          <Image
                            src={item.image}
                            alt={item.label}
                            fill
                            className="object-cover"
                            sizes="48px"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-[10px] uppercase text-black/40">
                            {item.type}
                          </div>
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium">
                          {item.label}
                        </div>
                        {item.sublabel ? (
                          <div className="truncate text-xs text-black/55">
                            {item.sublabel}
                          </div>
                        ) : null}
                      </div>

                      <div className="shrink-0 text-[10px] uppercase tracking-wide text-black/35">
                        {item.type}
                      </div>
                    </Link>
                  );
                })}

                {query.trim() ? (
                  <button
                    type="button"
                    onClick={submitSearch}
                    className="w-full border-t border-black/5 px-4 py-3 text-left text-sm font-medium hover:bg-black/5"
                  >
                    Search all results for “{query.trim()}”
                  </button>
                ) : null}
              </>
            ) : (
              <div className="px-4 py-6 text-sm text-black/55">
                No suggestions found.
              </div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
