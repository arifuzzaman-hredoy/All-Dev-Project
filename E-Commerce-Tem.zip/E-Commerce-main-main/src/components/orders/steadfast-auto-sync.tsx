"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

type Props = {
  orderId: string;
  admin?: boolean;
  enabled?: boolean;
  intervalMs?: number;
};

export default function SteadfastAutoSync({
  orderId,
  admin = false,
  enabled = true,
  intervalMs = 30000,
}: Props) {
  const router = useRouter();

  useEffect(() => {
    if (!enabled || !orderId) return;

    let alive = true;

    async function sync() {
      try {
        const url = admin
          ? `/api/admin/orders/${orderId}/steadfast-sync`
          : `/api/orders/${orderId}/steadfast-sync`;

        const res = await fetch(url, {
          method: "POST",
          cache: "no-store",
        });

        if (res.ok && alive) {
          router.refresh();
        }
      } catch {
        // silent fail
      }
    }

    void sync();

    const timer = window.setInterval(() => {
      void sync();
    }, intervalMs);

    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, [admin, enabled, intervalMs, orderId, router]);

  return null;
}
