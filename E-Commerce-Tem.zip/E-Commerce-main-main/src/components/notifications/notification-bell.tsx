"use client";

import Link from "next/link";
import * as React from "react";
import { Bell } from "lucide-react";
import { useSession } from "next-auth/react";

type NotificationItem = {
  id: string;
  title: string;
  message: string;
  linkUrl: string | null;
  isRead: boolean;
  createdAt: string;
};

type NotificationResponse = {
  items: NotificationItem[];
  unreadCount: number;
};

function formatTime(value: string) {
  const d = new Date(value);
  return d.toLocaleString();
}

export default function NotificationBell() {
  const { status } = useSession();
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [items, setItems] = React.useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = React.useState(0);

  const load = React.useCallback(async () => {
    if (status !== "authenticated") return;

    setLoading(true);
    try {
      const res = await fetch("/api/notifications", { cache: "no-store" });
      const json = (await res
        .json()
        .catch(() => null)) as NotificationResponse | null;

      setItems(Array.isArray(json?.items) ? json!.items : []);
      setUnreadCount(
        typeof json?.unreadCount === "number" ? json.unreadCount : 0,
      );
    } finally {
      setLoading(false);
    }
  }, [status]);

  React.useEffect(() => {
    void load();
    if (status !== "authenticated") return;

    const timer = window.setInterval(() => {
      void load();
    }, 20000);

    return () => window.clearInterval(timer);
  }, [load, status]);

  if (status !== "authenticated") return null;

  const markOneRead = async (id: string) => {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });

    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isRead: true } : item)),
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
  };

  const markAllRead = async () => {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markAll: true }),
    });

    setItems((prev) => prev.map((item) => ({ ...item, isRead: true })));
    setUnreadCount(0);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          setOpen((prev) => !prev);
          if (!open) void load();
        }}
        className="relative rounded-xl p-2 text-gray-700 transition-colors hover:bg-pink-50"
        aria-label="Notifications"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 ? (
          <span className="absolute -right-1 -top-1 rounded-full bg-pink-600 px-1.5 py-0.5 text-[10px] font-semibold text-white">
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        ) : null}
      </button>

      {open ? (
        <div className="fixed left-1/2 top-16 z-50 w-[calc(100vw-1rem)] max-w-sm -translate-x-1/2 overflow-hidden rounded-2xl border border-black/10 bg-white shadow-xl sm:absolute sm:left-auto sm:right-0 sm:top-12 sm:w-90 sm:max-w-[90vw] sm:translate-x-0">
          <div className="flex items-center justify-between border-b border-black/10 px-4 py-3">
            <div>
              <div className="text-sm font-semibold">Notifications</div>
              <div className="text-xs text-black/50">Latest updates</div>
            </div>

            {unreadCount > 0 ? (
              <button
                onClick={() => void markAllRead()}
                className="text-xs font-medium text-pink-600 hover:text-pink-700"
              >
                Mark all read
              </button>
            ) : null}
          </div>

          <div className="max-h-105 overflow-y-auto">
            {loading ? (
              <div className="px-4 py-4 text-sm text-black/50">Loading...</div>
            ) : items.length === 0 ? (
              <div className="px-4 py-6 text-sm text-black/50">
                No notifications yet.
              </div>
            ) : (
              items.map((item) => {
                const content = (
                  <div
                    className={`border-b border-black/5 px-4 py-3 transition hover:bg-pink-50/40 ${
                      item.isRead ? "bg-white" : "bg-pink-50/30"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-black">
                          {item.title}
                        </div>
                        <div className="mt-1 text-xs leading-5 text-black/65">
                          {item.message}
                        </div>
                        <div className="mt-1 text-[11px] text-black/40">
                          {formatTime(item.createdAt)}
                        </div>
                      </div>
                      {!item.isRead ? (
                        <span className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-pink-600" />
                      ) : null}
                    </div>
                  </div>
                );

                if (item.linkUrl) {
                  return (
                    <Link
                      key={item.id}
                      href={item.linkUrl}
                      onClick={() => {
                        void markOneRead(item.id);
                        setOpen(false);
                      }}
                    >
                      {content}
                    </Link>
                  );
                }

                return (
                  <button
                    key={item.id}
                    type="button"
                    className="block w-full text-left"
                    onClick={() => void markOneRead(item.id)}
                  >
                    {content}
                  </button>
                );
              })
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
