"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSession, signOut } from "next-auth/react";
import {
  Heart,
  User2,
  LayoutDashboard,
  Menu,
  X,
  Package2,
  ShoppingBag,
  Info,
  Star,
  ChevronDown,
  ChevronRight,
  LogOut,
  Languages,
} from "lucide-react";

import { cn } from "@/lib/cn";
import CartBadge from "../shop/cart-badge";
import HeaderSearch from "../search/header-search";
import NotificationBell from "@/components/notifications/notification-bell";
import {
  buildCategoryTree,
  type CategoryTreeItem,
  type CategoryTreeNode,
} from "@/lib/category-tree";

const desktopNavItems = [
  { name: "Products", href: "/products", icon: Package2 },
  { name: "Reviews", href: "/reviews", icon: Star },
  { name: "Orders", href: "/orders", icon: ShoppingBag },
  { name: "About Us", href: "/about-us", icon: Info },
];

type Branding = {
  storeName: string;
  logoUrl: string;
};

type PublicCategory = CategoryTreeItem;

const GOOGLE_TRANSLATE_CONTAINER_ID = "google_translate_element";

type GoogleTranslateElementConstructor = new (
  options: {
    pageLanguage: string;
    includedLanguages: string;
    autoDisplay: boolean;
  },
  elementId: string,
) => void;

declare global {
  interface Window {
    googleTranslateElementInit?: () => void;
    google?: {
      translate?: {
        TranslateElement?: GoogleTranslateElementConstructor;
      };
    };
  }
}

let googleTranslateScriptPromise: Promise<void> | null = null;

function waitForTranslateSelect(): Promise<HTMLSelectElement | null> {
  return new Promise((resolve) => {
    let attempts = 0;

    const findSelect = () => {
      const select =
        document.querySelector<HTMLSelectElement>(".goog-te-combo");

      if (select || attempts >= 30) {
        resolve(select);
        return;
      }

      attempts += 1;
      window.setTimeout(findSelect, 100);
    };

    findSelect();
  });
}

function loadGoogleTranslateScript(): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve();

  if (document.querySelector(".goog-te-combo")) {
    return Promise.resolve();
  }

  if (googleTranslateScriptPromise) {
    return googleTranslateScriptPromise;
  }

  googleTranslateScriptPromise = new Promise((resolve, reject) => {
    const initialize = () => {
      const TranslateElement = window.google?.translate?.TranslateElement;
      const container = document.getElementById(GOOGLE_TRANSLATE_CONTAINER_ID);

      if (!TranslateElement || !container) {
        reject(new Error("Google Translate did not initialize."));
        return;
      }

      new TranslateElement(
        {
          pageLanguage: "auto",
          includedLanguages: "bn,en",
          autoDisplay: false,
        },
        GOOGLE_TRANSLATE_CONTAINER_ID,
      );

      window.setTimeout(resolve, 300);
    };

    window.googleTranslateElementInit = initialize;

    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[data-google-translate="true"]',
    );

    if (existingScript) {
      if (window.google?.translate?.TranslateElement) initialize();
      else existingScript.addEventListener("load", initialize, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src =
      "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    script.async = true;
    script.dataset.googleTranslate = "true";
    script.onerror = () =>
      reject(new Error("Could not load Google Translate script."));

    document.body.appendChild(script);
  });

  return googleTranslateScriptPromise;
}

export function Header() {
  const pathname = usePathname();
  const { data, status } = useSession();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isFixedHeader, setIsFixedHeader] = useState(false);
  const [branding, setBranding] = useState<Branding>({
    storeName: "NexoraMart",
    logoUrl: "/nexoramart-logo.svg",
  });
  const [categories, setCategories] = useState<PublicCategory[]>([]);
  const [expandedParents, setExpandedParents] = useState<
    Record<string, boolean>
  >({});

  const mobileMenuRef = useRef<HTMLDivElement | null>(null);
  const mobileMenuButtonRef = useRef<HTMLButtonElement | null>(null);

  const isAdmin = data?.user?.role === "ADMIN" || data?.user?.role === "STAFF";
  const isLoggedIn = status === "authenticated";

  const categoryTree = useMemo(
    () => buildCategoryTree(categories),
    [categories],
  );

  const defaultExpandedParents = useMemo(() => {
    const result: Record<string, boolean> = {};
    for (const parent of categoryTree) {
      result[parent.id] = false;
    }
    return result;
  }, [categoryTree]);

  const resolvedExpandedParents = useMemo(() => {
    return { ...defaultExpandedParents, ...expandedParents };
  }, [defaultExpandedParents, expandedParents]);

  useEffect(() => {
    const handleScroll = () => {
      setIsFixedHeader(window.scrollY >= 200);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (!mobileMenuOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (!target) return;

      if (mobileMenuRef.current?.contains(target)) return;
      if (mobileMenuButtonRef.current?.contains(target)) return;

      setMobileMenuOpen(false);
    };

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("pointerdown", handlePointerDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [mobileMenuOpen]);

  useEffect(() => {
    let alive = true;

    const loadBranding = async () => {
      try {
        const res = await fetch("/api/store/settings/public", {
          cache: "no-store",
        });

        const json = await res.json().catch(() => null);

        if (!alive || !res.ok) return;

        setBranding({
          storeName:
            typeof json?.storeName === "string" && json.storeName.trim()
              ? json.storeName
              : "NexoraMart",
          logoUrl:
            typeof json?.logoUrl === "string" && json.logoUrl.trim()
              ? json.logoUrl : "/nexoramart-logo.svg",
        });
      } catch {
        // noop
      }
    };

    const loadCategories = async () => {
      try {
        const res = await fetch("/api/admin/categories", {
          cache: "no-store",
        });

        const json = (await res.json().catch(() => [])) as Array<
          Record<string, unknown>
        >;

        if (!alive || !res.ok || !Array.isArray(json)) return;

        const normalized = json
          .map((item) => ({
            id: typeof item.id === "string" ? item.id : "",
            name: typeof item.name === "string" ? item.name : "",
            slug: typeof item.slug === "string" ? item.slug : "",
            parentId:
              typeof item.parentId === "string" && item.parentId.trim()
                ? item.parentId
                : null,
            isActive: item.isActive !== false,
          }))
          .filter((item) => item.id && item.name && item.slug && item.isActive);

        setCategories(normalized);
      } catch {
        // noop
      }
    };

    void Promise.all([loadBranding(), loadCategories()]);

    return () => {
      alive = false;
    };
  }, []);

  const toggleParent = (parentId: string) => {
    setExpandedParents((prev) => ({
      ...prev,
      [parentId]: !(resolvedExpandedParents[parentId] ?? false),
    }));
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const translateCurrentPageToBangla = async () => {
    try {
      await loadGoogleTranslateScript();

      const select = await waitForTranslateSelect();
      if (!select) return;

      select.value = "bn";
      select.dispatchEvent(new Event("change", { bubbles: true }));
    } catch {
      // Google Translate can be blocked by browser/privacy extensions.
    }
  };

  const isLinkActive = (href: string) =>
    pathname === href || pathname.startsWith(`${href}/`);

  const mobilePrimaryLinks = [
    { name: "Products", href: "/products", icon: Package2 },
    { name: "Reviews", href: "/reviews", icon: Star },
    { name: "Orders", href: "/orders", icon: ShoppingBag },
    ...(isAdmin
      ? [{ name: "Admin", href: "/admin", icon: LayoutDashboard }]
      : []),
  ];

  const renderMobileCategoryNode = (parent: CategoryTreeNode) => {
    const hasChildren = parent.children.length > 0;
    const isExpanded = resolvedExpandedParents[parent.id] ?? false;

    return (
      <div key={parent.id} className="border-b border-slate-200 bg-white">
        <div className="flex items-center">
          <Link
            href={`/categories/${encodeURIComponent(parent.slug)}`}
            onClick={closeMobileMenu}
            className="flex min-w-0 flex-1 items-center px-5 py-4 text-[15px] font-medium text-slate-800"
          >
            <span className="truncate">{parent.name}</span>
          </Link>

          {hasChildren ? (
            <button
              type="button"
              onClick={() => toggleParent(parent.id)}
              className="flex h-12 w-12 items-center justify-center text-slate-600"
              aria-label={isExpanded ? "Collapse category" : "Expand category"}
            >
              {isExpanded ? (
                <ChevronDown className="h-5 w-5" />
              ) : (
                <ChevronRight className="h-5 w-5" />
              )}
            </button>
          ) : null}
        </div>

        {hasChildren && isExpanded ? (
          <div className="border-t border-slate-100 bg-slate-50">
            {parent.children.map((child) => (
              <Link
                key={child.id}
                href={`/categories/${encodeURIComponent(child.slug)}`}
                onClick={closeMobileMenu}
                className="flex items-center px-8 py-3.5 text-[14px] text-slate-700 transition hover:bg-white"
              >
                <span className="truncate">{child.name}</span>
              </Link>
            ))}
          </div>
        ) : null}
      </div>
    );
  };

  return (
    <>
      <div
        id={GOOGLE_TRANSLATE_CONTAINER_ID}
        aria-hidden="true"
        className="pointer-events-none absolute h-0 w-0 overflow-hidden opacity-0"
      />

      <header
        className={cn(
          "z-40 w-full overflow-visible border-black/10 bg-linear-to-r from-white via-pink-50 to-white/90 backdrop-blur-md transition-all duration-300",
          isFixedHeader
            ? "fixed inset-x-0 top-0 border shadow-[0_20px_50px_-24px_rgba(15,23,42,0.35)]"
            : "relative rounded-b-2xl border-x-0 border-t-0 border-b shadow-lg",
        )}
      >
        <div className="mx-auto max-w-6xl px-4">
          <div className="flex min-h-18 items-center gap-3">
            <Link href="/" className="group flex shrink-0 items-center gap-3">
              {branding.logoUrl ? (
                <div className="relative h-16 w-16 shrink-0 transition-transform group-hover:scale-105 sm:h-18 sm:w-18">
                  <Image
                    src={branding.logoUrl}
                    alt={`${branding.storeName} logo`}
                    fill
                    sizes="72px"
                    className="object-contain"
                    priority
                  />
                </div>
              ) : (
                <span className="text-base font-semibold tracking-wide text-slate-900">
                  {branding.storeName}
                </span>
              )}
            </Link>

            <div className="flex-1">
              <HeaderSearch />
            </div>

            <nav className="ml-auto hidden items-center gap-1 md:flex">
              {desktopNavItems.map((item) => {
                const active =
                  pathname === item.href ||
                  pathname.startsWith(item.href + "/");
                const Icon = item.icon;

                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition-all duration-150",
                      active
                        ? "bg-pink-600 text-white shadow-md scale-105"
                        : "text-gray-700 hover:bg-pink-50 hover:text-pink-700 hover:scale-105",
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {item.name}
                  </Link>
                );
              })}

              {isAdmin ? (
                <Link
                  href="/admin"
                  className={cn(
                    "ml-1 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition-all duration-150",
                    pathname.startsWith("/admin")
                      ? "bg-pink-600 text-white shadow-md scale-105"
                      : "text-gray-700 hover:bg-pink-50 hover:text-pink-700 hover:scale-105",
                  )}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  Admin
                </Link>
              ) : null}

              <button
                type="button"
                onClick={translateCurrentPageToBangla}
                className="inline-flex items-center gap-2 rounded-xl bg-[#fff1f5] px-3 py-2 text-sm font-medium text-pink-700 ring-1 ring-pink-200 transition-all hover:bg-pink-600 hover:text-white"
                aria-label="Translate this page to Bangla"
                title="Translate to Bangla"
              >
                <Languages className="h-4 w-4" />
                বাংলা
              </button>

              <Link
                className="rounded-xl p-2 text-gray-700 transition-colors hover:bg-pink-50"
                href="/wishlist"
                aria-label="Wishlist"
              >
                <Heart className="h-5 w-5" />
              </Link>

              <NotificationBell />

              <CartBadge />

              {isLoggedIn ? (
                <button
                  onClick={() => signOut({ callbackUrl: "/" })}
                  className="rounded-xl px-3 py-2 text-sm font-medium text-gray-700 transition-all hover:bg-pink-50"
                  aria-label="Logout"
                >
                  Logout
                </button>
              ) : (
                <Link
                  className="rounded-xl p-2 text-gray-700 transition-colors hover:bg-pink-50"
                  href="/login"
                  aria-label="Login"
                >
                  <User2 className="h-5 w-5" />
                </Link>
              )}
            </nav>

            <div className="ml-auto flex items-center gap-1 md:hidden">
              <NotificationBell />

              <button
                type="button"
                onClick={translateCurrentPageToBangla}
                className="rounded-xl p-2 text-pink-700 transition-colors hover:bg-pink-100"
                aria-label="Translate this page to Bangla"
                title="Translate to Bangla"
              >
                <Languages className="h-5 w-5" />
              </button>

              <button
                ref={mobileMenuButtonRef}
                type="button"
                onClick={() => setMobileMenuOpen((prev) => !prev)}
                className="rounded-xl p-2 text-pink-700 transition-colors hover:bg-pink-100"
                aria-label="Toggle menu"
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div
        className={cn(
          "fixed inset-0 z-80 bg-black/35 transition-opacity duration-300 md:hidden",
          mobileMenuOpen
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0",
        )}
        aria-hidden={!mobileMenuOpen}
      >
        <div
          ref={mobileMenuRef}
          className={cn(
            "absolute left-0 top-0 flex h-full w-[86vw] max-w-97.5 flex-col bg-white shadow-[0_18px_50px_rgba(15,23,42,0.22)] transition-transform duration-300 ease-out",
            mobileMenuOpen ? "translate-x-0" : "-translate-x-full",
          )}
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation"
        >
          <div className="shrink-0 border-b border-slate-200 bg-white">
            <div className="flex items-center justify-between px-4 py-4">
              <Link
                href="/"
                onClick={closeMobileMenu}
                className="flex min-w-0 items-center gap-3"
              >
                {branding.logoUrl ? (
                  <div className="relative h-12 w-28 shrink-0">
                    <Image
                      src={branding.logoUrl}
                      alt={`${branding.storeName} logo`}
                      fill
                      sizes="112px"
                      className="object-contain object-left"
                    />
                  </div>
                ) : (
                  <div className="text-lg font-semibold text-slate-900">
                    {branding.storeName}
                  </div>
                )}
              </Link>

              <button
                type="button"
                onClick={closeMobileMenu}
                className="flex h-11 w-11 items-center justify-center rounded-full text-slate-700 transition hover:bg-slate-100"
                aria-label="Close menu"
              >
                <X className="h-7 w-7" />
              </button>
            </div>

            <nav className="pb-1">
              {mobilePrimaryLinks.map((item) => {
                const Icon = item.icon;
                const active = isLinkActive(item.href);

                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={closeMobileMenu}
                    className={cn(
                      "flex items-center gap-3 border-t border-slate-100 px-5 py-4 text-[15px] font-medium transition",
                      active
                        ? "bg-sky-50 text-sky-700"
                        : "text-slate-800 hover:bg-slate-50",
                    )}
                  >
                    <Icon className="h-5 w-5 shrink-0" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto bg-[#f8f8f8]">
            <div className="border-b border-slate-200 bg-white px-5 py-3">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
                Categories
              </div>
            </div>

            <div className="pb-4">
              {categoryTree.length ? (
                categoryTree.map((parent) => renderMobileCategoryNode(parent))
              ) : (
                <div className="px-5 py-6 text-sm text-slate-500">
                  No categories found.
                </div>
              )}
            </div>
          </div>

          <div className="shrink-0 border-t border-slate-200 bg-white">
            <button
              type="button"
              onClick={() => {
                closeMobileMenu();
                translateCurrentPageToBangla();
              }}
              className="flex w-full items-center gap-3 border-b border-slate-100 px-5 py-4 text-left text-[15px] font-medium text-slate-800 transition hover:bg-slate-50"
            >
              <Languages className="h-5 w-5 shrink-0" />
              <span>বাংলায় দেখুন</span>
            </button>

            <Link
              href="/wishlist"
              onClick={closeMobileMenu}
              className="flex items-center gap-3 border-b border-slate-100 px-5 py-4 text-[15px] font-medium text-slate-800 transition hover:bg-slate-50"
            >
              <Heart className="h-5 w-5 shrink-0" />
              <span>Wishlist</span>
            </Link>

            {isLoggedIn ? (
              <button
                type="button"
                onClick={() => {
                  closeMobileMenu();
                  void signOut({ callbackUrl: "/" });
                }}
                className="flex w-full items-center gap-3 px-5 py-4 text-left text-[15px] font-medium text-slate-800 transition hover:bg-slate-50"
              >
                <LogOut className="h-5 w-5 shrink-0" />
                <span>Logout</span>
              </button>
            ) : (
              <Link
                href="/login"
                onClick={closeMobileMenu}
                className="flex items-center gap-3 px-5 py-4 text-[15px] font-medium text-slate-800 transition hover:bg-slate-50"
              >
                <User2 className="h-5 w-5 shrink-0" />
                <span>Login</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
