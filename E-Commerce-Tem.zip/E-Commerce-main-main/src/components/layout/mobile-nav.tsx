"use client";

import Link from "next/link";
import {
  Heart,
  Home,
  ShoppingBag,
  Star,
  User2,
  LayoutDashboard,
  type LucideIcon,
} from "lucide-react";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import { useSession } from "next-auth/react";
import CartBadge from "../shop/cart-badge";

type NavItemProps = {
  href: string;
  label: string;
  icon: LucideIcon;
  className?: string;
};

function NavItem({ href, label, icon: Icon, className }: NavItemProps) {
  const pathname = usePathname();
  const active = pathname === href;

  return (
    <Link
      href={href}
      className={cn(
        "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs transition",
        active ? "text-black bg-stone-300" : "text-black/60",
        className
      )}
    >
      <Icon className="h-5 w-5" />
      {label}
    </Link>
  );
}

export function MobileNav() {
  const { data } = useSession();
  const isAdmin = data?.user?.role === "ADMIN" || data?.user?.role === "STAFF";
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-black/10 bg-white/80 backdrop-blur md:hidden">
      <div className="mx-auto flex max-w-6xl px-2">
        <NavItem href="/" label="Home" icon={Home} />
        {isAdmin ? (
          <Link
            href="/admin"
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs transition hover:bg-black/5"
            )}
          >
            <LayoutDashboard className="h-5 w-5" />
            Admin
          </Link>
        ) : null}
        <NavItem href="/wishlist" label="Wishlist" icon={Heart} />
        {/* <CartBadge/> */}
        <NavItem href="/products" label="Products" icon={ShoppingBag} />
        <NavItem href="/cart" className="bg-rose-200" label="Cart" icon={ShoppingBag} />
        <NavItem href="/reviews" label="Reviews" icon={Star} />
        <NavItem href="/login" label="Account" icon={User2} />
      </div>
    </div>
  );
}
