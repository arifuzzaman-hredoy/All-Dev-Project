"use client";

import { useEffect, useRef } from "react";
import Script from "next/script";
import { usePathname, useSearchParams } from "next/navigation";

type MetaPixelCommand = (
  command: "init" | "track",
  eventOrPixelId: string,
  params?: Record<string, unknown>,
) => void;

declare global {
  interface Window {
    fbq?: MetaPixelCommand;
    _fbq?: MetaPixelCommand;
  }
}

const META_PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID;
const hasValidPixelId = Boolean(META_PIXEL_ID && /^\d+$/.test(META_PIXEL_ID));

export function MetaPixel() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const hasMounted = useRef(false);
  const lastTrackedUrl = useRef<string | null>(null);

  useEffect(() => {
    if (!hasValidPixelId) return;

    const query = searchParams.toString();
    const currentUrl = query ? `${pathname}?${query}` : pathname;

    if (!hasMounted.current) {
      hasMounted.current = true;
      lastTrackedUrl.current = currentUrl;
      return;
    }

    if (lastTrackedUrl.current === currentUrl) return;
    lastTrackedUrl.current = currentUrl;

    window.fbq?.("track", "PageView");
  }, [pathname, searchParams]);

  if (!hasValidPixelId) return null;

  return (
    <>
      <Script id="meta-pixel" strategy="afterInteractive">
        {`
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '${META_PIXEL_ID}');
          fbq('track', 'PageView');
        `}
      </Script>

      <noscript
        dangerouslySetInnerHTML={{
          __html: `<img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=${META_PIXEL_ID}&ev=PageView&noscript=1" />`,
        }}
      />
    </>
  );
}
