"use client";

type ZodFlattenLike = {
  formErrors?: string[];
  fieldErrors?: Record<string, string[]>;
};

export function ErrorBox({ error }: { error: unknown }) {
  if (!error) return null;

  // string
  if (typeof error === "string") {
    return (
      <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
        {error}
      </div>
    );
  }

  // object (like zod flatten)
  if (typeof error === "object") {
    const e = error as ZodFlattenLike;

    const formErrors = Array.isArray(e.formErrors) ? e.formErrors : [];
    const fieldErrors =
      e.fieldErrors && typeof e.fieldErrors === "object" ? e.fieldErrors : {};

    // if looks like empty object, show generic message
    const hasAny =
      formErrors.length > 0 || Object.keys(fieldErrors).length > 0;

    return (
      <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700 space-y-2">
        {!hasAny && <div>Something went wrong.</div>}

        {formErrors.length > 0 && (
          <ul className="list-disc pl-5">
            {formErrors.map((m, idx) => (
              <li key={idx}>{m}</li>
            ))}
          </ul>
        )}

        {Object.keys(fieldErrors).length > 0 && (
          <ul className="list-disc pl-5">
            {Object.entries(fieldErrors).flatMap(([field, msgs]) =>
              (msgs ?? []).map((m, idx) => (
                <li key={`${field}-${idx}`}>
                  <b>{field}:</b> {m}
                </li>
              )),
            )}
          </ul>
        )}
      </div>
    );
  }

  // fallback
  return (
    <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
      Something went wrong.
    </div>
  );
}