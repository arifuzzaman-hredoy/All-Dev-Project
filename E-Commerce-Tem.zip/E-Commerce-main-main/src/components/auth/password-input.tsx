"use client";

import * as React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";

type PasswordInputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  inputClassName?: string;
};

export function PasswordInput({ className, inputClassName, ...props }: PasswordInputProps) {
  const [visible, setVisible] = React.useState(false);

  return (
    <div className={cn("relative", className)}>
      <Input
        {...props}
        type={visible ? "text" : "password"}
        className={cn("pr-20", inputClassName)}
      />
      <Button
        type="button"
        variant="ghost"
        className="absolute right-1 top-1/2 h-8 -translate-y-1/2 rounded-lg px-3 text-xs font-semibold text-[#ad1457] hover:bg-[#fce4ec]"
        onClick={() => setVisible((current) => !current)}
        aria-label={visible ? "Hide password" : "Show password"}
      >
        {visible ? "Hide" : "Show"}
      </Button>
    </div>
  );
}
