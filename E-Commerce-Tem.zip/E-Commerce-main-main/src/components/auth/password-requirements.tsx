"use client";

import * as React from "react";
import { cn } from "@/lib/cn";

const requirements = [
  {
    label: "Minimum 6 characters",
    test: (value: string) => value.length >= 6,
  },
  {
    label: "Use at least one letter",
    test: (value: string) => /[a-zA-Z]/.test(value),
  },
  {
    label: "Use at least one number or symbol",
    test: (value: string) => /[0-9\W_]/.test(value),
  },
];

type PasswordRequirementsProps = {
  password: string;
  confirmPassword?: string;
  showMatch?: boolean;
};

export function PasswordRequirements({
  password,
  confirmPassword,
  showMatch = false,
}: PasswordRequirementsProps) {
  const items = React.useMemo(() => {
    const base = requirements.map((item) => ({
      label: item.label,
      valid: item.test(password),
    }));

    if (showMatch) {
      base.push({
        label: "Confirm password must match",
        valid: Boolean(password) && password === confirmPassword,
      });
    }

    return base;
  }, [confirmPassword, password, showMatch]);

  return (
    <div className="rounded-2xl border border-[#f8bbd0] bg-white/70 px-4 py-3 text-xs text-slate-600">
      <p className="mb-2 font-semibold text-slate-700">Password requirements</p>
      <ul className="space-y-1.5">
        {items.map((item) => (
          <li
            key={item.label}
            className={cn(
              "flex items-center gap-2",
              item.valid ? "text-emerald-700" : "text-slate-500",
            )}
          >
            <span
              className={cn(
                "inline-flex h-4 w-4 items-center justify-center rounded-full border text-[10px]",
                item.valid
                  ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                  : "border-slate-300 bg-slate-50 text-slate-400",
              )}
            >
              {item.valid ? "✓" : "•"}
            </span>
            {item.label}
          </li>
        ))}
      </ul>
    </div>
  );
}
