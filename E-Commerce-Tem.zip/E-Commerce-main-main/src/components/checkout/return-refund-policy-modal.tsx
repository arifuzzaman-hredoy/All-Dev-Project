"use client";

type Props = {
  open: boolean;
  onClose: () => void;
  content: string;
};

export default function ReturnRefundPolicyModal({
  open,
  onClose,
  content,
}: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <button
        type="button"
        onClick={onClose}
        className="absolute inset-0 bg-black/50"
        aria-label="Close modal"
      />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-xl">
          <div className="flex items-center justify-between border-b border-black/10 px-5 py-4">
            <div className="text-base font-semibold">
              Return and Refund Policy
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-black/10 px-3 py-2 text-sm hover:bg-black/5"
            >
              Close
            </button>
          </div>

          <div className="max-h-[70vh] overflow-auto px-5 py-4">
            {content.trim() ? (
              <div className="whitespace-pre-line text-sm leading-7 text-black/75">
                {content}
              </div>
            ) : (
              <div className="text-sm text-black/50">
                No return and refund policy added yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
