"use client";

import { useEffect } from "react";
import { clearAppliedCoupon } from "@/lib/coupon-client";

export default function PaymentSuccessCartCleanup() {
  useEffect(() => {
    const run = async () => {
      try {
        await fetch("/api/cart", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "clear" }),
        });
      } catch {
        // Ignore cleanup failures on the result page.
      }

      clearAppliedCoupon();
      window.dispatchEvent(new Event("rhc_cart_updated"));
    };

    void run();
  }, []);

  return null;
}
