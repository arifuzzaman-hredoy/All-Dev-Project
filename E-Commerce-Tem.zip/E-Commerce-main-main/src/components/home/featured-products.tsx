import { ShoppingCart } from "lucide-react";
import HomeProductCard from "@/components/products/home-product-card";

type Product = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  category?: { name: string } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  variants?: Array<{
    id: string;
    stock: number;
  }>;
};

export default function FeaturedProducts({
  products,
}: {
  products: Product[];
}) {
  if (!products?.length) {
    return (
      <div className="rounded-2xl bg-gray-50 p-16 text-center">
        <ShoppingCart className="mx-auto mb-4 h-16 w-16 text-rose-300" />
        <p className="text-lg font-medium text-slate-800">
          No featured products yet.
        </p>
        <p className="mt-2 text-sm text-rose-500/90">
          Admin → Products → mark items as Featured
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-1 md:grid-cols-3 md:gap-2 lg:grid-cols-6">
      {products.map((product) => (
        <HomeProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
