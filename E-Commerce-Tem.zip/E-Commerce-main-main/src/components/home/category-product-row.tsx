import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ShoppingCart, Eye, Star } from "lucide-react";
import { prisma } from "@/lib/prisma";
import CategoryProductSlider from "./category-product-slider";
import { attachEffectivePrices } from "@/lib/product-discounts";
import { getDescendantCategoryIds } from "@/lib/category-tree";

interface Props {
  slug: string;
  title: string;
  colorClass?: string;
}

function getAverageRating(reviews: { rating: number }[]) {
  if (!reviews.length) return 0;
  const total = reviews.reduce((sum, item) => sum + item.rating, 0);
  return total / reviews.length;
}

export default async function CategoryProductRow({
  slug,
  title,
  colorClass = "",
}: Props) {
  const category = await prisma.category.findUnique({
    where: { slug },
    select: {
      id: true,
      name: true,
    },
  });

  if (!category) return null;

  const allActiveCategories = await prisma.category.findMany({
    where: { isActive: true },
    select: {
      id: true,
      parentId: true,
    },
  });

  const categoryIds = getDescendantCategoryIds(
    category.id,
    allActiveCategories,
  );

  const productsRaw = await prisma.product.findMany({
    where: {
      isActive: true,
      OR: [
        {
          categoryId: {
            in: categoryIds,
          },
        },
        {
          categories: {
            some: {
              categoryId: {
                in: categoryIds,
              },
            },
          },
        },
      ],
    },
    orderBy: [{ updatedAt: "desc" }],
    take: 16,
    include: {
      category: {
        include: {
          parent: true,
        },
      },
      images: {
        orderBy: { sortOrder: "asc" },
        take: 1,
      },
      reviews: {
        select: { rating: true },
      },
    },
  });

  const resolvedProducts = await attachEffectivePrices(productsRaw);

  const products = resolvedProducts.map((product) => ({
    ...product,
    ratingAvg: getAverageRating(product.reviews),
    ratingCount: product.reviews.length,
  }));

  if (!products.length) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 pt-12 lg:px-6">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl font-semibold text-gray-900 md:text-3xl">
            {title}
          </h2>
        </div>

        <Link
          href={`/categories/${slug}`}
          className={`group shrink-0 flex items-center gap-2 rounded-sm px-5 py-2.5 text-sm font-medium ring-1 transition-all ${
            colorClass
              ? colorClass
              : "bg-[#fff1f5] text-[#ad1457] ring-[#f8bbd0] hover:bg-[#ffe4ec] hover:text-[#8e1042]"
          }`}
        >
          <span>View all</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>

      <CategoryProductSlider>
        {products.map((product) => {
          const img = product.images?.[0]?.url;
          const finalPrice = product.offerPrice ?? product.price;

          const discount =
            product.offerPrice && product.price > product.offerPrice
              ? Math.round(
                  ((product.price - product.offerPrice) / product.price) * 100,
                )
              : null;

          return (
            <Link
              key={product.id}
              href={`/products/${product.slug}`}
              draggable={false}
              className="group relative block w-30 shrink-0 overflow-hidden rounded-sm bg-white shadow-sm ring-1 ring-black/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg sm:w-40 md:w-48 lg:w-50"
            >
              <div className="pointer-events-none absolute inset-x-4 top-0 h-10 rounded-b-2xl bg-rose-200/30 blur-xl" />

              {discount ? (
                <div className="absolute left-2 top-2 z-20 rounded-full bg-rose-600 px-2 py-0.5 text-[9px] font-semibold text-white shadow-md">
                  -{discount}%
                </div>
              ) : null}

              <div className="absolute right-2 top-2 z-20 flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[9px] font-semibold text-slate-700 shadow backdrop-blur">
                <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                {product.ratingAvg.toFixed(1)}
                <span className="text-[8px] text-slate-500">
                  ({product.ratingCount})
                </span>
              </div>

              <div className="relative aspect-square overflow-hidden bg-rose-50">
                {img ? (
                  <Image
                    src={img}
                    alt={product.name}
                    fill
                    draggable={false}
                    className="pointer-events-none object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 640px) 160px, (max-width: 768px) 192px, (max-width: 1024px) 224px, 240px"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <ShoppingCart className="h-8 w-8 text-rose-300" />
                  </div>
                )}

                <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <div className="rounded-full bg-white p-2 shadow-lg">
                    <Eye className="h-4 w-4 text-rose-600" />
                  </div>
                </div>
              </div>

              <div className="p-2">
                <div className="mx-auto text-center">
                  {/* <span
                    className={`mx-auto inline-flex rounded-full px-1.5 py-0.5 text-[8px] font-semibold ${
                      product.stock > 0
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-rose-100 text-rose-600"
                    }`}
                  >
                    {product.stock > 0 ? "In Stock" : "Out of Stock"}
                  </span> */}

                  <h3 className="mt-1 min-w-0 truncate whitespace-nowrap text-xs font-semibold text-slate-800 transition-colors group-hover:text-rose-600">
                    {product.name}
                  </h3>

                  <div className="mt-1 flex items-center justify-center gap-1">
                    <span className="text-base font-bold text-slate-900">
                      ৳{finalPrice}
                    </span>

                    {product.offerPrice ? (
                      <span className="text-xs text-slate-400 line-through">
                        ৳{product.price}
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </CategoryProductSlider>
    </section>
  );
}
