import { Shield, Truck, Star, Headphones } from "lucide-react";

export default function TrustBadges() {
  const items = [
    {
      title: "Fast Delivery",
      desc: "Express shipping across Bangladesh.",
      icon: Truck,
      gradient: "from-[#ec407a] to-[#d81b60]",
    },
    {
      title: "Secure Checkout",
      desc: "Bank-grade secure payment gateway.",
      icon: Shield,
      gradient: "from-[#d81b60] to-[#ad1457]",
    },
    {
      title: "Verified Reviews",
      desc: "Authentic verified customer reviews.",
      icon: Star,
      gradient: "from-[#f06292] to-[#ec407a]",
    },
    {
      title: "24/7 Support",
      desc: "Round-the-clock customer support available.",
      icon: Headphones,
      gradient: "from-[#ad1457] to-[#ec407a]",
    },
  ];

  return (
    <div className="grid gap-4 md:gap-6 grid-cols-2 lg:grid-cols-4">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.title}
            className="group relative flex items-center gap-2 md:gap-5 overflow-hidden rounded-sm border border-[#f8bbd0] bg-white/90 p-2 shadow-lg transition-all hover:-translate-y-1 hover:shadow-xl"
          >
            <div
              className={`flex items-center justify-center relative rounded-sm bg-linear-to-br ${item.gradient} p-2 md:p-3 text-white shadow-lg h-fit`}
            >
              <Icon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="relative text-sm md:text-lg font-semibold text-gray-900">
                {item.title}
              </h3>
              <p className="relative mt-2 text-sm leading-relaxed text-gray-600 hidden sm:block">
                {item.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
