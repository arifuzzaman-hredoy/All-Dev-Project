"use client";

import { useEffect, useRef, useState } from "react";

type Props = {
  children: React.ReactNode;
};

export default function CategoryProductSlider({ children }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  const pointerDownRef = useRef(false);
  const isDraggingRef = useRef(false);
  const dragAxisRef = useRef<"horizontal" | "vertical" | null>(null);
  const startXRef = useRef(0);
  const startYRef = useRef(0);
  const startScrollLeftRef = useRef(0);
  const dragDistanceRef = useRef(0);
  const preventClickRef = useRef(false);

  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const DRAG_THRESHOLD = 6;
    const AXIS_LOCK_THRESHOLD = 8;

    const startInteraction = (clientX: number, clientY: number) => {
      pointerDownRef.current = true;
      dragAxisRef.current = null;
      isDraggingRef.current = false;
      preventClickRef.current = false;
      dragDistanceRef.current = 0;

      startXRef.current = clientX;
      startYRef.current = clientY;
      startScrollLeftRef.current = el.scrollLeft;
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;

      startInteraction(e.clientX, e.clientY);
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!pointerDownRef.current) return;

      const dx = e.clientX - startXRef.current;
      const dy = e.clientY - startYRef.current;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);

      if (!dragAxisRef.current) {
        if (absX < AXIS_LOCK_THRESHOLD && absY < AXIS_LOCK_THRESHOLD) return;

        dragAxisRef.current = absX > absY ? "horizontal" : "vertical";

        if (dragAxisRef.current === "vertical") {
          return;
        }

        isDraggingRef.current = true;
        setIsDragging(true);
      }

      if (dragAxisRef.current !== "horizontal") return;

      dragDistanceRef.current = Math.max(dragDistanceRef.current, absX);

      if (dragDistanceRef.current > DRAG_THRESHOLD) {
        preventClickRef.current = true;
      }

      e.preventDefault();
      el.scrollLeft = startScrollLeftRef.current - dx;
    };

    const endInteraction = () => {
      pointerDownRef.current = false;
      dragAxisRef.current = null;
      isDraggingRef.current = false;
      setIsDragging(false);

      window.setTimeout(() => {
        preventClickRef.current = false;
      }, 80);
    };

    const onPointerUp = () => {
      endInteraction();
    };

    const onPointerCancel = () => {
      endInteraction();
    };

    const preventDrag = (e: DragEvent) => {
      e.preventDefault();
    };

    const captureClick = (e: MouseEvent) => {
      if (preventClickRef.current) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("pointermove", onPointerMove);
    el.addEventListener("pointerup", onPointerUp);
    el.addEventListener("pointercancel", onPointerCancel);
    window.addEventListener("pointerup", onPointerUp);

    el.addEventListener("dragstart", preventDrag);
    el.addEventListener("click", captureClick, true);

    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointermove", onPointerMove);
      el.removeEventListener("pointerup", onPointerUp);
      el.removeEventListener("pointercancel", onPointerCancel);
      window.removeEventListener("pointerup", onPointerUp);

      el.removeEventListener("dragstart", preventDrag);
      el.removeEventListener("click", captureClick, true);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={`flex gap-1 overflow-x-auto scrollbar-hide pb-2 select-none touch-pan-y ${
        isDragging ? "cursor-grabbing" : "cursor-grab"
      }`}
      style={{ WebkitOverflowScrolling: "touch" }}
    >
      {children}
    </div>
  );
}
