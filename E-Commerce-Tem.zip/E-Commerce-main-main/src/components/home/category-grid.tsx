"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";

type Category = {
  id: string;
  name: string;
  slug: string;
  imageUrl?: string | null;
  parent?: {
    name: string;
    slug: string;
  } | null;
};

function CategoryCard({ category }: { category: Category }) {
  return (
    <Link
      href={`/categories/${encodeURIComponent(category.slug)}`}
      className="group block w-26 shrink-0 select-none sm:w-32 md:w-40"
      draggable={false}
    >
      <div className="overflow-hidden border border-pink-100 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-pink-200 hover:shadow-xl">
        <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-pink-50 via-rose-50 to-white">
          {category.parent ? (
            <div className="absolute left-2 top-2 z-10 max-w-[calc(100%-1rem)] rounded-full border border-white/70 bg-white/90 px-2 py-0.5 text-[9px] font-semibold text-pink-700 shadow-sm backdrop-blur">
              <span className="block truncate">{category.parent.name}</span>
            </div>
          ) : null}

          {category.imageUrl ? (
            <Image
              src={category.imageUrl}
              alt={category.name}
              fill
              draggable={false}
              className="pointer-events-none object-cover transition-transform duration-500 group-hover:scale-110"
              sizes="(max-width: 640px) 128px, (max-width: 768px) 144px, 176px"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-xs font-medium text-slate-400">
              No image
            </div>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/5 to-transparent opacity-70 transition-opacity duration-300 group-hover:opacity-90" />
        </div>

        <div className="relative bg-white px-3 py-2.5 text-center">
          <h3 className="truncate text-xs font-bold text-slate-900 transition-colors group-hover:text-pink-700 sm:text-sm">
            {category.name}
          </h3>

          <div className="mx-auto mt-1 h-0.5 w-6 rounded-full bg-pink-500 transition-all duration-300 group-hover:w-10" />
        </div>
      </div>
    </Link>
  );
}

export default function CategoryGrid({
  categories,
}: {
  categories: Category[];
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animationRef = useRef<number | null>(null);

  const [isHovering, setIsHovering] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const isHoveringRef = useRef(false);
  const isDraggingRef = useRef(false);
  const pointerDownRef = useRef(false);
  const dragActiveRef = useRef(false);

  const startXRef = useRef(0);
  const startYRef = useRef(0);
  const startScrollLeftRef = useRef(0);
  const dragDistanceRef = useRef(0);
  const preventClickRef = useRef(false);

  const scrollSpeed = 0.5;

  useEffect(() => {
    isHoveringRef.current = isHovering;
  }, [isHovering]);

  useEffect(() => {
    isDraggingRef.current = isDragging;
  }, [isDragging]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || categories.length === 0) return;

    const animate = () => {
      if (!isHoveringRef.current && !isDraggingRef.current) {
        const maxScrollLeft = el.scrollWidth - el.clientWidth;
        if (maxScrollLeft <= 0) {
          animationRef.current = requestAnimationFrame(animate);
          return;
        }

        el.scrollLeft += scrollSpeed;

        if (el.scrollLeft >= maxScrollLeft) {
          el.scrollLeft = 0;
        }
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [categories.length]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const DRAG_THRESHOLD = 6;
    const AXIS_LOCK_THRESHOLD = 8;

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;

      pointerDownRef.current = true;
      dragActiveRef.current = false;
      preventClickRef.current = false;
      dragDistanceRef.current = 0;
      startXRef.current = e.clientX;
      startYRef.current = e.clientY;
      startScrollLeftRef.current = el.scrollLeft;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!pointerDownRef.current) return;

      const deltaX = e.clientX - startXRef.current;
      const deltaY = e.clientY - startYRef.current;
      const absX = Math.abs(deltaX);
      const absY = Math.abs(deltaY);

      if (!dragActiveRef.current) {
        if (absX < AXIS_LOCK_THRESHOLD && absY < AXIS_LOCK_THRESHOLD) return;
        if (absY > absX) {
          pointerDownRef.current = false;
          return;
        }

        dragActiveRef.current = true;
        setIsDragging(true);
      }

      dragDistanceRef.current = absX;
      if (dragDistanceRef.current > DRAG_THRESHOLD) {
        preventClickRef.current = true;
      }

      e.preventDefault();
      el.scrollLeft = startScrollLeftRef.current - deltaX;
    };

    const stopDrag = () => {
      pointerDownRef.current = false;
      dragActiveRef.current = false;
      setIsDragging(false);

      window.setTimeout(() => {
        preventClickRef.current = false;
      }, 80);
    };

    const onDragStart = (e: DragEvent) => {
      e.preventDefault();
    };

    const captureClick = (e: MouseEvent) => {
      if (preventClickRef.current) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("pointermove", onPointerMove);
    el.addEventListener("pointerup", stopDrag);
    el.addEventListener("pointercancel", stopDrag);
    window.addEventListener("pointerup", stopDrag);
    el.addEventListener("dragstart", onDragStart);
    el.addEventListener("click", captureClick, true);

    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointermove", onPointerMove);
      el.removeEventListener("pointerup", stopDrag);
      el.removeEventListener("pointercancel", stopDrag);
      window.removeEventListener("pointerup", stopDrag);
      el.removeEventListener("dragstart", onDragStart);
      el.removeEventListener("click", captureClick, true);
    };
  }, []);

  if (!categories?.length) return null;

  return (
    <div className="relative">
      <div
        ref={containerRef}
        className="mx-auto flex w-fit max-w-full overflow-x-auto scrollbar-hide cursor-grab active:cursor-grabbing select-none touch-pan-x"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
        style={{ WebkitOverflowScrolling: "touch" }}
      >
        {categories.map((category) => (
          <div key={category.id} className="shrink-0">
            <CategoryCard category={category} />
          </div>
        ))}
      </div>
    </div>
  );
}
