import {
  ShieldCheck,
  PackageCheck,
  Sparkles,
  ArrowRight,
  SearchCheck,
} from "lucide-react";
import Link from "next/link";

const HelpSection = () => {
  return (
    <div className=" flex items-center justify-center py-4 sm:py-6 md:py-10 bg-white">
      <div className="relative w-full max-w-7xl overflow-hidden rounded-[28px] border border-gray-200 bg-white shadow-[0_8px_32px_rgba(0,0,0,0.08)]">
        <div className="relative z-10 grid grid-cols-1 gap-8 p-6 sm:p-8 md:grid-cols-[1.35fr_0.65fr] md:gap-10 md:p-10 lg:p-12">
          {/* left content */}
          <div className="flex flex-col justify-center">
            <div className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-medium tracking-[0.18em] text-cyan-700 uppercase">
              <Sparkles size={14} className="text-cyan-400" />
              Premium Experience
            </div>

            <h2 className="max-w-3xl text-2xl font-semibold leading-tight text-gray-900 sm:text-3xl md:text-[2rem] lg:text-[2.3rem]">
              Find the perfect choice,
              <span className="block text-gray-700">
                beautifully made simple
              </span>
            </h2>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-gray-600 sm:text-[15px]">
              From first click to final delivery, we offer a seamless shopping
              journey built on authenticity, premium quality, and dependable
              service.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 max-w-2xl">
              <div className="group rounded-2xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:bg-cyan-100 hover:border-cyan-200">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl border border-cyan-100 bg-cyan-100 text-cyan-500 shadow-inner">
                  <ShieldCheck size={22} />
                </div>
                <h3 className="text-base font-semibold text-gray-900">
                  Verified Quality Products
                </h3>
                <p className="mt-1 text-sm text-gray-600">
                  Trusted selections with premium presentation and consistency.
                </p>
              </div>

              <div className="group rounded-2xl border border-pink-100 bg-pink-50 p-4 transition duration-300 hover:bg-pink-100 hover:border-pink-200">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl border border-pink-100 bg-pink-100 text-pink-400 shadow-inner">
                  <PackageCheck size={22} />
                </div>
                <h3 className="text-base font-semibold text-gray-900">
                  Smooth, Reliable Fulfillment
                </h3>
                <p className="mt-1 text-sm text-gray-600">
                  Fast, simple, and customer-first from checkout to delivery.
                </p>
              </div>
            </div>
          </div>

          {/* right buttons */}
          <div className="flex flex-col justify-center gap-5 md:items-end">
            <ShineButton
              text="Explore Our Collection"
              icon={<ArrowRight size={18} />}
              glow="cyan"
              href="/products"
            />

            <ShineButton
              text="Track My Order"
              icon={<SearchCheck size={18} />}
              glow="pink"
              href="/orders"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const ShineButton = ({ text, icon, glow = "cyan", href }) => {
  const glowStyles =
    glow === "pink"
      ? "border-pink-300 bg-pink-100 text-pink-700 hover:bg-pink-200 hover:border-pink-400"
      : "border-cyan-300 bg-cyan-100 text-cyan-700 hover:bg-cyan-200 hover:border-cyan-400";

  return (
    <Link
      href={href}
      className={`group relative inline-flex min-w-50 items-center justify-center gap-2 overflow-hidden rounded-2xl border px-6 py-4 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${glowStyles}`}
    >
      <span className="relative z-10">{text}</span>
      <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
        {icon}
      </span>
    </Link>
  );
};

export default HelpSection;
