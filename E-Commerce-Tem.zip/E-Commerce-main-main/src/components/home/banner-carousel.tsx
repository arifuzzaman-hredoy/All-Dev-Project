"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

type Banner = {
  id: string;
  title: string | null;
  imageUrl: string;
  linkUrl: string | null;
};

export default function BannerCarousel({ banners }: { banners: Banner[] }) {
  const items = useMemo(() => (banners?.length ? banners : []), [banners]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (items.length <= 1 || !isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((i) => (i + 1) % items.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [items.length, isAutoPlaying]);

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((i) => (i + 1) % items.length);
  };

  const goToPrev = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((i) => (i - 1 + items.length) % items.length);
  };

  const goToSlide = (index: number) => {
    setIsAutoPlaying(false);
    setCurrentIndex(index);
  };

  if (!items.length) {
    return null;
  }

  const currentBanner = items[currentIndex];

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gray-900/5 sm:rounded-3xl">
      {/* Main Banner */}
      <div className="relative aspect-[4/3] w-full sm:aspect-video">
        <Image
          src={currentBanner.imageUrl}
          alt={currentBanner.title ?? "Banner"}
          fill
          className="object-contain transition-transform duration-700 hover:scale-105 sm:object-cover"
          sizes="(max-width: 768px) 100vw, 700px"
          priority
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-linear-to-t from-gray-900/90 via-gray-900/30 to-transparent" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 md:p-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="min-w-0 max-w-full sm:max-w-[60%]">
              <div className="mb-2 inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
                Featured
              </div>
              <h3 className="line-clamp-2 text-lg font-bold text-white sm:text-xl md:text-2xl">
                {currentBanner.title ?? "Special Offer"}
              </h3>
            </div>

            {currentBanner.linkUrl && (
              <Link
                href={currentBanner.linkUrl}
                className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-gray-900 shadow-lg transition-all hover:-translate-y-0.5 hover:bg-gray-100 hover:shadow-xl sm:w-auto sm:px-6"
              >
                <span>Shop Now</span>
                <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Controls - Centered with modern design */}
      {items.length > 1 && (
        <>
          {/* Arrow Buttons */}
          <button
            onClick={goToPrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-gray-800 shadow-lg transition-all hover:scale-110 hover:bg-white hover:shadow-xl backdrop-blur-sm sm:left-4 sm:p-3"
            aria-label="Previous banner"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <button
            onClick={goToNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-gray-800 shadow-lg transition-all hover:scale-110 hover:bg-white hover:shadow-xl backdrop-blur-sm sm:right-4 sm:p-3"
            aria-label="Next banner"
          >
            <ChevronRight className="h-5 w-5" />
          </button>

          {/* Dots Indicator - Centered */}
          <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1.5 sm:bottom-4 sm:gap-2">
            {items.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`transition-all ${index === currentIndex
                    ? "w-8 bg-white"
                    : "w-2 bg-white/50 hover:bg-white/80"
                  } h-2 rounded-full`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>

          {/* Auto-play indicator */}
          <div className="absolute right-3 top-3 sm:right-4 sm:top-4">
            <div className="rounded-full bg-black/30 px-2.5 py-1 text-[10px] text-white backdrop-blur-sm sm:px-3 sm:text-xs">
              {currentIndex + 1} / {items.length}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
