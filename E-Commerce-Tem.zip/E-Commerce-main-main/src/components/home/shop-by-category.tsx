import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { prisma } from "@/lib/prisma";

export default async function ShopByCategory() {
  let categories: {
    name: string;
    slug: string;
    imageUrl: string | null;
    _count: { products: number };
  }[] = [];

  try {
    categories = await prisma.category.findMany({
      where: {
        isActive: true,
        parentId: null,
      },
      orderBy: [{ name: "asc" }],
      take: 16,
      select: {
        name: true,
        slug: true,
        imageUrl: true,
        _count: {
          select: {
            products: true,
          },
        },
      },
    });
  } catch {
    categories = [];
  }

  if (!categories.length) {
    return null;
  }

  return (
    <div className="w-full">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 md:text-3xl">
            Categories
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Browse demo-ready ecommerce categories.
          </p>
        </div>

        <Link
          href="/categories"
          className="group inline-flex items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] ring-1 ring-[#f8bbd0] transition hover:bg-[#ffe4ec] hover:text-[#8e1042]"
        >
          <span>View all</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 overflow-hidden rounded-2xl border border-pink-100 bg-white shadow-sm sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8">
        {categories.map((category) => (
          <Link
            key={category.slug}
            href={`/categories/${category.slug}`}
            className="group border-b border-r border-pink-100 bg-white p-3 transition hover:bg-[#fff7fb]"
          >
            <div className="aspect-[4/3] overflow-hidden rounded-xl bg-[#fff1f5]">
              <img
                src={category.imageUrl || "/nexoramart-logo.svg"}
                alt={category.name}
                className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                loading="lazy"
              />
            </div>

            <div className="pt-3 text-center">
              <h3 className="line-clamp-1 text-sm font-bold text-slate-950">
                {category.name}
              </h3>
              <div className="mx-auto mt-2 h-0.5 w-10 rounded-full bg-[#db0f5b]" />
              <p className="mt-2 text-xs text-slate-500">
                {category._count.products} products
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
