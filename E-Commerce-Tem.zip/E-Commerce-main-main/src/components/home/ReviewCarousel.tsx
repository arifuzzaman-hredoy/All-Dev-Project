"use client";

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";

type Review = {
  id: number;
  name: string;
  role: string;
  rating: number;
  review: string;
  date: string;
  highlight: string;
  avatarClass: string;
};

const reviews: Review[] = [
  {
    id: 1,
    name: "Rakib Hasan",
    role: "Verified Buyer",
    rating: 5,
    review:
      "Product quality onek valo. Packaging premium chilo and delivery time er moddhei peyechi. Overall experience excellent.",
    date: "2 days ago",
    highlight: "Fast Delivery",
    avatarClass: "bg-blue-600",
  },
  {
    id: 2,
    name: "Nusrat Jahan",
    role: "Regular Customer",
    rating: 5,
    review:
      "Website er design clean, product find kora easy, support team quick response dise. Ami service niye khub satisfied.",
    date: "1 week ago",
    highlight: "Great Support",
    avatarClass: "bg-rose-600",
  },
  {
    id: 3,
    name: "Tanvir Ahmed",
    role: "Verified Buyer",
    rating: 4,
    review:
      "Price er compare e quality really valo. Category wise product browse kora easy chilo. Recommended.",
    date: "3 weeks ago",
    highlight: "Best Quality",
    avatarClass: "bg-emerald-600",
  },
  {
    id: 4,
    name: "Sadia Islam",
    role: "Happy Customer",
    rating: 5,
    review:
      "Order process smooth chilo. Product image er sathe real product match kore. Service ta professional mone hoyeche.",
    date: "1 month ago",
    highlight: "Smooth Order",
    avatarClass: "bg-violet-600",
  },
  {
    id: 5,
    name: "Mahmudul Karim",
    role: "Verified Buyer",
    rating: 5,
    review:
      "Delivery update regular peyechi. Product quality, support and overall shopping experience amar kache premium legeche.",
    date: "1 month ago",
    highlight: "Premium Feel",
    avatarClass: "bg-orange-600",
  },
  {
    id: 6,
    name: "Farhana Akter",
    role: "Regular Customer",
    rating: 4,
    review:
      "Category wise product khuja easy. Mobile theke use korteo kono problem hoyni. Overall khub valo experience.",
    date: "2 months ago",
    highlight: "Mobile Friendly",
    avatarClass: "bg-cyan-600",
  },
];

function getItemsPerView() {
  if (typeof window === "undefined") return 1;

  if (window.innerWidth >= 1024) return 3;
  if (window.innerWidth >= 768) return 2;

  return 1;
}

function subscribeToResize(callback: () => void) {
  window.addEventListener("resize", callback);

  return () => {
    window.removeEventListener("resize", callback);
  };
}

function useItemsPerView() {
  return useSyncExternalStore(subscribeToResize, getItemsPerView, () => 1);
}

function ReviewCard({ review }: { review: Review }) {
  const initials = review.name
    .split(" ")
    .map((word) => word[0])
    .join("");

  return (
    <article className="group relative h-full overflow-hidden rounded-[28px] border border-slate-200/80 bg-white/80 p-6 shadow-[0_18px_50px_rgba(15,23,42,0.08)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-2 hover:border-slate-300 hover:bg-white hover:shadow-[0_28px_80px_rgba(15,23,42,0.13)]">
      <div className="absolute right-5 top-5 h-20 w-20 rounded-full bg-slate-100/70 blur-2xl transition duration-500 group-hover:bg-slate-200/80" />
      <div className="absolute bottom-5 left-5 h-24 w-24 rounded-full bg-slate-100/60 blur-2xl transition duration-500 group-hover:bg-slate-200/70" />

      <div className="relative z-10 flex h-full flex-col">
        <div className="mb-6 flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${review.avatarClass} text-lg font-black text-white shadow-lg shadow-slate-900/10 ring-4 ring-slate-100 transition duration-500 group-hover:scale-110 group-hover:rotate-3`}
            >
              {initials}
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-950">
                {review.name}
              </h3>
              <p className="mt-1 text-sm font-medium text-slate-500">
                {review.role}
              </p>
            </div>
          </div>

          <span className="hidden rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-bold text-slate-600 sm:inline-flex">
            {review.highlight}
          </span>
        </div>

        <div className="mb-5 flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, index) => (
            <span
              key={index}
              className={`text-2xl transition duration-300 ${
                index < review.rating
                  ? "text-yellow-400 group-hover:scale-110"
                  : "text-slate-200"
              }`}
            >
              ★
            </span>
          ))}

          <span className="ml-2 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">
            {review.rating}.0
          </span>
        </div>

        <div className="relative flex-1">
          <span className="absolute -left-1 -top-5 text-7xl font-black leading-none text-slate-100">
            “
          </span>

          <p className="relative text-[15px] leading-7 text-slate-600">
            {review.review}
          </p>
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-5">
          <p className="text-sm font-medium text-slate-400">{review.date}</p>

          <div className="flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 ring-1 ring-emerald-100">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Verified
          </div>
        </div>
      </div>
    </article>
  );
}

export default function ReviewCarousel() {
  const itemsPerView = useItemsPerView();

  const carouselRef = useRef<HTMLDivElement | null>(null);
  const dragStartXRef = useRef(0);
  const lastDragXRef = useRef(0);
  const isDraggingRef = useRef(false);

  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffsetPx, setDragOffsetPx] = useState(0);

  const maxIndex = useMemo(() => {
    return Math.max(0, reviews.length - itemsPerView);
  }, [itemsPerView]);

  const safeActiveIndex = Math.min(activeIndex, maxIndex);

  useEffect(() => {
    if (isPaused || isDragging || maxIndex <= 0) return;

    const interval = window.setInterval(() => {
      setActiveIndex((prev) => {
        const currentIndex = Math.min(prev, maxIndex);
        return currentIndex >= maxIndex ? 0 : currentIndex + 1;
      });
    }, 3000);

    return () => {
      window.clearInterval(interval);
    };
  }, [isPaused, isDragging, maxIndex]);

  const goPrev = () => {
    setActiveIndex((prev) => {
      const currentIndex = Math.min(prev, maxIndex);
      return currentIndex <= 0 ? maxIndex : currentIndex - 1;
    });
  };

  const goNext = () => {
    setActiveIndex((prev) => {
      const currentIndex = Math.min(prev, maxIndex);
      return currentIndex >= maxIndex ? 0 : currentIndex + 1;
    });
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (maxIndex <= 0) return;

    isDraggingRef.current = true;
    dragStartXRef.current = event.clientX;
    lastDragXRef.current = event.clientX;

    setIsDragging(true);
    setIsPaused(true);
    setDragOffsetPx(0);

    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;

    lastDragXRef.current = event.clientX;

    const rawOffset = event.clientX - dragStartXRef.current;

    const limitedOffset = Math.max(-140, Math.min(140, rawOffset));

    setDragOffsetPx(limitedOffset);
  };

  const finishDragging = () => {
    if (!isDraggingRef.current) return;

    const dragDistance = lastDragXRef.current - dragStartXRef.current;
    const carouselWidth = carouselRef.current?.offsetWidth ?? 360;
    const swipeThreshold = Math.min(90, carouselWidth * 0.18);

    if (dragDistance <= -swipeThreshold) {
      goNext();
    }

    if (dragDistance >= swipeThreshold) {
      goPrev();
    }

    isDraggingRef.current = false;
    setIsDragging(false);
    setIsPaused(false);
    setDragOffsetPx(0);
  };

  return (
    <section className="bg-white px-4 py-10">
      <style>{`
        @keyframes titleUp {
          from {
            opacity: 0;
            transform: translateY(18px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>

      <div className="mx-auto max-w-7xl">
        <div className="mx-auto mb-10 max-w-3xl text-center [animation:titleUp_700ms_ease_both]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2 text-sm font-bold text-slate-700 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Customer Reviews
          </div>

          <h2 className="text-3xl font-black tracking-tight text-slate-950 md:text-5xl">
            Loved by Real Customers
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-slate-500 md:text-lg">
            Premium experience, trusted quality, and real feedback from our
            happy customers.
          </p>
        </div>

        <div
          ref={carouselRef}
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <div
            className="overflow-hidden rounded-[32px] px-1 py-4 touch-pan-y select-none"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={finishDragging}
            onPointerCancel={finishDragging}
            onPointerLeave={finishDragging}
          >
            <div
              className={`flex ${
                isDragging
                  ? "transition-none"
                  : "transition-transform duration-700 ease-out"
              }`}
              style={{
                transform: `translateX(calc(-${
                  safeActiveIndex * (100 / itemsPerView)
                }% + ${dragOffsetPx}px))`,
              }}
            >
              {reviews.map((review) => (
                <div
                  key={review.id}
                  className="shrink-0 px-3"
                  style={{
                    width: `${100 / itemsPerView}%`,
                  }}
                >
                  <ReviewCard review={review} />
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={goPrev}
            className="absolute left-0 top-1/2 z-20 hidden h-11 w-11 -translate-x-3 -translate-y-1/2 items-center justify-center rounded-full border border-slate-200 bg-white text-xl font-black text-slate-700 shadow-lg shadow-slate-900/10 transition hover:-translate-x-4 hover:bg-slate-50 md:flex"
            aria-label="Previous review"
          >
            ‹
          </button>

          <button
            type="button"
            onClick={goNext}
            className="absolute right-0 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 translate-x-3 items-center justify-center rounded-full border border-slate-200 bg-white text-xl font-black text-slate-700 shadow-lg shadow-slate-900/10 transition hover:translate-x-4 hover:bg-slate-50 md:flex"
            aria-label="Next review"
          >
            ›
          </button>
        </div>

        <div className="mt-6 flex items-center justify-center gap-2">
          {Array.from({ length: maxIndex + 1 }).map((_, index) => (
            <button
              key={index}
              type="button"
              onClick={() => setActiveIndex(index)}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                safeActiveIndex === index
                  ? "w-8 bg-slate-900"
                  : "w-2.5 bg-slate-300 hover:bg-slate-400"
              }`}
              aria-label={`Go to review slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}