import { IndianRupee, Receipt } from "lucide-react";

type Settings = {
  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  codEnabled: boolean;
  onlineEnabled: boolean;
};

export default function StoreHighlights({ settings }: { settings: Settings }) {
  const badges = [
    {
      condition: settings.onlineEnabled,
      label: "Online Payment",
      icon: Receipt,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      condition: settings.taxRate > 0,
      label: `Tax ${settings.taxRate}%`,
      icon: IndianRupee,
      color: "text-red-600",
      bgColor: "bg-red-50",
    },
  ].filter((b) => b.condition);

  return (
    <div className="mt-6 flex flex-wrap gap-3">
      {badges.map((badge) => {
        const Icon = badge.icon;
        return (
          <div
            key={badge.label}
            className={`inline-flex cursor-default items-center gap-2 rounded-full ${badge.bgColor} px-4 py-2.5 text-sm font-medium ${badge.color} shadow-sm ring-1 ring-black/5 transition-all hover:scale-105 hover:shadow-md`}
          >
            <Icon className="h-4 w-4" />
            <span>{badge.label}</span>
          </div>
        );
      })}
    </div>
  );
}
