"use client";

import Image, { type StaticImageData } from "next/image";
import Link from "next/link";
import heroBannerImg from "@/assets/banner/bannerblack.jpg";
import heroSideBannerImg1 from "@/assets/banner/bannerblack2.png";
import heroSideBannerImg2 from "@/assets/banner/iamgeblack3.png";

type HomeBannerSlot = "mainbanner" | "subbanner1" | "subbanner2";

type HomeBanner = {
  slot: string | null;
  title: string | null;
  imageUrl: string;
  linkUrl: string | null;
};

type HeroSectionProps = {
  settings: unknown;
  banners?: HomeBanner[];
};

type HeroBannerView = {
  href: string;
  image: string | StaticImageData;
  alt: string;
};

const fallbackSideBanners: HeroBannerView[] = [
  {
    href: "/products",
    image: heroSideBannerImg1,
    alt: "Promotional banner",
  },
  {
    href: "/products?featured=1",
    image: heroSideBannerImg2,
    alt: "Featured promotional banner",
  },
];

function findSlotBanner(
  banners: HomeBanner[],
  slot: HomeBannerSlot,
): HomeBanner | undefined {
  return banners.find(
    (banner) => banner.slot === slot && !!banner.imageUrl?.trim(),
  );
}

function getBannerView(
  banner: HomeBanner | undefined,
  fallback: HeroBannerView,
): HeroBannerView {
  return {
    href: banner?.linkUrl?.trim() || fallback.href,
    image: banner?.imageUrl?.trim() || fallback.image,
    alt: banner?.title?.trim() || fallback.alt,
  };
}

export default function HeroSection({
  settings,
  banners = [],
}: HeroSectionProps) {
  void settings;

  const heroBanners = banners.filter((banner) =>
    ["mainbanner", "subbanner1", "subbanner2"].includes(banner.slot ?? ""),
  );

  const mainBanner = getBannerView(findSlotBanner(heroBanners, "mainbanner"), {
    href: "/products",
    image: heroBannerImg,
    alt: "Featured banner",
  });

  const sideBanners = [
    getBannerView(
      findSlotBanner(heroBanners, "subbanner1"),
      fallbackSideBanners[0],
    ),
    getBannerView(
      findSlotBanner(heroBanners, "subbanner2"),
      fallbackSideBanners[1],
    ),
  ];

  return (
    <section className="relative overflow-hidden pt-12">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 lg:px-6 md:h-112 md:flex-row">
        {/* MAIN HERO */}
        <div className="min-w-0 md:h-full md:flex-[1.7]">
          <Link
            href={mainBanner.href}
            aria-label={mainBanner.alt}
            className="group block h-52 overflow-hidden rounded-2xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-[#ffe4ec] to-white shadow-[0_18px_60px_-40px_rgba(216,27,96,0.35)] sm:h-72 md:h-full"
          >
            <div className="relative h-full w-full">
              <Image
                src={mainBanner.image}
                alt={mainBanner.alt}
                fill
                priority
                className="object-cover"
                sizes="(max-width: 1280px) 100vw, 68vw"
              />
            </div>
          </Link>
        </div>

        {/* SIDE CARDS */}
        <div className="flex h-full flex-row gap-4 md:flex-[0.9] md:flex-col">
          {sideBanners.map((banner) => (
            <Link
              key={banner.alt}
              href={banner.href}
              aria-label={banner.alt}
              className="group block min-w-0 flex-1 overflow-hidden rounded-2xl border border-[#f8bbd0] bg-white shadow-[0_18px_50px_-38px_rgba(216,27,96,0.18)]"
            >
              <div className="relative h-36 w-full sm:h-44 md:h-full">
                <Image
                  src={banner.image}
                  alt={banner.alt}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width: 768px) 50vw, (max-width: 1280px) 40vw, 24vw"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
