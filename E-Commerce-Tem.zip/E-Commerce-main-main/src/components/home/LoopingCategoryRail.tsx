"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export type LoopingCategoryItem = {
  id: string;
  name: string;
  slug: string;
  imageUrl?: string | null;
};

type LoopingCategoryRailProps = {
  categories: LoopingCategoryItem[];
};

export function LoopingCategoryRail({ categories }: LoopingCategoryRailProps) {
  const railRef = useRef<HTMLDivElement | null>(null);
  const [paused, setPaused] = useState(false);

  const loopItems = useMemo(() => {
    if (!categories.length) return [];
    return [...categories, ...categories, ...categories];
  }, [categories]);

  function scrollByCard(direction: "left" | "right") {
    const el = railRef.current;
    if (!el) return;

    el.scrollBy({
      left: direction === "right" ? 320 : -320,
      behavior: "smooth",
    });
  }

  if (!categories.length) {
    return (
      <div className="rounded-2xl border border-pink-100 bg-white p-8 text-center text-slate-500">
        No categories found.
      </div>
    );
  }

  return (
    <div
      className="relative overflow-hidden border-y border-pink-100 bg-white"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <button
        type="button"
        onClick={() => scrollByCard("left")}
        className="absolute left-3 top-1/2 z-20 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-pink-100 bg-white/95 text-slate-800 shadow-lg hover:bg-pink-50"
        aria-label="Previous categories"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <div
        ref={railRef}
        className="no-scrollbar overflow-x-auto scroll-smooth"
      >
        <div
          className={`flex w-max gap-0 py-0 ${
            paused ? "[animation-play-state:paused]" : ""
          } animate-category-loop`}
        >
          {loopItems.map((category, index) => (
            <Link
              key={`${category.id}-${index}`}
              href={`/categories/${category.slug}`}
              className="group w-[285px] shrink-0 border-r border-pink-100 bg-white transition hover:bg-pink-50/40"
            >
              <div className="relative h-[170px] w-full overflow-hidden bg-pink-50">
                {category.imageUrl ? (
                  <Image
                    src={category.imageUrl}
                    alt={category.name}
                    fill
                    sizes="285px"
                    className="object-cover transition duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="grid h-full place-items-center text-sm font-semibold text-slate-400">
                    {category.name}
                  </div>
                )}
              </div>

              <div className="px-5 py-5 text-center">
                <h3 className="line-clamp-1 text-xl font-black text-slate-950">
                  {category.name}
                </h3>
                <span className="mx-auto mt-3 block h-[2px] w-10 rounded-full bg-pink-600 transition group-hover:w-16" />
              </div>
            </Link>
          ))}
        </div>
      </div>

      <button
        type="button"
        onClick={() => scrollByCard("right")}
        className="absolute right-3 top-1/2 z-20 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-pink-100 bg-white/95 text-slate-800 shadow-lg hover:bg-pink-50"
        aria-label="Next categories"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  );
}
