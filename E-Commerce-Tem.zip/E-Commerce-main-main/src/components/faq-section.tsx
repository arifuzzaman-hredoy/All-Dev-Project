"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/cn";

const faqs = [
  {
    question: "Are your products authentic?",
    answer:
      "Yes, all our products are sourced from trusted suppliers and verified to ensure authenticity and quality.",
  },
  {
    question: "How long does delivery take?",
    answer:
      "Delivery usually takes 2–5 business days depending on your location within Bangladesh.",
  },
  {
    question: "Can I return or exchange a product?",
    answer:
      "Yes, we offer a return and exchange policy for eligible products. Please check our return policy for full details.",
  },
  {
    question: "Do you provide customer support?",
    answer:
      "Absolutely! Our support team is available to assist you with orders, product queries, and after-sales service.",
  },
  {
    question: "How can I track my order?",
    answer:
      "Once your order is placed, you can track it from your account dashboard or through the tracking link sent to your email.",
  },
];

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="space-y-8">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-wide text-black/50">
          FAQ
        </p>
        <h2 className="mt-3 text-2xl font-bold tracking-tight text-black sm:text-3xl">
          Frequently Asked Questions
        </h2>
        <p className="mt-4 text-sm leading-7 text-black/65 sm:text-base">
          Here we have answered your common questions so you can make an easy decision.
        </p>
      </div>

      <div className="mx-auto max-w-3xl space-y-3">
        {faqs.map((faq, index) => {
          const isOpen = openIndex === index;

          return (
            <div
              key={faq.question}
              className="overflow-hidden rounded-2xl border border-black/10 bg-white/80 shadow-sm"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="flex w-full items-center justify-between px-5 py-4 text-left text-sm font-medium sm:text-base"
              >
                {faq.question}

                <ChevronDown
                  className={cn(
                    "h-5 w-5 transition-transform duration-200",
                    isOpen && "rotate-180",
                  )}
                />
              </button>

              <div
                className={cn(
                  "grid transition-all duration-300",
                  isOpen
                    ? "grid-rows-[1fr] opacity-100"
                    : "grid-rows-[0fr] opacity-0",
                )}
              >
                <div className="overflow-hidden px-5 pb-4 text-sm leading-7 text-black/65 sm:text-base">
                  {faq.answer}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
