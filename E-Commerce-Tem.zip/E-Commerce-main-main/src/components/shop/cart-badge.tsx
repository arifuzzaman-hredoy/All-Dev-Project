"use client";

import { ShoppingBag } from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";

type CartItem = { productId: string; qty: number };
type Cart = { items: CartItem[] };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parseCart(input: unknown): Cart {
  if (!input || typeof input !== "object") return { items: [] };

  const o = input as Record<string, unknown>;
  const cartObj = (o.cart as Record<string, unknown> | undefined) ?? {};
  const raw = Array.isArray(cartObj.items) ? cartObj.items : [];

  const items: CartItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      qty: Math.max(1, Math.floor(safeNumber(x.qty, 1))),
    }))
    .filter((i) => i.productId);

  return { items };
}

export default function CartBadge() {
  const [cart, setCart] = useState<Cart>({ items: [] });

  const count = useMemo(
    () => cart.items.reduce((sum, i) => sum + i.qty, 0),
    [cart.items]
  );

  const load = useCallback(async (): Promise<void> => {
    try {
      const r = await fetch("/api/cart", { cache: "no-store" });
      if (!r.ok) {
        setCart({ items: [] });
        return;
      }

      const j: unknown = await r.json().catch(() => null);
      setCart(parseCart(j));
    } catch {
      setCart({ items: [] });
    }
  }, []);

  useEffect(() => {
    queueMicrotask(() => {
      void load();
    });

    const handler = () => {
      void load();
    };

    window.addEventListener("rhc_cart_updated", handler);

    return () => {
      window.removeEventListener("rhc_cart_updated", handler);
    };
  }, [load]);

  return (
    <Link href="/cart" className="relative inline-flex items-center">
      <span className="text-sm font-semibold"><ShoppingBag /></span>
      <span className="absolute left-1 top-0 ml-2 rounded-full bg-black px-1 text-xs font-semibold text-white">
        {count}
      </span>
    </Link>
  );
}
