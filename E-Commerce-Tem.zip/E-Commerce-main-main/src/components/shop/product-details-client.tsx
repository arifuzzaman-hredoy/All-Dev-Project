"use client";

import Image from "next/image";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import {
  BadgeCheck,
  MessageCircle,
  Minus,
  PackageCheck,
  Plus,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Truck,
  Zap,
} from "lucide-react";

type ProductImage = {
  id: string;
  url: string;
};

type ProductVariant = {
  id: string;
  type: string;
  value: string;
  priceDiff: number;
  stock: number;
  images: ProductImage[];
};

type Props = {
  product: {
    id: string;
    slug: string;
    name: string;
    sku: string;
    description: string | null;
    youtubeUrl: string | null;
    price: number;
    offerPrice: number | null;
    stock: number;
    isFeatured: boolean;
    categoryNames: string[];
    images: ProductImage[];
    variants: ProductVariant[];
    discountPercentage?: number | null;
  };
  buyNowBaseUrl?: string;
  chatNowUrl?: string;
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number; variantId?: string | null }>;
  };
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function isCartResponse(v: unknown): v is CartResponse {
  const o = v as Record<string, unknown>;
  const cart = o.cart as Record<string, unknown> | undefined;
  return !!cart && Array.isArray((cart as { items?: unknown }).items);
}

function getVariantLabel(variant: ProductVariant | null): string {
  if (!variant) return "";
  return `${variant.type}: ${variant.value}`;
}

function buildBuyNowUrl(params: {
  productId: string;
  qty: number;
  variantId?: string | null;
  baseUrl?: string;
}): string {
  const query = new URLSearchParams();
  query.set("buyNow", "1");
  query.set("productId", params.productId);
  query.set("qty", String(Math.max(1, params.qty)));

  if (params.variantId) {
    query.set("variantId", params.variantId);
  }

  return `${params.baseUrl || "/checkout"}?${query.toString()}`;
}

function buildWhatsAppUrl(params: {
  productName: string;
  variantLabel?: string;
}) {
  const phone = "8801331960139";
  const message = params.variantLabel
    ? `Hello, I'm interested in this product: ${params.productName} (${params.variantLabel})`
    : `Hello, I'm interested in this product: ${params.productName}`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

function getYoutubeEmbedUrl(url: string | null): string | null {
  const raw = url?.trim();
  if (!raw) return null;

  try {
    const parsed = new URL(raw);
    const host = parsed.hostname.replace(/^www\./, "");
    let videoId = "";

    if (host === "youtu.be") {
      videoId = parsed.pathname.split("/").filter(Boolean)[0] || "";
    } else if (host === "youtube.com" || host === "m.youtube.com") {
      if (parsed.pathname.startsWith("/watch")) {
        videoId = parsed.searchParams.get("v") || "";
      } else if (
        parsed.pathname.startsWith("/embed/") ||
        parsed.pathname.startsWith("/shorts/")
      ) {
        videoId = parsed.pathname.split("/").filter(Boolean)[1] || "";
      }
    }

    if (!/^[a-zA-Z0-9_-]{6,}$/.test(videoId)) return null;

    return `https://www.youtube.com/embed/${videoId}`;
  } catch {
    return null;
  }
}

export default function ProductDetailsClient({
  product,
  buyNowBaseUrl = "/checkout",
  chatNowUrl,
}: Props) {
  const router = useRouter();
  const { toast } = useToast();

  const [qty, setQty] = useState(1);
  const [variantId, setVariantId] = useState<string | null>(
    product.variants[0]?.id ?? null,
  );
  const [loading, setLoading] = useState(false);
  const [buyingNow, setBuyingNow] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);

  const [requestOpen, setRequestOpen] = useState(false);
  const [requestLoading, setRequestLoading] = useState(false);
  const [requestName, setRequestName] = useState("");
  const [requestPhone, setRequestPhone] = useState("");
  const [requestEmail, setRequestEmail] = useState("");
  const [requestMessage, setRequestMessage] = useState("");

  const selectedVariant = useMemo(
    () => product.variants.find((v) => v.id === variantId) ?? null,
    [product.variants, variantId],
  );

  const baseOriginalPrice = safeNumber(product.price, 0);
  const baseDiscountedPrice = safeNumber(
    product.offerPrice ?? product.price,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(selectedVariant?.priceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  const hasDiscount = unitPrice < comparePrice;
  const currentStock = selectedVariant ? selectedVariant.stock : product.stock;
  const selectedVariantLabel = getVariantLabel(selectedVariant);

  const currentImages = selectedVariant?.images?.length
    ? selectedVariant.images
    : product.images;

  const [activeImage, setActiveImage] = useState<string>(
    currentImages[0]?.url ?? product.images[0]?.url ?? "",
  );

  const imageUrlsKey = currentImages.map((img) => img.url).join("|");

  useEffect(() => {
    if (currentImages[0]?.url) {
      setActiveImage(currentImages[0].url);
    } else if (product.images[0]?.url) {
      setActiveImage(product.images[0].url);
    } else {
      setActiveImage("");
    }
  }, [imageUrlsKey, product.images, currentImages]);

  const canBuy = currentStock > 0;

  const dec = () => setQty((q) => Math.max(1, q - 1));
  const inc = () =>
    setQty((q) => Math.min(Math.max(1, currentStock || 1), q + 1));

  const addToCartApi = async (): Promise<void> => {
    const r = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "add",
        productId: product.id,
        variantId,
        qty,
      }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      const msg = (j as ErrorResponse | null)?.error || "Failed to add to cart";
      throw new Error(msg);
    }

    if (!isCartResponse(j)) return;
  };

  const onAdd = async (): Promise<void> => {
    if (!canBuy || loading) return;

    setLoading(true);

    try {
      await addToCartApi();
      window.dispatchEvent(new Event("rhc_cart_updated"));

      toast({
        variant: "success",
        title: "Added to cart",
        description: selectedVariant
          ? `${product.name} • ${selectedVariant.type}: ${selectedVariant.value} added successfully.`
          : `${product.name} added successfully.`,
      });
    } catch (e) {
      toast({
        variant: "error",
        title: "Failed",
        description: e instanceof Error ? e.message : "Failed to add to cart",
      });
    } finally {
      setLoading(false);
    }
  };

  const onBuyNow = async (): Promise<void> => {
    if (!canBuy || buyingNow) return;

    setBuyingNow(true);

    try {
      const url = buildBuyNowUrl({
        productId: product.id,
        variantId,
        qty,
        baseUrl: buyNowBaseUrl,
      });

      router.push(url);
    } finally {
      setBuyingNow(false);
    }
  };

  const onChatNow = (): void => {
    const url =
      chatNowUrl ||
      buildWhatsAppUrl({
        productName: product.name,
        variantLabel: selectedVariantLabel || undefined,
      });

    window.open(url, "_blank", "noopener,noreferrer");
  };

  async function submitRequest() {
    if (!requestName.trim()) {
      toast({
        variant: "error",
        title: "Required",
        description: "Please enter your name.",
      });
      return;
    }

    if (!requestPhone.trim()) {
      toast({
        variant: "error",
        title: "Required",
        description: "Please enter your phone number.",
      });
      return;
    }

    setRequestLoading(true);

    try {
      const res = await fetch("/api/product-requests", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          productId: product.id,
          name: requestName.trim(),
          phone: requestPhone.trim(),
          email: requestEmail.trim() || null,
          message:
            requestMessage.trim() ||
            (selectedVariantLabel
              ? `Requested variant: ${selectedVariantLabel}`
              : null),
        }),
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(data?.error || "Failed to submit request");
      }

      toast({
        variant: "success",
        title: "Request submitted",
        description: "We received your product request successfully.",
      });

      setRequestOpen(false);
      setRequestName("");
      setRequestPhone("");
      setRequestEmail("");
      setRequestMessage("");
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Failed to submit request",
      });
    } finally {
      setRequestLoading(false);
    }
  }

  const descriptionText = product.description?.trim() ?? "";
  const shouldCollapseDescription = descriptionText.length > 260;
  const visibleDescription =
    shouldCollapseDescription && !showFullDescription
      ? `${descriptionText.slice(0, 260).trim()}...`
      : descriptionText;
  const discountPercent = hasDiscount
    ? Math.round(((comparePrice - unitPrice) / comparePrice) * 100)
    : product.discountPercentage;
  const youtubeEmbedUrl = getYoutubeEmbedUrl(product.youtubeUrl);

  return (
    <>
      <div className="grid gap-6 lg:grid-cols-12 lg:items-start">
        <div className="min-w-0 space-y-5 lg:col-span-7">
          <Card className="overflow-hidden rounded-[28px] border-[#f8bbd0] bg-white p-3 shadow-[0_28px_90px_-58px_rgba(216,27,96,0.45)] sm:p-4">
            <div className="space-y-3">
              <div className="relative flex aspect-square items-center justify-center overflow-hidden rounded-[24px] bg-linear-to-br from-[#fff1f5] via-white to-[#f8fafc] p-4 sm:p-6">
                <div className="pointer-events-none absolute inset-x-10 top-0 h-24 rounded-b-full bg-[#f8bbd0]/40 blur-3xl" />

                {discountPercent ? (
                  <div className="absolute left-4 top-4 z-10 inline-flex items-center gap-1.5 rounded-full bg-[#d81b60] px-3 py-1 text-xs font-bold text-white shadow-[0_16px_42px_-20px_rgba(216,27,96,0.8)]">
                    <Sparkles className="h-3.5 w-3.5" />
                    Save {discountPercent}%
                  </div>
                ) : null}

                {activeImage ? (
                  <Image
                    src={activeImage}
                    alt={product.name}
                    width={1200}
                    height={1200}
                    className="relative h-full w-full object-contain drop-shadow-[0_22px_34px_rgba(15,23,42,0.12)]"
                    priority
                  />
                ) : (
                  <span className="text-sm text-slate-500">No image</span>
                )}
              </div>

              {currentImages.length > 1 ? (
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-5">
                  {currentImages.slice(0, 10).map((img) => (
                    <button
                      key={img.id}
                      type="button"
                      onClick={() => setActiveImage(img.url)}
                      className={`relative aspect-square overflow-hidden rounded-2xl border bg-white p-1 shadow-sm transition hover:border-[#d81b60] ${
                        activeImage === img.url
                          ? "border-[#d81b60] ring-2 ring-[#f8bbd0]"
                          : "border-[#f8d7e2]"
                      }`}
                    >
                      <Image
                        src={img.url}
                        alt={product.name}
                        fill
                        className="object-contain"
                        sizes="120px"
                      />
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          </Card>

          <Card className="rounded-[28px] border-[#f8bbd0] bg-white p-5 shadow-[0_22px_70px_-58px_rgba(216,27,96,0.45)] sm:p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div className="min-w-0 space-y-2">
                {product.categoryNames?.length ? (
                  <div className="inline-flex max-w-full rounded-full bg-[#fff1f5] px-3 py-1 text-xs font-semibold text-[#ad1457]">
                    <span className="truncate">
                      {product.categoryNames.join(", ")}
                    </span>
                  </div>
                ) : null}
                <h1 className="wrap-break-word text-2xl font-bold tracking-tight text-slate-950 sm:text-3xl">
                  {product.name}
                </h1>
                <p className="text-sm text-slate-500">SKU: {product.sku}</p>
              </div>

              {product.isFeatured ? (
                <span className="inline-flex w-fit items-center gap-1.5 rounded-full border border-[#f8bbd0] bg-white px-3 py-1 text-xs font-semibold text-[#ad1457] shadow-sm">
                  <BadgeCheck className="h-3.5 w-3.5" />
                  Featured
                </span>
              ) : null}
            </div>

            <div className="mt-5 rounded-3xl border border-[#f8bbd0] bg-[#fff7fb] px-4 py-4">
              <div className="flex flex-wrap items-end gap-x-3 gap-y-1">
                <p className="text-3xl font-black tracking-tight text-slate-950">
                  ৳ {safeNumber(unitPrice, 0)}
                </p>
                {selectedVariantLabel ? (
                  <span className="pb-1 text-sm font-medium text-slate-500">
                    ({selectedVariantLabel})
                  </span>
                ) : null}
              </div>

              {hasDiscount ? (
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <p className="text-sm text-slate-400 line-through">
                    ৳ {comparePrice}
                  </p>
                  {discountPercent ? (
                    <span className="rounded-full bg-[#d81b60] px-2.5 py-1 text-xs font-bold text-white">
                      {discountPercent}% OFF
                    </span>
                  ) : null}
                </div>
              ) : null}
            </div>

            {product.variants.length ? (
              <div className="mt-6 space-y-3">
                <p className="text-sm font-semibold text-slate-900">
                  Available Variants
                </p>

                <div className="grid grid-cols-2 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {product.variants.map((variant) => {
                    const active = variant.id === variantId;

                    return (
                      <button
                        key={variant.id}
                        type="button"
                        onClick={() => {
                          setVariantId(variant.id);
                          setQty(1);
                        }}
                        className={`rounded-2xl border px-4 py-3 text-left text-sm shadow-sm transition ${
                          active
                            ? "border-[#d81b60] bg-[#d81b60] text-white shadow-[0_14px_34px_-22px_rgba(216,27,96,0.75)]"
                            : "border-[#f8bbd0] bg-white text-slate-700 hover:border-[#d81b60] hover:bg-[#fff1f5]"
                        }`}
                      >
                        <div
                          className={`truncate text-sm ${
                            active ? "text-white" : "text-slate-700"
                          }`}
                        >
                          {variant.value}
                        </div>
                        <div
                          className={`mt-1 text-xs ${
                            active ? "text-white/75" : "text-slate-500"
                          }`}
                        >
                          Stock {variant.stock}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {product.description ? (
              <div className="mt-6 space-y-2 border-t border-[#f8d7e2] pt-5">
                <p className="font-semibold text-slate-900">Description</p>

                <p className="wrap-break-word whitespace-pre-line text-sm leading-7 text-slate-600">
                  {visibleDescription}
                </p>

                {shouldCollapseDescription ? (
                  <button
                    type="button"
                    onClick={() => setShowFullDescription((prev) => !prev)}
                    className="text-sm font-semibold text-[#ad1457] underline underline-offset-4"
                  >
                    {showFullDescription ? "See less" : "See more"}
                  </button>
                ) : null}
              </div>
            ) : (
              <p className="mt-6 text-sm text-slate-500">
                No description added yet.
              </p>
            )}
          </Card>

          {youtubeEmbedUrl ? (
            <Card className="overflow-hidden rounded-[28px] border-[#f8bbd0] bg-white p-4 shadow-[0_22px_70px_-58px_rgba(216,27,96,0.45)] sm:p-5">
              <div className="mb-3">
                <p className="font-semibold text-slate-900">Product Video</p>
                <p className="mt-1 text-sm text-slate-500">
                  Watch this product video before ordering.
                </p>
              </div>
              <div className="relative aspect-video overflow-hidden rounded-3xl bg-slate-950">
                <iframe
                  src={youtubeEmbedUrl}
                  title={`${product.name} video`}
                  className="absolute inset-0 h-full w-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              </div>
            </Card>
          ) : null}
        </div>

        <div className="min-w-0 lg:col-span-5">
          <div className="space-y-4 lg:sticky lg:top-6">
            <Card className="overflow-hidden rounded-[28px] border-[#f8bbd0] bg-white shadow-[0_28px_90px_-58px_rgba(216,27,96,0.5)]">
              <div className="border-b border-[#f8d7e2] bg-linear-to-r from-[#fff1f5] to-white px-5 py-5">
                <p className="text-sm font-medium text-[#ad1457]">
                  Checkout Summary
                </p>

                <div className="mt-2 flex flex-wrap items-end gap-x-3 gap-y-1">
                  <p className="text-4xl font-black tracking-tight text-slate-950">
                    ৳ {safeNumber(unitPrice, 0)}
                  </p>

                  {selectedVariantLabel ? (
                    <span className="pb-1 text-sm text-slate-500">
                      ({selectedVariantLabel})
                    </span>
                  ) : null}
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <span
                    className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
                      canBuy
                        ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
                        : "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                    }`}
                  >
                    {canBuy ? `${currentStock} in stock` : "Out of stock"}
                  </span>
                  {hasDiscount && discountPercent ? (
                    <span className="inline-flex rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#ad1457] ring-1 ring-[#f8bbd0]">
                      Save {discountPercent}%
                    </span>
                  ) : null}
                </div>
              </div>

              <div className="space-y-5 p-5">
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-slate-900">
                    Quantity
                  </p>
                  <div className="flex items-center rounded-2xl border border-[#f8bbd0] bg-[#fffafb] p-1">
                  <button
                    type="button"
                    onClick={dec}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white text-slate-700 shadow-sm transition hover:bg-[#fff1f5] disabled:opacity-50"
                    disabled={!canBuy || loading || buyingNow || qty <= 1}
                    aria-label="Decrease quantity"
                  >
                    <Minus className="h-4 w-4" />
                  </button>

                  <span className="min-w-12 flex-1 text-center text-base font-bold text-slate-950">
                    {qty}
                  </span>

                  <button
                    type="button"
                    onClick={inc}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white text-slate-700 shadow-sm transition hover:bg-[#fff1f5] disabled:opacity-50"
                    disabled={
                      !canBuy ||
                      loading ||
                      buyingNow ||
                      qty >= Math.max(1, currentStock || 1)
                    }
                    aria-label="Increase quantity"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                  </div>
                </div>

                <div className="space-y-3">
                <Button
                  className="h-12 w-full rounded-2xl bg-[#d81b60] text-sm font-bold text-white shadow-[0_18px_44px_-22px_rgba(216,27,96,0.9)] hover:bg-[#c2185b]"
                  onClick={() => void onAdd()}
                  disabled={!canBuy || loading || buyingNow}
                >
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  {!canBuy
                    ? "Out of Stock"
                    : loading
                      ? "Adding..."
                      : "Add to Cart"}
                </Button>

                <Button
                  type="button"
                  variant="secondary"
                  className="h-12 w-full rounded-2xl border border-[#f8bbd0] bg-[#fff1f5] text-sm font-bold text-[#ad1457] hover:bg-[#ffe4ec]"
                  onClick={() => void onBuyNow()}
                  disabled={!canBuy || loading || buyingNow}
                >
                  <Zap className="mr-2 h-4 w-4" />
                  {!canBuy
                    ? "Out of Stock"
                    : buyingNow
                      ? "Redirecting..."
                      : "Buy Now"}
                </Button>

                {!canBuy ? (
                  <Button
                    type="button"
                    className="h-12 w-full rounded-2xl bg-[#d81b60] text-sm font-bold text-white hover:bg-[#c2185b]"
                    onClick={() => setRequestOpen(true)}
                  >
                    Request Product
                  </Button>
                ) : null}

                <Button
                  type="button"
                  variant="secondary"
                  className="h-12 w-full rounded-2xl border border-slate-200 bg-white text-sm font-bold text-slate-800 hover:bg-slate-50"
                  onClick={onChatNow}
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Chat Now
                </Button>
                </div>
              </div>
            </Card>

            <Card className="rounded-[28px] border-[#f8bbd0] bg-white p-4 shadow-sm">
              <p className="font-semibold text-slate-900">Delivery & Support</p>
              <div className="mt-4 grid gap-3 text-sm text-slate-600">
                <div className="flex items-start gap-3 rounded-2xl bg-[#fff7fb] p-3">
                  <Truck className="mt-0.5 h-5 w-5 shrink-0 text-[#d81b60]" />
                  <div>
                    <div className="font-semibold text-slate-900">
                      Nationwide delivery
                    </div>
                    <div>Courier delivery across Bangladesh.</div>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-2xl bg-[#fff7fb] p-3">
                  <PackageCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#d81b60]" />
                  <div>
                    <div className="font-semibold text-slate-900">
                      Product guidance
                    </div>
                    <div>Call or chat before ordering if you need help.</div>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-2xl bg-[#fff7fb] p-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#d81b60]" />
                  <div>
                    <div className="font-semibold text-slate-900">
                      Secure checkout
                    </div>
                    <div>Your cart and checkout flow stay protected.</div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {requestOpen ? (
        <div className="fixed inset-0 z-120 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-5 shadow-xl">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-lg font-semibold text-slate-900">
                  Request Product
                </div>
                <div className="mt-1 text-sm text-slate-500">
                  This product is currently out of stock. Submit your request.
                </div>
              </div>

              <button
                type="button"
                onClick={() => setRequestOpen(false)}
                className="rounded-full border border-slate-200 px-3 py-1 text-sm"
              >
                Close
              </button>
            </div>

            <div className="mt-5 space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-medium">Product</label>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                  {product.name}
                  {selectedVariantLabel ? ` (${selectedVariantLabel})` : ""}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium">Name *</label>
                <input
                  className="h-11 w-full rounded-2xl border border-slate-200 px-3 text-sm outline-none"
                  value={requestName}
                  onChange={(e) => setRequestName(e.target.value)}
                  placeholder="Your name"
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium">Phone *</label>
                <input
                  className="h-11 w-full rounded-2xl border border-slate-200 px-3 text-sm outline-none"
                  value={requestPhone}
                  onChange={(e) => setRequestPhone(e.target.value)}
                  placeholder="Your phone number"
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium">Email</label>
                <input
                  className="h-11 w-full rounded-2xl border border-slate-200 px-3 text-sm outline-none"
                  value={requestEmail}
                  onChange={(e) => setRequestEmail(e.target.value)}
                  placeholder="Optional email"
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium">Message</label>
                <textarea
                  className="min-h-28 w-full rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none"
                  value={requestMessage}
                  onChange={(e) => setRequestMessage(e.target.value)}
                  placeholder="Optional message"
                />
              </div>

              <Button
                type="button"
                disabled={requestLoading}
                onClick={() => void submitRequest()}
                className="w-full bg-pink-600 text-white hover:bg-pink-700"
              >
                {requestLoading ? "Submitting..." : "Submit Request"}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
