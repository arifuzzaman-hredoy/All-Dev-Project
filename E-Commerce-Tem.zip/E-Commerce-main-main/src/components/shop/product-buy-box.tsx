"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "../ui/toast";

type Variant = {
  id: string;
  type: string;
  value: string;
  priceDiff: number | null;
};

type Props = {
  productId: string;
  name: string;
  sku: string;
  basePrice: number; // offerPrice ?? price
  stock: number;
  variants: Variant[];
  imageUrl?: string | null;
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number }>;
  };
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function isCartResponse(v: unknown): v is CartResponse {
  const o = v as Record<string, unknown>;
  const cart = o.cart as Record<string, unknown> | undefined;
  return !!cart && Array.isArray((cart as { items?: unknown }).items);
}

export default function ProductBuyBox({
  productId,
  name,
  sku,
  basePrice,
  stock,
  variants,
}: Props) {
  const { toast } = useToast();

  const [qty, setQty] = useState<number>(1);
  const [variantId, setVariantId] = useState<string | null>(variants?.[0]?.id ?? null);
  const [loading, setLoading] = useState<boolean>(false);

  const selectedVariant = useMemo(
    () => variants.find((v) => v.id === variantId) ?? null,
    [variants, variantId]
  );

  const unitPrice = useMemo(() => {
    const diff = selectedVariant?.priceDiff ?? 0;
    return basePrice + diff;
  }, [basePrice, selectedVariant]);

  const canBuy = stock > 0;

  const inc = () => setQty((q) => Math.min(Math.max(1, stock || 1), q + 1));
  const dec = () => setQty((q) => Math.max(1, q - 1));

  const addToCartApi = async (pid: string, q: number): Promise<void> => {
    const r = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", productId: pid, qty: q }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      const msg = (j as ErrorResponse | null)?.error || "Failed to add to cart";
      throw new Error(msg);
    }

    if (!isCartResponse(j)) {
      // response shape mismatch shouldn't break UX
      return;
    }
  };

  const onAdd = async (): Promise<void> => {
    if (!canBuy || loading) return;

    setLoading(true);
    try {
      await addToCartApi(productId, qty);

      window.dispatchEvent(new Event("rhc_cart_updated"));

      toast({
        variant: "success",
        title: "Added to cart",
        description: `${name} (x${qty}) added successfully.`,
      });
    } catch (e) {
      toast({
        variant: "error",
        title: "Failed",
        description: e instanceof Error ? e.message : "Failed to add to cart",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm text-muted-foreground">Price</p>
        <div className="flex items-end justify-between gap-3">
          <p className="text-2xl font-bold">৳ {safeNumber(unitPrice, 0)}</p>
          <p className="text-sm text-muted-foreground">Stock: {stock}</p>
        </div>
      </div>

      {variants?.length ? (
        <div className="space-y-2">
          <p className="text-sm font-medium">Variant</p>
          <select
            className="h-10 w-full rounded-md border bg-background px-3 text-sm"
            value={variantId ?? ""}
            onChange={(e) => setVariantId(e.target.value)}
          >
            {variants.map((v) => (
              <option key={v.id} value={v.id}>
                {v.type}: {v.value}
                {v.priceDiff ? ` (+৳ ${v.priceDiff})` : ""}
              </option>
            ))}
          </select>
        </div>
      ) : null}

      <div className="space-y-2">
        <p className="text-sm font-medium">Quantity</p>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={dec}
            className="h-9 w-9 rounded-md border bg-background hover:bg-black/5 disabled:opacity-50"
            aria-label="Decrease quantity"
            disabled={!canBuy || loading || qty <= 1}
          >
            −
          </button>

          <span className="min-w-[2ch] text-center">{qty}</span>

          <button
            type="button"
            onClick={inc}
            className="h-9 w-9 rounded-md border bg-background hover:bg-black/5 disabled:opacity-50"
            aria-label="Increase quantity"
            disabled={!canBuy || loading || qty >= Math.max(1, stock || 1)}
          >
            +
          </button>
        </div>
      </div>

      <Button className="w-full" onClick={() => void onAdd()} disabled={!canBuy || loading}>
        {!canBuy ? "Out of Stock" : loading ? "Adding..." : "Add to Cart"}
      </Button>

      <p className="text-xs text-muted-foreground">
        SKU: {sku} {selectedVariant ? `• Variant: ${selectedVariant.type} ${selectedVariant.value}` : ""}
      </p>
    </div>
  );
}