"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Filter,
  ShoppingCart,
  SlidersHorizontal,
  Star,
  Tags,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type Product = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  variants?: Array<{
    id: string;
    stock: number;
  }>;
  hasVariants?: boolean;
  variantsCount?: number;
};

type ProductsApiResponse = {
  items: Product[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number; variantId?: string | null }>;
  };
};

type ErrorResponse = {
  error: string;
};

type CategorySummary = {
  id: string;
  name: string;
  slug: string;
  imageUrl: string | null;
  productCount: number;
};

function safeNumber(value: unknown, fallback = 0) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function parseProduct(value: unknown): Product | null {
  const obj = value as Record<string, unknown>;

  const id = typeof obj.id === "string" ? obj.id : "";
  const name = typeof obj.name === "string" ? obj.name : "";
  const slug = typeof obj.slug === "string" ? obj.slug : "";

  if (!id || !name || !slug) return null;

  const rawImages = Array.isArray(obj.images) ? obj.images : [];
  const images = rawImages
    .map((img) => {
      const io = img as Record<string, unknown>;
      return {
        url: typeof io.url === "string" ? io.url : "",
      };
    })
    .filter((img) => img.url);
  const rawVariants = Array.isArray(obj.variants) ? obj.variants : [];
  const variants = rawVariants
    .map((variant) => {
      const vo = variant as Record<string, unknown>;
      return {
        id: typeof vo.id === "string" ? vo.id : "",
        stock: safeNumber(vo.stock, 0),
      };
    })
    .filter((variant) => variant.id);
  const countObj = obj._count as Record<string, unknown> | undefined;
  const variantsCount = safeNumber(obj.variantsCount ?? countObj?.variants, 0);

  return {
    id,
    name,
    slug,
    price: safeNumber(obj.price, 0),
    offerPrice: obj.offerPrice === null ? null : safeNumber(obj.offerPrice, 0),
    stock: safeNumber(obj.stock, 0),
    images,
    ratingAvg: safeNumber(obj.ratingAvg, 0),
    ratingCount: safeNumber(obj.ratingCount, 0),
    variants,
    variantsCount,
    hasVariants: variantsCount > 0 || obj.hasVariants === true,
  };
}

function parseProductsResponse(value: unknown): ProductsApiResponse {
  const obj = value as Record<string, unknown>;
  const rawItems = Array.isArray(obj.items) ? obj.items : [];

  const items = rawItems
    .map(parseProduct)
    .filter((item): item is Product => item !== null);

  return {
    items,
    total: safeNumber(obj.total, items.length),
    page: Math.max(1, safeNumber(obj.page, 1)),
    take: Math.max(1, safeNumber(obj.take, 24)),
    pages: Math.max(1, safeNumber(obj.pages, 1)),
  };
}

async function addToCart(productId: string, variantId?: string | null) {
  const res = await fetch("/api/cart", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      action: "add",
      productId,
      qty: 1,
      variantId: variantId ?? null,
    }),
  });

  const data: CartResponse | ErrorResponse | null = await res
    .json()
    .catch(() => null);

  if (!res.ok) {
    throw new Error(
      (data as ErrorResponse | null)?.error || "Add to cart failed",
    );
  }

  window.dispatchEvent(new Event("rhc_cart_updated"));
}

export default function CategoryProductsClient({
  categorySlug,
  categoryName,
  subcategories,
}: {
  categorySlug: string;
  categoryName: string;
  subcategories: CategorySummary[];
}) {
  const { toast } = useToast();
  const router = useRouter();
  const sp = useSearchParams();
  const [data, setData] = React.useState<ProductsApiResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [addingId, setAddingId] = React.useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = React.useState(false);
  const [min, setMin] = React.useState(sp.get("min") || "");
  const [max, setMax] = React.useState(sp.get("max") || "");

  const q = sp.get("q") || "";
  const sort = sp.get("sort") || "newest";
  const offer = sp.get("offer") || "";
  const inStock = sp.get("inStock") || "";
  const minParam = sp.get("min") || "";
  const maxParam = sp.get("max") || "";
  const take = Math.max(6, safeNumber(sp.get("take"), 24));
  const page = Math.max(1, safeNumber(sp.get("page"), 1));
  const queryString = sp.toString();

  React.useEffect(() => {
    setMin(sp.get("min") || "");
    setMax(sp.get("max") || "");
  }, [sp]);

  const pushParams = React.useCallback(
    (updates: Record<string, string>) => {
      const params = new URLSearchParams(sp.toString());

      for (const [key, value] of Object.entries(updates)) {
        const next = value.trim();
        if (next) params.set(key, next);
        else params.delete(key);
      }

      params.delete("cat");
      params.set("page", "1");

      const nextQuery = params.toString();
      router.push(
        nextQuery
          ? `/categories/${categorySlug}?${nextQuery}`
          : `/categories/${categorySlug}`,
      );
    },
    [categorySlug, router, sp],
  );

  const goPage = React.useCallback(
    (nextPage: number) => {
      const params = new URLSearchParams(sp.toString());
      params.delete("cat");
      params.set("page", String(nextPage));

      router.push(`/categories/${categorySlug}?${params.toString()}`);
    },
    [categorySlug, router, sp],
  );

  const clearFilters = React.useCallback(() => {
    router.push(`/categories/${categorySlug}`);
  }, [categorySlug, router]);

  function subcategoryHref(slug: string) {
    const params = new URLSearchParams(sp.toString());
    params.delete("cat");
    params.delete("page");
    const nextQuery = params.toString();
    return nextQuery
      ? `/categories/${slug}?${nextQuery}`
      : `/categories/${slug}`;
  }

  const load = React.useCallback(async () => {
    setLoading(true);

    try {
      const params = new URLSearchParams(queryString);
      params.set("cat", categorySlug);
      params.set("page", String(page));
      params.set("take", String(take));

      const res = await fetch(`/api/products?${params.toString()}`, {
        cache: "no-store",
      });

      const json = await res.json().catch(() => null);
      setData(parseProductsResponse(json));
    } catch {
      setData({
        items: [],
        total: 0,
        page: 1,
        take: 24,
        pages: 1,
      });
    } finally {
      setLoading(false);
    }
  }, [categorySlug, page, queryString, take]);

  React.useEffect(() => {
    void load();
  }, [load]);

  async function handleAdd(product: Product) {
    const firstVariant = product.variants?.[0] ?? null;
    const selectedStock = firstVariant ? firstVariant.stock : product.stock;
    const hasVariants = Boolean(
      product.hasVariants || (product.variantsCount ?? 0) > 0,
    );

    if (selectedStock <= 0 || addingId) return;

    setAddingId(product.id);

    try {
      await addToCart(product.id, hasVariants ? firstVariant?.id : null);

      toast({
        variant: "success",
        title: "Added to cart",
        description: `${product.name} added successfully.`,
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Could not add to cart.",
      });
    } finally {
      setAddingId(null);
    }
  }

  const items = data?.items ?? [];
  const pages = data?.pages ?? 1;
  const activeFiltersCount = [
    q,
    minParam || maxParam,
    sort !== "newest" ? sort : "",
    offer,
    inStock,
    take !== 24 ? String(take) : "",
  ].filter(Boolean).length;

  return (
    <section className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
      <div className="mb-8">
        <div className="mb-4">
          <h2 className="text-xl font-bold text-slate-900">Subcategories</h2>
          <p className="mt-1 text-sm text-slate-500">
            {categoryName} category-এর সব subcategory আগে দেখানো হচ্ছে।
          </p>
        </div>

        {subcategories.length ? (
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {subcategories.map((child) => (
              <Link
                key={child.id}
                href={subcategoryHref(child.slug)}
                className="group flex h-full flex-col overflow-hidden rounded-2xl border border-[#f8bbd0] bg-white text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="relative aspect-square w-full overflow-hidden bg-[#fde7ee]">
                  {child.imageUrl ? (
                    <Image
                      src={child.imageUrl}
                      alt={child.name}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center">
                      <ShoppingCart className="h-9 w-9 text-[#d81b60]/35" />
                    </div>
                  )}
                </div>

                <div className="flex flex-1 flex-col items-center justify-center px-3 py-4 text-center">
                  <h3 className="max-w-full truncate text-sm font-semibold text-slate-900 transition group-hover:text-[#ad1457] sm:text-base">
                    {child.name}
                  </h3>

                  <p className="mt-1 text-xs text-slate-500">
                    {child.productCount} products
                  </p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div></div>
        )}
      </div>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Suggested Products
          </h2>
          <div className="mt-1 text-sm text-slate-500">
            Showing{" "}
            <span className="font-semibold text-slate-900">{items.length}</span>{" "}
            of{" "}
            <span className="font-semibold text-slate-900">
              {data?.total ?? 0}
            </span>{" "}
            products
          </div>
        </div>

        <Link
          href="/categories"
          className="w-fit rounded-full bg-[#fff1f5] px-4 py-2 text-sm font-medium text-[#ad1457] ring-1 ring-[#f8bbd0] transition hover:bg-[#ffe4ec]"
        >
          Back to categories
        </Link>
      </div>

      <div className="mb-6 rounded-3xl border border-[#f8d7e2] bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm font-semibold text-slate-900">Filters</div>
            <p className="mt-1 text-sm text-slate-500">
              {categoryName} category-এর suggested products filter করুন।
            </p>
          </div>

          <Button
            type="button"
            variant="secondary"
            onClick={() => setFiltersOpen((prev) => !prev)}
            className="w-full rounded-2xl border-[#f8bbd0] bg-[#fff1f5] text-[#ad1457] hover:bg-[#ffe4ec] sm:w-fit"
          >
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            Filter Options
            {activeFiltersCount ? (
              <span className="ml-2 rounded-full bg-[#d81b60] px-2 py-0.5 text-xs text-white">
                {activeFiltersCount}
              </span>
            ) : null}
            {filtersOpen ? (
              <ChevronUp className="ml-2 h-4 w-4" />
            ) : (
              <ChevronDown className="ml-2 h-4 w-4" />
            )}
          </Button>
        </div>

        <div
          className={`mt-5 grid gap-3 ${
            filtersOpen ? "grid" : "hidden"
          } md:grid md:grid-cols-2 lg:grid-cols-5`}
        >
          <div className="space-y-1">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <Filter className="h-3.5 w-3.5" />
              Search
            </label>
            <Input
              key={q}
              defaultValue={q}
              placeholder="Search products..."
              className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  pushParams({ q: e.currentTarget.value });
                }
              }}
            />
          </div>

          <div className="space-y-1">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <Tags className="h-3.5 w-3.5" />
              Sort By
            </label>
            <select
              value={sort}
              onChange={(e) => pushParams({ sort: e.target.value })}
              className="h-10 w-full rounded-xl border border-[#f2d3de] bg-white px-3 text-sm focus:border-[#d81b60] focus:outline-none"
            >
              <option value="newest">Newest</option>
              <option value="best_selling">Best Selling</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-600">
              Min Price
            </label>
            <Input
              value={min}
              onChange={(e) => setMin(e.target.value)}
              type="number"
              placeholder="0"
              className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-600">
              Max Price
            </label>
            <Input
              value={max}
              onChange={(e) => setMax(e.target.value)}
              type="number"
              placeholder="∞"
              className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-600">
              Per Page
            </label>
            <select
              value={take}
              onChange={(e) => pushParams({ take: e.target.value })}
              className="h-10 w-full rounded-xl border border-[#f2d3de] bg-white px-3 text-sm focus:border-[#d81b60] focus:outline-none"
            >
              <option value="12">12 / page</option>
              <option value="24">24 / page</option>
              <option value="36">36 / page</option>
              <option value="48">48 / page</option>
            </select>
          </div>

          <div className="flex flex-wrap gap-2 md:col-span-2 lg:col-span-5">
            <button
              type="button"
              onClick={() =>
                pushParams({ offer: offer === "limited" ? "" : "limited" })
              }
              className={`rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                offer === "limited"
                  ? "bg-[#d81b60] text-white"
                  : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
              }`}
            >
              Limited Offers
            </button>

            <button
              type="button"
              onClick={() =>
                pushParams({ inStock: inStock === "1" ? "" : "1" })
              }
              className={`rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                inStock === "1"
                  ? "bg-[#d81b60] text-white"
                  : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
              }`}
            >
              In Stock Only
            </button>

            <Button
              type="button"
              onClick={() => pushParams({ min, max })}
              className="rounded-xl bg-[#d81b60] text-white hover:bg-[#c2185b]"
            >
              Apply Price
            </Button>

            <Button
              type="button"
              variant="secondary"
              onClick={clearFilters}
              className="rounded-xl border-[#f8bbd0] bg-[#fff1f5] text-[#ad1457] hover:bg-[#ffe4ec]"
            >
              Clear All
            </Button>
          </div>
        </div>

        {activeFiltersCount ? (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-sm">
            <span className="text-slate-500">Active:</span>
            {q ? (
              <button
                type="button"
                onClick={() => pushParams({ q: "" })}
                className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-[#ad1457]"
              >
                Search: {q}
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}
            {minParam || maxParam ? (
              <button
                type="button"
                onClick={() => pushParams({ min: "", max: "" })}
                className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-[#ad1457]"
              >
                Price: {minParam || "0"} - {maxParam || "∞"}
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}
            {offer === "limited" ? (
              <button
                type="button"
                onClick={() => pushParams({ offer: "" })}
                className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-[#ad1457]"
              >
                Limited offer
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}
            {inStock === "1" ? (
              <button
                type="button"
                onClick={() => pushParams({ inStock: "" })}
                className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-[#ad1457]"
              >
                In stock
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}
          </div>
        ) : null}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, idx) => (
            <div
              key={idx}
              className="animate-pulse rounded-3xl border border-[#f8bbd0] bg-white p-3"
            >
              <div className="aspect-square rounded-2xl bg-[#fff1f5]" />
              <div className="mt-3 h-4 w-3/4 rounded bg-[#ffe4ec]" />
              <div className="mt-2 h-4 w-1/2 rounded bg-[#ffe4ec]" />
            </div>
          ))}
        </div>
      ) : !items.length ? (
        <div className="rounded-3xl border border-dashed border-[#f8bbd0] bg-white p-12 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#fff1f5]">
            <ShoppingCart className="h-8 w-8 text-[#ad1457]" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">
            No products found
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            এই ক্যাটেগরিতে এখনো কোনো প্রোডাক্ট নেই।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {items.map((product) => {
            const image = product.images?.[0]?.url || "/placeholder.png";
            const finalPrice = product.offerPrice ?? product.price;
            const firstVariant = product.variants?.[0] ?? null;
            const selectedStock = firstVariant
              ? firstVariant.stock
              : product.stock;
            const discount =
              product.offerPrice && product.price > product.offerPrice
                ? Math.round(
                    ((product.price - product.offerPrice) / product.price) *
                      100,
                  )
                : null;

            return (
              <div
                key={product.id}
                className="group flex h-full flex-col overflow-hidden border border-[#f8bbd0] bg-white text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <Link href={`/products/${product.slug}`} className="block">
                  <div className="relative aspect-square overflow-hidden bg-[#fff1f5]">
                    <Image
                      src={image}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 768px) 50vw, 25vw"
                    />

                    {discount ? (
                      <div className="absolute left-3 top-3 rounded-full bg-[#d81b60] px-2 py-1 text-xs font-semibold text-white">
                        -{discount}%
                      </div>
                    ) : null}

                    <div
                      className={`absolute right-3 top-3 rounded-full px-2 py-1 text-xs font-semibold ${
                        product.stock > 0
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-red-50 text-red-700"
                      }`}
                    >
                      {product.stock > 0 ? "In Stock" : "Out"}
                    </div>
                  </div>
                </Link>

                <div className="flex flex-1 flex-col items-center justify-between p-3">
                  <Link
                    href={`/products/${product.slug}`}
                    className="flex w-full flex-1 flex-col items-center text-center"
                  >
                    <h3 className="line-clamp-2 w-full text-center text-sm font-semibold leading-5 text-slate-900 transition group-hover:text-[#ad1457]">
                      {product.name}
                    </h3>
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <span className="text-base font-bold text-slate-900">
                        ৳{finalPrice}
                      </span>

                      {product.offerPrice ? (
                        <span className="text-xs text-slate-400 line-through">
                          ৳{product.price}
                        </span>
                      ) : null}
                    </div>
                  </Link>

                  <Button
                    type="button"
                    className="mt-3 w-full rounded-2xl bg-[#d81b60] text-sm font-semibold text-white hover:bg-[#c2185b] disabled:cursor-not-allowed disabled:opacity-50"
                    disabled={selectedStock <= 0 || addingId === product.id}
                    onClick={() => void handleAdd(product)}
                  >
                    {selectedStock <= 0
                      ? "Out of Stock"
                      : addingId === product.id
                        ? "Adding..."
                        : "Add to Cart"}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {!loading && pages > 1 ? (
        <div className="mt-8 flex items-center justify-center gap-2">
          <Button
            type="button"
            variant="secondary"
            disabled={page <= 1}
            onClick={() => goPage(Math.max(1, page - 1))}
            className="rounded-2xl"
          >
            Previous
          </Button>

          <div className="rounded-2xl bg-[#fff1f5] px-4 py-2 text-sm font-medium text-[#ad1457]">
            Page {page} of {pages}
          </div>

          <Button
            type="button"
            variant="secondary"
            disabled={page >= pages}
            onClick={() => goPage(Math.min(pages, page + 1))}
            className="rounded-2xl"
          >
            Next
          </Button>
        </div>
      ) : null}
    </section>
  );
}
