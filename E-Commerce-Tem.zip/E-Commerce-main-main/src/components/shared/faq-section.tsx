import { unstable_noStore as noStore } from "next/cache";
import { prisma } from "@/lib/prisma";
import { Card } from "../ui/card";

type FaqItem = {
  question: string;
  answer: string;
};

function normalizeFaqs(input: unknown): FaqItem[] {
  if (typeof input === "string") {
    try {
      const parsed = JSON.parse(input);
      return normalizeFaqs(parsed);
    } catch {
      return [];
    }
  }

  if (!Array.isArray(input)) return [];

  return input
    .map((item) => {
      const o = item as Record<string, unknown>;
      return {
        question: typeof o.question === "string" ? o.question.trim() : "",
        answer: typeof o.answer === "string" ? o.answer.trim() : "",
      };
    })
    .filter((x) => x.question && x.answer);
}

export default async function FAQSection() {
  noStore();

  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: {
      aboutFaqs: true,
    },
  });

  const faqs = normalizeFaqs(settings?.aboutFaqs);

  return (
    <section className="px-4">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
          FAQ
        </p>
        <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
          Frequently Asked Questions
        </h2>
      </div>

      <div className="mx-auto mt-8 max-w-3xl space-y-3">
        {faqs.length ? (
          faqs.map((faq, index) => (
            <details
              key={`${faq.question}-${index}`}
              className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-5 shadow-[0_12px_34px_-24px_rgba(216,27,96,0.22)]"
            >
              <summary className="cursor-pointer list-none text-sm font-semibold text-slate-900">
                {faq.question}
              </summary>
              <div className="mt-3 text-sm leading-7 text-slate-700">
                {faq.answer}
              </div>
            </details>
          ))
        ) : (
          <Card className="rounded-3xl border border-[#f8bbd0] bg-white/80 p-6 text-sm text-slate-600">
            No FAQ added yet.
          </Card>
        )}
      </div>
    </section>
  );
}
