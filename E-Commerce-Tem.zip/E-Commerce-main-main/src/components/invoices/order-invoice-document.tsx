import Image from "next/image";
import { cn } from "@/lib/cn";

type InvoiceVariant = {
  type: string;
  value: string;
} | null;

type InvoiceItem = {
  id: string;
  productName: string;
  sku: string;
  unitPrice: number;
  qty: number;
  lineTotal: number;
  variant?: InvoiceVariant;
};

type InvoiceOrder = {
  id: string;
  publicOrderId?: string | null;
  createdAt: Date;
  status: string;
  paymentStatus: string;
  paymentMethod: string;
  name: string;
  phone: string;
  email: string | null;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  couponCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  courierName: string | null;
  trackingId: string | null;
  items: InvoiceItem[];
};

type ContactInfo = {
  whatsapp: string | null;
  email: string | null;
  website: string | null;
};

type Props = {
  order: InvoiceOrder;
  storeName: string;
  storeLogo: string;
  invoiceLabel?: string;
  subtitle?: string;
  showContactInfo?: boolean;
  showThankYou?: boolean;
  contactInfo?: ContactInfo;
};

function formatCurrency(amount: number) {
  return `৳ ${Math.max(0, Math.round(amount)).toLocaleString("en-BD")}`;
}

function formatDateTime(value: Date) {
  return new Intl.DateTimeFormat("en-BD", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(value);
}

function compactInvoiceMeta(itemCount: number) {
  if (itemCount >= 16) {
    return {
      shellPad: "p-3",
      sectionPad: "p-2.5",
      cellPad: "px-2 py-1.5",
      tableText: "text-[10.5px]",
      heading: "text-base",
      noteText: "text-[9.5px]",
      itemTitle: "text-[10.5px]",
      smallText: "text-[9.5px]",
      summaryText: "text-[10.5px]",
      thankYouPad: "px-3 py-2.5",
      logoWrap: "h-10 w-10",
      logoSize: 30,
    };
  }

  if (itemCount >= 10) {
    return {
      shellPad: "p-3",
      sectionPad: "p-2.5",
      cellPad: "px-2 py-1.5",
      tableText: "text-[11px]",
      heading: "text-base",
      noteText: "text-[10px]",
      itemTitle: "text-[11px]",
      smallText: "text-[10px]",
      summaryText: "text-[11px]",
      thankYouPad: "px-3 py-2.5",
      logoWrap: "h-11 w-11",
      logoSize: 34,
    };
  }

  if (itemCount >= 6) {
    return {
      shellPad: "p-3.5",
      sectionPad: "p-3",
      cellPad: "px-2.5 py-2",
      tableText: "text-[12px]",
      heading: "text-lg",
      noteText: "text-[10px]",
      itemTitle: "text-[12px]",
      smallText: "text-[10px]",
      summaryText: "text-[12px]",
      thankYouPad: "px-4 py-3",
      logoWrap: "h-12 w-12",
      logoSize: 38,
    };
  }

  return {
    shellPad: "p-4",
    sectionPad: "p-3.5",
    cellPad: "px-3 py-2.5",
    tableText: "text-[13px]",
    heading: "text-xl",
    noteText: "text-[11px]",
    itemTitle: "text-[13px]",
    smallText: "text-[11px]",
    summaryText: "text-xs",
    thankYouPad: "px-5 py-4",
    logoWrap: "h-14 w-14",
    logoSize: 44,
  };
}

function makeAddress(order: InvoiceOrder) {
  return [order.addressLine1, order.addressLine2, order.area, order.city]
    .filter(Boolean)
    .join(", ");
}

function cleanContactValue(value: string | null | undefined) {
  const v = value?.trim();
  return v ? v : null;
}

function normalizeEmailAddress(input: string | null | undefined) {
  const v = cleanContactValue(input);
  if (!v) return null;

  const match = v.match(/<([^>]+)>/);
  if (match?.[1]) return match[1];

  return v;
}

function normalizeWebsite(input: string | null | undefined) {
  const v = cleanContactValue(input);
  if (!v) return null;
  return v.replace(/^https?:\/\//, "").replace(/\/+$/, "");
}

function renderVariant(variant?: InvoiceVariant) {
  if (!variant?.type || !variant?.value) return null;
  return `${variant.type}: ${variant.value}`;
}

export default function OrderInvoiceDocument({
  order,
  storeName,
  storeLogo,
  subtitle = "Official order invoice",
  showContactInfo = false,
  showThankYou = false,
  contactInfo,
}: Props) {
  const invoiceNo =
    order.publicOrderId?.trim() || order.id.slice(-8).toUpperCase();
  const address = makeAddress(order);
  const ui = compactInvoiceMeta(order.items.length);

  const whatsapp = cleanContactValue(contactInfo?.whatsapp);
  const email = normalizeEmailAddress(contactInfo?.email);
  const website = normalizeWebsite(contactInfo?.website);

  return (
    <div
      className={cn(
        "invoice-card rounded-[22px] border border-black/10 bg-white shadow-sm",
        ui.shellPad,
      )}
    >
      <div className="flex items-center justify-between gap-3 border-b border-black/10 pb-3">
        <div className="flex min-w-0 items-center gap-3">
          <div
            className={cn(
              "flex items-center justify-center overflow-hidden rounded-2xl border border-black/10 bg-white p-1.5",
              ui.logoWrap,
            )}
          >
            <Image
              src={storeLogo}
              alt={`${storeName} logo`}
              width={ui.logoSize}
              height={ui.logoSize}
              className="max-h-full max-w-full object-contain"
            />
          </div>

          <div className="min-w-0">
            <div
              className={cn(
                "truncate font-bold tracking-tight text-black",
                ui.heading,
              )}
            >
              {storeName}
            </div>
            <div className={cn("mt-0.5 text-black/55", ui.smallText)}>
              {subtitle}
            </div>
          </div>
        </div>

        {showThankYou && (
          <div className="hidden shrink-0 rounded-full border border-black/10 bg-black/2.5 px-4 py-2 text-xs font-semibold text-black sm:block">
            Customer Copy
          </div>
        )}

        <div className="shrink-0 text-right">
          <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-black/45">
            Invoice No
          </div>
          <div className="mt-0.5 text-base font-bold text-black">
            #{invoiceNo}
          </div>
          <div className={cn("mt-0.5 text-black/60", ui.smallText)}>
            Order ID: {order.publicOrderId?.trim() || order.id}
          </div>
          <div className={cn("text-black/60", ui.smallText)}>
            Date: {formatDateTime(order.createdAt)}
          </div>
        </div>
      </div>

      <div className="invoice-meta-grid mt-3 grid gap-3 md:grid-cols-[1.1fr_0.9fr]">
        <div
          className={cn(
            "rounded-2xl border border-black/10 bg-black/2.5",
            ui.sectionPad,
          )}
        >
          <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/50">
            Customer Information
          </div>

          <div className="mt-2 space-y-1.5">
            <div className="font-semibold text-black">{order.name}</div>
            <div className={cn("text-black/75", ui.smallText)}>
              {order.phone}
            </div>
            {order.email ? (
              <div className={cn("text-black/75", ui.smallText)}>
                {order.email}
              </div>
            ) : null}
            <div className={cn("leading-5 text-black/75", ui.smallText)}>
              {address}
            </div>
            {order.note ? (
              <div
                className={cn(
                  "rounded-xl border border-dashed border-black/12 bg-white/80 px-2.5 py-2 text-black/60",
                  ui.noteText,
                )}
              >
                Note: {order.note}
              </div>
            ) : null}
          </div>
        </div>

        <div
          className={cn(
            "rounded-2xl border border-black/10 bg-black/2.5",
            ui.sectionPad,
          )}
        >
          <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/50">
            Order & Courier Information
          </div>

          <div
            className={cn(
              "mt-2 grid gap-1.5 leading-5 text-black/75",
              ui.smallText,
            )}
          >
            <div>
              <span className="font-medium text-black">Order Status:</span>{" "}
              {order.status}
            </div>
            <div>
              <span className="font-medium text-black">Payment:</span>{" "}
              {order.paymentMethod} / {order.paymentStatus}
            </div>
            <div>
              <span className="font-medium text-black">Courier:</span>{" "}
              {order.courierName ?? "Not assigned"}
            </div>
            <div>
              <span className="font-medium text-black">Tracking ID:</span>{" "}
              {order.trackingId ?? "Pending"}
            </div>
            {order.couponCode ? (
              <div>
                <span className="font-medium text-black">Coupon:</span>{" "}
                {order.couponCode}
              </div>
            ) : null}
            <div>
              <span className="font-medium text-black">Items:</span>{" "}
              {order.items.length}
            </div>
          </div>
        </div>
      </div>

      <div className="invoice-table-wrap mt-3 overflow-hidden rounded-2xl border border-black/10">
        <table
          className={cn("invoice-table w-full border-collapse", ui.tableText)}
        >
          <thead className="bg-black/4 text-black">
            <tr>
              <th className={cn("text-left font-semibold", ui.cellPad)}>
                Item
              </th>
              <th className={cn("text-left font-semibold", ui.cellPad)}>
                Details
              </th>
              <th className={cn("text-right font-semibold", ui.cellPad)}>
                Unit
              </th>
              <th className={cn("text-right font-semibold", ui.cellPad)}>
                Qty
              </th>
              <th className={cn("text-right font-semibold", ui.cellPad)}>
                Total
              </th>
            </tr>
          </thead>

          <tbody>
            {order.items.map((item) => {
              const variantLabel = renderVariant(item.variant);

              return (
                <tr
                  key={item.id}
                  className="border-t border-black/10 align-top"
                >
                  <td className={cn("text-black", ui.cellPad)}>
                    <div
                      className={cn(
                        "font-semibold leading-4 text-black",
                        ui.itemTitle,
                      )}
                    >
                      {item.productName}
                    </div>
                  </td>

                  <td className={cn("text-black/65", ui.cellPad)}>
                    <div className={cn("leading-4", ui.smallText)}>
                      <div>SKU: {item.sku}</div>
                      <div>Variant: {variantLabel ?? "Standard"}</div>
                    </div>
                  </td>

                  <td className={cn("text-right text-black/75", ui.cellPad)}>
                    {formatCurrency(item.unitPrice)}
                  </td>

                  <td className={cn("text-right text-black/75", ui.cellPad)}>
                    {item.qty}
                  </td>

                  <td
                    className={cn(
                      "text-right font-semibold text-black",
                      ui.cellPad,
                    )}
                  >
                    {formatCurrency(item.lineTotal)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="invoice-summary-grid mt-3 grid gap-3 md:grid-cols-[1fr_260px]">
        <div className="invoice-note-card min-h-19 rounded-2xl border border-black/10 bg-black/2.5 p-3">
          {showContactInfo ? (
            <>
              <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/50">
                Contact Information
              </div>

              <div
                className={cn(
                  "mt-2 flex flex-col gap-1.5 text-black/75",
                  ui.smallText,
                )}
              >
                <div>
                  <span className="font-medium text-black">WhatsApp:</span>{" "}
                  {whatsapp ?? "Not provided"}
                </div>
                <div>
                  <span className="font-medium text-black">Email:</span>{" "}
                  {email ?? "Not provided"}
                </div>
                <div>
                  <span className="font-medium text-black">Website:</span>{" "}
                  {website ?? "Not provided"}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-black/50">
                Notes
              </div>
              <div className={cn("mt-2 text-black/65", ui.smallText)}>
                This invoice is system generated and valid without signature.
              </div>
            </>
          )}
        </div>

        <div className="invoice-summary-card rounded-2xl border border-black/10 bg-black/2.5 p-3">
          <div className={cn("space-y-1", ui.summaryText)}>
            <div className="flex items-center justify-between">
              <span className="text-black/60">Subtotal</span>
              <span className="font-medium text-black">
                {formatCurrency(order.subtotal)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-black/60">Discount</span>
              <span className="font-medium text-black">
                {formatCurrency(order.discount)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-black/60">Shipping</span>
              <span className="font-medium text-black">
                {formatCurrency(order.shipping)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-black/60">Tax</span>
              <span className="font-medium text-black">
                {formatCurrency(order.tax)}
              </span>
            </div>
            <div className="mt-2 flex items-center justify-between border-t border-dashed border-black/15 pt-2 text-[13px]">
              <span className="font-semibold text-black">Grand Total</span>
              <span className="font-bold text-black">
                {formatCurrency(order.total)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {showThankYou ? (
        <div
          className={cn(
            "invoice-thankyou mt-3 overflow-hidden rounded-[20px] border border-[#f8bbd0] bg-linear-to-r from-[#fff1f5] via-white to-[#fff7fb]",
            ui.thankYouPad,
          )}
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-[#ad1457]/70">
                Thank You
              </div>
              <div className="mt-1 text-lg font-bold tracking-tight text-[#ad1457]">
                Thank you for shopping with us.
              </div>
              <div
                className={cn("mt-1 max-w-2xl text-slate-600", ui.smallText)}
              >
                We appreciate your trust. Please keep this customer copy for
                your records and future support needs.
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
}
