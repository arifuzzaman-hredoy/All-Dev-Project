"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { ShoppingCart, Star } from "lucide-react";

import WishlistButton from "@/components/wishlist/wishlist-button";
import { useToast } from "@/components/ui/toast";

export type ProductCardProduct = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  category?: { name: string } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  hasVariants?: boolean;
  variantsCount?: number;
  variants?: Array<{
    id: string;
    stock: number;
  }>;
};

type HomeProductCardProps = {
  product: ProductCardProduct;
  isWishlisted?: boolean;
  onWishlistChange?: (next: boolean) => void;
  isAuthenticated?: boolean;
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number; variantId?: string | null }>;
  };
};

type ErrorResponse = { error: string };

function isCartResponse(v: unknown): v is CartResponse {
  const o = v as Record<string, unknown>;
  const cart = o.cart as Record<string, unknown> | undefined;
  return !!cart && Array.isArray((cart as { items?: unknown }).items);
}

export default function HomeProductCard({
  product,
  isWishlisted = false,
  onWishlistChange,
  isAuthenticated = false,
}: HomeProductCardProps) {
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  const img = product.images?.[0]?.url;
  const finalPrice = product.offerPrice ?? product.price;
  const firstVariant = product.variants?.[0] ?? null;
  const hasVariants = Boolean(
    product.hasVariants ||
      (product.variantsCount ?? 0) > 0 ||
      (product.variants?.length ?? 0) > 0,
  );
  const discount = product.offerPrice
    ? Math.round(((product.price - product.offerPrice) / product.price) * 100)
    : null;

  const selectedStock = firstVariant ? firstVariant.stock : product.stock;
  const canAddToCart = selectedStock > 0 && !adding;

  const addToCartApi = async (variantId?: string | null): Promise<void> => {
    const r = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "add",
        productId: product.id,
        qty: 1,
        variantId: variantId ?? null,
      }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      const msg = (j as ErrorResponse | null)?.error || "Failed to add to cart";
      throw new Error(msg);
    }

    if (!isCartResponse(j)) return;
  };

  const handleAddToCart = async (
    e: React.MouseEvent<HTMLButtonElement>,
  ): Promise<void> => {
    e.preventDefault();
    e.stopPropagation();

    if (!canAddToCart) return;

    setAdding(true);

    try {
      await addToCartApi(hasVariants ? firstVariant?.id : null);
      window.dispatchEvent(new Event("rhc_cart_updated"));

      toast({
        variant: "success",
        title: "Added to cart",
        description: `${product.name} added successfully.`,
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Failed to add to cart",
      });
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="group relative h-full w-full">
      {/* Wishlist */}
      {onWishlistChange && (
        <div className="absolute right-2 top-2 z-20">
          <WishlistButton
            productId={product.id}
            initialWishlisted={isWishlisted}
            isAuthenticated={isAuthenticated}
            onChange={onWishlistChange}
          />
        </div>
      )}

      <Link
        href={`/products/${product.slug}`}
        className="flex h-full w-full flex-col overflow-hidden rounded-2xl bg-white text-center shadow-sm ring-1 ring-black/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
      >
        {/* IMAGE */}
        <div className="relative aspect-square w-full overflow-hidden bg-gray-50">
          {img ? (
            <Image
              src={img}
              alt={product.name}
              fill
              className="object-contain transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full items-center justify-center">
              <ShoppingCart className="h-8 w-8 text-gray-300" />
            </div>
          )}

          {/* DISCOUNT */}
          {discount && (
            <div className="absolute left-2 top-2 rounded-full bg-rose-600 px-2 py-0.5 text-[10px] font-semibold text-white">
              -{discount}%
            </div>
          )}

          {/* RATING */}
          <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[10px] shadow">
            <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
            {product.ratingAvg?.toFixed(1) ?? "0.0"}
          </div>
        </div>

        {/* CONTENT */}
        <div className="flex min-w-0 flex-1 flex-col items-center justify-between p-3 text-center">
          <div className="flex w-full min-w-0 flex-col items-center">
            {/* CATEGORY */}
            <span className="max-w-full truncate text-center text-[10px] text-gray-400">
              {product.category?.name ?? "Uncategorized"}
            </span>

            {/* NAME */}
            <h3 className="line-clamp-2 min-w-0 text-center text-[17px] font-semibold leading-snug text-gray-800 transition group-hover:text-rose-600">
              {product.name}
            </h3>

            {/* PRICE */}
            <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
              <span className="text-base font-bold text-gray-900">
                ৳{finalPrice}
              </span>

              {product.offerPrice && (
                <span className="text-xs text-gray-400 line-through">
                  ৳{product.price}
                </span>
              )}
            </div>
          </div>

          {/* BUTTON */}
          <button
            onClick={(e) => void handleAddToCart(e)}
            disabled={!canAddToCart}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-rose-500 py-2 text-xs font-semibold text-white transition hover:bg-rose-600 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <ShoppingCart className="h-4 w-4" />
            {selectedStock <= 0
              ? "Out of Stock"
              : adding
                ? "Adding..."
                : "Add to Cart"}
          </button>
        </div>
      </Link>
    </div>
  );
}
