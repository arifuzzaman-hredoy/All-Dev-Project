import Link from "next/link";
import { ArrowRight } from "lucide-react";

import CategoryProductSlider from "@/components/home/category-product-slider";
import HomeProductCard from "@/components/products/home-product-card";
import type { HomeSliderProduct } from "@/lib/services/home-products";

type ProductSliderSectionProps = {
  title: string;
  subtitle?: string;
  products: HomeSliderProduct[];
  viewAllHref?: string;
};

export default function ProductSliderSection({
  title,
  subtitle,
  products,
  viewAllHref,
}: ProductSliderSectionProps) {
  if (!products.length) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 pt-12 lg:px-6">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl font-semibold text-gray-900 md:text-3xl">
            {title}
          </h2>
          {subtitle ? (
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          ) : null}
        </div>

        {viewAllHref ? (
          <Link
            href={viewAllHref}
            className="group flex shrink-0 items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] ring-1 ring-[#f8bbd0] transition-all hover:bg-[#ffe4ec] hover:text-[#8e1042]"
          >
            <span>View all</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        ) : null}
      </div>

      <CategoryProductSlider>
        {products.map((product) => (
          <div
            key={product.id}
            className="w-40 shrink-0 sm:w-44 md:w-48 lg:w-52"
          >
            <HomeProductCard product={product} />
          </div>
        ))}
      </CategoryProductSlider>
    </section>
  );
}
