"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import HomeProductCard from "@/components/products/home-product-card";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Star,
  Package,
  Filter,
  Grid3x3,
  List,
  ChevronDown,
  ChevronUp,
  FolderTree,
  SlidersHorizontal,
  Tags,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import WishlistButton from "@/components/wishlist/wishlist-button";
import {
  buildCategoryTree,
  type CategoryTreeItem,
  type CategoryTreeNode,
} from "@/lib/category-tree";

type Category = CategoryTreeItem;

type Product = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured?: boolean;
  category?: {
    id: string;
    name: string;
    slug?: string;
    parent?: { id: string; name: string; slug: string } | null;
  } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  hasVariants?: boolean;
  variantsCount?: number;
  variants?: Array<{
    id: string;
    stock: number;
  }>;
};

type ProductsApiResponse = {
  items: Product[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

type WishlistListResponse = {
  items: Array<{
    id: string;
    product: {
      id: string;
    };
    createdAt: string;
  }>;
};

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeNullableNumber(v: unknown): number | null {
  if (v === null) return null;
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function safeArray<T>(v: unknown, map: (x: unknown) => T): T[] {
  return Array.isArray(v) ? v.map(map) : [];
}

function parseProduct(input: unknown): Product | null {
  const o = input as Record<string, unknown>;
  const id = safeString(o.id);
  const name = safeString(o.name);
  const slug = safeString(o.slug);

  if (!id || !name || !slug) return null;

  const categoryObj = o.category as Record<string, unknown> | null | undefined;
  const category =
    categoryObj && typeof categoryObj === "object"
      ? {
          id: safeString(categoryObj.id),
          name: safeString(categoryObj.name),
          slug: safeString(categoryObj.slug),
          parent:
            categoryObj.parent && typeof categoryObj.parent === "object"
              ? {
                  id: safeString(
                    (categoryObj.parent as Record<string, unknown>).id,
                  ),
                  name: safeString(
                    (categoryObj.parent as Record<string, unknown>).name,
                  ),
                  slug: safeString(
                    (categoryObj.parent as Record<string, unknown>).slug,
                  ),
                }
              : null,
        }
      : null;

  const images = safeArray(o.images, (img) => {
    const io = img as Record<string, unknown>;
    return { url: safeString(io.url) };
  }).filter((x) => !!x.url);

  const countObj = o._count as Record<string, unknown> | undefined;

  const variantsCount = safeNumber(o.variantsCount ?? countObj?.variants, 0);
  const variants = safeArray(o.variants, (variant) => {
    const vo = variant as Record<string, unknown>;
    return {
      id: safeString(vo.id),
      stock: safeNumber(vo.stock, 0),
    };
  }).filter((variant) => variant.id);

  return {
    id,
    name,
    slug,
    price: safeNumber(o.price, 0),
    offerPrice: safeNullableNumber(o.offerPrice),
    stock: safeNumber(o.stock, 0),
    isFeatured: !!o.isFeatured,
    category: category?.name ? category : null,
    images,
    ratingAvg: safeNumber(o.ratingAvg, 0),
    ratingCount: safeNumber(o.ratingCount, 0),
    variantsCount,
    hasVariants: variantsCount > 0 || o.hasVariants === true,
    variants,
  };
}

function parseProductsResponse(input: unknown): ProductsApiResponse {
  const o = input as Record<string, unknown>;

  const items = safeArray(o.items, (x) => parseProduct(x)).filter(
    (p): p is Product => p !== null,
  );

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 12)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

function parseWishlistIds(input: unknown): Set<string> {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const ids = raw
    .map((item) => item as Record<string, unknown>)
    .map((item) => {
      const product = item.product as Record<string, unknown> | undefined;
      return product ? safeString(product.id) : "";
    })
    .filter(Boolean);

  return new Set(ids);
}

export default function ProductsBrowser({
  categories,
}: {
  categories: Category[];
}) {
  const router = useRouter();
  const sp = useSearchParams();
  const { status } = useSession();

  const [loading, setLoading] = React.useState(false);
  const [data, setData] = React.useState<ProductsApiResponse | null>(null);
  const [mobileCategoriesOpen, setMobileCategoriesOpen] = React.useState(false);
  const [mobileFiltersExpanded, setMobileFiltersExpanded] =
    React.useState(false);
  const [viewMode, setViewMode] = React.useState<"grid" | "list">("grid");
  const [expandedParents, setExpandedParents] = React.useState<
    Record<string, boolean>
  >({});
  const [wishIds, setWishIds] = React.useState<Set<string>>(new Set());

  const [min, setMin] = React.useState(sp.get("min") || "");
  const [max, setMax] = React.useState(sp.get("max") || "");

  const q = sp.get("q") || "";
  const sortParam = sp.get("sort") || "newest";
  const sort = sortParam === "best-seller" ? "best_selling" : sortParam;
  const cat = sp.get("cat") || "";
  const featured = sp.get("featured") || "";
  const offer = sp.get("offer") || "";
  const inStock = sp.get("inStock") || "";
  const takeFromUrl = Number(sp.get("take") || "12") || 12;
  const pageFromUrl = Number(sp.get("page") || "1") || 1;

  const tree: CategoryTreeNode[] = React.useMemo(
    () => buildCategoryTree(categories),
    [categories],
  );

  React.useEffect(() => {
    setMin(sp.get("min") || "");
    setMax(sp.get("max") || "");
  }, [sp]);

  React.useEffect(() => {
    const next: Record<string, boolean> = {};
    tree.forEach((parent) => {
      next[parent.id] =
        parent.slug === cat ||
        parent.children.some((child) => child.slug === cat);
    });
    setExpandedParents((prev) => ({ ...prev, ...next }));
  }, [tree, cat]);

  React.useEffect(() => {
    const loadWishlist = async () => {
      if (status !== "authenticated") {
        setWishIds(new Set());
        return;
      }

      const res = await fetch("/api/wishlist", { cache: "no-store" });
      const json: WishlistListResponse | { error?: string } | null = await res
        .json()
        .catch(() => null);

      setWishIds(parseWishlistIds(json));
    };

    void loadWishlist();
  }, [status]);

  const queryString = sp.toString();

  const fetchData = React.useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(`/api/products?${queryString}`, {
        cache: "no-store",
      });
      const j: unknown = await r.json();
      setData(parseProductsResponse(j));
    } catch {
      setData({
        items: [],
        total: 0,
        page: 1,
        take: 12,
        pages: 1,
      });
    } finally {
      setLoading(false);
    }
  }, [queryString]);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const setParam = React.useCallback(
    (key: string, value: string): void => {
      const params = new URLSearchParams(sp.toString());

      if (value.trim()) params.set(key, value.trim());
      else params.delete(key);

      if (key !== "page") params.set("page", "1");

      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const setManyParams = React.useCallback(
    (updates: Record<string, string>) => {
      const params = new URLSearchParams(sp.toString());

      for (const [key, value] of Object.entries(updates)) {
        if (value.trim()) params.set(key, value.trim());
        else params.delete(key);
      }

      params.set("page", "1");
      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const goPage = React.useCallback(
    (p: number): void => {
      const params = new URLSearchParams(sp.toString());
      params.set("page", String(p));
      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const clearAll = React.useCallback((): void => {
    router.push("/products");
  }, [router]);

  const activeFiltersCount = React.useMemo(() => {
    let count = 0;
    if (q) count++;
    if (min || max) count++;
    if (cat) count++;
    if (sort !== "newest") count++;
    if (featured === "1") count++;
    if (offer === "limited") count++;
    if (inStock === "1") count++;
    if (takeFromUrl !== 12) count++;
    return count;
  }, [q, min, max, cat, sort, featured, offer, inStock, takeFromUrl]);

  const activeCatName = React.useMemo(() => {
    if (!cat) return "All Categories";
    const found = categories.find((c) => c.slug === cat);
    if (!found) return "Category";

    if (!found.parentId) return found.name;

    const parent = categories.find((c) => c.id === found.parentId);
    return parent ? `${parent.name} → ${found.name}` : found.name;
  }, [cat, categories]);

  const pages = data?.pages ?? 1;
  const currentPage = clamp(data?.page ?? pageFromUrl, 1, pages);

  const pageButtons = React.useMemo(() => {
    const last = pages;
    const p = currentPage;

    const set = new Set<number>();
    set.add(1);
    set.add(last);

    for (let i = p - 1; i <= p + 1; i++) {
      if (i >= 1 && i <= last) set.add(i);
    }

    const arr = Array.from(set).sort((a, b) => a - b);

    const out: number[] = [];
    for (let i = 0; i < arr.length; i++) {
      out.push(arr[i]);
      if (i < arr.length - 1 && arr[i + 1] - arr[i] > 1) out.push(0);
    }

    return out;
  }, [pages, currentPage]);

  const toggleParent = (id: string) => {
    setExpandedParents((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const renderCategoryTree = (mobile = false) => (
    <div className="space-y-1.5">
      <button
        onClick={() => {
          setParam("cat", "");
          if (mobile) setMobileCategoriesOpen(false);
        }}
        className={`flex w-full items-center rounded-2xl border px-4 py-3 text-left transition-all ${
          !cat
            ? "border-[#d81b60] bg-[#fff1f5] text-[#ad1457]"
            : "border-transparent bg-white text-slate-700 hover:bg-[#fff7fb]"
        }`}
      >
        <span className="text-sm font-medium">All Categories</span>
      </button>

      {tree.map((parent) => {
        const isParentActive = cat === parent.slug;
        const hasChildren = parent.children.length > 0;
        const isOpen = expandedParents[parent.id];

        return (
          <div
            key={parent.id}
            className="overflow-hidden rounded-2xl border border-[#f3d4df] bg-white"
          >
            <div className="flex items-stretch">
              <button
                onClick={() => {
                  setParam("cat", parent.slug);
                  if (mobile) setMobileCategoriesOpen(false);
                }}
                className={`flex-1 px-4 py-3 text-left transition-all ${
                  isParentActive
                    ? "bg-[#fff1f5] text-[#ad1457]"
                    : "text-slate-800 hover:bg-[#fff7fb]"
                }`}
              >
                <span className="text-sm font-medium">{parent.name}</span>
              </button>

              {hasChildren ? (
                <button
                  type="button"
                  onClick={() => toggleParent(parent.id)}
                  className="border-l border-[#f3d4df] px-3 text-slate-500 transition hover:bg-[#fff7fb]"
                >
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
              ) : null}
            </div>

            {hasChildren && isOpen ? (
              <div className="border-t border-[#f8e4eb] bg-[#fffafb] px-2 py-2">
                <div className="space-y-1">
                  {parent.children.map((child) => {
                    const isChildActive = cat === child.slug;

                    return (
                      <button
                        key={child.id}
                        onClick={() => {
                          setParam("cat", child.slug);
                          if (mobile) setMobileCategoriesOpen(false);
                        }}
                        className={`flex w-full items-center rounded-xl px-3 py-2.5 text-left text-sm transition-all ${
                          isChildActive
                            ? "bg-[#d81b60] text-white"
                            : "text-slate-700 hover:bg-white"
                        }`}
                      >
                        <span className="mr-2 text-xs opacity-70">↳</span>
                        <span>{child.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}
          </div>
        );
      })}
    </div>
  );

  return (
    <main className="min-h-screen overflow-x-hidden bg-linear-to-b from-[#fff7fb] via-white to-white">
      <section className="sticky top-0 z-30 border-b border-[#f8bbd0] bg-white/75 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-4 lg:px-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Link
                  href="/"
                  className="transition-colors hover:text-[#ad1457]"
                >
                  Home
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span className="font-medium text-slate-900">Products</span>
              </div>
              <h1 className="mt-1 text-2xl font-bold text-slate-900 md:text-3xl">
                Browse Products
              </h1>
              <p className="mt-1 max-w-2xl text-sm text-slate-600">
                Explore the catalog with the same soft pink brand language used
                throughout the homepage.
              </p>
            </div>

            <div className="flex items-center gap-2 md:hidden">
              <Button
                variant="secondary"
                onClick={() => setMobileCategoriesOpen(true)}
                className="flex-1 rounded-full border-[#f8bbd0]"
              >
                <FolderTree className="mr-2 h-4 w-4" />
                Categories
                {cat ? (
                  <span className="ml-2 rounded-full bg-[#d81b60] px-2 py-0.5 text-xs text-white">
                    1
                  </span>
                ) : null}
              </Button>

              <Button
                variant="secondary"
                onClick={() =>
                  setViewMode(viewMode === "grid" ? "list" : "grid")
                }
                className="rounded-full border-[#f8bbd0]"
              >
                {viewMode === "grid" ? (
                  <List className="h-4 w-4" />
                ) : (
                  <Grid3x3 className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-3 py-6 pb-24 sm:px-4 lg:px-6">
        {activeFiltersCount > 0 ? (
          <div className="mb-6 flex flex-wrap items-center gap-2">
            <span className="text-sm text-slate-500">Active filters:</span>

            {q ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>Search: {q}</span>
                <button onClick={() => setParam("q", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {cat ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>Category: {activeCatName}</span>
                <button onClick={() => setParam("cat", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {featured === "1" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>Featured</span>
                <button onClick={() => setParam("featured", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {offer === "limited" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>Limited offer</span>
                <button onClick={() => setParam("offer", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {inStock === "1" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>In stock</span>
                <button onClick={() => setParam("inStock", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {min || max ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>
                  Price: {min || "0"} - {max || "∞"}
                </span>
                <button onClick={() => setManyParams({ min: "", max: "" })}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {sort !== "newest" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff1f5] px-3 py-1.5 text-sm text-[#ad1457]">
                <span>Sort: {sort.replace("_", " ")}</span>
                <button onClick={() => setParam("sort", "newest")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            <Button
              variant="ghost"
              onClick={clearAll}
              className="text-sm text-[#ad1457] hover:text-[#8e1042]"
            >
              Clear all
            </Button>
          </div>
        ) : null}

        <div className="grid gap-8 lg:grid-cols-[290px_1fr]">
          <div className="hidden lg:block">
            <aside className="sticky top-24 rounded-[28px] border border-[#f8d7e2] bg-white shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
              <div className="border-b border-[#f8e4eb] px-5 py-4">
                <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <FolderTree className="h-5 w-5 text-[#d81b60]" />
                  Categories
                </h2>
                <p className="mt-1 text-xs text-slate-500">
                  Browse by category and subcategory
                </p>
              </div>

              <div className="p-3">{renderCategoryTree(false)}</div>
            </aside>
          </div>

          <div className="min-w-0 space-y-6">
            <div className="rounded-[28px] border border-[#f8d7e2] bg-white p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.12)] sm:p-5">
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-sm text-gray-500">
                      Showing{" "}
                      <span className="font-medium text-gray-900">
                        {data?.items?.length || 0}
                      </span>{" "}
                      of{" "}
                      <span className="font-medium text-gray-900">
                        {data?.total || 0}
                      </span>{" "}
                      products
                    </p>
                  </div>

                  <div className="hidden items-center gap-3 md:flex">
                    <div className="flex items-center rounded-xl border border-[#f2d3de] p-1">
                      <button
                        onClick={() => setViewMode("grid")}
                        className={`rounded-lg p-2 transition-all ${
                          viewMode === "grid"
                            ? "bg-[#d81b60] text-white"
                            : "text-gray-400 hover:text-gray-600"
                        }`}
                      >
                        <Grid3x3 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setViewMode("list")}
                        className={`rounded-lg p-2 transition-all ${
                          viewMode === "list"
                            ? "bg-[#d81b60] text-white"
                            : "text-gray-400 hover:text-gray-600"
                        }`}
                      >
                        <List className="h-4 w-4" />
                      </button>
                    </div>

                    <Button
                      variant="secondary"
                      onClick={() => setMobileFiltersExpanded((prev) => !prev)}
                      className="md:hidden"
                    >
                      <SlidersHorizontal className="mr-2 h-4 w-4" />
                      Filters
                    </Button>
                  </div>
                </div>

                <div className="md:hidden">
                  <button
                    type="button"
                    onClick={() => setMobileFiltersExpanded((prev) => !prev)}
                    className="flex w-full items-center justify-between rounded-2xl border border-[#f8d7e2] bg-[#fffafb] px-4 py-3 text-left"
                  >
                    <div className="flex items-center gap-2">
                      <SlidersHorizontal className="h-4 w-4 text-[#d81b60]" />
                      <span className="text-sm font-medium text-slate-800">
                        Filter Options
                      </span>
                      {activeFiltersCount > 0 ? (
                        <span className="rounded-full bg-[#d81b60] px-2 py-0.5 text-[11px] text-white">
                          {activeFiltersCount}
                        </span>
                      ) : null}
                    </div>
                    {mobileFiltersExpanded ? (
                      <ChevronUp className="h-4 w-4 text-slate-500" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-slate-500" />
                    )}
                  </button>
                </div>

                <div
                  className={`grid gap-3 ${
                    mobileFiltersExpanded ? "grid" : "hidden"
                  } md:grid md:grid-cols-2 xl:grid-cols-5`}
                >
                  <div className="space-y-1">
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
                      <Filter className="h-3.5 w-3.5" />
                      Search
                    </label>
                    <Input
                      defaultValue={q}
                      placeholder="Search products..."
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          setParam(
                            "q",
                            (e.currentTarget as HTMLInputElement).value,
                          );
                        }
                      }}
                      className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
                      <Tags className="h-3.5 w-3.5" />
                      Sort By
                    </label>
                    <select
                      value={sort}
                      onChange={(e) => setParam("sort", e.target.value)}
                      className="h-10 w-full rounded-xl border border-[#f2d3de] bg-white px-3 text-sm focus:border-[#d81b60] focus:outline-none"
                    >
                      <option value="newest">Newest</option>
                      <option value="best_selling">Best Selling</option>
                      <option value="price_asc">Price: Low to High</option>
                      <option value="price_desc">Price: High to Low</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-slate-600">
                      Min Price
                    </label>
                    <Input
                      value={min}
                      onChange={(e) => setMin(e.target.value)}
                      type="number"
                      placeholder="0"
                      className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-slate-600">
                      Max Price
                    </label>
                    <Input
                      value={max}
                      onChange={(e) => setMax(e.target.value)}
                      type="number"
                      placeholder="∞"
                      className="rounded-xl border-[#f2d3de] focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-slate-600">
                      Per Page
                    </label>
                    <select
                      value={takeFromUrl}
                      onChange={(e) => setParam("take", e.target.value)}
                      className="h-10 w-full rounded-xl border border-[#f2d3de] bg-white px-3 text-sm focus:border-[#d81b60] focus:outline-none"
                    >
                      <option value="8">8 / page</option>
                      <option value="12">12 / page</option>
                      <option value="16">16 / page</option>
                      <option value="36">36 / page</option>
                      <option value="48">48 / page</option>
                    </select>
                  </div>

                  <div className="flex flex-wrap gap-2 md:col-span-2 xl:col-span-5">
                    <button
                      onClick={() =>
                        setParam("featured", featured === "1" ? "" : "1")
                      }
                      className={`rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                        featured === "1"
                          ? "bg-[#d81b60] text-white"
                          : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
                      }`}
                    >
                      Featured Products
                    </button>

                    <button
                      onClick={() =>
                        setParam("offer", offer === "limited" ? "" : "limited")
                      }
                      className={`rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                        offer === "limited"
                          ? "bg-[#d81b60] text-white"
                          : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
                      }`}
                    >
                      Limited Offers
                    </button>

                    <button
                      onClick={() =>
                        setParam("inStock", inStock === "1" ? "" : "1")
                      }
                      className={`rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                        inStock === "1"
                          ? "bg-[#d81b60] text-white"
                          : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
                      }`}
                    >
                      In Stock Only
                    </button>

                    <Button
                      onClick={() => setManyParams({ min, max })}
                      className="rounded-xl bg-[#d81b60] text-white hover:bg-[#c2185b]"
                    >
                      Apply Price
                    </Button>

                    <Button
                      variant="secondary"
                      onClick={clearAll}
                      className="rounded-xl border-[#f8bbd0] bg-[#fff1f5] text-[#ad1457] hover:bg-[#ffe4ec]"
                    >
                      Clear All
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {loading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-square rounded-2xl bg-[#fff1f5]" />
                    <div className="mt-4 space-y-3">
                      <div className="h-4 w-3/4 rounded bg-[#ffe4ec]" />
                      <div className="h-4 w-1/2 rounded bg-[#ffe4ec]" />
                      <div className="h-4 w-1/4 rounded bg-[#ffe4ec]" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div
                className={
                  viewMode === "grid"
                    ? "grid w-full min-w-0 grid-cols-2 gap-2 sm:gap-4 md:grid-cols-3 lg:grid-cols-4"
                    : "space-y-4"
                }
              >
                {(data?.items ?? []).map((product) =>
                  viewMode === "grid" ? (
                    <HomeProductCard
                      key={product.id}
                      product={product}
                      isWishlisted={wishIds.has(product.id)}
                      onWishlistChange={(next) => {
                        setWishIds((prev) => {
                          const updated = new Set(prev);
                          if (next) updated.add(product.id);
                          else updated.delete(product.id);
                          return updated;
                        });
                      }}
                      isAuthenticated={status === "authenticated"}
                    />
                  ) : (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isWishlisted={wishIds.has(product.id)}
                      onWishlistChange={(next) => {
                        setWishIds((prev) => {
                          const updated = new Set(prev);
                          if (next) updated.add(product.id);
                          else updated.delete(product.id);
                          return updated;
                        });
                      }}
                      isAuthenticated={status === "authenticated"}
                      viewMode={viewMode}
                    />
                  ),
                )}
              </div>
            )}

            {!loading && (!data?.items || data.items.length === 0) ? (
              <div className="rounded-2xl bg-white p-16 text-center shadow-sm ring-1 ring-[#f8bbd0]">
                <Package className="mx-auto mb-4 h-16 w-16 text-[#f8bbd0]" />
                <h3 className="text-lg font-medium text-slate-900">
                  No products found
                </h3>
                <p className="mt-2 text-sm text-slate-500">
                  Try adjusting your filters or search term
                </p>
                <Button
                  onClick={clearAll}
                  className="mt-6 rounded-xl bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
                >
                  Clear all filters
                </Button>
              </div>
            ) : null}

            {!loading && data?.pages && data.pages > 1 ? (
              <div className="flex flex-col items-center justify-between gap-4 pt-8 md:flex-row">
                <div className="text-sm text-slate-500">
                  Page {currentPage} of {pages}
                </div>

                <div className="flex w-full flex-wrap items-center justify-center gap-2 sm:w-auto sm:flex-nowrap">
                  <Button
                    variant="secondary"
                    onClick={() => goPage(currentPage - 1)}
                    disabled={currentPage <= 1}
                    className="rounded-xl border-[#f8bbd0] px-3 py-2 text-sm sm:px-4"
                  >
                    <ChevronLeft className="mr-1 h-4 w-4" />
                    <span className="hidden sm:inline">Previous</span>
                  </Button>

                  <div className="flex min-w-0 flex-wrap items-center justify-center gap-1">
                    {pageButtons.map((p, idx) =>
                      p === 0 ? (
                        <span
                          key={`gap-${idx}`}
                          className="px-2 py-2 text-slate-400 sm:px-3"
                        >
                          …
                        </span>
                      ) : (
                        <button
                          key={p}
                          onClick={() => goPage(p)}
                          className={`min-w-9 rounded-xl px-3 py-2 text-sm font-medium transition-all sm:min-w-10 sm:px-4 ${
                            p === currentPage
                              ? "bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)]"
                              : "bg-[#fff1f5] text-slate-700 hover:bg-[#ffe4ec]"
                          }`}
                        >
                          {p}
                        </button>
                      ),
                    )}
                  </div>

                  <Button
                    variant="secondary"
                    onClick={() => goPage(currentPage + 1)}
                    disabled={currentPage >= pages}
                    className="rounded-xl border-[#f8bbd0] px-3 py-2 text-sm sm:px-4"
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {mobileCategoriesOpen ? (
        <div className="fixed inset-0 z-999 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setMobileCategoriesOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-full max-w-sm bg-white shadow-xl">
            <div className="flex h-full flex-col">
              <div className="flex items-center justify-between border-b border-[#f8bbd0] p-4">
                <h2 className="text-lg font-semibold text-gray-900">
                  Categories
                </h2>
                <button
                  onClick={() => setMobileCategoriesOpen(false)}
                  className="rounded-lg p-2 hover:bg-[#fff1f5]"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {renderCategoryTree(true)}
              </div>

              <div className="border-t border-[#f8bbd0] p-4">
                <Button
                  onClick={() => {
                    setParam("cat", "");
                    setMobileCategoriesOpen(false);
                  }}
                  variant="secondary"
                  className="w-full rounded-xl border-[#f8bbd0] bg-[#fff1f5] hover:bg-[#ffe4ec]"
                >
                  Reset Category
                </Button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}

function ProductCard({
  product,
  isWishlisted,
  onWishlistChange,
  isAuthenticated,
  viewMode,
}: {
  product: Product;
  isWishlisted: boolean;
  onWishlistChange: (next: boolean) => void;
  isAuthenticated: boolean;
  viewMode: "grid" | "list";
}) {
  const img = product.images?.[0]?.url;
  const finalPrice = product.offerPrice ?? product.price;
  const discount =
    product.offerPrice && product.price > 0
      ? Math.round(((product.price - product.offerPrice) / product.price) * 100)
      : null;

  const categoryLabel = product.category?.parent
    ? `${product.category.parent.name} → ${product.category.name}`
    : product.category?.name || "Uncategorized";

  if (viewMode === "list") {
    return (
      <Link
        href={`/products/${product.slug}`}
        className="group relative flex gap-6 rounded-2xl border border-[#f8bbd0] bg-white/90 p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.16)] transition-all hover:shadow-lg"
      >
        <div className="relative h-32 w-32 shrink-0 overflow-hidden rounded-xl bg-[#fff1f5] p-2">
          {img ? (
            <Image
              src={img}
              alt={product.name}
              fill
              className="object-contain transition-transform duration-300 group-hover:scale-105"
              sizes="128px"
            />
          ) : null}
        </div>

        <div className="min-w-0 flex-1">
          <div className="text-xs text-slate-500">{categoryLabel}</div>
          <h3 className="mt-1 min-w-0 truncate whitespace-nowrap text-lg font-semibold text-slate-900">
            {product.name}
          </h3>

          <div className="mt-2 flex items-center gap-2 text-sm text-slate-500">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span>{product.ratingAvg?.toFixed(1) || "0.0"}</span>
            <span>({product.ratingCount || 0})</span>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <span className="text-lg font-bold text-slate-900">
              ৳{finalPrice}
            </span>
            {product.offerPrice ? (
              <span className="text-sm text-slate-400 line-through">
                ৳{product.price}
              </span>
            ) : null}
            {discount ? (
              <span className="rounded-full bg-[#fff1f5] px-2 py-1 text-xs font-medium text-[#ad1457]">
                -{discount}%
              </span>
            ) : null}
          </div>

          <div className="mt-3 text-sm text-slate-500">
            {product.stock > 0 ? "In Stock" : "Out of Stock"}
          </div>
        </div>

        <div className="absolute right-4 top-4 z-10">
          <WishlistButton
            productId={product.id}
            initialWishlisted={isWishlisted}
            isAuthenticated={isAuthenticated}
            onChange={onWishlistChange}
          />
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/products/${product.slug}`}
      className="group relative overflow-hidden rounded-2xl border border-[#f8bbd0] bg-white/90 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.16)] transition-all hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="absolute right-4 top-4 z-10">
        <WishlistButton
          productId={product.id}
          initialWishlisted={isWishlisted}
          isAuthenticated={isAuthenticated}
          onChange={onWishlistChange}
        />
      </div>

      <div className="relative aspect-square overflow-hidden bg-[#fff1f5] p-2">
        {img ? (
          <Image
            src={img}
            alt={product.name}
            fill
            className="object-contain transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 50vw, 33vw"
          />
        ) : null}

        {discount ? (
          <div className="absolute left-4 top-4 rounded-full bg-[#d81b60] px-3 py-1 text-xs font-medium text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)]">
            -{discount}%
          </div>
        ) : null}
      </div>

      <div className="min-w-0 p-5">
        <div className="truncate text-xs text-slate-500">{categoryLabel}</div>
        <h3 className="mt-1 min-w-0 truncate whitespace-nowrap font-semibold text-slate-900">
          {product.name}
        </h3>

        <div className="mt-3 flex items-center gap-2 text-sm text-slate-500">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span>{product.ratingAvg?.toFixed(1) || "0.0"}</span>
          <span>({product.ratingCount || 0})</span>
        </div>

        <div className="mt-4 flex items-end justify-between">
          <div>
            <div className="text-lg font-bold text-slate-900">
              ৳{finalPrice}
            </div>
            {product.offerPrice ? (
              <div className="text-sm text-slate-400 line-through">
                ৳{product.price}
              </div>
            ) : null}
          </div>

          <div
            className={`rounded-full px-3 py-1 text-xs font-medium ${
              product.stock > 0
                ? "bg-green-50 text-green-600"
                : "bg-red-50 text-red-600"
            }`}
          >
            {product.stock > 0 ? "In Stock" : "Out of Stock"}
          </div>
        </div>
      </div>
    </Link>
  );
}
