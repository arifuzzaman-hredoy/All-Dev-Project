"use client";

import * as React from "react";
import { Heart } from "lucide-react";
import { useRouter } from "next/navigation";

type Props = {
  productId: string;
  initialWishlisted?: boolean;
  isAuthenticated?: boolean;
  onChange?: (next: boolean) => void;
  className?: string;
};

type ToggleResponse = { inWishlist: boolean } | { error: string };

export default function WishlistButton({
  productId,
  initialWishlisted = false,
  isAuthenticated = false,
  onChange,
  className = "",
}: Props) {
  const router = useRouter();
  const [wishlisted, setWishlisted] = React.useState(initialWishlisted);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    setWishlisted(initialWishlisted);
  }, [initialWishlisted]);

  const toggleWishlist = async (
    e: React.MouseEvent<HTMLButtonElement>,
  ): Promise<void> => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      router.push("/login");
      return;
    }

    if (loading) return;

    const previous = wishlisted;
    const optimistic = !previous;

    setWishlisted(optimistic);
    onChange?.(optimistic);
    setLoading(true);

    try {
      const res = await fetch("/api/wishlist", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ productId }),
      });

      const json: ToggleResponse = await res
        .json()
        .catch(() => ({ error: "Request failed" }));

      if (!res.ok || !("inWishlist" in json)) {
        setWishlisted(previous);
        onChange?.(previous);
        return;
      }

      setWishlisted(json.inWishlist);
      onChange?.(json.inWishlist);
    } catch {
      setWishlisted(previous);
      onChange?.(previous);
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      onClick={toggleWishlist}
      disabled={loading}
      aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
      className={`inline-flex h-10 w-10 items-center justify-center rounded-full border border-black/10 bg-white/90 shadow-sm transition hover:scale-105 disabled:cursor-not-allowed disabled:opacity-60 ${className}`}
    >
      <Heart
        className={`h-5 w-5 transition ${
          wishlisted ? "fill-red-500 text-red-500" : "text-black/60"
        }`}
      />
    </button>
  );
}
