"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import PageHero from "@/components/layout/page-hero";

type WishlistItem = {
  id: string;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
    category: { name: string; slug: string } | null;
  };
  createdAt: string;
};

type WishlistResponse = { items: WishlistItem[] };

function safeWishlistResponse(input: unknown): WishlistResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];
  const items: WishlistItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const p = x.product as Record<string, unknown> | undefined;
      const imgs = Array.isArray(p?.images) ? p?.images : [];
      const first = imgs[0] as Record<string, unknown> | undefined;

      return {
        id: typeof x.id === "string" ? x.id : "",
        createdAt: typeof x.createdAt === "string" ? x.createdAt : "",
        product: {
          id: typeof p?.id === "string" ? p.id : "",
          name: typeof p?.name === "string" ? p.name : "",
          slug: typeof p?.slug === "string" ? p.slug : "",
          price: typeof p?.price === "number" ? p.price : Number(p?.price || 0),
          offerPrice:
            p?.offerPrice === null
              ? null
              : typeof p?.offerPrice === "number"
                ? p.offerPrice
                : null,
          stock: typeof p?.stock === "number" ? p.stock : Number(p?.stock || 0),
          images:
            first?.url && typeof first.url === "string"
              ? [{ url: first.url }]
              : [],
          category: null,
        },
      };
    })
    .filter((x) => x.id && x.product?.id && x.product?.slug);

  return { items };
}

export default function WishlistPageClient() {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const load = async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch("/api/wishlist", { cache: "no-store" });
      const j: unknown = await r.json().catch(() => null);
      const parsed = safeWishlistResponse(j);
      setItems(parsed.items);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => void load(), []);

  const remove = async (productId: string) => {
    const ok = confirm("Remove from wishlist?");
    if (!ok) return;

    await fetch(`/api/wishlist?productId=${encodeURIComponent(productId)}`, {
      method: "DELETE",
    });
    await load();
  };

  return (
    <div className="space-y-8 pb-10">
      <PageHero
        eyebrow="Wishlist"
        title="Saved items stay in the same polished storefront language as the home page."
        description="Keep track of products you want to revisit later, then jump back into shopping, checkout, or your cart without losing the brand feel."
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Wishlist" },
        ]}
        actions={[
          { href: "/products", label: "Browse products" },
          { href: "/cart", label: "Open cart", variant: "secondary" },
        ]}
        stats={[
          { label: "Saved items", value: String(items.length) },
          { label: "Back to shopping", value: "One tap" },
          { label: "Checkout ready", value: "Yes" },
          { label: "Home style", value: "Kept" },
        ]}
      />

      {loading ? (
        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          Loading…
        </Card>
      ) : items.length === 0 ? (
        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-8 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          <div className="text-base font-semibold text-slate-900">
            Wishlist empty
          </div>
          <div className="mt-2 text-sm text-slate-600">
            Save products you want to revisit later.
          </div>
          <div className="mt-4">
            <Link href="/products">
              <Button className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]">
                Browse Products
              </Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((w) => {
            const p = w.product;
            const img = p.images?.[0]?.url;
            const finalPrice = p.offerPrice ?? p.price;

            return (
              <Card
                key={w.id}
                className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-3 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.16)]"
              >
                <Link href={`/products/${p.slug}`} className="block">
                  <div className="relative aspect-square overflow-hidden rounded-2xl bg-[#fff1f5]">
                    {img ? (
                      <Image
                        src={img}
                        alt={p.name}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 50vw, 33vw"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-xs text-black/40">
                        No image
                      </div>
                    )}
                  </div>

                  <div className="mt-3 px-2">
                    <div className="line-clamp-1 text-sm font-semibold text-slate-900">
                      {p.name}
                    </div>
                    <div className="mt-1 text-sm text-slate-700">
                      ৳ {finalPrice}
                    </div>
                    {p.offerPrice ? (
                      <div className="text-xs text-slate-500 line-through">
                        ৳ {p.price}
                      </div>
                    ) : null}
                  </div>
                </Link>

                <div className="mt-3 flex gap-2 px-2">
                  <Button
                    variant="secondary"
                    onClick={() => void remove(p.id)}
                    className="w-full border-[#f8bbd0] bg-[#fff1f5] text-[#ad1457] hover:bg-[#ffe4ec]"
                  >
                    Remove
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
