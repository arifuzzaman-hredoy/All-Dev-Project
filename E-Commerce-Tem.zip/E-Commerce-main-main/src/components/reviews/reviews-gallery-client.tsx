"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { BadgeCheck, Images, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ReviewGalleryItem } from "@/lib/services/review-gallery";

type ReviewsGalleryClientProps = {
  initialItems: ReviewGalleryItem[];
  initialHasMore: boolean;
  initialNextSkip: number;
};

type ReviewsGalleryResponse = {
  items: ReviewGalleryItem[];
  hasMore: boolean;
  nextSkip: number;
};

function parseGalleryResponse(input: unknown): ReviewsGalleryResponse {
  const record = input as Record<string, unknown>;
  const rawItems = Array.isArray(record.items) ? record.items : [];

  const items = rawItems
    .map((item) => item as ReviewGalleryItem)
    .filter(
      (item) =>
        item?.id &&
        item.product?.slug &&
        Array.isArray(item.imageUrls),
    );

  return {
    items,
    hasMore: record.hasMore === true,
    nextSkip:
      typeof record.nextSkip === "number" && Number.isFinite(record.nextSkip)
        ? record.nextSkip
        : items.length,
  };
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";

  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function Stars({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, index) => {
        const active = index + 1 <= Math.round(value);

        return (
          <Star
            key={index}
            className={`h-4 w-4 ${
              active
                ? "fill-amber-400 text-amber-400"
                : "fill-slate-100 text-slate-200"
            }`}
          />
        );
      })}
    </div>
  );
}

export default function ReviewsGalleryClient({
  initialItems,
  initialHasMore,
  initialNextSkip,
}: ReviewsGalleryClientProps) {
  const [items, setItems] = useState(initialItems);
  const [hasMore, setHasMore] = useState(initialHasMore);
  const [nextSkip, setNextSkip] = useState(initialNextSkip);
  const [loading, setLoading] = useState(false);

  const loadMore = async (): Promise<void> => {
    if (loading || !hasMore) return;

    setLoading(true);

    try {
      const res = await fetch(`/api/reviews/gallery?skip=${nextSkip}&take=12`, {
        cache: "no-store",
      });
      const json: unknown = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error("Failed to load reviews");
      }

      const parsed = parseGalleryResponse(json);
      setItems((prev) => {
        const seen = new Set(prev.map((item) => item.id));
        const next = parsed.items.filter((item) => !seen.has(item.id));
        return [...prev, ...next];
      });
      setHasMore(parsed.hasMore);
      setNextSkip(parsed.nextSkip);
    } finally {
      setLoading(false);
    }
  };

  if (!items.length) {
    return (
      <div className="rounded-[32px] border border-[#f8bbd0] bg-white p-10 text-center shadow-sm">
        <Images className="mx-auto h-12 w-12 text-[#d81b60]" />
        <h2 className="mt-4 text-xl font-bold text-slate-950">
          No reviews yet
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
          Customer reviews will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
        {items.map((review) => {
          const href = `/products/${review.product.slug}#reviews`;
          const firstImage = review.imageUrls[0] || review.product.imageUrl;
          const extraImages = Math.max(0, review.imageUrls.length - 1);

          return (
            <Link
              key={review.id}
              href={href}
              className="group overflow-hidden  border border-[#f8bbd0] bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_70px_-48px_rgba(216,27,96,0.55)]"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-[#fff1f5]">
                {firstImage ? (
                  <Image
                    src={firstImage}
                    alt={`${review.product.name} review photo`}
                    fill
                    className="object-cover transition duration-500 group-hover:scale-105"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <Images className="h-10 w-10 text-[#d81b60]/40" />
                  </div>
                )}

                {extraImages ? (
                  <div className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-black/65 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
                    <Images className="h-3.5 w-3.5" />
                    +{extraImages}
                  </div>
                ) : null}
              </div>

              <div className="space-y-4 p-4">
                <div className="flex items-start gap-3">
                  {review.product.imageUrl ? (
                    <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-2xl border border-[#f8bbd0] bg-white">
                      <Image
                        src={review.product.imageUrl}
                        alt={review.product.name}
                        fill
                        className="object-contain p-1"
                        sizes="48px"
                      />
                    </div>
                  ) : null}

                  <div className="min-w-0 flex-1">
                    <h2 className="truncate text-sm font-bold text-slate-950 group-hover:text-[#ad1457]">
                      {review.product.name}
                    </h2>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <Stars value={review.rating} />
                      <span className="text-xs text-slate-500">
                        {formatDate(review.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-semibold text-slate-900">
                      {review.user.name || "Anonymous"}
                    </span>
                    {review.verified ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                        <BadgeCheck className="h-3 w-3" />
                        Verified
                      </span>
                    ) : null}
                  </div>

                  {review.comment ? (
                    <p className="mt-2 line-clamp-3 text-sm leading-6 text-slate-600">
                      {review.comment}
                    </p>
                  ) : (
                    <p className="mt-2 text-sm text-slate-400">
                      Customer uploaded product photos.
                    </p>
                  )}
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {hasMore ? (
        <div className="flex justify-center">
          <Button
            type="button"
            onClick={() => void loadMore()}
            disabled={loading}
            className="h-12 rounded-2xl bg-[#d81b60] px-8 text-sm font-bold text-white shadow-[0_18px_44px_-22px_rgba(216,27,96,0.9)] hover:bg-[#c2185b]"
          >
            {loading ? "Loading..." : "Load More Reviews"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
