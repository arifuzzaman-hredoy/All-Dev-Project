// app/page.tsx
import Link from "next/link";
import { headers } from "next/headers";
import { ArrowRight } from "lucide-react";

import { prisma } from "@/lib/prisma";
import type { HomeCategoryRow } from "@/lib/home-category-rows";
import { attachEffectivePrices } from "@/lib/product-discounts";

import HeroSection from "@/components/home/hero-section";
import TrustBadges from "@/components/home/trust-badges";
import FeaturedProducts from "@/components/home/featured-products";
import CategoryProductRow from "@/components/home/category-product-row";
import ReviewCarousel from "@/components/home/ReviewCarousel";
import ProductSliderSection from "@/components/products/product-slider-section";
import { LoopingCategoryRail } from "@/components/home/LoopingCategoryRail";

import {
  getBestSellerProducts,
  getLimitedOfferProducts,
} from "@/lib/services/home-products";

export const dynamic = "force-dynamic";

const HOME_BANNER_SLOTS = ["mainbanner", "subbanner1", "subbanner2"] as const;

const categoryColorClasses: Record<string, string> = {
  headphone:
    "bg-[#fff1f5] text-[#be123c] ring-[#fda4af] hover:bg-[#ffe4ec] hover:text-[#9f1239]",
  smartwatch:
    "bg-[#eff6ff] text-[#1d4ed8] ring-[#bfdbfe] hover:bg-[#dbeafe] hover:text-[#1e40af]",
  bluetooth:
    "bg-[#f5f3ff] text-[#6d28d9] ring-[#ddd6fe] hover:bg-[#ede9fe] hover:text-[#5b21b6]",
  "t-shirts":
    "bg-[#fff7ed] text-[#c2410c] ring-[#fed7aa] hover:bg-[#ffedd5] hover:text-[#9a3412]",
  mouse:
    "bg-[#f8fafc] text-[#475569] ring-[#cbd5e1] hover:bg-[#e2e8f0] hover:text-[#334155]",
  gaming:
    "bg-[#fdf2f8] text-[#be185d] ring-[#fbcfe8] hover:bg-[#fce7f3] hover:text-[#9d174d]",
};

function getCategoryColorClass(slug: string) {
  return (
    categoryColorClasses[slug] ??
    "bg-[#fff7fb] text-[#ad1457] ring-[#f8bbd0] hover:bg-[#ffe4ec] hover:text-[#8e1042]"
  );
}

function getAverageRating(reviews: { rating: number }[]) {
  if (!reviews.length) return 0;
  const total = reviews.reduce((sum, item) => sum + item.rating, 0);
  return total / reviews.length;
}

async function getRequestOrigin() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (!host) return null;

  const protocol =
    h.get("x-forwarded-proto") ??
    (host.startsWith("localhost") || host.startsWith("127.0.0.1")
      ? "http"
      : "https");

  return `${protocol}://${host}`;
}

export default async function HomePage() {
  const origin = await getRequestOrigin();

  const [
    settings,
    featuredRaw,
    homeBanners,
    bestSellerProducts,
    limitedOfferProducts,
    homeCategories,
  ] = await Promise.all([
    prisma.storeSettings.upsert({
      where: { id: "default" },
      update: {},
      create: { id: "default" },
    }),

    prisma.product.findMany({
      where: { isFeatured: true, isActive: true },
      orderBy: [{ updatedAt: "desc" }],
      take: 8,
      include: {
        images: {
          orderBy: { sortOrder: "asc" },
          take: 1,
        },
        variants: {
          orderBy: { createdAt: "asc" },
          take: 1,
          select: {
            id: true,
            stock: true,
          },
        },
        category: {
          include: {
            parent: true,
          },
        },
        reviews: {
          select: { rating: true },
        },
      },
    }),

    prisma.banner.findMany({
      where: {
        isActive: true,
        slot: { in: [...HOME_BANNER_SLOTS] },
      },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
    }),

    getBestSellerProducts(),

    getLimitedOfferProducts(),

    prisma.category.findMany({
      where: {
        isActive: true,
        parentId: null,
      },
      orderBy: [{ name: "asc" }],
      take: 24,
      select: {
        id: true,
        name: true,
        slug: true,
        imageUrl: true,
      },
    }),
  ]);

  const featuredResolved = await attachEffectivePrices(featuredRaw);

  const featured = featuredResolved.map((product) => ({
    ...product,
    ratingAvg: getAverageRating(product.reviews),
    ratingCount: product.reviews.length,
  }));

  const categoryRowsResponse = origin
    ? await fetch(`${origin}/api/home/category-rows`, {
        cache: "no-store",
      })
    : null;

  const categoryRows = categoryRowsResponse?.ok
    ? ((await categoryRowsResponse.json()) as HomeCategoryRow[])
    : [];

  return (
    <main className="min-h-screen overflow-hidden">
      <HeroSection settings={settings} banners={homeBanners} />

      <section className="mx-auto max-w-7xl px-4 pt-10 lg:px-6">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#db0f5b]">
              Shop by category
            </p>
            <h2 className="mt-2 text-2xl font-black text-slate-950 md:text-4xl">
              Categories
            </h2>
          </div>

          <Link
            href="/categories"
            className="group flex items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] transition-all ring-1 ring-[#f8bbd0] hover:bg-[#ffe4ec] hover:text-[#8e1042]"
          >
            <span>View all</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        <LoopingCategoryRail categories={homeCategories} />
      </section>

      <section className="mx-auto max-w-7xl px-4 pt-12 lg:px-6">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 md:text-3xl">
              Featured Products
            </h2>
          </div>

          <Link
            href="/products?featured=1"
            className="group flex items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] transition-all ring-1 ring-[#f8bbd0] hover:bg-[#ffe4ec] hover:text-[#8e1042]"
          >
            <span>View all</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        <FeaturedProducts products={featured} />
      </section>

      <ProductSliderSection
        title="Best Seller Products"
        subtitle="Top picks from real customer orders."
        products={bestSellerProducts}
        viewAllHref="/products?sort=best-seller"
      />

      <ProductSliderSection
        title="Limited Offer Products"
        subtitle="Current deals from product and category discounts."
        products={limitedOfferProducts}
        viewAllHref="/products?offer=limited"
      />

      {categoryRows.map((item) => (
        <CategoryProductRow
          key={item.slug}
          slug={item.slug}
          title={item.name}
          colorClass={getCategoryColorClass(item.slug)}
        />
      ))}

      <section className="mx-auto max-w-7xl px-4 pt-12 lg:px-6">
        <div className="mb-6 text-left">
          <h2 className="text-2xl font-semibold text-gray-900 md:text-3xl">
            Why Choose Us
          </h2>
        </div>
        <TrustBadges />
      </section>

      <ReviewCarousel />
    </main>
  );
}