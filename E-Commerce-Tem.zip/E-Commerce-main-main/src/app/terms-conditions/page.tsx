import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function TermsConditionsPage() {
  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: {
      termsConditions: true,
    },
  });

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-bold">Terms & Conditions</h1>

      <div className="mt-6 whitespace-pre-line rounded-3xl border border-black/10 bg-white p-6 text-sm leading-7 text-black/75">
        {settings?.termsConditions?.trim() ||
          "No Terms & Conditions added yet."}
      </div>
    </div>
  );
}
