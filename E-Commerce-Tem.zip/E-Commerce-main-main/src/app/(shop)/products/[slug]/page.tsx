import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";
import { Card } from "@/components/ui/card";
import ProductReviews from "@/components/reviews/product-reviews";
import ProductDetailsClient from "@/components/shop/product-details-client";
import RecommendedProducts from "@/components/products/recommended-products";
import { attachEffectivePrice } from "@/lib/product-discounts";

export const dynamic = "force-dynamic";

const SITE_URL = "https://nexoramart.com";

function buildWhatsAppLink(productName: string) {
  const phone = "8801331960139";
  const text = encodeURIComponent(
    `Hello, I'm interested in this product: ${productName}`,
  );

  return `https://wa.me/${phone}?text=${text}`;
}

function stripHtml(value?: string | null) {
  return (value || "")
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function absoluteUrl(url?: string | null) {
  if (!url) return `${SITE_URL}/placeholder.png`;

  if (url.startsWith("http://") || url.startsWith("https://")) {
    return url;
  }

  return `${SITE_URL}${url.startsWith("/") ? url : `/${url}`}`;
}

function makeSeoDescription(product: {
  name: string;
  description?: string | null;
  category?: { name: string } | null;
}) {
  const cleanDescription = stripHtml(product.description);

  if (cleanDescription) {
    return cleanDescription.length > 155
      ? `${cleanDescription.slice(0, 152)}...`
      : cleanDescription;
  }

  return `Buy ${product.name} from NexoraMart. ${
    product.category?.name ? `Category: ${product.category.name}. ` : ""
  }Trusted online shopping with delivery across Bangladesh.`;
}

async function getProductBySlug(slug: string) {
  const productRaw = await prisma.product.findFirst({
    where: {
      slug,
      isActive: true,
    },
    include: {
      images: {
        orderBy: {
          sortOrder: "asc",
        },
      },
      variants: {
        include: {
          images: {
            orderBy: {
              sortOrder: "asc",
            },
          },
        },
      },
      category: {
        include: {
          parent: true,
        },
      },
      categories: {
        include: {
          category: {
            include: {
              parent: true,
            },
          },
        },
        orderBy: {
          createdAt: "asc",
        },
      },
      reviews: {
        select: {
          rating: true,
        },
      },
    },
  });

  return attachEffectivePrice(productRaw);
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug?: string }> | { slug?: string };
}): Promise<Metadata> {
  const p = params instanceof Promise ? await params : params;
  const slug = p?.slug;

  if (!slug) {
    return {
      title: "Product | NexoraMart",
      description: "Product details from NexoraMart.",
      robots: {
        index: false,
        follow: true,
      },
    };
  }

  const product = await getProductBySlug(slug);

  if (!product) {
    return {
      title: "Product Not Found | NexoraMart",
      description: "This product is not available on NexoraMart.",
      robots: {
        index: false,
        follow: true,
      },
    };
  }

  const productUrl = `${SITE_URL}/products/${product.slug}`;
  const imageUrl = absoluteUrl(product.images?.[0]?.url);
  const description = makeSeoDescription(product);
  const productPrice = product.offerPrice ?? product.price;

  return {
    metadataBase: new URL(SITE_URL),

    title: `${product.name} | NexoraMart`,
    description,

    alternates: {
      canonical: productUrl,
    },

    openGraph: {
      title: `${product.name} | NexoraMart`,
      description,
      url: productUrl,
      siteName: "NexoraMart",
      type: "website",
      images: [
        {
          url: imageUrl,
          width: 1200,
          height: 630,
          alt: product.images?.[0]?.alt || product.name,
        },
      ],
    },

    twitter: {
      card: "summary_large_image",
      title: `${product.name} | NexoraMart`,
      description,
      images: [imageUrl],
    },

    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-image-preview": "large",
        "max-snippet": -1,
        "max-video-preview": -1,
      },
    },

    keywords: [
      product.name,
      product.sku,
      product.category?.name || "",
      product.category?.parent?.name || "",
      "NexoraMart",
      "online shopping Bangladesh",
      "Rangpur online shop",
      "trusted ecommerce Bangladesh",
      `buy ${product.name}`,
      `${product.name} price in Bangladesh`,
      `৳${productPrice}`,
    ].filter(Boolean),
  };
}

export default async function ProductDetailsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  if (!slug) return notFound();

  const p = await getProductBySlug(slug);

  if (!p) return notFound();

  const productUrl = `${SITE_URL}/products/${p.slug}`;
  const seoDescription = makeSeoDescription(p);

  const productImages = p.images?.length
    ? p.images.map((img) => absoluteUrl(img.url))
    : [absoluteUrl("/placeholder.png")];

  const productPrice = p.offerPrice ?? p.price;

  const categoryNames = p.categories?.length
    ? p.categories.map((item) =>
        [item.category.parent?.name, item.category.name]
          .filter(Boolean)
          .join(" → "),
      )
    : p.category
      ? [[p.category.parent?.name, p.category.name].filter(Boolean).join(" → ")]
      : [];

  const categoryName = categoryNames.length
    ? categoryNames.join(", ")
    : undefined;

  const reviewCount = p.reviews?.length ?? 0;

  const averageRating =
    reviewCount > 0
      ? p.reviews.reduce((sum, review) => sum + review.rating, 0) / reviewCount
      : null;

  const productJsonLd: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: seoDescription,
    sku: p.sku,
    image: productImages,
    category: categoryName,
    url: productUrl,
    brand: {
      "@type": "Brand",
      name: "NexoraMart",
    },
    offers: {
      "@type": "Offer",
      url: productUrl,
      priceCurrency: "BDT",
      price: String(productPrice),
      availability:
        p.stock > 0
          ? "https://schema.org/InStock"
          : "https://schema.org/OutOfStock",
      itemCondition: "https://schema.org/NewCondition",
      seller: {
        "@type": "Organization",
        name: "NexoraMart",
      },
    },
  };

  if (averageRating !== null) {
    productJsonLd.aggregateRating = {
      "@type": "AggregateRating",
      ratingValue: averageRating.toFixed(1),
      reviewCount,
    };
  }

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Products",
        item: `${SITE_URL}/products`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: p.name,
        item: productUrl,
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(productJsonLd),
        }}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(breadcrumbJsonLd),
        }}
      />

      <div className="bg-linear-to-b from-[#fff7fb] via-white to-white">
        <div className="mx-auto max-w-7xl space-y-8 px-3 py-6 sm:px-4 sm:py-8 lg:px-6 lg:py-10">
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 py-3 text-sm text-slate-500 shadow-sm backdrop-blur">
          <Link href="/" className="transition hover:text-[#ad1457] hover:underline">
            Home
          </Link>

          <span className="text-[#d81b60]">/</span>

          <Link href="/products" className="transition hover:text-[#ad1457] hover:underline">
            Products
          </Link>

          <span className="text-[#d81b60]">/</span>

          <span className="min-w-0 truncate font-medium text-slate-900">
            {p.name}
          </span>
        </div>

        <ProductDetailsClient
          product={{
            id: p.id,
            slug: p.slug,
            name: p.name,
            sku: p.sku,
            description: p.description ?? null,
            youtubeUrl: p.youtubeUrl ?? null,
            price: p.price,
            offerPrice: p.offerPrice ?? null,
            discountPercentage: p.discountPercentage ?? null,
            stock: p.stock,
            isFeatured: p.isFeatured,
            categoryNames,
            images: p.images.map((img) => ({
              id: img.id,
              url: img.url,
            })),
            variants: p.variants.map((v) => ({
              id: v.id,
              type: v.type,
              value: v.value,
              priceDiff: v.priceDiff,
              stock: v.stock,
              images: v.images.map((img) => ({
                id: img.id,
                url: img.url,
              })),
            })),
          }}
          buyNowBaseUrl="/checkout"
          chatNowUrl={buildWhatsAppLink(p.name)}
        />

        <Card className="rounded-[28px] border-[#f8bbd0] bg-white p-4 shadow-sm">
          <Link
            href="/products"
            className="inline-flex h-12 w-full items-center justify-center rounded-2xl border border-[#f8bbd0] bg-[#fff1f5] px-5 text-sm font-bold text-[#ad1457] transition hover:bg-[#ffe4ec]"
          >
            Back to Products
          </Link>
        </Card>

        <div
          id="reviews"
          className="rounded-[32px] border border-[#f8bbd0] bg-white/80 p-3 shadow-[0_22px_70px_-60px_rgba(216,27,96,0.5)] sm:p-5"
        >
          <ProductReviews productId={p.id} />
        </div>

        <RecommendedProducts
          title="Related Products"
          excludeProductIds={[p.id]}
          categoryIds={
            p.categories?.length
              ? Array.from(
                  new Set(
                    p.categories.flatMap((item) => [
                      item.category.id,
                      ...(item.category.parent?.id
                        ? [item.category.parent.id]
                        : []),
                    ]),
                  ),
                )
              : [
                  p.categoryId,
                  ...(p.category?.parent?.id ? [p.category.parent.id] : []),
                ]
          }
          fallbackToFeatured
          limit={8}
        />
        </div>
      </div>
    </>
  );
}
