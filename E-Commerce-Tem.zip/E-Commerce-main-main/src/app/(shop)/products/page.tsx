import { prisma } from "@/lib/prisma";
import ProductsBrowser from "@/components/products/products-browser";
import { Metadata } from "next";
import { Suspense } from "react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Products",
  description:
    "Browse our wide range of products with category filters, search, sorting, and pagination.",
};

export default async function ProductsPage() {
  const categories = await prisma.category.findMany({
    where: { isActive: true },
    orderBy: [{ parentId: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      slug: true,
      parentId: true,
      isActive: true,
    },
  });

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ProductsBrowser categories={categories} />
    </Suspense>
  );
}
