import "./globals.css";
import "./scrollbar-hide.css";

import { Suspense } from "react";
import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { GoogleAnalytics } from "@next/third-parties/google";

import { Providers } from "@/app/providers";
import { MetaPixel } from "@/components/analytics/meta-pixel";
import { Header } from "@/components/layout/header";
import { MobileNav } from "@/components/layout/mobile-nav";
import { SiteFontProvider } from "@/components/layout/site-font-provider";
import SiteFooter from "@/components/layout/site-footer";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
});

const SITE_URL = "https://nexoramart.com";
const GA_ID = process.env.NEXT_PUBLIC_GA_ID;

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),

  title: {
    default: "NexoraMart | Trusted Online Shopping in Bangladesh",
    template: "%s | NexoraMart",
  },

  description:
    "Shop trusted products from NexoraMart including perfumes, oud, attar, books, Islamic items, art & craft, honey, nuts, and selected food items with fast delivery across Bangladesh.",

  keywords: [
    "NexoraMart",
    "NexoraMart",
    "online shopping Bangladesh",
    "trusted ecommerce Bangladesh",
    "Rangpur online shop",
    "perfume Bangladesh",
    "oud perfume",
    "attar Bangladesh",
    "Islamic items",
    "Islamic products Bangladesh",
    "books Bangladesh",
    "art and craft",
    "honey Bangladesh",
    "food items Bangladesh",
    "premium products Bangladesh",
    "fast delivery Bangladesh",
  ],

  applicationName: "NexoraMart",
  creator: "NexoraMart",
  publisher: "NexoraMart",
  category: "eCommerce",

  alternates: {
    canonical: SITE_URL,
  },

  openGraph: {
    title: "NexoraMart | Trusted Online Shopping in Bangladesh",
    description:
      "Discover perfumes, oud, attar, books, Islamic items, art & craft, honey, nuts, and selected quality products from NexoraMart.",
    url: SITE_URL,
    siteName: "NexoraMart",
    type: "website",
    locale: "bn_BD",
  },

  twitter: {
    card: "summary_large_image",
    title: "NexoraMart | Trusted Online Shopping in Bangladesh",
    description:
      "Shop trusted products from NexoraMart with smooth ordering, reliable support, and fast delivery across Bangladesh.",
  },

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },

  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#ffffff",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en-BD" suppressHydrationWarning>
      <body className={inter.className}>
        <SiteFontProvider />
        <Providers>
          <div className="min-h-screen overflow-x-hidden">
            <div className="print:hidden">
              <Header />
            </div>

            <main className="mx-auto max-w-7xl pb-24 md:pb-24">
              {children}
            </main>

            <SiteFooter />
            <MobileNav />
          </div>
        </Providers>

        {GA_ID ? <GoogleAnalytics gaId={GA_ID} /> : null}
        <Suspense fallback={null}>
          <MetaPixel />
        </Suspense>
      </body>
    </html>
  );
}
