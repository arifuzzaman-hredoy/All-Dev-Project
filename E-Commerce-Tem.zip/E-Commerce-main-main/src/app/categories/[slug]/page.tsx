import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import CategoryProductsClient from "@/components/categories/category-products-client";
import { ChevronRight } from "lucide-react";
import { Suspense } from "react";

export const dynamic = "force-dynamic";

type PageProps = {
  params: Promise<{ slug: string }> | { slug: string };
};

export async function generateMetadata({ params }: PageProps) {
  const p = params instanceof Promise ? await params : params;
  const slug = p.slug;

  const category = await prisma.category.findUnique({
    where: { slug },
    select: {
      name: true,
      parent: {
        select: {
          name: true,
        },
      },
    },
  });

  if (!category) {
    return {
      title: "Category not found",
    };
  }

  return {
    title: category.parent
      ? `${category.parent.name} - ${category.name}`
      : category.name,
    description: `Browse ${category.name} products`,
  };
}

export default async function CategoryProductsPage({ params }: PageProps) {
  const p = params instanceof Promise ? await params : params;
  const slug = p.slug;

  const category = await prisma.category.findUnique({
    where: { slug },
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
      children: {
        where: {
          isActive: true,
        },
        select: {
          id: true,
          name: true,
          slug: true,
          imageUrl: true,
          _count: {
            select: {
              products: true,
              productLinks: true,
            },
          },
        },
        orderBy: {
          name: "asc",
        },
      },
    },
  });

  if (!category || !category.isActive) {
    notFound();
  }

  const title = category.parent
    ? `${category.parent.name} → ${category.name}`
    : category.name;

  return (
    <main className="min-h-screen bg-linear-to-b from-[#fff7fb] via-white to-white">
      <section className="border-b border-[#f8bbd0] bg-white/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <Link href="/" className="hover:text-[#ad1457]">
              Home
            </Link>
            <ChevronRight className="h-4 w-4" />
            <Link href="/categories" className="hover:text-[#ad1457]">
              Categories
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="font-medium text-slate-900">{title}</span>
          </div>

          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
            {title}
          </h1>

          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            এই category-এর subcategory, suggested products, এবং filter option
            এক জায়গায় দেখুন।
          </p>
        </div>
      </section>

      <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-8">Loading...</div>}>
        <CategoryProductsClient
          categorySlug={category.slug}
          categoryName={category.name}
          subcategories={category.children.map((child) => ({
            id: child.id,
            name: child.name,
            slug: child.slug,
            imageUrl: child.imageUrl,
            productCount: child._count.products + child._count.productLinks,
          }))}
        />
      </Suspense>
    </main>
  );
}
