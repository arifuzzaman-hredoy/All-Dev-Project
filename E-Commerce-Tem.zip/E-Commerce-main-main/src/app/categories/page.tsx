import Image from "next/image";
import Link from "next/link";
import { Metadata } from "next";
import { ChevronRight, Search } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getDescendantCategoryIds } from "@/lib/category-tree";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Categories",
  description: "Browse main product categories.",
};

type PageProps = {
  searchParams?: Promise<{ q?: string }> | { q?: string };
};

export default async function CategoriesPage({ searchParams }: PageProps) {
  const sp = searchParams instanceof Promise ? await searchParams : searchParams;
  const q = (sp?.q || "").trim();

  const allCategories = await prisma.category.findMany({
    where: { isActive: true },
    orderBy: [{ parentId: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      slug: true,
      parentId: true,
      imageUrl: true,
    },
  });

  const parents = allCategories
    .filter((category) => !category.parentId)
    .filter((category) =>
      q ? category.name.toLowerCase().includes(q.toLowerCase()) : true,
    );

  const categoryCards = await Promise.all(
    parents.map(async (category) => {
      const categoryIds = getDescendantCategoryIds(category.id, allCategories);
      const productCount = await prisma.product.count({
        where: {
          isActive: true,
          OR: [
            { categoryId: { in: categoryIds } },
            {
              categories: {
                some: {
                  categoryId: { in: categoryIds },
                },
              },
            },
          ],
        },
      });

      return {
        ...category,
        productCount,
      };
    }),
  );

  return (
    <main className="min-h-screen bg-linear-to-b from-[#fff7fb] via-white to-white">
      <section className="border-b border-[#f8bbd0] bg-white/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <Link href="/" className="hover:text-[#ad1457]">
              Home
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="font-medium text-slate-900">Categories</span>
          </div>

          <div className="mt-4 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
                Categories
              </h1>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                এখানে শুধু main category দেখানো হচ্ছে। কোনো category খুললে তার
                subcategory ও suggested products দেখা যাবে।
              </p>
            </div>

            <form action="/categories" className="relative w-full lg:w-86">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                name="q"
                defaultValue={q}
                placeholder="Filter categories..."
                className="h-11 w-full rounded-2xl border border-[#f8bbd0] bg-white pl-10 pr-4 text-sm text-slate-800 outline-none transition focus:border-[#d81b60] focus:ring-4 focus:ring-[#ec407a]/10"
              />
            </form>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
        {categoryCards.length ? (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-3 lg:grid-cols-4">
            {categoryCards.map((category) => (
              <Link
                key={category.id}
                href={`/categories/${category.slug}`}
                className="group overflow-hidden rounded-sm border border-[#f8bbd0] bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="relative aspect-square bg-[#fde7ee]">
                  {category.imageUrl ? (
                    <Image
                      src={category.imageUrl}
                      alt={category.name}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center px-4 text-center text-sm text-slate-500">
                      No image
                    </div>
                  )}
                </div>

                <div className="p-1">
                  <h2 className="truncate text-base font-semibold text-slate-900 group-hover:text-[#ad1457] text-center">
                    {category.name}
                  </h2>
                  <p className=" text-sm text-slate-500 text-center">
                    {category.productCount} products
                  </p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-[#f8bbd0] bg-white p-12 text-center">
            <h2 className="text-lg font-semibold text-slate-900">
              No categories found
            </h2>
            <p className="mt-2 text-sm text-slate-500">
              Try a different category filter.
            </p>
          </div>
        )}
      </section>
    </main>
  );
}
