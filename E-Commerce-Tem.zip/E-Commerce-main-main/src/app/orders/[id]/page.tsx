import RecommendedProducts from "@/components/products/recommended-products";
import { Card } from "@/components/ui/card";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import PageHero from "@/components/layout/page-hero";
import { authOptions } from "@/lib/auth";
import {
  canAccessCustomerOrder,
  firstSearchParamValue,
} from "@/lib/order-access";
import { syncSteadfastOrderById } from "@/lib/couriers/steadfast-sync";
import {
  buildSteadfastTrackingUrl,
  getSteadfastMeta,
} from "@/lib/couriers/steadfast";
import SteadfastAutoSync from "@/components/orders/steadfast-auto-sync";

export const dynamic = "force-dynamic";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function formatDate(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  return date.toLocaleString();
}

function formatVariant(type?: string | null, value?: string | null) {
  if (!type || !value) return null;
  return `${type}: ${value}`;
}

function getReadableOrderId(input: {
  publicOrderId?: string | null;
  id: string;
}) {
  return input.publicOrderId?.trim() || input.id;
}

function asObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function asString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value : null;
}

function asNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

export default async function OrderDetailsPage({
  params,
  searchParams,
}: {
  params: Promise<{ id?: string }> | { id?: string };
  searchParams?:
    | Promise<{ phone?: string | string[] }>
    | { phone?: string | string[] };
}) {
  const p = params instanceof Promise ? await params : params;
  const sp = searchParams instanceof Promise ? await searchParams : searchParams;
  const id = p?.id;

  if (!isNonEmptyString(id)) return notFound();

  const session = await getServerSession(authOptions);
  const sessionUserId =
    typeof session?.user?.id === "string" ? session.user.id : null;
  const phoneProof = firstSearchParamValue(sp?.phone);

  const orderProbe = await prisma.order.findUnique({
    where: { id },
    select: {
      id: true,
      publicOrderId: true,
      courierName: true,
      userId: true,
      phone: true,
    },
  });

  if (!orderProbe) return notFound();

  if (
    !canAccessCustomerOrder({
      sessionUserId,
      orderUserId: orderProbe.userId,
      orderPhone: orderProbe.phone,
      phoneProof,
    })
  ) {
    return notFound();
  }

  if (orderProbe.courierName === "Steadfast") {
    await syncSteadfastOrderById(orderProbe.id);
  }

  const [order, settings] = await Promise.all([
    prisma.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            variant: {
              select: {
                type: true,
                value: true,
              },
            },
            product: {
              select: {
                id: true,
                categoryId: true,
                category: {
                  select: {
                    id: true,
                    parent: {
                      select: {
                        id: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        manualBkashNumber: true,
        manualBkashImageUrl: true,
        manualNagadNumber: true,
        manualNagadImageUrl: true,
        manualRocketNumber: true,
        manualRocketImageUrl: true,
      },
    }),
  ]);

  if (!order) return notFound();

  const displayOrderId = getReadableOrderId(order);
  const phoneQuery = phoneProof
    ? `?phone=${encodeURIComponent(phoneProof)}`
    : "";

  const recommendedCategoryIds = Array.from(
    new Set(
      order.items.flatMap((item) => {
        const ids: string[] = [];

        if (item.product?.categoryId) ids.push(item.product.categoryId);
        if (item.product?.category?.parent?.id) {
          ids.push(item.product.category.parent.id);
        }

        return ids;
      }),
    ),
  );

  const orderedProductIds = Array.from(
    new Set(
      order.items
        .map((item) => item.product?.id)
        .filter((value): value is string => Boolean(value)),
    ),
  );

  const hasCourierInfo = Boolean(order.courierName || order.trackingId);
  const steadfastMeta = getSteadfastMeta(order.paymentMeta);
  const steadfastTrackingUrl = buildSteadfastTrackingUrl({
    consignmentId: steadfastMeta.consignmentId,
    trackingCode: steadfastMeta.trackingCode,
    trackingId: order.trackingId,
  });

  const paymentMeta = asObject(order.paymentMeta);
  const manualPaymentMeta = asObject(paymentMeta?.manualPayment);

  const manualProvider = asString(manualPaymentMeta?.provider);
  const manualPaymentNumber =
    manualProvider === "BKASH"
      ? (settings?.manualBkashNumber ?? null)
      : manualProvider === "NAGAD"
        ? (settings?.manualNagadNumber ?? null)
        : manualProvider === "ROCKET"
          ? (settings?.manualRocketNumber ?? null)
          : null;

  const manualPaymentLogo =
    manualProvider === "BKASH"
      ? (settings?.manualBkashImageUrl ?? null)
      : manualProvider === "NAGAD"
        ? (settings?.manualNagadImageUrl ?? null)
        : manualProvider === "ROCKET"
          ? (settings?.manualRocketImageUrl ?? null)
          : null;

  const manualPayment =
    order.paymentMethod === "MANUAL" || manualPaymentMeta
      ? {
          provider: manualProvider,
          paymentNumber: manualPaymentNumber,
          paymentLogo: manualPaymentLogo,
          senderPhone: asString(manualPaymentMeta?.senderPhone),
          submittedAmount: asNumber(manualPaymentMeta?.submittedAmount),
          submittedAt: asString(manualPaymentMeta?.submittedAt),
          transactionId: asString(order.transactionId),
        }
      : null;

  return (
    <div className="space-y-8 pb-10">
      <SteadfastAutoSync
        orderId={order.id}
        enabled={order.courierName === "Steadfast" || !!order.trackingId}
      />
      <PageHero
        eyebrow="Order Details"
        title={`Order ${displayOrderId}`}
        description={`Placed on ${formatDate(order.createdAt)}. Review the summary, items, invoice, and delivery details in the same polished storefront style.`}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Orders", href: "/orders" },
          { label: "Order Details" },
        ]}
        actions={[
          {
            href: `/orders/${order.id}/invoice${phoneQuery}`,
            label: "Customer Invoice",
          },
          { href: "/orders", label: "Back to orders", variant: "secondary" },
        ]}
        stats={[
          { label: "Order ID", value: displayOrderId },
          { label: "Order total", value: `৳ ${order.total}` },
          { label: "Items", value: String(order.items.length) },
          { label: "Payment", value: String(order.paymentStatus) },
        ]}
      />

      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Order Summary
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Subtotal</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.subtotal}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Discount</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.discount}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Shipping</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.shipping}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Tax</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.tax}
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-2xl border border-[#f8bbd0] bg-[#d81b60] p-4 text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)]">
              <div className="flex items-center justify-between">
                <span className="text-sm text-white/80">Grand Total</span>
                <span className="text-2xl font-bold">৳ {order.total}</span>
              </div>
            </div>
          </Card>

          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="flex items-center justify-between gap-3">
              <div className="text-sm font-semibold text-slate-900">
                Ordered Items
              </div>

              <Link
                href={`/orders/${order.id}/invoice${phoneQuery}`}
                className="rounded-full border border-[#f8bbd0] bg-white px-3 py-1.5 text-xs font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
              >
                View Invoice
              </Link>
            </div>

            <div className="mt-4 space-y-3">
              {order.items.map((it, index) => {
                const variantLabel = formatVariant(
                  it.variant?.type,
                  it.variant?.value,
                );

                return (
                  <div
                    key={it.id}
                    className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-xs text-slate-400">
                          Item #{index + 1}
                        </div>
                        <div className="mt-1 line-clamp-2 text-sm font-semibold text-slate-900">
                          {it.productName}
                        </div>

                        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                          <span>Unit Price: ৳ {it.unitPrice}</span>
                          <span>Qty: {it.qty}</span>
                          {it.sku ? <span>SKU: {it.sku}</span> : null}
                          <span>Variant: {variantLabel ?? "Standard"}</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs text-slate-500">Line Total</div>
                        <div className="text-base font-bold text-slate-900">
                          ৳ {it.lineTotal}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          <RecommendedProducts
            title="You May Also Like"
            excludeProductIds={orderedProductIds}
            categoryIds={recommendedCategoryIds}
            fallbackToFeatured
            limit={8}
          />
        </div>

        <div className="space-y-4">
          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Order Information
            </div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Order ID</div>
                <div className="font-medium text-slate-900">
                  {displayOrderId}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Placed At</div>
                <div className="font-medium text-slate-900">
                  {formatDate(order.createdAt)}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Order Status</div>
                <div className="font-medium text-slate-900">{order.status}</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Payment Method</div>
                <div className="font-medium text-slate-900">
                  {order.paymentMethod}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Payment Status</div>
                <div className="font-medium text-slate-900">
                  {order.paymentStatus}
                </div>
              </div>

              {order.couponCode ? (
                <div>
                  <div className="text-xs text-slate-500">Coupon Code</div>
                  <div className="font-medium text-slate-900">
                    {order.couponCode}
                  </div>
                </div>
              ) : null}
            </div>
          </Card>

          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Delivery Information
            </div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Customer Name</div>
                <div className="font-medium text-slate-900">{order.name}</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Phone</div>
                <div className="font-medium text-slate-900">{order.phone}</div>
              </div>

              {order.email ? (
                <div>
                  <div className="text-xs text-slate-500">Email</div>
                  <div className="font-medium text-slate-900">
                    {order.email}
                  </div>
                </div>
              ) : null}

              <div>
                <div className="text-xs text-slate-500">Address</div>
                <div className="font-medium leading-6 text-slate-700">
                  {order.addressLine1}
                  {order.addressLine2 ? `, ${order.addressLine2}` : ""}
                  {`, ${order.city}`}
                  {order.area ? `, ${order.area}` : ""}
                </div>
              </div>

              {order.note ? (
                <div>
                  <div className="text-xs text-slate-500">Customer Note</div>
                  <div className="rounded-2xl border border-[#f8bbd0] bg-[#fff1f5] p-3 text-slate-700">
                    {order.note}
                  </div>
                </div>
              ) : null}
            </div>
          </Card>

          {manualPayment ? (
            <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
              <div className="text-sm font-semibold text-slate-900">
                Manual Payment Details
              </div>

              <div className="mt-4 space-y-3 text-sm">
                {manualPayment.provider ? (
                  <div>
                    <div className="text-xs text-slate-500">Provider</div>
                    <div className="font-medium text-slate-900">
                      {manualPayment.paymentLogo ? (
                        <div className="flex items-center gap-2">
                          <Image
                            src={manualPayment.paymentLogo}
                            alt={manualPayment.provider ?? "Provider"}
                            width={120}
                            height={36}
                            className="object-contain"
                          />
                        </div>
                      ) : (
                        <>{manualPayment.provider}</>
                      )}
                    </div>
                  </div>
                ) : null}

                {manualPayment.paymentNumber ? (
                  <div>
                    <div className="text-xs text-slate-500">Payment Number</div>
                    <div className="font-medium text-slate-900">
                      {manualPayment.paymentNumber}
                    </div>
                  </div>
                ) : null}

                {manualPayment.senderPhone ? (
                  <div>
                    <div className="text-xs text-slate-500">Sender Number</div>
                    <div className="font-medium text-slate-900">
                      {manualPayment.senderPhone}
                    </div>
                  </div>
                ) : null}

                {manualPayment.transactionId ? (
                  <div>
                    <div className="text-xs text-slate-500">Transaction ID</div>
                    <div className="font-medium text-slate-900">
                      {manualPayment.transactionId}
                    </div>
                  </div>
                ) : null}

                {typeof manualPayment.submittedAmount === "number" ? (
                  <div>
                    <div className="text-xs text-slate-500">
                      Submitted Amount
                    </div>
                    <div className="font-medium text-slate-900">
                      ৳ {manualPayment.submittedAmount}
                    </div>
                  </div>
                ) : null}

                {manualPayment.submittedAt ? (
                  <div>
                    <div className="text-xs text-slate-500">Submitted At</div>
                    <div className="font-medium text-slate-900">
                      {new Date(manualPayment.submittedAt).toLocaleString()}
                    </div>
                  </div>
                ) : null}
              </div>
            </Card>
          ) : null}

          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Courier Details
            </div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Courier Service</div>
                <div className="font-medium text-slate-900">
                  {order.courierName || "Not assigned yet"}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Tracking ID</div>
                <div className="font-medium text-slate-900">
                  {order.trackingId || "Tracking not available yet"}
                </div>
              </div>

              {steadfastMeta.consignmentId ? (
                <div>
                  <div className="text-xs text-slate-500">
                    Steadfast Consignment ID
                  </div>
                  <div className="font-medium text-slate-900">
                    {steadfastMeta.consignmentId}
                  </div>
                </div>
              ) : null}

              {steadfastMeta.trackingCode ? (
                <div>
                  <div className="text-xs text-slate-500">
                    Steadfast Tracking Code
                  </div>
                  <div className="font-medium text-slate-900">
                    {steadfastMeta.trackingCode}
                  </div>
                </div>
              ) : null}

              {steadfastTrackingUrl ? (
                <div>
                  <div className="text-xs text-slate-500">Parcel Tracking</div>
                  <a
                    href={steadfastTrackingUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="font-medium text-blue-600 underline"
                  >
                    Track parcel on Steadfast
                  </a>
                </div>
              ) : null}

              <div>
                <div className="text-xs text-slate-500">Shipping Status</div>
                <div className="font-medium text-slate-900">
                  {order.status === "SHIPPED"
                    ? "Your order has been shipped"
                    : order.status === "DELIVERED"
                      ? "Your order has been delivered"
                      : order.status === "PROCESSING"
                        ? "Your order is being prepared"
                        : order.status === "CANCELLED"
                          ? "This order was cancelled"
                          : "Waiting for courier processing"}
                </div>
              </div>

              {!hasCourierInfo ? (
                <div className="rounded-2xl border border-yellow-200 bg-yellow-50 p-3 text-xs text-yellow-800">
                  Courier details will appear here once the order is processed
                  and assigned.
                </div>
              ) : null}
            </div>
          </Card>

          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Quick Actions
            </div>

            <div className="mt-4 flex flex-col gap-3">
              <Link
                href={`/orders/${order.id}/invoice${phoneQuery}`}
                className="inline-flex h-11 items-center justify-center rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 text-sm font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
              >
                Open Customer Invoice
              </Link>

              <Link
                href="/orders"
                className="inline-flex h-11 items-center justify-center rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 text-sm font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
              >
                My Orders
              </Link>

              <Link
                href="/products"
                className="inline-flex h-11 items-center justify-center rounded-2xl bg-[#d81b60] px-4 text-sm font-medium text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] transition hover:bg-[#c2185b]"
              >
                Continue Shopping
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
