import Link from "next/link";
import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";

import InvoicePrintButton from "@/components/admin/orders/invoice-print-button";
import OrderInvoiceDocument from "@/components/invoices/order-invoice-document";
import { authOptions } from "@/lib/auth";
import { env } from "@/lib/env";
import {
  canAccessCustomerOrder,
  firstSearchParamValue,
} from "@/lib/order-access";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function cleanValue(value: string | null | undefined) {
  const v = value?.trim();
  return v ? v : null;
}

export default async function CustomerInvoicePage({
  params,
  searchParams,
}: {
  params: Promise<{ id?: string }> | { id?: string };
  searchParams?:
    | Promise<{ phone?: string | string[] }>
    | { phone?: string | string[] };
}) {
  const resolvedParams = params instanceof Promise ? await params : params;
  const resolvedSearchParams =
    searchParams instanceof Promise ? await searchParams : searchParams;
  const id = resolvedParams?.id;

  if (!isNonEmptyString(id)) return notFound();

  const session = await getServerSession(authOptions);
  const sessionUserId =
    typeof session?.user?.id === "string" ? session.user.id : null;
  const phoneProof = firstSearchParamValue(resolvedSearchParams?.phone);

  const [order, settings] = await Promise.all([
    prisma.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            variant: {
              select: {
                type: true,
                value: true,
              },
            },
          },
        },
      },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        storeName: true,
        logoUrl: true,
        whatsappUrl: true,
      },
    }),
  ]);

  if (!order) return notFound();

  if (
    !canAccessCustomerOrder({
      sessionUserId,
      orderUserId: order.userId,
      orderPhone: order.phone,
      phoneProof,
    })
  ) {
    return notFound();
  }

  const storeName = settings?.storeName?.trim() || "NexoraMart";
  const storeLogo = settings?.logoUrl?.trim() || "/logo.png";
  const phoneQuery = phoneProof
    ? `?phone=${encodeURIComponent(phoneProof)}`
    : "";

  const contactInfo = {
    whatsapp: cleanValue(settings?.whatsappUrl),
    email: cleanValue(env.RESEND_FROM_EMAIL),
    website: cleanValue(env.NEXT_PUBLIC_BASE_URL),
  };

  return (
    <>
      <style>{`
        @page {
          size: A4 portrait;
          margin: 8mm;
        }

        @media print {
          html, body {
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body * {
            visibility: hidden !important;
          }

          #invoice-print-root,
          #invoice-print-root * {
            visibility: visible !important;
          }

          #invoice-print-root {
            position: absolute !important;
            inset: 0 auto auto 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          .no-print {
            display: none !important;
          }

          .invoice-shell {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          .invoice-card {
            width: 194mm !important;
            min-height: 0 !important;
            height: auto !important;
            max-height: none !important;
            margin: 0 auto !important;
            border-radius: 5mm !important;
            box-shadow: none !important;
            overflow: visible !important;
            break-inside: auto !important;
            page-break-inside: auto !important;
          }

          .invoice-table-wrap {
            overflow: visible !important;
          }

          .invoice-table {
            width: 100% !important;
          }

          .invoice-table thead {
            display: table-header-group !important;
          }

          .invoice-table tfoot {
            display: table-footer-group !important;
          }

          .invoice-table tr {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .invoice-table td,
          .invoice-table th {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .invoice-meta-grid,
          .invoice-summary-grid,
          .invoice-summary-card,
          .invoice-note-card,
          .invoice-thankyou {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .print\\:max-w-none {
            max-width: none !important;
          }

          .print\\:px-0,
          .print\\:pb-0 {
            padding-left: 0 !important;
            padding-right: 0 !important;
            padding-bottom: 0 !important;
          }
        }
      `}</style>

      <div className="no-print mx-auto max-w-5xl px-4 pt-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-lg font-semibold">Customer Invoice</div>
            <div className="text-sm text-black/60">
              Printable customer copy with contact information
            </div>
          </div>

          <div className="flex gap-2">
            <Link
              href={`/orders/${order.id}${phoneQuery}`}
              className="rounded-xl border border-black/10 px-4 py-2 text-sm hover:bg-black/5"
            >
              Back
            </Link>
            <InvoicePrintButton />
          </div>
        </div>
      </div>

      <div
        id="invoice-print-root"
        className="invoice-shell mx-auto max-w-5xl px-4 pb-6 print:max-w-none print:px-0 print:pb-0"
      >
        <OrderInvoiceDocument
          order={order}
          storeName={storeName}
          storeLogo={storeLogo}
          invoiceLabel="Customer Copy"
          subtitle="Customer invoice"
          showContactInfo
          showThankYou
          contactInfo={contactInfo}
        />
      </div>
    </>
  );
}
