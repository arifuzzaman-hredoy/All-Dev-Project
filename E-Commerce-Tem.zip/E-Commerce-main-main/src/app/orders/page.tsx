"use client";

import * as React from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PageHero from "@/components/layout/page-hero";

type OrderItem = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  subtotal: number;
  discount: number;
  shipping: number;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  courierName: string | null;
  trackingId: string | null;
  itemsCount: number;
  itemsPreview: Array<{
    productName: string;
    qty: number;
    lineTotal: number;
  }>;
};

type TrackResponse =
  | {
      ok: true;
      mode: "id" | "phone";
      items: OrderItem[];
    }
  | {
      ok: false;
      error: string;
    };

type MyOrdersResponse = {
  items: Array<{
    id: string;
    publicOrderId: string | null;
    createdAt: string;
    name: string;
    phone: string;
    total: number;
    subtotal: number;
    discount: number;
    shipping: number;
    status: string;
    paymentMethod: string;
    paymentStatus: string;
    courierName: string | null;
    trackingId: string | null;
    itemsCount: number;
    itemsPreview: Array<{
      productName: string;
      qty: number;
      lineTotal: number;
    }>;
  }>;
};

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function getReadableOrderId(order: {
  id: string;
  publicOrderId?: string | null;
}) {
  return order.publicOrderId?.trim() || order.id;
}

function getOrderDetailsHref(order: { id: string; phone?: string | null }) {
  const query = order.phone?.trim()
    ? `?phone=${encodeURIComponent(order.phone.trim())}`
    : "";

  return `/orders/${order.id}${query}`;
}

function parseItemsPreview(input: unknown) {
  const raw = Array.isArray(input) ? input : [];

  return raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productName: safeString(x.productName),
      qty: safeNumber(x.qty, 0),
      lineTotal: safeNumber(x.lineTotal, 0),
    }))
    .filter((x) => x.productName);
}

function parseTrackResponse(input: unknown): TrackResponse {
  const o = input as Record<string, unknown>;

  if (o.ok === false) {
    return {
      ok: false,
      error: safeString(o.error, "Something went wrong"),
    };
  }

  const raw = Array.isArray(o.items) ? o.items : [];

  return {
    ok: true,
    mode: (safeString(o.mode) === "phone" ? "phone" : "id") as "id" | "phone",
    items: raw
      .map((x) => x as Record<string, unknown>)
      .map((x) => ({
        id: safeString(x.id),
        publicOrderId:
          typeof x.publicOrderId === "string" ? x.publicOrderId : null,
        createdAt: safeString(x.createdAt),
        name: safeString(x.name),
        phone: safeString(x.phone),
        total: safeNumber(x.total, 0),
        subtotal: safeNumber(x.subtotal, 0),
        discount: safeNumber(x.discount, 0),
        shipping: safeNumber(x.shipping, 0),
        status: safeString(x.status),
        paymentMethod: safeString(x.paymentMethod),
        paymentStatus: safeString(x.paymentStatus),
        courierName: typeof x.courierName === "string" ? x.courierName : null,
        trackingId: typeof x.trackingId === "string" ? x.trackingId : null,
        itemsCount: safeNumber(x.itemsCount, 0),
        itemsPreview: parseItemsPreview(x.itemsPreview),
      }))
      .filter((x) => x.id),
  };
}

function parseMyOrdersResponse(input: unknown): MyOrdersResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  return {
    items: raw
      .map((x) => x as Record<string, unknown>)
      .map((x) => ({
        id: safeString(x.id),
        publicOrderId:
          typeof x.publicOrderId === "string" ? x.publicOrderId : null,
        createdAt: safeString(x.createdAt),
        name: safeString(x.name),
        phone: safeString(x.phone),
        total: safeNumber(x.total, 0),
        subtotal: safeNumber(x.subtotal, 0),
        discount: safeNumber(x.discount, 0),
        shipping: safeNumber(x.shipping, 0),
        status: safeString(x.status),
        paymentMethod: safeString(x.paymentMethod),
        paymentStatus: safeString(x.paymentStatus),
        courierName: typeof x.courierName === "string" ? x.courierName : null,
        trackingId: typeof x.trackingId === "string" ? x.trackingId : null,
        itemsCount: safeNumber(x.itemsCount, 0),
        itemsPreview: parseItemsPreview(x.itemsPreview),
      }))
      .filter((x) => x.id),
  };
}

function OrderStatusBadge({ value }: { value: string }) {
  const cls =
    value === "DELIVERED"
      ? "bg-green-50 text-green-700"
      : value === "CANCELLED"
        ? "bg-red-50 text-red-700"
        : value === "SHIPPED"
          ? "bg-blue-50 text-blue-700"
          : value === "PROCESSING"
            ? "bg-yellow-50 text-yellow-700"
            : "bg-black/5 text-black/70";

  return (
    <span className={`rounded-full px-2 py-1 text-[11px] font-medium ${cls}`}>
      {value}
    </span>
  );
}

function PaymentStatusBadge({ value }: { value: string }) {
  const cls =
    value === "PAID"
      ? "bg-green-50 text-green-700"
      : value === "FAILED" || value === "REFUNDED"
        ? "bg-red-50 text-red-700"
        : "bg-black/5 text-black/70";

  return (
    <span className={`rounded-full px-2 py-1 text-[11px] font-medium ${cls}`}>
      {value}
    </span>
  );
}

function CustomerOrderCard({
  order,
  showCustomer = false,
}: {
  order: OrderItem;
  showCustomer?: boolean;
}) {
  const displayOrderId = getReadableOrderId(order);
  const detailsHref = getOrderDetailsHref(order);
  const invoiceHref = `${detailsHref.replace(
    `/orders/${order.id}`,
    `/orders/${order.id}/invoice`,
  )}`;

  return (
    <div className="rounded-2xl border border-[#f8bbd0] bg-white/85 p-4 shadow-[0_12px_34px_-28px_rgba(216,27,96,0.22)] transition hover:bg-[#fff7fb]">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold text-slate-900">
            #{displayOrderId}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            {new Date(order.createdAt).toLocaleString()} • {order.itemsCount}{" "}
            items
          </div>
          {showCustomer ? (
            <div className="mt-1 text-xs text-slate-500">
              {order.name} • {order.phone}
            </div>
          ) : null}
        </div>

        <div className="text-right">
          <div className="text-base font-semibold text-slate-900">
            ৳ {order.total}
          </div>
          <div className="mt-1 flex flex-wrap justify-end gap-1">
            <OrderStatusBadge value={order.status} />
            <PaymentStatusBadge value={order.paymentStatus} />
          </div>
        </div>
      </div>

      <div className="mt-3 grid gap-2 text-xs text-slate-600 sm:grid-cols-3">
        <div className="rounded-xl border border-[#f8bbd0] bg-[#fff7fb] px-3 py-2">
          <div className="text-slate-400">Payment</div>
          <div className="font-medium text-slate-800">
            {order.paymentMethod || "Not set"}
          </div>
        </div>
        <div className="rounded-xl border border-[#f8bbd0] bg-[#fff7fb] px-3 py-2">
          <div className="text-slate-400">Shipping</div>
          <div className="font-medium text-slate-800">৳ {order.shipping}</div>
        </div>
        <div className="rounded-xl border border-[#f8bbd0] bg-[#fff7fb] px-3 py-2">
          <div className="text-slate-400">Courier</div>
          <div className="truncate font-medium text-slate-800">
            {order.courierName || "Not assigned"}
          </div>
        </div>
      </div>

      {order.itemsPreview.length ? (
        <div className="mt-3 space-y-1 rounded-xl border border-[#f8bbd0] bg-white px-3 py-2">
          {order.itemsPreview.map((item, index) => (
            <div
              key={`${item.productName}-${index}`}
              className="flex items-center justify-between gap-3 text-xs"
            >
              <span className="line-clamp-1 text-slate-700">
                {item.productName} × {item.qty}
              </span>
              <span className="shrink-0 font-medium text-slate-900">
                ৳ {item.lineTotal}
              </span>
            </div>
          ))}
          {order.itemsCount > order.itemsPreview.length ? (
            <div className="text-xs text-slate-400">
              +{order.itemsCount - order.itemsPreview.length} more item
              {order.itemsCount - order.itemsPreview.length === 1 ? "" : "s"}
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="min-w-0 text-slate-500">
          {order.trackingId
            ? `Tracking: ${order.trackingId}`
            : "Tracking will appear after courier booking"}
        </div>

        <div className="flex gap-2">
          <Link
            href={invoiceHref}
            className="rounded-full border border-[#f8bbd0] bg-white px-3 py-1.5 font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
          >
            Invoice
          </Link>
          <Link
            href={detailsHref}
            className="rounded-full bg-[#d81b60] px-3 py-1.5 font-medium text-white transition hover:bg-[#c2185b]"
          >
            View Details
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function OrdersPage() {
  const { status } = useSession();

  const [orderId, setOrderId] = React.useState("");
  const [phone, setPhone] = React.useState("");

  const [loadingTrack, setLoadingTrack] = React.useState(false);
  const [trackResult, setTrackResult] = React.useState<TrackResponse | null>(
    null,
  );

  const [loadingMine, setLoadingMine] = React.useState(false);
  const [myOrders, setMyOrders] = React.useState<MyOrdersResponse>({
    items: [],
  });

  React.useEffect(() => {
    if (status !== "authenticated") return;

    const loadMyOrders = async () => {
      setLoadingMine(true);
      try {
        const res = await fetch("/api/orders/account", { cache: "no-store" });
        const json: unknown = await res.json().catch(() => null);
        setMyOrders(parseMyOrdersResponse(json));
      } finally {
        setLoadingMine(false);
      }
    };

    void loadMyOrders();
  }, [status]);

  const searchById = async () => {
    const value = orderId.trim();
    if (!value) return;

    setLoadingTrack(true);
    setTrackResult(null);

    try {
      const res = await fetch(
        `/api/orders/track?orderId=${encodeURIComponent(value)}`,
        { cache: "no-store" },
      );
      const json: unknown = await res.json().catch(() => null);
      setTrackResult(parseTrackResponse(json));
    } finally {
      setLoadingTrack(false);
    }
  };

  const searchByPhone = async () => {
    const value = phone.trim();
    if (!value) return;

    setLoadingTrack(true);
    setTrackResult(null);

    try {
      const res = await fetch(
        `/api/orders/track?phone=${encodeURIComponent(value)}`,
        { cache: "no-store" },
      );
      const json: unknown = await res.json().catch(() => null);
      setTrackResult(parseTrackResponse(json));
    } finally {
      setLoadingTrack(false);
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <PageHero
        eyebrow="Orders & Tracking"
        title="Find your order."
        description="Track by order ID or phone number"
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Orders & Tracking" },
        ]}
        actions={[
          { href: "/products", label: "Browse products" },
          { href: "/cart", label: "Open cart", variant: "secondary" },
        ]}
        stats={[
          { label: "Search options", value: "2" },
          { label: "Account orders", value: "Live" },
          { label: "Tracking mode", value: "Fast" },
          { label: "Details page", value: "Ready" },
        ]}
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)]">
          <div className="text-sm font-semibold text-[#ad1457]">
            Track by Order ID
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Write your short order ID or full order ID to track a single order
          </div>

          <div className="mt-3 flex gap-2">
            <Input
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="Enter order ID (example: SB-000123)"
            />
            <Button
              onClick={() => void searchById()}
              disabled={loadingTrack}
              className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
            >
              Search
            </Button>
          </div>

          <div className="mt-6 text-sm font-semibold text-[#ad1457]">
            Track by Phone
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Write your phone number to track recent orders with that phone
            number. This is useful if you don&apos;t remember your order ID.
          </div>

          <div className="mt-3 flex gap-2">
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Enter phone number"
            />
            <Button
              onClick={() => void searchByPhone()}
              disabled={loadingTrack}
              className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
            >
              Search
            </Button>
          </div>

          <div className="mt-6 rounded-2xl border border-[#f8bbd0] bg-white/80 p-4 text-xs text-slate-600 shadow-[0_12px_34px_-24px_rgba(216,27,96,0.18)]">
            Tip: Search with short order ID like <b>SB-000123</b> for better
            results.
          </div>
        </Card>

        <div className="space-y-4">
          {status === "authenticated" ? (
            <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    My Orders
                  </div>
                  <div className="text-xs text-slate-600">
                    Logged-in account orders
                  </div>
                </div>
              </div>

              <div className="mt-3 space-y-2">
                {loadingMine ? (
                  <div className="text-sm text-slate-600">
                    Loading your orders...
                  </div>
                ) : myOrders.items.length ? (
                  myOrders.items.map((order) => (
                    <CustomerOrderCard key={order.id} order={order} />
                  ))
                ) : (
                  <div className="text-sm text-slate-600">
                    No account orders found.
                  </div>
                )}
              </div>
            </Card>
          ) : null}

          <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-white to-white p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Tracking Result
            </div>

            <div className="mt-3 space-y-2">
              {loadingTrack ? (
                <div className="text-sm text-slate-600">
                  Searching orders...
                </div>
              ) : trackResult?.ok === false ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {trackResult.error}
                </div>
              ) : trackResult?.ok === true && trackResult.items.length ? (
                trackResult.items.map((order) => (
                  <CustomerOrderCard
                    key={order.id}
                    order={order}
                    showCustomer
                  />
                ))
              ) : (
                <div className="text-sm text-black/60">
                  Search by Order ID or phone number to track orders.
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
