import CartClient from "@/components/cart/cart-client";

export const dynamic = "force-dynamic";
export const revalidate = 0;
export default function CartPage() {
  return <CartClient />;
}