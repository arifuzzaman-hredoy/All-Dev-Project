import { Suspense } from "react";
import SignUpClient from "@/app/(auth)/register/SignUpClient";

export default function RegisterPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SignUpClient />
    </Suspense>
  );
}
