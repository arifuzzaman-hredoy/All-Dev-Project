"use client";

import Link from "next/link";
import * as React from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

export default function ForgotPasswordPage() {
  const { toast } = useToast();
  const [email, setEmail] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data: unknown = await res.json().catch(() => ({}));
    setLoading(false);

    if (!res.ok) {
      toast({
        title: "Request failed",
        variant: "error",
        description:
          (data as { error?: string })?.error || "Please try again.",
      });
      return;
    }

    setSent(true);
    toast({
      title: "Check your email",
      variant: "success",
      description:
        "If that email exists, a password reset link has been sent.",
    });
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-10">
      <div className="w-full max-w-xl">
        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          <div className="inline-flex rounded-sm bg-[#ec407a]/15 px-3 py-1 text-xs font-medium text-[#ad1457]">
            Password reset
          </div>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-slate-900">
            Reset your password.
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Enter your account email and we will send a secure reset link.
          </p>

          {sent ? (
            <div className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
              If an account exists for {email}, a reset link is on the way.
            </div>
          ) : null}

          <form onSubmit={onSubmit} className="mt-6 space-y-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                Email
              </label>
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                type="email"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                required
              />
            </div>

            <Button
              className="w-full bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
              disabled={loading}
            >
              {loading ? "Sending..." : "Send reset link"}
            </Button>
          </form>

          <div className="mt-4 text-sm text-slate-600">
            Remembered it?{" "}
            <Link
              className="font-medium text-[#ad1457] underline underline-offset-4"
              href="/login"
            >
              Login
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
