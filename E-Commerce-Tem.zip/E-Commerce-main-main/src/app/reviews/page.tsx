import type { Metadata } from "next";
import Link from "next/link";
import { Star } from "lucide-react";
import ReviewsGalleryClient from "@/components/reviews/reviews-gallery-client";
import {
  getReviewGalleryPage,
  REVIEW_GALLERY_TAKE,
} from "@/lib/services/review-gallery";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Customer Reviews | NexoraMart",
  description: "See real customer reviews from NexoraMart.",
};

export default async function ReviewsPage() {
  const page = await getReviewGalleryPage({ take: REVIEW_GALLERY_TAKE });

  return (
    <main className="min-h-screen bg-linear-to-b from-[#fff7fb] via-white to-white">
      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6 lg:py-12">
        <div className="mb-8 flex flex-wrap items-center gap-2 rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 py-3 text-sm text-slate-500 shadow-sm backdrop-blur">
          <Link href="/" className="transition hover:text-[#ad1457] hover:underline">
            Home
          </Link>
          <span className="text-[#d81b60]">/</span>
          <span className="font-medium text-slate-900">Reviews</span>
        </div>

        <section className="mb-8 rounded-[36px] border border-[#f8bbd0] bg-white p-6 shadow-[0_28px_90px_-64px_rgba(216,27,96,0.55)] sm:p-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#fff1f5] px-3 py-1 text-xs font-bold uppercase tracking-wide text-[#ad1457]">
              <Star className="h-3.5 w-3.5" />
              Customer reviews
            </div>
            <h1 className="mt-4 text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">
              Real customer reviews
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-600 sm:text-base">
              Browse customer feedback for our products. Click any review to
              open the product page and jump directly to its review section.
            </p>
          </div>
        </section>

        <ReviewsGalleryClient
          initialItems={page.items}
          initialHasMore={page.hasMore}
          initialNextSkip={page.nextSkip}
        />
      </div>
    </main>
  );
}
