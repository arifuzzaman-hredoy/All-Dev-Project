import PaymentSuccessCartCleanup from "@/components/checkout/payment-success-cart-cleanup";

type Props = {
  searchParams: Promise<{
    status?: string;
    orderId?: string;
    reason?: string;
  }>;
};

export default async function PaymentResultPage({ searchParams }: Props) {
  const params = await searchParams;
  const status = params.status;

  let title = "Payment status unknown";
  let message = "We could not determine your payment result.";

  if (status === "success") {
    title = "Payment successful";
    message = `Your payment has been confirmed. Order ID: ${params.orderId ?? ""}`;
  } else if (status === "failed") {
    title = "Payment failed";
    message = "Your payment failed. Please try again.";
  } else if (status === "cancelled") {
    title = "Payment cancelled";
    message = "You cancelled the payment.";
  }

  return (
    <main className="container mx-auto max-w-2xl px-4 py-10">
      <div className="rounded-xl border p-6 shadow-sm">
        {status === "success" ? <PaymentSuccessCartCleanup /> : null}
        <h1 className="text-2xl font-semibold">{title}</h1>
        <p className="mt-3 text-sm text-gray-600">{message}</p>
      </div>
    </main>
  );
}
