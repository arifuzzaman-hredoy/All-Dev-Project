"use client";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { getCategoryDisplayPath } from "@/lib/category-tree";
import {
  ArrowLeft,
  ArrowRight,
  CheckSquare,
  Copy,
  ImagePlus,
  Layers3,
  Loader2,
  Pencil,
  Plus,
  RotateCcw,
  Save,
  Send,
  Star,
  Trash2,
  X,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import * as React from "react";

function Modal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  React.useEffect(() => {
    if (!open) return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };

    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-130">
      <button
        type="button"
        aria-label="Close modal"
        onClick={onClose}
        className="absolute inset-0 bg-black/50"
      />
      <div className="absolute inset-0 flex items-start justify-center overflow-y-auto px-4 pb-8 pt-20 sm:px-6 sm:pb-10 sm:pt-24">
        <div className="w-full max-w-6xl">
          <div className="flex max-h-[calc(100dvh-7rem)] flex-col overflow-hidden rounded-3xl border border-black/10 bg-white shadow-xl">
            <div className="flex items-center justify-between gap-3 border-b border-black/10 px-5 py-4">
              <div className="text-sm font-semibold">{title}</div>
              <Button
                variant="secondary"
                onClick={onClose}
                className={neutralButtonClass}
              >
                <X className="h-4 w-4" />
                Close
              </Button>
            </div>

            <div className="flex-1 overflow-auto p-5">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

type Category = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  isActive: boolean;
  parent?: { id: string; name: string; slug: string } | null;
};

type VariantForm = {
  id?: string;
  type: string;
  value: string;
  priceDiff: number;
  investedAmount: number;
  stock: number;
  images: string[];
};

type Product = {
  id: string;
  name: string;
  sku: string;
  description?: string | null;
  youtubeUrl?: string | null;
  price: number;
  offerPrice: number | null;
  investedAmount: number | null;
  stock: number;
  isFeatured: boolean;
  isActive: boolean;
  categoryId: string;
  category: {
    id: string;
    name: string;
    slug: string;
    parent?: { id: string; name: string; slug: string } | null;
  } | null;
  categories: Array<{
    id: string;
    category: {
      id: string;
      name: string;
      slug: string;
      parent?: { id: string; name: string; slug: string } | null;
    };
  }>;
  images: { url: string }[];
  variants: Array<{
    id: string;
    type: string;
    value: string;
    priceDiff: number;
    investedAmount: number | null;
    stock: number;
    images: { url: string }[];
  }>;
};

type UploadResponse = { url?: string; error?: string };

const ACCEPTED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

const MAX_IMAGE_SIZE = 25 * 1024 * 1024;
const ITEMS_PER_PAGE = 10;

function formatMoney(amount: number | null | undefined): string {
  return `৳${Number(amount || 0)}`;
}

function validateImageFile(file: File): string | null {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    return "Only PNG, JPG, JPEG, and WEBP images are allowed.";
  }

  if (file.size > MAX_IMAGE_SIZE) {
    return "Each image must be 25MB or less.";
  }

  return null;
}

function getProductCategoryIds(product: Product): string[] {
  const linkedIds = product.categories
    .map((item) => item.category.id)
    .filter(Boolean);

  return Array.from(
    new Set([product.categoryId, ...linkedIds].filter(Boolean)),
  );
}

function getProductCategoryDisplayPaths(
  product: Product,
  categories: Category[],
): string[] {
  const categoryIds = getProductCategoryIds(product);

  if (!categoryIds.length) return ["Uncategorized"];

  return categoryIds.map((categoryId) =>
    getCategoryDisplayPath(categoryId, categories),
  );
}

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);

  const res = await fetch("/api/upload/product-image", {
    method: "POST",
    body: fd,
  });

  const data: UploadResponse = await res.json().catch(() => ({}));

  if (!res.ok) throw new Error(data.error || "Upload failed");
  if (!data.url) throw new Error("Upload failed: missing image URL");

  return data.url;
}

const emptyVariantForm: VariantForm = {
  type: "Color",
  value: "",
  priceDiff: 0,
  investedAmount: 0,
  stock: 0,
  images: [],
};

const VARIANT_EDITOR_ID = "variant-editor";

const actionButtonClass =
  "bg-blue-600 text-white hover:bg-blue-700 focus-visible:ring-blue-600";
const editButtonClass =
  "border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100 focus-visible:ring-amber-500";
const uploadButtonClass =
  "border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 focus-visible:ring-emerald-500";
const neutralButtonClass =
  "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 focus-visible:ring-slate-500";
const featuredButtonClass =
  "border-yellow-200 bg-yellow-50 text-yellow-700 hover:bg-yellow-100 focus-visible:ring-yellow-500";

const facebookButtonClass =
  "border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 focus-visible:ring-blue-500";

function AdminProductsClient() {
  const LOW_STOCK_LIMIT = 5;

  const sp = useSearchParams();
  const filter = (sp.get("filter") || "").trim();
  const isLowStockFilter = filter === "low_stock";
  const isMainStockOutFilter = filter === "main_stock_out";
  const isVariantStockOutFilter = filter === "variant_stock_out";

  const [categories, setCategories] = React.useState<Category[]>([]);
  const [items, setItems] = React.useState<Product[]>([]);
  const [loadingList, setLoadingList] = React.useState(false);
  const [togglingFeaturedId, setTogglingFeaturedId] = React.useState<
    string | null
  >(null);

  const [postingFacebookId, setPostingFacebookId] = React.useState<
    string | null
  >(null);

  const [listQuery, setListQuery] = React.useState("");
  const [page, setPage] = React.useState(1);
  const [selectedProductIds, setSelectedProductIds] = React.useState<string[]>(
    [],
  );
  const [bulkBusy, setBulkBusy] = React.useState<
    null | "delete" | "feature" | "category" | "addCategory"
  >(null);
  const [showBulkCategoryModal, setShowBulkCategoryModal] =
    React.useState(false);
  const [showBulkCopyCategoryModal, setShowBulkCopyCategoryModal] =
    React.useState(false);
  const [bulkCategoryId, setBulkCategoryId] = React.useState("");
  const [bulkCopyCategoryId, setBulkCopyCategoryId] = React.useState("");

  const [showForm, setShowForm] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);

  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [youtubeUrl, setYoutubeUrl] = React.useState("");
  const [price, setPrice] = React.useState<number>(0);
  const [offerPrice, setOfferPrice] = React.useState<number>(0);
  const [investedAmount, setInvestedAmount] = React.useState<number>(0);
  const [stock, setStock] = React.useState<number>(0);
  const [categoryIds, setCategoryIds] = React.useState<string[]>([]);

  const [isFeatured, setIsFeatured] = React.useState(false);
  const [isActive, setIsActive] = React.useState(true);

  const [images, setImages] = React.useState<string[]>([]);
  const [uploading, setUploading] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [formError, setFormError] = React.useState<string | null>(null);

  const [variants, setVariants] = React.useState<VariantForm[]>([]);
  const [variantDraft, setVariantDraft] =
    React.useState<VariantForm>(emptyVariantForm);
  const [variantEditIndex, setVariantEditIndex] = React.useState<number | null>(
    null,
  );
  const [variantUploading, setVariantUploading] = React.useState(false);

  const productFileRef = React.useRef<HTMLInputElement | null>(null);
  const variantFileRef = React.useRef<HTMLInputElement | null>(null);

  const { toast } = useToast();

  const mainCategories = React.useMemo(
    () => categories.filter((c) => !c.parentId && c.isActive),
    [categories],
  );

  const selectedCategoryOptions = React.useMemo(() => {
    return categories.filter((cat) => categoryIds.includes(cat.id));
  }, [categories, categoryIds]);

  function toggleCategorySelection(categoryId: string) {
    setCategoryIds((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId],
    );
  }

  const selectedProductIdsSet = React.useMemo(
    () => new Set(selectedProductIds),
    [selectedProductIds],
  );

  const activeCategoryOptions = React.useMemo(() => {
    return categories.filter((c) => c.isActive);
  }, [categories]);

  const load = React.useCallback(async () => {
    setLoadingList(true);

    try {
      const [cRes, pRes] = await Promise.all([
        fetch("/api/admin/categories", { cache: "no-store" }),
        fetch("/api/admin/products", { cache: "no-store" }),
      ]);

      const cRaw: unknown = await cRes.json().catch(() => []);
      const pRaw: unknown = await pRes.json().catch(() => []);

      const nextCategories = Array.isArray(cRaw) ? (cRaw as Category[]) : [];
      const nextItems = Array.isArray(pRaw) ? (pRaw as Product[]) : [];

      setCategories(nextCategories);
      setItems(nextItems);

      const validIds = new Set(nextItems.map((item) => item.id));
      setSelectedProductIds((prev) => prev.filter((id) => validIds.has(id)));
    } catch {
      setCategories([]);
      setItems([]);
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not load products or categories.",
      });
    } finally {
      setLoadingList(false);
    }
  }, [toast]);

  React.useEffect(() => {
    void load();
  }, [load]);

  React.useEffect(() => {
    if (!categoryIds.length && categories.length) {
      const firstActive = categories.find((c) => c.isActive);
      if (firstActive) setCategoryIds([firstActive.id]);
    }
  }, [categories, categoryIds]);

  React.useEffect(() => {
    setPage(1);
  }, [listQuery, filter]);

  function resetForm() {
    setEditingId(null);
    setName("");
    setDescription("");
    setYoutubeUrl("");
    setPrice(0);
    setOfferPrice(0);
    setInvestedAmount(0);
    setStock(0);
    setCategoryIds(
      categories.find((c) => c.isActive)?.id
        ? [categories.find((c) => c.isActive)!.id]
        : [],
    );
    setIsFeatured(false);
    setIsActive(true);
    setImages([]);
    setVariants([]);
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    setFormError(null);

    if (productFileRef.current) productFileRef.current.value = "";
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function openCreate() {
    resetForm();
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditingId(null);
    setFormError(null);
    setVariantEditIndex(null);
    setVariantDraft(emptyVariantForm);

    if (productFileRef.current) productFileRef.current.value = "";
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function startEdit(product: Product) {
    setEditingId(product.id);
    setName(product.name);
    setDescription(product.description ?? "");
    setYoutubeUrl(product.youtubeUrl ?? "");
    setPrice(product.price);
    setOfferPrice(product.offerPrice ?? 0);
    setInvestedAmount(product.investedAmount ?? 0);
    setStock(product.stock);
    setCategoryIds(
      product.categories?.length
        ? product.categories.map((item) => item.category.id)
        : product.categoryId
          ? [product.categoryId]
          : [],
    );
    setIsFeatured(product.isFeatured);
    setIsActive(product.isActive);
    setImages(product.images.map((img) => img.url));
    setVariants(
      product.variants.map((v) => ({
        id: v.id,
        type: v.type,
        value: v.value,
        priceDiff: v.priceDiff,
        investedAmount: v.investedAmount ?? 0,
        stock: v.stock,
        images: v.images.map((img) => img.url),
      })),
    );
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    setFormError(null);
    setShowForm(true);
  }

  function moveImage(
    source: "product" | "variant",
    index: number,
    direction: "left" | "right",
  ) {
    const updater = (prev: string[]) => {
      const next = [...prev];
      const target = direction === "left" ? index - 1 : index + 1;

      if (target < 0 || target >= next.length) return prev;

      [next[index], next[target]] = [next[target], next[index]];
      return next;
    };

    if (source === "product") {
      setImages(updater);
    } else {
      setVariantDraft((prev) => ({
        ...prev,
        images: updater(prev.images),
      }));
    }
  }

  function removeProductImage(url: string) {
    setImages((prev) => prev.filter((x) => x !== url));
  }

  function removeVariantImage(url: string) {
    setVariantDraft((prev) => ({
      ...prev,
      images: prev.images.filter((x) => x !== url),
    }));
  }

  async function onPickProductFiles(files: FileList | null) {
    if (!files?.length) return;

    setFormError(null);
    setUploading(true);

    try {
      const list = Array.from(files);
      const validationErrors = list
        .map((file) => validateImageFile(file))
        .filter(Boolean) as string[];

      if (validationErrors.length) {
        throw new Error(validationErrors[0]);
      }

      const uploaded: string[] = [];

      for (const file of list) {
        const url = await uploadFile(file);
        uploaded.push(url);
      }

      setImages((prev) => [...prev, ...uploaded]);

      toast({
        title: "Uploaded",
        description: `${uploaded.length} shared product image uploaded successfully.`,
      });
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
      if (productFileRef.current) productFileRef.current.value = "";
    }
  }

  async function onPickVariantFiles(files: FileList | null) {
    if (!files?.length) return;

    setFormError(null);
    setVariantUploading(true);

    try {
      const list = Array.from(files);
      const validationErrors = list
        .map((file) => validateImageFile(file))
        .filter(Boolean) as string[];

      if (validationErrors.length) {
        throw new Error(validationErrors[0]);
      }

      const uploaded: string[] = [];

      for (const file of list) {
        const url = await uploadFile(file);
        uploaded.push(url);
      }

      setVariantDraft((prev) => ({
        ...prev,
        images: [...prev.images, ...uploaded],
      }));

      toast({
        title: "Uploaded",
        description: `${uploaded.length} variant image uploaded successfully.`,
      });
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setVariantUploading(false);
      if (variantFileRef.current) variantFileRef.current.value = "";
    }
  }

  function resetVariantDraft() {
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function saveVariantDraft() {
    setFormError(null);

    const value = variantDraft.value.trim();
    const type = variantDraft.type.trim();

    if (!type || !value) {
      setFormError("Variant type and value are required.");
      return;
    }

    if (variantDraft.stock < 0) {
      setFormError("Variant stock cannot be negative.");
      return;
    }

    if (variantDraft.investedAmount < 0) {
      setFormError("Variant invested amount cannot be negative.");
      return;
    }

    const duplicate = variants.some((v, idx) => {
      if (variantEditIndex !== null && idx === variantEditIndex) return false;

      return (
        v.type.trim().toLowerCase() === type.toLowerCase() &&
        v.value.trim().toLowerCase() === value.toLowerCase()
      );
    });

    if (duplicate) {
      setFormError("This variant already exists.");
      return;
    }

    const payload: VariantForm = {
      id: variantDraft.id,
      type,
      value,
      priceDiff: Number(variantDraft.priceDiff) || 0,
      investedAmount:
        variantDraft.investedAmount > 0
          ? Math.round(Number(variantDraft.investedAmount))
          : 0,
      stock: Number(variantDraft.stock) || 0,
      images: variantDraft.images,
    };

    if (variantEditIndex !== null) {
      setVariants((prev) =>
        prev.map((item, idx) => (idx === variantEditIndex ? payload : item)),
      );
    } else {
      setVariants((prev) => [...prev, payload]);
    }

    resetVariantDraft();
  }

  function editVariant(index: number) {
    setVariantEditIndex(index);
    setVariantDraft(variants[index]);

    document.getElementById(VARIANT_EDITOR_ID)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }

  function removeVariant(index: number) {
    setVariants((prev) => prev.filter((_, i) => i !== index));

    if (variantEditIndex === index) {
      resetVariantDraft();
    }
  }

  async function save() {
    setFormError(null);

    if (!name.trim()) {
      setFormError("Product name is required.");
      return;
    }

    if (!categoryIds.length) {
      setFormError("At least one category is required.");
      return;
    }

    if (price <= 0) {
      setFormError("Price must be greater than 0.");
      return;
    }

    if (stock < 0) {
      setFormError("Stock cannot be negative.");
      return;
    }

    if (offerPrice < 0) {
      setFormError("Offer price cannot be negative.");
      return;
    }

    if (offerPrice > 0 && offerPrice >= price) {
      setFormError("Offer price should be less than regular price.");
      return;
    }

    if (investedAmount < 0) {
      setFormError("Invested amount cannot be negative.");
      return;
    }

    if (images.length === 0) {
      setFormError("At least one shared product image is required.");
      return;
    }

    const body = {
      name: name.trim(),
      description: description.trim() ? description.trim() : null,
      youtubeUrl: youtubeUrl.trim() ? youtubeUrl.trim() : null,
      price: Number(price),
      offerPrice: offerPrice > 0 ? Number(offerPrice) : null,
      investedAmount:
        investedAmount > 0 ? Math.round(Number(investedAmount)) : null,
      stock: Number(stock),
      categoryIds,
      isFeatured,
      isActive,
      images,
      variants: variants.map((variant) => ({
        ...variant,
        investedAmount:
          variant.investedAmount > 0
            ? Math.round(Number(variant.investedAmount))
            : null,
      })),
    };

    const url = editingId
      ? `/api/admin/products/${editingId}`
      : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";

    setSaving(true);

    try {
      const res = await fetch(url, {
        method,
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

      const d: unknown = await res.json().catch(() => ({}));

      if (!res.ok) {
        const msg =
          (d as { error?: string })?.error || "Save failed. Please try again.";
        setFormError(msg);
        return;
      }

      toast({
        title: editingId ? "Updated" : "Created",
        description: editingId
          ? "Product updated successfully."
          : "Product created successfully.",
      });

      closeForm();
      await load();
    } catch {
      setFormError("Save failed. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleFeatured(product: Product) {
    if (togglingFeaturedId) return;

    setTogglingFeaturedId(product.id);

    try {
      const body = {
        name: product.name,
        description: product.description ?? null,
        youtubeUrl: product.youtubeUrl ?? null,
        price: Number(product.price),
        offerPrice: product.offerPrice ?? null,
        investedAmount: product.investedAmount ?? null,
        stock: Number(product.stock),
        categoryIds: product.categories?.length
          ? product.categories.map((item) => item.category.id)
          : product.categoryId
            ? [product.categoryId]
            : [],
        isFeatured: !product.isFeatured,
        isActive: product.isActive,
        images: product.images.map((img) => img.url),
        variants: product.variants.map((variant) => ({
          id: variant.id,
          type: variant.type,
          value: variant.value,
          priceDiff: variant.priceDiff,
          investedAmount: variant.investedAmount ?? null,
          stock: variant.stock,
          images: variant.images.map((img) => img.url),
        })),
      };

      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

      const data: unknown = await res.json().catch(() => ({}));

      if (!res.ok) {
        const msg =
          (data as { error?: string })?.error ||
          "Could not update featured status.";
        toast({
          variant: "error",
          title: "Failed",
          description: msg,
        });
        return;
      }

      setItems((prev) =>
        prev.map((item) =>
          item.id === product.id
            ? {
                ...item,
                isFeatured: !product.isFeatured,
              }
            : item,
        ),
      );

      if (editingId === product.id) {
        setIsFeatured(!product.isFeatured);
      }

      toast({
        title: !product.isFeatured ? "Featured enabled" : "Featured removed",
        description: `${product.name} ${
          !product.isFeatured ? "is now featured." : "is no longer featured."
        }`,
      });
    } catch {
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not update featured status.",
      });
    } finally {
      setTogglingFeaturedId(null);
    }
  }

  async function postToFacebook(product: Product) {
    if (postingFacebookId) return;

    const ok = window.confirm(
      `Post "${product.name}" to your Facebook Page now?`,
    );
    if (!ok) return;

    setPostingFacebookId(product.id);

    try {
      const res = await fetch(
        `/api/admin/products/${product.id}/facebook-post`,
        {
          method: "POST",
        },
      );

      const data: unknown = await res.json().catch(() => ({}));

      if (!res.ok) {
        const msg =
          (data as { error?: string })?.error ||
          "Could not post product to Facebook.";
        toast({
          variant: "error",
          title: "Facebook post failed",
          description: msg,
        });
        return;
      }

      toast({
        title: "Posted to Facebook",
        description: `${product.name} has been posted to your Facebook Page successfully.`,
      });
    } catch {
      toast({
        variant: "error",
        title: "Facebook post failed",
        description: "Could not post product to Facebook.",
      });
    } finally {
      setPostingFacebookId(null);
    }
  }

  async function remove(id: string) {
    const ok = window.confirm("Delete this product?");
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Delete failed",
        });
        return;
      }

      toast({
        title: "Deleted",
        description: "Product deleted successfully.",
      });

      if (editingId === id) closeForm();
      await load();
    } catch {
      toast({
        variant: "error",
        title: "Delete failed",
      });
    }
  }

  function toggleSelectProduct(productId: string) {
    setSelectedProductIds((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId],
    );
  }

  function clearSelection() {
    setSelectedProductIds([]);
  }

  async function runBulkAction(
    action: "delete" | "feature" | "category" | "addCategory",
    extra?: { categoryId?: string },
  ) {
    if (!selectedProductIds.length) {
      toast({
        variant: "error",
        title: "No products selected",
        description: "Please select one or more products first.",
      });
      return;
    }

    if (
      (action === "category" || action === "addCategory") &&
      !extra?.categoryId
    ) {
      toast({
        variant: "error",
        title: "Category required",
        description: "Please choose a category first.",
      });
      return;
    }

    if (action === "delete") {
      const ok = window.confirm(
        `Delete ${selectedProductIds.length} selected product(s)?`,
      );
      if (!ok) return;
    }

    setBulkBusy(action);

    try {
      const res = await fetch("/api/admin/products/bulk", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action,
          productIds: selectedProductIds,
          ...(action === "category" || action === "addCategory"
            ? { categoryId: extra?.categoryId }
            : undefined),
        }),
      });

      const data: unknown = await res.json().catch(() => ({}));

      if (!res.ok) {
        const message =
          (data as { error?: string })?.error ||
          "Bulk action failed. Please try again.";

        toast({
          variant: "error",
          title: "Bulk action failed",
          description: message,
        });
        return;
      }

      if (action === "feature") {
        toast({
          title: "Featured updated",
          description: `${selectedProductIds.length} selected product(s) marked as featured.`,
        });
      }

      if (action === "category") {
        const categoryLabel =
          (data as { categoryLabel?: string })?.categoryLabel || "category";

        toast({
          title: "Category updated",
          description: `${selectedProductIds.length} selected product(s) moved to ${categoryLabel}.`,
        });
      }

      if (action === "addCategory") {
        const result = data as {
          addedCount?: number;
          categoryLabel?: string;
        };
        const categoryLabel = result.categoryLabel || "category";
        const addedCount =
          typeof result.addedCount === "number" ? result.addedCount : 0;

        toast({
          title: "Category added",
          description: `${selectedProductIds.length} selected product(s) now also belong to ${categoryLabel}. ${addedCount} new link(s) added.`,
        });
      }

      if (action === "delete") {
        toast({
          title: "Deleted",
          description: `${selectedProductIds.length} selected product(s) deleted successfully.`,
        });
      }

      clearSelection();
      setShowBulkCategoryModal(false);
      setShowBulkCopyCategoryModal(false);
      await load();
    } catch {
      toast({
        variant: "error",
        title: "Bulk action failed",
        description: "Please try again.",
      });
    } finally {
      setBulkBusy(null);
    }
  }

  const [categoryFilter, setCategoryFilter] = React.useState("");

  const filteredItems = React.useMemo(() => {
    const q = listQuery.trim().toLowerCase();

    const isLowStock = (p: Product) => {
      if (p.stock > 0 && p.stock <= LOW_STOCK_LIMIT) return true;

      if (Array.isArray(p.variants) && p.variants.length) {
        return p.variants.some(
          (v) => v.stock > 0 && v.stock <= LOW_STOCK_LIMIT,
        );
      }

      return false;
    };

    const isMainStockOut = (p: Product) => {
      return p.stock === 0;
    };

    const isVariantStockOut = (p: Product) => {
      if (!Array.isArray(p.variants) || !p.variants.length) return false;
      return p.variants.some((v) => v.stock === 0);
    };

    let out = items;

    if (isLowStockFilter) {
      out = out.filter(isLowStock);
    }

    if (isMainStockOutFilter) {
      out = out.filter(isMainStockOut);
    }

    if (isVariantStockOutFilter) {
      out = out.filter(isVariantStockOut);
    }

    if (categoryFilter) {
      const selected = categories.find((c) => c.id === categoryFilter);

      if (selected) {
        const relatedIds = new Set<string>();
        relatedIds.add(selected.id);

        categories.forEach((c) => {
          if (c.parentId === selected.id) {
            relatedIds.add(c.id);
          }
        });

        out = out.filter((p) =>
          getProductCategoryIds(p).some((categoryId) =>
            relatedIds.has(categoryId),
          ),
        );
      }
    }

    if (q) {
      out = out.filter((p) => {
        const nameHit = p.name.toLowerCase().includes(q);
        const skuHit = p.sku.toLowerCase().includes(q);
        const catHit = getProductCategoryDisplayPaths(p, categories)
          .join(" | ")
          .toLowerCase()
          .includes(q);

        return nameHit || skuHit || catHit;
      });
    }

    return out;
  }, [
    items,
    listQuery,
    categoryFilter,
    categories,
    isLowStockFilter,
    isMainStockOutFilter,
    isVariantStockOutFilter,
    LOW_STOCK_LIMIT,
  ]);

  const categoryFilteredItemIds = React.useMemo(() => {
    if (!categoryFilter) return [];

    const selected = categories.find((c) => c.id === categoryFilter);
    if (!selected) return [];

    const relatedIds = new Set<string>();
    relatedIds.add(selected.id);

    categories.forEach((c) => {
      if (c.parentId === selected.id) {
        relatedIds.add(c.id);
      }
    });

    return items
      .filter((p) =>
        getProductCategoryIds(p).some((categoryId) =>
          relatedIds.has(categoryId),
        ),
      )
      .map((p) => p.id);
  }, [categoryFilter, categories, items]);

  function toggleSelectCategoryProducts() {
    if (!categoryFilteredItemIds.length) return;

    const allSelected = categoryFilteredItemIds.every((id) =>
      selectedProductIdsSet.has(id),
    );

    if (allSelected) {
      setSelectedProductIds((prev) =>
        prev.filter((id) => !categoryFilteredItemIds.includes(id)),
      );
      return;
    }

    setSelectedProductIds((prev) =>
      Array.from(new Set([...prev, ...categoryFilteredItemIds])),
    );
  }

  const allCategorySelected =
    categoryFilteredItemIds.length > 0 &&
    categoryFilteredItemIds.every((id) => selectedProductIdsSet.has(id));

  const totalPages = Math.max(
    1,
    Math.ceil(filteredItems.length / ITEMS_PER_PAGE),
  );

  React.useEffect(() => {
    if (page > totalPages) {
      setPage(totalPages);
    }
  }, [page, totalPages]);

  const paginatedItems = React.useMemo(() => {
    const start = (page - 1) * ITEMS_PER_PAGE;
    return filteredItems.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredItems, page]);

  const startItem =
    filteredItems.length === 0 ? 0 : (page - 1) * ITEMS_PER_PAGE + 1;
  const endItem = Math.min(page * ITEMS_PER_PAGE, filteredItems.length);

  const pageNumbers = React.useMemo(() => {
    const pages: number[] = [];
    const maxVisible = 5;

    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
      return pages;
    }

    if (page <= 3) {
      return [1, 2, 3, 4, totalPages];
    }

    if (page >= totalPages - 2) {
      return [1, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
    }

    return [1, page - 1, page, page + 1, totalPages];
  }, [page, totalPages]);

  const filteredItemIds = React.useMemo(
    () => filteredItems.map((item) => item.id),
    [filteredItems],
  );

  const paginatedItemIds = React.useMemo(
    () => paginatedItems.map((item) => item.id),
    [paginatedItems],
  );

  const selectedFilteredCount = React.useMemo(() => {
    return filteredItemIds.filter((id) => selectedProductIdsSet.has(id)).length;
  }, [filteredItemIds, selectedProductIdsSet]);

  const allFilteredSelected =
    filteredItemIds.length > 0 &&
    filteredItemIds.every((id) => selectedProductIdsSet.has(id));

  const someFilteredSelected =
    selectedFilteredCount > 0 && !allFilteredSelected;

  const allPageSelected =
    paginatedItemIds.length > 0 &&
    paginatedItemIds.every((id) => selectedProductIdsSet.has(id));

  function toggleSelectAllFiltered() {
    if (!filteredItemIds.length) return;

    if (allFilteredSelected) {
      setSelectedProductIds((prev) =>
        prev.filter((id) => !filteredItemIds.includes(id)),
      );
      return;
    }

    setSelectedProductIds((prev) =>
      Array.from(new Set([...prev, ...filteredItemIds])),
    );
  }

  function toggleSelectAllOnPage() {
    if (!paginatedItemIds.length) return;

    if (allPageSelected) {
      setSelectedProductIds((prev) =>
        prev.filter((id) => !paginatedItemIds.includes(id)),
      );
      return;
    }

    setSelectedProductIds((prev) =>
      Array.from(new Set([...prev, ...paginatedItemIds])),
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3 px-4">
        <div>
          <h1 className="text-2xl font-semibold">Products</h1>
          <p className="mt-1 text-sm text-black/70">
            Browse, filter and manage products.
          </p>
        </div>

        <Button onClick={openCreate} className={actionButtonClass}>
          <Plus className="h-4 w-4" />
          Add Product
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">
              {isLowStockFilter
                ? "Low Stock Products"
                : isMainStockOutFilter
                  ? "Main Stock Out Products"
                  : isVariantStockOutFilter
                    ? "Variant Stock Out Products"
                    : "All Products"}
            </div>
            <div className="mt-1 text-xs text-black/60">
              Showing {startItem}-{endItem} of {filteredItems.length}
              {isLowStockFilter
                ? ` • Stock 1-${LOW_STOCK_LIMIT} (product OR variants)`
                : null}
              {isMainStockOutFilter ? " • Main product stock = 0" : null}
              {isVariantStockOutFilter ? " • Any variant stock = 0" : null}
              {loadingList ? " • Loading..." : null}
            </div>
          </div>
        </div>

        <div className="mt-4 mb-4 flex items-center gap-2 overflow-x-auto">
          <Input
            className="min-w-0 flex-1"
            value={listQuery}
            onChange={(e) => setListQuery(e.target.value)}
            placeholder="Search by name / SKU / category"
          />
        </div>

        <div className="flex flex-wrap gap-4">
          <Link
            href="/admin/products"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              !isLowStockFilter &&
              !isMainStockOutFilter &&
              !isVariantStockOutFilter
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            All
          </Link>

          <Link
            href="/admin/products?filter=low_stock"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              isLowStockFilter
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            Low Stock
          </Link>

          <Link
            href="/admin/products?filter=main_stock_out"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              isMainStockOutFilter
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            Main Stock Out
          </Link>

          <Link
            href="/admin/products?filter=variant_stock_out"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              isVariantStockOutFilter
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            Variant Stock Out
          </Link>
        </div>

        <select
          className="mt-2 h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          <option value="">All categories</option>
          {mainCategories.map((parent) => {
            const children = categories.filter((c) => c.parentId === parent.id);

            return (
              <optgroup key={parent.id} label={parent.name}>
                <option value={parent.id}>{parent.name}</option>
                {children.map((child) => (
                  <option key={child.id} value={child.id}>
                    {parent.name} → {child.name}
                  </option>
                ))}
              </optgroup>
            );
          })}
        </select>

        {filteredItems.length > 0 ? (
          <div className="sticky top-3 z-20 mt-4 rounded-3xl border border-black/10 bg-white/95 p-3 shadow-sm backdrop-blur">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-wrap items-center gap-3">
                <label className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                  <input
                    type="checkbox"
                    checked={allFilteredSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = someFilteredSelected;
                    }}
                    onChange={toggleSelectAllFiltered}
                  />
                  {categoryFilter ? (
                    <button
                      type="button"
                      onClick={toggleSelectCategoryProducts}
                      className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                    >
                      <CheckSquare className="h-4 w-4" />
                      {allCategorySelected
                        ? "Unselect category"
                        : "Select category products"}{" "}
                      ({categoryFilteredItemIds.length})
                    </button>
                  ) : null}
                  Select all filtered ({filteredItems.length})
                </label>

                <button
                  type="button"
                  onClick={toggleSelectAllOnPage}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                >
                  <CheckSquare className="h-4 w-4" />
                  {allPageSelected ? "Unselect page" : "Select this page"} (
                  {paginatedItems.length})
                </button>

                <div className="text-sm text-black/60">
                  {selectedFilteredCount > 0
                    ? `${selectedFilteredCount} selected from current results`
                    : "No products selected"}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant="secondary"
                  onClick={() => {
                    if (!selectedProductIds.length) return;
                    setBulkCategoryId(
                      bulkCategoryId ||
                        categories.find((c) => c.isActive)?.id ||
                        "",
                    );
                    setShowBulkCategoryModal(true);
                  }}
                  disabled={!selectedProductIds.length || !!bulkBusy}
                  className={neutralButtonClass}
                >
                  <Layers3 className="h-4 w-4" />
                  Change Category
                </Button>

                <Button
                  variant="secondary"
                  onClick={() => {
                    if (!selectedProductIds.length) return;
                    setBulkCopyCategoryId(
                      bulkCopyCategoryId ||
                        categories.find((c) => c.isActive)?.id ||
                        "",
                    );
                    setShowBulkCopyCategoryModal(true);
                  }}
                  disabled={!selectedProductIds.length || !!bulkBusy}
                  className={neutralButtonClass}
                >
                  <Copy className="h-4 w-4" />
                  Copy to Category
                </Button>

                <Button
                  variant="secondary"
                  onClick={() => void runBulkAction("feature")}
                  disabled={!selectedProductIds.length || !!bulkBusy}
                  className={featuredButtonClass}
                >
                  {bulkBusy === "feature" ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Star className="h-4 w-4" />
                  )}
                  Feature Selected
                </Button>

                <Button
                  variant="danger"
                  onClick={() => void runBulkAction("delete")}
                  disabled={!selectedProductIds.length || !!bulkBusy}
                >
                  {bulkBusy === "delete" ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4" />
                  )}
                  Delete Selected
                </Button>
              </div>
            </div>
          </div>
        ) : null}

        <div className="mt-3 space-y-2"></div>

        <div className="mt-3 space-y-2">
          {paginatedItems.map((p) => {
            const isLowStockProduct =
              (p.stock > 0 && p.stock <= LOW_STOCK_LIMIT) ||
              (p.variants?.some(
                (v) => v.stock > 0 && v.stock <= LOW_STOCK_LIMIT,
              ) ??
                false);

            const isMainStockOutProduct = p.stock === 0;

            const isVariantStockOutProduct =
              p.variants?.some((v) => v.stock === 0) ?? false;

            const categoryLabel = getProductCategoryDisplayPaths(
              p,
              categories,
            ).join(" | ");

            const isTogglingThis = togglingFeaturedId === p.id;

            return (
              <div
                key={p.id}
                className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border px-3 py-3 transition ${
                  selectedProductIdsSet.has(p.id)
                    ? "border-blue-200 bg-blue-50/40"
                    : "border-black/10 bg-white/60"
                }`}
              >
                <div className="flex min-w-0 items-center gap-3">
                  <label className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white">
                    <input
                      type="checkbox"
                      checked={selectedProductIdsSet.has(p.id)}
                      onChange={() => toggleSelectProduct(p.id)}
                      aria-label={`Select ${p.name}`}
                    />
                  </label>
                  <div className="relative h-14 w-14 overflow-hidden rounded-xl bg-black/5">
                    {p.images?.[0]?.url ? (
                      <Image
                        src={p.images[0].url}
                        alt={p.name}
                        fill
                        className="object-cover"
                        sizes="56px"
                      />
                    ) : null}
                  </div>

                  <div className="text-sm">
                    <div className="flex flex-wrap items-center gap-2 font-medium">
                      {p.name}
                      {!p.isActive ? (
                        <span className="text-xs text-red-600">(Inactive)</span>
                      ) : null}
                      {p.isFeatured ? (
                        <span className="text-xs text-black/60">
                          (Featured)
                        </span>
                      ) : null}
                    </div>

                    <div className="text-xs text-black/60">
                      {categoryLabel} • SKU: {p.sku} • Price:{" "}
                      {formatMoney(p.price)} • Stock: {p.stock}
                      {p.offerPrice ? (
                        <> • Offer: {formatMoney(p.offerPrice)}</>
                      ) : null}
                      {p.investedAmount ? (
                        <> • Invested: {formatMoney(p.investedAmount)}</>
                      ) : null}
                    </div>

                    {isMainStockOutProduct ? (
                      <div className="mt-1 text-xs text-red-600">
                        Main stock out
                      </div>
                    ) : isVariantStockOutProduct ? (
                      <div className="mt-1 text-xs text-rose-600">
                        Variant stock out
                      </div>
                    ) : isLowStockProduct ? (
                      <div className="mt-1 text-xs text-amber-600">
                        Low stock (≤ {LOW_STOCK_LIMIT})
                        {p.variants?.some(
                          (v) => v.stock > 0 && v.stock <= LOW_STOCK_LIMIT,
                        )
                          ? " • includes variant stock"
                          : ""}
                      </div>
                    ) : null}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => void postToFacebook(p)}
                    disabled={!!postingFacebookId}
                    className={facebookButtonClass}
                    title="Post to Facebook Page"
                  >
                    <Send className="h-4 w-4" />
                    <span className="hidden sm:inline">
                      {postingFacebookId === p.id
                        ? "Posting..."
                        : "Post Facebook"}
                    </span>
                  </Button>

                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => void toggleFeatured(p)}
                    disabled={!!togglingFeaturedId}
                    className={
                      p.isFeatured
                        ? "border-yellow-300 bg-yellow-100 text-yellow-800 hover:bg-yellow-200 focus-visible:ring-yellow-500"
                        : featuredButtonClass
                    }
                    title={p.isFeatured ? "Remove Featured" : "Make Featured"}
                  >
                    <Star
                      className={`h-4 w-4 ${
                        p.isFeatured ? "fill-current" : ""
                      }`}
                    />
                    <span className="hidden sm:inline">
                      {isTogglingThis
                        ? "Updating..."
                        : p.isFeatured
                          ? "Featured"
                          : "Feature"}
                    </span>
                  </Button>

                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => startEdit(p)}
                    className={editButtonClass}
                  >
                    <Pencil className="h-4 w-4" />
                    <span className="hidden sm:inline">Edit</span>
                  </Button>

                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => void remove(p.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Delete</span>
                  </Button>
                </div>
              </div>
            );
          })}

          {!filteredItems.length ? (
            <div className="text-sm text-black/60">
              {isLowStockFilter
                ? "No low stock products."
                : isMainStockOutFilter
                  ? "No main stock out products."
                  : isVariantStockOutFilter
                    ? "No variant stock out products."
                    : "No products yet."}
            </div>
          ) : null}
        </div>

        {filteredItems.length > 0 ? (
          <div className="mt-5 flex flex-col gap-3 border-t border-black/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="text-xs text-black/60">
              Page {page} of {totalPages}
            </div>

            <div className="flex w-full flex-wrap items-center justify-center gap-2 sm:w-auto sm:justify-end">
              <Button
                variant="secondary"
                onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                disabled={page <= 1}
                className={neutralButtonClass}
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="hidden sm:inline">Previous</span>
              </Button>

              <div className="flex flex-wrap items-center justify-center gap-2">
                {pageNumbers.map((num, index) => {
                  const showEllipsisLeft =
                    index > 0 && num - pageNumbers[index - 1] > 1;

                  return (
                    <React.Fragment key={num}>
                      {showEllipsisLeft ? (
                        <span className="px-2 text-sm text-black/40">…</span>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => setPage(num)}
                        className={`min-w-10 rounded-xl px-3 py-2 text-sm font-medium transition ${
                          page === num
                            ? "bg-blue-600 text-white"
                            : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                        }`}
                      >
                        {num}
                      </button>
                    </React.Fragment>
                  );
                })}
              </div>

              <Button
                variant="secondary"
                onClick={() =>
                  setPage((prev) => Math.min(totalPages, prev + 1))
                }
                disabled={page >= totalPages}
                className={neutralButtonClass}
              >
                <span className="hidden sm:inline">Next</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : null}
      </Card>

      <Modal
        open={showBulkCategoryModal}
        title="Change Category for Selected Products"
        onClose={() => {
          if (bulkBusy) return;
          setShowBulkCategoryModal(false);
        }}
      >
        <div className="space-y-5">
          <div>
            <div className="text-sm font-semibold text-black/80">
              Selected products
            </div>
            <div className="mt-1 text-sm text-black/60">
              {selectedProductIds.length} product(s) will be moved to the
              selected category or sub-category.
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-medium text-black/70">
              Choose Category
            </label>

            <select
              className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
              value={bulkCategoryId}
              onChange={(e) => setBulkCategoryId(e.target.value)}
              disabled={bulkBusy === "category"}
            >
              <option value="">Select a category</option>

              {mainCategories.map((parent) => {
                const children = activeCategoryOptions.filter(
                  (c) => c.parentId === parent.id,
                );

                return (
                  <optgroup key={parent.id} label={parent.name}>
                    <option value={parent.id}>{parent.name}</option>
                    {children.map((child) => (
                      <option key={child.id} value={child.id}>
                        {parent.name} → {child.name}
                      </option>
                    ))}
                  </optgroup>
                );
              })}
            </select>

            {bulkCategoryId ? (
              <div className="text-xs text-black/50">
                Selected: {getCategoryDisplayPath(bulkCategoryId, categories)}
              </div>
            ) : null}
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="secondary"
              onClick={() => setShowBulkCategoryModal(false)}
              disabled={bulkBusy === "category"}
              className={neutralButtonClass}
            >
              <X className="h-4 w-4" />
              Cancel
            </Button>

            <Button
              onClick={() =>
                void runBulkAction("category", { categoryId: bulkCategoryId })
              }
              disabled={!bulkCategoryId || bulkBusy === "category"}
              className={actionButtonClass}
            >
              {bulkBusy === "category" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Layers3 className="h-4 w-4" />
              )}
              Update Category
            </Button>
          </div>
        </div>
      </Modal>

      <Modal
        open={showBulkCopyCategoryModal}
        title="Copy Selected Products to Category"
        onClose={() => {
          if (bulkBusy) return;
          setShowBulkCopyCategoryModal(false);
        }}
      >
        <div className="space-y-5">
          <div>
            <div className="text-sm font-semibold text-black/80">
              Selected products
            </div>
            <div className="mt-1 text-sm text-black/60">
              {selectedProductIds.length} product(s) will be added to the
              selected category. Existing categories will stay unchanged.
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-medium text-black/70">
              Choose Category
            </label>

            <select
              className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
              value={bulkCopyCategoryId}
              onChange={(e) => setBulkCopyCategoryId(e.target.value)}
              disabled={bulkBusy === "addCategory"}
            >
              <option value="">Select a category</option>

              {mainCategories.map((parent) => {
                const children = activeCategoryOptions.filter(
                  (c) => c.parentId === parent.id,
                );

                return (
                  <optgroup key={parent.id} label={parent.name}>
                    <option value={parent.id}>{parent.name}</option>
                    {children.map((child) => (
                      <option key={child.id} value={child.id}>
                        {parent.name} → {child.name}
                      </option>
                    ))}
                  </optgroup>
                );
              })}
            </select>

            {bulkCopyCategoryId ? (
              <div className="text-xs text-black/50">
                Selected:{" "}
                {getCategoryDisplayPath(bulkCopyCategoryId, categories)}
              </div>
            ) : null}
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="secondary"
              onClick={() => setShowBulkCopyCategoryModal(false)}
              disabled={bulkBusy === "addCategory"}
              className={neutralButtonClass}
            >
              <X className="h-4 w-4" />
              Cancel
            </Button>

            <Button
              onClick={() =>
                void runBulkAction("addCategory", {
                  categoryId: bulkCopyCategoryId,
                })
              }
              disabled={!bulkCopyCategoryId || bulkBusy === "addCategory"}
              className={actionButtonClass}
            >
              {bulkBusy === "addCategory" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
              Add to Category
            </Button>
          </div>
        </div>
      </Modal>

      <Modal
        open={showForm}
        title={editingId ? "Edit Product" : "Add Product"}
        onClose={closeForm}
      >
        <div className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Product Name *
              </label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Digital Hearing Aid"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Categories / Subcategories *
              </label>

              <div className="rounded-2xl border border-black/10 bg-white/70 p-3">
                <div className="max-h-72 overflow-y-auto space-y-3 pr-1">
                  {mainCategories.map((parent) => {
                    const children = categories.filter(
                      (c) => c.parentId === parent.id && c.isActive,
                    );

                    const parentChecked = categoryIds.includes(parent.id);

                    return (
                      <div
                        key={parent.id}
                        className="rounded-2xl border border-black/5 bg-white p-3"
                      >
                        <label className="flex items-center gap-2 text-sm font-medium text-black">
                          <input
                            type="checkbox"
                            checked={parentChecked}
                            onChange={() => toggleCategorySelection(parent.id)}
                          />
                          <span>{parent.name}</span>
                        </label>

                        {children.length ? (
                          <div className="mt-3 grid gap-2 pl-6 md:grid-cols-2">
                            {children.map((child) => {
                              const checked = categoryIds.includes(child.id);

                              return (
                                <label
                                  key={child.id}
                                  className="flex items-center gap-2 rounded-xl border border-black/5 bg-black/2 px-3 py-2 text-sm text-black/80"
                                >
                                  <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={() =>
                                      toggleCategorySelection(child.id)
                                    }
                                  />
                                  <span>
                                    {parent.name} → {child.name}
                                  </span>
                                </label>
                              );
                            })}
                          </div>
                        ) : null}
                      </div>
                    );
                  })}
                </div>

                {!!selectedCategoryOptions.length ? (
                  <div className="mt-3 rounded-2xl border border-dashed border-black/10 bg-black/2 p-3">
                    <div className="text-xs font-medium text-black/60">
                      Selected Categories
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {selectedCategoryOptions.map((cat) => (
                        <span
                          key={cat.id}
                          className="inline-flex items-center gap-2 rounded-full border border-pink-200 bg-pink-50 px-3 py-1 text-xs text-pink-700"
                        >
                          {getCategoryDisplayPath(cat.id, categories)}
                          <button
                            type="button"
                            onClick={() => toggleCategorySelection(cat.id)}
                            className="font-semibold"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="mt-3 text-xs text-black/50">
                    Select one or more categories/subcategories.
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="min-h-28 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
                placeholder="Write details about the product..."
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                YouTube Video URL
              </label>
              <Input
                type="url"
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
              />
              <div className="text-[11px] text-black/50">
                Optional. If added, this video will appear on the product page.
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Price (BDT) *
              </label>
              <Input
                type="number"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Offer Price
              </label>
              <Input
                type="number"
                value={offerPrice}
                onChange={(e) => setOfferPrice(Number(e.target.value))}
              />
              <div className="text-[11px] text-black/50">
                Set 0 to disable offer price.
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Invested Amount / Unit
              </label>
              <Input
                type="number"
                value={investedAmount}
                onChange={(e) => setInvestedAmount(Number(e.target.value))}
              />
              <div className="text-[11px] text-black/50">
                Product buying/cost amount. Used as default revenue investment.
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Stock *
              </label>
              <Input
                type="number"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
              />
              {stock === 0 ? (
                <div className="text-xs text-red-600">Stock out</div>
              ) : stock <= LOW_STOCK_LIMIT ? (
                <div className="text-xs text-amber-600">
                  Low stock (≤ {LOW_STOCK_LIMIT})
                </div>
              ) : (
                <div className="text-xs text-black/50">
                  Stock looks healthy.
                </div>
              )}
            </div>

            <div className="flex items-center gap-6 md:col-span-4">
              <label className="flex items-center gap-2 text-sm text-black/70">
                <input
                  type="checkbox"
                  checked={isFeatured}
                  onChange={(e) => setIsFeatured(e.target.checked)}
                />
                Featured
              </label>

              <label className="flex items-center gap-2 text-sm text-black/70">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                />
                Active
              </label>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">
                  Shared Product Images *
                </div>
                <div className="text-xs text-black/60">
                  এগুলো সব variant-এর fallback/shared image হিসেবে কাজ করবে।
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={productFileRef}
                  type="file"
                  multiple
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  className="hidden"
                  onChange={(e) => void onPickProductFiles(e.target.files)}
                  disabled={uploading || saving}
                />
                <Button
                  variant="secondary"
                  onClick={() => productFileRef.current?.click()}
                  disabled={uploading || saving}
                  className={uploadButtonClass}
                >
                  <ImagePlus className="h-4 w-4" />
                  {uploading ? "Uploading..." : "Upload Shared Images"}
                </Button>
              </div>
            </div>

            {images.length ? (
              <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
                {images.map((url, index) => (
                  <div
                    key={`${url}-${index}`}
                    className="space-y-2 rounded-2xl border border-black/10 bg-white/60 p-3"
                  >
                    <div className="relative aspect-square overflow-hidden rounded-xl bg-black/5">
                      <Image
                        src={url}
                        alt={`Product image ${index + 1}`}
                        fill
                        className="object-cover"
                        sizes="220px"
                      />
                    </div>

                    <div className="truncate text-[10px] text-black/60">
                      {url}
                    </div>

                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => moveImage("product", index, "left")}
                        disabled={index === 0}
                        className={neutralButtonClass}
                      >
                        <ArrowLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => moveImage("product", index, "right")}
                        disabled={index === images.length - 1}
                        className={neutralButtonClass}
                      >
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="danger"
                        size="sm"
                        onClick={() => removeProductImage(url)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-black/60">
                No shared product images uploaded yet.
              </div>
            )}
          </div>

          <div
            id={VARIANT_EDITOR_ID}
            className="scroll-mt-4 space-y-4 rounded-3xl border border-black/10 p-4"
          >
            <div>
              <div className="text-sm font-semibold">Variant Editor</div>
              <div className="text-xs text-black/60">
                Variant image না দিলে shared product images use হবে।
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-5">
              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Type</div>
                <select
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                  value={variantDraft.type}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      type: e.target.value,
                    }))
                  }
                >
                  <option value="Color">Color</option>
                  <option value="Size">Size</option>
                  <option value="Model">Model</option>
                  <option value="Measurement">Measurement</option>
                </select>
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Value</div>
                <Input
                  value={variantDraft.value}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      value: e.target.value,
                    }))
                  }
                  placeholder="e.g. Red / XL / M-01 / 2 ml / 500 ml / 1 kg"
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">
                  Additional Price (BDT)
                </div>
                <Input
                  type="number"
                  value={variantDraft.priceDiff}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      priceDiff: Number(e.target.value),
                    }))
                  }
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">
                  Invested / Unit
                </div>
                <Input
                  type="number"
                  value={variantDraft.investedAmount}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      investedAmount: Number(e.target.value),
                    }))
                  }
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Stock</div>
                <Input
                  type="number"
                  value={variantDraft.stock}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      stock: Number(e.target.value),
                    }))
                  }
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <div className="text-sm font-medium">Variant Images</div>
                  <div className="text-xs text-black/60">
                    Optional. Empty থাকলে shared product images use হবে।
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    ref={variantFileRef}
                    type="file"
                    multiple
                    accept="image/png,image/jpeg,image/jpg,image/webp"
                    className="hidden"
                    onChange={(e) => void onPickVariantFiles(e.target.files)}
                    disabled={variantUploading || saving}
                  />
                  <Button
                    variant="secondary"
                    onClick={() => variantFileRef.current?.click()}
                    disabled={variantUploading || saving}
                    className={uploadButtonClass}
                  >
                    <ImagePlus className="h-4 w-4" />
                    {variantUploading
                      ? "Uploading..."
                      : "Upload Variant Images"}
                  </Button>
                </div>
              </div>

              {variantDraft.images.length ? (
                <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
                  {variantDraft.images.map((url, index) => (
                    <div
                      key={`${url}-${index}`}
                      className="space-y-2 rounded-2xl border border-black/10 bg-white/60 p-3"
                    >
                      <div className="relative aspect-square overflow-hidden rounded-xl bg-black/5">
                        <Image
                          src={url}
                          alt={`Variant image ${index + 1}`}
                          fill
                          className="object-cover"
                          sizes="220px"
                        />
                      </div>

                      <div className="truncate text-[10px] text-black/60">
                        {url}
                      </div>

                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="secondary"
                          size="sm"
                          onClick={() => moveImage("variant", index, "left")}
                          disabled={index === 0}
                          className={neutralButtonClass}
                        >
                          <ArrowLeft className="h-4 w-4" />
                          Move Left
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          size="sm"
                          onClick={() => moveImage("variant", index, "right")}
                          disabled={index === variantDraft.images.length - 1}
                          className={neutralButtonClass}
                        >
                          <ArrowRight className="h-4 w-4" />
                          Move Right
                        </Button>
                        <Button
                          type="button"
                          variant="danger"
                          size="sm"
                          onClick={() => removeVariantImage(url)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-black/60">
                  No variant-specific images. Shared product images will be
                  used.
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                onClick={saveVariantDraft}
                className={actionButtonClass}
              >
                <Save className="h-4 w-4" />
                {variantEditIndex !== null ? "Update Variant" : "Add Variant"}
              </Button>

              {variantEditIndex !== null ? (
                <Button
                  variant="secondary"
                  onClick={resetVariantDraft}
                  className={neutralButtonClass}
                >
                  <RotateCcw className="h-4 w-4" />
                  Cancel Variant Edit
                </Button>
              ) : null}
            </div>

            {variants.length ? (
              <div className="grid gap-3">
                {variants.map((variant, index) => (
                  <div
                    key={`${variant.id ?? "new"}-${variant.type}-${variant.value}-${index}`}
                    className="rounded-2xl border border-black/10 p-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold">
                          {variant.type}: {variant.value}
                        </div>
                        <div className="text-xs text-black/60">
                          Price diff: ৳ {variant.priceDiff} • Stock:{" "}
                          {variant.stock} • Invested: ৳{" "}
                          {variant.investedAmount || 0}
                        </div>
                        <div className="mt-1 text-xs text-black/60">
                          {variant.images.length
                            ? `Own images: ${variant.images.length}`
                            : "Uses shared product images"}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => editVariant(index)}
                          className={editButtonClass}
                        >
                          <Pencil className="h-4 w-4" />
                          Edit
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={() => removeVariant(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Remove
                        </Button>
                      </div>
                    </div>

                    {variant.images.length ? (
                      <div className="mt-3 grid gap-2 sm:grid-cols-4">
                        {variant.images.map((img, idx) => (
                          <div
                            key={`${img}-${idx}`}
                            className="relative aspect-square overflow-hidden rounded-xl bg-black/5"
                          >
                            <Image
                              src={img}
                              alt={`${variant.value}-${idx}`}
                              fill
                              className="object-cover"
                              sizes="160px"
                            />
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-black/60">
                No variants added yet.
              </div>
            )}
          </div>

          {formError ? (
            <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {formError}
            </div>
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-xs text-black/60">
              Fill the form and press {editingId ? "Update" : "Create"}.
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                onClick={closeForm}
                disabled={saving}
                className={neutralButtonClass}
              >
                <X className="h-4 w-4" />
                Cancel
              </Button>
              <Button
                onClick={() => void save()}
                disabled={saving || uploading || variantUploading}
                className={actionButtonClass}
              >
                <Save className="h-4 w-4" />
                {saving ? "Saving..." : editingId ? "Update" : "Create"}
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default function AdminProductsPage() {
  return (
    <React.Suspense
      fallback={
        <div className="rounded-3xl border border-black/10 bg-white p-6 text-sm text-black/60">
          Loading products...
        </div>
      }
    >
      <AdminProductsClient />
    </React.Suspense>
  );
}
