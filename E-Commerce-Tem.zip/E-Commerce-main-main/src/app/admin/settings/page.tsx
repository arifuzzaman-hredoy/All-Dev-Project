"use client";

import Image from "next/image";
import { type ChangeEvent, useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import {
  BANGLA_FONT_OPTIONS,
  DEFAULT_BANGLA_FONT,
  DEFAULT_SITE_FONT,
  SITE_FONT_OPTIONS,
  getSiteFontStack,
  resolveBanglaFont,
  resolveSiteFont,
  type SiteFontOption,
} from "@/lib/site-fonts";

type FaqItem = {
  question: string;
  answer: string;
};

type ShippingRuleType = "DISTRICT" | "POLICE_STATION";

type ShippingRule = {
  id: string;
  type: ShippingRuleType;
  district: string;
  policeStation?: string | null;
  charge: number;
};

type DistrictOption = {
  id: string;
  name: string;
};

type PoliceStationOption = {
  id: string;
  name: string;
  district: string;
};

type Settings = {
  storeName: string;
  logoUrl: string;
  siteFontFamily: string;
  banglaFontFamily: string;
  taxRate: number;
  shippingInsideDhaka: number;
  shippingRangpur: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  shippingDefaultCharge: number;
  shippingRules: ShippingRule[];
  codEnabled: boolean;
  onlineEnabled: boolean;
  manualPaymentEnabled: boolean;
  manualBkashNumber: string;
  manualBkashImageUrl: string;
  manualNagadNumber: string;
  manualNagadImageUrl: string;
  manualRocketNumber: string;
  manualRocketImageUrl: string;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;

  returnRefundPolicy: string;
  privacyPolicy: string;
  termsConditions: string;

  aboutUs: string;
  aboutFaqs: FaqItem[];
};

type NewRuleForm = {
  type: ShippingRuleType;
  district: string;
  policeStation: string;
  charge: number;
};

type ManualPaymentProviderKey = "bkash" | "nagad" | "rocket";

const FONT_CHANGE_EVENT = "nexoramart:font-settings-changed";
const FONT_OPTION_LIMIT = 40;

const MANUAL_PAYMENT_PROVIDER_META: Record<
  ManualPaymentProviderKey,
  {
    label: string;
    numberField: keyof Pick<
      Settings,
      "manualBkashNumber" | "manualNagadNumber" | "manualRocketNumber"
    >;
    imageField: keyof Pick<
      Settings,
      "manualBkashImageUrl" | "manualNagadImageUrl" | "manualRocketImageUrl"
    >;
    imageUrlFallback: string;
  }
> = {
  bkash: {
    label: "bKash",
    numberField: "manualBkashNumber",
    imageField: "manualBkashImageUrl",
    imageUrlFallback: "/uploads/payments/bkash.png",
  },
  nagad: {
    label: "Nagad",
    numberField: "manualNagadNumber",
    imageField: "manualNagadImageUrl",
    imageUrlFallback: "/uploads/payments/nagad.png",
  },
  rocket: {
    label: "Rocket",
    numberField: "manualRocketNumber",
    imageField: "manualRocketImageUrl",
    imageUrlFallback: "/uploads/payments/rocket-bgf.png",
  },
};

function normalizeFaqs(input: unknown): FaqItem[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => {
      const o = item as Record<string, unknown>;
      return {
        question: typeof o.question === "string" ? o.question : "",
        answer: typeof o.answer === "string" ? o.answer : "",
      };
    })
    .filter((x) => x.question || x.answer);
}

function normalizeShippingRules(input: unknown): ShippingRule[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item): ShippingRule | null => {
      const o =
        item && typeof item === "object" && !Array.isArray(item)
          ? (item as Record<string, unknown>)
          : null;

      if (!o) return null;

      const type =
        o.type === "DISTRICT" || o.type === "POLICE_STATION" ? o.type : null;
      const district = typeof o.district === "string" ? o.district : "";
      const policeStation =
        typeof o.policeStation === "string" ? o.policeStation : null;
      const charge = Number(o.charge ?? 0);
      const id =
        typeof o.id === "string" && o.id
          ? o.id
          : `${type}:${district}:${policeStation ?? ""}`;

      if (!type || !district) return null;
      if (type === "POLICE_STATION" && !policeStation) return null;

      return {
        id,
        type,
        district,
        policeStation,
        charge: Number.isFinite(charge) ? Math.max(0, Math.floor(charge)) : 0,
      };
    })
    .filter((item): item is ShippingRule => item !== null);
}

function normalizeFontOptions(
  input: unknown,
  fallback: SiteFontOption[],
): SiteFontOption[] {
  const record =
    input && typeof input === "object" && !Array.isArray(input)
      ? (input as Record<string, unknown>)
      : null;
  const items = Array.isArray(record?.fonts) ? record.fonts : [];

  const fonts = items
    .map((item): SiteFontOption | null => {
      const data =
        item && typeof item === "object" && !Array.isArray(item)
          ? (item as Record<string, unknown>)
          : null;

      if (!data) return null;

      const value = typeof data.value === "string" ? data.value.trim() : "";
      const label = typeof data.label === "string" ? data.label.trim() : value;
      const cssFamily =
        typeof data.cssFamily === "string" && data.cssFamily.trim()
          ? data.cssFamily
          : `"${value.replaceAll('"', "")}"`;
      const googleFamily =
        typeof data.googleFamily === "string" && data.googleFamily.trim()
          ? data.googleFamily
          : value;
      const sample =
        typeof data.sample === "string" && data.sample.trim()
          ? data.sample
          : value;

      if (!value || !label || !googleFamily) return null;

      return {
        value,
        label,
        cssFamily,
        googleFamily,
        sample,
      };
    })
    .filter((item): item is SiteFontOption => item !== null);

  return fonts.length ? fonts : fallback;
}

function filterFontOptions(
  options: SiteFontOption[],
  query: string,
): SiteFontOption[] {
  const q = query.trim().toLowerCase();
  const filtered = q
    ? options.filter((font) => font.label.toLowerCase().includes(q))
    : options;

  return filtered.slice(0, FONT_OPTION_LIMIT);
}

function normalizeSettings(
  input: Partial<Settings> | null | undefined,
): Settings {
  return {
    storeName: input?.storeName ?? "NexoraMart",
    logoUrl: input?.logoUrl ?? "",
    siteFontFamily: resolveSiteFont(input?.siteFontFamily ?? DEFAULT_SITE_FONT)
      .value,
    banglaFontFamily: resolveBanglaFont(
      input?.banglaFontFamily ?? DEFAULT_BANGLA_FONT,
    ).value,
    taxRate: Number(input?.taxRate ?? 0),
    shippingInsideDhaka: Number(input?.shippingInsideDhaka ?? 0),
    shippingRangpur: Number(input?.shippingRangpur ?? 0),
    shippingOutsideDhaka: Number(input?.shippingOutsideDhaka ?? 0),
    shippingFreeOver: Number(input?.shippingFreeOver ?? 0),
    shippingDefaultCharge: Number(input?.shippingDefaultCharge ?? 0),
    shippingRules: normalizeShippingRules(input?.shippingRules),
    codEnabled: Boolean(input?.codEnabled ?? true),
    onlineEnabled: Boolean(input?.onlineEnabled ?? false),
    manualPaymentEnabled: Boolean(input?.manualPaymentEnabled ?? false),
    manualBkashNumber: input?.manualBkashNumber ?? "",
    manualBkashImageUrl: input?.manualBkashImageUrl ?? "",
    manualNagadNumber: input?.manualNagadNumber ?? "",
    manualNagadImageUrl: input?.manualNagadImageUrl ?? "",
    manualRocketNumber: input?.manualRocketNumber ?? "",
    manualRocketImageUrl: input?.manualRocketImageUrl ?? "",
    lowStockThreshold: Number(input?.lowStockThreshold ?? 5),

    facebookUrl: input?.facebookUrl ?? "",
    instagramUrl: input?.instagramUrl ?? "",
    youtubeUrl: input?.youtubeUrl ?? "",
    tiktokUrl: input?.tiktokUrl ?? "",
    whatsappUrl: input?.whatsappUrl ?? "",

    returnRefundPolicy: input?.returnRefundPolicy ?? "",
    privacyPolicy: input?.privacyPolicy ?? "",
    termsConditions: input?.termsConditions ?? "",

    aboutUs: input?.aboutUs ?? "",
    aboutFaqs: normalizeFaqs(input?.aboutFaqs),
  };
}

export default function AdminSettingsPage() {
  const [s, setS] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [logoUploading, setLogoUploading] = useState(false);
  const [manualImageUploading, setManualImageUploading] = useState<
    Record<ManualPaymentProviderKey, boolean>
  >({
    bkash: false,
    nagad: false,
    rocket: false,
  });

  const [districts, setDistricts] = useState<DistrictOption[]>([]);
  const [policeStations, setPoliceStations] = useState<PoliceStationOption[]>(
    [],
  );
  const [districtDataLoading, setDistrictDataLoading] = useState(false);
  const [siteFontOptions, setSiteFontOptions] =
    useState<SiteFontOption[]>(SITE_FONT_OPTIONS);
  const [banglaFontOptions, setBanglaFontOptions] =
    useState<SiteFontOption[]>(BANGLA_FONT_OPTIONS);
  const [fontListLoading, setFontListLoading] = useState(false);
  const [siteFontQuery, setSiteFontQuery] = useState("");
  const [banglaFontQuery, setBanglaFontQuery] = useState("");

  const [newRule, setNewRule] = useState<NewRuleForm>({
    type: "DISTRICT",
    district: "",
    policeStation: "",
    charge: 0,
  });

  const { toast } = useToast();

  const announceFontSettings = (settings: Settings) => {
    window.dispatchEvent(
      new CustomEvent(FONT_CHANGE_EVENT, {
        detail: {
          siteFontFamily: settings.siteFontFamily,
          banglaFontFamily: settings.banglaFontFamily,
        },
      }),
    );
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);

      try {
        const res = await fetch("/api/admin/settings", {
          cache: "no-store",
        });

        const json = await res.json().catch(() => null);

        if (!res.ok) {
          toast({
            variant: "error",
            title: "Failed",
            description: "Could not load settings",
          });
          setS(normalizeSettings(null));
          return;
        }

        setS(normalizeSettings(json?.settings));
      } catch {
        toast({
          variant: "error",
          title: "Failed",
          description: "Could not load settings",
        });
        setS(normalizeSettings(null));
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [toast]);

  useEffect(() => {
    let alive = true;

    const loadFonts = async () => {
      setFontListLoading(true);

      try {
        const [latinRes, banglaRes] = await Promise.all([
          fetch("/api/admin/google-fonts?subset=latin", {
            cache: "no-store",
          }),
          fetch("/api/admin/google-fonts?subset=bengali", {
            cache: "no-store",
          }),
        ]);

        const [latinJson, banglaJson] = await Promise.all([
          latinRes.json().catch(() => null),
          banglaRes.json().catch(() => null),
        ]);

        if (!alive) return;

        setSiteFontOptions(normalizeFontOptions(latinJson, SITE_FONT_OPTIONS));
        setBanglaFontOptions(
          normalizeFontOptions(banglaJson, BANGLA_FONT_OPTIONS),
        );
      } catch {
        if (!alive) return;

        setSiteFontOptions(SITE_FONT_OPTIONS);
        setBanglaFontOptions(BANGLA_FONT_OPTIONS);
      } finally {
        if (alive) setFontListLoading(false);
      }
    };

    void loadFonts();

    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const loadDistricts = async () => {
      setDistrictDataLoading(true);
      try {
        const res = await fetch("/api/courier/steadfast/police-stations", {
          cache: "no-store",
        });
        const json = await res.json().catch(() => null);

        if (!res.ok) return;

        const nextDistricts = Array.isArray(json?.districts)
          ? json.districts
              .map((item: Record<string, unknown>) => ({
                id:
                  typeof item.id === "string" ? item.id : String(item.id ?? ""),
                name: typeof item.name === "string" ? item.name : "",
              }))
              .filter((item: DistrictOption) => item.id && item.name)
          : [];

        setDistricts(nextDistricts);
      } finally {
        setDistrictDataLoading(false);
      }
    };

    void loadDistricts();
  }, []);

  useEffect(() => {
    const loadPoliceStations = async () => {
      if (!newRule.district) {
        setPoliceStations([]);
        return;
      }

      try {
        const query = new URLSearchParams({ district: newRule.district });
        const res = await fetch(
          `/api/courier/steadfast/police-stations?${query.toString()}`,
          { cache: "no-store" },
        );
        const json = await res.json().catch(() => null);

        if (!res.ok) {
          setPoliceStations([]);
          return;
        }

        const nextStations = Array.isArray(json?.policeStations)
          ? json.policeStations
              .map((item: Record<string, unknown>) => ({
                id:
                  typeof item.id === "string" ? item.id : String(item.id ?? ""),
                name: typeof item.name === "string" ? item.name : "",
                district:
                  typeof item.district === "string" ? item.district : "",
              }))
              .filter(
                (item: PoliceStationOption) =>
                  item.id && item.name && item.district,
              )
          : [];

        setPoliceStations(nextStations);
      } catch {
        setPoliceStations([]);
      }
    };

    void loadPoliceStations();
  }, [newRule.district]);

  const saveSettings = async (
    settings: Settings,
    options?: {
      successDescription?: string;
    },
  ) => {
    const normalizedDraft = normalizeSettings(settings);

    setSaving(true);

    try {
      const payload = {
        ...normalizedDraft,
        taxRate: Number(normalizedDraft.taxRate || 0),
        shippingInsideDhaka: Number(normalizedDraft.shippingInsideDhaka || 0),
        shippingRangpur: Number(normalizedDraft.shippingRangpur || 0),
        shippingOutsideDhaka: Number(normalizedDraft.shippingOutsideDhaka || 0),
        shippingFreeOver: Number(normalizedDraft.shippingFreeOver || 0),
        shippingDefaultCharge: Number(
          normalizedDraft.shippingDefaultCharge || 0,
        ),
        lowStockThreshold: Number(normalizedDraft.lowStockThreshold || 0),
        aboutFaqs: normalizedDraft.aboutFaqs.filter(
          (item) => item.question || item.answer,
        ),
      };

      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const json = await res.json().catch(() => null);

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description: json?.message || "Could not save settings",
        });
        return;
      }

      const nextSettings = normalizeSettings(json?.settings);
      setS(nextSettings);
      announceFontSettings(nextSettings);

      toast({
        variant: "success",
        title: "Saved",
        description:
          options?.successDescription || "Settings saved successfully",
      });

      return true;
    } catch {
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not save settings",
      });
      return false;
    } finally {
      setSaving(false);
    }
  };

  const save = async () => {
    if (!s) return;
    await saveSettings(s);
  };

  const applyFontSettings = async (patch: Partial<Settings>) => {
    if (!s || saving) return;

    const next = normalizeSettings({ ...s, ...patch });
    setS(next);
    announceFontSettings(next);

    await saveSettings(next, {
      successDescription: "Font updated across the website.",
    });
  };

  const uploadLogo = async (event: ChangeEvent<HTMLInputElement>) => {
    if (!s) return;

    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    setLogoUploading(true);

    try {
      const form = new FormData();
      form.append("file", file);

      const res = await fetch("/api/upload/logo-image", {
        method: "POST",
        body: form,
      });

      const json = await res.json().catch(() => null);

      if (!res.ok || typeof json?.url !== "string") {
        toast({
          variant: "error",
          title: "Upload failed",
          description: json?.error || "Could not upload logo",
        });
        return;
      }

      setS((current) =>
        current ? { ...current, logoUrl: json.url } : current,
      );

      toast({
        variant: "success",
        title: "Logo uploaded",
        description: "Logo published successfully.",
      });
    } catch {
      toast({
        variant: "error",
        title: "Upload failed",
        description: "Could not upload logo",
      });
    } finally {
      setLogoUploading(false);
    }
  };

  const uploadManualPaymentImage = async (
    provider: ManualPaymentProviderKey,
    event: ChangeEvent<HTMLInputElement>,
  ) => {
    if (!s) return;

    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    setManualImageUploading((current) => ({ ...current, [provider]: true }));

    try {
      const form = new FormData();
      form.append("file", file);

      const res = await fetch(`/api/upload/payment-image/${provider}`, {
        method: "POST",
        body: form,
      });

      const json = await res.json().catch(() => null);

      if (!res.ok || typeof json?.url !== "string") {
        toast({
          variant: "error",
          title: "Upload failed",
          description:
            json?.error ||
            `Could not upload ${MANUAL_PAYMENT_PROVIDER_META[provider].label} image`,
        });
        return;
      }

      const imageField = MANUAL_PAYMENT_PROVIDER_META[provider].imageField;
      setS((current) =>
        current ? { ...current, [imageField]: json.url } : current,
      );

      toast({
        variant: "success",
        title: "Image uploaded",
        description: `${MANUAL_PAYMENT_PROVIDER_META[provider].label} image saved successfully.`,
      });
    } catch {
      toast({
        variant: "error",
        title: "Upload failed",
        description: `Could not upload ${MANUAL_PAYMENT_PROVIDER_META[provider].label} image`,
      });
    } finally {
      setManualImageUploading((current) => ({ ...current, [provider]: false }));
    }
  };

  const addShippingRule = () => {
    if (!s) return;
    if (!newRule.district) return;
    if (newRule.type === "POLICE_STATION" && !newRule.policeStation) return;

    const ruleId = `${newRule.type}:${newRule.district}:${newRule.policeStation || ""}`;
    const exists = s.shippingRules.some((rule) => rule.id === ruleId);

    if (exists) {
      toast({
        variant: "error",
        title: "Already exists",
        description: "This shipping rule already exists.",
      });
      return;
    }

    setS({
      ...s,
      shippingRules: [
        ...s.shippingRules,
        {
          id: ruleId,
          type: newRule.type,
          district: newRule.district,
          policeStation:
            newRule.type === "POLICE_STATION" ? newRule.policeStation : null,
          charge: Math.max(0, Math.floor(Number(newRule.charge || 0))),
        },
      ],
    });

    setNewRule((prev) => ({
      ...prev,
      policeStation: "",
      charge: 0,
    }));
  };

  const removeShippingRule = (id: string) => {
    if (!s) return;
    setS({
      ...s,
      shippingRules: s.shippingRules.filter((rule) => rule.id !== id),
    });
  };

  const updateFaq = (
    index: number,
    key: "question" | "answer",
    value: string,
  ) => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: s.aboutFaqs.map((item, i) =>
        i === index ? { ...item, [key]: value } : item,
      ),
    });
  };

  const addFaq = () => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: [...s.aboutFaqs, { question: "", answer: "" }],
    });
  };

  const removeFaq = (index: number) => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: s.aboutFaqs.filter((_, i) => i !== index),
    });
  };

  const sortedRules = useMemo(() => {
    if (!s) return [];
    return [...s.shippingRules].sort((a, b) => {
      if (a.type !== b.type) {
        return a.type === "POLICE_STATION" ? -1 : 1;
      }
      return `${a.district}-${a.policeStation || ""}`.localeCompare(
        `${b.district}-${b.policeStation || ""}`,
      );
    });
  }, [s]);

  const visibleSiteFontOptions = useMemo(
    () => filterFontOptions(siteFontOptions, siteFontQuery),
    [siteFontOptions, siteFontQuery],
  );

  const visibleBanglaFontOptions = useMemo(
    () => filterFontOptions(banglaFontOptions, banglaFontQuery),
    [banglaFontOptions, banglaFontQuery],
  );

  if (loading || !s) {
    return (
      <div className="grid gap-4">
        <div className="text-lg font-semibold">Store Settings</div>
        <Card className="rounded-3xl p-6 text-sm text-black/60">
          Loading settings...
        </Card>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">General Settings</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm text-black/60">Store Name</div>
            <Input
              value={s.storeName ?? ""}
              onChange={(e) => setS({ ...s, storeName: e.target.value })}
            />
          </div>

          <div className="md:row-span-2">
            <div className="text-sm text-black/60">Store Logo</div>
            <div className="mt-2 flex flex-col sm:flex-row flex-wrap items-center gap-4 rounded-2xl border border-black/10 bg-white/60 p-3">
              <div className="relative grid h-16 w-16 place-items-center overflow-hidden rounded-2xl bg-pink-50">
                <Image
                  src={s.logoUrl || "/logo.png"}
                  alt={s.storeName || "Store logo"}
                  fill
                  sizes="64px"
                  className="object-contain p-2"
                />
              </div>

              <div className="min-w-0 flex-1">
                <Input
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  onChange={uploadLogo}
                  disabled={logoUploading}
                />
                <div className="mt-2 text-xs text-black/50">
                  PNG, JPG, JPEG or WEBP. Upload first, then save settings.
                </div>
              </div>

              {s.logoUrl ? (
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() =>
                    setS((current) =>
                      current ? { ...current, logoUrl: "" } : current,
                    )
                  }
                  disabled={logoUploading}
                >
                  Remove logo
                </Button>
              ) : null}
            </div>
          </div>

          <div>
            <div className="text-sm text-black/60">Tax Rate (%)</div>
            <Input
              type="number"
              value={s.taxRate}
              onChange={(e) => setS({ ...s, taxRate: Number(e.target.value) })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">
              Default Shipping Charge (৳)
            </div>
            <Input
              type="number"
              value={s.shippingDefaultCharge}
              onChange={(e) =>
                setS({ ...s, shippingDefaultCharge: Number(e.target.value) })
              }
            />
            <div className="mt-1 text-xs text-black/50">
              কোনো district বা police station rule match না করলে এই charge হবে।
            </div>
          </div>

          <div>
            <div className="text-sm text-black/60">Free Shipping Over (৳)</div>
            <Input
              type="number"
              value={s.shippingFreeOver}
              onChange={(e) =>
                setS({ ...s, shippingFreeOver: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Low Stock Threshold</div>
            <Input
              type="number"
              value={s.lowStockThreshold}
              onChange={(e) =>
                setS({ ...s, lowStockThreshold: Number(e.target.value) })
              }
            />
          </div>

          <div className="flex flex-wrap items-end gap-4 md:col-span-2">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={s.codEnabled}
                onChange={(e) => setS({ ...s, codEnabled: e.target.checked })}
              />
              COD Enabled
            </label>

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={s.onlineEnabled}
                onChange={(e) =>
                  setS({ ...s, onlineEnabled: e.target.checked })
                }
              />
              Online Enabled
            </label>

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={s.manualPaymentEnabled}
                onChange={(e) =>
                  setS({ ...s, manualPaymentEnabled: e.target.checked })
                }
              />
              Manual Payment Enabled
            </label>
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">Typography Settings</div>
            <div className="mt-1 text-xs text-black/50">
              Font changes save immediately and apply across the website.
            </div>
          </div>

          <div
            className="rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm"
            style={{
              fontFamily: getSiteFontStack(
                s.siteFontFamily,
                s.banglaFontFamily,
              ),
            }}
          >
            NexoraMart • সিয়ামসবে
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm text-black/60">Website English Font</div>
              <div className="text-xs text-black/40">
                {fontListLoading
                  ? "Loading Google fonts..."
                  : `${siteFontOptions.length} fonts`}
              </div>
            </div>
            <Input
              value={siteFontQuery}
              onChange={(e) => setSiteFontQuery(e.target.value)}
              placeholder="Search English Google fonts"
              className="mb-2"
            />
            <div className="grid gap-2 sm:grid-cols-2">
              {visibleSiteFontOptions.map((font) => {
                const active = s.siteFontFamily === font.value;

                return (
                  <button
                    key={font.value}
                    type="button"
                    onClick={() =>
                      void applyFontSettings({ siteFontFamily: font.value })
                    }
                    disabled={saving}
                    className={`rounded-2xl border p-3 text-left transition ${
                      active
                        ? "border-blue-500 bg-blue-50 text-blue-900"
                        : "border-black/10 bg-white/70 hover:bg-white"
                    }`}
                    style={{ fontFamily: font.cssFamily }}
                  >
                    <div className="text-sm font-semibold">{font.label}</div>
                    <div className="mt-1 text-xs opacity-70">
                      {font.sample}
                    </div>
                  </button>
                );
              })}
            </div>
            {!visibleSiteFontOptions.length ? (
              <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
                No English font found.
              </div>
            ) : null}
          </div>

          <div>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm text-black/60">Bangla Font</div>
              <div className="text-xs text-black/40">
                {fontListLoading
                  ? "Loading Google fonts..."
                  : `${banglaFontOptions.length} fonts`}
              </div>
            </div>
            <Input
              value={banglaFontQuery}
              onChange={(e) => setBanglaFontQuery(e.target.value)}
              placeholder="Search Bangla Google fonts"
              className="mb-2"
            />
            <div className="grid gap-2 sm:grid-cols-2">
              {visibleBanglaFontOptions.map((font) => {
                const active = s.banglaFontFamily === font.value;

                return (
                  <button
                    key={font.value}
                    type="button"
                    onClick={() =>
                      void applyFontSettings({ banglaFontFamily: font.value })
                    }
                    disabled={saving}
                    className={`rounded-2xl border p-3 text-left transition ${
                      active
                        ? "border-blue-500 bg-blue-50 text-blue-900"
                        : "border-black/10 bg-white/70 hover:bg-white"
                    }`}
                    style={{ fontFamily: font.cssFamily }}
                  >
                    <div className="text-sm font-semibold">{font.label}</div>
                    <div className="mt-1 text-xs opacity-70">
                      {font.sample}
                    </div>
                  </button>
                );
              })}
            </div>
            {!visibleBanglaFontOptions.length ? (
              <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
                No Bangla font found.
              </div>
            ) : null}
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">
          Manual Payment Settings
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <div className="text-sm text-black/60">bKash Number</div>
            <Input
              value={s.manualBkashNumber}
              onChange={(e) =>
                setS({ ...s, manualBkashNumber: e.target.value })
              }
              placeholder="01XXXXXXXXX"
            />
            <div className="mt-3 rounded-2xl border border-black/10 bg-white/70 p-3">
              <div className="mb-2 text-sm text-black/60">bKash Image</div>
              <div className="relative mb-3 flex h-16 items-center justify-center overflow-hidden rounded-xl bg-pink-50">
                <Image
                  src={
                    s.manualBkashImageUrl ||
                    MANUAL_PAYMENT_PROVIDER_META.bkash.imageUrlFallback
                  }
                  alt="bKash"
                  fill
                  sizes="128px"
                  className="object-contain p-2"
                />
              </div>
              <Input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                onChange={(e) => void uploadManualPaymentImage("bkash", e)}
                disabled={manualImageUploading.bkash}
              />
              <div className="mt-2 text-xs text-black/50">
                Upload an image. It will be saved automatically.
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm text-black/60">Nagad Number</div>
            <Input
              value={s.manualNagadNumber}
              onChange={(e) =>
                setS({ ...s, manualNagadNumber: e.target.value })
              }
              placeholder="01XXXXXXXXX"
            />
            <div className="mt-3 rounded-2xl border border-black/10 bg-white/70 p-3">
              <div className="mb-2 text-sm text-black/60">Nagad Image</div>
              <div className="relative mb-3 flex h-16 items-center justify-center overflow-hidden rounded-xl bg-rose-50">
                <Image
                  src={
                    s.manualNagadImageUrl ||
                    MANUAL_PAYMENT_PROVIDER_META.nagad.imageUrlFallback
                  }
                  alt="Nagad"
                  fill
                  sizes="128px"
                  className="object-contain p-2"
                />
              </div>
              <Input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                onChange={(e) => void uploadManualPaymentImage("nagad", e)}
                disabled={manualImageUploading.nagad}
              />
              <div className="mt-2 text-xs text-black/50">
                Upload an image. It will be saved automatically.
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm text-black/60">Rocket Number</div>
            <Input
              value={s.manualRocketNumber}
              onChange={(e) =>
                setS({ ...s, manualRocketNumber: e.target.value })
              }
              placeholder="01XXXXXXXXX"
            />
            <div className="mt-3 rounded-2xl border border-black/10 bg-white/70 p-3">
              <div className="mb-2 text-sm text-black/60">Rocket Image</div>
              <div className="relative mb-3 flex h-16 items-center justify-center overflow-hidden rounded-xl bg-amber-50">
                <Image
                  src={
                    s.manualRocketImageUrl ||
                    MANUAL_PAYMENT_PROVIDER_META.rocket.imageUrlFallback
                  }
                  alt="Rocket"
                  fill
                  sizes="128px"
                  className="object-contain p-2"
                />
              </div>
              <Input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                onChange={(e) => void uploadManualPaymentImage("rocket", e)}
                disabled={manualImageUploading.rocket}
              />
              <div className="mt-2 text-xs text-black/50">
                Upload an image. It will be saved automatically.
              </div>
            </div>
          </div>
        </div>

        <div className="mt-2 text-xs text-black/50">
          If manual payment enabled is on and at least one number is filled, the
          manual payment option will be shown on the checkout page.
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Shipping Rules</div>

        <div className="grid gap-3 md:grid-cols-4">
          <div>
            <div className="text-sm text-black/60">Rule Type</div>
            <select
              className="h-11 w-full rounded-2xl border border-black/10 bg-white px-4 text-sm"
              value={newRule.type}
              onChange={(e) =>
                setNewRule({
                  ...newRule,
                  type: e.target.value as ShippingRuleType,
                  policeStation: "",
                })
              }
            >
              <option value="DISTRICT">District</option>
              <option value="POLICE_STATION">Police Station</option>
            </select>
          </div>

          <div>
            <div className="text-sm text-black/60">District</div>
            <select
              className="h-11 w-full rounded-2xl border border-black/10 bg-white px-4 text-sm"
              value={newRule.district}
              onChange={(e) =>
                setNewRule({
                  ...newRule,
                  district: e.target.value,
                  policeStation: "",
                })
              }
              disabled={districtDataLoading}
            >
              <option value="">
                {districtDataLoading ? "Loading..." : "Select district"}
              </option>
              {districts.map((district) => (
                <option key={district.id} value={district.name}>
                  {district.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="text-sm text-black/60">Police Station</div>
            <select
              className="h-11 w-full rounded-2xl border border-black/10 bg-white px-4 text-sm disabled:bg-black/5"
              value={newRule.policeStation}
              onChange={(e) =>
                setNewRule({ ...newRule, policeStation: e.target.value })
              }
              disabled={newRule.type !== "POLICE_STATION"}
            >
              <option value="">
                {newRule.type === "POLICE_STATION"
                  ? "Select police station"
                  : "Not required"}
              </option>
              {policeStations.map((station) => (
                <option key={station.id} value={station.name}>
                  {station.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="text-sm text-black/60">Charge (৳)</div>
            <div className="flex gap-2">
              <Input
                type="number"
                value={newRule.charge}
                onChange={(e) =>
                  setNewRule({ ...newRule, charge: Number(e.target.value) })
                }
              />
              <Button type="button" onClick={addShippingRule}>
                Add
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-black/10 bg-black/3 p-3 text-sm text-black/70">
          Priority: <b>Police Station rule</b> → <b>District rule</b> →{" "}
          <b>Default shipping charge</b>
        </div>

        <div className="mt-4 space-y-2">
          {sortedRules.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
              No shipping rules added yet.
            </div>
          ) : (
            sortedRules.map((rule) => (
              <div
                key={rule.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-black/10 p-3"
              >
                <div className="text-sm">
                  <div className="font-medium">
                    {rule.type === "POLICE_STATION"
                      ? `${rule.district} → ${rule.policeStation}`
                      : rule.district}
                  </div>
                  <div className="text-xs text-black/60">
                    {rule.type === "POLICE_STATION"
                      ? "Police Station Rule"
                      : "District Rule"}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-sm font-semibold">৳ {rule.charge}</div>
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => removeShippingRule(rule.id)}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Legacy Shipping Fields</div>

        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <div className="text-sm text-black/60">Dhaka Shipping</div>
            <Input
              type="number"
              value={s.shippingInsideDhaka}
              onChange={(e) =>
                setS({ ...s, shippingInsideDhaka: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Rangpur Shipping</div>
            <Input
              type="number"
              value={s.shippingRangpur}
              onChange={(e) =>
                setS({ ...s, shippingRangpur: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Outside Dhaka Shipping</div>
            <Input
              type="number"
              value={s.shippingOutsideDhaka}
              onChange={(e) =>
                setS({ ...s, shippingOutsideDhaka: Number(e.target.value) })
              }
            />
          </div>
        </div>

        <div className="mt-2 text-xs text-black/50">
          এগুলো legacy fallback হিসেবে রাখা আছে। নতুন rule-based system ব্যবহার
          করলে district/police station rules এবং default charge আগে কাজ করবে।
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Social Links</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm text-black/60">Facebook URL</div>
            <Input
              value={s.facebookUrl}
              onChange={(e) => setS({ ...s, facebookUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Instagram URL</div>
            <Input
              value={s.instagramUrl}
              onChange={(e) => setS({ ...s, instagramUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">YouTube URL</div>
            <Input
              value={s.youtubeUrl}
              onChange={(e) => setS({ ...s, youtubeUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">TikTok URL</div>
            <Input
              value={s.tiktokUrl}
              onChange={(e) => setS({ ...s, tiktokUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">WhatsApp URL</div>
            <Input
              value={s.whatsappUrl}
              onChange={(e) => setS({ ...s, whatsappUrl: e.target.value })}
            />
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">About Us</div>
        <textarea
          className="min-h-40 w-full rounded-2xl border border-black/10 px-4 py-3 text-sm outline-none"
          value={s.aboutUs}
          onChange={(e) => setS({ ...s, aboutUs: e.target.value })}
        />
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="text-sm font-semibold">About FAQ</div>
          <Button type="button" variant="secondary" onClick={addFaq}>
            Add FAQ
          </Button>
        </div>

        <div className="space-y-3">
          {s.aboutFaqs.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-black/10 p-4 text-sm text-black/50">
              No FAQ added yet.
            </div>
          ) : (
            s.aboutFaqs.map((faq, index) => (
              <div
                key={`${index}-${faq.question}`}
                className="rounded-2xl border border-black/10 p-3"
              >
                <div className="grid gap-3">
                  <div>
                    <div className="text-sm text-black/60">Question</div>
                    <Input
                      value={faq.question}
                      onChange={(e) =>
                        updateFaq(index, "question", e.target.value)
                      }
                    />
                  </div>

                  <div>
                    <div className="text-sm text-black/60">Answer</div>
                    <textarea
                      className="min-h-24 w-full rounded-2xl border border-black/10 px-4 py-3 text-sm outline-none"
                      value={faq.answer}
                      onChange={(e) =>
                        updateFaq(index, "answer", e.target.value)
                      }
                    />
                  </div>

                  <div>
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => removeFaq(index)}
                    >
                      Remove FAQ
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Policies</div>

        <div className="grid gap-4">
          <div>
            <div className="mb-1 text-sm text-black/60">
              Return & Refund Policy
            </div>
            <textarea
              className="min-h-40 w-full rounded-2xl border border-black/10 px-4 py-3 text-sm outline-none"
              value={s.returnRefundPolicy}
              onChange={(e) =>
                setS({ ...s, returnRefundPolicy: e.target.value })
              }
            />
          </div>

          <div>
            <div className="mb-1 text-sm text-black/60">Privacy Policy</div>
            <textarea
              className="min-h-40 w-full rounded-2xl border border-black/10 px-4 py-3 text-sm outline-none"
              value={s.privacyPolicy}
              onChange={(e) => setS({ ...s, privacyPolicy: e.target.value })}
            />
          </div>

          <div>
            <div className="mb-1 text-sm text-black/60">Terms & Conditions</div>
            <textarea
              className="min-h-40 w-full rounded-2xl border border-black/10 px-4 py-3 text-sm outline-none"
              value={s.termsConditions}
              onChange={(e) => setS({ ...s, termsConditions: e.target.value })}
            />
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Save</div>
        <Button onClick={save} disabled={saving}>
          {saving ? "Saving..." : "Save Settings"}
        </Button>
      </Card>
    </div>
  );
}
