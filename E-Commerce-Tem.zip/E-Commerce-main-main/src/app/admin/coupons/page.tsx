"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type CouponType = "PERCENT" | "FIXED";
type CouponScope = "ORDER" | "PRODUCTS" | "CATEGORIES";

type Coupon = {
  id: string;
  code: string;
  description: string | null;
  scope: CouponScope;
  productIds: string[];
  categoryIds: string[];
  type: CouponType;
  value: number;
  minSubtotal: number;
  maxDiscount: number | null;
  startsAt: string | null;
  endsAt: string | null;
  usageLimit: number | null;
  usedCount: number;
  orderCount: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

type ProductOption = {
  id: string;
  name: string;
  sku: string;
};

type CategoryOption = {
  id: string;
  name: string;
};

type CouponFormState = {
  id?: string;
  code: string;
  description: string;
  scope: CouponScope;
  productIds: string[];
  categoryIds: string[];
  type: CouponType;
  value: number;
  minSubtotal: number;
  maxDiscount: number | "";
  startsAt: string;
  endsAt: string;
  usageLimit: number | "";
  isActive: boolean;
};

const emptyForm: CouponFormState = {
  code: "",
  description: "",
  scope: "ORDER",
  productIds: [],
  categoryIds: [],
  type: "PERCENT",
  value: 10,
  minSubtotal: 0,
  maxDiscount: "",
  startsAt: "",
  endsAt: "",
  usageLimit: "",
  isActive: true,
};

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeBool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

function toDateInputValue(v: string | null): string {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function dateInputToIso(value: string, boundary: "start" | "end"): string {
  const [year, month, day] = value.split("-").map(Number);

  if (!year || !month || !day) {
    return new Date(value).toISOString();
  }

  const date =
    boundary === "start"
      ? new Date(year, month - 1, day, 0, 0, 0, 0)
      : new Date(year, month - 1, day, 23, 59, 59, 999);

  return date.toISOString();
}

function parseCoupons(input: unknown): Coupon[] {
  const obj = input as { coupons?: unknown };
  const raw = Array.isArray(obj?.coupons) ? obj.coupons : [];

  return raw
    .map((item) => item as Record<string, unknown>)
    .map(
      (item): Coupon => ({
        id: safeString(item.id),
        code: safeString(item.code).toUpperCase(),
        description: item.description ? String(item.description) : null,
        scope:
          item.scope === "PRODUCTS" || item.scope === "CATEGORIES"
            ? (item.scope as CouponScope)
            : ("ORDER" as CouponScope),
        productIds: Array.isArray(item.productIds)
          ? item.productIds.map((x) => String(x))
          : [],
        categoryIds: Array.isArray(item.categoryIds)
          ? item.categoryIds.map((x) => String(x))
          : [],
        type:
          item.type === "FIXED"
            ? ("FIXED" as CouponType)
            : ("PERCENT" as CouponType),
        value: safeNumber(item.value, 0),
        minSubtotal: safeNumber(item.minSubtotal, 0),
        maxDiscount:
          typeof item.maxDiscount === "number" ? item.maxDiscount : null,
        startsAt: typeof item.startsAt === "string" ? item.startsAt : null,
        endsAt: typeof item.endsAt === "string" ? item.endsAt : null,
        usageLimit:
          typeof item.usageLimit === "number" ? item.usageLimit : null,
        usedCount: safeNumber(item.usedCount, 0),
        orderCount: safeNumber(item.orderCount, 0),
        isActive: safeBool(item.isActive, false),
        createdAt: safeString(item.createdAt),
        updatedAt: safeString(item.updatedAt),
      }),
    )
    .filter((item) => item.id && item.code);
}

function parseProducts(input: unknown): ProductOption[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      name: safeString(item.name),
      sku: safeString(item.sku),
    }))
    .filter((item) => item.id && item.name);
}

function parseCategories(input: unknown): CategoryOption[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      name: safeString(item.name),
    }))
    .filter((item) => item.id && item.name);
}

export default function AdminCouponsPage() {
  const { toast } = useToast();

  const [items, setItems] = useState<Coupon[]>([]);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [categories, setCategories] = useState<CategoryOption[]>([]);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const [query, setQuery] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [categoryQuery, setCategoryQuery] = useState("");

  const [form, setForm] = useState<CouponFormState>(emptyForm);

  const filteredCoupons = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (item) =>
        item.code.toLowerCase().includes(q) ||
        (item.description ?? "").toLowerCase().includes(q),
    );
  }, [items, query]);

  const filteredProducts = useMemo(() => {
    const q = productQuery.trim().toLowerCase();
    if (!q) return products;
    return products.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        item.sku.toLowerCase().includes(q),
    );
  }, [products, productQuery]);

  const filteredCategories = useMemo(() => {
    const q = categoryQuery.trim().toLowerCase();
    if (!q) return categories;
    return categories.filter((item) => item.name.toLowerCase().includes(q));
  }, [categories, categoryQuery]);

  const load = async () => {
    setLoading(true);
    try {
      const [couponRes, productRes, categoryRes] = await Promise.all([
        fetch("/api/admin/coupons", { cache: "no-store" }),
        fetch("/api/admin/products", { cache: "no-store" }),
        fetch("/api/admin/categories", { cache: "no-store" }),
      ]);

      const [couponJson, productJson, categoryJson] = await Promise.all([
        couponRes.json().catch(() => null),
        productRes.json().catch(() => null),
        categoryRes.json().catch(() => null),
      ]);

      setItems(parseCoupons(couponJson));
      setProducts(parseProducts(productJson));
      setCategories(parseCategories(categoryJson));
    } catch {
      setItems([]);
      setProducts([]);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const startAdd = () => {
    setForm(emptyForm);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const startEdit = (coupon: Coupon) => {
    setForm({
      id: coupon.id,
      code: coupon.code,
      description: coupon.description ?? "",
      scope: coupon.scope,
      productIds: coupon.productIds ?? [],
      categoryIds: coupon.categoryIds ?? [],
      type: coupon.type,
      value: coupon.value,
      minSubtotal: coupon.minSubtotal,
      maxDiscount: coupon.maxDiscount ?? "",
      startsAt: toDateInputValue(coupon.startsAt),
      endsAt: toDateInputValue(coupon.endsAt),
      usageLimit: coupon.usageLimit ?? "",
      isActive: coupon.isActive,
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const closeForm = () => {
    setForm(emptyForm);
    setShowForm(false);
    setProductQuery("");
    setCategoryQuery("");
  };

  const validate = (): string | null => {
    const code = form.code.trim().toUpperCase();

    if (!code) return "Coupon code is required";
    if (code.length < 3) return "Coupon code too short";

    if (!Number.isFinite(form.value) || form.value <= 0) {
      return "Value must be greater than 0";
    }

    if (form.type === "PERCENT" && form.value > 100) {
      return "Percent cannot exceed 100";
    }

    if (!Number.isFinite(form.minSubtotal) || form.minSubtotal < 0) {
      return "Minimum subtotal cannot be negative";
    }

    if (form.maxDiscount !== "") {
      const n = Number(form.maxDiscount);
      if (!Number.isFinite(n) || n < 0) {
        return "Max discount cannot be negative";
      }
    }

    if (form.usageLimit !== "") {
      const n = Number(form.usageLimit);
      if (!Number.isFinite(n) || n < 1) {
        return "Usage limit must be 1 or more";
      }
    }

    if (form.startsAt && form.endsAt) {
      const s = new Date(form.startsAt);
      const e = new Date(form.endsAt);

      if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) {
        return "Invalid date";
      }

      if (s > e) return "Start date must be before end date";
    }

    if (form.scope === "PRODUCTS" && form.productIds.length === 0) {
      return "Select at least one product";
    }

    if (form.scope === "CATEGORIES" && form.categoryIds.length === 0) {
      return "Select at least one category";
    }

    return null;
  };

  const buildPayload = () => ({
    code: form.code.trim().toUpperCase(),
    description: form.description.trim() || null,
    scope: form.scope,
    productIds: form.scope === "PRODUCTS" ? form.productIds : [],
    categoryIds: form.scope === "CATEGORIES" ? form.categoryIds : [],
    type: form.type,
    value: Number(form.value),
    minSubtotal: Number(form.minSubtotal || 0),
    maxDiscount: form.maxDiscount === "" ? null : Number(form.maxDiscount),
    startsAt: form.startsAt ? dateInputToIso(form.startsAt, "start") : null,
    endsAt: form.endsAt ? dateInputToIso(form.endsAt, "end") : null,
    usageLimit: form.usageLimit === "" ? null : Number(form.usageLimit),
    isActive: !!form.isActive,
  });

  const save = async () => {
    const error = validate();
    if (error) {
      toast({
        variant: "error",
        title: "Failed",
        description: error,
      });
      return;
    }

    setSaving(true);
    try {
      const payload = buildPayload();

      const res = await fetch("/api/admin/coupons", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form.id ? { id: form.id, ...payload } : payload),
      });

      const json = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(
          typeof json?.message === "string" ? json.message : "Save failed",
        );
      }

      await load();
      closeForm();

      toast({
        title: form.id ? "Coupon updated" : "Coupon created",
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Save failed",
        description:
          error instanceof Error ? error.message : "Something went wrong",
      });
    } finally {
      setSaving(false);
    }
  };

  const removeCoupon = async (id: string) => {
    const ok = confirm("Delete this coupon?");
    if (!ok) return;

    setSaving(true);
    try {
      const res = await fetch(
        `/api/admin/coupons?id=${encodeURIComponent(id)}`,
        {
          method: "DELETE",
        },
      );

      if (!res.ok) {
        throw new Error("Delete failed");
      }

      await load();

      if (form.id === id) {
        closeForm();
      }

      toast({ title: "Coupon deleted" });
    } catch {
      toast({
        variant: "error",
        title: "Delete failed",
      });
    } finally {
      setSaving(false);
    }
  };

  const quickToggle = async (coupon: Coupon) => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/coupons", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...coupon,
          isActive: !coupon.isActive,
        }),
      });

      if (!res.ok) {
        throw new Error("Toggle failed");
      }

      await load();
    } catch {
      toast({
        variant: "error",
        title: "Toggle failed",
      });
    } finally {
      setSaving(false);
    }
  };

  const statusLabel = (
    coupon: Coupon,
  ): "Inactive" | "Scheduled" | "Expired" | "Active" => {
    const now = new Date();
    const s = coupon.startsAt ? new Date(coupon.startsAt) : null;
    const e = coupon.endsAt ? new Date(coupon.endsAt) : null;

    if (!coupon.isActive) return "Inactive";
    if (s && now < s) return "Scheduled";
    if (e && now > e) return "Expired";
    return "Active";
  };

  const toggleProduct = (id: string) => {
    setForm((prev) => ({
      ...prev,
      productIds: prev.productIds.includes(id)
        ? prev.productIds.filter((item) => item !== id)
        : [...prev.productIds, id],
    }));
  };

  const toggleCategory = (id: string) => {
    setForm((prev) => ({
      ...prev,
      categoryIds: prev.categoryIds.includes(id)
        ? prev.categoryIds.filter((item) => item !== id)
        : [...prev.categoryIds, id],
    }));
  };

  return (
    <div className="grid gap-4">
      <div className="flex flex-col px-4 gap-3 md:flex-row md:items-end md:justify-between">
        <div className="min-w-0">
          <div className="text-lg font-semibold">Coupons</div>
          <div className="text-sm leading-6 text-black/60">
            Product, multiple products, category, multiple categories and
            full-order coupon support.
          </div>
        </div>

        <div className="flex w-full flex-col gap-2 sm:flex-row md:w-auto md:flex-wrap">
          <Input
            placeholder="Search coupons…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full sm:flex-1 md:w-64 md:flex-none"
          />
          <div className="grid grid-cols-2 gap-2 sm:flex">
            <Button
              variant="secondary"
              onClick={() => void load()}
              disabled={loading || saving}
              className="w-full sm:w-auto"
            >
              Refresh
            </Button>
            <Button
              onClick={startAdd}
              disabled={saving}
              className="w-full sm:w-auto"
            >
              Add Coupon
            </Button>
          </div>
        </div>
      </div>

      {showForm ? (
        <Card className="rounded-3xl p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="min-w-0">
              <div className="text-sm font-semibold">
                {form.id ? "Edit Coupon" : "New Coupon"}
              </div>
              <div className="text-xs text-black/60">
                Coupon code automatically uppercase হবে।
              </div>
            </div>

            <div className="grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto">
              {form.id ? (
                <Button
                  variant="danger"
                  onClick={() => void removeCoupon(form.id!)}
                  disabled={saving}
                  className="w-full sm:w-auto"
                >
                  Delete
                </Button>
              ) : null}
              <Button
                variant="secondary"
                onClick={closeForm}
                disabled={saving}
                className="w-full sm:w-auto"
              >
                Close
              </Button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <div>
              <div className="text-sm text-black/60">Coupon Code *</div>
              <Input
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                placeholder="e.g. EID25"
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Scope *</div>
              <select
                value={form.scope}
                onChange={(e) =>
                  setForm({
                    ...form,
                    scope: e.target.value as CouponScope,
                    productIds:
                      e.target.value === "PRODUCTS" ? form.productIds : [],
                    categoryIds:
                      e.target.value === "CATEGORIES" ? form.categoryIds : [],
                  })
                }
                className="h-11 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
              >
                <option value="ORDER">All eligible order items</option>
                <option value="PRODUCTS">Selected product(s)</option>
                <option value="CATEGORIES">Selected category(s)</option>
              </select>
            </div>

            <div>
              <div className="text-sm text-black/60">Type *</div>
              <select
                value={form.type}
                onChange={(e) =>
                  setForm({ ...form, type: e.target.value as CouponType })
                }
                className="h-11 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
              >
                <option value="PERCENT">Percent (%)</option>
                <option value="FIXED">Fixed (৳)</option>
              </select>
            </div>

            <div className="md:col-span-2 xl:col-span-3">
              <div className="text-sm text-black/60">
                Description (optional)
              </div>
              <textarea
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                placeholder="Short admin note / campaign note"
                className="min-h-24 w-full rounded-2xl border border-black/10 bg-white px-3 py-2 text-sm outline-none"
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Value *</div>
              <Input
                type="number"
                value={form.value}
                onChange={(e) =>
                  setForm({ ...form, value: Number(e.target.value) })
                }
              />
            </div>

            <div>
              <div className="text-sm text-black/60">
                Minimum eligible subtotal (৳)
              </div>
              <Input
                type="number"
                value={form.minSubtotal}
                onChange={(e) =>
                  setForm({ ...form, minSubtotal: Number(e.target.value) })
                }
              />
            </div>

            <div>
              <div className="text-sm text-black/60">
                Max discount (optional)
              </div>
              <Input
                type="number"
                value={form.maxDiscount}
                onChange={(e) =>
                  setForm({
                    ...form,
                    maxDiscount:
                      e.target.value === "" ? "" : Number(e.target.value),
                  })
                }
                placeholder="e.g. 500"
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Starts at (optional)</div>
              <Input
                type="date"
                value={form.startsAt}
                onChange={(e) => setForm({ ...form, startsAt: e.target.value })}
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Ends at (optional)</div>
              <Input
                type="date"
                value={form.endsAt}
                onChange={(e) => setForm({ ...form, endsAt: e.target.value })}
              />
            </div>

            <div>
              <div className="text-sm text-black/60">
                Usage limit (optional)
              </div>
              <Input
                type="number"
                value={form.usageLimit}
                onChange={(e) =>
                  setForm({
                    ...form,
                    usageLimit:
                      e.target.value === "" ? "" : Number(e.target.value),
                  })
                }
                placeholder="e.g. 100"
              />
            </div>

            <div className="flex items-center gap-3 md:col-span-2 xl:col-span-3">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={form.isActive}
                  onChange={(e) =>
                    setForm({ ...form, isActive: e.target.checked })
                  }
                />
                Active
              </label>
            </div>
          </div>

          {form.scope === "PRODUCTS" ? (
            <div className="mt-5 rounded-3xl border border-black/10 p-4">
              <div className="mb-3 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-semibold">Select Products</div>
                  <div className="text-xs text-black/60">
                    Selected: {form.productIds.length}
                  </div>
                </div>
                <Input
                  value={productQuery}
                  onChange={(e) => setProductQuery(e.target.value)}
                  placeholder="Search product by name / SKU"
                  className="w-full md:w-72"
                />
              </div>

              <div className="max-h-72 space-y-2 overflow-auto rounded-2xl border border-black/10 p-3">
                {filteredProducts.map((product) => (
                  <label
                    key={product.id}
                    className="flex items-start justify-between gap-3 rounded-2xl border border-black/5 px-3 py-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="wrap-break-word text-sm font-medium">
                        {product.name}
                      </div>
                      <div className="break-all text-xs text-black/50">
                        {product.sku}
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={form.productIds.includes(product.id)}
                      onChange={() => toggleProduct(product.id)}
                      className="mt-1 shrink-0"
                    />
                  </label>
                ))}
              </div>
            </div>
          ) : null}

          {form.scope === "CATEGORIES" ? (
            <div className="mt-5 rounded-3xl border border-black/10 p-4">
              <div className="mb-3 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-semibold">Select Categories</div>
                  <div className="text-xs text-black/60">
                    Selected: {form.categoryIds.length}
                  </div>
                </div>
                <Input
                  value={categoryQuery}
                  onChange={(e) => setCategoryQuery(e.target.value)}
                  placeholder="Search category"
                  className="w-full md:w-72"
                />
              </div>

              <div className="max-h-72 space-y-2 overflow-auto rounded-2xl border border-black/10 p-3">
                {filteredCategories.map((category) => (
                  <label
                    key={category.id}
                    className="flex items-start justify-between gap-3 rounded-2xl border border-black/5 px-3 py-2"
                  >
                    <div className="min-w-0 flex-1 wrap-break-word text-sm font-medium">
                      {category.name}
                    </div>
                    <input
                      type="checkbox"
                      checked={form.categoryIds.includes(category.id)}
                      onChange={() => toggleCategory(category.id)}
                      className="mt-1 shrink-0"
                    />
                  </label>
                ))}
              </div>
            </div>
          ) : null}

          <div className="mt-4">
            <Button
              onClick={() => void save()}
              disabled={saving}
              className="w-full sm:w-auto"
            >
              {saving ? "Saving…" : form.id ? "Update Coupon" : "Create Coupon"}
            </Button>
          </div>
        </Card>
      ) : null}

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm font-semibold">All Coupons</div>
          <div className="text-xs text-black/60">
            {loading ? "Loading…" : `${filteredCoupons.length} items`}
          </div>
        </div>

        <div className="grid gap-3 lg:grid-cols-2">
          {filteredCoupons.map((coupon) => (
            <div
              key={coupon.id}
              className="rounded-3xl border border-black/10 bg-white p-4 shadow-sm"
            >
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <Link
                  href={`/admin/coupons/${coupon.id}`}
                  className="min-w-0 flex-1 rounded-2xl outline-none transition hover:bg-black/[0.02] focus-visible:ring-2 focus-visible:ring-black"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="max-w-full wrap-break-word text-base font-semibold">
                      {coupon.code}
                    </div>
                    <span className="rounded-full bg-black/5 px-3 py-1 text-xs text-black/70">
                      {statusLabel(coupon)}
                    </span>
                    <span className="rounded-full bg-black/5 px-3 py-1 text-xs text-black/70">
                      {coupon.scope}
                    </span>
                  </div>

                  {coupon.description ? (
                    <div className="mt-2 wrap-break-word text-sm text-black/70">
                      {coupon.description}
                    </div>
                  ) : null}

                  <div className="mt-2 wrap-break-word text-sm text-black/70">
                    {coupon.type === "PERCENT"
                      ? `${coupon.value}% off`
                      : `৳ ${coupon.value} off`}
                    {coupon.minSubtotal ? (
                      <span className="text-black/50">
                        {" "}
                        • Min ৳{coupon.minSubtotal}
                      </span>
                    ) : null}
                    {coupon.maxDiscount != null ? (
                      <span className="text-black/50">
                        {" "}
                        • Max ৳{coupon.maxDiscount}
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-1 wrap-break-word text-xs leading-5 text-black/60">
                    Orders: {coupon.orderCount} • Used: {coupon.usedCount}
                    {coupon.usageLimit != null
                      ? ` / ${coupon.usageLimit}`
                      : ""}{" "}
                    •{" "}
                    {coupon.startsAt
                      ? `Start: ${toDateInputValue(coupon.startsAt)}`
                      : "Start: —"}{" "}
                    •{" "}
                    {coupon.endsAt
                      ? `End: ${toDateInputValue(coupon.endsAt)}`
                      : "End: —"}
                  </div>

                  {coupon.scope === "PRODUCTS" ? (
                    <div className="mt-2 text-xs text-black/55">
                      Products selected: {coupon.productIds.length}
                    </div>
                  ) : null}

                  {coupon.scope === "CATEGORIES" ? (
                    <div className="mt-2 text-xs text-black/55">
                      Categories selected: {coupon.categoryIds.length}
                    </div>
                  ) : null}
                </Link>

                <div className="grid grid-cols-2 gap-2 sm:flex sm:w-auto sm:flex-col">
                  <Link
                    href={`/admin/coupons/${coupon.id}`}
                    className="inline-flex h-11 w-full items-center justify-center rounded-2xl border border-black/10 bg-white/70 px-5 text-sm font-medium text-black transition hover:bg-white sm:w-auto"
                  >
                    Details
                  </Link>
                  <Button
                    variant="secondary"
                    onClick={() => void quickToggle(coupon)}
                    disabled={saving}
                    className="w-full sm:w-auto"
                  >
                    Toggle
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => startEdit(coupon)}
                    disabled={saving}
                    className="w-full sm:w-auto"
                  >
                    Edit
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {!filteredCoupons.length && !loading ? (
          <div className="mt-6 rounded-3xl bg-black/5 p-6 text-sm text-black/60">
            No coupons found. Click <b>Add Coupon</b> to create your first
            coupon.
          </div>
        ) : null}
      </Card>
    </div>
  );
}
