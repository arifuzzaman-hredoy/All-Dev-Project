import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Banknote,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  ReceiptText,
  ShoppingBag,
  Tag,
  Users,
} from "lucide-react";
import { OrderStatus, PaymentStatus } from "@prisma/client";
import { Card } from "@/components/ui/card";
import { prisma } from "@/lib/prisma";
import { normalizeCouponCode } from "@/lib/services/coupon-service";
import {
  getDefaultDeliveryCharge,
  getGrandSellAmount,
  getOrderItemsInvestedAmount,
  getRevenue,
} from "@/lib/revenue-calculation";

export const dynamic = "force-dynamic";

type PageProps = {
  params: Promise<{ id?: string }> | { id?: string };
  searchParams?: Promise<{ page?: string }> | { page?: string };
};

const ORDERS_PER_PAGE = 20;

function money(value: number | null | undefined) {
  if (value === null || value === undefined) return "-";
  return `৳ ${Math.round(value).toLocaleString("en-BD")}`;
}

function dateTime(value: Date) {
  return value.toLocaleString("en-BD", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function displayOrderId(order: { id: string; publicOrderId: string | null }) {
  return order.publicOrderId?.trim() || order.id;
}

function statusClass(status: OrderStatus) {
  switch (status) {
    case "PENDING":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "PROCESSING":
      return "border-sky-200 bg-sky-50 text-sky-700";
    case "SHIPPED":
      return "border-violet-200 bg-violet-50 text-violet-700";
    case "DELIVERED":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "CANCELLED":
      return "border-rose-200 bg-rose-50 text-rose-700";
  }
}

function paymentClass(status: PaymentStatus) {
  switch (status) {
    case "PAID":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "UNPAID":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "FAILED":
      return "border-red-200 bg-red-50 text-red-700";
    case "REFUNDED":
      return "border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700";
  }
}

function StatusBadge({
  children,
  className,
}: {
  children: React.ReactNode;
  className: string;
}) {
  return (
    <span
      className={`inline-flex w-fit items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold ${className}`}
    >
      {children}
    </span>
  );
}

function MetricCard({
  icon,
  label,
  value,
  note,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  note?: string;
}) {
  return (
    <Card className="rounded-[24px] border border-black/10 bg-white p-4 shadow-sm">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-black text-white">
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-xs font-medium uppercase tracking-[0.12em] text-black/45">
            {label}
          </div>
          <div className="mt-1 wrap-break-word text-xl font-bold text-black">
            {value}
          </div>
          {note ? <div className="mt-1 text-xs text-black/55">{note}</div> : null}
        </div>
      </div>
    </Card>
  );
}

function PaginationLinks({
  id,
  page,
  pages,
}: {
  id: string;
  page: number;
  pages: number;
}) {
  if (pages <= 1) return null;

  const items: number[] = [];
  const add = (n: number) => {
    if (n >= 1 && n <= pages && !items.includes(n)) items.push(n);
  };

  add(1);
  add(pages);
  add(page - 1);
  add(page);
  add(page + 1);

  const normalized = items.sort((a, b) => a - b);
  const final: Array<number | "gap"> = [];

  for (let i = 0; i < normalized.length; i++) {
    final.push(normalized[i]);
    if (i < normalized.length - 1 && normalized[i + 1] - normalized[i] > 1) {
      final.push("gap");
    }
  }

  const hrefFor = (nextPage: number) =>
    `/admin/coupons/${id}${nextPage > 1 ? `?page=${nextPage}` : ""}`;

  return (
    <div className="flex flex-col gap-3 pt-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-xs text-black/60">
        Page {page} of {pages}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {page > 1 ? (
          <Link
            href={hrefFor(page - 1)}
            className="inline-flex h-10 items-center gap-1 rounded-xl border border-black/10 px-3 text-sm hover:bg-black/5"
          >
            <ChevronLeft className="h-4 w-4" />
            Prev
          </Link>
        ) : (
          <span className="inline-flex h-10 cursor-not-allowed items-center gap-1 rounded-xl border border-black/10 px-3 text-sm opacity-50">
            <ChevronLeft className="h-4 w-4" />
            Prev
          </span>
        )}

        <div className="flex flex-wrap items-center gap-1">
          {final.map((item, idx) =>
            item === "gap" ? (
              <span key={`gap-${idx}`} className="px-2 text-black/40">
                ...
              </span>
            ) : (
              <Link
                key={item}
                href={hrefFor(item)}
                className={`inline-flex min-w-10 justify-center rounded-xl px-3 py-2 text-sm ${
                  item === page
                    ? "bg-black text-white"
                    : "border border-black/10 hover:bg-black/5"
                }`}
              >
                {item}
              </Link>
            ),
          )}
        </div>

        {page < pages ? (
          <Link
            href={hrefFor(page + 1)}
            className="inline-flex h-10 items-center gap-1 rounded-xl border border-black/10 px-3 text-sm hover:bg-black/5"
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </Link>
        ) : (
          <span className="inline-flex h-10 cursor-not-allowed items-center gap-1 rounded-xl border border-black/10 px-3 text-sm opacity-50">
            Next
            <ChevronRight className="h-4 w-4" />
          </span>
        )}
      </div>
    </div>
  );
}

export default async function AdminCouponDetailsPage({
  params,
  searchParams,
}: PageProps) {
  const resolvedParams = await params;
  const resolvedSearchParams = searchParams ? await searchParams : {};
  const id = resolvedParams.id;

  if (!id) notFound();

  const coupon = await prisma.coupon.findUnique({
    where: { id },
  });

  if (!coupon) notFound();

  const normalizedCode = normalizeCouponCode(coupon.code);
  const requestedPage = Math.max(1, Number(resolvedSearchParams.page || "1") || 1);
  const where = {
    couponCode: {
      equals: normalizedCode,
      mode: "insensitive" as const,
    },
  };
  const orderInclude = {
    user: {
      select: {
        name: true,
        email: true,
      },
    },
    revenueRecord: true,
    items: {
      orderBy: { createdAt: "asc" as const },
      include: {
        product: {
          select: {
            investedAmount: true,
          },
        },
        variant: {
          select: {
            investedAmount: true,
          },
        },
      },
    },
  };

  const [totalOrders, allOrders] = await Promise.all([
    prisma.order.count({ where }),
    prisma.order.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: orderInclude,
    }),
  ]);

  const pages = Math.max(1, Math.ceil(totalOrders / ORDERS_PER_PAGE));
  const page = Math.min(requestedPage, pages);
  const skip = (page - 1) * ORDERS_PER_PAGE;
  const orders = await prisma.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
    skip,
    take: ORDERS_PER_PAGE,
    include: orderInclude,
  });

  const activeOrders = allOrders.filter((order) => order.status !== "CANCELLED");
  const deliveredOrders = allOrders.filter((order) => order.status === "DELIVERED");
  const uniqueBuyers = new Set(
    allOrders.map((order) => order.userId || order.phone || order.email || order.name),
  ).size;

  const buildRows = (sourceOrders: typeof allOrders) =>
    sourceOrders.map((order) => {
      const deliveryCharge =
        order.revenueRecord?.deliveryCharge ??
        getDefaultDeliveryCharge(order.shipping);
      const investedAmount =
        order.revenueRecord?.investedAmount ??
        getOrderItemsInvestedAmount(order.items);
      const grandSell = getGrandSellAmount({
        sell: order.total,
        deliveryCharge,
      });
      const profit = getRevenue({
        sell: order.total,
        deliveryCharge,
        investedAmount,
      });

      return {
        order,
        grandSell,
        profit,
        itemSummary: order.items
          .map((item) => `${item.productName} x${item.qty}`)
          .join(", "),
      };
    });

  const rows = buildRows(orders);
  const activeRows = buildRows(allOrders).filter(
    (row) => row.order.status !== "CANCELLED",
  );
  const grossSales = activeRows.reduce((sum, row) => sum + row.order.total, 0);
  const grossSubtotal = activeRows.reduce(
    (sum, row) => sum + row.order.subtotal,
    0,
  );
  const totalDiscount = activeRows.reduce(
    (sum, row) => sum + row.order.discount,
    0,
  );
  const shippingCollected = activeRows.reduce(
    (sum, row) => sum + row.order.shipping,
    0,
  );
  const totalGrandSell = activeRows.reduce((sum, row) => sum + row.grandSell, 0);
  const knownProfitRows = activeRows.filter((row) => row.profit !== null);
  const estimatedProfit = knownProfitRows.reduce(
    (sum, row) => sum + (row.profit ?? 0),
    0,
  );
  const averageOrderValue = activeRows.length
    ? Math.round(grossSales / activeRows.length)
    : 0;
  const firstShown = totalOrders === 0 ? 0 : skip + 1;
  const lastShown = Math.min(skip + orders.length, totalOrders);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:py-10">
      <div className="mb-5">
        <Link
          href="/admin/coupons"
          className="inline-flex items-center gap-2 rounded-2xl border border-black/10 bg-white px-4 py-2 text-sm font-medium text-black transition hover:bg-black/5"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to coupons
        </Link>
      </div>

      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="wrap-break-word text-3xl font-bold tracking-tight text-black">
              {coupon.code}
            </h1>
            <span className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs font-semibold text-black/65">
              {coupon.scope}
            </span>
            <span
              className={`rounded-full border px-3 py-1 text-xs font-semibold ${
                coupon.isActive
                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                  : "border-rose-200 bg-rose-50 text-rose-700"
              }`}
            >
              {coupon.isActive ? "ACTIVE" : "INACTIVE"}
            </span>
          </div>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-black/60">
            {coupon.description ||
              "All orders that used this coupon are listed below with buyer and revenue details."}
          </p>
        </div>

        <div className="rounded-[24px] border border-black/10 bg-white p-4 shadow-sm">
          <div className="text-xs font-medium uppercase tracking-[0.12em] text-black/45">
            Coupon offer
          </div>
          <div className="mt-1 text-lg font-bold text-black">
            {coupon.type === "PERCENT"
              ? `${coupon.value}% off`
              : `${money(coupon.value)} off`}
          </div>
          <div className="mt-1 text-xs leading-5 text-black/55">
            Min {money(coupon.minSubtotal)}
            {coupon.maxDiscount !== null ? ` • Max ${money(coupon.maxDiscount)}` : ""}
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={<ShoppingBag className="h-5 w-5" />}
          label="Coupon orders"
          value={totalOrders.toLocaleString("en-BD")}
          note={`${activeOrders.length} active, ${deliveredOrders.length} delivered`}
        />
        <MetricCard
          icon={<Banknote className="h-5 w-5" />}
          label="Total sales"
          value={money(grossSales)}
          note="Cancelled orders excluded"
        />
        <MetricCard
          icon={<Tag className="h-5 w-5" />}
          label="Discount given"
          value={money(totalDiscount)}
          note={`Subtotal before discount ${money(grossSubtotal)}`}
        />
        <MetricCard
          icon={<ReceiptText className="h-5 w-5" />}
          label="Estimated profit"
          value={money(estimatedProfit)}
          note={
            knownProfitRows.length === activeRows.length
              ? `Net sell ${money(totalGrandSell)}`
              : `${knownProfitRows.length}/${activeRows.length} orders have cost data`
          }
        />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={<Users className="h-5 w-5" />}
          label="Buyers"
          value={uniqueBuyers.toLocaleString("en-BD")}
          note="Unique by account, phone, email or name"
        />
        <MetricCard
          icon={<Banknote className="h-5 w-5" />}
          label="Average order"
          value={money(averageOrderValue)}
          note="Active orders only"
        />
        <MetricCard
          icon={<ShoppingBag className="h-5 w-5" />}
          label="Shipping collected"
          value={money(shippingCollected)}
          note="Active orders only"
        />
        <MetricCard
          icon={<Tag className="h-5 w-5" />}
          label="Recorded usage"
          value={coupon.usedCount.toLocaleString("en-BD")}
          note={
            coupon.usageLimit !== null
              ? `Limit ${coupon.usageLimit.toLocaleString("en-BD")}`
              : "No usage limit"
          }
        />
      </div>

      <Card className="mt-6 rounded-[28px] border border-black/10 bg-white p-4 shadow-sm">
        <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="text-lg font-bold text-black">Order Details</div>
            <div className="text-sm text-black/55">
              Showing {firstShown.toLocaleString("en-BD")}-
              {lastShown.toLocaleString("en-BD")} of{" "}
              {totalOrders.toLocaleString("en-BD")} orders, max 20 per page.
            </div>
          </div>
          <div className="text-sm font-semibold text-black/60">
            Coupon code {coupon.code}
          </div>
        </div>

        <div className="hidden overflow-x-auto lg:block">
          <table className="w-full min-w-[1180px] border-separate border-spacing-0 text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-[0.08em] text-black/45">
                <th className="border-b border-black/10 px-3 py-3">Order</th>
                <th className="border-b border-black/10 px-3 py-3">Buyer</th>
                <th className="border-b border-black/10 px-3 py-3">Status</th>
                <th className="border-b border-black/10 px-3 py-3">Items</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Subtotal</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Discount</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Shipping</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Total</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Profit</th>
                <th className="border-b border-black/10 px-3 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ order, itemSummary, profit }) => (
                <tr key={order.id} className="align-top">
                  <td className="border-b border-black/5 px-3 py-4">
                    <div className="font-semibold text-black">
                      #{displayOrderId(order)}
                    </div>
                    <div className="mt-1 text-xs text-black/50">
                      {dateTime(order.createdAt)}
                    </div>
                  </td>
                  <td className="border-b border-black/5 px-3 py-4">
                    <div className="font-semibold text-black">{order.name}</div>
                    <div className="mt-1 text-xs leading-5 text-black/55">
                      {order.phone}
                      <br />
                      {order.email || order.user?.email || "No email"}
                    </div>
                  </td>
                  <td className="border-b border-black/5 px-3 py-4">
                    <div className="flex flex-col gap-2">
                      <StatusBadge className={statusClass(order.status)}>
                        {order.status}
                      </StatusBadge>
                      <StatusBadge className={paymentClass(order.paymentStatus)}>
                        {order.paymentStatus}
                      </StatusBadge>
                    </div>
                  </td>
                  <td className="max-w-[260px] border-b border-black/5 px-3 py-4">
                    <div className="line-clamp-3 text-black/70">
                      {itemSummary || "No items"}
                    </div>
                    <div className="mt-1 text-xs text-black/45">
                      {order.items.length} line items
                    </div>
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right font-medium">
                    {money(order.subtotal)}
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right font-medium text-rose-600">
                    -{money(order.discount)}
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right font-medium">
                    {money(order.shipping)}
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right font-bold">
                    {money(order.total)}
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right font-bold">
                    {order.status === "CANCELLED" ? "-" : money(profit)}
                  </td>
                  <td className="border-b border-black/5 px-3 py-4 text-right">
                    <Link
                      href={`/admin/orders/${order.id}`}
                      className="inline-flex items-center justify-center gap-1 rounded-2xl border border-black/10 bg-white px-3 py-2 text-xs font-semibold text-black transition hover:bg-black/5"
                    >
                      View
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="grid gap-3 lg:hidden">
          {rows.map(({ order, itemSummary, profit }) => (
            <div
              key={order.id}
              className="rounded-[22px] border border-black/10 bg-white p-4"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                  <div className="wrap-break-word text-base font-bold text-black">
                    #{displayOrderId(order)}
                  </div>
                  <div className="mt-1 text-xs text-black/50">
                    {dateTime(order.createdAt)}
                  </div>
                  <div className="mt-3 text-sm font-semibold text-black">
                    {order.name}
                  </div>
                  <div className="mt-1 wrap-break-word text-xs leading-5 text-black/55">
                    {order.phone} • {order.email || order.user?.email || "No email"}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <StatusBadge className={statusClass(order.status)}>
                    {order.status}
                  </StatusBadge>
                  <StatusBadge className={paymentClass(order.paymentStatus)}>
                    {order.paymentStatus}
                  </StatusBadge>
                </div>
              </div>

              <div className="mt-4 rounded-2xl bg-black/[0.03] p-3 text-sm text-black/70">
                <div className="line-clamp-3">{itemSummary || "No items"}</div>
                <div className="mt-1 text-xs text-black/45">
                  {order.items.length} line items
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-black/45">Subtotal</div>
                  <div className="font-semibold">{money(order.subtotal)}</div>
                </div>
                <div>
                  <div className="text-xs text-black/45">Discount</div>
                  <div className="font-semibold text-rose-600">
                    -{money(order.discount)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-black/45">Total</div>
                  <div className="font-bold">{money(order.total)}</div>
                </div>
                <div>
                  <div className="text-xs text-black/45">Profit</div>
                  <div className="font-bold">
                    {order.status === "CANCELLED" ? "-" : money(profit)}
                  </div>
                </div>
              </div>

              <Link
                href={`/admin/orders/${order.id}`}
                className="mt-4 inline-flex h-10 w-full items-center justify-center gap-2 rounded-2xl border border-black/10 bg-white px-4 text-sm font-semibold text-black transition hover:bg-black/5"
              >
                View full order
                <ExternalLink className="h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>

        {rows.length === 0 ? (
          <div className="rounded-[24px] border border-dashed border-black/10 p-8 text-center text-sm text-black/55">
            No orders have used this coupon yet.
          </div>
        ) : (
          <PaginationLinks id={id} page={page} pages={pages} />
        )}
      </Card>
    </div>
  );
}
