import AdminUsersClient from "@/components/admin/users/admin-users-client";

export default function AdminUsersPage() {
  return <AdminUsersClient />;
}