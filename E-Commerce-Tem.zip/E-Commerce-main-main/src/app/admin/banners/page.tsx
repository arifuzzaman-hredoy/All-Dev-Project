"use client";

import Image from "next/image";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type BannerSlot = "mainbanner" | "subbanner1" | "subbanner2";

type Banner = {
  id: string;
  slot: BannerSlot | null;
  title: string | null;
  imageUrl: string;
  linkUrl: string | null;
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
};

type BannersResponse = {
  banners: Banner[];
};

type UploadResponse = {
  url?: string;
  error?: string;
};

type BannerFormState = {
  id?: string;
  slot: BannerSlot | "";
  title: string;
  imageUrl: string;
  linkUrl: string;
  sortOrder: number;
  isActive: boolean;
};

const emptyForm: BannerFormState = {
  slot: "",
  title: "",
  imageUrl: "",
  linkUrl: "",
  sortOrder: 0,
  isActive: true,
};

const ACCEPTED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

const MAX_IMAGE_SIZE = 25 * 1024 * 1024;

const HOME_BANNER_SLOTS = [
  {
    value: "mainbanner",
    label: "Main Banner",
    hint: "Hero left large banner",
    ratio: "Recommended ratio: 16:9 or close wide landscape",
    suggestedSize: "Suggested size: 1600 × 900 px",
  },
  {
    value: "subbanner1",
    label: "Sub Banner 1",
    hint: "Hero right top banner",
    ratio: "Recommended ratio: 16:9 or close wide landscape",
    suggestedSize: "Suggested size: 1200 × 675 px",
  },
  {
    value: "subbanner2",
    label: "Sub Banner 2",
    hint: "Hero right bottom banner",
    ratio: "Recommended ratio: 16:9 or close wide landscape",
    suggestedSize: "Suggested size: 1200 × 675 px",
  },
] as const;

function isBannerSlot(value: unknown): value is BannerSlot {
  return HOME_BANNER_SLOTS.some((slot) => slot.value === value);
}

function getSlotLabel(slot: BannerSlot | null): string {
  return HOME_BANNER_SLOTS.find((item) => item.value === slot)?.label ?? "—";
}

function getSlotMeta(slot: BannerSlot | "" | null) {
  return HOME_BANNER_SLOTS.find((item) => item.value === slot) ?? null;
}

function isValidAbsoluteUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function isValidBannerImageUrl(value: string): boolean {
  const v = value.trim();
  return v.startsWith("/uploads/") || isValidAbsoluteUrl(v);
}

function isValidLinkUrlMaybeEmpty(value: string): boolean {
  const v = value.trim();
  if (!v) return true;
  if (v.startsWith("/")) return true;
  return isValidAbsoluteUrl(v);
}

function validateBannerImageFile(file: File): string | null {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    return "Only PNG, JPG, JPEG, and WEBP images are allowed.";
  }

  if (file.size > MAX_IMAGE_SIZE) {
    return "Image must be 25MB or less.";
  }

  return null;
}

function safeString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function safeBoolean(value: unknown, fallback = false): boolean {
  return typeof value === "boolean" ? value : fallback;
}

function safeNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function parseBannersResponse(input: unknown): BannersResponse {
  const obj = input as { banners?: unknown };
  const raw = Array.isArray(obj?.banners) ? obj.banners : [];

  const banners: Banner[] = raw
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      slot: isBannerSlot(item.slot) ? item.slot : null,
      title: typeof item.title === "string" ? item.title : null,
      imageUrl: safeString(item.imageUrl),
      linkUrl: typeof item.linkUrl === "string" ? item.linkUrl : null,
      sortOrder: safeNumber(item.sortOrder, 0),
      isActive: safeBoolean(item.isActive, false),
      createdAt: safeString(item.createdAt),
    }))
    .filter((banner) => banner.id && banner.imageUrl);

  return { banners };
}

async function uploadBannerImage(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);

  const response = await fetch("/api/upload/banner-image", {
    method: "POST",
    body: fd,
  });

  const data: UploadResponse = await response
    .json()
    .catch(() => ({}) as UploadResponse);

  if (!response.ok) {
    throw new Error(data.error || "Upload failed");
  }

  if (!data.url) {
    throw new Error("Upload failed: missing image URL");
  }

  return data.url;
}

export default function AdminBannersPage() {
  const [items, setItems] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<BannerFormState>(emptyForm);
  const [query, setQuery] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  const fileRef = useRef<HTMLInputElement | null>(null);

  const { toast } = useToast();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;

    return items.filter((banner) => {
      const title = (banner.title ?? "").toLowerCase();
      const link = (banner.linkUrl ?? "").toLowerCase();
      const image = banner.imageUrl.toLowerCase();
      const slot = (banner.slot ?? "").toLowerCase();
      return (
        title.includes(q) ||
        link.includes(q) ||
        image.includes(q) ||
        slot.includes(q)
      );
    });
  }, [items, query]);

  const usedSlots = useMemo(() => {
    return new Set(
      items
        .map((item) => item.slot)
        .filter((slot): slot is BannerSlot => !!slot),
    );
  }, [items]);

  const bannerCount = items.length;
  const canAddMore = bannerCount < 3;
  const currentSlotMeta = getSlotMeta(form.slot);

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/banners", { cache: "no-store" });
      const json: unknown = await response.json();
      const parsed = parseBannersResponse(json);

      const heroOnly = parsed.banners.filter(
        (banner) =>
          banner.slot === "mainbanner" ||
          banner.slot === "subbanner1" ||
          banner.slot === "subbanner2",
      );

      setItems(heroOnly);
    } catch {
      setItems([]);
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not load banners.",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void load();
  }, [load]);

  const startAdd = (): void => {
    if (!canAddMore) {
      toast({
        variant: "error",
        title: "Limit reached",
        description: "You can add only 3 hero banners.",
      });
      return;
    }

    const firstAvailableSlot =
      HOME_BANNER_SLOTS.find((slot) => !usedSlots.has(slot.value))?.value || "";

    setForm({
      ...emptyForm,
      slot: firstAvailableSlot,
    });
    setFormError(null);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const startEdit = (banner: Banner): void => {
    setForm({
      id: banner.id,
      slot: banner.slot ?? "",
      title: banner.title ?? "",
      imageUrl: banner.imageUrl ?? "",
      linkUrl: banner.linkUrl ?? "",
      sortOrder: banner.sortOrder ?? 0,
      isActive: !!banner.isActive,
    });
    setFormError(null);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const closeForm = (): void => {
    setShowForm(false);
    setForm(emptyForm);
    setFormError(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const validate = (): string | null => {
    if (!form.slot) return "Banner slot is required.";
    if (!form.imageUrl.trim()) return "Banner image is required.";

    if (!isValidBannerImageUrl(form.imageUrl)) {
      return "Banner image URL is invalid.";
    }

    if (!isValidLinkUrlMaybeEmpty(form.linkUrl)) {
      return "Link URL is invalid.";
    }

    if (!Number.isFinite(form.sortOrder) || form.sortOrder < 0) {
      return "Sort order must be 0 or more.";
    }

    const slotAlreadyUsed = items.some(
      (item) => item.slot === form.slot && item.id !== form.id,
    );

    if (slotAlreadyUsed) {
      return "This homepage slot is already used. Please choose another slot.";
    }

    if (!form.id && items.length >= 3) {
      return "Only 3 hero banners are allowed.";
    }

    return null;
  };

  const save = async (): Promise<void> => {
    const err = validate();
    if (err) {
      setFormError(err);
      return;
    }

    setSaving(true);
    setFormError(null);

    try {
      const payload = {
        title: form.title.trim() ? form.title.trim() : null,
        slot: form.slot,
        imageUrl: form.imageUrl.trim(),
        linkUrl: form.linkUrl.trim() ? form.linkUrl.trim() : null,
        sortOrder: Number(form.sortOrder) || 0,
        isActive: !!form.isActive,
      };

      const response = await fetch("/api/admin/banners", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form.id ? { id: form.id, ...payload } : payload),
      });

      const json = await response
        .json()
        .catch(() => ({}) as { message?: string });

      if (!response.ok) {
        throw new Error(json?.message || "Save failed");
      }

      toast({
        title: form.id ? "Updated" : "Created",
        description: form.id
          ? "Banner updated successfully."
          : "Banner created successfully.",
      });

      await load();
      closeForm();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Banner save failed";
      setFormError(message);
      toast({
        variant: "error",
        title: "Save failed",
        description: message,
      });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string): Promise<void> => {
    const ok = confirm("Delete this banner?");
    if (!ok) return;

    setSaving(true);
    try {
      const response = await fetch(
        `/api/admin/banners?id=${encodeURIComponent(id)}`,
        { method: "DELETE" },
      );

      const json = await response
        .json()
        .catch(() => ({}) as { message?: string });

      if (!response.ok) {
        throw new Error(json?.message || "Delete failed");
      }

      toast({
        title: "Deleted",
        description: "Banner deleted successfully.",
      });

      await load();
      if (form.id === id) closeForm();
    } catch (error) {
      toast({
        variant: "error",
        title: "Delete failed",
        description:
          error instanceof Error ? error.message : "Banner delete failed",
      });
    } finally {
      setSaving(false);
    }
  };

  const quickToggle = async (banner: Banner): Promise<void> => {
    setSaving(true);
    try {
      const response = await fetch("/api/admin/banners", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: banner.id,
          isActive: !banner.isActive,
        }),
      });

      const json = await response
        .json()
        .catch(() => ({}) as { message?: string });

      if (!response.ok) {
        throw new Error(json?.message || "Toggle failed");
      }

      await load();
    } catch (error) {
      toast({
        variant: "error",
        title: "Toggle failed",
        description:
          error instanceof Error ? error.message : "Could not update banner",
      });
    } finally {
      setSaving(false);
    }
  };

  const onPickFile = async (file: File): Promise<void> => {
    setFormError(null);

    const error = validateBannerImageFile(file);
    if (error) {
      setFormError(error);
      return;
    }

    setUploading(true);
    try {
      const imageUrl = await uploadBannerImage(file);
      setForm((prev) => ({ ...prev, imageUrl }));
      toast({
        title: "Uploaded",
        description: "Banner image uploaded successfully.",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Upload failed";
      setFormError(message);
      toast({
        variant: "error",
        title: "Upload failed",
        description: message,
      });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="grid gap-4 px-0 sm:px-1">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div className="min-w-0">
          <div className="text-lg font-semibold">Hero Banners</div>
          <div className="text-sm leading-6 text-black/60">
            Homepage hero section-এর জন্য শুধু 3টি banner manage করুন: Main
            Banner, Sub Banner 1, Sub Banner 2.
          </div>
        </div>

        <div className="flex w-full flex-col gap-2 sm:flex-row md:w-auto md:flex-wrap md:justify-end">
          <Input
            placeholder="Search banners..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full sm:flex-1 md:w-64 md:flex-none"
          />
          <div className="grid grid-cols-2 gap-2 sm:flex">
            <Button
              variant="secondary"
              onClick={() => void load()}
              disabled={loading || saving}
              className="w-full sm:w-auto"
            >
              Refresh
            </Button>
            <Button
              onClick={startAdd}
              disabled={saving || !canAddMore}
              className="w-full sm:w-auto"
            >
              Add Banner
            </Button>
          </div>
        </div>
      </div>

      <Card className="rounded-3xl p-4">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {HOME_BANNER_SLOTS.map((slot) => {
            const assigned = items.find((item) => item.slot === slot.value);

            return (
              <div
                key={slot.value}
                className="rounded-3xl border border-black/10 bg-white p-4"
              >
                <div className="text-sm font-semibold">{slot.label}</div>
                <div className="mt-1 text-xs text-black/60">{slot.hint}</div>
                <div className="mt-1 text-xs text-black/50">{slot.ratio}</div>
                <div className="mt-1 text-xs text-black/50">
                  {slot.suggestedSize}
                </div>
                <div className="mt-3 text-xs">
                  {assigned ? (
                    <span className="rounded-full bg-green-100 px-2 py-1 text-green-700">
                      Assigned
                    </span>
                  ) : (
                    <span className="rounded-full bg-amber-100 px-2 py-1 text-amber-700">
                      Empty
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 text-xs text-black/60">
          Total hero banners: {bannerCount}/3
        </div>
      </Card>

      {showForm ? (
        <Card className="rounded-3xl p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="min-w-0">
              <div className="text-sm font-semibold">
                {form.id ? "Edit Banner" : "New Banner"}
              </div>
              <div className="text-xs leading-6 text-black/60">
                এই banner homepage hero section-এ current design change না করে
                show হবে।
              </div>
            </div>

            <div className="grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto">
              {form.id ? (
                <Button
                  variant="danger"
                  onClick={() => void remove(form.id!)}
                  disabled={saving}
                  className="w-full sm:w-auto"
                >
                  Delete
                </Button>
              ) : null}
              <Button
                variant="secondary"
                onClick={closeForm}
                disabled={saving}
                className="w-full sm:w-auto"
              >
                Close
              </Button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            <div className="min-w-0">
              <div className="text-sm text-black/60">Homepage Slot *</div>
              <select
                value={form.slot}
                onChange={(e) =>
                  setForm({
                    ...form,
                    slot: isBannerSlot(e.target.value) ? e.target.value : "",
                  })
                }
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none backdrop-blur transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
              >
                <option value="">Select hero slot</option>
                {HOME_BANNER_SLOTS.map((slot) => {
                  const disabled = !!items.find(
                    (item) => item.slot === slot.value && item.id !== form.id,
                  );

                  return (
                    <option
                      key={slot.value}
                      value={slot.value}
                      disabled={disabled}
                    >
                      {slot.label}
                      {disabled ? " (Already used)" : ""}
                    </option>
                  );
                })}
              </select>
              <div className="mt-1 text-xs text-black/50">
                Assign a banner from 3 fixed slot
              </div>
            </div>

            <div className="min-w-0">
              <div className="text-sm text-black/60">Title</div>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Hearing Aid Offer"
              />
            </div>

            <div className="min-w-0">
              <div className="text-sm text-black/60">Link URL (optional)</div>
              <Input
                value={form.linkUrl}
                onChange={(e) => setForm({ ...form, linkUrl: e.target.value })}
                placeholder="/products অথবা https://..."
              />
            </div>

            <div className="rounded-2xl border border-black/10 bg-black/5 px-4 py-3">
              <div className="text-sm font-medium text-black/70">
                Selected slot details
              </div>
              {currentSlotMeta ? (
                <div className="mt-2 space-y-1 text-xs leading-5 text-black/60">
                  <div>{currentSlotMeta.hint}</div>
                  <div>{currentSlotMeta.ratio}</div>
                  <div>{currentSlotMeta.suggestedSize}</div>
                </div>
              ) : (
                <div className="mt-2 text-xs text-black/50">
                  Select a homepage slot to see recommended banner ratio.
                </div>
              )}
            </div>

            <div className="lg:col-span-2">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <div className="text-sm text-black/60">Banner Image *</div>
                  <div className="text-xs text-black/50">
                    png / jpg / jpeg / webp • max 25MB
                  </div>
                </div>

                <div className="w-full sm:w-auto">
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/png,image/jpeg,image/jpg,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) void onPickFile(file);
                    }}
                  />
                  <Button
                    variant="secondary"
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading || saving}
                    className="w-full sm:w-auto"
                  >
                    {uploading ? "Uploading..." : "Upload Image"}
                  </Button>
                </div>
              </div>

              <Input
                value={form.imageUrl}
                readOnly
                placeholder="Upload করলে local URL এখানে আসবে"
                className="mt-2"
              />

              <div className="mt-3 overflow-hidden rounded-2xl border border-black/10 bg-black/5">
                <div className="relative h-48 w-full sm:h-56 md:h-64 lg:h-85">
                  {form.imageUrl.trim() ? (
                    <Image
                      src={form.imageUrl.trim()}
                      alt="Banner preview"
                      fill
                      className="object-contain sm:object-cover"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 90vw, 900px"
                      priority
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center px-4 text-center text-sm text-black/50">
                      Preview
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-2 text-xs leading-5 text-black/50">
                মোবাইলে preview যেন crop হয়ে না যায়, তাই small screen-এ image
                contain mode ব্যবহার করা হয়েছে।
              </div>
            </div>

            <div>
              <div className="text-sm text-black/60">Sort order</div>
              <Input
                type="number"
                value={form.sortOrder}
                onChange={(e) =>
                  setForm({ ...form, sortOrder: Number(e.target.value) })
                }
                placeholder="0"
              />
            </div>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={form.isActive}
                  onChange={(e) =>
                    setForm({ ...form, isActive: e.target.checked })
                  }
                />
                Active
              </label>
            </div>
          </div>

          {formError ? (
            <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {formError}
            </div>
          ) : null}

          <div className="mt-4">
            <Button
              onClick={() => void save()}
              disabled={saving || uploading}
              className="w-full sm:w-auto"
            >
              {saving
                ? "Saving..."
                : form.id
                  ? "Update Banner"
                  : "Create Banner"}
            </Button>
          </div>
        </Card>
      ) : null}

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm font-semibold">Hero Banners</div>
          <div className="text-xs text-black/60">
            {loading ? "Loading..." : `${filtered.length} items`}
          </div>
        </div>

        <div className="grid gap-3 lg:grid-cols-2">
          {filtered.map((banner) => (
            <div
              key={banner.id}
              className="rounded-3xl border border-black/10 bg-white p-3 shadow-sm"
            >
              <div className="relative h-48 overflow-hidden rounded-2xl bg-black/5 sm:h-56">
                <Image
                  src={banner.imageUrl}
                  alt={banner.title ?? "Banner"}
                  fill
                  className="object-cover"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 480px"
                />

                <div className="absolute left-2 top-2 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-semibold text-black sm:left-3 sm:top-3 sm:px-3 sm:text-xs">
                  {banner.isActive ? "Active" : "Inactive"}
                </div>

                <div className="absolute right-2 top-2 max-w-[60%] truncate rounded-full bg-pink-600/90 px-2.5 py-1 text-[11px] font-semibold text-white sm:right-3 sm:top-3 sm:px-3 sm:text-xs">
                  {getSlotLabel(banner.slot)}
                </div>
              </div>

              <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">
                    {banner.title ?? "—"}
                  </div>
                  <div className="mt-1 text-xs leading-5 text-black/60 break-all sm:wrap-break-word">
                    Slot: {getSlotLabel(banner.slot)} • Sort: {banner.sortOrder}{" "}
                    • {banner.linkUrl ? banner.linkUrl : "No link"}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 sm:flex sm:shrink-0">
                  <Button
                    variant="secondary"
                    onClick={() => void quickToggle(banner)}
                    disabled={saving}
                    className="w-full sm:w-auto"
                  >
                    Toggle
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => startEdit(banner)}
                    disabled={saving}
                    className="w-full sm:w-auto"
                  >
                    Edit
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {!filtered.length && !loading ? (
          <div className="mt-6 rounded-3xl bg-black/5 p-6 text-sm leading-6 text-black/60">
            No hero banners found. Click <b>Add Banner</b> to create one of the
            3 homepage hero banners.
          </div>
        ) : null}
      </Card>
    </div>
  );
}
