"use client";

import * as React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Scope = "PRODUCT" | "CATEGORY" | "SUBCATEGORY";

type ProductOption = {
  id: string;
  name: string;
  sku: string;
  price: number;
  offerPrice: number | null;
};

type CategoryOption = {
  id: string;
  name: string;
  slug: string;
  parent: {
    id: string;
    name: string;
    slug: string;
  } | null;
};

type DiscountRow = {
  id: string;
  scope: Scope;
  percentage: number;
  isActive: boolean;
  productId: string | null;
  categoryId: string | null;
  startsAt: string | null;
  endsAt: string | null;
  note: string | null;
  createdAt: string;
  product: {
    id: string;
    name: string;
    sku: string;
  } | null;
  category: {
    id: string;
    name: string;
    slug: string;
    parent: {
      id: string;
      name: string;
      slug: string;
    } | null;
  } | null;
};

type ApiResponse = {
  discounts: DiscountRow[];
  products: ProductOption[];
  categories: CategoryOption[];
};

type FormState = {
  id?: string;
  scope: Scope;
  percentage: string;
  productId: string;
  categoryId: string;
  startsAt: string;
  endsAt: string;
  note: string;
  isActive: boolean;
};

const emptyForm: FormState = {
  scope: "PRODUCT",
  percentage: "",
  productId: "",
  categoryId: "",
  startsAt: "",
  endsAt: "",
  note: "",
  isActive: true,
};

function formatTarget(item: DiscountRow) {
  if (item.scope === "PRODUCT") {
    return item.product ? `${item.product.name} (${item.product.sku})` : "—";
  }

  if (!item.category) return "—";

  if (item.category.parent) {
    return `${item.category.parent.name} → ${item.category.name}`;
  }

  return item.category.name;
}

function normalizeText(value: string) {
  return value.trim().toLowerCase();
}

export default function AdminDiscountsPage() {
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [items, setItems] = React.useState<DiscountRow[]>([]);
  const [products, setProducts] = React.useState<ProductOption[]>([]);
  const [categories, setCategories] = React.useState<CategoryOption[]>([]);
  const [form, setForm] = React.useState<FormState>(emptyForm);
  const [error, setError] = React.useState<string | null>(null);

  const [productSearch, setProductSearch] = React.useState("");
  const [categorySearch, setCategorySearch] = React.useState("");
  const [tableSearch, setTableSearch] = React.useState("");

  async function load() {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/admin/discounts", { cache: "no-store" });
      const data: ApiResponse = await res.json();

      if (!res.ok) {
        throw new Error("Failed to load discounts");
      }

      setItems(data.discounts ?? []);
      setProducts(data.products ?? []);
      setCategories(data.categories ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }

  React.useEffect(() => {
    void load();
  }, []);

  const filteredProducts = React.useMemo(() => {
    const q = normalizeText(productSearch);
    if (!q) return products;

    return products.filter((item) => {
      const hay = `${item.name} ${item.sku}`.toLowerCase();
      return hay.includes(q);
    });
  }, [products, productSearch]);

  const filteredCategories = React.useMemo(() => {
    const q = normalizeText(categorySearch);
    if (!q) return categories;

    return categories.filter((item) => {
      const hay = `${item.name} ${item.slug} ${item.parent?.name ?? ""} ${item.parent?.slug ?? ""}`.toLowerCase();
      return hay.includes(q);
    });
  }, [categories, categorySearch]);

  const filteredDiscounts = React.useMemo(() => {
    const q = normalizeText(tableSearch);
    if (!q) return items;

    return items.filter((item) => {
      const target = formatTarget(item).toLowerCase();
      const note = (item.note ?? "").toLowerCase();
      const scope = item.scope.toLowerCase();
      const pct = String(item.percentage);
      const status = item.isActive ? "active" : "inactive";

      return (
        target.includes(q) ||
        note.includes(q) ||
        scope.includes(q) ||
        pct.includes(q) ||
        status.includes(q)
      );
    });
  }, [items, tableSearch]);

  function resetForm() {
    setForm(emptyForm);
    setProductSearch("");
    setCategorySearch("");
  }

  function startEdit(item: DiscountRow) {
    setForm({
      id: item.id,
      scope: item.scope,
      percentage: String(item.percentage),
      productId: item.productId ?? "",
      categoryId: item.categoryId ?? "",
      startsAt: item.startsAt ? item.startsAt.slice(0, 16) : "",
      endsAt: item.endsAt ? item.endsAt.slice(0, 16) : "",
      note: item.note ?? "",
      isActive: item.isActive,
    });

    if (item.product) {
      setProductSearch(`${item.product.name} (${item.product.sku})`);
    } else {
      setProductSearch("");
    }

    if (item.category) {
      setCategorySearch(
        item.category.parent
          ? `${item.category.parent.name} → ${item.category.name}`
          : item.category.name,
      );
    } else {
      setCategorySearch("");
    }

    setError(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      const payload = {
        scope: form.scope,
        percentage: Number(form.percentage),
        productId: form.scope === "PRODUCT" ? form.productId : null,
        categoryId: form.scope === "PRODUCT" ? null : form.categoryId,
        startsAt: form.startsAt || null,
        endsAt: form.endsAt || null,
        note: form.note || null,
        isActive: form.isActive,
      };

      const res = await fetch(
        form.id ? `/api/admin/discounts/${form.id}` : "/api/admin/discounts",
        {
          method: form.id ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
      );

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data?.message || "Save failed");
      }

      resetForm();
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    const yes = window.confirm("এই discount delete করতে চান?");
    if (!yes) return;

    try {
      const res = await fetch(`/api/admin/discounts/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        throw new Error("Delete failed");
      }

      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    }
  }

  return (
    <div className="space-y-6">
      <div className="px-4">
        <h1 className="text-2xl font-semibold text-slate-900">
          Product Discounts
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Product, category, অথবা subcategory level discount manage করুন।
        </p>
      </div>

      <Card className="rounded-3xl border border-slate-200 p-5 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="space-y-1">
              <label className="text-sm font-medium">Discount type</label>
              <select
                className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none"
                value={form.scope}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    scope: e.target.value as Scope,
                    productId: "",
                    categoryId: "",
                  }))
                }
              >
                <option value="PRODUCT">Specific Product</option>
                <option value="CATEGORY">Parent Category</option>
                <option value="SUBCATEGORY">Subcategory</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Discount %</label>
              <Input
                type="number"
                min={1}
                max={100}
                value={form.percentage}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, percentage: e.target.value }))
                }
                placeholder="e.g. 10"
              />
            </div>

            {form.scope === "PRODUCT" ? (
              <div className="space-y-1 xl:col-span-2">
                <label className="text-sm font-medium">Product search</label>
                <Input
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Search by product name or SKU"
                />
              </div>
            ) : (
              <div className="space-y-1 xl:col-span-2">
                <label className="text-sm font-medium">
                  {form.scope === "CATEGORY"
                    ? "Category search"
                    : "Subcategory search"}
                </label>
                <Input
                  value={categorySearch}
                  onChange={(e) => setCategorySearch(e.target.value)}
                  placeholder="Search by category, subcategory or slug"
                />
              </div>
            )}
          </div>

          {form.scope === "PRODUCT" ? (
            <div className="space-y-1">
              <label className="text-sm font-medium">
                Product{" "}
                <span className="text-slate-400">
                  ({filteredProducts.length} found)
                </span>
              </label>
              <select
                className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none"
                value={form.productId}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, productId: e.target.value }))
                }
              >
                <option value="">Select product</option>
                {filteredProducts.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} ({item.sku})
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="space-y-1">
              <label className="text-sm font-medium">
                {form.scope === "CATEGORY" ? "Category" : "Subcategory"}{" "}
                <span className="text-slate-400">
                  ({filteredCategories.length} found)
                </span>
              </label>
              <select
                className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none"
                value={form.categoryId}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, categoryId: e.target.value }))
                }
              >
                <option value="">Select category</option>
                {filteredCategories.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.parent
                      ? `${item.parent.name} → ${item.name}`
                      : item.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="space-y-1">
              <label className="text-sm font-medium">Starts at</label>
              <Input
                type="datetime-local"
                value={form.startsAt}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, startsAt: e.target.value }))
                }
              />
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Ends at</label>
              <Input
                type="datetime-local"
                value={form.endsAt}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, endsAt: e.target.value }))
                }
              />
            </div>

            <div className="space-y-1 xl:col-span-2">
              <label className="text-sm font-medium">Note</label>
              <Input
                value={form.note}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, note: e.target.value }))
                }
                placeholder="Optional note"
              />
            </div>
          </div>

          <label className="inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, isActive: e.target.checked }))
              }
            />
            Active
          </label>

          {error ? (
            <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}

          <div className="flex flex-wrap gap-3">
            <Button
              type="submit"
              disabled={saving}
              className="rounded-2xl bg-pink-600 text-white hover:bg-pink-700"
            >
              {saving ? "Saving..." : form.id ? "Update Discount" : "Add Discount"}
            </Button>

            <Button
              type="button"
              variant="secondary"
              onClick={resetForm}
              className="rounded-2xl"
            >
              Reset
            </Button>
          </div>
        </form>
      </Card>

      <Card className="rounded-3xl border border-slate-200 p-5 shadow-sm">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="text-lg font-semibold text-slate-900">
              Existing Discounts
            </div>
            <div className="text-sm text-slate-500">
              মোট {filteredDiscounts.length} টি discount দেখানো হচ্ছে
            </div>
          </div>

          <div className="w-full sm:max-w-sm">
            <label className="mb-1 block text-sm font-medium">
              Search discounts
            </label>
            <Input
              value={tableSearch}
              onChange={(e) => setTableSearch(e.target.value)}
              placeholder="Search by target, note, scope or percentage"
            />
          </div>
        </div>

        {loading ? (
          <div className="text-sm text-slate-500">Loading...</div>
        ) : !filteredDiscounts.length ? (
          <div className="text-sm text-slate-500">
            {tableSearch ? "No matching discounts found." : "No discounts found."}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="border-b text-slate-500">
                  <th className="px-3 py-3">Type</th>
                  <th className="px-3 py-3">Target</th>
                  <th className="px-3 py-3">Discount</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">Period</th>
                  <th className="px-3 py-3">Note</th>
                  <th className="px-3 py-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredDiscounts.map((item) => (
                  <tr key={item.id} className="border-b last:border-b-0">
                    <td className="px-3 py-3">{item.scope}</td>
                    <td className="px-3 py-3">{formatTarget(item)}</td>
                    <td className="px-3 py-3">{item.percentage}%</td>
                    <td className="px-3 py-3">
                      {item.isActive ? "Active" : "Inactive"}
                    </td>
                    <td className="px-3 py-3">
                      <div className="space-y-1 text-xs text-slate-500">
                        <div>From: {item.startsAt ? item.startsAt : "—"}</div>
                        <div>To: {item.endsAt ? item.endsAt : "—"}</div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="max-w-55 truncate text-xs text-slate-500">
                        {item.note || "—"}
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="secondary"
                          className="rounded-xl"
                          onClick={() => startEdit(item)}
                        >
                          Edit
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          className="rounded-xl"
                          onClick={() => handleDelete(item.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}