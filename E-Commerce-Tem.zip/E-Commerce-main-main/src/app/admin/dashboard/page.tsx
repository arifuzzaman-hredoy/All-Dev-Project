import AdminDashboardClient from "@/components/admin/admin-dashboard-client";

export default function AdminDashboardRoutePage() {
  return <AdminDashboardClient />;
}
