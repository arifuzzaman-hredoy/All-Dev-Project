import AdminReviewsClient from "@/components/admin/reviews/admin-reviews-client";

export default function AdminReviewPage() {
  return <AdminReviewsClient />;
}
