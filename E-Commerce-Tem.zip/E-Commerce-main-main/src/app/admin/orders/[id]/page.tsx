import AdminOrderDetailsClient from "@/components/admin/orders/admin-order-details-client";

export default function AdminOrderDetailsPage() {
  return <AdminOrderDetailsClient />;
}