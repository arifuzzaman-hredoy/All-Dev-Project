"use client";

import * as React from "react";
import Image from "next/image";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type RequestStatus = "PENDING" | "CONTACTED" | "FULFILLED" | "REJECTED";

type ProductRequestItem = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  message: string | null;
  adminNote: string | null;
  status: RequestStatus;
  createdAt: string;
  product: {
    id: string;
    name: string;
    slug: string;
    sku: string;
    stock: number;
    images: { url: string }[];
  };
};

const statuses: RequestStatus[] = [
  "PENDING",
  "CONTACTED",
  "FULFILLED",
  "REJECTED",
];

export default function AdminProductRequestsPage() {
  const [items, setItems] = React.useState<ProductRequestItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [savingId, setSavingId] = React.useState<string | null>(null);
  const [statusFilter, setStatusFilter] = React.useState<string>("");
  const [q, setQ] = React.useState("");

  async function load() {
    setLoading(true);

    try {
      const url = statusFilter
        ? `/api/admin/product-requests?status=${statusFilter}`
        : "/api/admin/product-requests";

      const res = await fetch(url, { cache: "no-store" });
      const data = await res.json().catch(() => []);

      if (!res.ok) {
        setItems([]);
        return;
      }

      setItems(Array.isArray(data) ? data : []);
    } finally {
      setLoading(false);
    }
  }

  React.useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  const filtered = React.useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return items;

    return items.filter((item) => {
      const hay = [
        item.name,
        item.phone,
        item.email ?? "",
        item.product.name,
        item.product.sku,
        item.message ?? "",
        item.adminNote ?? "",
        item.status,
      ]
        .join(" ")
        .toLowerCase();

      return hay.includes(needle);
    });
  }, [items, q]);

  async function updateRequest(
    id: string,
    payload: { status: RequestStatus; adminNote: string | null },
  ) {
    setSavingId(id);

    try {
      const res = await fetch(`/api/admin/product-requests/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) return;

      await load();
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="px-4">
        <h1 className="text-2xl font-semibold text-slate-900">
          Product Requests
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Stock out product request list এখান থেকে manage করুন।
        </p>
      </div>

      <Card className="rounded-3xl border border-slate-200 p-5 shadow-sm">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1 md:col-span-2">
            <label className="text-sm font-medium">Search</label>
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by product, customer, phone, email"
            />
          </div>

          <div className="space-y-1">
            <label className="text-sm font-medium">Status</label>
            <select
              className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">All</option>
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {loading ? (
        <Card className="rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div className="text-sm text-slate-500">Loading...</div>
        </Card>
      ) : !filtered.length ? (
        <Card className="rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div className="text-sm text-slate-500">
            No product requests found.
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {filtered.map((item) => (
            <Card
              key={item.id}
              className="rounded-3xl border border-slate-200 p-5 shadow-sm"
            >
              <div className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="relative h-20 w-20 overflow-hidden rounded-2xl bg-slate-100">
                      {item.product.images?.[0]?.url ? (
                        <Image
                          src={item.product.images[0].url}
                          alt={item.product.name}
                          fill
                          className="object-cover"
                        />
                      ) : null}
                    </div>

                    <div className="min-w-0">
                      <div className="text-lg font-semibold text-slate-900">
                        {item.product.name}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        SKU: {item.product.sku}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        Current stock: {item.product.stock}
                      </div>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm">
                    <div>
                      <span className="font-medium text-slate-800">
                        Customer:
                      </span>{" "}
                      {item.name}
                    </div>
                    <div className="mt-1">
                      <span className="font-medium text-slate-800">Phone:</span>{" "}
                      {item.phone}
                    </div>
                    {item.email ? (
                      <div className="mt-1">
                        <span className="font-medium text-slate-800">
                          Email:
                        </span>{" "}
                        {item.email}
                      </div>
                    ) : null}
                    {item.message ? (
                      <div className="mt-3">
                        <span className="font-medium text-slate-800">
                          Message:
                        </span>
                        <div className="mt-1 text-slate-600">
                          {item.message}
                        </div>
                      </div>
                    ) : null}
                  </div>
                </div>

                <RequestEditor
                  item={item}
                  saving={savingId === item.id}
                  onSave={updateRequest}
                />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function RequestEditor({
  item,
  saving,
  onSave,
}: {
  item: ProductRequestItem;
  saving: boolean;
  onSave: (
    id: string,
    payload: { status: RequestStatus; adminNote: string | null },
  ) => Promise<void>;
}) {
  const [status, setStatus] = React.useState<RequestStatus>(item.status);
  const [adminNote, setAdminNote] = React.useState(item.adminNote ?? "");

  return (
    <div className="space-y-4 rounded-2xl border border-slate-200 p-4">
      <div>
        <div className="text-sm font-medium text-slate-800">Request Status</div>
        <div className="mt-1 text-xs text-slate-500">
          Submitted: {new Date(item.createdAt).toLocaleString()}
        </div>
      </div>

      <div className="space-y-1">
        <label className="text-sm font-medium">Status</label>
        <select
          className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none"
          value={status}
          onChange={(e) => setStatus(e.target.value as RequestStatus)}
        >
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-1">
        <label className="text-sm font-medium">Admin Note</label>
        <textarea
          className="min-h-28 w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none"
          value={adminNote}
          onChange={(e) => setAdminNote(e.target.value)}
          placeholder="Optional internal note"
        />
      </div>

      <Button
        type="button"
        disabled={saving}
        onClick={() =>
          void onSave(item.id, {
            status,
            adminNote: adminNote.trim() || null,
          })
        }
        className="rounded-2xl bg-pink-600 text-white hover:bg-pink-700"
      >
        {saving ? "Saving..." : "Update Request"}
      </Button>
    </div>
  );
}
