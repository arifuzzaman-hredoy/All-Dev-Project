import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import WishlistPageClient from "@/components/wishlist/wishlist-page-client";

export default async function WishlistPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login?next=/wishlist");
  return <WishlistPageClient />;
}