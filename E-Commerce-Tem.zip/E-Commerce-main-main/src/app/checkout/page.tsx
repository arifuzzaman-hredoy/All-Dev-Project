import CheckoutClient from "@/components/checkout/checkout-client";

type CheckoutPageProps = {
  searchParams?:
    | Promise<Record<string, string | string[] | undefined>>
    | Record<string, string | string[] | undefined>;
};

function pickFirst(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

export default async function CheckoutPage({
  searchParams,
}: CheckoutPageProps) {
  const resolved =
    searchParams instanceof Promise ? await searchParams : (searchParams ?? {});

  return (
    <CheckoutClient
      initialSearchParams={{
        buyNow: pickFirst(resolved.buyNow),
        productId: pickFirst(resolved.productId),
        variantId: pickFirst(resolved.variantId),
        qty: pickFirst(resolved.qty),
      }}
    />
  );
}
