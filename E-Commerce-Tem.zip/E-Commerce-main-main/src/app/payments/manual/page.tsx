"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { clearAppliedCoupon } from "@/lib/coupon-client";

type Provider = {
  code: "BKASH" | "NAGAD" | "ROCKET";
  label: string;
  number: string;
  logoUrl?: string;
};

type VerifyResponse = {
  ok: true;
  total: number;
  providers: Provider[];
  checkout: {
    name: string;
    phone: string;
    city: string;
    area: string;
  };
};

function getErrorMessage(input: unknown, fallback: string): string {
  const row =
    input && typeof input === "object"
      ? (input as Record<string, unknown>)
      : null;

  if (!row) return fallback;
  if (typeof row.error === "string" && row.error.trim()) return row.error;
  if (typeof row.message === "string" && row.message.trim()) return row.message;

  return fallback;
}

async function clearClientCartState(): Promise<void> {
  try {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "clear" }),
    });
  } catch {
    // ignore
  }

  clearAppliedCoupon();

  try {
    window.dispatchEvent(new Event("rhc_cart_updated"));
  } catch {
    // ignore
  }
}

function ManualPaymentContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token") || "";
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [data, setData] = useState<VerifyResponse | null>(null);
  const [error, setError] = useState("");

  const [provider, setProvider] = useState<Provider["code"] | "">("");
  const [senderPhone, setSenderPhone] = useState("");
  const [transactionId, setTransactionId] = useState("");

  useEffect(() => {
    const load = async () => {
      if (!token) {
        setError("Missing payment token");
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const query = new URLSearchParams({ token });
        const res = await fetch(
          `/api/payments/manual/verify?${query.toString()}`,
          {
            cache: "no-store",
          },
        );
        const json: unknown = await res.json().catch(() => null);

        if (!res.ok) {
          setError(getErrorMessage(json, "Failed to load payment details"));
          setData(null);
          return;
        }

        const parsed = json as VerifyResponse;
        setData(parsed);
        setProvider(parsed.providers[0]?.code || "");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [token]);

  const selectedProvider = useMemo(() => {
    return data?.providers.find((item) => item.code === provider) || null;
  }, [data, provider]);

  const submit = async () => {
    if (!data) return;

    if (!provider || !senderPhone.trim() || !transactionId.trim()) {
      setError("Please complete all required payment fields");
      return;
    }

    setSubmitting(true);
    setError("");

    try {
      const res = await fetch("/api/payments/manual/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token,
          provider,
          senderPhone: senderPhone.trim(),
          transactionId: transactionId.trim(),
          amount: data.total,
        }),
      });

      const json: unknown = await res.json().catch(() => null);

      if (!res.ok) {
        setError(getErrorMessage(json, "Failed to submit manual payment"));
        return;
      }

      const orderId =
        json &&
        typeof json === "object" &&
        typeof (json as Record<string, unknown>).orderId === "string"
          ? ((json as Record<string, unknown>).orderId as string)
          : "";

      if (!orderId) {
        setError("Order was created but order ID was missing");
        return;
      }

      await clearClientCartState();
      router.replace(
        `/orders/${orderId}?phone=${encodeURIComponent(data.checkout.phone)}`,
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-6">
        <div className="text-2xl font-semibold">Manual Payment</div>
        <div className="text-sm text-black/60">
          Select a payment channel, send the exact amount, then submit your
          payment details.
        </div>
      </div>

      {loading ? (
        <Card className="rounded-3xl p-6">Loading payment details…</Card>
      ) : error && !data ? (
        <Card className="rounded-3xl p-6 text-red-600">{error}</Card>
      ) : data ? (
        <div className="grid gap-4 md:grid-cols-[1fr_360px]">
          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Payment Information</div>

            <div className="mt-4 grid gap-3">
              <div>
                <div className="mb-1 text-sm text-black/60">Choose Channel</div>
                <div className="grid gap-2">
                  {data.providers.map((item) => (
                    <label
                      key={item.code}
                      className="flex cursor-pointer items-center gap-3 rounded-2xl border border-black/10 p-3"
                    >
                      <input
                        type="radio"
                        name="manual-provider"
                        checked={provider === item.code}
                        onChange={() => setProvider(item.code)}
                      />
                      <div>
                        {item.logoUrl ? (
                          <div className="flex items-center gap-2">
                            <Image
                              src={item.logoUrl}
                              alt={item.label}
                              width={88}
                              height={28}
                              className="object-contain"
                            />
                            <div className="text-xs text-black/60">
                              {item.number}
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="text-sm font-medium">
                              {item.label}
                            </div>
                            <div className="text-xs text-black/60">
                              {item.number}
                            </div>
                          </>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {selectedProvider ? (
                <div className="rounded-2xl border border-black/10 bg-black/[0.03] p-4">
                  <div className="text-3xl font-semibold text-black/80 text-center">
                    Send your bill via:{" "}
                    <div className="flex items-center justify-center gap-4 rounded-lg bg-white/80 px-4 py-2">
                      <Image
                        src={selectedProvider.logoUrl || ""}
                        alt={selectedProvider.label}
                        width={88}
                        height={28}
                        className="object-contain"
                      />
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between rounded-xl bg-white px-4 py-3 ring-1 ring-black/10">
                    {/* LEFT */}
                    <div>
                      <div className="text-[11px] font-medium text-gray-500">
                        Payment Number
                      </div>

                      <div className="mt-1 flex items-center gap-2">
                        <span className="text-lg font-semibold text-gray-900 tracking-wide">
                          {selectedProvider.number}
                        </span>

                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(
                              selectedProvider.number,
                            );
                            setCopied(true);
                            setTimeout(() => setCopied(false), 2000);
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded transition ${
                            copied
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                          }`}
                        >
                          {copied ? "Copied ✓" : "Copy"}
                        </button>
                      </div>
                    </div>

                    {/* RIGHT INDICATOR */}
                    <div className="text-[15px] font-medium text-pink-600 bg-pink-50 px-2.5 py-1 rounded-md">
                      Send Money
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-sm text-black/60">
                      Amount to send
                    </span>
                    <span className="text-lg font-bold text-black">
                      ৳ {data.total}
                    </span>
                  </div>
                </div>
              ) : null}

              <Input
                value={senderPhone}
                onChange={(e) => setSenderPhone(e.target.value)}
                placeholder="Your payment sender number *"
              />

              <Input value={String(data.total)} readOnly placeholder="Amount" />

              <Input
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                placeholder="Transaction ID *"
              />

              {error ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {error}
                </div>
              ) : null}

              <Button
                className="w-full bg-pink-600 hover:bg-pink-700"
                onClick={() => void submit()}
                disabled={submitting}
              >
                {submitting ? "Submitting..." : "Submit Manual Payment"}
              </Button>
              <p className="text-xs text-shadow-gray-600">
                By Submitting your order will be placed. you will receive a sms
                after your payment is verified
              </p>
            </div>
          </Card>

          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Order Snapshot</div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-black/60">Customer</div>
                <div className="font-medium">{data.checkout.name}</div>
              </div>

              <div>
                <div className="text-xs text-black/60">Phone</div>
                <div className="font-medium">{data.checkout.phone}</div>
              </div>

              <div>
                <div className="text-xs text-black/60">District</div>
                <div className="font-medium">{data.checkout.city}</div>
              </div>

              <div>
                <div className="text-xs text-black/60">Police Station</div>
                <div className="font-medium">{data.checkout.area}</div>
              </div>

              <div className="border-t border-black/10 pt-3">
                <div className="text-xs text-black/60">Payable Total</div>
                <div className="text-xl font-bold">৳ {data.total}</div>
              </div>
            </div>
          </Card>
        </div>
      ) : null}
    </div>
  );
}

export default function ManualPaymentPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-3xl px-4 py-10">
          Loading payment details…
        </div>
      }
    >
      <ManualPaymentContent />
    </Suspense>
  );
}
