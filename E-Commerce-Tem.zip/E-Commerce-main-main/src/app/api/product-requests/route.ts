import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function isNonEmptyString(value: unknown): value is string {
    return typeof value === "string" && value.trim().length > 0;
}

function normalizeOptionalString(value: unknown): string | null {
    if (typeof value !== "string") return null;
    const v = value.trim();
    return v ? v : null;
}

export async function POST(req: NextRequest) {
    const body = await req.json().catch(() => null);

    const productId = isNonEmptyString(body?.productId) ? body.productId.trim() : "";
    const name = isNonEmptyString(body?.name) ? body.name.trim() : "";
    const phone = isNonEmptyString(body?.phone) ? body.phone.trim() : "";
    const email = normalizeOptionalString(body?.email);
    const message = normalizeOptionalString(body?.message);

    if (!productId) {
        return NextResponse.json(
            { error: "Product is required." },
            { status: 400 },
        );
    }

    if (!name) {
        return NextResponse.json(
            { error: "Name is required." },
            { status: 400 },
        );
    }

    if (!phone) {
        return NextResponse.json(
            { error: "Phone is required." },
            { status: 400 },
        );
    }

    const product = await prisma.product.findUnique({
        where: { id: productId },
        select: {
            id: true,
            name: true,
            isActive: true,
        },
    });

    if (!product || !product.isActive) {
        return NextResponse.json(
            { error: "Product not found." },
            { status: 404 },
        );
    }

    const created = await prisma.productRequest.create({
        data: {
            productId,
            name,
            phone,
            email,
            message,
        },
        select: {
            id: true,
            status: true,
            createdAt: true,
            product: {
                select: {
                    id: true,
                    name: true,
                },
            },
        },
    });

    return NextResponse.json(
        {
            ok: true,
            request: created,
            message: "Your request has been submitted successfully.",
        },
        { status: 201 },
    );
}