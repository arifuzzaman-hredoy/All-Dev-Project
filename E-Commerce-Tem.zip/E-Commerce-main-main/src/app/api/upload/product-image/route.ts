import { NextResponse } from "next/server";
import { uploadImageToLocalUploads } from "@/lib/local-uploads";

export const runtime = "nodejs";

type UploadResponse = { url: string } | { error: string };

export async function POST(
  req: Request,
): Promise<NextResponse<UploadResponse>> {
  try {
    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const url = await uploadImageToLocalUploads(file, "products");
    return NextResponse.json({ url }, { status: 201 });
  } catch (error) {
    console.error("Product image upload failed:", error);
    const message = error instanceof Error ? error.message : "Upload failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
