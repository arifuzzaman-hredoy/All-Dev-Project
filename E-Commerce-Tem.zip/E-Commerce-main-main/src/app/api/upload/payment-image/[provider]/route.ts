import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import {
  deleteLocalUploadByUrl,
  uploadImageToLocalUploads,
} from "@/lib/local-uploads";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type UploadResponse = { url: string } | { error: string };

const PROVIDER_FIELDS = {
  bkash: {
    label: "bKash",
    numberField: "manualBkashNumber",
    imageField: "manualBkashImageUrl",
  },
  nagad: {
    label: "Nagad",
    numberField: "manualNagadNumber",
    imageField: "manualNagadImageUrl",
  },
  rocket: {
    label: "Rocket",
    numberField: "manualRocketNumber",
    imageField: "manualRocketImageUrl",
  },
} as const;

type ProviderKey = keyof typeof PROVIDER_FIELDS;

async function getPreviousPaymentImageUrl(
  providerKey: ProviderKey,
): Promise<string> {
  if (providerKey === "bkash") {
    const previous = await prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: { manualBkashImageUrl: true },
    });

    return previous?.manualBkashImageUrl ?? "";
  }

  if (providerKey === "nagad") {
    const previous = await prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: { manualNagadImageUrl: true },
    });

    return previous?.manualNagadImageUrl ?? "";
  }

  const previous = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: { manualRocketImageUrl: true },
  });

  return previous?.manualRocketImageUrl ?? "";
}

async function savePaymentImageUrl(providerKey: ProviderKey, url: string) {
  if (providerKey === "bkash") {
    await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: { manualBkashImageUrl: url },
      create: { id: "default", manualBkashImageUrl: url },
    });
    return;
  }

  if (providerKey === "nagad") {
    await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: { manualNagadImageUrl: url },
      create: { id: "default", manualNagadImageUrl: url },
    });
    return;
  }

  await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: { manualRocketImageUrl: url },
    create: { id: "default", manualRocketImageUrl: url },
  });
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> | { provider: string } },
): Promise<NextResponse<UploadResponse>> {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const resolvedParams = params instanceof Promise ? await params : params;
  const providerKey = resolvedParams.provider.toLowerCase() as ProviderKey;
  const provider = PROVIDER_FIELDS[providerKey];

  if (!provider) {
    return NextResponse.json({ error: "Invalid provider" }, { status: 400 });
  }

  try {
    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const previousUrl = await getPreviousPaymentImageUrl(providerKey);

    const url = await uploadImageToLocalUploads(file, "payments", {
      preserveOriginal: true,
    });

    await savePaymentImageUrl(providerKey, url);

    if (previousUrl && previousUrl !== url) {
      await deleteLocalUploadByUrl(previousUrl);
    }

    return NextResponse.json({ url }, { status: 201 });
  } catch (error) {
    console.error(`${provider.label} image upload failed:`, error);

    const message = error instanceof Error ? error.message : "Upload failed";

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
