import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import {
  deleteLocalUploadByUrl,
  uploadImageToLocalUploads,
} from "@/lib/local-uploads";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type UploadResponse = { url: string } | { error: string };

export async function POST(
  req: NextRequest,
): Promise<NextResponse<UploadResponse>> {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const previous = await prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: { logoUrl: true },
    });

    const url = await uploadImageToLocalUploads(file, "logos", {
      preserveOriginal: true,
    });

    await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: { logoUrl: url },
      create: { id: "default", logoUrl: url },
    });

    if (previous?.logoUrl && previous.logoUrl !== url) {
      await deleteLocalUploadByUrl(previous.logoUrl);
    }

    return NextResponse.json({ url }, { status: 201 });
  } catch (error) {
    console.error("Logo image upload failed:", error);

    const message = error instanceof Error ? error.message : "Upload failed";

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
