import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import { uploadImageToLocalUploads } from "@/lib/local-uploads";

export const runtime = "nodejs";

type UploadResponse = { url: string } | { error: string };

export async function POST(
  req: NextRequest,
): Promise<NextResponse<UploadResponse>> {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const url = await uploadImageToLocalUploads(file, "categories");

    return NextResponse.json({ url }, { status: 201 });
  } catch (error) {
    console.error("Category image upload failed:", error);

    const message = error instanceof Error ? error.message : "Upload failed";

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
