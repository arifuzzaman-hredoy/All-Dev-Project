import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  DEFAULT_BANGLA_FONT,
  DEFAULT_SITE_FONT,
  resolveBanglaFont,
  resolveSiteFont,
} from "@/lib/site-fonts";

export const dynamic = "force-dynamic";

type Response = {
  ok: true;
  storeName: string;
  logoUrl: string;
  currency: string;
  siteFontFamily: string;
  banglaFontFamily: string;

  taxRate: number;
  shippingInsideDhaka: number;
  shippingRangpur: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  shippingDefaultCharge: number;
  shippingRules: unknown[];

  codEnabled: boolean;
  onlineEnabled: boolean;
  manualPaymentEnabled: boolean;
  manualBkashNumber: string;
  manualBkashImageUrl: string;
  manualNagadNumber: string;
  manualNagadImageUrl: string;
  manualRocketNumber: string;
  manualRocketImageUrl: string;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;

  returnRefundPolicy: string;
  aboutUs: string;
  privacyPolicy: string;
  termsConditions: string;
};

export async function GET(): Promise<NextResponse<Response>> {
  const s = await prisma.storeSettings.findUnique({
    where: { id: "default" },
  });

  return NextResponse.json({
    ok: true,
    storeName: s?.storeName ?? "NexoraMart",
    logoUrl: s?.logoUrl ?? "",
    currency: s?.currency ?? "BDT",
    siteFontFamily: resolveSiteFont(s?.siteFontFamily ?? DEFAULT_SITE_FONT)
      .value,
    banglaFontFamily: resolveBanglaFont(
      s?.banglaFontFamily ?? DEFAULT_BANGLA_FONT,
    ).value,

    taxRate: s?.taxRate ?? 0,
    shippingInsideDhaka: s?.shippingInsideDhaka ?? 0,
    shippingRangpur: s?.shippingRangpur ?? 0,
    shippingOutsideDhaka: s?.shippingOutsideDhaka ?? 0,
    shippingFreeOver: s?.shippingFreeOver ?? 0,
    shippingDefaultCharge: s?.shippingDefaultCharge ?? 0,
    shippingRules: Array.isArray(s?.shippingRules) ? s?.shippingRules : [],

    codEnabled: s?.codEnabled ?? true,
    onlineEnabled: s?.onlineEnabled ?? false,
    manualPaymentEnabled: s?.manualPaymentEnabled ?? false,
    manualBkashNumber: s?.manualBkashNumber ?? "",
    manualBkashImageUrl: s?.manualBkashImageUrl ?? "",
    manualNagadNumber: s?.manualNagadNumber ?? "",
    manualNagadImageUrl: s?.manualNagadImageUrl ?? "",
    manualRocketNumber: s?.manualRocketNumber ?? "",
    manualRocketImageUrl: s?.manualRocketImageUrl ?? "",
    lowStockThreshold: s?.lowStockThreshold ?? 5,

    facebookUrl: s?.facebookUrl ?? "",
    instagramUrl: s?.instagramUrl ?? "",
    youtubeUrl: s?.youtubeUrl ?? "",
    tiktokUrl: s?.tiktokUrl ?? "",
    whatsappUrl: s?.whatsappUrl ?? "",

    returnRefundPolicy: s?.returnRefundPolicy ?? "",
    aboutUs: s?.aboutUs ?? "",
    privacyPolicy: s?.privacyPolicy ?? "",
    termsConditions: s?.termsConditions ?? "",
  });
}
