import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { syncSteadfastOrderStatus } from "@/lib/services/steadfast-order-sync";

type Ctx = {
    params: Promise<{ id: string }> | { id: string };
};

export async function POST(_req: NextRequest, ctx: Ctx) {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const id = params.id;

    const order = await prisma.order.findFirst({
        where: {
            OR: [{ id }, { publicOrderId: id }],
            userId: session.user.id,
        },
        select: { id: true },
    });

    if (!order) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    try {
        const result = await syncSteadfastOrderStatus(order.id);

        if (!result.ok) {
            return NextResponse.json({ error: result.error }, { status: 404 });
        }

        return NextResponse.json(result);
    } catch (error) {
        return NextResponse.json(
            {
                error:
                    error instanceof Error
                        ? error.message
                        : "Failed to sync Steadfast status",
            },
            { status: 500 },
        );
    }
}