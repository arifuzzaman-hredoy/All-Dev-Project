import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { syncSteadfastOrderById } from "@/lib/couriers/steadfast-sync";

type TrackOrderItem = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  subtotal: number;
  discount: number;
  shipping: number;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  courierName: string | null;
  trackingId: string | null;
  itemsCount: number;
  itemsPreview: Array<{
    productName: string;
    qty: number;
    lineTotal: number;
  }>;
};

type SuccessResponse = {
  ok: true;
  mode: "id" | "phone";
  items: TrackOrderItem[];
};

type ErrorResponse = {
  ok: false;
  error: string;
};

function normalize(value: string): string {
  return value.trim();
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<SuccessResponse | ErrorResponse>> {
  const { searchParams } = new URL(req.url);

  const orderId = normalize(searchParams.get("orderId") || "");
  const phone = normalize(searchParams.get("phone") || "");

  if (!orderId && !phone) {
    return NextResponse.json(
      { ok: false, error: "Order ID or phone number is required" },
      { status: 400 },
    );
  }

  if (orderId) {
    const order = await prisma.order.findFirst({
      where: {
        OR: [{ id: orderId }, { publicOrderId: orderId }],
      },
      select: {
        id: true,
        publicOrderId: true,
        createdAt: true,
        name: true,
        phone: true,
        total: true,
        subtotal: true,
        discount: true,
        shipping: true,
        status: true,
        paymentMethod: true,
        paymentStatus: true,
        courierName: true,
        trackingId: true,
        items: {
          take: 3,
          orderBy: {
            createdAt: "asc",
          },
          select: {
            productName: true,
            qty: true,
            lineTotal: true,
          },
        },
        _count: {
          select: {
            items: true,
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json(
        { ok: false, error: "No order found with this ID" },
        { status: 404 },
      );
    }

    if (order.courierName === "Steadfast") {
      await syncSteadfastOrderById(order.id);
    }

    const freshOrder = await prisma.order.findUnique({
      where: { id: order.id },
      select: {
        id: true,
        publicOrderId: true,
        createdAt: true,
        name: true,
        phone: true,
        total: true,
        subtotal: true,
        discount: true,
        shipping: true,
        status: true,
        paymentMethod: true,
        paymentStatus: true,
        courierName: true,
        trackingId: true,
        items: {
          take: 3,
          orderBy: {
            createdAt: "asc",
          },
          select: {
            productName: true,
            qty: true,
            lineTotal: true,
          },
        },
        _count: {
          select: {
            items: true,
          },
        },
      },
    });

    if (!freshOrder) {
      return NextResponse.json(
        { ok: false, error: "No order found with this ID" },
        { status: 404 },
      );
    }

    return NextResponse.json({
      ok: true,
      mode: "id",
      items: [
        {
          id: freshOrder.id,
          publicOrderId: freshOrder.publicOrderId ?? null,
          createdAt: freshOrder.createdAt.toISOString(),
          name: freshOrder.name,
          phone: freshOrder.phone,
          total: freshOrder.total,
          subtotal: freshOrder.subtotal,
          discount: freshOrder.discount,
          shipping: freshOrder.shipping,
          status: freshOrder.status,
          paymentMethod: freshOrder.paymentMethod,
          paymentStatus: freshOrder.paymentStatus,
          courierName: freshOrder.courierName ?? null,
          trackingId: freshOrder.trackingId ?? null,
          itemsCount: freshOrder._count.items,
          itemsPreview: freshOrder.items,
        },
      ],
    });
  }

  const orders = await prisma.order.findMany({
    where: {
      phone: {
        equals: phone,
      },
    },
    orderBy: {
      createdAt: "desc",
    },
    take: 20,
    select: {
      id: true,
      publicOrderId: true,
      createdAt: true,
      name: true,
      phone: true,
      total: true,
      subtotal: true,
      discount: true,
      shipping: true,
      status: true,
      paymentMethod: true,
      paymentStatus: true,
      courierName: true,
      trackingId: true,
      items: {
        take: 3,
        orderBy: {
          createdAt: "asc",
        },
        select: {
          productName: true,
          qty: true,
          lineTotal: true,
        },
      },
      _count: {
        select: {
          items: true,
        },
      },
    },
  });

  if (!orders.length) {
    return NextResponse.json(
      { ok: false, error: "No orders found with this phone number" },
      { status: 404 },
    );
  }

  const steadfastOrders = orders
    .filter((order) => order.courierName === "Steadfast")
    .slice(0, 5);

  for (const order of steadfastOrders) {
    await syncSteadfastOrderById(order.id);
  }

  const freshOrders = await prisma.order.findMany({
    where: {
      phone: {
        equals: phone,
      },
    },
    orderBy: {
      createdAt: "desc",
    },
    take: 20,
    select: {
      id: true,
      publicOrderId: true,
      createdAt: true,
      name: true,
      phone: true,
      total: true,
      subtotal: true,
      discount: true,
      shipping: true,
      status: true,
      paymentMethod: true,
      paymentStatus: true,
      courierName: true,
      trackingId: true,
      items: {
        take: 3,
        orderBy: {
          createdAt: "asc",
        },
        select: {
          productName: true,
          qty: true,
          lineTotal: true,
        },
      },
      _count: {
        select: {
          items: true,
        },
      },
    },
  });

  return NextResponse.json({
    ok: true,
    mode: "phone",
    items: freshOrders.map((order) => ({
      id: order.id,
      publicOrderId: order.publicOrderId ?? null,
      createdAt: order.createdAt.toISOString(),
      name: order.name,
      phone: order.phone,
      total: order.total,
      subtotal: order.subtotal,
      discount: order.discount,
      shipping: order.shipping,
      status: order.status,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      courierName: order.courierName ?? null,
      trackingId: order.trackingId ?? null,
      itemsCount: order._count.items,
      itemsPreview: order.items,
    })),
  });
}
