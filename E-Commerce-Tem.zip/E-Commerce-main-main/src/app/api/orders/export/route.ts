import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { buildCsvFromRows, buildOrderExportRows } from "@/lib/order-export";

async function requireAdmin() {
    const session = await getServerSession(authOptions);
    const email = session?.user?.email;

    if (!email) return false;

    const user = await prisma.user.findUnique({
        where: { email },
        select: { role: true },
    });

    return Boolean(user && (user.role === "ADMIN" || user.role === "STAFF"));
}

export async function GET(req: NextRequest) {
    const ok = await requireAdmin();
    if (!ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = req.nextUrl.searchParams;

    const status = searchParams.get("status")?.trim() || "";
    const paymentStatus = searchParams.get("paymentStatus")?.trim() || "";
    const from = searchParams.get("from")?.trim() || "";
    const to = searchParams.get("to")?.trim() || "";
    const q = searchParams.get("q")?.trim() || "";

    const where: Record<string, unknown> = {};

    if (status) where.status = status;
    if (paymentStatus) where.paymentStatus = paymentStatus;

    if (from || to) {
        const createdAt: Record<string, Date> = {};
        if (from) createdAt.gte = new Date(`${from}T00:00:00.000Z`);
        if (to) createdAt.lte = new Date(`${to}T23:59:59.999Z`);
        where.createdAt = createdAt;
    }

    if (q) {
        where.OR = [
            { name: { contains: q, mode: "insensitive" } },
            { phone: { contains: q, mode: "insensitive" } },
            { publicOrderId: { contains: q, mode: "insensitive" } },
            { trackingId: { contains: q, mode: "insensitive" } },
        ];
    }

    const orders = await prisma.order.findMany({
        where,
        orderBy: {
            createdAt: "desc",
        },
        select: {
            id: true,
            publicOrderId: true,
            orderSequence: true,
            createdAt: true,
            status: true,
            paymentStatus: true,
            total: true,
            phone: true,
            name: true,
            addressLine1: true,
            addressLine2: true,
            city: true,
            area: true,
            note: true,
            trackingId: true,
            paymentMeta: true,
            items: {
                select: {
                    productName: true,
                    qty: true,
                    lineTotal: true,
                },
            },
        },
    });

    const rows = buildOrderExportRows(orders);
    const csv = buildCsvFromRows(rows);

    const filename = `admin-orders-export-${new Date()
        .toISOString()
        .slice(0, 10)}.csv`;

    return new NextResponse(csv, {
        status: 200,
        headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="${filename}"`,
        },
    });
}