import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { syncSteadfastOrderById } from "@/lib/couriers/steadfast-sync";

type ErrorResponse = {
  error: string;
};

type OrderItem = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  subtotal: number;
  discount: number;
  shipping: number;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  courierName: string | null;
  trackingId: string | null;
  itemsCount: number;
  itemsPreview: Array<{
    productName: string;
    qty: number;
    lineTotal: number;
  }>;
};

type SuccessResponse = {
  items: OrderItem[];
};

export async function GET(): Promise<
  NextResponse<SuccessResponse | ErrorResponse>
> {
  const session = await getServerSession(authOptions);

  const userId = typeof session?.user?.id === "string" ? session.user.id : null;

  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const orders = await prisma.order.findMany({
    where: {
      userId,
    },
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      publicOrderId: true,
      createdAt: true,
      name: true,
      phone: true,
      total: true,
      subtotal: true,
      discount: true,
      shipping: true,
      status: true,
      paymentMethod: true,
      paymentStatus: true,
      courierName: true,
      trackingId: true,
      items: {
        take: 3,
        orderBy: {
          createdAt: "asc",
        },
        select: {
          productName: true,
          qty: true,
          lineTotal: true,
        },
      },
      _count: {
        select: {
          items: true,
        },
      },
    },
  });

  const steadfastOrders = orders
    .filter((order) => order.courierName === "Steadfast")
    .slice(0, 5);

  for (const order of steadfastOrders) {
    await syncSteadfastOrderById(order.id);
  }

  const freshOrders = await prisma.order.findMany({
    where: {
      userId,
    },
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      publicOrderId: true,
      createdAt: true,
      name: true,
      phone: true,
      total: true,
      subtotal: true,
      discount: true,
      shipping: true,
      status: true,
      paymentMethod: true,
      paymentStatus: true,
      courierName: true,
      trackingId: true,
      items: {
        take: 3,
        orderBy: {
          createdAt: "asc",
        },
        select: {
          productName: true,
          qty: true,
          lineTotal: true,
        },
      },
      _count: {
        select: {
          items: true,
        },
      },
    },
  });

  return NextResponse.json({
    items: freshOrders.map((order) => ({
      id: order.id,
      publicOrderId: order.publicOrderId ?? null,
      createdAt: order.createdAt.toISOString(),
      name: order.name,
      phone: order.phone,
      total: order.total,
      subtotal: order.subtotal,
      discount: order.discount,
      shipping: order.shipping,
      status: order.status,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      courierName: order.courierName ?? null,
      trackingId: order.trackingId ?? null,
      itemsCount: order._count.items,
      itemsPreview: order.items,
    })),
  });
}
