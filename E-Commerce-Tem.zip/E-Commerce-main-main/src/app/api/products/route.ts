import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { OrderStatus, PaymentStatus, Prisma } from "@prisma/client";
import { getDescendantCategoryIds } from "@/lib/category-tree";
import { attachEffectivePrices } from "@/lib/product-discounts";

type ProductListItem = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured: boolean;
  category: {
    id: string;
    name: string;
    slug: string;
    parent: { id: string; name: string; slug: string } | null;
  } | null;
  images: { url: string }[];
  ratingAvg: number;
  ratingCount: number;
  variantsCount: number;
  hasVariants: boolean;
  variants: Array<{
    id: string;
    stock: number;
  }>;
};

type ProductsApiResponse = {
  items: ProductListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function toNumber(v: string | null, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function isWithinRange(price: number, min: number, max: number): boolean {
  if (min > 0 && price < min) return false;
  if (max > 0 && price > max) return false;
  return true;
}

async function attachRatings(
  products: Array<{
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    isFeatured: boolean;
    images: { url: string }[];
    category: {
      id: string;
      name: string;
      slug: string;
      parent: { id: string; name: string; slug: string } | null;
    } | null;
    createdAt: Date;
    discountPercent?: number | null;
    categories?: Array<{
      categoryId: string;
    }>;
    _count?: {
      variants: number;
    };
    variants?: Array<{
      id: string;
      stock: number;
    }>;
  }>,
): Promise<ProductListItem[]> {
  if (products.length === 0) return [];

  const ids = products.map((p) => p.id);

  const grouped = await prisma.review.groupBy({
    by: ["productId"],
    where: { productId: { in: ids } },
    _avg: { rating: true },
    _count: { rating: true },
  });

  const ratingMap = new Map<string, { avg: number; count: number }>();
  for (const g of grouped) {
    ratingMap.set(g.productId, {
      avg: typeof g._avg.rating === "number" ? g._avg.rating : 0,
      count: typeof g._count.rating === "number" ? g._count.rating : 0,
    });
  }

  return products.map((p) => {
    const rating = ratingMap.get(p.id) ?? { avg: 0, count: 0 };

    return {
      id: p.id,
      name: p.name,
      slug: p.slug,
      price: p.price,
      offerPrice: p.offerPrice,
      stock: p.stock,
      isFeatured: p.isFeatured,
      variantsCount: p._count?.variants ?? 0,
      hasVariants: (p._count?.variants ?? 0) > 0,
      variants: p.variants ?? [],
      images: p.images.map((img) => ({ url: img.url })),
      category: p.category
        ? {
            id: p.category.id,
            name: p.category.name,
            slug: p.category.slug,
            parent: p.category.parent
              ? {
                  id: p.category.parent.id,
                  name: p.category.parent.name,
                  slug: p.category.parent.slug,
                }
              : null,
          }
        : null,
      ratingAvg: Math.round(rating.avg * 10) / 10,
      ratingCount: rating.count,
    };
  });
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<ProductsApiResponse>> {
  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") || "").trim();
  const cat = (searchParams.get("cat") || "").trim();
  const sort = (searchParams.get("sort") || "newest").trim();
  const featured = (searchParams.get("featured") || "") === "1";
  const limitedOffer = (searchParams.get("offer") || "").trim() === "limited";
  const inStock = (searchParams.get("inStock") || "") === "1";

  const page = Math.max(1, toNumber(searchParams.get("page"), 1));
  const take = clamp(toNumber(searchParams.get("take"), 12), 6, 48);
  const skip = (page - 1) * take;

  const min = Math.max(0, toNumber(searchParams.get("min"), 0));
  const max = Math.max(0, toNumber(searchParams.get("max"), 0));

  const and: Prisma.ProductWhereInput[] = [{ isActive: true }];

  if (q) {
    and.push({
      OR: [
        { name: { contains: q, mode: "insensitive" } },
        { description: { contains: q, mode: "insensitive" } },
        { sku: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (featured) {
    and.push({ isFeatured: true });
  }

  if (inStock) {
    and.push({
      OR: [
        { stock: { gt: 0 } },
        {
          variants: {
            some: {
              stock: { gt: 0 },
            },
          },
        },
      ],
    });
  }

  if (cat) {
    const allCategories = await prisma.category.findMany({
      where: { isActive: true },
      select: {
        id: true,
        slug: true,
        parentId: true,
      },
    });

    const matched = allCategories.find((c) => c.slug === cat);

    if (matched) {
      const categoryIds = getDescendantCategoryIds(matched.id, allCategories);

      and.push({
        OR: [
          {
            categoryId: {
              in: categoryIds,
            },
          },
          {
            categories: {
              some: {
                categoryId: { in: categoryIds },
              },
            },
          },
        ],
      });
    } else {
      and.push({
        categoryId: "__not_found__",
      });
    }
  }

  const where: Prisma.ProductWhereInput = {
    AND: and,
  };

  const rawItems = await prisma.product.findMany({
    where,
    include: {
      images: {
        orderBy: { sortOrder: "asc" },
        take: 1,
        select: { url: true },
      },
      category: {
        select: {
          id: true,
          name: true,
          slug: true,
          parent: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      },
      categories: {
        select: {
          categoryId: true,
        },
      },
      variants: {
        orderBy: {
          createdAt: "asc",
        },
        take: 1,
        select: {
          id: true,
          stock: true,
        },
      },
      _count: {
        select: {
          variants: true,
        },
      },
    },
  });

  const resolvedItems = await attachEffectivePrices(rawItems);
  const filteredByOffer = limitedOffer
    ? resolvedItems.filter((p) => {
        const hasOfferPrice =
          typeof p.offerPrice === "number" && p.offerPrice < p.price;
        const hasDiscountPercent =
          typeof p.discountPercent === "number" && p.discountPercent > 0;

        return hasOfferPrice || hasDiscountPercent;
      })
    : resolvedItems;

  const filteredByPrice = filteredByOffer.filter((p) =>
    isWithinRange(p.offerPrice ?? p.price, min, max),
  );

  if (sort === "price_asc") {
    filteredByPrice.sort(
      (a, b) => (a.offerPrice ?? a.price) - (b.offerPrice ?? b.price),
    );
  } else if (sort === "price_desc") {
    filteredByPrice.sort(
      (a, b) => (b.offerPrice ?? b.price) - (a.offerPrice ?? a.price),
    );
  } else if (sort === "best_selling" || sort === "best-seller") {
    const productIds = filteredByPrice.map((product) => product.id);
    const grouped = productIds.length
      ? await prisma.orderItem.groupBy({
          by: ["productId"],
          where: {
            productId: {
              in: productIds,
            },
            order: {
              OR: [
                { status: OrderStatus.DELIVERED },
                { paymentStatus: PaymentStatus.PAID },
              ],
            },
          },
          _sum: {
            qty: true,
          },
        })
      : [];

    const soldQtyMap = new Map(
      grouped
        .filter((item) => typeof item.productId === "string")
        .map((item) => [item.productId as string, item._sum.qty ?? 0]),
    );

    filteredByPrice.sort((a, b) => {
      const qtyDiff = (soldQtyMap.get(b.id) ?? 0) - (soldQtyMap.get(a.id) ?? 0);
      if (qtyDiff !== 0) return qtyDiff;

      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  } else {
    filteredByPrice.sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }

  const total = filteredByPrice.length;
  const paged = filteredByPrice.slice(skip, skip + take);
  const withRatings = await attachRatings(paged);

  return NextResponse.json({
    items: withRatings,
    total,
    page,
    take,
    pages: Math.max(1, Math.ceil(total / take)),
  });
}
