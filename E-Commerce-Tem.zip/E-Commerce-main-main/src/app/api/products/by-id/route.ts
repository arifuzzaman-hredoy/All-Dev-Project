import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { attachEffectivePrice } from "@/lib/product-discounts";

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
        return NextResponse.json(
            { error: "Product ID is required" },
            { status: 400 },
        );
    }

    const product = await prisma.product.findUnique({
        where: { id },
        include: {
            images: {
                orderBy: { sortOrder: "asc" },
            },
            variants: {
                orderBy: { createdAt: "asc" },
            },
            category: {
                include: {
                    parent: true,
                },
            },
        },
    });

    if (!product || !product.isActive) {
        return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const resolved = await attachEffectivePrice(product);

    if (!resolved) {
        return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    return NextResponse.json({
        id: resolved.id,
        name: resolved.name,
        slug: resolved.slug,
        price: resolved.price,
        offerPrice: resolved.offerPrice,
        stock: resolved.stock,
        images: resolved.images.map((img) => ({
            url: img.url,
        })),
        variants: resolved.variants.map((variant) => ({
            id: variant.id,
            type: variant.type,
            value: variant.value,
            priceDiff: variant.priceDiff,
            stock: variant.stock,
        })),
    });
}