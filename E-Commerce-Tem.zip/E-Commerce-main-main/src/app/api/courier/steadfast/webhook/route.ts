import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  mapSteadfastStatusToOrderStatus,
  mergeSteadfastIntoPaymentMeta,
  normalizeSteadfastDeliveryStatus,
} from "@/lib/couriers/steadfast";
import {
  notifySteadfastBooked,
  notifySteadfastStatusChanged,
} from "@/lib/notifications";
import { env } from "@/lib/env";
import { Prisma } from "@prisma/client";

type WebhookBody = {
  notification_type?: string | null;
  invoice?: string | null;
  tracking_code?: string | null;
  delivery_status?: string | null;
  status?: string | null;
  consignment_id?: string | number | null;
  cod_amount?: number | string | null;
  delivery_charge?: number | string | null;
  tracking_message?: string | null;
  updated_at?: string | null;
  [key: string]: unknown;
};

function isAuthorized(req: NextRequest): boolean {
  const secret = env.STEADFAST_WEBHOOK_SECRET?.trim();
  if (!secret) return true;

  const authorization = req.headers.get("authorization")?.trim() || "";
  const legacySecret = req.headers.get("x-steadfast-webhook-secret")?.trim();

  return authorization === `Bearer ${secret}` || legacySecret === secret;
}

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized webhook" }, { status: 401 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as WebhookBody;
  const bodyRecord =
    bodyUnknown && typeof bodyUnknown === "object" && !Array.isArray(bodyUnknown)
      ? (bodyUnknown as Record<string, unknown>)
      : {};

  const invoice =
    typeof body.invoice === "string" && body.invoice.trim()
      ? body.invoice.trim()
      : null;

  if (!invoice) {
    return NextResponse.json({ error: "invoice missing" }, { status: 400 });
  }

  const order = await prisma.order.findFirst({
    where: {
      OR: [{ id: invoice }, { publicOrderId: invoice }],
    },
    select: {
      id: true,
      publicOrderId: true,
      status: true,
      trackingId: true,
      paymentMeta: true,
    },
  });

  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  const trackingId =
    typeof body.tracking_code === "string" ? body.tracking_code : order.trackingId;

  const deliveryStatus = normalizeSteadfastDeliveryStatus(
    typeof body.status === "string"
      ? body.status
      : typeof body.delivery_status === "string"
        ? body.delivery_status
        : null,
  );
  const mappedStatus = mapSteadfastStatusToOrderStatus(deliveryStatus);

  const nextPaymentMeta = mergeSteadfastIntoPaymentMeta({
    currentPaymentMeta: order.paymentMeta,
    trackingCode: trackingId ?? null,
    consignmentId:
      typeof body.consignment_id === "string" || typeof body.consignment_id === "number"
        ? String(body.consignment_id)
        : null,
    courierStatus: deliveryStatus,
    lastWebhook: bodyRecord,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: {
      courierName: "Steadfast",
      trackingId: trackingId ?? null,
      ...(mappedStatus ? { status: mappedStatus } : {}),
      paymentMeta: nextPaymentMeta as Prisma.InputJsonValue,
    },
  });

  if (!order.trackingId && trackingId) {
    await notifySteadfastBooked({
      orderId: order.id,
      trackingId,
    });
  }

  if ((mappedStatus && mappedStatus !== order.status) || deliveryStatus) {
    await notifySteadfastStatusChanged({
      orderId: order.id,
      previousOrderStatus: order.status,
      newOrderStatus: mappedStatus ?? order.status,
      courierStatus: deliveryStatus,
      trackingId: trackingId ?? null,
    });
  }

  return NextResponse.json({
    status: "success",
    message: "Webhook received successfully.",
  });
}
