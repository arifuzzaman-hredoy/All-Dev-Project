import { NextRequest, NextResponse } from "next/server";
import {
    fetchSteadfastDistricts,
    fetchSteadfastPoliceStations,
} from "@/lib/couriers/steadfast";

type ErrorResponse = {
    error: string;
};

type SuccessResponse = {
    ok: true;
    district: string | null;
    districts: Array<{
        id: string;
        name: string;
    }>;
    policeStations: Array<{
        id: string;
        name: string;
        district: string;
    }>;
};

export async function GET(
    req: NextRequest,
): Promise<NextResponse<SuccessResponse | ErrorResponse>> {
    try {
        const district = req.nextUrl.searchParams.get("district")?.trim() || "";

        const [districts, policeStations] = await Promise.all([
            fetchSteadfastDistricts(),
            district ? fetchSteadfastPoliceStations(district) : Promise.resolve([]),
        ]);

        return NextResponse.json({
            ok: true,
            district: district || null,
            districts,
            policeStations,
        });
    } catch (error) {
        console.error("Steadfast districts/police stations fetch failed:", error);

        return NextResponse.json(
            { error: "Failed to load district and police station data" },
            { status: 500 },
        );
    }
}