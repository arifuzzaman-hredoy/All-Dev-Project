import crypto from "crypto";
import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { getResendClient, getResendFromEmail } from "@/lib/resend";
import { enforceRateLimit } from "@/lib/rate-limit-guard";
import { AppError } from "@/lib/app-error";

const requestSchema = z.object({
  email: z.string().email(),
});

const RESET_TOKEN_TTL_MS = 60 * 60 * 1000;

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

function getClientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

function passwordResetEmailHtml(params: {
  resetUrl: string;
  appName: string;
}) {
  return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Reset your password</h2>
      <p>We received a request to reset your ${params.appName} password.</p>
      <p>
        <a href="${params.resetUrl}" style="display:inline-block;padding:12px 18px;border-radius:10px;background:#d81b60;color:#fff;text-decoration:none;font-weight:700;">
          Reset password
        </a>
      </p>
      <p>This link expires in 1 hour. If you did not request this, you can safely ignore this email.</p>
      <p style="font-size:12px;color:#64748b;">${params.resetUrl}</p>
    </div>
  `;
}

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req);
    enforceRateLimit({
      key: `forgot-password:${ip}`,
      limit: 5,
      windowMs: 15 * 60 * 1000,
    });

    const body = await req.json().catch(() => null);
    const parsed = requestSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid email" }, { status: 400 });
    }

    const email = parsed.data.email.trim().toLowerCase();
    const user = await prisma.user.findUnique({ where: { email } });

    if (user && !user.blocked) {
      await prisma.passwordResetToken.deleteMany({
        where: {
          userId: user.id,
          OR: [{ usedAt: { not: null } }, { expiresAt: { lt: new Date() } }],
        },
      });

      const token = crypto.randomBytes(32).toString("hex");
      const tokenHash = hashToken(token);
      const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);

      await prisma.passwordResetToken.create({
        data: {
          userId: user.id,
          tokenHash,
          expiresAt,
        },
      });

      const baseUrl = env.NEXT_PUBLIC_BASE_URL || env.NEXTAUTH_URL;
      const resetUrl = `${baseUrl.replace(/\/$/, "")}/reset-password?token=${encodeURIComponent(token)}`;
      const resend = getResendClient();

      if (resend) {
        await resend.emails.send({
          from: getResendFromEmail(),
          to: email,
          subject: `Reset your ${env.APP_NAME} password`,
          html: passwordResetEmailHtml({
            resetUrl,
            appName: env.APP_NAME,
          }),
        });
      } else {
        console.warn("Password reset email skipped: RESEND_API_KEY is missing.");
      }
    }

    return NextResponse.json({
      ok: true,
      message:
        "If an account exists for that email, a password reset link has been sent.",
    });
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }

    console.error("Forgot password failed:", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
