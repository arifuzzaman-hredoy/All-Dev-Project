import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    const email = session?.user?.email;

    if (!email) return null;

    return prisma.user.findUnique({
        where: { email },
        select: { id: true },
    });
}

export async function GET() {
    const user = await getCurrentUser();
    if (!user) {
        return NextResponse.json({ items: [], unreadCount: 0 });
    }

    const [items, unreadCount] = await Promise.all([
        prisma.notification.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: "desc" },
            take: 20,
            select: {
                id: true,
                title: true,
                message: true,
                linkUrl: true,
                isRead: true,
                createdAt: true,
            },
        }),
        prisma.notification.count({
            where: { userId: user.id, isRead: false },
        }),
    ]);

    return NextResponse.json({
        items,
        unreadCount,
    });
}

export async function PATCH(req: Request) {
    const user = await getCurrentUser();
    if (!user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = (await req.json().catch(() => null)) as
        | { id?: string; markAll?: boolean }
        | null;

    if (body?.markAll) {
        await prisma.notification.updateMany({
            where: {
                userId: user.id,
                isRead: false,
            },
            data: { isRead: true },
        });

        return NextResponse.json({ ok: true });
    }

    if (body?.id) {
        await prisma.notification.updateMany({
            where: {
                id: body.id,
                userId: user.id,
            },
            data: { isRead: true },
        });

        return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
}