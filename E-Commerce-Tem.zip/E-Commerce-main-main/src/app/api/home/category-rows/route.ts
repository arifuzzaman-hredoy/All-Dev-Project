import { NextResponse } from "next/server";
import { getHomeCategoryRows } from "@/lib/home-category-rows";

export async function GET() {
  const items = await getHomeCategoryRows();
  return NextResponse.json(items);
}
