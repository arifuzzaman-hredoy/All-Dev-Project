import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

type ErrorResponse = { error: string };
type OkResponse = { voted: boolean };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export async function POST(req: NextRequest): Promise<NextResponse<OkResponse | ErrorResponse>> {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;

  if (!isNonEmptyString(userId)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const reviewId = (bodyUnknown as { reviewId?: unknown })?.reviewId;

  if (!isNonEmptyString(reviewId)) {
    return NextResponse.json({ error: "reviewId required" }, { status: 400 });
  }

  const existing = await prisma.reviewVote.findFirst({
    where: { userId, reviewId: reviewId.trim() },
    select: { id: true },
  });

  if (existing) {
    await prisma.reviewVote.delete({ where: { id: existing.id } });
    return NextResponse.json({ voted: false });
  }

  await prisma.reviewVote.create({
    data: { userId, reviewId: reviewId.trim() },
  });

  return NextResponse.json({ voted: true }, { status: 201 });
}