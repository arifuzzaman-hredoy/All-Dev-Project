import { NextRequest, NextResponse } from "next/server";
import {
  getReviewGalleryPage,
  REVIEW_GALLERY_TAKE,
} from "@/lib/services/review-gallery";

function toNumber(value: string | null, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const skip = Math.max(0, toNumber(searchParams.get("skip"), 0));
  const take = Math.max(
    1,
    Math.min(24, toNumber(searchParams.get("take"), REVIEW_GALLERY_TAKE)),
  );

  const page = await getReviewGalleryPage({ skip, take });

  return NextResponse.json(page);
}
