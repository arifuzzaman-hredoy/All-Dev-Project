import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type ResponseOk = { productIds: string[] };
type ResponseErr = { error: string };

export async function GET(req: NextRequest): Promise<NextResponse<ResponseOk | ResponseErr>> {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;

  if (!userId) return NextResponse.json({ productIds: [] });

  const rows = await prisma.wishlistItem.findMany({
    where: { userId },
    select: { productId: true },
  });

  return NextResponse.json({ productIds: rows.map((r) => r.productId) });
}