import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { attachEffectivePrices } from "@/lib/product-discounts";

type WishlistListItem = {
  id: string;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
    category: { name: string; slug: string } | null;
  };
  createdAt: string;
};

type WishlistListResponse = { items: WishlistListItem[] };

type ToggleBody = { productId: string };
type ToggleResponse = { inWishlist: boolean };

type ErrorResponse = { error: string };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

async function requireUser(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId || !isNonEmptyString(userId)) {
    return { ok: false as const };
  }
  return { ok: true as const, userId };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<WishlistListResponse | ErrorResponse>> {
  const auth = await requireUser(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const rows = await prisma.wishlistItem.findMany({
    where: { userId: auth.userId },
    orderBy: { createdAt: "desc" },
    include: {
      product: {
        include: {
          images: { orderBy: { sortOrder: "asc" }, take: 1 },
          category: {
            include: {
              parent: true,
            },
          },
        },
      },
    },
  });

  const resolvedProducts = await attachEffectivePrices(
    rows
      .map((row) => row.product)
      .filter((p): p is NonNullable<typeof rows[number]["product"]> => Boolean(p)),
  );

  const resolvedMap = new Map(resolvedProducts.map((p) => [p.id, p]));

  const items: WishlistListItem[] = rows
    .filter((r) => r.product)
    .map((r) => {
      const product = resolvedMap.get(r.product.id) ?? r.product;

      return {
        id: r.id,
        product: {
          id: product.id,
          name: product.name,
          slug: product.slug,
          price: product.price,
          offerPrice: product.offerPrice ?? null,
          stock: product.stock,
          images: (product.images ?? [])
            .map((img) => ({ url: img.url }))
            .filter((x) => !!x.url),
          category: product.category
            ? { name: product.category.name, slug: product.category.slug }
            : null,
        },
        createdAt: r.createdAt.toISOString(),
      };
    });

  return NextResponse.json({ items });
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<ToggleResponse | ErrorResponse>> {
  const auth = await requireUser(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = bodyUnknown as Partial<ToggleBody>;

  if (!isNonEmptyString(body?.productId)) {
    return NextResponse.json(
      { error: "productId is required" },
      { status: 400 },
    );
  }

  const productId = body.productId.trim();

  const existing = await prisma.wishlistItem.findFirst({
    where: { userId: auth.userId, productId },
    select: { id: true },
  });

  if (existing) {
    await prisma.wishlistItem.delete({ where: { id: existing.id } });
    return NextResponse.json({ inWishlist: false });
  }

  await prisma.wishlistItem.create({
    data: { userId: auth.userId, productId },
  });

  return NextResponse.json({ inWishlist: true }, { status: 201 });
}

export async function DELETE(
  req: NextRequest,
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const auth = await requireUser(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const productId = searchParams.get("productId");

  if (!isNonEmptyString(productId)) {
    return NextResponse.json(
      { error: "productId is required" },
      { status: 400 },
    );
  }

  await prisma.wishlistItem.deleteMany({
    where: { userId: auth.userId, productId: productId.trim() },
  });

  return NextResponse.json({ ok: true });
}