import { NextResponse } from "next/server";
import { finalizeSSLCommerzPayment } from "@/lib/services/sslcommerz-payment-service";
import { env } from "@/lib/env";
import { logger } from "@/lib/logger";
import { handleApiError } from "@/lib/error-handler";
import { clearCartServer } from "@/lib/cart.server";

async function parsePayload(req: Request) {
  const contentType = req.headers.get("content-type") || "";

  if (contentType.includes("application/x-www-form-urlencoded")) {
    const form = await req.formData();
    return Object.fromEntries(form.entries()) as Record<string, string>;
  }

  if (contentType.includes("application/json")) {
    return (await req.json()) as Record<string, string>;
  }

  const url = new URL(req.url);
  return Object.fromEntries(url.searchParams.entries());
}

async function handler(req: Request) {
  try {
    const payload = await parsePayload(req);
    const tranId = payload.tran_id;
    const valId = payload.val_id;

    if (!tranId || !valId) {
      return NextResponse.redirect(
        `${env.NEXT_PUBLIC_BASE_URL}/payment/result?status=failed&reason=missing-payment-data`,
      );
    }

    await finalizeSSLCommerzPayment({
      tranId,
      valId,
      source: "success-callback",
    });

    await clearCartServer();

    return NextResponse.redirect(
      `${env.NEXT_PUBLIC_BASE_URL}/payment/result?status=success&orderId=${tranId}`,
    );
  } catch (error) {
    logger.error("SSLCommerz success callback failed", {
      error: error instanceof Error ? error.message : "Unknown error",
    });

    return handleApiError(error);
  }
}

export async function GET(req: Request) {
  return handler(req);
}

export async function POST(req: Request) {
  return handler(req);
}
