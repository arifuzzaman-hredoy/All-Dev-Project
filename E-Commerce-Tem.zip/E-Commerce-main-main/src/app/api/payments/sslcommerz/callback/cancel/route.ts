import { NextResponse } from "next/server";
import { markSSLCommerzFailed } from "@/lib/services/sslcommerz-payment-service";
import { env } from "@/lib/env";

async function parsePayload(req: Request) {
  const contentType = req.headers.get("content-type") || "";

  if (contentType.includes("application/x-www-form-urlencoded")) {
    const form = await req.formData();
    return Object.fromEntries(form.entries()) as Record<string, string>;
  }

  if (contentType.includes("application/json")) {
    return (await req.json()) as Record<string, string>;
  }

  const url = new URL(req.url);
  return Object.fromEntries(url.searchParams.entries());
}

async function handler(req: Request) {
  const payload = await parsePayload(req);
  const tranId = payload.tran_id;

  if (tranId) {
    await markSSLCommerzFailed({
      tranId,
      status: payload.status || "CANCELLED",
      payload,
    });
  }

  return NextResponse.redirect(
    `${env.NEXT_PUBLIC_BASE_URL}/payment/result?status=cancelled${tranId ? `&orderId=${tranId}` : ""}`,
  );
}

export async function GET(req: Request) {
  return handler(req);
}

export async function POST(req: Request) {
  return handler(req);
}
