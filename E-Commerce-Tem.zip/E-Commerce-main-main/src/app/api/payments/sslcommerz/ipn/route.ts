import { NextResponse } from "next/server";
import { finalizeSSLCommerzPayment } from "@/lib/services/sslcommerz-payment-service";import { logger } from "@/lib/logger";

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const payload = Object.fromEntries(form.entries()) as Record<string, string>;

    const tranId = payload.tran_id;
    const valId = payload.val_id;
    const status = payload.status;

    if (!tranId || !valId) {
      return new NextResponse("Missing tran_id or val_id", { status: 400 });
    }

    if (status !== "VALID" && status !== "VALIDATED") {
      return new NextResponse("Ignored non-success IPN", { status: 200 });
    }

    await finalizeSSLCommerzPayment({
      tranId,
      valId,
      source: "ipn",
    });

    return new NextResponse("IPN processed", { status: 200 });
  } catch (error) {
    logger.error("SSLCommerz IPN failed", {
      error: error instanceof Error ? error.message : "Unknown error",
    });

    return new NextResponse("IPN failed", { status: 500 });
  }
}