import { NextRequest, NextResponse } from "next/server";
import { getOptionalSessionUserId } from "@/lib/auth/guards";
import {
    manualPaymentSubmitSchema,
} from "@/lib/validations/checkout";
import { formatZodError } from "@/lib/validation-error";
import { verifyManualPaymentToken } from "@/lib/payments/manual-token";
import {
    createManualPaidOrder,
    prepareCheckout,
} from "@/lib/services/checkout-service";
import { notifyOrderPlaced } from "@/lib/notifications";
import { AppError } from "@/lib/app-error";

export async function POST(req: NextRequest) {
    try {
        const bodyUnknown: unknown = await req.json().catch(() => null);

        const parsed = manualPaymentSubmitSchema.safeParse(bodyUnknown);
        if (!parsed.success) {
            return NextResponse.json(
                { error: formatZodError(parsed.error) },
                { status: 400 },
            );
        }

        const body = parsed.data;

        const payload = verifyManualPaymentToken(body.token);
        const prepared = await prepareCheckout(payload.checkout);

        if (body.amount !== prepared.total) {
            return NextResponse.json(
                { error: "Submitted amount does not match order total" },
                { status: 400 },
            );
        }

        const userId = await getOptionalSessionUserId();

        const order = await createManualPaidOrder({
            userId,
            body: payload.checkout,
            prepared,
            idempotencyKey: payload.submissionKey,
            manual: {
                provider: body.provider,
                senderPhone: body.senderPhone,
                transactionId: body.transactionId,
                amount: body.amount,
            },
        });

        await notifyOrderPlaced(order.id);

        return NextResponse.json({
            ok: true,
            orderId: order.id,
        });
    } catch (error) {
        if (error instanceof AppError) {
            return NextResponse.json(
                { error: error.message },
                { status: error.statusCode },
            );
        }

        console.error("Manual payment submit failed:", error);
        return NextResponse.json(
            { error: "Manual payment submission failed" },
            { status: 500 },
        );
    }
}
