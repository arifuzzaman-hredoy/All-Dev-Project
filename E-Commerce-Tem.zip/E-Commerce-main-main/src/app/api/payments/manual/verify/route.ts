import { NextRequest, NextResponse } from "next/server";
import { verifyManualPaymentToken } from "@/lib/payments/manual-token";
import { prepareCheckout } from "@/lib/services/checkout-service";
import { prisma } from "@/lib/prisma";
import { AppError } from "@/lib/app-error";

export async function GET(req: NextRequest) {
  try {
    const token = req.nextUrl.searchParams.get("token")?.trim() || "";
    if (!token) {
      return NextResponse.json({ error: "Token is required" }, { status: 400 });
    }

    const payload = verifyManualPaymentToken(token);
    const prepared = await prepareCheckout(payload.checkout);

    const settings = await prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        manualPaymentEnabled: true,
        manualBkashNumber: true,
        manualBkashImageUrl: true,
        manualNagadNumber: true,
        manualNagadImageUrl: true,
        manualRocketNumber: true,
        manualRocketImageUrl: true,
      },
    });

    if (!settings?.manualPaymentEnabled) {
      return NextResponse.json(
        { error: "Manual payment is disabled" },
        { status: 422 },
      );
    }

    const providers = [
      settings.manualBkashNumber
        ? {
            code: "BKASH",
            label: "bKash",
            number: settings.manualBkashNumber,
            logoUrl: settings.manualBkashImageUrl ?? "",
          }
        : null,
      settings.manualNagadNumber
        ? {
            code: "NAGAD",
            label: "Nagad",
            number: settings.manualNagadNumber,
            logoUrl: settings.manualNagadImageUrl ?? "",
          }
        : null,
      settings.manualRocketNumber
        ? {
            code: "ROCKET",
            label: "Rocket",
            number: settings.manualRocketNumber,
            logoUrl: settings.manualRocketImageUrl ?? "",
          }
        : null,
    ].filter(Boolean);

    if (!providers.length) {
      return NextResponse.json(
        { error: "No manual payment number configured" },
        { status: 422 },
      );
    }

    return NextResponse.json({
      ok: true,
      checkout: payload.checkout,
      total: prepared.total,
      providers,
    });
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }

    console.error("Manual payment verify failed:", error);
    return NextResponse.json(
      { error: "Invalid or expired manual payment session" },
      { status: 400 },
    );
  }
}
