import { NextRequest, NextResponse } from "next/server";
import { checkoutSchema } from "@/lib/validations/checkout";
import { formatZodError } from "@/lib/validation-error";
import { AppError } from "@/lib/app-error";
import { createManualPaymentToken } from "@/lib/payments/manual-token";
import { prepareCheckout } from "@/lib/services/checkout-service";

export async function POST(req: NextRequest) {
    try {
        const bodyUnknown: unknown = await req.json().catch(() => null);

        const parsed = checkoutSchema.safeParse(bodyUnknown);
        if (!parsed.success) {
            return NextResponse.json(
                { error: formatZodError(parsed.error) },
                { status: 400 },
            );
        }

        const body = parsed.data;

        if (body.paymentMethod !== "MANUAL") {
            return NextResponse.json(
                { error: "Invalid payment method for this route" },
                { status: 400 },
            );
        }

        const prepared = await prepareCheckout(body);
        const token = createManualPaymentToken(body);

        return NextResponse.json({
            ok: true,
            token,
            total: prepared.total,
        });
    } catch (error) {
        if (error instanceof AppError) {
            return NextResponse.json(
                { error: error.message },
                { status: error.statusCode },
            );
        }

        console.error("Manual payment initiate failed:", error);
        return NextResponse.json(
            { error: "Manual payment initiation failed" },
            { status: 500 },
        );
    }
}