import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { AppError } from "@/lib/app-error";
import {
  normalizeCouponCode,
  validateCouponByCode,
  type CouponItemInput,
} from "@/lib/services/coupon-service";

type ErrorResponse = { error: string };
type OkResponse = {
  ok: true;
  code: string;
  discount: number;
  applicableSubtotal: number;
};

function parseItems(input: unknown): CouponItemInput[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      productId: String(item.productId ?? "").trim(),
      variantId: item.variantId ? String(item.variantId).trim() : undefined,
      qty: Number(item.qty ?? 0),
    }))
    .filter((item) => item.productId && Number.isFinite(item.qty) && item.qty > 0);
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<OkResponse | ErrorResponse>> {
  try {
    const body = (await req.json().catch(() => null)) as {
      code?: unknown;
      items?: unknown;
    } | null;

    const code = normalizeCouponCode(typeof body?.code === "string" ? body.code : "");
    const items = parseItems(body?.items);

    if (!code) {
      return NextResponse.json({ error: "Coupon code required" }, { status: 400 });
    }

    if (items.length === 0) {
      return NextResponse.json(
        { error: "No valid cart items found for coupon validation" },
        { status: 400 },
      );
    }

    const result = await validateCouponByCode(prisma, { code, items });

    return NextResponse.json({
      ok: true,
      code: result.coupon.code,
      discount: result.discount,
      applicableSubtotal: result.applicableSubtotal,
    });
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode || 400 },
      );
    }

    return NextResponse.json({ error: "Failed to validate coupon" }, { status: 500 });
  }
}