import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";
import { requireAdmin } from "@/lib/admin-guard";
import { z } from "zod";

type Ctx = {
  params: Promise<{ id: string }>;
};

const updateSchema = z.object({
  name: z.string().min(2).optional(),
  parentId: z.string().nullable().optional(),
  isActive: z.boolean().optional(),
  imageUrl: z.string().nullable().optional(),
});

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  const body = await req.json();
  const parsed = updateSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const existing = await prisma.category.findUnique({
    where: { id },
    include: {
      children: {
        select: { id: true },
      },
    },
  });

  if (!existing) {
    return NextResponse.json({ error: "Category not found" }, { status: 404 });
  }

  const data = parsed.data;

  if (typeof data.parentId !== "undefined") {
    if (data.parentId === id) {
      return NextResponse.json(
        { error: "A category cannot be its own parent" },
        { status: 400 },
      );
    }

    const childIds = new Set(existing.children.map((c) => c.id));
    if (data.parentId && childIds.has(data.parentId)) {
      return NextResponse.json(
        { error: "Cannot set a child category as parent" },
        { status: 400 },
      );
    }

    if (data.parentId) {
      const parent = await prisma.category.findUnique({
        where: { id: data.parentId },
        select: { id: true },
      });

      if (!parent) {
        return NextResponse.json(
          { error: "Selected parent category not found" },
          { status: 404 },
        );
      }
    }
  }

  let slug: string | undefined = undefined;

  if (data.name && data.name.trim() !== existing.name) {
    const slugBase = slugify(data.name);
    slug = slugBase;
    let i = 1;

    while (true) {
      const found = await prisma.category.findUnique({ where: { slug } });
      if (!found || found.id === id) break;
      slug = `${slugBase}-${i++}`;
    }
  }

  const updated = await prisma.category.update({
    where: { id },
    data: {
      name: data.name?.trim() || undefined,
      slug,
      parentId:
        typeof data.parentId !== "undefined"
          ? data.parentId || null
          : undefined,
      isActive: typeof data.isActive === "boolean" ? data.isActive : undefined,
      imageUrl:
        typeof data.imageUrl !== "undefined"
          ? data.imageUrl || null
          : undefined,
    },
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
      children: {
        select: {
          id: true,
          name: true,
          slug: true,
          parentId: true,
          isActive: true,
          imageUrl: true,
        },
        orderBy: { name: "asc" },
      },
      _count: {
        select: {
          products: true,
          children: true,
        },
      },
    },
  });

  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: Ctx) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  const existing = await prisma.category.findUnique({
    where: { id },
    include: {
      _count: {
        select: {
          products: true,
          children: true,
        },
      },
    },
  });

  if (!existing) {
    return NextResponse.json({ error: "Category not found" }, { status: 404 });
  }

  if (existing._count.children > 0) {
    return NextResponse.json(
      { error: "Cannot delete category with subcategories" },
      { status: 409 },
    );
  }

  if (existing._count.products > 0) {
    return NextResponse.json(
      { error: "Cannot delete category with products" },
      { status: 409 },
    );
  }

  await prisma.category.delete({
    where: { id },
  });

  return NextResponse.json({ ok: true });
}
