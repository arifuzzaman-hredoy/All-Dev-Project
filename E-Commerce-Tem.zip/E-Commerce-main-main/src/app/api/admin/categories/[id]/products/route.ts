import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

type Ctx = {
    params: Promise<{ id: string }>;
};

function normalizeQuery(value: string | null) {
    return (value || "").trim();
}

export async function GET(req: NextRequest, { params }: Ctx) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: categoryId } = await params;
    const q = normalizeQuery(req.nextUrl.searchParams.get("q"));

    const category = await prisma.category.findUnique({
        where: { id: categoryId },
        include: {
            parent: {
                select: { id: true, name: true, slug: true },
            },
        },
    });

    if (!category) {
        return NextResponse.json({ error: "Category not found" }, { status: 404 });
    }

    const linkedProducts = await prisma.product.findMany({
        where: {
            categories: {
                some: { categoryId },
            },
        },
        include: {
            category: {
                include: {
                    parent: {
                        select: { id: true, name: true, slug: true },
                    },
                },
            },
            categories: {
                include: {
                    category: {
                        include: {
                            parent: {
                                select: { id: true, name: true, slug: true },
                            },
                        },
                    },
                },
                orderBy: { createdAt: "asc" },
            },
            images: {
                orderBy: { sortOrder: "asc" },
                take: 1,
            },
        },
        orderBy: { createdAt: "desc" },
    });

    const availableProducts = await prisma.product.findMany({
        where: {
            isActive: true,
            ...(q
                ? {
                    OR: [
                        { name: { contains: q, mode: "insensitive" } },
                        { sku: { contains: q, mode: "insensitive" } },
                    ],
                }
                : {}),
        },
        select: {
            id: true,
            name: true,
            sku: true,
            categories: {
                select: {
                    categoryId: true,
                },
            },
            category: {
                include: {
                    parent: {
                        select: { id: true, name: true, slug: true },
                    },
                },
            },
        },
        orderBy: { createdAt: "desc" },
        take: 100,
    });

    return NextResponse.json({
        category,
        linkedProducts,
        availableProducts,
    });
}

export async function POST(req: NextRequest, { params }: Ctx) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: categoryId } = await params;
    const body = await req.json().catch(() => null);
    const productId = typeof body?.productId === "string" ? body.productId.trim() : "";

    if (!productId) {
        return NextResponse.json({ error: "Product is required" }, { status: 400 });
    }

    const [category, product] = await Promise.all([
        prisma.category.findUnique({
            where: { id: categoryId },
            select: { id: true },
        }),
        prisma.product.findUnique({
            where: { id: productId },
            select: { id: true },
        }),
    ]);

    if (!category) {
        return NextResponse.json({ error: "Category not found" }, { status: 404 });
    }

    if (!product) {
        return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    await prisma.productCategory.upsert({
        where: {
            productId_categoryId: {
                productId,
                categoryId,
            },
        },
        update: {},
        create: {
            productId,
            categoryId,
        },
    });

    return NextResponse.json({
        ok: true,
        message: "Product linked to category successfully",
    });
}

export async function DELETE(req: NextRequest, { params }: Ctx) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: categoryId } = await params;
    const productId =
        typeof req.nextUrl.searchParams.get("productId") === "string"
            ? req.nextUrl.searchParams.get("productId")!.trim()
            : "";

    if (!productId) {
        return NextResponse.json({ error: "Product is required" }, { status: 400 });
    }

    const product = await prisma.product.findUnique({
        where: { id: productId },
        include: {
            categories: {
                select: {
                    categoryId: true,
                },
            },
        },
    });

    if (!product) {
        return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    if (product.categories.length <= 1) {
        return NextResponse.json(
            {
                error: "A product must have at least one category",
            },
            { status: 400 },
        );
    }

    await prisma.productCategory.deleteMany({
        where: {
            productId,
            categoryId,
        },
    });

    const remaining = await prisma.productCategory.findMany({
        where: { productId },
        orderBy: { createdAt: "asc" },
        select: { categoryId: true },
        take: 1,
    });

    if (remaining[0]?.categoryId) {
        await prisma.product.update({
            where: { id: productId },
            data: {
                categoryId: remaining[0].categoryId,
            },
        });
    }

    return NextResponse.json({
        ok: true,
        message: "Product removed from category successfully",
    });
}