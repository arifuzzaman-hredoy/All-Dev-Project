import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";

const createSchema = z.object({
  name: z.string().min(2),
  parentId: z.string().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
});

export async function GET() {
  const items = await prisma.category.findMany({
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
      children: {
        select: {
          id: true,
          name: true,
          slug: true,
          parentId: true,
          isActive: true,
          imageUrl: true,
        },
        orderBy: { name: "asc" },
      },
      _count: {
        select: {
          products: true,
          children: true,
        },
      },
    },
    orderBy: [{ parentId: "asc" }, { name: "asc" }],
  });

  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const g = await requireAdmin(req);
  if (!g.ok)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success)
    return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const { name, parentId, imageUrl } = parsed.data;

  if (parentId) {
    const parent = await prisma.category.findUnique({
      where: { id: parentId },
      select: { id: true },
    });

    if (!parent) {
      return NextResponse.json(
        { error: "Parent category not found" },
        { status: 404 },
      );
    }
  }

  const slugBase = slugify(name);
  let slug = slugBase;
  let i = 1;

  while (await prisma.category.findUnique({ where: { slug } })) {
    slug = `${slugBase}-${i++}`;
  }

  const created = await prisma.category.create({
    data: {
      name,
      slug,
      parentId: parentId || null,
      imageUrl: imageUrl || null,
    },
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
    },
  });

  return NextResponse.json(created, { status: 201 });
}
