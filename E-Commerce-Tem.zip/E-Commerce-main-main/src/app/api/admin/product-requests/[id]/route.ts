import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { ProductRequestStatus } from "@prisma/client";

type Ctx = {
    params: Promise<{ id: string }>;
};

function normalizeStatus(value: unknown): ProductRequestStatus | null {
    if (
        value === "PENDING" ||
        value === "CONTACTED" ||
        value === "FULFILLED" ||
        value === "REJECTED"
    ) {
        return value;
    }

    return null;
}

function normalizeOptionalString(value: unknown): string | null {
    if (typeof value !== "string") return null;
    const v = value.trim();
    return v ? v : null;
}

export async function PATCH(req: NextRequest, { params }: Ctx) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    if (!id) {
        return NextResponse.json({ error: "Missing id" }, { status: 400 });
    }

    const body = await req.json().catch(() => null);
    const status = normalizeStatus(body?.status);
    const adminNote = normalizeOptionalString(body?.adminNote);

    if (!status) {
        return NextResponse.json(
            { error: "Valid status is required." },
            { status: 400 },
        );
    }

    const updated = await prisma.productRequest.update({
        where: { id },
        data: {
            status,
            adminNote,
        },
        include: {
            product: {
                select: {
                    id: true,
                    name: true,
                    slug: true,
                    sku: true,
                },
            },
        },
    });

    return NextResponse.json({
        ok: true,
        request: updated,
    });
}