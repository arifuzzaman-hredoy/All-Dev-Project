import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

export async function GET(req: NextRequest) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const status = req.nextUrl.searchParams.get("status")?.trim() || "";

    const items = await prisma.productRequest.findMany({
        where: status
            ? {
                status: status as
                    | "PENDING"
                    | "CONTACTED"
                    | "FULFILLED"
                    | "REJECTED",
            }
            : undefined,
        include: {
            product: {
                select: {
                    id: true,
                    name: true,
                    slug: true,
                    sku: true,
                    stock: true,
                    images: {
                        orderBy: { sortOrder: "asc" },
                        take: 1,
                        select: { url: true },
                    },
                },
            },
        },
        orderBy: [{ createdAt: "desc" }],
    });

    return NextResponse.json(items);
}