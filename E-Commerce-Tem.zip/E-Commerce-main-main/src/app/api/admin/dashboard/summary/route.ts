import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { OrderStatus } from "@prisma/client";

type ErrorResponse = { error: string };

type LowStockItem = {
  id: string;
  name: string;
  slug: string;
  sku: string;
  stock: number;
  categoryName: string;
};

type SummaryResponse = {
  ok: true;
  dhakaDayStartIso: string;
  dhakaDayEndIso: string;

  ordersToday: number;
  revenueToday: number;

  pendingOrders: number;
  processingOrders: number;

  totalUsers: number;

  lowStockThreshold: number;
  lowStockCount: number;
  lowStockTop: LowStockItem[];
};

async function requireAdmin(): Promise<{ ok: true } | { ok: false; res: NextResponse<ErrorResponse> }> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;
  if (role !== "ADMIN" && role !== "STAFF") {
    return { ok: false, res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { ok: true };
}

// Dhaka day window without extra deps (UTC+6)
function dhakaDayWindowUTC(now = new Date()): { startUTC: Date; endUTC: Date } {
  const offsetMs = 6 * 60 * 60 * 1000;
  const dhakaNow = new Date(now.getTime() + offsetMs);

  // start of "Dhaka date" in Dhaka's pseudo-UTC space
  const startDhaka = new Date(Date.UTC(dhakaNow.getUTCFullYear(), dhakaNow.getUTCMonth(), dhakaNow.getUTCDate()));
  const startUTC = new Date(startDhaka.getTime() - offsetMs);
  const endUTC = new Date(startUTC.getTime() + 24 * 60 * 60 * 1000);

  return { startUTC, endUTC };
}

export async function GET(): Promise<NextResponse<SummaryResponse | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const { startUTC, endUTC } = dhakaDayWindowUTC();

  const settings = await prisma.storeSettings.findUnique({ where: { id: "default" } });
  const lowStockThreshold = settings?.lowStockThreshold ?? 5;

  const [
    todayAgg,
    pendingOrders,
    processingOrders,
    totalUsers,
    lowStockCount,
    lowStockTop,
  ] = await Promise.all([
    prisma.order.aggregate({
      where: {
        createdAt: { gte: startUTC, lt: endUTC },
        status: { not: OrderStatus.CANCELLED },
      },
      _count: { id: true },
      _sum: { total: true },
    }),
    prisma.order.count({ where: { status: OrderStatus.PENDING } }),
    prisma.order.count({ where: { status: OrderStatus.PROCESSING } }),
    prisma.user.count(),
    prisma.product.count({
      where: { isActive: true, stock: { lte: lowStockThreshold } },
    }),
    prisma.product.findMany({
      where: { isActive: true, stock: { lte: lowStockThreshold } },
      orderBy: [{ stock: "asc" }, { updatedAt: "desc" }],
      take: 12,
      select: {
        id: true,
        name: true,
        slug: true,
        sku: true,
        stock: true,
        category: { select: { name: true } },
      },
    }),
  ]);

  const ordersToday = todayAgg._count.id ?? 0;
  const revenueToday = todayAgg._sum.total ?? 0;

  return NextResponse.json({
    ok: true,
    dhakaDayStartIso: startUTC.toISOString(),
    dhakaDayEndIso: endUTC.toISOString(),

    ordersToday,
    revenueToday,

    pendingOrders,
    processingOrders,

    totalUsers,

    lowStockThreshold,
    lowStockCount,
    lowStockTop: lowStockTop.map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      sku: p.sku,
      stock: p.stock,
      categoryName: p.category?.name ?? "—",
    })),
  });
}