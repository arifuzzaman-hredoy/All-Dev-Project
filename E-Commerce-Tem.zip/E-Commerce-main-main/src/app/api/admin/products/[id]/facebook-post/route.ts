import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

export const runtime = "nodejs";

type FacebookGraphSuccess = Record<string, unknown>;
type FacebookGraphError = {
    error?: {
        message?: string;
        type?: string;
        code?: number;
        error_subcode?: number;
        fbtrace_id?: string;
    };
};

function getRequestOrigin(req: NextRequest) {
    const forwardedProto = req.headers.get("x-forwarded-proto");
    const forwardedHost = req.headers.get("x-forwarded-host");
    const host = forwardedHost || req.headers.get("host");

    if (!host) return null;

    const protocol =
        forwardedProto ||
        (host.startsWith("localhost") || host.startsWith("127.0.0.1")
            ? "http"
            : "https");

    return `${protocol}://${host}`;
}

function toAbsoluteUrl(origin: string | null, url: string) {
    if (!url) return "";
    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    if (!origin) return url;
    return `${origin}${url.startsWith("/") ? url : `/${url}`}`;
}

function uniqueStrings(values: string[]) {
    return Array.from(new Set(values.filter(Boolean)));
}

function trimText(value: string | null | undefined, max = 4000) {
    const text = (value || "").trim();
    if (!text) return "";
    if (text.length <= max) return text;
    return `${text.slice(0, max - 3)}...`;
}

function buildFacebookPostMessage(product: {
    name: string;
    sku: string;
    description: string | null;
    price: number;
    offerPrice: number | null;
    stock: number;
    slug: string;
    category: {
        name: string;
        parent?: { name: string } | null;
    } | null;
    variants: Array<{
        type: string;
        value: string;
        priceDiff: number;
        stock: number;
    }>;
}) {
    const lines: string[] = [];

    lines.push(`✨ ${product.name}`);

    const categoryPath = product.category
        ? [product.category.parent?.name, product.category.name]
            .filter(Boolean)
            .join(" → ")
        : "";

    if (categoryPath) {
        lines.push(`📂 Category: ${categoryPath}`);
    }

    lines.push(`🧾 SKU: ${product.sku}`);

    if (product.offerPrice && product.offerPrice > 0) {
        lines.push(`💰 Regular Price: ৳${product.price}`);
        lines.push(`🔥 Offer Price: ৳${product.offerPrice}`);
    } else {
        lines.push(`💰 Price: ৳${product.price}`);
    }

    lines.push(`📦 Stock: ${product.stock}`);

    const description = trimText(product.description, 1400);
    if (description) {
        lines.push("");
        lines.push("📝 Description:");
        lines.push(description);
    }

    if (product.variants.length) {
        lines.push("");
        lines.push("🎯 Available Variants:");
        for (const variant of product.variants) {
            const extra =
                variant.priceDiff && variant.priceDiff !== 0
                    ? ` | Extra: ৳${variant.priceDiff}`
                    : "";
            lines.push(
                `• ${variant.type}: ${variant.value} | Stock: ${variant.stock}${extra}`,
            );
        }
    }

    lines.push("");
    lines.push(`🛒 Order now:`);

    return lines.join("\n");
}

async function fetchFacebookJson<T = FacebookGraphSuccess>(
    input: string,
    init?: RequestInit,
): Promise<T> {
    const response = await fetch(input, init);
    const json = (await response.json().catch(() => ({}))) as
        | T
        | FacebookGraphError;

    if (!response.ok) {
        const errorMessage =
            (json as FacebookGraphError)?.error?.message ||
            "Facebook request failed.";
        throw new Error(errorMessage);
    }

    return json as T;
}

async function uploadPhotoToFacebookPage(params: {
    pageId: string;
    accessToken: string;
    apiVersion: string;
    imageUrl: string;
    origin: string | null;
}) {
    const absoluteImageUrl = toAbsoluteUrl(params.origin, params.imageUrl);

    const imageResponse = await fetch(absoluteImageUrl, { cache: "no-store" });
    if (!imageResponse.ok) {
        throw new Error(`Could not fetch product image: ${absoluteImageUrl}`);
    }

    const contentType =
        imageResponse.headers.get("content-type") || "image/jpeg";
    const arrayBuffer = await imageResponse.arrayBuffer();
    const blob = new Blob([arrayBuffer], { type: contentType });

    const form = new FormData();
    form.append("published", "false");
    form.append("source", blob, "product-image");

    const uploadUrl = `https://graph.facebook.com/${params.apiVersion}/${params.pageId}/photos?access_token=${encodeURIComponent(params.accessToken)}`;

    const uploadResult = await fetchFacebookJson<{ id: string }>(uploadUrl, {
        method: "POST",
        body: form,
    });

    return uploadResult.id;
}

export async function POST(
    req: NextRequest,
    ctx: { params: Promise<{ id?: string }> | { id?: string } },
) {
    const gate = await requireAdmin(req);
    if (!gate.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const productId = params?.id?.trim();

    if (!productId) {
        return NextResponse.json(
            { error: "Product id is required." },
            { status: 400 },
        );
    }

    const pageId = process.env.FACEBOOK_PAGE_ID?.trim();
    const pageAccessToken = process.env.FACEBOOK_PAGE_ACCESS_TOKEN?.trim();
    const apiVersion = process.env.FACEBOOK_GRAPH_API_VERSION?.trim() || "v25.0";

    if (!pageId || !pageAccessToken) {
        return NextResponse.json(
            {
                error:
                    "Facebook Page is not configured yet. Add FACEBOOK_PAGE_ID and FACEBOOK_PAGE_ACCESS_TOKEN in environment variables.",
            },
            { status: 500 },
        );
    }

    const product = await prisma.product.findUnique({
        where: { id: productId },
        include: {
            category: {
                include: {
                    parent: true,
                },
            },
            images: {
                orderBy: {
                    sortOrder: "asc",
                },
            },
            variants: {
                include: {
                    images: {
                        orderBy: {
                            sortOrder: "asc",
                        },
                    },
                },
            },
        },
    });

    if (!product) {
        return NextResponse.json({ error: "Product not found." }, { status: 404 });
    }

    const origin = getRequestOrigin(req);
    const productLink = product.slug
        ? `${origin || ""}/products/${product.slug}`
        : `${origin || ""}/products`;

    const message = `${buildFacebookPostMessage(product)}\n${productLink}`;

    const imageUrls = uniqueStrings([
        ...product.images.map((img) => img.url),
        ...product.variants.flatMap((variant) =>
            variant.images.map((img) => img.url),
        ),
    ]);

    try {
        let postId = "";
        let attachedPhotoIds: string[] = [];

        if (imageUrls.length) {
            attachedPhotoIds = [];

            for (const imageUrl of imageUrls) {
                const uploadedId = await uploadPhotoToFacebookPage({
                    pageId,
                    accessToken: pageAccessToken,
                    apiVersion,
                    imageUrl,
                    origin,
                });
                attachedPhotoIds.push(uploadedId);
            }

            const feedForm = new FormData();
            feedForm.append("message", message);

            attachedPhotoIds.forEach((photoId, index) => {
                feedForm.append(
                    `attached_media[${index}]`,
                    JSON.stringify({ media_fbid: photoId }),
                );
            });

            const feedUrl = `https://graph.facebook.com/${apiVersion}/${pageId}/feed?access_token=${encodeURIComponent(pageAccessToken)}`;

            const postResult = await fetchFacebookJson<{ id: string }>(feedUrl, {
                method: "POST",
                body: feedForm,
            });

            postId = postResult.id;
        } else {
            const feedForm = new FormData();
            feedForm.append("message", message);

            const feedUrl = `https://graph.facebook.com/${apiVersion}/${pageId}/feed?access_token=${encodeURIComponent(pageAccessToken)}`;

            const postResult = await fetchFacebookJson<{ id: string }>(feedUrl, {
                method: "POST",
                body: feedForm,
            });

            postId = postResult.id;
        }

        return NextResponse.json({
            ok: true,
            postId,
            message: "Product posted to Facebook Page successfully.",
        });
    } catch (error) {
        console.error("Facebook product post failed:", error);

        return NextResponse.json(
            {
                error:
                    error instanceof Error
                        ? error.message
                        : "Could not publish product to Facebook Page.",
            },
            { status: 500 },
        );
    }
}