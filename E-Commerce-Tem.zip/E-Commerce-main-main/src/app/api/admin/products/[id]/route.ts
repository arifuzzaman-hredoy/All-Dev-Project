import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";
import { deleteLocalUploadsByUrls } from "@/lib/local-uploads";
import { normalizeCategoryIds } from "@/lib/product-category-links";

type Ctx = { params: Promise<{ id: string }> };

const variantSchema = z.object({
  id: z.string().optional(),
  type: z.string().min(1),
  value: z.string().min(1),
  priceDiff: z.number().int().default(0),
  investedAmount: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0).default(0),
  images: z.array(z.string().min(1)).default([]),
});

const updateSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional().nullable(),
  youtubeUrl: z.string().trim().url().optional().nullable().or(z.literal("")),
  price: z.number().int().min(0),
  offerPrice: z.number().int().min(0).optional().nullable(),
  investedAmount: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0),
  categoryIds: z.array(z.string()).min(1),
  isFeatured: z.boolean().optional(),
  isActive: z.boolean().optional(),
  images: z.array(z.string().min(1)).default([]),
  variants: z.array(variantSchema).default([]),
});

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  const body = await req.json();
  const parsed = updateSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid" }, { status: 400 });
  }

  const data = parsed.data;
  const categoryIds = normalizeCategoryIds(data.categoryIds);

  if (!categoryIds.length) {
    return NextResponse.json(
      { error: "At least one category is required" },
      { status: 400 },
    );
  }

  const count = await prisma.category.count({
    where: {
      id: { in: categoryIds },
      isActive: true,
    },
  });

  if (count !== categoryIds.length) {
    return NextResponse.json(
      { error: "One or more categories are invalid" },
      { status: 400 },
    );
  }

  const primaryCategoryId = categoryIds[0];

  const existingProduct = await prisma.product.findUnique({
    where: { id },
    include: {
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
      categories: true,
    },
  });

  if (!existingProduct) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const slugBase = slugify(data.name);
  let slug = slugBase;
  let i = 1;

  while (true) {
    const existing = await prisma.product.findUnique({ where: { slug } });
    if (!existing || existing.id === id) break;
    slug = `${slugBase}-${i++}`;
  }

  const oldProductImageUrls = existingProduct.images.map((img) => img.url);
  const nextProductImageUrls = data.images;
  const removedProductImageUrls = oldProductImageUrls.filter(
    (url) => !nextProductImageUrls.includes(url),
  );

  const existingVariantMap = new Map(
    existingProduct.variants.map((v) => [v.id, v] as const),
  );

  const incomingVariantIds = new Set(
    data.variants.map((v) => v.id).filter(Boolean) as string[],
  );

  const removedVariants = existingProduct.variants.filter(
    (v) => !incomingVariantIds.has(v.id),
  );

  const removedVariantImageUrls = removedVariants.flatMap((v) =>
    v.images.map((img) => img.url),
  );

  const changedExistingVariantRemovedUrls: string[] = [];

  for (const variant of data.variants) {
    if (!variant.id) continue;

    const existing = existingVariantMap.get(variant.id);
    if (!existing) continue;

    const oldUrls = existing.images.map((img) => img.url);
    const nextUrls = variant.images;
    const removedUrls = oldUrls.filter((url) => !nextUrls.includes(url));

    changedExistingVariantRemovedUrls.push(...removedUrls);
  }

  await prisma.$transaction(async (tx) => {
    await tx.product.update({
      where: { id },
      data: {
        name: data.name,
        slug,
        description: data.description ?? null,
        youtubeUrl: data.youtubeUrl?.trim() || null,
        price: data.price,
        offerPrice: data.offerPrice ?? null,
        investedAmount: data.investedAmount ?? null,
        stock: data.stock,
        categoryId: primaryCategoryId,
        isFeatured: data.isFeatured ?? false,
        isActive: data.isActive ?? true,
        images: {
          deleteMany: {},
          create: data.images.map((url, idx) => ({
            url,
            sortOrder: idx,
          })),
        },
        categories: {
          deleteMany: {},
          create: categoryIds.map((categoryId) => ({
            categoryId,
          })),
        },
      },
    });

    if (removedVariants.length) {
      await tx.productVariant.deleteMany({
        where: {
          id: {
            in: removedVariants.map((v) => v.id),
          },
        },
      });
    }

    for (const variant of data.variants) {
      if (variant.id && existingVariantMap.has(variant.id)) {
        await tx.productVariant.update({
          where: { id: variant.id },
          data: {
            type: variant.type,
            value: variant.value,
            priceDiff: variant.priceDiff,
            investedAmount: variant.investedAmount ?? null,
            stock: variant.stock,
            images: {
              deleteMany: {},
              create: variant.images.map((url, idx) => ({
                url,
                sortOrder: idx,
              })),
            },
          },
        });
      } else {
        await tx.productVariant.create({
          data: {
            productId: id,
            type: variant.type,
            value: variant.value,
            priceDiff: variant.priceDiff,
            investedAmount: variant.investedAmount ?? null,
            stock: variant.stock,
            images: {
              create: variant.images.map((url, idx) => ({
                url,
                sortOrder: idx,
              })),
            },
          },
        });
      }
    }
  });

  const updated = await prisma.product.findUnique({
    where: { id },
    include: {
      category: {
        include: {
          parent: {
            select: { id: true, name: true, slug: true },
          },
        },
      },
      categories: {
        include: {
          category: {
            include: {
              parent: {
                select: { id: true, name: true, slug: true },
              },
            },
          },
        },
        orderBy: { createdAt: "asc" },
      },
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  const allRemovedUrls = [
    ...removedProductImageUrls,
    ...removedVariantImageUrls,
    ...changedExistingVariantRemovedUrls,
  ];

  if (allRemovedUrls.length) {
    await deleteLocalUploadsByUrls(allRemovedUrls);
  }

  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: Ctx) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  try {
    const exists = await prisma.product.findUnique({
      where: { id },
      include: {
        images: true,
        variants: {
          include: { images: true },
        },
      },
    });

    if (!exists) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    await prisma.product.delete({ where: { id } });

    const sharedUrls = exists.images.map((img) => img.url);
    const variantUrls = exists.variants.flatMap((v) =>
      v.images.map((img) => img.url),
    );

    const allUrls = [...sharedUrls, ...variantUrls];

    if (allUrls.length) {
      await deleteLocalUploadsByUrls(allUrls);
    }

    return NextResponse.json({ ok: true });
  } catch (err: unknown) {
    const e = err as { code?: string };

    if (e.code === "P2003") {
      return NextResponse.json(
        { error: "Cannot delete: product is linked with other data." },
        { status: 409 },
      );
    }

    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
