import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { attachEffectivePrices } from "@/lib/product-discounts";

async function requireAdmin() {
    const session = await getServerSession(authOptions);
    const email = session?.user?.email;

    if (!email) return false;

    const user = await prisma.user.findUnique({
        where: { email },
        select: { role: true },
    });

    return Boolean(user && (user.role === "ADMIN" || user.role === "STAFF"));
}

export async function GET(req: NextRequest) {
    const ok = await requireAdmin();
    if (!ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const q = req.nextUrl.searchParams.get("q")?.trim() || "";

    const productsRaw = await prisma.product.findMany({
        where: {
            isActive: true,
            ...(q
                ? {
                    OR: [
                        { name: { contains: q, mode: "insensitive" } },
                        { sku: { contains: q, mode: "insensitive" } },
                    ],
                }
                : {}),
        },
        orderBy: {
            createdAt: "desc",
        },
        take: q ? 100 : 200,
        select: {
            id: true,
            name: true,
            sku: true,
            price: true,
            offerPrice: true,
            stock: true,
            categoryId: true,
            category: {
                select: {
                    id: true,
                    parent: {
                        select: {
                            id: true,
                        },
                    },
                },
            },
            variants: {
                select: {
                    id: true,
                    type: true,
                    value: true,
                    priceDiff: true,
                    stock: true,
                },
                orderBy: {
                    createdAt: "asc",
                },
            },
        },
    });

    const products = await attachEffectivePrices(productsRaw);

    return NextResponse.json({
        ok: true,
        products,
    });
}