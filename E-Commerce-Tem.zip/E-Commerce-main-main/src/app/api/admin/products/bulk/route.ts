import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { deleteLocalUploadsByUrls } from "@/lib/local-uploads";

const bulkSchema = z.discriminatedUnion("action", [
    z.object({
        action: z.literal("delete"),
        productIds: z.array(z.string().min(1)).min(1),
    }),
    z.object({
        action: z.literal("feature"),
        productIds: z.array(z.string().min(1)).min(1),
    }),
    z.object({
        action: z.literal("category"),
        productIds: z.array(z.string().min(1)).min(1),
        categoryId: z.string().min(1),
    }),
    z.object({
        action: z.literal("addCategory"),
        productIds: z.array(z.string().min(1)).min(1),
        categoryId: z.string().min(1),
    }),
]);

export async function POST(req: NextRequest) {
    const g = await requireAdmin(req);
    if (!g.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const rawBody = await req.json().catch(() => null);
    const parsed = bulkSchema.safeParse(rawBody);

    if (!parsed.success) {
        return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
    }

    const data = parsed.data;
    const productIds = Array.from(
        new Set(data.productIds.map((id) => id.trim()).filter(Boolean)),
    );

    if (!productIds.length) {
        return NextResponse.json(
            { error: "Please select at least one product." },
            { status: 400 },
        );
    }

    try {
        if (data.action === "feature") {
            const result = await prisma.product.updateMany({
                where: { id: { in: productIds } },
                data: { isFeatured: true },
            });

            return NextResponse.json({
                ok: true,
                action: "feature",
                updatedCount: result.count,
            });
        }

        if (data.action === "category" || data.action === "addCategory") {
            const category = await prisma.category.findUnique({
                where: { id: data.categoryId },
                select: {
                    id: true,
                    name: true,
                    isActive: true,
                    parent: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                },
            });

            if (!category || !category.isActive) {
                return NextResponse.json(
                    { error: "Selected category was not found or is inactive." },
                    { status: 404 },
                );
            }

            if (data.action === "addCategory") {
                const result = await prisma.productCategory.createMany({
                    data: productIds.map((productId) => ({
                        productId,
                        categoryId: data.categoryId,
                    })),
                    skipDuplicates: true,
                });

                return NextResponse.json({
                    ok: true,
                    action: "addCategory",
                    updatedCount: productIds.length,
                    addedCount: result.count,
                    categoryLabel: [category.parent?.name, category.name]
                        .filter(Boolean)
                        .join(" → "),
                });
            }

            await prisma.$transaction(async (tx) => {
                await tx.product.updateMany({
                    where: { id: { in: productIds } },
                    data: { categoryId: data.categoryId },
                });

                await tx.productCategory.deleteMany({
                    where: { productId: { in: productIds } },
                });

                await tx.productCategory.createMany({
                    data: productIds.map((productId) => ({
                        productId,
                        categoryId: data.categoryId,
                    })),
                    skipDuplicates: true,
                });
            });

            return NextResponse.json({
                ok: true,
                action: "category",
                updatedCount: productIds.length,
                categoryLabel: [category.parent?.name, category.name]
                    .filter(Boolean)
                    .join(" → "),
            });
        }

        const linkedOrderItemsCount = await prisma.orderItem.count({
            where: {
                productId: {
                    in: productIds,
                },
            },
        });

        if (linkedOrderItemsCount > 0) {
            return NextResponse.json(
                {
                    error:
                        "Some selected products are already linked with orders, so they cannot be deleted.",
                },
                { status: 409 },
            );
        }

        const products = await prisma.product.findMany({
            where: {
                id: { in: productIds },
            },
            include: {
                images: true,
                variants: {
                    include: {
                        images: true,
                    },
                },
            },
        });

        if (!products.length) {
            return NextResponse.json(
                { error: "No matching products found." },
                { status: 404 },
            );
        }

        await prisma.product.deleteMany({
            where: {
                id: { in: productIds },
            },
        });

        const urlsToDelete = products.flatMap((product) => [
            ...product.images.map((img) => img.url),
            ...product.variants.flatMap((variant) =>
                variant.images.map((img) => img.url),
            ),
        ]);

        if (urlsToDelete.length) {
            await deleteLocalUploadsByUrls(urlsToDelete);
        }

        return NextResponse.json({
            ok: true,
            action: "delete",
            deletedCount: products.length,
        });
    } catch (error) {
        console.error("Bulk product action failed:", error);

        return NextResponse.json(
            { error: "Bulk action failed. Please try again." },
            { status: 500 },
        );
    }
}
