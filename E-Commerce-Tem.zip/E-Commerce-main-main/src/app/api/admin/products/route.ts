import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify, makeSku } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";
import { normalizeCategoryIds } from "@/lib/product-category-links";

const variantSchema = z.object({
  id: z.string().optional(),
  type: z.string().min(1),
  value: z.string().min(1),
  priceDiff: z.number().int().default(0),
  investedAmount: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0).default(0),
  images: z.array(z.string().min(1)).default([]),
});

const createSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional().nullable(),
  youtubeUrl: z.string().trim().url().optional().nullable().or(z.literal("")),
  price: z.number().int().min(0),
  offerPrice: z.number().int().min(0).optional().nullable(),
  investedAmount: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0).default(0),
  categoryIds: z.array(z.string()).min(1),
  isFeatured: z.boolean().optional(),
  isActive: z.boolean().optional(),
  images: z.array(z.string().min(1)).default([]),
  variants: z.array(variantSchema).default([]),
});

export async function GET() {
  const items = await prisma.product.findMany({
    include: {
      category: {
        include: {
          parent: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      },
      categories: {
        include: {
          category: {
            include: {
              parent: {
                select: {
                  id: true,
                  name: true,
                  slug: true,
                },
              },
            },
          },
        },
        orderBy: { createdAt: "asc" },
      },
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid" }, { status: 400 });
  }

  const data = parsed.data;
  const categoryIds = normalizeCategoryIds(data.categoryIds);

  if (!categoryIds.length) {
    return NextResponse.json(
      { error: "At least one category is required" },
      { status: 400 },
    );
  }

  const count = await prisma.category.count({
    where: {
      id: { in: categoryIds },
      isActive: true,
    },
  });

  if (count !== categoryIds.length) {
    return NextResponse.json(
      { error: "One or more categories are invalid" },
      { status: 400 },
    );
  }

  const primaryCategoryId = categoryIds[0];

  const slugBase = slugify(data.name);
  let slug = slugBase;
  let i = 1;

  while (await prisma.product.findUnique({ where: { slug } })) {
    slug = `${slugBase}-${i++}`;
  }

  let sku = makeSku("RHC");
  while (await prisma.product.findUnique({ where: { sku } })) {
    sku = makeSku("RHC");
  }

  const created = await prisma.product.create({
    data: {
      name: data.name,
      slug,
      description: data.description ?? null,
      youtubeUrl: data.youtubeUrl?.trim() || null,
      price: data.price,
      offerPrice: data.offerPrice ?? null,
      investedAmount: data.investedAmount ?? null,
      stock: data.stock,
      sku,
      categoryId: primaryCategoryId,
      isFeatured: data.isFeatured ?? false,
      isActive: data.isActive ?? true,

      categories: {
        create: categoryIds.map((categoryId) => ({
          categoryId,
        })),
      },

      images: data.images.length
        ? {
          create: data.images.map((url, idx) => ({
            url,
            sortOrder: idx,
          })),
        }
        : undefined,

      variants: data.variants.length
        ? {
          create: data.variants.map((v) => ({
            type: v.type,
            value: v.value,
            priceDiff: v.priceDiff,
            investedAmount: v.investedAmount ?? null,
            stock: v.stock,
            images: v.images.length
              ? {
                create: v.images.map((url, idx) => ({
                  url,
                  sortOrder: idx,
                })),
              }
              : undefined,
          })),
        }
        : undefined,
    },
    include: {
      category: {
        include: {
          parent: {
            select: { id: true, name: true, slug: true },
          },
        },
      },
      categories: {
        include: {
          category: {
            include: {
              parent: {
                select: { id: true, name: true, slug: true },
              },
            },
          },
        },
        orderBy: { createdAt: "asc" },
      },
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  return NextResponse.json(created, { status: 201 });
}
