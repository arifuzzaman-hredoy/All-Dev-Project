import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

type Ctx = {
  params: Promise<{ id: string }> | { id: string };
};

const MAX_REVIEW_IMAGES = 5;

const reviewSchema = z.object({
  productId: z.string().min(1),
  authorName: z.string().trim().min(1).max(80).optional().nullable(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().trim().max(2000).optional().nullable(),
  imageUrls: z.array(z.string().trim().min(1)).default([]),
  isVerifiedPurchase: z.boolean().optional(),
});

function normalizeImageUrls(urls: string[]) {
  return urls
    .map((url) => url.trim())
    .filter(Boolean)
    .slice(0, MAX_REVIEW_IMAGES);
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = params.id;

  if (!id) {
    return NextResponse.json({ error: "Missing review id" }, { status: 400 });
  }

  const body = await req.json().catch(() => null);
  const parsed = reviewSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid review data" }, { status: 400 });
  }

  const data = parsed.data;
  const product = await prisma.product.findUnique({
    where: { id: data.productId },
    select: { id: true },
  });

  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  await prisma.review.update({
    where: { id },
    data: {
      productId: data.productId,
      authorName: data.authorName?.trim() || "Customer",
      rating: data.rating,
      comment: data.comment?.trim() || null,
      imageUrls: normalizeImageUrls(data.imageUrls),
      isVerifiedPurchase: data.isVerifiedPurchase ?? false,
    },
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = params.id;

  if (!id) {
    return NextResponse.json({ error: "Missing review id" }, { status: 400 });
  }

  await prisma.review.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
