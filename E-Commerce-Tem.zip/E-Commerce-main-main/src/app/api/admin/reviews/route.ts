import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

const MAX_REVIEW_IMAGES = 5;

const reviewSchema = z.object({
  productId: z.string().min(1),
  authorName: z.string().trim().min(1).max(80).optional().nullable(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().trim().max(2000).optional().nullable(),
  imageUrls: z.array(z.string().trim().min(1)).default([]),
  isVerifiedPurchase: z.boolean().optional(),
});

function normalizeImageUrls(urls: string[]) {
  return urls
    .map((url) => url.trim())
    .filter(Boolean)
    .slice(0, MAX_REVIEW_IMAGES);
}

export async function GET(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const reviews = await prisma.review.findMany({
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
      product: {
        select: {
          id: true,
          name: true,
          slug: true,
          images: {
            orderBy: { sortOrder: "asc" },
            take: 1,
            select: { url: true },
          },
        },
      },
    },
  });

  return NextResponse.json(
    reviews.map((review) => ({
      id: review.id,
      productId: review.productId,
      rating: review.rating,
      comment: review.comment,
      imageUrls: review.imageUrls,
      isVerifiedPurchase: review.isVerifiedPurchase,
      authorName: review.authorName,
      createdAt: review.createdAt.toISOString(),
      user: review.user,
      product: {
        id: review.product.id,
        name: review.product.name,
        slug: review.product.slug,
        imageUrl: review.product.images[0]?.url ?? null,
      },
    })),
  );
}

export async function POST(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = reviewSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid review data" }, { status: 400 });
  }

  const data = parsed.data;
  const product = await prisma.product.findUnique({
    where: { id: data.productId },
    select: { id: true },
  });

  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const review = await prisma.review.create({
    data: {
      productId: data.productId,
      userId: null,
      authorName: data.authorName?.trim() || "Customer",
      rating: data.rating,
      comment: data.comment?.trim() || null,
      imageUrls: normalizeImageUrls(data.imageUrls),
      isVerifiedPurchase: data.isVerifiedPurchase ?? false,
    },
  });

  return NextResponse.json({ ok: true, id: review.id }, { status: 201 });
}
