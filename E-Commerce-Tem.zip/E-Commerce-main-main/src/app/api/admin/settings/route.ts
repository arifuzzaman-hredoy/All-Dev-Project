import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { normalizeShippingRules } from "@/lib/pricing";
import {
  DEFAULT_BANGLA_FONT,
  DEFAULT_SITE_FONT,
  resolveBanglaFont,
  resolveSiteFont,
} from "@/lib/site-fonts";

export const dynamic = "force-dynamic";

function asString(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function asNullableString(value: unknown): string | null | undefined {
  if (value === null) return null;
  if (typeof value === "string") return value.trim() || null;
  return undefined;
}

function asNumber(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value)
    ? value
    : undefined;
}

function asBoolean(value: unknown): boolean | undefined {
  return typeof value === "boolean" ? value : undefined;
}

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const settings = await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {},
    create: { id: "default" },
  });

  return NextResponse.json({ settings });
}

export async function PUT(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const shippingRules = normalizeShippingRules(body.shippingRules);

  const settings = await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {
      storeName: asString(body.storeName),
      logoUrl: asString(body.logoUrl),
      siteFontFamily: resolveSiteFont(body.siteFontFamily).value,
      banglaFontFamily: resolveBanglaFont(body.banglaFontFamily).value,
      taxRate: asNumber(body.taxRate),
      shippingInsideDhaka: asNumber(body.shippingInsideDhaka),
      shippingRangpur: asNumber(body.shippingRangpur),
      shippingOutsideDhaka: asNumber(body.shippingOutsideDhaka),
      shippingFreeOver: asNumber(body.shippingFreeOver),
      shippingDefaultCharge: asNumber(body.shippingDefaultCharge),
      shippingRules,
      codEnabled: asBoolean(body.codEnabled),
      onlineEnabled: asBoolean(body.onlineEnabled),
      manualPaymentEnabled: asBoolean(body.manualPaymentEnabled),
      manualBkashNumber: asNullableString(body.manualBkashNumber),
      manualBkashImageUrl: asNullableString(body.manualBkashImageUrl),
      manualNagadNumber: asNullableString(body.manualNagadNumber),
      manualNagadImageUrl: asNullableString(body.manualNagadImageUrl),
      manualRocketNumber: asNullableString(body.manualRocketNumber),
      manualRocketImageUrl: asNullableString(body.manualRocketImageUrl),
      lowStockThreshold: asNumber(body.lowStockThreshold),

      facebookUrl: asString(body.facebookUrl),
      instagramUrl: asString(body.instagramUrl),
      youtubeUrl: asString(body.youtubeUrl),
      tiktokUrl: asString(body.tiktokUrl),
      whatsappUrl: asString(body.whatsappUrl),

      returnRefundPolicy: asString(body.returnRefundPolicy),
      aboutUs: asString(body.aboutUs),
      aboutFaqs: Array.isArray(body.aboutFaqs) ? body.aboutFaqs : undefined,
      privacyPolicy: asString(body.privacyPolicy),
      termsConditions: asString(body.termsConditions),
    },
    create: {
      id: "default",
      storeName: asString(body.storeName) ?? "NexoraMart",
      logoUrl: asString(body.logoUrl) ?? "",
      siteFontFamily: resolveSiteFont(body.siteFontFamily ?? DEFAULT_SITE_FONT)
        .value,
      banglaFontFamily: resolveBanglaFont(
        body.banglaFontFamily ?? DEFAULT_BANGLA_FONT,
      ).value,
      taxRate: asNumber(body.taxRate) ?? 0,
      shippingInsideDhaka: asNumber(body.shippingInsideDhaka) ?? 0,
      shippingRangpur: asNumber(body.shippingRangpur) ?? 0,
      shippingOutsideDhaka: asNumber(body.shippingOutsideDhaka) ?? 0,
      shippingFreeOver: asNumber(body.shippingFreeOver) ?? 0,
      shippingDefaultCharge: asNumber(body.shippingDefaultCharge) ?? 0,
      shippingRules,
      codEnabled: asBoolean(body.codEnabled) ?? true,
      onlineEnabled: asBoolean(body.onlineEnabled) ?? false,
      manualPaymentEnabled: asBoolean(body.manualPaymentEnabled) ?? false,
      manualBkashNumber: asNullableString(body.manualBkashNumber) ?? null,
      manualBkashImageUrl: asNullableString(body.manualBkashImageUrl) ?? null,
      manualNagadNumber: asNullableString(body.manualNagadNumber) ?? null,
      manualNagadImageUrl: asNullableString(body.manualNagadImageUrl) ?? null,
      manualRocketNumber: asNullableString(body.manualRocketNumber) ?? null,
      manualRocketImageUrl: asNullableString(body.manualRocketImageUrl) ?? null,
      lowStockThreshold: asNumber(body.lowStockThreshold) ?? 5,

      facebookUrl: asString(body.facebookUrl) ?? "",
      instagramUrl: asString(body.instagramUrl) ?? "",
      youtubeUrl: asString(body.youtubeUrl) ?? "",
      tiktokUrl: asString(body.tiktokUrl) ?? "",
      whatsappUrl: asString(body.whatsappUrl) ?? "",

      returnRefundPolicy: asString(body.returnRefundPolicy) ?? "",
      aboutUs: asString(body.aboutUs) ?? "",
      aboutFaqs: Array.isArray(body.aboutFaqs) ? body.aboutFaqs : [],
      privacyPolicy: asString(body.privacyPolicy) ?? "",
      termsConditions: asString(body.termsConditions) ?? "",
    },
  });

  return NextResponse.json({ settings });
}
