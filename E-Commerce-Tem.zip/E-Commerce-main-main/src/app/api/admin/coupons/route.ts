import { NextRequest, NextResponse } from "next/server";
import { CouponScope, CouponType } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { normalizeCouponCode } from "@/lib/services/coupon-service";

function uniqueStrings(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map((v) => String(v ?? "").trim()).filter(Boolean))];
}

function toNullableInt(value: unknown): number | null | undefined {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;

  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return undefined;
  return Math.floor(n);
}

function toScope(value: unknown): CouponScope {
  return value === "PRODUCTS" || value === "CATEGORIES" || value === "ORDER"
    ? value
    : "ORDER";
}

function toType(value: unknown): CouponType {
  return value === "FIXED" || value === "PERCENT" ? value : "PERCENT";
}

function parseCouponDate(value: unknown, boundary: "start" | "end"): Date | null {
  if (value === null || value === undefined || value === "") return null;

  const raw = String(value).trim();
  const dateOnlyMatch = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);

  if (dateOnlyMatch) {
    const year = Number(dateOnlyMatch[1]);
    const month = Number(dateOnlyMatch[2]);
    const day = Number(dateOnlyMatch[3]);

    return boundary === "start"
      ? new Date(year, month - 1, day, 0, 0, 0, 0)
      : new Date(year, month - 1, day, 23, 59, 59, 999);
  }

  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return null;

  return parsed;
}

function validatePayload(body: any): string | null {
  const code = String(body.code ?? "").trim().toUpperCase();
  if (!code) return "Coupon code is required";
  if (code.length < 3) return "Coupon code is too short";

  const value = Number(body.value);
  if (!Number.isFinite(value) || value <= 0) return "Coupon value must be greater than 0";

  const type = toType(body.type);
  if (type === "PERCENT" && value > 100) return "Percent coupon cannot exceed 100";

  const minSubtotal = Number(body.minSubtotal ?? 0);
  if (!Number.isFinite(minSubtotal) || minSubtotal < 0) {
    return "Minimum subtotal cannot be negative";
  }

  const maxDiscount = toNullableInt(body.maxDiscount);
  if (maxDiscount !== null && maxDiscount !== undefined && maxDiscount < 0) {
    return "Max discount cannot be negative";
  }

  const usageLimit = toNullableInt(body.usageLimit);
  if (usageLimit !== null && usageLimit !== undefined && usageLimit < 1) {
    return "Usage limit must be at least 1";
  }

  const scope = toScope(body.scope);
  const productIds = uniqueStrings(body.productIds);
  const categoryIds = uniqueStrings(body.categoryIds);

  if (scope === "PRODUCTS" && productIds.length === 0) {
    return "Select at least one product";
  }

  if (scope === "CATEGORIES" && categoryIds.length === 0) {
    return "Select at least one category";
  }

  if (body.startsAt && body.endsAt) {
    const s = parseCouponDate(body.startsAt, "start");
    const e = parseCouponDate(body.endsAt, "end");

    if (!s || !e) {
      return "Invalid date range";
    }

    if (s > e) return "Start date must be before end date";
  }

  return null;
}

function buildCouponData(body: any) {
  const scope = toScope(body.scope);

  return {
    code: String(body.code).toUpperCase().trim(),
    description: body.description ? String(body.description).trim() : null,
    scope,
    productIds: scope === "PRODUCTS" ? uniqueStrings(body.productIds) : [],
    categoryIds: scope === "CATEGORIES" ? uniqueStrings(body.categoryIds) : [],
    type: toType(body.type),
    value: Math.floor(Number(body.value)),
    minSubtotal: Math.max(0, Math.floor(Number(body.minSubtotal ?? 0))),
    maxDiscount: toNullableInt(body.maxDiscount) ?? null,
    startsAt: parseCouponDate(body.startsAt, "start"),
    endsAt: parseCouponDate(body.endsAt, "end"),
    usageLimit: toNullableInt(body.usageLimit) ?? null,
    isActive: typeof body.isActive === "boolean" ? body.isActive : true,
  };
}

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const [coupons, orderCounts] = await Promise.all([
    prisma.coupon.findMany({
      orderBy: { createdAt: "desc" },
    }),
    prisma.order.groupBy({
      by: ["couponCode"],
      where: {
        couponCode: {
          not: null,
        },
      },
      _count: {
        _all: true,
      },
    }),
  ]);

  const countByCode = new Map<string, number>();
  for (const row of orderCounts) {
    const code = normalizeCouponCode(row.couponCode);
    if (!code) continue;
    countByCode.set(code, (countByCode.get(code) ?? 0) + row._count._all);
  }

  return NextResponse.json({
    coupons: coupons.map((coupon) => ({
      ...coupon,
      orderCount: countByCode.get(normalizeCouponCode(coupon.code)) ?? 0,
    })),
  });
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const error = validatePayload(body);
  if (error) {
    return NextResponse.json({ message: error }, { status: 400 });
  }

  const coupon = await prisma.coupon.create({
    data: buildCouponData(body),
  });

  return NextResponse.json({ coupon });
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();

  if (!body?.id) {
    return NextResponse.json({ message: "Coupon id is required" }, { status: 400 });
  }

  const mergedForValidation = {
    ...(await prisma.coupon.findUnique({ where: { id: body.id } })),
    ...body,
  };

  const error = validatePayload(mergedForValidation);
  if (error) {
    return NextResponse.json({ message: error }, { status: 400 });
  }

  const coupon = await prisma.coupon.update({
    where: { id: body.id },
    data: buildCouponData(mergedForValidation),
  });

  return NextResponse.json({ coupon });
}

export async function DELETE(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ message: "Missing id" }, { status: 400 });
  }

  await prisma.coupon.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
