import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Role, Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

type ErrorResponse = { error: string };

type UserItem = {
  id: string;
  name: string | null;
  email: string;
  role: Role;
  blocked: boolean;
  createdAt: string;
  ordersCount: number;
};

type Response = {
  items: UserItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function num(v: string | null, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

type AuthUser = { id: string; role: Role; email: string };

async function requireStaffOrAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  if (user.role !== "ADMIN" && user.role !== "STAFF") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireStaffOrAdminDb();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") || "").trim();
  const role = (searchParams.get("role") || "").trim();

  const page = Math.max(1, num(searchParams.get("page"), 1));
  const take = clamp(num(searchParams.get("take"), 20), 10, 50);
  const skip = (page - 1) * take;

  const and: Prisma.UserWhereInput[] = [];

  if (q) {
    and.push({
      OR: [
        { email: { contains: q, mode: "insensitive" } },
        { name: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (role && Object.values(Role).includes(role as Role)) {
    and.push({ role: role as Role });
  }

  const where: Prisma.UserWhereInput = and.length ? { AND: and } : {};

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        blocked: true,
        createdAt: true,
        _count: { select: { orders: true } },
      },
    }),
    prisma.user.count({ where }),
  ]);

  return NextResponse.json({
    items: users.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      blocked: u.blocked,
      createdAt: u.createdAt.toISOString(),
      ordersCount: u._count.orders,
    })),
    total,
    page,
    take,
    pages: Math.max(1, Math.ceil(total / take)),
  });
}
