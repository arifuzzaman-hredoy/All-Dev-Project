import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

type ErrorResponse = { error: string };

type AuthUser = { id: string; role: Role; email: string };

async function requireAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user || user.role !== "ADMIN") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Admin only" }, { status: 403 }),
    };
  }

  return { ok: true, user };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

type PatchBody = {
  blocked?: boolean;
  role?: Role;
};

export async function PATCH(
  req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as PatchBody;

  const data: PatchBody = {};

  if (typeof body.blocked === "boolean") data.blocked = body.blocked;
  if (body.role && Object.values(Role).includes(body.role))
    data.role = body.role;

  await prisma.user.update({ where: { id }, data });

  return NextResponse.json({ ok: true });
}
