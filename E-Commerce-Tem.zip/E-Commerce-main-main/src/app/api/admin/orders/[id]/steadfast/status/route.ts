import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { isSteadfastEnabled } from "@/lib/couriers/steadfast";
import { syncSteadfastOrderById } from "@/lib/couriers/steadfast-sync";

async function requireAdminOrStaff() {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false as const,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { role: true },
  });

  if (!user || (user.role !== Role.ADMIN && user.role !== Role.STAFF)) {
    return {
      ok: false as const,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true as const };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export async function POST(
  _req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
) {
  const gate = await requireAdminOrStaff();
  if (!gate.ok) return gate.res;

  if (!isSteadfastEnabled()) {
    return NextResponse.json(
      { error: "Steadfast integration is disabled" },
      { status: 400 },
    );
  }

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid order id" }, { status: 400 });
  }

  const result = await syncSteadfastOrderById(id);

  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  console.log(result);

  return NextResponse.json({
    ok: true,
    orderId: result.orderId,
    deliveryStatus: result.deliveryStatus,
    mappedStatus: result.mappedStatus,
    trackingId: result.trackingId,
    changed: result.changed,
  });
}
