import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import { syncSteadfastOrderStatus } from "@/lib/services/steadfast-order-sync";

type Ctx = {
    params: Promise<{ id: string }> | { id: string };
};

export async function POST(req: NextRequest, ctx: Ctx) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const id = params.id;

    if (!id) {
        return NextResponse.json({ error: "Missing order id" }, { status: 400 });
    }

    try {
        const result = await syncSteadfastOrderStatus(id);

        if (!result.ok) {
            return NextResponse.json({ error: result.error }, { status: 404 });
        }

        return NextResponse.json(result);
    } catch (error) {
        return NextResponse.json(
            {
                error:
                    error instanceof Error
                        ? error.message
                        : "Failed to sync Steadfast status",
            },
            { status: 500 },
        );
    }
}