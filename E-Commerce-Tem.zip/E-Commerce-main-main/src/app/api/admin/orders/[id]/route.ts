import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  OrderStatus,
  PaymentStatus,
  PaymentMethod,
  Role,
  Prisma,
} from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { notifyOrderUpdated } from "@/lib/notifications";
import {
  buildSteadfastTrackingUrl,
  getSteadfastMeta,
} from "@/lib/couriers/steadfast";
import { attachEffectivePrices } from "@/lib/product-discounts";
type ErrorResponse = { error: string };

type OrderDetailsResponse = {
  id: string;
  publicOrderId: string | null;
  createdAt: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  name: string;
  phone: string;
  email: string | null;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  couponCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  courierName: string | null;
  trackingId: string | null;
  steadfastConsignmentId: string | null;
  steadfastTrackingCode: string | null;
  steadfastTrackingUrl: string | null;
  manualPayment: {
    provider: string | null;
    paymentNumber: string | null;
    senderPhone: string | null;
    submittedAmount: number | null;
    submittedAt: string | null;
    transactionId: string | null;
  } | null;
  items: Array<{
    id: string;
    productId: string | null;
    variantId: string | null;
    productName: string;
    sku: string;
    unitPrice: number;
    qty: number;
    lineTotal: number;
  }>;
};

type AuthUser = { id: string; role: Role; email: string };

async function requireAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "STAFF")) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function asObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function asString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function asNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function toNonNegativeInt(value: unknown, fallback = 0): number {
  const n = asNumber(value);
  return n === null ? fallback : Math.max(0, Math.floor(n));
}

function safeNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;

  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwarePrice(params: {
  productPrice: number;
  productOfferPrice: number | null;
  variantPriceDiff: number | null;
}) {
  const baseOriginalPrice = safeNumber(params.productPrice, 0);

  const baseDiscountedPrice = safeNumber(
    params.productOfferPrice ?? params.productPrice,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(params.variantPriceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  return {
    comparePrice,
    unitPrice,
  };
}

type EditableItemInput = {
  mode?: "catalog" | "custom";
  productId?: string | null;
  variantId?: string | null;
  customName?: string;
  customSku?: string | null;
  unitPrice: number;
  qty: number;
};

async function restockOrderItems(
  tx: Prisma.TransactionClient,
  items: Array<{
    productId: string | null;
    variantId: string | null;
    qty: number;
  }>,
) {
  for (const item of items) {
    if (!item.productId) continue;

    if (item.variantId) {
      await tx.productVariant.updateMany({
        where: {
          id: item.variantId,
          productId: item.productId,
        },
        data: {
          stock: { increment: item.qty },
        },
      });
    } else {
      await tx.product.updateMany({
        where: {
          id: item.productId,
        },
        data: {
          stock: { increment: item.qty },
        },
      });
    }
  }
}

async function deductOrderItems(
  tx: Prisma.TransactionClient,
  items: Array<{
    productId: string | null;
    variantId: string | null;
    qty: number;
    productName: string;
  }>,
) {
  for (const item of items) {
    if (!item.productId) continue;

    if (item.variantId) {
      const updated = await tx.productVariant.updateMany({
        where: {
          id: item.variantId,
          productId: item.productId,
          stock: { gte: item.qty },
        },
        data: {
          stock: { decrement: item.qty },
        },
      });

      if (updated.count === 0) {
        throw new Error(`Insufficient stock for ${item.productName}`);
      }
    } else {
      const updated = await tx.product.updateMany({
        where: {
          id: item.productId,
          stock: { gte: item.qty },
          isActive: true,
        },
        data: {
          stock: { decrement: item.qty },
        },
      });

      if (updated.count === 0) {
        throw new Error(`Insufficient stock for ${item.productName}`);
      }
    }
  }
}

export async function GET(
  _req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<OrderDetailsResponse | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const [order, settings] = await Promise.all([
    prisma.order.findUnique({
      where: { id },
      include: { items: true },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        manualBkashNumber: true,
        manualNagadNumber: true,
        manualRocketNumber: true,
      },
    }),
  ]);

  if (!order) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const steadfastMeta = getSteadfastMeta(order.paymentMeta);
  const steadfastTrackingUrl = buildSteadfastTrackingUrl({
    consignmentId: steadfastMeta.consignmentId,
    trackingCode: steadfastMeta.trackingCode,
    trackingId: order.trackingId,
  });

  const paymentMeta = asObject(order.paymentMeta);
  const manualPaymentMeta = asObject(paymentMeta?.manualPayment);

  const manualProvider = asString(manualPaymentMeta?.provider);
  const manualPaymentNumber =
    manualProvider === "BKASH"
      ? (settings?.manualBkashNumber ?? null)
      : manualProvider === "NAGAD"
        ? (settings?.manualNagadNumber ?? null)
        : manualProvider === "ROCKET"
          ? (settings?.manualRocketNumber ?? null)
          : null;

  const manualPayment =
    order.paymentMethod === "MANUAL" || manualPaymentMeta
      ? {
          provider: manualProvider,
          paymentNumber: manualPaymentNumber,
          senderPhone: asString(manualPaymentMeta?.senderPhone),
          submittedAmount: asNumber(manualPaymentMeta?.submittedAmount),
          submittedAt: asString(manualPaymentMeta?.submittedAt),
          transactionId: asString(order.transactionId),
        }
      : null;

  return NextResponse.json({
    id: order.id,
    publicOrderId: order.publicOrderId ?? null,
    createdAt: order.createdAt.toISOString(),
    status: order.status,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod,
    name: order.name,
    phone: order.phone,
    email: order.email ?? null,
    addressLine1: order.addressLine1,
    addressLine2: order.addressLine2 ?? null,
    city: order.city,
    area: order.area ?? null,
    note: order.note ?? null,
    couponCode: order.couponCode ?? null,
    subtotal: order.subtotal,
    discount: order.discount,
    shipping: order.shipping,
    tax: order.tax ?? 0,
    total: order.total,
    courierName: order.courierName ?? null,
    trackingId: order.trackingId ?? null,
    steadfastConsignmentId: steadfastMeta.consignmentId,
    steadfastTrackingCode: steadfastMeta.trackingCode,
    steadfastTrackingUrl,
    manualPayment,
    items: order.items.map((it) => ({
      id: it.id,
      productId: it.productId ?? null,
      variantId: it.variantId ?? null,
      productName: it.productName,
      sku: it.sku,
      unitPrice: it.unitPrice,
      qty: it.qty,
      lineTotal: it.lineTotal,
    })),
  });
}

type PatchBody = {
  status?: OrderStatus;
  paymentStatus?: PaymentStatus;
  courierName?: string | null;
  trackingId?: string | null;
  name?: string;
  email?: string | null;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string | null;
  city?: string;
  area?: string | null;
  note?: string | null;
  shipping?: number;
  tax?: number;
  discount?: number;
  items?: EditableItemInput[];
};

export async function PATCH(
  req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const existing = await prisma.order.findUnique({
    where: { id },
    include: {
      items: {
        select: {
          id: true,
          productId: true,
          variantId: true,
          qty: true,
        },
      },
    },
  });

  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as PatchBody;

  const nextStatus =
    body.status && Object.values(OrderStatus).includes(body.status)
      ? body.status
      : existing.status;

  const nextPaymentStatus =
    body.paymentStatus &&
    Object.values(PaymentStatus).includes(body.paymentStatus)
      ? body.paymentStatus
      : existing.paymentStatus;

  const nextCourierName =
    body.courierName === null
      ? null
      : typeof body.courierName === "string"
        ? body.courierName.trim() || null
        : existing.courierName;

  const nextTrackingId =
    body.trackingId === null
      ? null
      : typeof body.trackingId === "string"
        ? body.trackingId.trim() || null
        : existing.trackingId;

  const nextName =
    typeof body.name === "string" && body.name.trim()
      ? body.name.trim()
      : existing.name;

  const nextEmail =
    body.email === null
      ? null
      : typeof body.email === "string"
        ? body.email.trim() || null
        : existing.email;

  const nextPhone =
    typeof body.phone === "string" && body.phone.trim()
      ? body.phone.trim()
      : existing.phone;

  const nextAddressLine1 =
    typeof body.addressLine1 === "string" && body.addressLine1.trim()
      ? body.addressLine1.trim()
      : existing.addressLine1;

  const nextAddressLine2 =
    body.addressLine2 === null
      ? null
      : typeof body.addressLine2 === "string"
        ? body.addressLine2.trim() || null
        : existing.addressLine2;

  const nextCity =
    typeof body.city === "string" && body.city.trim()
      ? body.city.trim()
      : existing.city;

  const nextArea =
    body.area === null
      ? null
      : typeof body.area === "string"
        ? body.area.trim() || null
        : existing.area;

  const nextNote =
    body.note === null
      ? null
      : typeof body.note === "string"
        ? body.note.trim() || null
        : existing.note;

  const incomingItems = Array.isArray(body.items) ? body.items : null;
  if (incomingItems && incomingItems.length === 0) {
    return NextResponse.json(
      { error: "At least one item is required" },
      { status: 400 },
    );
  }

  const normalizedItems =
    incomingItems?.map((item) => {
      const mode = item.mode === "custom" ? "custom" : "catalog";

      return {
        mode,
        productId:
          typeof item.productId === "string" && item.productId.trim()
            ? item.productId
            : null,
        variantId:
          typeof item.variantId === "string" && item.variantId.trim()
            ? item.variantId
            : null,
        customName:
          typeof item.customName === "string" ? item.customName.trim() : "",
        customSku:
          typeof item.customSku === "string"
            ? item.customSku.trim() || null
            : null,
        unitPrice: toNonNegativeInt(item.unitPrice, 0),
        qty: Math.max(1, toNonNegativeInt(item.qty, 1)),
      };
    }) ?? null;

  const finalItemsInput =
    normalizedItems ??
    existing.items.map((item) => ({
      mode: item.productId ? "catalog" : "custom",
      productId: item.productId ?? null,
      variantId: item.variantId ?? null,
      customName: "",
      customSku: null,
      unitPrice: 0,
      qty: item.qty,
    }));

  if (
    finalItemsInput.some(
      (item) =>
        item.mode === "catalog" && (!item.productId || !item.productId.trim()),
    )
  ) {
    return NextResponse.json(
      { error: "Every catalog item must have a selected product" },
      { status: 400 },
    );
  }

  if (
    finalItemsInput.some(
      (item) =>
        item.mode === "custom" && (!item.customName || !item.customName.trim()),
    )
  ) {
    return NextResponse.json(
      { error: "Every custom item must have a product name" },
      { status: 400 },
    );
  }

  const productIds = [
    ...new Set(
      finalItemsInput
        .map((item) => item.productId)
        .filter((value): value is string => Boolean(value)),
    ),
  ];

  const variantIds = [
    ...new Set(
      finalItemsInput
        .map((item) => item.variantId)
        .filter((value): value is string => Boolean(value)),
    ),
  ];

  const [products, variants] = await Promise.all([
    prisma.product.findMany({
      where: {
        id: { in: productIds },
      },
      select: {
        id: true,
        name: true,
        sku: true,
        price: true,
        offerPrice: true,
        stock: true,
        isActive: true,
        categoryId: true,
      },
    }),
    prisma.productVariant.findMany({
      where: {
        id: { in: variantIds },
      },
      select: {
        id: true,
        productId: true,
        type: true,
        value: true,
        priceDiff: true,
        stock: true,
      },
    }),
  ]);

  const resolvedProducts = await attachEffectivePrices(products);

  const productMap = new Map(resolvedProducts.map((p) => [p.id, p]));
  const variantMap = new Map(variants.map((v) => [v.id, v]));

  const computedItems = finalItemsInput.map((item) => {
    if (item.mode === "custom") {
      const productName = item.customName.trim();
      const sku = item.customSku?.trim() || "CUSTOM";
      const lineTotal = item.unitPrice * item.qty;

      return {
        productId: null,
        variantId: null,
        productName,
        sku,
        unitPrice: item.unitPrice,
        qty: item.qty,
        lineTotal,
      };
    }

    const product = productMap.get(item.productId as string);
    if (!product) {
      throw new Error("Selected product not found");
    }

    const variant = item.variantId ? variantMap.get(item.variantId) : null;
    if (item.variantId && !variant) {
      throw new Error(`Variant not found for ${product.name}`);
    }

    if (variant && variant.productId !== product.id) {
      throw new Error(`Variant does not belong to ${product.name}`);
    }

    const priceInfo = calculateVariantAwarePrice({
      productPrice: product.price,
      productOfferPrice: product.offerPrice,
      variantPriceDiff: variant?.priceDiff ?? 0,
    });

    const fallbackUnitPrice = priceInfo.unitPrice;

    const unitPrice =
      normalizedItems !== null ? item.unitPrice : fallbackUnitPrice;

    const lineTotal = unitPrice * item.qty;

    return {
      productId: product.id,
      variantId: variant?.id ?? null,
      productName: product.name,
      sku: product.sku,
      unitPrice,
      qty: item.qty,
      lineTotal,
    };
  });

  const subtotal = computedItems.reduce((sum, item) => sum + item.lineTotal, 0);
  const shipping =
    body.shipping !== undefined
      ? toNonNegativeInt(body.shipping, existing.shipping)
      : existing.shipping;

  const tax =
    body.tax !== undefined
      ? toNonNegativeInt(body.tax, existing.tax)
      : existing.tax;

  const discount =
    body.discount !== undefined
      ? toNonNegativeInt(body.discount, existing.discount)
      : existing.discount;

  const total = Math.max(0, subtotal - discount + shipping + tax);

  try {
    await prisma.$transaction(async (tx) => {
      if (existing.stockDeducted) {
        await restockOrderItems(
          tx,
          existing.items.map((item) => ({
            productId: item.productId ?? null,
            variantId: item.variantId ?? null,
            qty: item.qty,
          })),
        );

        await deductOrderItems(
          tx,
          computedItems.map((item) => ({
            productId: item.productId,
            variantId: item.variantId,
            qty: item.qty,
            productName: item.productName,
          })),
        );
      }

      await tx.orderItem.deleteMany({
        where: {
          orderId: existing.id,
        },
      });

      await tx.order.update({
        where: { id: existing.id },
        data: {
          status: nextStatus,
          paymentStatus: nextPaymentStatus,
          courierName: nextCourierName,
          trackingId: nextTrackingId,

          name: nextName,
          email: nextEmail,
          phone: nextPhone,
          addressLine1: nextAddressLine1,
          addressLine2: nextAddressLine2,
          city: nextCity,
          area: nextArea,
          note: nextNote,

          subtotal,
          discount,
          shipping,
          tax,
          total,

          items: {
            create: computedItems.map((item) => ({
              productId: item.productId,
              variantId: item.variantId,
              productName: item.productName,
              sku: item.sku,
              unitPrice: item.unitPrice,
              qty: item.qty,
              lineTotal: item.lineTotal,
            })),
          },
        },
      });
    });

    await notifyOrderUpdated({
      orderId: existing.id,
      previousStatus: existing.status,
      previousPaymentStatus: existing.paymentStatus,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Order update failed:", error);

    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Failed to update order",
      },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const existing = await prisma.order.findUnique({
    where: { id },
    select: {
      id: true,
      stockDeducted: true,
      items: {
        select: {
          productId: true,
          variantId: true,
          qty: true,
        },
      },
    },
  });

  if (!existing) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  try {
    await prisma.$transaction(async (tx) => {
      if (existing.stockDeducted) {
        await restockOrderItems(
          tx,
          existing.items.map((item) => ({
            productId: item.productId ?? null,
            variantId: item.variantId ?? null,
            qty: item.qty,
          })),
        );
      }

      await tx.order.delete({
        where: { id },
      });
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete order failed:", error);
    return NextResponse.json(
      { error: "Failed to delete order" },
      { status: 500 },
    );
  }
}
