import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { OrderStatus } from "@prisma/client";

type ErrorResponse = { error: string };

async function requireAdmin(): Promise<{ ok: true } | { ok: false; res: NextResponse<ErrorResponse> }> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;
  if (role !== "ADMIN" && role !== "STAFF") {
    return { ok: false, res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { ok: true };
}

function parseDate(v: string | null): Date | null {
  if (!v) return null;
  const d = new Date(v);
  return Number.isFinite(d.getTime()) ? d : null;
}

function csvEscape(v: string): string {
  // wrap in quotes if needed and escape quotes
  if (/[",\n]/.test(v)) return `"${v.replaceAll('"', '""')}"`;
  return v;
}

export async function GET(req: NextRequest): Promise<NextResponse<string | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);

  // Example: /api/admin/reports/orders-csv?from=2026-03-01&to=2026-03-03&status=PENDING
  const from = parseDate(searchParams.get("from"));
  const to = parseDate(searchParams.get("to")); // exclusive-ish (we'll add 1 day if user gave YYYY-MM-DD)
  const status = (searchParams.get("status") || "").trim();

  let statusFilter: { status?: OrderStatus } = {};
  if (status && Object.values(OrderStatus).includes(status as OrderStatus)) {
    statusFilter = { status: status as OrderStatus };
  }

  const where: Record<string, unknown> = { ...statusFilter };

  if (from) (where as { createdAt?: { gte?: Date; lt?: Date } }).createdAt = { gte: from };
  if (to) {
    const c = (where as { createdAt?: { gte?: Date; lt?: Date } }).createdAt ?? {};
    c.lt = to;
    (where as { createdAt?: { gte?: Date; lt?: Date } }).createdAt = c;
  }

  const orders = await prisma.order.findMany({
    where: where as never,
    orderBy: { createdAt: "desc" },
    include: { items: true },
    take: 5000,
  });

  const header = [
    "order_id",
    "created_at",
    "status",
    "payment_method",
    "payment_status",
    "name",
    "phone",
    "city",
    "subtotal",
    "discount",
    "shipping",
    "total",
    "coupon_code",
    "courier_name",
    "tracking_id",
    "items_count",
  ].join(",");

  const rows = orders.map((o) => {
    const cols = [
      o.id,
      o.createdAt.toISOString(),
      o.status,
      o.paymentMethod,
      o.paymentStatus,
      o.name,
      o.phone,
      o.city,
      String(o.subtotal),
      String(o.discount),
      String(o.shipping),
      String(o.total),
      o.couponCode ?? "",
      o.courierName ?? "",
      o.trackingId ?? "",
      String(o.items.length),
    ].map((x) => csvEscape(String(x)));

    return cols.join(",");
  });

  const csv = [header, ...rows].join("\n");

  return new NextResponse(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="orders.csv"`,
      "Cache-Control": "no-store",
    },
  });
}