import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { OrderStatus } from "@prisma/client";
import {
  getDefaultDeliveryCharge,
  getGrandSellAmount,
  getOrderItemsInvestedAmount,
  getRevenue,
} from "@/lib/revenue-calculation";

type ErrorResponse = { error: string };

type MonthPoint = { month: string; revenue: number; orders: number };

type BestSellingItem = {
  productId: string;
  name: string;
  slug: string;
  qty: number;
  revenue: number;
};

type RevenueRow = {
  orderId: string;
  publicOrderId: string | null;
  createdAt: Date;
  customerName: string;
  phone: string;
  status: string;
  paymentStatus: string;
  sell: number;
  shipping: number;
  deliveryCharge: number;
  grandSellAmount: number;
  investedAmount: number | null;
  revenue: number | null;
  adminNote: string | null;
};

type Response = {
  ok: true;

  totalSell: number;
  totalOrders: number;

  last30Days: { orders: number; revenue: number };
  thisMonth: { orders: number; revenue: number };

  monthly: MonthPoint[];
  bestSelling30: BestSellingItem[];

  revenueReport: {
    year: number;
    month: number;
    rows: RevenueRow[];
    totals: {
      sell: number;
      deliveryCharge: number;
      grandSellAmount: number;
      investedAmount: number;
      revenue: number;
      completedRevenueRows: number;
    };
  };
};

async function requireAdmin(): Promise<
  { ok: true } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;

  if (role !== "ADMIN" && role !== "STAFF") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true };
}

function startOfMonthUTC(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}

function addMonthsUTC(d: Date, months: number): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + months, 1));
}

function ymLabel(d: Date): string {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

function toNumber(value: string | null, fallback: number) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function getMonthRange(year: number, month: number) {
  const start = new Date(Date.UTC(year, month - 1, 1));
  const end = new Date(Date.UTC(year, month, 1));
  return { start, end };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const now = new Date();
  const last30Start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const thisMonthStart = startOfMonthUTC(now);
  const nextMonthStart = addMonthsUTC(thisMonthStart, 1);

  const year = toNumber(
    req.nextUrl.searchParams.get("year"),
    now.getUTCFullYear(),
  );

  const month = toNumber(
    req.nextUrl.searchParams.get("month"),
    now.getUTCMonth() + 1,
  );

  const { start, end } = getMonthRange(year, month);

  const monthStarts: Date[] = [];
  for (let i = 5; i >= 0; i--) {
    monthStarts.push(addMonthsUTC(thisMonthStart, -i));
  }

  const statusFilter = { not: OrderStatus.CANCELLED };

  const [allAgg, agg30, aggThisMonth, revenueOrders] = await Promise.all([
    prisma.order.aggregate({
      where: { status: statusFilter },
      _count: { id: true },
      _sum: { total: true },
    }),

    prisma.order.aggregate({
      where: {
        createdAt: { gte: last30Start },
        status: statusFilter,
      },
      _count: { id: true },
      _sum: { total: true },
    }),

    prisma.order.aggregate({
      where: {
        createdAt: {
          gte: thisMonthStart,
          lt: nextMonthStart,
        },
        status: statusFilter,
      },
      _count: { id: true },
      _sum: { total: true },
    }),

    prisma.order.findMany({
      where: {
        createdAt: {
          gte: start,
          lt: end,
        },
        status: statusFilter,
      },
      orderBy: {
        createdAt: "desc",
      },
      select: {
        id: true,
        publicOrderId: true,
        createdAt: true,
        name: true,
        phone: true,
        total: true,
        shipping: true,
        status: true,
        paymentStatus: true,
        revenueRecord: {
          select: {
            deliveryCharge: true,
            investedAmount: true,
            adminNote: true,
          },
        },
        items: {
          select: {
            qty: true,
            variant: {
              select: {
                investedAmount: true,
              },
            },
            product: {
              select: {
                investedAmount: true,
              },
            },
          },
        },
      },
    }),
  ]);

  const monthly: MonthPoint[] = [];
  for (const startMonth of monthStarts) {
    const endMonth = addMonthsUTC(startMonth, 1);

    const a = await prisma.order.aggregate({
      where: {
        createdAt: {
          gte: startMonth,
          lt: endMonth,
        },
        status: statusFilter,
      },
      _count: { id: true },
      _sum: { total: true },
    });

    monthly.push({
      month: ymLabel(startMonth),
      revenue: a._sum.total ?? 0,
      orders: a._count.id ?? 0,
    });
  }

  const grouped = await prisma.orderItem.groupBy({
    by: ["productId"],
    where: {
      order: {
        createdAt: { gte: last30Start },
        status: statusFilter,
      },
    },
    _sum: {
      qty: true,
      lineTotal: true,
    },
    orderBy: {
      _sum: {
        qty: "desc",
      },
    },
    take: 10,
  });

  const ids = grouped
    .map((g) => g.productId)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  const products = ids.length
    ? await prisma.product.findMany({
      where: {
        id: {
          in: ids,
        },
      },
      select: {
        id: true,
        name: true,
        slug: true,
      },
    })
    : [];

  const pMap = new Map(products.map((p) => [p.id, p] as const));

  const bestSelling30: BestSellingItem[] = grouped
    .filter(
      (g): g is typeof g & { productId: string } =>
        typeof g.productId === "string" && g.productId.length > 0,
    )
    .map((g) => {
      const p = pMap.get(g.productId);

      return {
        productId: g.productId,
        name: p?.name ?? "Unknown",
        slug: p?.slug ?? "",
        qty: g._sum.qty ?? 0,
        revenue: g._sum.lineTotal ?? 0,
      };
    })
    .filter((x) => x.slug);

  const rows: RevenueRow[] = revenueOrders.map((order) => {
    const sell = order.total;

    const deliveryCharge =
      order.revenueRecord?.deliveryCharge ??
      getDefaultDeliveryCharge(order.shipping);

    const investedAmount =
      order.revenueRecord?.investedAmount ??
      getOrderItemsInvestedAmount(order.items);

    const grandSellAmount = getGrandSellAmount({
      sell,
      deliveryCharge,
    });

    const revenue = getRevenue({
      sell,
      deliveryCharge,
      investedAmount,
    });

    return {
      orderId: order.id,
      publicOrderId: order.publicOrderId,
      createdAt: order.createdAt,
      customerName: order.name,
      phone: order.phone,
      status: order.status,
      paymentStatus: order.paymentStatus,
      sell,
      shipping: order.shipping,
      deliveryCharge,
      grandSellAmount,
      investedAmount,
      revenue,
      adminNote: order.revenueRecord?.adminNote ?? null,
    };
  });

  const totals = rows.reduce(
    (acc, row) => {
      acc.sell += row.sell;
      acc.deliveryCharge += row.deliveryCharge;
      acc.grandSellAmount += row.grandSellAmount;
      acc.investedAmount += row.investedAmount ?? 0;
      acc.revenue += row.revenue ?? 0;
      acc.completedRevenueRows += row.revenue === null ? 0 : 1;
      return acc;
    },
    {
      sell: 0,
      deliveryCharge: 0,
      grandSellAmount: 0,
      investedAmount: 0,
      revenue: 0,
      completedRevenueRows: 0,
    },
  );

  return NextResponse.json({
    ok: true,

    totalSell: allAgg._sum.total ?? 0,
    totalOrders: allAgg._count.id ?? 0,

    last30Days: {
      orders: agg30._count.id ?? 0,
      revenue: agg30._sum.total ?? 0,
    },

    thisMonth: {
      orders: aggThisMonth._count.id ?? 0,
      revenue: aggThisMonth._sum.total ?? 0,
    },

    monthly,
    bestSelling30,

    revenueReport: {
      year,
      month,
      rows,
      totals,
    },
  });
}
