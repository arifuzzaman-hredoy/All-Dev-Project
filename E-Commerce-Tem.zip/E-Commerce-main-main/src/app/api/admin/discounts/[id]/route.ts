import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { ProductDiscountScope } from "@prisma/client";

function toScope(value: unknown): ProductDiscountScope {
    return value === "PRODUCT" ||
        value === "CATEGORY" ||
        value === "SUBCATEGORY"
        ? value
        : "PRODUCT";
}

function toNullableDate(value: unknown): Date | null {
    if (!value) return null;
    const d = new Date(String(value));
    return Number.isNaN(d.getTime()) ? null : d;
}

function toNullableString(value: unknown): string | null {
    const v = String(value ?? "").trim();
    return v ? v : null;
}

function toPercentage(value: unknown): number | null {
    const n = Number(value);
    if (!Number.isFinite(n)) return null;
    const pct = Math.floor(n);
    if (pct < 1 || pct > 100) return null;
    return pct;
}

export async function PATCH(
    req: NextRequest,
    ctx: { params: Promise<{ id?: string }> | { id?: string } },
) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const id = params?.id;

    if (!id) {
        return NextResponse.json({ message: "Missing id" }, { status: 400 });
    }

    const body = await req.json().catch(() => null);
    const scope = toScope(body?.scope);
    const percentage = toPercentage(body?.percentage);

    if (!percentage) {
        return NextResponse.json(
            { message: "Percentage must be between 1 and 100" },
            { status: 400 },
        );
    }

    const productId = toNullableString(body?.productId);
    const categoryId = toNullableString(body?.categoryId);
    const startsAt = toNullableDate(body?.startsAt);
    const endsAt = toNullableDate(body?.endsAt);
    const note = toNullableString(body?.note);

    if (startsAt && endsAt && startsAt > endsAt) {
        return NextResponse.json(
            { message: "Start date must be before end date" },
            { status: 400 },
        );
    }

    if (scope === "PRODUCT" && !productId) {
        return NextResponse.json(
            { message: "Product is required for product discount" },
            { status: 400 },
        );
    }

    if ((scope === "CATEGORY" || scope === "SUBCATEGORY") && !categoryId) {
        return NextResponse.json(
            { message: "Category is required for category discount" },
            { status: 400 },
        );
    }

    const updated = await prisma.productDiscount.update({
        where: { id },
        data: {
            scope,
            percentage,
            productId: scope === "PRODUCT" ? productId : null,
            categoryId: scope === "PRODUCT" ? null : categoryId,
            startsAt,
            endsAt,
            note,
            isActive: typeof body?.isActive === "boolean" ? body.isActive : true,
        },
    });

    return NextResponse.json({ discount: updated });
}

export async function DELETE(
    req: NextRequest,
    ctx: { params: Promise<{ id?: string }> | { id?: string } },
) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const id = params?.id;

    if (!id) {
        return NextResponse.json({ message: "Missing id" }, { status: 400 });
    }

    await prisma.productDiscount.delete({
        where: { id },
    });

    return NextResponse.json({ ok: true });
}