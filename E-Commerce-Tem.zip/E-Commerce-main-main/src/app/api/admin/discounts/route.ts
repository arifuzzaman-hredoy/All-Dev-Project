import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { ProductDiscountScope } from "@prisma/client";

function toScope(value: unknown): ProductDiscountScope {
    return value === "PRODUCT" ||
        value === "CATEGORY" ||
        value === "SUBCATEGORY"
        ? value
        : "PRODUCT";
}

function toNullableDate(value: unknown): Date | null {
    if (!value) return null;
    const d = new Date(String(value));
    return Number.isNaN(d.getTime()) ? null : d;
}

function toNullableString(value: unknown): string | null {
    const v = String(value ?? "").trim();
    return v ? v : null;
}

function toPercentage(value: unknown): number | null {
    const n = Number(value);
    if (!Number.isFinite(n)) return null;
    const pct = Math.floor(n);
    if (pct < 1 || pct > 100) return null;
    return pct;
}

export async function GET(req: NextRequest) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    const [discounts, products, categories] = await Promise.all([
        prisma.productDiscount.findMany({
            orderBy: [{ createdAt: "desc" }],
            include: {
                product: {
                    select: {
                        id: true,
                        name: true,
                        sku: true,
                    },
                },
                category: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                        parent: {
                            select: {
                                id: true,
                                name: true,
                                slug: true,
                            },
                        },
                    },
                },
            },
        }),
        prisma.product.findMany({
            where: { isActive: true },
            orderBy: { createdAt: "desc" },
            take: 500,
            select: {
                id: true,
                name: true,
                sku: true,
                price: true,
                offerPrice: true,
            },
        }),
        prisma.category.findMany({
            where: { isActive: true },
            orderBy: [{ name: "asc" }],
            include: {
                parent: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                    },
                },
            },
        }),
    ]);

    return NextResponse.json({
        discounts,
        products,
        categories,
    });
}

export async function POST(req: NextRequest) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => null);
    const scope = toScope(body?.scope);
    const percentage = toPercentage(body?.percentage);

    if (!percentage) {
        return NextResponse.json(
            { message: "Percentage must be between 1 and 100" },
            { status: 400 },
        );
    }

    const productId = toNullableString(body?.productId);
    const categoryId = toNullableString(body?.categoryId);
    const startsAt = toNullableDate(body?.startsAt);
    const endsAt = toNullableDate(body?.endsAt);
    const note = toNullableString(body?.note);

    if (startsAt && endsAt && startsAt > endsAt) {
        return NextResponse.json(
            { message: "Start date must be before end date" },
            { status: 400 },
        );
    }

    if (scope === "PRODUCT" && !productId) {
        return NextResponse.json(
            { message: "Product is required for product discount" },
            { status: 400 },
        );
    }

    if ((scope === "CATEGORY" || scope === "SUBCATEGORY") && !categoryId) {
        return NextResponse.json(
            { message: "Category is required for category discount" },
            { status: 400 },
        );
    }

    const created = await prisma.productDiscount.create({
        data: {
            scope,
            percentage,
            productId: scope === "PRODUCT" ? productId : null,
            categoryId: scope === "PRODUCT" ? null : categoryId,
            startsAt,
            endsAt,
            note,
            isActive: typeof body?.isActive === "boolean" ? body.isActive : true,
        },
    });

    return NextResponse.json({ discount: created }, { status: 201 });
}