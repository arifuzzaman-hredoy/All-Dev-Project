import { NextResponse, type NextRequest } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import {
  BANGLA_FONT_OPTIONS,
  SITE_FONT_OPTIONS,
  type SiteFontOption,
} from "@/lib/site-fonts";

export const dynamic = "force-dynamic";

type GoogleFontSubset = "latin" | "bengali";

type GoogleFontItem = {
  family: string;
  variants?: string[];
  subsets?: string[];
  category?: string;
};

type GoogleFontsResponse = {
  items?: GoogleFontItem[];
};

const FALLBACK_OPTIONS: Record<GoogleFontSubset, SiteFontOption[]> = {
  latin: SITE_FONT_OPTIONS,
  bengali: BANGLA_FONT_OPTIONS,
};

function getSubset(input: string | null): GoogleFontSubset {
  return input === "bengali" ? "bengali" : "latin";
}

function buildGoogleFamily(family: string, variants: string[] | undefined) {
  const desiredWeights = ["400", "500", "600", "700", "800"];
  const availableWeights = new Set(
    (variants ?? [])
      .map((variant) => (variant === "regular" ? "400" : variant))
      .filter((variant) => /^\d+$/.test(variant)),
  );
  const weights = desiredWeights.filter((weight) =>
    availableWeights.has(weight),
  );

  if (!weights.length) return family;
  return `${family}:wght@${weights.join(";")}`;
}

function toFontOption(item: GoogleFontItem): SiteFontOption | null {
  const family = item.family.trim();

  if (!family) return null;

  return {
    value: family,
    label: family,
    cssFamily: `"${family.replaceAll('"', "")}"`,
    googleFamily: buildGoogleFamily(family, item.variants),
    sample: item.category ? `${item.category} font` : family,
  };
}

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const subset = getSubset(req.nextUrl.searchParams.get("subset"));
  const apiKey = process.env.GOOGLE_FONTS_API_KEY?.trim();

  if (!apiKey) {
    return NextResponse.json({
      ok: true,
      source: "fallback",
      fonts: FALLBACK_OPTIONS[subset],
    });
  }

  const url = new URL("https://www.googleapis.com/webfonts/v1/webfonts");
  url.searchParams.set("key", apiKey);
  url.searchParams.set("sort", "popularity");
  url.searchParams.set("subset", subset);

  try {
    const res = await fetch(url, {
      next: { revalidate: 60 * 60 * 24 },
    });

    if (!res.ok) {
      return NextResponse.json({
        ok: true,
        source: "fallback",
        fonts: FALLBACK_OPTIONS[subset],
      });
    }

    const data = (await res.json().catch(() => null)) as
      | GoogleFontsResponse
      | null;
    const fonts = (data?.items ?? [])
      .filter((item) => item.subsets?.includes(subset))
      .map(toFontOption)
      .filter((font): font is SiteFontOption => font !== null);

    return NextResponse.json({
      ok: true,
      source: "google",
      fonts: fonts.length ? fonts : FALLBACK_OPTIONS[subset],
    });
  } catch {
    return NextResponse.json({
      ok: true,
      source: "fallback",
      fonts: FALLBACK_OPTIONS[subset],
    });
  }
}
