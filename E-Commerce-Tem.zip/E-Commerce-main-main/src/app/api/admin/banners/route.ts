import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

const HERO_BANNER_SLOTS = ["mainbanner", "subbanner1", "subbanner2"] as const;

type BannerSlot = (typeof HERO_BANNER_SLOTS)[number];

type BannerPayload = {
  id?: string;
  slot?: string | null;
  title?: string | null;
  imageUrl?: string;
  linkUrl?: string | null;
  sortOrder?: number;
  isActive?: boolean;
};

function isBannerSlot(value: unknown): value is BannerSlot {
  return typeof value === "string" && HERO_BANNER_SLOTS.includes(value as BannerSlot);
}

function normalizeNullableString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function normalizeRequiredString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function normalizeSortOrder(value: unknown): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.floor(n);
}

function isValidAbsoluteUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function isValidBannerImageUrl(value: string): boolean {
  const v = value.trim();
  return v.startsWith("/uploads/") || isValidAbsoluteUrl(v);
}

function isValidLinkUrlMaybeEmpty(value: string | null): boolean {
  if (!value) return true;
  if (value.startsWith("/")) return true;
  return isValidAbsoluteUrl(value);
}

function validateCreateOrUpdateBody(body: BannerPayload): string | null {
  if (!isBannerSlot(body.slot)) {
    return "A valid hero banner slot is required.";
  }

  const imageUrl = normalizeRequiredString(body.imageUrl);
  if (!imageUrl) {
    return "Banner image is required.";
  }

  if (!isValidBannerImageUrl(imageUrl)) {
    return "Banner image URL is invalid.";
  }

  const linkUrl = normalizeNullableString(body.linkUrl);
  if (!isValidLinkUrlMaybeEmpty(linkUrl)) {
    return "Link URL is invalid.";
  }

  const sortOrder = Number(body.sortOrder);
  if (!Number.isFinite(sortOrder) || sortOrder < 0) {
    return "Sort order must be 0 or more.";
  }

  return null;
}

export async function GET(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  try {
    const banners = await prisma.banner.findMany({
      where: {
        slot: {
          in: [...HERO_BANNER_SLOTS],
        },
      },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
    });

    return NextResponse.json({ banners });
  } catch (error) {
    console.error("GET /api/admin/banners failed:", error);
    return NextResponse.json(
      { message: "Could not load banners." },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = (await req.json().catch(() => null)) as BannerPayload | null;
    if (!body) {
      return NextResponse.json(
        { message: "Invalid request body." },
        { status: 400 },
      );
    }

    const validationError = validateCreateOrUpdateBody(body);
    if (validationError) {
      return NextResponse.json({ message: validationError }, { status: 400 });
    }

    const slot = body.slot as BannerSlot;
    const imageUrl = normalizeRequiredString(body.imageUrl);
    const title = normalizeNullableString(body.title);
    const linkUrl = normalizeNullableString(body.linkUrl);
    const sortOrder = normalizeSortOrder(body.sortOrder);
    const isActive = typeof body.isActive === "boolean" ? body.isActive : true;

    const [heroBannerCount, existingSlotBanner] = await Promise.all([
      prisma.banner.count({
        where: {
          slot: {
            in: [...HERO_BANNER_SLOTS],
          },
        },
      }),
      prisma.banner.findFirst({
        where: { slot },
        select: { id: true },
      }),
    ]);

    if (heroBannerCount >= 3) {
      return NextResponse.json(
        { message: "Only 3 hero banners are allowed." },
        { status: 400 },
      );
    }

    if (existingSlotBanner) {
      return NextResponse.json(
        { message: "This hero banner slot is already used." },
        { status: 400 },
      );
    }

    const banner = await prisma.banner.create({
      data: {
        slot,
        title,
        imageUrl,
        linkUrl,
        sortOrder,
        isActive,
      },
    });

    return NextResponse.json({
      message: "Banner created successfully.",
      banner,
    });
  } catch (error) {
    console.error("POST /api/admin/banners failed:", error);
    return NextResponse.json(
      { message: "Banner save failed." },
      { status: 500 },
    );
  }
}

export async function PATCH(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = (await req.json().catch(() => null)) as BannerPayload | null;
    if (!body?.id || typeof body.id !== "string") {
      return NextResponse.json({ message: "Banner id is required." }, { status: 400 });
    }

    const existing = await prisma.banner.findUnique({
      where: { id: body.id },
    });

    if (!existing) {
      return NextResponse.json({ message: "Banner not found." }, { status: 404 });
    }

    const isQuickToggleOnly =
      Object.keys(body).length === 2 && typeof body.isActive === "boolean";

    if (isQuickToggleOnly) {
      const updated = await prisma.banner.update({
        where: { id: body.id },
        data: {
          isActive: body.isActive,
        },
      });

      return NextResponse.json({
        message: "Banner updated successfully.",
        banner: updated,
      });
    }

    const mergedBody: BannerPayload = {
      id: body.id,
      slot: body.slot ?? existing.slot,
      title: body.title ?? existing.title,
      imageUrl: body.imageUrl ?? existing.imageUrl,
      linkUrl:
        body.linkUrl === undefined ? existing.linkUrl : body.linkUrl,
      sortOrder: body.sortOrder ?? existing.sortOrder,
      isActive:
        typeof body.isActive === "boolean" ? body.isActive : existing.isActive,
    };

    const validationError = validateCreateOrUpdateBody(mergedBody);
    if (validationError) {
      return NextResponse.json({ message: validationError }, { status: 400 });
    }

    const slot = mergedBody.slot as BannerSlot;

    const duplicateSlotBanner = await prisma.banner.findFirst({
      where: {
        slot,
        id: { not: body.id },
      },
      select: { id: true },
    });

    if (duplicateSlotBanner) {
      return NextResponse.json(
        { message: "This hero banner slot is already used." },
        { status: 400 },
      );
    }

    const updated = await prisma.banner.update({
      where: { id: body.id },
      data: {
        slot,
        title: normalizeNullableString(mergedBody.title),
        imageUrl: normalizeRequiredString(mergedBody.imageUrl),
        linkUrl: normalizeNullableString(mergedBody.linkUrl),
        sortOrder: normalizeSortOrder(mergedBody.sortOrder),
        isActive:
          typeof mergedBody.isActive === "boolean"
            ? mergedBody.isActive
            : existing.isActive,
      },
    });

    return NextResponse.json({
      message: "Banner updated successfully.",
      banner: updated,
    });
  } catch (error) {
    console.error("PATCH /api/admin/banners failed:", error);
    return NextResponse.json(
      { message: "Banner save failed." },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  const gate = await requireAdmin(req);
  if (!gate.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  try {
    const id = req.nextUrl.searchParams.get("id")?.trim();
    if (!id) {
      return NextResponse.json({ message: "Banner id is required." }, { status: 400 });
    }

    const existing = await prisma.banner.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!existing) {
      return NextResponse.json({ message: "Banner not found." }, { status: 404 });
    }

    await prisma.banner.delete({
      where: { id },
    });

    return NextResponse.json({
      message: "Banner deleted successfully.",
    });
  } catch (error) {
    console.error("DELETE /api/admin/banners failed:", error);
    return NextResponse.json(
      { message: "Banner delete failed." },
      { status: 500 },
    );
  }
}