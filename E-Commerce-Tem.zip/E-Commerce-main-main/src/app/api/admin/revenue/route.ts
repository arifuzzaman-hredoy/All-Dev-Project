import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import {
    getDefaultDeliveryCharge,
    getGrandSellAmount,
    getOrderItemsInvestedAmount,
    getRevenue,
} from "@/lib/revenue-calculation";
import { OrderStatus } from "@prisma/client";

function toNumber(value: string | null, fallback: number) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function getDateRange(year: number, month: number) {
    const start = new Date(Date.UTC(year, month - 1, 1, 0, 0, 0));
    const end = new Date(Date.UTC(year, month, 1, 0, 0, 0));
    return { start, end };
}

export async function GET(req: NextRequest) {
    const auth = await requireAdmin(req);
    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const now = new Date();
    const year = toNumber(
        req.nextUrl.searchParams.get("year"),
        now.getUTCFullYear(),
    );
    const month = toNumber(
        req.nextUrl.searchParams.get("month"),
        now.getUTCMonth() + 1,
    );

    const { start, end } = getDateRange(year, month);

    const orders = await prisma.order.findMany({
        where: {
            createdAt: {
                gte: start,
                lt: end,
            },
            status: {
                not: OrderStatus.CANCELLED,
            },
        },
        orderBy: {
            createdAt: "desc",
        },
        select: {
            id: true,
            publicOrderId: true,
            createdAt: true,
            name: true,
            phone: true,
            total: true,
            shipping: true,
            status: true,
            paymentStatus: true,
            revenueRecord: {
                select: {
                    id: true,
                    deliveryCharge: true,
                    investedAmount: true,
                    adminNote: true,
                    updatedAt: true,
                },
            },
            items: {
                select: {
                    qty: true,
                    variant: {
                        select: {
                            investedAmount: true,
                        },
                    },
                    product: {
                        select: {
                            investedAmount: true,
                        },
                    },
                },
            },
        },
    });

    const rows = orders.map((order) => {
        const sell = order.total;
        const deliveryCharge =
            order.revenueRecord?.deliveryCharge ??
            getDefaultDeliveryCharge(order.shipping);
        const investedAmount =
            order.revenueRecord?.investedAmount ??
            getOrderItemsInvestedAmount(order.items);
        const grandSellAmount = getGrandSellAmount({
            sell,
            deliveryCharge,
        });
        const revenue = getRevenue({
            sell,
            deliveryCharge,
            investedAmount,
        });

        return {
            orderId: order.id,
            publicOrderId: order.publicOrderId,
            createdAt: order.createdAt,
            customerName: order.name,
            phone: order.phone,
            status: order.status,
            paymentStatus: order.paymentStatus,
            sell,
            shipping: order.shipping,
            deliveryCharge,
            grandSellAmount,
            investedAmount,
            revenue,
            adminNote: order.revenueRecord?.adminNote ?? null,
            hasManualRecord: Boolean(order.revenueRecord),
        };
    });

    const totals = rows.reduce(
        (acc, row) => {
            acc.sell += row.sell;
            acc.deliveryCharge += row.deliveryCharge;
            acc.grandSellAmount += row.grandSellAmount;
            acc.investedAmount += row.investedAmount ?? 0;
            acc.revenue += row.revenue ?? 0;
            acc.completedRevenueRows += row.revenue === null ? 0 : 1;
            return acc;
        },
        {
            sell: 0,
            deliveryCharge: 0,
            grandSellAmount: 0,
            investedAmount: 0,
            revenue: 0,
            completedRevenueRows: 0,
        },
    );

    return NextResponse.json({
        ok: true,
        year,
        month,
        rows,
        totals,
    });
}
