import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { getDefaultDeliveryCharge } from "@/lib/revenue-calculation";

type Ctx = {
    params: Promise<{ orderId: string }> | { orderId: string };
};

function toInt(value: unknown, fallback: number) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.round(n));
}

function toNullableInt(value: unknown) {
    if (value === "" || value === null || typeof value === "undefined") {
        return null;
    }

    const n = Number(value);
    if (!Number.isFinite(n)) return null;

    return Math.max(0, Math.round(n));
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
    const auth = await requireAdmin(req);

    if (!auth.ok) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const params = ctx.params instanceof Promise ? await ctx.params : ctx.params;
    const orderId = params.orderId;

    if (!orderId) {
        return NextResponse.json({ error: "Missing order id" }, { status: 400 });
    }

    const order = await prisma.order.findUnique({
        where: { id: orderId },
        select: {
            id: true,
            shipping: true,
        },
    });

    if (!order) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const body = await req.json().catch(() => null);

    const deliveryCharge = toInt(
        body?.deliveryCharge,
        getDefaultDeliveryCharge(order.shipping),
    );

    const investedAmount = toNullableInt(body?.investedAmount);

    const adminNote =
        typeof body?.adminNote === "string" && body.adminNote.trim()
            ? body.adminNote.trim()
            : null;

    const revenueRecord = await prisma.orderRevenue.upsert({
        where: {
            orderId: order.id,
        },
        update: {
            deliveryCharge,
            investedAmount,
            adminNote,
        },
        create: {
            orderId: order.id,
            deliveryCharge,
            investedAmount,
            adminNote,
        },
    });

    return NextResponse.json({
        ok: true,
        revenueRecord,
    });
}