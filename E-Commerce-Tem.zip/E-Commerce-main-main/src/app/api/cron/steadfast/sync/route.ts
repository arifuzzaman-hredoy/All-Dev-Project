import { NextRequest, NextResponse } from "next/server";
import { env } from "@/lib/env";
import { isSteadfastEnabled } from "@/lib/couriers/steadfast";
import { syncSteadfastOrdersBatch } from "@/lib/couriers/steadfast-sync";

function isAuthorized(req: NextRequest): boolean {
    const secret = env.CRON_SECRET?.trim();
    if (!secret) return true;

    const bearer = req.headers.get("authorization");
    if (bearer === `Bearer ${secret}`) return true;

    const url = new URL(req.url);
    const querySecret = url.searchParams.get("secret");
    return querySecret === secret;
}

export async function GET(req: NextRequest) {
    if (!isAuthorized(req)) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!isSteadfastEnabled()) {
        return NextResponse.json(
            { ok: false, error: "Steadfast integration is disabled" },
            { status: 400 },
        );
    }

    const results = await syncSteadfastOrdersBatch(50);

    return NextResponse.json({
        ok: true,
        total: results.length,
        success: results.filter((item) => item.ok).length,
        failed: results.filter((item) => !item.ok).length,
        results,
    });
}