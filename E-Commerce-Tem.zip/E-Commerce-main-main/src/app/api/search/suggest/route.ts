import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type SuggestionItem = {
  id: string;
  label: string;
  sublabel?: string;
  href: string;
  type: "product" | "category" | "page";
  image?: string | null;
};

type SuggestResponse = {
  query: string;
  items: SuggestionItem[];
};

function normalize(value: string): string {
  return value.trim();
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<SuggestResponse>> {
  const { searchParams } = new URL(req.url);
  const q = normalize(searchParams.get("q") || "");

  if (!q || q.length < 1) {
    return NextResponse.json({
      query: q,
      items: [
        {
          id: "page-products",
          label: "Browse all products",
          href: "/products",
          type: "page",
        },
        {
          id: "page-cart",
          label: "Go to cart",
          href: "/cart",
          type: "page",
        },
        {
          id: "page-wishlist",
          label: "Go to wishlist",
          href: "/wishlist",
          type: "page",
        },
      ],
    });
  }

  const [products, categories] = await Promise.all([
    prisma.product.findMany({
      where: {
        isActive: true,
        OR: [
          { name: { contains: q, mode: "insensitive" } },
          { description: { contains: q, mode: "insensitive" } },
          { sku: { contains: q, mode: "insensitive" } },
        ],
      },
      orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
      take: 8,
      select: {
        id: true,
        name: true,
        slug: true,
        sku: true,
        images: {
          orderBy: { sortOrder: "asc" },
          take: 1,
          select: {
            url: true,
          },
        },
        category: {
          select: {
            name: true,
            slug: true,
            parent: {
              select: {
                name: true,
              },
            },
          },
        },
      },
    }),

    prisma.category.findMany({
      where: {
        isActive: true,
        OR: [
          { name: { contains: q, mode: "insensitive" } },
          { slug: { contains: q, mode: "insensitive" } },
        ],
      },
      orderBy: [{ parentId: "asc" }, { name: "asc" }],
      take: 6,
      select: {
        id: true,
        name: true,
        slug: true,
        parent: {
          select: {
            name: true,
          },
        },
      },
    }),
  ]);

  const productItems: SuggestionItem[] = products.map((p) => ({
    id: `product-${p.id}`,
    label: p.name,
    sublabel: p.category
      ? [p.category.parent?.name, p.category.name].filter(Boolean).join(" → ")
      : p.sku,
    href: `/products/${p.slug}`,
    type: "product",
    image: p.images[0]?.url ?? null,
  }));

  const categoryItems: SuggestionItem[] = categories.map((c) => ({
    id: `category-${c.id}`,
    label: c.name,
    sublabel: c.parent?.name ? `${c.parent.name} category` : "Category",
    href: `/products?cat=${encodeURIComponent(c.slug)}`,
    type: "category",
  }));

  const pageItems: SuggestionItem[] = [
    {
      id: "search-all-products",
      label: `Search all products for "${q}"`,
      href: `/products?q=${encodeURIComponent(q)}`,
      type: "page",
    },
  ];

  const items = [...productItems, ...categoryItems, ...pageItems].slice(0, 12);

  return NextResponse.json({
    query: q,
    items,
  });
}
