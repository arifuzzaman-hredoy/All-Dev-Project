import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCartServer } from "@/lib/cart.server";
import type { CartItem } from "@/lib/cart.types";
import { attachEffectivePrices } from "@/lib/product-discounts";

type CartDetailsItem = {
  qty: number;
  variantId: string | null;
  variantLabel: string | null;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
  };
};

type CartDetailsResponse = {
  items: CartDetailsItem[];
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;

  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwarePrice(params: {
  productPrice: number;
  productOfferPrice: number | null;
  variantPriceDiff: number | null;
}) {
  const baseOriginalPrice = safeNumber(params.productPrice, 0);

  const baseDiscountedPrice = safeNumber(
    params.productOfferPrice ?? params.productPrice,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(params.variantPriceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  return {
    comparePrice,
    unitPrice,
    offerPrice: unitPrice < comparePrice ? unitPrice : null,
  };
}

export async function GET(): Promise<NextResponse<CartDetailsResponse>> {
  const cart = await getCartServer();
  const ids = [...new Set(cart.items.map((i: CartItem) => i.productId))];

  if (ids.length === 0) {
    return NextResponse.json({ items: [] });
  }

  const productsRaw = await prisma.product.findMany({
    where: { id: { in: ids }, isActive: true },
    include: {
      category: {
        include: {
          parent: true,
        },
      },
      images: {
        orderBy: {
          sortOrder: "asc",
        },
      },
      variants: {
        include: {
          images: {
            orderBy: {
              sortOrder: "asc",
            },
          },
        },
      },
    },
  });

  const products = await attachEffectivePrices(productsRaw);
  const map = new Map(products.map((p) => [p.id, p] as const));

  const items: CartDetailsItem[] = cart.items
    .map((i: CartItem): CartDetailsItem | null => {
      const p = map.get(i.productId);
      if (!p) return null;

      const variant =
        i.variantId && p.variants.length
          ? p.variants.find((v) => v.id === i.variantId) ?? null
          : null;

      const priceDiff = variant?.priceDiff ?? 0;

      const priceInfo = calculateVariantAwarePrice({
        productPrice: p.price,
        productOfferPrice: p.offerPrice,
        variantPriceDiff: priceDiff,
      });

      const effectiveImages = variant?.images?.length
        ? variant.images
        : p.images;

      return {
        qty: i.qty,
        variantId: variant?.id ?? null,
        variantLabel: variant ? `${variant.type}: ${variant.value}` : null,
        product: {
          id: p.id,
          name: p.name,
          slug: p.slug,

          // original variant price
          price: priceInfo.comparePrice,

          // discounted variant price
          offerPrice: priceInfo.offerPrice,

          stock: variant ? variant.stock : p.stock,
          images: (effectiveImages ?? [])
            .map((x) => ({ url: x.url }))
            .filter((x) => typeof x.url === "string" && x.url.length > 0),
        },
      };
    })
    .filter((x): x is CartDetailsItem => x !== null);

  return NextResponse.json({ items });
}