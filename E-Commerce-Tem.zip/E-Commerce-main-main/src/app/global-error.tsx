"use client";

export default function GlobalError({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body>
        <div className="mx-auto flex min-h-screen max-w-2xl flex-col items-start justify-center gap-4 px-4 py-16">
          <h2 className="text-2xl font-semibold text-gray-900">Application error</h2>
          <p className="text-sm text-gray-600">
            A server error prevented the page from loading.
          </p>
          <button
            type="button"
            onClick={reset}
            className="inline-flex h-11 items-center justify-center rounded-2xl bg-pink-600 px-5 text-sm font-medium text-white transition hover:bg-pink-700"
          >
            Try again
          </button>
        </div>
      </body>
    </html>
  );
}