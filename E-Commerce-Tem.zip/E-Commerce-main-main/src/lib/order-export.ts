type OrderExportItem = {
    productName: string;
    qty: number;
    lineTotal?: number | null;
};

type OrderExportOrder = {
    id: string;
    publicOrderId?: string | null;
    orderSequence?: number | null;
    createdAt: Date | string;
    status: string;
    paymentStatus: string;
    total: number;
    phone: string;
    name: string;
    addressLine1: string;
    addressLine2?: string | null;
    city?: string | null;
    area?: string | null;
    note?: string | null;
    trackingId?: string | null;
    items?: OrderExportItem[];
    paymentMeta?: unknown;
};

function asObject(value: unknown): Record<string, unknown> | null {
    return value && typeof value === "object" && !Array.isArray(value)
        ? (value as Record<string, unknown>)
        : null;
}

function asString(value: unknown): string {
    return typeof value === "string" ? value.trim() : "";
}

function formatDate(value: Date | string): string {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return date.toISOString().slice(0, 10);
}

function getSteadfastId(order: OrderExportOrder): string {
    const root = asObject(order.paymentMeta);
    const steadfast = asObject(root?.steadfast);

    return (
        asString(steadfast?.consignmentId) ||
        asString(steadfast?.trackingCode) ||
        asString(order.trackingId) ||
        ""
    );
}

function getShortOrderId(order: OrderExportOrder): string {
    return (
        asString(order.publicOrderId) ||
        (order.orderSequence
            ? `SB-${String(order.orderSequence).padStart(5, "0")}`
            : "") ||
        order.id
    );
}

function getFullAddress(order: OrderExportOrder): string {
    return [
        asString(order.addressLine1),
        asString(order.addressLine2),
        asString(order.city),
        asString(order.area),
    ]
        .filter(Boolean)
        .join(", ");
}

function getProductsText(items: OrderExportItem[] | undefined): string {
    if (!Array.isArray(items) || items.length === 0) return "";

    return items
        .map((item) => {
            const name = asString(item.productName);
            const qty = Number(item.qty || 0);
            return name ? `${name}${qty > 0 ? ` x${qty}` : ""}` : "";
        })
        .filter(Boolean)
        .join(" | ");
}

export const ORDER_EXPORT_HEADERS = [
    "Status",
    "Serial Number",
    "Order Date",
    "Steadfast ID",
    "Payment Status",
    "LOT",
    "Order Price",
    "Mobile",
    "Name",
    "Address",
    "Products",
    "Notes",
] as const;

export function buildOrderExportRow(order: OrderExportOrder) {
    return {
        Status: asString(order.status),
        "Serial Number": getShortOrderId(order),
        "Order Date": formatDate(order.createdAt),
        "Steadfast ID": getSteadfastId(order),
        "Payment Status": asString(order.paymentStatus),
        LOT: 1,
        "Order Price": Number(order.total || 0),
        Mobile: asString(order.phone),
        Name: asString(order.name),
        Address: getFullAddress(order),
        Products: getProductsText(order.items),
        Notes: asString(order.note),
    };
}

export function buildOrderExportRows<T extends OrderExportOrder>(orders: T[]) {
    return orders.map(buildOrderExportRow);
}

export function buildCsvFromRows(
    rows: Array<Record<(typeof ORDER_EXPORT_HEADERS)[number], string | number>>,
): string {
    const header = ORDER_EXPORT_HEADERS.join(",");

    const body = rows.map((row) =>
        ORDER_EXPORT_HEADERS.map((key) => {
            const value = String(row[key] ?? "").replace(/"/g, '""');
            return `"${value}"`;
        }).join(","),
    );

    return [header, ...body].join("\n");
}