import {
  OrderStatus,
  PaymentMethod,
  PaymentStatus,
  Prisma,
} from "@prisma/client";

export type OrderForSteadfast = {
  id: string;
  publicOrderId?: string | null;
  createdAt: Date;
  name: string;
  email: string | null;
  phone: string;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  items: Array<{
    productName: string;
    sku: string;
    qty: number;
  }>;
};

export type SteadfastCreateOrderPayload = {
  invoice: string;
  recipient_name: string;
  recipient_phone: string;
  alternative_phone?: string;
  recipient_email?: string;
  recipient_address: string;
  cod_amount: number;
  note?: string;
  item_description?: string;
  total_lot?: number;
  delivery_type?: number;
};

export type SteadfastCreateOrderResponse = {
  status?: number;
  message?: string;
  consignment?: {
    consignment_id?: number | string;
    invoice?: string;
    tracking_code?: string;
    recipient_name?: string;
    recipient_phone?: string;
    recipient_address?: string;
    cod_amount?: number;
    status?: string;
    note?: string;
    created_at?: string;
    updated_at?: string;
  };
  [key: string]: unknown;
};

export type SteadfastStatusResponse = {
  status?: number;
  delivery_status?: string;
  [key: string]: unknown;
};

export type SteadfastPoliceStation = {
  id: string;
  name: string;
  district: string;
};

export type SteadfastDistrictOption = {
  id: string;
  name: string;
};

type SteadfastPoliceStationRaw = {
  id?: string | number;
  name?: string;
};

type SteadfastDistrictRaw = {
  id?: string | number;
  name?: string;
  policestations?: SteadfastPoliceStationRaw[];
};

type SteadfastPoliceStationsApiResponse = {
  status?: number;
  data?: SteadfastDistrictRaw[];
  [key: string]: unknown;
};

function env(name: string, fallback = ""): string {
  return process.env[name]?.trim() || fallback;
}

export function isSteadfastEnabled(): boolean {
  return env("STEADFAST_ENABLED", "false").toLowerCase() === "true";
}

function getBaseUrl(): string {
  return env("STEADFAST_BASE_URL", "https://portal.packzy.com/api/v1").replace(
    /\/+$/,
    "",
  );
}

function getApiKey(): string {
  return env("STEADFAST_API_KEY");
}

function getSecretKey(): string {
  return env("STEADFAST_SECRET_KEY");
}

function getHeaders(): HeadersInit {
  const apiKey = getApiKey();
  const secretKey = getSecretKey();

  if (!apiKey) {
    throw new Error("STEADFAST_API_KEY is missing");
  }

  if (!secretKey) {
    throw new Error("STEADFAST_SECRET_KEY is missing");
  }

  return {
    "Api-Key": apiKey,
    "Secret-Key": secretKey,
    "Content-Type": "application/json",
  };
}

function normalizePhone(phone: string): string {
  const value = (phone || "").trim();

  if (!value) return value;

  if (value.startsWith("+88")) return value.slice(3);
  if (value.startsWith("88") && value.length === 13) return value.slice(2);

  return value;
}

function cleanText(value: string | null | undefined): string {
  return (value || "").replace(/\s+/g, " ").trim();
}

function uniqueNonEmpty(values: Array<string | null | undefined>): string[] {
  const seen = new Set<string>();
  const result: string[] = [];

  for (const raw of values) {
    const value = cleanText(raw);
    if (!value) continue;

    const key = value.toLowerCase();
    if (seen.has(key)) continue;

    seen.add(key);
    result.push(value);
  }

  return result;
}

function normalizeLooseText(value: string): string {
  return value
    .toLowerCase()
    .replace(/['’`]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getDistrictAliases(district: string): string[] {
  const value = cleanText(district);
  const normalized = normalizeLooseText(value);

  const aliases = new Set<string>();

  if (normalized) aliases.add(normalized);

  if (normalized === "dhaka") {
    aliases.add("dhaka city");
    aliases.add("dhaka sub urban");
    aliases.add("dhaka suburban");
  }

  if (normalized === "narshindi") aliases.add("narsingdi");
  if (normalized === "narsingdi") aliases.add("narshindi");

  if (normalized === "chattogram") aliases.add("chittagong");
  if (normalized === "chittagong") aliases.add("chattogram");

  if (normalized === "cumilla") aliases.add("comilla");
  if (normalized === "comilla") aliases.add("cumilla");

  if (normalized === "jashore") aliases.add("jessore");
  if (normalized === "jessore") aliases.add("jashore");

  if (normalized === "chapainawabganj") aliases.add("chapai nawabganj");

  if (normalized === "coxs bazar") {
    aliases.add("coxs bazar");
    aliases.add("cox bazar");
  }

  return Array.from(aliases);
}

function isDhakaAlias(value: string): boolean {
  const normalized = normalizeLooseText(value);
  return (
    normalized === "dhaka" ||
    normalized === "dhaka city" ||
    normalized === "dhaka sub urban" ||
    normalized === "dhaka suburban"
  );
}

function isRangpurAlias(value: string): boolean {
  return normalizeLooseText(value) === "rangpur";
}

/**
 * city => district
 * area => police station
 */
function buildRecipientAddress(order: OrderForSteadfast): string {
  const streetParts = uniqueNonEmpty([order.addressLine1, order.addressLine2]);
  const district = cleanText(order.city);
  const policeStation = cleanText(order.area);

  const segments: string[] = [];

  if (streetParts.length) {
    segments.push(`Address: ${streetParts.join(", ")}`);
  }

  if (policeStation) {
    segments.push(`Police Station: ${policeStation}`);
  }

  if (district) {
    segments.push(`District: ${district}`);
  }

  segments.push("Country: Bangladesh");

  return segments.join(", ").slice(0, 250);
}

function buildItemDescription(order: OrderForSteadfast): string | undefined {
  const names = order.items
    .map((item) => cleanText(item.productName))
    .filter(Boolean)
    .slice(0, 6);

  if (!names.length) return undefined;

  return names.join(", ").slice(0, 255);
}

function buildNote(order: OrderForSteadfast): string | undefined {
  const noteParts = uniqueNonEmpty([
    order.note,
    order.area ? `Police Station: ${order.area}` : null,
    order.city ? `District: ${order.city}` : null,
  ]);

  if (!noteParts.length) return undefined;

  return noteParts.join(" | ").slice(0, 255);
}

export function buildSteadfastCreatePayload(
  order: OrderForSteadfast,
): SteadfastCreateOrderPayload {
  const codAmount = order.paymentStatus === "PAID" ? 0 : order.total;
  const normalizedPhone = normalizePhone(order.phone);

  return {
    invoice: cleanText(order.publicOrderId) || order.id,
    recipient_name: cleanText(order.name),
    recipient_phone: normalizedPhone,
    alternative_phone: normalizedPhone || undefined,
    recipient_email: order.email ?? undefined,
    recipient_address: buildRecipientAddress(order),
    cod_amount: codAmount,
    note: buildNote(order),
    item_description: buildItemDescription(order),
    total_lot: 1,
    delivery_type: 0,
  };
}

async function parseJsonSafe<T>(res: Response): Promise<T | null> {
  try {
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function extractErrorMessage(data: unknown, fallback: string): string {
  if (!data || typeof data !== "object") return fallback;

  const record = data as Record<string, unknown>;

  if (typeof record.message === "string" && record.message.trim()) {
    return record.message;
  }

  if (typeof record.error === "string" && record.error.trim()) {
    return record.error;
  }

  if (
    typeof record.delivery_status === "string" &&
    record.delivery_status.trim()
  ) {
    return record.delivery_status;
  }

  return fallback;
}

async function fetchSteadfastPoliceStationSource(): Promise<SteadfastDistrictRaw[]> {
  const res = await fetch(`${getBaseUrl()}/police_stations`, {
    method: "GET",
    headers: getHeaders(),
    next: { revalidate: 60 * 60 * 24 },
  });

  const payload =
    await parseJsonSafe<SteadfastPoliceStationsApiResponse>(res);

  if (!res.ok) {
    throw new Error(
      extractErrorMessage(
        payload,
        `Steadfast police stations fetch failed with ${res.status}`,
      ),
    );
  }

  return Array.isArray(payload?.data) ? payload.data : [];
}

export async function fetchSteadfastDistricts(): Promise<SteadfastDistrictOption[]> {
  const data = await fetchSteadfastPoliceStationSource();

  const groupedDhaka: SteadfastDistrictOption = {
    id: "dhaka",
    name: "Dhaka",
  };

  const seen = new Set<string>();
  const districts: SteadfastDistrictOption[] = [];

  for (const row of data) {
    const districtName = cleanText(row.name);
    if (!districtName) continue;

    if (isDhakaAlias(districtName)) {
      continue;
    }

    const normalized = normalizeLooseText(districtName);
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);

    districts.push({
      id:
        row.id !== undefined && row.id !== null ? String(row.id) : normalized,
      name: districtName,
    });
  }

  districts.push(groupedDhaka);

  return districts.sort((a, b) => a.name.localeCompare(b.name));
}

export async function fetchSteadfastPoliceStations(
  district: string,
): Promise<SteadfastPoliceStation[]> {
  const requestedDistrict = cleanText(district);
  if (!requestedDistrict) return [];

  const data = await fetchSteadfastPoliceStationSource();
  const districtAliases = getDistrictAliases(requestedDistrict);

  const matchedDistricts = data.filter((districtRow) => {
    const districtName = cleanText(districtRow.name);
    if (!districtName) return false;

    const normalizedDistrictName = normalizeLooseText(districtName);
    return districtAliases.includes(normalizedDistrictName);
  });

  const seen = new Set<string>();

  const policeStations = matchedDistricts
    .flatMap((districtRow) => {
      const stations = Array.isArray(districtRow.policestations)
        ? districtRow.policestations
        : [];

      return stations
        .map((station) => {
          const stationName = cleanText(station?.name);
          if (!stationName) return null;

          const stationId =
            station?.id !== undefined && station?.id !== null
              ? String(station.id)
              : `${normalizeLooseText(requestedDistrict)}:${normalizeLooseText(
                stationName,
              )}`;

          return {
            id: stationId,
            name: stationName,
            district: requestedDistrict,
          } satisfies SteadfastPoliceStation;
        })
        .filter((item): item is SteadfastPoliceStation => Boolean(item));
    })
    .filter((item) => {
      const key = normalizeLooseText(item.name);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.name.localeCompare(b.name));

  return policeStations;
}

export function isSteadfastDhakaDistrict(value: string): boolean {
  return isDhakaAlias(value);
}

export function isSteadfastRangpurDistrict(value: string): boolean {
  return isRangpurAlias(value);
}

export async function createSteadfastOrder(order: OrderForSteadfast) {
  const payload = buildSteadfastCreatePayload(order);

  const res = await fetch(`${getBaseUrl()}/create_order`, {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(payload),
    cache: "no-store",
  });

  const data = await parseJsonSafe<SteadfastCreateOrderResponse>(res);

  if (!res.ok) {
    throw new Error(
      extractErrorMessage(data, `Steadfast booking failed with ${res.status}`),
    );
  }

  const trackingCode =
    typeof data?.consignment?.tracking_code === "string"
      ? data.consignment.tracking_code
      : null;

  const consignmentId =
    typeof data?.consignment?.consignment_id === "string" ||
      typeof data?.consignment?.consignment_id === "number"
      ? String(data.consignment.consignment_id)
      : null;

  const courierStatus =
    typeof data?.consignment?.status === "string"
      ? data.consignment.status
      : null;

  const ok =
    (typeof data?.status === "number" && data.status === 200) ||
    Boolean(data?.consignment?.tracking_code);

  return {
    ok,
    payload,
    response: data,
    trackingCode,
    consignmentId,
    courierStatus,
    message: typeof data?.message === "string" ? data.message : null,
  };
}

export async function fetchSteadfastStatusByInvoice(invoice: string) {
  const encodedInvoice = encodeURIComponent(invoice);

  const res = await fetch(`${getBaseUrl()}/status_by_invoice/${encodedInvoice}`, {
    method: "GET",
    headers: getHeaders(),
    cache: "no-store",
  });

  const data = await parseJsonSafe<SteadfastStatusResponse>(res);

  if (!res.ok) {
    throw new Error(
      extractErrorMessage(
        data,
        `Steadfast status fetch failed with ${res.status}`,
      ),
    );
  }

  return data ?? {};
}

export function normalizeSteadfastDeliveryStatus(
  value: string | null | undefined,
): string | null {
  const s = (value || "").trim().toLowerCase();
  return s || null;
}

export function mapSteadfastStatusToOrderStatus(
  deliveryStatus: string | null | undefined,
): OrderStatus | null {
  const s = normalizeSteadfastDeliveryStatus(deliveryStatus);

  if (!s) return null;

  if (s === "delivered") return "DELIVERED";

  if (s === "cancelled" || s === "cancelled_approval_pending") {
    return "CANCELLED";
  }

  if (
    s === "partial_delivered" ||
    s === "partial_delivered_approval_pending" ||
    s === "delivered_approval_pending"
  ) {
    return "SHIPPED";
  }

  if (
    s === "pending" ||
    s === "hold" ||
    s === "in_review" ||
    s === "unknown" ||
    s === "unknown_approval_pending"
  ) {
    return "PROCESSING";
  }

  return null;
}

function asObject(
  value: Prisma.JsonValue | null | undefined,
): Record<string, unknown> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return {};
}

export function mergeSteadfastIntoPaymentMeta(params: {
  currentPaymentMeta: Prisma.JsonValue | null;
  bookingResponse?: SteadfastCreateOrderResponse | null;
  trackingCode?: string | null;
  consignmentId?: string | null;
  courierStatus?: string | null;
  lastStatusResponse?: SteadfastStatusResponse | null;
  lastWebhook?: Record<string, unknown> | null;
}) {
  const root = asObject(params.currentPaymentMeta);
  const existingSteadfast =
    root.steadfast &&
      typeof root.steadfast === "object" &&
      !Array.isArray(root.steadfast)
      ? (root.steadfast as Record<string, unknown>)
      : {};

  const mergedSteadfast: Record<string, unknown> = {
    ...existingSteadfast,
    trackingCode:
      params.trackingCode ??
      (typeof existingSteadfast.trackingCode === "string"
        ? existingSteadfast.trackingCode
        : null),
    consignmentId:
      params.consignmentId ??
      (typeof existingSteadfast.consignmentId === "string"
        ? existingSteadfast.consignmentId
        : null),
    courierStatus:
      params.courierStatus ??
      (typeof existingSteadfast.courierStatus === "string"
        ? existingSteadfast.courierStatus
        : null),
    updatedAt: new Date().toISOString(),
  };

  if (params.bookingResponse) {
    mergedSteadfast.bookingResponse = params.bookingResponse;
    mergedSteadfast.bookedAt =
      (typeof existingSteadfast.bookedAt === "string" &&
        existingSteadfast.bookedAt) ||
      new Date().toISOString();
  }

  if (params.lastStatusResponse) {
    mergedSteadfast.lastStatusResponse = params.lastStatusResponse;
    mergedSteadfast.lastStatusSyncedAt = new Date().toISOString();
  }

  if (params.lastWebhook) {
    mergedSteadfast.lastWebhook = params.lastWebhook;
    mergedSteadfast.lastWebhookReceivedAt = new Date().toISOString();
  }

  return {
    ...root,
    steadfast: mergedSteadfast,
  } satisfies Record<string, unknown>;
}

export function getSteadfastMeta(
  paymentMeta: Prisma.JsonValue | null | undefined,
): {
  trackingCode: string | null;
  consignmentId: string | null;
  courierStatus: string | null;
} {
  const root = asObject(paymentMeta);
  const s =
    root.steadfast &&
      typeof root.steadfast === "object" &&
      !Array.isArray(root.steadfast)
      ? (root.steadfast as Record<string, unknown>)
      : {};

  return {
    trackingCode: typeof s.trackingCode === "string" ? s.trackingCode : null,
    consignmentId:
      typeof s.consignmentId === "string" ? s.consignmentId : null,
    courierStatus:
      typeof s.courierStatus === "string" ? s.courierStatus : null,
  };
}

export function buildSteadfastTrackingUrl(input: {
  consignmentId?: string | null;
  trackingCode?: string | null;
  trackingId?: string | null;
}): string | null {
  const consumerId =
    cleanText(input.consignmentId) ||
    cleanText(input.trackingCode) ||
    cleanText(input.trackingId);

  if (!consumerId) return null;

  return `http://steadfast.com.bd/user/consignment/${encodeURIComponent(consumerId)}`;
}
