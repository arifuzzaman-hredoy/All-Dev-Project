import { prisma } from "@/lib/prisma";
import {
    fetchSteadfastStatusByInvoice,
    getSteadfastMeta,
    isSteadfastEnabled,
    mapSteadfastStatusToOrderStatus,
    mergeSteadfastIntoPaymentMeta,
    normalizeSteadfastDeliveryStatus,
} from "@/lib/couriers/steadfast";
import { notifySteadfastBooked, notifySteadfastStatusChanged } from "@/lib/notifications";
import { OrderStatus, Prisma } from "@prisma/client";

type SyncResult =
    | {
        ok: true;
        orderId: string;
        deliveryStatus: string | null;
        mappedStatus: OrderStatus | null;
        changed: boolean;
        trackingId: string | null;
    }
    | {
        ok: false;
        orderId: string;
        error: string;
    };

function paymentMetaAsObject(
    value: Prisma.JsonValue | null | undefined,
): Record<string, unknown> {
    if (value && typeof value === "object" && !Array.isArray(value)) {
        return value as Record<string, unknown>;
    }
    return {};
}

export async function syncSteadfastOrderById(orderId: string): Promise<SyncResult> {
    if (!isSteadfastEnabled()) {
        return {
            ok: false,
            orderId,
            error: "Steadfast integration is disabled",
        };
    }

    const order = await prisma.order.findUnique({
        where: { id: orderId },
        select: {
            id: true,
            publicOrderId: true,
            userId: true,
            name: true,
            email: true,
            status: true,
            paymentStatus: true,
            courierName: true,
            trackingId: true,
            paymentMeta: true,
        },
    });

    if (!order) {
        return {
            ok: false,
            orderId,
            error: "Order not found",
        };
    }

    const shouldSync =
        order.courierName === "Steadfast" ||
        paymentMetaAsObject(order.paymentMeta).steadfast;

    if (!shouldSync) {
        return {
            ok: false,
            orderId,
            error: "This order is not booked in Steadfast",
        };
    }

    try {
        const statusResponse = await fetchSteadfastStatusByInvoice(
            order.publicOrderId ?? order.id,
        );
        const deliveryStatus = normalizeSteadfastDeliveryStatus(
            typeof statusResponse.delivery_status === "string"
                ? statusResponse.delivery_status
                : null,
        );

        const mappedStatus = mapSteadfastStatusToOrderStatus(deliveryStatus);
        const meta = getSteadfastMeta(order.paymentMeta);

        const nextPaymentMeta = mergeSteadfastIntoPaymentMeta({
            currentPaymentMeta: order.paymentMeta,
            trackingCode: order.trackingId ?? meta.trackingCode,
            consignmentId: meta.consignmentId,
            courierStatus: deliveryStatus,
            lastStatusResponse: statusResponse,
        });

        const nextTrackingId = order.trackingId ?? meta.trackingCode ?? null;

        const changed =
            order.courierName !== "Steadfast" ||
            order.trackingId !== nextTrackingId ||
            meta.courierStatus !== deliveryStatus ||
            (mappedStatus ? order.status !== mappedStatus : false);

        await prisma.order.update({
            where: { id: order.id },
            data: {
                courierName: "Steadfast",
                trackingId: nextTrackingId,
                ...(mappedStatus ? { status: mappedStatus } : {}),
                paymentMeta: nextPaymentMeta as Prisma.InputJsonValue,
            },
        });

        if (changed) {
            if (!order.trackingId && nextTrackingId) {
                await notifySteadfastBooked({
                    orderId: order.id,
                    trackingId: nextTrackingId,
                });
            }

            if (
                meta.courierStatus !== deliveryStatus ||
                (mappedStatus && mappedStatus !== order.status)
            ) {
                await notifySteadfastStatusChanged({
                    orderId: order.id,
                    previousOrderStatus: order.status,
                    newOrderStatus: mappedStatus ?? order.status,
                    courierStatus: deliveryStatus,
                    trackingId: nextTrackingId,
                });
            }
        }

        return {
            ok: true,
            orderId: order.id,
            deliveryStatus,
            mappedStatus,
            changed,
            trackingId: nextTrackingId,
        };
    } catch (error) {
        return {
            ok: false,
            orderId,
            error: error instanceof Error ? error.message : "Steadfast sync failed",
        };
    }
}

export async function syncSteadfastOrdersBatch(limit = 50) {
    const orders = await prisma.order.findMany({
        where: {
            courierName: "Steadfast",
            status: {
                in: ["PENDING", "PROCESSING", "SHIPPED"],
            },
        },
        orderBy: {
            updatedAt: "asc",
        },
        take: limit,
        select: {
            id: true,
        },
    });

    const results: SyncResult[] = [];

    for (const order of orders) {
        const result = await syncSteadfastOrderById(order.id);
        results.push(result);
    }

    return results;
}