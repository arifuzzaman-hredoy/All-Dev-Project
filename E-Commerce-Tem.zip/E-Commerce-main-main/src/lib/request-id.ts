import { headers } from "next/headers";
import { randomUUID } from "crypto";

export async function getRequestId() {
  const h = await headers();

  const existing =
    h.get("x-request-id") || h.get("x-correlation-id") || h.get("x-trace-id");

  return existing || randomUUID();
}
