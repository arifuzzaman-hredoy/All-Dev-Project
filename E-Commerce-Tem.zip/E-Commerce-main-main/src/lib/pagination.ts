export type PaginationInput = {
  page?: number | string | null;
  take?: number | string | null;
  defaultPage?: number;
  defaultTake?: number;
  minTake?: number;
  maxTake?: number;
};

export type PaginationResult = {
  page: number;
  take: number;
  skip: number;
};

function toInt(value: unknown, fallback: number): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? Math.floor(n) : fallback;
}

export function getPagination(input: PaginationInput = {}): PaginationResult {
  const defaultPage = input.defaultPage ?? 1;
  const defaultTake = input.defaultTake ?? 10;
  const minTake = input.minTake ?? 5;
  const maxTake = input.maxTake ?? 100;

  const rawPage = toInt(input.page, defaultPage);
  const rawTake = toInt(input.take, defaultTake);

  const page = Math.max(1, rawPage);
  const take = Math.max(minTake, Math.min(maxTake, rawTake));
  const skip = (page - 1) * take;

  return { page, take, skip };
}

export type PaginatedResponse<T> = {
  items: T[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

export function makePaginatedResponse<T>(params: {
  items: T[];
  total: number;
  page: number;
  take: number;
}): PaginatedResponse<T> {
  const pages = Math.max(1, Math.ceil(params.total / params.take));

  return {
    items: params.items,
    total: params.total,
    page: params.page,
    take: params.take,
    pages,
  };
}
