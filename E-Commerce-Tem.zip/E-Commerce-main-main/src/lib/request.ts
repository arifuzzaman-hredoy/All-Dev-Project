import { headers } from "next/headers";

export async function getRequestIp() {
  const h = await headers();

  const forwardedFor = h.get("x-forwarded-for");
  if (forwardedFor) {
    return forwardedFor.split(",")[0]?.trim() || "unknown";
  }

  const realIp = h.get("x-real-ip");
  if (realIp) {
    return realIp;
  }

  return "unknown";
}
