import { Resend } from "resend";
import { env } from "@/lib/env";

let resendInstance: Resend | null = null;

export function getResendClient(): Resend | null {
    if (!env.RESEND_API_KEY) return null;

    if (!resendInstance) {
        resendInstance = new Resend(env.RESEND_API_KEY);
    }

    return resendInstance;
}

export function getResendFromEmail(): string {
    return env.RESEND_FROM_EMAIL || "NexoraMart <onboarding@resend.dev>";
}