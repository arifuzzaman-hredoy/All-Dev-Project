import { Prisma } from "@prisma/client";

function padSequence(sequence: number): string {
  return String(sequence).padStart(5, "0");
}

export async function createNextPublicOrderId(
  tx: Prisma.TransactionClient,
): Promise<{ sequence: number; publicOrderId: string }> {
  const currentMax = await tx.order.aggregate({
    _max: {
      orderSequence: true,
    },
  });

  const maxOrderSequence = currentMax._max.orderSequence ?? 0;

  const existingCounter = await tx.orderCounter.findUnique({
    where: { key: "order" },
    select: { key: true, lastValue: true },
  });

  if (!existingCounter) {
    await tx.orderCounter.create({
      data: {
        key: "order",
        lastValue: maxOrderSequence,
      },
    });
  } else if (existingCounter.lastValue < maxOrderSequence) {
    await tx.orderCounter.update({
      where: { key: "order" },
      data: {
        lastValue: maxOrderSequence,
      },
    });
  }

  const counter = await tx.orderCounter.update({
    where: { key: "order" },
    data: {
      lastValue: {
        increment: 1,
      },
    },
    select: {
      lastValue: true,
    },
  });

  const sequence = counter.lastValue;
  const publicOrderId = `SB-${padSequence(sequence)}`;

  return {
    sequence,
    publicOrderId,
  };
}