export class AppError extends Error {
  statusCode: number;
  code?: string;
  details?: unknown;
  expose: boolean;

  constructor(
    message: string,
    options?: {
      statusCode?: number;
      code?: string;
      details?: unknown;
      expose?: boolean;
    },
  ) {
    super(message);
    this.name = "AppError";
    this.statusCode = options?.statusCode ?? 400;
    this.code = options?.code;
    this.details = options?.details;
    this.expose = options?.expose ?? true;
  }
}
