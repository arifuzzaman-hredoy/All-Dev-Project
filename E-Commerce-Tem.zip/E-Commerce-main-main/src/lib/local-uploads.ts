import crypto from "crypto";
import fs from "fs/promises";
import path from "path";
import {
  deleteCloudinaryImageByUrl,
  isCloudinaryImageUrl,
  uploadBufferToCloudinary,
} from "@/lib/cloudinary-storage";

const ALLOWED_MIME_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
]);

const MAX_SIZE_IN_BYTES = 25 * 1024 * 1024; // 25MB
const UPLOADS_DIR = process.env.UPLOADS_DIR
  ? path.resolve(process.env.UPLOADS_DIR)
  : path.join(process.cwd(), "public", "uploads");

type UploadImageOptions = {
  preserveOriginal?: boolean;
};

export function validateImageFile(file: File): void {
  if (!ALLOWED_MIME_TYPES.has(file.type)) {
    throw new Error("Only PNG, JPG, JPEG, and WEBP images are allowed.");
  }

  if (file.size > MAX_SIZE_IN_BYTES) {
    throw new Error("Image size must be 25MB or less.");
  }
}

function shouldUseCloudinary(): boolean {
  return (process.env.IMAGE_STORAGE_DRIVER || "local").toLowerCase() === "cloudinary";
}

function getLocalUploadFolder(folder: string): string {
  const folderName = folder.split("/").filter(Boolean).at(-1) ?? "products";
  return folderName.replace(/[^a-z0-9_-]/gi, "") || "products";
}

function getExtensionFromMimeType(mimeType: string): string {
  if (mimeType === "image/png") return "png";
  if (mimeType === "image/webp") return "webp";
  return "jpg";
}

async function optimizeImageBuffer(buffer: Buffer): Promise<Buffer | null> {
  try {
    const { default: sharp } = await import("sharp");

    return await sharp(buffer)
      .rotate()
      .resize({
        width: 1800,
        height: 1800,
        fit: "inside",
        withoutEnlargement: true,
      })
      .webp({ quality: 82, effort: 4 })
      .toBuffer();
  } catch (error) {
    console.warn("Image optimization skipped; saving original file.", error);
    return null;
  }
}

export async function uploadImageToLocalUploads(
  file: File,
  folder: string,
  options: UploadImageOptions = {},
): Promise<string> {
  validateImageFile(file);

  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);
  const optimizedBuffer = options.preserveOriginal
    ? null
    : await optimizeImageBuffer(buffer);
  const outputBuffer = optimizedBuffer ?? buffer;
  const extension = optimizedBuffer
    ? "webp"
    : getExtensionFromMimeType(file.type);

  if (shouldUseCloudinary()) {
    return uploadBufferToCloudinary({
      buffer: outputBuffer,
      mimeType: optimizedBuffer ? "image/webp" : file.type,
      folder,
      filename: `${crypto.randomUUID()}.${extension}`,
    });
  }

  const uploadFolder = getLocalUploadFolder(folder);
  const filename = `${crypto.randomUUID()}.${extension}`;
  const uploadDir = path.join(UPLOADS_DIR, uploadFolder);

  await fs.mkdir(uploadDir, { recursive: true });
  await fs.writeFile(path.join(uploadDir, filename), outputBuffer);

  return `/uploads/${uploadFolder}/${filename}`;
}

export async function deleteLocalUploadByUrl(url: string): Promise<void> {
  if (isCloudinaryImageUrl(url)) {
    await deleteCloudinaryImageByUrl(url);
    return;
  }

  if (!url.startsWith("/uploads/")) return;

  try {
    const relativePath = url.replace(/^\/uploads\//, "");
    const filePath = path.normalize(path.join(UPLOADS_DIR, relativePath));

    if (!filePath.startsWith(UPLOADS_DIR + path.sep)) return;

    await fs.unlink(filePath);
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      error.code === "ENOENT"
    ) {
      return;
    }

    console.error("Failed to delete upload:", { url, error });
  }
}

export async function deleteLocalUploadsByUrls(urls: string[]): Promise<void> {
  const uniqueUrls = Array.from(
    new Set(urls.map((x) => x.trim()).filter(Boolean)),
  );

  await Promise.all(uniqueUrls.map((url) => deleteLocalUploadByUrl(url)));
}
