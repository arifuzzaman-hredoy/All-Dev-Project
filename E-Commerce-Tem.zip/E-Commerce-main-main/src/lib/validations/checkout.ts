import { z } from "zod";

export function normalizeBangladeshPhone(value: string): string {
  const digits = value.replace(/\D+/g, "");

  if (digits.startsWith("880") && digits.length === 13) {
    return digits.slice(2);
  }

  if (digits.startsWith("88") && digits.length === 13) {
    return digits.slice(2);
  }

  return digits;
}

const bangladeshPhoneSchema = z
  .string()
  .trim()
  .transform(normalizeBangladeshPhone)
  .refine((value) => /^01\d{9}$/.test(value), {
    message: "Enter a valid 11-digit Bangladesh phone number",
  });

export const checkoutSchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        variantId: z.string().min(1).optional(),
        qty: z.coerce.number().int().min(1).max(20),
      }),
    )
    .min(1),

  couponCode: z.string().trim().max(50).optional(),
  paymentMethod: z.enum(["COD", "ONLINE", "MANUAL"]),

  name: z.string().trim().min(2).max(120),
  email: z.string().email().optional(),
  phone: bangladeshPhoneSchema,

  addressLine1: z.string().trim().min(3).max(255),
  addressLine2: z.string().trim().max(255).optional(),

  city: z.string().trim().min(2).max(100),
  area: z.string().trim().min(2, "Please select a police station").max(100),

  note: z.string().trim().max(500).optional(),
});

export const manualPaymentSubmitSchema = z.object({
  token: z.string().min(20),
  provider: z.enum(["BKASH", "NAGAD", "ROCKET"]),
  senderPhone: z.string().trim().min(8).max(20),
  transactionId: z.string().trim().min(4).max(100),
  amount: z.coerce.number().int().min(0),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
export type ManualPaymentSubmitInput = z.infer<typeof manualPaymentSubmitSchema>;
