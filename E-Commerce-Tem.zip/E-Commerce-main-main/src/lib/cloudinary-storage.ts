import crypto from "crypto";

export type CloudinaryUploadInput = {
  buffer: Buffer;
  mimeType: string;
  folder: string;
  filename?: string;
};

type CloudinaryUploadResponse = {
  secure_url?: string;
  public_id?: string;
  error?: { message?: string };
};

type CloudinaryDestroyResponse = {
  result?: string;
  error?: { message?: string };
};

function getCloudinaryConfig() {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME?.trim();
  const apiKey = process.env.CLOUDINARY_API_KEY?.trim();
  const apiSecret = process.env.CLOUDINARY_API_SECRET?.trim();
  const baseFolder = sanitizeFolderPart(
    process.env.CLOUDINARY_FOLDER?.trim() || "ecommerce",
  );

  if (!cloudName || !apiKey || !apiSecret) {
    throw new Error(
      "Cloudinary is enabled but CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, or CLOUDINARY_API_SECRET is missing.",
    );
  }

  return { cloudName, apiKey, apiSecret, baseFolder };
}

function sanitizeFolderPart(value: string): string {
  return value
    .split("/")
    .map((part) => part.replace(/[^a-z0-9_-]/gi, "").trim())
    .filter(Boolean)
    .join("/");
}

function normalizeUploadFolder(folder: string): string {
  const folderName = folder.split("/").filter(Boolean).at(-1) ?? "uploads";
  return sanitizeFolderPart(folderName) || "uploads";
}

function signCloudinaryParams(
  params: Record<string, string | number | boolean | undefined>,
  apiSecret: string,
): string {
  const payload = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== "")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("&");

  return crypto
    .createHash("sha1")
    .update(`${payload}${apiSecret}`)
    .digest("hex");
}

export function isCloudinaryImageUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && parsed.hostname === "res.cloudinary.com";
  } catch {
    return false;
  }
}

export function isAllowedStoredImageUrl(url: string): boolean {
  const value = url.trim();
  if (!value) return false;
  if (value.startsWith("/uploads/")) return true;
  return isCloudinaryImageUrl(value);
}

export async function uploadBufferToCloudinary({
  buffer,
  mimeType,
  folder,
  filename,
}: CloudinaryUploadInput): Promise<string> {
  const { cloudName, apiKey, apiSecret, baseFolder } = getCloudinaryConfig();
  const uploadFolder = [baseFolder, normalizeUploadFolder(folder)]
    .filter(Boolean)
    .join("/");
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const paramsToSign = {
    folder: uploadFolder,
    timestamp,
  };
  const signature = signCloudinaryParams(paramsToSign, apiSecret);

  const form = new FormData();
  form.append(
    "file",
    new Blob([new Uint8Array(buffer)], { type: mimeType }),
    filename || "upload",
  );
  form.append("api_key", apiKey);
  form.append("timestamp", timestamp);
  form.append("folder", uploadFolder);
  form.append("signature", signature);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
    {
      method: "POST",
      body: form,
    },
  );

  const json = (await response.json().catch(() => ({}))) as CloudinaryUploadResponse;

  if (!response.ok || !json.secure_url) {
    throw new Error(json.error?.message || "Cloudinary image upload failed.");
  }

  return json.secure_url;
}

export function getCloudinaryPublicIdFromUrl(url: string): string | null {
  if (!isCloudinaryImageUrl(url)) return null;

  try {
    const parsed = new URL(url);
    const marker = "/image/upload/";
    const markerIndex = parsed.pathname.indexOf(marker);
    if (markerIndex === -1) return null;

    let publicPath = parsed.pathname.slice(markerIndex + marker.length);
    publicPath = publicPath.replace(/^v\d+\//, "");
    publicPath = publicPath.replace(/\.[a-z0-9]+$/i, "");
    publicPath = decodeURIComponent(publicPath);

    return publicPath || null;
  } catch {
    return null;
  }
}

export async function deleteCloudinaryImageByUrl(url: string): Promise<void> {
  const publicId = getCloudinaryPublicIdFromUrl(url);
  if (!publicId) return;

  const { cloudName, apiKey, apiSecret } = getCloudinaryConfig();
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const paramsToSign = {
    public_id: publicId,
    timestamp,
  };
  const signature = signCloudinaryParams(paramsToSign, apiSecret);

  const form = new FormData();
  form.append("public_id", publicId);
  form.append("api_key", apiKey);
  form.append("timestamp", timestamp);
  form.append("signature", signature);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/image/destroy`,
    {
      method: "POST",
      body: form,
    },
  );

  const json = (await response.json().catch(() => ({}))) as CloudinaryDestroyResponse;

  if (!response.ok) {
    console.error("Cloudinary delete failed:", json.error?.message || response.statusText);
  }
}
