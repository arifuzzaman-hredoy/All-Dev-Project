import type { ZodError } from "zod";

export function formatZodError(error: ZodError): string {
  const issues = error.issues
    .map((issue) => {
      const path = issue.path.length ? issue.path.join(".") : "request";
      return `${path}: ${issue.message}`;
    })
    .filter(Boolean);

  if (issues.length === 0) {
    return "Invalid request data";
  }

  return issues.join("; ");
}
