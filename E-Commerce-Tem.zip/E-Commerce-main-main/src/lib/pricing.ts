export type ShippingRuleType = "DISTRICT" | "POLICE_STATION";

export type ShippingRule = {
  id: string;
  type: ShippingRuleType;
  district: string;
  policeStation?: string | null;
  charge: number;
};

export type StorePricingSettings = {
  taxRate: number;
  shippingInsideDhaka: number;
  shippingRangpur: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  shippingDefaultCharge?: number;
  shippingRules?: ShippingRule[] | null;
};

export type TotalsInput = {
  subtotal: number;
  discount: number;
  district: string;
  policeStation?: string | null;
  settings: StorePricingSettings;
};

export type TotalsOutput = {
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  shippingSource: "FREE" | "POLICE_STATION" | "DISTRICT" | "DEFAULT" | "LEGACY";
  matchedRule: ShippingRule | null;
};

function clampInt(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.floor(n));
}

function cleanText(value: string | null | undefined): string {
  return (value || "").replace(/\s+/g, " ").trim();
}

function normalizeLooseText(value: string): string {
  return cleanText(value)
    .toLowerCase()
    .replace(/['’`]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isDhakaDistrict(value: string): boolean {
  const normalized = normalizeLooseText(value);
  return (
    normalized === "dhaka" ||
    normalized === "dhaka city" ||
    normalized === "dhaka sub urban" ||
    normalized === "dhaka suburban"
  );
}

function isRangpurDistrict(value: string): boolean {
  return normalizeLooseText(value) === "rangpur";
}

export function normalizeShippingRules(input: unknown): ShippingRule[] {
  if (!Array.isArray(input)) return [];

  const seen = new Set<string>();

  return input
    .map((item): ShippingRule | null => {
      const row =
        item && typeof item === "object" && !Array.isArray(item)
          ? (item as Record<string, unknown>)
          : null;

      if (!row) return null;

      const type =
        row.type === "DISTRICT" || row.type === "POLICE_STATION"
          ? row.type
          : null;

      const district =
        typeof row.district === "string" ? cleanText(row.district) : "";
      const policeStation =
        typeof row.policeStation === "string"
          ? cleanText(row.policeStation)
          : null;
      const charge = clampInt(Number(row.charge ?? 0));
      const id =
        typeof row.id === "string" && row.id.trim()
          ? row.id.trim()
          : `${type ?? "UNKNOWN"}:${district}:${policeStation ?? ""}:${charge}`;

      if (!type || !district) return null;
      if (type === "POLICE_STATION" && !policeStation) return null;

      const dedupeKey = [
        type,
        normalizeLooseText(district),
        normalizeLooseText(policeStation ?? ""),
      ].join("|");

      if (seen.has(dedupeKey)) return null;
      seen.add(dedupeKey);

      return {
        id,
        type,
        district,
        policeStation,
        charge,
      };
    })
    .filter((item): item is ShippingRule => item !== null);
}

export function resolveShippingCharge(params: {
  subtotal: number;
  discount: number;
  district: string;
  policeStation?: string | null;
  settings: StorePricingSettings;
}): {
  shipping: number;
  shippingSource: "FREE" | "POLICE_STATION" | "DISTRICT" | "DEFAULT" | "LEGACY";
  matchedRule: ShippingRule | null;
} {
  const subtotal = clampInt(params.subtotal);
  const discount = clampInt(params.discount);
  const discounted = Math.max(0, subtotal - discount);

  const freeOver = clampInt(params.settings.shippingFreeOver);
  if (freeOver > 0 && discounted >= freeOver) {
    return {
      shipping: 0,
      shippingSource: "FREE",
      matchedRule: null,
    };
  }

  const districtKey = normalizeLooseText(params.district);
  const policeStationKey = normalizeLooseText(params.policeStation || "");
  const rules = normalizeShippingRules(params.settings.shippingRules);

  const matchedPoliceStationRule =
    policeStationKey && districtKey
      ? rules.find(
        (rule) =>
          rule.type === "POLICE_STATION" &&
          normalizeLooseText(rule.district) === districtKey &&
          normalizeLooseText(rule.policeStation || "") === policeStationKey,
      ) || null
      : null;

  if (matchedPoliceStationRule) {
    return {
      shipping: clampInt(matchedPoliceStationRule.charge),
      shippingSource: "POLICE_STATION",
      matchedRule: matchedPoliceStationRule,
    };
  }

  const matchedDistrictRule =
    districtKey
      ? rules.find(
        (rule) =>
          rule.type === "DISTRICT" &&
          normalizeLooseText(rule.district) === districtKey,
      ) || null
      : null;

  if (matchedDistrictRule) {
    return {
      shipping: clampInt(matchedDistrictRule.charge),
      shippingSource: "DISTRICT",
      matchedRule: matchedDistrictRule,
    };
  }

  const hasModernConfig =
    typeof params.settings.shippingDefaultCharge === "number" || rules.length > 0;

  if (hasModernConfig) {
    return {
      shipping: clampInt(params.settings.shippingDefaultCharge ?? 0),
      shippingSource: "DEFAULT",
      matchedRule: null,
    };
  }

  if (isDhakaDistrict(params.district)) {
    return {
      shipping: clampInt(params.settings.shippingInsideDhaka),
      shippingSource: "LEGACY",
      matchedRule: null,
    };
  }

  if (isRangpurDistrict(params.district)) {
    return {
      shipping: clampInt(params.settings.shippingRangpur),
      shippingSource: "LEGACY",
      matchedRule: null,
    };
  }

  return {
    shipping: clampInt(params.settings.shippingOutsideDhaka),
    shippingSource: "LEGACY",
    matchedRule: null,
  };
}

export function calcTotals(input: TotalsInput): TotalsOutput {
  const subtotal = clampInt(input.subtotal);
  const discount = clampInt(input.discount);
  const discounted = Math.max(0, subtotal - discount);

  const taxRate = clampInt(input.settings.taxRate);
  const shippingResult = resolveShippingCharge({
    subtotal,
    discount,
    district: input.district,
    policeStation: input.policeStation,
    settings: input.settings,
  });

  const tax = clampInt((discounted * taxRate) / 100);
  const total = Math.max(0, discounted + shippingResult.shipping + tax);

  return {
    subtotal,
    discount,
    shipping: shippingResult.shipping,
    tax,
    total,
    shippingSource: shippingResult.shippingSource,
    matchedRule: shippingResult.matchedRule,
  };
}