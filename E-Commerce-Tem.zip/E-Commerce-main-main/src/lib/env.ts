import { z } from "zod";

const envBoolean = z.enum(["true", "false"]).transform((v) => v === "true");

const serverSchema = z
  .object({
    NODE_ENV: z
      .enum(["development", "test", "production"])
      .default("development"),

    DATABASE_URL: z.string().min(1, "DATABASE_URL required"),

    NEXTAUTH_URL: z.string().url(),
    NEXTAUTH_SECRET: z.string().min(16),

    APP_NAME: z.string().default("NexoraMart"),

    IMAGE_STORAGE_DRIVER: z.enum(["local", "cloudinary"]).default("local"),
    CLOUDINARY_CLOUD_NAME: z.string().optional(),
    CLOUDINARY_API_KEY: z.string().optional(),
    CLOUDINARY_API_SECRET: z.string().optional(),
    CLOUDINARY_FOLDER: z.string().default("ecommerce"),

    STEADFAST_API_KEY: z.string().optional(),
    STEADFAST_SECRET_KEY: z.string().optional(),
    STEADFAST_BASE_URL: z.string().url().optional(),
    STEADFAST_ENABLED: envBoolean.optional(),
    STEADFAST_ORDER_ENDPOINT: z.string().optional(),
    STEADFAST_STATUS_ENDPOINT: z.string().optional(),
    STEADFAST_WEBHOOK_SECRET: z.string().optional(),
    CRON_SECRET: z.string().optional(),

    SSLCOMMERZ_STORE_ID: z.string().min(1),
    SSLCOMMERZ_STORE_PASS: z.string().min(1),
    SSLCOMMERZ_IS_LIVE: envBoolean,

    SMTP_HOST: z.string().optional(),
    SMTP_PORT: z.coerce.number().optional(),
    SMTP_USER: z.string().optional(),
    SMTP_PASS: z.string().optional(),
    SMTP_FROM: z.string().optional(),
    RESEND_API_KEY: z.string().optional(),
    RESEND_FROM_EMAIL: z.string().optional(),
  })
  .superRefine((env, ctx) => {
    if (env.IMAGE_STORAGE_DRIVER !== "cloudinary") return;

    const requiredCloudinaryKeys = [
      "CLOUDINARY_CLOUD_NAME",
      "CLOUDINARY_API_KEY",
      "CLOUDINARY_API_SECRET",
    ] as const;

    for (const key of requiredCloudinaryKeys) {
      if (!env[key]?.trim()) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: [key],
          message: `${key} required when IMAGE_STORAGE_DRIVER=cloudinary`,
        });
      }
    }
  });

const clientSchema = z
  .object({
    NEXT_PUBLIC_BASE_URL: z.string().url().optional(),
    NEXT_PUBLIC_SITE_URL: z.string().url().optional(),
    NEXT_PUBLIC_CURRENCY: z.string().default("BDT"),
  })
  .superRefine((env, ctx) => {
    if (!env.NEXT_PUBLIC_BASE_URL && !env.NEXT_PUBLIC_SITE_URL) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["NEXT_PUBLIC_BASE_URL"],
        message: "NEXT_PUBLIC_BASE_URL or NEXT_PUBLIC_SITE_URL required",
      });
    }
  });

const serverParsed = serverSchema.safeParse(process.env);
if (!serverParsed.success) {
  console.error("Server env error:", serverParsed.error.format());
  throw new Error("Invalid server environment variables");
}

const clientParsed = clientSchema.safeParse(process.env);
if (!clientParsed.success) {
  console.error("Client env error:", clientParsed.error.format());
  throw new Error("Invalid client environment variables");
}

const publicBaseUrl =
  clientParsed.data.NEXT_PUBLIC_BASE_URL ?? clientParsed.data.NEXT_PUBLIC_SITE_URL!;

export const env = {
  ...serverParsed.data,
  ...clientParsed.data,
  NEXT_PUBLIC_BASE_URL: publicBaseUrl,
  NEXT_PUBLIC_SITE_URL: publicBaseUrl,
};
