import { NextResponse } from "next/server";

type SuccessResponse<T = unknown> = {
  success: true;
  message?: string;
  data?: T;
};

type ErrorResponse = {
  success: false;
  message: string;
  errors?: unknown;
};

export function ok<T>(data?: T, message = "Success", status = 200) {
  const body: SuccessResponse<T> = {
    success: true,
    message,
    data,
  };

  return NextResponse.json(body, { status });
}

export function fail(message = "Bad Request", status = 400, errors?: unknown) {
  const body: ErrorResponse = {
    success: false,
    message,
    ...(errors ? { errors } : {}),
  };

  return NextResponse.json(body, { status });
}
