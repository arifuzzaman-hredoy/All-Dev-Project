import { prisma } from "@/lib/prisma";
import { getResendClient, getResendFromEmail } from "@/lib/resend";
import { OrderStatus, PaymentStatus, Role } from "@prisma/client";

function shortOrderId(order: { publicOrderId?: string | null; id: string }): string {
    return order.publicOrderId?.trim() || order.id.slice(-8).toUpperCase();
}

function formatMoney(amount: number): string {
    return `৳${Number(amount || 0)}`;
}

async function createNotification(params: {
    userId: string;
    title: string;
    message: string;
    linkUrl?: string | null;
    orderId?: string | null;
}) {
    await prisma.notification.create({
        data: {
            userId: params.userId,
            title: params.title,
            message: params.message,
            linkUrl: params.linkUrl ?? null,
            orderId: params.orderId ?? null,
        },
    });
}

async function sendEmail(params: {
    to: string;
    subject: string;
    html: string;
}) {
    const resend = getResendClient();
    if (!resend) return;

    try {
        await resend.emails.send({
            from: getResendFromEmail(),
            to: params.to,
            subject: params.subject,
            html: params.html,
        });
    } catch (error) {
        console.error("Resend email failed:", error);
    }
}

async function getOrderForNotification(orderId: string) {
    return prisma.order.findUnique({
        where: { id: orderId },
        include: {
            user: {
                select: {
                    id: true,
                    name: true,
                    email: true,
                },
            },
            items: {
                select: {
                    id: true,
                    productName: true,
                    qty: true,
                    lineTotal: true,
                },
            },
        },
    });
}

function orderPlacedEmailHtml(params: {
    customerName: string;
    orderId: string;
    total: number;
    status: string;
    paymentStatus: string;
}) {
    return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Order confirmed</h2>
      <p>Hello ${params.customerName},</p>
      <p>Your order has been placed successfully.</p>
      <div style="padding:14px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa;">
        <p style="margin:4px 0;"><strong>Order ID:</strong> ${params.orderId}</p>
        <p style="margin:4px 0;"><strong>Total:</strong> ${formatMoney(params.total)}</p>
        <p style="margin:4px 0;"><strong>Status:</strong> ${params.status}</p>
        <p style="margin:4px 0;"><strong>Payment:</strong> ${params.paymentStatus}</p>
      </div>
      <p style="margin-top:16px;">Thank you for shopping with us.</p>
    </div>
  `;
}

function orderUpdateEmailHtml(params: {
    customerName: string;
    orderId: string;
    total: number;
    status: string;
    paymentStatus: string;
    changedStatus: boolean;
    changedPayment: boolean;
}) {
    return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Order updated</h2>
      <p>Hello ${params.customerName},</p>
      <p>Your order information has been updated.</p>
      <div style="padding:14px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa;">
        <p style="margin:4px 0;"><strong>Order ID:</strong> ${params.orderId}</p>
        <p style="margin:4px 0;"><strong>Total:</strong> ${formatMoney(params.total)}</p>
        <p style="margin:4px 0;"><strong>Status:</strong> ${params.status}${params.changedStatus ? " (updated)" : ""}</p>
        <p style="margin:4px 0;"><strong>Payment:</strong> ${params.paymentStatus}${params.changedPayment ? " (updated)" : ""}</p>
      </div>
      <p style="margin-top:16px;">Please check your account/order page for details.</p>
    </div>
  `;
}

function courierBookedEmailHtml(params: {
    customerName: string;
    orderId: string;
    trackingId: string | null;
}) {
    return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Your order has been booked in Steadfast</h2>
      <p>Hello ${params.customerName},</p>
      <p>Your order has been handed over to Steadfast Courier.</p>
      <div style="padding:14px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa;">
        <p style="margin:4px 0;"><strong>Order ID:</strong> ${params.orderId}</p>
        <p style="margin:4px 0;"><strong>Courier:</strong> Steadfast</p>
        <p style="margin:4px 0;"><strong>Tracking ID:</strong> ${params.trackingId || "Will be updated soon"}</p>
      </div>
      <p style="margin-top:16px;">You can now follow the latest update from your order details page.</p>
    </div>
  `;
}

function courierStatusEmailHtml(params: {
    customerName: string;
    orderId: string;
    orderStatus: string;
    courierStatus: string | null;
    trackingId: string | null;
}) {
    return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Courier status updated</h2>
      <p>Hello ${params.customerName},</p>
      <p>Your Steadfast courier update has changed.</p>
      <div style="padding:14px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa;">
        <p style="margin:4px 0;"><strong>Order ID:</strong> ${params.orderId}</p>
        <p style="margin:4px 0;"><strong>Order Status:</strong> ${params.orderStatus}</p>
        <p style="margin:4px 0;"><strong>Courier Status:</strong> ${params.courierStatus || "Updated"}</p>
        <p style="margin:4px 0;"><strong>Tracking ID:</strong> ${params.trackingId || "Not available yet"}</p>
      </div>
      <p style="margin-top:16px;">Please check your account/order page for details.</p>
    </div>
  `;
}

export async function notifyOrderPlaced(orderId: string) {
    const order = await getOrderForNotification(orderId);
    if (!order) return;

    const shortId = shortOrderId(order);

    const admins = await prisma.user.findMany({
        where: {
            role: { in: [Role.ADMIN, Role.STAFF] },
            blocked: false,
        },
        select: { id: true },
    });

    if (admins.length) {
        await prisma.notification.createMany({
            data: admins.map((admin) => ({
                userId: admin.id,
                title: `New order #${shortId}`,
                message: `${order.name} placed an order for ${formatMoney(order.total)}.`,
                linkUrl: `/admin/orders/${order.id}`,
                orderId: order.id,
            })),
        });
    }

    if (order.userId) {
        await createNotification({
            userId: order.userId,
            title: `Order placed #${shortId}`,
            message: `Your order for ${formatMoney(order.total)} has been placed successfully.`,
            linkUrl: `/orders/${order.id}`,
            orderId: order.id,
        });
    }

    if (order.email) {
        await sendEmail({
            to: order.email,
            subject: `Order confirmed #${shortId}`,
            html: orderPlacedEmailHtml({
                customerName: order.name,
                orderId: shortId,
                total: order.total,
                status: order.status,
                paymentStatus: order.paymentStatus,
            }),
        });
    }
}

export async function notifyOrderUpdated(params: {
    orderId: string;
    previousStatus?: OrderStatus;
    previousPaymentStatus?: PaymentStatus;
}) {
    const order = await getOrderForNotification(params.orderId);
    if (!order) return;

    const statusChanged =
        !!params.previousStatus && params.previousStatus !== order.status;
    const paymentChanged =
        !!params.previousPaymentStatus &&
        params.previousPaymentStatus !== order.paymentStatus;

    if (!statusChanged && !paymentChanged) return;

    const shortId = shortOrderId(order);

    let title = `Order updated #${shortId}`;
    let message = `Your order has been updated.`;

    if (statusChanged && paymentChanged) {
        title = `Order & payment updated #${shortId}`;
        message = `Order status is now ${order.status} and payment status is ${order.paymentStatus}.`;
    } else if (statusChanged) {
        title = `Order status updated #${shortId}`;
        message = `Your order status is now ${order.status}.`;
    } else if (paymentChanged) {
        title = `Payment updated #${shortId}`;
        message = `Your payment status is now ${order.paymentStatus}.`;
    }

    if (order.userId) {
        await createNotification({
            userId: order.userId,
            title,
            message,
            linkUrl: `/orders/${order.id}`,
            orderId: order.id,
        });
    }

    if (order.email) {
        await sendEmail({
            to: order.email,
            subject: title,
            html: orderUpdateEmailHtml({
                customerName: order.name,
                orderId: shortId,
                total: order.total,
                status: order.status,
                paymentStatus: order.paymentStatus,
                changedStatus: statusChanged,
                changedPayment: paymentChanged,
            }),
        });
    }
}

export async function notifySteadfastBooked(params: {
    orderId: string;
    trackingId: string | null;
}) {
    const order = await getOrderForNotification(params.orderId);
    if (!order) return;

    const shortId = shortOrderId(order);
    const title = `Booked in Steadfast #${shortId}`;
    const message = params.trackingId
        ? `Your order has been booked in Steadfast. Tracking ID: ${params.trackingId}.`
        : `Your order has been booked in Steadfast.`;

    if (order.userId) {
        await createNotification({
            userId: order.userId,
            title,
            message,
            linkUrl: `/orders/${order.id}`,
            orderId: order.id,
        });
    }

    if (order.email) {
        await sendEmail({
            to: order.email,
            subject: title,
            html: courierBookedEmailHtml({
                customerName: order.name,
                orderId: shortId,
                trackingId: params.trackingId,
            }),
        });
    }
}

export async function notifySteadfastStatusChanged(params: {
    orderId: string;
    previousOrderStatus?: OrderStatus;
    newOrderStatus: OrderStatus;
    courierStatus: string | null;
    trackingId: string | null;
}) {
    const order = await getOrderForNotification(params.orderId);
    if (!order) return;

    const shortId = shortOrderId(order);
    const statusLabel = params.courierStatus || params.newOrderStatus;

    const title = `Courier update #${shortId}`;
    const message = params.trackingId
        ? `Steadfast status is now ${statusLabel}. Tracking ID: ${params.trackingId}.`
        : `Steadfast status is now ${statusLabel}.`;

    if (order.userId) {
        await createNotification({
            userId: order.userId,
            title,
            message,
            linkUrl: `/orders/${order.id}`,
            orderId: order.id,
        });
    }

    if (order.email) {
        await sendEmail({
            to: order.email,
            subject: title,
            html: courierStatusEmailHtml({
                customerName: order.name,
                orderId: shortId,
                orderStatus: params.newOrderStatus,
                courierStatus: params.courierStatus,
                trackingId: params.trackingId,
            }),
        });
    }
}

function reviewSubmittedEmailHtml(params: {
    customerName: string;
    productName: string;
    rating: number;
}) {
    return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h2 style="margin-bottom:8px;">Review submitted</h2>
      <p>Hello ${params.customerName},</p>
      <p>Your review has been submitted successfully.</p>
      <div style="padding:14px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa;">
        <p style="margin:4px 0;"><strong>Product:</strong> ${params.productName}</p>
        <p style="margin:4px 0;"><strong>Rating:</strong> ${params.rating}/5</p>
      </div>
      <p style="margin-top:16px;">Thank you for sharing your feedback.</p>
    </div>
  `;
}

export async function notifyReviewSubmitted(params: {
    userId: string;
    slug: string;
    productName: string;
    rating: number;
    customerName?: string | null;
    customerEmail?: string | null;
}) {
    const admins = await prisma.user.findMany({
        where: {
            role: { in: [Role.ADMIN, Role.STAFF] },
            blocked: false,
        },
        select: { id: true },
    });

    if (admins.length) {
        await prisma.notification.createMany({
            data: admins.map((admin) => ({
                userId: admin.id,
                title: `New review on ${params.productName}`,
                message: `${params.customerName || "A customer"} submitted a ${params.rating}-star review.`,
                linkUrl: `/products/${params.slug}`,
                orderId: null,
            })),
        });
    }

    await createNotification({
        userId: params.userId,
        title: "Review submitted",
        message: `Your review for ${params.productName} has been submitted successfully.`,
        linkUrl: `/products/${params.slug}`,
        orderId: null,
    });

    if (params.customerEmail) {
        await sendEmail({
            to: params.customerEmail,
            subject: `Review submitted for ${params.productName}`,
            html: reviewSubmittedEmailHtml({
                customerName: params.customerName || "Customer",
                productName: params.productName,
                rating: params.rating,
            }),
        });
    }
}