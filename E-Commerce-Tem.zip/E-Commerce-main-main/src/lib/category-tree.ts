export type CategoryTreeItem = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  isActive?: boolean;
};

export type CategoryTreeNode = CategoryTreeItem & {
  children: CategoryTreeNode[];
};

export function buildCategoryTree(
  items: CategoryTreeItem[],
): CategoryTreeNode[] {
  const map = new Map<string, CategoryTreeNode>();

  for (const item of items) {
    map.set(item.id, {
      ...item,
      children: [],
    });
  }

  const roots: CategoryTreeNode[] = [];

  for (const node of map.values()) {
    if (node.parentId && map.has(node.parentId)) {
      map.get(node.parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  }

  const sortRecursive = (nodes: CategoryTreeNode[]) => {
    nodes.sort((a, b) => a.name.localeCompare(b.name));
    for (const node of nodes) {
      sortRecursive(node.children);
    }
  };

  sortRecursive(roots);

  return roots;
}

export function getDescendantCategoryIds(
  categoryId: string,
  items: Array<{
    id: string;
    parentId: string | null;
  }>,
): string[] {
  const childrenMap = new Map<string, string[]>();

  for (const item of items) {
    if (!item.parentId) continue;

    const prev = childrenMap.get(item.parentId) ?? [];
    prev.push(item.id);
    childrenMap.set(item.parentId, prev);
  }

  const result = new Set<string>([categoryId]);
  const queue = [categoryId];

  while (queue.length > 0) {
    const current = queue.shift()!;
    const children = childrenMap.get(current) ?? [];

    for (const childId of children) {
      if (!result.has(childId)) {
        result.add(childId);
        queue.push(childId);
      }
    }
  }

  return Array.from(result);
}

export function getCategoryDisplayPath(
  categoryId: string,
  items: Array<{
    id: string;
    name: string;
    parentId: string | null;
  }>,
): string {
  const map = new Map(items.map((item) => [item.id, item]));
  const parts: string[] = [];

  let current = map.get(categoryId);
  while (current) {
    parts.unshift(current.name);
    current = current.parentId ? map.get(current.parentId) : undefined;
  }

  return parts.join(" → ");
}
