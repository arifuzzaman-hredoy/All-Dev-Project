export type SiteFontOption = {
  value: string;
  label: string;
  cssFamily: string;
  googleFamily: string;
  sample: string;
};

export const DEFAULT_SITE_FONT = "Inter";
export const DEFAULT_BANGLA_FONT = "Noto Sans Bengali";
const FONT_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9 -]{0,79}$/;

export const SITE_FONT_OPTIONS: SiteFontOption[] = [
  {
    value: "Inter",
    label: "Inter",
    cssFamily: '"Inter"',
    googleFamily: "Inter:wght@400;500;600;700;800",
    sample: "Clean modern shopping text",
  },
  {
    value: "Poppins",
    label: "Poppins",
    cssFamily: '"Poppins"',
    googleFamily: "Poppins:wght@400;500;600;700;800",
    sample: "Bold product cards and buttons",
  },
  {
    value: "Roboto",
    label: "Roboto",
    cssFamily: '"Roboto"',
    googleFamily: "Roboto:wght@400;500;700",
    sample: "Simple readable interface",
  },
  {
    value: "Lato",
    label: "Lato",
    cssFamily: '"Lato"',
    googleFamily: "Lato:wght@400;700;900",
    sample: "Friendly store typography",
  },
  {
    value: "Montserrat",
    label: "Montserrat",
    cssFamily: '"Montserrat"',
    googleFamily: "Montserrat:wght@400;500;600;700;800",
    sample: "Premium catalog feel",
  },
  {
    value: "Open Sans",
    label: "Open Sans",
    cssFamily: '"Open Sans"',
    googleFamily: "Open Sans:wght@400;500;600;700",
    sample: "Readable long descriptions",
  },
];

export const BANGLA_FONT_OPTIONS: SiteFontOption[] = [
  {
    value: "Noto Sans Bengali",
    label: "Noto Sans Bengali",
    cssFamily: '"Noto Sans Bengali"',
    googleFamily: "Noto Sans Bengali:wght@400;500;600;700;800",
    sample: "বাংলা লেখা পরিষ্কার দেখাবে",
  },
  {
    value: "Hind Siliguri",
    label: "Hind Siliguri",
    cssFamily: '"Hind Siliguri"',
    googleFamily: "Hind Siliguri:wght@400;500;600;700",
    sample: "বাংলা UI এর জন্য সুন্দর",
  },
  {
    value: "Anek Bangla",
    label: "Anek Bangla",
    cssFamily: '"Anek Bangla"',
    googleFamily: "Anek Bangla:wght@400;500;600;700;800",
    sample: "প্রোডাক্ট নাম ও ক্যাটাগরি",
  },
  {
    value: "Noto Serif Bengali",
    label: "Noto Serif Bengali",
    cssFamily: '"Noto Serif Bengali"',
    googleFamily: "Noto Serif Bengali:wght@400;500;600;700",
    sample: "নীতি ও আর্টিকেল টেক্সট",
  },
  {
    value: "Baloo Da 2",
    label: "Baloo Da 2",
    cssFamily: '"Baloo Da 2"',
    googleFamily: "Baloo Da 2:wght@400;500;600;700;800",
    sample: "নরম ও বন্ধুসুলভ বাংলা",
  },
];

function quoteFontFamily(value: string): string {
  return `"${value.replaceAll('"', "")}"`;
}

function getKnownOrGoogleFont(
  value: unknown,
  fallbackValue: string,
  knownFonts: SiteFontOption[],
): SiteFontOption {
  const fallback =
    knownFonts.find((font) => font.value === fallbackValue) ?? knownFonts[0];

  if (typeof value !== "string") return fallback;

  const normalized = value.trim().replace(/\s+/g, " ");
  const known = knownFonts.find((font) => font.value === normalized);

  if (known) return known;
  if (!FONT_NAME_PATTERN.test(normalized)) return fallback;

  return {
    value: normalized,
    label: normalized,
    cssFamily: quoteFontFamily(normalized),
    googleFamily: normalized,
    sample: normalized,
  };
}

export function resolveSiteFont(value: unknown): SiteFontOption {
  return getKnownOrGoogleFont(value, DEFAULT_SITE_FONT, SITE_FONT_OPTIONS);
}

export function resolveBanglaFont(value: unknown): SiteFontOption {
  return getKnownOrGoogleFont(
    value,
    DEFAULT_BANGLA_FONT,
    BANGLA_FONT_OPTIONS,
  );
}

export function getGoogleFontsHref(fonts: SiteFontOption[]): string {
  const families = Array.from(new Set(fonts.map((font) => font.googleFamily)));
  const familyQuery = families
    .map((family) => `family=${family.replaceAll(" ", "+")}`)
    .join("&");

  return `https://fonts.googleapis.com/css2?${familyQuery}&display=swap`;
}

export function getSiteFontStack(
  siteFontFamily: unknown,
  banglaFontFamily: unknown,
): string {
  const siteFont = resolveSiteFont(siteFontFamily);
  const banglaFont = resolveBanglaFont(banglaFontFamily);

  return `${siteFont.cssFamily}, ${banglaFont.cssFamily}, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;
}
