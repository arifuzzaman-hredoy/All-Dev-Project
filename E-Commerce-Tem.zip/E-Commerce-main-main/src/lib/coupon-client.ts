export type AppliedCoupon = {
  code: string;
  discount: number;
};

const KEY = "rhc_applied_coupon_v1";

export function saveAppliedCoupon(c: AppliedCoupon): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(c));
  } catch {}
}

export function loadAppliedCoupon(): AppliedCoupon | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const p = JSON.parse(raw) as unknown;
    const o = p as { code?: unknown; discount?: unknown };
    if (typeof o.code !== "string") return null;
    const n = typeof o.discount === "number" ? o.discount : Number(o.discount);
    if (!Number.isFinite(n)) return null;
    return { code: o.code, discount: Math.max(0, Math.floor(n)) };
  } catch {
    return null;
  }
}

export function clearAppliedCoupon(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {}
}