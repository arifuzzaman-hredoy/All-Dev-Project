import { prisma } from "@/lib/prisma";

type ProductLike = {
  id: string;
  price: number;
  offerPrice: number | null;
  categoryId?: string | null;
};

type DiscountScope = "PRODUCT" | "CATEGORY" | "SUBCATEGORY";

type ActiveDiscount = {
  id: string;
  scope: DiscountScope;
  percentage: number;
  productId: string | null;
  categoryId: string | null;
  startsAt: Date | null;
  endsAt: Date | null;
  isActive: boolean;
};

type ProductWithEffectivePrice<T> = T & {
  offerPrice: number | null;
  discountPercentage: number | null;
};

function isDiscountCurrentlyActive(discount: ActiveDiscount, now: Date) {
  if (!discount.isActive) return false;
  if (discount.startsAt && discount.startsAt > now) return false;
  if (discount.endsAt && discount.endsAt < now) return false;
  if (discount.percentage <= 0) return false;
  if (discount.percentage >= 100) return false;
  return true;
}

function calculateDiscountedPrice(regularPrice: number, percentage: number) {
  const discountAmount = Math.floor((regularPrice * percentage) / 100);
  return Math.max(0, regularPrice - discountAmount);
}

function getBestPercentage(percentages: number[]) {
  if (!percentages.length) return null;
  return Math.max(...percentages);
}

export async function attachEffectivePrices<T extends ProductLike>(
  products: T[],
): Promise<Array<ProductWithEffectivePrice<T>>> {
  if (!products.length) return [];

  const now = new Date();
  const productIds = products.map((product) => product.id);

  const legacyCategoryIds = products
    .map((product) => product.categoryId)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  const productCategoryLinks = await prisma.productCategory.findMany({
    where: {
      productId: {
        in: productIds,
      },
    },
    select: {
      productId: true,
      categoryId: true,
    },
  });

  const productCategoryMap = new Map<string, Set<string>>();

  for (const product of products) {
    productCategoryMap.set(product.id, new Set());

    if (product.categoryId) {
      productCategoryMap.get(product.id)?.add(product.categoryId);
    }
  }

  for (const link of productCategoryLinks) {
    if (!productCategoryMap.has(link.productId)) {
      productCategoryMap.set(link.productId, new Set());
    }

    productCategoryMap.get(link.productId)?.add(link.categoryId);
  }

  const allCategoryIds = Array.from(
    new Set([
      ...legacyCategoryIds,
      ...productCategoryLinks.map((link) => link.categoryId),
    ]),
  );

  const categories = allCategoryIds.length
    ? await prisma.category.findMany({
        where: {
          id: {
            in: allCategoryIds,
          },
        },
        select: {
          id: true,
          parentId: true,
        },
      })
    : [];

  const categoryParentMap = new Map(
    categories.map((category) => [category.id, category.parentId] as const),
  );

  const searchableCategoryIds = new Set<string>();

  for (const categoryId of allCategoryIds) {
    searchableCategoryIds.add(categoryId);

    const parentId = categoryParentMap.get(categoryId);
    if (parentId) {
      searchableCategoryIds.add(parentId);
    }
  }

  const discounts = await prisma.productDiscount.findMany({
    where: {
      isActive: true,
      OR: [
        {
          scope: "PRODUCT",
          productId: {
            in: productIds,
          },
        },
        {
          scope: {
            in: ["CATEGORY", "SUBCATEGORY"],
          },
          categoryId: {
            in: Array.from(searchableCategoryIds),
          },
        },
      ],
    },
    select: {
      id: true,
      scope: true,
      percentage: true,
      productId: true,
      categoryId: true,
      startsAt: true,
      endsAt: true,
      isActive: true,
    },
  });

  const activeDiscounts = discounts.filter((discount) =>
    isDiscountCurrentlyActive(discount as ActiveDiscount, now),
  ) as ActiveDiscount[];

  const productDiscountMap = new Map<string, number[]>();
  const categoryDiscountMap = new Map<string, number[]>();

  for (const discount of activeDiscounts) {
    if (discount.scope === "PRODUCT" && discount.productId) {
      const list = productDiscountMap.get(discount.productId) ?? [];
      list.push(discount.percentage);
      productDiscountMap.set(discount.productId, list);
    }

    if (
      (discount.scope === "CATEGORY" || discount.scope === "SUBCATEGORY") &&
      discount.categoryId
    ) {
      const list = categoryDiscountMap.get(discount.categoryId) ?? [];
      list.push(discount.percentage);
      categoryDiscountMap.set(discount.categoryId, list);
    }
  }

  return products.map((product) => {
    const percentages: number[] = [];

    const directProductDiscounts = productDiscountMap.get(product.id) ?? [];
    percentages.push(...directProductDiscounts);

    const productCategoryIds = productCategoryMap.get(product.id) ?? new Set();

    for (const categoryId of productCategoryIds) {
      const categoryDiscounts = categoryDiscountMap.get(categoryId) ?? [];
      percentages.push(...categoryDiscounts);

      const parentId = categoryParentMap.get(categoryId);
      if (parentId) {
        const parentDiscounts = categoryDiscountMap.get(parentId) ?? [];
        percentages.push(...parentDiscounts);
      }
    }

    const bestPercentage = getBestPercentage(percentages);

    if (!bestPercentage) {
      return {
        ...product,
        offerPrice: product.offerPrice,
        discountPercentage: null,
      };
    }

    return {
      ...product,
      offerPrice: calculateDiscountedPrice(product.price, bestPercentage),
      discountPercentage: bestPercentage,
    };
  });
}

export async function attachEffectivePrice<T extends ProductLike>(
  product: T | null,
): Promise<ProductWithEffectivePrice<T> | null> {
  if (!product) return null;

  const [resolved] = await attachEffectivePrices([product]);
  return resolved ?? null;
}
