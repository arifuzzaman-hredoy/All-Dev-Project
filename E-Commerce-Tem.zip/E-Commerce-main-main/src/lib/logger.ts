type LogLevel = "info" | "warn" | "error";

type LogMeta = Record<string, unknown>;

function writeLog(level: LogLevel, message: string, meta?: LogMeta) {
  const payload = {
    level,
    message,
    timestamp: new Date().toISOString(),
    ...(meta ? { meta } : {}),
  };

  if (level === "error") {
    console.error(JSON.stringify(payload));
    return;
  }

  if (level === "warn") {
    console.warn(JSON.stringify(payload));
    return;
  }

  console.log(JSON.stringify(payload));
}

export const logger = {
  info(message: string, meta?: LogMeta) {
    writeLog("info", message, meta);
  },

  warn(message: string, meta?: LogMeta) {
    writeLog("warn", message, meta);
  },

  error(message: string, meta?: LogMeta) {
    writeLog("error", message, meta);
  },
};
