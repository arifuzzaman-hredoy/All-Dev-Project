type Entry = {
  count: number;
  expiresAt: number;
};

const store = new Map<string, Entry>();

type RateLimitOptions = {
  limit: number;
  windowMs: number;
};

export function rateLimit(
  key: string,
  options: RateLimitOptions,
): { success: boolean; remaining: number; resetAt: number } {
  const now = Date.now();
  const current = store.get(key);

  if (!current || current.expiresAt <= now) {
    const next: Entry = {
      count: 1,
      expiresAt: now + options.windowMs,
    };
    store.set(key, next);

    return {
      success: true,
      remaining: options.limit - 1,
      resetAt: next.expiresAt,
    };
  }

  if (current.count >= options.limit) {
    return {
      success: false,
      remaining: 0,
      resetAt: current.expiresAt,
    };
  }

  current.count += 1;
  store.set(key, current);

  return {
    success: true,
    remaining: options.limit - current.count,
    resetAt: current.expiresAt,
  };
}
