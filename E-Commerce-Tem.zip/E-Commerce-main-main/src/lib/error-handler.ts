import { ZodError } from "zod";
import { Prisma } from "@prisma/client";
import { fail } from "@/lib/api-response";
import { AppError } from "@/lib/app-error";
import { logger } from "@/lib/logger";

export function handleApiError(error: unknown) {
  if (error instanceof AppError) {
    if (error.statusCode >= 500) {
      logger.error("AppError", {
        message: error.message,
        code: error.code,
        details: error.details,
        statusCode: error.statusCode,
      });
    }

    return fail(
      error.expose ? error.message : "Something went wrong",
      error.statusCode,
      error.expose ? error.details : undefined,
    );
  }

  if (error instanceof ZodError) {
    logger.warn("Validation failed", {
      issues: error.flatten(),
    });

    return fail("Validation failed", 422, error.flatten());
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    logger.error("Prisma known error", {
      code: error.code,
      message: error.message,
    });

    if (error.code === "P2002") {
      return fail("Duplicate entry", 409);
    }

    if (error.code === "P2025") {
      return fail("Record not found", 404);
    }

    return fail("Database request failed", 500);
  }

  if (error instanceof Prisma.PrismaClientValidationError) {
    logger.error("Prisma validation error", {
      message: error.message,
    });

    return fail("Invalid database query", 400);
  }

  logger.error("Unhandled API error", {
    error: error instanceof Error ? error.message : "Unknown error",
  });

  return fail("Internal server error", 500);
}
