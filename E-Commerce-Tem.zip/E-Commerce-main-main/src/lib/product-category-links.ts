export function normalizeCategoryIds(input: unknown): string[] {
    if (!Array.isArray(input)) return [];

    return Array.from(
        new Set(
            input
                .filter((id): id is string => typeof id === "string")
                .map((id) => id.trim())
                .filter((id) => id.length > 0),
        ),
    );
}