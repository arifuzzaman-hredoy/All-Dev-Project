export type PricingCategoryNode = {
    id: string;
    name?: string | null;
    slug?: string | null;
    discountPercent?: number | null;
    parent?: PricingCategoryNode | null;
};

export type ProductPricingInput = {
    price: number;
    offerPrice?: number | null;
    discountPercent?: number | null;
    category?: PricingCategoryNode | null;
};

export type ProductPricingResult = {
    basePrice: number;
    finalPrice: number;
    offerPrice: number | null;
    appliedDiscountPercent: number;
    discountSource:
    | "PRODUCT"
    | "CATEGORY"
    | "PARENT_CATEGORY"
    | "MANUAL_OFFER"
    | "NONE";
};

function toSafeInt(value: unknown, fallback = 0): number {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.round(n));
}

function normalizePercent(value: unknown): number {
    const n = toSafeInt(value, 0);
    return Math.max(0, Math.min(100, n));
}

function calculatePercentPrice(price: number, percent: number): number {
    const safePrice = toSafeInt(price, 0);
    const safePercent = normalizePercent(percent);
    return Math.max(0, Math.round((safePrice * (100 - safePercent)) / 100));
}

function resolveCategoryDiscount(category?: PricingCategoryNode | null): {
    percent: number;
    source: "CATEGORY" | "PARENT_CATEGORY" | "NONE";
} {
    if (!category) {
        return { percent: 0, source: "NONE" };
    }

    const currentPercent = normalizePercent(category.discountPercent);
    if (currentPercent > 0) {
        return { percent: currentPercent, source: "CATEGORY" };
    }

    let depth = 0;
    let cursor = category.parent ?? null;

    while (cursor) {
        depth += 1;
        const percent = normalizePercent(cursor.discountPercent);
        if (percent > 0) {
            return {
                percent,
                source: depth >= 1 ? "PARENT_CATEGORY" : "CATEGORY",
            };
        }
        cursor = cursor.parent ?? null;
    }

    return { percent: 0, source: "NONE" };
}

export function resolveProductPricing(
    input: ProductPricingInput,
): ProductPricingResult {
    const price = toSafeInt(input.price, 0);
    const manualOffer =
        input.offerPrice === null || typeof input.offerPrice === "undefined"
            ? null
            : toSafeInt(input.offerPrice, 0);

    const productPercent = normalizePercent(input.discountPercent);
    const categoryDiscount = resolveCategoryDiscount(input.category);

    let percent = 0;
    let percentSource: ProductPricingResult["discountSource"] = "NONE";

    if (productPercent > 0) {
        percent = productPercent;
        percentSource = "PRODUCT";
    } else if (categoryDiscount.percent > 0) {
        percent = categoryDiscount.percent;
        percentSource = categoryDiscount.source;
    }

    const percentagePrice =
        percent > 0 ? calculatePercentPrice(price, percent) : null;

    let finalPrice = price;
    let source: ProductPricingResult["discountSource"] = "NONE";

    if (
        typeof manualOffer === "number" &&
        manualOffer > 0 &&
        manualOffer < finalPrice
    ) {
        finalPrice = manualOffer;
        source = "MANUAL_OFFER";
    }

    if (
        typeof percentagePrice === "number" &&
        percentagePrice >= 0 &&
        percentagePrice < finalPrice
    ) {
        finalPrice = percentagePrice;
        source = percentSource;
    }

    return {
        basePrice: price,
        finalPrice,
        offerPrice: finalPrice < price ? finalPrice : null,
        appliedDiscountPercent:
            source === "PRODUCT" ||
                source === "CATEGORY" ||
                source === "PARENT_CATEGORY"
                ? percent
                : 0,
        discountSource: source,
    };
}