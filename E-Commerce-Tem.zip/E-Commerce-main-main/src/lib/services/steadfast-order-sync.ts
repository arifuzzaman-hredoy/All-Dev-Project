import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import {
    fetchSteadfastStatusByInvoice,
    mapSteadfastStatusToOrderStatus,
    mergeSteadfastIntoPaymentMeta,
    normalizeSteadfastDeliveryStatus,
} from "@/lib/couriers/steadfast";

export async function syncSteadfastOrderStatus(orderId: string) {
    const order = await prisma.order.findFirst({
        where: {
            OR: [{ id: orderId }, { publicOrderId: orderId }],
        },
        select: {
            id: true,
            publicOrderId: true,
            status: true,
            courierName: true,
            trackingId: true,
            paymentMeta: true,
        },
    });

    if (!order) {
        return { ok: false as const, error: "Order not found" };
    }

    const invoice = order.publicOrderId || order.id;

    const statusResponse = await fetchSteadfastStatusByInvoice(invoice);

    const data = Array.isArray(statusResponse?.data)
        ? statusResponse.data[0]
        : statusResponse?.data || statusResponse;

    const trackingCode =
        data?.tracking_code ||
        data?.trackingCode ||
        data?.consignment_id ||
        order.trackingId ||
        null;

    const deliveryStatus = normalizeSteadfastDeliveryStatus(
        data?.delivery_status ||
        data?.deliveryStatus ||
        data?.status ||
        data?.current_status ||
        null,
    );

    const mappedStatus = mapSteadfastStatusToOrderStatus(deliveryStatus);

    const nextPaymentMeta = mergeSteadfastIntoPaymentMeta({
        currentPaymentMeta: order.paymentMeta,
        trackingCode: trackingCode ? String(trackingCode) : null,
        consignmentId: data?.consignment_id ? String(data.consignment_id) : null,
        courierStatus: deliveryStatus,
    });

    const updated = await prisma.order.update({
        where: { id: order.id },
        data: {
            courierName: "Steadfast",
            trackingId: trackingCode ? String(trackingCode) : order.trackingId,
            ...(mappedStatus ? { status: mappedStatus } : {}),
            paymentMeta: nextPaymentMeta as Prisma.InputJsonValue,
        },
        select: {
            id: true,
            publicOrderId: true,
            status: true,
            courierName: true,
            trackingId: true,
            paymentMeta: true,
        },
    });

    return {
        ok: true as const,
        order: updated,
        courierStatus: deliveryStatus,
        raw: statusResponse,
    };
}