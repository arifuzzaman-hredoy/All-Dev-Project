import { prisma } from "@/lib/prisma";
import { PaymentMethod, PaymentStatus, Prisma } from "@prisma/client";
import type { CheckoutInput } from "@/lib/validations/checkout";
import { generateIdempotencyKey } from "@/lib/payments/sslcommerz/helpers";
import { AppError } from "../app-error";
import { createNextPublicOrderId } from "@/lib/order-public-id";
import {
  redeemCouponUsage,
  validateCouponByCode,
} from "@/lib/services/coupon-service";
import { calcTotals, normalizeShippingRules } from "@/lib/pricing";
import { attachEffectivePrices } from "@/lib/product-discounts";

type PreparedOrderItem = {
  productId: string;
  variantId?: string;
  productName: string;
  sku: string;
  unitPrice: number;
  qty: number;
  lineTotal: number;
};

type PreparedCheckout = {
  items: PreparedOrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  couponCode?: string;
};

function isOrderCreateUniqueConflict(error: unknown): boolean {
  if (!error || typeof error !== "object") {
    return false;
  }

  const record = error as {
    code?: unknown;
    meta?: unknown;
    message?: unknown;
  };

  if (record.code !== "P2002") {
    return false;
  }

  const meta =
    record.meta && typeof record.meta === "object"
      ? (record.meta as { target?: unknown })
      : null;

  const target = Array.isArray(meta?.target)
    ? meta.target.map(String).join(",")
    : typeof meta?.target === "string"
      ? meta.target
      : "";

  const message = typeof record.message === "string" ? record.message : "";

  return (
    target.includes("publicOrderId") ||
    target.includes("orderSequence") ||
    message.includes("publicOrderId") ||
    message.includes("orderSequence") ||
    record.code === "P2002"
  );
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;

  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwarePrice(params: {
  productPrice: number;
  productOfferPrice: number | null;
  variantPriceDiff: number | null;
}) {
  const baseOriginalPrice = safeNumber(params.productPrice, 0);

  const baseDiscountedPrice = safeNumber(
    params.productOfferPrice ?? params.productPrice,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(params.variantPriceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  return {
    comparePrice,
    unitPrice,
    offerPrice: unitPrice < comparePrice ? unitPrice : null,
  };
}

export async function prepareCheckout(
  body: CheckoutInput,
): Promise<PreparedCheckout> {
  const productIds = [...new Set(body.items.map((i) => i.productId))];
  const variantIds = [
    ...new Set(body.items.map((i) => i.variantId).filter(Boolean)),
  ] as string[];

  const [products, variants, settings] = await Promise.all([
    prisma.product.findMany({
      where: {
        id: { in: productIds },
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        sku: true,
        price: true,
        offerPrice: true,
        stock: true,
        isActive: true,
        categoryId: true,
        category: {
          select: {
            id: true,
            parent: {
              select: {
                id: true,
              },
            },
          },
        },
      },
    }),
    prisma.productVariant.findMany({
      where: { id: { in: variantIds } },
      select: {
        id: true,
        productId: true,
        value: true,
        type: true,
        priceDiff: true,
        stock: true,
      },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        taxRate: true,
        shippingInsideDhaka: true,
        shippingRangpur: true,
        shippingOutsideDhaka: true,
        shippingFreeOver: true,
        shippingDefaultCharge: true,
        shippingRules: true,
        codEnabled: true,
        onlineEnabled: true,
        manualPaymentEnabled: true,
        manualBkashNumber: true,
        manualNagadNumber: true,
        manualRocketNumber: true,
      },
    }),
  ]);

  if (!settings) {
    throw new AppError("Store settings not found", {
      statusCode: 500,
      expose: false,
    });
  }

  if (body.paymentMethod === "COD" && !settings.codEnabled) {
    throw new AppError("Cash on delivery is disabled", { statusCode: 422 });
  }

  if (body.paymentMethod === "ONLINE" && !settings.onlineEnabled) {
    throw new AppError("Online payment is disabled", { statusCode: 422 });
  }

  const hasManualChannels = Boolean(
    settings.manualBkashNumber ||
    settings.manualNagadNumber ||
    settings.manualRocketNumber,
  );

  if (body.paymentMethod === "MANUAL") {
    if (!settings.manualPaymentEnabled) {
      throw new AppError("Manual payment is disabled", { statusCode: 422 });
    }

    if (!hasManualChannels) {
      throw new AppError("No manual payment number is configured", {
        statusCode: 422,
      });
    }
  }

  const resolvedProducts = await attachEffectivePrices(products);
  const productMap = new Map(resolvedProducts.map((p) => [p.id, p]));
  const variantMap = new Map(variants.map((v) => [v.id, v]));
  const preparedItems: PreparedOrderItem[] = [];

  for (const item of body.items) {
    const product = productMap.get(item.productId);

    if (!product) {
      throw new AppError("Product not found or inactive", { statusCode: 404 });
    }

    const variant = item.variantId ? variantMap.get(item.variantId) : null;

    if (item.variantId && !variant) {
      throw new AppError("Selected product variant not found", {
        statusCode: 404,
      });
    }

    if (variant && variant.productId !== product.id) {
      throw new AppError("Variant does not belong to the product", {
        statusCode: 422,
      });
    }

    const availableStock = variant ? variant.stock : product.stock;

    if (availableStock < item.qty) {
      throw new AppError(`${product.name} stock is insufficient`, {
        statusCode: 409,
      });
    }

    const priceInfo = calculateVariantAwarePrice({
      productPrice: product.price,
      productOfferPrice: product.offerPrice,
      variantPriceDiff: variant?.priceDiff ?? 0,
    });

    const unitPrice = priceInfo.unitPrice;
    const lineTotal = unitPrice * item.qty;

    preparedItems.push({
      productId: product.id,
      variantId: variant?.id,
      productName: product.name,
      sku: product.sku,
      unitPrice,
      qty: item.qty,
      lineTotal,
    });
  }

  const subtotal = preparedItems.reduce((sum, item) => sum + item.lineTotal, 0);

  let discount = 0;
  if (body.couponCode) {
    const couponResult = await validateCouponByCode(prisma, {
      code: body.couponCode,
      items: body.items,
    });

    discount = couponResult.discount;
  }

  const totals = calcTotals({
    subtotal,
    discount,
    district: body.city,
    policeStation: body.area,
    settings: {
      taxRate: settings.taxRate,
      shippingInsideDhaka: settings.shippingInsideDhaka,
      shippingRangpur: settings.shippingRangpur,
      shippingOutsideDhaka: settings.shippingOutsideDhaka,
      shippingFreeOver: settings.shippingFreeOver,
      shippingDefaultCharge: settings.shippingDefaultCharge ?? 0,
      shippingRules: normalizeShippingRules(settings.shippingRules),
    },
  });

  return {
    items: preparedItems,
    subtotal,
    discount,
    shipping: totals.shipping,
    tax: totals.tax,
    total: totals.total,
    couponCode: body.couponCode,
  };
}

async function deductPreparedStock(
  tx: Prisma.TransactionClient,
  items: PreparedOrderItem[],
) {
  for (const item of items) {
    if (item.variantId) {
      const updated = await tx.productVariant.updateMany({
        where: {
          id: item.variantId,
          productId: item.productId,
          stock: { gte: item.qty },
        },
        data: {
          stock: { decrement: item.qty },
        },
      });

      if (updated.count === 0) {
        throw new AppError(`Stock unavailable for ${item.productName}`, {
          statusCode: 409,
        });
      }
    } else {
      const updated = await tx.product.updateMany({
        where: {
          id: item.productId,
          stock: { gte: item.qty },
          isActive: true,
        },
        data: {
          stock: { decrement: item.qty },
        },
      });

      if (updated.count === 0) {
        throw new AppError(`Stock unavailable for ${item.productName}`, {
          statusCode: 409,
        });
      }
    }
  }
}

export async function createCodOrder(params: {
  userId?: string | null;
  body: CheckoutInput;
  prepared: PreparedCheckout;
  idempotencyKey?: string;
}) {
  return prisma.$transaction(async (tx) => {
    if (params.idempotencyKey) {
      const existing = await tx.order.findUnique({
        where: { idempotencyKey: params.idempotencyKey },
        select: { id: true, total: true, paymentStatus: true, status: true },
      });

      if (existing) return existing;
    }

    await deductPreparedStock(tx, params.prepared.items);

    if (params.prepared.couponCode) {
      await redeemCouponUsage(tx, {
        code: params.prepared.couponCode,
      });
    }

    const { sequence, publicOrderId } = await createNextPublicOrderId(tx);

    const order = await tx.order.create({
      data: {
        userId: params.userId ?? null,
        idempotencyKey: params.idempotencyKey ?? generateIdempotencyKey(),
        name: params.body.name,
        email: params.body.email,
        phone: params.body.phone,
        addressLine1: params.body.addressLine1,
        addressLine2: params.body.addressLine2,
        city: params.body.city,
        area: params.body.area,
        note: params.body.note,
        couponCode: params.prepared.couponCode,
        subtotal: params.prepared.subtotal,
        discount: params.prepared.discount,
        shipping: params.prepared.shipping,
        publicOrderId,
        orderSequence: sequence,
        tax: params.prepared.tax,
        total: params.prepared.total,
        paymentMethod: PaymentMethod.COD,
        paymentStatus: PaymentStatus.UNPAID,
        stockDeducted: true,
        items: {
          create: params.prepared.items.map((item) => ({
            productId: item.productId,
            variantId: item.variantId,
            productName: item.productName,
            sku: item.sku,
            unitPrice: item.unitPrice,
            qty: item.qty,
            lineTotal: item.lineTotal,
          })),
        },
      },
      select: {
        id: true,
        publicOrderId: true,
        total: true,
        paymentMethod: true,
        paymentStatus: true,
        status: true,
        createdAt: true,
      },
    });

    return order;
  });
}

export async function createOnlinePendingOrder(params: {
  userId?: string | null;
  body: CheckoutInput;
  prepared: PreparedCheckout;
  idempotencyKey?: string;
}) {
  return prisma.$transaction(async (tx) => {
    if (params.idempotencyKey) {
      const existing = await tx.order.findUnique({
        where: { idempotencyKey: params.idempotencyKey },
        select: {
          id: true,
          publicOrderId: true,
          total: true,
          paymentMethod: true,
          paymentStatus: true,
          status: true,
          sslczSessionKey: true,
        },
      });

      if (existing) return existing;
    }

    const { sequence, publicOrderId } = await createNextPublicOrderId(tx);

    const order = await tx.order.create({
      data: {
        publicOrderId,
        orderSequence: sequence,
        userId: params.userId ?? null,
        idempotencyKey: params.idempotencyKey ?? generateIdempotencyKey(),
        name: params.body.name,
        email: params.body.email,
        phone: params.body.phone,
        addressLine1: params.body.addressLine1,
        addressLine2: params.body.addressLine2,
        city: params.body.city,
        area: params.body.area,
        note: params.body.note,
        couponCode: params.prepared.couponCode,
        subtotal: params.prepared.subtotal,
        discount: params.prepared.discount,
        shipping: params.prepared.shipping,
        tax: params.prepared.tax,
        total: params.prepared.total,
        paymentMethod: PaymentMethod.ONLINE,
        paymentStatus: PaymentStatus.UNPAID,
        stockDeducted: false,
        paymentGateway: "SSLCOMMERZ",
        items: {
          create: params.prepared.items.map((item) => ({
            productId: item.productId,
            variantId: item.variantId,
            productName: item.productName,
            sku: item.sku,
            unitPrice: item.unitPrice,
            qty: item.qty,
            lineTotal: item.lineTotal,
          })),
        },
      },
      select: {
        id: true,
        publicOrderId: true,
        total: true,
        paymentMethod: true,
        paymentStatus: true,
        status: true,
        createdAt: true,
      },
    });

    return order;
  });
}

export async function createManualPaidOrder(params: {
  userId?: string | null;
  body: CheckoutInput;
  prepared: PreparedCheckout;
  manual: {
    provider: "BKASH" | "NAGAD" | "ROCKET";
    senderPhone: string;
    transactionId: string;
    amount: number;
  };
  idempotencyKey: string;
}) {
  const maxRetries = 5;

  for (let attempt = 0; attempt < maxRetries; attempt += 1) {
    try {
      const order = await prisma.$transaction(async (tx) => {
        const existing = await tx.order.findUnique({
          where: { idempotencyKey: params.idempotencyKey },
          select: {
            id: true,
            publicOrderId: true,
            total: true,
            paymentMethod: true,
            paymentStatus: true,
            status: true,
          },
        });

        if (existing) return existing;

        await deductPreparedStock(tx, params.prepared.items);

        if (params.prepared.couponCode) {
          await redeemCouponUsage(tx, {
            code: params.prepared.couponCode,
          });
        }

        const { sequence, publicOrderId } = await createNextPublicOrderId(tx);

        return tx.order.create({
          data: {
            publicOrderId,
            orderSequence: sequence,
            userId: params.userId ?? null,
            idempotencyKey: params.idempotencyKey,
            name: params.body.name,
            email: params.body.email,
            phone: params.body.phone,
            addressLine1: params.body.addressLine1,
            addressLine2: params.body.addressLine2,
            city: params.body.city,
            area: params.body.area,
            note: params.body.note,
            couponCode: params.prepared.couponCode,
            subtotal: params.prepared.subtotal,
            discount: params.prepared.discount,
            shipping: params.prepared.shipping,
            tax: params.prepared.tax,
            total: params.prepared.total,
            paymentMethod: PaymentMethod.MANUAL,
            paymentStatus: PaymentStatus.PAID,
            transactionId: params.manual.transactionId,
            stockDeducted: true,
            paymentGateway: "MANUAL",
            paymentGatewayStatus: "COMPLETED",
            paymentMeta: {
              manualPayment: {
                provider: params.manual.provider,
                senderPhone: params.manual.senderPhone,
                submittedAmount: params.manual.amount,
                submittedAt: new Date().toISOString(),
              },
            },
            items: {
              create: params.prepared.items.map((item) => ({
                productId: item.productId,
                variantId: item.variantId,
                productName: item.productName,
                sku: item.sku,
                unitPrice: item.unitPrice,
                qty: item.qty,
                lineTotal: item.lineTotal,
              })),
            },
          },
          select: {
            id: true,
            publicOrderId: true,
            total: true,
            paymentMethod: true,
            paymentStatus: true,
            status: true,
            createdAt: true,
          },
        });
      });

      return order;
    } catch (error) {
      if (isOrderCreateUniqueConflict(error) && attempt < maxRetries - 1) {
        continue;
      }

      throw error;
    }
  }

  throw new AppError("Failed to create manual payment order", {
    statusCode: 500,
  });
}
