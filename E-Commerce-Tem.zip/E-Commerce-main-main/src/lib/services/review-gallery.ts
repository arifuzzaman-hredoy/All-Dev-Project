import { prisma } from "@/lib/prisma";

export const REVIEW_GALLERY_TAKE = 12;

export type ReviewGalleryItem = {
  id: string;
  rating: number;
  comment: string | null;
  imageUrls: string[];
  createdAt: string;
  verified: boolean;
  user: {
    name: string | null;
  };
  product: {
    name: string;
    slug: string;
    imageUrl: string | null;
  };
};

export type ReviewGalleryPage = {
  items: ReviewGalleryItem[];
  hasMore: boolean;
  nextSkip: number;
};

type GetReviewGalleryParams = {
  skip?: number;
  take?: number;
};

export async function getReviewGalleryPage({
  skip = 0,
  take = REVIEW_GALLERY_TAKE,
}: GetReviewGalleryParams = {}): Promise<ReviewGalleryPage> {
  const safeSkip = Math.max(0, Math.floor(skip));
  const safeTake = Math.max(1, Math.min(24, Math.floor(take)));

  const rows = await prisma.review.findMany({
    where: {
      product: {
        isActive: true,
      },
    },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    skip: safeSkip,
    take: safeTake + 1,
    select: {
      id: true,
      rating: true,
      comment: true,
      imageUrls: true,
      createdAt: true,
      authorName: true,
      isVerifiedPurchase: true,
      user: {
        select: {
          name: true,
        },
      },
      product: {
        select: {
          name: true,
          slug: true,
          images: {
            orderBy: {
              sortOrder: "asc",
            },
            take: 1,
            select: {
              url: true,
            },
          },
        },
      },
    },
  });

  const pageRows = rows.slice(0, safeTake);

  return {
    items: pageRows.map((row) => ({
      id: row.id,
      rating: row.rating,
      comment: row.comment,
      imageUrls: row.imageUrls,
      createdAt: row.createdAt.toISOString(),
      verified: row.isVerifiedPurchase,
      user: {
        name: row.authorName || row.user?.name || null,
      },
      product: {
        name: row.product.name,
        slug: row.product.slug,
        imageUrl: row.product.images[0]?.url ?? null,
      },
    })),
    hasMore: rows.length > safeTake,
    nextSkip: safeSkip + pageRows.length,
  };
}
