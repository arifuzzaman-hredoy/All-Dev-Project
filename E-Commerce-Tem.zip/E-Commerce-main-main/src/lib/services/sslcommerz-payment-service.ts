import { prisma } from "@/lib/prisma";
import { PaymentMethod, PaymentStatus } from "@prisma/client";
import { sslcommerzValidateByValId } from "@/lib/payments/sslcommerz/client";
import {
  fromSSLAmount,
  isSSLSuccessStatus,
} from "@/lib/payments/sslcommerz/helpers";
import { AppError } from "../app-error";
import { logger } from "../logger";
import { notifyOrderUpdated } from "../notifications";
import { redeemCouponUsage } from "@/lib/services/coupon-service";

export async function finalizeSSLCommerzPayment(params: {
  tranId: string;
  valId: string;
  source: "success-callback" | "ipn";
}) {
  const validation = await sslcommerzValidateByValId(params.valId);

  if (!isSSLSuccessStatus(validation.status)) {
    throw new AppError("Payment is not valid", { statusCode: 422 });
  }

  const order = await prisma.order.findUnique({
    where: { id: params.tranId },
    select: {
      id: true,
      total: true,
      paymentMethod: true,
      paymentStatus: true,
      stockDeducted: true,
      couponCode: true,
      items: {
        select: {
          productId: true,
          variantId: true,
          productName: true,
          qty: true,
        },
      },
    },
  });

  if (!order) {
    throw new AppError("Order not found for payment validation", {
      statusCode: 404,
    });
  }

  if (order.paymentMethod !== PaymentMethod.ONLINE) {
    throw new AppError("This order is not an online payment order", {
      statusCode: 422,
    });
  }

  const validatedAmount = fromSSLAmount(validation.amount);

  if (validatedAmount !== order.total) {
    throw new AppError("Validated amount mismatch", {
      statusCode: 409,
    });
  }

  if (order.paymentStatus === PaymentStatus.PAID && order.stockDeducted) {
    return {
      alreadyProcessed: true,
      orderId: order.id,
      validation,
    };
  }

  const result = await prisma.$transaction(async (tx) => {
    const current = await tx.order.findUnique({
      where: { id: order.id },
      select: {
        id: true,
        paymentStatus: true,
        stockDeducted: true,
        couponCode: true,
        items: {
          select: {
            productId: true,
            variantId: true,
            productName: true,
            qty: true,
          },
        },
      },
    });

    if (!current) {
      throw new AppError("Order missing during finalize", {
        statusCode: 404,
      });
    }

    if (current.paymentStatus === PaymentStatus.PAID && current.stockDeducted) {
      return {
        alreadyProcessed: true,
        orderId: current.id,
      };
    }

    for (const item of current.items) {
      if (!item.productId) {
        throw new AppError(
          `Invalid order item: missing product for ${item.productName}`,
          { statusCode: 500 },
        );
      }

      if (item.variantId) {
        const variantId = item.variantId;
        const productId = item.productId;

        const updated = await tx.productVariant.updateMany({
          where: {
            id: variantId,
            productId,
            stock: { gte: item.qty },
          },
          data: {
            stock: { decrement: item.qty },
          },
        });

        if (updated.count === 0) {
          throw new AppError(`Stock unavailable for ${item.productName}`, {
            statusCode: 409,
          });
        }
      } else {
        const productId = item.productId;

        const updated = await tx.product.updateMany({
          where: {
            id: productId,
            stock: { gte: item.qty },
            isActive: true,
          },
          data: {
            stock: { decrement: item.qty },
          },
        });

        if (updated.count === 0) {
          throw new AppError(`Stock unavailable for ${item.productName}`, {
            statusCode: 409,
          });
        }
      }
    }

    if (current.couponCode) {
      await redeemCouponUsage(tx, {
        code: current.couponCode,
      });
    }

    const updatedOrder = await tx.order.update({
      where: { id: current.id },
      data: {
        paymentStatus: PaymentStatus.PAID,
        stockDeducted: true,
        transactionId: validation.tran_id ?? current.id,
        sslczValId: validation.val_id ?? null,
        bankTranId: validation.bank_tran_id ?? null,
        paymentGatewayStatus: validation.status ?? "VALIDATED",
        paymentMeta: validation,
      },
      select: {
        id: true,
        paymentStatus: true,
        stockDeducted: true,
        transactionId: true,
      },
    });

    return {
      alreadyProcessed: false,
      orderId: updatedOrder.id,
      validation,
    };
  });

  logger.info("SSLCommerz payment finalized", {
    source: params.source,
    orderId: order.id,
    valId: validation.val_id,
    bankTranId: validation.bank_tran_id,
    status: validation.status,
  });

  await notifyOrderUpdated({
    orderId: order.id,
    previousStatus: undefined,
    previousPaymentStatus: order.paymentStatus,
  });

  return result;
}

export async function markSSLCommerzFailed(params: {
  tranId: string;
  status: string;
  payload?: unknown;
}) {
  const existing = await prisma.order.findUnique({
    where: { id: params.tranId },
    select: {
      id: true,
      paymentMethod: true,
      paymentStatus: true,
      stockDeducted: true,
    },
  });

  if (!existing) {
    throw new AppError("Order not found", { statusCode: 404 });
  }

  if (existing.paymentMethod !== PaymentMethod.ONLINE) {
    return existing;
  }

  if (existing.paymentStatus === PaymentStatus.PAID) {
    return existing;
  }

  const updated = await prisma.order.update({
    where: { id: existing.id },
    data: {
      paymentStatus: PaymentStatus.FAILED,
      paymentGatewayStatus: params.status,
      paymentMeta: params.payload as object,
    },
    select: {
      id: true,
      paymentStatus: true,
    },
  });

  await notifyOrderUpdated({
    orderId: existing.id,
    previousPaymentStatus: existing.paymentStatus,
  });

  return updated;
}