import { AppError } from "@/lib/app-error";
import { CouponScope, CouponType } from "@prisma/client";
import { attachEffectivePrices } from "@/lib/product-discounts";

export type CouponItemInput = {
  productId: string;
  variantId?: string | null;
  qty: number;
};

type DbLike = {
  coupon: {
    findUnique: (args: any) => Promise<any>;
    update: (args: any) => Promise<any>;
  };
  product: {
    findMany: (args: any) => Promise<any[]>;
  };
  productVariant: {
    findMany: (args: any) => Promise<any[]>;
  };
  category: {
    findMany: (args: any) => Promise<any[]>;
  };
};

type ResolvedCouponItem = {
  productId: string;
  variantId?: string;
  categoryId: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
};

export function normalizeCouponCode(code: string | null | undefined): string {
  return String(code ?? "")
    .trim()
    .toUpperCase();
}

function ensurePositiveInt(value: unknown, fallback = 0): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.floor(n));
}

function safeNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;

  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwarePrice(params: {
  productPrice: number;
  productOfferPrice: number | null;
  variantPriceDiff: number | null;
}) {
  const baseOriginalPrice = safeNumber(params.productPrice, 0);

  const baseDiscountedPrice = safeNumber(
    params.productOfferPrice ?? params.productPrice,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(params.variantPriceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  return {
    comparePrice,
    unitPrice,
  };
}

function collectDescendantCategoryIds(
  allCategories: Array<{ id: string; parentId: string | null }>,
  selectedCategoryIds: string[],
): Set<string> {
  const childrenMap = new Map<string | null, string[]>();

  for (const category of allCategories) {
    const key = category.parentId ?? null;
    const prev = childrenMap.get(key) ?? [];
    prev.push(category.id);
    childrenMap.set(key, prev);
  }

  const result = new Set<string>();
  const stack = [...selectedCategoryIds];

  while (stack.length) {
    const current = stack.pop();
    if (!current || result.has(current)) continue;
    result.add(current);

    const children = childrenMap.get(current) ?? [];
    for (const childId of children) {
      if (!result.has(childId)) {
        stack.push(childId);
      }
    }
  }

  return result;
}

export async function resolveCouponItems(
  db: DbLike,
  items: CouponItemInput[],
): Promise<ResolvedCouponItem[]> {
  if (!Array.isArray(items) || items.length === 0) {
    return [];
  }

  const normalizedItems = items
    .map((item) => ({
      productId: String(item.productId ?? "").trim(),
      variantId: item.variantId ? String(item.variantId).trim() : undefined,
      qty: ensurePositiveInt(item.qty, 0),
    }))
    .filter((item) => item.productId && item.qty > 0);

  if (normalizedItems.length === 0) {
    return [];
  }

  const productIds = [
    ...new Set(normalizedItems.map((item) => item.productId)),
  ];
  const variantIds = [
    ...new Set(
      normalizedItems
        .map((item) => item.variantId)
        .filter((value): value is string => Boolean(value)),
    ),
  ];

  const [products, variants] = await Promise.all([
    db.product.findMany({
      where: {
        id: { in: productIds },
        isActive: true,
      },
      select: {
        id: true,
        categoryId: true,
        price: true,
        offerPrice: true,
        stock: true,
        isActive: true,
        category: {
          select: {
            id: true,
            parent: {
              select: {
                id: true,
              },
            },
          },
        },
      },
    }),
    db.productVariant.findMany({
      where: { id: { in: variantIds } },
      select: {
        id: true,
        productId: true,
        priceDiff: true,
        stock: true,
      },
    }),
  ]);

  const resolvedProducts = await attachEffectivePrices(products);
  const productMap = new Map(resolvedProducts.map((item) => [item.id, item]));
  const variantMap = new Map(variants.map((item) => [item.id, item]));

  return normalizedItems.map((item) => {
    const product = productMap.get(item.productId);
    if (!product) {
      throw new AppError("Product not found or inactive", { statusCode: 404 });
    }

    const variant = item.variantId ? variantMap.get(item.variantId) : null;

    if (item.variantId && !variant) {
      throw new AppError("Selected product variant not found", {
        statusCode: 404,
      });
    }

    if (variant && variant.productId !== product.id) {
      throw new AppError("Variant does not belong to the product", {
        statusCode: 422,
      });
    }

    const priceInfo = calculateVariantAwarePrice({
      productPrice: product.price,
      productOfferPrice: product.offerPrice,
      variantPriceDiff: variant?.priceDiff ?? 0,
    });

    const unitPrice = priceInfo.unitPrice;
    const lineTotal = unitPrice * item.qty;

    return {
      productId: product.id,
      variantId: variant?.id,
      categoryId: product.categoryId,
      qty: item.qty,
      unitPrice,
      lineTotal,
    };
  });
}

export async function validateCouponByCode(
  db: DbLike,
  params: {
    code: string;
    items: CouponItemInput[];
  },
) {
  const code = normalizeCouponCode(params.code);

  if (!code) {
    throw new AppError("Coupon code required", { statusCode: 400 });
  }

  const coupon = await db.coupon.findUnique({
    where: { code },
    select: {
      id: true,
      code: true,
      description: true,
      scope: true,
      productIds: true,
      categoryIds: true,
      type: true,
      value: true,
      minSubtotal: true,
      maxDiscount: true,
      startsAt: true,
      endsAt: true,
      usageLimit: true,
      usedCount: true,
      isActive: true,
    },
  });

  if (!coupon || !coupon.isActive) {
    throw new AppError("Invalid coupon", { statusCode: 400 });
  }

  const now = new Date();

  if (coupon.startsAt && now < coupon.startsAt) {
    throw new AppError("Coupon not started yet", { statusCode: 400 });
  }

  if (coupon.endsAt && now > coupon.endsAt) {
    throw new AppError("Coupon expired", { statusCode: 400 });
  }

  if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
    throw new AppError("Coupon usage limit reached", { statusCode: 400 });
  }

  const resolvedItems = await resolveCouponItems(db, params.items);
  if (resolvedItems.length === 0) {
    throw new AppError("No valid items found for coupon validation", {
      statusCode: 400,
    });
  }

  let applicableItems = resolvedItems;

  if (coupon.scope === CouponScope.PRODUCTS) {
    const allowedProductIds = new Set(coupon.productIds ?? []);
    applicableItems = resolvedItems.filter((item) =>
      allowedProductIds.has(item.productId),
    );

    if (applicableItems.length === 0) {
      throw new AppError("This coupon is not valid for the selected products", {
        statusCode: 400,
      });
    }
  }

  if (coupon.scope === CouponScope.CATEGORIES) {
    const allCategories = await db.category.findMany({
      select: {
        id: true,
        parentId: true,
      },
    });

    const allowedCategoryIds = collectDescendantCategoryIds(
      allCategories,
      coupon.categoryIds ?? [],
    );

    applicableItems = resolvedItems.filter((item) =>
      allowedCategoryIds.has(item.categoryId),
    );

    if (applicableItems.length === 0) {
      throw new AppError(
        "This coupon is not valid for the selected categories",
        {
          statusCode: 400,
        },
      );
    }
  }

  const applicableSubtotal = applicableItems.reduce(
    (sum, item) => sum + item.lineTotal,
    0,
  );

  if (applicableSubtotal < coupon.minSubtotal) {
    throw new AppError(`Minimum eligible subtotal is ৳${coupon.minSubtotal}`, {
      statusCode: 400,
    });
  }

  let discount = 0;

  if (coupon.type === CouponType.PERCENT) {
    discount = Math.floor((applicableSubtotal * coupon.value) / 100);
    if (coupon.maxDiscount !== null) {
      discount = Math.min(discount, coupon.maxDiscount);
    }
  } else {
    discount = coupon.value;
  }

  discount = Math.max(0, Math.min(discount, applicableSubtotal));

  return {
    coupon,
    applicableSubtotal,
    discount,
  };
}

export async function redeemCouponUsage(
  db: Pick<DbLike, "coupon">,
  params: { code: string },
) {
  const code = normalizeCouponCode(params.code);
  if (!code) return null;

  const coupon = await db.coupon.findUnique({
    where: { code },
    select: {
      id: true,
      isActive: true,
      usageLimit: true,
      usedCount: true,
    },
  });

  if (!coupon || !coupon.isActive) {
    throw new AppError("Coupon is no longer valid", { statusCode: 409 });
  }

  if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
    throw new AppError("Coupon usage limit exceeded", { statusCode: 409 });
  }

  return db.coupon.update({
    where: { id: coupon.id },
    data: {
      usedCount: { increment: 1 },
    },
  });
}
