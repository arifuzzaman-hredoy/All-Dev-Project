import {
  OrderStatus,
  PaymentStatus,
  ProductDiscountScope,
  Prisma,
} from "@prisma/client";

import { prisma } from "@/lib/prisma";
import { attachEffectivePrices } from "@/lib/product-discounts";

const HOME_PRODUCT_TAKE = 12;

const homeProductInclude = {
  category: {
    select: {
      name: true,
    },
  },
  images: {
    orderBy: {
      sortOrder: "asc",
    },
    take: 1,
    select: {
      url: true,
    },
  },
  variants: {
    orderBy: {
      createdAt: "asc",
    },
    take: 1,
    select: {
      id: true,
      stock: true,
    },
  },
  _count: {
    select: {
      variants: true,
    },
  },
} satisfies Prisma.ProductInclude;

type HomeProductRow = Prisma.ProductGetPayload<{
  include: typeof homeProductInclude;
}>;

export type HomeSliderProduct = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  category?: { name: string } | null;
  images?: { url: string }[];
  ratingAvg: number;
  ratingCount: number;
  hasVariants: boolean;
  variantsCount: number;
  variants: Array<{
    id: string;
    stock: number;
  }>;
};

function getActiveDiscountWhere(now: Date): Prisma.ProductDiscountWhereInput {
  return {
    isActive: true,
    percentage: {
      gt: 0,
    },
    AND: [
      {
        OR: [{ startsAt: null }, { startsAt: { lte: now } }],
      },
      {
        OR: [{ endsAt: null }, { endsAt: { gte: now } }],
      },
    ],
  };
}

async function attachRatingsAndPrices(
  products: HomeProductRow[],
): Promise<HomeSliderProduct[]> {
  if (!products.length) return [];

  const resolvedProducts = await attachEffectivePrices(products);
  const productIds = resolvedProducts.map((product) => product.id);

  const ratings = await prisma.review.groupBy({
    by: ["productId"],
    where: {
      productId: {
        in: productIds,
      },
    },
    _avg: {
      rating: true,
    },
    _count: {
      rating: true,
    },
  });

  const ratingMap = new Map(
    ratings.map((rating) => [
      rating.productId,
      {
        avg:
          typeof rating._avg.rating === "number" ? rating._avg.rating : 0,
        count:
          typeof rating._count.rating === "number"
            ? rating._count.rating
            : 0,
      },
    ]),
  );

  return resolvedProducts.map((product) => {
    const rating = ratingMap.get(product.id) ?? { avg: 0, count: 0 };
    const variantsCount = product._count.variants;

    return {
      id: product.id,
      name: product.name,
      slug: product.slug,
      price: product.price,
      offerPrice: product.offerPrice,
      stock: product.stock,
      category: product.category,
      images: product.images,
      ratingAvg: Math.round(rating.avg * 10) / 10,
      ratingCount: rating.count,
      hasVariants: variantsCount > 0,
      variantsCount,
      variants: product.variants,
    };
  });
}

export async function getBestSellerProducts(
  take = HOME_PRODUCT_TAKE,
): Promise<HomeSliderProduct[]> {
  const grouped = await prisma.orderItem.groupBy({
    by: ["productId"],
    where: {
      productId: {
        not: null,
      },
      order: {
        OR: [
          { status: OrderStatus.DELIVERED },
          { paymentStatus: PaymentStatus.PAID },
        ],
      },
    },
    _sum: {
      qty: true,
    },
    orderBy: {
      _sum: {
        qty: "desc",
      },
    },
    take: take * 4,
  });

  const productIds = grouped
    .map((item) => item.productId)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  if (!productIds.length) return [];

  const products = await prisma.product.findMany({
    where: {
      id: {
        in: productIds,
      },
      isActive: true,
    },
    include: homeProductInclude,
  });

  const productMap = new Map(products.map((product) => [product.id, product]));
  const sortedProducts = productIds
    .map((id) => productMap.get(id))
    .filter((product): product is HomeProductRow => Boolean(product))
    .slice(0, take);

  return attachRatingsAndPrices(sortedProducts);
}

export async function getLimitedOfferProducts(
  take = HOME_PRODUCT_TAKE,
): Promise<HomeSliderProduct[]> {
  const now = new Date();
  const activeDiscountWhere = getActiveDiscountWhere(now);

  const activeDiscounts = await prisma.productDiscount.findMany({
    where: {
      ...activeDiscountWhere,
      OR: [
        {
          scope: ProductDiscountScope.PRODUCT,
          productId: {
            not: null,
          },
        },
        {
          scope: {
            in: [
              ProductDiscountScope.CATEGORY,
              ProductDiscountScope.SUBCATEGORY,
            ],
          },
          categoryId: {
            not: null,
          },
        },
      ],
    },
    select: {
      productId: true,
      categoryId: true,
      scope: true,
    },
  });

  const discountedProductIds = activeDiscounts
    .filter((discount) => discount.scope === ProductDiscountScope.PRODUCT)
    .map((discount) => discount.productId)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  const discountedCategoryIds = activeDiscounts
    .filter(
      (discount) =>
        discount.scope === ProductDiscountScope.CATEGORY ||
        discount.scope === ProductDiscountScope.SUBCATEGORY,
    )
    .map((discount) => discount.categoryId)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  const childCategories = discountedCategoryIds.length
    ? await prisma.category.findMany({
        where: {
          isActive: true,
          parentId: {
            in: discountedCategoryIds,
          },
        },
        select: {
          id: true,
        },
      })
    : [];

  const eligibleCategoryIds = Array.from(
    new Set([
      ...discountedCategoryIds,
      ...childCategories.map((category) => category.id),
    ]),
  );

  const discountPredicates: Prisma.ProductWhereInput[] = [
    {
      offerPrice: {
        not: null,
      },
    },
    {
      discountPercent: {
        gt: 0,
      },
    },
  ];

  if (discountedProductIds.length) {
    discountPredicates.push({
      id: {
        in: discountedProductIds,
      },
    });
  }

  if (eligibleCategoryIds.length) {
    discountPredicates.push(
      {
        categoryId: {
          in: eligibleCategoryIds,
        },
      },
      {
        categories: {
          some: {
            categoryId: {
              in: eligibleCategoryIds,
            },
          },
        },
      },
    );
  }

  const products = await prisma.product.findMany({
    where: {
      isActive: true,
      OR: discountPredicates,
    },
    orderBy: [{ updatedAt: "desc" }],
    take,
    include: homeProductInclude,
  });

  return attachRatingsAndPrices(products);
}
