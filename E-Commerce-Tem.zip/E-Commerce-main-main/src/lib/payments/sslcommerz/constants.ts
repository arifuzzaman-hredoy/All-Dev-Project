import { env } from "@/lib/env";

export const SSLCOMMERZ_BASE_URL = env.SSLCOMMERZ_IS_LIVE
  ? "https://securepay.sslcommerz.com"
  : "https://sandbox.sslcommerz.com";

export const SSLCOMMERZ_INIT_URL = `${SSLCOMMERZ_BASE_URL}/gwprocess/v4/api.php`;
export const SSLCOMMERZ_VALIDATE_URL = `${SSLCOMMERZ_BASE_URL}/validator/api/validationserverAPI.php`;

export const SSLCOMMERZ_GATEWAY_NAME = "SSLCOMMERZ";
