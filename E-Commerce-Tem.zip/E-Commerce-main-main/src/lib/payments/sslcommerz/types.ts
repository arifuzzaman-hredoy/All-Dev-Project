export type SSLCommerzInitiateResponse = {
  status?: string;
  failedreason?: string;
  sessionkey?: string;
  GatewayPageURL?: string;
  redirectGatewayURL?: string;
  directPaymentURLBank?: string;
  directPaymentURLCard?: string;
  directPaymentURL?: string;
  storeBanner?: string;
  storeLogo?: string;
  desc?: Array<{
    name?: string;
    type?: string;
    logo?: string;
    gw?: string;
    r_flag?: string;
    redirectGatewayURL?: string;
  }>;
};

export type SSLCommerzValidationResponse = {
  status?: string;
  tran_date?: string;
  tran_id?: string;
  val_id?: string;
  amount?: string;
  store_amount?: string;
  bank_tran_id?: string;
  card_type?: string;
  card_no?: string;
  currency?: string;
  card_issuer?: string;
  card_brand?: string;
  card_issuer_country?: string;
  card_issuer_country_code?: string;
  currency_type?: string;
  currency_amount?: string;
  risk_level?: string;
  risk_title?: string;
  error?: string;
  APIConnect?: string;
};

export type SSLCommerzCallbackPayload = {
  status?: string;
  tran_id?: string;
  val_id?: string;
  amount?: string;
  currency?: string;
  bank_tran_id?: string;
  verify_sign?: string;
  verify_key?: string;
  [key: string]: string | undefined;
};
