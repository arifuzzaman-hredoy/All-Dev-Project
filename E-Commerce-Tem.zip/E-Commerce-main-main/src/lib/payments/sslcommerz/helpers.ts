import crypto from "crypto";

export function toSSLAmount(amountInBDT: number): string {
  const n = Number(amountInBDT);
  if (!Number.isFinite(n)) return "0.00";
  return n.toFixed(2);
}

export function fromSSLAmount(
  amount: string | number | null | undefined,
): number {
  const n = typeof amount === "number" ? amount : Number(amount ?? 0);
  if (!Number.isFinite(n)) return 0;
  return Math.round(n);
}

export function generateIdempotencyKey() {
  return crypto.randomUUID();
}

export function isSSLSuccessStatus(status?: string | null) {
  return status === "VALID" || status === "VALIDATED";
}