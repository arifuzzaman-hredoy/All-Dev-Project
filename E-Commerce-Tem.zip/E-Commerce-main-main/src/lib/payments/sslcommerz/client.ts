import { AppError } from "@/lib/app-error";
import { env } from "@/lib/env";
import {
  SSLCOMMERZ_INIT_URL,
  SSLCOMMERZ_VALIDATE_URL,
} from "@/lib/payments/sslcommerz/constants";
import type {
  SSLCommerzInitiateResponse,
  SSLCommerzValidationResponse,
} from "@/lib/payments/sslcommerz/types";

export async function sslcommerzInitiate(
  payload: Record<string, string>
): Promise<SSLCommerzInitiateResponse> {
  const body = new URLSearchParams(payload);

  const res = await fetch(SSLCOMMERZ_INIT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: body.toString(),
    cache: "no-store",
  });

  const text = await res.text();

  let json: SSLCommerzInitiateResponse;
  try {
    json = JSON.parse(text);
  } catch {
    throw new AppError("Payment gateway returned invalid response", {
      statusCode: 502,
      expose: false,
    });
  }

  if (!res.ok) {
    throw new AppError("Failed to initiate payment session", {
      statusCode: 502,
      details: json,
      expose: false,
    });
  }

  if (!json.GatewayPageURL) {
    throw new AppError(json.failedreason || "Payment session creation failed", {
      statusCode: 502,
    });
  }

  return json;
}

export async function sslcommerzValidateByValId(
  valId: string
): Promise<SSLCommerzValidationResponse> {
  const url = new URL(SSLCOMMERZ_VALIDATE_URL);
  url.searchParams.set("val_id", valId);
  url.searchParams.set("store_id", env.SSLCOMMERZ_STORE_ID);
  url.searchParams.set("store_passwd", env.SSLCOMMERZ_STORE_PASS);
  url.searchParams.set("v", "1");
  url.searchParams.set("format", "json");

  const res = await fetch(url.toString(), {
    method: "GET",
    cache: "no-store",
  });

  const text = await res.text();

  let json: SSLCommerzValidationResponse;
  try {
    json = JSON.parse(text);
  } catch {
    throw new AppError("Payment validation returned invalid response", {
      statusCode: 502,
      expose: false,
    });
  }

  if (!res.ok) {
    throw new AppError("Payment validation failed", {
      statusCode: 502,
      details: json,
      expose: false,
    });
  }

  return json;
}