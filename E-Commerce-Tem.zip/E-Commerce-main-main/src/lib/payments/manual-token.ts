import { createHmac, timingSafeEqual } from "crypto";
import type { CheckoutInput } from "@/lib/validations/checkout";

type ManualPaymentTokenPayload = {
    checkout: CheckoutInput;
    submissionKey: string;
    iat: number;
    exp: number;
};

function getSecret(): string {
    const secret = process.env.MANUAL_PAYMENT_TOKEN_SECRET || process.env.NEXTAUTH_SECRET;
    if (!secret) {
        throw new Error("Missing manual payment token secret");
    }
    return secret;
}

function toBase64Url(input: string): string {
    return Buffer.from(input, "utf8")
        .toString("base64")
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/g, "");
}

function fromBase64Url(input: string): string {
    const padded = input.replace(/-/g, "+").replace(/_/g, "/");
    const pad = padded.length % 4 === 0 ? "" : "=".repeat(4 - (padded.length % 4));
    return Buffer.from(padded + pad, "base64").toString("utf8");
}

function sign(data: string): string {
    return createHmac("sha256", getSecret()).update(data).digest("base64url");
}

export function createManualPaymentToken(checkout: CheckoutInput): string {
    const now = Math.floor(Date.now() / 1000);

    const payload: ManualPaymentTokenPayload = {
        checkout,
        submissionKey: `manual:${now}:${Math.random().toString(36).slice(2, 12)}`,
        iat: now,
        exp: now + 60 * 30,
    };

    const encoded = toBase64Url(JSON.stringify(payload));
    const signature = sign(encoded);

    return `${encoded}.${signature}`;
}

export function verifyManualPaymentToken(token: string): ManualPaymentTokenPayload {
    const [encoded, signature] = token.split(".");

    if (!encoded || !signature) {
        throw new Error("Invalid manual payment token");
    }

    const expected = sign(encoded);

    const a = Buffer.from(signature);
    const b = Buffer.from(expected);

    if (a.length !== b.length || !timingSafeEqual(a, b)) {
        throw new Error("Invalid manual payment token signature");
    }

    const payload = JSON.parse(fromBase64Url(encoded)) as ManualPaymentTokenPayload;

    if (!payload?.checkout || !payload?.submissionKey || !payload?.exp) {
        throw new Error("Invalid manual payment token payload");
    }

    const now = Math.floor(Date.now() / 1000);
    if (payload.exp < now) {
        throw new Error("Manual payment session expired");
    }

    return payload;
}