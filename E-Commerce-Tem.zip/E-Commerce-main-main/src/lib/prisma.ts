import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { env } from "@/lib/env"
import { runStartupChecks } from "./startup-check";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

runStartupChecks();

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    adapter: new PrismaPg({
      connectionString: env.DATABASE_URL!,
    }),
  });

if (env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
