import { env } from "@/lib/env";

function isLocalUrl(url: string) {
  return (
    url.startsWith("http://localhost:") ||
    url.startsWith("http://127.0.0.1:") ||
    url.includes("://localhost") ||
    url.includes("://127.0.0.1")
  );
}

export function runStartupChecks() {
  const isRealProduction =
    env.NODE_ENV === "production" && process.env.VERCEL_ENV === "production";

  if (!isRealProduction) {
    return;
  }

  if (!isLocalUrl(env.NEXTAUTH_URL) && env.NEXTAUTH_URL.startsWith("http://")) {
    throw new Error("NEXTAUTH_URL must use https");
  }

  if (
    !isLocalUrl(env.NEXT_PUBLIC_BASE_URL) &&
    env.NEXT_PUBLIC_BASE_URL.startsWith("http://")
  ) {
    throw new Error("NEXT_PUBLIC_BASE_URL must use https");
  }
}
