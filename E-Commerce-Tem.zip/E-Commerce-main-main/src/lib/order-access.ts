export function normalizeOrderAccessPhone(value: string | null | undefined) {
  const digits = String(value ?? "").replace(/\D+/g, "");

  if (digits.startsWith("880") && digits.length === 13) {
    return digits.slice(2);
  }

  if (digits.startsWith("88") && digits.length === 13) {
    return digits.slice(2);
  }

  return digits;
}

export function canAccessCustomerOrder(params: {
  sessionUserId?: string | null;
  orderUserId?: string | null;
  orderPhone?: string | null;
  phoneProof?: string | null;
}) {
  if (
    params.sessionUserId &&
    params.orderUserId &&
    params.sessionUserId === params.orderUserId
  ) {
    return true;
  }

  const orderPhone = normalizeOrderAccessPhone(params.orderPhone);
  const phoneProof = normalizeOrderAccessPhone(params.phoneProof);

  return Boolean(orderPhone && phoneProof && orderPhone === phoneProof);
}

export function firstSearchParamValue(
  value: string | string[] | undefined,
): string | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}
