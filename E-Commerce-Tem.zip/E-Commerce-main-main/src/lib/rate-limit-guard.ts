import { rateLimit } from "@/lib/rate-limit";
import { AppError } from "@/lib/app-error";

type GuardOptions = {
  key: string;
  limit: number;
  windowMs: number;
};

export function enforceRateLimit({ key, limit, windowMs }: GuardOptions) {
  const result = rateLimit(key, { limit, windowMs });

  if (!result.success) {
    throw new AppError("Too many requests. Please try again later.", {
      statusCode: 429,
    });
  }

  return result;
}
