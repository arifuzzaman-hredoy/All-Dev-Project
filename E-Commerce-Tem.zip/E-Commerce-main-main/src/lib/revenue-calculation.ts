export function getDefaultDeliveryCharge(orderShipping: number) {
  return Math.max(0, Math.round(Number(orderShipping || 0) + 10));
}

export function getGrandSellAmount(params: {
  sell: number;
  deliveryCharge: number;
}) {
  return Math.max(0, Math.round(params.sell - params.deliveryCharge));
}

export function getRevenue(params: {
  sell: number;
  deliveryCharge: number;
  investedAmount: number | null;
}) {
  if (params.investedAmount === null) return null;

  return Math.round(
    getGrandSellAmount({
      sell: params.sell,
      deliveryCharge: params.deliveryCharge,
    }) - params.investedAmount,
  );
}

export function getOrderItemsInvestedAmount(
  items: Array<{
    qty: number;
    product: {
      investedAmount: number | null;
    } | null;
    variant?: {
      investedAmount: number | null;
    } | null;
  }>,
) {
  if (!items.length) return null;

  let total = 0;

  for (const item of items) {
    const investedAmount =
      item.variant?.investedAmount ?? item.product?.investedAmount ?? null;

    if (investedAmount === null) {
      return null;
    }

    total += Math.max(0, item.qty) * investedAmount;
  }

  return total;
}
