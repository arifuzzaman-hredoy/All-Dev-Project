export type CartItem = {
  productId: string;
  qty: number;
  variantId?: string | null;
};

export type Cart = {
  items: CartItem[];
};
