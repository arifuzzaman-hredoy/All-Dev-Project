import { prisma } from "@/lib/prisma";
import { getDescendantCategoryIds } from "@/lib/category-tree";

export type HomeCategoryRow = {
  id: string;
  name: string;
  slug: string;
  imageUrl: string | null;
};

type CategoryNode = {
  id: string;
  name: string;
  slug: string;
  imageUrl: string | null;
};

type ActiveCategoryNode = {
  id: string;
  parentId: string | null;
};

export async function getHomeCategoryRows(): Promise<HomeCategoryRow[]> {
  const mainCategories = await prisma.category.findMany({
    where: {
      isActive: true,
      parentId: null,
    },
    orderBy: [{ name: "asc" }],
    select: {
      id: true,
      name: true,
      slug: true,
      imageUrl: true,
    },
  });

  const allActiveCategories = await prisma.category.findMany({
    where: { isActive: true },
    select: {
      id: true,
      parentId: true,
    },
  });

  const rows: HomeCategoryRow[] = [];

  for (const category of mainCategories as CategoryNode[]) {
    const categoryIds = getDescendantCategoryIds(
      category.id,
      allActiveCategories as ActiveCategoryNode[],
    );

    const hasProduct = await prisma.product.findFirst({
      where: {
        isActive: true,
        OR: [
          {
            categoryId: {
              in: categoryIds,
            },
          },
          {
            categories: {
              some: {
                categoryId: {
                  in: categoryIds,
                },
              },
            },
          },
        ],
      },
      select: {
        id: true,
      },
    });

    if (!hasProduct) continue;

    rows.push({
      id: category.id,
      name: category.name,
      slug: category.slug,
      imageUrl: category.imageUrl,
    });

    if (rows.length >= 15) break;
  }

  return rows;
}
