import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { AppError } from "@/lib/app-error";

export async function requireAuth() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.email) {
    throw new AppError("Unauthorized", { statusCode: 401 });
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    throw new AppError("User not found", { statusCode: 404 });
  }

  return user;
}

export async function requireActiveUser() {
  const user = await requireAuth();

  if (user.blocked) {
    throw new AppError("Your account is blocked", { statusCode: 403 });
  }

  return user;
}

export async function requireAdmin() {
  const user = await requireAuth();

  if (user.role !== "ADMIN") {
    throw new AppError("Admin access required", { statusCode: 403 });
  }

  return user;
}

export async function requireStaffOrAdmin() {
  const user = await requireAuth();

  if (user.role !== "ADMIN" && user.role !== "STAFF") {
    throw new AppError("Staff or admin access required", { statusCode: 403 });
  }

  return user;
}

export async function getOptionalSessionUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);
  const sessionUserId =
    typeof session?.user?.id === "string" ? session.user.id : null;

  if (!sessionUserId) return null;

  const user = await prisma.user.findUnique({
    where: { id: sessionUserId },
    select: {
      id: true,
      blocked: true,
    },
  });

  if (!user || user.blocked) return null;

  return user.id;
}
