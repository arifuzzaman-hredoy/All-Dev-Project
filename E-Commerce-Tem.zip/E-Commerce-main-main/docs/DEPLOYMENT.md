# Ecommerce Production DevOps Deployment

Project: `Ecommerce`  
Repo: `https://github.com/techtemlead-lab/nexoramart.git`  
Domain: `ecommerce.techteamlead.com`  
App port: `4050`  
Deployment: Docker Compose + host Nginx + Let's Encrypt + GitHub Actions

## Brutally important notes

1. Your staging domain is the same as production: `ecommerce.techteamlead.com`. That is not staging. A real staging setup needs another subdomain like `staging-ecommerce.techteamlead.com` or `ecommerce-staging.techteamlead.com`.
2. You said no SSH key access, but GitHub Actions CI/CD should not deploy with a root password. Create an SSH key and store the private key in GitHub Secrets.
3. Your provided `ADMIN_PASSWORD=admin12345` is weak. Do not use it in production.
4. Because images are now Cloudinary-based, do not depend on Docker volumes for uploaded images.

---

## 1. DNS

Create an A record:

```txt
ecommerce.techteamlead.com  A  198.54.121.88
```

Wait until it resolves:

```bash
nslookup ecommerce.techteamlead.com
```

---

## 2. VPS base setup

SSH into the VPS:

```bash
ssh root@198.54.121.88 -p 22
```

Install required packages:

```bash
apt update && apt upgrade -y
apt install -y git curl nginx certbot python3-certbot-nginx ufw fail2ban postgresql postgresql-contrib
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker nginx postgresql fail2ban
```

Firewall:

```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
ufw status
```

If you lock SSH to only your IP, GitHub-hosted Actions will not be able to SSH because GitHub runner IPs change. Either keep SSH open with key-only auth + fail2ban, use a self-hosted runner, or maintain GitHub Actions IP ranges manually.

---

## 3. Create SSH key for GitHub Actions deploy

On your local machine:

```bash
ssh-keygen -t ed25519 -C "github-actions-ecommerce" -f ecommerce_deploy_key
```

Copy the public key to VPS:

```bash
ssh-copy-id -i ecommerce_deploy_key.pub root@198.54.121.88
```

GitHub repo secrets to add:

```txt
VPS_HOST=198.54.121.88
VPS_USER=root
VPS_PORT=22
VPS_SSH_KEY=<content of ecommerce_deploy_key private key>
```

Never commit the private key.

---

## 4. Clone project to VPS

```bash
mkdir -p /opt
cd /opt
git clone -b main https://github.com/techtemlead-lab/nexoramart.git ecommerce
cd /opt/ecommerce
```

Create production env:

```bash
cp .env.production.example .env.production
nano .env.production
```

Minimum required values:

```env
NODE_ENV="production"
PORT="4050"
NEXTAUTH_URL="https://ecommerce.techteamlead.com"
NEXT_PUBLIC_BASE_URL="https://ecommerce.techteamlead.com"
NEXT_PUBLIC_SITE_URL="https://ecommerce.techteamlead.com"
DATABASE_URL="postgresql://ecommerce_user:STRONG_DB_PASSWORD@host.docker.internal:5432/ecommerce?schema=public"
NEXTAUTH_SECRET="GENERATE_A_LONG_RANDOM_SECRET"
IMAGE_STORAGE_DRIVER="cloudinary"
CLOUDINARY_CLOUD_NAME="YOUR_CLOUD_NAME"
CLOUDINARY_API_KEY="YOUR_API_KEY"
CLOUDINARY_API_SECRET="YOUR_API_SECRET"
CLOUDINARY_FOLDER="ecommerce"
SSLCOMMERZ_STORE_ID="demo"
SSLCOMMERZ_STORE_PASS="demo"
SSLCOMMERZ_IS_LIVE="false"
```

Generate a strong secret:

```bash
openssl rand -base64 48
```

---

## 5. PostgreSQL database setup

From `/opt/ecommerce`:

```bash
export DB_NAME="ecommerce"
export DB_USER="ecommerce_user"
export DB_PASSWORD="STRONG_DB_PASSWORD"
./scripts/setup-postgres.sh
```

If Docker cannot connect to host PostgreSQL, PostgreSQL is probably listening only on `localhost`. You need to allow Docker bridge connections in PostgreSQL config, or run PostgreSQL as a Docker Compose service instead. Do not guess here—test the connection.

---

## 6. Deploy with Docker Compose

```bash
cd /opt/ecommerce
docker compose up -d --build
```

Check:

```bash
docker compose ps
docker compose logs -f ecommerce
curl http://127.0.0.1:4050/api/health
```

Run seed only if this is a fresh empty database:

```bash
docker compose run --rm --entrypoint npm ecommerce run seed
```

Do not run seed blindly on an existing real store database.

---

## 7. Migrate existing local images to Cloudinary

This uploads images from `public/uploads` to Cloudinary and updates these DB fields:

- product images
- variant images
- category images
- banner images
- store logo
- manual payment images
- review images

Run after `.env.production` is correct and the DB is reachable:

```bash
cd /opt/ecommerce
docker compose run --rm --entrypoint node ecommerce scripts/migrate-local-uploads-to-cloudinary.mjs
```

For only DB-referenced images:

```bash
MIGRATE_ONLY_REFERENCED=true docker compose run --rm --entrypoint node ecommerce scripts/migrate-local-uploads-to-cloudinary.mjs
```

After migration, new admin uploads will go directly to Cloudinary because:

```env
IMAGE_STORAGE_DRIVER="cloudinary"
```

---

## 8. Nginx reverse proxy

Install config:

```bash
cp /opt/ecommerce/deploy/nginx/ecommerce.techteamlead.com.conf /etc/nginx/sites-available/ecommerce.techteamlead.com.conf
ln -sfn /etc/nginx/sites-available/ecommerce.techteamlead.com.conf /etc/nginx/sites-enabled/ecommerce.techteamlead.com.conf
nginx -t
systemctl reload nginx
```

SSL:

```bash
certbot --nginx -d ecommerce.techteamlead.com -m techtemlead@gmail.com --agree-tos --redirect --no-eff-email
systemctl reload nginx
```

Test renewal:

```bash
certbot renew --dry-run
```

---

## 9. GitHub Actions CI/CD

After pushing these files to `main`, every push to `main` will deploy automatically using:

```txt
.github/workflows/deploy.yml
```

Manual deployment on VPS:

```bash
cd /opt/ecommerce
./scripts/deploy.sh
```

---

## 10. Backup

Manual backup:

```bash
cd /opt/ecommerce
./scripts/backup.sh
```

Cron example, daily at 2:30 AM:

```bash
crontab -e
```

Add:

```cron
30 2 * * * APP_DIR=/opt/ecommerce BACKUP_ROOT=/opt/backups/ecommerce /opt/ecommerce/scripts/backup.sh >> /var/log/ecommerce-backup.log 2>&1
```

Cloudinary assets are not dumped by `pg_dump`. The database stores Cloudinary URLs. For full media backup, use Cloudinary export/backup separately.

---

## 11. Useful commands

```bash
cd /opt/ecommerce

docker compose ps
docker compose logs -f ecommerce
docker compose restart ecommerce
docker compose down
docker compose up -d --build

git status
git pull origin main
```

---

## 12. Changed files summary

```txt
Dockerfile
.dockerignore
docker-compose.yml
.env.production.example
.github/workflows/deploy.yml
deploy/nginx/ecommerce.techteamlead.com.conf
docs/DEPLOYMENT.md
scripts/docker-entrypoint.sh
scripts/deploy.sh
scripts/setup-postgres.sh
scripts/backup.sh
scripts/migrate-local-uploads-to-cloudinary.mjs
src/app/api/health/route.ts
src/lib/cloudinary-storage.ts
src/lib/local-uploads.ts
src/lib/env.ts
src/app/api/reviews/route.ts
src/components/reviews/product-reviews.tsx
prisma/seed.js
prisma/seed.ts
```
