# NexoraMart production seed and auth update

This patch adds a production catalog seed with 60 detailed products, local seed image files, optional Cloudinary upload during seed, and password show/requirements UI.

## Files changed

- `package.json`
- `package-lock.json`
- `prisma/schema.prisma`
- `prisma/seed.ts`
- `prisma/seed.mjs`
- `public/uploads/seed/**`
- `src/components/auth/password-input.tsx`
- `src/components/auth/password-requirements.tsx`
- `src/components/LoginClient.tsx`
- `src/app/(auth)/register/SignUpClient.tsx`
- `src/app/(auth)/reset-password/ResetPasswordClient.tsx`
- `src/app/api/auth/register/route.ts`
- selected branding/metadata files changed from SiamsBay to NexoraMart

## Local test

Run on Windows PowerShell inside your local project:

```powershell
cd "G:\Current Project\Development\E-Commerce Project\E-Commerce"
copy .env.example .env
npm ci
npm run build
```

## Push

```powershell
git add .
git commit -m "Add production catalog seed password UI and NexoraMart branding"
git push origin main
```

## VPS deploy

GitHub Actions should deploy automatically after push. After it passes, seed the production database.

Run on VPS path `/var/www/ecommerce`:

```bash
cd /var/www/ecommerce
git pull origin main
docker compose up -d --build
```

## Seed 60 products and upload seed images to Cloudinary

Make sure `/var/www/ecommerce/.env.production` has:

```env
APP_NAME=NexoraMart
IMAGE_STORAGE_DRIVER=cloudinary
CLOUDINARY_CLOUD_NAME=dwahqlufr
CLOUDINARY_API_KEY=YOUR_REAL_KEY
CLOUDINARY_API_SECRET=YOUR_REAL_SECRET
CLOUDINARY_FOLDER=ecommerce
```

Then run:

```bash
cd /var/www/ecommerce
docker compose exec ecommerce npm run seed
```

The seed script reads local image files from `public/uploads/seed/**`. If Cloudinary env is valid, it uploads those files to Cloudinary and saves Cloudinary URLs in the database. If Cloudinary env is missing or storage driver is `local`, it saves local `/uploads/seed/...` URLs instead.

## Verify product count

```bash
cd /var/www/ecommerce
source /root/ecommerce-db-info.txt
PGPASSWORD="$DB_PASSWORD" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -c 'SELECT COUNT(*) FROM "Product";'
```

Expected: at least `60` products.

## Verify Cloudinary URLs

```bash
cd /var/www/ecommerce
source /root/ecommerce-db-info.txt
PGPASSWORD="$DB_PASSWORD" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -c 'SELECT url FROM "ProductImage" ORDER BY "createdAt" DESC LIMIT 10;'
```

Expected: URLs should start with `https://res.cloudinary.com/` when Cloudinary upload worked.

## Auth UI changes

- Login password field now has Show/Hide button.
- Register password field now has Show/Hide button.
- Reset password fields now have Show/Hide buttons.
- Register/reset pages show password requirements so users understand why validation fails.
