# Ecommerce VPS Deploy Commands

Use these commands after pushing this fixed project to:

```txt
https://github.com/techtemlead-lab/E-Commerce.git
```

## 1. VPS packages

Run on VPS as root:

```bash
cd /root
apt update
apt install -y git curl nginx certbot python3-certbot-nginx ufw fail2ban postgresql postgresql-contrib postgresql-client
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker
```

## 2. Create PostgreSQL database

Run on VPS as root:

```bash
cd /var/www/ecommerce
chmod +x /var/www/ecommerce/scripts/setup-postgres.sh
bash /var/www/ecommerce/scripts/setup-postgres.sh
cat /root/ecommerce-db-info.txt
```

Copy the `DATABASE_URL` into `/var/www/ecommerce/.env.production`.

## 3. Create production env

Run on VPS as root:

```bash
cd /var/www/ecommerce
cp /var/www/ecommerce/.env.production.example /var/www/ecommerce/.env.production
nano /var/www/ecommerce/.env.production
chmod 600 /var/www/ecommerce/.env.production
```

Replace all `CHANGE_THIS_*` values. Cloudinary must be real if `IMAGE_STORAGE_DRIVER=cloudinary`.

## 4. Manual Docker deploy test

Run on VPS as root:

```bash
cd /var/www/ecommerce
chmod +x /var/www/ecommerce/scripts/*.sh
docker compose down
docker compose up -d --build
docker compose ps
docker compose logs --tail=200 ecommerce
curl http://localhost:4050/api/health
```

## 5. GitHub Actions secrets

Add these in GitHub repo:

```txt
Settings → Secrets and variables → Actions
```

Required secrets:

```txt
VPS_HOST=198.54.121.88
VPS_USER=root
VPS_PORT=22
VPS_SSH_KEY=<private key that can SSH into VPS>
```

VPS must also have a GitHub deploy key configured with host alias:

```sshconfig
Host github.com-ecommerce
  HostName github.com
  User git
  IdentityFile /root/.ssh/ecommerce_github_deploy_key
  IdentitiesOnly yes
```

Test on VPS:

```bash
ssh -T git@github.com-ecommerce
```

## 6. Fresh clone on VPS

Run on VPS as root:

```bash
cd /var/www
rm -rf /var/www/ecommerce
git clone git@github.com-ecommerce:techtemlead-lab/E-Commerce.git /var/www/ecommerce
cd /var/www/ecommerce
cp /var/www/ecommerce/.env.production.example /var/www/ecommerce/.env.production
nano /var/www/ecommerce/.env.production
chmod 600 /var/www/ecommerce/.env.production
```

## 7. Nginx and SSL

Run only after local health check works.

```bash
cd /var/www/ecommerce
cp /var/www/ecommerce/deploy/nginx/ecommerce.techteamlead.com.conf /etc/nginx/sites-available/ecommerce.techteamlead.com.conf
ln -sf /etc/nginx/sites-available/ecommerce.techteamlead.com.conf /etc/nginx/sites-enabled/ecommerce.techteamlead.com.conf
nginx -t
systemctl reload nginx
certbot --nginx -d ecommerce.techteamlead.com --email techtemlead@gmail.com --agree-tos --redirect
```
