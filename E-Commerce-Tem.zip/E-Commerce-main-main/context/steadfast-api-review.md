# Steadfast Courier API Review

Last checked: 2026-05-02

Source document:
- `/home/mahialamazad/Downloads/steadfast_api.pdf`
- The PDF is a one-page FireShot/Google Docs image, not searchable text. `pdftotext` returned empty output, so the page was rendered to `/tmp/steadfast_api_page-1.png` and reviewed visually.

## API facts from the document

Base URL:
- `https://portal.packzy.com/api/v1`

Required headers:
- `Api-Key`
- `Secret-Key`
- `Content-Type: application/json`

Create order:
- `POST /create_order`
- Required fields: `invoice`, `recipient_name`, `recipient_phone`, `recipient_address`, `cod_amount`
- Optional fields shown in the doc: `alternative_phone`, `recipient_email`, `note`, `item_description`, `total_lot`, `delivery_type`
- `recipient_phone` and `alternative_phone` are expected to be 11 digit Bangladeshi phone numbers.
- `recipient_address` must be within 250 characters.
- `delivery_type`: `0` for home delivery, `1` for Point Delivery / Steadfast Hub Pick Up.

Status lookup:
- `GET /status_by_cid/{id}`
- `GET /status_by_invoice/{invoice}`
- `GET /status_by_trackingcode/{trackingCode}`
- Status response shape shown: `{ "status": 200, "delivery_status": "in_review" }`

Documented delivery statuses:
- `pending`
- `delivered_approval_pending`
- `partial_delivered_approval_pending`
- `cancelled_approval_pending`
- `unknown_approval_pending`
- `delivered`
- `partial_delivered`
- `cancelled`
- `hold`
- `in_review`
- `unknown`

Other documented endpoints:
- `POST /create_order/bulk-order`
- `GET /get_balance`
- `POST /create_return_request`
- `GET /get_return_request/{id}`
- `GET /get_return_requests`
- `GET /payments`
- `GET /payments/{payment_id}`
- `GET /police_stations`

## Project files checked

- `src/lib/couriers/steadfast.ts`
- `src/lib/couriers/steadfast-sync.ts`
- `src/lib/services/steadfast-order-sync.ts`
- `src/app/api/admin/orders/[id]/steadfast/book/route.ts`
- `src/app/api/admin/orders/[id]/steadfast/status/route.ts`
- `src/app/api/admin/orders/[id]/steadfast-sync/route.ts`
- `src/app/api/orders/[id]/steadfast-sync/route.ts`
- `src/app/api/courier/steadfast/police-stations/route.ts`
- `src/app/api/courier/steadfast/webhook/route.ts`
- `src/app/api/cron/steadfast/sync/route.ts`
- `src/components/orders/steadfast-auto-sync.tsx`
- `src/lib/validations/checkout.ts`
- `src/lib/env.ts`

## Verdict

The main Steadfast API implementation is mostly correct against the PDF:
- Auth headers match the document.
- Default base URL matches the document.
- Booking uses `POST /create_order`.
- The create-order payload includes all required fields plus supported optional fields.
- Address is capped to 250 characters.
- Status sync uses `GET /status_by_invoice/{invoice}`.
- The known delivery statuses are mapped into local order statuses.
- Police station lookup uses `GET /police_stations`.

## Issues and risks

1. Phone validation is weaker than the Steadfast requirement.
   - Project checkout validation allows any 8-20 character phone string.
   - `normalizePhone()` strips `+88` or leading `88`, but does not ensure the final phone is exactly 11 digits.
   - This can allow invalid Steadfast booking requests.

2. There are two status-sync implementations.
   - Newer path: `src/lib/couriers/steadfast-sync.ts`
   - Older/general path: `src/lib/services/steadfast-order-sync.ts`
   - `SteadfastAutoSync` still calls `/api/admin/orders/[id]/steadfast-sync` and `/api/orders/[id]/steadfast-sync`, which use the older service module.
   - The admin details button calls `/api/admin/orders/[id]/steadfast/status`, which uses the newer module.
   - This split can cause different behavior depending on where sync is triggered.

3. The older sync service can mark any matching order as `courierName: "Steadfast"` after a sync.
   - It does not check `STEADFAST_ENABLED`.
   - It does not first verify that the order was already booked with Steadfast.
   - It does not send the same notifications as the newer sync module.

4. `fetchSteadfastPoliceStationSource()` uses both `cache: "no-store"` and `next.revalidate`.
   - Those settings express opposite caching intentions.
   - Prefer one behavior. For admin settings lookup, a short revalidation cache is probably enough.

5. `STEADFAST_ORDER_ENDPOINT` and `STEADFAST_STATUS_ENDPOINT` exist in `src/lib/env.ts` but are not used.
   - This is harmless but confusing. Either wire them in or remove them from the schema.

## Suggested cleanup order

1. Enforce an exact normalized Bangladeshi phone format before Steadfast booking.
2. Move all manual, cron, customer, and admin sync paths to `src/lib/couriers/steadfast-sync.ts`.
3. Remove or deprecate `src/lib/services/steadfast-order-sync.ts`.
4. Make police-station fetch caching intentional.
5. Remove unused Steadfast endpoint env vars unless custom endpoint override is planned.

