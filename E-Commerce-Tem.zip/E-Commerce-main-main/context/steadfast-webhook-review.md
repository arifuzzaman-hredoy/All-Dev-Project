# Steadfast Webhook Review

Last checked: 2026-05-02

Source document:
- `/home/mahialamazad/Downloads/steadfast_webhook.pdf`
- The PDF is a one-page FireShot screenshot from the Steadfast merchant dashboard. It has no embedded searchable text; `pdftotext` returned empty output. The page was rendered to `/tmp/steadfast_webhook_page-1.png` and reviewed visually.

## Webhook facts from the document

Steadfast sends:
- Method: `POST`
- Body: JSON
- Header: `Content-Type: application/json`
- Optional auth header if configured: `Authorization: Bearer {your_api_key}`

The Steadfast dashboard has two merchant settings:
- Callback URL
- Auth Token (Bearer)

Delivery status update payload:

```json
{
  "notification_type": "delivery_status",
  "consignment_id": 12345,
  "invoice": "INV-67890",
  "cod_amount": 1500.00,
  "status": "Delivered",
  "delivery_charge": 100.00,
  "tracking_message": "Your package has been delivered successfully.",
  "updated_at": "2025-03-02 12:45:30"
}
```

Delivery status fields:
- `notification_type`: fixed value `delivery_status`
- `consignment_id`: integer
- `invoice`: string
- `cod_amount`: float
- `status`: string. Document lists these values: `pending`, `delivered`, `partial_delivered`, `cancelled`, `unknown`
- `delivery_charge`: float
- `tracking_message`: string
- `updated_at`: datetime string in `YYYY-MM-DD HH:MM:SS`

Tracking update payload:

```json
{
  "notification_type": "tracking_update",
  "consignment_id": 12345,
  "invoice": "INV-67890",
  "tracking_message": "Package arrived at the sorting center.",
  "updated_at": "2025-03-02 13:15:00"
}
```

Tracking update fields:
- `notification_type`: fixed value `tracking_update`
- `consignment_id`: integer
- `invoice`: string
- `tracking_message`: string
- `updated_at`: datetime string in `YYYY-MM-DD HH:MM:SS`

Expected successful response:

```json
{
  "status": "success",
  "message": "Webhook received successfully."
}
```

The document says the server should return HTTP `200 OK` when processed successfully.

## Project files checked

- `src/app/api/courier/steadfast/webhook/route.ts`
- `src/lib/couriers/steadfast.ts`
- `src/lib/env.ts`
- `src/lib/notifications.ts`
- `context/steadfast-api-review.md`

## Verdict

Original finding: the webhook implementation was not fully correct for the PDF.

Implementation update on 2026-05-02:
- The project now accepts the documented `Authorization: Bearer ${STEADFAST_WEBHOOK_SECRET}` header.
- The project still accepts the older custom `x-steadfast-webhook-secret` header during migration.
- The project now reads `status` first, with `delivery_status` as a fallback.
- The project stores the raw webhook body at `paymentMeta.steadfast.lastWebhook`.
- The project now returns `{ "status": "success", "message": "Webhook received successfully." }` on success.

It has the right basic endpoint shape:
- Accepts `POST`
- Parses JSON
- Looks up the order by `invoice`
- Updates `courierName`, `trackingId`, order status, and `paymentMeta`
- Sends local notifications
- Returns HTTP 200 on success

Before that update, it did not match the documented webhook contract in a few important ways.

## Issues and risks

1. Auth header mismatch. Fixed on 2026-05-02.
   - PDF says Steadfast sends `Authorization: Bearer {token}` when auth is configured.
   - Code checks `x-steadfast-webhook-secret` instead.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:23`
   - Result: if the Steadfast dashboard is configured with an auth token, legitimate webhooks will be rejected unless a custom non-documented header is somehow sent.

2. Delivery status field mismatch. Fixed on 2026-05-02.
   - PDF delivery-status payload uses `status`, for example `"Delivered"`.
   - Code only reads `delivery_status`.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:66`
   - Result: real delivery-status webhooks from this PDF will not change the local order status.

3. Tracking-code expectation mismatch.
   - PDF webhook payloads include `consignment_id` but not `tracking_code`.
   - Code only uses `tracking_code` for `trackingId`, falling back to the old stored tracking id.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:63`
   - This may be acceptable if booking already saved `trackingId`, but the webhook itself will not add a missing tracking code because the PDF does not send one.

4. `notification_type` is ignored. Partially addressed on 2026-05-02.
   - PDF distinguishes `delivery_status` and `tracking_update`.
   - Code treats every webhook the same.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:15`
   - Current behavior: the raw payload is stored in `paymentMeta.steadfast.lastWebhook`, so `tracking_message`, `updated_at`, `cod_amount`, and `delivery_charge` are no longer lost, but the app still does not render a tracking timeline from them.

5. Response body differs from the documented success example. Fixed on 2026-05-02.
   - PDF success body is `{ "status": "success", "message": "Webhook received successfully." }`.
   - Code returns `{ "ok": true }`.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:108`
   - HTTP 200 is the most important part, but matching the body would be safer.

6. The webhook can set any invoice-matching order to `courierName: "Steadfast"`.
   - There is no check that the order was already booked with Steadfast.
   - File/line: `src/app/api/courier/steadfast/webhook/route.ts:81`
   - This is probably okay if the endpoint is protected with the correct bearer token, but risky if `STEADFAST_WEBHOOK_SECRET` is empty.

## Suggested fix

Remaining future improvement:
- Render `paymentMeta.steadfast.lastWebhook.tracking_message` and `updated_at` in the customer/admin courier panels.
- Add a true tracking-history array if Steadfast sends repeated tracking updates and the business wants a timeline.
