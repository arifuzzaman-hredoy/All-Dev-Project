# Customer Orders and Steadfast Implementation Notes

Last updated: 2026-05-02

## Why this exists

The customer `/orders` area now has two jobs:
- Let logged-in customers see richer order cards.
- Let guest customers open full order details only when they have proof from tracking/checkout, currently the matching order phone number in the URL query.

This avoids guessing later about why `/orders/[id]` uses `?phone=...` for guest access.

## Customer order access model

Full customer order detail pages expose address, phone, payment details, invoice, courier metadata, and item lines.

Protected pages:
- `src/app/orders/[id]/page.tsx`
- `src/app/orders/[id]/invoice/page.tsx`

Access is allowed when either:
- The logged-in user owns the order: `order.userId === session.user.id`
- The request includes a phone proof matching the order phone: `/orders/{id}?phone=01...`

Shared helper:
- `src/lib/order-access.ts`

Normal customer flows now preserve the phone proof:
- COD checkout redirects to `/orders/{id}?phone=...`
- Manual payment redirects to `/orders/{id}?phone=...`
- `/orders` tracking result cards link to details and invoice with `?phone=...`

## `/orders` page details

Files changed:
- `src/app/orders/page.tsx`
- `src/app/api/orders/account/route.ts`
- `src/app/api/orders/track/route.ts`

The customer cards now show:
- readable order id
- created date
- item count
- order/payment badges
- total
- payment method
- shipping charge
- courier name
- tracking id when available
- preview of first 3 item lines
- invoice and detail actions

## Steadfast research

User-provided PDFs:
- `/home/mahialamazad/Downloads/steadfast_api.pdf`
- `/home/mahialamazad/Downloads/steadfast_webhook.pdf`

Public sources checked:
- Official Steadfast website: `https://www.steadfast.com.bd/`
- Public Laravel package for Steadfast Courier: `https://github.com/steadfast-it/SteadFast-Courier-Laravel-Package`

Relevant public-site facts:
- Steadfast provides ecommerce delivery, COD, online management, and real-time tracking codes for consignments.
- Their public FAQ states common 1 kg delivery charges: Inside Dhaka 70, Dhaka Suburban 100, Outside Dhaka 130.
- Coverage is presented as all 64 Bangladesh districts.

Relevant API/package facts:
- Base URL example in the package: `https://portal.steadfast.com.bd/api/v1`
- The PDF used in this project shows `https://portal.packzy.com/api/v1`; the current project keeps that as the default because it matches the user-provided PDF.
- Create order fields are consistent with the PDF: `invoice`, `recipient_name`, `recipient_phone`, `recipient_address`, `cod_amount`, plus optional note fields.
- Status lookup supports consignment id, invoice id, and tracking code.
- Status responses use `delivery_status`.
- Webhook auth is bearer-token based: `Authorization: Bearer {token}`.
- Webhook payload status is carried as `status`, not only `delivery_status`.

## Steadfast webhook changes made

Files changed:
- `src/app/api/courier/steadfast/webhook/route.ts`
- `src/lib/couriers/steadfast.ts`

Webhook now:
- Accepts documented `Authorization: Bearer ${STEADFAST_WEBHOOK_SECRET}`.
- Still accepts legacy `x-steadfast-webhook-secret` for compatibility.
- Reads `body.status` first, then falls back to `body.delivery_status`.
- Stores the raw webhook payload in `paymentMeta.steadfast.lastWebhook`.
- Returns the documented success-style JSON body.

## Remaining Steadfast risks

- Checkout phone validation still allows broad 8-20 character input. Steadfast booking should eventually enforce normalized 11-digit Bangladeshi phone numbers before calling `/create_order`.
- There are still two status-sync modules in the codebase. Prefer consolidating on `src/lib/couriers/steadfast-sync.ts`.
- The API PDF and public package disagree on default base URL (`portal.packzy.com` vs `portal.steadfast.com.bd`). Keep this controlled by `STEADFAST_BASE_URL`.

