export const enLabels = {
  common: {
    dashboard: 'Dashboard',
    createPaper: 'Create Question Paper',
    myPapers: 'My Papers',
    billing: 'Billing',
    branding: 'Branding',
    pricing: 'Pricing',
    save: 'Save',
    submit: 'Submit'
  }
} as const;
