export const bnLabels = {
  common: {
    dashboard: 'ড্যাশবোর্ড',
    createPaper: 'প্রশ্নপত্র তৈরি করুন',
    myPapers: 'আমার প্রশ্নপত্র',
    billing: 'বিলিং ও ব্যবহার',
    branding: 'প্রতিষ্ঠানের ব্র্যান্ডিং',
    pricing: 'প্যাকেজ',
    save: 'সংরক্ষণ করুন',
    submit: 'জমা দিন'
  },
  questionTypes: {
    MCQ: 'বহুনির্বাচনী প্রশ্ন',
    SHORT: 'সংক্ষিপ্ত প্রশ্ন',
    ONE_WORD: 'এক কথায় উত্তর',
    FILL_BLANK: 'শূন্যস্থান পূরণ',
    TRUE_FALSE: 'সত্য/মিথ্যা',
    CREATIVE: 'সৃজনশীল প্রশ্ন',
    BROAD: 'বর্ণনামূলক প্রশ্ন',
    MATH_PROBLEM: 'গাণিতিক সমস্যা',
    MATCHING: 'মিলকরণ'
  },
  difficultyLevels: {
    VERY_EASY: 'খুব সহজ',
    EASY: 'সহজ',
    MEDIUM: 'মাঝারি',
    HARD: 'কঠিন',
    VERY_HARD: 'খুব কঠিন',
    MIXED: 'মিশ্র',
    BOARD_STANDARD: 'বোর্ড মানের',
    WEAK_STUDENT_FRIENDLY: 'দুর্বল শিক্ষার্থী উপযোগী',
    MERIT_STUDENT_FRIENDLY: 'মেধাবী শিক্ষার্থী উপযোগী'
  },
  importanceLevels: {
    NORMAL: 'সাধারণ',
    IMPORTANT: 'গুরুত্বপূর্ণ',
    VERY_IMPORTANT: 'খুব গুরুত্বপূর্ণ',
    MOST_IMPORTANT: 'সর্বাধিক গুরুত্বপূর্ণ',
    BOARD_REPEATED: 'বোর্ড/পরীক্ষায় বারবার এসেছে',
    TEACHER_RECOMMENDED: 'শিক্ষকের সুপারিশকৃত',
    PREVIOUS_EXAM_COMMON: 'আগের পরীক্ষায় কমন'
  },
  contentModes: {
    FULL_CHAPTER: 'সম্পূর্ণ অধ্যায়',
    PAGE_RANGE: 'নির্দিষ্ট পৃষ্ঠা',
    IMPORTANT_QUESTIONS_ONLY: 'শুধু গুরুত্বপূর্ণ প্রশ্ন'
  },
  templateStyles: {
    CLASSIC: 'ক্লাসিক',
    MODERN: 'মডার্ন',
    MINIMAL: 'মিনিমাল',
    BOARD_EXAM: 'বোর্ড পরীক্ষা',
    COACHING_TEST: 'কোচিং টেস্ট'
  },
  errors: {
    scannedPdf: 'This PDF looks scanned/image-based. OCR support will be added later.',
    planLimit: 'আপনার প্ল্যানের সীমা শেষ হয়েছে। প্ল্যান আপগ্রেড করুন।'
  }
} as const;
