import { bnLabels } from '@/lib/i18n/bn';
import { enLabels } from '@/lib/i18n/en';

export { bnLabels, enLabels };

export const labels = {
  bn: bnLabels,
  en: enLabels
};

export function bilingual(bangla: string, english: string) {
  return `${bangla} (${english})`;
}

export function enumLabel<T extends string>(map: Record<T, string>, value: T, english?: string) {
  const bangla = map[value] ?? value;
  return english ? `${bangla} (${english})` : bangla;
}
