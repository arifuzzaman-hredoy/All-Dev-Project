export const CONTENT_MODES = [
  { value: 'FULL_CHAPTER', label: 'Full Chapter' },
  { value: 'PAGE_RANGE', label: 'Page Range' },
  { value: 'IMPORTANT_QUESTIONS_ONLY', label: 'Important Questions Only' }
] as const;

export const QUESTION_TYPES = [
  { value: 'MCQ', label: 'MCQ' },
  { value: 'SHORT', label: 'Short Question' },
  { value: 'ONE_WORD', label: 'One Word Answer' },
  { value: 'FILL_BLANK', label: 'Fill in the Blanks' },
  { value: 'TRUE_FALSE', label: 'True/False' },
  { value: 'CREATIVE', label: 'Creative Question' },
  { value: 'BROAD', label: 'Broad Question' },
  { value: 'MATH_PROBLEM', label: 'Math Problem' },
  { value: 'MATCHING', label: 'Matching' }
] as const;

export const DIFFICULTY_LEVELS = [
  { value: 'VERY_EASY', label: 'Very Easy' },
  { value: 'EASY', label: 'Easy' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'HARD', label: 'Hard' },
  { value: 'VERY_HARD', label: 'Very Hard' },
  { value: 'MIXED', label: 'Mixed' },
  { value: 'BOARD_STANDARD', label: 'Board Standard' },
  { value: 'WEAK_STUDENT_FRIENDLY', label: 'Weak Student Friendly' },
  { value: 'MERIT_STUDENT_FRIENDLY', label: 'Merit Student Friendly' }
] as const;

export const IMPORTANCE_LEVELS = [
  { value: 'NORMAL', label: 'Normal' },
  { value: 'IMPORTANT', label: 'Important' },
  { value: 'VERY_IMPORTANT', label: 'Very Important' },
  { value: 'MOST_IMPORTANT', label: 'Most Important' },
  { value: 'BOARD_REPEATED', label: 'Board Repeated' },
  { value: 'TEACHER_RECOMMENDED', label: 'Teacher Recommended' },
  { value: 'PREVIOUS_EXAM_COMMON', label: 'Previous Exam Common' }
] as const;

export type ContentMode = (typeof CONTENT_MODES)[number]['value'];
