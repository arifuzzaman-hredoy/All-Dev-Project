import path from 'path';
import { extractPdfTextFromBuffer } from '@/lib/pdf/extract-pdf-text';
import { extractHtmlTextFromBuffer } from '@/lib/files/extract-html-text';

type ExtractedFilePage = {
  pageNumber: number;
  text: string;
};

export type ExtractUploadedTextResult = {
  fullText: string;
  pages: ExtractedFilePage[];
  status: 'SUCCESS' | 'SCANNED_OR_EMPTY';
};

const MIN_TEXT_LENGTH = 40;

function normalizeText(value: string) {
  return value
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function extensionOf(fileName: string) {
  return path.extname(fileName || '').toLowerCase();
}

function isHtmlFile(fileName: string, mimeType?: string | null) {
  const extension = extensionOf(fileName);
  const type = (mimeType ?? '').toLowerCase();
  return extension === '.html' || extension === '.htm' || type === 'text/html' || type === 'application/xhtml+xml';
}

function isPlainTextFile(fileName: string, mimeType?: string | null) {
  const extension = extensionOf(fileName);
  const type = (mimeType ?? '').toLowerCase();
  return (
    extension === '.txt' ||
    extension === '.md' ||
    extension === '.csv' ||
    type.startsWith('text/')
  );
}

function emptyAwareResult(text: string): ExtractUploadedTextResult {
  const fullText = normalizeText(text);
  const pages = fullText ? [{ pageNumber: 1, text: fullText }] : [];
  return {
    fullText,
    pages,
    status: fullText.length < MIN_TEXT_LENGTH ? 'SCANNED_OR_EMPTY' : 'SUCCESS'
  };
}

export async function extractTextFromUploadedBuffer(
  buffer: Buffer,
  originalFileName: string,
  mimeType?: string | null
): Promise<ExtractUploadedTextResult> {
  const extension = extensionOf(originalFileName);
  const type = (mimeType ?? '').toLowerCase();

  if (extension === '.pdf' || type === 'application/pdf') {
    return extractPdfTextFromBuffer(buffer);
  }

  if (extension === '.docx' || type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    try {
      const mammoth = await import('mammoth');
      const result = await mammoth.extractRawText({ buffer });
      return emptyAwareResult(result.value);
    } catch (error) {
      console.error('DOCX extraction failed:', error);
      throw new Error('Could not extract text from this DOCX file. Please upload a valid text-based DOCX.');
    }
  }

  if (isHtmlFile(originalFileName, mimeType)) {
    const extracted = extractHtmlTextFromBuffer(buffer);
    return emptyAwareResult(extracted.fullText);
  }

  if (isPlainTextFile(originalFileName, mimeType)) {
    return emptyAwareResult(buffer.toString('utf8'));
  }

  if (type.startsWith('image/')) {
    throw new Error('This file looks image-based. OCR support will be added later.');
  }

  throw new Error('This file type is not supported yet. Please upload a text-based PDF, DOCX, HTML, TXT, MD, or CSV file.');
}
