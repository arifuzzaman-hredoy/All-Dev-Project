import { randomUUID } from 'crypto';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';

const UPLOAD_ROOT = path.join(process.cwd(), 'storage', 'uploads');

const SUPPORTED_EXTENSIONS = new Set([
  '.pdf',
  '.docx',
  '.html',
  '.htm',
  '.txt',
  '.md',
  '.csv'
]);

const SUPPORTED_MIME_TYPES = new Set([
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/html',
  'application/xhtml+xml',
  'text/plain',
  'text/markdown',
  'text/csv',
  'application/csv'
]);

export async function ensureUploadDir(subFolder = '') {
  const targetDir = path.join(UPLOAD_ROOT, subFolder);
  await mkdir(targetDir, { recursive: true });
  return targetDir;
}

function sanitizeFileName(fileName: string) {
  const parsed = path.parse(fileName);
  const safeBase =
    parsed.name
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'upload';
  const safeExt = parsed.ext.toLowerCase() || '.bin';
  return `${safeBase}${safeExt}`;
}

function isSupportedUpload(file: File) {
  const extension = path.extname(file.name || '').toLowerCase();

  // Important: browsers may upload local .html files as application/octet-stream.
  // So extension check must be the source of truth first.
  if (SUPPORTED_EXTENSIONS.has(extension)) return true;
  if (file.type && SUPPORTED_MIME_TYPES.has(file.type.toLowerCase())) return true;

  return false;
}

export async function saveUploadedFile(file: File, subFolder: string) {
  if (!isSupportedUpload(file)) {
    throw new Error('Unsupported file type. Please upload a text-based PDF, DOCX, HTML, TXT, MD, or CSV file.');
  }

  const uploadDir = await ensureUploadDir(subFolder);
  const originalFileName = file.name || 'upload-file';
  const safeFileName = sanitizeFileName(originalFileName);
  const storedFileName = `${Date.now()}-${randomUUID()}-${safeFileName}`;
  const filePath = path.join(uploadDir, storedFileName);
  const bytes = Buffer.from(await file.arrayBuffer());

  await writeFile(filePath, bytes);

  return {
    filePath,
    buffer: bytes,
    originalFileName,
    mimeType: file.type || 'application/octet-stream',
    sizeBytes: file.size
  };
}
