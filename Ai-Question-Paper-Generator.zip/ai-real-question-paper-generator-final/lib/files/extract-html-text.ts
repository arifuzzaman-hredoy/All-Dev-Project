const MIN_HEADING_LENGTH = 2;

function decodeHtmlEntities(value: string) {
  const named: Record<string, string> = {
    '&nbsp;': ' ',
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
    '&apos;': "'"
  };

  return value
    .replace(/&(nbsp|amp|lt|gt|quot|apos);|&#39;/g, (match) => named[match] ?? match)
    .replace(/&#(\d+);/g, (_match, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_match, code) => String.fromCharCode(parseInt(code, 16)));
}

function cleanHtml(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<!--([\s\S]*?)-->/g, ' ')
    .replace(/<\/?(p|div|section|article|header|footer|main|aside|nav|h[1-6]|li|tr|table|thead|tbody|tfoot|br|hr)\b[^>]*>/gi, '\n')
    .replace(/<\/?(td|th)\b[^>]*>/gi, '\t')
    .replace(/<[^>]+>/g, ' ');
}

export function extractHtmlTextFromBuffer(buffer: Buffer) {
  // Most PDF-to-HTML converters export UTF-8. This keeps Bangla text intact.
  const raw = buffer.toString('utf8');
  const titleMatch = raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? decodeHtmlEntities(cleanHtml(titleMatch[1])).replace(/\s+/g, ' ').trim() : '';

  const fullText = decodeHtmlEntities(cleanHtml(raw))
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .join('\n')
    .trim();

  const headings = Array.from(raw.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi))
    .map((match) => decodeHtmlEntities(cleanHtml(match[1])).replace(/\s+/g, ' ').trim())
    .filter((heading) => heading.length >= MIN_HEADING_LENGTH);

  return {
    title,
    fullText,
    headings
  };
}
