type ExtractedPdfPage = {
  pageNumber: number;
  text: string;
};

export type ExtractPdfTextResult = {
  fullText: string;
  pages: ExtractedPdfPage[];
  status: 'SUCCESS' | 'SCANNED_OR_EMPTY';
};

type PdfParseV2Page = {
  num?: number;
  text?: string;
};

type PdfParseV2TextResult = {
  text?: string;
  pages?: PdfParseV2Page[];
};

type PdfParseV2Instance = {
  getText: () => Promise<PdfParseV2TextResult>;
  destroy?: () => Promise<void> | void;
};

type PdfParseV2Constructor = new (options: { data: Buffer }) => PdfParseV2Instance;

type PdfParseLegacyResult = {
  text?: string;
  numpages?: number;
};

type PdfParseLegacyFunction = (dataBuffer: Buffer) => Promise<PdfParseLegacyResult>;

type PdfParseModuleShape = {
  PDFParse?: unknown;
  default?: unknown;
};

const MIN_TEXT_LENGTH = 40;
const MIN_BANGLA_OR_TEXT_RATIO = 0.12;

function normalizeText(value: string) {
  return value
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function looksLikeUsefulText(value: string) {
  const compact = value.replace(/\s+/g, '');
  if (compact.length < MIN_TEXT_LENGTH) return false;

  const banglaChars = (compact.match(/[\u0980-\u09FF]/g) ?? []).length;
  const latinChars = (compact.match(/[A-Za-z0-9]/g) ?? []).length;
  const useful = banglaChars + latinChars;

  return useful / compact.length >= MIN_BANGLA_OR_TEXT_RATIO;
}

function scannedResult(): ExtractPdfTextResult {
  return {
    fullText: '',
    pages: [],
    status: 'SCANNED_OR_EMPTY'
  };
}

function isPdfParseV2Constructor(value: unknown): value is PdfParseV2Constructor {
  return typeof value === 'function';
}

function isPdfParseLegacyFunction(value: unknown): value is PdfParseLegacyFunction {
  return typeof value === 'function';
}

async function extractWithPdfParseV2(buffer: Buffer): Promise<{ fullText: string; pages: ExtractedPdfPage[] } | null> {
  const mod = (await import('pdf-parse')) as unknown as PdfParseModuleShape;
  const PDFParse = mod.PDFParse;

  if (!isPdfParseV2Constructor(PDFParse)) return null;

  const parser = new PDFParse({ data: buffer });

  try {
    const parsed = await parser.getText();
    const fallbackText = normalizeText(parsed.text ?? '');
    const pages = (parsed.pages ?? [])
      .map((page, index) => ({
        pageNumber: Number(page.num ?? index + 1),
        text: normalizeText(page.text ?? '')
      }))
      .filter((page) => page.text.length > 0);

    const fullText = normalizeText(pages.map((page) => page.text).join('\n\n') || fallbackText);

    return {
      fullText,
      pages: pages.length > 0 ? pages : fullText ? [{ pageNumber: 1, text: fullText }] : []
    };
  } finally {
    await Promise.resolve(parser.destroy?.());
  }
}

async function extractWithPdfParseLegacy(buffer: Buffer): Promise<{ fullText: string; pages: ExtractedPdfPage[] } | null> {
  const mod = (await import('pdf-parse')) as unknown as PdfParseModuleShape;
  const legacyParser = isPdfParseLegacyFunction(mod.default) ? mod.default : null;

  if (!legacyParser) return null;

  const parsed = await legacyParser(buffer);
  const fullText = normalizeText(parsed.text ?? '');

  return {
    fullText,
    pages: fullText ? [{ pageNumber: 1, text: fullText }] : []
  };
}

export async function extractPdfTextFromBuffer(buffer: Buffer): Promise<ExtractPdfTextResult> {
  const attempts: Array<() => Promise<{ fullText: string; pages: ExtractedPdfPage[] } | null>> = [
    () => extractWithPdfParseV2(buffer),
    () => extractWithPdfParseLegacy(buffer)
  ];

  for (const attempt of attempts) {
    try {
      const extracted = await attempt();
      if (!extracted) continue;

      const fullText = normalizeText(extracted.fullText);
      const pages = extracted.pages
        .map((page) => ({
          ...page,
          text: normalizeText(page.text)
        }))
        .filter((page) => page.text.length > 0);

      if (looksLikeUsefulText(fullText)) {
        return {
          fullText,
          pages: pages.length > 0 ? pages : [{ pageNumber: 1, text: fullText }],
          status: 'SUCCESS'
        };
      }
    } catch (error) {
      console.warn('PDF text extraction attempt failed:', error instanceof Error ? error.message : error);
    }
  }

  return scannedResult();
}
