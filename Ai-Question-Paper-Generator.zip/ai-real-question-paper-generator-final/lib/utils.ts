export function safeJsonParse(input: string) {
  try {
    return JSON.parse(input);
  } catch (e) {
    return null;
  }
}
