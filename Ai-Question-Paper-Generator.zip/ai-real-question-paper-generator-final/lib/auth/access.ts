import type { Role, User } from '@prisma/client';
import { notFound, redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { isAdminRole, requireUser } from '@/lib/auth/session';

type PaperOwner = {
  userId: string;
};

type AccessUser = Pick<User, 'id' | 'role'>;

export function canAccessPaper(user: AccessUser, paper: PaperOwner) {
  return paper.userId === user.id || isAdminRole(user.role as Role);
}

export async function requirePaperAccess(paperId: string) {
  const user = await requireUser();
  const paper = await prisma.questionPaper.findUnique({
    where: { id: paperId },
    select: { id: true, userId: true }
  });

  if (!paper) notFound();
  if (!canAccessPaper(user, paper)) redirect('/dashboard?error=unauthorized');

  return { user, paper };
}
