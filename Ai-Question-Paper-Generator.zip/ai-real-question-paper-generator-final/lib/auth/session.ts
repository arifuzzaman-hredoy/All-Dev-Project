import { Role } from '@prisma/client';
import { createHmac, timingSafeEqual } from 'crypto';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';

export const SESSION_COOKIE_NAME = 'ai_qpaper_session';
const SESSION_MAX_AGE = 60 * 60 * 24 * 7;

export function isAdminRole(role: Role) {
  return role === Role.ADMIN || role === Role.SUPER_ADMIN;
}

function getSecret() {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) throw new Error('NEXTAUTH_SECRET is required for authentication.');
  return secret;
}

function base64Url(value: string) {
  return Buffer.from(value, 'utf8').toString('base64url');
}

function fromBase64Url(value: string) {
  return Buffer.from(value, 'base64url').toString('utf8');
}

function sign(value: string) {
  return createHmac('sha256', getSecret()).update(value).digest('base64url');
}

function createSessionValue(userId: string) {
  const payload = base64Url(userId);
  return `${payload}.${sign(payload)}`;
}

function verifySessionValue(value: string) {
  const [payload, signature] = value.split('.');
  if (!payload || !signature) return null;

  const expected = sign(payload);
  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);

  if (signatureBuffer.length !== expectedBuffer.length) return null;
  if (!timingSafeEqual(signatureBuffer, expectedBuffer)) return null;

  const userId = fromBase64Url(payload).trim();
  return userId || null;
}

export function createSession(userId: string) {
  cookies().set(SESSION_COOKIE_NAME, createSessionValue(userId), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_MAX_AGE,
    path: '/'
  });
}

export function destroySession() {
  cookies().delete(SESSION_COOKIE_NAME);
}

export async function getCurrentUser() {
  const sessionValue = cookies().get(SESSION_COOKIE_NAME)?.value;
  if (!sessionValue) return null;

  let userId: string | null = null;
  try {
    userId = verifySessionValue(sessionValue);
  } catch {
    return null;
  }

  if (!userId) return null;

  return prisma.user.findUnique({
    where: { id: userId }
  });
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect('/login');
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (!isAdminRole(user.role)) redirect('/dashboard');
  return user;
}
