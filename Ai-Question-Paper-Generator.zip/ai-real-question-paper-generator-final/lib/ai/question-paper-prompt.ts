import type { QuestionType } from '@prisma/client';
import type { ChatCompletionMessageParam } from 'openai/resources/chat/completions';
import { CQ_STRUCTURE, DEFAULT_BANGLA_PAPER_INSTRUCTIONS, questionTypeInstruction } from '@/lib/education/bd-question-standards';

type PromptBookPage = {
  pageNumber: number;
  content: string;
};

type PromptImportantQuestion = {
  questionText: string;
  answerText?: string | null;
  questionType: string;
  difficultyLevel: string;
  importanceLevel: string;
  pageNumber?: number | null;
  exerciseNo?: string | null;
  questionNo?: string | null;
  isBoardRepeated: boolean;
  isTeacherRecommended: boolean;
  sourceNote?: string | null;
};

type PromptReferenceDocument = {
  title: string;
  type: string;
  text: string;
};

type BuildPromptInput = {
  paperTitle: string;
  className: string;
  subjectName: string;
  bookTitle: string;
  chapterTitle: string;
  totalMarks?: number | null;
  durationMinutes?: number | null;
  selectedQuestionTypes: string[];
  difficultyLevel: string;
  importanceLevel: string;
  extraInstruction?: string | null;
  referenceInstruction?: string | null;
  useReferencePattern?: boolean;
  outputLanguage?: 'BANGLA' | 'ENGLISH' | 'AUTO' | string;
  bookPageContents: PromptBookPage[];
  importantQuestions: PromptImportantQuestion[];
  referenceDocuments?: PromptReferenceDocument[];
};

function formatPages(pages: PromptBookPage[]) {
  if (pages.length === 0) return 'No book page content was retrieved.';

  return pages
    .map((page) => `Page ${page.pageNumber}\n${page.content}`)
    .join('\n\n---\n\n');
}

function formatImportantQuestions(questions: PromptImportantQuestion[]) {
  if (questions.length === 0) return 'No important questions were retrieved.';

  return questions
    .map((question, index) => {
      const reference = [
        question.pageNumber ? `page ${question.pageNumber}` : null,
        question.exerciseNo ? `exercise ${question.exerciseNo}` : null,
        question.questionNo ? `question ${question.questionNo}` : null,
        question.isBoardRepeated ? 'board repeated' : null,
        question.isTeacherRecommended ? 'teacher recommended' : null
      ]
        .filter(Boolean)
        .join(', ');

      return [
        `Important Question ${index + 1}${reference ? ` (${reference})` : ''}`,
        `Type: ${question.questionType}`,
        `Difficulty: ${question.difficultyLevel}`,
        `Importance: ${question.importanceLevel}`,
        `Question: ${question.questionText}`,
        question.answerText ? `Answer: ${question.answerText}` : null,
        question.sourceNote ? `Source note: ${question.sourceNote}` : null
      ]
        .filter(Boolean)
        .join('\n');
    })
    .join('\n\n---\n\n');
}

function formatReferenceDocuments(documents: PromptReferenceDocument[] = []) {
  if (documents.length === 0) return 'No previous question/reference PDF was provided.';

  return documents
    .map((document, index) => [
      `Reference ${index + 1}: ${document.title}`,
      `Type: ${document.type}`,
      document.text
    ].join('\n'))
    .join('\n\n---\n\n');
}

export function buildQuestionPaperPrompt(input: BuildPromptInput): ChatCompletionMessageParam[] {
  const selectedTypeStandards = questionTypeInstruction(input.selectedQuestionTypes as QuestionType[]);
  const system = `You are an expert Bangladeshi academic question paper maker.
You understand Bangladeshi school, coaching, class test, model test, and board-style question formats.

Strict rules:
1. Return valid JSON only. No markdown. No explanation outside JSON.
2. Generate questions only from selected book/chapter/page content and important question records.
3. Previous question/reference PDF is only for style, pattern, marks distribution, and difficulty understanding.
4. Do not directly copy previous question unless teacher explicitly asks.
5. Prioritize ImportantQuestion records if available.
6. Do not hallucinate outside the book/chapter content.

Language rules:
1. If outputLanguage is BANGLA, every question, instruction, answer, explanation, section title, and sourceReference must be in Bangla.
2. If source content is Bangla, output must be Bangla.
3. Do not mix Hindi.
4. Do not use awkward translation.
5. Use natural academic Bangla used in Bangladesh.
6. Use English only for standard terms when necessary.

Bangladeshi question format rules:
MCQ:
- Use Bangla question text.
- Give exactly 4 options in options array.
- The option labels are ক, খ, গ, ঘ in order.
- correctAnswer must be one of ক, খ, গ, ঘ.
- explanation must explain why the answer is correct.
- MCQ should be exam-worthy, not too simple unless difficulty is EASY.

Creative Question / CQ:
- Must include an উদ্দীপক.
- Must include four sub-questions: ক. জ্ঞানমূলক — ১ নম্বর, খ. অনুধাবনমূলক — ২ নম্বর, গ. প্রয়োগমূলক — ৩ নম্বর, ঘ. উচ্চতর দক্ষতামূলক — ৪ নম্বর.
- Total CQ marks: ১০.
- CQ structure reference: ${CQ_STRUCTURE.stimulusTitle}; ${CQ_STRUCTURE.parts.map((part) => `${part.key}. ${part.label} (${part.marks})`).join(', ')}.
- Provide either questionText with full stimulus and four parts, or stimulus + subQuestions.
- answerText must contain model answer guidance for ক/খ/গ/ঘ.
- explanation must mention expected answer depth.

Short Question:
- 1 or 2 marks.
- Direct but exam-worthy.
- Answer should be concise.

Broad Question:
- 5 to 10 marks.
- Must require explanation/analysis.

Math Problem:
- Must be solvable from chapter content.
- Include numbers/formula from source when possible.
- answerText should include step-by-step solution.
- Avoid random unrealistic numbers.

Fill in the Blanks:
- Use clear blank: _____.
- correctAnswer required.

True/False:
- correctAnswer must be সত্য or মিথ্যা.
- explanation required.

Matching:
- Create left column and right column in questionText.
- answerText should provide correct matching.

Selected question type standards:
${selectedTypeStandards}

Default Bangla instruction style:
${DEFAULT_BANGLA_PAPER_INSTRUCTIONS.map((item) => `- ${item}`).join('\n')}`;

  const user = `Create a question paper from the following saved draft and source material.

Draft:
- Paper title: ${input.paperTitle}
- Class: ${input.className}
- Subject: ${input.subjectName}
- Book: ${input.bookTitle}
- Chapter: ${input.chapterTitle}
- Total marks: ${input.totalMarks ?? 0}
- Duration minutes: ${input.durationMinutes ?? 0}
- Selected question types: ${input.selectedQuestionTypes.join(', ')}
- Difficulty level: ${input.difficultyLevel}
- Importance level: ${input.importanceLevel}
- Output language: ${input.outputLanguage ?? 'BANGLA'}
- Teacher extra instruction: ${input.extraInstruction || 'None'}
- Reference instruction: ${input.referenceInstruction || 'None'}
- Follow reference pattern strongly: ${input.useReferencePattern ? 'Yes' : 'No'}

Marks distribution guidance:
- Follow teacher totalMarks and selected question types.
- If totalMarks is 50 and selected MCQ + SHORT + CREATIVE, a valid pattern is: MCQ ২০ × ১ = ২০, Short ৫ × ২ = ১০, Creative ২ × ১০ = ২০.
- If previous question/reference is uploaded, analyze its section pattern and use similar distribution if possible.

Book page source content:
${formatPages(input.bookPageContents)}

Important questions source content:
${formatImportantQuestions(input.importantQuestions)}

Previous question/reference style guidance:
${formatReferenceDocuments(input.referenceDocuments)}

Return JSON using exactly this shape:
{
  "paperTitle": "string",
  "className": "string",
  "subject": "string",
  "book": "string",
  "chapter": "string",
  "totalMarks": number,
  "durationMinutes": number,
  "sections": [
    {
      "sectionTitle": "string",
      "questionType": "MCQ | SHORT | ONE_WORD | FILL_BLANK | TRUE_FALSE | CREATIVE | BROAD | MATH_PROBLEM | MATCHING",
      "questions": [
        {
          "questionText": "string",
          "options": ["string", "string", "string", "string"],
          "correctAnswer": "string",
          "answerText": "string",
          "explanation": "string",
          "marks": number,
          "difficultyLevel": "VERY_EASY | EASY | MEDIUM | HARD | VERY_HARD | MIXED | BOARD_STANDARD | WEAK_STUDENT_FRIENDLY | MERIT_STUDENT_FRIENDLY",
          "importanceLevel": "NORMAL | IMPORTANT | VERY_IMPORTANT | MOST_IMPORTANT | BOARD_REPEATED | TEACHER_RECOMMENDED | PREVIOUS_EXAM_COMMON",
          "sourceReference": "string",
          "stimulus": "string optional, for CREATIVE/CQ",
          "subQuestions": [
            { "key": "ক", "label": "জ্ঞানমূলক", "questionText": "string", "marks": 1, "answerText": "string" }
          ]
        }
      ]
    }
  ]
}`;

  return [
    { role: 'system', content: system },
    { role: 'user', content: user }
  ];
}
