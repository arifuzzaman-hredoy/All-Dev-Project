export function buildQuestionQualityCheckPrompt(generatedPaper: unknown, sourceContent: string, settings: { outputLanguage?: string }) {
  return [
    {
      role: 'system' as const,
      content: 'You are a strict Bangladeshi academic question paper quality reviewer. Return JSON only.'
    },
    {
      role: 'user' as const,
      content: `Check this generated question paper for quality.

Rules:
1. All questions are Bangla if outputLanguage is BANGLA.
2. Questions are from source content.
3. MCQ has exactly 4 options.
4. CQ has উদ্দীপক + ক/খ/গ/ঘ.
5. Marks are reasonable.
6. No duplicate questions.
7. No direct copy from previous question unless instructed.
8. Output follows Bangladesh exam style.

Settings:
${JSON.stringify(settings)}

Source:
${sourceContent.slice(0, 6000)}

Generated paper:
${JSON.stringify(generatedPaper).slice(0, 10000)}

Return:
{ "passed": boolean, "issues": ["string"], "suggestions": ["string"] }`
    }
  ];
}

export const ENABLE_AI_QUALITY_CHECK = false;
