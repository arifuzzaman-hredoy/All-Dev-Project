import OpenAI from 'openai';
import type { ChatCompletionMessageParam } from 'openai/resources/chat/completions';

type DeepSeekOptions = {
  temperature?: number;
  maxTokens?: number;
};

export async function generateWithDeepSeek(messages: ChatCompletionMessageParam[], options: DeepSeekOptions = {}) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  const baseURL = process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';
  const model = process.env.DEEPSEEK_MODEL || 'deepseek-chat';

  if (!apiKey) throw new Error('DeepSeek API key not configured');

  const client = new OpenAI({ apiKey, baseURL });

  const res = await client.chat.completions.create({
    model,
    messages,
    temperature: options.temperature ?? 0.2,
    max_tokens: options.maxTokens ?? 4000
  });

  const content = res.choices[0]?.message?.content;
  if (!content) throw new Error('DeepSeek returned an empty response');

  return content;
}

export async function testDeepSeek(prompt: string) {
  return generateWithDeepSeek([{ role: 'user', content: prompt }], { maxTokens: 800 });
}
