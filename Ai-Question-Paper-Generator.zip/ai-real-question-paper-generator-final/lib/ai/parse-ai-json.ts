import { DifficultyLevel, ImportanceLevel, QuestionType } from '@prisma/client';
import { z } from 'zod';

const aiSubQuestionSchema = z.object({
  key: z.string().trim().min(1),
  label: z.string().optional().nullable(),
  questionText: z.string().trim().min(1),
  marks: z.number().positive().optional().nullable(),
  answerText: z.string().optional().nullable()
});

const aiQuestionSchema = z.object({
  questionText: z.string().trim().optional().default(''),
  options: z.array(z.string()).optional().default([]),
  correctAnswer: z.string().optional().nullable(),
  answerText: z.string().optional().nullable(),
  explanation: z.string().optional().nullable(),
  marks: z.number().positive().optional().nullable(),
  difficultyLevel: z.nativeEnum(DifficultyLevel).optional().nullable(),
  importanceLevel: z.nativeEnum(ImportanceLevel).optional().nullable(),
  sourceReference: z.string().optional().nullable(),
  stimulus: z.string().optional().nullable(),
  subQuestions: z.array(aiSubQuestionSchema).optional().default([])
});

const aiSectionSchema = z.object({
  sectionTitle: z.string().trim().min(1),
  questionType: z.nativeEnum(QuestionType),
  questions: z.array(aiQuestionSchema).default([])
});

const aiPaperSchema = z.object({
  paperTitle: z.string().trim().min(1),
  className: z.string().optional().default(''),
  subject: z.string().optional().default(''),
  book: z.string().optional().default(''),
  chapter: z.string().optional().default(''),
  totalMarks: z.number().optional().default(0),
  durationMinutes: z.number().optional().default(0),
  sections: z.array(aiSectionSchema).min(1)
});

export type ParsedAiQuestionPaper = z.infer<typeof aiPaperSchema>;

function stripMarkdownFences(rawText: string) {
  return rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
}

function extractJson(rawText: string) {
  const cleaned = stripMarkdownFences(rawText);
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');

  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
    throw new Error('AI returned invalid JSON. Please regenerate.');
  }

  return cleaned.slice(firstBrace, lastBrace + 1);
}

export function parseAiQuestionPaperJson(rawText: string) {
  try {
    const jsonText = extractJson(rawText);
    const parsed: unknown = JSON.parse(jsonText);
    const paper = aiPaperSchema.parse(parsed);

    return {
      ...paper,
      sections: paper.sections.map((section) => ({
        ...section,
        questions: section.questions.map((question) => ({
          ...question,
          questionText: normalizeQuestionText(question)
        }))
      }))
    };
  } catch {
    throw new Error('AI returned invalid JSON. Please regenerate.');
  }
}

function normalizeQuestionText(question: z.infer<typeof aiQuestionSchema>) {
  const parts: string[] = [];
  const baseQuestion = question.questionText.trim();
  const stimulus = question.stimulus?.trim();

  if (stimulus) parts.push(`উদ্দীপক:\n${stimulus}`);
  if (baseQuestion) parts.push(baseQuestion);

  if (question.subQuestions.length > 0) {
    const subQuestionText = question.subQuestions
      .map((subQuestion) => {
        const marks = subQuestion.marks ? ` (${subQuestion.marks})` : '';
        const label = subQuestion.label ? ` ${subQuestion.label}` : '';
        return `${subQuestion.key})${label}: ${subQuestion.questionText}${marks}`;
      })
      .join('\n');
    parts.push(subQuestionText);
  }

  const normalized = parts.join('\n\n').trim();
  if (!normalized) throw new Error('AI returned a question without text.');
  return normalized;
}
