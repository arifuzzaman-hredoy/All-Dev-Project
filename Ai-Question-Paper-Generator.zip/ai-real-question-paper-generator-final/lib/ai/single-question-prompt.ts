import type { ChatCompletionMessageParam } from 'openai/resources/chat/completions';

type CurrentQuestionInput = {
  sectionTitle?: string | null;
  questionType: string;
  questionText: string;
  options: string[];
  correctAnswer?: string | null;
  answerText?: string | null;
  explanation?: string | null;
  marks?: number | null;
  difficultyLevel: string;
  importanceLevel: string;
};

type PromptBookPage = {
  pageNumber: number;
  content: string;
};

type PromptImportantQuestion = {
  questionText: string;
  answerText?: string | null;
  questionType: string;
  difficultyLevel: string;
  importanceLevel: string;
  pageNumber?: number | null;
  exerciseNo?: string | null;
  questionNo?: string | null;
  isBoardRepeated: boolean;
  isTeacherRecommended: boolean;
};

type BuildSingleQuestionPromptInput = {
  currentQuestion: CurrentQuestionInput;
  paperTitle: string;
  className: string;
  subjectName: string;
  bookTitle: string;
  chapterTitle: string;
  difficultyLevel: string;
  importanceLevel: string;
  teacherInstruction?: string | null;
  bookPageContents: PromptBookPage[];
  importantQuestions: PromptImportantQuestion[];
};

function formatPages(pages: PromptBookPage[]) {
  if (pages.length === 0) return 'No book page content was retrieved.';
  return pages.map((page) => `Page ${page.pageNumber}\n${page.content}`).join('\n\n---\n\n');
}

function formatImportantQuestions(questions: PromptImportantQuestion[]) {
  if (questions.length === 0) return 'No important questions were retrieved.';

  return questions
    .map((question, index) => {
      const reference = [
        question.pageNumber ? `page ${question.pageNumber}` : null,
        question.exerciseNo ? `exercise ${question.exerciseNo}` : null,
        question.questionNo ? `question ${question.questionNo}` : null,
        question.isBoardRepeated ? 'board repeated' : null,
        question.isTeacherRecommended ? 'teacher recommended' : null
      ]
        .filter(Boolean)
        .join(', ');

      return [
        `Important Question ${index + 1}${reference ? ` (${reference})` : ''}`,
        `Type: ${question.questionType}`,
        `Difficulty: ${question.difficultyLevel}`,
        `Importance: ${question.importanceLevel}`,
        `Question: ${question.questionText}`,
        question.answerText ? `Answer: ${question.answerText}` : null
      ]
        .filter(Boolean)
        .join('\n');
    })
    .join('\n\n---\n\n');
}

export function buildSingleQuestionRegenerationPrompt(input: BuildSingleQuestionPromptInput): ChatCompletionMessageParam[] {
  const system = `You are an expert Bangladeshi academic question paper maker.

Strict rules:
1. Regenerate or improve only one question.
2. Do not generate a full paper.
3. Use only the given source content.
4. Keep the same question type unless the teacher instruction clearly asks otherwise.
5. Keep the same section title unless changing it improves clarity.
6. Follow selected difficulty and importance.
7. Follow teacher instruction.
8. Use Bangla if the source/current question/teacher instruction is Bangla, otherwise English.
9. Return valid JSON only.
10. No markdown.
11. No explanation outside JSON.
12. For MCQ, options must be exactly 4 items when possible.
13. For non-MCQ, options can be an empty array.`;

  const user = `Improve or regenerate this one generated question.

Paper:
- Title: ${input.paperTitle}
- Class: ${input.className}
- Subject: ${input.subjectName}
- Book: ${input.bookTitle}
- Chapter: ${input.chapterTitle}
- Selected difficulty: ${input.difficultyLevel}
- Selected importance: ${input.importanceLevel}
- Teacher instruction for this question only: ${input.teacherInstruction || 'None'}

Current question:
${JSON.stringify(input.currentQuestion, null, 2)}

Book page source content:
${formatPages(input.bookPageContents)}

Important questions source content:
${formatImportantQuestions(input.importantQuestions)}

Return JSON using exactly this shape:
{
  "sectionTitle": "string",
  "questionType": "MCQ",
  "questionText": "string",
  "options": ["string", "string", "string", "string"],
  "correctAnswer": "string",
  "answerText": "string",
  "explanation": "string",
  "marks": 1,
  "difficultyLevel": "MEDIUM",
  "importanceLevel": "IMPORTANT"
}`;

  return [
    { role: 'system', content: system },
    { role: 'user', content: user }
  ];
}
