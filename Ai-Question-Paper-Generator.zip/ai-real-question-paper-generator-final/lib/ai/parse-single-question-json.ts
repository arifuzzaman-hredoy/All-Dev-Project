import { DifficultyLevel, ImportanceLevel, QuestionType } from '@prisma/client';
import { z } from 'zod';

const singleQuestionSchema = z.object({
  sectionTitle: z.string().trim().optional().nullable(),
  questionType: z.nativeEnum(QuestionType),
  questionText: z.string().trim().min(1),
  options: z.array(z.string()).optional().default([]),
  correctAnswer: z.string().trim().optional().nullable(),
  answerText: z.string().trim().optional().nullable(),
  explanation: z.string().trim().optional().nullable(),
  marks: z.number().positive().optional().nullable(),
  difficultyLevel: z.nativeEnum(DifficultyLevel),
  importanceLevel: z.nativeEnum(ImportanceLevel)
});

export type ParsedSingleQuestion = z.infer<typeof singleQuestionSchema>;

function stripMarkdownFences(rawText: string) {
  return rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
}

function extractJson(rawText: string) {
  const cleaned = stripMarkdownFences(rawText);
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');

  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
    throw new Error('AI returned invalid question JSON. Please try again.');
  }

  return cleaned.slice(firstBrace, lastBrace + 1);
}

export function parseSingleQuestionJson(rawText: string) {
  try {
    const jsonText = extractJson(rawText);
    const parsed: unknown = JSON.parse(jsonText);
    return singleQuestionSchema.parse(parsed);
  } catch {
    throw new Error('AI returned invalid question JSON. Please try again.');
  }
}
