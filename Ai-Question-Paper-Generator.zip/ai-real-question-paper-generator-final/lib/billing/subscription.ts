import { SubscriptionStatus, UsageAction, type Plan, type Subscription } from '@prisma/client';
import { prisma } from '@/lib/prisma';

const PLAN_LIMIT_MESSAGE = 'Your plan limit has been reached. Please upgrade your plan.';

export class BillingError extends Error {
  constructor(
    message: string,
    public code: 'PLAN_LIMIT_REACHED' | 'FEATURE_NOT_ALLOWED' | 'NO_FREE_PLAN'
  ) {
    super(message);
    this.name = 'BillingError';
  }
}

type SubscriptionWithPlan = Subscription & { plan: Plan };

type VirtualSubscription = {
  id: null;
  userId: string;
  planId: string;
  status: SubscriptionStatus;
  billingCycle: 'MONTHLY';
  startsAt: Date;
  endsAt: Date | null;
  currentPeriodStart: Date;
  currentPeriodEnd: Date | null;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
  plan: Plan;
};

export type UserSubscriptionOrFree = SubscriptionWithPlan | VirtualSubscription;

export function getCurrentPeriodRange(date = new Date()) {
  const start = new Date(date.getFullYear(), date.getMonth(), 1);
  const end = new Date(date.getFullYear(), date.getMonth() + 1, 1);
  return { start, end };
}

export async function getActiveSubscription(userId: string) {
  const now = new Date();

  return prisma.subscription.findFirst({
    where: {
      userId,
      status: { in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING] },
      OR: [{ endsAt: null }, { endsAt: { gt: now } }]
    },
    include: { plan: true },
    orderBy: { createdAt: 'desc' }
  });
}

export async function getUserSubscriptionOrFree(userId: string): Promise<UserSubscriptionOrFree> {
  const subscription = await getActiveSubscription(userId);
  if (subscription) return subscription;

  const freePlan = await prisma.plan.findUnique({ where: { slug: 'free' } });
  if (!freePlan) {
    throw new BillingError('Free plan is not configured. Please contact admin.', 'NO_FREE_PLAN');
  }

  const { start, end } = getCurrentPeriodRange();

  return {
    id: null,
    userId,
    planId: freePlan.id,
    status: SubscriptionStatus.ACTIVE,
    billingCycle: 'MONTHLY',
    startsAt: start,
    endsAt: null,
    currentPeriodStart: start,
    currentPeriodEnd: end,
    notes: 'Free plan fallback',
    createdAt: start,
    updatedAt: start,
    plan: freePlan
  };
}

export async function getMonthlyUsage(userId: string, action: UsageAction) {
  const { start, end } = getCurrentPeriodRange();
  const result = await prisma.usageLog.aggregate({
    where: {
      userId,
      action,
      createdAt: { gte: start, lt: end }
    },
    _sum: { amount: true }
  });

  return result._sum.amount ?? 0;
}

function remaining(limit: number, used: number) {
  return Math.max(0, limit - used);
}

export async function getUsageSummary(userId: string) {
  const subscription = await getUserSubscriptionOrFree(userId);
  const plan = subscription.plan;
  const [paperUsed, aiGenerationUsed, aiRegenerateUsed, exportDocxUsed, exportHtmlUsed, exportPdfUsed] = await Promise.all([
    getMonthlyUsage(userId, UsageAction.CREATE_DRAFT_PAPER),
    getMonthlyUsage(userId, UsageAction.AI_GENERATE_PAPER),
    getMonthlyUsage(userId, UsageAction.AI_REGENERATE_QUESTION),
    getMonthlyUsage(userId, UsageAction.EXPORT_DOCX),
    getMonthlyUsage(userId, UsageAction.EXPORT_HTML),
    getMonthlyUsage(userId, UsageAction.EXPORT_PDF)
  ]);
  const exportUsed = exportDocxUsed + exportHtmlUsed + exportPdfUsed;

  return {
    plan,
    subscription,
    paperUsed,
    aiGenerationUsed,
    aiRegenerateUsed,
    exportUsed,
    limits: {
      paperLimitMonthly: plan.paperLimitMonthly,
      aiGenerationLimitMonthly: plan.aiGenerationLimitMonthly,
      aiRegenerateLimitMonthly: plan.aiRegenerateLimitMonthly,
      exportLimitMonthly: plan.exportLimitMonthly,
      maxPagesPerPaper: plan.maxPagesPerPaper
    },
    remaining: {
      papers: remaining(plan.paperLimitMonthly, paperUsed),
      aiGenerations: remaining(plan.aiGenerationLimitMonthly, aiGenerationUsed),
      aiRegenerations: remaining(plan.aiRegenerateLimitMonthly, aiRegenerateUsed),
      exports: remaining(plan.exportLimitMonthly, exportUsed)
    }
  };
}

function limitForAction(plan: Plan, action: UsageAction) {
  if (action === UsageAction.CREATE_DRAFT_PAPER) return plan.paperLimitMonthly;
  if (action === UsageAction.AI_GENERATE_PAPER) return plan.aiGenerationLimitMonthly;
  if (action === UsageAction.AI_REGENERATE_QUESTION) return plan.aiRegenerateLimitMonthly;
  return plan.exportLimitMonthly;
}

async function getExportUsage(userId: string) {
  const [docx, html, pdf] = await Promise.all([
    getMonthlyUsage(userId, UsageAction.EXPORT_DOCX),
    getMonthlyUsage(userId, UsageAction.EXPORT_HTML),
    getMonthlyUsage(userId, UsageAction.EXPORT_PDF)
  ]);

  return docx + html + pdf;
}

export async function assertUsageAllowed(userId: string, action: UsageAction, options: { amount?: number } = {}) {
  const amount = options.amount ?? 1;
  const subscription = await getUserSubscriptionOrFree(userId);
  const plan = subscription.plan;

  if (action === UsageAction.AI_REGENERATE_QUESTION && !plan.canUseSelectiveRegenerate) {
    throw new BillingError('Selective regenerate is not available on your current plan.', 'FEATURE_NOT_ALLOWED');
  }

  if (action === UsageAction.EXPORT_DOCX && !plan.canExportDocx) {
    throw new BillingError('DOCX export is not available on your current plan.', 'FEATURE_NOT_ALLOWED');
  }

  if (action === UsageAction.EXPORT_PDF && !plan.canExportPdf) {
    throw new BillingError('PDF export is not available on your current plan.', 'FEATURE_NOT_ALLOWED');
  }

  const used = action === UsageAction.EXPORT_DOCX || action === UsageAction.EXPORT_HTML || action === UsageAction.EXPORT_PDF
    ? await getExportUsage(userId)
    : await getMonthlyUsage(userId, action);
  const limit = limitForAction(plan, action);

  if (used + amount > limit) {
    throw new BillingError(PLAN_LIMIT_MESSAGE, 'PLAN_LIMIT_REACHED');
  }

  return subscription;
}

export async function recordUsage(userId: string, action: UsageAction, paperId?: string, amount = 1) {
  const subscription = await getActiveSubscription(userId);

  return prisma.usageLog.create({
    data: {
      userId,
      subscriptionId: subscription?.id ?? null,
      paperId,
      action,
      amount
    }
  });
}

export async function assertFeatureAllowed(
  userId: string,
  feature: 'importantQuestions' | 'selectiveRegenerate' | 'exportDocx' | 'exportPdf' | 'teacherCopy'
) {
  const subscription = await getUserSubscriptionOrFree(userId);
  const plan = subscription.plan;
  const allowed =
    (feature === 'importantQuestions' && plan.canUseImportantQuestions) ||
    (feature === 'selectiveRegenerate' && plan.canUseSelectiveRegenerate) ||
    (feature === 'exportDocx' && plan.canExportDocx) ||
    (feature === 'exportPdf' && plan.canExportPdf) ||
    (feature === 'teacherCopy' && plan.canUseTeacherCopy);

  if (!allowed) {
    throw new BillingError('This feature is not available on your current plan.', 'FEATURE_NOT_ALLOWED');
  }

  return true;
}

export function billingErrorMessage(error: unknown) {
  if (error instanceof BillingError) return error.message;
  return null;
}
