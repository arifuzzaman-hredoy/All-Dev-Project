'use server';

import { PaperTemplateStyle, Prisma } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { canAccessPaper } from '@/lib/auth/access';
import { isAdminRole, requireUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

const optionalString = z.string().trim().transform((value) => value || null);

const brandingSchema = z.object({
  schoolId: optionalString,
  name: z.string().trim().min(1, 'Institution name is required').max(200),
  logoUrl: optionalString,
  address: optionalString,
  phone: optionalString,
  email: z.string().trim().email('Enter a valid email').or(z.literal('')).transform((value) => value || null),
  website: optionalString,
  watermarkText: optionalString,
  defaultHeaderNote: optionalString,
  defaultFooterText: optionalString,
  defaultSignatureText: optionalString
});

const paperTemplateSchema = z.object({
  paperId: z.string().trim().min(1, 'Paper is required'),
  examTitle: optionalString,
  headerNote: optionalString,
  footerText: optionalString,
  watermarkText: optionalString,
  teacherName: optionalString,
  signatureText: optionalString,
  templateStyle: z.nativeEnum(PaperTemplateStyle)
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function friendlyError(error: unknown) {
  if (error instanceof z.ZodError) return error.issues.map((issue) => issue.message).join(', ');
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2025') return 'The selected record was not found.';
  }
  return 'Something went wrong. Please try again.';
}

export async function updateSchoolBranding(formData: FormData) {
  const user = await requireUser();
  let redirectUrl = '/dashboard/branding?success=branding_updated';

  try {
    const data = brandingSchema.parse({
      schoolId: formString(formData, 'schoolId'),
      name: formString(formData, 'name'),
      logoUrl: formString(formData, 'logoUrl'),
      address: formString(formData, 'address'),
      phone: formString(formData, 'phone'),
      email: formString(formData, 'email'),
      website: formString(formData, 'website'),
      watermarkText: formString(formData, 'watermarkText'),
      defaultHeaderNote: formString(formData, 'defaultHeaderNote'),
      defaultFooterText: formString(formData, 'defaultFooterText'),
      defaultSignatureText: formString(formData, 'defaultSignatureText')
    });

    const schoolId = data.schoolId ?? user.schoolId;
    const schoolData = {
      name: data.name,
      logoUrl: data.logoUrl,
      address: data.address,
      phone: data.phone,
      email: data.email,
      website: data.website,
      watermarkText: data.watermarkText,
      defaultHeaderNote: data.defaultHeaderNote,
      defaultFooterText: data.defaultFooterText,
      defaultSignatureText: data.defaultSignatureText
    };

    if (schoolId) {
      const school = await prisma.school.findUniqueOrThrow({ where: { id: schoolId } });
      if (!isAdminRole(user.role) && school.id !== user.schoolId) {
        redirectUrl = '/dashboard/branding?error=unauthorized';
      } else {
        await prisma.school.update({ where: { id: school.id }, data: schoolData });
      }
    } else {
      const school = await prisma.school.create({ data: schoolData });
      await prisma.user.update({ where: { id: user.id }, data: { schoolId: school.id } });
    }

    revalidatePath('/dashboard/branding');
    revalidatePath('/dashboard/settings');
  } catch (error) {
    console.error('Update school branding failed:', error);
    redirectUrl = `/dashboard/branding?error=${encodeURIComponent(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}

export async function updatePaperTemplate(formData: FormData) {
  const user = await requireUser();
  let paperId = formString(formData, 'paperId');
  let redirectUrl = `/dashboard/papers/${paperId}?success=template_updated`;

  try {
    const data = paperTemplateSchema.parse({
      paperId: formString(formData, 'paperId'),
      examTitle: formString(formData, 'examTitle'),
      headerNote: formString(formData, 'headerNote'),
      footerText: formString(formData, 'footerText'),
      watermarkText: formString(formData, 'watermarkText'),
      teacherName: formString(formData, 'teacherName'),
      signatureText: formString(formData, 'signatureText'),
      templateStyle: formString(formData, 'templateStyle')
    });
    paperId = data.paperId;

    const paper = await prisma.questionPaper.findUniqueOrThrow({
      where: { id: data.paperId },
      select: { id: true, userId: true }
    });

    if (!canAccessPaper(user, paper)) {
      redirectUrl = '/dashboard?error=unauthorized';
    } else {
      await prisma.questionPaper.update({
        where: { id: data.paperId },
        data: {
          examTitle: data.examTitle,
          headerNote: data.headerNote,
          footerText: data.footerText,
          watermarkText: data.watermarkText,
          teacherName: data.teacherName,
          signatureText: data.signatureText,
          templateStyle: data.templateStyle
        }
      });

      revalidatePath(`/dashboard/papers/${data.paperId}`);
    }
  } catch (error) {
    console.error('Update paper template failed:', error);
    redirectUrl = `/dashboard/papers/${paperId}?error=${encodeURIComponent(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}
