'use server';

import { revalidatePath } from 'next/cache';
import { Prisma, QuestionType, DifficultyLevel, ImportanceLevel } from '@prisma/client';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

const requiredString = z.string().trim().min(1, 'This field is required');
const optionalString = z.string().trim().transform((value) => value || null);
const optionalInt = z
  .string()
  .trim()
  .transform((value) => (value === '' ? null : Number(value)))
  .pipe(z.number().int().positive().nullable());

const classSchema = z.object({
  name: requiredString,
  orderNo: optionalInt
});

const subjectSchema = z.object({
  name: requiredString,
  classId: requiredString
});

const bookSchema = z.object({
  title: requiredString,
  edition: optionalString,
  publisher: optionalString,
  classId: requiredString,
  subjectId: requiredString
});

const chapterSchema = z.object({
  chapterNo: optionalInt.pipe(z.number().int().positive('Chapter number is required')),
  title: requiredString,
  summary: optionalString,
  bookId: requiredString
});

const bookPageSchema = z.object({
  pageNumber: optionalInt.pipe(z.number().int().positive('Page number is required')),
  content: requiredString,
  imageUrl: optionalString,
  bookId: requiredString,
  chapterId: requiredString
});

const questionSchema = z.object({
  questionText: requiredString,
  answerText: optionalString,
  questionType: z.nativeEnum(QuestionType),
  difficultyLevel: z.nativeEnum(DifficultyLevel),
  importanceLevel: z.nativeEnum(ImportanceLevel),
  pageNumber: optionalInt,
  exerciseNo: optionalString,
  questionNo: optionalString,
  isBoardRepeated: z.boolean(),
  isTeacherRecommended: z.boolean(),
  sourceNote: optionalString,
  bookId: requiredString,
  chapterId: requiredString
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function formBoolean(formData: FormData, key: string) {
  return formData.get(key) === 'on';
}

function parseId(formData: FormData) {
  return z.string().min(1, 'Missing record id').parse(formString(formData, 'id'));
}

function friendlyError(error: unknown) {
  if (error instanceof z.ZodError) {
    return error.issues.map((issue) => issue.message).join(', ');
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2002') return 'A record with the same unique value already exists.';
    if (error.code === 'P2003') return 'The selected related record does not exist.';
    if (error.code === 'P2025') return 'The record was not found.';
  }

  return 'Something went wrong while saving. Please try again.';
}

async function runAdminAction(path: string, action: () => Promise<void>) {
  await requireAdmin();

  try {
    await action();
    revalidatePath(path);
    revalidatePath('/admin');
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function createClassLevel(formData: FormData) {
  const data = classSchema.parse({
    name: formString(formData, 'name'),
    orderNo: formString(formData, 'orderNo')
  });

  await runAdminAction('/admin/classes', async () => {
    await prisma.classLevel.create({ data });
  });
}

export async function updateClassLevel(formData: FormData) {
  const id = parseId(formData);
  const data = classSchema.parse({
    name: formString(formData, 'name'),
    orderNo: formString(formData, 'orderNo')
  });

  await runAdminAction('/admin/classes', async () => {
    await prisma.classLevel.update({ where: { id }, data });
  });
}

export async function deleteClassLevel(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/classes', async () => {
    await prisma.classLevel.delete({ where: { id } });
  });
}

export async function createSubject(formData: FormData) {
  const data = subjectSchema.parse({
    name: formString(formData, 'name'),
    classId: formString(formData, 'classId')
  });

  await runAdminAction('/admin/subjects', async () => {
    await prisma.subject.create({ data });
  });
}

export async function updateSubject(formData: FormData) {
  const id = parseId(formData);
  const data = subjectSchema.parse({
    name: formString(formData, 'name'),
    classId: formString(formData, 'classId')
  });

  await runAdminAction('/admin/subjects', async () => {
    await prisma.subject.update({ where: { id }, data });
  });
}

export async function deleteSubject(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/subjects', async () => {
    await prisma.subject.delete({ where: { id } });
  });
}

export async function createBook(formData: FormData) {
  const data = bookSchema.parse({
    title: formString(formData, 'title'),
    edition: formString(formData, 'edition'),
    publisher: formString(formData, 'publisher'),
    classId: formString(formData, 'classId'),
    subjectId: formString(formData, 'subjectId')
  });

  await runAdminAction('/admin/books', async () => {
    await prisma.book.create({ data });
  });
}

export async function updateBook(formData: FormData) {
  const id = parseId(formData);
  const data = bookSchema.parse({
    title: formString(formData, 'title'),
    edition: formString(formData, 'edition'),
    publisher: formString(formData, 'publisher'),
    classId: formString(formData, 'classId'),
    subjectId: formString(formData, 'subjectId')
  });

  await runAdminAction('/admin/books', async () => {
    await prisma.book.update({ where: { id }, data });
  });
}

export async function deleteBook(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/books', async () => {
    await prisma.book.delete({ where: { id } });
  });
}

export async function createChapter(formData: FormData) {
  const data = chapterSchema.parse({
    chapterNo: formString(formData, 'chapterNo'),
    title: formString(formData, 'title'),
    summary: formString(formData, 'summary'),
    bookId: formString(formData, 'bookId')
  });

  await runAdminAction('/admin/chapters', async () => {
    await prisma.chapter.create({ data });
  });
}

export async function updateChapter(formData: FormData) {
  const id = parseId(formData);
  const data = chapterSchema.parse({
    chapterNo: formString(formData, 'chapterNo'),
    title: formString(formData, 'title'),
    summary: formString(formData, 'summary'),
    bookId: formString(formData, 'bookId')
  });

  await runAdminAction('/admin/chapters', async () => {
    await prisma.chapter.update({ where: { id }, data });
  });
}

export async function deleteChapter(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/chapters', async () => {
    await prisma.chapter.delete({ where: { id } });
  });
}

export async function createBookPage(formData: FormData) {
  const data = bookPageSchema.parse({
    pageNumber: formString(formData, 'pageNumber'),
    content: formString(formData, 'content'),
    imageUrl: formString(formData, 'imageUrl'),
    bookId: formString(formData, 'bookId'),
    chapterId: formString(formData, 'chapterId')
  });

  await runAdminAction('/admin/book-pages', async () => {
    await prisma.bookPage.create({ data });
  });
}

export async function updateBookPage(formData: FormData) {
  const id = parseId(formData);
  const data = bookPageSchema.parse({
    pageNumber: formString(formData, 'pageNumber'),
    content: formString(formData, 'content'),
    imageUrl: formString(formData, 'imageUrl'),
    bookId: formString(formData, 'bookId'),
    chapterId: formString(formData, 'chapterId')
  });

  await runAdminAction('/admin/book-pages', async () => {
    await prisma.bookPage.update({ where: { id }, data });
  });
}

export async function deleteBookPage(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/book-pages', async () => {
    await prisma.bookPage.delete({ where: { id } });
  });
}

export async function createImportantQuestion(formData: FormData) {
  const data = questionSchema.parse({
    questionText: formString(formData, 'questionText'),
    answerText: formString(formData, 'answerText'),
    questionType: formString(formData, 'questionType'),
    difficultyLevel: formString(formData, 'difficultyLevel'),
    importanceLevel: formString(formData, 'importanceLevel'),
    pageNumber: formString(formData, 'pageNumber'),
    exerciseNo: formString(formData, 'exerciseNo'),
    questionNo: formString(formData, 'questionNo'),
    isBoardRepeated: formBoolean(formData, 'isBoardRepeated'),
    isTeacherRecommended: formBoolean(formData, 'isTeacherRecommended'),
    sourceNote: formString(formData, 'sourceNote'),
    bookId: formString(formData, 'bookId'),
    chapterId: formString(formData, 'chapterId')
  });

  await runAdminAction('/admin/questions', async () => {
    await prisma.importantQuestion.create({ data });
  });
}

export async function updateImportantQuestion(formData: FormData) {
  const id = parseId(formData);
  const data = questionSchema.parse({
    questionText: formString(formData, 'questionText'),
    answerText: formString(formData, 'answerText'),
    questionType: formString(formData, 'questionType'),
    difficultyLevel: formString(formData, 'difficultyLevel'),
    importanceLevel: formString(formData, 'importanceLevel'),
    pageNumber: formString(formData, 'pageNumber'),
    exerciseNo: formString(formData, 'exerciseNo'),
    questionNo: formString(formData, 'questionNo'),
    isBoardRepeated: formBoolean(formData, 'isBoardRepeated'),
    isTeacherRecommended: formBoolean(formData, 'isTeacherRecommended'),
    sourceNote: formString(formData, 'sourceNote'),
    bookId: formString(formData, 'bookId'),
    chapterId: formString(formData, 'chapterId')
  });

  await runAdminAction('/admin/questions', async () => {
    await prisma.importantQuestion.update({ where: { id }, data });
  });
}

export async function deleteImportantQuestion(formData: FormData) {
  const id = parseId(formData);
  await runAdminAction('/admin/questions', async () => {
    await prisma.importantQuestion.delete({ where: { id } });
  });
}
