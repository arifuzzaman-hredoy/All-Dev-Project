'use server';

import { Prisma } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

const optionalString = z.string().trim().transform((value) => value || null);
const schoolSchema = z.object({
  name: z.string().trim().min(1, 'School name is required'),
  logoUrl: optionalString,
  address: optionalString,
  phone: optionalString,
  email: z.string().trim().email('Enter a valid email').or(z.literal('')).transform((value) => value || null),
  website: optionalString,
  watermarkText: optionalString,
  defaultHeaderNote: optionalString,
  defaultFooterText: optionalString,
  defaultSignatureText: optionalString
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function parseId(formData: FormData) {
  return z.string().trim().min(1).parse(formString(formData, 'id'));
}

function schoolData(formData: FormData) {
  return schoolSchema.parse({
    name: formString(formData, 'name'),
    logoUrl: formString(formData, 'logoUrl'),
    address: formString(formData, 'address'),
    phone: formString(formData, 'phone'),
    email: formString(formData, 'email'),
    website: formString(formData, 'website'),
    watermarkText: formString(formData, 'watermarkText'),
    defaultHeaderNote: formString(formData, 'defaultHeaderNote'),
    defaultFooterText: formString(formData, 'defaultFooterText'),
    defaultSignatureText: formString(formData, 'defaultSignatureText')
  });
}

function friendlyError(error: unknown) {
  if (error instanceof z.ZodError) return error.issues.map((issue) => issue.message).join(', ');
  if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2025') return 'School was not found.';
  if (error instanceof Error) return error.message;
  return 'Something went wrong. Please try again.';
}

async function run(action: () => Promise<void>) {
  await requireAdmin();
  try {
    await action();
    revalidatePath('/admin/schools');
  } catch (error) {
    console.error('School admin action failed:', error);
    throw new Error(friendlyError(error));
  }
}

export async function createSchool(formData: FormData) {
  const data = schoolData(formData);
  await run(async () => {
    await prisma.school.create({ data });
  });
}

export async function updateSchool(formData: FormData) {
  const id = parseId(formData);
  const data = schoolData(formData);
  await run(async () => {
    await prisma.school.update({ where: { id }, data });
  });
}

export async function deleteSchool(formData: FormData) {
  const id = parseId(formData);
  await run(async () => {
    const userCount = await prisma.user.count({ where: { schoolId: id } });
    if (userCount > 0) throw new Error('Cannot delete a school with attached users.');
    await prisma.school.delete({ where: { id } });
  });
}
