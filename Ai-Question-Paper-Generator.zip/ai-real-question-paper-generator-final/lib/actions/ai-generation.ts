'use server';

import { DifficultyLevel, GenerationStatus, ImportanceLevel, PaperStatus, Prisma, QuestionType, SourceDocumentType, UsageAction } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { generateWithDeepSeek } from '@/lib/ai/deepseek';
import { parseAiQuestionPaperJson } from '@/lib/ai/parse-ai-json';
import { buildQuestionPaperPrompt } from '@/lib/ai/question-paper-prompt';
import { requirePaperAccess } from '@/lib/auth/access';
import { assertUsageAllowed, BillingError, recordUsage } from '@/lib/billing/subscription';
import { prisma } from '@/lib/prisma';

type PaperSettings = {
  contentMode?: string;
  pageFrom?: number | null;
  pageTo?: number | null;
  selectedQuestionTypes?: string[];
  difficultyLevel?: string;
  importanceLevel?: string;
  extraInstruction?: string;
  referenceInstruction?: string;
  useReferencePattern?: boolean;
  outputLanguage?: 'BANGLA' | 'ENGLISH' | 'AUTO' | string;
};

function asSettings(value: Prisma.JsonValue | null): PaperSettings {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return value as PaperSettings;
}

function isDifficultyLevel(value: string | undefined): value is DifficultyLevel {
  return !!value && Object.values(DifficultyLevel).includes(value as DifficultyLevel);
}

function isImportanceLevel(value: string | undefined): value is ImportanceLevel {
  return !!value && Object.values(ImportanceLevel).includes(value as ImportanceLevel);
}

function isQuestionType(value: string): value is QuestionType {
  return Object.values(QuestionType).includes(value as QuestionType);
}

function importantQuestionWhere(chapterId: string, importanceLevel: ImportanceLevel): Prisma.ImportantQuestionWhereInput {
  if (importanceLevel === ImportanceLevel.NORMAL) return { chapterId };

  return {
    chapterId,
    OR: [{ importanceLevel }, { isBoardRepeated: true }, { isTeacherRecommended: true }]
  };
}

function cleanErrorMessage(error: unknown) {
  if (error instanceof Error) {
    if (error.message.includes('API key')) return error.message;
    if (error.message.includes('invalid JSON')) return error.message;
    if (error.message.includes('empty response')) return error.message;
  }

  return 'AI generation failed. Please check your AI settings and try again.';
}

function normalizeMarks(value: number | null | undefined) {
  if (!value || !Number.isFinite(value)) return null;
  return Math.max(1, Math.round(value));
}

function limitText(text: string | null | undefined, maxLength: number) {
  if (!text) return '';
  return text.length > maxLength ? `${text.slice(0, maxLength)}...` : text;
}

export async function generateQuestionPaperWithAI(paperId: string) {
  const { user } = await requirePaperAccess(paperId);
  const model = process.env.DEEPSEEK_MODEL || 'deepseek-chat';
  let redirectUrl = `/dashboard/papers/${paperId}`;

  try {
    await assertUsageAllowed(user.id, UsageAction.AI_GENERATE_PAPER);
  } catch (error) {
    if (error instanceof BillingError) redirect(`/dashboard/papers/${paperId}?error=plan_limit_reached`);
    throw error;
  }

  const paper = await prisma.questionPaper.findUnique({
    where: { id: paperId },
    include: {
      user: true,
      classLevel: true,
      subject: true,
      book: true,
      chapter: true,
      sourceDocuments: {
        where: { type: { in: [SourceDocumentType.PREVIOUS_QUESTION, SourceDocumentType.REFERENCE_NOTE] } },
        orderBy: { createdAt: 'desc' }
      }
    }
  });

  if (!paper) throw new Error('Question paper not found.');
  if (!paper.chapterId || !paper.classLevel || !paper.subject || !paper.book || !paper.chapter) {
    await prisma.generationLog.create({
      data: {
        provider: 'deepseek',
        model,
        status: GenerationStatus.FAILED,
        userId: paper.userId,
        paperId,
        errorMessage: 'Question paper is missing academic source information.'
      }
    });
    revalidatePath(`/dashboard/papers/${paperId}`);
    redirect(`/dashboard/papers/${paperId}?error=ai_generation_failed`);
  }

  const settings = asSettings(paper.settings);
  const difficultyLevel = isDifficultyLevel(settings.difficultyLevel) ? settings.difficultyLevel : DifficultyLevel.MEDIUM;
  const importanceLevel = isImportanceLevel(settings.importanceLevel) ? settings.importanceLevel : ImportanceLevel.NORMAL;
  const selectedQuestionTypes = (settings.selectedQuestionTypes ?? []).filter(isQuestionType);

  try {
    const pageWhere: Prisma.BookPageWhereInput =
      settings.contentMode === 'PAGE_RANGE'
        ? {
            chapterId: paper.chapterId,
            pageNumber: {
              gte: settings.pageFrom ?? undefined,
              lte: settings.pageTo ?? undefined
            }
          }
        : { chapterId: paper.chapterId };

    const [pages, importantQuestions] = await Promise.all([
      prisma.bookPage.findMany({
        where: pageWhere,
        orderBy: { pageNumber: 'asc' }
      }),
      prisma.importantQuestion.findMany({
        where: importantQuestionWhere(paper.chapterId, importanceLevel),
        orderBy: [{ isBoardRepeated: 'desc' }, { isTeacherRecommended: 'desc' }, { pageNumber: 'asc' }]
      })
    ]);

    const messages = buildQuestionPaperPrompt({
      paperTitle: paper.title,
      className: paper.classLevel.name,
      subjectName: paper.subject.name,
      bookTitle: paper.book.title,
      chapterTitle: `Chapter ${paper.chapter.chapterNo}: ${paper.chapter.title}`,
      totalMarks: paper.totalMarks,
      durationMinutes: paper.durationMinutes,
      selectedQuestionTypes,
      difficultyLevel,
      importanceLevel,
      extraInstruction: settings.extraInstruction,
      outputLanguage: settings.outputLanguage ?? 'BANGLA',
      referenceInstruction: settings.referenceInstruction,
      useReferencePattern: Boolean(settings.useReferencePattern),
      bookPageContents: pages.map((page) => ({
        pageNumber: page.pageNumber,
        content: limitText(page.content, 6000)
      })),
      importantQuestions: importantQuestions.map((question) => ({
        questionText: question.questionText,
        answerText: question.answerText,
        questionType: question.questionType,
        difficultyLevel: question.difficultyLevel,
        importanceLevel: question.importanceLevel,
        pageNumber: question.pageNumber,
        exerciseNo: question.exerciseNo,
        questionNo: question.questionNo,
        isBoardRepeated: question.isBoardRepeated,
        isTeacherRecommended: question.isTeacherRecommended,
        sourceNote: question.sourceNote
      })),
      referenceDocuments: paper.sourceDocuments
        .filter((document) => document.extractedText)
        .map((document) => ({
          title: document.title,
          type: document.type,
          text: limitText(document.extractedText, 4000)
        }))
    });

    const rawResponse = await generateWithDeepSeek(messages, { maxTokens: 5000, temperature: 0.2 });
    const parsed = parseAiQuestionPaperJson(rawResponse);

    const generatedRows = parsed.sections.flatMap((section, sectionIndex) =>
      section.questions.map((question, questionIndex) => ({
        sectionTitle: section.sectionTitle,
        questionText: question.questionText,
        options: question.options,
        correctAnswer: question.correctAnswer ?? null,
        answerText: question.answerText ?? null,
        explanation: question.explanation ?? question.sourceReference ?? null,
        questionType: section.questionType,
        difficultyLevel: question.difficultyLevel ?? difficultyLevel,
        importanceLevel: question.importanceLevel ?? importanceLevel,
        marks: normalizeMarks(question.marks),
        orderIndex: sectionIndex * 1000 + questionIndex,
        paperId
      }))
    );

    await prisma.$transaction([
      prisma.generatedQuestion.deleteMany({ where: { paperId } }),
      ...(generatedRows.length > 0 ? [prisma.generatedQuestion.createMany({ data: generatedRows })] : []),
      prisma.questionPaper.update({
        where: { id: paperId },
        data: {
          status: PaperStatus.GENERATED,
          generatedJson: parsed
        }
      }),
      prisma.generationLog.create({
        data: {
          provider: 'deepseek',
          model,
          status: GenerationStatus.SUCCESS,
          userId: paper.userId,
          paperId
        }
      })
    ]);
    await recordUsage(user.id, UsageAction.AI_GENERATE_PAPER, paperId);

  } catch (error) {
    const message = cleanErrorMessage(error);

    await prisma.generationLog.create({
      data: {
        provider: 'deepseek',
        model,
        status: GenerationStatus.FAILED,
        userId: paper.userId,
        paperId,
        errorMessage: message
      }
    });

    revalidatePath(`/dashboard/papers/${paperId}`);
    redirectUrl = `/dashboard/papers/${paperId}?error=ai_generation_failed`;
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  revalidatePath('/dashboard');
  revalidatePath('/dashboard/papers');
  revalidatePath('/dashboard/billing');
  redirect(redirectUrl);
}
