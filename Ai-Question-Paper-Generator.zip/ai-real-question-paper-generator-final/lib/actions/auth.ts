'use server';

import { Role } from '@prisma/client';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { hashPassword, verifyPassword } from '@/lib/auth/password';
import { createSession, destroySession, isAdminRole } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

const registerSchema = z
  .object({
    name: z.string().trim().min(1, 'Name is required'),
    email: z.string().trim().email('Enter a valid email address').transform((value) => value.toLowerCase()),
    password: z.string().min(6, 'Password must be at least 6 characters'),
    confirmPassword: z.string().min(6, 'Confirm password must be at least 6 characters')
  })
  .refine((data) => data.password === data.confirmPassword, {
    path: ['confirmPassword'],
    message: 'Passwords do not match'
  });

const loginSchema = z.object({
  email: z.string().trim().email('Enter a valid email address').transform((value) => value.toLowerCase()),
  password: z.string().min(1, 'Password is required')
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function roleHome(role: Role) {
  return isAdminRole(role) ? '/admin' : '/dashboard';
}

export async function registerUser(formData: FormData) {
  let redirectTo = '/register?error=unknown';

  try {
    const data = registerSchema.parse({
      name: formString(formData, 'name'),
      email: formString(formData, 'email'),
      password: formString(formData, 'password'),
      confirmPassword: formString(formData, 'confirmPassword')
    });

    const existingUser = await prisma.user.findUnique({ where: { email: data.email } });
    if (existingUser) {
      redirectTo = '/register?error=email_exists';
    } else {
      const userCount = await prisma.user.count();
      const role = userCount === 0 ? Role.SUPER_ADMIN : Role.TEACHER;
      const passwordHash = await hashPassword(data.password);

      const user = await prisma.user.create({
        data: {
          name: data.name,
          email: data.email,
          passwordHash,
          role
        }
      });

      createSession(user.id);
      redirectTo = roleHome(user.role);
    }
  } catch (error) {
    console.error('Register user failed:', error);
    redirectTo = error instanceof z.ZodError && error.issues.some((issue) => issue.path.includes('confirmPassword'))
      ? '/register?error=password_mismatch'
      : '/register?error=invalid_input';
  }

  redirect(redirectTo);
}

export async function loginUser(formData: FormData) {
  let redirectTo = '/login?error=unknown';

  try {
    const data = loginSchema.parse({
      email: formString(formData, 'email'),
      password: formString(formData, 'password')
    });

    const user = await prisma.user.findUnique({ where: { email: data.email } });
    if (!user) {
      redirectTo = '/login?error=invalid_credentials';
    } else if (!user.passwordHash) {
      redirectTo = '/login?error=password_not_set';
    } else {
      const isValidPassword = await verifyPassword(data.password, user.passwordHash);
      if (!isValidPassword) {
        redirectTo = '/login?error=invalid_credentials';
      } else {
        createSession(user.id);
        redirectTo = roleHome(user.role);
      }
    }
  } catch (error) {
    console.error('Login user failed:', error);
    redirectTo = '/login?error=invalid_credentials';
  }

  redirect(redirectTo);
}

export async function logoutUser() {
  destroySession();
  redirect('/login');
}
