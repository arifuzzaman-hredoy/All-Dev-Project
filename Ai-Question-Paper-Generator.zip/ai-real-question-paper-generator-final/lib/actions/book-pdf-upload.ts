'use server';

import { ExtractionStatus, SourceDocumentType } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth/session';
import { extractTextFromUploadedBuffer } from '@/lib/files/extract-uploaded-text';
import { saveUploadedFile } from '@/lib/files/storage';
import { prisma } from '@/lib/prisma';

const uploadSchema = z.object({
  classId: z.string().trim().min(1, 'Class is required'),
  subjectId: z.string().trim().min(1, 'Subject is required'),
  bookId: z.string().trim().min(1, 'Book is required'),
  chapterId: z.string().trim().min(1, 'Chapter is required'),
  startPageNumber: z
    .string()
    .trim()
    .transform((value) => Number(value))
    .pipe(z.number().int().positive('Start page number is required')),
  importMode: z.enum(['CREATE_BOOK_PAGES', 'STORE_ONLY']),
  title: z.string().trim().max(200).optional().default('')
});

const updateSourceDocumentSchema = z.object({
  documentId: z.string().trim().min(1, 'Source document is required'),
  title: z.string().trim().min(1, 'Title is required').max(200),
  classId: z.string().trim().min(1, 'Class is required'),
  subjectId: z.string().trim().min(1, 'Subject is required'),
  bookId: z.string().trim().min(1, 'Book is required'),
  chapterId: z.string().trim().min(1, 'Chapter is required')
});

const deleteSourceDocumentSchema = z.object({
  documentId: z.string().trim().min(1, 'Source document is required')
});

const importSourceDocumentSchema = z.object({
  documentId: z.string().trim().min(1, 'Source document is required'),
  startPageNumber: z
    .string()
    .trim()
    .transform((value) => Number(value))
    .pipe(z.number().int().positive('Start page number is required'))
});

type ExtractedPage = {
  pageNumber: number;
  text: string;
};

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function friendlyError(error: unknown) {
  if (error instanceof z.ZodError) return error.issues.map((issue) => issue.message).join(', ');
  if (error instanceof Error) return error.message;
  return 'Something went wrong. Please try again.';
}

function safeRedirectParam(message: string) {
  return encodeURIComponent(message);
}

function normalizePages(value: unknown): ExtractedPage[] {
  if (!Array.isArray(value)) return [];

  return value
    .map((item, index) => {
      if (!item || typeof item !== 'object') return null;
      const record = item as { pageNumber?: unknown; text?: unknown };
      const text = typeof record.text === 'string' ? record.text.trim() : '';
      if (!text) return null;
      const pageNumber = typeof record.pageNumber === 'number' && Number.isFinite(record.pageNumber) ? record.pageNumber : index + 1;
      return { pageNumber, text };
    })
    .filter((page): page is ExtractedPage => Boolean(page));
}

async function importPagesToBook(data: {
  bookId: string;
  chapterId: string;
  startPageNumber: number;
  pages: ExtractedPage[];
}) {
  if (data.pages.length === 0) return;

  await prisma.$transaction(
    data.pages.map((page, index) =>
      prisma.bookPage.upsert({
        where: {
          bookId_pageNumber: {
            bookId: data.bookId,
            pageNumber: data.startPageNumber + index
          }
        },
        update: {
          content: page.text,
          chapterId: data.chapterId
        },
        create: {
          pageNumber: data.startPageNumber + index,
          content: page.text,
          bookId: data.bookId,
          chapterId: data.chapterId
        }
      })
    )
  );
}

export async function uploadBookPdf(formData: FormData) {
  const user = await requireAdmin();
  let redirectUrl = '/admin/book-upload?success=uploaded';

  try {
    const data = uploadSchema.parse({
      classId: formString(formData, 'classId'),
      subjectId: formString(formData, 'subjectId'),
      bookId: formString(formData, 'bookId'),
      chapterId: formString(formData, 'chapterId'),
      startPageNumber: formString(formData, 'startPageNumber'),
      importMode: formString(formData, 'importMode'),
      title: formString(formData, 'title')
    });

    const file = formData.get('bookFile') ?? formData.get('pdfFile');

    if (!(file instanceof File) || file.size === 0) {
      throw new Error('Please upload a valid book source file.');
    }

    const saved = await saveUploadedFile(file, 'book-sources');
    let extractedText = '';
    let extractedPages: ExtractedPage[] = [];
    let extractionStatus: ExtractionStatus = ExtractionStatus.PENDING;
    let errorMessage: string | null = null;

    try {
      const extracted = await extractTextFromUploadedBuffer(saved.buffer, saved.originalFileName, saved.mimeType);
      extractedText = extracted.fullText;
      extractedPages = extracted.pages;
      extractionStatus = extracted.status === 'SUCCESS' ? ExtractionStatus.SUCCESS : ExtractionStatus.SCANNED_OR_EMPTY;

      if (extractionStatus === ExtractionStatus.SCANNED_OR_EMPTY) {
        errorMessage = 'This PDF/file looks scanned, image-based, font-encoded, or empty. Upload an HTML/DOCX/TXT version or add OCR later.';
        redirectUrl = `/admin/book-upload?warning=${safeRedirectParam(errorMessage)}`;
      }
    } catch (error) {
      extractionStatus = ExtractionStatus.FAILED;
      errorMessage = friendlyError(error);
      redirectUrl = `/admin/book-upload?error=${safeRedirectParam(errorMessage)}`;
    }

    const sourceDocument = await prisma.sourceDocument.create({
      data: {
        type: SourceDocumentType.BOOK_PDF,
        title: data.title || saved.originalFileName,
        originalFileName: saved.originalFileName,
        storedFilePath: saved.filePath,
        mimeType: saved.mimeType,
        sizeBytes: saved.sizeBytes,
        extractedText: extractedText || null,
        extractedPages,
        extractionStatus,
        errorMessage,
        userId: user.id,
        schoolId: user.schoolId,
        classId: data.classId,
        subjectId: data.subjectId,
        bookId: data.bookId,
        chapterId: data.chapterId
      }
    });

    if (data.importMode === 'CREATE_BOOK_PAGES' && extractionStatus === ExtractionStatus.SUCCESS) {
      await importPagesToBook({
        bookId: data.bookId,
        chapterId: data.chapterId,
        startPageNumber: data.startPageNumber,
        pages: extractedPages
      });
      redirectUrl = `/admin/book-upload?success=${safeRedirectParam(`File uploaded and ${extractedPages.length} page(s) imported successfully.`)}`;
    } else if (data.importMode === 'STORE_ONLY' && extractionStatus === ExtractionStatus.SUCCESS) {
      redirectUrl = `/admin/book-upload?success=${safeRedirectParam(`File uploaded and stored successfully. Extracted ${extractedPages.length} page(s).`)}`;
    }

    if (sourceDocument.extractionStatus === ExtractionStatus.FAILED && errorMessage) {
      redirectUrl = `/admin/book-upload?error=${safeRedirectParam(errorMessage)}`;
    }

    revalidatePath('/admin/book-upload');
    revalidatePath('/admin/book-pages');
  } catch (error) {
    console.error('Book file upload failed:', error);
    redirectUrl = `/admin/book-upload?error=${safeRedirectParam(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}

export async function updateSourceDocument(formData: FormData) {
  await requireAdmin();
  let redirectUrl = '/admin/book-upload?success=metadata_updated';

  try {
    const data = updateSourceDocumentSchema.parse({
      documentId: formString(formData, 'documentId'),
      title: formString(formData, 'title'),
      classId: formString(formData, 'classId'),
      subjectId: formString(formData, 'subjectId'),
      bookId: formString(formData, 'bookId'),
      chapterId: formString(formData, 'chapterId')
    });

    await prisma.sourceDocument.update({
      where: { id: data.documentId },
      data: {
        title: data.title,
        classId: data.classId,
        subjectId: data.subjectId,
        bookId: data.bookId,
        chapterId: data.chapterId
      }
    });

    revalidatePath('/admin/book-upload');
  } catch (error) {
    console.error('Update source document failed:', error);
    redirectUrl = `/admin/book-upload?error=${safeRedirectParam(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}

export async function deleteSourceDocument(formData: FormData) {
  await requireAdmin();
  let redirectUrl = '/admin/book-upload?success=deleted';

  try {
    const data = deleteSourceDocumentSchema.parse({
      documentId: formString(formData, 'documentId')
    });

    await prisma.sourceDocument.delete({ where: { id: data.documentId } });
    revalidatePath('/admin/book-upload');
  } catch (error) {
    console.error('Delete source document failed:', error);
    redirectUrl = `/admin/book-upload?error=${safeRedirectParam(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}

export async function importSourceDocumentPages(formData: FormData) {
  await requireAdmin();
  let redirectUrl = '/admin/book-upload?success=imported';

  try {
    const data = importSourceDocumentSchema.parse({
      documentId: formString(formData, 'documentId'),
      startPageNumber: formString(formData, 'startPageNumber')
    });

    const document = await prisma.sourceDocument.findUnique({ where: { id: data.documentId } });

    if (!document) throw new Error('Source document not found.');
    if (!document.bookId || !document.chapterId) throw new Error('Source document must be linked to a book and chapter before import.');
    if (document.extractionStatus !== ExtractionStatus.SUCCESS) throw new Error('Only successfully extracted files can be imported.');

    const pages = normalizePages(document.extractedPages);
    if (pages.length === 0) throw new Error('No extracted pages found for this source document.');

    await importPagesToBook({
      bookId: document.bookId,
      chapterId: document.chapterId,
      startPageNumber: data.startPageNumber,
      pages
    });

    redirectUrl = `/admin/book-upload?success=${safeRedirectParam(`${pages.length} page(s) imported into Book Pages.`)}`;
    revalidatePath('/admin/book-upload');
    revalidatePath('/admin/book-pages');
  } catch (error) {
    console.error('Import source document pages failed:', error);
    redirectUrl = `/admin/book-upload?error=${safeRedirectParam(friendlyError(error))}`;
  }

  redirect(redirectUrl);
}
