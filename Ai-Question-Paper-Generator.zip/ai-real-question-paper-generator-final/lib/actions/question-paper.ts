'use server';

import { DifficultyLevel, ExtractionStatus, ImportanceLevel, PaperStatus, PaperTemplateStyle, Prisma, QuestionType, SourceDocumentType, UsageAction } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { requireUser } from '@/lib/auth/session';
import { assertFeatureAllowed, assertUsageAllowed, BillingError, getUserSubscriptionOrFree, recordUsage } from '@/lib/billing/subscription';
import { extractTextFromUploadedBuffer } from '@/lib/files/extract-uploaded-text';
import { saveUploadedFile } from '@/lib/files/storage';
import { prisma } from '@/lib/prisma';

const contentModes = ['FULL_CHAPTER', 'PAGE_RANGE', 'IMPORTANT_QUESTIONS_ONLY'] as const;

const optionalPositiveInt = z
  .string()
  .trim()
  .transform((value) => (value === '' ? null : Number(value)))
  .pipe(z.number().int().positive().nullable());

const draftPaperSchema = z
  .object({
    classId: z.string().trim().min(1, 'Class is required'),
    subjectId: z.string().trim().min(1, 'Subject is required'),
    bookId: z.string().trim().min(1, 'Book is required'),
    chapterId: z.string().trim().min(1, 'Chapter is required'),
    contentMode: z.enum(contentModes),
    pageFrom: optionalPositiveInt,
    pageTo: optionalPositiveInt,
    totalMarks: optionalPositiveInt,
    durationMinutes: optionalPositiveInt,
    selectedQuestionTypes: z.array(z.nativeEnum(QuestionType)).min(1, 'Select at least one question type'),
    difficultyLevel: z.nativeEnum(DifficultyLevel),
    importanceLevel: z.nativeEnum(ImportanceLevel),
    examTitle: z.string().trim().max(300).optional().default(''),
    headerNote: z.string().trim().max(1000).optional().default(''),
    footerText: z.string().trim().max(1000).optional().default(''),
    watermarkText: z.string().trim().max(300).optional().default(''),
    teacherName: z.string().trim().max(200).optional().default(''),
    signatureText: z.string().trim().max(300).optional().default(''),
    templateStyle: z.nativeEnum(PaperTemplateStyle),
    outputLanguage: z.enum(['BANGLA', 'ENGLISH', 'AUTO']).default('BANGLA'),
    referenceTitle: z.string().trim().max(200).optional().default(''),
    referenceType: z.nativeEnum(SourceDocumentType).optional().default(SourceDocumentType.PREVIOUS_QUESTION),
    referenceInstruction: z.string().trim().max(2000).optional().default(''),
    useReferencePattern: z.boolean().optional().default(false),
    extraInstruction: z.string().trim().max(3000).optional().default('')
  })
  .superRefine((data, ctx) => {
    if (data.contentMode !== 'PAGE_RANGE') return;

    if (!data.pageFrom) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['pageFrom'], message: 'Page from is required' });
    }

    if (!data.pageTo) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['pageTo'], message: 'Page to is required' });
    }

    if (data.pageFrom && data.pageTo && data.pageTo < data.pageFrom) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['pageTo'],
        message: 'Page to must be greater than or equal to page from'
      });
    }
  });

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function friendlyActionError(error: unknown) {
  if (error instanceof z.ZodError) {
    return error.issues.map((issue) => issue.message).join(', ');
  }

  if (error instanceof Error && error.name === 'CleanActionError') {
    return error.message;
  }

  if (error instanceof BillingError) {
    return error.message;
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P1001') return 'Database connection is unavailable. Please check the tunnel and try again.';
    if (error.code === 'P2003') return 'One of the selected academic records does not exist.';
    if (error.code === 'P2025') return 'The selected content was not found.';
  }

  if (error instanceof Prisma.PrismaClientInitializationError) {
    return 'Database connection is unavailable. Please check the tunnel and try again.';
  }

  return 'Could not create draft paper. Please check the form and try again.';
}

function contentPreview(content: string) {
  return content.length > 360 ? `${content.slice(0, 360)}...` : content;
}

function referencePreview(content: string) {
  return content.length > 1000 ? `${content.slice(0, 1000)}...` : content;
}

function cleanActionError(message: string) {
  const error = new Error(message);
  error.name = 'CleanActionError';
  return error;
}

function importantQuestionWhere(chapterId: string, importanceLevel: ImportanceLevel): Prisma.ImportantQuestionWhereInput {
  if (importanceLevel === ImportanceLevel.NORMAL) {
    return { chapterId };
  }

  return {
    chapterId,
    OR: [{ importanceLevel }, { isBoardRepeated: true }, { isTeacherRecommended: true }]
  };
}

export async function createDraftQuestionPaper(formData: FormData) {
  const currentUser = await requireUser();
  let paperId: string | null = null;

  try {
    const data = draftPaperSchema.parse({
      classId: formString(formData, 'classId'),
      subjectId: formString(formData, 'subjectId'),
      bookId: formString(formData, 'bookId'),
      chapterId: formString(formData, 'chapterId'),
      contentMode: formString(formData, 'contentMode'),
      pageFrom: formString(formData, 'pageFrom'),
      pageTo: formString(formData, 'pageTo'),
      totalMarks: formString(formData, 'totalMarks'),
      durationMinutes: formString(formData, 'durationMinutes'),
      selectedQuestionTypes: formData.getAll('selectedQuestionTypes').map(String),
      difficultyLevel: formString(formData, 'difficultyLevel'),
      importanceLevel: formString(formData, 'importanceLevel'),
      examTitle: formString(formData, 'examTitle'),
      headerNote: formString(formData, 'headerNote'),
      footerText: formString(formData, 'footerText'),
      watermarkText: formString(formData, 'watermarkText'),
      teacherName: formString(formData, 'teacherName'),
      signatureText: formString(formData, 'signatureText'),
      templateStyle: formString(formData, 'templateStyle') || PaperTemplateStyle.CLASSIC,
      outputLanguage: formString(formData, 'outputLanguage') || 'BANGLA',
      referenceTitle: formString(formData, 'referenceTitle'),
      referenceType: formString(formData, 'referenceType') || SourceDocumentType.PREVIOUS_QUESTION,
      referenceInstruction: formString(formData, 'referenceInstruction'),
      useReferencePattern: formData.get('useReferencePattern') === 'on',
      extraInstruction: formString(formData, 'extraInstruction')
    });
    const referenceFile = formData.get('referenceFile') ?? formData.get('referencePdf');
    const subscription = await getUserSubscriptionOrFree(currentUser.id);

    await assertUsageAllowed(currentUser.id, UsageAction.CREATE_DRAFT_PAPER);

    if (data.contentMode === 'IMPORTANT_QUESTIONS_ONLY') {
      await assertFeatureAllowed(currentUser.id, 'importantQuestions');
    }

    if (
      data.contentMode === 'PAGE_RANGE' &&
      data.pageFrom &&
      data.pageTo &&
      data.pageTo - data.pageFrom + 1 > subscription.plan.maxPagesPerPaper
    ) {
      throw cleanActionError(`Your plan allows maximum ${subscription.plan.maxPagesPerPaper} pages per paper.`);
    }

    const [classLevel, subject, book, chapter] = await Promise.all([
      prisma.classLevel.findUniqueOrThrow({ where: { id: data.classId } }),
      prisma.subject.findUniqueOrThrow({ where: { id: data.subjectId } }),
      prisma.book.findUniqueOrThrow({ where: { id: data.bookId } }),
      prisma.chapter.findUniqueOrThrow({ where: { id: data.chapterId } })
    ]);

    if (subject.classId !== classLevel.id) {
      throw cleanActionError('Selected subject does not belong to the selected class.');
    }

    if (book.classId !== classLevel.id || book.subjectId !== subject.id) {
      throw cleanActionError('Selected book does not belong to the selected class and subject.');
    }

    if (chapter.bookId !== book.id) {
      throw cleanActionError('Selected chapter does not belong to the selected book.');
    }

    const pageWhere: Prisma.BookPageWhereInput =
      data.contentMode === 'PAGE_RANGE'
        ? {
            chapterId: data.chapterId,
            pageNumber: { gte: data.pageFrom ?? undefined, lte: data.pageTo ?? undefined }
          }
        : { chapterId: data.chapterId };

    const [pages, importantQuestions] = await Promise.all([
      data.contentMode === 'IMPORTANT_QUESTIONS_ONLY'
        ? Promise.resolve([])
        : prisma.bookPage.findMany({
            where: pageWhere,
            orderBy: { pageNumber: 'asc' }
          }),
      prisma.importantQuestion.findMany({
        where: importantQuestionWhere(data.chapterId, data.importanceLevel),
        orderBy: [{ isBoardRepeated: 'desc' }, { isTeacherRecommended: 'desc' }, { pageNumber: 'asc' }]
      })
    ]);

    const title = `${classLevel.name} ${subject.name} Draft Paper - ${chapter.title}`;

    const settings = {
      contentMode: data.contentMode,
      pageFrom: data.pageFrom,
      pageTo: data.pageTo,
      selectedQuestionTypes: data.selectedQuestionTypes,
      difficultyLevel: data.difficultyLevel,
      importanceLevel: data.importanceLevel,
      examTitle: data.examTitle,
      headerNote: data.headerNote,
      footerText: data.footerText,
      watermarkText: data.watermarkText,
      teacherName: data.teacherName,
      signatureText: data.signatureText,
      templateStyle: data.templateStyle,
      outputLanguage: data.outputLanguage,
      referenceTitle: data.referenceTitle,
      referenceInstruction: data.referenceInstruction,
      useReferencePattern: data.useReferencePattern,
      extraInstruction: data.extraInstruction,
      retrievedPageCount: pages.length,
      retrievedImportantQuestionCount: importantQuestions.length,
      retrievedContentPreview: pages.slice(0, 5).map((page) => ({
        pageNumber: page.pageNumber,
        content: contentPreview(page.content)
      })),
      retrievedImportantQuestionsPreview: importantQuestions.slice(0, 8).map((question) => ({
        questionText: question.questionText,
        answerText: question.answerText,
        questionType: question.questionType,
        difficultyLevel: question.difficultyLevel,
        importanceLevel: question.importanceLevel,
        pageNumber: question.pageNumber,
        exerciseNo: question.exerciseNo,
        questionNo: question.questionNo,
        isBoardRepeated: question.isBoardRepeated,
        isTeacherRecommended: question.isTeacherRecommended
      })),
      sourceBook: book.title
    };

    const paper = await prisma.questionPaper.create({
      data: {
        title,
        totalMarks: data.totalMarks,
        durationMinutes: data.durationMinutes,
        status: PaperStatus.DRAFT,
        userId: currentUser.id,
        schoolId: currentUser.schoolId,
        classId: data.classId,
        subjectId: data.subjectId,
        bookId: data.bookId,
        chapterId: data.chapterId,
        examTitle: data.examTitle || null,
        headerNote: data.headerNote || null,
        footerText: data.footerText || null,
        watermarkText: data.watermarkText || null,
        teacherName: data.teacherName || null,
        signatureText: data.signatureText || null,
        templateStyle: data.templateStyle,
        settings
      }
    });

    paperId = paper.id;

    if (referenceFile instanceof File && referenceFile.size > 0) {
      let extractedText = '';
      let extractedPages: { pageNumber: number; text: string }[] = [];
      let extractionStatus: ExtractionStatus = ExtractionStatus.PENDING;
      let errorMessage: string | null = null;
      let saved: Awaited<ReturnType<typeof saveUploadedFile>> | null = null;

      try {
        saved = await saveUploadedFile(referenceFile, 'paper-references');
        const extracted = await extractTextFromUploadedBuffer(saved.buffer, saved.originalFileName, saved.mimeType);
        extractedText = extracted.fullText;
        extractedPages = extracted.pages;
        extractionStatus = extracted.status === 'SUCCESS' ? ExtractionStatus.SUCCESS : ExtractionStatus.SCANNED_OR_EMPTY;
        if (extractionStatus === ExtractionStatus.SCANNED_OR_EMPTY) {
          errorMessage = 'This file looks scanned/image-based or empty. OCR support will be added later.';
        }
      } catch (error) {
        extractionStatus = ExtractionStatus.FAILED;
        errorMessage = error instanceof Error ? error.message : 'Could not extract text from reference file.';
      }

      if (saved) {
        const sourceDocument = await prisma.sourceDocument.create({
          data: {
            type: data.referenceType,
            title: data.referenceTitle || saved.originalFileName,
            originalFileName: saved.originalFileName,
            storedFilePath: saved.filePath,
            mimeType: saved.mimeType,
            sizeBytes: saved.sizeBytes,
            extractedText: extractedText || null,
            extractedPages,
            extractionStatus,
            errorMessage,
            userId: currentUser.id,
            schoolId: currentUser.schoolId,
            classId: data.classId,
            subjectId: data.subjectId,
            bookId: data.bookId,
            chapterId: data.chapterId,
            paperId: paper.id
          }
        });

        await prisma.questionPaper.update({
          where: { id: paper.id },
          data: {
            settings: {
              ...settings,
              referenceDocumentId: sourceDocument.id,
              referenceTitle: sourceDocument.title,
              referenceInstruction: data.referenceInstruction,
              useReferencePattern: data.useReferencePattern,
              referenceExtractionStatus: extractionStatus,
              referenceTextPreview: extractedText ? referencePreview(extractedText) : null
            }
          }
        });
      }
    }

    await recordUsage(currentUser.id, UsageAction.CREATE_DRAFT_PAPER, paper.id);
  } catch (error) {
    console.error('Create draft paper failed:', error);
    const message = friendlyActionError(error);
    redirect(`/dashboard/create-paper?error=${encodeURIComponent(message)}`);
  }

  if (!paperId) {
    redirect(`/dashboard/create-paper?error=${encodeURIComponent('Draft paper was not created.')}`);
  }

  revalidatePath('/dashboard/papers');
  revalidatePath('/dashboard/billing');
  redirect(`/dashboard/papers/${paperId}?success=draft_created`);
}
