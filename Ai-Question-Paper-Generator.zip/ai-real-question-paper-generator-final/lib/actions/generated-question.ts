'use server';

import { DifficultyLevel, GenerationStatus, ImportanceLevel, PaperStatus, Prisma, QuestionType, UsageAction } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { generateWithDeepSeek } from '@/lib/ai/deepseek';
import { parseSingleQuestionJson } from '@/lib/ai/parse-single-question-json';
import { buildSingleQuestionRegenerationPrompt } from '@/lib/ai/single-question-prompt';
import { requirePaperAccess } from '@/lib/auth/access';
import { assertUsageAllowed, BillingError, recordUsage } from '@/lib/billing/subscription';
import { prisma } from '@/lib/prisma';

type PaperSettings = {
  contentMode?: string;
  pageFrom?: number | null;
  pageTo?: number | null;
  difficultyLevel?: string;
  importanceLevel?: string;
};

const optionalString = z.string().trim().transform((value) => value || null);
const optionalPositiveInt = z
  .string()
  .trim()
  .transform((value) => (value === '' ? null : Number(value)))
  .pipe(z.number().int().positive().nullable());

const generatedQuestionSchema = z.object({
  questionId: z.preprocess(
    (value) => {
      const trimmed = String(value ?? '').trim();
      return trimmed || undefined;
    },
    z.string().min(1).optional()
  ),
  paperId: z.string().trim().min(1, 'Paper is required'),
  sectionTitle: optionalString,
  questionText: z.string().trim().min(1, 'Question text is required'),
  optionsText: z.string().optional().default(''),
  correctAnswer: optionalString,
  answerText: optionalString,
  explanation: optionalString,
  questionType: z.nativeEnum(QuestionType),
  difficultyLevel: z.nativeEnum(DifficultyLevel),
  importanceLevel: z.nativeEnum(ImportanceLevel),
  marks: optionalPositiveInt
});

const idSchema = z.object({
  questionId: z.string().trim().min(1, 'Question is required'),
  paperId: z.string().trim().min(1, 'Paper is required')
});

const moveSchema = idSchema.extend({
  direction: z.enum(['UP', 'DOWN'])
});

const regenerateSchema = idSchema.extend({
  instruction: z.string().trim().max(2000).optional().default('')
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function parseOptions(optionsText: string) {
  return optionsText
    .split(/\r?\n/)
    .map((option) => option.trim())
    .filter(Boolean);
}

function asSettings(value: Prisma.JsonValue | null): PaperSettings {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return value as PaperSettings;
}

function isDifficultyLevel(value: string | undefined): value is DifficultyLevel {
  return !!value && Object.values(DifficultyLevel).includes(value as DifficultyLevel);
}

function isImportanceLevel(value: string | undefined): value is ImportanceLevel {
  return !!value && Object.values(ImportanceLevel).includes(value as ImportanceLevel);
}

function optionsList(value: Prisma.JsonValue | null) {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}

function paperPath(paperId: string, query: string) {
  return `/dashboard/papers/${paperId}?${query}`;
}

async function normalizeOrderIndexes(paperId: string) {
  const questions = await prisma.generatedQuestion.findMany({
    where: { paperId },
    orderBy: [{ orderIndex: 'asc' }, { createdAt: 'asc' }]
  });

  await prisma.$transaction(
    questions.map((question, index) =>
      prisma.generatedQuestion.update({
        where: { id: question.id },
        data: { orderIndex: index }
      })
    )
  );
}

function importantQuestionWhere(chapterId: string, importanceLevel: ImportanceLevel): Prisma.ImportantQuestionWhereInput {
  if (importanceLevel === ImportanceLevel.NORMAL) return { chapterId };
  return {
    chapterId,
    OR: [{ importanceLevel }, { isBoardRepeated: true }, { isTeacherRecommended: true }]
  };
}

function cleanAiError(error: unknown) {
  if (error instanceof Error) {
    if (error.message.includes('API key')) return error.message;
    if (error.message.includes('invalid question JSON')) return error.message;
    if (error.message.includes('empty response')) return error.message;
  }

  return 'Single question regeneration failed. Please try again.';
}

function actionData(formData: FormData) {
  const parsed = generatedQuestionSchema.parse({
    questionId: formString(formData, 'questionId'),
    paperId: formString(formData, 'paperId'),
    sectionTitle: formString(formData, 'sectionTitle'),
    questionText: formString(formData, 'questionText'),
    optionsText: formString(formData, 'optionsText'),
    correctAnswer: formString(formData, 'correctAnswer'),
    answerText: formString(formData, 'answerText'),
    explanation: formString(formData, 'explanation'),
    questionType: formString(formData, 'questionType'),
    difficultyLevel: formString(formData, 'difficultyLevel'),
    importanceLevel: formString(formData, 'importanceLevel'),
    marks: formString(formData, 'marks')
  });

  return {
    ...parsed,
    options: parseOptions(parsed.optionsText)
  };
}

export async function updateGeneratedQuestion(formData: FormData) {
  let paperId = formString(formData, 'paperId');
  let redirectUrl = paperPath(paperId, 'error=question_update_failed');
  await requirePaperAccess(paperId);

  try {
    const data = actionData(formData);
    if (!data.questionId) throw new Error('Question is required');
    paperId = data.paperId;

    await prisma.generatedQuestion.updateMany({
      where: { id: data.questionId, paperId },
      data: {
        sectionTitle: data.sectionTitle,
        questionText: data.questionText,
        options: data.options,
        correctAnswer: data.correctAnswer,
        answerText: data.answerText,
        explanation: data.explanation,
        questionType: data.questionType,
        difficultyLevel: data.difficultyLevel,
        importanceLevel: data.importanceLevel,
        marks: data.marks
      }
    });

    redirectUrl = paperPath(paperId, 'success=question_updated');
  } catch {
    redirectUrl = paperPath(paperId, 'error=question_update_failed');
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  redirect(redirectUrl);
}

export async function deleteGeneratedQuestion(formData: FormData) {
  let paperId = formString(formData, 'paperId');
  let redirectUrl = paperPath(paperId, 'error=question_delete_failed');
  await requirePaperAccess(paperId);

  try {
    const data = idSchema.parse({
      questionId: formString(formData, 'questionId'),
      paperId
    });
    paperId = data.paperId;

    await prisma.generatedQuestion.deleteMany({ where: { id: data.questionId, paperId } });
    await normalizeOrderIndexes(paperId);
    redirectUrl = paperPath(paperId, 'success=question_deleted');
  } catch {
    redirectUrl = paperPath(paperId, 'error=question_delete_failed');
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  redirect(redirectUrl);
}

export async function addManualGeneratedQuestion(formData: FormData) {
  let paperId = formString(formData, 'paperId');
  let redirectUrl = paperPath(paperId, 'error=question_add_failed');
  await requirePaperAccess(paperId);

  try {
    const data = actionData(formData);
    paperId = data.paperId;

    const maxQuestion = await prisma.generatedQuestion.findFirst({
      where: { paperId },
      orderBy: { orderIndex: 'desc' }
    });

    await prisma.$transaction([
      prisma.generatedQuestion.create({
        data: {
          paperId,
          sectionTitle: data.sectionTitle,
          questionText: data.questionText,
          options: data.options,
          correctAnswer: data.correctAnswer,
          answerText: data.answerText,
          explanation: data.explanation,
          questionType: data.questionType,
          difficultyLevel: data.difficultyLevel,
          importanceLevel: data.importanceLevel,
          marks: data.marks,
          orderIndex: (maxQuestion?.orderIndex ?? -1) + 1
        }
      }),
      prisma.questionPaper.update({
        where: { id: paperId },
        data: { status: PaperStatus.GENERATED }
      })
    ]);

    redirectUrl = paperPath(paperId, 'success=question_added');
  } catch {
    redirectUrl = paperPath(paperId, 'error=question_add_failed');
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  revalidatePath('/dashboard');
  revalidatePath('/dashboard/papers');
  redirect(redirectUrl);
}

export async function moveGeneratedQuestion(formData: FormData) {
  let paperId = formString(formData, 'paperId');
  let redirectUrl = paperPath(paperId, 'error=question_move_failed');
  await requirePaperAccess(paperId);

  try {
    const data = moveSchema.parse({
      questionId: formString(formData, 'questionId'),
      paperId,
      direction: formString(formData, 'direction')
    });
    paperId = data.paperId;

    const current = await prisma.generatedQuestion.findFirstOrThrow({ where: { id: data.questionId, paperId } });
    const neighbor = await prisma.generatedQuestion.findFirst({
      where: {
        paperId,
        orderIndex: data.direction === 'UP' ? { lt: current.orderIndex } : { gt: current.orderIndex }
      },
      orderBy: { orderIndex: data.direction === 'UP' ? 'desc' : 'asc' }
    });

    if (neighbor) {
      await prisma.$transaction([
        prisma.generatedQuestion.update({ where: { id: current.id }, data: { orderIndex: neighbor.orderIndex } }),
        prisma.generatedQuestion.update({ where: { id: neighbor.id }, data: { orderIndex: current.orderIndex } })
      ]);
    }

    redirectUrl = paperPath(paperId, 'success=question_moved');
  } catch {
    redirectUrl = paperPath(paperId, 'error=question_move_failed');
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  redirect(redirectUrl);
}

export async function regenerateSingleQuestionWithAI(formData: FormData) {
  let paperId = formString(formData, 'paperId');
  let redirectUrl = paperPath(paperId, 'error=question_regenerate_failed');
  const model = process.env.DEEPSEEK_MODEL || 'deepseek-chat';
  let userId: string | null = null;
  const { user } = await requirePaperAccess(paperId);

  try {
    await assertUsageAllowed(user.id, UsageAction.AI_REGENERATE_QUESTION);
    const data = regenerateSchema.parse({
      questionId: formString(formData, 'questionId'),
      paperId,
      instruction: formString(formData, 'instruction')
    });
    paperId = data.paperId;

    const question = await prisma.generatedQuestion.findFirstOrThrow({
      where: { id: data.questionId, paperId },
      include: {
        paper: {
          include: {
            user: true,
            classLevel: true,
            subject: true,
            book: true,
            chapter: true
          }
        }
      }
    });

    const paper = question.paper;
    userId = paper.userId;
    if (!paper.chapterId || !paper.classLevel || !paper.subject || !paper.book || !paper.chapter) {
      throw new Error('Question paper is missing academic source information.');
    }

    const settings = asSettings(paper.settings);
    const difficultyLevel = isDifficultyLevel(settings.difficultyLevel) ? settings.difficultyLevel : question.difficultyLevel;
    const importanceLevel = isImportanceLevel(settings.importanceLevel) ? settings.importanceLevel : question.importanceLevel;
    const pageWhere: Prisma.BookPageWhereInput =
      settings.contentMode === 'PAGE_RANGE'
        ? {
            chapterId: paper.chapterId,
            pageNumber: {
              gte: settings.pageFrom ?? undefined,
              lte: settings.pageTo ?? undefined
            }
          }
        : { chapterId: paper.chapterId };

    const [pages, importantQuestions] = await Promise.all([
      prisma.bookPage.findMany({ where: pageWhere, orderBy: { pageNumber: 'asc' } }),
      prisma.importantQuestion.findMany({
        where: importantQuestionWhere(paper.chapterId, importanceLevel),
        orderBy: [{ isBoardRepeated: 'desc' }, { isTeacherRecommended: 'desc' }, { pageNumber: 'asc' }]
      })
    ]);

    const messages = buildSingleQuestionRegenerationPrompt({
      currentQuestion: {
        sectionTitle: question.sectionTitle,
        questionType: question.questionType,
        questionText: question.questionText,
        options: optionsList(question.options),
        correctAnswer: question.correctAnswer,
        answerText: question.answerText,
        explanation: question.explanation,
        marks: question.marks,
        difficultyLevel: question.difficultyLevel,
        importanceLevel: question.importanceLevel
      },
      paperTitle: paper.title,
      className: paper.classLevel.name,
      subjectName: paper.subject.name,
      bookTitle: paper.book.title,
      chapterTitle: `Chapter ${paper.chapter.chapterNo}: ${paper.chapter.title}`,
      difficultyLevel,
      importanceLevel,
      teacherInstruction: data.instruction,
      bookPageContents: pages.map((page) => ({ pageNumber: page.pageNumber, content: page.content })),
      importantQuestions: importantQuestions.map((importantQuestion) => ({
        questionText: importantQuestion.questionText,
        answerText: importantQuestion.answerText,
        questionType: importantQuestion.questionType,
        difficultyLevel: importantQuestion.difficultyLevel,
        importanceLevel: importantQuestion.importanceLevel,
        pageNumber: importantQuestion.pageNumber,
        exerciseNo: importantQuestion.exerciseNo,
        questionNo: importantQuestion.questionNo,
        isBoardRepeated: importantQuestion.isBoardRepeated,
        isTeacherRecommended: importantQuestion.isTeacherRecommended
      }))
    });

    const rawResponse = await generateWithDeepSeek(messages, { maxTokens: 1800, temperature: 0.2 });
    const parsed = parseSingleQuestionJson(rawResponse);

    await prisma.$transaction([
      prisma.generatedQuestion.update({
        where: { id: question.id },
        data: {
          sectionTitle: parsed.sectionTitle ?? question.sectionTitle,
          questionText: parsed.questionText,
          options: parsed.options,
          correctAnswer: parsed.correctAnswer ?? null,
          answerText: parsed.answerText ?? null,
          explanation: parsed.explanation ?? null,
          questionType: parsed.questionType,
          difficultyLevel: parsed.difficultyLevel,
          importanceLevel: parsed.importanceLevel,
          marks: parsed.marks ? Math.round(parsed.marks) : null
        }
      }),
      prisma.generationLog.create({
        data: {
          provider: 'deepseek',
          model,
          status: GenerationStatus.SUCCESS,
          userId: paper.userId,
          paperId
        }
      })
    ]);
    await recordUsage(user.id, UsageAction.AI_REGENERATE_QUESTION, paperId);

    redirectUrl = paperPath(paperId, 'success=question_regenerated');
  } catch (error) {
    if (error instanceof BillingError) {
      redirectUrl = paperPath(paperId, 'error=plan_limit_reached');
      revalidatePath(`/dashboard/papers/${paperId}`);
      redirect(redirectUrl);
    }

    const message = cleanAiError(error);

    if (userId) {
      await prisma.generationLog.create({
        data: {
          provider: 'deepseek',
          model,
          status: GenerationStatus.FAILED,
          userId,
          paperId,
          errorMessage: message
        }
      });
    }

    redirectUrl = paperPath(paperId, 'error=question_regenerate_failed');
  }

  revalidatePath(`/dashboard/papers/${paperId}`);
  revalidatePath('/dashboard/billing');
  redirect(redirectUrl);
}
