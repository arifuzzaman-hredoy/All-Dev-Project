'use server';

import { BillingCycle, PaymentStatus, Prisma, SubscriptionStatus } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

const requiredString = z.string().trim().min(1, 'This field is required');
const optionalString = z.string().trim().transform((value) => value || null);
const nonNegativeInt = z
  .string()
  .trim()
  .transform((value) => (value === '' ? 0 : Number(value)))
  .pipe(z.number().int().nonnegative());
const optionalDate = z
  .string()
  .trim()
  .transform((value) => (value ? new Date(value) : null))
  .pipe(z.date().nullable());

const planSchema = z.object({
  name: requiredString,
  slug: requiredString.regex(/^[a-z0-9-]+$/, 'Slug can use lowercase letters, numbers, and hyphens only'),
  description: optionalString,
  priceMonthly: nonNegativeInt,
  priceYearly: nonNegativeInt,
  priceLifetime: nonNegativeInt,
  paperLimitMonthly: nonNegativeInt,
  aiGenerationLimitMonthly: nonNegativeInt,
  aiRegenerateLimitMonthly: nonNegativeInt,
  exportLimitMonthly: nonNegativeInt,
  maxPagesPerPaper: nonNegativeInt,
  canUseImportantQuestions: z.boolean(),
  canUseSelectiveRegenerate: z.boolean(),
  canExportDocx: z.boolean(),
  canExportPdf: z.boolean(),
  canUseTeacherCopy: z.boolean(),
  isActive: z.boolean(),
  sortOrder: z
    .string()
    .trim()
    .transform((value) => (value === '' ? 0 : Number(value)))
    .pipe(z.number().int())
});

const subscriptionSchema = z.object({
  userId: requiredString,
  planId: requiredString,
  status: z.nativeEnum(SubscriptionStatus),
  billingCycle: z.nativeEnum(BillingCycle),
  startsAt: optionalDate,
  endsAt: optionalDate,
  currentPeriodStart: optionalDate,
  currentPeriodEnd: optionalDate,
  notes: optionalString
});

const paymentSchema = z.object({
  userId: requiredString,
  subscriptionId: optionalString,
  amount: nonNegativeInt.pipe(z.number().positive('Amount is required')),
  currency: requiredString,
  status: z.nativeEnum(PaymentStatus),
  provider: requiredString,
  transactionId: optionalString,
  note: optionalString
});

function formString(formData: FormData, key: string) {
  return String(formData.get(key) ?? '');
}

function formBoolean(formData: FormData, key: string) {
  return formData.get(key) === 'on';
}

function parseId(formData: FormData) {
  return requiredString.parse(formString(formData, 'id'));
}

function friendlyError(error: unknown) {
  if (error instanceof z.ZodError) return error.issues.map((issue) => issue.message).join(', ');
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2002') return 'A record with this unique value already exists.';
    if (error.code === 'P2003') return 'The selected related record does not exist.';
    if (error.code === 'P2025') return 'The record was not found.';
  }
  if (error instanceof Error) return error.message;
  return 'Something went wrong. Please try again.';
}

async function runBillingAction(paths: string[], action: () => Promise<void>) {
  await requireAdmin();
  try {
    await action();
    for (const path of paths) revalidatePath(path);
  } catch (error) {
    console.error('Billing admin action failed:', error);
    throw new Error(friendlyError(error));
  }
}

function planData(formData: FormData) {
  return planSchema.parse({
    name: formString(formData, 'name'),
    slug: formString(formData, 'slug').toLowerCase(),
    description: formString(formData, 'description'),
    priceMonthly: formString(formData, 'priceMonthly'),
    priceYearly: formString(formData, 'priceYearly'),
    priceLifetime: formString(formData, 'priceLifetime'),
    paperLimitMonthly: formString(formData, 'paperLimitMonthly'),
    aiGenerationLimitMonthly: formString(formData, 'aiGenerationLimitMonthly'),
    aiRegenerateLimitMonthly: formString(formData, 'aiRegenerateLimitMonthly'),
    exportLimitMonthly: formString(formData, 'exportLimitMonthly'),
    maxPagesPerPaper: formString(formData, 'maxPagesPerPaper'),
    canUseImportantQuestions: formBoolean(formData, 'canUseImportantQuestions'),
    canUseSelectiveRegenerate: formBoolean(formData, 'canUseSelectiveRegenerate'),
    canExportDocx: formBoolean(formData, 'canExportDocx'),
    canExportPdf: formBoolean(formData, 'canExportPdf'),
    canUseTeacherCopy: formBoolean(formData, 'canUseTeacherCopy'),
    isActive: formBoolean(formData, 'isActive'),
    sortOrder: formString(formData, 'sortOrder')
  });
}

function subscriptionData(formData: FormData) {
  const now = new Date();
  const data = subscriptionSchema.parse({
    userId: formString(formData, 'userId'),
    planId: formString(formData, 'planId'),
    status: formString(formData, 'status'),
    billingCycle: formString(formData, 'billingCycle'),
    startsAt: formString(formData, 'startsAt'),
    endsAt: formString(formData, 'endsAt'),
    currentPeriodStart: formString(formData, 'currentPeriodStart'),
    currentPeriodEnd: formString(formData, 'currentPeriodEnd'),
    notes: formString(formData, 'notes')
  });

  return {
    ...data,
    startsAt: data.startsAt ?? now,
    currentPeriodStart: data.currentPeriodStart ?? now
  };
}

function paymentData(formData: FormData) {
  return paymentSchema.parse({
    userId: formString(formData, 'userId'),
    subscriptionId: formString(formData, 'subscriptionId'),
    amount: formString(formData, 'amount'),
    currency: formString(formData, 'currency') || 'BDT',
    status: formString(formData, 'status'),
    provider: formString(formData, 'provider') || 'manual',
    transactionId: formString(formData, 'transactionId'),
    note: formString(formData, 'note')
  });
}

export async function createPlan(formData: FormData) {
  const data = planData(formData);
  await runBillingAction(['/admin/plans', '/pricing'], async () => {
    await prisma.plan.create({ data });
  });
}

export async function updatePlan(formData: FormData) {
  const id = parseId(formData);
  const data = planData(formData);
  await runBillingAction(['/admin/plans', '/pricing', '/dashboard/billing'], async () => {
    await prisma.plan.update({ where: { id }, data });
  });
}

export async function togglePlanStatus(formData: FormData) {
  const id = parseId(formData);
  await runBillingAction(['/admin/plans', '/pricing'], async () => {
    const plan = await prisma.plan.findUniqueOrThrow({ where: { id } });
    await prisma.plan.update({ where: { id }, data: { isActive: !plan.isActive } });
  });
}

export async function deletePlan(formData: FormData) {
  const id = parseId(formData);
  await runBillingAction(['/admin/plans', '/pricing'], async () => {
    const subscriptionCount = await prisma.subscription.count({ where: { planId: id } });
    if (subscriptionCount > 0) throw new Error('Cannot delete a plan with subscriptions.');
    await prisma.plan.delete({ where: { id } });
  });
}

export async function createSubscription(formData: FormData) {
  const data = subscriptionData(formData);
  await runBillingAction(['/admin/subscriptions', '/dashboard/billing'], async () => {
    await prisma.subscription.create({ data });
  });
}

export async function updateSubscription(formData: FormData) {
  const id = parseId(formData);
  const data = subscriptionData(formData);
  await runBillingAction(['/admin/subscriptions', '/dashboard/billing'], async () => {
    await prisma.subscription.update({ where: { id }, data });
  });
}

export async function cancelSubscription(formData: FormData) {
  const id = parseId(formData);
  await runBillingAction(['/admin/subscriptions', '/dashboard/billing'], async () => {
    await prisma.subscription.update({
      where: { id },
      data: { status: SubscriptionStatus.CANCELLED, endsAt: new Date() }
    });
  });
}

export async function createManualPayment(formData: FormData) {
  const data = paymentData(formData);
  await runBillingAction(['/admin/payments'], async () => {
    await prisma.payment.create({ data });
  });
}

export async function updatePaymentStatus(formData: FormData) {
  const id = parseId(formData);
  const status = z.nativeEnum(PaymentStatus).parse(formString(formData, 'status'));
  await runBillingAction(['/admin/payments'], async () => {
    await prisma.payment.update({ where: { id }, data: { status } });
  });
}
