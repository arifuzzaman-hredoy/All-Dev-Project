import type { ExportQuestion, PaperExportData } from '@/lib/export/paper-export-data';
import { DEFAULT_BANGLA_PAPER_INSTRUCTIONS } from '@/lib/education/bd-question-standards';

type RenderOptions = {
  includeAnswers: boolean;
  mode: 'student' | 'teacher';
};

function escapeHtml(value: string | number | null | undefined) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function groupQuestions(questions: ExportQuestion[]) {
  const groups = new Map<string, { title: string; questionType: string; questions: ExportQuestion[] }>();

  for (const question of questions) {
    const title = question.sectionTitle || 'Questions';
    const key = `${title}-${question.questionType}`;
    const group = groups.get(key);

    if (group) {
      group.questions.push(question);
    } else {
      groups.set(key, { title, questionType: question.questionType, questions: [question] });
    }
  }

  return Array.from(groups.values());
}

const optionLabels = ['ক', 'খ', 'গ', 'ঘ'];

const sectionLabels: Record<string, string> = {
  MCQ: 'বহুনির্বাচনী প্রশ্ন',
  SHORT: 'সংক্ষিপ্ত প্রশ্ন',
  ONE_WORD: 'এক কথায় উত্তর',
  FILL_BLANK: 'শূন্যস্থান পূরণ',
  TRUE_FALSE: 'সত্য/মিথ্যা',
  CREATIVE: 'সৃজনশীল প্রশ্ন',
  BROAD: 'রচনামূলক/বর্ণনামূলক প্রশ্ন',
  MATH_PROBLEM: 'গাণিতিক সমস্যা',
  MATCHING: 'মিলকরণ'
};

function sectionHeading(questionType: string, fallback: string, index: number) {
  const sectionLetter = String.fromCharCode(65 + index);
  return `Section ${sectionLetter}: ${sectionLabels[questionType] ?? fallback}`;
}

function renderQuestion(question: ExportQuestion, number: number, includeAnswers: boolean) {
  const options = question.options
    .map((option, index) => `<li><span>${optionLabels[index] || index + 1})</span> ${escapeHtml(option)}</li>`)
    .join('');

  return `
    <div class="question-block">
      <div class="question-line">
        <div class="question-text"><strong>${number}.</strong> ${escapeHtml(question.questionText)}</div>
        ${question.marks ? `<div class="marks">${question.marks}</div>` : ''}
      </div>
      ${options ? `<ol class="options">${options}</ol>` : ''}
      ${
        includeAnswers
          ? `<div class="answer-box">
              ${question.correctAnswer ? `<p><strong>সঠিক উত্তর:</strong> ${escapeHtml(question.correctAnswer)}</p>` : ''}
              ${question.answerText ? `<p><strong>মডেল উত্তর:</strong> ${escapeHtml(question.answerText)}</p>` : ''}
              ${question.explanation ? `<p><strong>ব্যাখ্যা:</strong> ${escapeHtml(question.explanation)}</p>` : ''}
            </div>`
          : ''
      }
    </div>
  `;
}

export function renderPaperHtml(data: PaperExportData, options: RenderOptions) {
  const groups = groupQuestions(data.questions);
  let questionNumber = 1;
  const templateClass = `template-${data.templateStyle.toLowerCase().replaceAll('_', '-')}`;
  const contact = [data.schoolAddress, data.schoolPhone, data.schoolEmail, data.schoolWebsite].filter(Boolean).map(escapeHtml).join(' / ');

  const sections = groups
    .map((group, index) => {
      const questions = group.questions
        .map((question) => renderQuestion(question, questionNumber++, options.includeAnswers))
        .join('');

      return `
        <section class="section">
          <h2>${escapeHtml(sectionHeading(group.questionType, group.title, index))} <span>${escapeHtml(group.questionType)}</span></h2>
          ${questions}
        </section>
      `;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(data.title)} - ${options.mode}</title>
  <style>
    @page { size: A4; margin: 18mm; }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: #f3f4f6;
      color: #111827;
      font-family: "Noto Sans Bengali", "SolaimanLipi", "Kalpurush", Arial, sans-serif;
      line-height: 1.55;
    }
    .page {
      width: min(210mm, 100%);
      min-height: 297mm;
      margin: 24px auto;
      background: #fff;
      padding: 18mm;
      box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
      position: relative;
      overflow: hidden;
    }
    .watermark { position: fixed; inset: 35% 0 auto; z-index: 0; text-align: center; font-size: 56px; font-weight: 800; color: rgba(17, 24, 39, 0.06); transform: rotate(-24deg); pointer-events: none; }
    .content { position: relative; z-index: 1; }
    .header { text-align: center; border-bottom: 1px solid #d1d5db; padding-bottom: 16px; margin-bottom: 20px; }
    .logo { max-height: 64px; max-width: 90px; object-fit: contain; margin-bottom: 8px; }
    .school { font-size: 20px; font-weight: 800; }
    .contact { margin-top: 4px; font-size: 12px; color: #4b5563; }
    h1 { margin: 8px 0; font-size: 24px; }
    .paper-title { margin-top: 4px; font-size: 15px; color: #374151; }
    .meta { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px 18px; margin-top: 12px; text-align: left; font-size: 14px; }
    .header-note { margin-top: 12px; padding: 8px 10px; background: #f9fafb; border: 1px solid #e5e7eb; text-align: left; font-size: 13px; }
    .copy-label { display: inline-block; margin-top: 10px; border: 1px solid #d1d5db; border-radius: 999px; padding: 3px 10px; font-size: 12px; text-transform: uppercase; }
    .section { margin-top: 22px; }
    h2 { font-size: 17px; border-bottom: 1px solid #e5e7eb; padding-bottom: 6px; }
    h2 span { font-size: 12px; color: #4b5563; margin-left: 8px; }
    .instructions { margin: 16px 0 6px; padding: 10px 12px; border: 1px solid #e5e7eb; background: #f9fafb; text-align: left; font-size: 13px; }
    .instructions strong { display: block; margin-bottom: 4px; }
    .instructions ul { margin: 0; padding-left: 22px; }
    .question-block { page-break-inside: avoid; margin: 14px 0; padding-bottom: 12px; border-bottom: 1px dashed #e5e7eb; }
    .question-line { display: flex; gap: 12px; align-items: flex-start; }
    .question-text { flex: 1; white-space: pre-wrap; }
    .marks { min-width: 42px; text-align: right; font-weight: 700; }
    .options { margin: 8px 0 0 26px; padding: 0; list-style: none; display: grid; gap: 4px; }
    .options span { font-weight: 700; }
    .answer-box { margin-top: 10px; padding: 10px 12px; background: #f9fafb; border-left: 3px solid #111827; font-size: 14px; }
    .answer-box p { margin: 5px 0; white-space: pre-wrap; }
    .signature { margin-top: 40px; display: flex; justify-content: flex-end; font-size: 13px; color: #374151; }
    .signature span { min-width: 180px; border-top: 1px solid #9ca3af; padding-top: 8px; text-align: center; }
    .footer { margin-top: 28px; padding-top: 12px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 12px; color: #6b7280; }
    .template-modern .header { border-bottom: 4px solid #111827; }
    .template-modern .school { letter-spacing: 0; }
    .template-minimal .header { border-bottom: 0; padding-bottom: 8px; }
    .template-minimal .question-block { border-bottom-color: #f3f4f6; }
    .template-board-exam .header { border: 2px solid #111827; padding: 14px; }
    .template-board-exam .copy-label { border-color: #111827; }
    .template-coaching-test .header { border-bottom: 2px dashed #9ca3af; }
    .template-coaching-test h2 { background: #f9fafb; padding: 8px; border: 1px solid #e5e7eb; }
    .no-print { margin: 16px auto; width: min(210mm, calc(100% - 32px)); display: flex; gap: 8px; }
    .no-print a, .no-print button { border: 1px solid #d1d5db; border-radius: 6px; padding: 8px 12px; background: #fff; color: #111827; text-decoration: none; cursor: pointer; }
    @media print {
      body { background: #fff; }
      .page { margin: 0; width: auto; min-height: auto; padding: 0; box-shadow: none; }
      .no-print { display: none !important; }
      .question-block { page-break-inside: avoid; break-inside: avoid; }
    }
  </style>
</head>
<body>
  <main class="page ${templateClass}">
    ${data.watermarkText ? `<div class="watermark">${escapeHtml(data.watermarkText)}</div>` : ''}
    <div class="content">
    <header class="header">
      ${data.schoolLogoUrl ? `<img src="${escapeHtml(data.schoolLogoUrl)}" class="logo" alt="" />` : ''}
      ${data.schoolName ? `<div class="school">${escapeHtml(data.schoolName)}</div>` : ''}
      ${contact ? `<div class="contact">${contact}</div>` : ''}
      <h1>${escapeHtml(data.examTitle)}</h1>
      <div class="paper-title">${escapeHtml(data.title)}</div>
      <div class="copy-label">${options.mode === 'teacher' ? 'Teacher Copy / উত্তরসহ' : 'Student Copy / শিক্ষার্থী কপি'}</div>
      <div class="meta">
        <div><strong>শ্রেণি:</strong> ${escapeHtml(data.className)}</div>
        <div><strong>বিষয়:</strong> ${escapeHtml(data.subjectName)}</div>
        <div><strong>বই:</strong> ${escapeHtml(data.bookTitle)}</div>
        <div><strong>অধ্যায়:</strong> ${escapeHtml(data.chapterTitle)}</div>
        <div><strong>পূর্ণমান:</strong> ${escapeHtml(data.totalMarks ?? '')}</div>
        <div><strong>সময়:</strong> ${data.durationMinutes ? `${escapeHtml(data.durationMinutes)} মিনিট` : ''}</div>
        ${data.teacherName ? `<div><strong>শিক্ষক:</strong> ${escapeHtml(data.teacherName)}</div>` : ''}
      </div>
      ${data.headerNote ? `<div class="header-note">${escapeHtml(data.headerNote)}</div>` : ''}
      <div class="instructions">
        <strong>নির্দেশনা:</strong>
        <ul>
          ${DEFAULT_BANGLA_PAPER_INSTRUCTIONS.map((instruction) => `<li>${escapeHtml(instruction)}</li>`).join('')}
          <li>ডান পাশে প্রশ্নের মান দেওয়া আছে।</li>
        </ul>
      </div>
    </header>
    ${sections}
    ${data.signatureText ? `<div class="signature"><span>${escapeHtml(data.signatureText)}</span></div>` : ''}
    <footer class="footer">${escapeHtml(data.footerText ?? 'Generated by Ai Real Question Paper Generator')}</footer>
    </div>
  </main>
</body>
</html>`;
}
