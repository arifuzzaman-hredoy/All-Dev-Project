import { prisma } from '@/lib/prisma';

export type ExportQuestion = {
  sectionTitle: string | null;
  questionType: string;
  questionText: string;
  options: string[];
  correctAnswer: string | null;
  answerText: string | null;
  explanation: string | null;
  marks: number | null;
  difficultyLevel: string;
  importanceLevel: string;
  orderIndex: number;
};

export type PaperExportData = {
  id: string;
  title: string;
  status: string;
  schoolName: string | null;
  schoolLogoUrl: string | null;
  schoolAddress: string | null;
  schoolPhone: string | null;
  schoolEmail: string | null;
  schoolWebsite: string | null;
  className: string | null;
  subjectName: string | null;
  bookTitle: string | null;
  chapterTitle: string | null;
  examTitle: string;
  headerNote: string | null;
  footerText: string | null;
  watermarkText: string | null;
  teacherName: string | null;
  signatureText: string | null;
  templateStyle: string;
  totalMarks: number | null;
  durationMinutes: number | null;
  createdAt: Date;
  questions: ExportQuestion[];
};

export class PaperExportError extends Error {
  constructor(
    message: string,
    public code: 'NOT_FOUND' | 'NO_QUESTIONS'
  ) {
    super(message);
  }
}

function optionsList(value: unknown) {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}

export async function getPaperExportData(paperId: string): Promise<PaperExportData> {
  const paper = await prisma.questionPaper.findUnique({
    where: { id: paperId },
    include: {
      user: { include: { school: true } },
      school: true,
      classLevel: true,
      subject: true,
      book: true,
      chapter: true,
      generated: { orderBy: { orderIndex: 'asc' } }
    }
  });

  if (!paper) {
    throw new PaperExportError('Question paper not found.', 'NOT_FOUND');
  }

  if (paper.generated.length === 0) {
    throw new PaperExportError('No generated questions found for this paper.', 'NO_QUESTIONS');
  }
  const school = paper.school ?? paper.user.school;

  return {
    id: paper.id,
    title: paper.title,
    status: paper.status,
    schoolName: school?.name ?? null,
    schoolLogoUrl: school?.logoUrl ?? null,
    schoolAddress: school?.address ?? null,
    schoolPhone: school?.phone ?? null,
    schoolEmail: school?.email ?? null,
    schoolWebsite: school?.website ?? null,
    className: paper.classLevel?.name ?? null,
    subjectName: paper.subject?.name ?? null,
    bookTitle: paper.book?.title ?? null,
    chapterTitle: paper.chapter ? `Chapter ${paper.chapter.chapterNo}: ${paper.chapter.title}` : null,
    examTitle: paper.examTitle ?? paper.title,
    headerNote: paper.headerNote ?? school?.defaultHeaderNote ?? null,
    footerText: paper.footerText ?? school?.defaultFooterText ?? null,
    watermarkText: paper.watermarkText ?? school?.watermarkText ?? null,
    teacherName: paper.teacherName ?? null,
    signatureText: paper.signatureText ?? school?.defaultSignatureText ?? null,
    templateStyle: paper.templateStyle,
    totalMarks: paper.totalMarks,
    durationMinutes: paper.durationMinutes,
    createdAt: paper.createdAt,
    questions: paper.generated.map((question) => ({
      sectionTitle: question.sectionTitle,
      questionType: question.questionType,
      questionText: question.questionText,
      options: optionsList(question.options),
      correctAnswer: question.correctAnswer,
      answerText: question.answerText,
      explanation: question.explanation,
      marks: question.marks,
      difficultyLevel: question.difficultyLevel,
      importanceLevel: question.importanceLevel,
      orderIndex: question.orderIndex
    }))
  };
}
