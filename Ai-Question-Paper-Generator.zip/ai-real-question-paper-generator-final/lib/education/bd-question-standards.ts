import type { DifficultyLevel, ImportanceLevel, QuestionType } from '@prisma/client';

export const BANGLADESHI_QUESTION_TYPES: Record<QuestionType, { labelBn: string; instruction: string }> = {
  MCQ: {
    labelBn: 'বহুনির্বাচনী প্রশ্ন',
    instruction: 'চারটি বিকল্প থাকবে, একটি সঠিক উত্তর থাকবে।'
  },
  SHORT: {
    labelBn: 'সংক্ষিপ্ত প্রশ্ন',
    instruction: '২-৩ লাইনে উত্তরযোগ্য প্রশ্ন।'
  },
  ONE_WORD: {
    labelBn: 'এক কথায় উত্তর',
    instruction: 'এক শব্দ/এক বাক্যে উত্তরযোগ্য।'
  },
  FILL_BLANK: {
    labelBn: 'শূন্যস্থান পূরণ',
    instruction: 'শূন্যস্থানে সঠিক শব্দ/সংখ্যা বসাতে হবে।'
  },
  TRUE_FALSE: {
    labelBn: 'সত্য/মিথ্যা',
    instruction: 'প্রদত্ত বাক্য সত্য না মিথ্যা নির্ণয় করতে হবে।'
  },
  CREATIVE: {
    labelBn: 'সৃজনশীল প্রশ্ন',
    instruction: 'বাংলাদেশি সৃজনশীল প্রশ্নের ফরম্যাট অনুসরণ করতে হবে: উদ্দীপক + ক/খ/গ/ঘ।'
  },
  BROAD: {
    labelBn: 'রচনামূলক/বর্ণনামূলক প্রশ্ন',
    instruction: 'বিস্তারিত উত্তরের জন্য উপযোগী প্রশ্ন।'
  },
  MATH_PROBLEM: {
    labelBn: 'গাণিতিক সমস্যা',
    instruction: 'ধাপে ধাপে সমাধানযোগ্য অংক/সমস্যা।'
  },
  MATCHING: {
    labelBn: 'মিলকরণ',
    instruction: 'বাম পাশ ও ডান পাশ মিলাতে হবে।'
  }
};

export const CQ_STRUCTURE = {
  stimulusTitle: 'উদ্দীপক',
  parts: [
    { key: 'ক', label: 'জ্ঞানমূলক', marks: 1 },
    { key: 'খ', label: 'অনুধাবনমূলক', marks: 2 },
    { key: 'গ', label: 'প্রয়োগমূলক', marks: 3 },
    { key: 'ঘ', label: 'উচ্চতর দক্ষতামূলক', marks: 4 }
  ],
  totalMarks: 10
} as const;

export const DEFAULT_BANGLA_PAPER_INSTRUCTIONS = [
  'সব প্রশ্নের উত্তর দাও।',
  'প্রয়োজনীয় চিত্র অঙ্কন করো।',
  'উত্তরপত্রে প্রশ্নের ক্রমিক নম্বর স্পষ্টভাবে লিখতে হবে।',
  'বহুনির্বাচনী প্রশ্নের ক্ষেত্রে সঠিক উত্তর নির্বাচন করো।'
];

export const DIFFICULTY_BN_LABELS: Partial<Record<DifficultyLevel, string>> = {
  VERY_EASY: 'খুব সহজ',
  EASY: 'সহজ',
  MEDIUM: 'মাঝারি',
  HARD: 'কঠিন',
  VERY_HARD: 'খুব কঠিন',
  BOARD_STANDARD: 'বোর্ড স্ট্যান্ডার্ড',
  WEAK_STUDENT_FRIENDLY: 'দুর্বল শিক্ষার্থী উপযোগী',
  MERIT_STUDENT_FRIENDLY: 'মেধাবী শিক্ষার্থী উপযোগী'
};

export const IMPORTANCE_BN_LABELS: Record<ImportanceLevel, string> = {
  NORMAL: 'সাধারণ',
  IMPORTANT: 'গুরুত্বপূর্ণ',
  VERY_IMPORTANT: 'খুব গুরুত্বপূর্ণ',
  MOST_IMPORTANT: 'সর্বাধিক গুরুত্বপূর্ণ',
  BOARD_REPEATED: 'পরীক্ষায় বারবার এসেছে',
  TEACHER_RECOMMENDED: 'শিক্ষক সুপারিশকৃত',
  PREVIOUS_EXAM_COMMON: 'আগের পরীক্ষায় কমন'
};

export function questionTypeInstruction(types: QuestionType[]) {
  return types
    .map((type) => {
      const standard = BANGLADESHI_QUESTION_TYPES[type];
      if (!standard) return null;
      return `- ${type}: ${standard.labelBn}. ${standard.instruction}`;
    })
    .filter(Boolean)
    .join('\n');
}
