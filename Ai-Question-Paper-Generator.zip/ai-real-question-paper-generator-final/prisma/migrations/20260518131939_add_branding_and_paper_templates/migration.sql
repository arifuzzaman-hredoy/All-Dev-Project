-- CreateEnum
CREATE TYPE "PaperTemplateStyle" AS ENUM ('CLASSIC', 'MODERN', 'MINIMAL', 'BOARD_EXAM', 'COACHING_TEST');

-- AlterTable
ALTER TABLE "QuestionPaper" ADD COLUMN     "examTitle" TEXT,
ADD COLUMN     "footerText" TEXT,
ADD COLUMN     "headerNote" TEXT,
ADD COLUMN     "signatureText" TEXT,
ADD COLUMN     "teacherName" TEXT,
ADD COLUMN     "templateStyle" "PaperTemplateStyle" NOT NULL DEFAULT 'CLASSIC',
ADD COLUMN     "watermarkText" TEXT;

-- AlterTable
ALTER TABLE "School" ADD COLUMN     "defaultFooterText" TEXT,
ADD COLUMN     "defaultHeaderNote" TEXT,
ADD COLUMN     "defaultSignatureText" TEXT,
ADD COLUMN     "watermarkText" TEXT,
ADD COLUMN     "website" TEXT;
