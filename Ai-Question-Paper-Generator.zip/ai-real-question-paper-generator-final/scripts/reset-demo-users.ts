import bcrypt from 'bcryptjs';
import { BillingCycle, PrismaClient, Role, SubscriptionStatus } from '@prisma/client';

const prisma = new PrismaClient();

async function ensureUser(email: string, name: string, password: string, role: Role) {
  const passwordHash = await bcrypt.hash(password, 12);
  return prisma.user.upsert({
    where: { email },
    update: { name, passwordHash, role },
    create: { email, name, passwordHash, role }
  });
}

async function ensureSubscription(userId: string, planSlug: string) {
  const plan = await prisma.plan.findUnique({ where: { slug: planSlug } });
  if (!plan) return;

  const existing = await prisma.subscription.findFirst({
    where: { userId, status: { in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING] } }
  });

  if (existing) {
    await prisma.subscription.update({ where: { id: existing.id }, data: { planId: plan.id, status: SubscriptionStatus.ACTIVE } });
    return;
  }

  const now = new Date();
  await prisma.subscription.create({
    data: {
      userId,
      planId: plan.id,
      status: SubscriptionStatus.ACTIVE,
      billingCycle: BillingCycle.MONTHLY,
      startsAt: now,
      currentPeriodStart: now,
      currentPeriodEnd: new Date(now.getFullYear(), now.getMonth() + 1, 1),
      notes: `Reset script ${planSlug} subscription`
    }
  });
}

async function main() {
  const admin = await ensureUser('admin@example.com', 'Super Admin', 'admin123456', Role.SUPER_ADMIN);
  const teacher = await ensureUser('teacher@example.com', 'Demo Teacher', 'teacher123456', Role.TEACHER);

  await prisma.user.updateMany({
    where: { email: 'demo.teacher@example.com' },
    data: { name: 'Demo Teacher', passwordHash: teacher.passwordHash, role: Role.TEACHER }
  });

  await ensureSubscription(admin.id, 'school');
  await ensureSubscription(teacher.id, 'basic');

  console.log('Demo users reset successfully.');
  console.log('Admin:   admin@example.com / admin123456');
  console.log('Teacher: teacher@example.com / teacher123456');
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
