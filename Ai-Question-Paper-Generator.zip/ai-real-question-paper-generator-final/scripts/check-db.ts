import 'dotenv/config';
import { prisma } from '@/lib/prisma';

async function main() {
  const [
    classLevelCount,
    subjectCount,
    bookCount,
    chapterCount,
    bookPageCount,
    importantQuestionCount,
    questionPaperCount,
    schoolCount,
    planCount,
    subscriptionCount,
    paymentCount,
    usageLogCount,
    sourceDocumentCount
  ] = await Promise.all([
    prisma.classLevel.count(),
    prisma.subject.count(),
    prisma.book.count(),
    prisma.chapter.count(),
    prisma.bookPage.count(),
    prisma.importantQuestion.count(),
    prisma.questionPaper.count(),
    prisma.school.count(),
    prisma.plan.count(),
    prisma.subscription.count(),
    prisma.payment.count(),
    prisma.usageLog.count(),
    prisma.sourceDocument.count()
  ]);

  console.table({
    ClassLevel: classLevelCount,
    Subject: subjectCount,
    Book: bookCount,
    Chapter: chapterCount,
    BookPage: bookPageCount,
    ImportantQuestion: importantQuestionCount,
    QuestionPaper: questionPaperCount,
    School: schoolCount,
    Plan: planCount,
    Subscription: subscriptionCount,
    Payment: paymentCount,
    UsageLog: usageLogCount,
    SourceDocument: sourceDocumentCount
  });
}

main()
  .catch((error) => {
    console.error('Database check failed:', error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
