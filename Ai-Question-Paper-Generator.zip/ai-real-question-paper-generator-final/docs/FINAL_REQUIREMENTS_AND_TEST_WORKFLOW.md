# Ai Real Question Paper Generator — Final Requirements and Test Workflow

## Final Product Vision
A Bangla-first SaaS system for teachers, schools, and coaching centers. Teachers choose class, subject, book, chapter/page, question type, difficulty, importance, and optional previous question/reference PDFs. The AI generates Bangladesh-style Bangla question papers with MCQ, CQ/creative, short, broad, math, fill-in-the-blanks, true/false, matching, answers, and explanations. The system supports teacher editing, selective regeneration, branding, export, SaaS plans, and admin content management.

## Default Demo Login
Run `npm run prisma:seed` and, if needed, `npm run reset:users`.

Admin:
- Email: `admin@example.com`
- Password: `admin123456`

Teacher:
- Email: `teacher@example.com`
- Password: `teacher123456`

Change these before production.

## Core Teacher Workflow
1. Login as teacher.
2. Open `/dashboard/branding` and set institution branding.
3. Open `/dashboard/create-paper`.
4. Select class, subject, book, chapter.
5. Select full chapter, page range, or important questions only.
6. Select MCQ / Short / CQ / Math etc.
7. Select difficulty and importance level.
8. Keep output language as Bangla.
9. Add teacher instruction, for example: `বাংলাদেশি স্কুল পরীক্ষার মতো MCQ, সংক্ষিপ্ত প্রশ্ন এবং সৃজনশীল প্রশ্ন তৈরি করুন।`
10. Optionally upload previous question/reference PDF to follow its pattern.
11. Create draft paper.
12. Click Generate with AI.
13. Review generated questions.
14. Edit/delete/add/move questions.
15. Regenerate one question with instruction.
16. Export Student Copy / Teacher Copy as print, HTML, DOCX, or PDF fallback.
17. Check usage at `/dashboard/billing`.

## Core Admin Workflow
1. Login as admin.
2. Open `/admin`.
3. Add/manage classes, subjects, books, chapters, book pages, important questions.
4. Upload text-based book PDF at `/admin/book-upload`.
5. Review source documents at `/admin/source-documents`.
6. Manage schools, plans, subscriptions, payments, and users.

## Book PDF Upload Workflow
1. Login as admin.
2. Open `/admin/book-upload`.
3. Select class, subject, book, chapter.
4. Enter start page number.
5. Upload a text-based PDF.
6. Choose import mode `Create book pages`.
7. The app extracts PDF text and upserts `BookPage` records.
8. If the PDF is scanned/image-only, it will be saved as `SCANNED_OR_EMPTY`. OCR is not included yet.

## Previous Question / Reference Upload Workflow
1. Teacher opens `/dashboard/create-paper`.
2. Completes all paper requirements.
3. Uploads a previous question/reference PDF.
4. Adds instruction such as: `আগের প্রশ্নের মতো মার্ক বণ্টন ও স্টাইল অনুসরণ করুন, কিন্তু সরাসরি কপি করবেন না।`
5. AI uses reference for style/pattern only. Actual questions must come from selected book/chapter/page/important questions.

## Bangladesh-Style Question Standard
### MCQ
- Bangla output by default.
- Exactly 4 options.
- Option labels: ক, খ, গ, ঘ.
- Correct answer: one of ক/খ/গ/ঘ.
- Teacher copy includes explanation.

### CQ / Creative Question
Must follow:
- উদ্দীপক
- ক) জ্ঞানমূলক — ১ নম্বর
- খ) অনুধাবনমূলক — ২ নম্বর
- গ) প্রয়োগমূলক — ৩ নম্বর
- ঘ) উচ্চতর দক্ষতামূলক — ৪ নম্বর

### Math Problem
- From selected chapter content.
- Step-by-step solution in teacher copy.
- Important exercise questions get priority.

## Local Development Setup With Neon
1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` to Neon PostgreSQL connection string.
3. Set `NEXTAUTH_SECRET` to a random secret.
4. Set `DEEPSEEK_API_KEY` for AI generation.
5. Run:

```powershell
npm install
npx prisma validate
npx prisma migrate dev
npx prisma generate
npm run prisma:seed
npm run reset:users
npm run typecheck
npm run build
npm run dev
```

## Must-Test Pages
### Public/Auth
- `/`
- `/login`
- `/register`
- `/pricing`

### Teacher
- `/dashboard`
- `/dashboard/create-paper`
- `/dashboard/papers`
- `/dashboard/papers/[id]`
- `/dashboard/papers/[id]/print?copy=student`
- `/dashboard/papers/[id]/print?copy=teacher`
- `/dashboard/billing`
- `/dashboard/branding`
- `/dashboard/settings`

### Admin
- `/admin`
- `/admin/classes`
- `/admin/subjects`
- `/admin/books`
- `/admin/chapters`
- `/admin/book-pages`
- `/admin/book-upload`
- `/admin/questions`
- `/admin/source-documents`
- `/admin/schools`
- `/admin/plans`
- `/admin/subscriptions`
- `/admin/payments`
- `/admin/users`

## Known Limitations
- OCR for scanned PDFs is not implemented yet.
- Real payment gateway is not integrated yet.
- PDF export may use printable HTML fallback for reliable Bangla rendering.
- AI quality depends heavily on Bangla book page content and DeepSeek API availability.
- Demo credentials are for development only.
