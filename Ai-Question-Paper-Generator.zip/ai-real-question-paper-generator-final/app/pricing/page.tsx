import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function PricingPage() {
  const user = await getCurrentUser();
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: [{ sortOrder: 'asc' }, { priceMonthly: 'asc' }]
  });

  return (
    <main className="space-y-8">
      <section className="text-center">
        <h1 className="text-3xl font-bold text-gray-950">প্যাকেজ ও মূল্য</h1>
        <p className="mt-2 text-sm text-gray-600">আপনার প্রশ্নপত্র তৈরির প্রয়োজন অনুযায়ী প্ল্যান নির্বাচন করুন।</p>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {plans.map((plan) => (
          <div key={plan.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
            <h2 className="text-xl font-bold text-gray-950">{plan.name}</h2>
            <p className="mt-2 text-3xl font-bold text-gray-950">BDT {plan.priceMonthly}</p>
            <p className="text-sm text-gray-500">per month</p>
            <p className="mt-3 text-sm leading-6 text-gray-600">{plan.description ?? 'Manual billing plan.'}</p>
            <ul className="mt-4 space-y-2 text-sm text-gray-700">
              <li>{plan.paperLimitMonthly} papers/month</li>
              <li>{plan.aiGenerationLimitMonthly} AI generations/month</li>
              <li>{plan.aiRegenerateLimitMonthly} regenerations/month</li>
              <li>{plan.exportLimitMonthly} exports/month</li>
              <li>Max {plan.maxPagesPerPaper} pages per paper</li>
              <li>{plan.canUseImportantQuestions ? 'Important questions included' : 'No important questions'}</li>
              <li>{plan.canUseSelectiveRegenerate ? 'Selective regenerate included' : 'No selective regenerate'}</li>
            </ul>
            <Link href={user ? '/dashboard/billing' : '/register'} className="mt-5 block rounded-md bg-gray-950 px-4 py-2 text-center text-sm font-semibold text-white hover:bg-gray-800">
              {user ? 'Go to Billing' : 'Register'}
            </Link>
          </div>
        ))}
      </section>
    </main>
  );
}
