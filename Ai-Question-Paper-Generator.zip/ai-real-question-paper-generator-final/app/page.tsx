import React from 'react';
import Link from 'next/link';
import { getCurrentUser, isAdminRole } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const user = await getCurrentUser();

  return (
    <main className="space-y-8">
      <section className="text-center py-20">
        <h1 className="text-4xl font-bold">Ai Real Question Paper Generator</h1>
        <p className="mt-4 text-gray-600">AI-powered question paper generator for teachers, schools, and coaching centers.</p>
        <div className="mt-6 flex justify-center gap-4">
          {user ? (
            <>
              <Link href="/dashboard" className="rounded-md bg-blue-600 px-5 py-3 text-white">Dashboard</Link>
              {isAdminRole(user.role) ? <Link href="/admin" className="rounded-md border border-gray-200 px-5 py-3">Admin Dashboard</Link> : null}
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-md bg-blue-600 px-5 py-3 text-white">Create Question Paper</Link>
              <Link href="/login" className="rounded-md border border-gray-200 px-5 py-3">Login</Link>
              <Link href="/register" className="rounded-md border border-gray-200 px-5 py-3">Register</Link>
            </>
          )}
        </div>
      </section>
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-semibold">Simple & Fast</h3>
          <p className="text-sm text-gray-500">Create papers in seconds using AI and your uploaded books.</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-semibold">Flexible</h3>
          <p className="text-sm text-gray-500">Choose class, subject, chapter range and question types.</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-semibold">Production-ready</h3>
          <p className="text-sm text-gray-500">Scalable foundation with Prisma, Tailwind and TypeScript.</p>
        </div>
      </section>
    </main>
  );
}
