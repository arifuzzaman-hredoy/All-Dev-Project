import Link from 'next/link';
import { registerUser } from '@/lib/actions/auth';

export const dynamic = 'force-dynamic';

const errorMessages: Record<string, string> = {
  email_exists: 'An account with this email already exists.',
  password_mismatch: 'Passwords do not match.',
  invalid_input: 'Please check the form and try again.',
  unknown: 'Something went wrong. Please try again.'
};

export default function RegisterPage({
  searchParams
}: {
  searchParams?: { error?: string };
}) {
  const errorMessage = searchParams?.error ? errorMessages[searchParams.error] ?? errorMessages.unknown : null;

  return (
    <main className="mx-auto flex min-h-[70vh] max-w-md items-center">
      <div className="w-full rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-950">Register</h1>
        <p className="mt-1 text-sm text-gray-600">Create your teacher account.</p>

        {errorMessage ? <div className="mt-4 rounded-md border border-red-200 bg-red-50 p-3 text-sm font-medium text-red-700">{errorMessage}</div> : null}

        <form action={registerUser} className="mt-6 space-y-4">
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Name
            <input name="name" required className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Email
            <input name="email" type="email" required className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Password
            <input name="password" type="password" required minLength={6} className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Confirm password
            <input name="confirmPassword" type="password" required minLength={6} className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          </label>
          <button type="submit" className="w-full rounded-md bg-gray-950 px-4 py-2.5 text-sm font-semibold text-white hover:bg-gray-800">
            Register
          </button>
        </form>

        <p className="mt-4 text-sm text-gray-600">
          Already have an account? <Link href="/login" className="font-semibold text-gray-950 hover:underline">Login</Link>
        </p>
      </div>
    </main>
  );
}
