import './globals.css';
import React from 'react';
import Link from 'next/link';
import LogoutButton from '@/components/auth/LogoutButton';
import { getCurrentUser, isAdminRole } from '@/lib/auth/session';

export const metadata = {
  title: 'Ai Real Question Paper Generator',
  description: 'AI-powered question paper generator for teachers, schools, and coaching centers.'
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();

  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50 text-gray-900">
        <div className="mx-auto max-w-6xl px-4 py-6">
          <header className="mb-8 flex flex-wrap items-center justify-between gap-4 rounded-lg border border-gray-200 bg-white px-4 py-3 shadow-sm">
            <Link href="/" className="text-sm font-bold text-gray-950">
              Ai Real Question Paper Generator
            </Link>
            <nav className="flex flex-wrap items-center gap-3 text-sm">
              {user ? (
                <>
                  <Link href="/dashboard" className="font-medium text-gray-700 hover:text-gray-950">Dashboard</Link>
                  <Link href="/dashboard/branding" className="font-medium text-gray-700 hover:text-gray-950">Branding</Link>
                  <Link href="/pricing" className="font-medium text-gray-700 hover:text-gray-950">Pricing</Link>
                  {isAdminRole(user.role) ? <Link href="/admin" className="font-medium text-gray-700 hover:text-gray-950">Admin</Link> : null}
                  <span className="hidden text-gray-300 sm:inline">|</span>
                  <span className="text-gray-600">{user.name || user.email}</span>
                  <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{user.role}</span>
                  <LogoutButton />
                </>
              ) : (
                <>
                  <Link href="/login" className="font-medium text-gray-700 hover:text-gray-950">Login</Link>
                  <Link href="/pricing" className="font-medium text-gray-700 hover:text-gray-950">Pricing</Link>
                  <Link href="/register" className="rounded-md bg-gray-950 px-3 py-2 font-semibold text-white hover:bg-gray-800">Register</Link>
                </>
              )}
            </nav>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
