import React from 'react';

export default function AdminUsersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Users</h1>
      <p className="text-sm text-gray-600">Manage users and roles.</p>
    </div>
  );
}
