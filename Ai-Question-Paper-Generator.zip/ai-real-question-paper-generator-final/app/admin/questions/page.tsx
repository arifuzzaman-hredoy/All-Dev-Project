import { DifficultyLevel, ImportanceLevel, QuestionType } from '@prisma/client';
import DeleteButton from '@/components/admin/DeleteButton';
import {
  createImportantQuestion,
  deleteImportantQuestion,
  updateImportantQuestion
} from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';

function badgeClass(kind: 'difficulty' | 'importance') {
  return kind === 'difficulty'
    ? 'rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700'
    : 'rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700';
}

export default async function AdminQuestionsPage() {
  const [questions, books, chapters] = await Promise.all([
    prisma.importantQuestion.findMany({
      include: { book: true, chapter: true },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.book.findMany({ include: { subject: true, classLevel: true }, orderBy: { title: 'asc' } }),
    prisma.chapter.findMany({ include: { book: true }, orderBy: [{ book: { title: 'asc' } }, { chapterNo: 'asc' }] })
  ]);

  const questionTypes = Object.values(QuestionType);
  const difficultyLevels = Object.values(DifficultyLevel);
  const importanceLevels = Object.values(ImportanceLevel);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Important Questions</h1>
        <p className="text-sm text-gray-600">Tag source questions with type, difficulty, importance, and teacher signals.</p>
      </div>

      <form action={createImportantQuestion} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Important Question</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <select name="bookId" required className={inputClass}>
            <option value="">Select book</option>
            {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
          </select>
          <select name="chapterId" required className={inputClass}>
            <option value="">Select chapter</option>
            {chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.book.title} - Ch {chapter.chapterNo}: {chapter.title}</option>)}
          </select>
          <textarea name="questionText" required rows={4} placeholder="Question text" className={`${inputClass} md:col-span-2`} />
          <textarea name="answerText" rows={4} placeholder="Answer text (optional)" className={`${inputClass} md:col-span-2`} />
          <select name="questionType" defaultValue={QuestionType.SHORT} required className={inputClass}>
            {questionTypes.map((type) => <option key={type} value={type}>{type}</option>)}
          </select>
          <select name="difficultyLevel" defaultValue={DifficultyLevel.MEDIUM} required className={inputClass}>
            {difficultyLevels.map((level) => <option key={level} value={level}>{level}</option>)}
          </select>
          <select name="importanceLevel" defaultValue={ImportanceLevel.IMPORTANT} required className={inputClass}>
            {importanceLevels.map((level) => <option key={level} value={level}>{level}</option>)}
          </select>
          <input name="pageNumber" type="number" min="1" placeholder="Page number" className={inputClass} />
          <input name="exerciseNo" placeholder="Exercise no." className={inputClass} />
          <input name="questionNo" placeholder="Question no." className={inputClass} />
          <input name="sourceNote" placeholder="Source note" className={`${inputClass} md:col-span-2`} />
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <input name="isBoardRepeated" type="checkbox" className="h-4 w-4 rounded border-gray-300" />
            Board repeated
          </label>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <input name="isTeacherRecommended" type="checkbox" className="h-4 w-4 rounded border-gray-300" />
            Teacher recommended
          </label>
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:w-fit">Add Question</button>
        </div>
      </form>

      <div className="space-y-4">
        {questions.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 shadow-sm">No important questions yet.</div>
        ) : (
          questions.map((question) => (
            <div key={question.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <div className="mb-4 flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{question.questionType}</span>
                <span className={badgeClass('difficulty')}>{question.difficultyLevel}</span>
                <span className={badgeClass('importance')}>{question.importanceLevel}</span>
                {question.isBoardRepeated ? <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-700">Board repeated</span> : null}
                {question.isTeacherRecommended ? <span className="rounded-full bg-purple-50 px-2.5 py-1 text-xs font-semibold text-purple-700">Teacher recommended</span> : null}
              </div>
              <form id={`update-${question.id}`} action={updateImportantQuestion} className="grid gap-4 md:grid-cols-2">
                <input type="hidden" name="id" value={question.id} />
                <select name="bookId" defaultValue={question.bookId} required className={inputClass}>
                  {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
                </select>
                <select name="chapterId" defaultValue={question.chapterId} required className={inputClass}>
                  {chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.book.title} - Ch {chapter.chapterNo}: {chapter.title}</option>)}
                </select>
                <textarea name="questionText" defaultValue={question.questionText} required rows={4} className={`${inputClass} md:col-span-2`} />
                <textarea name="answerText" defaultValue={question.answerText ?? ''} rows={4} className={`${inputClass} md:col-span-2`} />
                <select name="questionType" defaultValue={question.questionType} required className={inputClass}>
                  {questionTypes.map((type) => <option key={type} value={type}>{type}</option>)}
                </select>
                <select name="difficultyLevel" defaultValue={question.difficultyLevel} required className={inputClass}>
                  {difficultyLevels.map((level) => <option key={level} value={level}>{level}</option>)}
                </select>
                <select name="importanceLevel" defaultValue={question.importanceLevel} required className={inputClass}>
                  {importanceLevels.map((level) => <option key={level} value={level}>{level}</option>)}
                </select>
                <input name="pageNumber" type="number" min="1" defaultValue={question.pageNumber ?? ''} className={inputClass} />
                <input name="exerciseNo" defaultValue={question.exerciseNo ?? ''} className={inputClass} />
                <input name="questionNo" defaultValue={question.questionNo ?? ''} className={inputClass} />
                <input name="sourceNote" defaultValue={question.sourceNote ?? ''} className={`${inputClass} md:col-span-2`} />
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
                  <input name="isBoardRepeated" type="checkbox" defaultChecked={question.isBoardRepeated} className="h-4 w-4 rounded border-gray-300" />
                  Board repeated
                </label>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
                  <input name="isTeacherRecommended" type="checkbox" defaultChecked={question.isTeacherRecommended} className="h-4 w-4 rounded border-gray-300" />
                  Teacher recommended
                </label>
              </form>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-gray-600">{question.book.title} / {question.chapter.title}</p>
                <div className="flex gap-2">
                  <button form={`update-${question.id}`} className="rounded-md bg-gray-950 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800">Save</button>
                  <form action={deleteImportantQuestion}>
                    <input type="hidden" name="id" value={question.id} />
                    <DeleteButton />
                  </form>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
