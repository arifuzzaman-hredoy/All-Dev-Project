import Link from 'next/link';
import { ExtractionStatus, SourceDocumentType } from '@prisma/client';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

function preview(text?: string | null) {
  if (!text) return '-';
  return text.length > 220 ? `${text.slice(0, 220)}...` : text;
}

export default async function AdminSourceDocumentsPage({
  searchParams
}: {
  searchParams?: { type?: SourceDocumentType; status?: ExtractionStatus };
}) {
  const type = searchParams?.type && Object.values(SourceDocumentType).includes(searchParams.type) ? searchParams.type : undefined;
  const status = searchParams?.status && Object.values(ExtractionStatus).includes(searchParams.status) ? searchParams.status : undefined;
  const documents = await prisma.sourceDocument.findMany({
    where: {
      type,
      extractionStatus: status
    },
    include: {
      user: true,
      classLevel: true,
      subject: true,
      book: true,
      chapter: true,
      paper: true
    },
    orderBy: { createdAt: 'desc' },
    take: 100
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Source Documents</h1>
        <p className="text-sm text-gray-600">Review uploaded PDFs, extraction status, and linked papers/content.</p>
      </div>

      <form className="flex flex-wrap gap-3 rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
        <select name="type" defaultValue={type ?? ''} className="rounded-md border border-gray-300 px-3 py-2 text-sm">
          <option value="">All types</option>
          {Object.values(SourceDocumentType).map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
        <select name="status" defaultValue={status ?? ''} className="rounded-md border border-gray-300 px-3 py-2 text-sm">
          <option value="">All statuses</option>
          {Object.values(ExtractionStatus).map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
        <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Filter</button>
      </form>

      <div className="space-y-4">
        {documents.map((document) => (
          <article key={document.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="font-semibold text-gray-950">{document.title}</h2>
                <p className="text-xs text-gray-500">{document.type} / {document.extractionStatus} / {document.originalFileName}</p>
              </div>
              <span className="text-xs text-gray-500">{document.createdAt.toLocaleString()}</span>
            </div>
            <p className="mt-3 text-sm text-gray-600">
              User: {document.user?.email ?? '-'} / {document.classLevel?.name ?? '-'} / {document.subject?.name ?? '-'} / {document.book?.title ?? '-'} / {document.chapter?.title ?? '-'}
            </p>
            {document.paper ? (
              <Link href={`/dashboard/papers/${document.paper.id}`} className="mt-2 inline-flex text-sm font-semibold text-gray-950 hover:underline">
                Paper: {document.paper.title}
              </Link>
            ) : null}
            {document.errorMessage ? <p className="mt-3 rounded bg-amber-50 p-3 text-sm text-amber-700">{document.errorMessage}</p> : null}
            <p className="mt-3 whitespace-pre-wrap rounded bg-gray-50 p-3 text-sm leading-6 text-gray-700">{preview(document.extractedText)}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
