import { createSchool, deleteSchool, updateSchool } from '@/lib/actions/school-admin';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';

function SchoolFields({ school }: { school?: Awaited<ReturnType<typeof prisma.school.findMany>>[number] }) {
  return (
    <>
      <div className="grid gap-3 md:grid-cols-2">
        <input name="name" required defaultValue={school?.name ?? ''} placeholder="School / coaching name" className={inputClass} />
        <input name="logoUrl" defaultValue={school?.logoUrl ?? ''} placeholder="Logo URL" className={inputClass} />
        <input name="phone" defaultValue={school?.phone ?? ''} placeholder="Phone" className={inputClass} />
        <input name="email" type="email" defaultValue={school?.email ?? ''} placeholder="Email" className={inputClass} />
        <input name="website" defaultValue={school?.website ?? ''} placeholder="Website" className={inputClass} />
        <input name="watermarkText" defaultValue={school?.watermarkText ?? ''} placeholder="Watermark text" className={inputClass} />
      </div>
      <textarea name="address" defaultValue={school?.address ?? ''} placeholder="Address" rows={2} className={`${inputClass} w-full`} />
      <textarea name="defaultHeaderNote" defaultValue={school?.defaultHeaderNote ?? ''} placeholder="Default header note" rows={2} className={`${inputClass} w-full`} />
      <textarea name="defaultFooterText" defaultValue={school?.defaultFooterText ?? ''} placeholder="Default footer text" rows={2} className={`${inputClass} w-full`} />
      <input name="defaultSignatureText" defaultValue={school?.defaultSignatureText ?? ''} placeholder="Default signature text" className={`${inputClass} w-full`} />
    </>
  );
}

export default async function AdminSchoolsPage() {
  const schools = await prisma.school.findMany({
    include: { _count: { select: { users: true, questionPapers: true } } },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Schools</h1>
        <p className="text-sm text-gray-600">Manage institution branding records.</p>
      </div>

      <form action={createSchool} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Create School</h2>
        <SchoolFields />
        <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Create School</button>
      </form>

      <div className="space-y-4">
        {schools.map((school) => {
          const formId = `school-${school.id}`;
          return (
            <section key={school.id} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-gray-950">{school.name}</h2>
                  <p className="text-sm text-gray-500">{school._count.users} users / {school._count.questionPapers} papers</p>
                </div>
              </div>
              <form id={formId} action={updateSchool} className="space-y-4">
                <input type="hidden" name="id" value={school.id} />
                <SchoolFields school={school} />
              </form>
              <div className="flex flex-wrap gap-2">
                <button form={formId} type="submit" className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save</button>
                <form action={deleteSchool}>
                  <input type="hidden" name="id" value={school.id} />
                  <button type="submit" disabled={school._count.users > 0} className="rounded-md border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50">
                    Delete
                  </button>
                </form>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
