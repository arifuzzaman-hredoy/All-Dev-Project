import { PaymentStatus } from '@prisma/client';
import { createManualPayment, updatePaymentStatus } from '@/lib/actions/billing-admin';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';

export default async function AdminPaymentsPage() {
  const [payments, users, subscriptions] = await Promise.all([
    prisma.payment.findMany({
      include: { user: true, subscription: { include: { plan: true } } },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.user.findMany({ orderBy: { email: 'asc' } }),
    prisma.subscription.findMany({ include: { user: true, plan: true }, orderBy: { createdAt: 'desc' } })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Payments</h1>
        <p className="text-sm text-gray-600">Track manual payments for subscriptions.</p>
      </div>

      <form action={createManualPayment} className="grid gap-3 rounded-lg border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
        <h2 className="text-lg font-semibold text-gray-950 md:col-span-2">Add Manual Payment</h2>
        <select name="userId" required className={inputClass}>
          <option value="">Select user</option>
          {users.map((user) => <option key={user.id} value={user.id}>{user.email}</option>)}
        </select>
        <select name="subscriptionId" className={inputClass}>
          <option value="">No subscription link</option>
          {subscriptions.map((subscription) => (
            <option key={subscription.id} value={subscription.id}>{subscription.user.email} / {subscription.plan.name}</option>
          ))}
        </select>
        <input name="amount" required type="number" min="1" placeholder="Amount" className={inputClass} />
        <input name="currency" defaultValue="BDT" className={inputClass} />
        <select name="status" defaultValue={PaymentStatus.PENDING} className={inputClass}>
          {Object.values(PaymentStatus).map((status) => <option key={status} value={status}>{status}</option>)}
        </select>
        <input name="provider" defaultValue="manual" className={inputClass} />
        <input name="transactionId" placeholder="Transaction ID" className={inputClass} />
        <input name="note" placeholder="Note" className={inputClass} />
        <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:col-span-2">Add Payment</button>
      </form>

      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Plan</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Transaction</th>
              <th className="px-4 py-3">Created</th>
              <th className="px-4 py-3">Update</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {payments.map((payment) => (
              <tr key={payment.id}>
                <td className="px-4 py-3 font-medium text-gray-950">{payment.user.email}</td>
                <td className="px-4 py-3 text-gray-600">{payment.subscription?.plan.name ?? '-'}</td>
                <td className="px-4 py-3 text-gray-600">{payment.amount} {payment.currency}</td>
                <td className="px-4 py-3 text-gray-600">{payment.status}</td>
                <td className="px-4 py-3 text-gray-600">{payment.transactionId ?? '-'}</td>
                <td className="px-4 py-3 text-gray-600">{payment.createdAt.toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <form action={updatePaymentStatus} className="flex gap-2">
                    <input type="hidden" name="id" value={payment.id} />
                    <select name="status" defaultValue={payment.status} className={inputClass}>
                      {Object.values(PaymentStatus).map((status) => <option key={status} value={status}>{status}</option>)}
                    </select>
                    <button type="submit" className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
