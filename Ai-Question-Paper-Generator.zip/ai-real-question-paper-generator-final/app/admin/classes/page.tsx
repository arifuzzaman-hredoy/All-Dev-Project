import DeleteButton from '@/components/admin/DeleteButton';
import { createClassLevel, deleteClassLevel, updateClassLevel } from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminClassesPage() {
  const classes = await prisma.classLevel.findMany({
    orderBy: [{ orderNo: 'asc' }, { name: 'asc' }]
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Classes</h1>
        <p className="text-sm text-gray-600">Manage class levels used by subjects, books, and papers.</p>
      </div>

      <form action={createClassLevel} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Class</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-[1fr_160px_auto]">
          <input name="name" required placeholder="Class 8" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <input name="orderNo" type="number" min="1" placeholder="Order" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Add</button>
        </div>
      </form>

      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {classes.length === 0 ? (
              <tr>
                <td colSpan={3} className="px-4 py-8 text-center text-gray-500">No classes yet.</td>
              </tr>
            ) : (
              classes.map((classLevel) => (
                <tr key={classLevel.id}>
                  <td className="px-4 py-3">
                    <form id={`update-${classLevel.id}`} action={updateClassLevel} className="grid gap-3 md:grid-cols-[1fr_140px]">
                      <input type="hidden" name="id" value={classLevel.id} />
                      <input name="name" defaultValue={classLevel.name} required className="rounded-md border border-gray-300 px-3 py-2" />
                      <input name="orderNo" type="number" min="1" defaultValue={classLevel.orderNo ?? ''} className="rounded-md border border-gray-300 px-3 py-2" />
                    </form>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{classLevel.orderNo ?? '-'}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <button form={`update-${classLevel.id}`} className="rounded-md bg-gray-950 px-3 py-2 font-medium text-white hover:bg-gray-800">Save</button>
                      <form action={deleteClassLevel}>
                        <input type="hidden" name="id" value={classLevel.id} />
                        <DeleteButton />
                      </form>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
