import { BillingCycle, SubscriptionStatus } from '@prisma/client';
import { cancelSubscription, createSubscription, updateSubscription } from '@/lib/actions/billing-admin';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';

function dateValue(date: Date | null) {
  return date ? date.toISOString().slice(0, 10) : '';
}

export default async function AdminSubscriptionsPage() {
  const [subscriptions, users, plans] = await Promise.all([
    prisma.subscription.findMany({
      include: { user: true, plan: true },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.user.findMany({ orderBy: { email: 'asc' } }),
    prisma.plan.findMany({ orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }] })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Subscriptions</h1>
        <p className="text-sm text-gray-600">Assign plans, update status, and extend access manually.</p>
      </div>

      <form action={createSubscription} className="grid gap-3 rounded-lg border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
        <h2 className="text-lg font-semibold text-gray-950 md:col-span-2">Create Subscription</h2>
        <select name="userId" required className={inputClass}>
          <option value="">Select user</option>
          {users.map((user) => <option key={user.id} value={user.id}>{user.email}</option>)}
        </select>
        <select name="planId" required className={inputClass}>
          <option value="">Select plan</option>
          {plans.map((plan) => <option key={plan.id} value={plan.id}>{plan.name}</option>)}
        </select>
        <select name="status" defaultValue={SubscriptionStatus.ACTIVE} className={inputClass}>
          {Object.values(SubscriptionStatus).map((status) => <option key={status} value={status}>{status}</option>)}
        </select>
        <select name="billingCycle" defaultValue={BillingCycle.MONTHLY} className={inputClass}>
          {Object.values(BillingCycle).map((cycle) => <option key={cycle} value={cycle}>{cycle}</option>)}
        </select>
        <input name="startsAt" type="date" className={inputClass} />
        <input name="endsAt" type="date" className={inputClass} />
        <input name="currentPeriodStart" type="date" className={inputClass} />
        <input name="currentPeriodEnd" type="date" className={inputClass} />
        <textarea name="notes" placeholder="Notes" rows={2} className={`${inputClass} md:col-span-2`} />
        <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:col-span-2">Create Subscription</button>
      </form>

      <div className="space-y-4">
        {subscriptions.map((subscription) => {
          const formId = `subscription-${subscription.id}`;
          return (
            <section key={subscription.id} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <div>
                <h2 className="text-lg font-semibold text-gray-950">{subscription.user.email}</h2>
                <p className="text-sm text-gray-500">{subscription.plan.name} / {subscription.status}</p>
              </div>
              <form id={formId} action={updateSubscription} className="grid gap-3 md:grid-cols-2">
                <input type="hidden" name="id" value={subscription.id} />
                <select name="userId" defaultValue={subscription.userId} required className={inputClass}>
                  {users.map((user) => <option key={user.id} value={user.id}>{user.email}</option>)}
                </select>
                <select name="planId" defaultValue={subscription.planId} required className={inputClass}>
                  {plans.map((plan) => <option key={plan.id} value={plan.id}>{plan.name}</option>)}
                </select>
                <select name="status" defaultValue={subscription.status} className={inputClass}>
                  {Object.values(SubscriptionStatus).map((status) => <option key={status} value={status}>{status}</option>)}
                </select>
                <select name="billingCycle" defaultValue={subscription.billingCycle} className={inputClass}>
                  {Object.values(BillingCycle).map((cycle) => <option key={cycle} value={cycle}>{cycle}</option>)}
                </select>
                <input name="startsAt" type="date" defaultValue={dateValue(subscription.startsAt)} className={inputClass} />
                <input name="endsAt" type="date" defaultValue={dateValue(subscription.endsAt)} className={inputClass} />
                <input name="currentPeriodStart" type="date" defaultValue={dateValue(subscription.currentPeriodStart)} className={inputClass} />
                <input name="currentPeriodEnd" type="date" defaultValue={dateValue(subscription.currentPeriodEnd)} className={inputClass} />
                <textarea name="notes" defaultValue={subscription.notes ?? ''} rows={2} className={`${inputClass} md:col-span-2`} />
              </form>
              <div className="flex flex-wrap gap-2">
                <button form={formId} type="submit" className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save</button>
                <form action={cancelSubscription}>
                  <input type="hidden" name="id" value={subscription.id} />
                  <button type="submit" className="rounded-md border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50">Cancel</button>
                </form>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
