import { deletePlan, togglePlanStatus, updatePlan, createPlan } from '@/lib/actions/billing-admin';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';
const checkboxFields = [
  ['canUseImportantQuestions', 'Important questions'],
  ['canUseSelectiveRegenerate', 'Selective regenerate'],
  ['canExportDocx', 'DOCX export'],
  ['canExportPdf', 'PDF export'],
  ['canUseTeacherCopy', 'Teacher copy'],
  ['isActive', 'Active']
] as const;

function PlanFields({ prefix, plan }: { prefix: string; plan?: Awaited<ReturnType<typeof prisma.plan.findMany>>[number] }) {
  return (
    <>
      <div className="grid gap-3 md:grid-cols-3">
        <input name="name" required defaultValue={plan?.name ?? ''} placeholder="Plan name" className={inputClass} />
        <input name="slug" required defaultValue={plan?.slug ?? ''} placeholder="slug" className={inputClass} />
        <input name="sortOrder" type="number" defaultValue={plan?.sortOrder ?? 0} placeholder="Sort order" className={inputClass} />
      </div>
      <textarea name="description" defaultValue={plan?.description ?? ''} placeholder="Description" rows={2} className={`${inputClass} w-full`} />
      <div className="grid gap-3 md:grid-cols-3">
        <input name="priceMonthly" type="number" min="0" defaultValue={plan?.priceMonthly ?? 0} placeholder="Monthly price" className={inputClass} />
        <input name="priceYearly" type="number" min="0" defaultValue={plan?.priceYearly ?? 0} placeholder="Yearly price" className={inputClass} />
        <input name="priceLifetime" type="number" min="0" defaultValue={plan?.priceLifetime ?? 0} placeholder="Lifetime price" className={inputClass} />
      </div>
      <div className="grid gap-3 md:grid-cols-5">
        <input name="paperLimitMonthly" type="number" min="0" defaultValue={plan?.paperLimitMonthly ?? 3} placeholder="Papers" className={inputClass} />
        <input name="aiGenerationLimitMonthly" type="number" min="0" defaultValue={plan?.aiGenerationLimitMonthly ?? 3} placeholder="AI generations" className={inputClass} />
        <input name="aiRegenerateLimitMonthly" type="number" min="0" defaultValue={plan?.aiRegenerateLimitMonthly ?? 3} placeholder="Regenerates" className={inputClass} />
        <input name="exportLimitMonthly" type="number" min="0" defaultValue={plan?.exportLimitMonthly ?? 5} placeholder="Exports" className={inputClass} />
        <input name="maxPagesPerPaper" type="number" min="0" defaultValue={plan?.maxPagesPerPaper ?? 10} placeholder="Max pages" className={inputClass} />
      </div>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {checkboxFields.map(([name, label]) => (
          <label key={`${prefix}-${name}`} className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <input name={name} type="checkbox" defaultChecked={plan ? Boolean(plan[name]) : name !== 'canUseImportantQuestions' && name !== 'canUseSelectiveRegenerate'} className="h-4 w-4" />
            {label}
          </label>
        ))}
      </div>
    </>
  );
}

export default async function AdminPlansPage() {
  const plans = await prisma.plan.findMany({
    include: { _count: { select: { subscriptions: true } } },
    orderBy: [{ sortOrder: 'asc' }, { priceMonthly: 'asc' }]
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Plans</h1>
        <p className="text-sm text-gray-600">Manage SaaS plans, limits, and feature access.</p>
      </div>

      <form action={createPlan} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Create Plan</h2>
        <PlanFields prefix="create" />
        <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Create Plan</button>
      </form>

      <div className="space-y-4">
        {plans.map((plan) => {
          const formId = `update-plan-${plan.id}`;
          return (
            <section key={plan.id} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-gray-950">{plan.name}</h2>
                  <p className="text-sm text-gray-500">{plan.slug} / {plan._count.subscriptions} subscriptions</p>
                </div>
                <span className={plan.isActive ? 'rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700' : 'rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-600'}>
                  {plan.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              <form id={formId} action={updatePlan} className="space-y-4">
                <input type="hidden" name="id" value={plan.id} />
                <PlanFields prefix={plan.id} plan={plan} />
              </form>
              <div className="flex flex-wrap gap-2">
                <button form={formId} type="submit" className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save</button>
                <form action={togglePlanStatus}>
                  <input type="hidden" name="id" value={plan.id} />
                  <button type="submit" className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
                    {plan.isActive ? 'Disable' : 'Enable'}
                  </button>
                </form>
                <form action={deletePlan}>
                  <input type="hidden" name="id" value={plan.id} />
                  <button type="submit" disabled={plan._count.subscriptions > 0} className="rounded-md border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50">
                    Delete
                  </button>
                </form>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
