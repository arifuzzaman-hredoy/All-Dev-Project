import DeleteButton from '@/components/admin/DeleteButton';
import { createSubject, deleteSubject, updateSubject } from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminSubjectsPage() {
  const [subjects, classes] = await Promise.all([
    prisma.subject.findMany({
      include: { classLevel: true },
      orderBy: [{ classLevel: { orderNo: 'asc' } }, { name: 'asc' }]
    }),
    prisma.classLevel.findMany({ orderBy: [{ orderNo: 'asc' }, { name: 'asc' }] })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Subjects</h1>
        <p className="text-sm text-gray-600">Manage subjects under each class.</p>
      </div>

      <form action={createSubject} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Subject</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-[1fr_220px_auto]">
          <input name="name" required placeholder="Mathematics" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <select name="classId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
            <option value="">Select class</option>
            {classes.map((classLevel) => (
              <option key={classLevel.id} value={classLevel.id}>{classLevel.name}</option>
            ))}
          </select>
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Add</button>
        </div>
      </form>

      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
        <table className="w-full min-w-[780px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Class</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {subjects.length === 0 ? (
              <tr><td colSpan={3} className="px-4 py-8 text-center text-gray-500">No subjects yet.</td></tr>
            ) : (
              subjects.map((subject) => (
                <tr key={subject.id}>
                  <td className="px-4 py-3">
                    <form id={`update-${subject.id}`} action={updateSubject} className="grid gap-3 md:grid-cols-[1fr_220px]">
                      <input type="hidden" name="id" value={subject.id} />
                      <input name="name" defaultValue={subject.name} required className="rounded-md border border-gray-300 px-3 py-2" />
                      <select name="classId" defaultValue={subject.classId} required className="rounded-md border border-gray-300 px-3 py-2">
                        {classes.map((classLevel) => (
                          <option key={classLevel.id} value={classLevel.id}>{classLevel.name}</option>
                        ))}
                      </select>
                    </form>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{subject.classLevel.name}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <button form={`update-${subject.id}`} className="rounded-md bg-gray-950 px-3 py-2 font-medium text-white hover:bg-gray-800">Save</button>
                      <form action={deleteSubject}>
                        <input type="hidden" name="id" value={subject.id} />
                        <DeleteButton />
                      </form>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
