import Link from 'next/link';
import React from 'react';
import { requireAdmin } from '@/lib/auth/session';

const navItems = [
  { href: '/admin', label: 'Admin Dashboard' },
  { href: '/admin/classes', label: 'Classes' },
  { href: '/admin/subjects', label: 'Subjects' },
  { href: '/admin/books', label: 'Books' },
  { href: '/admin/chapters', label: 'Chapters' },
  { href: '/admin/book-pages', label: 'Book Pages' },
  { href: '/admin/book-upload', label: 'Book File Upload' },
  { href: '/admin/questions', label: 'Important Questions' },
  { href: '/admin/users', label: 'Users' },
  { href: '/admin/schools', label: 'Schools' },
  { href: '/admin/plans', label: 'Plans' },
  { href: '/admin/subscriptions', label: 'Subscriptions' },
  { href: '/admin/payments', label: 'Payments' },
  { href: '/admin/source-documents', label: 'Source Documents' }
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();

  return (
    <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
      <aside className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm lg:sticky lg:top-8 lg:self-start">
        <div className="mb-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Admin</p>
          <h2 className="text-lg font-bold text-gray-950">Content Manager</h2>
        </div>
        <nav className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-100 hover:text-gray-950"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="min-w-0">{children}</main>
    </div>
  );
}
