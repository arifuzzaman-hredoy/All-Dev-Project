import DeleteButton from '@/components/admin/DeleteButton';
import { createChapter, deleteChapter, updateChapter } from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminChaptersPage() {
  const [chapters, books] = await Promise.all([
    prisma.chapter.findMany({
      include: { book: { include: { subject: true, classLevel: true } } },
      orderBy: [{ book: { title: 'asc' } }, { chapterNo: 'asc' }]
    }),
    prisma.book.findMany({
      include: { subject: true, classLevel: true },
      orderBy: { title: 'asc' }
    })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Chapters</h1>
        <p className="text-sm text-gray-600">Manage chapters for each book.</p>
      </div>

      <form action={createChapter} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Chapter</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-[140px_1fr]">
          <input name="chapterNo" type="number" min="1" required placeholder="No." className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <input name="title" required placeholder="Pattern" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <select name="bookId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2">
            <option value="">Select book</option>
            {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
          </select>
          <textarea name="summary" rows={3} placeholder="Summary" className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2" />
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:w-fit">Add Chapter</button>
        </div>
      </form>

      <div className="space-y-4">
        {chapters.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 shadow-sm">No chapters yet.</div>
        ) : (
          chapters.map((chapter) => (
            <div key={chapter.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <form id={`update-${chapter.id}`} action={updateChapter} className="grid gap-4 md:grid-cols-[140px_1fr]">
                <input type="hidden" name="id" value={chapter.id} />
                <input name="chapterNo" type="number" min="1" defaultValue={chapter.chapterNo} required className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <input name="title" defaultValue={chapter.title} required className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <select name="bookId" defaultValue={chapter.bookId} required className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2">
                  {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
                </select>
                <textarea name="summary" rows={3} defaultValue={chapter.summary ?? ''} className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2" />
              </form>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-gray-600">{chapter.book.title}</p>
                <div className="flex gap-2">
                  <button form={`update-${chapter.id}`} className="rounded-md bg-gray-950 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800">Save</button>
                  <form action={deleteChapter}>
                    <input type="hidden" name="id" value={chapter.id} />
                    <DeleteButton />
                  </form>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
