import DeleteButton from '@/components/admin/DeleteButton';
import { createBook, deleteBook, updateBook } from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminBooksPage() {
  const [books, classes, subjects] = await Promise.all([
    prisma.book.findMany({
      include: { classLevel: true, subject: { include: { classLevel: true } } },
      orderBy: { title: 'asc' }
    }),
    prisma.classLevel.findMany({ orderBy: [{ orderNo: 'asc' }, { name: 'asc' }] }),
    prisma.subject.findMany({ include: { classLevel: true }, orderBy: { name: 'asc' } })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Books</h1>
        <p className="text-sm text-gray-600">Manage book metadata and connect each book to class and subject.</p>
      </div>

      <form action={createBook} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Book</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          <input name="title" required placeholder="Class 8 Mathematics" className="rounded-md border border-gray-300 px-3 py-2 text-sm xl:col-span-2" />
          <input name="edition" placeholder="Edition" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <input name="publisher" placeholder="Publisher" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <select name="classId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
            <option value="">Class</option>
            {classes.map((classLevel) => <option key={classLevel.id} value={classLevel.id}>{classLevel.name}</option>)}
          </select>
          <select name="subjectId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm xl:col-span-2">
            <option value="">Subject</option>
            {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name} ({subject.classLevel.name})</option>)}
          </select>
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Add Book</button>
        </div>
      </form>

      <div className="space-y-4">
        {books.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 shadow-sm">No books yet.</div>
        ) : (
          books.map((book) => (
            <div key={book.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <form id={`update-${book.id}`} action={updateBook} className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
                <input type="hidden" name="id" value={book.id} />
                <input name="title" defaultValue={book.title} required className="rounded-md border border-gray-300 px-3 py-2 text-sm xl:col-span-2" />
                <input name="edition" defaultValue={book.edition ?? ''} placeholder="Edition" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <input name="publisher" defaultValue={book.publisher ?? ''} placeholder="Publisher" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <select name="classId" defaultValue={book.classId} required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
                  {classes.map((classLevel) => <option key={classLevel.id} value={classLevel.id}>{classLevel.name}</option>)}
                </select>
                <select name="subjectId" defaultValue={book.subjectId} required className="rounded-md border border-gray-300 px-3 py-2 text-sm xl:col-span-2">
                  {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name} ({subject.classLevel.name})</option>)}
                </select>
              </form>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-gray-600">{book.classLevel.name} / {book.subject.name}</p>
                <div className="flex gap-2">
                  <button form={`update-${book.id}`} className="rounded-md bg-gray-950 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800">Save</button>
                  <form action={deleteBook}>
                    <input type="hidden" name="id" value={book.id} />
                    <DeleteButton />
                  </form>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
