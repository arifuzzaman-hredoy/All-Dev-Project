import DeleteButton from '@/components/admin/DeleteButton';
import { createBookPage, deleteBookPage, updateBookPage } from '@/lib/actions/admin-content';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminBookPagesPage() {
  const [pages, books, chapters] = await Promise.all([
    prisma.bookPage.findMany({
      include: { book: true, chapter: true },
      orderBy: [{ book: { title: 'asc' } }, { pageNumber: 'asc' }]
    }),
    prisma.book.findMany({ include: { subject: true, classLevel: true }, orderBy: { title: 'asc' } }),
    prisma.chapter.findMany({ include: { book: true }, orderBy: [{ book: { title: 'asc' } }, { chapterNo: 'asc' }] })
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Book Pages</h1>
        <p className="text-sm text-gray-600">Store page-level source content for later AI generation.</p>
      </div>

      <form action={createBookPage} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Book Page</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <input name="pageNumber" type="number" min="1" required placeholder="Page number" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <input name="imageUrl" placeholder="Image URL (optional)" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
          <select name="bookId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
            <option value="">Select book</option>
            {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
          </select>
          <select name="chapterId" required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
            <option value="">Select chapter</option>
            {chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.book.title} - Ch {chapter.chapterNo}: {chapter.title}</option>)}
          </select>
          <textarea name="content" required rows={5} placeholder="Page content" className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2" />
          <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:w-fit">Add Page</button>
        </div>
      </form>

      <div className="space-y-4">
        {pages.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 shadow-sm">No book pages yet.</div>
        ) : (
          pages.map((page) => (
            <div key={page.id} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <form id={`update-${page.id}`} action={updateBookPage} className="grid gap-4 md:grid-cols-2">
                <input type="hidden" name="id" value={page.id} />
                <input name="pageNumber" type="number" min="1" defaultValue={page.pageNumber} required className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <input name="imageUrl" defaultValue={page.imageUrl ?? ''} placeholder="Image URL" className="rounded-md border border-gray-300 px-3 py-2 text-sm" />
                <select name="bookId" defaultValue={page.bookId} required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
                  {books.map((book) => <option key={book.id} value={book.id}>{book.title} ({book.classLevel.name}, {book.subject.name})</option>)}
                </select>
                <select name="chapterId" defaultValue={page.chapterId} required className="rounded-md border border-gray-300 px-3 py-2 text-sm">
                  {chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.book.title} - Ch {chapter.chapterNo}: {chapter.title}</option>)}
                </select>
                <textarea name="content" rows={5} defaultValue={page.content} required className="rounded-md border border-gray-300 px-3 py-2 text-sm md:col-span-2" />
              </form>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-gray-600">{page.book.title} / {page.chapter.title} / Page {page.pageNumber}</p>
                <div className="flex gap-2">
                  <button form={`update-${page.id}`} className="rounded-md bg-gray-950 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800">Save</button>
                  <form action={deleteBookPage}>
                    <input type="hidden" name="id" value={page.id} />
                    <DeleteButton />
                  </form>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
