import {
  deleteSourceDocument,
  importSourceDocumentPages,
  updateSourceDocument,
  uploadBookPdf
} from '@/lib/actions/book-pdf-upload';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 px-3 py-2 text-sm';
const smallButtonClass = 'rounded-md bg-gray-950 px-3 py-1.5 text-xs font-semibold text-white hover:bg-gray-800';
const dangerButtonClass = 'w-full rounded-md bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100';

function safeDecode(value?: string) {
  if (!value) return null;
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function preview(text?: string | null) {
  if (!text) return '-';
  return text.length > 900 ? `${text.slice(0, 900)}...` : text;
}

function extractedPageCount(value: unknown) {
  return Array.isArray(value) ? value.length : 0;
}

function statusClass(status: string) {
  if (status === 'SUCCESS') return 'bg-green-100 text-green-700';
  if (status === 'SCANNED_OR_EMPTY') return 'bg-amber-100 text-amber-700';
  if (status === 'FAILED') return 'bg-red-100 text-red-700';
  return 'bg-gray-100 text-gray-700';
}

function successText(value?: string) {
  if (!value) return null;
  if (value === 'metadata_updated') return 'Upload metadata updated successfully.';
  if (value === 'deleted') return 'Upload history removed successfully.';
  if (value === 'uploaded') return 'Book source file uploaded successfully.';
  if (value === 'imported') return 'Extracted pages imported successfully.';
  return safeDecode(value);
}

export default async function AdminBookUploadPage({
  searchParams
}: {
  searchParams?: { success?: string; error?: string; warning?: string };
}) {
  const [classes, subjects, books, chapters, documents] = await Promise.all([
    prisma.classLevel.findMany({ orderBy: [{ orderNo: 'asc' }, { name: 'asc' }] }),
    prisma.subject.findMany({ include: { classLevel: true }, orderBy: { name: 'asc' } }),
    prisma.book.findMany({ include: { classLevel: true, subject: true }, orderBy: { title: 'asc' } }),
    prisma.chapter.findMany({ include: { book: true }, orderBy: [{ book: { title: 'asc' } }, { chapterNo: 'asc' }] }),
    prisma.sourceDocument.findMany({
      where: { type: 'BOOK_PDF' },
      include: { classLevel: true, subject: true, book: true, chapter: true },
      orderBy: { createdAt: 'desc' },
      take: 30
    })
  ]);

  const successMessage = successText(searchParams?.success);
  const warningMessage = safeDecode(searchParams?.warning);
  const errorMessage = safeDecode(searchParams?.error);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Book File Upload</h1>
        <p className="text-sm text-gray-600">
          Upload PDF, DOCX, HTML, TXT, MD, or CSV files and import extracted content into BookPage records.
        </p>
        <p className="mt-2 rounded-md bg-blue-50 px-3 py-2 text-xs leading-5 text-blue-800">
          Tip: Scanned/image-based Bangla PDFs usually have no extractable text. Convert that PDF to HTML/DOCX/TXT first, then upload here. OCR will be a separate future feature.
        </p>
      </div>

      {successMessage ? <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm font-medium text-green-700">{successMessage}</div> : null}
      {warningMessage ? <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm font-medium text-amber-700">{warningMessage}</div> : null}
      {errorMessage ? <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700">{errorMessage}</div> : null}

      <form action={uploadBookPdf} className="grid gap-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2" encType="multipart/form-data">
        <input name="title" placeholder="Source title, example: Class 9 Physics Chapter 1" className={inputClass} />
        <input name="startPageNumber" type="number" min="1" required defaultValue={1} className={inputClass} />
        <select name="classId" required className={inputClass}>
          <option value="">Select class</option>
          {classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
        <select name="subjectId" required className={inputClass}>
          <option value="">Select subject</option>
          {subjects.map((item) => <option key={item.id} value={item.id}>{item.name} - {item.classLevel.name}</option>)}
        </select>
        <select name="bookId" required className={inputClass}>
          <option value="">Select book</option>
          {books.map((item) => <option key={item.id} value={item.id}>{item.title} - {item.classLevel.name} / {item.subject.name}</option>)}
        </select>
        <select name="chapterId" required className={inputClass}>
          <option value="">Select chapter</option>
          {chapters.map((item) => <option key={item.id} value={item.id}>{item.book.title} - Chapter {item.chapterNo}: {item.title}</option>)}
        </select>
        <select name="importMode" defaultValue="CREATE_BOOK_PAGES" className={inputClass}>
          <option value="CREATE_BOOK_PAGES">Create/replace book pages from extracted text</option>
          <option value="STORE_ONLY">Store source document only</option>
        </select>
        <label className="grid gap-1.5 text-sm font-medium text-gray-700">
          Book source file
          <input
            name="bookFile"
            type="file"
            accept="application/pdf,.pdf,.docx,.html,.htm,.txt,.md,.csv,text/plain,text/html,text/markdown,text/csv,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            required
            className={inputClass}
          />
          <span className="text-xs text-gray-500">Supported: PDF, DOCX, HTML, TXT, MD, CSV. Scanned images need OCR later.</span>
        </label>
        <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 md:col-span-2">Upload File</button>
      </form>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-gray-950">Recent Book Source Files / Upload History</h2>
            <p className="text-sm text-gray-600">Every upload is saved here. You can edit metadata, re-import extracted pages, or remove the upload history record.</p>
          </div>
          <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-700">{documents.length} records</span>
        </div>
        <div className="mt-4 space-y-4">
          {documents.length === 0 ? <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-600">No uploaded source documents yet.</p> : null}
          {documents.map((document) => (
            <div key={document.id} className="rounded-md border border-gray-200 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold text-gray-950">{document.title}</p>
                  <p className="text-xs text-gray-500">{document.originalFileName} / {document.mimeType ?? '-'} / {document.createdAt.toLocaleString()}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusClass(document.extractionStatus)}`}>{document.extractionStatus}</span>
                  <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                    {extractedPageCount(document.extractedPages)} pages
                  </span>
                </div>
              </div>

              {document.errorMessage ? <p className="mt-2 rounded bg-amber-50 p-2 text-xs font-medium text-amber-700">{document.errorMessage}</p> : null}

              <p className="mt-2 text-sm text-gray-600">{document.classLevel?.name ?? '-'} / {document.subject?.name ?? '-'} / {document.book?.title ?? '-'} / {document.chapter?.title ?? '-'}</p>
              <p className="mt-3 max-h-52 overflow-auto whitespace-pre-wrap rounded bg-gray-50 p-3 text-sm leading-6 text-gray-700">{preview(document.extractedText)}</p>

              <div className="mt-4 grid gap-4 border-t border-gray-100 pt-4 lg:grid-cols-[1fr_auto]">
                <form action={updateSourceDocument} className="grid gap-2 md:grid-cols-2">
                  <input type="hidden" name="documentId" value={document.id} />
                  <input name="title" defaultValue={document.title} className={inputClass} />
                  <select name="classId" defaultValue={document.classId ?? ''} required className={inputClass}>
                    {classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
                  </select>
                  <select name="subjectId" defaultValue={document.subjectId ?? ''} required className={inputClass}>
                    {subjects.map((item) => <option key={item.id} value={item.id}>{item.name} - {item.classLevel.name}</option>)}
                  </select>
                  <select name="bookId" defaultValue={document.bookId ?? ''} required className={inputClass}>
                    {books.map((item) => <option key={item.id} value={item.id}>{item.title} - {item.classLevel.name} / {item.subject.name}</option>)}
                  </select>
                  <select name="chapterId" defaultValue={document.chapterId ?? ''} required className={inputClass}>
                    {chapters.map((item) => <option key={item.id} value={item.id}>{item.book.title} - Chapter {item.chapterNo}: {item.title}</option>)}
                  </select>
                  <button type="submit" className={`${smallButtonClass} md:col-span-2`}>Save metadata changes</button>
                </form>

                <div className="space-y-2 lg:w-72">
                  <form action={importSourceDocumentPages} className="grid gap-2 rounded-md bg-gray-50 p-3">
                    <input type="hidden" name="documentId" value={document.id} />
                    <label className="text-xs font-semibold text-gray-600">Re-import into Book Pages from page</label>
                    <input name="startPageNumber" type="number" min="1" defaultValue={1} className={inputClass} />
                    <button type="submit" disabled={document.extractionStatus !== 'SUCCESS'} className="rounded-md bg-gray-950 px-3 py-1.5 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:bg-gray-300">
                      Import extracted pages
                    </button>
                  </form>
                  <form action={deleteSourceDocument}>
                    <input type="hidden" name="documentId" value={document.id} />
                    <button type="submit" className={dangerButtonClass}>Delete upload history</button>
                  </form>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
