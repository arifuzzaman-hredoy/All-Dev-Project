import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const cards = [
  { label: 'Total Classes', key: 'classes' },
  { label: 'Total Subjects', key: 'subjects' },
  { label: 'Total Books', key: 'books' },
  { label: 'Total Chapters', key: 'chapters' },
  { label: 'Total Book Pages', key: 'bookPages' },
  { label: 'Total Important Questions', key: 'questions' }
] as const;

export default async function AdminPage() {
  const [classes, subjects, books, chapters, bookPages, questions] = await Promise.all([
    prisma.classLevel.count(),
    prisma.subject.count(),
    prisma.book.count(),
    prisma.chapter.count(),
    prisma.bookPage.count(),
    prisma.importantQuestion.count()
  ]);

  const counts = { classes, subjects, books, chapters, bookPages, questions };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">Admin Dashboard</h1>
        <p className="text-sm text-gray-600">Manage the content backbone for question paper generation.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => (
          <div key={card.key} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-medium text-gray-500">{card.label}</p>
            <p className="mt-3 text-3xl font-bold text-gray-950">{counts[card.key]}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
