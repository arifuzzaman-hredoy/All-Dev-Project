import { NextResponse } from 'next/server';
import { testDeepSeek } from '@/lib/ai/deepseek';

export async function GET() {
  const prompt = 'Class 8 Mathematics Chapter 1 থেকে ৫টি MCQ তৈরি করুন। Return JSON only.';
  try {
    const aiRes = await testDeepSeek(prompt);
    return NextResponse.json({ success: true, data: aiRes });
  } catch (err: any) {
    const message = err?.message || 'Unknown error from AI service';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
