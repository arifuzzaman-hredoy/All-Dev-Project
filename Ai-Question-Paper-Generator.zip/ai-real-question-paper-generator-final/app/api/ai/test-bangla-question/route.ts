import { DifficultyLevel, ImportanceLevel, QuestionType } from '@prisma/client';
import { NextResponse } from 'next/server';
import { generateWithDeepSeek } from '@/lib/ai/deepseek';
import { parseAiQuestionPaperJson } from '@/lib/ai/parse-ai-json';
import { buildQuestionPaperPrompt } from '@/lib/ai/question-paper-prompt';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const messages = buildQuestionPaperPrompt({
      paperTitle: 'বাংলাদেশি স্টাইল প্রশ্নপত্র টেস্ট',
      className: 'Class 8',
      subjectName: 'Mathematics',
      bookTitle: 'Class 8 Mathematics',
      chapterTitle: 'Chapter 1: প্যাটার্ন',
      totalMarks: 24,
      durationMinutes: 45,
      selectedQuestionTypes: [QuestionType.MCQ, QuestionType.SHORT, QuestionType.CREATIVE],
      difficultyLevel: DifficultyLevel.MEDIUM,
      importanceLevel: ImportanceLevel.IMPORTANT,
      outputLanguage: 'BANGLA',
      extraInstruction: 'বাংলাদেশি স্কুল পরীক্ষার মতো MCQ, সংক্ষিপ্ত প্রশ্ন এবং সৃজনশীল প্রশ্ন তৈরি করুন।',
      referenceInstruction: 'আগের প্রশ্নের মতো মার্ক বণ্টন অনুসরণ করুন, কিন্তু সরাসরি কপি করবেন না।',
      useReferencePattern: true,
      bookPageContents: [
        {
          pageNumber: 1,
          content:
            'প্যাটার্ন হলো সংখ্যা, চিত্র বা বস্তুর এমন বিন্যাস যেখানে একটি নির্দিষ্ট নিয়ম অনুসরণ করা হয়। যেমন ২, ৪, ৬, ৮ ধারায় প্রতিটি পরের সংখ্যা আগের সংখ্যার চেয়ে ২ বেশি। আবার ৩, ৬, ৯, ১২ ধারায় প্রতিবার ৩ যোগ করা হয়েছে। প্যাটার্ন নির্ণয়ের মাধ্যমে পরবর্তী পদ বের করা যায়।'
        },
        {
          pageNumber: 2,
          content:
            'গাণিতিক প্যাটার্নে সাধারণ পদ নির্ণয় করা গুরুত্বপূর্ণ। যদি ধারাটি ৫, ১০, ১৫, ২০ হয়, তবে n-তম পদ ৫n। একইভাবে ৪, ৭, ১০, ১৩ ধারায় সাধারণ পার্থক্য ৩ এবং n-তম পদ 3n+1।'
        }
      ],
      importantQuestions: [
        {
          questionText: '২, ৫, ৮, ১১ ধারাটির সাধারণ পার্থক্য কত?',
          answerText: '৩',
          questionType: QuestionType.SHORT,
          difficultyLevel: DifficultyLevel.EASY,
          importanceLevel: ImportanceLevel.IMPORTANT,
          isBoardRepeated: false,
          isTeacherRecommended: true
        }
      ],
      referenceDocuments: [
        {
          title: 'নমুনা আগের প্রশ্ন',
          type: 'PREVIOUS_QUESTION',
          text: 'বহুনির্বাচনী ৪টি, সংক্ষিপ্ত ২টি এবং একটি সৃজনশীল প্রশ্ন থাকবে। সৃজনশীল প্রশ্নে বাস্তব জীবনের উদ্দীপক থাকবে।'
        }
      ]
    });

    const raw = await generateWithDeepSeek(messages, { maxTokens: 2500, temperature: 0.2 });
    const parsed = parseAiQuestionPaperJson(raw);

    return NextResponse.json(parsed);
  } catch (error) {
    console.error('Bangla question test failed:', error);
    return NextResponse.json({ error: 'Bangla question generation test failed.' }, { status: 500 });
  }
}
