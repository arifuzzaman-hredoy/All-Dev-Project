import {
  AlignmentType,
  Document,
  HeadingLevel,
  Packer,
  Paragraph,
  TextRun
} from 'docx';
import { UsageAction } from '@prisma/client';
import { NextResponse } from 'next/server';
import { canAccessPaper } from '@/lib/auth/access';
import { getCurrentUser } from '@/lib/auth/session';
import { assertFeatureAllowed, assertUsageAllowed, BillingError, recordUsage } from '@/lib/billing/subscription';
import { DEFAULT_BANGLA_PAPER_INSTRUCTIONS } from '@/lib/education/bd-question-standards';
import { safeFileName } from '@/lib/export/file-name';
import { getPaperExportData, PaperExportError, type ExportQuestion } from '@/lib/export/paper-export-data';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

function groupQuestions(questions: ExportQuestion[]) {
  const groups = new Map<string, { title: string; questionType: string; questions: ExportQuestion[] }>();

  for (const question of questions) {
    const title = question.sectionTitle || 'Questions';
    const key = `${title}-${question.questionType}`;
    const group = groups.get(key);

    if (group) group.questions.push(question);
    else groups.set(key, { title, questionType: question.questionType, questions: [question] });
  }

  return Array.from(groups.values());
}

const optionLabels = ['ক', 'খ', 'গ', 'ঘ'];

const sectionLabels: Record<string, string> = {
  MCQ: 'বহুনির্বাচনী প্রশ্ন',
  SHORT: 'সংক্ষিপ্ত প্রশ্ন',
  ONE_WORD: 'এক কথায় উত্তর',
  FILL_BLANK: 'শূন্যস্থান পূরণ',
  TRUE_FALSE: 'সত্য/মিথ্যা',
  CREATIVE: 'সৃজনশীল প্রশ্ন',
  BROAD: 'রচনামূলক/বর্ণনামূলক প্রশ্ন',
  MATH_PROBLEM: 'গাণিতিক সমস্যা',
  MATCHING: 'মিলকরণ'
};

function sectionHeading(questionType: string, fallback: string, index: number) {
  const sectionLetter = String.fromCharCode(65 + index);
  return `Section ${sectionLetter}: ${sectionLabels[questionType] ?? fallback}`;
}

function paragraph(text: string, options: { bold?: boolean; spacing?: number } = {}) {
  return new Paragraph({
    spacing: { after: options.spacing ?? 120 },
    children: [new TextRun({ text, bold: options.bold, font: 'Noto Sans Bengali' })]
  });
}

function questionParagraph(question: ExportQuestion, number: number) {
  return new Paragraph({
    spacing: { before: 120, after: 80 },
    children: [
      new TextRun({ text: `${number}. `, bold: true, font: 'Noto Sans Bengali' }),
      new TextRun({ text: question.questionText, font: 'Noto Sans Bengali' }),
      ...(question.marks ? [new TextRun({ text: ` [${question.marks}]`, bold: true, font: 'Noto Sans Bengali' })] : [])
    ]
  });
}

function optionParagraph(option: string, index: number) {
  return new Paragraph({
    indent: { left: 360 },
    spacing: { after: 60 },
    children: [
      new TextRun({ text: `${optionLabels[index] ?? index + 1}) `, bold: true, font: 'Noto Sans Bengali' }),
      new TextRun({ text: option, font: 'Noto Sans Bengali' })
    ]
  });
}

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

    const paperOwner = await prisma.questionPaper.findUnique({ where: { id: params.id }, select: { userId: true } });
    if (!paperOwner) return NextResponse.json({ error: 'Question paper not found.' }, { status: 404 });
    if (!canAccessPaper(user, paperOwner)) return NextResponse.json({ error: 'Access denied.' }, { status: 403 });

    const url = new URL(request.url);
    const copy = url.searchParams.get('copy') === 'teacher' ? 'teacher' : 'student';
    const includeAnswers = copy === 'teacher';
    if (includeAnswers) await assertFeatureAllowed(user.id, 'teacherCopy');
    await assertUsageAllowed(user.id, UsageAction.EXPORT_DOCX);
    const data = await getPaperExportData(params.id);
    const children: Paragraph[] = [];

    if (data.schoolName) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 120 },
          children: [new TextRun({ text: data.schoolName, bold: true, size: 28, font: 'Noto Sans Bengali' })]
        })
      );
    }
    const contact = [data.schoolAddress, data.schoolPhone, data.schoolEmail, data.schoolWebsite].filter(Boolean).join(' / ');
    if (contact) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 120 },
          children: [new TextRun({ text: contact, size: 20, font: 'Noto Sans Bengali' })]
        })
      );
    }

    children.push(
      new Paragraph({
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({ text: data.examTitle, bold: true, font: 'Noto Sans Bengali' })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 240 },
        children: [new TextRun({ text: includeAnswers ? 'Teacher Copy / উত্তরসহ' : 'Student Copy / শিক্ষার্থী কপি', bold: true, font: 'Noto Sans Bengali' })]
      }),
      paragraph(`প্রশ্নপত্র: ${data.title}`),
      paragraph(`শ্রেণি: ${data.className ?? '-'}    বিষয়: ${data.subjectName ?? '-'}`),
      paragraph(`বই: ${data.bookTitle ?? '-'}    অধ্যায়: ${data.chapterTitle ?? '-'}`),
      paragraph(`পূর্ণমান: ${data.totalMarks ?? '-'}    সময়: ${data.durationMinutes ? `${data.durationMinutes} মিনিট` : '-'}`)
    );
    if (data.teacherName) children.push(paragraph(`শিক্ষক: ${data.teacherName}`));
    if (data.headerNote) children.push(paragraph(data.headerNote));
    children.push(paragraph('নির্দেশনা:', { bold: true, spacing: 60 }));
    DEFAULT_BANGLA_PAPER_INSTRUCTIONS.forEach((instruction) => children.push(paragraph(`• ${instruction}`, { spacing: 40 })));
    children.push(paragraph('• ডান পাশে প্রশ্নের মান দেওয়া আছে।', { spacing: 120 }));

    let questionNumber = 1;
    for (const [groupIndex, group] of groupQuestions(data.questions).entries()) {
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 240, after: 120 },
          children: [new TextRun({ text: `${sectionHeading(group.questionType, group.title, groupIndex)} (${group.questionType})`, bold: true, font: 'Noto Sans Bengali' })]
        })
      );

      for (const question of group.questions) {
        children.push(questionParagraph(question, questionNumber++));
        question.options.forEach((option, index) => children.push(optionParagraph(option, index)));

        if (includeAnswers) {
          if (question.correctAnswer) children.push(paragraph(`সঠিক উত্তর: ${question.correctAnswer}`, { bold: true, spacing: 80 }));
          if (question.answerText) children.push(paragraph(`মডেল উত্তর: ${question.answerText}`, { spacing: 80 }));
          if (question.explanation) children.push(paragraph(`ব্যাখ্যা: ${question.explanation}`, { spacing: 120 }));
        }
      }
    }

    children.push(
      ...(data.signatureText ? [paragraph(data.signatureText, { bold: true, spacing: 240 })] : []),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 360 },
        children: [new TextRun({ text: data.footerText ?? 'Generated by Ai Real Question Paper Generator', size: 18, font: 'Noto Sans Bengali' })]
      })
    );

    const doc = new Document({
      sections: [{ children }]
    });
    const buffer = await Packer.toBuffer(doc);
    const filename = `${safeFileName(data.title)}-${copy}.docx`;
    await recordUsage(user.id, UsageAction.EXPORT_DOCX, params.id);

    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    if (error instanceof BillingError) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }

    if (error instanceof PaperExportError) {
      return NextResponse.json({ error: error.message }, { status: error.code === 'NOT_FOUND' ? 404 : 400 });
    }

    return NextResponse.json({ error: 'Could not export DOCX.' }, { status: 500 });
  }
}
