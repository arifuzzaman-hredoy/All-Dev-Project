import { NextResponse } from 'next/server';
import { UsageAction } from '@prisma/client';
import { canAccessPaper } from '@/lib/auth/access';
import { getCurrentUser } from '@/lib/auth/session';
import { assertFeatureAllowed, assertUsageAllowed, BillingError, recordUsage } from '@/lib/billing/subscription';
import { safeFileName } from '@/lib/export/file-name';
import { getPaperExportData, PaperExportError } from '@/lib/export/paper-export-data';
import { renderPaperHtml } from '@/lib/export/render-paper-html';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

    const paperOwner = await prisma.questionPaper.findUnique({ where: { id: params.id }, select: { userId: true } });
    if (!paperOwner) return NextResponse.json({ error: 'Question paper not found.' }, { status: 404 });
    if (!canAccessPaper(user, paperOwner)) return NextResponse.json({ error: 'Access denied.' }, { status: 403 });

    const url = new URL(request.url);
    const copy = url.searchParams.get('copy') === 'teacher' ? 'teacher' : 'student';
    if (copy === 'teacher') await assertFeatureAllowed(user.id, 'teacherCopy');
    await assertUsageAllowed(user.id, UsageAction.EXPORT_HTML);
    const data = await getPaperExportData(params.id);
    const html = renderPaperHtml(data, { includeAnswers: copy === 'teacher', mode: copy });
    const filename = `${safeFileName(data.title)}-${copy}.html`;
    await recordUsage(user.id, UsageAction.EXPORT_HTML, params.id);

    return new Response(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    if (error instanceof BillingError) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }

    if (error instanceof PaperExportError) {
      return NextResponse.json({ error: error.message }, { status: error.code === 'NOT_FOUND' ? 404 : 400 });
    }

    return NextResponse.json({ error: 'Could not export HTML.' }, { status: 500 });
  }
}
