import type React from 'react';
import { PaperTemplateStyle, SourceDocumentType } from '@prisma/client';
import { createDraftQuestionPaper } from '@/lib/actions/question-paper';
import {
  CONTENT_MODES,
  DIFFICULTY_LEVELS,
  IMPORTANCE_LEVELS,
  QUESTION_TYPES
} from '@/lib/constants/question-options';
import { requireUser } from '@/lib/auth/session';
import { bnLabels, bilingual } from '@/lib/i18n/labels';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 shadow-sm focus:border-gray-950 focus:outline-none focus:ring-1 focus:ring-gray-950';

function Section({
  title,
  description,
  children
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
      <div className="mb-5">
        <h2 className="text-lg font-semibold text-gray-950">{title}</h2>
        <p className="mt-1 text-sm text-gray-600">{description}</p>
      </div>
      {children}
    </section>
  );
}

function safeDecode(value: string) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

export default async function CreatePaperPage({
  searchParams
}: {
  searchParams?: { error?: string; success?: string };
}) {
  const user = await requireUser();
  const userWithSchool = await prisma.user.findUnique({
    where: { id: user.id },
    include: { school: true }
  });
  const school = userWithSchool?.school ?? null;

  const [classes, subjects, books, chapters] = await Promise.all([
    prisma.classLevel.findMany({ orderBy: [{ orderNo: 'asc' }, { name: 'asc' }] }),
    prisma.subject.findMany({ include: { classLevel: true }, orderBy: [{ classLevel: { orderNo: 'asc' } }, { name: 'asc' }] }),
    prisma.book.findMany({
      include: { classLevel: true, subject: true },
      orderBy: [{ classLevel: { orderNo: 'asc' } }, { title: 'asc' }]
    }),
    prisma.chapter.findMany({
      include: { book: true },
      orderBy: [{ book: { title: 'asc' } }, { chapterNo: 'asc' }]
      })
  ]);
  const errorMessage = searchParams?.error ? safeDecode(searchParams.error) : null;
  const successMessage = searchParams?.success ? safeDecode(searchParams.success) : null;
  const showDebugInfo = process.env.NODE_ENV !== 'production';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-950">প্রশ্নপত্র তৈরি করুন</h1>
          <p className="mt-1 text-sm text-gray-600">
            বই/অধ্যায়, প্রশ্নের ধরন, টেমপ্লেট এবং রেফারেন্স দিয়ে একটি ড্রাফট প্রশ্নপত্র তৈরি করুন।
          </p>
        </div>
      </div>

      {errorMessage ? <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700">{errorMessage}</div> : null}
      {successMessage ? <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm font-medium text-green-700">{successMessage}</div> : null}

      {showDebugInfo ? (
        <div className="rounded-md border border-gray-200 bg-gray-50 p-3 text-xs font-medium text-gray-600">
          Database debug: {classes.length} classes loaded, {subjects.length} subjects loaded, {books.length} books loaded, {chapters.length} chapters loaded.
        </div>
      ) : null}

      <form action={createDraftQuestionPaper} className="space-y-6" encType="multipart/form-data">
        <Section title="একাডেমিক তথ্য" description="ক্লাস, বিষয়, বই এবং অধ্যায় নির্বাচন করুন।">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              {bilingual('ক্লাস নির্বাচন করুন', 'Select Class')}
              <select name="classId" required className={inputClass}>
                <option value="">Select class</option>
                {classes.map((classLevel) => (
                  <option key={classLevel.id} value={classLevel.id}>
                    {classLevel.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              {bilingual('বিষয় নির্বাচন করুন', 'Select Subject')}
              <select name="subjectId" required className={inputClass}>
                <option value="">Select subject</option>
                {subjects.map((subject) => (
                  <option key={subject.id} value={subject.id}>
                    {subject.name} - {subject.classLevel.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              {bilingual('বই নির্বাচন করুন', 'Select Book')}
              <select name="bookId" required className={inputClass}>
                <option value="">Select book</option>
                {books.map((book) => (
                  <option key={book.id} value={book.id}>
                    {book.title} - {book.classLevel.name} / {book.subject.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              {bilingual('অধ্যায় নির্বাচন করুন', 'Select Chapter')}
              <select name="chapterId" required className={inputClass}>
                <option value="">Select chapter</option>
                {chapters.map((chapter) => (
                  <option key={chapter.id} value={chapter.id}>
                    Chapter {chapter.chapterNo}: {chapter.title} - {chapter.book.title}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </Section>

        <Section title="কনটেন্ট নির্বাচন" description="কোন পৃষ্ঠা বা অধ্যায়ের কনটেন্ট ব্যবহার হবে সেটি ঠিক করুন।">
          <div className="grid gap-4 md:grid-cols-[1fr_180px_180px]">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              কনটেন্ট মোড
              <select name="contentMode" required defaultValue="FULL_CHAPTER" className={inputClass}>
                {CONTENT_MODES.map((mode) => (
                  <option key={mode.value} value={mode.value}>
                    {bnLabels.contentModes[mode.value as keyof typeof bnLabels.contentModes]} ({mode.label})
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              পৃষ্ঠা শুরু
              <input name="pageFrom" type="number" min="1" placeholder="1" className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              পৃষ্ঠা শেষ
              <input name="pageTo" type="number" min="1" placeholder="10" className={inputClass} />
            </label>
          </div>
        </Section>

        <Section title="প্রশ্নের ধরন" description="নম্বর, সময় এবং কোন ধরনের প্রশ্ন থাকবে সেটি নির্বাচন করুন।">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              মোট নম্বর
              <input name="totalMarks" type="number" min="1" placeholder="100" className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              সময় (মিনিট)
              <input name="durationMinutes" type="number" min="1" placeholder="180" className={inputClass} />
            </label>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {QUESTION_TYPES.map((type) => (
              <label key={type.value} className="flex items-center gap-3 rounded-md border border-gray-200 px-3 py-2 text-sm font-medium text-gray-700">
                <input name="selectedQuestionTypes" value={type.value} type="checkbox" className="h-4 w-4 rounded border-gray-300" />
                {bnLabels.questionTypes[type.value as keyof typeof bnLabels.questionTypes]} ({type.label})
              </label>
            ))}
          </div>
        </Section>

        <Section title="প্রশ্নপত্রের পরিচয় ও টেমপ্লেট" description="পরীক্ষার নাম, শিক্ষক, হেডার/ফুটার এবং প্রিন্ট স্টাইল ঠিক করুন।">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              পরীক্ষার নাম
              <input name="examTitle" placeholder="First Terminal Examination 2026" className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              শিক্ষকের নাম
              <input name="teacherName" defaultValue={user.name ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              টেমপ্লেট স্টাইল
              <select name="templateStyle" defaultValue={PaperTemplateStyle.CLASSIC} className={inputClass}>
                {Object.values(PaperTemplateStyle).map((style) => (
                  <option key={style} value={style}>{bnLabels.templateStyles[style]} ({style.replaceAll('_', ' ')})</option>
                ))}
              </select>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              ওয়াটারমার্ক
              <input name="watermarkText" defaultValue={school?.watermarkText ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              আউটপুট ভাষা
              <select name="outputLanguage" defaultValue="BANGLA" className={inputClass}>
                <option value="BANGLA">বাংলা</option>
                <option value="ENGLISH">English</option>
                <option value="AUTO">Auto detect</option>
              </select>
              <span className="text-xs text-gray-500">বাংলাদেশি প্রশ্নপত্রের স্টাইল অনুসরণ করে প্রশ্ন তৈরি হবে।</span>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              হেডার নোট
              <textarea name="headerNote" rows={2} defaultValue={school?.defaultHeaderNote ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              ফুটার টেক্সট
              <textarea name="footerText" rows={2} defaultValue={school?.defaultFooterText ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              স্বাক্ষর টেক্সট
              <input name="signatureText" defaultValue={school?.defaultSignatureText ?? ''} className={inputClass} />
            </label>
          </div>
        </Section>

        <Section title="কঠিন/সহজ লেভেল" description="প্রশ্ন কতটা সহজ বা কঠিন হবে সেটি নির্বাচন করুন।">
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:max-w-md">
            লেভেল
            <select name="difficultyLevel" required defaultValue="MEDIUM" className={inputClass}>
              {DIFFICULTY_LEVELS.map((level) => (
                <option key={level.value} value={level.value}>
                  {bnLabels.difficultyLevels[level.value as keyof typeof bnLabels.difficultyLevels]} ({level.label})
                </option>
              ))}
            </select>
          </label>
        </Section>

        <Section title="গুরুত্বপূর্ণ প্রশ্ন সেটিং" description="সাধারণ, গুরুত্বপূর্ণ বা বোর্ডে আসা প্রশ্নকে অগ্রাধিকার দিন।">
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:max-w-md">
            গুরুত্ব
            <select name="importanceLevel" required defaultValue="NORMAL" className={inputClass}>
              {IMPORTANCE_LEVELS.map((level) => (
                <option key={level.value} value={level.value}>
                  {bnLabels.importanceLevels[level.value as keyof typeof bnLabels.importanceLevels]} ({level.label})
                </option>
              ))}
            </select>
          </label>
        </Section>

        <Section title="আগের প্রশ্ন/রেফারেন্স আপলোড" description="আগের প্রশ্ন বা রেফারেন্স ফাইল দিলে AI একই প্যাটার্ন/স্টাইল বিশ্লেষণ করতে পারবে।">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              রেফারেন্স শিরোনাম
              <input name="referenceTitle" placeholder="SSC Test Paper 2025" className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              রেফারেন্স ধরন
              <select name="referenceType" defaultValue={SourceDocumentType.PREVIOUS_QUESTION} className={inputClass}>
                <option value={SourceDocumentType.PREVIOUS_QUESTION}>আগের প্রশ্ন (Previous Question)</option>
                <option value={SourceDocumentType.REFERENCE_NOTE}>রেফারেন্স নোট (Reference Note)</option>
              </select>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              রেফারেন্স ফাইল আপলোড
              <input name="referenceFile" type="file" accept="application/pdf,.pdf,.docx,.txt,.md,.csv,text/plain,text/markdown,text/csv,application/vnd.openxmlformats-officedocument.wordprocessingml.document" className={inputClass} />
              <span className="text-xs text-gray-500">PDF, DOCX, TXT, MD, CSV সাপোর্ট করে। স্ক্যান/ইমেজ ফাইলের OCR পরে যোগ করা হবে।</span>
            </label>
            <label className="flex items-center gap-3 rounded-md border border-gray-200 px-3 py-2 text-sm font-medium text-gray-700 md:col-span-2">
              <input name="useReferencePattern" type="checkbox" className="h-4 w-4" />
              AI will analyze uploaded previous question and follow similar pattern
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              রেফারেন্স নির্দেশনা
              <textarea
                name="referenceInstruction"
                rows={4}
                placeholder="এই আগের প্রশ্নের প্রশ্নের ধরন, মার্ক বণ্টন, ভাষা ও স্টাইল অনুসরণ করে নতুন প্রশ্ন বানান। সরাসরি কপি করবেন না।"
                className={inputClass}
              />
            </label>
          </div>
        </Section>

        <Section title="শিক্ষকের অতিরিক্ত নির্দেশনা" description="AI প্রশ্ন তৈরি করার সময় যে নির্দেশনা অনুসরণ করবে।">
          <textarea
            name="extraInstruction"
            rows={5}
            placeholder="অনুশীলনী ১.১ এর ১, ৪, ৭ নম্বর math থেকে বেশি question দিন।"
            className={`${inputClass} w-full`}
          />
          <div className="mt-3 grid gap-2 text-xs text-gray-600 sm:grid-cols-2">
            <p>উদাহরণ: প্রশ্নগুলো বোর্ড পরীক্ষার মতো করুন।</p>
            <p>উদাহরণ: MCQ গুলো একটু কঠিন করুন।</p>
            <p>উদাহরণ: সৃজনশীল প্রশ্নে উদ্দীপক অবশ্যই দিন।</p>
            <p>উদাহরণ: অনুশীলনী ১.১ এর ১, ৪, ৭ নম্বর অংক থেকে বেশি প্রশ্ন দিন।</p>
            <p className="sm:col-span-2">উদাহরণ: আগের প্রশ্নের মতো মার্ক বণ্টন অনুসরণ করুন, কিন্তু সরাসরি কপি করবেন না।</p>
          </div>
        </Section>

        <div className="flex flex-col items-end gap-2">
          <button type="submit" className="rounded-md bg-gray-950 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-gray-800">
            Create Draft Paper
          </button>
          <p className="text-xs text-gray-500">After creating a draft, you will be redirected to the paper details page.</p>
        </div>
      </form>
    </div>
  );
}
