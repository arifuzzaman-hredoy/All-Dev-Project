import { updateSchoolBranding } from '@/lib/actions/branding';
import { requireUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const inputClass = 'rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 shadow-sm';

function safeDecode(value?: string) {
  if (!value) return null;
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

export default async function BrandingPage({
  searchParams
}: {
  searchParams?: { success?: string; error?: string };
}) {
  const user = await requireUser();
  const currentUser = await prisma.user.findUnique({
    where: { id: user.id },
    include: { school: true }
  });
  const school = currentUser?.school ?? null;
  const successMessage = searchParams?.success === 'branding_updated' ? 'Branding updated successfully.' : null;
  const errorMessage = safeDecode(searchParams?.error);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">প্রতিষ্ঠানের ব্র্যান্ডিং</h1>
        <p className="mt-1 text-sm text-gray-600">প্রিন্ট ও এক্সপোর্টেড প্রশ্নপত্রে ব্যবহৃত স্কুল/কোচিং তথ্য সেট করুন।</p>
      </div>

      {successMessage ? <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm font-medium text-green-700">{successMessage}</div> : null}
      {errorMessage ? <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700">{errorMessage}</div> : null}

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <form action={updateSchoolBranding} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
          <input type="hidden" name="schoolId" value={school?.id ?? ''} />
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              Institution name
              <input name="name" required defaultValue={school?.name ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              Logo URL
              <input name="logoUrl" defaultValue={school?.logoUrl ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              Phone
              <input name="phone" defaultValue={school?.phone ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700">
              Email
              <input name="email" type="email" defaultValue={school?.email ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Website
              <input name="website" defaultValue={school?.website ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Address
              <textarea name="address" rows={2} defaultValue={school?.address ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Watermark text
              <input name="watermarkText" defaultValue={school?.watermarkText ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Default header note
              <textarea name="defaultHeaderNote" rows={2} defaultValue={school?.defaultHeaderNote ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Default footer text
              <textarea name="defaultFooterText" rows={2} defaultValue={school?.defaultFooterText ?? ''} className={inputClass} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
              Default signature text
              <input name="defaultSignatureText" defaultValue={school?.defaultSignatureText ?? ''} className={inputClass} />
            </label>
          </div>
          <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save Branding</button>
        </form>

        <aside className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold uppercase text-gray-500">Preview</p>
          <div className="mt-4 rounded-md border border-gray-200 p-5 text-center">
            {school?.logoUrl ? <img src={school.logoUrl} alt="" className="mx-auto mb-3 h-14 w-14 object-contain" /> : null}
            <h2 className="text-xl font-bold text-gray-950">{school?.name || 'Institution name'}</h2>
            <p className="mt-2 text-sm text-gray-600">{school?.address || 'Address'}</p>
            <p className="mt-1 text-xs text-gray-500">{[school?.phone, school?.email, school?.website].filter(Boolean).join(' / ') || 'Contact details'}</p>
            <div className="mt-5 rounded-md bg-gray-50 p-3 text-sm text-gray-600">{school?.defaultHeaderNote || 'Header note preview'}</div>
            <p className="mt-5 text-xs text-gray-500">{school?.defaultFooterText || 'Footer text preview'}</p>
            <p className="mt-6 border-t border-gray-200 pt-3 text-sm font-semibold text-gray-700">{school?.defaultSignatureText || 'Signature text'}</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
