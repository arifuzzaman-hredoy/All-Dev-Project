import Link from 'next/link';
import { PaperStatus } from '@prisma/client';
import { isAdminRole, requireUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const user = await requireUser();
  const paperWhere = isAdminRole(user.role) ? {} : { userId: user.id };

  const [totalPapers, draftPapers, generatedPapers, approvedPapers] = await Promise.all([
    prisma.questionPaper.count({ where: paperWhere }),
    prisma.questionPaper.count({ where: { ...paperWhere, status: PaperStatus.DRAFT } }),
    prisma.questionPaper.count({ where: { ...paperWhere, status: PaperStatus.GENERATED } }),
    prisma.questionPaper.count({ where: { ...paperWhere, status: PaperStatus.APPROVED } })
  ]);

  const stats = [
    { label: 'Total papers', value: totalPapers },
    { label: 'Draft papers', value: draftPapers },
    { label: 'Generated papers', value: generatedPapers },
    { label: 'Approved papers', value: approvedPapers }
  ];

  const actions = [
    { title: 'Create Question Paper', description: 'Start a new draft from saved content.', href: '/dashboard/create-paper' },
    { title: 'My Papers', description: 'Review saved drafts and generated papers.', href: '/dashboard/papers' },
    { title: 'Branding', description: 'Manage institution header, footer, logo, and paper defaults.', href: '/dashboard/branding' },
    { title: 'Billing', description: 'View your current plan, limits, and usage.', href: '/dashboard/billing' },
    ...(isAdminRole(user.role) ? [{ title: 'Admin Content', description: 'Manage classes, books, chapters, pages, and questions.', href: '/admin' }] : [])
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">ড্যাশবোর্ড</h1>
        <p className="mt-1 text-sm text-gray-600">আপনার প্রশ্নপত্র ও ব্যবহার সংক্ষেপে দেখুন।</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-medium text-gray-500">{stat.label}</p>
            <p className="mt-3 text-3xl font-bold text-gray-950">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {actions.map((action) => (
          <Link key={action.href} href={action.href} className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm hover:border-gray-300 hover:bg-gray-50">
            <h2 className="text-lg font-semibold text-gray-950">{action.title}</h2>
            <p className="mt-2 text-sm leading-6 text-gray-600">{action.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
