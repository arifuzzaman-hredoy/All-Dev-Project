import Link from 'next/link';
import { requireUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

export default async function DashboardSettingsPage() {
  const user = await requireUser();
  const currentUser = await prisma.user.findUnique({
    where: { id: user.id },
    include: { school: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Current User</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div>
            <p className="text-xs font-semibold uppercase text-gray-500">Name</p>
            <p className="mt-1 text-sm font-medium text-gray-950">{user.name ?? '-'}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-500">Email</p>
            <p className="mt-1 text-sm font-medium text-gray-950">{user.email}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-500">Role</p>
            <p className="mt-1 text-sm font-medium text-gray-950">{user.role}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-500">School / Institution</p>
            <p className="mt-1 text-sm font-medium text-gray-950">{currentUser?.school?.name ?? '-'}</p>
          </div>
        </div>
        <Link href="/dashboard/branding" className="mt-5 inline-flex rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
          Manage Branding
        </Link>
      </section>
    </div>
  );
}
