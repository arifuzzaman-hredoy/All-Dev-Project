import Link from 'next/link';
import { notFound } from 'next/navigation';
import PrintButton from '@/components/export/PrintButton';
import { requirePaperAccess } from '@/lib/auth/access';
import { DEFAULT_BANGLA_PAPER_INSTRUCTIONS } from '@/lib/education/bd-question-standards';
import { getPaperExportData, PaperExportError, type ExportQuestion } from '@/lib/export/paper-export-data';

export const dynamic = 'force-dynamic';

function optionsList(question: ExportQuestion) {
  return question.options ?? [];
}

function groupQuestions(questions: ExportQuestion[]) {
  const groups = new Map<string, { title: string; questionType: string; questions: ExportQuestion[] }>();

  for (const question of questions) {
    const title = question.sectionTitle || 'Questions';
    const key = `${title}-${question.questionType}`;
    const group = groups.get(key);

    if (group) group.questions.push(question);
    else groups.set(key, { title, questionType: question.questionType, questions: [question] });
  }

  return Array.from(groups.values());
}

const optionLabels = ['ক', 'খ', 'গ', 'ঘ'];

const sectionLabels: Record<string, string> = {
  MCQ: 'বহুনির্বাচনী প্রশ্ন',
  SHORT: 'সংক্ষিপ্ত প্রশ্ন',
  ONE_WORD: 'এক কথায় উত্তর',
  FILL_BLANK: 'শূন্যস্থান পূরণ',
  TRUE_FALSE: 'সত্য/মিথ্যা',
  CREATIVE: 'সৃজনশীল প্রশ্ন',
  BROAD: 'রচনামূলক/বর্ণনামূলক প্রশ্ন',
  MATH_PROBLEM: 'গাণিতিক সমস্যা',
  MATCHING: 'মিলকরণ'
};

function sectionHeading(questionType: string, fallback: string, index: number) {
  const sectionLetter = String.fromCharCode(65 + index);
  return `Section ${sectionLetter}: ${sectionLabels[questionType] ?? fallback}`;
}

export default async function PrintablePaperPage({
  params,
  searchParams
}: {
  params: { id: string };
  searchParams?: { copy?: string };
}) {
  await requirePaperAccess(params.id);

  const copy = searchParams?.copy === 'teacher' ? 'teacher' : 'student';
  const includeAnswers = copy === 'teacher';

  let data;
  try {
    data = await getPaperExportData(params.id);
  } catch (error) {
    if (error instanceof PaperExportError && error.code === 'NOT_FOUND') notFound();

    return (
      <div className="mx-auto max-w-3xl space-y-4 py-12">
        <h1 className="text-2xl font-bold text-gray-950">No generated questions found</h1>
        <p className="text-sm text-gray-600">Generate or add questions before opening the printable copy.</p>
        <Link href={`/dashboard/papers/${params.id}`} className="inline-flex rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
          Back to Paper
        </Link>
      </div>
    );
  }

  const groups = groupQuestions(data.questions);
  let questionNumber = 1;
  const contact = [data.schoolAddress, data.schoolPhone, data.schoolEmail, data.schoolWebsite].filter(Boolean).join(' / ');

  return (
    <div className="bg-gray-100 print:bg-white">
      <div className="no-print mx-auto flex w-full max-w-[210mm] gap-3 px-4 py-4">
        <Link href={`/dashboard/papers/${data.id}`} className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
          Back to Paper
        </Link>
        <PrintButton />
      </div>

      <main className="relative mx-auto min-h-[297mm] w-full max-w-[210mm] overflow-hidden bg-white p-8 shadow-lg print:min-h-0 print:max-w-none print:p-0 print:shadow-none">
        {data.watermarkText ? <div className="pointer-events-none fixed inset-x-0 top-1/3 -rotate-12 text-center text-6xl font-black text-gray-950/5">{data.watermarkText}</div> : null}
        <div className="relative z-10">
        <header className={data.templateStyle === 'BOARD_EXAM' ? 'border-2 border-gray-950 p-5 text-center' : 'border-b border-gray-300 pb-5 text-center'}>
          {data.schoolLogoUrl ? <img src={data.schoolLogoUrl} alt="" className="mx-auto mb-2 h-14 max-w-24 object-contain" /> : null}
          {data.schoolName ? <div className="text-xl font-extrabold text-gray-950">{data.schoolName}</div> : null}
          {contact ? <div className="mt-1 text-xs text-gray-600">{contact}</div> : null}
          <h1 className="mt-2 text-2xl font-bold text-gray-950">{data.examTitle}</h1>
          <p className="text-sm text-gray-600">{data.title}</p>
          <div className="mt-2 inline-flex rounded-full border border-gray-300 px-3 py-1 text-xs font-semibold uppercase text-gray-600">
            {includeAnswers ? 'Teacher Copy / উত্তরসহ' : 'Student Copy / শিক্ষার্থী কপি'}
          </div>
          <div className="mt-4 grid gap-2 text-left text-sm text-gray-700 sm:grid-cols-2">
            <div><strong>শ্রেণি:</strong> {data.className ?? '-'}</div>
            <div><strong>বিষয়:</strong> {data.subjectName ?? '-'}</div>
            <div><strong>বই:</strong> {data.bookTitle ?? '-'}</div>
            <div><strong>অধ্যায়:</strong> {data.chapterTitle ?? '-'}</div>
            <div><strong>পূর্ণমান:</strong> {data.totalMarks ?? '-'}</div>
            <div><strong>সময়:</strong> {data.durationMinutes ? `${data.durationMinutes} মিনিট` : '-'}</div>
            {data.teacherName ? <div><strong>শিক্ষক:</strong> {data.teacherName}</div> : null}
          </div>
          {data.headerNote ? <p className="mt-4 rounded border border-gray-200 bg-gray-50 p-2 text-left text-sm text-gray-700">{data.headerNote}</p> : null}
          <div className="mt-4 rounded border border-gray-200 bg-gray-50 p-3 text-left text-sm text-gray-700">
            <p className="font-semibold">নির্দেশনা:</p>
            <ul className="mt-1 list-disc pl-5">
              {DEFAULT_BANGLA_PAPER_INSTRUCTIONS.map((instruction) => (
                <li key={instruction}>{instruction}</li>
              ))}
              <li>ডান পাশে প্রশ্নের মান দেওয়া আছে।</li>
            </ul>
          </div>
        </header>

        <div className="mt-6 space-y-6">
          {groups.map((group, groupIndex) => (
            <section key={`${group.title}-${group.questionType}`} className="space-y-3">
              <h2 className="border-b border-gray-200 pb-2 text-lg font-semibold text-gray-950">
                {sectionHeading(group.questionType, group.title, groupIndex)} <span className="text-xs font-medium text-gray-500">{group.questionType}</span>
              </h2>
              {group.questions.map((question) => {
                const currentNumber = questionNumber++;
                const options = optionsList(question);

                return (
                  <div key={`${question.orderIndex}-${currentNumber}`} className="break-inside-avoid border-b border-dashed border-gray-200 pb-4">
                    <div className="flex items-start gap-3">
                      <p className="flex-1 whitespace-pre-wrap text-sm leading-6 text-gray-950">
                        <strong>{currentNumber}.</strong> {question.questionText}
                      </p>
                      {question.marks ? <span className="min-w-10 text-right text-sm font-semibold text-gray-950">{question.marks}</span> : null}
                    </div>
                    {options.length > 0 ? (
                      <ol className="mt-2 grid gap-1 pl-6 text-sm text-gray-700">
                        {options.map((option, index) => (
                          <li key={`${currentNumber}-${index}`}>
                            <strong>{optionLabels[index] ?? index + 1})</strong> {option}
                          </li>
                        ))}
                      </ol>
                    ) : null}
                    {includeAnswers ? (
                      <div className="mt-3 border-l-4 border-gray-900 bg-gray-50 p-3 text-sm leading-6 text-gray-700">
                        {question.correctAnswer ? <p><strong>সঠিক উত্তর:</strong> {question.correctAnswer}</p> : null}
                        {question.answerText ? <p className="whitespace-pre-wrap"><strong>মডেল উত্তর:</strong> {question.answerText}</p> : null}
                        {question.explanation ? <p className="whitespace-pre-wrap"><strong>ব্যাখ্যা:</strong> {question.explanation}</p> : null}
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </section>
          ))}
        </div>

        <footer className="mt-8 border-t border-gray-200 pt-3 text-center text-xs text-gray-500">
          {data.signatureText ? <div className="mb-8 flex justify-end text-sm text-gray-700"><span className="min-w-44 border-t border-gray-400 pt-2">{data.signatureText}</span></div> : null}
          {data.footerText ?? 'Generated by Ai Real Question Paper Generator'}
        </footer>
        </div>
      </main>
    </div>
  );
}
