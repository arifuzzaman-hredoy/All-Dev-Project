import type React from 'react';
import Link from 'next/link';
import { PaperTemplateStyle } from '@prisma/client';
import { notFound } from 'next/navigation';
import { updatePaperTemplate } from '@/lib/actions/branding';
import { generateQuestionPaperWithAI } from '@/lib/actions/ai-generation';
import {
  addManualGeneratedQuestion,
  deleteGeneratedQuestion,
  moveGeneratedQuestion,
  regenerateSingleQuestionWithAI,
  updateGeneratedQuestion
} from '@/lib/actions/generated-question';
import { requirePaperAccess } from '@/lib/auth/access';
import { DIFFICULTY_LEVELS, IMPORTANCE_LEVELS, QUESTION_TYPES } from '@/lib/constants/question-options';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

type PagePreview = {
  pageNumber?: number | null;
  content?: string | null;
};

type ImportantQuestionPreview = {
  questionText?: string | null;
  answerText?: string | null;
  questionType?: string | null;
  difficultyLevel?: string | null;
  importanceLevel?: string | null;
  pageNumber?: number | null;
  exerciseNo?: string | null;
  questionNo?: string | null;
  isBoardRepeated?: boolean | null;
  isTeacherRecommended?: boolean | null;
};

type PaperSettings = {
  contentMode?: string;
  pageFrom?: number | null;
  pageTo?: number | null;
  selectedQuestionTypes?: string[];
  difficultyLevel?: string;
  importanceLevel?: string;
  extraInstruction?: string;
  retrievedPageCount?: number;
  retrievedImportantQuestionCount?: number;
  retrievedContentPreview?: PagePreview[];
  retrievedImportantQuestionsPreview?: ImportantQuestionPreview[];
  referenceInstruction?: string;
  referenceExtractionStatus?: string;
  referenceTextPreview?: string | null;
  useReferencePattern?: boolean;
};

const inputClass = 'rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 shadow-sm focus:border-gray-950 focus:outline-none focus:ring-1 focus:ring-gray-950';

const successMessages: Record<string, string> = {
  draft_created: 'Draft paper created successfully.',
  template_updated: 'Paper template updated successfully.',
  question_updated: 'Question updated successfully.',
  question_deleted: 'Question deleted successfully.',
  question_added: 'Manual question added successfully.',
  question_moved: 'Question order updated successfully.',
  question_regenerated: 'Question regenerated successfully.'
};

const errorMessages: Record<string, string> = {
  ai_generation_failed: 'AI generation failed. Check the latest generation log below, then try again.',
  question_update_failed: 'Question update failed. Please check the fields and try again.',
  question_delete_failed: 'Question delete failed. Please try again.',
  question_add_failed: 'Question add failed. Please check the fields and try again.',
  question_move_failed: 'Question move failed. Please try again.',
  question_regenerate_failed: 'Question regeneration failed. The old question was kept unchanged.',
  plan_limit_reached: 'Your plan limit has been reached. Please upgrade your plan.'
};

const banglaOptionLabels = ['ক', 'খ', 'গ', 'ঘ'];

const banglaSectionLabels: Record<string, string> = {
  MCQ: 'বহুনির্বাচনী প্রশ্ন',
  SHORT: 'সংক্ষিপ্ত প্রশ্ন',
  ONE_WORD: 'এক কথায় উত্তর',
  FILL_BLANK: 'শূন্যস্থান পূরণ',
  TRUE_FALSE: 'সত্য/মিথ্যা',
  CREATIVE: 'সৃজনশীল প্রশ্ন',
  BROAD: 'রচনামূলক/বর্ণনামূলক প্রশ্ন',
  MATH_PROBLEM: 'গাণিতিক সমস্যা',
  MATCHING: 'মিলকরণ'
};

function asSettings(value: unknown): PaperSettings {
  if (!value || typeof value !== 'object') return {};
  return value as PaperSettings;
}

function optionLabel(options: readonly { value: string; label: string }[], value?: string) {
  return options.find((option) => option.value === value)?.label ?? value ?? '-';
}

function DetailItem({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-md border border-gray-200 bg-gray-50 p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">{label}</p>
      <div className="mt-2 text-sm font-medium text-gray-950">{value || '-'}</div>
    </div>
  );
}

function optionsList(value: unknown) {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}

function displayQuestionText(value: string) {
  return value
    .replace(/\s+(উদ্দীপক:)/g, '\n$1')
    .replace(/\s+([কখগঘ])[).]\s*/g, '\n$1) ')
    .trim();
}

export default async function PaperDetailsPage({
  params,
  searchParams
}: {
  params: { id: string };
  searchParams?: { error?: string; success?: string };
}) {
  await requirePaperAccess(params.id);

  const paper = await prisma.questionPaper.findUnique({
    where: { id: params.id },
    include: {
      classLevel: true,
      subject: true,
      book: true,
      chapter: true,
      sourceDocuments: {
        where: { type: { in: ['PREVIOUS_QUESTION', 'REFERENCE_NOTE'] } },
        orderBy: { createdAt: 'desc' }
      },
      generated: { orderBy: { orderIndex: 'asc' } },
      generationLogs: { orderBy: { createdAt: 'desc' }, take: 5 }
    }
  });

  if (!paper) notFound();

  const settings = asSettings(paper.settings);
  const selectedTypes = settings.selectedQuestionTypes ?? [];
  const pages = settings.retrievedContentPreview ?? [];
  const importantQuestions = settings.retrievedImportantQuestionsPreview ?? [];
  const successMessage = searchParams?.success ? successMessages[searchParams.success] : null;
  const errorMessage = searchParams?.error ? errorMessages[searchParams.error] : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-950">{paper.title}</h1>
          <p className="mt-1 text-sm text-gray-600">Draft paper source summary and retrieved database content preview.</p>
        </div>
        <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-700">{paper.status}</span>
      </div>

      {successMessage ? <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm font-medium text-green-700">{successMessage}</div> : null}
      {errorMessage ? <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700">{errorMessage}</div> : null}

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Paper Template & Branding</h2>
        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <DetailItem label="Exam title" value={paper.examTitle ?? paper.title} />
          <DetailItem label="Template style" value={paper.templateStyle.replaceAll('_', ' ')} />
          <DetailItem label="Teacher name" value={paper.teacherName ?? '-'} />
          <DetailItem label="Header note" value={paper.headerNote ?? '-'} />
          <DetailItem label="Footer text" value={paper.footerText ?? '-'} />
          <DetailItem label="Watermark text" value={paper.watermarkText ?? '-'} />
          <DetailItem label="Signature text" value={paper.signatureText ?? '-'} />
        </div>
        <form action={updatePaperTemplate} className="mt-5 grid gap-4 md:grid-cols-2">
          <input type="hidden" name="paperId" value={paper.id} />
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Exam title
            <input name="examTitle" defaultValue={paper.examTitle ?? ''} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Teacher name
            <input name="teacherName" defaultValue={paper.teacherName ?? ''} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Template style
            <select name="templateStyle" defaultValue={paper.templateStyle} className={inputClass}>
              {Object.values(PaperTemplateStyle).map((style) => (
                <option key={style} value={style}>{style.replaceAll('_', ' ')}</option>
              ))}
            </select>
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Watermark text
            <input name="watermarkText" defaultValue={paper.watermarkText ?? ''} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Header note
            <textarea name="headerNote" defaultValue={paper.headerNote ?? ''} rows={2} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Footer text
            <textarea name="footerText" defaultValue={paper.footerText ?? ''} rows={2} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Signature text
            <input name="signatureText" defaultValue={paper.signatureText ?? ''} className={inputClass} />
          </label>
          <div className="md:col-span-2">
            <button type="submit" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save Template</button>
          </div>
        </form>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Paper Settings</h2>
        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <DetailItem label="Class" value={paper.classLevel?.name} />
          <DetailItem label="Subject" value={paper.subject?.name} />
          <DetailItem label="Book" value={paper.book?.title} />
          <DetailItem label="Chapter" value={paper.chapter ? `Chapter ${paper.chapter.chapterNo}: ${paper.chapter.title}` : '-'} />
          <DetailItem label="Total marks" value={paper.totalMarks ?? '-'} />
          <DetailItem label="Duration" value={paper.durationMinutes ? `${paper.durationMinutes} minutes` : '-'} />
          <DetailItem label="Question types" value={selectedTypes.length ? selectedTypes.map((type) => optionLabel(QUESTION_TYPES, type)).join(', ') : '-'} />
          <DetailItem label="Difficulty" value={optionLabel(DIFFICULTY_LEVELS, settings.difficultyLevel)} />
          <DetailItem label="Importance" value={optionLabel(IMPORTANCE_LEVELS, settings.importanceLevel)} />
          <DetailItem label="Content mode" value={settings.contentMode?.replaceAll('_', ' ')} />
          <DetailItem label="Page range" value={settings.pageFrom && settings.pageTo ? `${settings.pageFrom} to ${settings.pageTo}` : '-'} />
          <DetailItem label="Retrieved counts" value={`${settings.retrievedPageCount ?? 0} pages, ${settings.retrievedImportantQuestionCount ?? 0} questions`} />
        </div>

        <div className="mt-5 rounded-md border border-gray-200 bg-gray-50 p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Extra instruction</p>
          <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-gray-800">{settings.extraInstruction || '-'}</p>
        </div>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-gray-950">আগের প্রশ্ন/রেফারেন্স বিশ্লেষণ</h2>
            <p className="mt-1 text-sm text-gray-600">AI generation will use this reference to follow style/pattern, not directly copy.</p>
          </div>
          {settings.useReferencePattern ? <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">Pattern enabled</span> : null}
        </div>
        <div className="mt-4 space-y-3">
          {paper.sourceDocuments.length === 0 ? (
            <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-500">No previous question or reference document attached.</p>
          ) : (
            paper.sourceDocuments.map((document) => (
              <div key={document.id} className="rounded-md border border-gray-200 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-gray-950">{document.title}</p>
                    <p className="text-xs text-gray-500">{document.originalFileName} / {document.type} / {document.extractionStatus}</p>
                  </div>
                </div>
                {document.extractionStatus === 'SCANNED_OR_EMPTY' ? (
                  <p className="mt-3 rounded bg-amber-50 p-3 text-sm text-amber-700">This PDF looks scanned/image-based. OCR support will be added later.</p>
                ) : null}
                {document.errorMessage ? <p className="mt-3 rounded bg-red-50 p-3 text-sm text-red-700">{document.errorMessage}</p> : null}
                {settings.referenceInstruction ? (
                  <p className="mt-3 rounded bg-blue-50 p-3 text-sm text-blue-700"><strong>Teacher instruction:</strong> {settings.referenceInstruction}</p>
                ) : null}
                <p className="mt-3 whitespace-pre-wrap rounded bg-gray-50 p-3 text-sm leading-6 text-gray-700">
                  {document.extractedText ? (document.extractedText.length > 1000 ? `${document.extractedText.slice(0, 1000)}...` : document.extractedText) : 'No extracted text preview available.'}
                </p>
              </div>
            ))
          )}
        </div>
      </section>

      {paper.generated.length > 0 ? (
        <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
          <div>
            <h2 className="text-lg font-semibold text-gray-950">Export Paper</h2>
            <p className="mt-1 text-sm text-gray-600">Download student or teacher copies from the current generated questions.</p>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Link href={`/dashboard/papers/${paper.id}/print?copy=student`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Printable Student Copy
            </Link>
            <Link href={`/dashboard/papers/${paper.id}/print?copy=teacher`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Printable Teacher Copy
            </Link>
            <a href={`/api/papers/${paper.id}/export/docx?copy=student`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Download Student DOCX
            </a>
            <a href={`/api/papers/${paper.id}/export/docx?copy=teacher`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Download Teacher DOCX
            </a>
            <a href={`/api/papers/${paper.id}/export/html?copy=student`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Download Student HTML
            </a>
            <a href={`/api/papers/${paper.id}/export/html?copy=teacher`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              Download Teacher HTML
            </a>
            <a href={`/api/papers/${paper.id}/export/pdf?copy=student`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              PDF / Printable Student Export
            </a>
            <a href={`/api/papers/${paper.id}/export/pdf?copy=teacher`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
              PDF / Printable Teacher Export
            </a>
          </div>
        </section>
      ) : null}

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-semibold text-gray-950">Retrieved Pages Preview</h2>
          <span className="text-sm text-gray-500">{settings.retrievedPageCount ?? 0} matched</span>
        </div>
        <div className="mt-4 space-y-3">
          {pages.length === 0 ? (
            <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-500">No page preview saved for this draft.</p>
          ) : (
            pages.map((page, index) => (
              <div key={`${page.pageNumber ?? index}-${index}`} className="rounded-md border border-gray-200 p-4">
                <p className="text-sm font-semibold text-gray-950">Page {page.pageNumber ?? '-'}</p>
                <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-gray-700">{page.content}</p>
              </div>
            ))
          )}
        </div>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-semibold text-gray-950">Retrieved Important Questions Preview</h2>
          <span className="text-sm text-gray-500">{settings.retrievedImportantQuestionCount ?? 0} matched</span>
        </div>
        <div className="mt-4 space-y-3">
          {importantQuestions.length === 0 ? (
            <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-500">No important questions matched this draft.</p>
          ) : (
            importantQuestions.map((question, index) => (
              <div key={`${question.questionText ?? index}-${index}`} className="rounded-md border border-gray-200 p-4">
                <div className="mb-3 flex flex-wrap gap-2">
                  {question.questionType ? <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{optionLabel(QUESTION_TYPES, question.questionType)}</span> : null}
                  {question.difficultyLevel ? <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700">{optionLabel(DIFFICULTY_LEVELS, question.difficultyLevel)}</span> : null}
                  {question.importanceLevel ? <span className="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700">{optionLabel(IMPORTANCE_LEVELS, question.importanceLevel)}</span> : null}
                  {question.isBoardRepeated ? <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-700">Board repeated</span> : null}
                  {question.isTeacherRecommended ? <span className="rounded-full bg-purple-50 px-2.5 py-1 text-xs font-semibold text-purple-700">Teacher recommended</span> : null}
                </div>
                <p className="text-sm font-semibold text-gray-950">{question.questionText}</p>
                {question.answerText ? <p className="mt-2 text-sm leading-6 text-gray-700">{question.answerText}</p> : null}
                <p className="mt-3 text-xs text-gray-500">
                  Page {question.pageNumber ?? '-'} / Exercise {question.exerciseNo ?? '-'} / Question {question.questionNo ?? '-'}
                </p>
              </div>
            ))
          )}
        </div>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-gray-950">Generated Questions</h2>
            <p className="mt-1 text-sm text-gray-600">
              {paper.generated.length > 0
                ? `${paper.generated.length} generated questions saved for this paper.`
                : 'No generated questions yet. Generate with AI to create the first version.'}
            </p>
          </div>
        </div>

        <div className="mt-4 space-y-4">
          {paper.generated.length === 0 ? (
            <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-500">
              No generated questions yet. Generate with AI to create the first version.
            </p>
          ) : (
            paper.generated.map((question, index) => {
              const options = optionsList(question.options);
              const saveFormId = `save-question-${question.id}`;

              return (
                <div key={question.id} className="rounded-md border border-gray-200 p-4">
                  <div className="mb-3 flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold text-gray-950">Question {index + 1}</span>
                    <span className="text-sm text-gray-500">{banglaSectionLabels[question.questionType] ?? question.sectionTitle ?? 'প্রশ্ন'}</span>
                    {question.sectionTitle ? <span className="text-xs text-gray-400">{question.sectionTitle}</span> : null}
                    <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{optionLabel(QUESTION_TYPES, question.questionType)}</span>
                    <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700">{optionLabel(DIFFICULTY_LEVELS, question.difficultyLevel)}</span>
                    <span className="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700">{optionLabel(IMPORTANCE_LEVELS, question.importanceLevel)}</span>
                    {question.marks ? <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-700">{question.marks} marks</span> : null}
                  </div>

                  <div className="mb-4 rounded-md border border-gray-200 bg-gray-50 p-4">
                    <p className="whitespace-pre-wrap text-sm leading-6 text-gray-950">{displayQuestionText(question.questionText)}</p>
                    {options.length > 0 ? (
                      <div className="mt-3 grid gap-1 text-sm text-gray-800 sm:grid-cols-2">
                        {options.map((option, optionIndex) => (
                          <p key={`${question.id}-preview-option-${optionIndex}`}>
                            <strong>{banglaOptionLabels[optionIndex] ?? optionIndex + 1})</strong> {option}
                          </p>
                        ))}
                      </div>
                    ) : null}
                    {question.answerText || question.correctAnswer || question.explanation ? (
                      <div className="mt-3 border-l-4 border-gray-900 bg-white p-3 text-sm leading-6 text-gray-700">
                        <p className="font-semibold text-gray-950">উত্তরমালা</p>
                        {question.correctAnswer ? <p><strong>সঠিক উত্তর:</strong> {question.correctAnswer}</p> : null}
                        {question.answerText ? <p className="whitespace-pre-wrap"><strong>মডেল উত্তর:</strong> {question.answerText}</p> : null}
                        {question.explanation ? <p className="whitespace-pre-wrap"><strong>ব্যাখ্যা:</strong> {question.explanation}</p> : null}
                      </div>
                    ) : null}
                  </div>

                  <form id={saveFormId} action={updateGeneratedQuestion} className="grid gap-4 md:grid-cols-2">
                    <input type="hidden" name="questionId" value={question.id} />
                    <input type="hidden" name="paperId" value={paper.id} />

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Section title
                      <input name="sectionTitle" defaultValue={question.sectionTitle ?? ''} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Question type
                      <select name="questionType" defaultValue={question.questionType} required className={inputClass}>
                        {QUESTION_TYPES.map((type) => (
                          <option key={type.value} value={type.value}>{type.label}</option>
                        ))}
                      </select>
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
                      Question text
                      <textarea name="questionText" defaultValue={question.questionText} required rows={4} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
                      Options
                      <textarea name="optionsText" defaultValue={options.join('\n')} rows={4} placeholder="One option per line" className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Correct answer
                      <input name="correctAnswer" defaultValue={question.correctAnswer ?? ''} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Marks
                      <input name="marks" type="number" min="1" defaultValue={question.marks ?? ''} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
                      Answer text
                      <textarea name="answerText" defaultValue={question.answerText ?? ''} rows={3} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
                      Explanation
                      <textarea name="explanation" defaultValue={question.explanation ?? ''} rows={3} className={inputClass} />
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Difficulty
                      <select name="difficultyLevel" defaultValue={question.difficultyLevel} required className={inputClass}>
                        {DIFFICULTY_LEVELS.map((level) => (
                          <option key={level.value} value={level.value}>{level.label}</option>
                        ))}
                      </select>
                    </label>

                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Importance
                      <select name="importanceLevel" defaultValue={question.importanceLevel} required className={inputClass}>
                        {IMPORTANCE_LEVELS.map((level) => (
                          <option key={level.value} value={level.value}>{level.label}</option>
                        ))}
                      </select>
                    </label>
                  </form>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <button form={saveFormId} className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Save Changes</button>

                    <form action={moveGeneratedQuestion}>
                      <input type="hidden" name="questionId" value={question.id} />
                      <input type="hidden" name="paperId" value={paper.id} />
                      <input type="hidden" name="direction" value="UP" />
                      <button className="rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">Move Up</button>
                    </form>

                    <form action={moveGeneratedQuestion}>
                      <input type="hidden" name="questionId" value={question.id} />
                      <input type="hidden" name="paperId" value={paper.id} />
                      <input type="hidden" name="direction" value="DOWN" />
                      <button className="rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">Move Down</button>
                    </form>

                    <form action={deleteGeneratedQuestion}>
                      <input type="hidden" name="questionId" value={question.id} />
                      <input type="hidden" name="paperId" value={paper.id} />
                      <button className="rounded-md border border-red-200 px-3 py-2 text-sm font-medium text-red-700 hover:bg-red-50">Delete</button>
                    </form>
                  </div>

                  <form action={regenerateSingleQuestionWithAI} className="mt-5 rounded-md border border-gray-200 bg-gray-50 p-4">
                    <input type="hidden" name="questionId" value={question.id} />
                    <input type="hidden" name="paperId" value={paper.id} />
                    <label className="grid gap-1.5 text-sm font-medium text-gray-700">
                      Selective regenerate instruction
                      <textarea
                        name="instruction"
                        rows={3}
                        placeholder="Instruction for this question only. Example: এই প্রশ্নটা আরেকটু কঠিন করুন।"
                        className={inputClass}
                      />
                    </label>
                    <div className="mt-3 flex flex-wrap items-center gap-3">
                      <button className="rounded-md bg-gray-950 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-800">Regenerate This Question</button>
                      <p className="text-xs text-gray-500">Only this question will be replaced. Other questions will stay unchanged.</p>
                    </div>
                  </form>
                </div>
              );
            })
          )}
        </div>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Add Manual Question</h2>
        <form action={addManualGeneratedQuestion} className="mt-5 grid gap-4 md:grid-cols-2">
          <input type="hidden" name="paperId" value={paper.id} />
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Section title
            <input name="sectionTitle" placeholder="Section A" className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Question type
            <select name="questionType" defaultValue="SHORT" required className={inputClass}>
              {QUESTION_TYPES.map((type) => (
                <option key={type.value} value={type.value}>{type.label}</option>
              ))}
            </select>
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Question text
            <textarea name="questionText" required rows={4} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Options
            <textarea name="optionsText" rows={4} placeholder="One option per line" className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Correct answer
            <input name="correctAnswer" className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Marks
            <input name="marks" type="number" min="1" className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Answer text
            <textarea name="answerText" rows={3} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700 md:col-span-2">
            Explanation
            <textarea name="explanation" rows={3} className={inputClass} />
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Difficulty
            <select name="difficultyLevel" defaultValue={settings.difficultyLevel ?? 'MEDIUM'} required className={inputClass}>
              {DIFFICULTY_LEVELS.map((level) => (
                <option key={level.value} value={level.value}>{level.label}</option>
              ))}
            </select>
          </label>
          <label className="grid gap-1.5 text-sm font-medium text-gray-700">
            Importance
            <select name="importanceLevel" defaultValue={settings.importanceLevel ?? 'NORMAL'} required className={inputClass}>
              {IMPORTANCE_LEVELS.map((level) => (
                <option key={level.value} value={level.value}>{level.label}</option>
              ))}
            </select>
          </label>
          <div className="md:col-span-2">
            <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">Add Question</button>
          </div>
        </form>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Generation Logs</h2>
        <div className="mt-4 space-y-3">
          {paper.generationLogs.length === 0 ? (
            <p className="rounded-md bg-gray-50 p-4 text-sm text-gray-500">No generation logs yet.</p>
          ) : (
            paper.generationLogs.map((log) => (
              <div key={log.id} className="rounded-md border border-gray-200 p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{log.provider}</span>
                  <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{log.model}</span>
                  <span className={log.status === 'SUCCESS' ? 'rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-700' : 'rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700'}>
                    {log.status}
                  </span>
                  <span className="text-xs text-gray-500">{log.createdAt.toLocaleString()}</span>
                </div>
                {log.errorMessage ? <p className="mt-3 text-sm leading-6 text-red-700">{log.errorMessage}</p> : null}
              </div>
            ))
          )}
        </div>
      </section>

      <div className="flex flex-wrap gap-3">
        <Link href="/dashboard/create-paper" className="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
          Back to Create Paper
        </Link>
        <div className="space-y-2">
          <form
            action={async () => {
              'use server';
              await generateQuestionPaperWithAI(paper.id);
            }}
          >
            <button className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">
              {paper.status === 'GENERATED' ? 'Regenerate with AI' : 'Generate with AI'}
            </button>
          </form>
          {paper.status === 'GENERATED' ? (
            <p className="text-xs text-amber-700">Regenerating will replace previous generated questions.</p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
