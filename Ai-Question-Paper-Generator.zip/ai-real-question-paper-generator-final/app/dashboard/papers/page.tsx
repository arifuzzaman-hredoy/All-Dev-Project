import Link from 'next/link';
import { isAdminRole, requireUser } from '@/lib/auth/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function PapersPage() {
  const user = await requireUser();
  const papers = await prisma.questionPaper.findMany({
    where: isAdminRole(user.role) ? {} : { userId: user.id },
    include: { classLevel: true, subject: true, book: true, chapter: true, user: true },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-950">আমার প্রশ্নপত্র</h1>
          <p className="mt-1 text-sm text-gray-600">আপনার ড্রাফট ও জেনারেটেড প্রশ্নপত্র।</p>
        </div>
        <Link href="/dashboard/create-paper" className="rounded-md bg-gray-950 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">
          প্রশ্নপত্র তৈরি করুন
        </Link>
      </div>

      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Class</th>
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Book</th>
              <th className="px-4 py-3">Chapter</th>
              <th className="px-4 py-3">Created</th>
              {isAdminRole(user.role) ? <th className="px-4 py-3">Owner</th> : null}
              <th className="px-4 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {papers.length === 0 ? (
              <tr>
                <td colSpan={isAdminRole(user.role) ? 9 : 8} className="px-4 py-10 text-center text-gray-500">
                  No papers yet. Create a draft paper to see it here.
                </td>
              </tr>
            ) : (
              papers.map((paper) => (
                <tr key={paper.id}>
                  <td className="px-4 py-3 font-medium text-gray-950">{paper.title}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">{paper.status}</span>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{paper.classLevel?.name ?? '-'}</td>
                  <td className="px-4 py-3 text-gray-600">{paper.subject?.name ?? '-'}</td>
                  <td className="px-4 py-3 text-gray-600">{paper.book?.title ?? '-'}</td>
                  <td className="px-4 py-3 text-gray-600">{paper.chapter ? `Chapter ${paper.chapter.chapterNo}: ${paper.chapter.title}` : '-'}</td>
                  <td className="px-4 py-3 text-gray-600">{paper.createdAt.toLocaleDateString()}</td>
                  {isAdminRole(user.role) ? <td className="px-4 py-3 text-gray-600">{paper.user.name ?? paper.user.email}</td> : null}
                  <td className="px-4 py-3 text-right">
                    <Link href={`/dashboard/papers/${paper.id}`} className="rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                      View
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
