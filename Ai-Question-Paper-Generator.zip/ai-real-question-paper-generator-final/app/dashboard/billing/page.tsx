import Link from 'next/link';
import { requireUser } from '@/lib/auth/session';
import { getUsageSummary } from '@/lib/billing/subscription';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

function UsageCard({ label, used, limit }: { label: string; used: number; limit: number }) {
  return (
    <div className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-medium text-gray-500">{label}</p>
      <p className="mt-3 text-3xl font-bold text-gray-950">{used} / {limit}</p>
      <p className="mt-1 text-xs text-gray-500">{Math.max(0, limit - used)} remaining this month</p>
    </div>
  );
}

function Feature({ label, enabled }: { label: string; enabled: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-gray-200 px-3 py-2 text-sm">
      <span className="font-medium text-gray-700">{label}</span>
      <span className={enabled ? 'font-semibold text-green-700' : 'font-semibold text-gray-400'}>{enabled ? 'Enabled' : 'Locked'}</span>
    </div>
  );
}

export default async function BillingPage() {
  const user = await requireUser();
  const summary = await getUsageSummary(user.id);
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: [{ sortOrder: 'asc' }, { priceMonthly: 'asc' }]
  });
  const { plan, subscription } = summary;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-950">বিলিং ও ব্যবহার</h1>
        <p className="mt-1 text-sm text-gray-600">আপনার বর্তমান প্ল্যান, মাসিক ব্যবহার ও সীমা।</p>
      </div>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase text-gray-500">Current Plan</p>
            <h2 className="mt-1 text-2xl font-bold text-gray-950">{plan.name}</h2>
            <p className="mt-1 text-sm text-gray-600">{plan.description ?? 'No description provided.'}</p>
          </div>
          <div className="text-sm text-gray-600">
            <p><strong>Status:</strong> {subscription.status}</p>
            <p><strong>Billing:</strong> {subscription.billingCycle}</p>
            <p><strong>Period:</strong> {subscription.currentPeriodStart.toLocaleDateString()} - {subscription.currentPeriodEnd?.toLocaleDateString() ?? '-'}</p>
          </div>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <UsageCard label="Papers" used={summary.paperUsed} limit={summary.limits.paperLimitMonthly} />
        <UsageCard label="AI generations" used={summary.aiGenerationUsed} limit={summary.limits.aiGenerationLimitMonthly} />
        <UsageCard label="Regenerations" used={summary.aiRegenerateUsed} limit={summary.limits.aiRegenerateLimitMonthly} />
        <UsageCard label="Exports" used={summary.exportUsed} limit={summary.limits.exportLimitMonthly} />
      </div>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-950">Feature Access</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Feature label="Important questions" enabled={plan.canUseImportantQuestions} />
          <Feature label="Selective regenerate" enabled={plan.canUseSelectiveRegenerate} />
          <Feature label="DOCX export" enabled={plan.canExportDocx} />
          <Feature label="PDF export" enabled={plan.canExportPdf} />
          <Feature label="Teacher copy" enabled={plan.canUseTeacherCopy} />
          <Feature label={`Max ${plan.maxPagesPerPaper} pages per paper`} enabled />
        </div>
      </section>

      <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-semibold text-gray-950">Available Plans</h2>
          <Link href="/pricing" className="text-sm font-semibold text-gray-950 hover:underline">View pricing</Link>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {plans.map((availablePlan) => (
            <div key={availablePlan.id} className="rounded-md border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-950">{availablePlan.name}</h3>
              <p className="mt-1 text-sm text-gray-600">BDT {availablePlan.priceMonthly}/month</p>
              <p className="mt-3 text-xs leading-5 text-gray-500">
                {availablePlan.paperLimitMonthly} papers, {availablePlan.aiGenerationLimitMonthly} AI generations, {availablePlan.exportLimitMonthly} exports.
              </p>
            </div>
          ))}
        </div>
        <p className="mt-4 rounded-md bg-gray-50 p-3 text-sm text-gray-600">To upgrade your plan, contact admin/support.</p>
      </section>
    </div>
  );
}
