import { logoutUser } from '@/lib/actions/auth';

export default function LogoutButton() {
  return (
    <form action={logoutUser}>
      <button type="submit" className="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
        Logout
      </button>
    </form>
  );
}
