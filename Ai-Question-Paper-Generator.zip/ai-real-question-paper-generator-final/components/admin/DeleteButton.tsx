'use client';

type DeleteButtonProps = {
  label?: string;
};

export default function DeleteButton({ label = 'Delete' }: DeleteButtonProps) {
  return (
    <button
      type="submit"
      onClick={(event) => {
        if (!window.confirm('Delete this record? This cannot be undone.')) {
          event.preventDefault();
        }
      }}
      className="rounded-md border border-red-200 px-3 py-2 text-sm font-medium text-red-700 transition hover:bg-red-50"
    >
      {label}
    </button>
  );
}
