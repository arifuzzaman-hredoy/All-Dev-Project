param(
    [string]$ProjectDir = (Join-Path $PSScriptRoot "app"),
    [switch]$RemoveLocalProperties
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $ProjectDir)) {
    throw "Project directory not found: $ProjectDir"
}

function Remove-PathWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [int]$Attempts = 6
    )

    if (-not (Test-Path -LiteralPath $Path)) { return }

    for ($Attempt = 1; $Attempt -le $Attempts; $Attempt++) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            return
        }
        catch {
            if ($Attempt -eq $Attempts) { throw }
            Start-Sleep -Milliseconds (300 * $Attempt)
        }
    }
}

$Adb = "G:\Android\Sdk\platform-tools\adb.exe"
if (Test-Path -LiteralPath $Adb) {
    & $Adb kill-server 2>$null
}

$Gradle = Join-Path $ProjectDir "android\gradlew.bat"
if (Test-Path -LiteralPath $Gradle) {
    Push-Location (Join-Path $ProjectDir "android")
    try { & .\gradlew.bat --stop 2>$null } finally { Pop-Location }
}

Get-Process -Name dart,flutter,kotlin-daemon -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue

$GeneratedPaths = @(
    (Join-Path $ProjectDir ".dart_tool"),
    (Join-Path $ProjectDir ".flutter-tool-temp"),
    (Join-Path $ProjectDir "build"),
    (Join-Path $ProjectDir "android\.gradle"),
    (Join-Path $ProjectDir "android\.kotlin"),
    (Join-Path $ProjectDir "android\.cxx"),
    (Join-Path $ProjectDir "android\app\.cxx")
)

foreach ($GeneratedPath in $GeneratedPaths) {
    Remove-PathWithRetry -Path $GeneratedPath
}

$GeneratedMetadataFiles = @(
    (Join-Path $ProjectDir ".flutter-plugins-dependencies")
)
foreach ($GeneratedMetadataFile in $GeneratedMetadataFiles) {
    if (Test-Path -LiteralPath $GeneratedMetadataFile) {
        Remove-Item -LiteralPath $GeneratedMetadataFile -Force
    }
}

Get-ChildItem -LiteralPath $ProjectDir -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -in @(
            "phone-smoke-test.log",
            "phone-performance-report.txt",
            "final-phone-verification.log",
            "FINAL_FEATURE_MATRIX.txt"
        )
    } |
    Remove-Item -Force

$GeneratedRegistrant = Join-Path $ProjectDir "android\app\src\main\java\io\flutter\plugins\GeneratedPluginRegistrant.java"
if (Test-Path -LiteralPath $GeneratedRegistrant) {
    Remove-Item -LiteralPath $GeneratedRegistrant -Force
}

if ($RemoveLocalProperties) {
    $LocalProperties = Join-Path $ProjectDir "android\local.properties"
    if (Test-Path -LiteralPath $LocalProperties) {
        Remove-Item -LiteralPath $LocalProperties -Force
    }
}

Write-Host "Generated Flutter/Gradle files removed." -ForegroundColor Green
