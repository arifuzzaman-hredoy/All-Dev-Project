param(
    [string]$FlutterSdk = "G:\sdk\flutter",
    [string]$AndroidSdk = "G:\Android\Sdk",
    [string]$GradleUserHome = "G:\GradleCache",
    [string]$PubCache = "G:\PubCache",
    [switch]$TestPhone,
    [switch]$SkipPhoneInstall
)

$ErrorActionPreference = "Stop"
$ProjectDir = Join-Path $PSScriptRoot "app"

if (-not (Test-Path -LiteralPath (Join-Path $FlutterSdk "bin\flutter.bat"))) {
    throw "Flutter SDK not found: $FlutterSdk"
}
if (-not (Test-Path -LiteralPath $AndroidSdk)) {
    throw "Android SDK not found: $AndroidSdk"
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectDir "pubspec.yaml"))) {
    throw "Flutter project not found: $ProjectDir"
}

function Assert-PowerShellScriptsParse {
    param([Parameter(Mandatory = $true)][string]$RootPath)

    $ParseFailures = @()
    $ScriptFiles = Get-ChildItem `
        -LiteralPath $RootPath `
        -Filter "*.ps1" `
        -File `
        -Recurse `
        -ErrorAction Stop

    foreach ($ScriptFile in $ScriptFiles) {
        $ParserTokens = $null
        $ParserErrors = $null

        [System.Management.Automation.Language.Parser]::ParseFile(
            $ScriptFile.FullName,
            [ref]$ParserTokens,
            [ref]$ParserErrors
        ) | Out-Null

        foreach ($ParserError in @($ParserErrors)) {
            $ParseFailures += (
                "{0}:{1}:{2} {3}" -f `
                    $ScriptFile.FullName, `
                    $ParserError.Extent.StartLineNumber, `
                    $ParserError.Extent.StartColumnNumber, `
                    $ParserError.Message
            )
        }
    }

    if ($ParseFailures.Count -gt 0) {
        throw (
            "PowerShell syntax validation failed:`n" +
            ($ParseFailures -join [Environment]::NewLine)
        )
    }
}

Assert-PowerShellScriptsParse -RootPath $PSScriptRoot
Write-Host "PowerShell syntax validation passed." -ForegroundColor Green

$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = $GradleUserHome
$env:PUB_CACHE = $PubCache
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

New-Item -ItemType Directory -Path $GradleUserHome,$PubCache -Force | Out-Null

function Escape-GradlePath([string]$Path) {
    return $Path.Replace("\", "\\")
}

$LocalProperties = @(
    "sdk.dir=$(Escape-GradlePath $AndroidSdk)",
    "flutter.sdk=$(Escape-GradlePath $FlutterSdk)"
) -join [Environment]::NewLine

Set-Content -LiteralPath (Join-Path $ProjectDir "android\local.properties") -Value $LocalProperties -Encoding ascii

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

& (Join-Path $PSScriptRoot "CLEAN_GENERATED_FILES.ps1") -ProjectDir $ProjectDir

Set-Location $ProjectDir

flutter doctor -v
if ($LASTEXITCODE -ne 0) { throw "flutter doctor failed." }

flutter pub get
if ($LASTEXITCODE -ne 0) { throw "flutter pub get failed." }

.\QA.ps1
if ($LASTEXITCODE -ne 0) { throw "Full QA failed." }

if ($TestPhone) {
    if ($SkipPhoneInstall) {
        .\FINAL_VERIFY_ON_PHONE.ps1 -SkipQA -SkipInstall
    }
    else {
        .\TEST_ON_PHONE.ps1 -SkipQA
        if ($LASTEXITCODE -ne 0) { throw "Phone smoke test failed." }
        .\FINAL_VERIFY_ON_PHONE.ps1 -SkipQA -SkipInstall
    }
}

Write-Host "Hredoy Flow 4.6.3 setup and QA completed." -ForegroundColor Green
