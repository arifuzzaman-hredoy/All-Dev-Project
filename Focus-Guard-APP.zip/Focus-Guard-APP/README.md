# Hredoy Flow 4.6.3 — Hybrid Reels Counter QA Recovery

Hredoy Flow is a local-first Flutter productivity and Android wellbeing app. Version 4.6.3 retains the hybrid counter that fixes the v4.6.0 physical-phone regression where Reels/Shorts could remain at zero when Facebook, Instagram or YouTube hid creator/caption text from the Accessibility tree.

The counter now prefers two stable privacy-safe fingerprints, but falls back to one settled full-screen pager candidate when identity text is unavailable. Raw Accessibility callbacks never increment the counter directly, callback bursts are clustered, and comment/caption/nested scrolling is rejected.

The 26 July 2026 6:30 AM routine restart, routine schema `7`, manual tasks, profile picture, XP, Study Quest, Focus history, settings, rules, Focus Forest and 216 bundled alarm sounds remain unchanged.
