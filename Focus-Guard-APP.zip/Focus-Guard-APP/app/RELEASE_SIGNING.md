# Production release signing

Debug and profile builds do not require a private key. A distributable release APK must use a private signing identity.

## One-time setup

```powershell
Set-Location "G:\Current Project\Development\focus_guard_flutter_v1\app"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\CONFIGURE_RELEASE_SIGNING.ps1
```

This creates `android/hredoy-flow-release.jks` and `android/release-signing.properties`. Both are excluded from source control and full-project ZIPs. Store encrypted backups. Future updates must be signed with the same key.

## Build and verify

```powershell
.\BUILD_RELEASE_APK.ps1
```

The script runs QA, obfuscates Dart code, keeps split-debug symbols, verifies the APK signature with `apksigner`, and writes a SHA-256 report.

## Install

```powershell
.\INSTALL_RELEASE_ON_PHONE.ps1 -SkipBuild
```

A release key different from a previously installed debug key cannot update that installation in place. Uninstalling the old build removes its private local data, so export or back up important local data first.
