param(
    [string]$DeviceId = "R38M800T0HD",
    [switch]$SkipQA,
    [switch]$SkipInstall,
    [switch]$RequirePermissions
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"
$PackageId = "com.hredoy.focus_guard_flutter"
$Activity = "$PackageId/.MainActivity"
$ExpectedVersion = "4.6.3"
$ReportFile = Join-Path $PSScriptRoot "FINAL_FEATURE_MATRIX.txt"
$RuntimeLog = Join-Path $PSScriptRoot "final-phone-verification.log"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null
$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

function Add-Result {
    param(
        [Parameter(Mandatory = $true)][string]$Area,
        [Parameter(Mandatory = $true)][string]$Feature,
        [Parameter(Mandatory = $true)][string]$Status,
        [Parameter(Mandatory = $true)][string]$Evidence
    )
    $script:Results.Add([pscustomobject]@{
        Area = $Area
        Feature = $Feature
        Status = $Status
        Evidence = $Evidence
    })
}

function Test-SourceTokens {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string[]]$Tokens
    )
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $Source = Get-Content -LiteralPath $Path -Raw
    foreach ($Token in $Tokens) {
        if (-not $Source.Contains($Token)) { return $false }
    }
    return $true
}

function Wait-ForDevice {
    adb start-server | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "ADB server could not start." }
    for ($Attempt = 1; $Attempt -le 20; $Attempt += 1) {
        $Devices = adb devices -l | Out-String
        if ($Devices -match "(?m)^$([regex]::Escape($DeviceId))\s+device\b") { return }
        Write-Host "Waiting for unlocked/authorized phone ($Attempt/20)..." -ForegroundColor Yellow
        Start-Sleep -Seconds 2
    }
    throw "Device $DeviceId was not detected. Unlock the phone and approve USB debugging."
}

$Results = New-Object System.Collections.Generic.List[object]

if (-not $SkipQA) {
    & "$PSScriptRoot\QA.ps1"
    if ($LASTEXITCODE -ne 0) { throw "Project QA failed." }
}

$SourceChecks = @(
    @{ Area = "Phone Control"; Feature = "Per-app schedules and exact limits"; Path = ".\lib\screens\phone_control_screen.dart"; Tokens = @("dailyLimitMinutes", "reelsDailyLimit", "scrollLimit") },
    @{ Area = "Dashboard"; Feature = "Premium dashboard and seven-day metrics"; Path = ".\lib\screens\phone_control_dashboard_screen.dart"; Tokens = @("Total screen time", "Controlled-app time", "12:00 AM to now", "phone-control-weekly-chart") },
    @{ Area = "Schedules"; Feature = "Recurring multi-app schedule profiles"; Path = ".\lib\screens\schedule_profiles_screen.dart"; Tokens = @("Schedule Profiles", "requestScheduleProfileUnlock", "duplicate") },
    @{ Area = "Social"; Feature = "Notification control, history and social counters"; Path = ".\lib\screens\social_control_screen.dart"; Tokens = @("Notification", "Reels", "scroll") },
    @{ Area = "Study Mode"; Feature = "Study Mode dashboard, subjects, tasks, goals and insights"; Path = ".\lib\screens\study_mode_screen.dart"; Tokens = @("Dashboard", "Subjects", "Tasks", "Goals", "Insights", "Setup") },
    @{ Area = "Web & DNS"; Feature = "Local DNS VPN and web rules"; Path = ".\lib\screens\protection_center_screen.dart"; Tokens = @("Web & DNS protection", "Local DNS VPN", "Adult-content protection", "Safe Search bypass guard") },
    @{ Area = "Commitment"; Feature = "Prime Mode, Keep Me Out and emergency policy"; Path = ".\lib\screens\protection_center_screen.dart"; Tokens = @("Prime Mode", "Keep Me Out", "Emergency policy", "Restore after reboot") },
    @{ Area = "Dashboard"; Feature = "Current action and full-picture slider"; Path = ".\lib\screens\today_screen.dart"; Tokens = @("Current action", "current-action-card", "assets/slider/morning_focus.png", "assets/slider/current_action.png", "assets/slider/countdown_city.png", "assets/slider/study_forest.png") },
    @{ Area = "Safety"; Feature = "Fail-open auto classification and emergency stop"; Path = ".\lib\screens\phone_control_screen.dart"; Tokens = @("Auto Safe Setup", "Stop all blocking", "Only apps you selected can be blocked") },
    @{ Area = "Usage"; Feature = "Local-midnight activity timeline"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\PhoneControlStore.kt"; Tokens = @("UsageEvents", "startOfDayMillis", "screenTimeWindowStartMillis", "usage_events", "accessibility_fallback") }
)

foreach ($Check in $SourceChecks) {
    $Passed = Test-SourceTokens -Path $Check.Path -Tokens $Check.Tokens
    Add-Result -Area $Check.Area -Feature $Check.Feature -Status $(if ($Passed) { "SOURCE_PASS" } else { "SOURCE_FAIL" }) -Evidence $Check.Path
    if (-not $Passed) { throw "Source feature verification failed: $($Check.Feature)" }
}

$NativeChecks = @(
    @{ Area = "App enforcement"; Feature = "Accessibility enforcement engine"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\FocusAccessibilityService.kt"; Tokens = @("PhoneControlEngine.decision", "recordScroll", "recordUsage", "updateForeground(foregroundPackage, now)", 'currentPackage = ""', "activePackage == foregroundPackage", "HOME_ACTION_COOLDOWN_MILLIS") },
    @{ Area = "Safety"; Feature = "One-time fail-open migration"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\SafetyBootstrap.kt"; Tokens = @("resetBlockingForSafety", "applyManualBlockingMigration", "clearActiveLocksForSafety", "ProtectionVpnService.stop") },
    @{ Area = "Social"; Feature = "Notification listener enforcement"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\NotificationControlService.kt"; Tokens = @("cancelNotification", "shouldBlockNotification") },
    @{ Area = "Web & DNS"; Feature = "DNS-only Android VPN engine"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\ProtectionVpnService.kt"; Tokens = @("addDnsServer", "addRoute", "protect(socket)", "buildNxDomainResponse") },
    @{ Area = "Commitment"; Feature = "Hardcore native policy engine"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\ProtectionEngine.kt"; Tokens = @("Uninstall Guard", "Prime Mode", "Keep Me Out") },
    @{ Area = "Protection"; Feature = "Reboot restoration"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\BootReceiver.kt"; Tokens = @("ProtectionVpnService.reconcile", "markBootRestore") },
    @{ Area = "Usage"; Feature = "Non-overlapping screen-time intervals"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\UsageTimeline.kt"; Tokens = @("UsageTimeline", "FOREGROUND", "BACKGROUND", "SCREEN_OFF", "totalScreenTimeMillis") },
    @{ Area = "Wellbeing"; Feature = "Detailed Reels and screen-time notifications"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\Notifications.kt"; Tokens = @("showReelsProgress", "showScreenTimeWarning", "BigTextStyle") },
    @{ Area = "Alarm"; Feature = "216 generated alarm-sound resource mapping"; Path = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\AlarmSoundCatalog.kt"; Tokens = @("17..216", "getIdentifier", "generatedToneLabel") }
)
foreach ($Check in $NativeChecks) {
    $Passed = Test-SourceTokens -Path $Check.Path -Tokens $Check.Tokens
    Add-Result -Area $Check.Area -Feature $Check.Feature -Status $(if ($Passed) { "SOURCE_PASS" } else { "SOURCE_FAIL" }) -Evidence $Check.Path
    if (-not $Passed) { throw "Native feature verification failed: $($Check.Feature)" }
}

Wait-ForDevice

if (-not $SkipInstall) {
    & "$PSScriptRoot\TEST_ON_PHONE.ps1" -DeviceId $DeviceId -SkipQA
    if ($LASTEXITCODE -ne 0) { throw "Phone smoke test failed." }
}

$PackageDump = adb -s $DeviceId shell dumpsys package $PackageId | Out-String
$VersionMatch = [regex]::Match($PackageDump, "(?m)versionName=([^\s]+)")
if (-not $VersionMatch.Success) { throw "Installed version could not be read." }
$InstalledVersion = $VersionMatch.Groups[1].Value
if ($InstalledVersion -ne $ExpectedVersion) {
    throw "Expected Hredoy Flow $ExpectedVersion, installed version is $InstalledVersion."
}
Add-Result -Area "Release" -Feature "Installed application version" -Status "PASS" -Evidence $InstalledVersion

$AccessibilityServices = (adb -s $DeviceId shell settings get secure enabled_accessibility_services | Out-String).Trim()
$NotificationListeners = (adb -s $DeviceId shell settings get secure enabled_notification_listeners | Out-String).Trim()
$BatteryWhitelist = adb -s $DeviceId shell dumpsys deviceidle whitelist | Out-String
$UsageStatsAppOp = adb -s $DeviceId shell cmd appops get $PackageId GET_USAGE_STATS 2>&1 | Out-String
$AccessibilityReady = $AccessibilityServices -match [regex]::Escape("$PackageId/.FocusAccessibilityService") -or
    $AccessibilityServices -match [regex]::Escape("$PackageId/com.hredoy.focus_guard_flutter.FocusAccessibilityService")
$NotificationReady = $NotificationListeners -match [regex]::Escape("$PackageId/.NotificationControlService") -or
    $NotificationListeners -match [regex]::Escape("$PackageId/com.hredoy.focus_guard_flutter.NotificationControlService")
$BatteryReady = $BatteryWhitelist -match [regex]::Escape($PackageId)
$UsageReady = $UsageStatsAppOp -match "allow"

Add-Result -Area "Permissions" -Feature "Accessibility App Blocker" -Status $(if ($AccessibilityReady) { "READY" } else { "NOT_READY" }) -Evidence "Android secure settings"
Add-Result -Area "Permissions" -Feature "Notification Access" -Status $(if ($NotificationReady) { "READY" } else { "NOT_READY" }) -Evidence "Android enabled notification listeners"
Add-Result -Area "Permissions" -Feature "Usage Access" -Status $(if ($UsageReady) { "READY" } else { "NOT_READY" }) -Evidence ($UsageStatsAppOp.Trim())
Add-Result -Area "Permissions" -Feature "Battery unrestricted" -Status $(if ($BatteryReady) { "READY" } else { "NOT_READY" }) -Evidence "Android device-idle whitelist"

if ($RequirePermissions -and (-not ($AccessibilityReady -and $NotificationReady -and $UsageReady -and $BatteryReady))) {
    throw "Required Android permissions are not all enabled. Open the in-app permission cards and run this script again."
}

adb -s $DeviceId logcat -c | Out-Null
adb -s $DeviceId shell am force-stop $PackageId | Out-Null
$Launch = adb -s $DeviceId shell am start -W -n $Activity | Out-String
if ($LASTEXITCODE -ne 0) { throw "Final application launch failed." }
Start-Sleep -Seconds 6
$AppProcessId = (adb -s $DeviceId shell pidof -s $PackageId | Out-String).Trim()
if ([string]::IsNullOrWhiteSpace($AppProcessId)) { throw "The app process stopped during final verification." }
$Logs = adb -s $DeviceId logcat --pid=$AppProcessId -d -v threadtime | Out-String
$Logs | Set-Content -LiteralPath $RuntimeLog -Encoding utf8
$BlockLoopCount = ([regex]::Matches($Logs, "FocusAccessibilityService\.performBlock")).Count
if ($BlockLoopCount -gt 2) {
    throw "Accessibility block-loop guard failed: performBlock appeared $BlockLoopCount times during final safe launch. Review $RuntimeLog"
}

$FatalPatterns = @(
    "FATAL EXCEPTION",
    "ANR in $PackageId",
    "E/flutter",
    "Another exception was thrown",
    "RenderFlex overflowed",
    "Failed assertion",
    "SecurityException",
    "ForegroundServiceStartNotAllowedException",
    "Unable to start service"
)
$FatalMatches = foreach ($Pattern in $FatalPatterns) {
    $Logs | Select-String -SimpleMatch $Pattern
}
if ($FatalMatches) {
    $FatalMatches | ForEach-Object { Write-Host $_.Line -ForegroundColor Red }
    throw "Runtime fatal-pattern scan failed. Review $RuntimeLog"
}
Add-Result -Area "Runtime" -Feature "Launch/crash/ANR/overflow and Accessibility-loop scan" -Status "PASS" -Evidence "$RuntimeLog • performBlock=$BlockLoopCount"

$ServiceDump = adb -s $DeviceId shell dumpsys activity services $PackageId | Out-String
$VpnRunning = $ServiceDump -match "ProtectionVpnService"
Add-Result -Area "Web & DNS" -Feature "Protection VPN service process" -Status $(if ($VpnRunning) { "RUNNING" } else { "NOT_RUNNING_OR_NOT_ENABLED" }) -Evidence "dumpsys activity services"

$ManualChecks = @(
    @{ Area = "Phone Control"; Feature = "Exact app-minute limit expires and blocks one safe test app" },
    @{ Area = "Social limits"; Feature = "Reels count/time and scroll budget increment on supported routes" },
    @{ Area = "Social limits"; Feature = "Per-app Reels dashboard shows viewed, minutes, remaining and blocked counters" },
    @{ Area = "Wellbeing"; Feature = "50% and 75% per-app Reels notifications arrive once with detailed text" },
    @{ Area = "Wellbeing"; Feature = "Screen-time goal milestone and over-goal repeat notifications arrive with details" },
    @{ Area = "Alarm"; Feature = "Search, preview and select early, middle and final sounds from the 216-sound library" },
    @{ Area = "Dashboard"; Feature = "Dashboard screen time starts at local midnight and controlled-app totals match Android Usage Access" },
    @{ Area = "Schedules"; Feature = "Recurring profile block-wins, emergency unlock and Resume Lock" },
    @{ Area = "Social"; Feature = "Selected notification is cancelled and recorded; calls/alarms remain allowed" },
    @{ Area = "Study Mode"; Feature = "Two-minute Study session updates subject/task/insights and Focus Tree" },
    @{ Area = "Study Mode"; Feature = "Only manually selected distracting apps are blocked during Study Mode" },
    @{ Area = "Web & DNS"; Feature = "Custom blocked domain returns blocked result; allow-list override still resolves" },
    @{ Area = "Web & DNS"; Feature = "Family DNS and fail-open/fail-closed behavior on the real network" },
    @{ Area = "Commitment"; Feature = "Prime Mode and Keep Me Out enforce until timer or permitted emergency unlock" },
    @{ Area = "Safety"; Feature = "Hredoy Flow, Home, Settings, phone, keyboard, emergency and banking apps stay available" },
    @{ Area = "Commitment"; Feature = "Explicit Prime/Keep Me Out block lists restore safely after reboot" },
    @{ Area = "Dashboard"; Feature = "Current action updates when a scheduled task starts or ends; visual slider remains smooth" },
    @{ Area = "Data"; Feature = "26 July routine, alarms, ringtones, goals and profile picture remain; old blocking policies are safely reset once" }
)
foreach ($Check in $ManualChecks) {
    Add-Result -Area $Check.Area -Feature $Check.Feature -Status "MANUAL_REQUIRED" -Evidence "Physical interaction/security boundary"
}

$Header = @"
Hredoy Flow 4.6.3 Production Feature Verification
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
Device: $DeviceId
Installed version: $InstalledVersion

Status meanings:
PASS / SOURCE_PASS = verified by build/source/runtime automation
READY = Android permission is enabled
NOT_READY = permission must be enabled before enforcement can work
MANUAL_REQUIRED = cannot be truthfully proven by a non-interactive ADB smoke test

"@
$Table = $Results | Format-Table -AutoSize | Out-String -Width 240
$Limitations = @"
Platform limits:
- A normal Android app cannot guarantee force-stop or uninstall prevention; this release uses fail-open Accessibility enforcement only for apps explicitly selected by the user.
- The local VPN is DNS-only and does not decrypt HTTPS or classify images.
- Private DNS or app-specific encrypted DNS can bypass DNS interception.
- Reels/Shorts counting and per-app milestone notifications depend on supported Accessibility route signals.
- AI NSFW image classification is not included.

Runtime launch output:
$Launch
"@
($Header + $Table + $Limitations) | Set-Content -LiteralPath $ReportFile -Encoding utf8

Write-Host "Final automated verification completed." -ForegroundColor Green
Write-Host "Feature matrix report: $ReportFile" -ForegroundColor Green
Write-Host "Runtime log: $RuntimeLog" -ForegroundColor Green
Write-Host "Permissions — Accessibility=$AccessibilityReady, Usage=$UsageReady, Notifications=$NotificationReady, Battery=$BatteryReady" -ForegroundColor Cyan
Write-Host "MANUAL_REQUIRED rows are intentional; complete them on the phone instead of treating them as automated passes." -ForegroundColor Yellow
