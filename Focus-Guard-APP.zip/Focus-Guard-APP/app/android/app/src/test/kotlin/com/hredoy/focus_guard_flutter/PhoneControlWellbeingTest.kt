package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneControlWellbeingTest {
    @Test
    fun reelsMilestonesRoundTripPerApp() {
        val rule = AppControlRule(
            packageName = "com.google.android.youtube",
            label = "YouTube",
            reelsGuard = true,
            reelsDailyLimit = 80,
            reelsTimeLimitMinutes = 40,
            reelsWarningPercentages = setOf(50, 75, 100)
        )

        val decoded = AppControlRule.fromMap(rule.toMap())

        assertEquals(80, decoded.reelsDailyLimit)
        assertEquals(40, decoded.reelsTimeLimitMinutes)
        assertEquals(setOf(50, 75, 100), decoded.reelsWarningPercentages)
    }

    @Test
    fun screenTimeWarningSettingsRoundTrip() {
        val policy = PhoneControlPolicy(
            wellbeingWarningsEnabled = true,
            screenTimeGoalMinutes = 300,
            screenTimeWarningPercentages = setOf(25, 50, 75, 100),
            screenTimeRepeatMinutes = 45,
            detailedWarningNotifications = true
        )

        val decoded = PhoneControlPolicy.fromMap(policy.toMap())

        assertTrue(decoded.wellbeingWarningsEnabled)
        assertEquals(300, decoded.screenTimeGoalMinutes)
        assertEquals(setOf(25, 50, 75, 100), decoded.screenTimeWarningPercentages)
        assertEquals(45, decoded.screenTimeRepeatMinutes)
        assertTrue(decoded.detailedWarningNotifications)
    }
}
