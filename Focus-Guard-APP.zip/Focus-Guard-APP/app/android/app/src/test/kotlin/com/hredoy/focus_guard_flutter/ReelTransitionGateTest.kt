package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReelTransitionGateTest {
    @Test
    fun `first reel counts only after two stable snapshots and initial dwell`() {
        val gate = ReelTransitionGate(initialDwellMillis = 900L)
        gate.enter("social.app", 1_000L)

        assertFalse(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 1_500L))
        assertFalse(gate.onStableFingerprint("social.app", "reel-a", "reel-b", 2_000L))
        assertTrue(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 2_050L))
    }

    @Test
    fun `noisy callbacks and repeated snapshots never duplicate a reel`() {
        val gate = ReelTransitionGate(initialDwellMillis = 0L, minimumTransitionGapMillis = 800L)
        gate.enter("social.app", 0L)

        assertTrue(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 100L))
        assertFalse(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 1_000L))
        assertFalse(gate.onStableFingerprint("social.app", "reel-a", "reel-b", 1_500L))
        assertFalse(gate.onStableFingerprint("social.app", "", "", 2_000L))
    }

    @Test
    fun `only a different stable reel identity counts after settle gap`() {
        val gate = ReelTransitionGate(initialDwellMillis = 0L, minimumTransitionGapMillis = 850L)
        gate.enter("social.app", 0L)

        assertTrue(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 100L))
        assertFalse(gate.onStableFingerprint("social.app", "reel-b", "reel-b", 500L))
        assertTrue(gate.onStableFingerprint("social.app", "reel-b", "reel-b", 1_100L))
        assertFalse(gate.onStableFingerprint("social.app", "reel-b", "reel-b", 2_100L))
        assertTrue(gate.onStableFingerprint("social.app", "reel-c", "reel-c", 2_200L))
    }

    @Test
    fun `initial Reel entry counts after dwell when identity text is hidden`() {
        val gate = ReelTransitionGate(initialDwellMillis = 900L)
        gate.enter("social.app", 1_000L)

        assertFalse(
            gate.confirmSettledCandidate(
                packageName = "social.app",
                firstFingerprint = "",
                secondFingerprint = "",
                fallbackToken = null,
                initialEntry = true,
                now = 1_700L
            ).accepted
        )
        val result = gate.confirmSettledCandidate(
            packageName = "social.app",
            firstFingerprint = "",
            secondFingerprint = "",
            fallbackToken = null,
            initialEntry = true,
            now = 2_000L
        )

        assertTrue(result.accepted)
        assertEquals(ReelConfirmationSource.INITIAL_ENTRY, result.source)
    }

    @Test
    fun `clustered pager fallback counts once when fingerprints are unavailable`() {
        val gate = ReelTransitionGate(initialDwellMillis = 0L, minimumTransitionGapMillis = 800L)
        gate.enter("social.app", 0L)
        assertTrue(
            gate.confirmSettledCandidate(
                packageName = "social.app",
                firstFingerprint = "reel-a",
                secondFingerprint = "reel-a",
                fallbackToken = null,
                initialEntry = false,
                now = 100L
            ).accepted
        )

        val firstFallback = gate.confirmSettledCandidate(
            packageName = "social.app",
            firstFingerprint = "",
            secondFingerprint = "",
            fallbackToken = "pager-1",
            initialEntry = false,
            now = 1_000L
        )
        val repeatedFallback = gate.confirmSettledCandidate(
            packageName = "social.app",
            firstFingerprint = "",
            secondFingerprint = "",
            fallbackToken = "pager-1",
            initialEntry = false,
            now = 2_000L
        )

        assertTrue(firstFallback.accepted)
        assertEquals(ReelConfirmationSource.PAGER_FALLBACK, firstFallback.source)
        assertFalse(repeatedFallback.accepted)
    }

    @Test
    fun `new pager candidate counts when apps expose only a static fingerprint`() {
        val gate = ReelTransitionGate(initialDwellMillis = 0L, minimumTransitionGapMillis = 800L)
        gate.enter("social.app", 0L)
        assertTrue(gate.onStableFingerprint("social.app", "static-ui", "static-ui", 100L))

        val result = gate.confirmSettledCandidate(
            packageName = "social.app",
            firstFingerprint = "static-ui",
            secondFingerprint = "static-ui",
            fallbackToken = "pager-2",
            initialEntry = false,
            now = 1_000L
        )

        assertTrue(result.accepted)
        assertEquals(ReelConfirmationSource.PAGER_FALLBACK, result.source)
    }

    @Test
    fun `fallback candidates inside minimum settle gap are rejected`() {
        val gate = ReelTransitionGate(initialDwellMillis = 0L, minimumTransitionGapMillis = 850L)
        gate.enter("social.app", 0L)
        assertTrue(gate.onStableFingerprint("social.app", "reel-a", "reel-a", 100L))

        assertFalse(
            gate.confirmSettledCandidate(
                packageName = "social.app",
                firstFingerprint = "",
                secondFingerprint = "",
                fallbackToken = "pager-too-fast",
                initialEntry = false,
                now = 700L
            ).accepted
        )
    }
}
