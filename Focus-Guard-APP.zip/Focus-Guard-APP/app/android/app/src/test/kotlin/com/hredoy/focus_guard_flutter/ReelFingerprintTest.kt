package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReelFingerprintTest {
    @Test
    fun `dynamic counters and timestamps are removed from identity tokens`() {
        assertEquals("creator name", ReelFingerprintBuilder.normalizeIdentityToken("Creator Name 12.4K 00:18"))
        assertEquals("", ReelFingerprintBuilder.normalizeIdentityToken("12.4K"))
        assertEquals("", ReelFingerprintBuilder.normalizeIdentityToken("Like"))
    }

    @Test
    fun `same reel tokens produce the same fingerprint regardless of callback order`() {
        val first = ReelFingerprintBuilder.fromRawTokens(
            "social.app",
            listOf("@creator", "A useful caption", "12.4K")
        )
        val second = ReelFingerprintBuilder.fromRawTokens(
            "social.app",
            listOf("A useful caption", "@creator", "99K")
        )

        assertTrue(first.usable)
        assertEquals(first.value, second.value)
    }

    @Test
    fun `different reel identity text produces a different fingerprint`() {
        val first = ReelFingerprintBuilder.fromRawTokens(
            "social.app",
            listOf("@creator", "First lesson")
        )
        val second = ReelFingerprintBuilder.fromRawTokens(
            "social.app",
            listOf("@creator", "Second lesson")
        )

        assertFalse(first.value.isBlank())
        assertNotEquals(first.value, second.value)
    }
}
