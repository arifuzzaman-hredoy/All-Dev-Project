package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class PhoneControlCommitmentTest {
    @Test
    fun minimumCommitmentUsesAtLeastTwentyPercent() {
        val rule = AppControlRule(
            packageName = "com.example.social",
            label = "Social",
            dailyLimitMinutes = 100,
            commitmentPercent = 20
        )
        assertEquals(20, rule.minimumCommitmentMinutes())
        assertTrue(rule.isRestrictive())
    }

    @Test
    fun automaticStudyScheduleSupportsOvernightWindows() {
        val policy = PhoneControlPolicy(
            studyScheduleEnabled = true,
            studyWeekdays = setOf(5),
            studyStartMinute = 22 * 60,
            studyEndMinute = 6 * 60
        )
        assertTrue(policy.studyScheduleActive(at(2026, Calendar.JULY, 24, 23)))
        assertTrue(policy.studyScheduleActive(at(2026, Calendar.JULY, 25, 5)))
        assertFalse(policy.studyScheduleActive(at(2026, Calendar.JULY, 25, 7)))
    }

    @Test
    fun fixedReelsWindowCanTargetOneAppOrAllApps() {
        val start = 1_000L
        val policy = PhoneControlPolicy(
            globalReelsWindowEnabled = true,
            globalReelsWindowStartMillis = start,
            globalReelsWindowEndMillis = 10_000L,
            globalReelsWindowLimit = 5_000,
            globalReelsWindowPackages = setOf("com.google.android.youtube"),
            globalReelsWindowLocked = true
        )
        assertTrue(policy.globalReelsWindowActive(5_000L))
        assertTrue(policy.globalReelsWindowApplies("com.google.android.youtube"))
        assertFalse(policy.globalReelsWindowApplies("com.instagram.android"))
        assertEquals(5_000, policy.globalReelsWindowLimit)
    }

    private fun at(
        year: Int,
        month: Int,
        day: Int,
        hour: Int,
        minute: Int = 0
    ): Calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(year, month, day, hour, minute, 0)
    }
}
