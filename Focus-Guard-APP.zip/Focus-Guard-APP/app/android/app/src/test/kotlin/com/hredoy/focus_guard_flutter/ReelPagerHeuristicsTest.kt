package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReelPagerHeuristicsTest {
    @Test
    fun `hidden event source still accepts a large Reel pager transition`() {
        val reason = ReelPagerHeuristics.confirmationReason(
            ReelPagerHeuristicInput(
                routeConfirmed = true,
                strongRouteSource = false,
                pagerClass = false,
                fillsMostOfScreen = true,
                indexChanged = false,
                largeVerticalDelta = true,
                compactPagerCollection = false,
                sourceMissing = true,
                nonPagerSurface = false
            )
        )

        assertEquals("route-delta", reason)
    }

    @Test
    fun `comment and caption surfaces are always rejected`() {
        val reason = ReelPagerHeuristics.confirmationReason(
            ReelPagerHeuristicInput(
                routeConfirmed = true,
                strongRouteSource = true,
                pagerClass = true,
                fillsMostOfScreen = true,
                indexChanged = true,
                largeVerticalDelta = true,
                compactPagerCollection = true,
                sourceMissing = false,
                nonPagerSurface = true
            )
        )

        assertNull(reason)
    }

    @Test
    fun `small nested scroll without pager evidence is rejected`() {
        val reason = ReelPagerHeuristics.confirmationReason(
            ReelPagerHeuristicInput(
                routeConfirmed = true,
                strongRouteSource = false,
                pagerClass = false,
                fillsMostOfScreen = false,
                indexChanged = false,
                largeVerticalDelta = false,
                compactPagerCollection = false,
                sourceMissing = false,
                nonPagerSurface = false
            )
        )

        assertNull(reason)
    }

    @Test
    fun `unconfirmed route never becomes a Reel transition`() {
        val reason = ReelPagerHeuristics.confirmationReason(
            ReelPagerHeuristicInput(
                routeConfirmed = false,
                strongRouteSource = true,
                pagerClass = true,
                fillsMostOfScreen = true,
                indexChanged = true,
                largeVerticalDelta = true,
                compactPagerCollection = true,
                sourceMissing = false,
                nonPagerSurface = false
            )
        )

        assertNull(reason)
    }
}
