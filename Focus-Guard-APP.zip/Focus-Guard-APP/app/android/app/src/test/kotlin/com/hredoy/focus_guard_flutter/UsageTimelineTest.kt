package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertEquals
import org.junit.Test

class UsageTimelineTest {
    @Test
    fun foregroundCarriedAcrossMidnightStartsAtWindowBoundary() {
        val result = UsageTimeline.calculate(
            transitions = listOf(
                UsageTransition(500L, "app.one", UsageTransitionType.FOREGROUND),
                UsageTransition(1_500L, "app.one", UsageTransitionType.BACKGROUND)
            ),
            windowStartMillis = 1_000L,
            windowEndMillis = 2_000L
        )

        assertEquals(500L, result.totalScreenTimeMillis)
        assertEquals(500L, result.usageByPackage["app.one"])
    }

    @Test
    fun appSwitchesDoNotDoubleCountTotalScreenTime() {
        val result = UsageTimeline.calculate(
            transitions = listOf(
                UsageTransition(1_000L, "app.one", UsageTransitionType.FOREGROUND),
                UsageTransition(2_000L, "app.two", UsageTransitionType.FOREGROUND),
                UsageTransition(3_000L, "app.one", UsageTransitionType.BACKGROUND),
                UsageTransition(4_000L, "app.two", UsageTransitionType.BACKGROUND)
            ),
            windowStartMillis = 1_000L,
            windowEndMillis = 5_000L
        )

        assertEquals(3_000L, result.totalScreenTimeMillis)
        assertEquals(1_000L, result.usageByPackage["app.one"])
        assertEquals(2_000L, result.usageByPackage["app.two"])
    }

    @Test
    fun screenOffClosesTheForegroundInterval() {
        val result = UsageTimeline.calculate(
            transitions = listOf(
                UsageTransition(1_000L, "app.one", UsageTransitionType.FOREGROUND),
                UsageTransition(2_500L, "", UsageTransitionType.SCREEN_OFF)
            ),
            windowStartMillis = 1_000L,
            windowEndMillis = 5_000L
        )

        assertEquals(1_500L, result.totalScreenTimeMillis)
        assertEquals(1_500L, result.usageByPackage["app.one"])
    }

    @Test
    fun invalidWindowReturnsZeroWithoutNegativeDurations() {
        val result = UsageTimeline.calculate(
            transitions = listOf(
                UsageTransition(1_000L, "app.one", UsageTransitionType.FOREGROUND)
            ),
            windowStartMillis = 2_000L,
            windowEndMillis = 2_000L
        )

        assertEquals(0L, result.totalScreenTimeMillis)
        assertEquals(emptyMap<String, Long>(), result.usageByPackage)
    }
}
