package com.hredoy.focus_guard_flutter

import android.content.pm.ApplicationInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneControlSafetyTest {
    @Test
    fun hredoyFlowAndEssentialPackagesAreAlwaysProtected() {
        assertTrue(PhoneControlSafety.isProtectedPackage("com.hredoy.focus_guard_flutter"))
        assertTrue(PhoneControlSafety.isProtectedPackage("com.android.settings"))
        assertTrue(PhoneControlSafety.isProtectedPackage("com.samsung.android.dialer"))
        assertTrue(PhoneControlSafety.isProtectedPackage("com.bKash.customerapp"))
    }

    @Test
    fun socialAppsAreReviewCandidatesButNeverAutoBlocked() {
        val profile = AppSafetyClassifier.classify(
            packageName = "com.instagram.android",
            label = "Instagram",
            applicationFlags = 0,
            applicationCategory = ApplicationInfo.CATEGORY_SOCIAL
        )

        assertEquals("social", profile.category)
        assertEquals("review", profile.recommendation)
        assertFalse(profile.protected)
        assertTrue(profile.suggestedReelsGuard)
    }

    @Test
    fun educationAppsAreDetectedAndAllowedByDefault() {
        val education = AppSafetyClassifier.classify(
            packageName = "org.khanacademy.android",
            label = "Khan Academy",
            applicationFlags = 0,
            applicationCategory = ApplicationInfo.CATEGORY_UNDEFINED
        )
        assertEquals("education", education.category)
        assertEquals("allow", education.recommendation)
        assertFalse(education.suggestedReelsGuard)
    }

    @Test
    fun productiveAndSystemAppsStayAllowedByDefault() {
        val productive = AppSafetyClassifier.classify(
            packageName = "com.example.docs",
            label = "Docs",
            applicationFlags = 0,
            applicationCategory = ApplicationInfo.CATEGORY_PRODUCTIVITY
        )
        val system = AppSafetyClassifier.classify(
            packageName = "com.vendor.tool",
            label = "Vendor Tool",
            applicationFlags = ApplicationInfo.FLAG_SYSTEM,
            applicationCategory = ApplicationInfo.CATEGORY_UNDEFINED
        )

        assertEquals("allow", productive.recommendation)
        assertEquals("allow", system.recommendation)
    }
}
