package com.hredoy.focus_guard_flutter

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class PhoneControlRuleScheduleTest {
    @Test
    fun configuredScheduleIsFailOpenUntilRestrictionIsEnabled() {
        val rule = AppControlRule(
            packageName = "com.example.video",
            label = "Video",
            allowedWeekdays = setOf(1, 2, 3, 4, 5),
            allowedStartMinute = 8 * 60,
            allowedEndMinute = 18 * 60
        )

        assertTrue(rule.isAllowedAt(at(2026, Calendar.JULY, 26, 23)))
        assertFalse(
            rule.copy(blockOutsideSchedule = true)
                .isAllowedAt(at(2026, Calendar.JULY, 26, 23))
        )
    }

    @Test
    fun sameDayScheduleUsesSelectedWeekdaysAndTimeWindow() {
        val rule = AppControlRule(
            packageName = "com.example.social",
            label = "Social",
            blockOutsideSchedule = true,
            allowedWeekdays = setOf(1, 2, 3, 4, 5),
            allowedStartMinute = 8 * 60,
            allowedEndMinute = 18 * 60
        )

        assertTrue(rule.isAllowedAt(at(2026, Calendar.JULY, 27, 9)))
        assertFalse(rule.isAllowedAt(at(2026, Calendar.JULY, 27, 19)))
        assertFalse(rule.isAllowedAt(at(2026, Calendar.JULY, 26, 9)))
    }

    @Test
    fun overnightScheduleCarriesIntoTheFollowingCalendarDay() {
        val rule = AppControlRule(
            packageName = "com.example.chat",
            label = "Chat",
            blockOutsideSchedule = true,
            allowedWeekdays = setOf(5),
            allowedStartMinute = 22 * 60,
            allowedEndMinute = 6 * 60
        )

        assertTrue(rule.isAllowedAt(at(2026, Calendar.JULY, 24, 23)))
        assertTrue(rule.isAllowedAt(at(2026, Calendar.JULY, 25, 5, 30)))
        assertFalse(rule.isAllowedAt(at(2026, Calendar.JULY, 25, 7)))
    }

    private fun at(
        year: Int,
        month: Int,
        day: Int,
        hour: Int,
        minute: Int = 0
    ): Calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(year, month, day, hour, minute, 0)
    }
}
