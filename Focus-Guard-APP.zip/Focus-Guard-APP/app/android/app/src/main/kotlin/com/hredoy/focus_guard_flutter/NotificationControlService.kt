package com.hredoy.focus_guard_flutter

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

object NotificationAccess {
    fun isEnabled(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)
}

class NotificationControlService : NotificationListenerService() {
    private val phoneStore by lazy { PhoneControlStore(this) }
    private val focusStore by lazy { FocusStore(this) }
    private val protectionStore by lazy { ProtectionStore(this) }
    private val recentKeys = ConcurrentHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        val packageName = sbn.packageName?.trim().orEmpty()
        if (packageName.isBlank() || packageName == this.packageName) return
        if (isSafetyCritical(notification)) return
        val shouldBlock = phoneStore.shouldBlockNotification(
            packageName,
            Calendar.getInstance(),
            focusStore.isFocusActive()
        ) || protectionStore.shouldBlockNotification(packageName)
        if (!shouldBlock) return

        val now = System.currentTimeMillis()
        val previous = recentKeys.put(sbn.key, now)
        if (previous != null && now - previous < DUPLICATE_WINDOW_MILLIS) return
        if (recentKeys.size > MAX_RECENT_KEYS) {
            recentKeys.entries.removeIf { now - it.value > DUPLICATE_WINDOW_MILLIS }
        }

        val extras = notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (
            extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras?.getCharSequence(Notification.EXTRA_TEXT)
            )?.toString().orEmpty()
        val appLabel = runCatching {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(packageName)

        runCatching { cancelNotification(sbn.key) }
        phoneStore.recordNotificationBlocked(
            packageName = packageName,
            appLabel = appLabel,
            title = title,
            text = text
        )
    }

    private fun isSafetyCritical(notification: Notification): Boolean {
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return true
        return notification.category in setOf(
            Notification.CATEGORY_ALARM,
            Notification.CATEGORY_CALL,
            Notification.CATEGORY_NAVIGATION,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_TRANSPORT
        )
    }

    companion object {
        private const val DUPLICATE_WINDOW_MILLIS = 2_000L
        private const val MAX_RECENT_KEYS = 250
    }
}
