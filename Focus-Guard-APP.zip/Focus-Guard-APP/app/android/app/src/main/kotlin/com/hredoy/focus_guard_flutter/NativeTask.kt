package com.hredoy.focus_guard_flutter

import android.content.Intent
import org.json.JSONObject

data class NativeTask(
    val id: String,
    val triggerAtMillis: Long,
    val title: String,
    val category: String,
    val notes: String,
    val durationMinutes: Int,
    val alarmEnabled: Boolean,
    val snoozeMinutes: Int,
    val alarmSoundId: String = "smart",
    val alarmSoundLabel: String = "Smart by task type",
    val alarmSoundUri: String = "",
    val autoFocus: Boolean,
    val isSnoozed: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("triggerAtMillis", triggerAtMillis)
        .put("title", title)
        .put("category", category)
        .put("notes", notes)
        .put("durationMinutes", durationMinutes)
        .put("alarmEnabled", alarmEnabled)
        .put("snoozeMinutes", snoozeMinutes)
        .put("alarmSoundId", alarmSoundId)
        .put("alarmSoundLabel", alarmSoundLabel)
        .put("alarmSoundUri", alarmSoundUri)
        .put("autoFocus", autoFocus)
        .put("isSnoozed", isSnoozed)

    fun toIntent(intent: Intent): Intent = intent.apply {
        putExtra("id", id)
        putExtra("triggerAtMillis", triggerAtMillis)
        putExtra("title", title)
        putExtra("category", category)
        putExtra("notes", notes)
        putExtra("durationMinutes", durationMinutes)
        putExtra("alarmEnabled", alarmEnabled)
        putExtra("snoozeMinutes", snoozeMinutes)
        putExtra("alarmSoundId", alarmSoundId)
        putExtra("alarmSoundLabel", alarmSoundLabel)
        putExtra("alarmSoundUri", alarmSoundUri)
        putExtra("autoFocus", autoFocus)
        putExtra("isSnoozed", isSnoozed)
    }

    companion object {
        fun fromMap(map: Map<*, *>): NativeTask = NativeTask(
            id = map["id"]?.toString() ?: error("Task id is required"),
            triggerAtMillis = (map["triggerAtMillis"] as Number).toLong(),
            title = map["title"]?.toString() ?: "Task reminder",
            category = map["category"]?.toString() ?: "General",
            notes = map["notes"]?.toString() ?: "",
            durationMinutes = (map["durationMinutes"] as? Number)?.toInt() ?: 0,
            alarmEnabled = map["alarmEnabled"] as? Boolean ?: true,
            snoozeMinutes = (map["snoozeMinutes"] as? Number)?.toInt() ?: 5,
            alarmSoundId = map["alarmSoundId"]?.toString() ?: "smart",
            alarmSoundLabel = map["alarmSoundLabel"]?.toString()
                ?: "Smart by task type",
            alarmSoundUri = map["alarmSoundUri"]?.toString() ?: "",
            autoFocus = map["autoFocus"] as? Boolean ?: false,
            isSnoozed = map["isSnoozed"] as? Boolean ?: false
        )

        fun fromJson(json: JSONObject): NativeTask = NativeTask(
            id = json.getString("id"),
            triggerAtMillis = json.getLong("triggerAtMillis"),
            title = json.optString("title", "Task reminder"),
            category = json.optString("category", "General"),
            notes = json.optString("notes", ""),
            durationMinutes = json.optInt("durationMinutes", 0),
            alarmEnabled = json.optBoolean("alarmEnabled", true),
            snoozeMinutes = json.optInt("snoozeMinutes", 5),
            alarmSoundId = json.optString("alarmSoundId", "smart"),
            alarmSoundLabel = json.optString(
                "alarmSoundLabel",
                "Smart by task type"
            ),
            alarmSoundUri = json.optString("alarmSoundUri", ""),
            autoFocus = json.optBoolean("autoFocus", false),
            isSnoozed = json.optBoolean("isSnoozed", false)
        )

        fun fromIntent(intent: Intent): NativeTask = NativeTask(
            id = intent.getStringExtra("id") ?: "routine",
            triggerAtMillis = intent.getLongExtra(
                "triggerAtMillis",
                System.currentTimeMillis()
            ),
            title = intent.getStringExtra("title") ?: "Task reminder",
            category = intent.getStringExtra("category") ?: "General",
            notes = intent.getStringExtra("notes") ?: "",
            durationMinutes = intent.getIntExtra("durationMinutes", 0),
            alarmEnabled = intent.getBooleanExtra("alarmEnabled", true),
            snoozeMinutes = intent.getIntExtra("snoozeMinutes", 5),
            alarmSoundId = intent.getStringExtra("alarmSoundId") ?: "smart",
            alarmSoundLabel = intent.getStringExtra("alarmSoundLabel")
                ?: "Smart by task type",
            alarmSoundUri = intent.getStringExtra("alarmSoundUri") ?: "",
            autoFocus = intent.getBooleanExtra("autoFocus", false),
            isSnoozed = intent.getBooleanExtra("isSnoozed", false)
        )
    }
}
