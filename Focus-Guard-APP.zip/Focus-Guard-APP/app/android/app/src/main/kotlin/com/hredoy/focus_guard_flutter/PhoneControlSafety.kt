package com.hredoy.focus_guard_flutter

object PhoneControlSafety {
    const val APP_PACKAGE = "com.hredoy.focus_guard_flutter"

    private val exactProtectedPackages = setOf(
        APP_PACKAGE,
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller"
    )

    private val protectedTokens = setOf(
        "systemui",
        "settings",
        "launcher",
        "home",
        "dialer",
        "incallui",
        "telecom",
        "emergency",
        "permissioncontroller",
        "packageinstaller",
        "inputmethod",
        "keyboard",
        "authenticator",
        "contacts",
        "messages",
        "messaging",
        "camera",
        "clock",
        "alarm",
        "calendar",
        "navigation",
        "maps",
        "bank",
        "bkash",
        "nagad",
        "rocket",
        "wallet",
        "payment"
    )

    fun isProtectedPackage(packageName: String): Boolean {
        val value = packageName.trim().lowercase()
        if (value.isBlank()) return true
        if (value in exactProtectedPackages) return true
        return protectedTokens.any(value::contains)
    }

    fun sanitizePackages(packages: Set<String>): Set<String> = packages
        .map(String::trim)
        .filter(String::isNotBlank)
        .filterNot(::isProtectedPackage)
        .toSet()
}
