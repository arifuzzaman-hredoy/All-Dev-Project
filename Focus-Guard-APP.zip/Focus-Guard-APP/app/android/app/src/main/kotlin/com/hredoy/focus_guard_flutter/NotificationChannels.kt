package com.hredoy.focus_guard_flutter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object NotificationChannels {
    const val ROUTINE = "hredoy_flow_routine_v3"
    const val TASK_ALARM = "hredoy_flow_task_alarm_v3"
    const val FOCUS = "hredoy_flow_focus_v3"
    const val PROTECTION = "hredoy_flow_protection_v1"
    const val WELLBEING = "hredoy_flow_wellbeing_v1"

    fun ensure(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)

        manager.createNotificationChannel(
            NotificationChannel(
                ROUTINE,
                "Task notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for scheduled Hredoy Flow tasks"
                enableVibration(true)
            }
        )

        manager.createNotificationChannel(
            NotificationChannel(
                TASK_ALARM,
                "Full-screen task alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarm-clock style task alerts"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 700, 350, 700, 350, 1000)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setSound(null, null)
                runCatching { setBypassDnd(true) }
            }
        )

        manager.createNotificationChannel(
            NotificationChannel(
                FOCUS,
                "Focus updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Focus session status and completion"
            }
        )

        manager.createNotificationChannel(
            NotificationChannel(
                PROTECTION,
                "Protection service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Local DNS and website protection status"
                setShowBadge(false)
            }
        )

        manager.createNotificationChannel(
            NotificationChannel(
                WELLBEING,
                "Screen-time and Reels warnings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Detailed progress warnings for screen time, Reels and Shorts"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 180, 350)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
    }
}
