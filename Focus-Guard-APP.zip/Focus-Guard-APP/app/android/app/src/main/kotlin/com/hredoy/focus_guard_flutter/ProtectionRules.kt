package com.hredoy.focus_guard_flutter

import android.net.Uri
import java.net.IDN
import java.util.Locale

object ProtectionRules {
    private val browserPackages = setOf(
        "com.android.chrome",
        "com.sec.android.app.sbrowser",
        "org.mozilla.firefox",
        "org.mozilla.fenix",
        "com.microsoft.emmx",
        "com.brave.browser",
        "com.opera.browser",
        "com.opera.mini.native",
        "com.duckduckgo.mobile.android",
        "com.kiwibrowser.browser",
        "com.vivaldi.browser"
    )

    private val tamperPackageTokens = setOf(
        "settings",
        "permissioncontroller",
        "packageinstaller",
        "vending",
        "packageinspector"
    )

    private val adultDomainLabels = setOf(
        "porn",
        "porno",
        "pornhub",
        "xvideos",
        "xnxx",
        "xxx",
        "redtube",
        "youporn",
        "sexcam",
        "sexvideo",
        "hentai",
        "rule34",
        "brazzers",
        "onlyfans",
        "adultfriendfinder",
        "chaturbate",
        "stripchat",
        "livejasmin",
        "cam4"
    )

    private val safeSearchHosts = setOf(
        "google.com",
        "www.google.com",
        "google.com.bd",
        "www.google.com.bd",
        "bing.com",
        "www.bing.com",
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com"
    )

    fun isBrowserPackage(packageName: String): Boolean {
        val value = packageName.trim().lowercase(Locale.US)
        return value in browserPackages ||
            value.contains("browser") ||
            value.contains("chrome") ||
            value.contains("firefox")
    }

    fun isTamperPackage(packageName: String): Boolean {
        val value = packageName.trim().lowercase(Locale.US)
        return tamperPackageTokens.any(value::contains)
    }

    fun normalizeDomain(raw: String): String {
        var value = raw.trim().lowercase(Locale.US)
        if (value.isBlank()) return ""
        value = value.removePrefix("http://").removePrefix("https://")
        value = value.substringBefore('/').substringBefore(':').trim('.')
        return runCatching { IDN.toASCII(value) }.getOrDefault(value)
    }

    fun isValidIpv4(value: String): Boolean {
        val parts = value.trim().split('.')
        if (parts.size != 4) return false
        return parts.all { part ->
            part.isNotEmpty() && part.length <= 3 &&
                part.all(Char::isDigit) &&
                part.toIntOrNull() in 0..255
        }
    }

    fun hostMatches(domain: String, rule: String): Boolean {
        val normalizedDomain = normalizeDomain(domain)
        val normalizedRule = normalizeDomain(rule).removePrefix("*.")
        if (normalizedDomain.isBlank() || normalizedRule.isBlank()) return false
        return normalizedDomain == normalizedRule ||
            normalizedDomain.endsWith(".$normalizedRule")
    }

    fun isLocallyClassifiedAdult(domain: String): Boolean {
        val labels = normalizeDomain(domain).split('.')
        return labels.any { label ->
            adultDomainLabels.any { token ->
                label == token ||
                    label.startsWith("$token-") ||
                    label.endsWith("-$token") ||
                    label.contains("-$token-")
            }
        }
    }

    fun isAllowedDomain(domain: String, policy: ProtectionPolicy): Boolean =
        policy.allowedDomains.any { rule -> hostMatches(domain, rule) }

    fun domainBlockReason(domain: String, policy: ProtectionPolicy): String? {
        val normalized = normalizeDomain(domain)
        if (normalized.isBlank() || isAllowedDomain(normalized, policy)) return null
        if (policy.blockedDomains.any { rule -> hostMatches(normalized, rule) }) {
            return "Custom domain block"
        }
        if (policy.adultContentEnabled && isLocallyClassifiedAdult(normalized)) {
            return "Adult-content protection"
        }
        return null
    }

    fun extractHost(raw: String): String {
        val text = raw.trim()
        if (text.isBlank()) return ""
        val candidate = when {
            text.startsWith("http://", true) || text.startsWith("https://", true) -> text
            text.contains('.') && !text.contains(' ') -> "https://$text"
            else -> return ""
        }
        return runCatching { Uri.parse(candidate).host.orEmpty() }
            .getOrDefault("")
            .let(::normalizeDomain)
    }

    fun safeSearchBlockReason(urlOrText: String, policy: ProtectionPolicy): String? {
        if (!policy.safeSearchEnabled) return null
        val lower = urlOrText.lowercase(Locale.US)
        val host = extractHost(urlOrText)
        if (host.isBlank() || safeSearchHosts.none { hostMatches(host, it) }) return null
        if ("safe=off" in lower || "safesearch=off" in lower || "restricted_mode=off" in lower) {
            return "Safe Search cannot be disabled while protection is active"
        }
        val decoded = runCatching { Uri.decode(lower) }.getOrDefault(lower)
        val keyword = policy.blockedKeywords.firstOrNull { value ->
            val normalized = value.trim().lowercase(Locale.US)
            normalized.isNotBlank() && decoded.contains(normalized)
        }
        return keyword?.let { "Safe Search blocked keyword: $it" }
    }
}
