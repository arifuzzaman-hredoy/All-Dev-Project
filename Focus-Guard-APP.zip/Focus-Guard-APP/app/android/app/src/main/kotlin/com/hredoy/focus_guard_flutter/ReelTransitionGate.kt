package com.hredoy.focus_guard_flutter

enum class ReelConfirmationSource {
    FINGERPRINT,
    PAGER_FALLBACK,
    INITIAL_ENTRY
}

data class ReelTransitionConfirmation(
    val accepted: Boolean,
    val source: ReelConfirmationSource? = null
)

/**
 * Confirms one settled Reel transition after Accessibility callbacks have gone
 * quiet. A stable privacy-safe fingerprint is preferred. When an app hides all
 * identity text, a clustered full-screen pager candidate can be used as a
 * guarded fallback. Raw callbacks never increment the counter directly.
 */
class ReelTransitionGate(
    private val initialDwellMillis: Long = 900L,
    private val minimumTransitionGapMillis: Long = 850L
) {
    private var activePackage: String? = null
    private var enteredAt: Long = 0L
    private var lastAcceptedAt: Long = 0L
    private var lastAcceptedFingerprint: String? = null
    private var lastAcceptedFallbackToken: String? = null

    fun reset() {
        activePackage = null
        enteredAt = 0L
        lastAcceptedAt = 0L
        lastAcceptedFingerprint = null
        lastAcceptedFallbackToken = null
    }

    fun enter(packageName: String, now: Long) {
        if (packageName.isBlank()) return
        if (activePackage == packageName) return
        activePackage = packageName
        enteredAt = now
        lastAcceptedAt = 0L
        lastAcceptedFingerprint = null
        lastAcceptedFallbackToken = null
    }

    fun leave(packageName: String? = null) {
        if (packageName == null || activePackage == packageName) reset()
    }

    fun confirmSettledCandidate(
        packageName: String,
        firstFingerprint: String,
        secondFingerprint: String,
        fallbackToken: String?,
        initialEntry: Boolean,
        now: Long
    ): ReelTransitionConfirmation {
        if (packageName.isBlank() || activePackage != packageName) {
            return ReelTransitionConfirmation(false)
        }

        val hasAcceptedReel = lastAcceptedAt > 0L
        if (!hasAcceptedReel && now - enteredAt < initialDwellMillis) {
            return ReelTransitionConfirmation(false)
        }
        if (hasAcceptedReel && now - lastAcceptedAt < minimumTransitionGapMillis) {
            return ReelTransitionConfirmation(false)
        }

        val stableFingerprint = firstFingerprint.isNotBlank() &&
            firstFingerprint == secondFingerprint
        val previousFingerprint = lastAcceptedFingerprint
        if (stableFingerprint &&
            (previousFingerprint == null || firstFingerprint != previousFingerprint)
        ) {
            accept(
                now = now,
                fingerprint = firstFingerprint,
                fallbackToken = fallbackToken
            )
            return ReelTransitionConfirmation(true, ReelConfirmationSource.FINGERPRINT)
        }

        val cleanFallbackToken = fallbackToken?.trim().orEmpty()
        if (cleanFallbackToken.isNotBlank() &&
            cleanFallbackToken != lastAcceptedFallbackToken
        ) {
            accept(
                now = now,
                fingerprint = if (stableFingerprint) firstFingerprint else null,
                fallbackToken = cleanFallbackToken
            )
            return ReelTransitionConfirmation(true, ReelConfirmationSource.PAGER_FALLBACK)
        }

        if (!hasAcceptedReel && initialEntry) {
            accept(
                now = now,
                fingerprint = if (stableFingerprint) firstFingerprint else null,
                fallbackToken = null
            )
            return ReelTransitionConfirmation(true, ReelConfirmationSource.INITIAL_ENTRY)
        }

        return ReelTransitionConfirmation(false)
    }

    fun onStableFingerprint(
        packageName: String,
        firstFingerprint: String,
        secondFingerprint: String,
        now: Long
    ): Boolean = confirmSettledCandidate(
        packageName = packageName,
        firstFingerprint = firstFingerprint,
        secondFingerprint = secondFingerprint,
        fallbackToken = null,
        initialEntry = false,
        now = now
    ).accepted

    private fun accept(
        now: Long,
        fingerprint: String?,
        fallbackToken: String?
    ) {
        lastAcceptedAt = now
        if (!fingerprint.isNullOrBlank()) {
            lastAcceptedFingerprint = fingerprint
        }
        if (!fallbackToken.isNullOrBlank()) {
            lastAcceptedFallbackToken = fallbackToken
        }
    }
}
