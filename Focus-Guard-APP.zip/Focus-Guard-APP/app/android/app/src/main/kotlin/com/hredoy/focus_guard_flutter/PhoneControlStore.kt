package com.hredoy.focus_guard_flutter

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class PhoneControlStore(context: Context) {
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    @Volatile private var cachedPolicyRaw: String? = null
    @Volatile private var cachedPolicy: PhoneControlPolicy? = null

    init {
        ensureReelCounterSchema()
    }

    @Synchronized
    fun policy(): PhoneControlPolicy {
        val raw = preferences.getString(KEY_POLICY, null)
        val existing = cachedPolicy
        if (existing != null && raw == cachedPolicyRaw) return existing
        val decoded = sanitizePolicy(PhoneControlPolicy.fromJson(raw))
        val safeRaw = decoded.toJson().toString()
        if (raw != safeRaw) {
            preferences.edit().putString(KEY_POLICY, safeRaw).apply()
        }
        cachedPolicyRaw = safeRaw
        cachedPolicy = decoded
        return decoded
    }

    @Synchronized
    fun savePolicy(policy: PhoneControlPolicy) {
        val existing = sanitizePolicy(
            PhoneControlPolicy.fromJson(preferences.getString(KEY_POLICY, null))
        )
        val requested = sanitizePolicy(policy)
        val safe = enforceCommitmentWindows(existing, requested)
        val raw = safe.toJson().toString()
        cachedPolicyRaw = raw
        cachedPolicy = safe
        preferences.edit().putString(KEY_POLICY, raw).apply()
    }

    private fun enforceCommitmentWindows(
        existing: PhoneControlPolicy,
        requested: PhoneControlPolicy
    ): PhoneControlPolicy {
        val now = System.currentTimeMillis()
        val requestedByPackage = requested.rules.associateBy { it.packageName }.toMutableMap()

        existing.rules.forEach { oldRule ->
            if (oldRule.commitmentLockedUntilMillis > now) {
                requestedByPackage[oldRule.packageName] = oldRule
            }
        }

        val mergedRules = requestedByPackage.values.map { nextRule ->
            val oldRule = existing.rules.firstOrNull { it.packageName == nextRule.packageName }
            if (!nextRule.isRestrictive()) {
                nextRule.copy(commitmentLockedUntilMillis = 0L)
            } else if ((oldRule?.commitmentLockedUntilMillis ?: 0L) > now) {
                oldRule!!
            } else {
                val stronger = oldRule == null || becameMoreRestrictive(oldRule, nextRule)
                if (stronger && nextRule.commitmentLockedUntilMillis <= now) {
                    nextRule.copy(
                        commitmentLockedUntilMillis = now +
                            nextRule.minimumCommitmentMinutes() * 60_000L
                    )
                } else {
                    nextRule
                }
            }
        }.sortedBy { it.label.lowercase() }

        val existingWindowLocked = existing.globalReelsWindowEnabled &&
            existing.globalReelsWindowStartMillis > 0L &&
            existing.globalReelsWindowEndMillis > now &&
            (existing.globalReelsWindowLocked || now >= existing.globalReelsWindowStartMillis)
        val windowPolicy = if (existingWindowLocked) {
            requested.copy(
                globalReelsWindowEnabled = existing.globalReelsWindowEnabled,
                globalReelsWindowStartMillis = existing.globalReelsWindowStartMillis,
                globalReelsWindowEndMillis = existing.globalReelsWindowEndMillis,
                globalReelsWindowLimit = existing.globalReelsWindowLimit,
                globalReelsWindowPackages = existing.globalReelsWindowPackages,
                globalReelsWindowLocked = true
            )
        } else {
            val validWindow = requested.globalReelsWindowEnabled &&
                requested.globalReelsWindowStartMillis > 0L &&
                requested.globalReelsWindowEndMillis > requested.globalReelsWindowStartMillis &&
                requested.globalReelsWindowLimit > 0
            requested.copy(
                globalReelsWindowLocked = validWindow &&
                    (requested.globalReelsWindowLocked ||
                        now >= requested.globalReelsWindowStartMillis)
            )
        }

        return sanitizePolicy(windowPolicy.copy(rules = mergedRules))
    }

    private fun becameMoreRestrictive(old: AppControlRule, next: AppControlRule): Boolean =
        (!old.enabled && next.enabled) ||
            (!old.blockApp && next.blockApp) ||
            (!old.blockOutsideSchedule && next.blockOutsideSchedule) ||
            (next.dailyLimitMinutes > 0 &&
                (old.dailyLimitMinutes <= 0 || next.dailyLimitMinutes < old.dailyLimitMinutes)) ||
            (!old.reelsGuard && next.reelsGuard) ||
            (!old.blockReelsImmediately && next.blockReelsImmediately) ||
            (next.reelsDailyLimit > 0 &&
                (old.reelsDailyLimit <= 0 || next.reelsDailyLimit < old.reelsDailyLimit)) ||
            (next.reelsTimeLimitMinutes > 0 &&
                (old.reelsTimeLimitMinutes <= 0 ||
                    next.reelsTimeLimitMinutes < old.reelsTimeLimitMinutes)) ||
            (next.scrollLimit > 0 &&
                (old.scrollLimit <= 0 || next.scrollLimit < old.scrollLimit))

    @Synchronized
    fun applyManualBlockingMigration() {
        val existing = PhoneControlPolicy.fromJson(preferences.getString(KEY_POLICY, null))
        val safe = sanitizePolicy(
            existing.copy(
                masterEnabled = false,
                notificationBlockerEnabled = false,
                studyStrictAllowList = false,
                studyAllowedPackages = emptySet(),
                studyBlockedPackages = emptySet(),
                studyScheduleEnabled = false,
                globalReelsWindowEnabled = false,
                globalReelsWindowStartMillis = 0L,
                globalReelsWindowEndMillis = 0L,
                globalReelsWindowLimit = 0,
                globalReelsWindowPackages = emptySet(),
                globalReelsWindowLocked = false,
                rules = existing.rules.map { rule ->
                    rule.copy(
                        enabled = false,
                        blockApp = false,
                        blockOutsideSchedule = false,
                        commitmentLockedUntilMillis = 0L
                    )
                },
                profiles = existing.profiles.map { profile ->
                    profile.copy(enabled = false)
                }
            )
        )
        val raw = safe.toJson().toString()
        cachedPolicyRaw = raw
        cachedPolicy = safe
        preferences.edit()
            .putString(KEY_POLICY, raw)
            .remove(KEY_PROFILE_UNLOCK_UNTIL)
            .remove(KEY_PROFILE_UNLOCK_COUNTS)
            .remove(KEY_GLOBAL_REELS_WINDOW_ID)
            .remove(KEY_GLOBAL_REELS_WINDOW_COUNT)
            .apply()
    }

    private fun sanitizePolicy(policy: PhoneControlPolicy): PhoneControlPolicy {
        val rules = policy.rules
            .filterNot { PhoneControlSafety.isProtectedPackage(it.packageName) }
            .distinctBy { it.packageName }
            .map { rule ->
                rule.copy(
                    category = rule.category.ifBlank { "normal" },
                    commitmentPercent = rule.commitmentPercent.coerceIn(20, 100),
                    reelsWarningPercentages = rule.reelsWarningPercentages
                        .filter { it in 10..100 }
                        .toSet()
                        .ifEmpty { setOf(50, 75, 90) },
                    commitmentLockedUntilMillis = rule.commitmentLockedUntilMillis.coerceAtLeast(0L)
                )
            }
        val profiles = policy.profiles.map { profile ->
            profile.copy(
                blockedPackages = PhoneControlSafety.sanitizePackages(profile.blockedPackages)
            )
        }
        return policy.copy(
            notificationPackages = PhoneControlSafety.sanitizePackages(
                policy.notificationPackages
            ),
            studyStrictAllowList = false,
            studyAllowedPackages = emptySet(),
            studyBlockedPackages = PhoneControlSafety.sanitizePackages(
                policy.studyBlockedPackages
            ),
            globalReelsWindowPackages = PhoneControlSafety.sanitizePackages(
                policy.globalReelsWindowPackages
            ),
            globalReelsWindowLimit = policy.globalReelsWindowLimit.coerceAtLeast(0),
            globalReelsWindowStartMillis = policy.globalReelsWindowStartMillis.coerceAtLeast(0L),
            globalReelsWindowEndMillis = policy.globalReelsWindowEndMillis.coerceAtLeast(0L),
            screenTimeGoalMinutes = policy.screenTimeGoalMinutes.coerceIn(30, 1440),
            screenTimeWarningPercentages = policy.screenTimeWarningPercentages
                .filter { it in 10..100 }
                .toSet()
                .ifEmpty { setOf(50, 75, 90, 100) },
            screenTimeRepeatMinutes = policy.screenTimeRepeatMinutes.coerceIn(15, 240),
            rules = rules,
            profiles = profiles
        )
    }

    @Synchronized
    fun recordUsage(packageName: String, elapsedMillis: Long) {
        if (packageName.isBlank() || elapsedMillis <= 0L) return
        ensureToday()
        val values = readLongMap(KEY_USAGE)
        values[packageName] = (values[packageName] ?: 0L) + elapsedMillis
        writeLongMap(KEY_USAGE, values)
        maybeShowScreenTimeWarning()
    }

    @Synchronized
    fun recordScroll(packageName: String): Int {
        if (packageName.isBlank()) return 0
        ensureToday()
        val values = readLongMap(KEY_SCROLLS)
        val updated = ((values[packageName] ?: 0L) + 1L).coerceAtMost(Int.MAX_VALUE.toLong())
        values[packageName] = updated
        writeLongMap(KEY_SCROLLS, values)
        return updated.toInt()
    }

    @Synchronized
    fun recordBlocked(packageName: String) {
        if (packageName.isBlank()) return
        ensureToday()
        val values = readLongMap(KEY_BLOCKED_ATTEMPTS)
        values[packageName] = (values[packageName] ?: 0L) + 1L
        writeLongMap(KEY_BLOCKED_ATTEMPTS, values)
    }

    @Synchronized
    fun recordReelsBlocked(packageName: String) {
        if (packageName.isBlank()) return
        ensureToday()
        val values = readLongMap(KEY_REELS_BLOCKED)
        values[packageName] = (values[packageName] ?: 0L) + 1L
        writeLongMap(KEY_REELS_BLOCKED, values)
    }


    @Synchronized
    private fun ensureReelCounterSchema() {
        val stored = preferences.getInt(KEY_REEL_COUNTER_SCHEMA_VERSION, 0)
        if (stored >= REEL_COUNTER_SCHEMA_VERSION) return
        preferences.edit()
            .remove(KEY_REELS_VIEWED)
            .remove(KEY_REELS_WATCH_MILLIS)
            .remove(KEY_REELS_BLOCKED)
            .remove(KEY_GLOBAL_REELS_WINDOW_COUNT)
            .remove(KEY_WARNING_MARKERS)
            .putInt(KEY_REEL_COUNTER_SCHEMA_VERSION, REEL_COUNTER_SCHEMA_VERSION)
            .apply()
    }

    @Synchronized
    fun recordReelViewed(packageName: String): Int {
        if (packageName.isBlank()) return 0
        ensureToday()
        val values = readLongMap(KEY_REELS_VIEWED)
        val updated = ((values[packageName] ?: 0L) + 1L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
        values[packageName] = updated
        writeLongMap(KEY_REELS_VIEWED, values)

        val policy = policy()
        if (policy.globalReelsWindowActive() &&
            policy.globalReelsWindowApplies(packageName)
        ) {
            ensureGlobalReelsWindowCounter(policy)
            val current = preferences.getLong(KEY_GLOBAL_REELS_WINDOW_COUNT, 0L)
            preferences.edit().putLong(
                KEY_GLOBAL_REELS_WINDOW_COUNT,
                (current + 1L).coerceAtMost(Int.MAX_VALUE.toLong())
            ).apply()
        }
        maybeShowReelsProgressWarning(packageName, updated.toInt(), policy)
        return updated.toInt()
    }

    private fun maybeShowReelsProgressWarning(
        packageName: String,
        viewed: Int,
        currentPolicy: PhoneControlPolicy
    ) {
        if (!currentPolicy.wellbeingWarningsEnabled || viewed <= 0) return
        val rule = currentPolicy.ruleFor(packageName) ?: return
        if (!rule.reelsGuard || rule.reelsDailyLimit <= 0) return
        val limit = rule.reelsDailyLimit
        val percentages = rule.reelsWarningPercentages
            .filter { it in 10..100 }
            .sorted()
        val reached = percentages.lastOrNull { percentage ->
            val threshold = ((limit * percentage) + 99) / 100
            viewed >= threshold
        } ?: return
        val marker = "reels:$packageName:$limit:$reached"
        if (!markWarningOnce(marker)) return
        Notifications.showReelsProgress(
            context = appContext,
            appLabel = rule.label.ifBlank { packageName },
            viewed = viewed,
            limit = limit,
            percentage = reached,
            watchMinutes = (reelWatchMillis(packageName) / 60_000L).toInt(),
            remaining = (limit - viewed).coerceAtLeast(0),
            detailed = currentPolicy.detailedWarningNotifications
        )
    }

    private fun maybeShowScreenTimeWarning() {
        val currentPolicy = policy()
        if (!currentPolicy.wellbeingWarningsEnabled) return
        val now = System.currentTimeMillis()
        val lastCheck = preferences.getLong(KEY_LAST_SCREEN_WARNING_CHECK, 0L)
        if (now - lastCheck < SCREEN_WARNING_CHECK_INTERVAL_MILLIS) return
        preferences.edit().putLong(KEY_LAST_SCREEN_WARNING_CHECK, now).apply()

        val currentSnapshot = snapshot(appContext)
        val usedMinutes = (((currentSnapshot["totalScreenTimeMillis"] as? Number)?.toLong()
            ?: 0L) / 60_000L).toInt()
        val goal = currentPolicy.screenTimeGoalMinutes.coerceIn(30, 1440)
        if (usedMinutes <= 0 || goal <= 0) return

        val usage = currentSnapshot["usageMillis"] as? Map<*, *> ?: emptyMap<Any, Any>()
        val top = usage.entries.maxByOrNull { entry ->
            (entry.value as? Number)?.toLong() ?: 0L
        }
        val topPackage = top?.key?.toString().orEmpty()
        val topMinutes = (((top?.value as? Number)?.toLong() ?: 0L) / 60_000L).toInt()
        val topLabel = currentPolicy.rules
            .firstOrNull { it.packageName == topPackage }
            ?.label
            ?.ifBlank { topPackage }
            ?: topPackage

        val percent = ((usedMinutes * 100.0) / goal).toInt()
        val reached = currentPolicy.screenTimeWarningPercentages
            .filter { it in 10..100 }
            .sorted()
            .lastOrNull { percent >= it }
        if (reached != null) {
            val marker = "screen:goal:$goal:$reached"
            if (markWarningOnce(marker)) {
                Notifications.showScreenTimeWarning(
                    context = appContext,
                    usedMinutes = usedMinutes,
                    goalMinutes = goal,
                    percentage = reached,
                    topAppLabel = topLabel,
                    topAppMinutes = topMinutes,
                    detailed = currentPolicy.detailedWarningNotifications,
                    repeatedAfterGoal = false
                )
            }
        }

        if (usedMinutes > goal) {
            val repeat = currentPolicy.screenTimeRepeatMinutes.coerceIn(15, 240)
            val bucket = (usedMinutes - goal) / repeat
            if (bucket >= 1) {
                val marker = "screen:repeat:$goal:$repeat:$bucket"
                if (markWarningOnce(marker)) {
                    Notifications.showScreenTimeWarning(
                        context = appContext,
                        usedMinutes = usedMinutes,
                        goalMinutes = goal,
                        percentage = ((usedMinutes * 100.0) / goal).toInt(),
                        topAppLabel = topLabel,
                        topAppMinutes = topMinutes,
                        detailed = currentPolicy.detailedWarningNotifications,
                        repeatedAfterGoal = true
                    )
                }
            }
        }
    }

    private fun markWarningOnce(marker: String): Boolean {
        val values = preferences.getStringSet(KEY_WARNING_MARKERS, emptySet()).orEmpty()
        if (marker in values) return false
        preferences.edit()
            .putStringSet(KEY_WARNING_MARKERS, values.toMutableSet().apply { add(marker) })
            .apply()
        return true
    }

    @Synchronized
    fun globalReelsWindowCount(): Int {
        val policy = policy()
        ensureGlobalReelsWindowCounter(policy)
        return preferences.getLong(KEY_GLOBAL_REELS_WINDOW_COUNT, 0L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
    }

    private fun ensureGlobalReelsWindowCounter(policy: PhoneControlPolicy) {
        val id = policy.globalReelsWindowId()
        val stored = preferences.getString(KEY_GLOBAL_REELS_WINDOW_ID, null)
        if (stored == id) return
        preferences.edit()
            .putString(KEY_GLOBAL_REELS_WINDOW_ID, id)
            .putLong(KEY_GLOBAL_REELS_WINDOW_COUNT, 0L)
            .apply()
    }

    @Synchronized
    fun recordReelWatch(packageName: String, elapsedMillis: Long) {
        if (packageName.isBlank() || elapsedMillis <= 0L) return
        ensureToday()
        val values = readLongMap(KEY_REELS_WATCH_MILLIS)
        values[packageName] = (values[packageName] ?: 0L) + elapsedMillis
        writeLongMap(KEY_REELS_WATCH_MILLIS, values)
    }

    fun reelViewedCount(packageName: String): Int {
        ensureToday()
        return (readLongMap(KEY_REELS_VIEWED)[packageName] ?: 0L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
    }

    fun reelWatchMillis(packageName: String): Long {
        ensureToday()
        return readLongMap(KEY_REELS_WATCH_MILLIS)[packageName] ?: 0L
    }

    @Synchronized
    fun recordNotificationBlocked(
        packageName: String,
        appLabel: String,
        title: String,
        text: String
    ) {
        if (packageName.isBlank()) return
        ensureToday()
        val values = readLongMap(KEY_NOTIFICATIONS_BLOCKED)
        values[packageName] = (values[packageName] ?: 0L) + 1L
        writeLongMap(KEY_NOTIFICATIONS_BLOCKED, values)

        val history = readNotificationHistory().toMutableList()
        history.add(
            0,
            mapOf(
                "packageName" to packageName,
                "appLabel" to appLabel.take(MAX_HISTORY_TEXT),
                "title" to title.take(MAX_HISTORY_TEXT),
                "text" to text.take(MAX_HISTORY_TEXT),
                "timestampMillis" to System.currentTimeMillis()
            )
        )
        writeNotificationHistory(
            history.take(policy().notificationHistoryLimit.coerceIn(10, 500))
        )
    }

    fun shouldBlockNotification(
        packageName: String,
        calendar: Calendar,
        focusActive: Boolean
    ): Boolean {
        if (PhoneControlSafety.isProtectedPackage(packageName)) return false
        val policy = policy()
        if ((focusActive || policy.studyScheduleActive(calendar)) &&
            policy.studyModeEnabled &&
            policy.studySilenceNotifications
        ) {
            return true
        }
        if (!policy.masterEnabled) return false
        if (policy.notificationBlockerEnabled &&
            packageName in policy.notificationPackages &&
            policy.notificationWindowActive(calendar)
        ) {
            return true
        }
        if (!policy.scheduleProfilesEnabled) return false
        return policy.profiles.any { profile ->
            profile.silenceNotifications &&
                profile.blocks(packageName, calendar) &&
                !isProfileUnlocked(profile.id)
        }
    }

    @Synchronized
    fun clearNotificationHistory() {
        preferences.edit().remove(KEY_NOTIFICATION_HISTORY).apply()
    }

    fun fallbackUsageMillis(packageName: String): Long {
        ensureToday()
        return readLongMap(KEY_USAGE)[packageName] ?: 0L
    }

    fun systemUsageMillis(context: Context, packageName: String): Long {
        ensureToday()
        return PhoneUsageStats.todayUsageMillis(context, packageName)
    }

    fun scrollCount(packageName: String): Int {
        ensureToday()
        return (readLongMap(KEY_SCROLLS)[packageName] ?: 0L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
    }

    fun isProfileUnlocked(profileId: String): Boolean {
        if (profileId.isBlank()) return false
        ensureToday()
        val until = readLongMap(KEY_PROFILE_UNLOCK_UNTIL)[profileId] ?: 0L
        return until > System.currentTimeMillis()
    }

    @Synchronized
    fun profileRuntimeSnapshot(): List<Map<String, Any>> {
        ensureToday()
        val unlockUntil = readLongMap(KEY_PROFILE_UNLOCK_UNTIL)
        val unlockCounts = readLongMap(KEY_PROFILE_UNLOCK_COUNTS)
        return policy().profiles.map { profile ->
            mapOf(
                "profileId" to profile.id,
                "unlockedUntilMillis" to (unlockUntil[profile.id] ?: 0L),
                "unlocksUsedToday" to (unlockCounts[profile.id] ?: 0L)
                    .coerceAtMost(Int.MAX_VALUE.toLong())
                    .toInt(),
                "granted" to true
            )
        }
    }

    @Synchronized
    fun requestEmergencyUnlock(profileId: String, requestedMinutes: Int): Map<String, Any> {
        ensureToday()
        val profile = policy().profiles.firstOrNull { it.id == profileId }
            ?: return mapOf(
                "profileId" to profileId,
                "unlockedUntilMillis" to 0L,
                "unlocksUsedToday" to 0,
                "granted" to false
            )
        val counts = readLongMap(KEY_PROFILE_UNLOCK_COUNTS)
        val used = (counts[profileId] ?: 0L).coerceAtLeast(0L)
        if (profile.maxEmergencyUnlocksPerDay <= 0 ||
            used >= profile.maxEmergencyUnlocksPerDay.toLong()
        ) {
            return mapOf(
                "profileId" to profileId,
                "unlockedUntilMillis" to (readLongMap(KEY_PROFILE_UNLOCK_UNTIL)[profileId] ?: 0L),
                "unlocksUsedToday" to used.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
                "granted" to false
            )
        }
        val configured = profile.emergencyUnlockMinutes.coerceAtLeast(1)
        val duration = requestedMinutes.coerceAtLeast(1).coerceAtMost(configured)
        val until = System.currentTimeMillis() + duration * 60_000L
        val untilMap = readLongMap(KEY_PROFILE_UNLOCK_UNTIL)
        untilMap[profileId] = until
        writeLongMap(KEY_PROFILE_UNLOCK_UNTIL, untilMap)
        counts[profileId] = used + 1L
        writeLongMap(KEY_PROFILE_UNLOCK_COUNTS, counts)
        return mapOf(
            "profileId" to profileId,
            "unlockedUntilMillis" to until,
            "unlocksUsedToday" to (used + 1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            "granted" to true
        )
    }

    @Synchronized
    fun cancelEmergencyUnlock(profileId: String) {
        ensureToday()
        val values = readLongMap(KEY_PROFILE_UNLOCK_UNTIL)
        values.remove(profileId)
        writeLongMap(KEY_PROFILE_UNLOCK_UNTIL, values)
    }

    /**
     * Clears display-only counters without resetting app-minute, Reels, scroll,
     * emergency-unlock or notification enforcement. Daily enforcement always
     * rolls over at local midnight and cannot be bypassed from the UI.
     */
    fun clearDisplayCounters() {
        ensureToday()
        preferences.edit()
            .remove(KEY_BLOCKED_ATTEMPTS)
            .apply()
    }

    fun snapshot(context: Context): Map<String, Any> {
        ensureToday()
        val policy = policy()
        val packages = (
            policy.rules.map { it.packageName } +
                policy.profiles.flatMap { it.blockedPackages }
            ).filter { it.isNotBlank() }.toSet()
        val fallback = readLongMap(KEY_USAGE)
        val systemSnapshot = PhoneUsageStats.todaySnapshot(context)
        val usage = if (PhoneUsageStats.hasAccess(context)) {
            systemSnapshot.usageByPackage
                .filterKeys { it in packages }
                .toMutableMap()
                .apply {
                    for ((packageName, value) in fallback) {
                        if ((this[packageName] ?: 0L) < value) this[packageName] = value
                    }
                }
        } else {
            fallback
        }
        val fallbackTotal = fallback.values.sum().coerceAtLeast(0L)
        val totalScreenTime = maxOf(
            systemSnapshot.totalScreenTimeMillis,
            fallbackTotal
        ).coerceAtMost(
            (System.currentTimeMillis() - systemSnapshot.windowStartMillis)
                .coerceAtLeast(0L)
        )
        val effectiveSource = when {
            systemSnapshot.source != "unavailable" -> systemSnapshot.source
            fallbackTotal > 0L -> "accessibility_fallback"
            else -> "unavailable"
        }
        return mapOf(
            "trackingDate" to trackingDate(),
            "usageMillis" to usage,
            "scrollCounts" to readLongMap(KEY_SCROLLS),
            "blockedAttempts" to readLongMap(KEY_BLOCKED_ATTEMPTS),
            "reelsBlocked" to readLongMap(KEY_REELS_BLOCKED),
            "reelsViewed" to readLongMap(KEY_REELS_VIEWED),
            "reelsWatchMillis" to readLongMap(KEY_REELS_WATCH_MILLIS),
            "globalReelsWindowViewed" to globalReelsWindowCount(),
            "notificationsBlocked" to readLongMap(KEY_NOTIFICATIONS_BLOCKED),
            "totalScreenTimeMillis" to totalScreenTime,
            "screenTimeWindowStartMillis" to systemSnapshot.windowStartMillis,
            "screenTimeSource" to effectiveSource,
            "screenTimeEventCount" to systemSnapshot.eventCount
        )
    }


    fun dashboardSnapshot(context: Context): Map<String, Any> {
        val current = snapshot(context).toMutableMap()
        val dashboardPolicy = policy()
        val controlledPackages = (
            dashboardPolicy.rules.filter { it.enabled }.map { it.packageName } +
                dashboardPolicy.profiles
                    .filter { it.enabled }
                    .flatMap { it.blockedPackages }
            ).filter { it.isNotBlank() }.toSet()
        val usage = current["usageMillis"] as? Map<*, *> ?: emptyMap<Any, Any>()
        val distractionTime = usage.values.sumOf { value ->
            ((value as? Number)?.toLong() ?: 0L).coerceAtLeast(0L)
        }
        val weekly = PhoneUsageStats.weeklyUsage(context, controlledPackages)
            .map { it.toMutableMap() }
            .toMutableList()
        if (weekly.isNotEmpty()) {
            val today = weekly.last()
            val currentTotal = (current["totalScreenTimeMillis"] as? Number)
                ?.toLong()
                ?.coerceAtLeast(0L)
                ?: 0L
            today["totalScreenTimeMillis"] = maxOf(
                (today["totalScreenTimeMillis"] as? Number)?.toLong() ?: 0L,
                currentTotal
            )
            today["distractionTimeMillis"] = maxOf(
                (today["distractionTimeMillis"] as? Number)?.toLong() ?: 0L,
                distractionTime
            )
        }
        current["distractionTimeMillis"] = distractionTime
        current["weekly"] = weekly
        return current
    }

    fun socialSnapshot(context: Context): Map<String, Any> {
        ensureToday()
        return mapOf(
            "notificationAccessEnabled" to NotificationAccess.isEnabled(context),
            "reelsBlocked" to readLongMap(KEY_REELS_BLOCKED),
            "reelsViewed" to readLongMap(KEY_REELS_VIEWED),
            "reelsWatchMillis" to readLongMap(KEY_REELS_WATCH_MILLIS),
            "globalReelsWindowViewed" to globalReelsWindowCount(),
            "notificationsBlocked" to readLongMap(KEY_NOTIFICATIONS_BLOCKED),
            "scrollCounts" to readLongMap(KEY_SCROLLS),
            "notificationHistory" to readNotificationHistory()
        )
    }

    private fun readNotificationHistory(): List<Map<String, Any>> {
        val raw = preferences.getString(KEY_NOTIFICATION_HISTORY, null).orEmpty()
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        mapOf(
                            "packageName" to item.optString("packageName"),
                            "appLabel" to item.optString("appLabel"),
                            "title" to item.optString("title"),
                            "text" to item.optString("text"),
                            "timestampMillis" to item.optLong("timestampMillis", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun writeNotificationHistory(values: List<Map<String, Any>>) {
        val array = JSONArray()
        values.forEach { value ->
            array.put(JSONObject(value))
        }
        preferences.edit().putString(KEY_NOTIFICATION_HISTORY, array.toString()).apply()
    }

    private fun ensureToday() {
        val today = LocalDate.now().toString()
        if (preferences.getString(KEY_TRACKING_DATE, null) == today) return
        preferences.edit()
            .putString(KEY_TRACKING_DATE, today)
            .remove(KEY_USAGE)
            .remove("phone_control_usage_baseline")
            .remove(KEY_SCROLLS)
            .remove(KEY_BLOCKED_ATTEMPTS)
            .remove(KEY_REELS_BLOCKED)
            .remove(KEY_REELS_VIEWED)
            .remove(KEY_REELS_WATCH_MILLIS)
            .remove(KEY_NOTIFICATIONS_BLOCKED)
            .remove(KEY_PROFILE_UNLOCK_UNTIL)
            .remove(KEY_PROFILE_UNLOCK_COUNTS)
            .remove(KEY_WARNING_MARKERS)
            .remove(KEY_LAST_SCREEN_WARNING_CHECK)
            .apply()
    }

    private fun trackingDate(): String {
        ensureToday()
        return preferences.getString(KEY_TRACKING_DATE, LocalDate.now().toString())
            ?: LocalDate.now().toString()
    }

    private fun readLongMap(key: String): MutableMap<String, Long> {
        val raw = preferences.getString(key, null).orEmpty()
        if (raw.isBlank()) return mutableMapOf()
        return runCatching {
            val json = JSONObject(raw)
            buildMap<String, Long> {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val packageName = keys.next()
                    put(packageName, json.optLong(packageName, 0L).coerceAtLeast(0L))
                }
            }.toMutableMap()
        }.getOrDefault(mutableMapOf())
    }

    private fun writeLongMap(key: String, values: Map<String, Long>) {
        val json = JSONObject()
        values.forEach { (packageName, value) ->
            if (packageName.isNotBlank() && value > 0L) {
                json.put(packageName, value)
            }
        }
        preferences.edit().putString(key, json.toString()).apply()
    }

    companion object {
        private const val PREFS = "focus_guard"
        private const val KEY_POLICY = "phone_control_policy_v1"
        private const val KEY_TRACKING_DATE = "phone_control_tracking_date"
        private const val KEY_USAGE = "phone_control_usage"
        private const val KEY_SCROLLS = "phone_control_scrolls"
        private const val KEY_BLOCKED_ATTEMPTS = "phone_control_blocked_attempts"
        private const val KEY_REELS_BLOCKED = "phone_control_reels_blocked"
        private const val KEY_REELS_VIEWED = "phone_control_reels_viewed"
        private const val KEY_REELS_WATCH_MILLIS = "phone_control_reels_watch_millis"
        private const val KEY_REEL_COUNTER_SCHEMA_VERSION = "phone_control_reel_counter_schema_version"
        private const val REEL_COUNTER_SCHEMA_VERSION = 3
        private const val KEY_GLOBAL_REELS_WINDOW_ID = "phone_control_global_reels_window_id"
        private const val KEY_GLOBAL_REELS_WINDOW_COUNT = "phone_control_global_reels_window_count"
        private const val KEY_NOTIFICATIONS_BLOCKED = "phone_control_notifications_blocked"
        private const val KEY_NOTIFICATION_HISTORY = "phone_control_notification_history"
        private const val KEY_WARNING_MARKERS = "phone_control_warning_markers"
        private const val KEY_LAST_SCREEN_WARNING_CHECK = "phone_control_last_screen_warning_check"
        private const val SCREEN_WARNING_CHECK_INTERVAL_MILLIS = 2 * 60_000L
        private const val KEY_PROFILE_UNLOCK_UNTIL = "phone_control_profile_unlock_until"
        private const val KEY_PROFILE_UNLOCK_COUNTS = "phone_control_profile_unlock_counts"
        private const val MAX_HISTORY_TEXT = 180
    }
}

data class DailyUsageSnapshot(
    val usageByPackage: Map<String, Long>,
    val totalScreenTimeMillis: Long,
    val windowStartMillis: Long,
    val source: String,
    val eventCount: Int
)

object PhoneUsageStats {
    @Volatile private var cachedToday: CachedSnapshot? = null

    private data class CachedSnapshot(
        val dayStartMillis: Long,
        val collectedAtMillis: Long,
        val snapshot: DailyUsageSnapshot
    )

    fun hasAccess(context: Context): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun todaySnapshot(context: Context): DailyUsageSnapshot {
        val end = System.currentTimeMillis()
        val start = startOfDayMillis(end)
        val cached = cachedToday
        if (cached != null &&
            cached.dayStartMillis == start &&
            end - cached.collectedAtMillis <= CACHE_MILLIS
        ) {
            return cached.snapshot
        }
        val snapshot = snapshotForWindow(context, start, end)
        cachedToday = CachedSnapshot(start, end, snapshot)
        return snapshot
    }

    fun todayUsageMillis(context: Context, packageName: String): Long {
        if (!hasAccess(context) || packageName.isBlank()) return 0L
        return todaySnapshot(context).usageByPackage[packageName] ?: 0L
    }

    fun todayUsageMap(context: Context, packages: Set<String>): Map<String, Long> {
        if (!hasAccess(context) || packages.isEmpty()) return emptyMap()
        return todaySnapshot(context).usageByPackage.filterKeys { it in packages }
    }

    fun totalScreenTimeMillis(context: Context): Long =
        if (hasAccess(context)) todaySnapshot(context).totalScreenTimeMillis else 0L

    fun weeklyUsage(
        context: Context,
        controlledPackages: Set<String>,
        days: Int = 7
    ): List<Map<String, Any>> {
        val safeDays = days.coerceIn(1, 31)
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val now = System.currentTimeMillis()
        return (safeDays - 1 downTo 0).map { offset ->
            val startCalendar = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -offset)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val endCalendar = (startCalendar.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, 1)
            }
            val start = startCalendar.timeInMillis
            val end = minOf(endCalendar.timeInMillis, now)
            val snapshot = if (end > start) {
                if (offset == 0) todaySnapshot(context)
                else snapshotForWindow(context, start, end)
            } else {
                DailyUsageSnapshot(emptyMap(), 0L, start, "unavailable", 0)
            }
            val distraction = snapshot.usageByPackage.entries.sumOf { (packageName, value) ->
                if (packageName in controlledPackages) value else 0L
            }.coerceIn(0L, snapshot.totalScreenTimeMillis)
            mapOf(
                "date" to formatter.format(Date(start)),
                "totalScreenTimeMillis" to snapshot.totalScreenTimeMillis,
                "distractionTimeMillis" to distraction
            )
        }
    }

    private fun snapshotForWindow(
        context: Context,
        startMillis: Long,
        endMillis: Long
    ): DailyUsageSnapshot {
        if (!hasAccess(context) || endMillis <= startMillis) {
            return DailyUsageSnapshot(
                usageByPackage = emptyMap(),
                totalScreenTimeMillis = 0L,
                windowStartMillis = startMillis,
                source = "unavailable",
                eventCount = 0
            )
        }

        val manager = context.getSystemService(UsageStatsManager::class.java)
        val transitions = readTransitions(manager, startMillis, endMillis)
        val timeline = UsageTimeline.calculate(transitions, startMillis, endMillis)
        if (timeline.eventCount > 0) {
            return DailyUsageSnapshot(
                usageByPackage = timeline.usageByPackage,
                totalScreenTimeMillis = timeline.totalScreenTimeMillis,
                windowStartMillis = startMillis,
                source = "usage_events",
                eventCount = timeline.eventCount
            )
        }

        val maximumWindow = (endMillis - startMillis).coerceAtLeast(0L)
        val aggregate: Map<String, UsageStats> = runCatching {
            manager.queryAndAggregateUsageStats(startMillis, endMillis).toMap()
        }.getOrElse { emptyMap() }
        val usage = aggregate.mapValues { (_, stats) ->
            stats.totalTimeInForeground.coerceIn(0L, maximumWindow)
        }
        return DailyUsageSnapshot(
            usageByPackage = usage,
            totalScreenTimeMillis = usage.values.sum().coerceIn(0L, maximumWindow),
            windowStartMillis = startMillis,
            source = if (usage.isEmpty()) "unavailable" else "aggregate_fallback",
            eventCount = 0
        )
    }

    private fun readTransitions(
        manager: UsageStatsManager,
        startMillis: Long,
        endMillis: Long
    ): List<UsageTransition> {
        val queryStart = (startMillis - LOOKBACK_MILLIS).coerceAtLeast(0L)
        val events = runCatching { manager.queryEvents(queryStart, endMillis) }
            .getOrNull() ?: return emptyList()
        val event = UsageEvents.Event()
        val result = mutableListOf<UsageTransition>()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val type = when {
                event.eventType in FOREGROUND_EVENT_TYPES ->
                    UsageTransitionType.FOREGROUND
                event.eventType in BACKGROUND_EVENT_TYPES ->
                    UsageTransitionType.BACKGROUND
                event.eventType in SCREEN_OFF_EVENT_TYPES ->
                    UsageTransitionType.SCREEN_OFF
                else -> null
            } ?: continue
            result += UsageTransition(
                timestampMillis = event.timeStamp,
                packageName = event.packageName.orEmpty(),
                type = type
            )
        }
        return result
    }

    private fun startOfDayMillis(referenceMillis: Long): Long =
        Calendar.getInstance().apply {
            timeInMillis = referenceMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    private val FOREGROUND_EVENT_TYPES = setOf(
        UsageEvents.Event.MOVE_TO_FOREGROUND,
        UsageEvents.Event.ACTIVITY_RESUMED
    )
    private val BACKGROUND_EVENT_TYPES = setOf(
        UsageEvents.Event.MOVE_TO_BACKGROUND,
        UsageEvents.Event.ACTIVITY_PAUSED,
        UsageEvents.Event.ACTIVITY_STOPPED
    )
    private val SCREEN_OFF_EVENT_TYPES = setOf(
        UsageEvents.Event.SCREEN_NON_INTERACTIVE,
        UsageEvents.Event.KEYGUARD_SHOWN,
        UsageEvents.Event.DEVICE_SHUTDOWN
    )
    private const val CACHE_MILLIS = 15_000L
    private const val LOOKBACK_MILLIS = 24L * 60L * 60L * 1000L
}

