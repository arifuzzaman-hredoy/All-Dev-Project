package com.hredoy.focus_guard_flutter

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean

class ProtectionVpnService : VpnService() {
    private val active = AtomicBoolean(false)
    private val store by lazy { ProtectionStore(this) }
    private var tunnel: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var consecutiveFailures = 0

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensure(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel("Protection stopped")
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification("Starting local DNS protection…"))
        if (!active.get()) startTunnel()
        return START_STICKY
    }

    override fun onDestroy() {
        stopTunnel("Protection service stopped", stopSelf = false)
        super.onDestroy()
    }

    override fun onRevoke() {
        store.recordServiceMessage("Android revoked the VPN connection")
        stopTunnel("VPN permission revoked")
        super.onRevoke()
    }

    private fun startTunnel() {
        val policy = store.policy()
        if (!policy.webProtectionEnabled || !policy.vpnDnsEnabled) {
            stopTunnel("DNS protection is disabled")
            return
        }
        if (prepare(this) != null) {
            store.recordServiceMessage("VPN permission is required")
            stopTunnel("VPN permission required")
            return
        }

        val descriptor = runCatching {
            Builder()
                .setSession("Hredoy Flow Protection")
                .setMtu(1500)
                .addAddress(LOCAL_VPN_ADDRESS, 24)
                .addDnsServer(LOCAL_DNS_ADDRESS)
                .addRoute(LOCAL_DNS_ADDRESS, 32)
                .setBlocking(true)
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        setMetered(false)
                    }
                    setConfigureIntent(
                        PendingIntent.getActivity(
                            this@ProtectionVpnService,
                            0,
                            Intent(this@ProtectionVpnService, MainActivity::class.java),
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                    )
                }
                .establish()
        }.getOrElse { error ->
            store.recordServiceMessage("VPN start failed: ${error.message.orEmpty()}")
            null
        }

        if (descriptor == null) {
            stopTunnel("Unable to create local VPN")
            return
        }

        tunnel = descriptor
        active.set(true)
        isRunning = true
        consecutiveFailures = 0
        store.recordServiceMessage("Local DNS protection is running")
        updateNotification("DNS, adult-content and custom domain protection active")
        worker = Thread({ packetLoop(descriptor) }, "HredoyFlowDnsVpn").apply {
            isDaemon = true
            start()
        }
    }

    private fun packetLoop(descriptor: ParcelFileDescriptor) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(MAX_PACKET_SIZE)
        try {
            while (active.get()) {
                val length = runCatching { input.read(buffer) }.getOrElse { break }
                if (length <= 0) continue
                val request = DnsPacket.parseIpv4Udp(buffer, length) ?: continue
                val currentPolicy = store.policy()
                val blockReason = if (currentPolicy.isWebWindowActive()) {
                    ProtectionRules.domainBlockReason(request.questionName, currentPolicy)
                } else {
                    null
                }
                if (blockReason != null) {
                    store.recordWebBlocked(request.questionName, blockReason)
                    output.write(DnsPacket.buildNxDomainResponse(request))
                    consecutiveFailures = 0
                    continue
                }

                val upstreamResponse = queryUpstream(
                    request.dnsPayload,
                    currentPolicy.primaryDns,
                    currentPolicy.secondaryDns
                )
                if (upstreamResponse != null) {
                    output.write(DnsPacket.buildIpv4UdpResponse(request, upstreamResponse))
                    consecutiveFailures = 0
                    continue
                }

                consecutiveFailures += 1
                store.recordServiceMessage(
                    "DNS upstream timeout (${consecutiveFailures.coerceAtMost(99)})"
                )
                if (currentPolicy.failClosed) {
                    output.write(DnsPacket.buildNxDomainResponse(request))
                } else if (consecutiveFailures >= MAX_FAILURES_BEFORE_FAIL_OPEN) {
                    store.recordServiceMessage(
                        "Protection paused after DNS failures so internet access can recover"
                    )
                    break
                }
            }
        } finally {
            runCatching { input.close() }
            runCatching { output.close() }
            if (active.get()) {
                stopTunnel("DNS protection paused")
            }
        }
    }

    private fun queryUpstream(
        payload: ByteArray,
        primaryDns: String,
        secondaryDns: String
    ): ByteArray? {
        val candidates = listOf(primaryDns, secondaryDns)
            .filter(ProtectionRules::isValidIpv4)
            .distinct()
        for (server in candidates) {
            val response = runCatching {
                DatagramSocket().use { socket ->
                    if (!protect(socket)) return@use null
                    socket.soTimeout = DNS_TIMEOUT_MILLIS
                    val address = InetAddress.getByName(server)
                    socket.send(DatagramPacket(payload, payload.size, address, DNS_PORT))
                    val responseBuffer = ByteArray(MAX_DNS_RESPONSE_SIZE)
                    val responsePacket = DatagramPacket(responseBuffer, responseBuffer.size)
                    socket.receive(responsePacket)
                    responseBuffer.copyOf(responsePacket.length)
                }
            }.recoverCatching { error ->
                if (error is SocketTimeoutException) null else throw error
            }.getOrNull()
            if (response != null && response.isNotEmpty()) return response
        }
        return null
    }

    @Synchronized
    private fun stopTunnel(message: String, stopSelf: Boolean = true) {
        active.set(false)
        isRunning = false
        store.recordServiceMessage(message)
        runCatching { tunnel?.close() }
        tunnel = null
        worker?.interrupt()
        worker = null
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        if (stopSelf) stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val launchIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ProtectionVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotificationChannels.PROTECTION)
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentTitle("Hredoy Flow protection")
            .setContentText(text)
            .setContentIntent(launchIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(android.app.NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        const val ACTION_START = "com.hredoy.focus_guard_flutter.PROTECTION_START"
        const val ACTION_STOP = "com.hredoy.focus_guard_flutter.PROTECTION_STOP"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun reconcile(context: Context) {
            val appContext = context.applicationContext
            val store = ProtectionStore(appContext)
            if (store.shouldRunVpn() && prepare(appContext) == null) {
                runCatching {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, ProtectionVpnService::class.java).apply {
                            action = ACTION_START
                        }
                    )
                }.onFailure { error ->
                    store.recordServiceMessage(
                        "Android blocked automatic VPN start: ${error.message.orEmpty()}"
                    )
                }
            } else if (!store.shouldRunVpn()) {
                runCatching {
                    appContext.stopService(
                        Intent(appContext, ProtectionVpnService::class.java)
                    )
                }
            }
        }

        fun stop(context: Context) {
            val appContext = context.applicationContext
            runCatching {
                appContext.stopService(
                    Intent(appContext, ProtectionVpnService::class.java)
                )
            }
        }

        private const val LOCAL_VPN_ADDRESS = "10.66.0.1"
        private const val LOCAL_DNS_ADDRESS = "10.66.0.2"
        private const val DNS_PORT = 53
        private const val DNS_TIMEOUT_MILLIS = 3_000
        private const val MAX_FAILURES_BEFORE_FAIL_OPEN = 4
        private const val MAX_PACKET_SIZE = 32_767
        private const val MAX_DNS_RESPONSE_SIZE = 16_384
        private const val NOTIFICATION_ID = 7601
    }
}
