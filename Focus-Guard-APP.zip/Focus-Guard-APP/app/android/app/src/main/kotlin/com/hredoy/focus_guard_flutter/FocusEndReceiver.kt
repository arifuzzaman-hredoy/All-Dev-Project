package com.hredoy.focus_guard_flutter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class FocusEndReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        FocusController.end(context, notify = true)
    }
}
