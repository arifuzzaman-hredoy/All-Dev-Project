package com.hredoy.focus_guard_flutter

enum class UsageTransitionType {
    FOREGROUND,
    BACKGROUND,
    SCREEN_OFF
}

data class UsageTransition(
    val timestampMillis: Long,
    val packageName: String,
    val type: UsageTransitionType
)

data class UsageTimelineResult(
    val usageByPackage: Map<String, Long>,
    val totalScreenTimeMillis: Long,
    val eventCount: Int
)

/**
 * Converts ordered Android usage transitions into non-overlapping foreground
 * intervals. Total screen time is the union of those intervals, so split-screen,
 * duplicate resume events and launcher hand-offs cannot inflate the daily total.
 */
object UsageTimeline {
    fun calculate(
        transitions: List<UsageTransition>,
        windowStartMillis: Long,
        windowEndMillis: Long
    ): UsageTimelineResult {
        if (windowEndMillis <= windowStartMillis) {
            return UsageTimelineResult(emptyMap(), 0L, transitions.size)
        }

        val ordered = transitions.sortedBy { it.timestampMillis }
        val usageByPackage = linkedMapOf<String, Long>()
        var activePackage: String? = null
        var activeSince = windowStartMillis
        var total = 0L

        fun closeActive(atMillis: Long) {
            val packageName = activePackage ?: return
            val start = activeSince.coerceAtLeast(windowStartMillis)
            val end = atMillis.coerceIn(windowStartMillis, windowEndMillis)
            if (end > start) {
                val duration = end - start
                usageByPackage[packageName] =
                    (usageByPackage[packageName] ?: 0L) + duration
                total += duration
            }
            activePackage = null
            activeSince = end
        }

        for (transition in ordered) {
            if (transition.timestampMillis > windowEndMillis) break
            val timestamp = transition.timestampMillis
            when (transition.type) {
                UsageTransitionType.FOREGROUND -> {
                    val packageName = transition.packageName.trim()
                    if (packageName.isEmpty()) continue
                    if (activePackage == packageName) continue
                    closeActive(timestamp)
                    activePackage = packageName
                    activeSince = timestamp.coerceAtLeast(windowStartMillis)
                }

                UsageTransitionType.BACKGROUND -> {
                    if (activePackage == transition.packageName) {
                        closeActive(timestamp)
                    }
                }

                UsageTransitionType.SCREEN_OFF -> closeActive(timestamp)
            }
        }

        closeActive(windowEndMillis)
        val maximumWindow = windowEndMillis - windowStartMillis
        return UsageTimelineResult(
            usageByPackage = usageByPackage.mapValues { (_, value) ->
                value.coerceIn(0L, maximumWindow)
            },
            totalScreenTimeMillis = total.coerceIn(0L, maximumWindow),
            eventCount = ordered.size
        )
    }
}
