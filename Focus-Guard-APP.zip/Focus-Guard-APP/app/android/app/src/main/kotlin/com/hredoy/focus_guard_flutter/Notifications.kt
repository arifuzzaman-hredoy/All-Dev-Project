package com.hredoy.focus_guard_flutter

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifications {
    fun showRoutine(context: Context, task: NativeTask) {
        NotificationChannels.ensure(context)
        val open = PendingIntent.getActivity(
            context,
            task.id.hashCode(),
            task.toIntent(Intent(context, MainActivity::class.java)),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, NotificationChannels.ROUTINE)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(task.title)
            .setContentText("${task.category} • Start now")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    task.notes.ifBlank {
                        "Start this task now and stay focused for ${task.durationMinutes} minutes."
                    }
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(task.id.hashCode(), notification)
        }
    }

    fun showFocusFinished(context: Context, label: String) {
        NotificationChannels.ensure(context)
        val open = appOpenIntent(context, 881)
        val notification = NotificationCompat.Builder(context, NotificationChannels.FOCUS)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("Focus session complete")
            .setContentText(label)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(881, notification) }
    }

    fun showReelsProgress(
        context: Context,
        appLabel: String,
        viewed: Int,
        limit: Int,
        percentage: Int,
        watchMinutes: Int,
        remaining: Int,
        detailed: Boolean
    ) {
        if (limit <= 0) return
        NotificationChannels.ensure(context)
        val title = "$appLabel Reels: $percentage% used"
        val summary = "$viewed of $limit watched • $remaining remaining"
        val detail = if (detailed) {
            buildString {
                append("You have watched $viewed short videos in $appLabel today. ")
                append("Your limit is $limit and $remaining remain. ")
                append("Detected short-video time: $watchMinutes minutes. ")
                append("Open Hredoy Flow to reduce the limit, block Reels only, or start Focus mode.")
            }
        } else {
            summary
        }
        val notification = NotificationCompat.Builder(context, NotificationChannels.WELLBEING)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setProgress(limit, viewed.coerceAtMost(limit), false)
            .setContentIntent(appOpenIntent(context, "reels:$appLabel:$percentage".hashCode()))
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(
                "reels:$appLabel:$percentage".hashCode(),
                notification
            )
        }
    }

    fun showScreenTimeWarning(
        context: Context,
        usedMinutes: Int,
        goalMinutes: Int,
        percentage: Int,
        topAppLabel: String,
        topAppMinutes: Int,
        detailed: Boolean,
        repeatedAfterGoal: Boolean
    ) {
        if (goalMinutes <= 0) return
        NotificationChannels.ensure(context)
        val remaining = (goalMinutes - usedMinutes).coerceAtLeast(0)
        val title = if (repeatedAfterGoal) {
            "Screen time is ${usedMinutes - goalMinutes} min over goal"
        } else {
            "Screen time: $percentage% of daily goal"
        }
        val summary = if (usedMinutes < goalMinutes) {
            "$usedMinutes of $goalMinutes min used • $remaining min remaining"
        } else {
            "$usedMinutes min used • daily goal was $goalMinutes min"
        }
        val detail = if (detailed) {
            buildString {
                append("Today you have used your phone for $usedMinutes minutes. ")
                if (usedMinutes < goalMinutes) {
                    append("You have $remaining minutes left before your $goalMinutes-minute goal. ")
                } else {
                    append("You are ${(usedMinutes - goalMinutes).coerceAtLeast(0)} minutes above your goal. ")
                }
                if (topAppLabel.isNotBlank() && topAppMinutes > 0) {
                    append("Most-used controlled app: $topAppLabel ($topAppMinutes min). ")
                }
                append("Consider a 10-minute break, starting Focus, or lowering a distracting app limit.")
            }
        } else {
            summary
        }
        val max = goalMinutes.coerceAtLeast(1)
        val progress = usedMinutes.coerceAtMost(max)
        val notification = NotificationCompat.Builder(context, NotificationChannels.WELLBEING)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setProgress(max, progress, false)
            .setContentIntent(appOpenIntent(context, "screen:$percentage:$usedMinutes".hashCode()))
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(
                "screen:$percentage:${if (repeatedAfterGoal) usedMinutes / 15 else 0}".hashCode(),
                notification
            )
        }
    }

    private fun appOpenIntent(context: Context, requestCode: Int): PendingIntent =
        PendingIntent.getActivity(
            context,
            requestCode,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
