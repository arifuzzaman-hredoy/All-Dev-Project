package com.hredoy.focus_guard_flutter

import android.app.NotificationManager
import android.content.Context

object DndController {
    fun enable(context: Context) {
        val store = FocusStore(context)
        if (!store.useDnd()) return
        val manager = context.getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) return
        runCatching {
            store.savePreviousDndFilter(manager.currentInterruptionFilter)
            manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
    }

    fun restore(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) return
        val previous = FocusStore(context).previousDndFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
        runCatching { manager.setInterruptionFilter(previous) }
    }
}
