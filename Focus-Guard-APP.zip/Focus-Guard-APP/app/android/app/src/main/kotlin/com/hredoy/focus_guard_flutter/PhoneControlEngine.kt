package com.hredoy.focus_guard_flutter

import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque
import java.util.Calendar

data class ReelPagerEvidence(
    val signatureSeed: String,
    val reason: String
)

object PhoneControlEngine {
    private val shortVideoPackages = setOf(
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill"
    )

    private val strongRouteHints = mapOf(
        "com.instagram.android" to listOf(
            "clips_viewer",
            "reels_viewer",
            "reel_viewer",
            "clips_player"
        ),
        "com.facebook.katana" to listOf(
            "reels_viewer",
            "reel_viewer",
            "clips_viewer",
            "reels_player"
        ),
        "com.google.android.youtube" to listOf(
            "reel_watch_player",
            "shorts_player",
            "reel_recycler",
            "shorts_recycler"
        )
    )

    private val routeWords = listOf("reels", "reel", "shorts", "short video", "clips")
    private val immersivePlayerHints = listOf("player", "viewer", "watch", "video")

    private val pagerRouteHints = listOf(
        "clips_viewer",
        "reels_viewer",
        "reel_viewer",
        "clips_player",
        "reels_player",
        "reel_watch_player",
        "shorts_player",
        "reel_recycler",
        "shorts_recycler",
        "reels_pager",
        "shorts_pager"
    )

    private val nonPagerScrollHints = listOf(
        "comment",
        "reply",
        "caption",
        "description",
        "sheet",
        "dialog",
        "reaction",
        "like_list",
        "share_sheet"
    )

    fun decision(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?,
        focusStore: FocusStore,
        phoneStore: PhoneControlStore,
        usageMillis: Long
    ): PhoneControlDecision? {
        if (packageName.isBlank() || PhoneControlSafety.isProtectedPackage(packageName)) {
            return null
        }

        val now = System.currentTimeMillis()
        val calendar = Calendar.getInstance()
        val focusUntil = focusStore.focusUntil()
        val policy = phoneStore.policy()

        if (focusUntil > now) {
            if (policy.studyModeEnabled &&
                policy.focusUsesStudyRules &&
                packageName in policy.studyBlockedPackages
            ) {
                return PhoneControlDecision(
                    reason = "Study Focus",
                    detail = "blocked by your Study Mode list until focus ends"
                )
            }
            if (packageName in focusStore.blockedPackages()) {
                return PhoneControlDecision(
                    reason = "Focus Shield",
                    detail = "blocked until the focus timer ends"
                )
            }
        }

        if (policy.studyScheduleActive(calendar) &&
            packageName in policy.studyBlockedPackages
        ) {
            return PhoneControlDecision(
                reason = "Study Schedule",
                detail = "blocked during your automatic study window"
            )
        }

        if (!policy.masterEnabled) return null

        if (policy.scheduleProfilesEnabled) {
            val activeProfile = policy
                .activeProfilesFor(packageName, calendar)
                .firstOrNull { profile -> !phoneStore.isProfileUnlocked(profile.id) }
            if (activeProfile != null) {
                return PhoneControlDecision(
                    reason = "Schedule Profile",
                    detail = "${activeProfile.name} is active until ${formatMinute(activeProfile.endMinute)}"
                )
            }
        }

        val rule = policy.ruleFor(packageName)
        if (rule != null) {
            if (rule.blockApp) {
                return PhoneControlDecision(
                    reason = "Blocked by you",
                    detail = "this app is on your manual block list"
                )
            }

            if (policy.scheduleEnabled &&
                rule.blockOutsideSchedule &&
                !rule.isAllowedAt(calendar)
            ) {
                return PhoneControlDecision(
                    reason = "Schedule Blocker",
                    detail = "outside ${formatMinute(rule.allowedStartMinute)}–${formatMinute(rule.allowedEndMinute)}"
                )
            }

            if (policy.appLimitsEnabled &&
                rule.dailyLimitMinutes > 0 &&
                usageMillis >= rule.dailyLimitMinutes * 60_000L
            ) {
                return PhoneControlDecision(
                    reason = "Daily App Limit",
                    detail = "${rule.dailyLimitMinutes} minute limit reached"
                )
            }

            if (policy.scrollLimitEnabled &&
                rule.scrollLimit > 0 &&
                phoneStore.scrollCount(packageName) >= rule.scrollLimit
            ) {
                return PhoneControlDecision(
                    reason = "Scroll Limit",
                    detail = "${rule.scrollLimit} scroll gestures reached"
                )
            }
        }

        if (policy.reelsBlockerEnabled &&
            isShortVideoScreen(packageName, event, root)
        ) {
            if (policy.globalReelsWindowActive(now) &&
                policy.globalReelsWindowApplies(packageName) &&
                phoneStore.globalReelsWindowCount() >= policy.globalReelsWindowLimit
            ) {
                return PhoneControlDecision(
                    reason = "Fixed Reels Budget",
                    detail = "${policy.globalReelsWindowLimit} reels reached for this locked date range"
                )
            }

            if (rule?.reelsGuard == true) {
                val viewed = phoneStore.reelViewedCount(packageName)
                val watchMillis = phoneStore.reelWatchMillis(packageName)
                val countReached = rule.reelsDailyLimit > 0 &&
                    viewed >= rule.reelsDailyLimit
                val timeReached = rule.reelsTimeLimitMinutes > 0 &&
                    watchMillis >= rule.reelsTimeLimitMinutes * 60_000L
                if (rule.blockReelsImmediately || countReached || timeReached) {
                    val detail = when {
                        rule.blockReelsImmediately -> "short-video feed is blocked; the rest of the app remains usable"
                        countReached -> "${rule.reelsDailyLimit} short videos reached today"
                        else -> "${rule.reelsTimeLimitMinutes} short-video minutes reached today"
                    }
                    return PhoneControlDecision(
                        reason = "Reels Guard",
                        detail = detail
                    )
                }
            }
        }

        return null
    }

    fun shouldTrackScroll(packageName: String, phoneStore: PhoneControlStore): Boolean {
        val policy = phoneStore.policy()
        if (!policy.masterEnabled) return false
        val rule = policy.ruleFor(packageName)
        val globalReels = policy.reelsBlockerEnabled &&
            policy.globalReelsWindowActive() &&
            policy.globalReelsWindowApplies(packageName)
        return (policy.scrollLimitEnabled && (rule?.scrollLimit ?: 0) > 0) ||
            (policy.reelsBlockerEnabled && rule?.reelsGuard == true) ||
            globalReels
    }


    fun reelPagerEvidence(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?
    ): ReelPagerEvidence? {
        if (event?.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED || root == null) {
            return null
        }

        val source = runCatching { event.source }.getOrNull()
        val combined = readSourceContext(source)
        if (nonPagerScrollHints.any(combined::contains)) return null

        val rootSignals = readNodeSignals(root)
        val strongRouteSource = pagerRouteHints.any(combined::contains)
        val strongRouteInRoot = strongRouteHints[packageName]
            .orEmpty()
            .any(rootSignals.viewIds::contains)
        val pagerClass = combined.contains("viewpager") ||
            combined.contains("recyclerview") ||
            combined.contains("pager")

        val rootBounds = Rect()
        val sourceBounds = Rect()
        root.getBoundsInScreen(rootBounds)
        if (source != null) {
            source.getBoundsInScreen(sourceBounds)
        } else {
            sourceBounds.set(rootBounds)
        }
        val rootHeight = rootBounds.height().coerceAtLeast(1)
        val rootWidth = rootBounds.width().coerceAtLeast(1)
        val fillsMostOfScreen = sourceBounds.height() >= (rootHeight * 72 / 100) &&
            sourceBounds.width() >= (rootWidth * 72 / 100)

        val indexChanged = event.fromIndex >= 0 &&
            event.toIndex >= 0 &&
            event.fromIndex != event.toIndex
        val largeVerticalDelta = if (android.os.Build.VERSION.SDK_INT >= 28) {
            kotlin.math.abs(event.scrollDeltaY) >= maxOf(180, rootHeight / 4)
        } else {
            false
        }
        val compactPagerCollection = event.itemCount in 1..50 && indexChanged
        val routeConfirmed = packageName in shortVideoPackages ||
            strongRouteSource ||
            strongRouteInRoot

        val reason = ReelPagerHeuristics.confirmationReason(
            ReelPagerHeuristicInput(
                routeConfirmed = routeConfirmed,
                strongRouteSource = strongRouteSource,
                pagerClass = pagerClass,
                fillsMostOfScreen = fillsMostOfScreen,
                indexChanged = indexChanged,
                largeVerticalDelta = largeVerticalDelta,
                compactPagerCollection = compactPagerCollection,
                sourceMissing = source == null,
                nonPagerSurface = false
            )
        ) ?: return null

        val signatureSeed = if (indexChanged) {
            "index:${event.fromIndex}:${event.toIndex}:${event.itemCount}"
        } else {
            ""
        }
        return ReelPagerEvidence(signatureSeed = signatureSeed, reason = reason)
    }

    fun isLikelyReelPagerEvent(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?
    ): Boolean = reelPagerEvidence(packageName, event, root) != null

    fun isShortVideoScreen(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?
    ): Boolean {
        if (packageName in shortVideoPackages) return true

        val eventSignal = buildString {
            event?.text?.forEach { value -> append(' ').append(value) }
            append(' ').append(event?.contentDescription?.toString().orEmpty())
            append(' ').append(event?.className?.toString().orEmpty())
        }.lowercase()
        val nodeSignals = readNodeSignals(root)
        val packageRouteHints = strongRouteHints[packageName].orEmpty()
        if (packageRouteHints.any(nodeSignals.viewIds::contains)) return true

        val routeWordInEvent = routeWords.any(eventSignal::contains)
        val routeWordInViewId = routeWords.any(nodeSignals.viewIds::contains)
        val immersivePlayer = immersivePlayerHints.any(nodeSignals.viewIds::contains)
        return routeWordInEvent && routeWordInViewId && immersivePlayer
    }

    private fun readSourceContext(source: AccessibilityNodeInfo?): String {
        if (source == null) return ""
        val values = StringBuilder()
        var current: AccessibilityNodeInfo? = source
        var depth = 0
        while (current != null && depth < MAX_SOURCE_ANCESTORS) {
            val node = current
            values.append(' ').append(node.viewIdResourceName.orEmpty())
            values.append(' ').append(node.className?.toString().orEmpty())
            values.append(' ').append(node.contentDescription?.toString().orEmpty())
            current = runCatching { node.parent }.getOrNull()
            depth += 1
        }
        return values.toString().lowercase()
    }

    private fun readNodeSignals(root: AccessibilityNodeInfo?): NodeSignals {
        if (root == null) return NodeSignals()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val viewIds = StringBuilder()
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_NODES) {
            val node = queue.removeFirst()
            visited += 1
            viewIds.append(' ').append(node.viewIdResourceName.orEmpty())
            val childCount = node.childCount.coerceAtMost(MAX_CHILDREN_PER_NODE)
            for (index in 0 until childCount) {
                runCatching { node.getChild(index) }
                    .getOrNull()
                    ?.let(queue::addLast)
            }
        }
        return NodeSignals(viewIds = viewIds.toString().lowercase())
    }

    private data class NodeSignals(val viewIds: String = "")

    private fun formatMinute(value: Int): String {
        val safe = value.coerceIn(0, 1439)
        val hour = safe / 60
        val minute = safe % 60
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        val suffix = if (hour >= 12) "PM" else "AM"
        return "%d:%02d %s".format(displayHour, minute, suffix)
    }

    private const val MAX_NODES = 90
    private const val MAX_CHILDREN_PER_NODE = 24
    private const val MAX_SOURCE_ANCESTORS = 5
}
