package com.hredoy.focus_guard_flutter

import java.nio.charset.StandardCharsets


data class DnsPacketRequest(
    val sourceAddress: ByteArray,
    val destinationAddress: ByteArray,
    val sourcePort: Int,
    val destinationPort: Int,
    val identification: Int,
    val dnsPayload: ByteArray,
    val questionName: String,
    val questionEndOffset: Int
)

object DnsPacket {
    fun parseIpv4Udp(packet: ByteArray, length: Int): DnsPacketRequest? {
        if (length < 32) return null
        val version = unsigned(packet[0]) ushr 4
        val headerLength = (unsigned(packet[0]) and 0x0F) * 4
        if (version != 4 || headerLength < 20 || length < headerLength + 8 + 12) {
            return null
        }
        if (unsigned(packet[9]) != UDP_PROTOCOL) return null
        val fragmentFlags = readU16(packet, 6)
        if (fragmentFlags and 0x1FFF != 0) return null
        val sourcePort = readU16(packet, headerLength)
        val destinationPort = readU16(packet, headerLength + 2)
        if (destinationPort != DNS_PORT) return null
        val udpLength = readU16(packet, headerLength + 4)
        if (udpLength < 8 + 12) return null
        val dnsOffset = headerLength + 8
        val dnsLength = minOf(udpLength - 8, length - dnsOffset)
        if (dnsLength < 12) return null
        val dns = packet.copyOfRange(dnsOffset, dnsOffset + dnsLength)
        val parsedQuestion = parseQuestion(dns) ?: return null
        return DnsPacketRequest(
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20),
            sourcePort = sourcePort,
            destinationPort = destinationPort,
            identification = readU16(packet, 4),
            dnsPayload = dns,
            questionName = parsedQuestion.first,
            questionEndOffset = parsedQuestion.second
        )
    }

    fun buildNxDomainResponse(request: DnsPacketRequest): ByteArray {
        val questionEnd = request.questionEndOffset.coerceIn(12, request.dnsPayload.size)
        val response = request.dnsPayload.copyOf(questionEnd)
        if (response.size < 12) return buildIpv4UdpResponse(request, response)
        response[2] = 0x81.toByte()
        response[3] = 0x83.toByte()
        response[6] = 0
        response[7] = 0
        response[8] = 0
        response[9] = 0
        response[10] = 0
        response[11] = 0
        return buildIpv4UdpResponse(request, response)
    }

    fun buildIpv4UdpResponse(
        request: DnsPacketRequest,
        dnsResponse: ByteArray
    ): ByteArray {
        val udpLength = 8 + dnsResponse.size
        val totalLength = 20 + udpLength
        val packet = ByteArray(totalLength)
        packet[0] = 0x45
        packet[1] = 0
        writeU16(packet, 2, totalLength)
        writeU16(packet, 4, request.identification)
        writeU16(packet, 6, 0x4000)
        packet[8] = 64
        packet[9] = UDP_PROTOCOL.toByte()
        request.destinationAddress.copyInto(packet, destinationOffset = 12)
        request.sourceAddress.copyInto(packet, destinationOffset = 16)
        writeU16(packet, 10, ipChecksum(packet, 0, 20))

        writeU16(packet, 20, DNS_PORT)
        writeU16(packet, 22, request.sourcePort)
        writeU16(packet, 24, udpLength)
        writeU16(packet, 26, 0)
        dnsResponse.copyInto(packet, destinationOffset = 28)
        return packet
    }

    private fun parseQuestion(dns: ByteArray): Pair<String, Int>? {
        if (dns.size < 17 || readU16(dns, 4) < 1) return null
        var offset = 12
        val labels = ArrayList<String>(8)
        var guard = 0
        while (offset < dns.size && guard++ < 64) {
            val labelLength = unsigned(dns[offset])
            offset += 1
            if (labelLength == 0) break
            if (labelLength and 0xC0 != 0 || labelLength > 63) return null
            if (offset + labelLength > dns.size) return null
            val label = String(
                dns,
                offset,
                labelLength,
                StandardCharsets.US_ASCII
            )
            labels.add(label)
            offset += labelLength
        }
        if (labels.isEmpty() || offset + 4 > dns.size) return null
        val questionEnd = offset + 4
        return ProtectionRules.normalizeDomain(labels.joinToString(".")) to questionEnd
    }

    private fun ipChecksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += readU16(bytes, index).toLong()
            while (sum > 0xFFFF) sum = (sum and 0xFFFF) + (sum ushr 16)
            index += 2
        }
        if (index < end) {
            sum += unsigned(bytes[index]).toLong() shl 8
            while (sum > 0xFFFF) sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return sum.inv().toInt() and 0xFFFF
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        (unsigned(bytes[offset]) shl 8) or unsigned(bytes[offset + 1])

    private fun writeU16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = ((value ushr 8) and 0xFF).toByte()
        bytes[offset + 1] = (value and 0xFF).toByte()
    }

    private fun unsigned(value: Byte): Int = value.toInt() and 0xFF

    private const val UDP_PROTOCOL = 17
    private const val DNS_PORT = 53
}
