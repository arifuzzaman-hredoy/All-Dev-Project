package com.hredoy.focus_guard_flutter

import android.view.accessibility.AccessibilityNodeInfo
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.Locale

/**
 * Builds a privacy-safe identity fingerprint from the currently visible
 * short-video page. Raw text never leaves memory and is never persisted.
 */
data class ReelFingerprint(
    val value: String,
    val identityTokenCount: Int
) {
    val usable: Boolean
        get() = value.isNotBlank() && identityTokenCount > 0
}

object ReelFingerprintBuilder {
    private val reelContainerHints = listOf(
        "clips_viewer",
        "reels_viewer",
        "reel_viewer",
        "clips_player",
        "reels_player",
        "reel_watch_player",
        "shorts_player",
        "reel_recycler",
        "shorts_recycler",
        "reels_pager",
        "shorts_pager"
    )

    private val identityViewHints = listOf(
        "username",
        "user_name",
        "author",
        "creator",
        "owner",
        "channel",
        "handle",
        "caption",
        "title",
        "description",
        "media_text",
        "reel_text",
        "shorts_title"
    )

    private val ignoredViewHints = listOf(
        "comment",
        "reply",
        "like",
        "reaction",
        "share",
        "save",
        "bookmark",
        "follow",
        "button",
        "toolbar",
        "progress",
        "seek",
        "duration",
        "timestamp",
        "badge",
        "count",
        "audio",
        "music",
        "sound"
    )

    private val ignoredExactText = setOf(
        "like",
        "likes",
        "comment",
        "comments",
        "share",
        "save",
        "follow",
        "following",
        "more",
        "reels",
        "reel",
        "shorts",
        "short",
        "play",
        "pause",
        "mute",
        "unmute",
        "original audio",
        "use audio"
    )

    fun capture(packageName: String, root: AccessibilityNodeInfo?): ReelFingerprint {
        if (packageName.isBlank() || root == null) return ReelFingerprint("", 0)

        val captureRoot = findReelContainer(root) ?: root
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(captureRoot)
        val tokens = linkedSetOf<String>()
        var visited = 0

        while (queue.isNotEmpty() && visited < MAX_NODES) {
            val node = queue.removeFirst()
            visited += 1
            if (node.isVisibleToUser || node === captureRoot) {
                val viewId = node.viewIdResourceName.orEmpty().lowercase(Locale.US)
                val ignoredView = ignoredViewHints.any(viewId::contains)
                val identityView = identityViewHints.any(viewId::contains)
                if (!ignoredView) {
                    addToken(tokens, node.text?.toString(), identityView)
                    addToken(tokens, node.contentDescription?.toString(), identityView)
                }
            }

            val childCount = node.childCount.coerceAtMost(MAX_CHILDREN_PER_NODE)
            for (index in 0 until childCount) {
                runCatching { node.getChild(index) }
                    .getOrNull()
                    ?.let(queue::addLast)
            }
        }

        return fromRawTokens(packageName, tokens.toList())
    }

    private fun findReelContainer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_CONTAINER_SEARCH_NODES) {
            val node = queue.removeFirst()
            visited += 1
            val viewId = node.viewIdResourceName.orEmpty().lowercase(Locale.US)
            if (reelContainerHints.any(viewId::contains)) return node
            val childCount = node.childCount.coerceAtMost(MAX_CHILDREN_PER_NODE)
            for (index in 0 until childCount) {
                runCatching { node.getChild(index) }
                    .getOrNull()
                    ?.let(queue::addLast)
            }
        }
        return null
    }

    internal fun fromRawTokens(
        packageName: String,
        rawTokens: List<String>
    ): ReelFingerprint {
        val normalized = rawTokens
            .asSequence()
            .map(::normalizeIdentityToken)
            .filter(String::isNotBlank)
            .distinct()
            .sorted()
            .take(MAX_IDENTITY_TOKENS)
            .toList()
        if (packageName.isBlank() || normalized.isEmpty()) {
            return ReelFingerprint("", 0)
        }
        val payload = buildString {
            append(packageName.lowercase(Locale.US))
            normalized.forEach { token -> append('\n').append(token) }
        }
        return ReelFingerprint(
            value = sha256(payload).take(FINGERPRINT_LENGTH),
            identityTokenCount = normalized.size
        )
    }

    internal fun normalizeIdentityToken(raw: String): String {
        var value = raw
            .lowercase(Locale.US)
            .replace(URL_PATTERN, " ")
            .replace(TIME_PATTERN, " ")
            .replace(WHITESPACE_PATTERN, " ")
            .trim()
        if (value.length !in MIN_TEXT_LENGTH..MAX_TEXT_LENGTH) return ""
        if (value in ignoredExactText) return ""

        val words = value.split(' ')
            .map { word -> word.trim(*PUNCTUATION) }
            .filter { word ->
                word.isNotBlank() &&
                    !PURE_NUMBER_PATTERN.matches(word) &&
                    !COMPACT_COUNT_PATTERN.matches(word)
            }
        value = words.joinToString(" ").trim()
        if (value.length < MIN_TEXT_LENGTH || value in ignoredExactText) return ""
        if (!value.any(Char::isLetter)) return ""
        return value.take(MAX_TEXT_LENGTH)
    }

    private fun addToken(
        target: MutableSet<String>,
        raw: String?,
        identityView: Boolean
    ) {
        val normalized = normalizeIdentityToken(raw.orEmpty())
        if (normalized.isBlank()) return
        if (!identityView && normalized.length < GENERAL_TEXT_MIN_LENGTH && !normalized.startsWith("@")) {
            return
        }
        target += normalized
    }

    private fun sha256(value: String): String = MessageDigest
        .getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }

    private val URL_PATTERN = Regex("https?://\\S+|www\\.\\S+")
    private val TIME_PATTERN = Regex("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b")
    private val WHITESPACE_PATTERN = Regex("\\s+")
    private val PURE_NUMBER_PATTERN = Regex("^[\\d.,%+\u0660-\u0669\u06f0-\u06f9]+$")
    private val COMPACT_COUNT_PATTERN = Regex("^\\d+(?:[.,]\\d+)?[kmb]$")
    private val PUNCTUATION = charArrayOf(
        '.', ',', ':', ';', '!', '?', '#', '*', '•', '·', '|', '/', '\\', '(', ')', '[', ']', '{', '}', '"', '\''
    )

    private const val MAX_CONTAINER_SEARCH_NODES = 180
    private const val MAX_NODES = 240
    private const val MAX_CHILDREN_PER_NODE = 24
    private const val MAX_IDENTITY_TOKENS = 24
    private const val FINGERPRINT_LENGTH = 24
    private const val MIN_TEXT_LENGTH = 3
    private const val GENERAL_TEXT_MIN_LENGTH = 5
    private const val MAX_TEXT_LENGTH = 120
}
