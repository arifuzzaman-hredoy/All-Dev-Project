package com.hredoy.focus_guard_flutter

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar


data class ProtectionPolicy(
    val webProtectionEnabled: Boolean = false,
    val vpnDnsEnabled: Boolean = false,
    val adultContentEnabled: Boolean = true,
    val safeSearchEnabled: Boolean = true,
    val browserGuardEnabled: Boolean = true,
    val webScheduleEnabled: Boolean = false,
    val webWeekdays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val webStartMinute: Int = 0,
    val webEndMinute: Int = 0,
    val blockedDomains: Set<String> = emptySet(),
    val allowedDomains: Set<String> = emptySet(),
    val blockedKeywords: Set<String> = setOf("porn", "xxx", "adult video", "explicit video"),
    val primaryDns: String = "1.1.1.3",
    val secondaryDns: String = "1.0.0.3",
    val failClosed: Boolean = false,
    val historyLimit: Int = 200,
    val primeModeUntilMillis: Long = 0L,
    val primeBlockedPackages: Set<String> = emptySet(),
    val primeAllowedPackages: Set<String> = emptySet(),
    val primeSilenceNotifications: Boolean = true,
    val keepMeOutUntilMillis: Long = 0L,
    val keepMeOutPackages: Set<String> = emptySet(),
    val tamperProtectionEnabled: Boolean = false,
    val uninstallGuardEnabled: Boolean = false,
    val rebootRestoreEnabled: Boolean = true,
    val emergencyUnlockMinutes: Int = 5,
    val maxEmergencyUnlocksPerDay: Int = 2
) {
    fun isPrimeActive(now: Long = System.currentTimeMillis()): Boolean =
        primeModeUntilMillis > now

    fun isKeepMeOutActive(now: Long = System.currentTimeMillis()): Boolean =
        keepMeOutUntilMillis > now

    fun isWebWindowActive(calendar: Calendar = Calendar.getInstance()): Boolean {
        if (!webProtectionEnabled) return false
        if (!webScheduleEnabled) return true
        val start = webStartMinute.coerceIn(0, 1439)
        val end = webEndMinute.coerceIn(0, 1439)
        val weekday = androidWeekdayToMondayFirstForProtection(
            calendar.get(Calendar.DAY_OF_WEEK)
        )
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 +
            calendar.get(Calendar.MINUTE)
        if (start == end) return weekday in webWeekdays
        if (start < end) {
            return weekday in webWeekdays && minute >= start && minute < end
        }
        val previousWeekday = if (weekday == 1) 7 else weekday - 1
        return (weekday in webWeekdays && minute >= start) ||
            (previousWeekday in webWeekdays && minute < end)
    }

    fun toMap(): Map<String, Any> = mapOf(
        "webProtectionEnabled" to webProtectionEnabled,
        "vpnDnsEnabled" to vpnDnsEnabled,
        "adultContentEnabled" to adultContentEnabled,
        "safeSearchEnabled" to safeSearchEnabled,
        "browserGuardEnabled" to browserGuardEnabled,
        "webScheduleEnabled" to webScheduleEnabled,
        "webWeekdays" to webWeekdays.sorted(),
        "webStartMinute" to webStartMinute,
        "webEndMinute" to webEndMinute,
        "blockedDomains" to blockedDomains.sorted(),
        "allowedDomains" to allowedDomains.sorted(),
        "blockedKeywords" to blockedKeywords.sorted(),
        "primaryDns" to primaryDns,
        "secondaryDns" to secondaryDns,
        "failClosed" to failClosed,
        "historyLimit" to historyLimit,
        "primeModeUntilMillis" to primeModeUntilMillis,
        "primeBlockedPackages" to primeBlockedPackages.sorted(),
        "primeAllowedPackages" to primeAllowedPackages.sorted(),
        "primeSilenceNotifications" to primeSilenceNotifications,
        "keepMeOutUntilMillis" to keepMeOutUntilMillis,
        "keepMeOutPackages" to keepMeOutPackages.sorted(),
        "tamperProtectionEnabled" to tamperProtectionEnabled,
        "uninstallGuardEnabled" to uninstallGuardEnabled,
        "rebootRestoreEnabled" to rebootRestoreEnabled,
        "emergencyUnlockMinutes" to emergencyUnlockMinutes,
        "maxEmergencyUnlocksPerDay" to maxEmergencyUnlocksPerDay
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("webProtectionEnabled", webProtectionEnabled)
        put("vpnDnsEnabled", vpnDnsEnabled)
        put("adultContentEnabled", adultContentEnabled)
        put("safeSearchEnabled", safeSearchEnabled)
        put("browserGuardEnabled", browserGuardEnabled)
        put("webScheduleEnabled", webScheduleEnabled)
        put("webWeekdays", JSONArray(webWeekdays.sorted()))
        put("webStartMinute", webStartMinute)
        put("webEndMinute", webEndMinute)
        put("blockedDomains", JSONArray(blockedDomains.sorted()))
        put("allowedDomains", JSONArray(allowedDomains.sorted()))
        put("blockedKeywords", JSONArray(blockedKeywords.sorted()))
        put("primaryDns", primaryDns)
        put("secondaryDns", secondaryDns)
        put("failClosed", failClosed)
        put("historyLimit", historyLimit)
        put("primeModeUntilMillis", primeModeUntilMillis)
        put("primeBlockedPackages", JSONArray(primeBlockedPackages.sorted()))
        put("primeAllowedPackages", JSONArray(primeAllowedPackages.sorted()))
        put("primeSilenceNotifications", primeSilenceNotifications)
        put("keepMeOutUntilMillis", keepMeOutUntilMillis)
        put("keepMeOutPackages", JSONArray(keepMeOutPackages.sorted()))
        put("tamperProtectionEnabled", tamperProtectionEnabled)
        put("uninstallGuardEnabled", uninstallGuardEnabled)
        put("rebootRestoreEnabled", rebootRestoreEnabled)
        put("emergencyUnlockMinutes", emergencyUnlockMinutes)
        put("maxEmergencyUnlocksPerDay", maxEmergencyUnlocksPerDay)
    }

    companion object {
        fun fromMap(raw: Map<*, *>): ProtectionPolicy {
            fun stringSet(key: String): Set<String> =
                (raw[key] as? List<*>)
                    ?.mapNotNull { value ->
                        value?.toString()
                            ?.trim()
                            ?.lowercase()
                            ?.takeIf(String::isNotBlank)
                    }
                    ?.toSet()
                    .orEmpty()

            val weekdays = (raw["webWeekdays"] as? List<*>)
                ?.mapNotNull { (it as? Number)?.toInt() }
                ?.filter { it in 1..7 }
                ?.toSet()
                .orEmpty()
                .ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
            val keywords = stringSet("blockedKeywords")
                .ifEmpty { setOf("porn", "xxx", "adult video", "explicit video") }
            return ProtectionPolicy(
                webProtectionEnabled = raw["webProtectionEnabled"] as? Boolean ?: false,
                vpnDnsEnabled = raw["vpnDnsEnabled"] as? Boolean ?: false,
                adultContentEnabled = raw["adultContentEnabled"] as? Boolean ?: true,
                safeSearchEnabled = raw["safeSearchEnabled"] as? Boolean ?: true,
                browserGuardEnabled = raw["browserGuardEnabled"] as? Boolean ?: true,
                webScheduleEnabled = raw["webScheduleEnabled"] as? Boolean ?: false,
                webWeekdays = weekdays,
                webStartMinute = ((raw["webStartMinute"] as? Number)?.toInt()
                    ?: 0).coerceIn(0, 1439),
                webEndMinute = ((raw["webEndMinute"] as? Number)?.toInt()
                    ?: 0).coerceIn(0, 1439),
                blockedDomains = stringSet("blockedDomains"),
                allowedDomains = stringSet("allowedDomains"),
                blockedKeywords = keywords,
                primaryDns = raw["primaryDns"]?.toString()
                    ?.takeIf(ProtectionRules::isValidIpv4)
                    ?: "1.1.1.3",
                secondaryDns = raw["secondaryDns"]?.toString()
                    ?.takeIf(ProtectionRules::isValidIpv4)
                    ?: "1.0.0.3",
                failClosed = raw["failClosed"] as? Boolean ?: false,
                historyLimit = ((raw["historyLimit"] as? Number)?.toInt()
                    ?: 200).coerceIn(20, 1000),
                primeModeUntilMillis = ((raw["primeModeUntilMillis"] as? Number)?.toLong()
                    ?: 0L).coerceAtLeast(0L),
                primeBlockedPackages = stringSet("primeBlockedPackages"),
                primeAllowedPackages = stringSet("primeAllowedPackages"),
                primeSilenceNotifications =
                    raw["primeSilenceNotifications"] as? Boolean ?: true,
                keepMeOutUntilMillis = ((raw["keepMeOutUntilMillis"] as? Number)?.toLong()
                    ?: 0L).coerceAtLeast(0L),
                keepMeOutPackages = stringSet("keepMeOutPackages"),
                tamperProtectionEnabled =
                    raw["tamperProtectionEnabled"] as? Boolean ?: false,
                uninstallGuardEnabled =
                    raw["uninstallGuardEnabled"] as? Boolean ?: false,
                rebootRestoreEnabled = raw["rebootRestoreEnabled"] as? Boolean ?: true,
                emergencyUnlockMinutes = ((raw["emergencyUnlockMinutes"] as? Number)?.toInt()
                    ?: 5).coerceIn(1, 30),
                maxEmergencyUnlocksPerDay =
                    ((raw["maxEmergencyUnlocksPerDay"] as? Number)?.toInt()
                        ?: 2).coerceIn(0, 10)
            )
        }

        fun fromJson(raw: String?): ProtectionPolicy {
            if (raw.isNullOrBlank()) return ProtectionPolicy()
            return runCatching {
                val json = JSONObject(raw)
                fun stringSet(key: String): Set<String> {
                    val values = json.optJSONArray(key) ?: JSONArray()
                    return buildSet {
                        for (index in 0 until values.length()) {
                            val value = values.optString(index)
                                .trim()
                                .lowercase()
                            if (value.isNotBlank()) add(value)
                        }
                    }
                }
                val weekdaysArray = json.optJSONArray("webWeekdays") ?: JSONArray()
                val weekdays = buildSet {
                    for (index in 0 until weekdaysArray.length()) {
                        val day = weekdaysArray.optInt(index, -1)
                        if (day in 1..7) add(day)
                    }
                }.ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
                ProtectionPolicy(
                    webProtectionEnabled = json.optBoolean("webProtectionEnabled", false),
                    vpnDnsEnabled = json.optBoolean("vpnDnsEnabled", false),
                    adultContentEnabled = json.optBoolean("adultContentEnabled", true),
                    safeSearchEnabled = json.optBoolean("safeSearchEnabled", true),
                    browserGuardEnabled = json.optBoolean("browserGuardEnabled", true),
                    webScheduleEnabled = json.optBoolean("webScheduleEnabled", false),
                    webWeekdays = weekdays,
                    webStartMinute = json.optInt("webStartMinute", 0).coerceIn(0, 1439),
                    webEndMinute = json.optInt("webEndMinute", 0).coerceIn(0, 1439),
                    blockedDomains = stringSet("blockedDomains"),
                    allowedDomains = stringSet("allowedDomains"),
                    blockedKeywords = stringSet("blockedKeywords")
                        .ifEmpty {
                            setOf("porn", "xxx", "adult video", "explicit video")
                        },
                    primaryDns = json.optString("primaryDns", "1.1.1.3")
                        .takeIf(ProtectionRules::isValidIpv4)
                        ?: "1.1.1.3",
                    secondaryDns = json.optString("secondaryDns", "1.0.0.3")
                        .takeIf(ProtectionRules::isValidIpv4)
                        ?: "1.0.0.3",
                    failClosed = json.optBoolean("failClosed", false),
                    historyLimit = json.optInt("historyLimit", 200).coerceIn(20, 1000),
                    primeModeUntilMillis = json.optLong("primeModeUntilMillis", 0L)
                        .coerceAtLeast(0L),
                    primeBlockedPackages = stringSet("primeBlockedPackages"),
                    primeAllowedPackages = stringSet("primeAllowedPackages"),
                    primeSilenceNotifications =
                        json.optBoolean("primeSilenceNotifications", true),
                    keepMeOutUntilMillis = json.optLong("keepMeOutUntilMillis", 0L)
                        .coerceAtLeast(0L),
                    keepMeOutPackages = stringSet("keepMeOutPackages"),
                    tamperProtectionEnabled =
                        json.optBoolean("tamperProtectionEnabled", false),
                    uninstallGuardEnabled =
                        json.optBoolean("uninstallGuardEnabled", false),
                    rebootRestoreEnabled = json.optBoolean("rebootRestoreEnabled", true),
                    emergencyUnlockMinutes = json.optInt("emergencyUnlockMinutes", 5)
                        .coerceIn(1, 30),
                    maxEmergencyUnlocksPerDay =
                        json.optInt("maxEmergencyUnlocksPerDay", 2).coerceIn(0, 10)
                )
            }.getOrDefault(ProtectionPolicy())
        }
    }
}


data class ProtectionDecision(
    val reason: String,
    val detail: String,
    val kind: String,
    val target: String = ""
)

private fun androidWeekdayToMondayFirstForProtection(day: Int): Int = when (day) {
    Calendar.MONDAY -> 1
    Calendar.TUESDAY -> 2
    Calendar.WEDNESDAY -> 3
    Calendar.THURSDAY -> 4
    Calendar.FRIDAY -> 5
    Calendar.SATURDAY -> 6
    Calendar.SUNDAY -> 7
    else -> 1
}
