package com.hredoy.focus_guard_flutter

data class ReelPagerHeuristicInput(
    val routeConfirmed: Boolean,
    val strongRouteSource: Boolean,
    val pagerClass: Boolean,
    val fillsMostOfScreen: Boolean,
    val indexChanged: Boolean,
    val largeVerticalDelta: Boolean,
    val compactPagerCollection: Boolean,
    val sourceMissing: Boolean,
    val nonPagerSurface: Boolean
)

object ReelPagerHeuristics {
    fun confirmationReason(input: ReelPagerHeuristicInput): String? {
        if (input.nonPagerSurface || !input.routeConfirmed) return null

        val accepted = when {
            input.strongRouteSource &&
                (input.indexChanged || input.largeVerticalDelta || input.pagerClass) -> true
            input.pagerClass && input.fillsMostOfScreen &&
                (input.largeVerticalDelta || input.compactPagerCollection) -> true
            input.sourceMissing &&
                (input.largeVerticalDelta || input.compactPagerCollection) -> true
            input.fillsMostOfScreen &&
                (input.largeVerticalDelta || input.compactPagerCollection) -> true
            else -> false
        }
        if (!accepted) return null

        return when {
            input.indexChanged -> "index-change"
            input.strongRouteSource -> "route-source"
            input.pagerClass -> "fullscreen-pager"
            else -> "route-delta"
        }
    }
}
