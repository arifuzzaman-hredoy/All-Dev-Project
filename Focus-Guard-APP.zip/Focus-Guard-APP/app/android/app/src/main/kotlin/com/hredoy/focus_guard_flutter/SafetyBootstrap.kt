package com.hredoy.focus_guard_flutter

import android.content.Context

/** One-time fail-open migration for v4.2 safety rules. */
object SafetyBootstrap {
    private const val PREFS = "focus_guard"
    private const val KEY_VERSION = "phone_control_safety_bootstrap_version"
    private const val CURRENT_VERSION = 2

    @Synchronized
    fun apply(context: Context): Boolean {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt(KEY_VERSION, 0) >= CURRENT_VERSION) return false

        FocusStore(appContext).resetBlockingForSafety()
        PhoneControlStore(appContext).applyManualBlockingMigration()
        ProtectionStore(appContext).clearActiveLocksForSafety()
        ProtectionVpnService.stop(appContext)
        prefs.edit().putInt(KEY_VERSION, CURRENT_VERSION).commit()
        return true
    }
}
