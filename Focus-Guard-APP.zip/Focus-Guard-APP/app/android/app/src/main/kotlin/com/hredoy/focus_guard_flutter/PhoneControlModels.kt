package com.hredoy.focus_guard_flutter

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar


data class AppControlRule(
    val packageName: String,
    val label: String,
    val category: String = "normal",
    val enabled: Boolean = true,
    val blockApp: Boolean = false,
    val blockOutsideSchedule: Boolean = false,
    val allowedWeekdays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val allowedStartMinute: Int = 6 * 60,
    val allowedEndMinute: Int = 22 * 60,
    val dailyLimitMinutes: Int = 120,
    val reelsGuard: Boolean = false,
    val blockReelsImmediately: Boolean = false,
    val reelsDailyLimit: Int = 10,
    val reelsTimeLimitMinutes: Int = 15,
    val reelsWarningPercentages: Set<Int> = setOf(50, 75, 90),
    val scrollLimit: Int = 0,
    val commitmentPercent: Int = 20,
    val commitmentLockedUntilMillis: Long = 0L
) {
    val commitmentActive: Boolean
        get() = commitmentLockedUntilMillis > System.currentTimeMillis()

    fun minimumCommitmentMinutes(): Int {
        val base = when {
            dailyLimitMinutes > 0 -> dailyLimitMinutes
            reelsTimeLimitMinutes > 0 -> reelsTimeLimitMinutes
            else -> 60
        }
        return kotlin.math.ceil(base * commitmentPercent.coerceIn(20, 100) / 100.0)
            .toInt()
            .coerceIn(5, 720)
    }

    fun isRestrictive(): Boolean = enabled && (
        blockApp ||
            blockOutsideSchedule ||
            dailyLimitMinutes > 0 ||
            reelsGuard ||
            scrollLimit > 0
        )

    fun toMap(): Map<String, Any> = mapOf(
        "packageName" to packageName,
        "label" to label,
        "category" to category,
        "enabled" to enabled,
        "blockApp" to blockApp,
        "blockOutsideSchedule" to blockOutsideSchedule,
        "allowedWeekdays" to allowedWeekdays.sorted(),
        "allowedStartMinute" to allowedStartMinute,
        "allowedEndMinute" to allowedEndMinute,
        "dailyLimitMinutes" to dailyLimitMinutes,
        "reelsGuard" to reelsGuard,
        "blockReelsImmediately" to blockReelsImmediately,
        "reelsDailyLimit" to reelsDailyLimit,
        "reelsTimeLimitMinutes" to reelsTimeLimitMinutes,
        "reelsWarningPercentages" to reelsWarningPercentages.sorted(),
        "scrollLimit" to scrollLimit,
        "commitmentPercent" to commitmentPercent,
        "commitmentLockedUntilMillis" to commitmentLockedUntilMillis
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("label", label)
        put("category", category)
        put("enabled", enabled)
        put("blockApp", blockApp)
        put("blockOutsideSchedule", blockOutsideSchedule)
        put("allowedWeekdays", JSONArray(allowedWeekdays.sorted()))
        put("allowedStartMinute", allowedStartMinute)
        put("allowedEndMinute", allowedEndMinute)
        put("dailyLimitMinutes", dailyLimitMinutes)
        put("reelsGuard", reelsGuard)
        put("blockReelsImmediately", blockReelsImmediately)
        put("reelsDailyLimit", reelsDailyLimit)
        put("reelsTimeLimitMinutes", reelsTimeLimitMinutes)
        put("reelsWarningPercentages", JSONArray(reelsWarningPercentages.sorted()))
        put("scrollLimit", scrollLimit)
        put("commitmentPercent", commitmentPercent)
        put("commitmentLockedUntilMillis", commitmentLockedUntilMillis)
    }

    fun isAllowedAt(calendar: Calendar): Boolean {
        if (!enabled || !blockOutsideSchedule) return true
        val start = allowedStartMinute.coerceIn(0, 1439)
        val end = allowedEndMinute.coerceIn(0, 1439)
        if (start == end) return true
        val weekday = androidWeekdayToMondayFirst(calendar.get(Calendar.DAY_OF_WEEK))
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        if (start < end) {
            return weekday in allowedWeekdays && minute >= start && minute < end
        }
        val previousWeekday = if (weekday == 1) 7 else weekday - 1
        return (weekday in allowedWeekdays && minute >= start) ||
            (previousWeekday in allowedWeekdays && minute < end)
    }

    companion object {
        fun fromMap(raw: Map<*, *>): AppControlRule {
            val days = (raw["allowedWeekdays"] as? List<*>)
                ?.mapNotNull { (it as? Number)?.toInt() }
                ?.filter { it in 1..7 }
                ?.toSet()
                .orEmpty()
                .ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
            val warningPercentages = (raw["reelsWarningPercentages"] as? List<*>)
                ?.mapNotNull { (it as? Number)?.toInt() }
                ?.filter { it in 10..100 }
                ?.toSet()
                .orEmpty()
                .ifEmpty { setOf(50, 75, 90) }
            return AppControlRule(
                packageName = raw["packageName"]?.toString().orEmpty(),
                label = raw["label"]?.toString()
                    ?.takeIf { it.isNotBlank() }
                    ?: raw["packageName"]?.toString().orEmpty(),
                category = raw["category"]?.toString()?.ifBlank { "normal" } ?: "normal",
                enabled = raw["enabled"] as? Boolean ?: true,
                blockApp = raw["blockApp"] as? Boolean ?: false,
                blockOutsideSchedule = raw["blockOutsideSchedule"] as? Boolean ?: false,
                allowedWeekdays = days,
                allowedStartMinute = ((raw["allowedStartMinute"] as? Number)?.toInt()
                    ?: 360).coerceIn(0, 1439),
                allowedEndMinute = ((raw["allowedEndMinute"] as? Number)?.toInt()
                    ?: 1320).coerceIn(0, 1439),
                dailyLimitMinutes = ((raw["dailyLimitMinutes"] as? Number)?.toInt()
                    ?: 120).coerceAtLeast(0),
                reelsGuard = raw["reelsGuard"] as? Boolean ?: false,
                blockReelsImmediately = if (raw.containsKey("blockReelsImmediately")) {
                    raw["blockReelsImmediately"] as? Boolean ?: false
                } else {
                    raw["reelsGuard"] as? Boolean ?: false
                },
                reelsDailyLimit = ((raw["reelsDailyLimit"] as? Number)?.toInt()
                    ?: 10).coerceAtLeast(0),
                reelsTimeLimitMinutes = ((raw["reelsTimeLimitMinutes"] as? Number)?.toInt()
                    ?: 15).coerceAtLeast(0),
                reelsWarningPercentages = warningPercentages,
                scrollLimit = ((raw["scrollLimit"] as? Number)?.toInt()
                    ?: 0).coerceAtLeast(0),
                commitmentPercent = ((raw["commitmentPercent"] as? Number)?.toInt()
                    ?: 20).coerceIn(20, 100),
                commitmentLockedUntilMillis = ((raw["commitmentLockedUntilMillis"] as? Number)
                    ?.toLong() ?: 0L).coerceAtLeast(0L)
            )
        }

        fun fromJson(raw: JSONObject): AppControlRule {
            val daysArray = raw.optJSONArray("allowedWeekdays") ?: JSONArray()
            val days = buildSet {
                for (index in 0 until daysArray.length()) {
                    val day = daysArray.optInt(index, -1)
                    if (day in 1..7) add(day)
                }
            }.ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
            val warningArray = raw.optJSONArray("reelsWarningPercentages") ?: JSONArray()
            val warningPercentages = buildSet {
                for (index in 0 until warningArray.length()) {
                    val value = warningArray.optInt(index, -1)
                    if (value in 10..100) add(value)
                }
            }.ifEmpty { setOf(50, 75, 90) }
            return AppControlRule(
                packageName = raw.optString("packageName"),
                label = raw.optString("label").ifBlank {
                    raw.optString("packageName")
                },
                category = raw.optString("category", "normal").ifBlank { "normal" },
                enabled = raw.optBoolean("enabled", true),
                blockApp = raw.optBoolean("blockApp", false),
                blockOutsideSchedule = raw.optBoolean("blockOutsideSchedule", false),
                allowedWeekdays = days,
                allowedStartMinute = raw.optInt("allowedStartMinute", 360)
                    .coerceIn(0, 1439),
                allowedEndMinute = raw.optInt("allowedEndMinute", 1320)
                    .coerceIn(0, 1439),
                dailyLimitMinutes = raw.optInt("dailyLimitMinutes", 120)
                    .coerceAtLeast(0),
                reelsGuard = raw.optBoolean("reelsGuard", false),
                blockReelsImmediately = if (raw.has("blockReelsImmediately")) {
                    raw.optBoolean("blockReelsImmediately", false)
                } else {
                    raw.optBoolean("reelsGuard", false)
                },
                reelsDailyLimit = raw.optInt("reelsDailyLimit", 10).coerceAtLeast(0),
                reelsTimeLimitMinutes = raw.optInt("reelsTimeLimitMinutes", 15)
                    .coerceAtLeast(0),
                reelsWarningPercentages = warningPercentages,
                scrollLimit = raw.optInt("scrollLimit", 0).coerceAtLeast(0),
                commitmentPercent = raw.optInt("commitmentPercent", 20)
                    .coerceIn(20, 100),
                commitmentLockedUntilMillis = raw.optLong(
                    "commitmentLockedUntilMillis",
                    0L
                ).coerceAtLeast(0L)
            )
        }
    }
}


data class ScheduleProfile(
    val id: String,
    val name: String,
    val enabled: Boolean = true,
    val blockedPackages: Set<String> = emptySet(),
    val weekdays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val startMinute: Int = 19 * 60,
    val endMinute: Int = 23 * 60,
    val emergencyUnlockMinutes: Int = 10,
    val maxEmergencyUnlocksPerDay: Int = 2,
    val silenceNotifications: Boolean = false
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "enabled" to enabled,
        "blockedPackages" to blockedPackages.sorted(),
        "weekdays" to weekdays.sorted(),
        "startMinute" to startMinute,
        "endMinute" to endMinute,
        "emergencyUnlockMinutes" to emergencyUnlockMinutes,
        "maxEmergencyUnlocksPerDay" to maxEmergencyUnlocksPerDay,
        "silenceNotifications" to silenceNotifications
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("enabled", enabled)
        put("blockedPackages", JSONArray(blockedPackages.sorted()))
        put("weekdays", JSONArray(weekdays.sorted()))
        put("startMinute", startMinute)
        put("endMinute", endMinute)
        put("emergencyUnlockMinutes", emergencyUnlockMinutes)
        put("maxEmergencyUnlocksPerDay", maxEmergencyUnlocksPerDay)
        put("silenceNotifications", silenceNotifications)
    }

    fun isActiveAt(calendar: Calendar): Boolean {
        if (!enabled || blockedPackages.isEmpty()) return false
        val start = startMinute.coerceIn(0, 1439)
        val end = endMinute.coerceIn(0, 1439)
        val weekday = androidWeekdayToMondayFirst(calendar.get(Calendar.DAY_OF_WEEK))
        if (start == end) return weekday in weekdays
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        if (start < end) {
            return weekday in weekdays && minute >= start && minute < end
        }
        val previousWeekday = if (weekday == 1) 7 else weekday - 1
        return (weekday in weekdays && minute >= start) ||
            (previousWeekday in weekdays && minute < end)
    }

    fun blocks(packageName: String, calendar: Calendar): Boolean =
        packageName in blockedPackages && isActiveAt(calendar)

    companion object {
        fun fromMap(raw: Map<*, *>): ScheduleProfile {
            val days = (raw["weekdays"] as? List<*>)
                ?.mapNotNull { (it as? Number)?.toInt() }
                ?.filter { it in 1..7 }
                ?.toSet()
                .orEmpty()
                .ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
            val packages = (raw["blockedPackages"] as? List<*>)
                ?.mapNotNull { value ->
                    value?.toString()?.takeIf { text -> text.isNotBlank() }
                }
                ?.toSet()
                .orEmpty()
            return ScheduleProfile(
                id = raw["id"]?.toString().orEmpty(),
                name = raw["name"]?.toString()?.takeIf(String::isNotBlank)
                    ?: "Schedule profile",
                enabled = raw["enabled"] as? Boolean ?: true,
                blockedPackages = packages,
                weekdays = days,
                startMinute = ((raw["startMinute"] as? Number)?.toInt()
                    ?: 1140).coerceIn(0, 1439),
                endMinute = ((raw["endMinute"] as? Number)?.toInt()
                    ?: 1380).coerceIn(0, 1439),
                emergencyUnlockMinutes = ((raw["emergencyUnlockMinutes"] as? Number)?.toInt()
                    ?: 10).coerceAtLeast(0),
                maxEmergencyUnlocksPerDay = ((raw["maxEmergencyUnlocksPerDay"] as? Number)?.toInt()
                    ?: 2).coerceAtLeast(0),
                silenceNotifications = raw["silenceNotifications"] as? Boolean ?: false
            )
        }

        fun fromJson(raw: JSONObject): ScheduleProfile {
            val daysArray = raw.optJSONArray("weekdays") ?: JSONArray()
            val days = buildSet {
                for (index in 0 until daysArray.length()) {
                    val day = daysArray.optInt(index, -1)
                    if (day in 1..7) add(day)
                }
            }.ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
            val packagesArray = raw.optJSONArray("blockedPackages") ?: JSONArray()
            val packages = buildSet {
                for (index in 0 until packagesArray.length()) {
                    val packageName = packagesArray.optString(index)
                    if (packageName.isNotBlank()) add(packageName)
                }
            }
            return ScheduleProfile(
                id = raw.optString("id"),
                name = raw.optString("name").ifBlank { "Schedule profile" },
                enabled = raw.optBoolean("enabled", true),
                blockedPackages = packages,
                weekdays = days,
                startMinute = raw.optInt("startMinute", 1140).coerceIn(0, 1439),
                endMinute = raw.optInt("endMinute", 1380).coerceIn(0, 1439),
                emergencyUnlockMinutes = raw.optInt("emergencyUnlockMinutes", 10)
                    .coerceAtLeast(0),
                maxEmergencyUnlocksPerDay = raw.optInt("maxEmergencyUnlocksPerDay", 2)
                    .coerceAtLeast(0),
                silenceNotifications = raw.optBoolean("silenceNotifications", false)
            )
        }
    }
}


data class PhoneControlPolicy(
    val masterEnabled: Boolean = false,
    val scheduleEnabled: Boolean = true,
    val scheduleProfilesEnabled: Boolean = true,
    val appLimitsEnabled: Boolean = true,
    val reelsBlockerEnabled: Boolean = true,
    val scrollLimitEnabled: Boolean = true,
    val notificationBlockerEnabled: Boolean = false,
    val notificationPackages: Set<String> = emptySet(),
    val notificationScheduleEnabled: Boolean = false,
    val notificationWeekdays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val notificationStartMinute: Int = 22 * 60,
    val notificationEndMinute: Int = 7 * 60,
    val notificationHistoryLimit: Int = 100,
    val studyModeEnabled: Boolean = true,
    val studyStrictAllowList: Boolean = false,
    val studyAllowedPackages: Set<String> = emptySet(),
    val studyBlockedPackages: Set<String> = emptySet(),
    val studySilenceNotifications: Boolean = true,
    val studyDefaultMinutes: Int = 50,
    val studyDailyGoalMinutes: Int = 120,
    val studyScheduleEnabled: Boolean = false,
    val studyWeekdays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val studyStartMinute: Int = 19 * 60,
    val studyEndMinute: Int = 23 * 60,
    val focusUsesStudyRules: Boolean = true,
    val globalReelsWindowEnabled: Boolean = false,
    val globalReelsWindowStartMillis: Long = 0L,
    val globalReelsWindowEndMillis: Long = 0L,
    val globalReelsWindowLimit: Int = 0,
    val globalReelsWindowPackages: Set<String> = emptySet(),
    val globalReelsWindowLocked: Boolean = false,
    val wellbeingWarningsEnabled: Boolean = true,
    val screenTimeGoalMinutes: Int = 240,
    val screenTimeWarningPercentages: Set<Int> = setOf(50, 75, 90, 100),
    val screenTimeRepeatMinutes: Int = 30,
    val detailedWarningNotifications: Boolean = true,
    val rules: List<AppControlRule> = emptyList(),
    val profiles: List<ScheduleProfile> = emptyList()
) {
    fun ruleFor(packageName: String): AppControlRule? =
        rules.firstOrNull { it.enabled && it.packageName == packageName }

    fun activeProfilesFor(packageName: String, calendar: Calendar): List<ScheduleProfile> =
        profiles.filter { profile -> profile.blocks(packageName, calendar) }

    fun notificationWindowActive(calendar: Calendar): Boolean {
        if (!notificationScheduleEnabled) return true
        val start = notificationStartMinute.coerceIn(0, 1439)
        val end = notificationEndMinute.coerceIn(0, 1439)
        val weekday = androidWeekdayToMondayFirst(calendar.get(Calendar.DAY_OF_WEEK))
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        if (start == end) return weekday in notificationWeekdays
        if (start < end) {
            return weekday in notificationWeekdays && minute >= start && minute < end
        }
        val previousWeekday = if (weekday == 1) 7 else weekday - 1
        return (weekday in notificationWeekdays && minute >= start) ||
            (previousWeekday in notificationWeekdays && minute < end)
    }

    fun studyScheduleActive(calendar: Calendar): Boolean {
        if (!studyModeEnabled || !studyScheduleEnabled) return false
        val start = studyStartMinute.coerceIn(0, 1439)
        val end = studyEndMinute.coerceIn(0, 1439)
        val weekday = androidWeekdayToMondayFirst(calendar.get(Calendar.DAY_OF_WEEK))
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        if (start == end) return weekday in studyWeekdays
        if (start < end) {
            return weekday in studyWeekdays && minute >= start && minute < end
        }
        val previousWeekday = if (weekday == 1) 7 else weekday - 1
        return (weekday in studyWeekdays && minute >= start) ||
            (previousWeekday in studyWeekdays && minute < end)
    }

    fun globalReelsWindowActive(now: Long = System.currentTimeMillis()): Boolean =
        globalReelsWindowEnabled &&
            globalReelsWindowLimit > 0 &&
            globalReelsWindowStartMillis > 0L &&
            globalReelsWindowEndMillis > globalReelsWindowStartMillis &&
            now >= globalReelsWindowStartMillis &&
            now < globalReelsWindowEndMillis

    fun globalReelsWindowApplies(packageName: String): Boolean =
        globalReelsWindowPackages.isEmpty() || packageName in globalReelsWindowPackages

    fun globalReelsWindowId(): String =
        "$globalReelsWindowStartMillis:$globalReelsWindowEndMillis:$globalReelsWindowLimit:" +
            globalReelsWindowPackages.sorted().joinToString(",")

    fun toMap(): Map<String, Any> = mapOf(
        "masterEnabled" to masterEnabled,
        "scheduleEnabled" to scheduleEnabled,
        "scheduleProfilesEnabled" to scheduleProfilesEnabled,
        "appLimitsEnabled" to appLimitsEnabled,
        "reelsBlockerEnabled" to reelsBlockerEnabled,
        "scrollLimitEnabled" to scrollLimitEnabled,
        "notificationBlockerEnabled" to notificationBlockerEnabled,
        "notificationPackages" to notificationPackages.sorted(),
        "notificationScheduleEnabled" to notificationScheduleEnabled,
        "notificationWeekdays" to notificationWeekdays.sorted(),
        "notificationStartMinute" to notificationStartMinute,
        "notificationEndMinute" to notificationEndMinute,
        "notificationHistoryLimit" to notificationHistoryLimit,
        "studyModeEnabled" to studyModeEnabled,
        "studyStrictAllowList" to studyStrictAllowList,
        "studyAllowedPackages" to studyAllowedPackages.sorted(),
        "studyBlockedPackages" to studyBlockedPackages.sorted(),
        "studySilenceNotifications" to studySilenceNotifications,
        "studyDefaultMinutes" to studyDefaultMinutes,
        "studyDailyGoalMinutes" to studyDailyGoalMinutes,
        "studyScheduleEnabled" to studyScheduleEnabled,
        "studyWeekdays" to studyWeekdays.sorted(),
        "studyStartMinute" to studyStartMinute,
        "studyEndMinute" to studyEndMinute,
        "focusUsesStudyRules" to focusUsesStudyRules,
        "globalReelsWindowEnabled" to globalReelsWindowEnabled,
        "globalReelsWindowStartMillis" to globalReelsWindowStartMillis,
        "globalReelsWindowEndMillis" to globalReelsWindowEndMillis,
        "globalReelsWindowLimit" to globalReelsWindowLimit,
        "globalReelsWindowPackages" to globalReelsWindowPackages.sorted(),
        "globalReelsWindowLocked" to globalReelsWindowLocked,
        "wellbeingWarningsEnabled" to wellbeingWarningsEnabled,
        "screenTimeGoalMinutes" to screenTimeGoalMinutes,
        "screenTimeWarningPercentages" to screenTimeWarningPercentages.sorted(),
        "screenTimeRepeatMinutes" to screenTimeRepeatMinutes,
        "detailedWarningNotifications" to detailedWarningNotifications,
        "rules" to rules.map(AppControlRule::toMap),
        "profiles" to profiles.map(ScheduleProfile::toMap)
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("masterEnabled", masterEnabled)
        put("scheduleEnabled", scheduleEnabled)
        put("scheduleProfilesEnabled", scheduleProfilesEnabled)
        put("appLimitsEnabled", appLimitsEnabled)
        put("reelsBlockerEnabled", reelsBlockerEnabled)
        put("scrollLimitEnabled", scrollLimitEnabled)
        put("notificationBlockerEnabled", notificationBlockerEnabled)
        put("notificationPackages", JSONArray(notificationPackages.sorted()))
        put("notificationScheduleEnabled", notificationScheduleEnabled)
        put("notificationWeekdays", JSONArray(notificationWeekdays.sorted()))
        put("notificationStartMinute", notificationStartMinute)
        put("notificationEndMinute", notificationEndMinute)
        put("notificationHistoryLimit", notificationHistoryLimit)
        put("studyModeEnabled", studyModeEnabled)
        put("studyStrictAllowList", studyStrictAllowList)
        put("studyAllowedPackages", JSONArray(studyAllowedPackages.sorted()))
        put("studyBlockedPackages", JSONArray(studyBlockedPackages.sorted()))
        put("studySilenceNotifications", studySilenceNotifications)
        put("studyDefaultMinutes", studyDefaultMinutes)
        put("studyDailyGoalMinutes", studyDailyGoalMinutes)
        put("studyScheduleEnabled", studyScheduleEnabled)
        put("studyWeekdays", JSONArray(studyWeekdays.sorted()))
        put("studyStartMinute", studyStartMinute)
        put("studyEndMinute", studyEndMinute)
        put("focusUsesStudyRules", focusUsesStudyRules)
        put("globalReelsWindowEnabled", globalReelsWindowEnabled)
        put("globalReelsWindowStartMillis", globalReelsWindowStartMillis)
        put("globalReelsWindowEndMillis", globalReelsWindowEndMillis)
        put("globalReelsWindowLimit", globalReelsWindowLimit)
        put("globalReelsWindowPackages", JSONArray(globalReelsWindowPackages.sorted()))
        put("globalReelsWindowLocked", globalReelsWindowLocked)
        put("wellbeingWarningsEnabled", wellbeingWarningsEnabled)
        put("screenTimeGoalMinutes", screenTimeGoalMinutes)
        put("screenTimeWarningPercentages", JSONArray(screenTimeWarningPercentages.sorted()))
        put("screenTimeRepeatMinutes", screenTimeRepeatMinutes)
        put("detailedWarningNotifications", detailedWarningNotifications)
        put("rules", JSONArray().apply { rules.forEach { put(it.toJson()) } })
        put("profiles", JSONArray().apply { profiles.forEach { put(it.toJson()) } })
    }

    companion object {
        private fun stringSet(raw: Any?): Set<String> = (raw as? List<*>)
            ?.mapNotNull { it?.toString()?.takeIf(String::isNotBlank) }
            ?.toSet()
            .orEmpty()

        private fun daySet(raw: Any?): Set<Int> = (raw as? List<*>)
            ?.mapNotNull { (it as? Number)?.toInt() }
            ?.filter { it in 1..7 }
            ?.toSet()
            .orEmpty()
            .ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }

        private fun percentageSet(raw: Any?, fallback: Set<Int>): Set<Int> =
            (raw as? List<*>)
                ?.mapNotNull { (it as? Number)?.toInt() }
                ?.filter { it in 10..100 }
                ?.toSet()
                .orEmpty()
                .ifEmpty { fallback }

        fun fromMap(raw: Map<*, *>): PhoneControlPolicy {
            val rules = (raw["rules"] as? List<*>)
                ?.mapNotNull { (it as? Map<*, *>)?.let(AppControlRule::fromMap) }
                ?.filter { it.packageName.isNotBlank() }
                .orEmpty()
            val profiles = (raw["profiles"] as? List<*>)
                ?.mapNotNull { (it as? Map<*, *>)?.let(ScheduleProfile::fromMap) }
                ?.filter { it.id.isNotBlank() }
                .orEmpty()
            return PhoneControlPolicy(
                masterEnabled = raw["masterEnabled"] as? Boolean ?: false,
                scheduleEnabled = raw["scheduleEnabled"] as? Boolean ?: true,
                scheduleProfilesEnabled = raw["scheduleProfilesEnabled"] as? Boolean ?: true,
                appLimitsEnabled = raw["appLimitsEnabled"] as? Boolean ?: true,
                reelsBlockerEnabled = raw["reelsBlockerEnabled"] as? Boolean ?: true,
                scrollLimitEnabled = raw["scrollLimitEnabled"] as? Boolean ?: true,
                notificationBlockerEnabled = raw["notificationBlockerEnabled"] as? Boolean ?: false,
                notificationPackages = stringSet(raw["notificationPackages"]),
                notificationScheduleEnabled =
                    raw["notificationScheduleEnabled"] as? Boolean ?: false,
                notificationWeekdays = daySet(raw["notificationWeekdays"]),
                notificationStartMinute = ((raw["notificationStartMinute"] as? Number)?.toInt()
                    ?: 1320).coerceIn(0, 1439),
                notificationEndMinute = ((raw["notificationEndMinute"] as? Number)?.toInt()
                    ?: 420).coerceIn(0, 1439),
                notificationHistoryLimit = ((raw["notificationHistoryLimit"] as? Number)?.toInt()
                    ?: 100).coerceIn(10, 500),
                studyModeEnabled = raw["studyModeEnabled"] as? Boolean ?: true,
                studyStrictAllowList = raw["studyStrictAllowList"] as? Boolean ?: false,
                studyAllowedPackages = stringSet(raw["studyAllowedPackages"]),
                studyBlockedPackages = stringSet(raw["studyBlockedPackages"]),
                studySilenceNotifications =
                    raw["studySilenceNotifications"] as? Boolean ?: true,
                studyDefaultMinutes = ((raw["studyDefaultMinutes"] as? Number)?.toInt()
                    ?: 50).coerceIn(10, 240),
                studyDailyGoalMinutes = ((raw["studyDailyGoalMinutes"] as? Number)?.toInt()
                    ?: 120).coerceIn(10, 720),
                studyScheduleEnabled = raw["studyScheduleEnabled"] as? Boolean ?: false,
                studyWeekdays = daySet(raw["studyWeekdays"]),
                studyStartMinute = ((raw["studyStartMinute"] as? Number)?.toInt()
                    ?: 1140).coerceIn(0, 1439),
                studyEndMinute = ((raw["studyEndMinute"] as? Number)?.toInt()
                    ?: 1380).coerceIn(0, 1439),
                focusUsesStudyRules = raw["focusUsesStudyRules"] as? Boolean ?: true,
                globalReelsWindowEnabled =
                    raw["globalReelsWindowEnabled"] as? Boolean ?: false,
                globalReelsWindowStartMillis = ((raw["globalReelsWindowStartMillis"] as? Number)
                    ?.toLong() ?: 0L).coerceAtLeast(0L),
                globalReelsWindowEndMillis = ((raw["globalReelsWindowEndMillis"] as? Number)
                    ?.toLong() ?: 0L).coerceAtLeast(0L),
                globalReelsWindowLimit = ((raw["globalReelsWindowLimit"] as? Number)?.toInt()
                    ?: 0).coerceAtLeast(0),
                globalReelsWindowPackages = stringSet(raw["globalReelsWindowPackages"]),
                globalReelsWindowLocked = raw["globalReelsWindowLocked"] as? Boolean ?: false,
                wellbeingWarningsEnabled =
                    raw["wellbeingWarningsEnabled"] as? Boolean ?: true,
                screenTimeGoalMinutes = ((raw["screenTimeGoalMinutes"] as? Number)?.toInt()
                    ?: 240).coerceIn(30, 1440),
                screenTimeWarningPercentages = percentageSet(
                    raw["screenTimeWarningPercentages"],
                    setOf(50, 75, 90, 100)
                ),
                screenTimeRepeatMinutes = ((raw["screenTimeRepeatMinutes"] as? Number)?.toInt()
                    ?: 30).coerceIn(15, 240),
                detailedWarningNotifications =
                    raw["detailedWarningNotifications"] as? Boolean ?: true,
                rules = rules,
                profiles = profiles
            )
        }

        fun fromJson(raw: String?): PhoneControlPolicy {
            if (raw.isNullOrBlank()) return PhoneControlPolicy()
            return runCatching {
                val json = JSONObject(raw)
                fun jsonStringSet(key: String): Set<String> {
                    val array = json.optJSONArray(key) ?: JSONArray()
                    return buildSet {
                        for (index in 0 until array.length()) {
                            val value = array.optString(index)
                            if (value.isNotBlank()) add(value)
                        }
                    }
                }
                fun jsonDaySet(key: String): Set<Int> {
                    val array = json.optJSONArray(key) ?: JSONArray()
                    return buildSet {
                        for (index in 0 until array.length()) {
                            val value = array.optInt(index, -1)
                            if (value in 1..7) add(value)
                        }
                    }.ifEmpty { setOf(1, 2, 3, 4, 5, 6, 7) }
                }
                fun jsonPercentageSet(key: String, fallback: Set<Int>): Set<Int> {
                    val array = json.optJSONArray(key) ?: JSONArray()
                    return buildSet {
                        for (index in 0 until array.length()) {
                            val value = array.optInt(index, -1)
                            if (value in 10..100) add(value)
                        }
                    }.ifEmpty { fallback }
                }
                val rulesArray = json.optJSONArray("rules") ?: JSONArray()
                val rules = buildList {
                    for (index in 0 until rulesArray.length()) {
                        val value = rulesArray.optJSONObject(index) ?: continue
                        val rule = AppControlRule.fromJson(value)
                        if (rule.packageName.isNotBlank()) add(rule)
                    }
                }
                val profilesArray = json.optJSONArray("profiles") ?: JSONArray()
                val profiles = buildList {
                    for (index in 0 until profilesArray.length()) {
                        val value = profilesArray.optJSONObject(index) ?: continue
                        val profile = ScheduleProfile.fromJson(value)
                        if (profile.id.isNotBlank()) add(profile)
                    }
                }
                PhoneControlPolicy(
                    masterEnabled = json.optBoolean("masterEnabled", false),
                    scheduleEnabled = json.optBoolean("scheduleEnabled", true),
                    scheduleProfilesEnabled = json.optBoolean("scheduleProfilesEnabled", true),
                    appLimitsEnabled = json.optBoolean("appLimitsEnabled", true),
                    reelsBlockerEnabled = json.optBoolean("reelsBlockerEnabled", true),
                    scrollLimitEnabled = json.optBoolean("scrollLimitEnabled", true),
                    notificationBlockerEnabled =
                        json.optBoolean("notificationBlockerEnabled", false),
                    notificationPackages = jsonStringSet("notificationPackages"),
                    notificationScheduleEnabled =
                        json.optBoolean("notificationScheduleEnabled", false),
                    notificationWeekdays = jsonDaySet("notificationWeekdays"),
                    notificationStartMinute = json.optInt("notificationStartMinute", 1320)
                        .coerceIn(0, 1439),
                    notificationEndMinute = json.optInt("notificationEndMinute", 420)
                        .coerceIn(0, 1439),
                    notificationHistoryLimit = json.optInt("notificationHistoryLimit", 100)
                        .coerceIn(10, 500),
                    studyModeEnabled = json.optBoolean("studyModeEnabled", true),
                    studyStrictAllowList = json.optBoolean("studyStrictAllowList", false),
                    studyAllowedPackages = jsonStringSet("studyAllowedPackages"),
                    studyBlockedPackages = jsonStringSet("studyBlockedPackages"),
                    studySilenceNotifications =
                        json.optBoolean("studySilenceNotifications", true),
                    studyDefaultMinutes = json.optInt("studyDefaultMinutes", 50)
                        .coerceIn(10, 240),
                    studyDailyGoalMinutes = json.optInt("studyDailyGoalMinutes", 120)
                        .coerceIn(10, 720),
                    studyScheduleEnabled = json.optBoolean("studyScheduleEnabled", false),
                    studyWeekdays = jsonDaySet("studyWeekdays"),
                    studyStartMinute = json.optInt("studyStartMinute", 1140)
                        .coerceIn(0, 1439),
                    studyEndMinute = json.optInt("studyEndMinute", 1380)
                        .coerceIn(0, 1439),
                    focusUsesStudyRules = json.optBoolean("focusUsesStudyRules", true),
                    globalReelsWindowEnabled =
                        json.optBoolean("globalReelsWindowEnabled", false),
                    globalReelsWindowStartMillis = json.optLong(
                        "globalReelsWindowStartMillis",
                        0L
                    ).coerceAtLeast(0L),
                    globalReelsWindowEndMillis = json.optLong(
                        "globalReelsWindowEndMillis",
                        0L
                    ).coerceAtLeast(0L),
                    globalReelsWindowLimit = json.optInt("globalReelsWindowLimit", 0)
                        .coerceAtLeast(0),
                    globalReelsWindowPackages = jsonStringSet("globalReelsWindowPackages"),
                    globalReelsWindowLocked = json.optBoolean("globalReelsWindowLocked", false),
                    wellbeingWarningsEnabled =
                        json.optBoolean("wellbeingWarningsEnabled", true),
                    screenTimeGoalMinutes = json.optInt("screenTimeGoalMinutes", 240)
                        .coerceIn(30, 1440),
                    screenTimeWarningPercentages = jsonPercentageSet(
                        "screenTimeWarningPercentages",
                        setOf(50, 75, 90, 100)
                    ),
                    screenTimeRepeatMinutes = json.optInt("screenTimeRepeatMinutes", 30)
                        .coerceIn(15, 240),
                    detailedWarningNotifications =
                        json.optBoolean("detailedWarningNotifications", true),
                    rules = rules,
                    profiles = profiles
                )
            }.getOrDefault(PhoneControlPolicy())
        }
    }
}


data class PhoneControlDecision(
    val reason: String,
    val detail: String
)

private fun androidWeekdayToMondayFirst(day: Int): Int = when (day) {
    Calendar.MONDAY -> 1
    Calendar.TUESDAY -> 2
    Calendar.WEDNESDAY -> 3
    Calendar.THURSDAY -> 4
    Calendar.FRIDAY -> 5
    Calendar.SATURDAY -> 6
    Calendar.SUNDAY -> 7
    else -> 1
}
