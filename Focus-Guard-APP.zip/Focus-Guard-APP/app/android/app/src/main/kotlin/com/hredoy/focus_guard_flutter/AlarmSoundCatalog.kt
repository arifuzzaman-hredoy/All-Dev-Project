package com.hredoy.focus_guard_flutter

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri

object AlarmSoundCatalog {
    const val SMART = "smart"
    const val SYSTEM = "system"
    const val CUSTOM = "custom"

    fun candidateUris(context: Context, task: NativeTask): List<Uri> = buildList<Uri> {
        if ((task.alarmSoundId == SYSTEM || task.alarmSoundId == CUSTOM) &&
            task.alarmSoundUri.isNotBlank()
        ) {
            runCatching { Uri.parse(task.alarmSoundUri) }.getOrNull()?.let(::add)
        }

        val resolvedId = if (task.alarmSoundId == SMART) {
            smartPreset(task.category, task.title)
        } else {
            task.alarmSoundId
        }
        resourceId(context, resolvedId)?.let { add(resourceUri(context, it)) }

        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let(::add)
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)?.let(::add)
    }.distinctBy { uri: Uri -> uri.toString() }

    fun smartPreset(category: String, title: String): String {
        val text = "$category $title".lowercase()
        return when {
            hasAny(
                text,
                "exam", "test", "deadline", "urgent", "important",
                "পরীক্ষা", "জরুরি", "ডেডলাইন"
            ) -> "exam_alert"
            hasAny(
                text,
                "code", "coding", "computer", "program", "software", "ict",
                "কোড", "কম্পিউটার", "প্রোগ্রাম"
            ) -> "coding_digital"
            hasAny(
                text,
                "math",
                "physics",
                "chemistry",
                "electronics",
                "science",
                "circuit",
                "গণিত",
                "পদার্থ",
                "রসায়ন",
                "ইলেকট্রনিক্স",
                "বিজ্ঞান"
            ) -> "science_signal"
            hasAny(
                text,
                "read", "english", "bangla", "book", "language",
                "পড়া", "পড়া", "বাংলা", "ইংরেজি", "বই"
            ) -> "reading_chime"
            hasAny(
                text,
                "study", "revision", "class", "chapter", "lesson",
                "পড়াশোনা", "রিভিশন", "ক্লাস", "অধ্যায়"
            ) -> "study_bell"
            hasAny(
                text,
                "meeting", "call", "appointment", "office",
                "মিটিং", "কল", "অফিস"
            ) -> "meeting_chime"
            hasAny(
                text,
                "gym", "workout", "exercise", "run", "walk",
                "জিম", "ব্যায়াম", "দৌড়", "হাঁটা"
            ) -> "workout_energy"
            hasAny(
                text,
                "morning", "wake", "breakfast", "সকাল", "উঠা", "নাস্তা"
            ) -> "morning_sunrise"
            hasAny(
                text,
                "break", "rest", "calm", "sleep", "self care",
                "বিরতি", "বিশ্রাম", "শান্ত", "ঘুম"
            ) -> "calm_waves"
            else -> "focus_pulse"
        }
    }

    fun displayLabel(task: NativeTask): String {
        if (task.alarmSoundId == SMART) {
            return "Smart • ${labelForId(smartPreset(task.category, task.title))}"
        }
        return task.alarmSoundLabel.ifBlank { labelForId(task.alarmSoundId) }
    }

    fun labelForId(id: String): String = when (id) {
        SMART -> "Smart by task type"
        SYSTEM -> "Phone alarm tone"
        CUSTOM -> "My audio file"
        "focus_pulse" -> "Focus Pulse"
        "deep_work" -> "Deep Work"
        "study_bell" -> "Study Bell"
        "reading_chime" -> "Reading Chime"
        "exam_alert" -> "Exam Alert"
        "deadline_beacon" -> "Deadline Beacon"
        "coding_digital" -> "Coding Digital"
        "science_signal" -> "Science Signal"
        "meeting_chime" -> "Meeting Chime"
        "morning_sunrise" -> "Morning Sunrise"
        "workout_energy" -> "Workout Energy"
        "gentle_reminder" -> "Gentle Reminder"
        "calm_waves" -> "Calm Waves"
        "bright_bell" -> "Bright Bell"
        "classic_alarm" -> "Classic Alarm"
        "urgent_siren" -> "Urgent Siren"
        else -> generatedToneLabel(id) ?: "Alarm sound"
    }

    fun resourceId(context: Context, id: String): Int? {
        val legacy = when (id) {
            "focus_pulse" -> R.raw.hf_focus_pulse
            "deep_work" -> R.raw.hf_deep_work
            "study_bell" -> R.raw.hf_study_bell
            "reading_chime" -> R.raw.hf_reading_chime
            "exam_alert" -> R.raw.hf_exam_alert
            "deadline_beacon" -> R.raw.hf_deadline_beacon
            "coding_digital" -> R.raw.hf_coding_digital
            "science_signal" -> R.raw.hf_science_signal
            "meeting_chime" -> R.raw.hf_meeting_chime
            "morning_sunrise" -> R.raw.hf_morning_sunrise
            "workout_energy" -> R.raw.hf_workout_energy
            "gentle_reminder" -> R.raw.hf_gentle_reminder
            "calm_waves" -> R.raw.hf_calm_waves
            "bright_bell" -> R.raw.hf_bright_bell
            "classic_alarm" -> R.raw.hf_classic_alarm
            "urgent_siren" -> R.raw.hf_urgent_siren
            else -> null
        }
        if (legacy != null) return legacy
        if (!id.matches(Regex("tone_\\d{3}"))) return null
        val value = context.resources.getIdentifier(
            "hf_$id",
            "raw",
            context.packageName
        )
        return value.takeIf { it != 0 }
    }

    private fun generatedToneLabel(id: String): String? {
        val number = id.removePrefix("tone_").toIntOrNull() ?: return null
        if (number !in 17..216) return null
        val families = listOf(
            "Forest Bell",
            "Rain Pulse",
            "River Chime",
            "Sunrise Tone",
            "Digital Beacon",
            "Study Spark",
            "Deep Focus",
            "Crystal Note",
            "Mountain Echo",
            "Night Lantern"
        )
        val index = number - 17
        val family = families[index % families.size]
        val rhythm = (index / families.size) % 5 + 1
        val variation = index / 50 + 1
        return "$family ${rhythm.toString().padStart(2, '0')} · V$variation"
    }

    private fun resourceUri(context: Context, resourceId: Int): Uri = Uri.parse(
        "android.resource://${context.packageName}/$resourceId"
    )

    private fun hasAny(text: String, vararg values: String): Boolean =
        values.any { value -> text.contains(value) }
}

object AlarmSoundPreview {
    private var player: MediaPlayer? = null
    private var generation = 0

    @Synchronized
    fun play(
        context: Context,
        soundId: String,
        soundUri: String,
        category: String,
        title: String
    ) {
        stop()
        generation += 1
        val currentGeneration = generation
        val task = NativeTask(
            id = "preview",
            triggerAtMillis = System.currentTimeMillis(),
            title = title.ifBlank { "Task reminder" },
            category = category.ifBlank { "General" },
            notes = "",
            durationMinutes = 1,
            alarmEnabled = true,
            snoozeMinutes = 5,
            alarmSoundId = soundId,
            alarmSoundLabel = "Preview",
            alarmSoundUri = soundUri,
            autoFocus = false
        )
        playCandidate(
            context.applicationContext,
            AlarmSoundCatalog.candidateUris(context, task),
            0,
            currentGeneration
        )
    }

    @Synchronized
    fun stop() {
        generation += 1
        runCatching { player?.stop() }
        runCatching { player?.reset() }
        runCatching { player?.release() }
        player = null
    }

    private fun playCandidate(
        context: Context,
        candidates: List<Uri>,
        index: Int,
        expectedGeneration: Int
    ) {
        if (expectedGeneration != generation || index >= candidates.size) return
        val candidate = MediaPlayer()
        try {
            candidate.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            candidate.setDataSource(context, candidates[index])
            candidate.isLooping = false
            candidate.setOnPreparedListener(MediaPlayer.OnPreparedListener { prepared: MediaPlayer ->
                if (expectedGeneration == generation && player === prepared) {
                    prepared.start()
                } else {
                    runCatching { prepared.release() }
                }
            })
            candidate.setOnCompletionListener(MediaPlayer.OnCompletionListener { completed: MediaPlayer ->
                if (player === completed) player = null
                runCatching { completed.release() }
            })
            candidate.setOnErrorListener(MediaPlayer.OnErrorListener { failed: MediaPlayer, _: Int, _: Int ->
                if (player === failed) player = null
                runCatching { failed.release() }
                playCandidate(context, candidates, index + 1, expectedGeneration)
                true
            })
        } catch (_: Throwable) {
            runCatching { candidate.release() }
            playCandidate(context, candidates, index + 1, expectedGeneration)
            return
        }
        player = candidate
        runCatching { candidate.prepareAsync() }
            .onFailure {
                if (player === candidate) player = null
                runCatching { candidate.release() }
                playCandidate(context, candidates, index + 1, expectedGeneration)
            }
    }
}
