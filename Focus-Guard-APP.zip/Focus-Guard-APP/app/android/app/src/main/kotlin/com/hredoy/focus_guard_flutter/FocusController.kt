package com.hredoy.focus_guard_flutter

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object FocusController {
    private const val REQUEST_CODE = 9301

    fun start(context: Context, minutes: Int, label: String): Long {
        require(minutes in 1..720) { "Focus duration must be between 1 and 720 minutes" }
        val until = System.currentTimeMillis() + minutes * 60_000L
        FocusStore(context).setFocus(until, label)
        DndController.enable(context)

        val intent = Intent(context, FocusEndReceiver::class.java).putExtra("label", label)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val manager = context.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, until, pendingIntent)
        } else {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, until, pendingIntent)
        }
        return until
    }

    fun end(context: Context, notify: Boolean = false) {
        val store = FocusStore(context)
        val label = store.focusLabel()
        store.clearFocus()
        DndController.restore(context)

        val manager = context.getSystemService(AlarmManager::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, FocusEndReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.cancel(pendingIntent)
        if (notify) Notifications.showFocusFinished(context, label)
    }
}
