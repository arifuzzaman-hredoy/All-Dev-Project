package com.hredoy.focus_guard_flutter

import android.content.Context
import android.net.VpnService
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProtectionStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun policy(): ProtectionPolicy = ProtectionPolicy.fromJson(
        prefs.getString(KEY_POLICY, null)
    )

    @Synchronized
    fun savePolicy(candidate: ProtectionPolicy, allowActiveReduction: Boolean = false) {
        ensureToday()
        val now = System.currentTimeMillis()
        val current = policy()
        val emergencyUnlocked = isEmergencyUnlocked(now)
        val safe = if (allowActiveReduction || emergencyUnlocked) {
            candidate
        } else {
            val primeActive = current.primeModeUntilMillis > now
            val keepOutActive = current.keepMeOutUntilMillis > now
            candidate.copy(
                primeModeUntilMillis = if (primeActive) {
                    maxOf(current.primeModeUntilMillis, candidate.primeModeUntilMillis)
                } else {
                    candidate.primeModeUntilMillis
                },
                primeBlockedPackages = if (primeActive) {
                    current.primeBlockedPackages
                } else {
                    candidate.primeBlockedPackages
                },
                primeAllowedPackages = if (primeActive) {
                    current.primeAllowedPackages
                } else {
                    candidate.primeAllowedPackages
                },
                primeSilenceNotifications = if (primeActive) {
                    current.primeSilenceNotifications
                } else {
                    candidate.primeSilenceNotifications
                },
                keepMeOutUntilMillis = if (keepOutActive) {
                    maxOf(current.keepMeOutUntilMillis, candidate.keepMeOutUntilMillis)
                } else {
                    candidate.keepMeOutUntilMillis
                },
                keepMeOutPackages = if (keepOutActive) {
                    current.keepMeOutPackages
                } else {
                    candidate.keepMeOutPackages
                }
            )
        }
        prefs.edit().putString(KEY_POLICY, safe.toJson().toString()).apply()
    }


    @Synchronized
    fun clearActiveLocksForSafety() {
        val current = policy()
        val safe = current.copy(
            webProtectionEnabled = false,
            vpnDnsEnabled = false,
            browserGuardEnabled = false,
            failClosed = false,
            primeModeUntilMillis = 0L,
            primeBlockedPackages = emptySet(),
            primeAllowedPackages = emptySet(),
            keepMeOutUntilMillis = 0L,
            keepMeOutPackages = emptySet(),
            tamperProtectionEnabled = false,
            uninstallGuardEnabled = false
        )
        prefs.edit()
            .putString(KEY_POLICY, safe.toJson().toString())
            .putLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L)
            .apply()
    }

    @Synchronized
    fun activatePrimeMode(
        durationMinutes: Int,
        blockedPackages: Set<String>,
        allowedPackages: Set<String>,
        silenceNotifications: Boolean
    ): Map<String, Any> {
        ensureToday()
        val current = policy()
        val now = System.currentTimeMillis()
        if (current.isPrimeActive(now) && !isEmergencyUnlocked(now)) {
            return mapOf(
                "granted" to false,
                "activeUntilMillis" to current.primeModeUntilMillis,
                "unlocksUsedToday" to emergencyUnlocksUsedToday(),
                "message" to "Prime Mode is already active and cannot be replaced"
            )
        }
        val safeMinutes = durationMinutes.coerceIn(5, 24 * 60)
        val until = now + safeMinutes * 60_000L
        val updated = current.copy(
            primeModeUntilMillis = until,
            primeBlockedPackages = PhoneControlSafety.sanitizePackages(blockedPackages),
            primeAllowedPackages = allowedPackages
                .map(String::trim)
                .filter(String::isNotBlank)
                .toSet(),
            primeSilenceNotifications = silenceNotifications
        )
        savePolicy(updated, allowActiveReduction = true)
        recordHistory(
            kind = "prime",
            target = "Prime Mode",
            reason = "Locked for $safeMinutes minutes",
            packageName = ""
        )
        return mapOf(
            "granted" to true,
            "activeUntilMillis" to until,
            "unlocksUsedToday" to emergencyUnlocksUsedToday(),
            "message" to "Prime Mode is active"
        )
    }

    @Synchronized
    fun activateKeepMeOut(
        durationMinutes: Int,
        packages: Set<String>
    ): Map<String, Any> {
        ensureToday()
        val current = policy()
        val now = System.currentTimeMillis()
        if (current.isKeepMeOutActive(now) && !isEmergencyUnlocked(now)) {
            return mapOf(
                "granted" to false,
                "activeUntilMillis" to current.keepMeOutUntilMillis,
                "unlocksUsedToday" to emergencyUnlocksUsedToday(),
                "message" to "Keep Me Out is already active and cannot be replaced"
            )
        }
        val cleanPackages = PhoneControlSafety.sanitizePackages(packages)
        if (cleanPackages.isEmpty()) {
            return mapOf(
                "granted" to false,
                "activeUntilMillis" to 0L,
                "unlocksUsedToday" to emergencyUnlocksUsedToday(),
                "message" to "Choose at least one app"
            )
        }
        val safeMinutes = durationMinutes.coerceIn(5, 24 * 60)
        val until = now + safeMinutes * 60_000L
        savePolicy(
            current.copy(
                keepMeOutUntilMillis = until,
                keepMeOutPackages = cleanPackages
            ),
            allowActiveReduction = true
        )
        recordHistory(
            kind = "keep_out",
            target = "${cleanPackages.size} apps",
            reason = "Keep Me Out for $safeMinutes minutes",
            packageName = ""
        )
        return mapOf(
            "granted" to true,
            "activeUntilMillis" to until,
            "unlocksUsedToday" to emergencyUnlocksUsedToday(),
            "message" to "Keep Me Out is active"
        )
    }

    @Synchronized
    fun requestEmergencyUnlock(requestedMinutes: Int): Map<String, Any> {
        ensureToday()
        val policy = policy()
        val maxUses = policy.maxEmergencyUnlocksPerDay.coerceIn(0, 10)
        val used = emergencyUnlocksUsedToday()
        if (maxUses == 0 || used >= maxUses) {
            return mapOf(
                "granted" to false,
                "activeUntilMillis" to 0L,
                "unlocksUsedToday" to used,
                "message" to "Daily emergency unlock limit reached"
            )
        }
        val minutes = requestedMinutes
            .coerceAtLeast(1)
            .coerceAtMost(policy.emergencyUnlockMinutes.coerceIn(1, 30))
        val until = System.currentTimeMillis() + minutes * 60_000L
        prefs.edit()
            .putLong(KEY_EMERGENCY_UNLOCK_UNTIL, until)
            .putInt(KEY_EMERGENCY_UNLOCK_COUNT, used + 1)
            .apply()
        recordHistory(
            kind = "emergency_unlock",
            target = "Hardcore protection",
            reason = "Temporary unlock for $minutes minutes",
            packageName = ""
        )
        return mapOf(
            "granted" to true,
            "activeUntilMillis" to until,
            "unlocksUsedToday" to used + 1,
            "message" to "Emergency unlock granted"
        )
    }

    @Synchronized
    fun cancelEmergencyUnlock() {
        prefs.edit().putLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L).apply()
    }

    fun isEmergencyUnlocked(now: Long = System.currentTimeMillis()): Boolean =
        prefs.getLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L) > now

    fun emergencyUnlocksUsedToday(): Int {
        ensureToday()
        return prefs.getInt(KEY_EMERGENCY_UNLOCK_COUNT, 0)
    }

    @Synchronized
    fun recordWebBlocked(domain: String, reason: String, packageName: String = "") {
        ensureToday()
        prefs.edit()
            .putInt(KEY_WEB_BLOCKED_TODAY, prefs.getInt(KEY_WEB_BLOCKED_TODAY, 0) + 1)
            .apply()
        recordHistory(
            kind = "web",
            target = ProtectionRules.normalizeDomain(domain),
            reason = reason,
            packageName = packageName
        )
    }

    @Synchronized
    fun recordTamperBlocked(packageName: String, reason: String) {
        ensureToday()
        prefs.edit()
            .putInt(
                KEY_TAMPER_BLOCKED_TODAY,
                prefs.getInt(KEY_TAMPER_BLOCKED_TODAY, 0) + 1
            )
            .apply()
        recordHistory(
            kind = "tamper",
            target = packageName,
            reason = reason,
            packageName = packageName
        )
    }

    @Synchronized
    fun recordServiceMessage(message: String) {
        prefs.edit().putString(KEY_LAST_SERVICE_MESSAGE, message.take(240)).apply()
    }

    @Synchronized
    fun markBootRestore() {
        prefs.edit().putLong(KEY_LAST_BOOT_RESTORE, System.currentTimeMillis()).apply()
    }

    @Synchronized
    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    fun shouldBlockNotification(packageName: String, now: Long = System.currentTimeMillis()): Boolean {
        val policy = policy()
        if (isEmergencyUnlocked(now) || PhoneControlSafety.isProtectedPackage(packageName)) {
            return false
        }
        if (policy.isPrimeActive(now) && policy.primeSilenceNotifications) return true
        if (policy.isKeepMeOutActive(now) && packageName in policy.keepMeOutPackages) {
            return true
        }
        return false
    }

    fun shouldRunVpn(): Boolean {
        val policy = policy()
        return policy.webProtectionEnabled && policy.vpnDnsEnabled
    }

    fun domainBlockReason(domain: String): String? {
        val policy = policy()
        if (!policy.isWebWindowActive()) return null
        return ProtectionRules.domainBlockReason(domain, policy)
    }

    fun snapshot(context: Context): Map<String, Any> {
        ensureToday()
        val privateDnsMode = runCatching {
            Settings.Global.getString(context.contentResolver, "private_dns_mode")
                .orEmpty()
        }.getOrDefault("")
        return mapOf(
            "vpnPrepared" to (VpnService.prepare(context) == null),
            "vpnRunning" to ProtectionVpnService.isRunning,
            "privateDnsActive" to (privateDnsMode.isNotBlank() && privateDnsMode != "off"),
            "webBlockedToday" to prefs.getInt(KEY_WEB_BLOCKED_TODAY, 0),
            "tamperBlockedToday" to prefs.getInt(KEY_TAMPER_BLOCKED_TODAY, 0),
            "emergencyUnlocksUsedToday" to emergencyUnlocksUsedToday(),
            "emergencyUnlockedUntilMillis" to
                prefs.getLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L),
            "lastBootRestoreAtMillis" to prefs.getLong(KEY_LAST_BOOT_RESTORE, 0L),
            "lastServiceMessage" to
                prefs.getString(KEY_LAST_SERVICE_MESSAGE, "").orEmpty(),
            "history" to readHistory()
        )
    }

    fun diagnostics(): Map<String, Any> {
        val samplePolicy = ProtectionPolicy(
            webProtectionEnabled = true,
            adultContentEnabled = true,
            safeSearchEnabled = true,
            blockedDomains = setOf("example-blocked.test"),
            allowedDomains = setOf("allowed.example-blocked.test")
        )
        val checks = linkedMapOf<String, Boolean>()
        checks["customDomain"] = ProtectionRules.domainBlockReason(
            "sub.example-blocked.test",
            samplePolicy
        ) == "Custom domain block"
        checks["allowListWins"] = ProtectionRules.domainBlockReason(
            "allowed.example-blocked.test",
            samplePolicy
        ) == null
        checks["adultClassification"] = ProtectionRules.isLocallyClassifiedAdult(
            "nudity.testcategory.com"
        ) || ProtectionRules.isLocallyClassifiedAdult("porn.example")
        checks["safeSearchKeyword"] = ProtectionRules.safeSearchBlockReason(
            "https://www.google.com/search?q=porn",
            samplePolicy
        ) != null
        checks["ipv4Validation"] =
            ProtectionRules.isValidIpv4("1.1.1.3") &&
                !ProtectionRules.isValidIpv4("999.1.1.1")
        val policyRoundTrip = ProtectionPolicy.fromJson(samplePolicy.toJson().toString())
        checks["policyRoundTrip"] =
            policyRoundTrip.blockedDomains == samplePolicy.blockedDomains &&
                policyRoundTrip.allowedDomains == samplePolicy.allowedDomains
        return mapOf(
            "passed" to checks.values.all { it },
            "checks" to checks,
            "message" to if (checks.values.all { it }) {
                "Native protection diagnostics passed"
            } else {
                "One or more protection diagnostics failed"
            }
        )
    }

    @Synchronized
    private fun recordHistory(
        kind: String,
        target: String,
        reason: String,
        packageName: String
    ) {
        val values = readHistory().toMutableList()
        values.add(
            0,
            mapOf(
                "timestampMillis" to System.currentTimeMillis(),
                "kind" to kind,
                "target" to target.take(180),
                "reason" to reason.take(240),
                "packageName" to packageName.take(180)
            )
        )
        val limit = policy().historyLimit.coerceIn(20, 1000)
        writeHistory(values.take(limit))
    }

    private fun readHistory(): List<Map<String, Any>> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val value = array.optJSONObject(index) ?: continue
                    add(
                        mapOf(
                            "timestampMillis" to value.optLong("timestampMillis", 0L),
                            "kind" to value.optString("kind", "protection"),
                            "target" to value.optString("target", ""),
                            "reason" to value.optString("reason", ""),
                            "packageName" to value.optString("packageName", "")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun writeHistory(values: List<Map<String, Any>>) {
        val array = JSONArray()
        values.forEach { item ->
            array.put(JSONObject().apply {
                put("timestampMillis", item["timestampMillis"])
                put("kind", item["kind"])
                put("target", item["target"])
                put("reason", item["reason"])
                put("packageName", item["packageName"])
            })
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    @Synchronized
    private fun ensureToday() {
        val today = trackingDate()
        if (prefs.getString(KEY_DATE, null) == today) return
        prefs.edit()
            .putString(KEY_DATE, today)
            .putInt(KEY_WEB_BLOCKED_TODAY, 0)
            .putInt(KEY_TAMPER_BLOCKED_TODAY, 0)
            .putInt(KEY_EMERGENCY_UNLOCK_COUNT, 0)
            .putLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L)
            .apply()
    }

    private fun trackingDate(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    companion object {
        private const val PREFS_NAME = "hredoy_flow_protection"
        private const val KEY_POLICY = "policy_json_v1"
        private const val KEY_DATE = "tracking_date"
        private const val KEY_WEB_BLOCKED_TODAY = "web_blocked_today"
        private const val KEY_TAMPER_BLOCKED_TODAY = "tamper_blocked_today"
        private const val KEY_EMERGENCY_UNLOCK_COUNT = "emergency_unlock_count"
        private const val KEY_EMERGENCY_UNLOCK_UNTIL = "emergency_unlock_until"
        private const val KEY_HISTORY = "history_json"
        private const val KEY_LAST_BOOT_RESTORE = "last_boot_restore"
        private const val KEY_LAST_SERVICE_MESSAGE = "last_service_message"
    }
}
