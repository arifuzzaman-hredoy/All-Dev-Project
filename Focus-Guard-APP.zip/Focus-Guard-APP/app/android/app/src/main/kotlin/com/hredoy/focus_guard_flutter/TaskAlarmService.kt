package com.hredoy.focus_guard_flutter

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class TaskAlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var activeTask: NativeTask? = null
    private var alarmWakeLock: PowerManager.WakeLock? = null
    private var soundGeneration: Int = 0

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensure(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAlarm()
            ACTION_START -> startAlarm(NativeTask.fromIntent(intent))
        }
        return START_REDELIVER_INTENT
    }

    private fun startAlarm(task: NativeTask) {
        AlarmSoundPreview.stop()
        acquireAlarmWakeLock()
        activeTask = task
        vibrator?.cancel()
        val notification = buildAlarmNotification(task)
        startForeground(NOTIFICATION_ID, notification)
        launchAlarmUi(task)
        startSound(task)
        startVibration()
    }

    private fun launchAlarmUi(task: NativeTask) {
        // An alarm is user-requested, time-sensitive work. Always try the
        // dedicated full-screen activity, even while another app is open.
        // Android may still reject a background launch; the CATEGORY_ALARM
        // full-screen notification below remains the platform fallback.
        runCatching {
            startActivity(
                task.toIntent(Intent(this, TaskAlarmActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION
                })
            )
        }
    }

    private fun buildAlarmNotification(task: NativeTask): android.app.Notification {
        val fullScreenIntent = PendingIntent.getActivity(
            this,
            task.id.hashCode(),
            task.toIntent(Intent(this, TaskAlarmActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getBroadcast(
            this,
            task.id.hashCode() + 41,
            task.toIntent(Intent(this, AlarmActionReceiver::class.java).apply {
                action = AlarmActionReceiver.ACTION_STOP
            }),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snoozeIntent = PendingIntent.getBroadcast(
            this,
            task.id.hashCode() + 42,
            task.toIntent(Intent(this, AlarmActionReceiver::class.java).apply {
                action = AlarmActionReceiver.ACTION_SNOOZE
            }),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NotificationChannels.TASK_ALARM)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(task.title)
            .setContentText("${task.category} • Task time")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    task.notes.ifBlank {
                        "Start now and focus for ${task.durationMinutes} minutes."
                    }
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenIntent, true)
            .setContentIntent(fullScreenIntent)
            .addAction(0, "Snooze ${task.snoozeMinutes} min", snoozeIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    private fun startSound(task: NativeTask) {
        stopSound()
        soundGeneration += 1
        val generation = soundGeneration
        playSoundCandidate(
            AlarmSoundCatalog.candidateUris(applicationContext, task),
            index = 0,
            generation = generation
        )
    }

    private fun playSoundCandidate(
        candidates: List<android.net.Uri>,
        index: Int,
        generation: Int
    ) {
        if (generation != soundGeneration || index >= candidates.size) return
        val candidate = MediaPlayer()
        try {
            candidate.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            candidate.setDataSource(applicationContext, candidates[index])
            candidate.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            candidate.isLooping = true
            candidate.setOnPreparedListener(MediaPlayer.OnPreparedListener { prepared: MediaPlayer ->
                if (generation == soundGeneration && player === prepared) {
                    prepared.start()
                } else {
                    runCatching { prepared.release() }
                }
            })
            candidate.setOnErrorListener(MediaPlayer.OnErrorListener { failed: MediaPlayer, _: Int, _: Int ->
                if (player === failed) player = null
                runCatching { failed.release() }
                playSoundCandidate(candidates, index + 1, generation)
                true
            })
        } catch (_: Throwable) {
            runCatching { candidate.release() }
            playSoundCandidate(candidates, index + 1, generation)
            return
        }
        player = candidate
        runCatching { candidate.prepareAsync() }
            .onFailure {
                if (player === candidate) player = null
                runCatching { candidate.release() }
                playSoundCandidate(candidates, index + 1, generation)
            }
    }

    private fun startVibration() {
        vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 700, 350, 700, 350, 1000)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun acquireAlarmWakeLock() {
        val current = alarmWakeLock
        if (current?.isHeld == true) return
        alarmWakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "HredoyFlow:active-task-alarm"
            )
            .apply {
                setReferenceCounted(false)
                acquire(MAX_WAKE_LOCK_MILLIS)
            }
    }

    private fun releaseAlarmWakeLock() {
        alarmWakeLock?.let { lock ->
            if (lock.isHeld) runCatching { lock.release() }
        }
        alarmWakeLock = null
    }

    private fun stopSound() {
        soundGeneration += 1
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }

    private fun stopAlarm() {
        stopSound()
        vibrator?.cancel()
        vibrator = null
        activeTask = null
        releaseAlarmWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        NotificationManagerCompat.from(this).cancel(NOTIFICATION_ID)
        stopSelf()
    }

    override fun onDestroy() {
        stopSound()
        vibrator?.cancel()
        vibrator = null
        activeTask = null
        releaseAlarmWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        NotificationManagerCompat.from(this).cancel(NOTIFICATION_ID)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.hredoy.focus_guard_flutter.action.START_TASK_ALARM"
        const val ACTION_STOP = "com.hredoy.focus_guard_flutter.action.STOP_TASK_ALARM"
        private const val NOTIFICATION_ID = 73001
        private const val MAX_WAKE_LOCK_MILLIS = 15 * 60 * 1000L

        fun stop(context: Context) {
            context.stopService(Intent(context, TaskAlarmService::class.java))
        }
    }
}
