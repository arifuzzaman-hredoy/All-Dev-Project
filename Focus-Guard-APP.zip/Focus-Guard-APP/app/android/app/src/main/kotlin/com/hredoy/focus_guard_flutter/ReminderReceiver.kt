package com.hredoy.focus_guard_flutter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        val wakeLock = appContext
            .getSystemService(PowerManager::class.java)
            .newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "HredoyFlow:alarm-delivery"
            )
            .apply {
                setReferenceCounted(false)
                acquire(20_000L)
            }

        try {
            val task = NativeTask.fromIntent(intent)
            val store = FocusStore(appContext)
            if (store.completedTasks().contains(task.id)) return

            if (task.alarmEnabled) {
                ContextCompat.startForegroundService(
                    appContext,
                    task.toIntent(Intent(appContext, TaskAlarmService::class.java).apply {
                        action = TaskAlarmService.ACTION_START
                    })
                )
            } else {
                Notifications.showRoutine(appContext, task)
            }

            if (task.autoFocus &&
                store.autoFocus() &&
                task.durationMinutes > 0 &&
                !store.isFocusActive()
            ) {
                runCatching {
                    FocusController.start(appContext, task.durationMinutes, task.title)
                }
            }
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
            pendingResult.finish()
        }
    }
}
