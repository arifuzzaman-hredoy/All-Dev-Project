package com.hredoy.focus_guard_flutter

import android.content.pm.ApplicationInfo

/**
 * Classifies launchable apps for a safe, recommendation-only setup.
 * The classifier never enables blocking by itself.
 */
object AppSafetyClassifier {
    data class Profile(
        val category: String,
        val recommendation: String,
        val protected: Boolean,
        val reason: String,
        val suggestedDailyMinutes: Int,
        val suggestedReelsGuard: Boolean
    ) {
        fun toMap(): Map<String, Any> = mapOf(
            "category" to category,
            "recommendation" to recommendation,
            "protected" to protected,
            "reason" to reason,
            "suggestedDailyMinutes" to suggestedDailyMinutes,
            "suggestedReelsGuard" to suggestedReelsGuard
        )
    }

    private val socialTokens = setOf(
        "facebook", "instagram", "messenger", "tiktok", "twitter", "x.android",
        "snapchat", "reddit", "pinterest", "discord", "imo", "telegram"
    )
    private val videoTokens = setOf(
        "youtube", "netflix", "primevideo", "hotstar", "twitch", "video", "shorts"
    )
    private val gameTokens = setOf(
        "game", "gaming", "pubg", "freefire", "roblox", "minecraft", "clash"
    )
    private val educationTokens = setOf(
        "classroom", "academy", "course", "learning", "learn", "dictionary",
        "books", "reader", "wikipedia", "quiz", "exam", "school", "college",
        "university", "khan", "udemy", "coursera", "duolingo", "photomath",
        "byju", "brainly", "education", "student"
    )
    private val productivityTokens = setOf(
        "docs", "drive", "office", "notion", "todo", "calendar", "notes",
        "keep", "workspace", "scanner", "pdf", "calculator", "clock"
    )
    private val communicationTokens = setOf(
        "phone", "dialer", "contacts", "messages", "sms", "mail", "gmail",
        "outlook", "whatsapp", "alaap", "meet", "zoom", "teams"
    )
    private val shoppingTokens = setOf(
        "shopping", "shop", "amazon", "daraz", "aliexpress", "foodpanda"
    )

    fun classify(
        packageName: String,
        label: String,
        applicationFlags: Int,
        applicationCategory: Int
    ): Profile {
        val packageValue = packageName.lowercase()
        val labelValue = label.lowercase()
        val haystack = "$packageValue $labelValue"
        val protected = PhoneControlSafety.isProtectedPackage(packageName)
        if (protected) {
            return Profile(
                category = "essential",
                recommendation = "allow",
                protected = true,
                reason = "Essential phone or Hredoy Flow safety app",
                suggestedDailyMinutes = 0,
                suggestedReelsGuard = false
            )
        }

        val isSystem = applicationFlags and ApplicationInfo.FLAG_SYSTEM != 0 ||
            applicationFlags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0
        if (isSystem && applicationCategory !in setOf(
                ApplicationInfo.CATEGORY_SOCIAL,
                ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_GAME
            )
        ) {
            return Profile(
                category = "system",
                recommendation = "allow",
                protected = false,
                reason = "System app; kept allowed by default",
                suggestedDailyMinutes = 0,
                suggestedReelsGuard = false
            )
        }

        val category = when {
            applicationCategory == ApplicationInfo.CATEGORY_SOCIAL ||
                socialTokens.any(haystack::contains) -> "social"
            applicationCategory == ApplicationInfo.CATEGORY_VIDEO ||
                videoTokens.any(haystack::contains) -> "video"
            applicationCategory == ApplicationInfo.CATEGORY_GAME ||
                gameTokens.any(haystack::contains) -> "game"
            educationTokens.any(haystack::contains) -> "education"
            applicationCategory == ApplicationInfo.CATEGORY_PRODUCTIVITY ||
                productivityTokens.any(haystack::contains) -> "productive"
            communicationTokens.any(haystack::contains) -> "communication"
            applicationCategory == ApplicationInfo.CATEGORY_MAPS -> "navigation"
            shoppingTokens.any(haystack::contains) -> "shopping"
            else -> "normal"
        }

        return when (category) {
            "social" -> Profile(
                category = category,
                recommendation = "review",
                protected = false,
                reason = "Social feeds often need a manual limit",
                suggestedDailyMinutes = 45,
                suggestedReelsGuard = true
            )
            "video" -> Profile(
                category = category,
                recommendation = "review",
                protected = false,
                reason = "Video and short-form content can be distracting",
                suggestedDailyMinutes = 60,
                suggestedReelsGuard = true
            )
            "game" -> Profile(
                category = category,
                recommendation = "review",
                protected = false,
                reason = "Game app; review before blocking",
                suggestedDailyMinutes = 60,
                suggestedReelsGuard = false
            )
            "shopping" -> Profile(
                category = category,
                recommendation = "review",
                protected = false,
                reason = "Shopping app; optional manual block",
                suggestedDailyMinutes = 30,
                suggestedReelsGuard = false
            )
            "education" -> Profile(
                category = category,
                recommendation = "allow",
                protected = false,
                reason = "Education app; automatically kept available",
                suggestedDailyMinutes = 0,
                suggestedReelsGuard = false
            )
            "productive", "navigation", "communication" -> Profile(
                category = category,
                recommendation = "allow",
                protected = false,
                reason = "Useful app; automatically kept available",
                suggestedDailyMinutes = 0,
                suggestedReelsGuard = false
            )
            else -> Profile(
                category = category,
                recommendation = "allow",
                protected = false,
                reason = "Allowed until you choose to block it",
                suggestedDailyMinutes = 0,
                suggestedReelsGuard = false
            )
        }
    }
}
