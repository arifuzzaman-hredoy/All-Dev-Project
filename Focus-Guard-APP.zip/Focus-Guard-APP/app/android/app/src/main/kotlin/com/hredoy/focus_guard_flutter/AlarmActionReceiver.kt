package com.hredoy.focus_guard_flutter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import kotlin.concurrent.thread

class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val task = NativeTask.fromIntent(intent)
        TaskAlarmService.stop(context)
        TaskAlarmActivity.dismissActive()
        NotificationManagerCompat.from(context).cancel(73001)

        if (intent.action == ACTION_SNOOZE) {
            val pendingResult = goAsync()
            val appContext = context.applicationContext
            thread(name = "hredoy-flow-alarm-snooze", isDaemon = false) {
                try {
                    AlarmScheduler.snooze(appContext, task)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    companion object {
        const val ACTION_STOP = "com.hredoy.focus_guard_flutter.action.ALARM_STOP"
        const val ACTION_SNOOZE = "com.hredoy.focus_guard_flutter.action.ALARM_SNOOZE"
    }
}
