package com.hredoy.focus_guard_flutter

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class FocusAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val focusStore by lazy { FocusStore(this) }
    private val phoneStore by lazy { PhoneControlStore(this) }
    private val protectionStore by lazy { ProtectionStore(this) }

    private var currentPackage: String = ""
    private var currentPackageSince: Long = 0L
    private var lastBlockedPackage: String? = null
    private var lastBlockedReason: String? = null
    private var lastBlockedAt = 0L
    private var lastHomeActionAt = 0L
    private var lastScrollPackage: String? = null
    private var lastScrollAt = 0L
    private var cachedUsagePackage: String? = null
    private var cachedUsageMillis = 0L
    private var cachedUsageAt = 0L
    private var currentReelPackage: String? = null
    private var lastReelDetectedAt = 0L
    private var lastReelWatchTickAt = 0L
    private val reelTransitionGate = ReelTransitionGate()
    private var reelVerificationGeneration = 0L
    private var pendingReelVerification: Runnable? = null
    private var reelCandidateSequence = 0L
    private var activeReelCandidateToken: String? = null
    private var lastReelPagerSignalAt = 0L
    private var initialReelCandidatePending = false

    private val usageTicker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            flushCurrentUsage(now)
            flushReelWatch(now)
            val foregroundPackage = currentPackage
            if (foregroundPackage.isNotBlank() &&
                !PhoneControlSafety.isProtectedPackage(foregroundPackage)
            ) {
                val root = rootInActiveWindow
                trackReelActivity(foregroundPackage, null, root, now)
                enforceBlock(foregroundPackage, null, root, now)
            }
            handler.postDelayed(this, USAGE_TICK_MILLIS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        SafetyBootstrap.apply(this)
        handler.removeCallbacks(usageTicker)
        handler.postDelayed(usageTicker, USAGE_TICK_MILLIS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val type = event?.eventType ?: return
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_SCROLLED
        ) {
            return
        }

        val foregroundPackage = event.packageName
            ?.toString()
            ?.trim()
            .orEmpty()
            .ifBlank {
                runCatching {
                    rootInActiveWindow?.packageName?.toString()?.trim().orEmpty()
                }.getOrDefault("")
            }
        if (foregroundPackage.isBlank()) return

        val now = System.currentTimeMillis()
        // Always update foreground first. Previously, returning early for Hredoy Flow
        // left the previously blocked package cached and caused repeated HOME actions.
        updateForeground(foregroundPackage, now)
        if (PhoneControlSafety.isProtectedPackage(foregroundPackage)) return

        val root = rootInActiveWindow
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            PhoneControlEngine.shouldTrackScroll(foregroundPackage, phoneStore) &&
            (foregroundPackage != lastScrollPackage || now - lastScrollAt >= SCROLL_DEBOUNCE_MILLIS)
        ) {
            lastScrollPackage = foregroundPackage
            lastScrollAt = now
            phoneStore.recordScroll(foregroundPackage)
        }

        trackReelActivity(foregroundPackage, event, root, now)
        enforceBlock(foregroundPackage, event, root, now)
    }

    private fun updateForeground(packageName: String, now: Long) {
        if (currentPackage == packageName) return
        flushCurrentUsage(now)
        flushReelWatch(now)
        if (currentReelPackage != packageName) {
            currentReelPackage = null
            lastReelDetectedAt = 0L
            lastReelWatchTickAt = 0L
            cancelPendingReelVerification()
            resetReelCandidateState()
            reelTransitionGate.leave()
        }
        currentPackage = packageName
        currentPackageSince = now
        cachedUsagePackage = null
    }

    private fun flushCurrentUsage(now: Long) {
        val packageName = currentPackage
        val since = currentPackageSince
        if (packageName.isNotBlank() &&
            !PhoneControlSafety.isProtectedPackage(packageName) &&
            since > 0L && now > since
        ) {
            phoneStore.recordUsage(packageName, now - since)
        }
        currentPackageSince = if (packageName.isBlank()) 0L else now
        if (cachedUsagePackage == packageName) {
            cachedUsageMillis = 0L
            cachedUsageAt = 0L
        }
    }

    private fun trackReelActivity(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?,
        now: Long
    ) {
        val policy = phoneStore.policy()
        val rule = policy.ruleFor(packageName)
        val perAppReelsGuard = rule?.reelsGuard == true
        val globalWindowGuard = policy.globalReelsWindowActive(now) &&
            policy.globalReelsWindowApplies(packageName)
        val isSupportedReelScreen = policy.masterEnabled &&
            policy.reelsBlockerEnabled &&
            (perAppReelsGuard || globalWindowGuard) &&
            PhoneControlEngine.isShortVideoScreen(packageName, event, root)

        if (!isSupportedReelScreen) {
            if (currentReelPackage == packageName &&
                now - lastReelDetectedAt > REEL_ACTIVE_GRACE_MILLIS
            ) {
                currentReelPackage = null
                lastReelWatchTickAt = 0L
                cancelPendingReelVerification()
                resetReelCandidateState()
                reelTransitionGate.leave(packageName)
            }
            return
        }

        if (currentReelPackage != packageName) {
            currentReelPackage = packageName
            lastReelWatchTickAt = now
            resetReelCandidateState()
            initialReelCandidatePending = true
            reelTransitionGate.enter(packageName, now)
            scheduleReelFingerprintVerification(
                packageName = packageName,
                delayMillis = REEL_INITIAL_DWELL_MILLIS,
                fallbackToken = null,
                initialEntry = true,
                evidenceReason = "initial-entry"
            )
        } else {
            val pagerEvidence = PhoneControlEngine.reelPagerEvidence(packageName, event, root)
            if (pagerEvidence != null) {
                val candidateToken = reelCandidateToken(
                    packageName = packageName,
                    evidence = pagerEvidence,
                    now = now
                )
                scheduleReelFingerprintVerification(
                    packageName = packageName,
                    delayMillis = REEL_SETTLE_DELAY_MILLIS,
                    fallbackToken = candidateToken,
                    initialEntry = initialReelCandidatePending,
                    evidenceReason = pagerEvidence.reason
                )
            }
        }
        lastReelDetectedAt = now
        flushReelWatch(now)
    }

    private fun scheduleReelFingerprintVerification(
        packageName: String,
        delayMillis: Long,
        fallbackToken: String?,
        initialEntry: Boolean,
        evidenceReason: String
    ) {
        cancelPendingReelVerification()
        val generation = reelVerificationGeneration
        val firstSample = Runnable firstSample@{
            if (!isActiveReelSession(packageName, generation)) {
                return@firstSample
            }
            val first = ReelFingerprintBuilder.capture(packageName, rootInActiveWindow)

            val secondSample = Runnable secondSample@{
                if (!isActiveReelSession(packageName, generation)) {
                    return@secondSample
                }
                val second = ReelFingerprintBuilder.capture(packageName, rootInActiveWindow)
                val confirmation = reelTransitionGate.confirmSettledCandidate(
                    packageName = packageName,
                    firstFingerprint = first.value,
                    secondFingerprint = second.value,
                    fallbackToken = fallbackToken,
                    initialEntry = initialEntry,
                    now = System.currentTimeMillis()
                )
                if (confirmation.accepted) {
                    initialReelCandidatePending = false
                    val confirmedCount = phoneStore.recordReelViewed(packageName)
                    val source = confirmation.source?.name.orEmpty().lowercase()
                    val fingerprint = first.value.take(8).ifBlank { "hidden" }
                    Log.i(
                        REEL_LOG_TAG,
                        "confirmed package=$packageName count=$confirmedCount source=$source evidence=$evidenceReason fingerprint=$fingerprint"
                    )
                }
            }
            handler.postDelayed(secondSample, REEL_STABILITY_SAMPLE_GAP_MILLIS)
        }
        pendingReelVerification = firstSample
        handler.postDelayed(firstSample, delayMillis)
    }

    private fun isActiveReelSession(packageName: String, generation: Long): Boolean =
        generation == reelVerificationGeneration &&
            currentPackage == packageName &&
            currentReelPackage == packageName &&
            System.currentTimeMillis() - lastReelDetectedAt <= REEL_ACTIVE_GRACE_MILLIS

    private fun reelCandidateToken(
        packageName: String,
        evidence: ReelPagerEvidence,
        now: Long
    ): String {
        val sameBurst = activeReelCandidateToken != null &&
            now - lastReelPagerSignalAt <= REEL_PAGER_BURST_GAP_MILLIS
        if (!sameBurst) {
            reelCandidateSequence += 1L
            val seed = evidence.signatureSeed.ifBlank { evidence.reason }
            activeReelCandidateToken = "$packageName:$reelCandidateSequence:$seed"
        }
        lastReelPagerSignalAt = now
        return requireNotNull(activeReelCandidateToken)
    }

    private fun resetReelCandidateState() {
        activeReelCandidateToken = null
        lastReelPagerSignalAt = 0L
        initialReelCandidatePending = false
    }

    private fun cancelPendingReelVerification() {
        pendingReelVerification?.let(handler::removeCallbacks)
        pendingReelVerification = null
        reelVerificationGeneration += 1L
    }

    private fun flushReelWatch(now: Long) {
        val packageName = currentReelPackage ?: return
        if (packageName != currentPackage ||
            now - lastReelDetectedAt > REEL_ACTIVE_GRACE_MILLIS
        ) {
            currentReelPackage = null
            lastReelWatchTickAt = 0L
            cancelPendingReelVerification()
            resetReelCandidateState()
            reelTransitionGate.leave(packageName)
            return
        }
        val previous = lastReelWatchTickAt
        if (previous > 0L && now > previous) {
            phoneStore.recordReelWatch(
                packageName,
                (now - previous).coerceAtMost(REEL_ACTIVE_GRACE_MILLIS)
            )
        }
        lastReelWatchTickAt = now
    }

    private fun enforceBlock(
        foregroundPackage: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?,
        now: Long
    ) {
        if (PhoneControlSafety.isProtectedPackage(foregroundPackage)) return

        val focusUntil = focusStore.focusUntil()
        if (focusUntil in 1..now) {
            FocusController.end(this)
        }

        val protectionDecision = ProtectionEngine.decision(
            packageName = foregroundPackage,
            event = event,
            root = root,
            store = protectionStore,
            now = now
        )
        if (protectionDecision != null) {
            performBlock(
                foregroundPackage = foregroundPackage,
                reason = protectionDecision.reason,
                detail = protectionDecision.detail,
                now = now,
                onNewBlock = {
                    if (protectionDecision.kind == "web") {
                        protectionStore.recordWebBlocked(
                            protectionDecision.target,
                            protectionDecision.detail,
                            foregroundPackage
                        )
                    } else if (protectionDecision.kind == "tamper") {
                        protectionStore.recordTamperBlocked(
                            foregroundPackage,
                            protectionDecision.detail
                        )
                    }
                }
            )
            return
        }

        val usageMillis = usageFor(foregroundPackage, now)
        val decision = PhoneControlEngine.decision(
            packageName = foregroundPackage,
            event = event,
            root = root,
            focusStore = focusStore,
            phoneStore = phoneStore,
            usageMillis = usageMillis
        ) ?: return

        performBlock(
            foregroundPackage = foregroundPackage,
            reason = decision.reason,
            detail = decision.detail,
            now = now,
            onNewBlock = {
                phoneStore.recordBlocked(foregroundPackage)
                if (decision.reason == "Reels Guard") {
                    phoneStore.recordReelsBlocked(foregroundPackage)
                }
            }
        )
    }

    private fun performBlock(
        foregroundPackage: String,
        reason: String,
        detail: String,
        now: Long,
        onNewBlock: (() -> Unit)? = null
    ) {
        if (PhoneControlSafety.isProtectedPackage(foregroundPackage)) return
        val repeated = foregroundPackage == lastBlockedPackage &&
            reason == lastBlockedReason &&
            now - lastBlockedAt < BLOCK_THROTTLE_MILLIS
        if (repeated || now - lastHomeActionAt < HOME_ACTION_COOLDOWN_MILLIS) return

        lastBlockedPackage = foregroundPackage
        lastBlockedReason = reason
        lastBlockedAt = now
        lastHomeActionAt = now
        onNewBlock?.invoke()
        Toast.makeText(this, "$reason: $detail", Toast.LENGTH_SHORT).show()

        // Fail open after one decision. Clearing the cached foreground prevents the
        // periodic ticker from repeatedly ejecting the user when Android delays a
        // launcher/window callback.
        currentPackage = ""
        currentPackageSince = 0L
        cachedUsagePackage = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed(
            {
                val activePackage = runCatching {
                    rootInActiveWindow?.packageName?.toString()?.trim().orEmpty()
                }.getOrDefault("")
                if (activePackage == foregroundPackage) {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                }
            },
            220L
        )
    }

    private fun usageFor(packageName: String, now: Long): Long {
        if (cachedUsagePackage == packageName &&
            now - cachedUsageAt < USAGE_CACHE_MILLIS
        ) {
            return cachedUsageMillis + currentElapsed(packageName, now)
        }
        val systemUsage = phoneStore.systemUsageMillis(this, packageName)
        val fallbackUsage = phoneStore.fallbackUsageMillis(packageName)
        cachedUsagePackage = packageName
        cachedUsageMillis = maxOf(systemUsage, fallbackUsage)
        cachedUsageAt = now
        return cachedUsageMillis + currentElapsed(packageName, now)
    }

    private fun currentElapsed(packageName: String, now: Long): Long =
        if (currentPackage == packageName && currentPackageSince > 0L) {
            (now - currentPackageSince).coerceAtLeast(0L)
        } else {
            0L
        }

    override fun onInterrupt() {
        val now = System.currentTimeMillis()
        flushCurrentUsage(now)
        flushReelWatch(now)
        cancelPendingReelVerification()
        handler.removeCallbacks(usageTicker)
    }

    override fun onDestroy() {
        val now = System.currentTimeMillis()
        flushCurrentUsage(now)
        flushReelWatch(now)
        cancelPendingReelVerification()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        private const val USAGE_TICK_MILLIS = 15_000L
        private const val USAGE_CACHE_MILLIS = 12_000L
        private const val SCROLL_DEBOUNCE_MILLIS = 320L
        private const val BLOCK_THROTTLE_MILLIS = 2_500L
        private const val HOME_ACTION_COOLDOWN_MILLIS = 1_200L
        private const val REEL_ACTIVE_GRACE_MILLIS = 20_000L
        private const val REEL_INITIAL_DWELL_MILLIS = 1_050L
        private const val REEL_SETTLE_DELAY_MILLIS = 720L
        private const val REEL_STABILITY_SAMPLE_GAP_MILLIS = 260L
        private const val REEL_PAGER_BURST_GAP_MILLIS = 700L
        private const val REEL_LOG_TAG = "HredoyReelCounter"
    }
}
