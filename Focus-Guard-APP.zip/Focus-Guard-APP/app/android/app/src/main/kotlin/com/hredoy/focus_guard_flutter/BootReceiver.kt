package com.hredoy.focus_guard_flutter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlin.concurrent.thread

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        thread(name = "hredoy-flow-boot-restore", isDaemon = false) {
            try {
                SafetyBootstrap.apply(appContext)
                NotificationChannels.ensure(appContext)
                if (FocusStore(appContext).focusUntil() <= System.currentTimeMillis()) {
                    FocusController.end(appContext)
                }
                AlarmScheduler.restore(appContext)
                val protectionStore = ProtectionStore(appContext)
                protectionStore.markBootRestore()
                if (protectionStore.policy().rebootRestoreEnabled) {
                    ProtectionVpnService.reconcile(appContext)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
