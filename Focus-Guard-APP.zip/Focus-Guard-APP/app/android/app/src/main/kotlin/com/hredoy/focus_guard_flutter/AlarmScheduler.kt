package com.hredoy.focus_guard_flutter

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

object AlarmScheduler {
    fun replaceAll(
        context: Context,
        tasks: List<NativeTask>,
        forceReschedule: Boolean = false
    ) {
        val store = FocusStore(context)
        val previous = readStored(store)
        val previousById = previous.associateBy { it.id }
        val incomingIds = tasks.mapTo(mutableSetOf()) { it.id }
        val completedIds = store.completedTasks()
        val now = System.currentTimeMillis()

        val activeSnoozes = previous
            .asSequence()
            .filter {
                it.isSnoozed &&
                    it.id in incomingIds &&
                    it.id !in completedIds &&
                    it.triggerAtMillis > now
            }
            .associateBy { it.id }

        val merged = tasks
            .asSequence()
            .filter { it.id !in completedIds }
            .map { task ->
                val snoozed = activeSnoozes[task.id]
                if (snoozed == null) {
                    task
                } else {
                    // Keep the snoozed trigger while adopting the newest task
                    // title, category, duration, focus flags, and ringtone.
                    // Editing a task during snooze must not leave stale sound
                    // settings queued in AlarmManager.
                    task.copy(
                        triggerAtMillis = snoozed.triggerAtMillis,
                        isSnoozed = true
                    )
                }
            }
            .toList()
        val mergedById = merged.associateBy { it.id }

        previous.forEach { oldTask ->
            val replacement = mergedById[oldTask.id]
            if (forceReschedule || replacement == null || replacement != oldTask) {
                cancel(context, oldTask)
            }
        }

        merged.forEach { task ->
            if (task.triggerAtMillis <= now) return@forEach
            val previousTask = previousById[task.id]
            if (forceReschedule || previousTask == null || previousTask != task) {
                schedule(context, task)
            }
        }

        saveStored(store, merged)
    }

    fun restore(context: Context) {
        val store = FocusStore(context)
        val completedIds = store.completedTasks()
        val now = System.currentTimeMillis()
        readStored(store)
            .asSequence()
            .filter {
                it.id !in completedIds &&
                    it.triggerAtMillis > now
            }
            .forEach { schedule(context, it) }
    }

    fun schedule(context: Context, task: NativeTask) {
        val operation = pendingIntent(context, task)
        val manager = context.getSystemService(AlarmManager::class.java)
        val exactAllowed =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()

        if (!exactAllowed) {
            manager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                task.triggerAtMillis,
                operation
            )
            return
        }

        if (task.alarmEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val showIntent = PendingIntent.getActivity(
                context,
                task.id.hashCode() + 7000,
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            manager.setAlarmClock(
                AlarmManager.AlarmClockInfo(task.triggerAtMillis, showIntent),
                operation
            )
        } else {
            manager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                task.triggerAtMillis,
                operation
            )
        }
    }

    fun snooze(context: Context, task: NativeTask) {
        val snoozedTask = task.copy(
            triggerAtMillis = System.currentTimeMillis() +
                task.snoozeMinutes.coerceAtLeast(1) * 60_000L,
            isSnoozed = true
        )
        val store = FocusStore(context)
        val updated = readStored(store)
            .filterNot { it.id == task.id }
            .toMutableList()
            .apply { add(snoozedTask) }
        saveStored(store, updated)
        schedule(context, snoozedTask)
    }

    private fun readStored(store: FocusStore): List<NativeTask> {
        val array = runCatching { JSONArray(store.scheduledTasksJson()) }
            .getOrDefault(JSONArray())
        return buildList {
            for (index in 0 until array.length()) {
                runCatching { NativeTask.fromJson(array.getJSONObject(index)) }
                    .getOrNull()
                    ?.let(::add)
            }
        }
    }

    private fun saveStored(store: FocusStore, tasks: List<NativeTask>) {
        val array = JSONArray()
        tasks.forEach { array.put(it.toJson()) }
        store.saveScheduledTasks(array.toString())
    }

    private fun cancel(context: Context, task: NativeTask) {
        context.getSystemService(AlarmManager::class.java)
            .cancel(pendingIntent(context, task))
    }

    private fun pendingIntent(context: Context, task: NativeTask): PendingIntent {
        val intent = task.toIntent(Intent(context, ReminderReceiver::class.java))
        return PendingIntent.getBroadcast(
            context,
            task.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
