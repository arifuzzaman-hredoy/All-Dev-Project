package com.hredoy.focus_guard_flutter

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.RingtoneManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "com.hredoy.focus_guard/native"
    private val schedulingExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var pendingSoundResult: MethodChannel.Result? = null
    private var pendingSoundRequestCode: Int = 0
    private var pendingProfileImageResult: MethodChannel.Result? = null
    private var pendingProfileImageRequestCode: Int = 0
    private var pendingVpnResult: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SafetyBootstrap.apply(this)
        NotificationChannels.ensure(this)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                runCatching {
                    when (call.method) {
                        "initialize" -> {
                            val arguments = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val rawTasks = arguments["tasks"] as? List<*>
                                ?: emptyList<Any>()
                            val forceReschedule = arguments["forceReschedule"] as? Boolean
                                ?: false
                            val tasks = rawTasks.mapNotNull { raw ->
                                (raw as? Map<*, *>)?.let(NativeTask::fromMap)
                            }
                            val appContext = applicationContext
                            schedulingExecutor.execute {
                                runCatching {
                                    AlarmScheduler.replaceAll(
                                        appContext,
                                        tasks,
                                        forceReschedule
                                    )
                                }.onSuccess {
                                    runOnUiThread { result.success(null) }
                                }.onFailure { error ->
                                    runOnUiThread {
                                        result.error(
                                            "FOCUS_GUARD_SCHEDULER_ERROR",
                                            error.message,
                                            null
                                        )
                                    }
                                }
                            }
                        }
                        "pickProfileImage" -> openProfileImagePicker(result)
                        "captureProfileImage" -> openProfileCamera(result)
                        "getAppDataPath" -> result.success(filesDir.absolutePath)
                        "shareText" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val subject = args["subject"]?.toString() ?: "Hredoy Flow"
                            val text = args["text"]?.toString() ?: ""
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, subject)
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            startActivity(
                                Intent.createChooser(
                                    shareIntent,
                                    "Share Hredoy Flow backup"
                                )
                            )
                            result.success(null)
                        }
                        "getCompletedTasks" -> result.success(
                            FocusStore(this).completedTasks().toList()
                        )
                        "setTaskCompleted" -> {
                            val args = call.arguments as Map<*, *>
                            val id = args["id"]?.toString()
                                ?: error("Task id is required")
                            val completed = args["completed"] as? Boolean ?: false
                            FocusStore(this).setTaskCompleted(id, completed)
                            result.success(null)
                        }
                        "getSettings" -> {
                            val store = FocusStore(this)
                            result.success(
                                mapOf(
                                    "blockedPackages" to store.blockedPackages().toList(),
                                    "useDnd" to store.useDnd(),
                                    "autoFocus" to store.autoFocus(),
                                    "focusUntilMillis" to store.focusUntil()
                                )
                            )
                        }
                        "saveSettings" -> {
                            val args = call.arguments as Map<*, *>
                            val store = FocusStore(this)
                            val packages = (args["blockedPackages"] as? List<*>)
                                ?.map { it.toString() }
                                ?.toSet()
                                ?: emptySet()
                            store.setBlockedPackages(packages)
                            store.setUseDnd(args["useDnd"] as? Boolean ?: true)
                            store.setAutoFocus(args["autoFocus"] as? Boolean ?: false)
                            result.success(null)
                        }
                        "getSystemReadiness" -> {
                            val alarmManager = getSystemService(AlarmManager::class.java)
                            val notificationManager =
                                getSystemService(NotificationManager::class.java)
                            val powerManager = getSystemService(PowerManager::class.java)
                            result.success(
                                mapOf(
                                    "notificationsEnabled" to
                                        NotificationManagerCompat.from(this)
                                            .areNotificationsEnabled(),
                                    "exactAlarmsEnabled" to
                                        (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                                            alarmManager.canScheduleExactAlarms()),
                                    "fullScreenIntentEnabled" to
                                        (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE ||
                                            notificationManager.canUseFullScreenIntent()),
                                    "accessibilityEnabled" to isFocusAccessibilityEnabled(),
                                    "batteryOptimizationIgnored" to
                                        powerManager.isIgnoringBatteryOptimizations(packageName),
                                    "usageAccessEnabled" to PhoneUsageStats.hasAccess(this),
                                    "notificationAccessEnabled" to NotificationAccess.isEnabled(this)
                                )
                            )
                        }
                        "getProtectionPolicy" -> {
                            result.success(ProtectionStore(this).policy().toMap())
                        }
                        "saveProtectionPolicy" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            ProtectionStore(this).savePolicy(
                                ProtectionPolicy.fromMap(args)
                            )
                            ProtectionVpnService.reconcile(this)
                            result.success(null)
                        }
                        "getProtectionSnapshot" -> {
                            val appContext = applicationContext
                            schedulingExecutor.execute {
                                runCatching {
                                    ProtectionStore(appContext).snapshot(appContext)
                                }.onSuccess { snapshot ->
                                    runOnUiThread { result.success(snapshot) }
                                }.onFailure { error ->
                                    runOnUiThread {
                                        result.error(
                                            "PROTECTION_SNAPSHOT_ERROR",
                                            error.message,
                                            null
                                        )
                                    }
                                }
                            }
                        }
                        "requestProtectionVpnPermission" -> {
                            val prepareIntent = VpnService.prepare(this)
                            if (prepareIntent == null) {
                                ProtectionVpnService.reconcile(this)
                                result.success(true)
                            } else if (pendingVpnResult != null) {
                                result.error(
                                    "VPN_PERMISSION_PENDING",
                                    "A VPN permission request is already open.",
                                    null
                                )
                            } else {
                                pendingVpnResult = result
                                startActivityForResult(prepareIntent, REQUEST_VPN_PERMISSION)
                            }
                        }
                        "startProtectionVpn" -> {
                            if (VpnService.prepare(this) != null) {
                                result.error(
                                    "VPN_PERMISSION_REQUIRED",
                                    "Approve the Android VPN permission first.",
                                    null
                                )
                            } else {
                                ProtectionVpnService.reconcile(this)
                                result.success(null)
                            }
                        }
                        "stopProtectionVpn" -> {
                            ProtectionVpnService.stop(this)
                            result.success(null)
                        }
                        "activatePrimeMode" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val blocked = (args["blockedPackages"] as? List<*>)
                                ?.mapNotNull { it?.toString() }
                                ?.toSet()
                                .orEmpty()
                            val allowed = (args["allowedPackages"] as? List<*>)
                                ?.mapNotNull { it?.toString() }
                                ?.toSet()
                                .orEmpty()
                            result.success(
                                ProtectionStore(this).activatePrimeMode(
                                    durationMinutes =
                                        (args["minutes"] as? Number)?.toInt() ?: 60,
                                    blockedPackages = blocked,
                                    allowedPackages = allowed,
                                    silenceNotifications =
                                        args["silenceNotifications"] as? Boolean ?: true
                                )
                            )
                        }
                        "activateKeepMeOut" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val packages = (args["packages"] as? List<*>)
                                ?.mapNotNull { it?.toString() }
                                ?.toSet()
                                .orEmpty()
                            result.success(
                                ProtectionStore(this).activateKeepMeOut(
                                    durationMinutes =
                                        (args["minutes"] as? Number)?.toInt() ?: 60,
                                    packages = packages
                                )
                            )
                        }
                        "requestHardcoreEmergencyUnlock" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            result.success(
                                ProtectionStore(this).requestEmergencyUnlock(
                                    (args["minutes"] as? Number)?.toInt() ?: 5
                                )
                            )
                        }
                        "cancelHardcoreEmergencyUnlock" -> {
                            ProtectionStore(this).cancelEmergencyUnlock()
                            result.success(null)
                        }
                        "clearProtectionHistory" -> {
                            ProtectionStore(this).clearHistory()
                            result.success(null)
                        }
                        "runProtectionDiagnostics" -> {
                            result.success(ProtectionStore(this).diagnostics())
                        }
                        "openVpnSettings" -> {
                            startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                            result.success(null)
                        }
                        "runPhoneControlSafeSetup" -> {
                            FocusController.end(this)
                            FocusStore(this).resetBlockingForSafety()
                            val phoneStore = PhoneControlStore(this)
                            phoneStore.applyManualBlockingMigration()
                            ProtectionStore(this).clearActiveLocksForSafety()
                            ProtectionVpnService.stop(this)
                            result.success(phoneStore.policy().toMap())
                        }
                        "emergencyStopAllBlocking" -> {
                            FocusController.end(this)
                            FocusStore(this).resetBlockingForSafety()
                            val phoneStore = PhoneControlStore(this)
                            phoneStore.applyManualBlockingMigration()
                            ProtectionStore(this).clearActiveLocksForSafety()
                            ProtectionVpnService.stop(this)
                            result.success(phoneStore.policy().toMap())
                        }
                        "getPhoneControlPolicy" -> {
                            result.success(PhoneControlStore(this).policy().toMap())
                        }
                        "savePhoneControlPolicy" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            PhoneControlStore(this).savePolicy(
                                PhoneControlPolicy.fromMap(args)
                            )
                            result.success(null)
                        }
                        "getScheduleProfileRuntime" -> {
                            result.success(
                                PhoneControlStore(this).profileRuntimeSnapshot()
                            )
                        }
                        "requestScheduleProfileUnlock" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val profileId = args["profileId"]?.toString().orEmpty()
                            val minutes = (args["minutes"] as? Number)?.toInt() ?: 0
                            result.success(
                                PhoneControlStore(this).requestEmergencyUnlock(
                                    profileId,
                                    minutes
                                )
                            )
                        }
                        "cancelScheduleProfileUnlock" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val profileId = args["profileId"]?.toString().orEmpty()
                            PhoneControlStore(this).cancelEmergencyUnlock(profileId)
                            result.success(null)
                        }
                        "getPhoneControlUsage" -> {
                            val appContext = applicationContext
                            schedulingExecutor.execute {
                                runCatching {
                                    PhoneControlStore(appContext).snapshot(appContext)
                                }.onSuccess { snapshot ->
                                    runOnUiThread { result.success(snapshot) }
                                }.onFailure { error ->
                                    runOnUiThread {
                                        result.error(
                                            "PHONE_CONTROL_USAGE_ERROR",
                                            error.message,
                                            null
                                        )
                                    }
                                }
                            }
                        }

                        "getPhoneControlDashboard" -> {
                            val appContext = applicationContext
                            schedulingExecutor.execute {
                                runCatching {
                                    PhoneControlStore(appContext).dashboardSnapshot(appContext)
                                }.onSuccess { snapshot ->
                                    runOnUiThread { result.success(snapshot) }
                                }.onFailure { error ->
                                    runOnUiThread {
                                        result.error(
                                            "PHONE_CONTROL_DASHBOARD_ERROR",
                                            error.message,
                                            null
                                        )
                                    }
                                }
                            }
                        }
                        "getSocialControlSnapshot" -> {
                            val appContext = applicationContext
                            schedulingExecutor.execute {
                                runCatching {
                                    PhoneControlStore(appContext).socialSnapshot(appContext)
                                }.onSuccess { snapshot ->
                                    runOnUiThread { result.success(snapshot) }
                                }.onFailure { error ->
                                    runOnUiThread {
                                        result.error(
                                            "SOCIAL_CONTROL_SNAPSHOT_ERROR",
                                            error.message,
                                            null
                                        )
                                    }
                                }
                            }
                        }
                        "clearNotificationHistory" -> {
                            PhoneControlStore(this).clearNotificationHistory()
                            result.success(null)
                        }
                        "resetPhoneControlUsage" -> {
                            PhoneControlStore(this).clearDisplayCounters()
                            result.success(null)
                        }
                        "listLaunchableApps" -> {
                            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                                addCategory(Intent.CATEGORY_LAUNCHER)
                            }
                            @Suppress("DEPRECATION")
                            val activities = packageManager.queryIntentActivities(launcherIntent, 0)
                            val apps = activities
                                .asSequence()
                                .mapNotNull { info ->
                                    val activityInfo = info.activityInfo ?: return@mapNotNull null
                                    val packageValue = activityInfo.packageName.orEmpty()
                                    if (packageValue.isBlank() || packageValue == packageName) {
                                        null
                                    } else {
                                        val label = info.loadLabel(packageManager).toString()
                                        val appInfo = activityInfo.applicationInfo
                                        val profile = AppSafetyClassifier.classify(
                                            packageName = packageValue,
                                            label = label,
                                            applicationFlags = appInfo.flags,
                                            applicationCategory = appInfo.category
                                        )
                                        buildMap<String, Any> {
                                            put("packageName", packageValue)
                                            put("label", label)
                                            putAll(profile.toMap())
                                        }
                                    }
                                }
                                .distinctBy { it["packageName"] }
                                .sortedWith(
                                    compareBy<Map<String, Any>>(
                                        { if (it["recommendation"] == "review") 0 else 1 },
                                        { it["label"]?.toString()?.lowercase().orEmpty() }
                                    )
                                )
                                .toList()
                            result.success(apps)
                        }
                        "setKeepScreenOn" -> {
                            val enabled = (call.arguments as? Map<*, *>)
                                ?.get("enabled") as? Boolean ?: false
                            runOnUiThread {
                                if (enabled) {
                                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                                } else {
                                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                                }
                            }
                            result.success(null)
                        }
                        "requestBatteryOptimizationExemption" -> {
                            requestBatteryOptimizationExemption()
                            result.success(null)
                        }
                        "pickSystemAlarmSound" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            openSystemSoundPicker(
                                result,
                                args["currentUri"]?.toString().orEmpty()
                            )
                        }
                        "pickCustomAlarmSound" -> openCustomAudioPicker(result)
                        "previewAlarmSound" -> {
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            AlarmSoundPreview.play(
                                this,
                                args["soundId"]?.toString() ?: AlarmSoundCatalog.SMART,
                                args["soundUri"]?.toString().orEmpty(),
                                args["category"]?.toString() ?: "General",
                                args["taskTitle"]?.toString() ?: "Task reminder"
                            )
                            result.success(null)
                        }
                        "stopAlarmSoundPreview" -> {
                            AlarmSoundPreview.stop()
                            result.success(null)
                        }
                        "requestNotificationPermission" -> {
                            requestNotificationPermission()
                            result.success(null)
                        }
                        "openExactAlarmSettings" -> {
                            openExactAlarmSettings()
                            result.success(null)
                        }
                        "openFullScreenAlarmSettings" -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                                startActivity(
                                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                                        data = Uri.parse("package:$packageName")
                                    }
                                )
                            } else {
                                startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.parse("package:$packageName")
                                    }
                                )
                            }
                            result.success(null)
                        }
                        "openAccessibilitySettings" -> {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            result.success(null)
                        }
                        "openDndSettings" -> {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            result.success(null)
                        }
                        "openBatterySettings" -> {
                            startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.parse("package:$packageName")
                                }
                            )
                            result.success(null)
                        }
                        "openNotificationSettings" -> {
                            startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                    putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                                }
                            )
                            result.success(null)
                        }
                        "openNotificationAccessSettings" -> {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            result.success(null)
                        }
                        "openUsageAccessSettings" -> {
                            startActivity(
                                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                                    data = Uri.parse("package:$packageName")
                                }
                            )
                            result.success(null)
                        }
                        "testTaskAlarm" -> {
                            AlarmSoundPreview.stop()
                            val args = call.arguments as? Map<*, *>
                                ?: emptyMap<Any, Any>()
                            val task = NativeTask(
                                id = "test-${System.currentTimeMillis()}",
                                triggerAtMillis = System.currentTimeMillis(),
                                title = "Hredoy Flow test alarm",
                                category = "System check",
                                notes = "This confirms full-screen alarm, selected sound, vibration, snooze, and stop controls.",
                                durationMinutes = 5,
                                alarmEnabled = true,
                                snoozeMinutes = 5,
                                alarmSoundId = args["soundId"]?.toString()
                                    ?: AlarmSoundCatalog.SMART,
                                alarmSoundLabel = args["soundLabel"]?.toString()
                                    ?: "Smart by task type",
                                alarmSoundUri = args["soundUri"]?.toString().orEmpty(),
                                autoFocus = false
                            )
                            ContextCompat.startForegroundService(
                                this,
                                task.toIntent(
                                    Intent(this, TaskAlarmService::class.java).apply {
                                        action = TaskAlarmService.ACTION_START
                                    }
                                )
                            )
                            result.success(null)
                        }
                        "startFocus" -> {
                            val args = call.arguments as Map<*, *>
                            val minutes = (args["minutes"] as Number).toInt()
                            val label = args["label"]?.toString() ?: "Focused study"
                            result.success(FocusController.start(this, minutes, label))
                        }
                        "endFocus" -> {
                            FocusController.end(this)
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                }.onFailure { error ->
                    result.error("FOCUS_GUARD_ERROR", error.message, null)
                }
            }
    }

    @Deprecated("Deprecated in Android API; retained for broad FlutterActivity compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN_PERMISSION) {
            val pending = pendingVpnResult
            pendingVpnResult = null
            val granted = resultCode == Activity.RESULT_OK
            if (granted) ProtectionVpnService.reconcile(this)
            pending?.success(granted)
            return
        }
        if (requestCode == REQUEST_PROFILE_GALLERY ||
            requestCode == REQUEST_PROFILE_CAMERA
        ) {
            handleProfileImageResult(requestCode, resultCode, data)
            return
        }
        if (requestCode != REQUEST_SYSTEM_SOUND && requestCode != REQUEST_CUSTOM_AUDIO) {
            return
        }
        val result = pendingSoundResult ?: return
        if (requestCode != pendingSoundRequestCode) return
        pendingSoundResult = null
        pendingSoundRequestCode = 0

        if (resultCode != Activity.RESULT_OK) {
            result.success(null)
            return
        }

        if (requestCode == REQUEST_SYSTEM_SOUND) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                data?.getParcelableExtra(
                    RingtoneManager.EXTRA_RINGTONE_PICKED_URI,
                    Uri::class.java
                )
            } else {
                @Suppress("DEPRECATION")
                data?.getParcelableExtra<Uri>(
                    RingtoneManager.EXTRA_RINGTONE_PICKED_URI
                )
            }
            if (uri == null) {
                result.success(null)
                return
            }
            val label = runCatching {
                RingtoneManager.getRingtone(this, uri)?.getTitle(this)
            }.getOrNull().orEmpty().ifBlank { "Phone alarm tone" }
            result.success(
                mapOf(
                    "id" to AlarmSoundCatalog.SYSTEM,
                    "label" to label,
                    "uri" to uri.toString()
                )
            )
            return
        }

        val uri = data?.data
        if (uri == null) {
            result.success(null)
            return
        }
        persistReadPermission(uri, data.flags)
        result.success(
            mapOf(
                "id" to AlarmSoundCatalog.CUSTOM,
                "label" to displayName(uri),
                "uri" to uri.toString()
            )
        )
    }

    override fun onDestroy() {
        AlarmSoundPreview.stop()
        schedulingExecutor.shutdown()
        pendingSoundResult?.error(
            "SOUND_PICKER_CLOSED",
            "The sound picker closed before returning a result.",
            null
        )
        pendingSoundResult = null
        pendingProfileImageResult?.error(
            "PROFILE_IMAGE_PICKER_CLOSED",
            "The profile image picker closed before returning a result.",
            null
        )
        pendingProfileImageResult = null
        pendingVpnResult?.error(
            "VPN_PERMISSION_CLOSED",
            "The VPN permission dialog closed before returning a result.",
            null
        )
        pendingVpnResult = null
        super.onDestroy()
    }

    private fun openProfileImagePicker(result: MethodChannel.Result) {
        prepareProfileImagePicker(result, REQUEST_PROFILE_GALLERY)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQUEST_PROFILE_GALLERY)
        } catch (error: Throwable) {
            clearPendingProfileImagePicker(result)
            throw error
        }
    }

    private fun openProfileCamera(result: MethodChannel.Result) {
        prepareProfileImagePicker(result, REQUEST_PROFILE_CAMERA)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) == null) {
            clearPendingProfileImagePicker(result)
            error("No camera application is available.")
        }
        try {
            startActivityForResult(intent, REQUEST_PROFILE_CAMERA)
        } catch (error: Throwable) {
            clearPendingProfileImagePicker(result)
            throw error
        }
    }

    private fun prepareProfileImagePicker(
        result: MethodChannel.Result,
        requestCode: Int
    ) {
        if (pendingProfileImageResult != null || pendingSoundResult != null) {
            error("Another media picker is already open.")
        }
        pendingProfileImageResult = result
        pendingProfileImageRequestCode = requestCode
    }

    private fun clearPendingProfileImagePicker(result: MethodChannel.Result) {
        if (pendingProfileImageResult === result) {
            pendingProfileImageResult = null
            pendingProfileImageRequestCode = 0
        }
    }

    private fun handleProfileImageResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        val result = pendingProfileImageResult ?: return
        if (requestCode != pendingProfileImageRequestCode) return
        pendingProfileImageResult = null
        pendingProfileImageRequestCode = 0

        if (resultCode != Activity.RESULT_OK) {
            result.success(null)
            return
        }

        val sourceBitmap = if (requestCode == REQUEST_PROFILE_CAMERA) {
            @Suppress("DEPRECATION")
            data?.extras?.get("data") as? Bitmap
        } else {
            null
        }
        val sourceUri = if (requestCode == REQUEST_PROFILE_GALLERY) data?.data else null
        if (sourceBitmap == null && sourceUri == null) {
            result.success(null)
            return
        }

        schedulingExecutor.execute {
            runCatching {
                if (sourceBitmap != null) {
                    compressProfileBitmap(sourceBitmap)
                } else {
                    decodeAndCompressProfileImage(sourceUri!!)
                }
            }.onSuccess { bytes ->
                runOnUiThread { result.success(bytes) }
            }.onFailure { error ->
                runOnUiThread {
                    result.error(
                        "PROFILE_IMAGE_ERROR",
                        error.message ?: "Unable to process profile image.",
                        null
                    )
                }
            }
        }
    }

    private fun decodeAndCompressProfileImage(uri: Uri): ByteArray {
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val maxSide = maxOf(info.size.width, info.size.height)
                if (maxSide > PROFILE_IMAGE_MAX_SOURCE_SIDE) {
                    val ratio = PROFILE_IMAGE_MAX_SOURCE_SIDE.toDouble() / maxSide
                    decoder.setTargetSize(
                        (info.size.width * ratio).toInt().coerceAtLeast(1),
                        (info.size.height * ratio).toInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri).use { stream ->
                BitmapFactory.decodeStream(stream, null, bounds)
            }
            var sampleSize = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sampleSize >
                PROFILE_IMAGE_MAX_SOURCE_SIDE
            ) {
                sampleSize *= 2
            }
            val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            contentResolver.openInputStream(uri).use { stream ->
                requireNotNull(BitmapFactory.decodeStream(stream, null, options)) {
                    "The selected image could not be decoded."
                }
            }
        }
        return compressProfileBitmap(bitmap)
    }

    private fun compressProfileBitmap(bitmap: Bitmap): ByteArray {
        val side = minOf(bitmap.width, bitmap.height)
        require(side > 0) { "The selected image is empty." }
        val square = Bitmap.createBitmap(
            bitmap,
            (bitmap.width - side) / 2,
            (bitmap.height - side) / 2,
            side,
            side
        )
        val outputBitmap = if (side > PROFILE_IMAGE_OUTPUT_SIDE) {
            Bitmap.createScaledBitmap(
                square,
                PROFILE_IMAGE_OUTPUT_SIDE,
                PROFILE_IMAGE_OUTPUT_SIDE,
                true
            )
        } else {
            square
        }
        return ByteArrayOutputStream().use { output ->
            check(outputBitmap.compress(Bitmap.CompressFormat.JPEG, 86, output)) {
                "The selected image could not be compressed."
            }
            output.toByteArray()
        }
    }

    private fun openSystemSoundPicker(
        result: MethodChannel.Result,
        currentUri: String
    ) {
        prepareSoundPicker(result, REQUEST_SYSTEM_SOUND)
        val existing = currentUri.takeIf { it.isNotBlank() }
            ?.let { runCatching { Uri.parse(it) }.getOrNull() }
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(
                RingtoneManager.EXTRA_RINGTONE_TYPE,
                RingtoneManager.TYPE_ALARM or
                    RingtoneManager.TYPE_NOTIFICATION or
                    RingtoneManager.TYPE_RINGTONE
            )
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose alarm sound")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
        }
        try {
            startActivityForResult(intent, REQUEST_SYSTEM_SOUND)
        } catch (error: Throwable) {
            clearPendingSoundPicker(result)
            throw error
        }
    }

    private fun openCustomAudioPicker(result: MethodChannel.Result) {
        prepareSoundPicker(result, REQUEST_CUSTOM_AUDIO)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            startActivityForResult(intent, REQUEST_CUSTOM_AUDIO)
        } catch (error: Throwable) {
            clearPendingSoundPicker(result)
            throw error
        }
    }

    private fun prepareSoundPicker(result: MethodChannel.Result, requestCode: Int) {
        if (pendingSoundResult != null || pendingProfileImageResult != null) {
            error("Another media picker is already open.")
        }
        AlarmSoundPreview.stop()
        pendingSoundResult = result
        pendingSoundRequestCode = requestCode
    }

    private fun clearPendingSoundPicker(result: MethodChannel.Result) {
        if (pendingSoundResult === result) {
            pendingSoundResult = null
            pendingSoundRequestCode = 0
        }
    }

    private fun persistReadPermission(uri: Uri, flags: Int) {
        val readFlag = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                if (readFlag == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION else readFlag
            )
        }
    }

    private fun displayName(uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        } finally {
            cursor?.close()
        }.orEmpty().ifBlank { "My audio file" }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                5101
            )
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                    }
                )
                return
            }
        }
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
        )
    }

    private fun isFocusAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, FocusAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return enabledServices
            .split(':')
            .mapNotNull(ComponentName::unflattenFromString)
            .any { component -> component == expected }
    }

    private fun requestBatteryOptimizationExemption() {
        val powerManager = getSystemService(PowerManager::class.java)
        if (powerManager.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
            return
        }
        runCatching {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        }.onFailure {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        }
    }

    companion object {
        private const val REQUEST_SYSTEM_SOUND = 6201
        private const val REQUEST_CUSTOM_AUDIO = 6202
        private const val REQUEST_PROFILE_GALLERY = 6301
        private const val REQUEST_PROFILE_CAMERA = 6302
        private const val REQUEST_VPN_PERMISSION = 6303
        private const val PROFILE_IMAGE_MAX_SOURCE_SIDE = 1440
        private const val PROFILE_IMAGE_OUTPUT_SIDE = 720
    }
}
