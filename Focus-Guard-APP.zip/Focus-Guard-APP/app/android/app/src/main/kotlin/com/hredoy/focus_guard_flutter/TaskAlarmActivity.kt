package com.hredoy.focus_guard_flutter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TaskAlarmActivity : Activity() {
    private lateinit var task: NativeTask

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        task = NativeTask.fromIntent(intent)
        current = WeakReference(this)
        prepareWindow()
        setContentView(buildContent())
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            task = NativeTask.fromIntent(intent)
            setContentView(buildContent())
        }
    }

    private fun prepareWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(13, 20, 32)
        window.navigationBarColor = Color.rgb(13, 20, 32)
    }

    private fun buildContent(): View {
        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 20, 32), Color.rgb(29, 53, 74))
            )
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(16), 0, dp(18))
        }

        content.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_stat_focus)
            setColorFilter(Color.rgb(121, 220, 148))
        }, LinearLayout.LayoutParams(dp(86), dp(86)))

        content.addView(TextView(this).apply {
            text = "HREDOY FLOW"
            setTextColor(Color.rgb(121, 220, 148))
            textSize = 13f
            letterSpacing = .18f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(18), 0, 0)
        })

        content.addView(TextView(this).apply {
            text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            setTextColor(Color.WHITE)
            textSize = 54f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(18), 0, 0)
        })

        content.addView(TextView(this).apply {
            text = task.category.uppercase(Locale.getDefault())
            setTextColor(Color.rgb(183, 196, 210))
            textSize = 13f
            letterSpacing = .1f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })

        content.addView(TextView(this).apply {
            text = task.title
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(20), 0, 0)
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        content.addView(TextView(this).apply {
            text = "What to do now"
            setTextColor(Color.rgb(121, 220, 148))
            textSize = 14f
            gravity = Gravity.START
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(8))
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        content.addView(TextView(this).apply {
            text = task.notes.ifBlank {
                "Start this task now and stay focused for ${task.durationMinutes} minutes."
            }
            setTextColor(Color.rgb(228, 235, 242))
            textSize = 17f
            gravity = Gravity.START
            setLineSpacing(0f, 1.2f)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.argb(45, 255, 255, 255))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        content.addView(TextView(this).apply {
            text = "Planned duration: ${task.durationMinutes} minutes"
            setTextColor(Color.rgb(183, 196, 210))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(2))
        })

        content.addView(TextView(this).apply {
            text = AlarmSoundCatalog.displayLabel(task)
            setTextColor(Color.rgb(150, 169, 187))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(6))
        })

        scroll.addView(
            content,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        val snooze = Button(this).apply {
            text = "Snooze ${task.snoozeMinutes} min"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.argb(55, 255, 255, 255))
                cornerRadius = dp(16).toFloat()
            }
            setOnClickListener {
                TaskAlarmService.stop(this@TaskAlarmActivity)
                AlarmScheduler.snooze(this@TaskAlarmActivity, task)
                finishAndRemoveTask()
            }
        }
        root.addView(
            snooze,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
            ).apply { bottomMargin = dp(10) }
        )

        val stop = Button(this).apply {
            text = "Stop alarm"
            isAllCaps = false
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(12, 33, 22))
            background = GradientDrawable().apply {
                setColor(Color.rgb(121, 220, 148))
                cornerRadius = dp(16).toFloat()
            }
            setOnClickListener {
                TaskAlarmService.stop(this@TaskAlarmActivity)
                finishAndRemoveTask()
            }
        }
        root.addView(
            stop,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(58)
            )
        )

        val open = TextView(this).apply {
            text = "Open Hredoy Flow"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
            setOnClickListener {
                TaskAlarmService.stop(this@TaskAlarmActivity)
                startActivity(Intent(this@TaskAlarmActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                })
                finishAndRemoveTask()
            }
        }
        root.addView(
            open,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        return root
    }

    @Deprecated("The alarm requires an explicit stop or snooze action.")
    override fun onBackPressed() {
        // Intentionally blocked while the alarm is active.
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    companion object {
        private var current: WeakReference<TaskAlarmActivity>? = null

        fun dismissActive() {
            val activity = current?.get() ?: return
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    activity.finishAndRemoveTask()
                }
            }
        }
    }
}
