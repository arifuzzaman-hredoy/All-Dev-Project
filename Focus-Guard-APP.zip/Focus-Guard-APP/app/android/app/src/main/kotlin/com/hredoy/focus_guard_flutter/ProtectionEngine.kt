package com.hredoy.focus_guard_flutter

import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque
import java.util.Locale

object ProtectionEngine {
    fun decision(
        packageName: String,
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?,
        store: ProtectionStore,
        now: Long = System.currentTimeMillis()
    ): ProtectionDecision? {
        if (packageName.isBlank() || packageName == APP_PACKAGE) return null
        val policy = store.policy()
        if (store.isEmergencyUnlocked(now)) return null

        val signals by lazy { readSignals(event, root) }

        if (policy.isPrimeActive(now)) {
            if (policy.uninstallGuardEnabled &&
                ProtectionRules.isTamperPackage(packageName) &&
                isUninstallOrDisableAttempt(signals)
            ) {
                return ProtectionDecision(
                    reason = "Uninstall Guard",
                    detail = "Prime Mode protects Hredoy Flow until the timer ends",
                    kind = "tamper",
                    target = packageName
                )
            }
            if (!PhoneControlSafety.isProtectedPackage(packageName)) {
                val shouldBlock = packageName in policy.primeBlockedPackages &&
                    packageName !in policy.primeAllowedPackages
                if (shouldBlock) {
                    return ProtectionDecision(
                        reason = "Prime Mode",
                        detail = "This app is on the Prime Mode block list",
                        kind = "prime",
                        target = packageName
                    )
                }
            }
        }

        if (policy.isKeepMeOutActive(now) &&
            packageName in policy.keepMeOutPackages &&
            !PhoneControlSafety.isProtectedPackage(packageName)
        ) {
            return ProtectionDecision(
                reason = "Keep Me Out",
                detail = "The timed app lock is still active",
                kind = "keep_out",
                target = packageName
            )
        }

        if (!policy.browserGuardEnabled ||
            !policy.isWebWindowActive() ||
            !ProtectionRules.isBrowserPackage(packageName)
        ) {
            return null
        }

        val candidate = signals.urlCandidates.firstOrNull { value ->
            ProtectionRules.extractHost(value).isNotBlank()
        }.orEmpty()
        if (candidate.isBlank()) return null
        val host = ProtectionRules.extractHost(candidate)
        val domainReason = ProtectionRules.domainBlockReason(host, policy)
        if (domainReason != null) {
            return ProtectionDecision(
                reason = "Website blocked",
                detail = "$host • $domainReason",
                kind = "web",
                target = host
            )
        }
        val safeSearchReason = ProtectionRules.safeSearchBlockReason(candidate, policy)
        if (safeSearchReason != null) {
            return ProtectionDecision(
                reason = "Safe Search",
                detail = safeSearchReason,
                kind = "web",
                target = host
            )
        }
        return null
    }

    private fun isUninstallOrDisableAttempt(signals: ScreenSignals): Boolean {
        val text = signals.allText
        val mentionsApp = "hredoy flow" in text || APP_PACKAGE in text
        if (!mentionsApp) return false
        return UNINSTALL_TOKENS.any(text::contains)
    }

    private fun readSignals(
        event: AccessibilityEvent?,
        root: AccessibilityNodeInfo?
    ): ScreenSignals {
        val candidates = LinkedHashSet<String>()
        val text = StringBuilder()

        event?.text?.forEach { value ->
            val item = value?.toString()?.trim().orEmpty()
            if (item.isNotBlank()) {
                appendBounded(text, item)
                if (looksLikeUrl(item)) candidates.add(item)
            }
        }

        if (root != null) {
            val queue = ArrayDeque<AccessibilityNodeInfo>()
            queue.add(root)
            var visited = 0
            while (queue.isNotEmpty() && visited < MAX_NODES) {
                val node = queue.removeFirst()
                visited += 1
                val nodeText = node.text?.toString()?.trim().orEmpty()
                val description = node.contentDescription?.toString()?.trim().orEmpty()
                val viewId = node.viewIdResourceName?.lowercase(Locale.US).orEmpty()
                if (nodeText.isNotBlank()) appendBounded(text, nodeText)
                if (description.isNotBlank()) appendBounded(text, description)
                if (looksLikeUrl(nodeText) || URL_VIEW_TOKENS.any(viewId::contains)) {
                    if (nodeText.isNotBlank()) candidates.add(nodeText)
                }
                if (looksLikeUrl(description)) candidates.add(description)
                val childCount = node.childCount.coerceAtMost(MAX_CHILDREN_PER_NODE)
                for (index in 0 until childCount) {
                    node.getChild(index)?.let(queue::addLast)
                }
            }
        }

        return ScreenSignals(
            allText = text.toString().lowercase(Locale.US),
            urlCandidates = candidates.toList()
        )
    }

    private fun appendBounded(target: StringBuilder, value: String) {
        if (target.length >= MAX_TEXT_LENGTH) return
        if (target.isNotEmpty()) target.append(' ')
        target.append(value.take(MAX_TEXT_LENGTH - target.length))
    }

    private fun looksLikeUrl(value: String): Boolean {
        val text = value.trim()
        return (text.startsWith("http://", true) ||
            text.startsWith("https://", true) ||
            (text.contains('.') && !text.contains(' ') && text.length <= 512))
    }

    private data class ScreenSignals(
        val allText: String,
        val urlCandidates: List<String>
    )

    private const val APP_PACKAGE = "com.hredoy.focus_guard_flutter"
    private const val MAX_NODES = 120
    private const val MAX_CHILDREN_PER_NODE = 28
    private const val MAX_TEXT_LENGTH = 8_000
    private val URL_VIEW_TOKENS = setOf(
        "url_bar",
        "location_bar",
        "omnibox",
        "address",
        "search_box"
    )
    private val UNINSTALL_TOKENS = setOf(
        "uninstall",
        "disable",
        "force stop",
        "remove app",
        "delete app"
    )
}
