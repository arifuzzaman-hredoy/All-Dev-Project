package com.hredoy.focus_guard_flutter

import android.content.Context
import org.json.JSONArray

class FocusStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun completedTasks(): Set<String> =
        preferences.getStringSet(KEY_COMPLETED, emptySet())?.toSet() ?: emptySet()

    fun setTaskCompleted(id: String, completed: Boolean) {
        val updated = completedTasks().toMutableSet()
        if (completed) updated.add(id) else updated.remove(id)
        preferences.edit().putStringSet(KEY_COMPLETED, updated).apply()
    }

    fun blockedPackages(): Set<String> = PhoneControlSafety.sanitizePackages(
        preferences.getStringSet(KEY_BLOCKED, emptySet())?.toSet().orEmpty()
    )

    fun setBlockedPackages(packages: Set<String>) {
        preferences.edit()
            .putStringSet(KEY_BLOCKED, PhoneControlSafety.sanitizePackages(packages))
            .apply()
    }

    fun useDnd(): Boolean = preferences.getBoolean(KEY_USE_DND, true)
    fun setUseDnd(enabled: Boolean) = preferences.edit().putBoolean(KEY_USE_DND, enabled).apply()

    fun autoFocus(): Boolean = preferences.getBoolean(KEY_AUTO_FOCUS, false)
    fun setAutoFocus(enabled: Boolean) = preferences.edit().putBoolean(KEY_AUTO_FOCUS, enabled).apply()

    fun focusUntil(): Long = preferences.getLong(KEY_FOCUS_UNTIL, 0L)
    fun focusLabel(): String = preferences.getString(KEY_FOCUS_LABEL, "Focused study") ?: "Focused study"
    fun isFocusActive(): Boolean = focusUntil() > System.currentTimeMillis()

    fun setFocus(untilMillis: Long, label: String) {
        preferences.edit()
            .putLong(KEY_FOCUS_UNTIL, untilMillis)
            .putString(KEY_FOCUS_LABEL, label)
            .apply()
    }

    fun clearFocus() {
        preferences.edit().remove(KEY_FOCUS_UNTIL).remove(KEY_FOCUS_LABEL).apply()
    }

    @Synchronized
    fun resetBlockingForSafety() {
        preferences.edit()
            .putStringSet(KEY_BLOCKED, emptySet())
            .putBoolean(KEY_AUTO_FOCUS, false)
            .remove(KEY_FOCUS_UNTIL)
            .remove(KEY_FOCUS_LABEL)
            .apply()
    }

    fun previousDndFilter(defaultValue: Int): Int =
        preferences.getInt(KEY_PREVIOUS_DND, defaultValue)

    fun savePreviousDndFilter(value: Int) {
        preferences.edit().putInt(KEY_PREVIOUS_DND, value).apply()
    }

    fun saveScheduledTasks(json: String) {
        preferences.edit().putString(KEY_SCHEDULED_TASKS, json).apply()
    }

    fun scheduledTasksJson(): String =
        preferences.getString(KEY_SCHEDULED_TASKS, JSONArray().toString()) ?: JSONArray().toString()

    companion object {
        private const val PREFS = "focus_guard"
        private const val KEY_COMPLETED = "completed_tasks"
        private const val KEY_BLOCKED = "blocked_packages"
        private const val KEY_USE_DND = "use_dnd"
        private const val KEY_AUTO_FOCUS = "auto_focus"
        private const val KEY_FOCUS_UNTIL = "focus_until"
        private const val KEY_FOCUS_LABEL = "focus_label"
        private const val KEY_PREVIOUS_DND = "previous_dnd"
        private const val KEY_SCHEDULED_TASKS = "scheduled_tasks"
    }
}
