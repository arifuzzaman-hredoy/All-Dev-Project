param(
    [string]$DeviceId = "R38M800T0HD",
    [switch]$SkipQA,
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"
$PackageId = "com.hredoy.focus_guard_flutter"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null
$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

if (-not $SkipBuild) {
    if ($SkipQA) {
        & "$PSScriptRoot\BUILD_RELEASE_APK.ps1" -SkipQA
    }
    else {
        & "$PSScriptRoot\BUILD_RELEASE_APK.ps1"
    }
    if ($LASTEXITCODE -ne 0) { throw "Signed release APK build failed." }
}

$Apk = Join-Path $PSScriptRoot "build\app\outputs\flutter-apk\app-release.apk"
if (-not (Test-Path -LiteralPath $Apk)) {
    throw "Signed release APK not found. Run .\BUILD_RELEASE_APK.ps1 first."
}

adb start-server
$DeviceOutput = adb devices -l | Out-String
if ($DeviceOutput -notmatch "(?m)^$([regex]::Escape($DeviceId))\s+device\b") {
    throw "Device $DeviceId was not detected."
}

adb -s $DeviceId install -r $Apk
if ($LASTEXITCODE -ne 0) {
    throw "Release installation failed. A signing-identity mismatch may require uninstalling an older development build, which would remove its local app data."
}

$PackageDump = adb -s $DeviceId shell dumpsys package $PackageId | Out-String
if ($PackageDump -notmatch "(?m)versionName=4\.6\.1\b") {
    throw "Installed release version is not 4.6.3."
}

adb -s $DeviceId shell am force-stop $PackageId | Out-Null
adb -s $DeviceId shell monkey -p $PackageId -c android.intent.category.LAUNCHER 1 | Out-Null
Write-Host "Signed Hredoy Flow 4.6.3 release installed and launched." -ForegroundColor Green
