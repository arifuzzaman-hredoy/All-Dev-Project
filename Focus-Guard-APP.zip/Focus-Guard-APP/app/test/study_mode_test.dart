import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';
import 'package:focus_guard_flutter/widgets/common_widgets.dart';

void main() {
  test('Study Mode policy round-trip preserves protection settings', () {
    const PhoneControlPolicy source = PhoneControlPolicy(
      studyModeEnabled: true,
      studyStrictAllowList: false,
      studyAllowedPackages: <String>{},
      studyBlockedPackages: <String>{
        'com.instagram.android',
        'com.zhiliaoapp.musically',
      },
      studySilenceNotifications: true,
      studyDefaultMinutes: 75,
      studyDailyGoalMinutes: 180,
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(decoded.studyModeEnabled, isTrue);
    expect(decoded.studyStrictAllowList, isFalse);
    expect(decoded.studyAllowedPackages, isEmpty);
    expect(decoded.studyBlockedPackages, hasLength(2));
    expect(decoded.studyBlockedPackages, contains('com.instagram.android'));
    expect(decoded.studySilenceNotifications, isTrue);
    expect(decoded.studyDefaultMinutes, 75);
    expect(decoded.studyDailyGoalMinutes, 180);
  });

  testWidgets('section header stacks its action on a narrow phone width',
      (WidgetTester tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: SectionHeader(
              title: 'Notification Blocker',
              subtitle: '0 apps selected',
              action: FilledButton.tonalIcon(
                onPressed: () {},
                icon: const Icon(Icons.apps_rounded),
                label: const Text('Choose apps'),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Notification Blocker'), findsOneWidget);
    expect(find.text('Choose apps'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
