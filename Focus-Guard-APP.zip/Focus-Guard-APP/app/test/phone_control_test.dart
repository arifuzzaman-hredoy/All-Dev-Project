import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/alarm_presets.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';
import 'package:focus_guard_flutter/services/native_bridge.dart';
import 'package:focus_guard_flutter/widgets/focus_tree.dart';

void main() {
  test('same-day schedule allows only selected weekdays and time window', () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.example.social',
      label: 'Social',
      blockOutsideSchedule: true,
      allowedWeekdays: <int>{1, 2, 3, 4, 5},
      allowedStartMinute: 8 * 60,
      allowedEndMinute: 18 * 60,
    );

    expect(rule.isAllowedAt(DateTime(2026, 7, 27, 9)), isTrue); // Monday
    expect(rule.isAllowedAt(DateTime(2026, 7, 27, 19)), isFalse);
    expect(rule.isAllowedAt(DateTime(2026, 7, 26, 9)), isFalse); // Sunday
  });

  test('overnight schedule carries access into the next calendar day', () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.example.chat',
      label: 'Chat',
      blockOutsideSchedule: true,
      allowedWeekdays: <int>{5},
      allowedStartMinute: 22 * 60,
      allowedEndMinute: 6 * 60,
    );

    expect(rule.isAllowedAt(DateTime(2026, 7, 24, 23)), isTrue); // Friday
    expect(rule.isAllowedAt(DateTime(2026, 7, 25, 5, 30)), isTrue); // Saturday
    expect(rule.isAllowedAt(DateTime(2026, 7, 25, 7)), isFalse);
  });

  test(
      'configured schedule remains fail-open until schedule blocking is enabled',
      () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.example.video',
      label: 'Video',
      allowedWeekdays: <int>{1, 2, 3, 4, 5},
      allowedStartMinute: 8 * 60,
      allowedEndMinute: 18 * 60,
    );

    final DateTime outsideWindow = DateTime(2026, 7, 26, 23); // Sunday
    expect(rule.isAllowedAt(outsideWindow), isTrue);
    expect(
      rule.copyWith(blockOutsideSchedule: true).isAllowedAt(outsideWindow),
      isFalse,
    );
  });

  test('policy round-trip preserves schedule, limits and reels guard', () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.instagram.android',
      label: 'Instagram',
      blockApp: true,
      dailyLimitMinutes: 45,
      reelsGuard: true,
      blockReelsImmediately: false,
      reelsDailyLimit: 24,
      reelsTimeLimitMinutes: 18,
      scrollLimit: 70,
    );
    const PhoneControlPolicy source = PhoneControlPolicy(
      masterEnabled: true,
      rules: <AppControlRule>[rule],
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(decoded.masterEnabled, isTrue);
    expect(decoded.activeFeatureCount, 8);
    expect(decoded.rules.single.packageName, 'com.instagram.android');
    expect(decoded.rules.single.blockApp, isTrue);
    expect(decoded.rules.single.dailyLimitMinutes, 45);
    expect(decoded.rules.single.reelsGuard, isTrue);
    expect(decoded.rules.single.blockReelsImmediately, isFalse);
    expect(decoded.rules.single.reelsDailyLimit, 24);
    expect(decoded.rules.single.reelsTimeLimitMinutes, 18);
    expect(decoded.rules.single.scrollLimit, 70);
  });

  test('per-app Reels warning milestones and wellbeing settings round-trip',
      () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.google.android.youtube',
      label: 'YouTube',
      reelsGuard: true,
      reelsDailyLimit: 80,
      reelsTimeLimitMinutes: 40,
      reelsWarningPercentages: <int>{50, 75, 100},
    );
    const PhoneControlPolicy source = PhoneControlPolicy(
      wellbeingWarningsEnabled: true,
      screenTimeGoalMinutes: 300,
      screenTimeWarningPercentages: <int>{25, 50, 75, 100},
      screenTimeRepeatMinutes: 45,
      detailedWarningNotifications: true,
      rules: <AppControlRule>[rule],
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(
      decoded.rules.single.reelsWarningPercentages,
      <int>{50, 75, 100},
    );
    expect(decoded.screenTimeGoalMinutes, 300);
    expect(
      decoded.screenTimeWarningPercentages,
      <int>{25, 50, 75, 100},
    );
    expect(decoded.screenTimeRepeatMinutes, 45);
    expect(decoded.detailedWarningNotifications, isTrue);
  });

  test('invalid warning thresholds recover to safe defaults', () {
    final AppControlRule rule = AppControlRule.fromMap(
      <String, Object>{
        'packageName': 'com.example.video',
        'label': 'Video',
        'reelsWarningPercentages': <int>[0, 101],
      },
    );
    final PhoneControlPolicy policy = PhoneControlPolicy.fromMap(
      <String, Object>{
        'screenTimeWarningPercentages': <int>[0, 101],
      },
    );

    expect(rule.reelsWarningPercentages, <int>{50, 75, 90});
    expect(policy.screenTimeWarningPercentages, <int>{50, 75, 90, 100});
  });

  test('new app rules are fail-open until the user explicitly blocks them', () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.example.safe',
      label: 'Safe app',
    );

    expect(rule.blockApp, isFalse);
    expect(rule.blockOutsideSchedule, isFalse);
    expect(rule.isAllowedAt(DateTime(2026, 7, 24, 2)), isTrue);
  });

  test(
      'study mode stores an explicit block list without strict allow-list mode',
      () {
    const PhoneControlPolicy source = PhoneControlPolicy(
      studyStrictAllowList: false,
      studyAllowedPackages: <String>{},
      studyBlockedPackages: <String>{'com.example.social'},
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(decoded.studyStrictAllowList, isFalse);
    expect(decoded.studyAllowedPackages, isEmpty);
    expect(decoded.studyBlockedPackages, <String>{'com.example.social'});
  });

  test('phone usage map exposes per-app and total blocked counters', () {
    final PhoneControlUsage usage = PhoneControlUsage.fromMap(
      <String, Object>{
        'usageMillis': <String, int>{'app': 7200000},
        'scrollCounts': <String, int>{'app': 80},
        'blockedAttempts': <String, int>{'app': 3, 'other': 2},
        'reelsViewed': <String, int>{'app': 12},
        'reelsWatchMillis': <String, int>{'app': 540000},
        'totalScreenTimeMillis': 9000000,
        'screenTimeWindowStartMillis':
            DateTime(2026, 7, 24).millisecondsSinceEpoch,
        'screenTimeSource': 'usage_events',
        'screenTimeEventCount': 42,
      },
    );

    expect(usage.usageMinutesFor('app'), 120);
    expect(usage.scrollCountFor('app'), 80);
    expect(usage.totalBlockedAttempts, 5);
    expect(usage.reelsViewedFor('app'), 12);
    expect(usage.reelsWatchMinutesFor('app'), 9);
    expect(formatUsageDuration(usage.totalScreenTimeMillis), '2h 30m');
    expect(usage.screenTimeWindowStart, DateTime(2026, 7, 24));
    expect(usage.screenTimeSourceLabel, 'Android activity timeline');
    expect(usage.screenTimeEventCount, 42);
  });

  testWidgets('focus tree renders safely in a compact phone card',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 320,
            height: 250,
            child: FocusTree(
              key: ValueKey<String>('test-focus-tree'),
              progress: 0.65,
              level: 12,
              height: 220,
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
        find.byKey(const ValueKey<String>('test-focus-tree')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  test('automatic Study schedule supports same-day and overnight windows', () {
    const PhoneControlPolicy sameDay = PhoneControlPolicy(
      studyScheduleEnabled: true,
      studyWeekdays: <int>{5},
      studyStartMinute: 10 * 60,
      studyEndMinute: 12 * 60,
    );
    expect(sameDay.studyScheduleActiveAt(DateTime(2026, 7, 24, 11)), isTrue);
    expect(sameDay.studyScheduleActiveAt(DateTime(2026, 7, 24, 13)), isFalse);

    const PhoneControlPolicy overnight = PhoneControlPolicy(
      studyScheduleEnabled: true,
      studyWeekdays: <int>{5},
      studyStartMinute: 22 * 60,
      studyEndMinute: 6 * 60,
    );
    expect(overnight.studyScheduleActiveAt(DateTime(2026, 7, 24, 23)), isTrue);
    expect(overnight.studyScheduleActiveAt(DateTime(2026, 7, 25, 5)), isTrue);
  });

  test('fixed Reels window applies to all or selected apps and round-trips',
      () {
    final DateTime start = DateTime(2026, 7, 24, 10);
    final DateTime end = DateTime(2026, 7, 26, 22);
    final PhoneControlPolicy source = PhoneControlPolicy(
      globalReelsWindowEnabled: true,
      globalReelsWindowStartMillis: start.millisecondsSinceEpoch,
      globalReelsWindowEndMillis: end.millisecondsSinceEpoch,
      globalReelsWindowLimit: 5000,
      globalReelsWindowPackages: const <String>{'com.google.android.youtube'},
      globalReelsWindowLocked: true,
    );
    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());
    expect(decoded.globalReelsWindowLimit, 5000);
    expect(
        decoded.globalReelsWindowActiveAt(DateTime(2026, 7, 25, 12)), isTrue);
    expect(decoded.globalReelsWindowAppliesTo('com.google.android.youtube'),
        isTrue);
    expect(
        decoded.globalReelsWindowAppliesTo('com.instagram.android'), isFalse);
    expect(decoded.globalReelsWindowLocked, isTrue);
  });

  test('app commitment uses at least twenty percent of configured time', () {
    const AppControlRule rule = AppControlRule(
      packageName: 'com.example.social',
      label: 'Social',
      dailyLimitMinutes: 100,
      commitmentPercent: 20,
    );
    expect(rule.minimumCommitmentMinutes, 20);
    final AppControlRule decoded = AppControlRule.fromMap(rule.toMap());
    expect(decoded.commitmentPercent, 20);
  });

  test('alarm preset catalog contains 216 unique ready presets', () {
    expect(AlarmPresetCatalog.all.length, 216);
    expect(
      AlarmPresetCatalog.all
          .map((AlarmPreset preset) => preset.id)
          .toSet()
          .length,
      216,
    );
  });

  test('installed apps expose precise distraction and safe category filters',
      () {
    const LaunchableAppInfo social = LaunchableAppInfo(
      packageName: 'com.example.social',
      label: 'Social',
      category: 'social',
      recommendation: 'review',
    );
    const LaunchableAppInfo education = LaunchableAppInfo(
      packageName: 'com.example.education',
      label: 'Education',
      category: 'education',
    );
    const LaunchableAppInfo productive = LaunchableAppInfo(
      packageName: 'com.example.productive',
      label: 'Productive',
      category: 'productive',
    );

    expect(social.matchesCategoryFilter('distracting'), isTrue);
    expect(social.matchesCategoryFilter('social'), isTrue);
    expect(social.categoryLabel, 'Social media');
    expect(education.matchesCategoryFilter('education'), isTrue);
    expect(education.matchesCategoryFilter('distracting'), isFalse);
    expect(productive.matchesCategoryFilter('useful'), isTrue);
  });
}
