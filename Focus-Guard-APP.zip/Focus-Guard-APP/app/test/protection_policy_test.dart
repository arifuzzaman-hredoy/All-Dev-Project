import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/protection_policy.dart';

void main() {
  test('protection policy round-trip preserves web and commitment settings',
      () {
    const ProtectionPolicy source = ProtectionPolicy(
      webProtectionEnabled: true,
      vpnDnsEnabled: true,
      adultContentEnabled: true,
      safeSearchEnabled: true,
      browserGuardEnabled: true,
      webScheduleEnabled: true,
      webWeekdays: <int>{1, 2, 3, 4, 5},
      webStartMinute: 22 * 60,
      webEndMinute: 6 * 60,
      blockedDomains: <String>{'blocked.example'},
      allowedDomains: <String>{'school.blocked.example'},
      blockedKeywords: <String>{'explicit query'},
      primaryDns: '1.1.1.3',
      secondaryDns: '1.0.0.3',
      failClosed: true,
      historyLimit: 400,
      primeModeUntilMillis: 1784862000000,
      primeAllowedPackages: <String>{'org.wikipedia'},
      primeSilenceNotifications: true,
      keepMeOutUntilMillis: 1784863000000,
      keepMeOutPackages: <String>{'com.example.video'},
      tamperProtectionEnabled: true,
      uninstallGuardEnabled: true,
      rebootRestoreEnabled: true,
      emergencyUnlockMinutes: 7,
      maxEmergencyUnlocksPerDay: 1,
    );

    final ProtectionPolicy decoded = ProtectionPolicy.fromMap(source.toMap());

    expect(decoded.webProtectionEnabled, isTrue);
    expect(decoded.vpnDnsEnabled, isTrue);
    expect(decoded.webWeekdays, <int>{1, 2, 3, 4, 5});
    expect(decoded.blockedDomains, contains('blocked.example'));
    expect(decoded.allowedDomains, contains('school.blocked.example'));
    expect(decoded.blockedKeywords, contains('explicit query'));
    expect(decoded.failClosed, isTrue);
    expect(decoded.historyLimit, 400);
    expect(decoded.primeAllowedPackages, contains('org.wikipedia'));
    expect(decoded.keepMeOutPackages, contains('com.example.video'));
    expect(decoded.emergencyUnlockMinutes, 7);
    expect(decoded.maxEmergencyUnlocksPerDay, 1);
  });

  test('commitment safety controls are opt-in by default', () {
    const ProtectionPolicy policy = ProtectionPolicy();

    expect(policy.primeModeUntilMillis, 0);
    expect(policy.keepMeOutUntilMillis, 0);
    expect(policy.tamperProtectionEnabled, isFalse);
    expect(policy.uninstallGuardEnabled, isFalse);
  });

  test('web schedule handles same-day and overnight windows', () {
    const ProtectionPolicy sameDay = ProtectionPolicy(
      webProtectionEnabled: true,
      webScheduleEnabled: true,
      webWeekdays: <int>{1},
      webStartMinute: 9 * 60,
      webEndMinute: 17 * 60,
    );
    expect(sameDay.isWebWindowActiveAt(DateTime(2026, 7, 27, 10)), isTrue);
    expect(sameDay.isWebWindowActiveAt(DateTime(2026, 7, 27, 18)), isFalse);

    const ProtectionPolicy overnight = ProtectionPolicy(
      webProtectionEnabled: true,
      webScheduleEnabled: true,
      webWeekdays: <int>{5},
      webStartMinute: 22 * 60,
      webEndMinute: 6 * 60,
    );
    expect(overnight.isWebWindowActiveAt(DateTime(2026, 7, 24, 23)), isTrue);
    expect(overnight.isWebWindowActiveAt(DateTime(2026, 7, 25, 5)), isTrue);
    expect(overnight.isWebWindowActiveAt(DateTime(2026, 7, 25, 8)), isFalse);
  });

  test('snapshot parses VPN, counters, unlock and history', () {
    final ProtectionSnapshot snapshot = ProtectionSnapshot.fromMap(
      <String, Object>{
        'vpnPrepared': true,
        'vpnRunning': true,
        'privateDnsActive': false,
        'webBlockedToday': 4,
        'tamperBlockedToday': 2,
        'emergencyUnlocksUsedToday': 1,
        'emergencyUnlockedUntilMillis': 1784862000000,
        'lastBootRestoreAtMillis': 1784861000000,
        'lastServiceMessage': 'Local DNS protection is running',
        'history': <Map<String, Object>>[
          <String, Object>{
            'timestampMillis': 1784860000000,
            'kind': 'web',
            'target': 'blocked.example',
            'reason': 'Custom domain block',
            'packageName': 'com.android.chrome',
          },
        ],
      },
    );

    expect(snapshot.vpnPrepared, isTrue);
    expect(snapshot.vpnRunning, isTrue);
    expect(snapshot.webBlockedToday, 4);
    expect(snapshot.tamperBlockedToday, 2);
    expect(snapshot.history.single.target, 'blocked.example');
  });
}
