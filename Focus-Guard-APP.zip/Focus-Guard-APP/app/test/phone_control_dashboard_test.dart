import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';
import 'package:focus_guard_flutter/screens/phone_control_dashboard_screen.dart';

void main() {
  test('dashboard snapshot parses actual weekly distraction metrics', () {
    final PhoneControlDashboardSnapshot snapshot =
        PhoneControlDashboardSnapshot.fromMap(
      <String, Object>{
        'usageMillis': <String, int>{'social.app': 3600000},
        'scrollCounts': <String, int>{'social.app': 44},
        'blockedAttempts': <String, int>{'social.app': 3},
        'totalScreenTimeMillis': 7200000,
        'distractionTimeMillis': 3600000,
        'trackingDate': '2026-07-23',
        'screenTimeWindowStartMillis':
            DateTime(2026, 7, 23).millisecondsSinceEpoch,
        'screenTimeSource': 'usage_events',
        'screenTimeEventCount': 91,
        'weekly': <Map<String, Object>>[
          <String, Object>{
            'date': '2026-07-22',
            'totalScreenTimeMillis': 5400000,
            'distractionTimeMillis': 1800000,
          },
          <String, Object>{
            'date': '2026-07-23',
            'totalScreenTimeMillis': 7200000,
            'distractionTimeMillis': 3600000,
          },
        ],
      },
    );

    expect(snapshot.usage.totalBlockedAttempts, 3);
    expect(snapshot.distractionRatio, 0.5);
    expect(snapshot.weekly.length, 2);
    expect(snapshot.weeklyDistractionMillis, 5400000);
    expect(snapshot.weekly.last.parsedDate, DateTime(2026, 7, 23));
    expect(snapshot.usage.screenTimeWindowStart, DateTime(2026, 7, 23));
    expect(snapshot.usage.screenTimeSourceLabel, 'Android activity timeline');
    expect(snapshot.usage.screenTimeEventCount, 91);
  });

  testWidgets('weekly distraction chart renders on a compact phone width',
      (WidgetTester tester) async {
    const List<PhoneControlDayUsage> days = <PhoneControlDayUsage>[
      PhoneControlDayUsage(
        date: '2026-07-17',
        distractionTimeMillis: 1200000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-18',
        distractionTimeMillis: 1800000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-19',
        distractionTimeMillis: 900000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-20',
        distractionTimeMillis: 2400000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-21',
        distractionTimeMillis: 3000000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-22',
        distractionTimeMillis: 1500000,
      ),
      PhoneControlDayUsage(
        date: '2026-07-23',
        distractionTimeMillis: 2100000,
      ),
    ];

    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 320,
            height: 270,
            child: Padding(
              padding: EdgeInsets.all(8),
              child: PhoneControlTrendChart(days: days),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey<String>('phone-control-weekly-chart')),
      findsOneWidget,
    );
    expect(find.text('Last 7 days'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
