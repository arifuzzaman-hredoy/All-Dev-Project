import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/models/app_models.dart';

void main() {
  test('profile picture survives preferences JSON round trip', () {
    final String encoded = base64Encode(<int>[1, 2, 3, 4, 5]);
    final AppPreferencesModel original = StudyPlan.initialData()
        .preferences
        .copyWith(profileImageBase64: encoded);

    final AppPreferencesModel restored = AppPreferencesModel.fromJson(
      original.toJson(),
    );

    expect(restored.profileImageBase64, encoded);
  });

  test('legacy preferences default to no profile picture', () {
    final Map<String, Object?> json = StudyPlan.initialData()
        .preferences
        .toJson()
      ..remove('profileImageBase64');
    final AppPreferencesModel restored = AppPreferencesModel.fromJson(json);

    expect(restored.profileImageBase64, isEmpty);
  });

  test('copyWith can remove a saved profile picture', () {
    final AppPreferencesModel withPhoto = StudyPlan.initialData()
        .preferences
        .copyWith(profileImageBase64: 'saved-photo');
    final AppPreferencesModel withoutPhoto =
        withPhoto.copyWith(profileImageBase64: '');

    expect(withoutPhoto.profileImageBase64, isEmpty);
  });
}
