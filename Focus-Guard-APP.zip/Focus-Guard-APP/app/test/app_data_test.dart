import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/models/alarm_sounds.dart';
import 'package:focus_guard_flutter/models/app_models.dart';

void main() {
  test('seed data contains routine, subjects, goals and habits', () {
    final AppData data = StudyPlan.initialData();
    expect(data.version, StudyPlan.currentDataVersion);
    expect(data.tasks, isNotEmpty);
    expect(data.subjects.length, greaterThanOrEqualTo(6));
    expect(data.goals, isNotEmpty);
    expect(data.habits, isNotEmpty);
    expect(data.tasks.every((TaskItem task) => task.alarmEnabled), isTrue);
  });

  test('seed schema version stays synchronized with the current migration', () {
    final AppData data = StudyPlan.initialData();
    expect(StudyPlan.currentDataVersion, 7);
    expect(data.version, StudyPlan.currentDataVersion);
  });

  test('app data JSON round trip preserves alarm settings', () {
    final AppData original = StudyPlan.initialData();
    final Object? decoded = jsonDecode(jsonEncode(original.toJson()));
    final AppData restored = AppData.fromJson(
      (decoded! as Map<Object?, Object?>).cast<String, Object?>(),
    );
    expect(restored.tasks.length, original.tasks.length);
    expect(restored.subjects.length, original.subjects.length);
    expect(restored.preferences.examDate, original.preferences.examDate);
    expect(restored.tasks.first.alarmEnabled, isTrue);
    expect(restored.tasks.first.snoozeMinutes, 5);
    expect(
      restored.tasks.first.alarmSoundId,
      original.tasks.first.alarmSoundId,
    );
    expect(
      restored.preferences.defaultAlarmSoundId,
      original.preferences.defaultAlarmSoundId,
    );
  });

  test('legacy task JSON defaults to a safe full-screen alarm', () {
    final DateTime now = DateTime.now();
    final TaskItem task = TaskItem.fromJson(<String, Object?>{
      'id': 'legacy',
      'title': 'Legacy task',
      'subjectId': 'general',
      'startAt': now.toIso8601String(),
      'durationMinutes': 25,
      'priority': 2,
      'createdAt': now.toIso8601String(),
      'updatedAt': now.toIso8601String(),
    });
    expect(task.alarmEnabled, isTrue);
    expect(task.snoozeMinutes, 5);
    expect(task.alarmSoundId, AlarmSoundCatalog.smartId);
    expect(task.alarmSoundLabel, AlarmSoundCatalog.smartLabel);
    expect(task.alarmSoundUri, isEmpty);
  });
}
