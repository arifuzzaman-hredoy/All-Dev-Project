import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/controllers/app_controller.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/models/app_models.dart';

void main() {
  test('reset routine begins exactly at 26 July 2026 6:30 AM', () {
    final List<TaskItem> tasks = StudyPlan.buildRoutine();

    expect(tasks, isNotEmpty);
    expect(tasks.first.startAt, DateTime(2026, 7, 26, 6, 30));
    expect(tasks.first.id, startsWith(StudyPlan.routineIdPrefix));
  });

  test('generated routine has no unexplained gaps and every block alarms', () {
    final List<TaskItem> tasks = StudyPlan.buildRoutine();

    for (final TaskItem task in tasks) {
      expect(task.reminderEnabled, isTrue, reason: task.title);
      expect(task.alarmEnabled, isTrue, reason: task.title);
      expect(task.durationMinutes, greaterThan(0), reason: task.title);
      expect(task.notes, isNotEmpty, reason: task.title);
    }

    for (int index = 0; index < tasks.length - 1; index += 1) {
      final TaskItem current = tasks[index];
      final TaskItem next = tasks[index + 1];
      final DateTime expectedNext = current.startAt.add(
        Duration(minutes: current.durationMinutes),
      );
      expect(
        next.startAt,
        expectedNext,
        reason: 'Gap or overlap between "${current.title}" and "${next.title}"',
      );
    }
  });

  test('physical office is exactly 2 PM to 7 PM for five hours', () {
    final List<TaskItem> officeBlocks = StudyPlan.buildRoutine()
        .where(
          (TaskItem task) =>
              task.subjectId == StudyPlan.work &&
              task.title.startsWith('Physical office —'),
        )
        .toList(growable: false);

    expect(officeBlocks, isNotEmpty);
    for (final TaskItem task in officeBlocks) {
      expect(task.startAt.hour, 14);
      expect(task.startAt.minute, 0);
      expect(task.durationMinutes, 300);
      expect(task.startAt.add(const Duration(minutes: 300)).hour, 19);
    }
  });

  test('routine reset preserves custom tasks and refreshes generated targets',
      () async {
    final AppData seed = StudyPlan.initialData();
    final DateTime now = DateTime.now();
    final TaskItem custom = TaskItem(
      id: 'custom-safe-task',
      title: 'My custom safe task',
      subjectId: StudyPlan.general,
      startAt: now.add(const Duration(days: 1)),
      durationMinutes: 25,
      priority: 2,
      createdAt: now,
      updatedAt: now,
    );
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(tasks: <TaskItem>[...seed.tasks, custom]),
    );

    await controller.resetRoutineFromJuly26();

    expect(
      controller.data.tasks.any((TaskItem task) => task.id == custom.id),
      isTrue,
    );
    expect(
      controller.data.tasks
          .where((TaskItem task) => StudyPlan.isManagedRoutineId(task.id))
          .first
          .startAt,
      DateTime(2026, 7, 26, 6, 30),
    );
    expect(controller.activeGoals.length, 7);
    expect(controller.selectedDate, DateTime(2026, 7, 26));
  });

  test('real focus minutes grow Study Quest XP and level', () async {
    final AppData seed = StudyPlan.initialData();
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(
        tasks: const <TaskItem>[],
        sessions: const <FocusSession>[],
      ),
    );
    final int beforeLevel = controller.gameStats.level;
    final int beforeXp = controller.gameStats.totalXp;
    final DateTime start = DateTime.now().subtract(const Duration(hours: 2));

    await controller.addSession(
      FocusSession(
        id: 'quest-session',
        label: 'Deep study',
        taskId: null,
        subjectId: StudyPlan.math,
        startedAt: start,
        endedAt: start.add(const Duration(minutes: 120)),
        plannedMinutes: 120,
        actualMinutes: 120,
        completed: true,
      ),
    );

    expect(controller.gameStats.totalXp, greaterThan(beforeXp));
    expect(controller.gameStats.level, greaterThan(beforeLevel));
  });
}
