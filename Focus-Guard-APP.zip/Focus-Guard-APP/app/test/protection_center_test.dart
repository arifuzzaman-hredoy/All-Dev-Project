import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/screens/protection_center_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const MethodChannel channel = MethodChannel('com.hredoy.focus_guard/native');

  setUp(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (MethodCall call) async {
      switch (call.method) {
        case 'getProtectionPolicy':
          return <String, Object>{
            'webProtectionEnabled': true,
            'vpnDnsEnabled': false,
            'adultContentEnabled': true,
            'safeSearchEnabled': true,
            'browserGuardEnabled': true,
            'webScheduleEnabled': false,
            'webWeekdays': <int>[1, 2, 3, 4, 5, 6, 7],
            'webStartMinute': 0,
            'webEndMinute': 0,
            'blockedDomains': <String>[],
            'allowedDomains': <String>[],
            'blockedKeywords': <String>['porn'],
            'primaryDns': '1.1.1.3',
            'secondaryDns': '1.0.0.3',
            'historyLimit': 200,
          };
        case 'getProtectionSnapshot':
          return <String, Object>{
            'vpnPrepared': false,
            'vpnRunning': false,
            'privateDnsActive': false,
            'webBlockedToday': 0,
            'tamperBlockedToday': 0,
            'emergencyUnlocksUsedToday': 1,
            'emergencyUnlockedNow': true,
            'emergencyUnlockedUntilMillis': DateTime.now()
                .add(const Duration(hours: 2))
                .millisecondsSinceEpoch,
            'history': <Object>[],
          };
        case 'listLaunchableApps':
          return <Map<String, String>>[
            <String, String>{
              'packageName': 'com.example.video',
              'label': 'Video App',
            },
          ];
      }
      return null;
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  testWidgets('Protection Center is responsive on a narrow phone',
      (WidgetTester tester) async {
    tester.view.physicalSize = const Size(320, 700);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      const MaterialApp(home: ProtectionCenterScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.text('Protection Center'), findsOneWidget);
    expect(find.text('Web & DNS'), findsOneWidget);
    expect(find.text('Web & DNS protection'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Hardcore app picker and emergency card stay readable on 320px',
      (WidgetTester tester) async {
    tester.view.physicalSize = const Size(320, 700);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      const MaterialApp(home: ProtectionCenterScreen()),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('Hardcore'));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey<String>('responsive-emergency-unlock-card')),
      findsOneWidget,
    );
    expect(find.text('Emergency unlock is active'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
