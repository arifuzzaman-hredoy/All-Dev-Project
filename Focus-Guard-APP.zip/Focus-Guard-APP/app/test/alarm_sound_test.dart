import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/alarm_sounds.dart';
import 'package:focus_guard_flutter/screens/alarm_sound_picker_screen.dart';

void main() {
  test('catalog exposes exactly 216 real built-in alarm sounds', () {
    expect(AlarmSoundCatalog.builtInSoundCount, 216);
    expect(AlarmSoundCatalog.soundPresets.length, 216);
    expect(AlarmSoundCatalog.builtIns.length, 217);

    final List<String> ids = AlarmSoundCatalog.builtIns
        .map((AlarmSoundPreset preset) => preset.id)
        .toList(growable: false);
    expect(ids.toSet().length, ids.length);
    expect(ids.first, AlarmSoundCatalog.smartId);
    expect(
      ids,
      containsAll(<String>[
        'study_bell',
        'exam_alert',
        'coding_digital',
        'meeting_chime',
        'workout_energy',
        'classic_alarm',
        'urgent_siren',
        'tone_017',
        'tone_216',
      ]),
    );
  });

  test('generated sound library exposes searchable groups and labels', () {
    expect(AlarmSoundCatalog.groups.first, 'All');
    expect(AlarmSoundCatalog.groups, contains('Nature'));
    expect(AlarmSoundCatalog.groups, contains('Focus'));
    expect(AlarmSoundCatalog.presetById('tone_216'), isNotNull);
    expect(
      AlarmSoundCatalog.presetById('tone_216')!.description,
      contains('216'),
    );
  });

  testWidgets('216-sound picker can search the final bundled tone',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: AlarmSoundPickerScreen(
          initialSelection: AlarmSoundCatalog.smart,
          category: 'Study',
          taskTitle: 'Revision',
        ),
      ),
    );

    await tester.enterText(
      find.byKey(const ValueKey<String>('alarm-sound-search')),
      'tone_216',
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey<String>('alarm-sound-tone_216')),
      findsOneWidget,
    );
    expect(find.text('Night Lantern 05 · V4'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  test('custom and phone selections survive platform map conversion', () {
    final AlarmSoundSelection custom = AlarmSoundSelection.fromMap(
      <Object?, Object?>{
        'id': AlarmSoundCatalog.customId,
        'label': 'My custom tone.mp3',
        'uri': 'content://media/audio/42',
      },
    );
    expect(custom.isCustom, isTrue);
    expect(custom.uri, 'content://media/audio/42');
    expect(custom.toMap()['label'], 'My custom tone.mp3');

    final AlarmSoundSelection phone = AlarmSoundSelection.fromMap(
      <Object?, Object?>{
        'id': AlarmSoundCatalog.systemId,
        'label': 'Galaxy Bells',
        'uri': 'content://settings/system/alarm_alert',
      },
    );
    expect(phone.isSystem, isTrue);
    expect(phone.label, 'Galaxy Bells');
  });

  test('missing labels fall back to a safe user-facing value', () {
    expect(AlarmSoundCatalog.safeLabel('study_bell', ''), 'Study Bell');
    expect(
      AlarmSoundCatalog.safeLabel(AlarmSoundCatalog.systemId, ''),
      'Phone alarm tone',
    );
    expect(
      AlarmSoundCatalog.safeLabel(AlarmSoundCatalog.customId, ''),
      'My audio file',
    );
    expect(
      AlarmSoundCatalog.safeLabel('unknown-value', ''),
      AlarmSoundCatalog.smartLabel,
    );
  });
}
