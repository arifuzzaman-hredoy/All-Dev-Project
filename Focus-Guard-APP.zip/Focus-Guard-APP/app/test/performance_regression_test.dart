import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/controllers/app_controller.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/main.dart';
import 'package:focus_guard_flutter/models/app_models.dart';
import 'package:focus_guard_flutter/widgets/common_widgets.dart';

void main() {
  test(
    'large local data uses cached indexes for repeated dashboard queries',
    () async {
      final AppData seed = StudyPlan.initialData();
      final DateTime base = dateOnly(
        DateTime.now(),
      ).subtract(const Duration(days: 60));

      final List<TaskItem> tasks = List<TaskItem>.generate(5000, (int index) {
        final DateTime startAt = base.add(
          Duration(days: index % 120, minutes: (index * 17) % 1440),
        );
        return TaskItem(
          id: 'stress-task-$index',
          title: 'Stress task $index',
          subjectId: seed.subjects[index % seed.subjects.length].id,
          startAt: startAt,
          durationMinutes: 25 + (index % 4) * 15,
          priority: 1 + index % 3,
          notes: 'Generated performance test item',
          reminderEnabled: index % 7 == 0,
          alarmEnabled: index % 13 == 0,
          snoozeMinutes: 5,
          autoFocus: false,
          createdAt: startAt,
          updatedAt: startAt,
          completedAt: index % 3 == 0 ? startAt : null,
        );
      });

      final List<FocusSession> sessions = List<FocusSession>.generate(1500, (
        int index,
      ) {
        final DateTime startedAt = base.add(
          Duration(days: index % 120, minutes: index % 60),
        );
        return FocusSession(
          id: 'stress-session-$index',
          label: 'Session $index',
          taskId: null,
          subjectId: seed.subjects[index % seed.subjects.length].id,
          startedAt: startedAt,
          endedAt: startedAt.add(const Duration(minutes: 25)),
          plannedMinutes: 25,
          actualMinutes: 25,
          completed: true,
        );
      });

      final Stopwatch createWatch = Stopwatch()..start();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(tasks: tasks, sessions: sessions),
      );
      createWatch.stop();

      expect(createWatch.elapsed, lessThan(const Duration(seconds: 4)));
      expect(identical(controller.activeTasks, controller.activeTasks), isTrue);

      final Stopwatch queryWatch = Stopwatch()..start();
      for (int index = 0; index < 300; index += 1) {
        final DateTime day = base.add(Duration(days: index % 120));
        controller.tasksFor(day);
        controller.completionPercent(day);
        controller.focusMinutesFor(day);
        controller.currentStreak;
        controller.focusBySubject();
        controller.taskCountForSubject(seed.subjects.first.id);
      }
      queryWatch.stop();

      expect(queryWatch.elapsed, lessThan(const Duration(seconds: 2)));
      expect(controller.activeTasks.length, 5000);
      expect(controller.totalFocusMinutes, 1500 * 25);

      final Stopwatch preferenceWatch = Stopwatch()..start();
      await controller.updatePreferences(
        controller.preferences.copyWith(
          showCompleted: !controller.preferences.showCompleted,
        ),
      );
      preferenceWatch.stop();
      expect(
        preferenceWatch.elapsed,
        lessThan(const Duration(milliseconds: 250)),
      );
    },
    timeout: const Timeout(Duration(seconds: 15)),
  );

  test(
    'test-mode CRUD updates indexes immediately without disk or native wait',
    () async {
      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          tasks: const <TaskItem>[],
          sessions: const <FocusSession>[],
        ),
      );
      final DateTime now = DateTime.now();
      final TaskItem task = TaskItem(
        id: 'instant-task',
        title: 'Instant task',
        subjectId: StudyPlan.general,
        startAt: now,
        durationMinutes: 25,
        priority: 2,
        createdAt: now,
        updatedAt: now,
      );

      final Stopwatch watch = Stopwatch()..start();
      await controller.addTask(task);
      watch.stop();

      expect(watch.elapsed, lessThan(const Duration(milliseconds: 250)));
      expect(controller.activeTasks, contains(task));
      expect(controller.tasksFor(now), contains(task));
      expect(controller.taskCountForSubject(StudyPlan.general), 1);
    },
  );

  testWidgets(
    'today and planner lazily build large task collections',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final DateTime today = dateOnly(DateTime.now());
      final List<TaskItem> tasks = List<TaskItem>.generate(1200, (int index) {
        final DateTime startAt = today.add(Duration(minutes: index % 1440));
        return TaskItem(
          id: 'lazy-task-$index',
          title: 'Lazy task $index',
          subjectId: seed.subjects[index % seed.subjects.length].id,
          startAt: startAt,
          durationMinutes: 25,
          priority: 2,
          createdAt: startAt,
          updatedAt: startAt,
        );
      }, growable: false);
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          tasks: tasks,
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pump();

      expect(tester.takeException(), isNull);
      expect(find.byType(TaskTile).evaluate().length, lessThan(40));

      await tester.tap(find.text('Planner').last);
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);
      expect(find.byType(TaskTile).evaluate().length, lessThan(40));
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );
}
