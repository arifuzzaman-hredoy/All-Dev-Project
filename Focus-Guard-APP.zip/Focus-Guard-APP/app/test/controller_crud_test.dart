import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/controllers/app_controller.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/models/alarm_sounds.dart';
import 'package:focus_guard_flutter/models/app_models.dart';

void main() {
  test('task CRUD, trash, restore, and completion stay consistent', () async {
    final AppData seed = StudyPlan.initialData();
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(tasks: const <TaskItem>[]),
    );
    final DateTime now = DateTime.now();
    final TaskItem task = TaskItem(
      id: 'crud-task',
      title: 'Original task',
      subjectId: StudyPlan.general,
      startAt: now.add(const Duration(minutes: 30)),
      durationMinutes: 50,
      priority: 2,
      createdAt: now,
      updatedAt: now,
      alarmSoundId: AlarmSoundCatalog.customId,
      alarmSoundLabel: 'My revision sound',
      alarmSoundUri: 'content://audio/revision',
    );

    await controller.addTask(task);
    expect(controller.activeTasks.single.title, 'Original task');

    final TaskItem updated = task.copyWith(
      title: 'Updated task',
      priority: 3,
      updatedAt: now.add(const Duration(seconds: 1)),
    );
    await controller.updateTask(updated);
    expect(controller.activeTasks.single.title, 'Updated task');
    expect(controller.activeTasks.single.priority, 3);
    expect(
        controller.activeTasks.single.alarmSoundId, AlarmSoundCatalog.customId);
    expect(controller.activeTasks.single.alarmSoundUri,
        'content://audio/revision');

    await controller.setTaskCompleted(updated, true);
    expect(controller.activeTasks.single.isCompleted, isTrue);

    final TaskItem completed = controller.activeTasks.single;
    await controller.deleteTask(completed);
    expect(controller.activeTasks, isEmpty);
    expect(controller.data.tasks.single.isDeleted, isTrue);

    await controller.restoreTask(controller.data.tasks.single);
    expect(controller.activeTasks.single.isDeleted, isFalse);

    await controller.permanentlyDeleteTask('crud-task');
    expect(controller.data.tasks, isEmpty);
  });

  test(
      'daily routine is ordered strictly by start time, not subject or priority',
      () {
    final AppData seed = StudyPlan.initialData();
    final DateTime day = DateTime(2026, 7, 24);
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(
        tasks: <TaskItem>[
          TaskItem(
            id: 'late-study',
            title: 'Late study block',
            subjectId: StudyPlan.revision,
            startAt: DateTime(2026, 7, 24, 10),
            durationMinutes: 50,
            priority: 3,
            createdAt: day,
            updatedAt: day,
          ),
          TaskItem(
            id: 'early-break',
            title: 'Early recovery block',
            subjectId: StudyPlan.health,
            startAt: DateTime(2026, 7, 24, 8),
            durationMinutes: 20,
            priority: 1,
            createdAt: day,
            updatedAt: day,
          ),
          TaskItem(
            id: 'middle-work',
            title: 'Middle work block',
            subjectId: StudyPlan.work,
            startAt: DateTime(2026, 7, 24, 9),
            durationMinutes: 40,
            priority: 2,
            createdAt: day,
            completedAt: DateTime(2026, 7, 24, 9, 40),
            updatedAt: day,
          ),
        ],
      ),
    );

    expect(
      controller.tasksFor(day).map((TaskItem task) => task.id),
      <String>['early-break', 'middle-work', 'late-study'],
    );
  });

  test('task duplication preserves its selected ringtone', () async {
    final AppData seed = StudyPlan.initialData();
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(tasks: const <TaskItem>[]),
    );
    final DateTime now = DateTime.now();
    final TaskItem task = TaskItem(
      id: 'sound-task',
      title: 'Sound task',
      subjectId: StudyPlan.general,
      startAt: now,
      durationMinutes: 25,
      priority: 2,
      alarmSoundId: 'study_bell',
      alarmSoundLabel: 'Study Bell',
      createdAt: now,
      updatedAt: now,
    );

    await controller.addTask(task);
    await controller.duplicateTask(task);

    expect(controller.activeTasks.length, 2);
    final TaskItem duplicate = controller.activeTasks.singleWhere(
      (TaskItem item) => item.id != task.id,
    );
    expect(duplicate.alarmSoundId, 'study_bell');
    expect(duplicate.alarmSoundLabel, 'Study Bell');
  });

  test(
    'goal, note, habit, and subject CRUD preserve derived indexes',
    () async {
      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          tasks: const <TaskItem>[],
          goals: const <GoalItem>[],
          habits: const <HabitItem>[],
          notes: const <NoteItem>[],
        ),
      );
      final DateTime now = DateTime.now();

      const SubjectItem subject = SubjectItem(
        id: 'custom-subject',
        name: 'Custom',
        colorValue: 0xFF445566,
        iconCodePoint: 0xe86f,
      );
      await controller.addSubject(subject);
      expect(controller.subjectById(subject.id).name, 'Custom');

      final GoalItem goal = GoalItem(
        id: 'goal-1',
        title: 'Finish module',
        subjectId: subject.id,
        target: 10,
        progress: 2,
        deadline: now.add(const Duration(days: 7)),
        createdAt: now,
        updatedAt: now,
      );
      await controller.addGoal(goal);
      expect(controller.activeGoals.single.id, goal.id);
      await controller.updateGoal(goal.copyWith(progress: 7, updatedAt: now));
      expect(controller.activeGoals.single.progress, 7);

      final NoteItem note = NoteItem(
        id: 'note-1',
        title: 'Formula',
        body: 'E = mc2',
        subjectId: subject.id,
        pinned: false,
        createdAt: now,
        updatedAt: now,
      );
      await controller.addNote(note);
      await controller.updateNote(note.copyWith(pinned: true, updatedAt: now));
      expect(controller.activeNotes.single.pinned, isTrue);

      final HabitItem habit = HabitItem(
        id: 'habit-1',
        title: 'Review notes',
        colorValue: 0xFF445566,
        iconCodePoint: 0xe86f,
        weekdays: <int>[now.weekday],
        completedDateKeys: const <String>[],
        createdAt: now,
      );
      await controller.addHabit(habit);
      await controller.toggleHabit(habit, now);
      expect(controller.data.habits.single.isDone(now), isTrue);
      await controller.toggleHabit(controller.data.habits.single, now);
      expect(controller.data.habits.single.isDone(now), isFalse);
    },
  );
  test('current action uses the active time window and is not overdue early', () {
    final AppData seed = StudyPlan.initialData();
    final DateTime now = DateTime(2026, 7, 24, 10, 20);
    final TaskItem current = TaskItem(
      id: 'current-action',
      title: 'Current action',
      subjectId: StudyPlan.general,
      startAt: DateTime(2026, 7, 24, 10),
      durationMinutes: 50,
      priority: 3,
      createdAt: now,
      updatedAt: now,
    );
    final TaskItem next = TaskItem(
      id: 'next-action',
      title: 'Next action',
      subjectId: StudyPlan.general,
      startAt: DateTime(2026, 7, 24, 11),
      durationMinutes: 30,
      priority: 2,
      createdAt: now,
      updatedAt: now,
    );
    final AppController controller = AppController.createForTesting(
      data: seed.copyWith(tasks: <TaskItem>[current, next]),
    );

    expect(controller.currentTaskAt(now)?.id, current.id);
    expect(current.isActiveAt(now), isTrue);
    expect(current.isActiveAt(current.endAt), isFalse);
    expect(controller.currentTaskAt(DateTime(2026, 7, 24, 10, 55)), isNull);
  });

}
