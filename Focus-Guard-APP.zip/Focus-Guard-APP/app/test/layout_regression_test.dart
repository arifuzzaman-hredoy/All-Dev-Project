import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/controllers/app_controller.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/main.dart';
import 'package:focus_guard_flutter/models/alarm_sounds.dart';
import 'package:focus_guard_flutter/models/app_models.dart';
import 'package:focus_guard_flutter/screens/alarm_sound_picker_screen.dart';
import 'package:focus_guard_flutter/screens/task_editor_screen.dart';
import 'package:focus_guard_flutter/widgets/app_logo.dart';
import 'package:focus_guard_flutter/widgets/common_widgets.dart';
import 'package:focus_guard_flutter/widgets/profile_avatar.dart';

void main() {
  testWidgets('compact wordmark works inside a constrained Row', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Row(
            children: <Widget>[
              AppLogo(size: 44, showWordmark: true, compact: true),
              Spacer(),
            ],
          ),
        ),
      ),
    );

    expect(tester.takeException(), isNull);
    expect(find.text('Hredoy Flow'), findsOneWidget);
  });

  testWidgets('subject badge shrink-wraps safely inside a Wrap', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Wrap(
            children: <Widget>[SubjectBadge(subject: StudyPlan.subjects.first)],
          ),
        ),
      ),
    );

    expect(tester.takeException(), isNull);
  });

  testWidgets('metric cards scale safely inside compact insight grids', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 174,
              height: 147.5,
              child: MetricCard(
                label: 'Completed tasks',
                value: '1,250 days',
                subtitle: 'A compact progress summary',
                icon: Icons.insights_rounded,
              ),
            ),
          ),
        ),
      ),
    );

    await tester.pump();
    expect(tester.takeException(), isNull);
    expect(find.text('Completed tasks'), findsOneWidget);
  });

  testWidgets(
    'task editor renders on a compact phone without layout failures',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(360, 640);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppController controller = AppController.createForTesting();
      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: const MaterialApp(home: TaskEditorScreen()),
        ),
      );
      await tester.pump();

      expect(tester.takeException(), isNull);
      expect(find.text('Create task'), findsOneWidget);
      expect(
        find.byKey(const ValueKey<String>('task-save-button')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey<String>('task-save-button-bottom')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey<String>('task-alarm-sound-tile')),
        findsOneWidget,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );

  testWidgets(
    'alarm sound picker remains usable on a compact phone',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(360, 640);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      await tester.pumpWidget(
        const MaterialApp(
          home: AlarmSoundPickerScreen(
            initialSelection: AlarmSoundCatalog.smart,
            category: 'Study',
            taskTitle: 'Physics revision',
          ),
        ),
      );
      await tester.pump();

      expect(tester.takeException(), isNull);
      expect(find.text('Choose alarm sound'), findsOneWidget);
      expect(find.text('Phone tones'), findsOneWidget);
      expect(find.text('My audio'), findsOneWidget);
      expect(find.text('Smart by task type'), findsOneWidget);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );

  testWidgets(
    'dashboard remains overflow-free on a compact phone',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(360, 640);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);
      expect(find.text('Hredoy Flow'), findsOneWidget);
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );

  testWidgets(
    'dashboard visual slides remain overflow-free on a narrow phone',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(320, 640);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pump();

      final Finder slider = find.byKey(
        const ValueKey<String>('dashboard-visual-slider'),
      );
      expect(slider, findsOneWidget);
      expect(tester.getSize(slider).height, greaterThanOrEqualTo(288));
      expect(tester.takeException(), isNull);

      for (int page = 1; page < 4; page++) {
        await tester.drag(slider, const Offset(-260, 0));
        await tester.pump(const Duration(milliseconds: 500));
        expect(tester.takeException(), isNull);
      }
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );

  testWidgets(
    'dashboard shows the task active at the current moment',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final DateTime now = DateTime.now();
      final AppData seed = StudyPlan.initialData();
      final TaskItem current = TaskItem(
        id: 'production-current-action',
        title: 'Production focus block',
        subjectId: StudyPlan.general,
        startAt: now.subtract(const Duration(minutes: 1)),
        durationMinutes: 20,
        priority: 3,
        createdAt: now,
        updatedAt: now,
      );
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          tasks: <TaskItem>[...seed.tasks, current],
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pump();

      final Finder currentCard =
          find.byKey(const ValueKey<String>('current-action-card'));
      await tester.dragUntilVisible(
        currentCard,
        find.byType(CustomScrollView).first,
        const Offset(0, -320),
      );
      await tester.pump();

      expect(currentCard, findsOneWidget);
      expect(find.text('Production focus block'), findsWidgets);
      expect(find.text('IN PROGRESS'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 30)),
  );

  testWidgets(
    'saving a task closes the editor without focus lifecycle errors',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);

      await tester.tap(find.text('New task'));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byType(TextFormField).first,
        'Lifecycle safe task',
      );

      final Finder saveButton = find.byKey(
        const ValueKey<String>('task-save-button'),
      );
      expect(saveButton, findsOneWidget);

      await tester.tap(saveButton);
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);
      expect(find.byType(TaskEditorScreen), findsNothing);
      expect(
        controller.activeTasks.where(
          (TaskItem task) => task.title == 'Lifecycle safe task',
        ),
        isNotEmpty,
      );
    },
    timeout: const Timeout(Duration(seconds: 45)),
  );

  testWidgets(
    'sidebar opens profile and returns to a selected root tab',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byTooltip('Open navigation menu'));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey<String>('app-navigation-drawer')),
        findsOneWidget,
      );
      final Finder profileShortcut = find.byKey(
        const ValueKey<String>('drawer-profile-shortcut'),
      );
      expect(profileShortcut, findsOneWidget);
      expect(find.text('Profile'), findsOneWidget);
      expect(find.text('Protection Center'), findsOneWidget);

      await tester.tap(profileShortcut);
      await tester.pumpAndSettle();
      expect(find.byType(ProfileAvatar), findsOneWidget);

      final Finder commandCenter = find.text('Exam command center');
      await tester.dragUntilVisible(
        commandCenter,
        find.byKey(const ValueKey<String>('profile-scroll-view')),
        const Offset(0, -320),
      );
      await tester.pumpAndSettle();
      expect(commandCenter, findsOneWidget);
      expect(tester.takeException(), isNull);

      await tester.tap(find.byTooltip('Open navigation menu'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Planner').first);
      await tester.pumpAndSettle();

      expect(find.text('Planner'), findsWidgets);
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 45)),
  );

  testWidgets(
    'sidebar lower actions remain reachable after the feature list grows',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byTooltip('Open navigation menu'));
      await tester.pumpAndSettle();

      final Finder drawer =
          find.byKey(const ValueKey<String>('app-navigation-drawer'));
      final Finder drawerScrollable = find
          .descendant(of: drawer, matching: find.byType(Scrollable))
          .first;

      await tester.scrollUntilVisible(
        find.byKey(const ValueKey<String>('drawer-study-quest')),
        220,
        scrollable: drawerScrollable,
      );
      await tester.pumpAndSettle();

      expect(find.text('Study Quest'), findsOneWidget);
      await tester.tap(
        find.byKey(const ValueKey<String>('drawer-study-quest')),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // FocusTree intentionally repeats forever. pumpAndSettle() would time
      // out even when navigation and rendering are correct.
      expect(find.text('Today’s quests'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 45)),
  );

  testWidgets(
    'rapid tab switching does not keep inactive pages rebuilding',
    (WidgetTester tester) async {
      tester.view.physicalSize = const Size(390, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final AppData seed = StudyPlan.initialData();
      final AppController controller = AppController.createForTesting(
        data: seed.copyWith(
          preferences: seed.preferences.copyWith(onboardingComplete: true),
        ),
      );

      await tester.pumpWidget(
        AppScope(
          controller: controller,
          child: HredoyFlowApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();

      for (final String tab in <String>[
        'Planner',
        'Focus',
        'Insights',
        'More',
        'Today',
      ]) {
        await tester.tap(find.text(tab).last);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      }
    },
    timeout: const Timeout(Duration(seconds: 45)),
  );
}
