import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';
import 'package:focus_guard_flutter/models/protection_policy.dart';
import 'package:focus_guard_flutter/models/smart_flow.dart';
import 'package:focus_guard_flutter/services/policy_safety.dart';

void main() {
  test('Smart Flow defaults to safe Simple Mode', () {
    const SmartFlowSettings settings = SmartFlowSettings();

    expect(settings.experienceMode, ExperienceMode.simple);
    expect(settings.rulePreviewRequired, isTrue);
    expect(settings.dailyCoachEnabled, isTrue);
    expect(settings.userAlwaysAllowedPackages, isEmpty);
    expect(settings.simpleShortcutIds, contains('safety'));
  });

  test('Smart Flow settings round-trip without losing custom safety choices', () {
    const SmartFlowSettings original = SmartFlowSettings(
      experienceMode: ExperienceMode.advanced,
      dailyCoachEnabled: false,
      weeklyReportEnabled: true,
      smartRecommendationsEnabled: false,
      rulePreviewRequired: true,
      lastSafetyStopMillis: 123456,
      userAlwaysAllowedPackages: <String>{'com.example.bank'},
      simpleShortcutIds: <String>{'coach', 'safety'},
    );

    final SmartFlowSettings restored =
        SmartFlowSettings.fromJson(original.toJson());

    expect(restored.experienceMode, ExperienceMode.advanced);
    expect(restored.dailyCoachEnabled, isFalse);
    expect(restored.smartRecommendationsEnabled, isFalse);
    expect(restored.lastSafetyStopMillis, 123456);
    expect(
      restored.userAlwaysAllowedPackages,
      contains('com.example.bank'),
    );
    expect(restored.simpleShortcutIds, <String>{'coach', 'safety'});
  });

  test('Weekly report text stays readable and shareable', () {
    const WeeklyFlowReport report = WeeklyFlowReport(
      completedTasks: 12,
      totalTasks: 16,
      focusMinutes: 240,
      productiveDays: 6,
      averageCompletion: 75,
      bestDayLabel: 'Friday',
    );

    final String text = report.toShareText();
    expect(text, contains('12/16'));
    expect(text, contains('240 minutes'));
    expect(text, contains('Friday'));
  });

  test('always-allowed sanitizer removes every restrictive package reference', () {
    const String safePackage = 'com.example.bank';
    const PhoneControlPolicy phone = PhoneControlPolicy(
      notificationPackages: <String>{safePackage, 'com.example.social'},
      studyAllowedPackages: <String>{'com.example.reader'},
      studyBlockedPackages: <String>{safePackage, 'com.example.game'},
      globalReelsWindowEnabled: true,
      globalReelsWindowLimit: 500,
      globalReelsWindowPackages: <String>{safePackage, 'com.example.video'},
      rules: <AppControlRule>[
        AppControlRule(
          packageName: safePackage,
          label: 'Bank',
          blockApp: true,
        ),
        AppControlRule(
          packageName: 'com.example.social',
          label: 'Social',
          blockApp: true,
        ),
      ],
      profiles: <ScheduleProfile>[
        ScheduleProfile(
          id: 'study',
          name: 'Study',
          blockedPackages: <String>{safePackage, 'com.example.game'},
        ),
      ],
    );

    final PhoneControlPolicy sanitized =
        sanitizePhoneControlForAlwaysAllowed(phone, <String>{safePackage});

    expect(
      sanitized.rules.map((AppControlRule rule) => rule.packageName),
      isNot(contains(safePackage)),
    );
    expect(sanitized.studyAllowedPackages, contains(safePackage));
    expect(sanitized.studyBlockedPackages, isNot(contains(safePackage)));
    expect(sanitized.notificationPackages, isNot(contains(safePackage)));
    expect(sanitized.globalReelsWindowEnabled, isTrue);
    expect(sanitized.globalReelsWindowPackages, <String>{'com.example.video'});
    expect(
      sanitized.profiles.single.blockedPackages,
      isNot(contains(safePackage)),
    );
  });

  test('always-allowed sanitizer protects Prime Mode and Keep Me Out', () {
    const String safePackage = 'com.example.authenticator';
    const ProtectionPolicy policy = ProtectionPolicy(
      primeBlockedPackages: <String>{safePackage, 'com.example.game'},
      primeAllowedPackages: <String>{'com.example.reader'},
      keepMeOutPackages: <String>{safePackage, 'com.example.social'},
    );

    final ProtectionPolicy sanitized =
        sanitizeProtectionForAlwaysAllowed(policy, <String>{safePackage});

    expect(sanitized.primeAllowedPackages, contains(safePackage));
    expect(sanitized.primeBlockedPackages, isNot(contains(safePackage)));
    expect(sanitized.keepMeOutPackages, isNot(contains(safePackage)));
  });


  test('always-allowed sanitizer fails open for an all-app Reels window', () {
    const PhoneControlPolicy phone = PhoneControlPolicy(
      globalReelsWindowEnabled: true,
      globalReelsWindowLimit: 100,
      globalReelsWindowPackages: <String>{},
    );

    final PhoneControlPolicy sanitized = sanitizePhoneControlForAlwaysAllowed(
      phone,
      <String>{'com.example.bank'},
    );

    expect(sanitized.globalReelsWindowEnabled, isFalse);
  });

}
