import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';

void main() {
  test('social-control policy round-trip preserves notification controls', () {
    const PhoneControlPolicy source = PhoneControlPolicy(
      masterEnabled: true,
      notificationBlockerEnabled: true,
      notificationPackages: <String>{'com.example.chat'},
      notificationScheduleEnabled: true,
      notificationWeekdays: <int>{1, 2, 3, 4, 5},
      notificationStartMinute: 21 * 60,
      notificationEndMinute: 7 * 60,
      notificationHistoryLimit: 250,
      profiles: <ScheduleProfile>[
        ScheduleProfile(
          id: 'study',
          name: 'Study',
          blockedPackages: <String>{'com.example.chat'},
          silenceNotifications: true,
        ),
      ],
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(decoded.notificationBlockerEnabled, isTrue);
    expect(decoded.notificationPackages, contains('com.example.chat'));
    expect(decoded.notificationScheduleEnabled, isTrue);
    expect(decoded.notificationWeekdays, <int>{1, 2, 3, 4, 5});
    expect(decoded.notificationStartMinute, 21 * 60);
    expect(decoded.notificationEndMinute, 7 * 60);
    expect(decoded.notificationHistoryLimit, 250);
    expect(decoded.profiles.single.silenceNotifications, isTrue);
  });

  test('social snapshot parses local counters and notification history', () {
    final SocialControlSnapshot snapshot = SocialControlSnapshot.fromMap(
      <String, Object>{
        'notificationAccessEnabled': true,
        'reelsBlocked': <String, int>{'video.app': 3},
        'reelsViewed': <String, int>{'video.app': 18},
        'reelsWatchMillis': <String, int>{'video.app': 780000},
        'notificationsBlocked': <String, int>{'chat.app': 5},
        'scrollCounts': <String, int>{'video.app': 42},
        'notificationHistory': <Map<String, Object>>[
          <String, Object>{
            'packageName': 'chat.app',
            'appLabel': 'Chat',
            'title': 'New message',
            'text': 'Private preview',
            'timestampMillis': 1784851200000,
          },
        ],
      },
    );

    expect(snapshot.notificationAccessEnabled, isTrue);
    expect(snapshot.totalReelsBlocked, 3);
    expect(snapshot.totalReelsViewed, 18);
    expect(snapshot.totalReelsWatchMillis, 780000);
    expect(snapshot.totalNotificationsBlocked, 5);
    expect(snapshot.totalScrolls, 42);
    expect(snapshot.notificationHistory.single.appLabel, 'Chat');
  });

  test('legacy policy defaults social controls to disabled', () {
    final PhoneControlPolicy decoded = PhoneControlPolicy.fromMap(
      <String, Object>{
        'masterEnabled': true,
        'rules': <Object>[],
      },
    );

    expect(decoded.notificationBlockerEnabled, isFalse);
    expect(decoded.notificationPackages, isEmpty);
  });

  test('notification schedule supports same-day and overnight quiet windows',
      () {
    const PhoneControlPolicy sameDay = PhoneControlPolicy(
      notificationScheduleEnabled: true,
      notificationWeekdays: <int>{1},
      notificationStartMinute: 9 * 60,
      notificationEndMinute: 17 * 60,
    );
    expect(
      sameDay.notificationWindowActiveAt(DateTime(2026, 7, 27, 10)),
      isTrue,
    );
    expect(
      sameDay.notificationWindowActiveAt(DateTime(2026, 7, 27, 18)),
      isFalse,
    );

    const PhoneControlPolicy overnight = PhoneControlPolicy(
      notificationScheduleEnabled: true,
      notificationWeekdays: <int>{5},
      notificationStartMinute: 22 * 60,
      notificationEndMinute: 6 * 60,
    );
    expect(
      overnight.notificationWindowActiveAt(DateTime(2026, 7, 24, 23)),
      isTrue,
    );
    expect(
      overnight.notificationWindowActiveAt(DateTime(2026, 7, 25, 5)),
      isTrue,
    );
    expect(
      overnight.notificationWindowActiveAt(DateTime(2026, 7, 25, 8)),
      isFalse,
    );
  });
}
