import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/phone_control.dart';

void main() {
  test('recurring profile activates on selected days and supports overnight',
      () {
    const ScheduleProfile profile = ScheduleProfile(
      id: 'night-detox',
      name: 'Night Detox',
      blockedPackages: <String>{'social.app'},
      weekdays: <int>{5},
      startMinute: 22 * 60,
      endMinute: 6 * 60,
    );

    expect(profile.isActiveAt(DateTime(2026, 7, 24, 23)), isTrue);
    expect(profile.isActiveAt(DateTime(2026, 7, 25, 5, 30)), isTrue);
    expect(profile.isActiveAt(DateTime(2026, 7, 25, 7)), isFalse);
    expect(profile.blocksPackageAt('social.app', DateTime(2026, 7, 24, 23)),
        isTrue);
    expect(profile.blocksPackageAt('study.app', DateTime(2026, 7, 24, 23)),
        isFalse);
  });

  test('overlap resolution detects shared apps and ignores unrelated apps', () {
    const ScheduleProfile student = ScheduleProfile(
      id: 'student',
      name: 'Student Focus',
      blockedPackages: <String>{'social.app', 'video.app'},
      weekdays: <int>{1},
      startMinute: 19 * 60,
      endMinute: 23 * 60,
    );
    const ScheduleProfile night = ScheduleProfile(
      id: 'night',
      name: 'Night Detox',
      blockedPackages: <String>{'social.app'},
      weekdays: <int>{1},
      startMinute: 22 * 60,
      endMinute: 6 * 60,
    );
    const ScheduleProfile unrelated = ScheduleProfile(
      id: 'other',
      name: 'Other',
      blockedPackages: <String>{'game.app'},
      weekdays: <int>{1},
      startMinute: 20 * 60,
      endMinute: 21 * 60,
    );

    expect(student.overlapsWith(night), isTrue);
    expect(student.overlapsWith(unrelated), isFalse);
  });

  test('policy round-trip preserves old app rules and new schedule profiles',
      () {
    const PhoneControlPolicy source = PhoneControlPolicy(
      masterEnabled: true,
      rules: <AppControlRule>[
        AppControlRule(packageName: 'social.app', label: 'Social'),
      ],
      profiles: <ScheduleProfile>[
        ScheduleProfile(
          id: 'student',
          name: 'Student Focus',
          blockedPackages: <String>{'social.app'},
          weekdays: <int>{1, 2, 3, 4, 5},
          emergencyUnlockMinutes: 10,
          maxEmergencyUnlocksPerDay: 1,
          silenceNotifications: true,
        ),
      ],
    );

    final PhoneControlPolicy decoded =
        PhoneControlPolicy.fromMap(source.toMap());

    expect(decoded.rules.single.packageName, 'social.app');
    expect(decoded.profiles.single.name, 'Student Focus');
    expect(decoded.profiles.single.silenceNotifications, isTrue);
    expect(decoded.scheduleProfilesEnabled, isTrue);
    expect(decoded.activeProfilesFor('social.app', DateTime(2026, 7, 27, 20)),
        hasLength(1));
  });

  test('legacy policy without profiles remains valid and keeps rules', () {
    final PhoneControlPolicy decoded = PhoneControlPolicy.fromMap(
      <String, Object>{
        'masterEnabled': true,
        'scheduleEnabled': true,
        'rules': <Map<String, Object>>[
          <String, Object>{
            'packageName': 'legacy.app',
            'label': 'Legacy',
          },
        ],
      },
    );

    expect(decoded.masterEnabled, isTrue);
    expect(decoded.rules.single.packageName, 'legacy.app');
    expect(decoded.profiles, isEmpty);
    expect(decoded.scheduleProfilesEnabled, isTrue);
  });

  test('emergency unlock runtime parses native status safely', () {
    final ScheduleProfileRuntime runtime = ScheduleProfileRuntime.fromMap(
      <String, Object>{
        'profileId': 'student',
        'unlockedUntilMillis': 4102444800000,
        'unlocksUsedToday': 1,
        'granted': true,
      },
    );

    expect(runtime.profileId, 'student');
    expect(runtime.unlocksUsedToday, 1);
    expect(runtime.granted, isTrue);
    expect(runtime.isUnlockedNow, isTrue);
  });
}
