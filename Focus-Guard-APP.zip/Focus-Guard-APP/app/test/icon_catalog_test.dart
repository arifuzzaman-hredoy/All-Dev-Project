import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/models/app_icon_catalog.dart';

void main() {
  test('persisted selectable icons resolve to tree-shake-safe constants', () {
    const List<IconData> selectable = <IconData>[
      Icons.menu_book_rounded,
      Icons.calculate_rounded,
      Icons.memory_rounded,
      Icons.science_rounded,
      Icons.code_rounded,
      Icons.translate_rounded,
      Icons.language_rounded,
      Icons.work_rounded,
      Icons.health_and_safety_rounded,
      Icons.fact_check_rounded,
      Icons.category_rounded,
      Icons.bedtime_rounded,
      Icons.restaurant_rounded,
      Icons.psychology_rounded,
      Icons.shield_rounded,
      Icons.water_drop_rounded,
      Icons.fitness_center_rounded,
      Icons.check_circle_rounded,
    ];

    for (final IconData icon in selectable) {
      final IconData resolved = AppIconCatalog.resolve(icon.codePoint);
      expect(resolved.codePoint, icon.codePoint);
      expect(resolved.fontFamily, icon.fontFamily);
    }
  });

  test('unknown persisted icon uses the requested safe fallback', () {
    final IconData resolved = AppIconCatalog.resolve(
      -1,
      fallback: Icons.check_circle_rounded,
    );
    expect(resolved.codePoint, Icons.check_circle_rounded.codePoint);
  });
}
