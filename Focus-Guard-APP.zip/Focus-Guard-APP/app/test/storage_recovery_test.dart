import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:focus_guard_flutter/data/study_plan.dart';
import 'package:focus_guard_flutter/models/app_models.dart';
import 'package:focus_guard_flutter/services/local_store.dart';

void main() {
  test(
    'local store saves compact data and recovers from a corrupt primary file',
    () async {
      final Directory directory = await Directory.systemTemp.createTemp(
        'hredoy-flow-store-test-',
      );
      addTearDown(() async {
        if (await directory.exists()) {
          await directory.delete(recursive: true);
        }
      });

      final AppData seed = StudyPlan.initialData();
      final DateTime now = DateTime.now();
      final List<TaskItem> firstTasks = List<TaskItem>.generate(
        320,
        (int index) => TaskItem(
          id: 'stored-$index',
          title: 'Stored task $index',
          subjectId: seed.subjects[index % seed.subjects.length].id,
          startAt: now.add(Duration(minutes: index)),
          durationMinutes: 25,
          priority: 2,
          createdAt: now,
          updatedAt: now,
        ),
        growable: false,
      );

      final LocalStore store = LocalStore(directory.path);
      final AppData first = seed.copyWith(tasks: firstTasks);
      final String exported = await store.encodeAsync(first);
      final AppData exportedRoundTrip = await store.decodeAsync(exported);
      expect(exportedRoundTrip.tasks.length, 320);
      expect(exported, contains('\n'));
      final AppData second = first.copyWith(
        tasks: <TaskItem>[
          ...firstTasks,
          TaskItem(
            id: 'stored-new',
            title: 'Newer task',
            subjectId: StudyPlan.general,
            startAt: now,
            durationMinutes: 25,
            priority: 3,
            createdAt: now,
            updatedAt: now,
          ),
        ],
      );

      await store.save(first);
      await store.save(second);

      final AppData? latest = await store.load();
      expect(latest, isNotNull);
      expect(latest!.tasks.length, 321);

      final File primary = File('${directory.path}/hredoy_flow_data_v3.json');
      await primary.writeAsString('{broken-json');

      final AppData? recovered = await store.load();
      expect(recovered, isNotNull);
      expect(recovered!.tasks.length, 320);
      expect(recovered.tasks.first.title, 'Stored task 0');
    },
    timeout: const Timeout(Duration(seconds: 20)),
  );

  test('backup decoder rejects non-object JSON', () async {
    final Directory directory = await Directory.systemTemp.createTemp(
      'hredoy-flow-decode-test-',
    );
    addTearDown(() async {
      if (await directory.exists()) {
        await directory.delete(recursive: true);
      }
    });

    final LocalStore store = LocalStore(directory.path);
    await expectLater(
      store.decodeAsync('[1, 2, 3]'),
      throwsA(isA<FormatException>()),
    );
  });
}
