$ErrorActionPreference = "Stop"

Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null

$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

function Assert-LastExitCode {
    param([Parameter(Mandatory = $true)][string]$Message)
    if ($LASTEXITCODE -ne 0) { throw $Message }
}

function Assert-Contains {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][string]$Message
    )
    if (-not $Source.Contains($Token)) { throw $Message }
}

function Assert-PowerShellScriptsParse {
    param([Parameter(Mandatory = $true)][string]$RootPath)

    $ParseFailures = @()
    $ScriptFiles = Get-ChildItem `
        -LiteralPath $RootPath `
        -Filter "*.ps1" `
        -File `
        -Recurse `
        -ErrorAction Stop

    foreach ($ScriptFile in $ScriptFiles) {
        $ParserTokens = $null
        $ParserErrors = $null

        [System.Management.Automation.Language.Parser]::ParseFile(
            $ScriptFile.FullName,
            [ref]$ParserTokens,
            [ref]$ParserErrors
        ) | Out-Null

        foreach ($ParserError in @($ParserErrors)) {
            $ParseFailures += (
                "{0}:{1}:{2} {3}" -f `
                    $ScriptFile.FullName, `
                    $ParserError.Extent.StartLineNumber, `
                    $ParserError.Extent.StartColumnNumber, `
                    $ParserError.Message
            )
        }
    }

    if ($ParseFailures.Count -gt 0) {
        throw (
            "PowerShell syntax validation failed:`n" +
            ($ParseFailures -join [Environment]::NewLine)
        )
    }
}

Assert-PowerShellScriptsParse -RootPath (Split-Path $PSScriptRoot -Parent)

Write-Host "[1/14] Static lifecycle, production UI, midnight usage, protection, compact layouts, Android, storage, and performance guards" -ForegroundColor Cyan

$TaskEditorSource = Get-Content -LiteralPath ".\lib\screens\task_editor_screen.dart" -Raw
if ($TaskEditorSource -match "AppScope\.of\(context\)") {
    throw "Task editor must use AppScope.read to avoid save/pop rebuild races."
}
foreach ($Token in @(
    "task-save-button",
    "task-alarm-sound-tile",
    "alarm-preset-library-tile",
    "AlarmPresetScreen",
    "216 ready-made alarm",
    "AlarmSoundPickerScreen",
    "alarmSoundId",
    "alarmSoundUri"
)) {
    Assert-Contains $TaskEditorSource $Token "Task editor ringtone/lifecycle token missing: $Token"
}
Assert-Contains $TaskEditorSource "task-save-button-bottom" "Task editor bottom save action is missing."
if ($TaskEditorSource -match "milliseconds:\s*120") {
    throw "Artificial keyboard delay was reintroduced."
}

$SettingsSource = Get-Content -LiteralPath ".\lib\screens\settings_screen.dart" -Raw
$MoreScreenSource = Get-Content -LiteralPath ".\lib\screens\more_screen.dart" -Raw
foreach ($Token in @(
    "default-alarm-sound-tile",
    "defaultAlarmSoundId",
    "AlarmSoundPickerScreen",
    "onChangeEnd"
)) {
    Assert-Contains $SettingsSource $Token "Settings ringtone/performance token missing: $Token"
}
foreach ($Token in @(
    "NativeSystemReadiness",
    "systemReadiness",
    "launchableApps",
    "Choose focus-blocked apps",
    "!app.protected",
    "requestBatteryOptimizationExemption"
)) {
    Assert-Contains $SettingsSource $Token "Settings readiness/app-picker token missing: $Token"
}
$SoundPickerSource = Get-Content -LiteralPath ".\lib\screens\alarm_sound_picker_screen.dart" -Raw
foreach ($Token in @(
    "pickSystemAlarmSound",
    "pickCustomAlarmSound",
    "previewAlarmSound",
    "Search 216 built-in sounds",
    "alarm-sound-group-filter",
    "built-in alarm sounds"
)) {
    Assert-Contains $SoundPickerSource $Token "Alarm sound picker token missing: $Token"
}

$RootSource = Get-Content -LiteralPath ".\lib\screens\root_screen.dart" -Raw
$CommandSearchSource = Get-Content -LiteralPath ".\lib\screens\command_search_screen.dart" -Raw
$AlarmPresetModelSource = Get-Content -LiteralPath ".\lib\models\alarm_presets.dart" -Raw
$AlarmPresetScreenSource = Get-Content -LiteralPath ".\lib\screens\alarm_preset_screen.dart" -Raw
$ReelsInsightsSource = Get-Content -LiteralPath ".\lib\screens\reels_insights_screen.dart" -Raw
$WellbeingAlertsSource = Get-Content -LiteralPath ".\lib\screens\wellbeing_alerts_screen.dart" -Raw
foreach ($Token in @(
    "CommandSearchScreen",
    "NavigationDestinationLabelBehavior.onlyShowSelected",
    "label: 'Search'"
)) {
    Assert-Contains $RootSource $Token "Search navigation token missing: $Token"
}
foreach ($Token in @(
    "Recommended commands",
    "Fixed Reels date-range budget",
    "Automatic Study schedule",
    "Choose from 216 built-in alarm sounds"
)) {
    Assert-Contains $CommandSearchSource $Token "Command search token missing: $Token"
}
foreach ($Token in @(
    "Today’s short-video dashboard",
    "Per-app limits",
    "Confirmed Reels",
    "Progress notifications",
    "Save per-app Reels limit",
    "reelsWarningPercentages"
)) {
    Assert-Contains $ReelsInsightsSource $Token "Per-app Reels insights token missing: $Token"
}
foreach ($Token in @(
    "Today’s screen-time status",
    "Detailed wellbeing notifications",
    "Goal milestones",
    "Warnings after the goal",
    "screenTimeWarningPercentages"
)) {
    Assert-Contains $WellbeingAlertsSource $Token "Wellbeing warning UI token missing: $Token"
}
$SmartFlowModelSource = Get-Content -LiteralPath ".\lib\models\smart_flow.dart" -Raw
$SmartFlowControllerSource = Get-Content -LiteralPath ".\lib\controllers\smart_flow_controller.dart" -Raw
$SmartCoachSource = Get-Content -LiteralPath ".\lib\screens\smart_coach_screen.dart" -Raw
$SafetyCenterSource = Get-Content -LiteralPath ".\lib\screens\safety_center_screen.dart" -Raw
$RecommendationsSource = Get-Content -LiteralPath ".\lib\screens\smart_recommendations_screen.dart" -Raw
$WeeklyReportSource = Get-Content -LiteralPath ".\lib\screens\weekly_report_screen.dart" -Raw
$ExperienceSource = Get-Content -LiteralPath ".\lib\screens\experience_settings_screen.dart" -Raw
$RulePreviewSource = Get-Content -LiteralPath ".\lib\widgets\rule_activation_preview.dart" -Raw
$SmartFlowTestSource = Get-Content -LiteralPath ".\test\smart_flow_test.dart" -Raw
$PolicySafetySource = Get-Content -LiteralPath ".\lib\services\policy_safety.dart" -Raw
foreach ($Token in @(
    "ExperienceMode.simple",
    "rulePreviewRequired",
    "userAlwaysAllowedPackages",
    "simpleShortcutIds"
)) {
    Assert-Contains $SmartFlowModelSource $Token "Smart Flow settings token missing: $Token"
}
foreach ($Token in @(
    "hredoy_flow_smart_v1.json",
    "setExperienceMode",
    "recordSafetyStop",
    "SmartFlowScope"
)) {
    Assert-Contains $SmartFlowControllerSource $Token "Smart Flow persistence token missing: $Token"
}
foreach ($Token in @("Today’s top actions", "Quick plan", "Show Daily Coach shortcuts")) {
    Assert-Contains $SmartCoachSource $Token "Daily Coach token missing: $Token"
}
foreach ($Token in @("STOP ALL BLOCKING", "Always allowed", "Require rule preview before save")) {
    Assert-Contains $SafetyCenterSource $Token "Safety Center token missing: $Token"
}
foreach ($Token in @("Recommendation only — never auto-block", "Suggested for review", "essential apps always protected")) {
    Assert-Contains $RecommendationsSource $Token "Smart recommendations token missing: $Token"
}
foreach ($Token in @("Weekly Flow Report", "Daily breakdown", "Share report")) {
    Assert-Contains $WeeklyReportSource $Token "Weekly report token missing: $Token"
}
foreach ($Token in @("Simple & Advanced Mode", "Simple Mode shortcuts", "ExperienceMode.advanced")) {
    Assert-Contains $ExperienceSource $Token "Experience mode token missing: $Token"
}
foreach ($Token in @("Review before activation", "Confirm save", "Apps affected directly")) {
    Assert-Contains $RulePreviewSource $Token "Rule preview token missing: $Token"
}
foreach ($Token in @("defaults to safe Simple Mode", "settings round-trip", "Weekly report text")) {
    Assert-Contains $SmartFlowTestSource $Token "Smart Flow regression test token missing: $Token"
}
foreach ($Token in @(
    "sanitizePhoneControlForAlwaysAllowed",
    "sanitizeProtectionForAlwaysAllowed",
    "studyBlockedPackages",
    "primeBlockedPackages"
)) {
    Assert-Contains $PolicySafetySource $Token "Central always-allowed policy sanitizer token missing: $Token"
}
foreach ($Token in @(
    "always-allowed sanitizer removes every restrictive package reference",
    "always-allowed sanitizer protects Prime Mode and Keep Me Out",
    "always-allowed sanitizer fails open for an all-app Reels window"
)) {
    Assert-Contains $SmartFlowTestSource $Token "Always-allowed sanitizer test token missing: $Token"
}
foreach ($Token in @("List<AlarmPreset>.generate(216", "class AlarmPresetCatalog")) {
    Assert-Contains $AlarmPresetModelSource $Token "216-preset catalog token missing: $Token"
}
Assert-Contains $AlarmPresetScreenSource "Search 216 alarm presets" "Alarm preset search UI is missing."
if ($RootSource -match "IndexedStack") {
    throw "IndexedStack keeps all heavy tabs subscribed and was removed for performance."
}

$DrawerSource = Get-Content -LiteralPath ".\lib\widgets\app_drawer.dart" -Raw
Assert-Contains $DrawerSource "import '../models/smart_flow.dart';" "Drawer must import the ExperienceMode label extension directly."
Assert-Contains $DrawerSource "drawer-profile-shortcut" "Drawer must keep the Profile shortcut visible near the top of Quick Access."
if (([regex]::Matches($DrawerSource, "title:\s+const Text\('Study Quest'\)")).Count -ne 1) {
    throw "Drawer must expose Study Quest exactly once; duplicate navigation was reintroduced."
}
$LogoSource = Get-Content -LiteralPath ".\lib\widgets\app_logo.dart" -Raw
$RoutineSource = Get-Content -LiteralPath ".\lib\data\study_plan.dart" -Raw
$GameSource = Get-Content -LiteralPath ".\lib\models\study_game.dart" -Raw
$GameScreenSource = Get-Content -LiteralPath ".\lib\screens\focus_game_screen.dart" -Raw
$ProfileSource = Get-Content -LiteralPath ".\lib\screens\profile_screen.dart" -Raw
$LayoutRegressionSource = Get-Content -LiteralPath ".\test\layout_regression_test.dart" -Raw
foreach ($Token in @(
    "ProfileAvatar",
    "dragUntilVisible",
    "profile-scroll-view",
    "Exam command center",
    "scrollUntilVisible",
    "drawer-study-quest",
    "drawer-profile-shortcut"
)) {
    Assert-Contains $LayoutRegressionSource $Token "Profile sidebar regression test token missing: $Token"
}
foreach ($Token in @(
    "NavigationDrawer",
    "app-navigation-drawer",
    "Profile",
    "Study Quest",
    "drawer-study-quest",
    "Goals & Targets"
)) {
    Assert-Contains $DrawerSource $Token "Sidebar navigation token missing: $Token"
}
foreach ($Token in @("assets/branding/app_icon.png", "Image.asset", "Hredoy Flow")) {
    Assert-Contains $LogoSource $Token "App-icon wordmark token missing: $Token"
}
foreach ($Token in @(
    "DateTime(2026, 7, 26, 6, 30)",
    "Physical office — five-hour priority work block",
    "300",
    "Purposeful free time",
    "reminderEnabled: true",
    "alarmEnabled: true"
)) {
    Assert-Contains $RoutineSource $Token "Routine restart/no-gap token missing: $Token"
}
foreach ($Token in @("class StudyGameStats", "safeFocus * 3", "safeCompleted * 15")) {
    Assert-Contains $GameSource $Token "Study Quest model token missing: $Token"
}
foreach ($Token in @("Today’s quests", "Level rewards", "Study Quest")) {
    Assert-Contains $GameScreenSource $Token "Study Quest screen token missing: $Token"
}
foreach ($Token in @(
    "Exam command center",
    "Reset generated routine",
    "Study Quest",
    "ProfileAvatar",
    "Choose from gallery",
    "Take a photo",
    "Remove photo",
    "profileImageBase64",
    "profile-scroll-view"
)) {
    Assert-Contains $ProfileSource $Token "Profile command-center/photo token missing: $Token"
}
$ProfileAvatarSource = Get-Content -LiteralPath ".\lib\widgets\profile_avatar.dart" -Raw
foreach ($Token in @("base64Decode", "MemoryImage", "Change profile picture")) {
    Assert-Contains $ProfileAvatarSource $Token "Reusable profile-avatar token missing: $Token"
}
foreach ($Token in @("ProfileAvatar", "profileImageBase64")) {
    Assert-Contains $DrawerSource $Token "Drawer profile-picture token missing: $Token"
}

$TodaySource = Get-Content -LiteralPath ".\lib\screens\today_screen.dart" -Raw
if ([string]::IsNullOrWhiteSpace($TodaySource)) {
    throw "Today screen source could not be loaded for static QA."
}
$ControllerSource = Get-Content -LiteralPath ".\lib\controllers\app_controller.dart" -Raw
$ControllerCrudSource = Get-Content -LiteralPath ".\test\controller_crud_test.dart" -Raw
$PlannerSource = Get-Content -LiteralPath ".\lib\screens\planner_screen.dart" -Raw
if ($TodaySource -notmatch "CustomScrollView" -or $TodaySource -notmatch "SliverList") {
    throw "Today must use lazy slivers for large task collections."
}
if ($PlannerSource -notmatch "CustomScrollView" -or $PlannerSource -notmatch "SliverList") {
    throw "Planner must use lazy slivers for large task collections."
}
if ($TodaySource -match "\bcacheExtent\s*:" -or $PlannerSource -match "\bcacheExtent\s*:") {
    throw "Deprecated cacheExtent was reintroduced."
}
if ($TodaySource -match "ScrollCacheExtent" -or $PlannerSource -match "ScrollCacheExtent") {
    throw "Custom ScrollCacheExtent compatibility code was reintroduced; use Flutter's optimized default cache."
}
Assert-Contains $PlannerSource "FittedBox" "Planner date cells must scale safely on compact screens."
foreach ($Token in @(
    "currentTaskAt",
    "Current action",
    "current-action-card",
    "_SlideShell",
    "_GlassPanel",
    "Image.asset",
    "assets/slider/morning_focus.png",
    "assets/slider/current_action.png",
    "assets/slider/countdown_city.png",
    "assets/slider/study_forest.png",
    "pictureOnly: true",
    "dashboard-visual-slider",
    "Timer.periodic"
)) {
    Assert-Contains $TodaySource $Token "Current-action/full-picture-slider token missing: $Token"
}
if ($TodaySource.Contains("_PictureOrb") -or $TodaySource.Contains("assets/branding/app_icon.png")) {
    throw "Dashboard slider must use full pictures without oversized app-logo artwork."
}
if ($TodaySource.Contains("class _SlidePill")) {
    throw "Obsolete slider pill helper was reintroduced after the full-picture redesign."
}
foreach ($Token in @(
    "currentTaskAt",
    "isActiveAt",
    "endAt"
)) {
    Assert-Contains $ControllerSource $Token "Current-action scheduling token missing: $Token"
}
Assert-Contains $ControllerCrudSource "current action uses the active time window and is not overdue early" "Current-action regression test is missing."
Assert-Contains $LayoutRegressionSource "dashboard visual slides remain overflow-free on a narrow phone" "Narrow visual-slider overflow regression test is missing."
Assert-Contains $LayoutRegressionSource "dashboard-visual-slider" "Dashboard visual-slider test key is missing."
Assert-Contains $TodaySource "visualSliderHeight" "Dashboard visual slider must use adaptive height."
Assert-Contains $TodaySource "screenWidth < 340" "Dashboard visual slider narrow-width height guard is missing."
Assert-Contains $LayoutRegressionSource "greaterThanOrEqualTo(288)" "Narrow-phone slider height regression assertion is missing."

$ProductionUiFiles = Get-ChildItem -LiteralPath ".\lib\screens",".\lib\widgets" -Filter "*.dart" -File -Recurse
foreach ($UiFile in $ProductionUiFiles) {
    $UiSource = Get-Content -LiteralPath $UiFile.FullName -Raw
    if ($UiSource -match '(?i)\b(demo|placeholder|prototype|coming soon|phase\s+[0-9]+)\b') {
        throw "Production UI contains temporary/demo wording: $($UiFile.FullName)"
    }
}

$CommonWidgetsSource = Get-Content -LiteralPath ".\lib\widgets\common_widgets.dart" -Raw
foreach ($Token in @(
    "class MetricCard",
    "LayoutBuilder",
    "constraints.hasBoundedHeight",
    "BoxFit.scaleDown",
    "TextOverflow.ellipsis"
)) {
    Assert-Contains $CommonWidgetsSource $Token "Compact MetricCard safety token missing: $Token"
}

foreach ($Token in @(
    "final int timeOrder = a.startAt.compareTo(b.startAt)",
    "if (timeOrder != 0) return timeOrder"
)) {
    Assert-Contains $ControllerSource $Token "Chronological task sorting token missing: $Token"
}
foreach ($Token in @(
    "daily routine is ordered strictly by start time, not subject or priority",
    "early-break",
    "middle-work",
    "late-study"
)) {
    Assert-Contains $ControllerCrudSource $Token "Chronological routine regression test token missing: $Token"
}
Assert-Contains $ControllerCrudSource "completedAt: DateTime(2026, 7, 24, 9, 40)" "Completed chronological test task must use TaskItem.completedAt."
if ($ControllerCrudSource -match "\bisCompleted\s*:") {
    throw "TaskItem has no isCompleted constructor parameter; use completedAt in tests."
}

foreach ($RequiredToken in @(
    "_tasksByDate",
    "_pendingTasksByDate",
    "_taskCompletedByDate",
    "_focusMinutesByDate",
    "taskCountForSubject",
    "_scheduleSave",
    "_pendingSaveSnapshot",
    "flushPendingWrites",
    "_pendingNativeSnapshot",
    "_queueNativeReschedule",
    "_firstTaskAfter"
)) {
    Assert-Contains $ControllerSource $RequiredToken "Controller performance guard missing: $RequiredToken"
}


$StudyPlanSource = Get-Content -LiteralPath ".\lib\data\study_plan.dart" -Raw
$AppDataTestSource = Get-Content -LiteralPath ".\test\app_data_test.dart" -Raw
foreach ($Token in @(
    "static const int currentDataVersion = 7",
    "version: currentDataVersion"
)) {
    Assert-Contains $StudyPlanSource $Token "Schema-version source token missing: $Token"
}
foreach ($Token in @(
    "DateTime(2026, 7, 26, 6, 30)",
    "routine-20260726-r4-",
    "final DateTime firstDay = DateTime(start.year, start.month, start.day)",
    "DateTime day = firstDay"
)) {
    Assert-Contains $StudyPlanSource $Token "26 July routine restart guard missing: $Token"
}
if ($StudyPlanSource -match "DateTime\(2026, 7, 23, 21\)") {
    throw "The retired 23 July 9:00 PM routine anchor was reintroduced."
}
Assert-Contains $AppDataTestSource "StudyPlan.currentDataVersion" "Seed-data test must use the centralized schema version."
Assert-Contains $AppDataTestSource "expect(StudyPlan.currentDataVersion, 7)" "Seed-data migration expectation must match schema version 7."
if ($AppDataTestSource -match "expect\(data\.version,\s*4\)") {
    throw "Stale schema-version 4 expectation was reintroduced."
}
foreach ($Token in @(
    "_data.version < StudyPlan.currentDataVersion",
    "version: StudyPlan.currentDataVersion",
    "imported.version < StudyPlan.currentDataVersion"
)) {
    Assert-Contains $ControllerSource $Token "Controller schema-version token missing: $Token"
}

$MainSource = Get-Content -LiteralPath ".\lib\main.dart" -Raw
foreach ($Token in @("HredoyFlowBootstrap", "_FastStartupScreen", "flushPendingWrites")) {
    Assert-Contains $MainSource $Token "Fast-start/lifecycle token missing: $Token"
}

$NativeBridgeSource = Get-Content -LiteralPath ".\lib\services\native_bridge.dart" -Raw
foreach ($Token in @("extension LaunchableAppCategory", "categoryLabel", "matchesCategoryFilter")) {
    Assert-Contains $NativeBridgeSource $Token "Central app-category token missing: $Token"
}
if ($NativeBridgeSource.Contains("import 'dart:typed_data';")) {
    throw "native_bridge.dart must rely on flutter/services.dart for Uint8List; the redundant dart:typed_data import was reintroduced."
}
$FocusScreenSource = Get-Content -LiteralPath ".\lib\screens\focus_screen.dart" -Raw
$FocusHubSource = Get-Content -LiteralPath ".\lib\screens\focus_hub_screen.dart" -Raw
foreach ($Token in @(
    "getSystemReadiness",
    "listLaunchableApps",
    "setKeepScreenOn",
    "requestBatteryOptimizationExemption",
    "pickProfileImage",
    "captureProfileImage",
    "phoneControlPolicy",
    "savePhoneControlPolicy",
    "phoneControlUsage",
    "phoneControlDashboard",
    "getPhoneControlDashboard",
    "scheduleProfileRuntime",
    "requestScheduleProfileUnlock",
    "cancelScheduleProfileUnlock",
    "openUsageAccessSettings",
    "openNotificationAccessSettings",
    "socialControlSnapshot",
    "clearNotificationHistory",
    "runPhoneControlSafeSetup",
    "emergencyStopAllBlocking",
    "suggestedForReview"
)) {
    Assert-Contains $NativeBridgeSource $Token "Native readiness/profile token missing: $Token"
}
$MainActivitySource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\MainActivity.kt" -Raw
foreach ($Token in @(
    "REQUEST_PROFILE_GALLERY",
    "REQUEST_PROFILE_CAMERA",
    "decodeAndCompressProfileImage",
    "PROFILE_IMAGE_OUTPUT_SIDE = 720"
)) {
    Assert-Contains $MainActivitySource $Token "Native profile-image token missing: $Token"
}
foreach ($Token in @(
    "getPhoneControlPolicy",
    "savePhoneControlPolicy",
    "getPhoneControlUsage",
    "getPhoneControlDashboard",
    "PHONE_CONTROL_DASHBOARD_ERROR",
    "getScheduleProfileRuntime",
    "requestScheduleProfileUnlock",
    "cancelScheduleProfileUnlock",
    "resetPhoneControlUsage",
    "ACTION_USAGE_ACCESS_SETTINGS",
    "usageAccessEnabled",
    "notificationAccessEnabled",
    "getSocialControlSnapshot",
    "clearNotificationHistory",
    "openNotificationAccessSettings",
    "runPhoneControlSafeSetup",
    "emergencyStopAllBlocking",
    "AppSafetyClassifier.classify",
    "SafetyBootstrap.apply"
)) {
    Assert-Contains $MainActivitySource $Token "Native Phone Control channel token missing: $Token"
}
foreach ($Token in @("ProfileAvatar", "profileImageBase64", "ProfileScreen")) {
    Assert-Contains $TodaySource $Token "Dashboard profile-picture token missing: $Token"
}
Assert-Contains $FocusScreenSource "setKeepScreenOn(true)" "Focus screen must keep the display awake while visible."
Assert-Contains $FocusScreenSource "setKeepScreenOn(false)" "Focus screen must release the display flag on exit."
foreach ($Token in @("Finish Focus Shield setup", "Accessibility App Blocker is OFF", "blockedPackages.isEmpty")) {
    Assert-Contains $FocusHubSource $Token "Protected-focus setup guard missing: $Token"
}

$PhoneControlModelSource = Get-Content -LiteralPath ".\lib\models\phone_control.dart" -Raw
$PhoneControlScreenSource = Get-Content -LiteralPath ".\lib\screens\phone_control_screen.dart" -Raw
$PhoneControlDashboardSource = Get-Content -LiteralPath ".\lib\screens\phone_control_dashboard_screen.dart" -Raw
$ActiveFeaturesSource = Get-Content -LiteralPath ".\lib\screens\active_features_screen.dart" -Raw
$FocusTreeSource = Get-Content -LiteralPath ".\lib\widgets\focus_tree.dart" -Raw
foreach ($Token in @(
    "_drawBackgroundForest",
    "_drawMountains",
    "final Rect pond",
    "_drawFireflies",
    "_drawBirds",
    "Forest"
)) {
    Assert-Contains $FocusTreeSource $Token "Focus Forest visual token missing: $Token"
}
$PhoneControlTestSource = Get-Content -LiteralPath ".\test\phone_control_test.dart" -Raw
$PhoneControlDashboardTestSource = Get-Content -LiteralPath ".\test\phone_control_dashboard_test.dart" -Raw
$ScheduleProfilesSource = Get-Content -LiteralPath ".\lib\screens\schedule_profiles_screen.dart" -Raw
$ScheduleProfilesTestSource = Get-Content -LiteralPath ".\test\schedule_profiles_test.dart" -Raw
$SocialControlSource = Get-Content -LiteralPath ".\lib\screens\social_control_screen.dart" -Raw
$SocialControlTestSource = Get-Content -LiteralPath ".\test\social_control_test.dart" -Raw
$StudyModeSource = Get-Content -LiteralPath ".\lib\screens\study_mode_screen.dart" -Raw
$StudyModeTestSource = Get-Content -LiteralPath ".\test\study_mode_test.dart" -Raw
$CommonWidgetsSource = Get-Content -LiteralPath ".\lib\widgets\common_widgets.dart" -Raw
$NativePhoneModelsSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\PhoneControlModels.kt" -Raw
$NativePhoneStoreSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\PhoneControlStore.kt" -Raw
$UsageTimelineSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\UsageTimeline.kt" -Raw
$UsageTimelineTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\UsageTimelineTest.kt" -Raw
$PhoneControlRuleScheduleTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\PhoneControlRuleScheduleTest.kt" -Raw
$PhoneControlWellbeingTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\PhoneControlWellbeingTest.kt" -Raw
$NativePhoneEngineSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\PhoneControlEngine.kt" -Raw
$PhoneControlCommitmentTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\PhoneControlCommitmentTest.kt" -Raw
foreach ($Token in @("Study Schedule", "Fixed Reels Budget", "globalReelsWindowActive", "globalReelsWindowApplies")) {
    Assert-Contains $NativePhoneEngineSource $Token "Native Study/Reels decision token missing: $Token"
}
foreach ($Token in @("enforceCommitmentWindows", "minimumCommitmentMinutes", "KEY_GLOBAL_REELS_WINDOW_COUNT")) {
    Assert-Contains $NativePhoneStoreSource $Token "Native commitment/window persistence token missing: $Token"
}
foreach ($Token in @("minimumCommitmentUsesAtLeastTwentyPercent", "automaticStudyScheduleSupportsOvernightWindows", "fixedReelsWindowCanTargetOneAppOrAllApps")) {
    Assert-Contains $PhoneControlCommitmentTestSource $Token "Native smart-limit test missing: $Token"
}
$AccessibilitySource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\FocusAccessibilityService.kt" -Raw
$ReelGateSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\ReelTransitionGate.kt" -Raw
$ReelFingerprintSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\ReelFingerprint.kt" -Raw
$ReelPagerHeuristicsSource = Get-Content -LiteralPath ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter\ReelPagerHeuristics.kt" -Raw
$ReelGateTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\ReelTransitionGateTest.kt" -Raw
$ReelFingerprintTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\ReelFingerprintTest.kt" -Raw
$ReelPagerHeuristicsTestSource = Get-Content -LiteralPath ".\android\app\src\test\kotlin\com\hredoy\focus_guard_flutter\ReelPagerHeuristicsTest.kt" -Raw
$AndroidAppBuildSource = Get-Content -LiteralPath ".\android\app\build.gradle.kts" -Raw
foreach ($Token in @(
    "class AppControlRule",
    "class ScheduleProfile",
    "class ScheduleProfileRuntime",
    "class PhoneControlPolicy",
    "class PhoneControlUsage",
    "class PhoneControlDayUsage",
    "class PhoneControlDashboardSnapshot",
    "distractionRatio",
    "weeklyDistractionMillis",
    "isAllowedAt",
    "activeFeatureCount",
    "scheduleProfilesEnabled",
    "activeProfilesFor",
    "overlapsWith",
    "reelsBlockerEnabled",
    "scrollLimitEnabled",
    "notificationBlockerEnabled",
    "notificationPackages",
    "notificationScheduleEnabled",
    "notificationHistoryLimit",
    "blockReelsImmediately",
    "reelsDailyLimit",
    "reelsTimeLimitMinutes",
    "reelsViewed",
    "reelsWatchMillis",
    "studyModeEnabled",
    "blockApp",
    "studyBlockedPackages",
    "studySilenceNotifications",
    "studyDefaultMinutes",
    "studyDailyGoalMinutes",
    "studyScheduleEnabled",
    "studyScheduleActiveAt",
    "focusUsesStudyRules",
    "globalReelsWindowEnabled",
    "globalReelsWindowLimit",
    "commitmentLockedUntilMillis",
    "minimumCommitmentMinutes",
    "class SocialControlSnapshot",
    "class NotificationHistoryItem",
    "silenceNotifications"
)) {
    Assert-Contains $PhoneControlModelSource $Token "Phone Control model token missing: $Token"
}
foreach ($Token in @(
    "Phone Control active",
    "Auto Safe Setup",
    "Run safe setup",
    "Stop all blocking",
    "Blocked by you",
    "Only apps you selected can be blocked",
    "Schedule Blocker",
    "Daily App Limits",
    "Reels & Shorts Guard",
    "Scroll Limit",
    "Daily app minutes",
    "Daily short-video count",
    "Daily short-video minutes",
    "Daily scroll gestures",
    "Block every Reel/Short immediately",
    "Fixed Reels / Shorts budget",
    "All supported short-video apps",
    "Minimum commitment",
    "Distracting",
    "Social",
    "Video",
    "Games",
    "Useful",
    "Education",
    "Normal / safe",
    "Rule locked until commitment ends",
    "phone-control-scroll-view"
)) {
    Assert-Contains $PhoneControlScreenSource $Token "Phone Control UI token missing: $Token"
}

foreach ($Token in @(
    "automatic Study schedule supports same-day and overnight windows",
    "fixed Reels window applies to all or selected apps and round-trips",
    "app commitment uses at least twenty percent",
    "alarm preset catalog contains 216 unique ready presets",
    "installed apps expose precise distraction and safe category filters"
)) {
    Assert-Contains $PhoneControlTestSource $Token "Smart-limit regression test missing: $Token"
}
foreach ($Token in @(
    "Run Study Mode automatically",
    "Use the same rules in Focus sessions",
    "Apps blocked during Study & Focus"
)) {
    Assert-Contains $StudyModeSource $Token "Automatic Study Mode token missing: $Token"
}

foreach ($Token in @(
    "Total screen time",
    "Controlled-app time",
    "12:00 AM to now",
    "Reduce distraction",
    "Distraction trend",
    "phone-control-master-button",
    "phone-control-weekly-chart",
    "PhoneControlTrendChart",
    "phone-control-dashboard-scroll",
    "Search commands",
    "CommandSearchScreen"
)) {
    Assert-Contains $PhoneControlDashboardSource $Token "Premium Phone Control dashboard token missing: $Token"
}
foreach ($Token in @(
    "Phone Features",
    "Master Phone Control",
    "BLOCKING & LIMITS",
    "STUDY & FOCUS",
    "WEB & HARDCORE PROTECTION",
    "Notification Blocker",
    "Protection Center",
    "Local DNS, custom domains, adult protection, Prime Mode and Keep Me Out",
    "active-features-scroll-view"
)) {
    Assert-Contains $ActiveFeaturesSource $Token "Live feature-center token missing: $Token"
}
foreach ($Token in @(
    "PhoneControlDashboardScreen",
    "title: 'Phone Control'",
    "ScheduleProfilesScreen",
    "title: 'Schedule Profiles'",
    "SocialControlScreen",
    "title: 'Social & Notifications'",
    "StudyModeScreen",
    "title: 'Study Mode'"
)) {
    Assert-Contains $MoreScreenSource $Token "More-screen production navigation token missing: $Token"
}
Assert-Contains $DrawerSource "PhoneControlDashboardScreen" "Drawer must open the premium Phone Control dashboard."
Assert-Contains $DrawerSource "ScheduleProfilesScreen" "Drawer must open recurring Schedule Profiles."
Assert-Contains $MoreScreenSource "ScheduleProfilesScreen" "More screen must open recurring Schedule Profiles."
foreach ($Token in @(
    "Schedule Profiles",
    "Student Focus",
    "Night Detox",
    "Productive Work",
    "Emergency unlock",
    "block-wins",
    "schedule-profiles-scroll-view",
    "schedule-profile-editor-scroll",
    "Save schedule profile"
)) {
    Assert-Contains $ScheduleProfilesSource $Token "Schedule Profiles UI token missing: $Token"
}
foreach ($Token in @(
    "recurring profile activates on selected days and supports overnight",
    "overlap resolution detects shared apps",
    "policy round-trip preserves old app rules and new schedule profiles",
    "legacy policy without profiles remains valid",
    "emergency unlock runtime parses native status safely"
)) {
    Assert-Contains $ScheduleProfilesTestSource $Token "Schedule Profiles regression test token missing: $Token"
}
if ($ScheduleProfilesTestSource -match "\d_\d") {
    throw "Schedule Profile tests must avoid numeric digit separators because the project language floor is Dart 3.4."
}

foreach ($Token in @(
    "Social & Notifications",
    "Notification Blocker",
    "Reels & Shorts Guard",
    "Blocked notification history",
    "openNotificationAccessSettings",
    "socialControlSnapshot",
    "notificationPackages",
    "Notification blocking schedule",
    "History retention",
    "Reels viewed",
    "No Reel count limit"
)) {
    Assert-Contains $SocialControlSource $Token "Social-control UI token missing: $Token"
}
foreach ($Token in @(
    "social-control policy round-trip preserves notification controls",
    "social snapshot parses local counters and notification history",
    "legacy policy defaults social controls to disabled",
    "notification schedule supports same-day and overnight quiet windows"
)) {
    Assert-Contains $SocialControlTestSource $Token "Social-control regression test token missing: $Token"
}

foreach ($Token in @(
    "Study Mode",
    "Dashboard",
    "Subjects",
    "Tasks",
    "Goals",
    "Insights",
    "Setup",
    "Manual block list only",
    "Apps to block during Study Mode",
    "Silence notifications",
    "Daily study goal",
    "30-day study heatmap",
    "Productivity score",
    "Start a protected session"
)) {
    Assert-Contains $StudyModeSource $Token "Study Mode token missing: $Token"
}
foreach ($Token in @(
    "Study Mode policy round-trip preserves protection settings",
    "section header stacks its action on a narrow phone width",
    "Notification Blocker",
    "Choose apps"
)) {
    Assert-Contains $StudyModeTestSource $Token "Study Mode regression test token missing: $Token"
}
foreach ($Token in @(
    "LayoutBuilder",
    "constraints.maxWidth < 430",
    "Align(alignment: Alignment.centerLeft"
)) {
    Assert-Contains $CommonWidgetsSource $Token "Responsive SectionHeader token missing: $Token"
}
foreach ($Token in @(
    "blockReelsImmediately",
    "reelsDailyLimit",
    "reelsTimeLimitMinutes",
    "notificationScheduleEnabled",
    "blockApp",
    "studyBlockedPackages",
    "studySilenceNotifications"
)) {
    Assert-Contains $NativePhoneModelsSource $Token "Native policy token missing: $Token"
}
foreach ($Token in @(
    "recordReelViewed",
    "recordReelWatch",
    "reelsViewed",
    "reelsWatchMillis",
    "notificationWindowActive",
    "focusActive"
)) {
    Assert-Contains $NativePhoneStoreSource $Token "Native limit/storage token missing: $Token"
}
foreach ($Token in @(
    "blocked by your Study Mode list",
    "Blocked by you",
    "viewed >= rule.reelsDailyLimit",
    "reelsTimeLimitMinutes"
)) {
    Assert-Contains $NativePhoneEngineSource $Token "Native enforcement token missing: $Token"
}
foreach ($Token in @(
    "trackReelActivity",
    "scheduleReelFingerprintVerification",
    "ReelFingerprintBuilder.capture",
    "reelTransitionGate.enter",
    "reelTransitionGate.confirmSettledCandidate",
    "PhoneControlEngine.reelPagerEvidence",
    "REEL_PAGER_BURST_GAP_MILLIS",
    "fallbackToken",
    "recordReelViewed",
    "HredoyReelCounter",
    "recordReelWatch"
)) {
    Assert-Contains $AccessibilitySource $Token "Accessibility hybrid Reel tracking token missing: $Token"
}
if ($AccessibilitySource.Contains("reelTransitionGate.onScroll")) {
    throw "Accessibility callbacks must not increment the Reel counter directly."
}
foreach ($Token in @(
    "class ReelTransitionGate",
    "initialDwellMillis",
    "minimumTransitionGapMillis",
    "confirmSettledCandidate",
    "ReelConfirmationSource.PAGER_FALLBACK",
    "ReelConfirmationSource.INITIAL_ENTRY",
    "cleanFallbackToken != lastAcceptedFallbackToken",
    "now - lastAcceptedAt < minimumTransitionGapMillis"
)) {
    Assert-Contains $ReelGateSource $Token "Hybrid Reel transition gate token missing: $Token"
}
foreach ($Token in @(
    "object ReelFingerprintBuilder",
    "privacy-safe identity fingerprint",
    "normalizeIdentityToken",
    "identityViewHints",
    "ignoredViewHints",
    "MessageDigest",
    "identityTokenCount"
)) {
    Assert-Contains $ReelFingerprintSource $Token "Reel fingerprint token missing: $Token"
}
foreach ($Token in @(
    "reelPagerEvidence",
    "isLikelyReelPagerEvent",
    "nonPagerScrollHints",
    "fillsMostOfScreen",
    "largeVerticalDelta",
    "strongRouteSource",
    "source == null",
    "ReelPagerHeuristics.confirmationReason"
)) {
    Assert-Contains $NativePhoneEngineSource $Token "Reel pager-event filter token missing: $Token"
}
foreach ($Token in @(
    "object ReelPagerHeuristics",
    "routeConfirmed",
    "nonPagerSurface",
    "sourceMissing",
    "largeVerticalDelta"
)) {
    Assert-Contains $ReelPagerHeuristicsSource $Token "Reel pager heuristic token missing: $Token"
}
foreach ($Token in @(
    "first reel counts only after two stable snapshots and initial dwell",
    "noisy callbacks and repeated snapshots never duplicate a reel",
    "only a different stable reel identity counts after settle gap",
    "initial Reel entry counts after dwell when identity text is hidden",
    "clustered pager fallback counts once when fingerprints are unavailable",
    "new pager candidate counts when apps expose only a static fingerprint",
    "fallback candidates inside minimum settle gap are rejected"
)) {
    Assert-Contains $ReelGateTestSource $Token "Hybrid Reel transition regression test missing: $Token"
}
foreach ($Token in @(
    "hidden event source still accepts a large Reel pager transition",
    "comment and caption surfaces are always rejected",
    "small nested scroll without pager evidence is rejected",
    "unconfirmed route never becomes a Reel transition"
)) {
    Assert-Contains $ReelPagerHeuristicsTestSource $Token "Reel pager heuristic regression test missing: $Token"
}
foreach ($Token in @(
    "dynamic counters and timestamps are removed from identity tokens",
    "same reel tokens produce the same fingerprint regardless of callback order",
    "different reel identity text produces a different fingerprint"
)) {
    Assert-Contains $ReelFingerprintTestSource $Token "Reel fingerprint regression test missing: $Token"
}
Assert-Contains $NativePhoneStoreSource "REEL_COUNTER_SCHEMA_VERSION = 3" "Hybrid Reel counter migration version must remain 3."
Assert-Contains $ReelsInsightsSource "Hybrid confirmed-count mode is active" "Hybrid Reel counter explanation is missing from the UI."
Assert-Contains $AndroidAppBuildSource 'kotlin {' "Built-in Kotlin compilerOptions DSL is missing from android/app/build.gradle.kts."
Assert-Contains $AndroidAppBuildSource 'compilerOptions {' "Built-in Kotlin compilerOptions configuration is missing."

foreach ($Token in @(
    "class FocusTree",
    "_FocusForestPainter",
    "Live focus tree growing with study time",
    "study-quest-tree"
)) {
    $TargetSource = if ($Token -eq "study-quest-tree") { $GameScreenSource } elseif ($Token -eq "Live focus tree growing with study time") { $FocusScreenSource } else { $FocusTreeSource }
    Assert-Contains $TargetSource $Token "Focus-tree token missing: $Token"
}
foreach ($Token in @(
    "same-day schedule allows only selected weekdays",
    "overnight schedule carries access",
    "policy round-trip preserves schedule",
    "new app rules are fail-open",
    "configured schedule remains fail-open until schedule blocking is enabled",
    "study mode stores an explicit block list",
    "focus tree renders safely"
)) {
    Assert-Contains $PhoneControlTestSource $Token "Phone Control regression test token missing: $Token"
}

foreach ($Token in @(
    "dashboard snapshot parses actual weekly distraction metrics",
    "weekly distraction chart renders on a compact phone width",
    "phone-control-weekly-chart",
    "5400000"
)) {
    Assert-Contains $PhoneControlDashboardTestSource $Token "Phone Control dashboard regression test token missing: $Token"
}
if ($PhoneControlTestSource -match "\d_\d") {
    throw "Phone Control tests must avoid numeric digit separators because the project language floor is Dart 3.4."
}
foreach ($Token in @("7200000", "9000000")) {
    Assert-Contains $PhoneControlTestSource $Token "Phone Control usage fixture compatibility token missing: $Token"
}
foreach ($Token in @(
    "configuredScheduleIsFailOpenUntilRestrictionIsEnabled",
    "blockOutsideSchedule = true",
    "sameDayScheduleUsesSelectedWeekdaysAndTimeWindow",
    "overnightScheduleCarriesIntoTheFollowingCalendarDay"
)) {
    Assert-Contains $PhoneControlRuleScheduleTestSource $Token "Native Phone Control schedule regression token missing: $Token"
}
foreach ($Token in @(
    "reelsMilestonesRoundTripPerApp",
    "screenTimeWarningSettingsRoundTrip",
    "setOf(50, 75, 100)",
    "screenTimeRepeatMinutes = 45"
)) {
    Assert-Contains $PhoneControlWellbeingTestSource $Token "Native wellbeing regression token missing: $Token"
}

$ModelsSource = Get-Content -LiteralPath ".\lib\models\app_models.dart" -Raw
$IconCatalogSource = Get-Content -LiteralPath ".\lib\models\app_icon_catalog.dart" -Raw
$SoundModelSource = Get-Content -LiteralPath ".\lib\models\alarm_sounds.dart" -Raw
if ($ModelsSource -match "IconData\s*\(\s*iconCodePoint") {
    throw "Runtime IconData construction breaks profile/release icon tree shaking."
}
foreach ($Token in @(
    "abstract final class AppIconCatalog",
    "static const List<IconData> supported",
    "static IconData resolve",
    "Icons.menu_book_rounded",
    "Icons.check_circle_rounded"
)) {
    Assert-Contains $IconCatalogSource $Token "Tree-shake-safe icon catalog token missing: $Token"
}
foreach ($Token in @(
    "alarmSoundId",
    "alarmSoundLabel",
    "alarmSoundUri",
    "defaultAlarmSoundId",
    "defaultAlarmSoundUri"
)) {
    Assert-Contains $ModelsSource $Token "Persisted alarm-sound model field missing: $Token"
}
foreach ($Token in @(
    "builtInSoundCount = 216",
    "List<AlarmSoundPreset>.generate(200",
    'tone_${number.toString().padLeft(3, ''0'')}'
)) {
    Assert-Contains $SoundModelSource $Token "216-sound catalog token missing: $Token"
}

$StoreSource = Get-Content -LiteralPath ".\lib\services\local_store.dart" -Raw
if ($StoreSource -notmatch "Isolate\.run" -or
    $StoreSource -notmatch "hredoy_flow_data_v3\.backup" -or
    $StoreSource -notmatch "encodeAsync" -or
    $StoreSource -notmatch "_decodeAppData") {
    throw "Large-data isolate, asynchronous export, or recovery backup support is missing."
}
if ($StoreSource -notmatch "Future<AppData>\.sync") {
    throw "Small backup decode errors must be delivered asynchronously through the returned Future."
}

$GradleSource = Get-Content -LiteralPath ".\android\app\build.gradle.kts" -Raw
$RootGradleSource = Get-Content -LiteralPath ".\android\build.gradle.kts" -Raw
$GradleSettingsSource = Get-Content -LiteralPath ".\android\settings.gradle.kts" -Raw
$GradleProperties = Get-Content -LiteralPath ".\android\gradle.properties" -Raw
Assert-Contains $GradleSettingsSource 'id("com.android.application") version "9.0.1" apply false' "AGP 9.0.1 must remain declared in the root plugins block."
Assert-Contains $GradleProperties 'android.builtInKotlin=true' "AGP 9 built-in Kotlin must be explicitly enabled."
Assert-Contains $GradleProperties 'android.newDsl=false' "Flutter 3.44 Android DSL compatibility flag is missing."
if ($GradleSettingsSource -match 'id\("kotlin-android"\)' -or
    $GradleSettingsSource -match 'id\("org\.jetbrains\.kotlin\.android"\)' -or
    $GradleSource -match 'id\("kotlin-android"\)' -or
    $GradleSource -match 'id\("org\.jetbrains\.kotlin\.android"\)') {
    throw "Legacy Kotlin Gradle Plugin was reintroduced in Android Gradle configuration."
}
if ($GradleProperties -match "android\.builtInKotlin=false") {
    throw "Built-in Kotlin migration was reverted."
}
Assert-Contains $GradleSource 'kotlin {' "Built-in Kotlin compilerOptions DSL is missing from the app module."
Assert-Contains $GradleSource 'compilerOptions {' "Built-in Kotlin compilerOptions configuration is missing from the app module."

$KotlinDir = ".\android\app\src\main\kotlin\com\hredoy\focus_guard_flutter"
$MainActivitySource = Get-Content -LiteralPath "$KotlinDir\MainActivity.kt" -Raw
$NativeTaskSource = Get-Content -LiteralPath "$KotlinDir\NativeTask.kt" -Raw
$AlarmServiceSource = Get-Content -LiteralPath "$KotlinDir\TaskAlarmService.kt" -Raw
$AlarmCatalogSource = Get-Content -LiteralPath "$KotlinDir\AlarmSoundCatalog.kt" -Raw
foreach ($Token in @(
    "pickSystemAlarmSound",
    "pickCustomAlarmSound",
    "ACTION_OPEN_DOCUMENT",
    "takePersistableUriPermission",
    "previewAlarmSound"
)) {
    Assert-Contains $MainActivitySource $Token "Android sound-picker token missing: $Token"
}
foreach ($Token in @("alarmSoundId", "alarmSoundLabel", "alarmSoundUri")) {
    Assert-Contains $NativeTaskSource $Token "Native task sound field missing: $Token"
}
Assert-Contains $AlarmServiceSource "AlarmSoundCatalog.candidateUris" "Alarm service is not using per-task ringtone selection."
Assert-Contains $AlarmCatalogSource "smartPreset" "Smart category-to-ringtone mapping is missing."

$AlarmSchedulerSource = Get-Content -LiteralPath "$KotlinDir\AlarmScheduler.kt" -Raw
if ($AlarmSchedulerSource -notmatch "forceReschedule" -or
    $AlarmSchedulerSource -notmatch "previousTask != task" -or
    $AlarmSchedulerSource -notmatch "snoozed.triggerAtMillis") {
    throw "Incremental native alarm scheduling or fresh-sound snooze merge guard is missing."
}

$ReminderReceiverSource = Get-Content -LiteralPath "$KotlinDir\ReminderReceiver.kt" -Raw
$AccessibilitySource = Get-Content -LiteralPath "$KotlinDir\FocusAccessibilityService.kt" -Raw
$PhoneControlModelsSource = Get-Content -LiteralPath "$KotlinDir\PhoneControlModels.kt" -Raw
$PhoneControlStoreSource = Get-Content -LiteralPath "$KotlinDir\PhoneControlStore.kt" -Raw
$PhoneControlEngineSource = Get-Content -LiteralPath "$KotlinDir\PhoneControlEngine.kt" -Raw
$NotificationsSource = Get-Content -LiteralPath "$KotlinDir\Notifications.kt" -Raw
$NotificationChannelsSource = Get-Content -LiteralPath "$KotlinDir\NotificationChannels.kt" -Raw
foreach ($Token in @(
    "reelsWarningPercentages",
    "wellbeingWarningsEnabled",
    "screenTimeGoalMinutes",
    "screenTimeWarningPercentages",
    "screenTimeRepeatMinutes",
    "detailedWarningNotifications"
)) {
    Assert-Contains $PhoneControlModelsSource $Token "Native wellbeing model token missing: $Token"
}
foreach ($Token in @(
    "maybeShowReelsProgressWarning",
    "maybeShowScreenTimeWarning",
    "markWarningOnce",
    "KEY_WARNING_MARKERS",
    "SCREEN_WARNING_CHECK_INTERVAL_MILLIS"
)) {
    Assert-Contains $PhoneControlStoreSource $Token "Native wellbeing notification trigger missing: $Token"
}
foreach ($Token in @("showReelsProgress", "showScreenTimeWarning", "BigTextStyle", "CATEGORY_REMINDER")) {
    Assert-Contains $NotificationsSource $Token "Detailed wellbeing notification token missing: $Token"
}
Assert-Contains $NotificationChannelsSource 'WELLBEING = "hredoy_flow_wellbeing_v1"' "Wellbeing notification channel is missing."
$NotificationControlSource = Get-Content -LiteralPath "$KotlinDir\NotificationControlService.kt" -Raw
$PhoneControlSafetySource = Get-Content -LiteralPath "$KotlinDir\PhoneControlSafety.kt" -Raw
$AppSafetyClassifierSource = Get-Content -LiteralPath "$KotlinDir\AppSafetyClassifier.kt" -Raw
$SafetyBootstrapSource = Get-Content -LiteralPath "$KotlinDir\SafetyBootstrap.kt" -Raw
$EmergencyUnlockSource = Get-Content -LiteralPath ".\EMERGENCY_UNLOCK_PHONE.ps1" -Raw
$AccessibilityConfig = Get-Content -LiteralPath ".\android\app\src\main\res\xml\accessibility_service_config.xml" -Raw
$ManifestSource = Get-Content -LiteralPath ".\android\app\src\main\AndroidManifest.xml" -Raw
foreach ($Token in @("setAlarmClock", "setExactAndAllowWhileIdle", "setAndAllowWhileIdle")) {
    Assert-Contains $AlarmSchedulerSource $Token "Locked-screen alarm scheduling token missing: $Token"
}
foreach ($Token in @("PARTIAL_WAKE_LOCK", "goAsync", "startForegroundService")) {
    Assert-Contains $ReminderReceiverSource $Token "Alarm delivery wake token missing: $Token"
}
foreach ($Token in @("alarmWakeLock", "START_REDELIVER_INTENT", "MAX_WAKE_LOCK_MILLIS", "launchAlarmUi(task)", "FLAG_ACTIVITY_NO_USER_ACTION")) {
    Assert-Contains $AlarmServiceSource $Token "Active alarm reliability token missing: $Token"
}
foreach ($Token in @(
    "TYPE_WINDOWS_CHANGED",
    "TYPE_VIEW_SCROLLED",
    "rootInActiveWindow",
    "GLOBAL_ACTION_HOME",
    "PhoneControlEngine.decision",
    "recordScroll",
    "recordUsage",
    "SafetyBootstrap.apply",
    "updateForeground(foregroundPackage, now)",
    "BLOCK_THROTTLE_MILLIS",
    "HOME_ACTION_COOLDOWN_MILLIS",
    'currentPackage = ""',
    "activePackage == foregroundPackage",
    "USAGE_TICK_MILLIS"
)) {
    Assert-Contains $AccessibilitySource $Token "Focus/Phone Control enforcement token missing: $Token"
}
foreach ($Token in @(
    "data class AppControlRule",
    "data class ScheduleProfile",
    "data class PhoneControlPolicy",
    "scheduleProfilesEnabled",
    "activeProfilesFor",
    "isActiveAt",
    "isAllowedAt",
    "allowedWeekdays",
    "notificationBlockerEnabled",
    "notificationPackages",
    "blockApp",
    "studyBlockedPackages",
    "silenceNotifications"
)) {
    Assert-Contains $PhoneControlModelsSource $Token "Native Phone Control model token missing: $Token"
}
foreach ($Token in @(
    "class PhoneControlStore",
    "PhoneUsageStats",
    "queryAndAggregateUsageStats",
    "queryEvents",
    "UsageEvents",
    "UsageTimeline.calculate",
    "startOfDayMillis",
    "screenTimeWindowStartMillis",
    "accessibility_fallback",
    "phone_control_policy_v1",
    "systemUsageMillis",
    "dashboardSnapshot",
    "profileRuntimeSnapshot",
    "requestEmergencyUnlock",
    "cancelEmergencyUnlock",
    "phone_control_profile_unlock_until",
    "weeklyUsage",
    "distractionTimeMillis",
    "clearDisplayCounters",
    "recordReelsBlocked",
    "recordNotificationBlocked",
    "shouldBlockNotification",
    "socialSnapshot",
    "phone_control_notification_history"
)) {
    Assert-Contains $PhoneControlStoreSource $Token "Native Phone Control store token missing: $Token"
}
if ($PhoneControlStoreSource -match 'fun\s+resetToday\s*\(') {
    throw "A user-triggered daily usage reset was reintroduced; limits must roll over only at local midnight."
}
if ($PhoneControlStoreSource -match 'phone_control_usage_baseline') {
    # The one-time literal removal is allowed only as migration cleanup.
    $BaselineOccurrences = ([regex]::Matches($PhoneControlStoreSource, 'phone_control_usage_baseline')).Count
    if ($BaselineOccurrences -ne 1 -or $PhoneControlStoreSource -notmatch '\.remove\("phone_control_usage_baseline"\)') {
        throw "Screen-time baseline subtraction was reintroduced."
    }
}
foreach ($Token in @(
    "object UsageTimeline",
    "UsageTransitionType.FOREGROUND",
    "UsageTransitionType.BACKGROUND",
    "UsageTransitionType.SCREEN_OFF",
    "totalScreenTimeMillis = total.coerceIn",
    "windowStartMillis"
)) {
    Assert-Contains $UsageTimelineSource $Token "Usage timeline token missing: $Token"
}
foreach ($Token in @(
    "foregroundCarriedAcrossMidnightStartsAtWindowBoundary",
    "appSwitchesDoNotDoubleCountTotalScreenTime",
    "screenOffClosesTheForegroundInterval",
    "invalidWindowReturnsZeroWithoutNegativeDurations"
)) {
    Assert-Contains $UsageTimelineTestSource $Token "Usage timeline native unit-test token missing: $Token"
}
foreach ($Token in @(
    "Schedule Profile",
    "scheduleProfilesEnabled",
    "isProfileUnlocked",
    "Schedule Blocker",
    "Daily App Limit",
    "Scroll Limit",
    "Reels Guard",
    "Blocked by you",
    "studyBlockedPackages",
    "PhoneControlSafety.isProtectedPackage",
    "MAX_NODES"
)) {
    Assert-Contains $PhoneControlEngineSource $Token "Native Phone Control engine token missing: $Token"
}

foreach ($Token in @(
    'event?.contentDescription?.toString().orEmpty()',
    'event?.className?.toString().orEmpty()',
    'strongRouteHints',
    'routeWordInViewId',
    'immersivePlayerHints'
)) {
    Assert-Contains $PhoneControlEngineSource $Token "Conservative Reels detector token missing: $Token"
}
$ReadNodeSignalsStart = $PhoneControlEngineSource.IndexOf("private fun readNodeSignals(")
if ($ReadNodeSignalsStart -lt 0) {
    throw "Unable to locate the bounded root-node Reels detector for source validation."
}
$FormatMinuteStart = $PhoneControlEngineSource.IndexOf("private fun formatMinute(", $ReadNodeSignalsStart)
if ($FormatMinuteStart -le $ReadNodeSignalsStart) {
    throw "Unable to isolate the bounded root-node Reels detector for source validation."
}
$ReadNodeSignalsSource = $PhoneControlEngineSource.Substring(
    $ReadNodeSignalsStart,
    $FormatMinuteStart - $ReadNodeSignalsStart
)
if ($ReadNodeSignalsSource -match 'node\.text' -or
    $ReadNodeSignalsSource -match 'node\.contentDescription') {
    throw "Reels Guard root scanning must use bounded view IDs only; visible labels would cause whole-app false positives."
}
foreach ($Token in @(
    'viewIdResourceName',
    'visited < MAX_NODES',
    'childCount.coerceAtMost(MAX_CHILDREN_PER_NODE)'
)) {
    Assert-Contains $ReadNodeSignalsSource $Token "Bounded root-node Reels detector token missing: $Token"
}
foreach ($Token in @(
    'private fun readSourceContext',
    'depth < MAX_SOURCE_ANCESTORS',
    'node.parent',
    'node.contentDescription'
)) {
    Assert-Contains $PhoneControlEngineSource $Token "Bounded event-source Reels context token missing: $Token"
}
Assert-Contains $AccessibilityConfig 'flagRetrieveInteractiveWindows' "Accessibility interactive-window fallback is missing."
Assert-Contains $AccessibilityConfig 'flagReportViewIds' "Reels Guard view-id reporting is missing."
Assert-Contains $AccessibilityConfig 'typeViewScrolled' "Scroll-limit accessibility event is missing."
Assert-Contains $ManifestSource 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS' "Battery exemption permission is missing."
Assert-Contains $ManifestSource 'PACKAGE_USAGE_STATS' "Usage access permission is missing."
Assert-Contains $ManifestSource 'NotificationControlService' "Notification listener service is missing from AndroidManifest.xml."
Assert-Contains $ManifestSource 'BIND_NOTIFICATION_LISTENER_SERVICE' "Notification listener binding permission is missing."
Assert-Contains $ManifestSource 'android:allowBackup="false"' "Sensitive notification history must not be included in Android cloud backup."
foreach ($Token in @(
    "class NotificationControlService",
    "cancelNotification",
    "recordNotificationBlocked",
    "CATEGORY_CALL",
    "CATEGORY_ALARM",
    "NotificationManagerCompat.getEnabledListenerPackages"
)) {
    Assert-Contains $NotificationControlSource $Token "Native notification-control token missing: $Token"
}
foreach ($Token in @(
    "object PhoneControlSafety",
    "authenticator",
    "bkash",
    "nagad",
    "wallet",
    "APP_PACKAGE",
    "sanitizePackages"
)) {
    Assert-Contains $PhoneControlSafetySource $Token "Central protected-app safety token missing: $Token"
}
foreach ($Token in @("recommendation", "review", "System app; kept allowed by default", "suggestedDailyMinutes")) {
    Assert-Contains $AppSafetyClassifierSource $Token "Auto app-safety classifier token missing: $Token"
}
foreach ($Token in @("resetBlockingForSafety", "applyManualBlockingMigration", "clearActiveLocksForSafety", "ProtectionVpnService.stop")) {
    Assert-Contains $SafetyBootstrapSource $Token "One-time fail-open safety migration token missing: $Token"
}
foreach ($Token in @("pm disable-user", "FocusAccessibilityService", "were not deleted")) {
    Assert-Contains $EmergencyUnlockSource $Token "Emergency phone-unlock script token missing: $Token"
}
if ($AccessibilitySource -match 'foregroundPackage\s*==\s*packageName\)\s*return') {
    throw "Accessibility service reintroduced the stale-foreground self-app early return."
}


$ProtectionPolicySource = Get-Content -LiteralPath ".\lib\models\protection_policy.dart" -Raw
$ProtectionScreenSource = Get-Content -LiteralPath ".\lib\screens\protection_center_screen.dart" -Raw
$ProtectionPolicyTestSource = Get-Content -LiteralPath ".\test\protection_policy_test.dart" -Raw
$ProtectionCenterTestSource = Get-Content -LiteralPath ".\test\protection_center_test.dart" -Raw
$ProtectionCenterSource = Get-Content -LiteralPath ".\lib\screens\protection_center_screen.dart" -Raw
foreach ($Token in @("responsive-emergency-unlock-card", "responsive-protection-picker-header", "Resume protection now")) {
    Assert-Contains $ProtectionCenterSource $Token "Responsive Protection Center token missing: $Token"
}
$ProtectionModelsSource = Get-Content -LiteralPath "$KotlinDir\ProtectionModels.kt" -Raw
$ProtectionRulesSource = Get-Content -LiteralPath "$KotlinDir\ProtectionRules.kt" -Raw
$ProtectionStoreSource = Get-Content -LiteralPath "$KotlinDir\ProtectionStore.kt" -Raw
foreach ($Token in @("webProtectionEnabled = false", "vpnDnsEnabled = false", "browserGuardEnabled = false", "failClosed = false")) {
    Assert-Contains $ProtectionStoreSource $Token "Emergency safety reset token missing: $Token"
}
if ($ProtectionStoreSource -match '\"privateDnsActive\"\s+to\s+privateDnsMode\.isNotBlank\(\)\s+&&') {
    throw "ProtectionStore privateDnsActive must parenthesize the complete Boolean Pair value."
}
Assert-Contains $ProtectionStoreSource '"privateDnsActive" to (privateDnsMode.isNotBlank() && privateDnsMode != "off")' "ProtectionStore private DNS snapshot compile fix is missing."
$ProtectionEngineSource = Get-Content -LiteralPath "$KotlinDir\ProtectionEngine.kt" -Raw
$ProtectionVpnSource = Get-Content -LiteralPath "$KotlinDir\ProtectionVpnService.kt" -Raw
$DnsPacketSource = Get-Content -LiteralPath "$KotlinDir\DnsPacket.kt" -Raw
$BootReceiverSource = Get-Content -LiteralPath "$KotlinDir\BootReceiver.kt" -Raw
$NotificationChannelsSource = Get-Content -LiteralPath "$KotlinDir\NotificationChannels.kt" -Raw
foreach ($Token in @(
    "class ProtectionPolicy",
    "webProtectionEnabled",
    "vpnDnsEnabled",
    "blockedDomains",
    "allowedDomains",
    "primeModeUntilMillis",
    "keepMeOutUntilMillis",
    "isWebWindowActiveAt"
)) {
    Assert-Contains $ProtectionPolicySource $Token "Dart protection policy token missing: $Token"
}
foreach ($Token in @(
    "class ProtectionCenterScreen",
    "Web & DNS protection",
    "Local DNS VPN",
    "Adult-content protection",
    "Safe Search bypass guard",
    "Prime Mode",
    "Keep Me Out",
    "Emergency policy",
    "Protection history"
)) {
    Assert-Contains $ProtectionScreenSource $Token "Protection Center UI token missing: $Token"
}
foreach ($Token in @(
    "getProtectionPolicy",
    "saveProtectionPolicy",
    "requestProtectionVpnPermission",
    "startProtectionVpn",
    "activatePrimeMode",
    "activateKeepMeOut",
    "requestHardcoreEmergencyUnlock",
    "runProtectionDiagnostics"
)) {
    Assert-Contains $NativeBridgeSource $Token "Protection MethodChannel token missing: $Token"
    Assert-Contains $MainActivitySource $Token "Native protection method handler missing: $Token"
}
foreach ($Token in @(
    "data class ProtectionPolicy",
    "isWebWindowActive",
    "toJson",
    "fromJson"
)) {
    Assert-Contains $ProtectionModelsSource $Token "Native protection model token missing: $Token"
}
foreach ($Token in @(
    "object ProtectionRules",
    "domainBlockReason",
    "safeSearchBlockReason",
    "isLocallyClassifiedAdult",
    "isValidIpv4"
)) {
    Assert-Contains $ProtectionRulesSource $Token "Native web rule token missing: $Token"
}
foreach ($Token in @(
    "class ProtectionStore",
    "activatePrimeMode",
    "activateKeepMeOut",
    "requestEmergencyUnlock",
    "recordWebBlocked",
    "recordTamperBlocked",
    "shouldBlockNotification",
    "Prime Mode is already active and cannot be replaced",
    "Keep Me Out is already active and cannot be replaced"
)) {
    Assert-Contains $ProtectionStoreSource $Token "Native protection store token missing: $Token"
}
foreach ($Token in @(
    "object ProtectionEngine",
    "Uninstall Guard",
    "Prime Mode",
    "Keep Me Out",
    "Website blocked",
    "PhoneControlSafety.isProtectedPackage"
)) {
    Assert-Contains $ProtectionEngineSource $Token "Native protection engine token missing: $Token"
}
foreach ($Token in @(
    "class ProtectionVpnService",
    "BIND_VPN_SERVICE",
    "addDnsServer",
    "addRoute",
    "protect(socket)",
    "buildNxDomainResponse",
    "MAX_FAILURES_BEFORE_FAIL_OPEN"
)) {
    if ($Token -eq "BIND_VPN_SERVICE") {
        Assert-Contains $ManifestSource $Token "VPN binding permission is missing from AndroidManifest.xml."
    } else {
        Assert-Contains $ProtectionVpnSource $Token "Local DNS VPN token missing: $Token"
    }
}
foreach ($Token in @(
    "parseIpv4Udp",
    "buildNxDomainResponse",
    "buildIpv4UdpResponse",
    "ipChecksum"
)) {
    Assert-Contains $DnsPacketSource $Token "DNS packet token missing: $Token"
}
foreach ($Token in @(
    "ProtectionVpnService.reconcile",
    "markBootRestore"
)) {
    Assert-Contains $BootReceiverSource $Token "Reboot restoration token missing: $Token"
}
Assert-Contains $NotificationChannelsSource 'PROTECTION = "hredoy_flow_protection_v1"' "Protection foreground notification channel is missing."
Assert-Contains $ManifestSource 'FOREGROUND_SERVICE_SYSTEM_EXEMPTED' "VPN foreground-service permission is missing."
Assert-Contains $ManifestSource 'android:foregroundServiceType="systemExempted"' "VPN foreground-service type is missing."
Assert-Contains $ManifestSource 'android:name=".ProtectionVpnService"' "Protection VPN service is missing."
Assert-Contains $AccessibilitySource "ProtectionEngine.decision" "Accessibility service is not enforcing web/commitment protection."
Assert-Contains $NotificationControlSource "protectionStore.shouldBlockNotification" "Prime/Keep Me Out notification suppression is missing."
Assert-Contains $MoreScreenSource "Protection Center" "Protection Center is not visible in More."
Assert-Contains $DrawerSource "Protection Center" "Protection Center is not visible in the drawer."
foreach ($Token in @("protection policy round-trip preserves web and commitment settings", "web schedule handles same-day and overnight")) {
    Assert-Contains $ProtectionPolicyTestSource $Token "Protection policy test token missing: $Token"
}
foreach ($Token in @("Protection Center is responsive on a narrow phone", "Web & DNS protection", "DateTime.now()", "Duration(hours: 2)")) {
    Assert-Contains $ProtectionCenterTestSource $Token "Protection Center widget test token missing: $Token"
}
if ($ProtectionCenterTestSource -match "DateTime\(2026, 7, 24, 22\)") {
    throw "Protection Center test reintroduced an expired fixed emergency-unlock timestamp."
}
if ($ManifestSource -match "DeviceAdminReceiver" -or $ManifestSource -match "BIND_DEVICE_ADMIN") {
    throw "Legacy Device Admin was introduced. Normal-app anti-uninstall must remain best-effort and transparent."
}

$FinalVerifySource = Get-Content -LiteralPath ".\FINAL_VERIFY_ON_PHONE.ps1" -Raw
$FeatureMatrixSource = Get-Content -LiteralPath ".\FEATURE_MATRIX.md" -Raw
$ReleaseBuildSource = Get-Content -LiteralPath ".\BUILD_RELEASE_APK.ps1" -Raw
$ReleaseInstallSource = Get-Content -LiteralPath ".\INSTALL_RELEASE_ON_PHONE.ps1" -Raw
$ReleaseConfigureSource = Get-Content -LiteralPath ".\CONFIGURE_RELEASE_SIGNING.ps1" -Raw
$ReleaseSigningSource = Get-Content -LiteralPath ".\android\app\build.gradle.kts" -Raw
$QaSource = Get-Content -LiteralPath $PSCommandPath -Raw
Assert-Contains $QaSource "Assert-PowerShellScriptsParse" "QA must parse every bundled PowerShell script before running Flutter or Gradle."
$ForbiddenCStyleEscape = 'create(' + [char]92 + '"release' + [char]92 + '")'
if ($QaSource.Contains($ForbiddenCStyleEscape)) {
    throw "C-style backslash escaping was reintroduced in the release-signing QA token."
}
Assert-Contains $FinalVerifySource '$AppProcessId' "Final phone verification must not overwrite PowerShell's reserved PID variable."
if ($FinalVerifySource -match '(?m)^\s*\$Pid\s*=') {
    throw "Final phone verification still assigns to the reserved PowerShell PID variable."
}
foreach ($Token in @(
    'release-signing.properties',
    'signingConfigs',
    'create("release")'
)) {
    Assert-Contains $ReleaseSigningSource $Token "Release-signing Gradle token missing: $Token"
}
foreach ($Token in @("release-signing.properties", "app-release.apk", "SHA256")) {
    Assert-Contains $ReleaseBuildSource $Token "Release build validation token missing: $Token"
}
foreach ($Token in @("keytool.exe", "-storetype PKCS12", "-Encoding ascii")) {
    Assert-Contains $ReleaseConfigureSource $Token "Release-signing setup token missing: $Token"
}
foreach ($Token in @("install -r", "versionName=4\.6\.1", "signing-identity mismatch")) {
    Assert-Contains $ReleaseInstallSource $Token "Release install validation token missing: $Token"
}
if ((Test-Path -LiteralPath ".\android\release-signing.properties") -or
    (Test-Path -LiteralPath ".\android\hredoy-flow-release.jks")) {
    throw "Private release-signing files must not be bundled in the source project."
}
foreach ($Token in @(
    "FINAL_FEATURE_MATRIX.txt",
    "MANUAL_REQUIRED",
    "ProtectionVpnService",
    "Accessibility App Blocker",
    'ExpectedVersion = "4.6.3"'
)) {
    Assert-Contains $FinalVerifySource $Token "Final phone-verification token missing: $Token"
}
foreach ($Token in @(
    "Web and DNS protection",
    "Commitment protection",
    "DNS-only",
    "AI NSFW image classification is intentionally not included"
)) {
    Assert-Contains $FeatureMatrixSource $Token "Feature matrix transparency token missing: $Token"
}

$ExpectedRawSounds = @(
    "hf_focus_pulse.wav",
    "hf_deep_work.wav",
    "hf_study_bell.wav",
    "hf_reading_chime.wav",
    "hf_exam_alert.wav",
    "hf_deadline_beacon.wav",
    "hf_coding_digital.wav",
    "hf_science_signal.wav",
    "hf_meeting_chime.wav",
    "hf_morning_sunrise.wav",
    "hf_workout_energy.wav",
    "hf_gentle_reminder.wav",
    "hf_calm_waves.wav",
    "hf_bright_bell.wav",
    "hf_classic_alarm.wav",
    "hf_urgent_siren.wav"
)
foreach ($SoundFile in $ExpectedRawSounds) {
    $SoundPath = Join-Path ".\android\app\src\main\res\raw" $SoundFile
    if (-not (Test-Path -LiteralPath $SoundPath)) {
        throw "Built-in ringtone asset missing: $SoundFile"
    }
    $FileInfo = Get-Item -LiteralPath $SoundPath
    if ($FileInfo.Length -lt 20000) {
        throw "Built-in ringtone asset is unexpectedly small: $SoundFile"
    }
    $SoundBytes = [System.IO.File]::ReadAllBytes($FileInfo.FullName)
    $Header = [System.Text.Encoding]::ASCII.GetString($SoundBytes, 0, 4)
    if ($Header -ne "RIFF") {
        throw "Built-in ringtone is not a valid WAV/RIFF file: $SoundFile"
    }
    $ResourceName = [System.IO.Path]::GetFileNameWithoutExtension($SoundFile)
    if (-not $AlarmCatalogSource.Contains("R.raw.$ResourceName")) {
        throw "Built-in ringtone is not mapped in AlarmSoundCatalog: $SoundFile"
    }
}

$AllBundledSounds = Get-ChildItem `
    -LiteralPath ".\android\app\src\main\res\raw" `
    -Filter "hf_*.wav" `
    -File
if ($AllBundledSounds.Count -ne 216) {
    throw "Expected exactly 216 real bundled alarm WAV files, found $($AllBundledSounds.Count)."
}
foreach ($SoundFile in $AllBundledSounds) {
    if ($SoundFile.Length -lt 20000) {
        throw "Bundled alarm WAV is unexpectedly small: $($SoundFile.Name)"
    }
    $SoundBytes = [System.IO.File]::ReadAllBytes($SoundFile.FullName)
    if ([System.Text.Encoding]::ASCII.GetString($SoundBytes, 0, 4) -ne "RIFF" -or
        [System.Text.Encoding]::ASCII.GetString($SoundBytes, 8, 4) -ne "WAVE") {
        throw "Bundled alarm sound is not a valid WAV/RIFF file: $($SoundFile.Name)"
    }
}
$UniqueSoundHashes = @(
    $AllBundledSounds |
    ForEach-Object { (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash } |
    Sort-Object -Unique
)
if ($UniqueSoundHashes.Count -ne 216) {
    throw "All 216 bundled alarm sounds must have unique audio files."
}
if (-not (Test-Path -LiteralPath ".\android\app\src\main\res\raw\hf_tone_216.wav")) {
    throw "The final generated alarm sound hf_tone_216.wav is missing."
}
foreach ($Token in @("17..216", "getIdentifier", "generatedToneLabel", 'Regex("tone_\\d{3}")')) {
    Assert-Contains $AlarmCatalogSource $Token "Generated Android alarm-sound mapping token missing: $Token"
}

$DartFiles = Get-ChildItem -LiteralPath ".\lib" -Recurse -Filter "*.dart" -File
$LifecycleHazards = $DartFiles | Select-String -Pattern "GlobalKey\s*<"
if ($LifecycleHazards) {
    $LifecycleHazards | ForEach-Object { Write-Host $_.Line -ForegroundColor Red }
    throw "Explicit GlobalKey lifecycle hazard was reintroduced."
}

Assert-Contains $ReelGateSource "minimumTransitionGapMillis" "Reel transition debounce gate missing."
foreach ($Token in @(
    "firstFingerprint == secondFingerprint",
    "cleanFallbackToken != lastAcceptedFallbackToken",
    "!hasAcceptedReel && initialEntry"
)) {
    Assert-Contains $ReelGateSource $Token "Hybrid Reel confirmation contract token missing: $Token"
}
Assert-Contains $StudyPlanSource "routine-20260726-r4-" "26 July clean routine prefix missing."

Write-Host "[2/14] Restore locked packages" -ForegroundColor Cyan
flutter pub get
Assert-LastExitCode "flutter pub get failed."

Write-Host "[3/14] Normalize and verify deterministic formatting" -ForegroundColor Cyan
$FormattedDartFiles = @(
    ".\lib\models\alarm_presets.dart",
    ".\lib\models\alarm_sounds.dart",
    ".\lib\models\phone_control.dart",
    ".\lib\models\protection_policy.dart",
    ".\lib\services\native_bridge.dart",
    ".\lib\screens\active_features_screen.dart",
    ".\lib\screens\alarm_preset_screen.dart",
    ".\lib\screens\alarm_sound_picker_screen.dart",
    ".\lib\screens\command_search_screen.dart",
    ".\lib\screens\more_screen.dart",
    ".\lib\screens\phone_control_dashboard_screen.dart",
    ".\lib\screens\phone_control_screen.dart",
    ".\lib\screens\protection_center_screen.dart",
    ".\lib\screens\reels_insights_screen.dart",
    ".\lib\screens\schedule_profiles_screen.dart",
    ".\lib\screens\social_control_screen.dart",
    ".\lib\screens\study_mode_screen.dart",
    ".\lib\screens\task_editor_screen.dart",
    ".\lib\screens\wellbeing_alerts_screen.dart",
    ".\lib\screens\today_screen.dart",
    ".\lib\screens\root_screen.dart",
    ".\lib\widgets\app_drawer.dart",
    ".\lib\widgets\common_widgets.dart",
    ".\lib\widgets\focus_tree.dart",
    ".\test\alarm_sound_test.dart",
    ".\test\phone_control_test.dart",
    ".\test\protection_policy_test.dart",
    ".\test\protection_center_test.dart",
    ".\test\schedule_profiles_test.dart",
    ".\test\social_control_test.dart",
    ".\test\study_mode_test.dart"
) | ForEach-Object { Get-Item -LiteralPath $_ } | Sort-Object FullName

$FormatTargets = @($FormattedDartFiles | ForEach-Object { $_.FullName })
& dart format @FormatTargets
Assert-LastExitCode "Dart formatting failed."

$FormatHashesBefore = @(
    $FormattedDartFiles |
    ForEach-Object {
        "{0}|{1}" -f $_.FullName, (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    }
)

& dart format @FormatTargets
Assert-LastExitCode "Second Dart formatting pass failed."

$FormatHashesAfter = @(
    $FormattedDartFiles |
    ForEach-Object {
        "{0}|{1}" -f $_.FullName, (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    }
)
if (Compare-Object -ReferenceObject $FormatHashesBefore -DifferenceObject $FormatHashesAfter) {
    throw "Dart formatting was not deterministic after normalization."
}

Write-Host "[4/14] Flutter static analysis" -ForegroundColor Cyan
flutter analyze --no-pub
Assert-LastExitCode "flutter analyze failed."

Write-Host "[5/14] Complete unit, CRUD, ringtone, storage, layout, lifecycle, and performance suite" -ForegroundColor Cyan
flutter test --no-pub --concurrency=1
Assert-LastExitCode "Full Flutter test suite failed."

Write-Host "[6/14] Repeat compact layouts and form lifecycle twice" -ForegroundColor Cyan
1..2 | ForEach-Object {
    flutter test .\test\layout_regression_test.dart --no-pub --concurrency=1
    Assert-LastExitCode "Repeated layout/lifecycle test pass $_ failed."
}

Write-Host "[7/14] Repeat ringtone model and persistence tests twice" -ForegroundColor Cyan
1..2 | ForEach-Object {
    flutter test .\test\alarm_sound_test.dart .\test\app_data_test.dart --no-pub --concurrency=1
    Assert-LastExitCode "Repeated ringtone data test pass $_ failed."
}

Write-Host "[8/14] Repeat 5,000-task indexes and lazy-list performance suite" -ForegroundColor Cyan
Remove-Item -LiteralPath ".\build\test_cache" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath ".\.flutter-tool-temp" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null
flutter test .\test\performance_regression_test.dart --no-pub --concurrency=1
Assert-LastExitCode "Performance regression tests failed."

Write-Host "[9/14] Repeat CRUD and storage recovery suites" -ForegroundColor Cyan
flutter test .\test\controller_crud_test.dart .\test\storage_recovery_test.dart --no-pub --concurrency=1
Assert-LastExitCode "CRUD/storage recovery tests failed."

Write-Host "[10/14] Verify routine continuity, current action, phone/social/study/web protection, profile picture, and focus-tree behavior" -ForegroundColor Cyan
flutter test .\test\routine_game_test.dart .\test\profile_picture_test.dart .\test\phone_control_test.dart .\test\phone_control_dashboard_test.dart .\test\schedule_profiles_test.dart .\test\social_control_test.dart .\test\study_mode_test.dart .\test\protection_policy_test.dart .\test\protection_center_test.dart --no-pub --concurrency=1
Assert-LastExitCode "Routine continuity, current action, Study Quest, profile-picture, Phone Control, Schedule Profiles, Social Control, Study Mode, web/commitment protection, or focus-tree tests failed."

Write-Host "[11/14] Run Android screen-time and app-safety unit tests" -ForegroundColor Cyan
Push-Location ".\android"
try {
    & .\gradlew.bat testDebugUnitTest --no-daemon
    $AndroidUnitTestExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
if ($AndroidUnitTestExitCode -ne 0) {
    throw "Android screen-time or app-safety unit tests failed."
}

Write-Host "[12/14] Compile Android debug APK" -ForegroundColor Cyan
flutter build apk --debug --no-pub
Assert-LastExitCode "Android debug APK build failed."
$DebugApk = Join-Path $PSScriptRoot "build\app\outputs\flutter-apk\app-debug.apk"
if (-not (Test-Path $DebugApk)) { throw "Debug APK was not created: $DebugApk" }

Write-Host "[13/14] Compile Android profile APK for real performance testing" -ForegroundColor Cyan
flutter build apk --profile --no-pub
Assert-LastExitCode "Android profile APK build failed."
$ProfileApk = Join-Path $PSScriptRoot "build\app\outputs\flutter-apk\app-profile.apk"
if (-not (Test-Path $ProfileApk)) { throw "Profile APK was not created: $ProfileApk" }

Write-Host "[14/14] Verify APK artifacts" -ForegroundColor Cyan
if ((Get-Item -LiteralPath $DebugApk).Length -lt 1000000) { throw "Debug APK is unexpectedly small." }
if ((Get-Item -LiteralPath $ProfileApk).Length -lt 1000000) { throw "Profile APK is unexpectedly small." }

Write-Host "Hredoy Flow 4.6.3 QA passed: Daily Coach, Simple and Advanced Mode, required rule activation preview, always-allowed app safety, smart recommendation dashboard, one-tap blocking stop, weekly report, responsive Protection Center, categorized manual app limits, Study/Focus schedules, Reels controls, command search, 216 alarm presets, 216 real bundled alarm sounds, hybrid snapshot-and-pager-verified per-app Reels counts and milestone warnings, detailed screen-time alerts, Focus Forest, full-screen alarm path, full-picture slider, full Flutter/native tests, Android debug/profile builds, routines and saved user data." -ForegroundColor Green
