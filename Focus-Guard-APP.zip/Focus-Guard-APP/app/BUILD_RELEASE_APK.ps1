param(
    [switch]$SkipQA
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"
$SigningProperties = Join-Path $PSScriptRoot "android\release-signing.properties"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null

$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

if (-not (Test-Path -LiteralPath $SigningProperties)) {
    throw "Production signing is not configured. Run .\CONFIGURE_RELEASE_SIGNING.ps1 first."
}

$SigningValues = @{}
Get-Content -LiteralPath $SigningProperties | ForEach-Object {
    if ($_ -match '^\s*([^#][^=]*)=(.*)$') {
        $SigningValues[$matches[1].Trim()] = $matches[2].Trim()
    }
}
foreach ($RequiredKey in @("storeFile", "storePassword", "keyAlias", "keyPassword")) {
    if (-not $SigningValues.ContainsKey($RequiredKey) -or
        [string]::IsNullOrWhiteSpace($SigningValues[$RequiredKey])) {
        throw "Release signing property is missing: $RequiredKey"
    }
}
$KeystorePath = Join-Path (Join-Path $PSScriptRoot "android") $SigningValues["storeFile"]
if (-not (Test-Path -LiteralPath $KeystorePath)) {
    throw "Release keystore was not found: $KeystorePath"
}

if (-not $SkipQA) {
    & "$PSScriptRoot\QA.ps1"
    if ($LASTEXITCODE -ne 0) { throw "Project QA failed." }
}

$SymbolsDir = Join-Path $PSScriptRoot "build\symbols"
flutter build apk --release --no-pub --obfuscate --split-debug-info="$SymbolsDir"
if ($LASTEXITCODE -ne 0) { throw "Release APK build failed." }

$Output = Join-Path $PSScriptRoot "build\app\outputs\flutter-apk"
$Apk = Join-Path $Output "app-release.apk"
if (-not (Test-Path -LiteralPath $Apk)) { throw "Release APK was not created: $Apk" }
if ((Get-Item -LiteralPath $Apk).Length -lt 1000000) { throw "Release APK is unexpectedly small." }

$ApkSigner = Get-ChildItem -Path (Join-Path $AndroidSdk "build-tools") `
    -Filter "apksigner.bat" -File -Recurse -ErrorAction SilentlyContinue |
    Sort-Object `
        @{ Expression = {
            $VersionText = $_.Directory.Name
            try { [version]$VersionText } catch { [version]"0.0" }
        }; Descending = $true }, `
        @{ Expression = { $_.FullName }; Descending = $true } |
    Select-Object -First 1
if ($null -eq $ApkSigner) {
    throw "apksigner.bat was not found under Android SDK build-tools."
}
& $ApkSigner.FullName verify --verbose --print-certs $Apk
if ($LASTEXITCODE -ne 0) { throw "Release APK signature verification failed." }

$Sha256 = (Get-FileHash -LiteralPath $Apk -Algorithm SHA256).Hash.ToLowerInvariant()
$HashReport = Join-Path $Output "app-release.sha256.txt"
@(
    "Hredoy Flow 4.6.3 signed release APK",
    "File: $Apk",
    "SHA256: $Sha256",
    "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')"
) | Set-Content -LiteralPath $HashReport -Encoding UTF8

Write-Host "Signed release APK created and verified: $Apk" -ForegroundColor Green
Write-Host "SHA-256: $Sha256" -ForegroundColor Green
Write-Host "Symbols: $SymbolsDir" -ForegroundColor Cyan
Write-Host "Hash report: $HashReport" -ForegroundColor Cyan
Start-Process explorer.exe $Output
