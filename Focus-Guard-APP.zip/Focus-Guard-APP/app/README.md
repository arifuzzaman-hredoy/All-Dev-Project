# Hredoy Flow 4.6.3+66

This release fixes the v4.6.0 zero-count regression on apps that hide creator/caption identity from Accessibility.

The hybrid counter:

- never increments from a raw Accessibility callback;
- accepts only route-confirmed full-screen Reel pager evidence;
- rejects comments, replies, captions, sheets and small nested lists;
- clusters noisy callback bursts into one candidate;
- waits for the screen to settle;
- prefers two matching privacy-safe fingerprints;
- uses one guarded pager fallback when identity is hidden or static;
- counts the initial detected Reel after the dwell guard;
- keeps duplicate-token and minimum-gap protection.

Native counter schema remains `3`, so this update does not wipe the corrected v4.6.0 counter data again. Watch time remains a secondary enforcement fallback. Routine restart remains 26 July 2026 at 6:30 AM with planner schema `7`.
