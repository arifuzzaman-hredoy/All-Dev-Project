# Hredoy Flow 4.6.3 Static Validation

Required checks:

- `version: 4.6.3+66`
- QA isolates `readNodeSignals()` before checking for visible-label access
- root-tree Reels scanning uses `viewIdResourceName` only
- event-source context is bounded by `MAX_SOURCE_ANCESTORS`
- raw Accessibility callbacks never increment Reel counts
- `ReelTransitionGate.confirmSettledCandidate` supports fingerprint, pager fallback and initial-entry confirmations
- `ReelPagerHeuristics` rejects non-pager surfaces and accepts route-confirmed hidden-source pager movement
- callback bursts use `REEL_PAGER_BURST_GAP_MILLIS`
- `ReelFingerprintBuilder` filters counters, timestamps and action labels
- native Reel counter schema remains `3`
- planner schema remains `7`
- routine starts 26 July 2026 at 6:30 AM
- 216 bundled WAV files remain present
