param(
    [string]$DeviceId = "R38M800T0HD",
    [ValidateSet("profile", "debug", "release")]
    [string]$Mode = "profile"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null

$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

adb kill-server 2>$null
adb start-server
if ($LASTEXITCODE -ne 0) { throw "ADB server could not start." }

$DeviceReady = $false
for ($Attempt = 1; $Attempt -le 15; $Attempt += 1) {
    $DeviceOutput = adb devices -l | Out-String
    Write-Host $DeviceOutput

    if ($DeviceOutput -match "(?m)^$([regex]::Escape($DeviceId))\s+device\b") {
        $DeviceReady = $true
        break
    }
    Start-Sleep -Seconds 2
}

if (-not $DeviceReady) {
    throw "Device $DeviceId was not detected. Unlock the phone, enable USB debugging, and approve this computer."
}

flutter pub get
if ($LASTEXITCODE -ne 0) { throw "flutter pub get failed." }

adb -s $DeviceId shell am force-stop com.hredoy.focus_guard_flutter 2>$null
adb -s $DeviceId logcat -c 2>$null
Start-Sleep -Milliseconds 350

if ($Mode -eq "debug") {
    Write-Host "Running DEBUG mode. Debug assertions and JIT make scrolling slower than the real APK." -ForegroundColor Yellow
} elseif ($Mode -eq "profile") {
    Write-Host "Running PROFILE mode for realistic scrolling and loading performance." -ForegroundColor Green
} else {
    Write-Host "Running RELEASE mode for maximum APK speed." -ForegroundColor Green
}

flutter run "--$Mode" --no-pub -d $DeviceId
if ($LASTEXITCODE -ne 0) { throw "Flutter $Mode run failed." }
