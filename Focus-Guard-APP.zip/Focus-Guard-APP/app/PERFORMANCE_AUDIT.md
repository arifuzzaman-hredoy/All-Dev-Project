# Performance audit

- Today updates its clock every 30 seconds only while the app is resumed.
- Automatic dashboard slides advance every seven seconds and pause during manual swipes.
- Slider illustrations are local Flutter widgets/assets; no network image fetch is introduced.
- Usage-event snapshots are cached for 15 seconds.
- Daily screen time is a union of foreground intervals, avoiding duplicate/split transition inflation.
- Weekly usage is limited to seven points and native collection remains off the UI thread.
- Large task collections retain cached indexes and lazy sliver lists.
- Full QA repeats compact layouts, storage/ringtone persistence, CRUD recovery and 5,000-task performance tests, then runs native timeline tests before Android debug/profile builds.
