# Hredoy Flow 4.6.3+66 — Stable-Snapshot QA Contract Recovery

- Fixed Stage 1 QA checking the opposite of the runtime stability rule.
- QA now requires `firstFingerprint == secondFingerprint`, matching `ReelTransitionGate`.
- Added explicit source contracts for unique pager fallback tokens and initial-entry fallback.
- Reels runtime Kotlin sources remain unchanged from v4.6.2.
- Routine, tasks, alarms, profile, XP, settings and saved rules remain compatible.

# Hredoy Flow 4.6.2+65 — Reels Detector QA Contract Recovery

- Fixed the Stage 1 QA false positive that treated bounded event-source ancestor context as a full visible-label scan.
- The anti-false-positive check now inspects only `readNodeSignals()`, which traverses the root tree and remains view-ID-only.
- `readSourceContext()` remains bounded to five source ancestors and can inspect content descriptions only to reject comments, replies, captions, sheets and dialogs.
- Hybrid Reels runtime counting behavior is unchanged from 4.6.1.

# Hredoy Flow 4.6.1+64 — Hybrid Reels Counter Zero-Count Recovery

## Fixed

- Fixed v4.6.0 physical-device zero counting when Facebook, Instagram or YouTube exposes no usable creator/caption identity.
- Added an initial-entry confirmation after the existing dwell guard.
- Added a guarded full-screen pager fallback after callback bursts settle.
- Kept stable fingerprint confirmation as the preferred path.
- Kept comments, replies, captions, sheets and nested scrolling excluded.
- Kept raw Accessibility callbacks from incrementing the counter directly.
- Kept counter schema `3`, avoiding another automatic counter reset.

## Regression coverage

- Hidden identity initial entry.
- Hidden identity pager fallback.
- Duplicate fallback-token suppression.
- Static fingerprint plus new pager transition.
- Minimum transition-gap enforcement.
- Hidden event source, comment/caption and small nested-scroll heuristics.

## Continuity

- Routine remains anchored to 26 July 2026 at 6:30 AM with planner schema `7`.
- Existing tasks, alarms, profile, XP, Study Quest, Focus history, settings and phone-control rules remain compatible.

# Hredoy Flow 4.5.4+62 — Schema-Test Synchronization Recovery

## Fixed

- Updated `app_data_test.dart` to expect `StudyPlan.currentDataVersion == 7`, matching the 26 July routine-reset migration.
- Added an explicit QA contract so the schema constant and seed-data regression expectation cannot silently diverge again.
- Updated `PROJECT_AUDIT.json` schema metadata from `6` to `7`.
- Corrected the signed-release installer, which still matched `versionName=4.5.0`, to verify `4.5.4`.
- Aligned QA, phone verification and release metadata to `4.5.4+62`.

## Runtime continuity

- No Reels counter, Accessibility enforcement, routine migration, alarm, Focus Forest or user-data runtime behavior changed.
- The routine remains anchored to 26 July 2026 at 6:30 AM.
- Existing manual tasks, profile picture, XP, Study Quest, Focus history, phone-control rules and local settings remain compatible.

---

# Hredoy Flow 4.5.3+61 — Accurate Reels Counter QA Recovery

## QA recovery

- Replaced the obsolete `REEL_VIEW_DEBOUNCE_MILLIS` source guard with contracts for `ReelTransitionGate`.
- The QA gate now verifies Accessibility wiring, page-transition accumulation, settle-gap suppression and the three native noisy-callback regression tests.
- No Reels runtime, routine migration, alarm, Focus Forest or user-data behavior changed from v4.5.2.

## Added

- A dedicated **Reels & Shorts limits** dashboard that lists supported installed apps separately.
- Live per-app counters for detected Reels/Shorts views, watch minutes, blocked attempts and remaining allowance.
- Per-app count limits, minute limits, immediate Reels-only blocking, commitment percentage and configurable 25%/50%/75%/90%/100% warning milestones.
- Detailed native wellbeing notifications for Reels progress and screen-time milestones.
- Daily screen-time goal, 25%/50%/75%/90%/100% warnings and repeated over-goal warnings at a configurable interval.
- A richer animated **Focus Forest** with sky, mountains, forest layers, central tree, meadow, pond, trail, birds, flowers and fireflies.
- Exactly **216 real bundled WAV alarm sounds**, searchable and filterable by sound family, while preserving phone-tone and custom-audio choices.

## Fixed

- Updated the Windows QA source guard to validate the new `_FocusForestPainter` implementation instead of the removed `_FocusTreePainter` name. This is a QA-only recovery; Focus Forest runtime behavior is unchanged.
- Reels limits are no longer hidden only inside the general app-rule editor.
- Reels counts and watch time are visible from one dedicated dashboard.
- The count-limit engine blocks at the configured limit rather than after one extra Reel.
- Fixed-window Reels budgets also stop at the configured count.
- The alarm-sound picker now scales to the full 216-sound library with search and group filters.

## Safety and continuity

- Installed apps are still never auto-blocked.
- Warnings do not create new blocking rules.
- Accessibility Reels detection remains best-effort because supported apps can change their UI routes.
- Existing routines, tasks, goals, alarms, selected ringtones, profile picture, Study Quest, XP, Focus history and local settings remain compatible.
