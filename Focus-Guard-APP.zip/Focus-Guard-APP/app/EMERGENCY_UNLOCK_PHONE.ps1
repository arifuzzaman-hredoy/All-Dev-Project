[CmdletBinding()]
param(
    [string]$DeviceId = "",
    [switch]$KeepServiceDisabled
)

$ErrorActionPreference = "Stop"

$PackageName = "com.hredoy.focus_guard_flutter"
$ServiceComponent = "$PackageName/.FocusAccessibilityService"
$AdbCandidates = @(
    "G:\Android\Sdk\platform-tools\adb.exe",
    (Join-Path $env:LOCALAPPDATA "Android\Sdk\platform-tools\adb.exe")
)
$Adb = $AdbCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $Adb) {
    throw "adb.exe was not found. Install Android platform-tools or update this script with your SDK path."
}

& $Adb start-server | Out-Null
$Devices = & $Adb devices
$Ready = @($Devices | Select-String -Pattern "\sdevice$")
if ($Ready.Count -eq 0) {
    throw "No authorized Android device is connected. Unlock the phone and approve USB debugging."
}

$Target = @()
if ([string]::IsNullOrWhiteSpace($DeviceId)) {
    $Target = @()
} else {
    $Target = @("-s", $DeviceId)
}

Write-Host "Stopping Hredoy Flow enforcement without deleting app data..." -ForegroundColor Yellow
& $Adb @Target shell am force-stop $PackageName | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "Could not stop Hredoy Flow on the connected phone."
}

$DisableOutput = & $Adb @Target shell pm disable-user --user 0 $ServiceComponent 2>&1 | Out-String
$ComponentDisabled = $LASTEXITCODE -eq 0 -and $DisableOutput -match "disabled"
if (-not $ComponentDisabled) {
    Write-Host "Android did not allow component disable through ADB. Opening Accessibility settings for manual disable." -ForegroundColor Yellow
    & $Adb @Target shell am start -a android.settings.ACCESSIBILITY_SETTINGS | Out-Null
} else {
    & $Adb @Target shell am start -a android.intent.action.MAIN -c android.intent.category.HOME | Out-Null
}

Write-Host "Hredoy Flow enforcement was stopped." -ForegroundColor Green
Write-Host "Tasks, routines, XP, profile picture and saved settings were not deleted." -ForegroundColor Green
if (-not $ComponentDisabled) {
    Write-Host "On the phone, turn OFF Hredoy Flow in Accessibility now." -ForegroundColor Yellow
}

if (-not $KeepServiceDisabled) {
    Write-Host ""
    Write-Host "After installing Hredoy Flow 4.6.3, re-enable the component with:" -ForegroundColor Cyan
    Write-Host "& `"$Adb`" $($Target -join ' ') shell pm enable $ServiceComponent"
    Write-Host "Then open Android Accessibility settings and enable Hredoy Flow again." -ForegroundColor Cyan
}
