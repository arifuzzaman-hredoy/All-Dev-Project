import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/study_plan.dart';
import '../models/app_models.dart';
import '../models/study_game.dart';
import '../services/local_store.dart';
import '../services/native_bridge.dart';

class AppController extends ChangeNotifier {
  AppController._();

  static const SubjectItem _fallbackSubject = SubjectItem(
    id: StudyPlan.general,
    name: 'General',
    colorValue: 0xFF8892A6,
    iconCodePoint: 0xe574,
  );

  late AppData _data;
  late LocalStore _store;
  bool _ready = false;
  bool _testing = false;
  bool _disposed = false;
  DateTime _selectedDate = dateOnly(DateTime.now());

  AppData? _pendingNativeSnapshot;
  bool _pendingNativeForce = false;
  bool _nativeSyncRunning = false;
  Completer<void>? _nativeFlushCompleter;
  Timer? _saveDebounce;
  AppData? _pendingSaveSnapshot;
  Completer<void>? _saveFlushCompleter;
  bool _saveWorkerRunning = false;

  Map<String, SubjectItem> _subjectsById = const <String, SubjectItem>{};
  List<SubjectItem> _activeSubjects = const <SubjectItem>[];
  List<TaskItem> _activeTasks = const <TaskItem>[];
  Map<String, List<TaskItem>> _tasksByDate = const <String, List<TaskItem>>{};
  Map<String, List<TaskItem>> _pendingTasksByDate =
      const <String, List<TaskItem>>{};
  Map<String, int> _taskTotalByDate = const <String, int>{};
  Map<String, int> _taskCompletedByDate = const <String, int>{};
  Map<String, int> _taskCountBySubject = const <String, int>{};
  List<GoalItem> _activeGoals = const <GoalItem>[];
  List<NoteItem> _activeNotes = const <NoteItem>[];
  List<FocusSession> _recentSessions = const <FocusSession>[];
  Map<String, int> _focusMinutesByDate = const <String, int>{};
  Map<String, int> _focusMinutesBySubject = const <String, int>{};
  Set<String> _productiveDateKeys = const <String>{};
  Set<String> _completedTaskDateKeys = const <String>{};
  Set<String> _sessionDateKeys = const <String>{};
  int _totalFocusMinutes = 0;
  int _completedTaskCount = 0;
  int _currentStreak = 0;
  String _streakCalculatedFor = '';

  bool get ready => _ready;
  AppData get data => _data;
  DateTime get selectedDate => _selectedDate;
  AppPreferencesModel get preferences => _data.preferences;
  ThemeMode get themeMode => preferences.materialThemeMode;
  Color get accentColor => Color(preferences.accentValue);

  static Future<AppController> create() async {
    final AppController controller = AppController._();
    await controller._initialize();
    return controller;
  }

  /// Creates a deterministic in-memory controller for tests. It never touches
  /// Android channels, alarms, notifications, or the file system.
  static AppController createForTesting({AppData? data}) {
    final AppController controller = AppController._();
    controller._testing = true;
    controller._store = LocalStore(
      '${Directory.systemTemp.path}/hredoy_flow_widget_test',
    );
    controller._data = data ?? StudyPlan.initialData();
    controller._rebuildIndexes();
    controller._ready = true;
    return controller;
  }

  Future<void> _initialize() async {
    String path;
    try {
      path = await NativeBridge.appDataPath();
    } catch (_) {
      path = '${Directory.systemTemp.path}/hredoy_flow';
    }

    _store = LocalStore(path);
    final Future<AppData?> storedFuture = _store.load();
    final Future<Set<String>> completedFuture =
        NativeBridge.completedTaskIds().catchError((_) => <String>{});

    final AppData? stored = await storedFuture;
    _data = stored ?? StudyPlan.initialData();

    if (_data.subjects.isEmpty) {
      _data = _data.copyWith(subjects: StudyPlan.subjects);
    }
    if (_data.version < 3) {
      _data = _migrateToVersion3(_data);
    }

    if (_data.version < 4) {
      _data = _data.copyWith(version: 4);
    }
    if (_data.version < StudyPlan.currentDataVersion) {
      _data = _migrateToCurrentVersion(_data);
    }

    _rebuildIndexes();
    _ready = true;

    // The first usable frame is no longer held behind platform-channel work.
    // Native completion reconciliation, persistence, and AlarmManager diffing
    // continue in the background after local data is ready.
    unawaited(
      completedFuture.then(_applyNativeCompletions).catchError((_) {}),
    );
    unawaited(_scheduleSave(_data).catchError((_) {}));
    unawaited(_queueNativeReschedule(_data, force: true).catchError((_) {}));
  }

  Future<void> _applyNativeCompletions(Set<String> completed) async {
    if (completed.isEmpty || _disposed) return;
    final DateTime now = DateTime.now();
    bool changed = false;
    final List<TaskItem> tasks = _data.tasks.map((TaskItem task) {
      if (completed.contains(task.id) && !task.isCompleted) {
        changed = true;
        return task.copyWith(completedAt: now, updatedAt: now);
      }
      return task;
    }).toList(growable: false);
    if (!changed || _disposed) return;
    _data = _data.copyWith(tasks: tasks);
    await _commit(reschedule: true, tasksChanged: true);
  }

  AppData _migrateToVersion3(AppData source) {
    final AppData englishSeed = StudyPlan.initialData();
    final Map<String, TaskItem> seedTasks = <String, TaskItem>{
      for (final TaskItem task in englishSeed.tasks) task.id: task,
    };
    final Map<String, GoalItem> seedGoals = <String, GoalItem>{
      for (final GoalItem goal in englishSeed.goals) goal.id: goal,
    };
    final Map<String, HabitItem> seedHabits = <String, HabitItem>{
      for (final HabitItem habit in englishSeed.habits) habit.id: habit,
    };
    final Map<String, NoteItem> seedNotes = <String, NoteItem>{
      for (final NoteItem note in englishSeed.notes) note.id: note,
    };

    final List<TaskItem> tasks = source.tasks.map((TaskItem task) {
      final TaskItem? seed = seedTasks[task.id];
      if (seed == null) return task;
      return task.copyWith(
        title: _containsBengali(task.title) ? seed.title : task.title,
        notes: _containsBengali(task.notes) ? seed.notes : task.notes,
        alarmEnabled: task.alarmEnabled,
        snoozeMinutes: task.snoozeMinutes,
        alarmSoundId: task.alarmSoundId,
        alarmSoundLabel: task.alarmSoundLabel,
        alarmSoundUri: task.alarmSoundUri,
      );
    }).toList(growable: false);

    final List<GoalItem> goals = source.goals.map((GoalItem goal) {
      final GoalItem? seed = seedGoals[goal.id];
      if (seed == null) return goal;
      return goal.copyWith(
        title: _containsBengali(goal.title) ? seed.title : goal.title,
        notes: _containsBengali(goal.notes) ? seed.notes : goal.notes,
      );
    }).toList(growable: false);

    final List<HabitItem> habits = source.habits.map((HabitItem habit) {
      final HabitItem? seed = seedHabits[habit.id];
      if (seed == null || !_containsBengali(habit.title)) return habit;
      return habit.copyWith(title: seed.title);
    }).toList(growable: false);

    final List<NoteItem> notes = source.notes.map((NoteItem note) {
      final NoteItem? seed = seedNotes[note.id];
      if (seed == null) return note;
      return note.copyWith(
        title: _containsBengali(note.title) ? seed.title : note.title,
        body: _containsBengali(note.body) ? seed.body : note.body,
      );
    }).toList(growable: false);

    final List<FocusSession> sessions =
        source.sessions.map((FocusSession session) {
      final TaskItem? linked =
          session.taskId == null ? null : seedTasks[session.taskId!];
      if (linked == null || !_containsBengali(session.label)) return session;
      return FocusSession(
        id: session.id,
        label: linked.title,
        taskId: session.taskId,
        subjectId: session.subjectId,
        startedAt: session.startedAt,
        endedAt: session.endedAt,
        plannedMinutes: session.plannedMinutes,
        actualMinutes: session.actualMinutes,
        completed: session.completed,
        note: session.note,
      );
    }).toList(growable: false);

    return source.copyWith(
      version: 3,
      tasks: tasks,
      goals: goals,
      habits: habits,
      notes: notes,
      sessions: sessions,
    );
  }

  bool _containsBengali(String value) =>
      value.runes.any((int rune) => rune >= 0x0980 && rune <= 0x09FF);

  AppData _migrateToCurrentVersion(AppData source) {
    final Set<String> managedGoalIds =
        StudyPlan.buildGoals().map((GoalItem goal) => goal.id).toSet();
    final List<TaskItem> customTasks = source.tasks
        .where((TaskItem task) => !StudyPlan.isManagedRoutineId(task.id))
        .toList(growable: false);
    final List<GoalItem> customGoals = source.goals
        .where((GoalItem goal) => !managedGoalIds.contains(goal.id))
        .toList(growable: false);

    return source.copyWith(
      version: StudyPlan.currentDataVersion,
      tasks: <TaskItem>[...customTasks, ...StudyPlan.buildRoutine()],
      goals: <GoalItem>[...customGoals, ...StudyPlan.buildGoals()],
      habits: source.habits.isEmpty ? StudyPlan.buildHabits() : source.habits,
    );
  }

  void _rebuildIndexes() {
    _rebuildSubjectIndex();
    _rebuildTaskIndexes();
    _rebuildGoalIndex();
    _rebuildNoteIndex();
    _rebuildSessionIndexes();
  }

  void _rebuildSubjectIndex() {
    final Map<String, SubjectItem> subjects = <String, SubjectItem>{
      for (final SubjectItem subject in _data.subjects) subject.id: subject,
    };
    _subjectsById = Map<String, SubjectItem>.unmodifiable(subjects);

    final List<SubjectItem> visibleSubjects = _data.subjects
        .where((SubjectItem subject) => !subject.archived)
        .toList(growable: false);
    _activeSubjects = List<SubjectItem>.unmodifiable(
      visibleSubjects.isEmpty
          ? <SubjectItem>[subjects[StudyPlan.general] ?? _fallbackSubject]
          : visibleSubjects,
    );
  }

  void _rebuildTaskIndexes() {
    final List<TaskItem> active = _data.tasks
        .where((TaskItem task) => !task.isDeleted)
        .toList(growable: false)
      ..sort((TaskItem a, TaskItem b) => a.startAt.compareTo(b.startAt));
    _activeTasks = List<TaskItem>.unmodifiable(active);

    final Map<String, List<TaskItem>> tasksByDate = <String, List<TaskItem>>{};
    final Map<String, List<TaskItem>> pendingByDate =
        <String, List<TaskItem>>{};
    final Map<String, int> totalByDate = <String, int>{};
    final Map<String, int> completedByDate = <String, int>{};
    final Map<String, int> countBySubject = <String, int>{};
    final Set<String> completedDates = <String>{};
    int completedCount = 0;

    for (final TaskItem task in active) {
      final String taskDateKey = dateKey(task.startAt);
      tasksByDate.putIfAbsent(taskDateKey, () => <TaskItem>[]).add(task);
      totalByDate.update(
        taskDateKey,
        (int value) => value + 1,
        ifAbsent: () => 1,
      );
      if (!task.isCompleted) {
        pendingByDate.putIfAbsent(taskDateKey, () => <TaskItem>[]).add(task);
      }
      countBySubject.update(
        task.subjectId,
        (int value) => value + 1,
        ifAbsent: () => 1,
      );
      if (task.isCompleted) {
        completedCount += 1;
        completedDates.add(taskDateKey);
        completedByDate.update(
          taskDateKey,
          (int value) => value + 1,
          ifAbsent: () => 1,
        );
      }
    }

    for (final List<TaskItem> values in tasksByDate.values) {
      values.sort(_compareTaskForDisplay);
    }
    for (final List<TaskItem> values in pendingByDate.values) {
      values.sort(_compareTaskForDisplay);
    }
    _tasksByDate = Map<String, List<TaskItem>>.unmodifiable(
      tasksByDate.map(
        (String key, List<TaskItem> value) => MapEntry<String, List<TaskItem>>(
          key,
          List<TaskItem>.unmodifiable(value),
        ),
      ),
    );
    _pendingTasksByDate = Map<String, List<TaskItem>>.unmodifiable(
      pendingByDate.map(
        (String key, List<TaskItem> value) => MapEntry<String, List<TaskItem>>(
          key,
          List<TaskItem>.unmodifiable(value),
        ),
      ),
    );
    _taskTotalByDate = Map<String, int>.unmodifiable(totalByDate);
    _taskCompletedByDate = Map<String, int>.unmodifiable(completedByDate);
    _taskCountBySubject = Map<String, int>.unmodifiable(countBySubject);
    _completedTaskCount = completedCount;
    _completedTaskDateKeys = Set<String>.unmodifiable(completedDates);
    _refreshProductiveDateIndex();
  }

  void _rebuildGoalIndex() {
    final List<GoalItem> goals = _data.goals
        .where((GoalItem goal) => !goal.isDeleted)
        .toList(growable: false)
      ..sort((GoalItem a, GoalItem b) => a.deadline.compareTo(b.deadline));
    _activeGoals = List<GoalItem>.unmodifiable(goals);
  }

  void _rebuildNoteIndex() {
    final List<NoteItem> notes = _data.notes
        .where((NoteItem note) => !note.isDeleted)
        .toList(growable: false)
      ..sort((NoteItem a, NoteItem b) {
        if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
        return b.updatedAt.compareTo(a.updatedAt);
      });
    _activeNotes = List<NoteItem>.unmodifiable(notes);
  }

  void _rebuildSessionIndexes() {
    final List<FocusSession> sessions = List<FocusSession>.from(_data.sessions)
      ..sort(
        (FocusSession a, FocusSession b) => b.startedAt.compareTo(a.startedAt),
      );
    _recentSessions = List<FocusSession>.unmodifiable(sessions.take(20));

    final Map<String, int> focusByDate = <String, int>{};
    final Map<String, int> focusBySubject = <String, int>{};
    final Set<String> sessionDates = <String>{};
    int totalFocus = 0;
    for (final FocusSession session in _data.sessions) {
      final int minutes = session.actualMinutes.clamp(0, 24 * 60).toInt();
      if (minutes <= 0) continue;
      totalFocus += minutes;
      final String key = dateKey(session.startedAt);
      focusByDate.update(
        key,
        (int value) => value + minutes,
        ifAbsent: () => minutes,
      );
      focusBySubject.update(
        session.subjectId,
        (int value) => value + minutes,
        ifAbsent: () => minutes,
      );
      sessionDates.add(key);
    }
    _focusMinutesByDate = Map<String, int>.unmodifiable(focusByDate);
    _focusMinutesBySubject = Map<String, int>.unmodifiable(focusBySubject);
    _sessionDateKeys = Set<String>.unmodifiable(sessionDates);
    _totalFocusMinutes = totalFocus;
    _refreshProductiveDateIndex();
  }

  void _refreshProductiveDateIndex() {
    _productiveDateKeys = Set<String>.unmodifiable(<String>{
      ..._completedTaskDateKeys,
      ..._sessionDateKeys,
    });
    _currentStreak = _calculateCurrentStreak(_productiveDateKeys);
    _streakCalculatedFor = dateKey(DateTime.now());
  }

  int _calculateCurrentStreak(Set<String> productiveDates) {
    int streak = 0;
    DateTime cursor = dateOnly(DateTime.now());
    for (int index = 0; index < 3650; index += 1) {
      if (!productiveDates.contains(dateKey(cursor))) {
        if (index == 0) {
          cursor = cursor.subtract(const Duration(days: 1));
          continue;
        }
        break;
      }
      streak += 1;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return streak;
  }

  int _firstTaskAfter(DateTime moment) {
    int low = 0;
    int high = _activeTasks.length;
    while (low < high) {
      final int middle = low + ((high - low) >> 1);
      if (_activeTasks[middle].startAt.isAfter(moment)) {
        high = middle;
      } else {
        low = middle + 1;
      }
    }
    return low;
  }

  int _compareTaskForDisplay(TaskItem a, TaskItem b) {
    final int timeOrder = a.startAt.compareTo(b.startAt);
    if (timeOrder != 0) return timeOrder;
    if (a.isCompleted != b.isCompleted) return a.isCompleted ? 1 : -1;
    if (a.priority != b.priority) return b.priority.compareTo(a.priority);
    return a.id.compareTo(b.id);
  }

  SubjectItem subjectById(String id) => _subjectsById[id] ?? _fallbackSubject;

  List<SubjectItem> get activeSubjects => _activeSubjects;
  List<TaskItem> get activeTasks => _activeTasks;
  List<GoalItem> get activeGoals => _activeGoals;
  List<NoteItem> get activeNotes => _activeNotes;
  List<FocusSession> get recentSessions => _recentSessions;
  int get totalFocusMinutes => _totalFocusMinutes;
  int get completedTaskCount => _completedTaskCount;
  int get currentStreak {
    final String todayKey = dateKey(DateTime.now());
    if (_streakCalculatedFor != todayKey) {
      _currentStreak = _calculateCurrentStreak(_productiveDateKeys);
      _streakCalculatedFor = todayKey;
    }
    return _currentStreak;
  }

  int taskCountForSubject(String subjectId) =>
      _taskCountBySubject[subjectId] ?? 0;

  StudyGameStats get gameStats => StudyGameStats.calculate(
        focusMinutes: totalFocusMinutes,
        completedTasks: completedTaskCount,
        streak: currentStreak,
      );

  int completedTaskCountForSubject(String subjectId) {
    int count = 0;
    for (final TaskItem task in _activeTasks) {
      if (task.subjectId == subjectId && task.isCompleted) count += 1;
    }
    return count;
  }

  int effectiveGoalProgress(GoalItem goal) => math.max(
        goal.progress,
        math.min(goal.target, completedTaskCountForSubject(goal.subjectId)),
      );

  double effectiveGoalRatio(GoalItem goal) {
    if (goal.target <= 0) return 0;
    return (effectiveGoalProgress(goal) / goal.target)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  int get completedGoalCount => activeGoals
      .where((GoalItem goal) => effectiveGoalProgress(goal) >= goal.target)
      .length;

  List<TaskItem> tasksFor(DateTime date) {
    final String key = dateKey(date);
    return preferences.showCompleted
        ? _tasksByDate[key] ?? const <TaskItem>[]
        : _pendingTasksByDate[key] ?? const <TaskItem>[];
  }

  List<TaskItem> get todayTasks => tasksFor(DateTime.now());

  TaskItem? currentTaskAt(DateTime moment) {
    final int end = _firstTaskAfter(moment);
    for (int index = end - 1; index >= 0; index -= 1) {
      final TaskItem task = _activeTasks[index];
      if (task.isActiveAt(moment)) return task;
      if (task.startAt.isBefore(moment.subtract(const Duration(days: 1)))) {
        break;
      }
    }
    return null;
  }

  TaskItem? get currentTask => currentTaskAt(DateTime.now());

  int completedTaskCountFor(DateTime date) =>
      _taskCompletedByDate[dateKey(date)] ?? 0;

  int get overdueTaskCount {
    final DateTime now = DateTime.now();
    final int end = _firstTaskAfter(now);
    int count = 0;
    for (int index = 0; index < end; index += 1) {
      final TaskItem task = _activeTasks[index];
      if (!task.isCompleted && !task.endAt.isAfter(now)) count += 1;
    }
    return count;
  }

  List<TaskItem> get upcomingTasks {
    final DateTime now = DateTime.now();
    final int start = _firstTaskAfter(now);
    final List<TaskItem> result = <TaskItem>[];
    for (int index = start; index < _activeTasks.length; index += 1) {
      final TaskItem task = _activeTasks[index];
      if (!task.isCompleted) {
        result.add(task);
        if (result.length == 8) break;
      }
    }
    return List<TaskItem>.unmodifiable(result);
  }

  List<TaskItem> get overdueTasks {
    final DateTime now = DateTime.now();
    final int end = _firstTaskAfter(now);
    final List<TaskItem> result = <TaskItem>[];
    for (int index = 0; index < end; index += 1) {
      final TaskItem task = _activeTasks[index];
      if (!task.isCompleted && !task.endAt.isAfter(now)) {
        result.add(task);
      }
    }
    return List<TaskItem>.unmodifiable(result);
  }

  List<HabitItem> habitsFor(DateTime date) => List<HabitItem>.unmodifiable(
        _data.habits.where(
          (HabitItem habit) => habit.active && habit.isScheduled(date),
        ),
      );

  int daysUntil(DateTime target) =>
      dateOnly(target).difference(dateOnly(DateTime.now())).inDays;

  int completionPercent(DateTime date) {
    final String key = dateKey(date);
    final int total = _taskTotalByDate[key] ?? 0;
    if (total == 0) return 0;
    final int done = _taskCompletedByDate[key] ?? 0;
    return ((done / total) * 100).round();
  }

  int focusMinutesFor(DateTime date) => _focusMinutesByDate[dateKey(date)] ?? 0;

  Map<String, int> focusBySubject() => _focusMinutesBySubject;

  void selectDate(DateTime date) {
    final DateTime next = dateOnly(date);
    if (next == _selectedDate) return;
    _selectedDate = next;
    _safeNotify();
  }

  Future<void> addTask(TaskItem task) async {
    _data = _data.copyWith(tasks: <TaskItem>[..._data.tasks, task]);
    await _commit(reschedule: true, tasksChanged: true);
  }

  Future<void> updateTask(TaskItem task) async {
    _data = _data.copyWith(
      tasks: _data.tasks
          .map((TaskItem item) => item.id == task.id ? task : item)
          .toList(growable: false),
    );
    await _commit(reschedule: true, tasksChanged: true);
  }

  Future<void> duplicateTask(TaskItem task) async {
    final DateTime now = DateTime.now();
    await addTask(
      TaskItem(
        id: newId('task'),
        title: '${task.title} (Copy)',
        subjectId: task.subjectId,
        startAt: task.startAt.add(const Duration(days: 1)),
        durationMinutes: task.durationMinutes,
        priority: task.priority,
        notes: task.notes,
        reminderEnabled: task.reminderEnabled,
        alarmEnabled: task.alarmEnabled,
        snoozeMinutes: task.snoozeMinutes,
        alarmSoundId: task.alarmSoundId,
        alarmSoundLabel: task.alarmSoundLabel,
        alarmSoundUri: task.alarmSoundUri,
        autoFocus: task.autoFocus,
        createdAt: now,
        updatedAt: now,
      ),
    );
  }

  Future<void> setTaskCompleted(TaskItem task, bool completed) async {
    final DateTime now = DateTime.now();
    final TaskItem updated = task.copyWith(
      completedAt: completed ? now : null,
      clearCompletedAt: !completed,
      updatedAt: now,
    );
    _data = _data.copyWith(
      tasks: _data.tasks
          .map((TaskItem item) => item.id == task.id ? updated : item)
          .toList(growable: false),
    );
    if (!_testing) {
      unawaited(
        NativeBridge.setTaskCompleted(task.id, completed).catchError((_) {}),
      );
    }
    await _commit(reschedule: true, tasksChanged: true);
  }

  Future<void> deleteTask(TaskItem task) async {
    await updateTask(
      task.copyWith(deletedAt: DateTime.now(), updatedAt: DateTime.now()),
    );
  }

  Future<void> restoreTask(TaskItem task) async {
    await updateTask(
      task.copyWith(clearDeletedAt: true, updatedAt: DateTime.now()),
    );
  }

  Future<void> permanentlyDeleteTask(String id) async {
    _data = _data.copyWith(
      tasks: _data.tasks
          .where((TaskItem task) => task.id != id)
          .toList(growable: false),
    );
    await _commit(reschedule: true, tasksChanged: true);
  }

  Future<void> addSubject(SubjectItem subject) async {
    _data = _data.copyWith(subjects: <SubjectItem>[..._data.subjects, subject]);
    await _commit(subjectsChanged: true);
  }

  Future<void> updateSubject(SubjectItem subject) async {
    _data = _data.copyWith(
      subjects: _data.subjects
          .map((SubjectItem item) => item.id == subject.id ? subject : item)
          .toList(growable: false),
    );
    await _commit(reschedule: true, subjectsChanged: true);
  }

  Future<void> addGoal(GoalItem goal) async {
    _data = _data.copyWith(goals: <GoalItem>[..._data.goals, goal]);
    await _commit(goalsChanged: true);
  }

  Future<void> updateGoal(GoalItem goal) async {
    _data = _data.copyWith(
      goals: _data.goals
          .map((GoalItem item) => item.id == goal.id ? goal : item)
          .toList(growable: false),
    );
    await _commit(goalsChanged: true);
  }

  Future<void> deleteGoal(GoalItem goal) async {
    await updateGoal(
      goal.copyWith(deletedAt: DateTime.now(), updatedAt: DateTime.now()),
    );
  }

  Future<void> restoreGoal(GoalItem goal) async {
    await updateGoal(
      goal.copyWith(clearDeletedAt: true, updatedAt: DateTime.now()),
    );
  }

  Future<void> permanentlyDeleteGoal(String id) async {
    _data = _data.copyWith(
      goals: _data.goals
          .where((GoalItem goal) => goal.id != id)
          .toList(growable: false),
    );
    await _commit(goalsChanged: true);
  }

  Future<void> addHabit(HabitItem habit) async {
    _data = _data.copyWith(habits: <HabitItem>[..._data.habits, habit]);
    await _commit();
  }

  Future<void> updateHabit(HabitItem habit) async {
    _data = _data.copyWith(
      habits: _data.habits
          .map((HabitItem item) => item.id == habit.id ? habit : item)
          .toList(growable: false),
    );
    await _commit();
  }

  Future<void> deleteHabit(String id) async {
    _data = _data.copyWith(
      habits: _data.habits
          .where((HabitItem habit) => habit.id != id)
          .toList(growable: false),
    );
    await _commit();
  }

  Future<void> toggleHabit(HabitItem habit, DateTime date) async {
    final Set<String> completed = habit.completedDateKeys.toSet();
    final String key = dateKey(date);
    if (!completed.remove(key)) completed.add(key);
    await updateHabit(
      habit.copyWith(completedDateKeys: completed.toList(growable: false)),
    );
  }

  Future<void> addNote(NoteItem note) async {
    _data = _data.copyWith(notes: <NoteItem>[..._data.notes, note]);
    await _commit(notesChanged: true);
  }

  Future<void> updateNote(NoteItem note) async {
    _data = _data.copyWith(
      notes: _data.notes
          .map((NoteItem item) => item.id == note.id ? note : item)
          .toList(growable: false),
    );
    await _commit(notesChanged: true);
  }

  Future<void> deleteNote(NoteItem note) async {
    await updateNote(
      note.copyWith(deletedAt: DateTime.now(), updatedAt: DateTime.now()),
    );
  }

  Future<void> restoreNote(NoteItem note) async {
    await updateNote(
      note.copyWith(clearDeletedAt: true, updatedAt: DateTime.now()),
    );
  }

  Future<void> permanentlyDeleteNote(String id) async {
    _data = _data.copyWith(
      notes: _data.notes
          .where((NoteItem note) => note.id != id)
          .toList(growable: false),
    );
    await _commit(notesChanged: true);
  }

  Future<void> addSession(FocusSession session) async {
    _data = _data.copyWith(
      sessions: <FocusSession>[..._data.sessions, session],
    );
    await _commit(sessionsChanged: true);
  }

  Future<void> updatePreferences(AppPreferencesModel preferences) async {
    _data = _data.copyWith(preferences: preferences);
    await _commit();
  }

  Future<void> resetRoutineFromJuly26() async {
    final List<TaskItem> customTasks = _data.tasks
        .where((TaskItem task) => !StudyPlan.isManagedRoutineId(task.id))
        .toList(growable: false);
    final Set<String> managedGoalIds =
        StudyPlan.buildGoals().map((GoalItem goal) => goal.id).toSet();
    final List<GoalItem> customGoals = _data.goals
        .where((GoalItem goal) => !managedGoalIds.contains(goal.id))
        .toList(growable: false);
    _data = _data.copyWith(
      version: StudyPlan.currentDataVersion,
      tasks: <TaskItem>[...customTasks, ...StudyPlan.buildRoutine()],
      goals: <GoalItem>[...customGoals, ...StudyPlan.buildGoals()],
    );
    _selectedDate = dateOnly(StudyPlan.routineAnchor);
    await _commit(
      reschedule: true,
      rebuildAll: true,
      awaitPersistence: true,
    );
  }

  Future<void> completeOnboarding(String name) async {
    final String safeName = name.trim().isEmpty ? 'Hredoy' : name.trim();
    await updatePreferences(
      preferences.copyWith(userName: safeName, onboardingComplete: true),
    );
  }

  Future<void> showOnboardingAgain() async {
    await updatePreferences(preferences.copyWith(onboardingComplete: false));
  }

  Future<void> refreshNativeCompletions() async {
    if (_testing) return;
    try {
      final Set<String> completed = await NativeBridge.completedTaskIds();
      bool changed = false;
      final DateTime now = DateTime.now();
      final List<TaskItem> tasks = _data.tasks.map((TaskItem task) {
        if (completed.contains(task.id) && !task.isCompleted) {
          changed = true;
          return task.copyWith(completedAt: now, updatedAt: now);
        }
        return task;
      }).toList(growable: false);
      if (changed) {
        _data = _data.copyWith(tasks: tasks);
        await _commit(reschedule: true, tasksChanged: true);
      }
    } catch (_) {
      // Manual refresh remains safe when Android services are unavailable.
    }
  }

  String exportJson() => _store.encode(_data);

  Future<String> exportJsonAsync() => _store.encodeAsync(_data);

  Future<void> importJson(String raw) async {
    final AppData imported = await _store.decodeAsync(raw);
    if (imported.version < 2) {
      throw const FormatException('This backup version is too old.');
    }
    _data = imported.version < StudyPlan.currentDataVersion
        ? _migrateToCurrentVersion(imported)
        : imported;
    await _commit(
      reschedule: true,
      rebuildAll: true,
      awaitPersistence: true,
    );
  }

  Future<void> resetAllData() async {
    _data = StudyPlan.initialData();
    _selectedDate = dateOnly(DateTime.now());
    await _commit(
      reschedule: true,
      rebuildAll: true,
      awaitPersistence: true,
    );
  }

  Future<void> _commit({
    bool reschedule = false,
    bool rebuildAll = false,
    bool subjectsChanged = false,
    bool tasksChanged = false,
    bool goalsChanged = false,
    bool notesChanged = false,
    bool sessionsChanged = false,
    bool awaitPersistence = false,
  }) async {
    if (rebuildAll) {
      _rebuildIndexes();
    } else {
      if (subjectsChanged) _rebuildSubjectIndex();
      if (tasksChanged) _rebuildTaskIndexes();
      if (goalsChanged) _rebuildGoalIndex();
      if (notesChanged) _rebuildNoteIndex();
      if (sessionsChanged) _rebuildSessionIndexes();
    }
    _safeNotify();
    if (_testing) return;

    final AppData snapshot = _data;
    final Future<void> persistence = _scheduleSave(
      snapshot,
      immediate: awaitPersistence,
    );
    if (awaitPersistence) {
      await persistence;
    } else {
      unawaited(persistence.catchError((_) {}));
    }
    if (reschedule) {
      // Alarm replacement happens in the background. The in-memory state is
      // already committed, and both persistence and AlarmManager work are
      // coalesced so the UI never waits behind obsolete snapshots.
      unawaited(_queueNativeReschedule(snapshot));
    }
  }

  Future<void> _scheduleSave(
    AppData snapshot, {
    bool immediate = false,
  }) {
    if (_testing) return Future<void>.value();
    _pendingSaveSnapshot = snapshot;
    final Completer<void> completer = _saveFlushCompleter ??= Completer<void>();
    _saveDebounce?.cancel();
    if (immediate) {
      unawaited(_drainPendingSaves());
    } else if (!_saveWorkerRunning) {
      _saveDebounce = Timer(
        const Duration(milliseconds: 140),
        () => unawaited(_drainPendingSaves()),
      );
    }
    return completer.future;
  }

  Future<void> _drainPendingSaves() async {
    if (_testing || _saveWorkerRunning) return;
    _saveWorkerRunning = true;
    _saveDebounce?.cancel();
    _saveDebounce = null;
    Object? failure;
    StackTrace? failureStack;
    AppData? failedSnapshot;
    try {
      while (_pendingSaveSnapshot != null) {
        final AppData snapshot = _pendingSaveSnapshot!;
        _pendingSaveSnapshot = null;
        try {
          await _store.save(snapshot);
        } catch (_) {
          failedSnapshot = snapshot;
          rethrow;
        }
      }
    } catch (error, stack) {
      failure = error;
      failureStack = stack;
      // Never discard an unsaved state. A newer pending snapshot wins;
      // otherwise keep the failed snapshot for the next lifecycle flush or
      // mutation instead of entering an uncontrolled retry loop.
      _pendingSaveSnapshot ??= failedSnapshot;
    } finally {
      _saveWorkerRunning = false;
      final Completer<void>? completer = _saveFlushCompleter;
      _saveFlushCompleter = null;
      if (failure == null) {
        if (completer != null && !completer.isCompleted) completer.complete();
      } else if (completer != null && !completer.isCompleted) {
        completer.completeError(failure, failureStack);
      }
      if (failure == null && _pendingSaveSnapshot != null) {
        unawaited(_drainPendingSaves());
      }
    }
  }

  Future<void> flushPendingWrites() {
    if (_testing) return Future<void>.value();
    _saveDebounce?.cancel();
    _saveDebounce = null;
    if (_pendingSaveSnapshot != null) {
      final Completer<void> completer =
          _saveFlushCompleter ??= Completer<void>();
      if (!_saveWorkerRunning) {
        unawaited(_drainPendingSaves());
      }
      return completer.future;
    }
    return _saveFlushCompleter?.future ?? Future<void>.value();
  }

  Future<void> _queueNativeReschedule(AppData snapshot, {bool force = false}) {
    if (_testing) return Future<void>.value();
    // Keep only the newest task snapshot. Rapid CRUD operations should not
    // queue many obsolete AlarmManager synchronizations behind each other.
    _pendingNativeSnapshot = snapshot;
    _pendingNativeForce = _pendingNativeForce || force;
    final Completer<void> completer =
        _nativeFlushCompleter ??= Completer<void>();
    if (!_nativeSyncRunning) {
      unawaited(_drainNativeReschedules());
    }
    return completer.future;
  }

  Future<void> _drainNativeReschedules() async {
    if (_testing || _nativeSyncRunning) return;
    _nativeSyncRunning = true;
    try {
      while (_pendingNativeSnapshot != null) {
        final AppData snapshot = _pendingNativeSnapshot!;
        final bool force = _pendingNativeForce;
        _pendingNativeSnapshot = null;
        _pendingNativeForce = false;
        await _rescheduleReminders(snapshot, force: force);
      }
    } finally {
      _nativeSyncRunning = false;
      final Completer<void>? completer = _nativeFlushCompleter;
      _nativeFlushCompleter = null;
      if (completer != null && !completer.isCompleted) completer.complete();
      if (_pendingNativeSnapshot != null) {
        unawaited(_drainNativeReschedules());
      }
    }
  }

  Future<void> _rescheduleReminders(
    AppData snapshot, {
    bool force = false,
  }) async {
    final List<TaskItem> reminders = snapshot.tasks
        .where(
          (TaskItem task) =>
              !task.isDeleted &&
              !task.isCompleted &&
              (task.reminderEnabled || task.alarmEnabled),
        )
        .toList(growable: false);
    final Map<String, String> names = <String, String>{
      for (final SubjectItem subject in snapshot.subjects)
        subject.id: subject.name,
    };
    try {
      await NativeBridge.initialize(
        reminders,
        (String subjectId) => names[subjectId] ?? 'General',
        forceReschedule: force,
      );
    } catch (_) {
      // The next startup and each later task mutation retries scheduling.
    }
  }

  void _safeNotify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _saveDebounce?.cancel();
    unawaited(flushPendingWrites().catchError((_) {}));
    super.dispose();
  }
}

class AppScope extends InheritedNotifier<AppController> {
  const AppScope({
    required AppController controller,
    required super.child,
    super.key,
  }) : super(notifier: controller);

  static AppController of(BuildContext context) {
    final AppScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope was not found in the widget tree.');
    return scope!.notifier!;
  }

  /// Reads without subscribing. Form routes use this so saving and popping do
  /// not rebuild the route in the same frame.
  static AppController read(BuildContext context) {
    final AppScope? scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope was not found in the widget tree.');
    return scope!.notifier!;
  }
}
