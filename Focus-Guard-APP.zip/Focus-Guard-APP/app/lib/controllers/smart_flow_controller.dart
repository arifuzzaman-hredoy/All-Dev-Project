import 'dart:convert';
import 'dart:io';

import 'package:flutter/widgets.dart';

import '../models/smart_flow.dart';
import '../services/native_bridge.dart';

class SmartFlowController extends ChangeNotifier {
  SmartFlowController._(this._settings, {this.testing = false});

  final bool testing;
  SmartFlowSettings _settings;
  String? _directoryPath;
  Future<void>? _writeInFlight;
  bool _disposed = false;

  SmartFlowSettings get settings => _settings;

  static Future<SmartFlowController> create() async {
    String path;
    try {
      path = await NativeBridge.appDataPath();
    } catch (_) {
      path = '${Directory.systemTemp.path}/hredoy_flow';
    }
    final File file = File('$path/hredoy_flow_smart_v1.json');
    SmartFlowSettings settings = const SmartFlowSettings();
    if (await file.exists()) {
      try {
        final Object? decoded = jsonDecode(await file.readAsString());
        if (decoded is Map<Object?, Object?>) {
          settings = SmartFlowSettings.fromJson(
            decoded.cast<String, Object?>(),
          );
        }
      } catch (_) {
        settings = const SmartFlowSettings();
      }
    }
    final SmartFlowController controller = SmartFlowController._(settings);
    controller._directoryPath = path;
    return controller;
  }

  static SmartFlowController createForTesting({
    SmartFlowSettings settings = const SmartFlowSettings(),
  }) =>
      SmartFlowController._(settings, testing: true);

  Future<void> setExperienceMode(ExperienceMode mode) =>
      _update(_settings.copyWith(experienceMode: mode));

  Future<void> setDailyCoachEnabled(bool value) =>
      _update(_settings.copyWith(dailyCoachEnabled: value));

  Future<void> setWeeklyReportEnabled(bool value) =>
      _update(_settings.copyWith(weeklyReportEnabled: value));

  Future<void> setRecommendationsEnabled(bool value) =>
      _update(_settings.copyWith(smartRecommendationsEnabled: value));

  Future<void> setRulePreviewRequired(bool value) =>
      _update(_settings.copyWith(rulePreviewRequired: value));

  Future<void> setSimpleShortcuts(Set<String> values) =>
      _update(_settings.copyWith(simpleShortcutIds: Set<String>.from(values)));

  Future<void> setAlwaysAllowedPackages(Set<String> values) => _update(
        _settings.copyWith(
          userAlwaysAllowedPackages: Set<String>.from(values),
        ),
      );

  Future<void> recordSafetyStop() => _update(
        _settings.copyWith(
          lastSafetyStopMillis: DateTime.now().millisecondsSinceEpoch,
        ),
      );

  Future<void> _update(SmartFlowSettings next) async {
    if (_disposed) return;
    _settings = next;
    notifyListeners();
    await _persist();
  }

  Future<void> _persist() {
    if (testing || _directoryPath == null) return Future<void>.value();
    final Future<void> previous =
        _writeInFlight ?? Future<void>.value();
    final Future<void> write = previous.then<void>(
      (_) => _writeSettings(),
      onError: (Object _, StackTrace __) => _writeSettings(),
    );
    _writeInFlight = write;
    return write;
  }

  Future<void> _writeSettings() async {
    final Directory directory = Directory(_directoryPath!);
    await directory.create(recursive: true);
    final File target = File('${directory.path}/hredoy_flow_smart_v1.json');
    final File temp = File('${directory.path}/hredoy_flow_smart_v1.tmp');
    await temp.writeAsString(jsonEncode(_settings.toJson()), flush: true);
    if (await target.exists()) await target.delete();
    await temp.rename(target.path);
  }

  Future<void> flushPendingWrites() => _writeInFlight ?? Future<void>.value();

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}

class SmartFlowScope extends InheritedNotifier<SmartFlowController> {
  const SmartFlowScope({
    required SmartFlowController controller,
    required super.child,
    super.key,
  }) : super(notifier: controller);

  static SmartFlowController of(BuildContext context) {
    final SmartFlowScope? scope =
        context.dependOnInheritedWidgetOfExactType<SmartFlowScope>();
    assert(scope != null, 'SmartFlowScope is missing.');
    return scope!.notifier!;
  }

  static SmartFlowController? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<SmartFlowScope>()?.notifier;
}
