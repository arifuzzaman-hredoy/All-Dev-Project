import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'controllers/app_controller.dart';
import 'controllers/smart_flow_controller.dart';
import 'screens/onboarding_screen.dart';
import 'screens/root_screen.dart';
import 'widgets/app_logo.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  unawaited(
    SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]),
  );
  runApp(const HredoyFlowBootstrap());
}

class HredoyFlowBootstrap extends StatefulWidget {
  const HredoyFlowBootstrap({super.key});

  @override
  State<HredoyFlowBootstrap> createState() => _HredoyFlowBootstrapState();
}

class _HredoyFlowBootstrapState extends State<HredoyFlowBootstrap> {
  late final Future<_BootstrapControllers> _controllerFuture =
      _createControllers();

  Future<_BootstrapControllers> _createControllers() async {
    final AppController appController = await AppController.create();
    final SmartFlowController smartController =
        await SmartFlowController.create();
    return _BootstrapControllers(appController, smartController);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<_BootstrapControllers>(
        future: _controllerFuture,
        builder: (
          BuildContext context,
          AsyncSnapshot<_BootstrapControllers> snapshot,
        ) {
          final _BootstrapControllers? controllers = snapshot.data;
          if (controllers != null) {
            return AppScope(
              controller: controllers.app,
              child: HredoyFlowApp(
                controller: controllers.app,
                smartController: controllers.smart,
              ),
            );
          }
          if (snapshot.hasError) {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              home: Scaffold(
                body: SafeArea(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          const AppLogo(size: 72),
                          const SizedBox(height: 20),
                          const Text(
                            'Hredoy Flow could not open local data.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            '${snapshot.error}',
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          }
          return const MaterialApp(
            debugShowCheckedModeBanner: false,
            home: _FastStartupScreen(),
          );
        },
      );
}

class _BootstrapControllers {
  const _BootstrapControllers(this.app, this.smart);

  final AppController app;
  final SmartFlowController smart;
}

class _FastStartupScreen extends StatelessWidget {
  const _FastStartupScreen();

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              AppLogo(size: 76),
              SizedBox(height: 18),
              Text(
                'Hredoy Flow',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              SizedBox(height: 18),
              SizedBox.square(
                dimension: 26,
                child: CircularProgressIndicator(strokeWidth: 2.5),
              ),
            ],
          ),
        ),
      );
}

class HredoyFlowApp extends StatefulWidget {
  const HredoyFlowApp({
    required this.controller,
    this.smartController,
    super.key,
  });

  final AppController controller;
  final SmartFlowController? smartController;

  @override
  State<HredoyFlowApp> createState() => _HredoyFlowAppState();
}

class _HredoyFlowAppState extends State<HredoyFlowApp>
    with WidgetsBindingObserver {
  late ThemeMode _themeMode;
  late int _accentValue;
  late bool _onboardingComplete;
  late SmartFlowController _smartController;
  bool _ownsSmartController = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _smartController = widget.smartController ??
        SmartFlowController.createForTesting();
    _ownsSmartController = widget.smartController == null;
    _readPresentationState();
    widget.controller.addListener(_handleControllerChange);
  }

  @override
  void didUpdateWidget(covariant HredoyFlowApp oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_handleControllerChange);
      _readPresentationState();
      widget.controller.addListener(_handleControllerChange);
    }
    if (oldWidget.smartController != widget.smartController &&
        widget.smartController != null) {
      if (_ownsSmartController) _smartController.dispose();
      _smartController = widget.smartController!;
      _ownsSmartController = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      unawaited(widget.controller.flushPendingWrites().catchError((_) {}));
      unawaited(_smartController.flushPendingWrites().catchError((_) {}));
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    widget.controller.removeListener(_handleControllerChange);
    unawaited(widget.controller.flushPendingWrites().catchError((_) {}));
    unawaited(_smartController.flushPendingWrites().catchError((_) {}));
    if (_ownsSmartController) _smartController.dispose();
    super.dispose();
  }

  void _readPresentationState() {
    final preferences = widget.controller.preferences;
    _themeMode = preferences.materialThemeMode;
    _accentValue = preferences.accentValue;
    _onboardingComplete = preferences.onboardingComplete;
  }

  void _handleControllerChange() {
    final preferences = widget.controller.preferences;
    final ThemeMode nextThemeMode = preferences.materialThemeMode;
    final int nextAccentValue = preferences.accentValue;
    final bool nextOnboardingComplete = preferences.onboardingComplete;

    if (nextThemeMode == _themeMode &&
        nextAccentValue == _accentValue &&
        nextOnboardingComplete == _onboardingComplete) {
      return;
    }
    if (!mounted) return;
    setState(() {
      _themeMode = nextThemeMode;
      _accentValue = nextAccentValue;
      _onboardingComplete = nextOnboardingComplete;
    });
  }

  @override
  Widget build(BuildContext context) {
    final Color seed = Color(_accentValue);
    return SmartFlowScope(
      controller: _smartController,
      child: MaterialApp(
        title: 'Hredoy Flow',
        debugShowCheckedModeBanner: false,
        themeMode: _themeMode,
        theme: _theme(seed, Brightness.light),
        darkTheme: _theme(seed, Brightness.dark),
        home:
            _onboardingComplete ? const RootScreen() : const OnboardingScreen(),
      ),
    );
  }

  ThemeData _theme(Color seed, Brightness brightness) {
    final ColorScheme colors = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: brightness,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: colors,
      scaffoldBackgroundColor: brightness == Brightness.dark
          ? const Color(0xFF101316)
          : const Color(0xFFF4F7FB),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: colors.onSurface,
          fontSize: 21,
          fontWeight: FontWeight.w900,
          letterSpacing: -0.35,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: colors.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colors.surfaceContainerLow,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: colors.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: colors.primary, width: 1.6),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        elevation: 0,
        backgroundColor: colors.surface,
        indicatorColor: colors.primaryContainer,
        labelTextStyle: WidgetStatePropertyAll<TextStyle>(
          TextStyle(fontSize: 11, color: colors.onSurface),
        ),
      ),
    );
  }
}
