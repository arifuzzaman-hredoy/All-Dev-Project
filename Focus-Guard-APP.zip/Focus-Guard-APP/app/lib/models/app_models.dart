// ignore_for_file: non_const_argument_for_const_parameter

import 'package:flutter/material.dart';

import 'alarm_sounds.dart';
import 'app_icon_catalog.dart';

String dateKey(DateTime value) {
  final DateTime date = DateTime(value.year, value.month, value.day);
  return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
}

DateTime dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day);

String newId(String prefix) =>
    '$prefix-${DateTime.now().microsecondsSinceEpoch}';

class SubjectItem {
  const SubjectItem({
    required this.id,
    required this.name,
    required this.colorValue,
    required this.iconCodePoint,
    this.archived = false,
  });

  final String id;
  final String name;
  final int colorValue;
  final int iconCodePoint;
  final bool archived;

  Color get color => Color(colorValue);
  IconData get icon => AppIconCatalog.resolve(
        iconCodePoint,
        fallback: Icons.menu_book_rounded,
      );

  SubjectItem copyWith({
    String? name,
    int? colorValue,
    int? iconCodePoint,
    bool? archived,
  }) =>
      SubjectItem(
        id: id,
        name: name ?? this.name,
        colorValue: colorValue ?? this.colorValue,
        iconCodePoint: iconCodePoint ?? this.iconCodePoint,
        archived: archived ?? this.archived,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'name': name,
        'colorValue': colorValue,
        'iconCodePoint': iconCodePoint,
        'archived': archived,
      };

  factory SubjectItem.fromJson(Map<String, Object?> json) => SubjectItem(
        id: json['id']! as String,
        name: json['name']! as String,
        colorValue: (json['colorValue']! as num).toInt(),
        iconCodePoint: (json['iconCodePoint']! as num).toInt(),
        archived: json['archived'] as bool? ?? false,
      );
}

class TaskItem {
  const TaskItem({
    required this.id,
    required this.title,
    required this.subjectId,
    required this.startAt,
    required this.durationMinutes,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
    this.notes = '',
    this.reminderEnabled = true,
    this.alarmEnabled = true,
    this.snoozeMinutes = 5,
    this.alarmSoundId = AlarmSoundCatalog.smartId,
    this.alarmSoundLabel = AlarmSoundCatalog.smartLabel,
    this.alarmSoundUri = '',
    this.autoFocus = false,
    this.completedAt,
    this.deletedAt,
  });

  final String id;
  final String title;
  final String subjectId;
  final DateTime startAt;
  final int durationMinutes;
  final int priority;
  final String notes;
  final bool reminderEnabled;
  final bool alarmEnabled;
  final int snoozeMinutes;
  final String alarmSoundId;
  final String alarmSoundLabel;
  final String alarmSoundUri;
  final bool autoFocus;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? completedAt;
  final DateTime? deletedAt;

  bool get isCompleted => completedAt != null;
  bool get isDeleted => deletedAt != null;
  DateTime get endAt => startAt.add(Duration(minutes: durationMinutes));

  bool isActiveAt(DateTime moment) =>
      !isCompleted &&
      !isDeleted &&
      !moment.isBefore(startAt) &&
      moment.isBefore(endAt);

  bool get isOverdue =>
      !isCompleted && !isDeleted && endAt.isBefore(DateTime.now());

  TaskItem copyWith({
    String? title,
    String? subjectId,
    DateTime? startAt,
    int? durationMinutes,
    int? priority,
    String? notes,
    bool? reminderEnabled,
    bool? alarmEnabled,
    int? snoozeMinutes,
    String? alarmSoundId,
    String? alarmSoundLabel,
    String? alarmSoundUri,
    bool? autoFocus,
    DateTime? completedAt,
    bool clearCompletedAt = false,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
    DateTime? updatedAt,
  }) =>
      TaskItem(
        id: id,
        title: title ?? this.title,
        subjectId: subjectId ?? this.subjectId,
        startAt: startAt ?? this.startAt,
        durationMinutes: durationMinutes ?? this.durationMinutes,
        priority: priority ?? this.priority,
        notes: notes ?? this.notes,
        reminderEnabled: reminderEnabled ?? this.reminderEnabled,
        alarmEnabled: alarmEnabled ?? this.alarmEnabled,
        snoozeMinutes: snoozeMinutes ?? this.snoozeMinutes,
        alarmSoundId: alarmSoundId ?? this.alarmSoundId,
        alarmSoundLabel: alarmSoundLabel ?? this.alarmSoundLabel,
        alarmSoundUri: alarmSoundUri ?? this.alarmSoundUri,
        autoFocus: autoFocus ?? this.autoFocus,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        completedAt: clearCompletedAt ? null : completedAt ?? this.completedAt,
        deletedAt: clearDeletedAt ? null : deletedAt ?? this.deletedAt,
      );

  Map<String, Object> toNativeMap(String category) => <String, Object>{
        'id': id,
        'triggerAtMillis': startAt.millisecondsSinceEpoch,
        'title': title,
        'category': category,
        'notes': notes,
        'durationMinutes': durationMinutes,
        'alarmEnabled': alarmEnabled,
        'snoozeMinutes': snoozeMinutes,
        'alarmSoundId': alarmSoundId,
        'alarmSoundLabel': alarmSoundLabel,
        'alarmSoundUri': alarmSoundUri,
        'autoFocus': autoFocus,
      };

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'subjectId': subjectId,
        'startAt': startAt.toIso8601String(),
        'durationMinutes': durationMinutes,
        'priority': priority,
        'notes': notes,
        'reminderEnabled': reminderEnabled,
        'alarmEnabled': alarmEnabled,
        'snoozeMinutes': snoozeMinutes,
        'alarmSoundId': alarmSoundId,
        'alarmSoundLabel': alarmSoundLabel,
        'alarmSoundUri': alarmSoundUri,
        'autoFocus': autoFocus,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'deletedAt': deletedAt?.toIso8601String(),
      };

  factory TaskItem.fromJson(Map<String, Object?> json) => TaskItem(
        id: json['id']! as String,
        title: json['title']! as String,
        subjectId: json['subjectId']! as String,
        startAt: DateTime.parse(json['startAt']! as String),
        durationMinutes: (json['durationMinutes']! as num).toInt(),
        priority: (json['priority'] as num?)?.toInt() ?? 2,
        notes: json['notes'] as String? ?? '',
        reminderEnabled: json['reminderEnabled'] as bool? ?? true,
        alarmEnabled: json['alarmEnabled'] as bool? ?? true,
        snoozeMinutes: (json['snoozeMinutes'] as num?)?.toInt() ?? 5,
        alarmSoundId:
            json['alarmSoundId'] as String? ?? AlarmSoundCatalog.smartId,
        alarmSoundLabel:
            json['alarmSoundLabel'] as String? ?? AlarmSoundCatalog.smartLabel,
        alarmSoundUri: json['alarmSoundUri'] as String? ?? '',
        autoFocus: json['autoFocus'] as bool? ?? false,
        createdAt: DateTime.parse(json['createdAt']! as String),
        updatedAt: DateTime.parse(json['updatedAt']! as String),
        completedAt: (json['completedAt'] as String?) == null
            ? null
            : DateTime.parse(json['completedAt']! as String),
        deletedAt: (json['deletedAt'] as String?) == null
            ? null
            : DateTime.parse(json['deletedAt']! as String),
      );
}

class GoalItem {
  const GoalItem({
    required this.id,
    required this.title,
    required this.subjectId,
    required this.target,
    required this.progress,
    required this.deadline,
    required this.createdAt,
    required this.updatedAt,
    this.notes = '',
    this.deletedAt,
  });

  final String id;
  final String title;
  final String subjectId;
  final int target;
  final int progress;
  final DateTime deadline;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? deletedAt;

  bool get isCompleted => progress >= target;
  bool get isDeleted => deletedAt != null;
  double get ratio =>
      target <= 0 ? 0.0 : (progress / target).clamp(0, 1).toDouble();

  GoalItem copyWith({
    String? title,
    String? subjectId,
    int? target,
    int? progress,
    DateTime? deadline,
    String? notes,
    DateTime? updatedAt,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) =>
      GoalItem(
        id: id,
        title: title ?? this.title,
        subjectId: subjectId ?? this.subjectId,
        target: target ?? this.target,
        progress: progress ?? this.progress,
        deadline: deadline ?? this.deadline,
        notes: notes ?? this.notes,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: clearDeletedAt ? null : deletedAt ?? this.deletedAt,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'subjectId': subjectId,
        'target': target,
        'progress': progress,
        'deadline': deadline.toIso8601String(),
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'deletedAt': deletedAt?.toIso8601String(),
      };

  factory GoalItem.fromJson(Map<String, Object?> json) => GoalItem(
        id: json['id']! as String,
        title: json['title']! as String,
        subjectId: json['subjectId']! as String,
        target: (json['target']! as num).toInt(),
        progress: (json['progress']! as num).toInt(),
        deadline: DateTime.parse(json['deadline']! as String),
        notes: json['notes'] as String? ?? '',
        createdAt: DateTime.parse(json['createdAt']! as String),
        updatedAt: DateTime.parse(json['updatedAt']! as String),
        deletedAt: (json['deletedAt'] as String?) == null
            ? null
            : DateTime.parse(json['deletedAt']! as String),
      );
}

class HabitItem {
  const HabitItem({
    required this.id,
    required this.title,
    required this.colorValue,
    required this.iconCodePoint,
    required this.weekdays,
    required this.completedDateKeys,
    required this.createdAt,
    this.active = true,
  });

  final String id;
  final String title;
  final int colorValue;
  final int iconCodePoint;
  final List<int> weekdays;
  final List<String> completedDateKeys;
  final DateTime createdAt;
  final bool active;

  Color get color => Color(colorValue);
  IconData get icon => AppIconCatalog.resolve(
        iconCodePoint,
        fallback: Icons.check_circle_rounded,
      );
  bool isScheduled(DateTime date) => weekdays.contains(date.weekday);
  bool isDone(DateTime date) => completedDateKeys.contains(dateKey(date));

  HabitItem copyWith({
    String? title,
    int? colorValue,
    int? iconCodePoint,
    List<int>? weekdays,
    List<String>? completedDateKeys,
    bool? active,
  }) =>
      HabitItem(
        id: id,
        title: title ?? this.title,
        colorValue: colorValue ?? this.colorValue,
        iconCodePoint: iconCodePoint ?? this.iconCodePoint,
        weekdays: weekdays ?? this.weekdays,
        completedDateKeys: completedDateKeys ?? this.completedDateKeys,
        createdAt: createdAt,
        active: active ?? this.active,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'colorValue': colorValue,
        'iconCodePoint': iconCodePoint,
        'weekdays': weekdays,
        'completedDateKeys': completedDateKeys,
        'createdAt': createdAt.toIso8601String(),
        'active': active,
      };

  factory HabitItem.fromJson(Map<String, Object?> json) => HabitItem(
        id: json['id']! as String,
        title: json['title']! as String,
        colorValue: (json['colorValue']! as num).toInt(),
        iconCodePoint: (json['iconCodePoint']! as num).toInt(),
        weekdays: (json['weekdays']! as List<Object?>)
            .map((Object? value) => (value! as num).toInt())
            .toList(),
        completedDateKeys:
            (json['completedDateKeys'] as List<Object?>? ?? <Object?>[])
                .map((Object? value) => value! as String)
                .toList(),
        createdAt: DateTime.parse(json['createdAt']! as String),
        active: json['active'] as bool? ?? true,
      );
}

class NoteItem {
  const NoteItem({
    required this.id,
    required this.title,
    required this.body,
    required this.subjectId,
    required this.createdAt,
    required this.updatedAt,
    this.pinned = false,
    this.deletedAt,
  });

  final String id;
  final String title;
  final String body;
  final String subjectId;
  final bool pinned;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? deletedAt;

  bool get isDeleted => deletedAt != null;

  NoteItem copyWith({
    String? title,
    String? body,
    String? subjectId,
    bool? pinned,
    DateTime? updatedAt,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) =>
      NoteItem(
        id: id,
        title: title ?? this.title,
        body: body ?? this.body,
        subjectId: subjectId ?? this.subjectId,
        pinned: pinned ?? this.pinned,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: clearDeletedAt ? null : deletedAt ?? this.deletedAt,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'body': body,
        'subjectId': subjectId,
        'pinned': pinned,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'deletedAt': deletedAt?.toIso8601String(),
      };

  factory NoteItem.fromJson(Map<String, Object?> json) => NoteItem(
        id: json['id']! as String,
        title: json['title']! as String,
        body: json['body'] as String? ?? '',
        subjectId: json['subjectId'] as String? ?? 'general',
        pinned: json['pinned'] as bool? ?? false,
        createdAt: DateTime.parse(json['createdAt']! as String),
        updatedAt: DateTime.parse(json['updatedAt']! as String),
        deletedAt: (json['deletedAt'] as String?) == null
            ? null
            : DateTime.parse(json['deletedAt']! as String),
      );
}

class FocusSession {
  const FocusSession({
    required this.id,
    required this.label,
    required this.taskId,
    required this.subjectId,
    required this.startedAt,
    required this.endedAt,
    required this.plannedMinutes,
    required this.actualMinutes,
    required this.completed,
    this.note = '',
  });

  final String id;
  final String label;
  final String? taskId;
  final String subjectId;
  final DateTime startedAt;
  final DateTime endedAt;
  final int plannedMinutes;
  final int actualMinutes;
  final bool completed;
  final String note;

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'label': label,
        'taskId': taskId,
        'subjectId': subjectId,
        'startedAt': startedAt.toIso8601String(),
        'endedAt': endedAt.toIso8601String(),
        'plannedMinutes': plannedMinutes,
        'actualMinutes': actualMinutes,
        'completed': completed,
        'note': note,
      };

  factory FocusSession.fromJson(Map<String, Object?> json) => FocusSession(
        id: json['id']! as String,
        label: json['label']! as String,
        taskId: json['taskId'] as String?,
        subjectId: json['subjectId'] as String? ?? 'general',
        startedAt: DateTime.parse(json['startedAt']! as String),
        endedAt: DateTime.parse(json['endedAt']! as String),
        plannedMinutes: (json['plannedMinutes']! as num).toInt(),
        actualMinutes: (json['actualMinutes']! as num).toInt(),
        completed: json['completed'] as bool? ?? false,
        note: json['note'] as String? ?? '',
      );
}

class AppPreferencesModel {
  const AppPreferencesModel({
    required this.userName,
    required this.themeMode,
    required this.accentValue,
    required this.syllabusTarget,
    required this.examDate,
    required this.defaultFocusMinutes,
    required this.strictFocus,
    required this.showCompleted,
    this.onboardingComplete = false,
    this.defaultTaskAlarm = true,
    this.defaultSnoozeMinutes = 5,
    this.defaultAlarmSoundId = AlarmSoundCatalog.smartId,
    this.defaultAlarmSoundLabel = AlarmSoundCatalog.smartLabel,
    this.defaultAlarmSoundUri = '',
    this.profileImageBase64 = '',
  });

  final String userName;
  final String themeMode;
  final int accentValue;
  final DateTime syllabusTarget;
  final DateTime examDate;
  final int defaultFocusMinutes;
  final bool strictFocus;
  final bool showCompleted;
  final bool onboardingComplete;
  final bool defaultTaskAlarm;
  final int defaultSnoozeMinutes;
  final String defaultAlarmSoundId;
  final String defaultAlarmSoundLabel;
  final String defaultAlarmSoundUri;
  final String profileImageBase64;

  ThemeMode get materialThemeMode {
    switch (themeMode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  AppPreferencesModel copyWith({
    String? userName,
    String? themeMode,
    int? accentValue,
    DateTime? syllabusTarget,
    DateTime? examDate,
    int? defaultFocusMinutes,
    bool? strictFocus,
    bool? showCompleted,
    bool? onboardingComplete,
    bool? defaultTaskAlarm,
    int? defaultSnoozeMinutes,
    String? defaultAlarmSoundId,
    String? defaultAlarmSoundLabel,
    String? defaultAlarmSoundUri,
    String? profileImageBase64,
  }) =>
      AppPreferencesModel(
        userName: userName ?? this.userName,
        themeMode: themeMode ?? this.themeMode,
        accentValue: accentValue ?? this.accentValue,
        syllabusTarget: syllabusTarget ?? this.syllabusTarget,
        examDate: examDate ?? this.examDate,
        defaultFocusMinutes: defaultFocusMinutes ?? this.defaultFocusMinutes,
        strictFocus: strictFocus ?? this.strictFocus,
        showCompleted: showCompleted ?? this.showCompleted,
        onboardingComplete: onboardingComplete ?? this.onboardingComplete,
        defaultTaskAlarm: defaultTaskAlarm ?? this.defaultTaskAlarm,
        defaultSnoozeMinutes: defaultSnoozeMinutes ?? this.defaultSnoozeMinutes,
        defaultAlarmSoundId: defaultAlarmSoundId ?? this.defaultAlarmSoundId,
        defaultAlarmSoundLabel:
            defaultAlarmSoundLabel ?? this.defaultAlarmSoundLabel,
        defaultAlarmSoundUri: defaultAlarmSoundUri ?? this.defaultAlarmSoundUri,
        profileImageBase64: profileImageBase64 ?? this.profileImageBase64,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'userName': userName,
        'themeMode': themeMode,
        'accentValue': accentValue,
        'syllabusTarget': syllabusTarget.toIso8601String(),
        'examDate': examDate.toIso8601String(),
        'defaultFocusMinutes': defaultFocusMinutes,
        'strictFocus': strictFocus,
        'showCompleted': showCompleted,
        'onboardingComplete': onboardingComplete,
        'defaultTaskAlarm': defaultTaskAlarm,
        'defaultSnoozeMinutes': defaultSnoozeMinutes,
        'defaultAlarmSoundId': defaultAlarmSoundId,
        'defaultAlarmSoundLabel': defaultAlarmSoundLabel,
        'defaultAlarmSoundUri': defaultAlarmSoundUri,
        'profileImageBase64': profileImageBase64,
      };

  factory AppPreferencesModel.fromJson(
    Map<String, Object?> json,
  ) =>
      AppPreferencesModel(
        userName: json['userName'] as String? ?? 'Hredoy',
        themeMode: json['themeMode'] as String? ?? 'dark',
        accentValue: (json['accentValue'] as num?)?.toInt() ?? 0xFF55B84D,
        syllabusTarget: DateTime.parse(
          json['syllabusTarget'] as String? ?? '2026-08-02T00:00:00.000',
        ),
        examDate: DateTime.parse(
          json['examDate'] as String? ?? '2026-08-06T00:00:00.000',
        ),
        defaultFocusMinutes:
            (json['defaultFocusMinutes'] as num?)?.toInt() ?? 50,
        strictFocus: json['strictFocus'] as bool? ?? true,
        showCompleted: json['showCompleted'] as bool? ?? true,
        onboardingComplete: json['onboardingComplete'] as bool? ?? false,
        defaultTaskAlarm: json['defaultTaskAlarm'] as bool? ?? true,
        defaultSnoozeMinutes:
            (json['defaultSnoozeMinutes'] as num?)?.toInt() ?? 5,
        defaultAlarmSoundId:
            json['defaultAlarmSoundId'] as String? ?? AlarmSoundCatalog.smartId,
        defaultAlarmSoundLabel: json['defaultAlarmSoundLabel'] as String? ??
            AlarmSoundCatalog.smartLabel,
        defaultAlarmSoundUri: json['defaultAlarmSoundUri'] as String? ?? '',
        profileImageBase64: json['profileImageBase64'] as String? ?? '',
      );
}

class AppData {
  const AppData({
    required this.version,
    required this.subjects,
    required this.tasks,
    required this.goals,
    required this.habits,
    required this.notes,
    required this.sessions,
    required this.preferences,
  });

  final int version;
  final List<SubjectItem> subjects;
  final List<TaskItem> tasks;
  final List<GoalItem> goals;
  final List<HabitItem> habits;
  final List<NoteItem> notes;
  final List<FocusSession> sessions;
  final AppPreferencesModel preferences;

  AppData copyWith({
    int? version,
    List<SubjectItem>? subjects,
    List<TaskItem>? tasks,
    List<GoalItem>? goals,
    List<HabitItem>? habits,
    List<NoteItem>? notes,
    List<FocusSession>? sessions,
    AppPreferencesModel? preferences,
  }) =>
      AppData(
        version: version ?? this.version,
        subjects: subjects ?? this.subjects,
        tasks: tasks ?? this.tasks,
        goals: goals ?? this.goals,
        habits: habits ?? this.habits,
        notes: notes ?? this.notes,
        sessions: sessions ?? this.sessions,
        preferences: preferences ?? this.preferences,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'version': version,
        'subjects': subjects.map((SubjectItem item) => item.toJson()).toList(),
        'tasks': tasks.map((TaskItem item) => item.toJson()).toList(),
        'goals': goals.map((GoalItem item) => item.toJson()).toList(),
        'habits': habits.map((HabitItem item) => item.toJson()).toList(),
        'notes': notes.map((NoteItem item) => item.toJson()).toList(),
        'sessions': sessions.map((FocusSession item) => item.toJson()).toList(),
        'preferences': preferences.toJson(),
      };

  factory AppData.fromJson(Map<String, Object?> json) => AppData(
        version: (json['version'] as num?)?.toInt() ?? 2,
        subjects: (json['subjects'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => SubjectItem.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        tasks: (json['tasks'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => TaskItem.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        goals: (json['goals'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => GoalItem.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        habits: (json['habits'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => HabitItem.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        notes: (json['notes'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => NoteItem.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        sessions: (json['sessions'] as List<Object?>? ?? <Object?>[])
            .map(
              (Object? item) => FocusSession.fromJson(
                (item! as Map<Object?, Object?>).cast<String, Object?>(),
              ),
            )
            .toList(),
        preferences: AppPreferencesModel.fromJson(
          (json['preferences']! as Map<Object?, Object?>)
              .cast<String, Object?>(),
        ),
      );
}
