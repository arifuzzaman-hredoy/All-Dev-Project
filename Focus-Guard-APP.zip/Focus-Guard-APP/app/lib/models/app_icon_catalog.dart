import 'package:flutter/material.dart';

/// Resolves persisted icon code points to compile-time Material icon constants.
///
/// Android profile/release builds tree-shake the Material icon font. Creating
/// IconData from a runtime integer prevents that optimization and fails AOT
/// asset bundling, so every selectable/legacy icon is registered here.
abstract final class AppIconCatalog {
  static const IconData _legacyGeneral = IconData(
    0xe574,
    fontFamily: 'MaterialIcons',
  );
  static const IconData _legacyTest = IconData(
    0xe86f,
    fontFamily: 'MaterialIcons',
  );

  static const List<IconData> supported = <IconData>[
    Icons.menu_book_rounded,
    Icons.calculate_rounded,
    Icons.memory_rounded,
    Icons.science_rounded,
    Icons.code_rounded,
    Icons.translate_rounded,
    Icons.language_rounded,
    Icons.work_rounded,
    Icons.health_and_safety_rounded,
    Icons.fact_check_rounded,
    Icons.category_rounded,
    Icons.bedtime_rounded,
    Icons.restaurant_rounded,
    Icons.psychology_rounded,
    Icons.shield_rounded,
    Icons.water_drop_rounded,
    Icons.fitness_center_rounded,
    Icons.check_circle_rounded,
    _legacyGeneral,
    _legacyTest,
  ];

  static IconData resolve(
    int codePoint, {
    IconData fallback = Icons.category_rounded,
  }) {
    for (final IconData icon in supported) {
      if (icon.codePoint == codePoint) {
        return icon;
      }
    }
    return fallback;
  }
}
