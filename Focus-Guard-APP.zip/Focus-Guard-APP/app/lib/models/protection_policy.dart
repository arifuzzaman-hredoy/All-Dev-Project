import 'dart:math' as math;

class ProtectionPolicy {
  const ProtectionPolicy({
    this.webProtectionEnabled = false,
    this.vpnDnsEnabled = false,
    this.adultContentEnabled = true,
    this.safeSearchEnabled = true,
    this.browserGuardEnabled = true,
    this.webScheduleEnabled = false,
    this.webWeekdays = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.webStartMinute = 0,
    this.webEndMinute = 0,
    this.blockedDomains = const <String>{},
    this.allowedDomains = const <String>{},
    this.blockedKeywords = const <String>{
      'porn',
      'xxx',
      'adult video',
      'explicit video',
    },
    this.primaryDns = '1.1.1.3',
    this.secondaryDns = '1.0.0.3',
    this.failClosed = false,
    this.historyLimit = 200,
    this.primeModeUntilMillis = 0,
    this.primeBlockedPackages = const <String>{},
    this.primeAllowedPackages = const <String>{},
    this.primeSilenceNotifications = true,
    this.keepMeOutUntilMillis = 0,
    this.keepMeOutPackages = const <String>{},
    this.tamperProtectionEnabled = false,
    this.uninstallGuardEnabled = false,
    this.rebootRestoreEnabled = true,
    this.emergencyUnlockMinutes = 5,
    this.maxEmergencyUnlocksPerDay = 2,
  });

  final bool webProtectionEnabled;
  final bool vpnDnsEnabled;
  final bool adultContentEnabled;
  final bool safeSearchEnabled;
  final bool browserGuardEnabled;
  final bool webScheduleEnabled;
  final Set<int> webWeekdays;
  final int webStartMinute;
  final int webEndMinute;
  final Set<String> blockedDomains;
  final Set<String> allowedDomains;
  final Set<String> blockedKeywords;
  final String primaryDns;
  final String secondaryDns;
  final bool failClosed;
  final int historyLimit;
  final int primeModeUntilMillis;
  final Set<String> primeBlockedPackages;
  final Set<String> primeAllowedPackages;
  final bool primeSilenceNotifications;
  final int keepMeOutUntilMillis;
  final Set<String> keepMeOutPackages;
  final bool tamperProtectionEnabled;
  final bool uninstallGuardEnabled;
  final bool rebootRestoreEnabled;
  final int emergencyUnlockMinutes;
  final int maxEmergencyUnlocksPerDay;

  bool get primeModeActive =>
      primeModeUntilMillis > DateTime.now().millisecondsSinceEpoch;

  bool get keepMeOutActive =>
      keepMeOutUntilMillis > DateTime.now().millisecondsSinceEpoch;

  bool isWebWindowActiveAt(DateTime value) {
    if (!webProtectionEnabled) return false;
    if (!webScheduleEnabled) return true;
    final int start = webStartMinute.clamp(0, 1439).toInt();
    final int end = webEndMinute.clamp(0, 1439).toInt();
    final int minute = value.hour * 60 + value.minute;
    if (start == end) return webWeekdays.contains(value.weekday);
    if (start < end) {
      return webWeekdays.contains(value.weekday) &&
          minute >= start &&
          minute < end;
    }
    final int previousWeekday = value.weekday == 1 ? 7 : value.weekday - 1;
    return (webWeekdays.contains(value.weekday) && minute >= start) ||
        (webWeekdays.contains(previousWeekday) && minute < end);
  }

  ProtectionPolicy copyWith({
    bool? webProtectionEnabled,
    bool? vpnDnsEnabled,
    bool? adultContentEnabled,
    bool? safeSearchEnabled,
    bool? browserGuardEnabled,
    bool? webScheduleEnabled,
    Set<int>? webWeekdays,
    int? webStartMinute,
    int? webEndMinute,
    Set<String>? blockedDomains,
    Set<String>? allowedDomains,
    Set<String>? blockedKeywords,
    String? primaryDns,
    String? secondaryDns,
    bool? failClosed,
    int? historyLimit,
    int? primeModeUntilMillis,
    Set<String>? primeBlockedPackages,
    Set<String>? primeAllowedPackages,
    bool? primeSilenceNotifications,
    int? keepMeOutUntilMillis,
    Set<String>? keepMeOutPackages,
    bool? tamperProtectionEnabled,
    bool? uninstallGuardEnabled,
    bool? rebootRestoreEnabled,
    int? emergencyUnlockMinutes,
    int? maxEmergencyUnlocksPerDay,
  }) =>
      ProtectionPolicy(
        webProtectionEnabled: webProtectionEnabled ?? this.webProtectionEnabled,
        vpnDnsEnabled: vpnDnsEnabled ?? this.vpnDnsEnabled,
        adultContentEnabled: adultContentEnabled ?? this.adultContentEnabled,
        safeSearchEnabled: safeSearchEnabled ?? this.safeSearchEnabled,
        browserGuardEnabled: browserGuardEnabled ?? this.browserGuardEnabled,
        webScheduleEnabled: webScheduleEnabled ?? this.webScheduleEnabled,
        webWeekdays: webWeekdays ?? this.webWeekdays,
        webStartMinute: webStartMinute ?? this.webStartMinute,
        webEndMinute: webEndMinute ?? this.webEndMinute,
        blockedDomains: blockedDomains ?? this.blockedDomains,
        allowedDomains: allowedDomains ?? this.allowedDomains,
        blockedKeywords: blockedKeywords ?? this.blockedKeywords,
        primaryDns: primaryDns ?? this.primaryDns,
        secondaryDns: secondaryDns ?? this.secondaryDns,
        failClosed: failClosed ?? this.failClosed,
        historyLimit: historyLimit ?? this.historyLimit,
        primeModeUntilMillis: primeModeUntilMillis ?? this.primeModeUntilMillis,
        primeBlockedPackages: primeBlockedPackages ?? this.primeBlockedPackages,
        primeAllowedPackages: primeAllowedPackages ?? this.primeAllowedPackages,
        primeSilenceNotifications:
            primeSilenceNotifications ?? this.primeSilenceNotifications,
        keepMeOutUntilMillis: keepMeOutUntilMillis ?? this.keepMeOutUntilMillis,
        keepMeOutPackages: keepMeOutPackages ?? this.keepMeOutPackages,
        tamperProtectionEnabled:
            tamperProtectionEnabled ?? this.tamperProtectionEnabled,
        uninstallGuardEnabled:
            uninstallGuardEnabled ?? this.uninstallGuardEnabled,
        rebootRestoreEnabled: rebootRestoreEnabled ?? this.rebootRestoreEnabled,
        emergencyUnlockMinutes:
            emergencyUnlockMinutes ?? this.emergencyUnlockMinutes,
        maxEmergencyUnlocksPerDay:
            maxEmergencyUnlocksPerDay ?? this.maxEmergencyUnlocksPerDay,
      );

  Map<String, Object?> toMap() => <String, Object?>{
        'webProtectionEnabled': webProtectionEnabled,
        'vpnDnsEnabled': vpnDnsEnabled,
        'adultContentEnabled': adultContentEnabled,
        'safeSearchEnabled': safeSearchEnabled,
        'browserGuardEnabled': browserGuardEnabled,
        'webScheduleEnabled': webScheduleEnabled,
        'webWeekdays': webWeekdays.toList(growable: false)..sort(),
        'webStartMinute': webStartMinute,
        'webEndMinute': webEndMinute,
        'blockedDomains': blockedDomains.toList(growable: false)..sort(),
        'allowedDomains': allowedDomains.toList(growable: false)..sort(),
        'blockedKeywords': blockedKeywords.toList(growable: false)..sort(),
        'primaryDns': primaryDns,
        'secondaryDns': secondaryDns,
        'failClosed': failClosed,
        'historyLimit': historyLimit,
        'primeModeUntilMillis': primeModeUntilMillis,
        'primeBlockedPackages': primeBlockedPackages.toList(growable: false)
          ..sort(),
        'primeAllowedPackages': primeAllowedPackages.toList(growable: false)
          ..sort(),
        'primeSilenceNotifications': primeSilenceNotifications,
        'keepMeOutUntilMillis': keepMeOutUntilMillis,
        'keepMeOutPackages': keepMeOutPackages.toList(growable: false)..sort(),
        'tamperProtectionEnabled': tamperProtectionEnabled,
        'uninstallGuardEnabled': uninstallGuardEnabled,
        'rebootRestoreEnabled': rebootRestoreEnabled,
        'emergencyUnlockMinutes': emergencyUnlockMinutes,
        'maxEmergencyUnlocksPerDay': maxEmergencyUnlocksPerDay,
      };

  factory ProtectionPolicy.fromMap(Map<dynamic, dynamic>? map) {
    if (map == null) return const ProtectionPolicy();

    Set<String> readStrings(String key) =>
        (map[key] as List<dynamic>? ?? const <dynamic>[])
            .map((dynamic value) => value.toString().trim().toLowerCase())
            .where((String value) => value.isNotEmpty)
            .toSet();

    final Set<int> weekdays =
        (map['webWeekdays'] as List<dynamic>? ?? const <dynamic>[])
            .whereType<num>()
            .map((num value) => value.toInt())
            .where((int value) => value >= 1 && value <= 7)
            .toSet();

    return ProtectionPolicy(
      webProtectionEnabled: map['webProtectionEnabled'] as bool? ?? false,
      vpnDnsEnabled: map['vpnDnsEnabled'] as bool? ?? false,
      adultContentEnabled: map['adultContentEnabled'] as bool? ?? true,
      safeSearchEnabled: map['safeSearchEnabled'] as bool? ?? true,
      browserGuardEnabled: map['browserGuardEnabled'] as bool? ?? true,
      webScheduleEnabled: map['webScheduleEnabled'] as bool? ?? false,
      webWeekdays:
          weekdays.isEmpty ? const <int>{1, 2, 3, 4, 5, 6, 7} : weekdays,
      webStartMinute: ((map['webStartMinute'] as num?)?.toInt() ?? 0)
          .clamp(0, 1439)
          .toInt(),
      webEndMinute:
          ((map['webEndMinute'] as num?)?.toInt() ?? 0).clamp(0, 1439).toInt(),
      blockedDomains: readStrings('blockedDomains'),
      allowedDomains: readStrings('allowedDomains'),
      blockedKeywords: readStrings('blockedKeywords').isEmpty
          ? const <String>{'porn', 'xxx', 'adult video', 'explicit video'}
          : readStrings('blockedKeywords'),
      primaryDns: map['primaryDns']?.toString() ?? '1.1.1.3',
      secondaryDns: map['secondaryDns']?.toString() ?? '1.0.0.3',
      failClosed: map['failClosed'] as bool? ?? false,
      historyLimit: ((map['historyLimit'] as num?)?.toInt() ?? 200)
          .clamp(20, 1000)
          .toInt(),
      primeModeUntilMillis: math
          .max(0, (map['primeModeUntilMillis'] as num?)?.toInt() ?? 0)
          .toInt(),
      primeBlockedPackages: readStrings('primeBlockedPackages'),
      primeAllowedPackages: readStrings('primeAllowedPackages'),
      primeSilenceNotifications:
          map['primeSilenceNotifications'] as bool? ?? true,
      keepMeOutUntilMillis: math
          .max(0, (map['keepMeOutUntilMillis'] as num?)?.toInt() ?? 0)
          .toInt(),
      keepMeOutPackages: readStrings('keepMeOutPackages'),
      tamperProtectionEnabled: map['tamperProtectionEnabled'] as bool? ?? false,
      uninstallGuardEnabled: map['uninstallGuardEnabled'] as bool? ?? false,
      rebootRestoreEnabled: map['rebootRestoreEnabled'] as bool? ?? true,
      emergencyUnlockMinutes:
          ((map['emergencyUnlockMinutes'] as num?)?.toInt() ?? 5)
              .clamp(1, 30)
              .toInt(),
      maxEmergencyUnlocksPerDay:
          ((map['maxEmergencyUnlocksPerDay'] as num?)?.toInt() ?? 2)
              .clamp(0, 10)
              .toInt(),
    );
  }
}

class ProtectionHistoryItem {
  const ProtectionHistoryItem({
    required this.timestampMillis,
    required this.kind,
    required this.target,
    required this.reason,
    this.packageName = '',
  });

  final int timestampMillis;
  final String kind;
  final String target;
  final String reason;
  final String packageName;

  factory ProtectionHistoryItem.fromMap(Map<dynamic, dynamic> map) =>
      ProtectionHistoryItem(
        timestampMillis: (map['timestampMillis'] as num?)?.toInt() ?? 0,
        kind: map['kind']?.toString() ?? 'protection',
        target: map['target']?.toString() ?? '',
        reason: map['reason']?.toString() ?? '',
        packageName: map['packageName']?.toString() ?? '',
      );
}

class ProtectionSnapshot {
  const ProtectionSnapshot({
    this.vpnPrepared = false,
    this.vpnRunning = false,
    this.privateDnsActive = false,
    this.webBlockedToday = 0,
    this.tamperBlockedToday = 0,
    this.emergencyUnlocksUsedToday = 0,
    this.emergencyUnlockedUntilMillis = 0,
    this.lastBootRestoreAtMillis = 0,
    this.lastServiceMessage = '',
    this.history = const <ProtectionHistoryItem>[],
  });

  final bool vpnPrepared;
  final bool vpnRunning;
  final bool privateDnsActive;
  final int webBlockedToday;
  final int tamperBlockedToday;
  final int emergencyUnlocksUsedToday;
  final int emergencyUnlockedUntilMillis;
  final int lastBootRestoreAtMillis;
  final String lastServiceMessage;
  final List<ProtectionHistoryItem> history;

  bool get emergencyUnlockedNow =>
      emergencyUnlockedUntilMillis > DateTime.now().millisecondsSinceEpoch;

  factory ProtectionSnapshot.fromMap(Map<dynamic, dynamic>? map) {
    final List<dynamic> rawHistory =
        map?['history'] as List<dynamic>? ?? const <dynamic>[];
    return ProtectionSnapshot(
      vpnPrepared: map?['vpnPrepared'] as bool? ?? false,
      vpnRunning: map?['vpnRunning'] as bool? ?? false,
      privateDnsActive: map?['privateDnsActive'] as bool? ?? false,
      webBlockedToday: (map?['webBlockedToday'] as num?)?.toInt() ?? 0,
      tamperBlockedToday: (map?['tamperBlockedToday'] as num?)?.toInt() ?? 0,
      emergencyUnlocksUsedToday:
          (map?['emergencyUnlocksUsedToday'] as num?)?.toInt() ?? 0,
      emergencyUnlockedUntilMillis:
          (map?['emergencyUnlockedUntilMillis'] as num?)?.toInt() ?? 0,
      lastBootRestoreAtMillis:
          (map?['lastBootRestoreAtMillis'] as num?)?.toInt() ?? 0,
      lastServiceMessage: map?['lastServiceMessage']?.toString() ?? '',
      history: rawHistory
          .whereType<Map<dynamic, dynamic>>()
          .map(ProtectionHistoryItem.fromMap)
          .toList(growable: false),
    );
  }
}

class ProtectionActionResult {
  const ProtectionActionResult({
    required this.granted,
    this.activeUntilMillis = 0,
    this.unlocksUsedToday = 0,
    this.message = '',
  });

  final bool granted;
  final int activeUntilMillis;
  final int unlocksUsedToday;
  final String message;

  factory ProtectionActionResult.fromMap(Map<dynamic, dynamic>? map) =>
      ProtectionActionResult(
        granted: map?['granted'] as bool? ?? false,
        activeUntilMillis: (map?['activeUntilMillis'] as num?)?.toInt() ?? 0,
        unlocksUsedToday: (map?['unlocksUsedToday'] as num?)?.toInt() ?? 0,
        message: map?['message']?.toString() ?? '',
      );
}
