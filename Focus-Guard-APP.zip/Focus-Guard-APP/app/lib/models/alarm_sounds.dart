class AlarmSoundSelection {
  const AlarmSoundSelection({
    required this.id,
    required this.label,
    this.uri = '',
  });

  final String id;
  final String label;
  final String uri;

  bool get isCustom => id == AlarmSoundCatalog.customId;
  bool get isSystem => id == AlarmSoundCatalog.systemId;
  bool get isBuiltIn => !isCustom && !isSystem;

  AlarmSoundSelection copyWith({String? id, String? label, String? uri}) =>
      AlarmSoundSelection(
        id: id ?? this.id,
        label: label ?? this.label,
        uri: uri ?? this.uri,
      );

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'label': label,
        'uri': uri,
      };

  factory AlarmSoundSelection.fromMap(Map<Object?, Object?> map) =>
      AlarmSoundSelection(
        id: map['id']?.toString() ?? AlarmSoundCatalog.smartId,
        label: map['label']?.toString() ?? AlarmSoundCatalog.smartLabel,
        uri: map['uri']?.toString() ?? '',
      );
}

class AlarmSoundPreset {
  const AlarmSoundPreset({
    required this.id,
    required this.label,
    required this.description,
    required this.group,
  });

  final String id;
  final String label;
  final String description;
  final String group;

  AlarmSoundSelection get selection => AlarmSoundSelection(
        id: id,
        label: label,
      );
}

abstract final class AlarmSoundCatalog {
  static const String smartId = 'smart';
  static const String smartLabel = 'Smart by task type';
  static const String systemId = 'system';
  static const String customId = 'custom';
  static const int builtInSoundCount = 216;

  static const AlarmSoundSelection smart = AlarmSoundSelection(
    id: smartId,
    label: smartLabel,
  );

  static const List<AlarmSoundPreset> _legacySounds = <AlarmSoundPreset>[
    AlarmSoundPreset(
      id: 'focus_pulse',
      label: 'Focus Pulse',
      description: 'Balanced pulse for deep work and normal tasks.',
      group: 'Focus',
    ),
    AlarmSoundPreset(
      id: 'deep_work',
      label: 'Deep Work',
      description:
          'Lower, steady pattern that is noticeable without being harsh.',
      group: 'Focus',
    ),
    AlarmSoundPreset(
      id: 'study_bell',
      label: 'Study Bell',
      description: 'Clear bell pattern for study and revision sessions.',
      group: 'Study',
    ),
    AlarmSoundPreset(
      id: 'reading_chime',
      label: 'Reading Chime',
      description: 'Soft layered chime for reading and language work.',
      group: 'Study',
    ),
    AlarmSoundPreset(
      id: 'exam_alert',
      label: 'Exam Alert',
      description: 'Strong repeating alarm for exams and high-priority work.',
      group: 'Urgent',
    ),
    AlarmSoundPreset(
      id: 'deadline_beacon',
      label: 'Deadline Beacon',
      description: 'Distinct rising signal for deadlines and urgent tasks.',
      group: 'Urgent',
    ),
    AlarmSoundPreset(
      id: 'coding_digital',
      label: 'Coding Digital',
      description: 'Digital sequence for coding, computer, and technical work.',
      group: 'Technical',
    ),
    AlarmSoundPreset(
      id: 'science_signal',
      label: 'Science Signal',
      description: 'Crisp pulse for math, physics, electronics, and chemistry.',
      group: 'Technical',
    ),
    AlarmSoundPreset(
      id: 'meeting_chime',
      label: 'Meeting Chime',
      description: 'Professional double chime for meetings and classes.',
      group: 'Daily',
    ),
    AlarmSoundPreset(
      id: 'morning_sunrise',
      label: 'Morning Sunrise',
      description: 'Gradual bright pattern for morning routines.',
      group: 'Morning',
    ),
    AlarmSoundPreset(
      id: 'workout_energy',
      label: 'Workout Energy',
      description: 'Faster upbeat signal for exercise and active routines.',
      group: 'Energy',
    ),
    AlarmSoundPreset(
      id: 'gentle_reminder',
      label: 'Gentle Reminder',
      description: 'Light taps for low-priority personal reminders.',
      group: 'Gentle',
    ),
    AlarmSoundPreset(
      id: 'calm_waves',
      label: 'Calm Waves',
      description: 'Smooth, calm pattern for breaks and self-care.',
      group: 'Nature',
    ),
    AlarmSoundPreset(
      id: 'bright_bell',
      label: 'Bright Bell',
      description: 'Bright bell that cuts through background noise.',
      group: 'Classic',
    ),
    AlarmSoundPreset(
      id: 'classic_alarm',
      label: 'Classic Alarm',
      description: 'Traditional alternating alarm-clock pattern.',
      group: 'Classic',
    ),
    AlarmSoundPreset(
      id: 'urgent_siren',
      label: 'Urgent Siren',
      description: 'Most noticeable built-in sound for critical reminders.',
      group: 'Urgent',
    ),
  ];

  static const List<String> _families = <String>[
    'Forest Bell',
    'Rain Pulse',
    'River Chime',
    'Sunrise Tone',
    'Digital Beacon',
    'Study Spark',
    'Deep Focus',
    'Crystal Note',
    'Mountain Echo',
    'Night Lantern',
  ];

  static const List<String> _groups = <String>[
    'Nature',
    'Focus',
    'Study',
    'Morning',
    'Technical',
    'Gentle',
    'Energy',
    'Classic',
    'Deep work',
    'Night',
  ];

  static final List<AlarmSoundPreset> soundPresets =
      List<AlarmSoundPreset>.unmodifiable(<AlarmSoundPreset>[
    ..._legacySounds,
    ...List<AlarmSoundPreset>.generate(200, (int index) {
      final int number = index + 17;
      final int familyIndex = index % _families.length;
      final int rhythm = (index ~/ _families.length) % 5 + 1;
      final int variation = (index ~/ 50) + 1;
      return AlarmSoundPreset(
        id: 'tone_${number.toString().padLeft(3, '0')}',
        label:
            '${_families[familyIndex]} ${rhythm.toString().padLeft(2, '0')} · V$variation',
        description:
            'Built-in tone $number of $builtInSoundCount with a distinct rhythm, pitch and alarm envelope.',
        group: _groups[familyIndex],
      );
    }),
  ]);

  static final List<AlarmSoundPreset> builtIns =
      List<AlarmSoundPreset>.unmodifiable(<AlarmSoundPreset>[
    const AlarmSoundPreset(
      id: smartId,
      label: smartLabel,
      description:
          'Automatically chooses a matching tone from the task category.',
      group: 'Automatic',
    ),
    ...soundPresets,
  ]);

  static List<String> get groups {
    final List<String> values = soundPresets
        .map((AlarmSoundPreset preset) => preset.group)
        .toSet()
        .toList(growable: false)
      ..sort();
    return <String>['All', ...values];
  }

  static AlarmSoundPreset? presetById(String id) {
    for (final AlarmSoundPreset preset in builtIns) {
      if (preset.id == id) return preset;
    }
    return null;
  }

  static String safeLabel(String id, String storedLabel) {
    if (storedLabel.trim().isNotEmpty) return storedLabel.trim();
    if (id == systemId) return 'Phone alarm tone';
    if (id == customId) return 'My audio file';
    return presetById(id)?.label ?? smartLabel;
  }
}
