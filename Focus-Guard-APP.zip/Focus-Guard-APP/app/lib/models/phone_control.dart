import 'dart:math' as math;

class AppControlRule {
  const AppControlRule({
    required this.packageName,
    required this.label,
    this.category = 'normal',
    this.enabled = true,
    this.blockApp = false,
    this.blockOutsideSchedule = false,
    this.allowedWeekdays = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.allowedStartMinute = 6 * 60,
    this.allowedEndMinute = 22 * 60,
    this.dailyLimitMinutes = 120,
    this.reelsGuard = false,
    this.blockReelsImmediately = false,
    this.reelsDailyLimit = 10,
    this.reelsTimeLimitMinutes = 15,
    this.reelsWarningPercentages = const <int>{50, 75, 90},
    this.scrollLimit = 0,
    this.commitmentPercent = 20,
    this.commitmentLockedUntilMillis = 0,
  });

  final String packageName;
  final String label;
  final String category;
  final bool enabled;
  final bool blockApp;
  final bool blockOutsideSchedule;
  final Set<int> allowedWeekdays;
  final int allowedStartMinute;
  final int allowedEndMinute;
  final int dailyLimitMinutes;
  final bool reelsGuard;
  final bool blockReelsImmediately;
  final int reelsDailyLimit;
  final int reelsTimeLimitMinutes;
  final Set<int> reelsWarningPercentages;
  final int scrollLimit;
  final int commitmentPercent;
  final int commitmentLockedUntilMillis;

  bool get commitmentActive =>
      commitmentLockedUntilMillis > DateTime.now().millisecondsSinceEpoch;

  bool get hasRestriction =>
      enabled &&
      (blockApp ||
          blockOutsideSchedule ||
          dailyLimitMinutes > 0 ||
          reelsGuard ||
          scrollLimit > 0);

  int get minimumCommitmentMinutes {
    final int base = dailyLimitMinutes > 0
        ? dailyLimitMinutes
        : reelsTimeLimitMinutes > 0
            ? reelsTimeLimitMinutes
            : 60;
    return math.max(5, math.min(720, (base * commitmentPercent / 100).ceil()));
  }

  AppControlRule copyWith({
    String? label,
    String? category,
    bool? enabled,
    bool? blockApp,
    bool? blockOutsideSchedule,
    Set<int>? allowedWeekdays,
    int? allowedStartMinute,
    int? allowedEndMinute,
    int? dailyLimitMinutes,
    bool? reelsGuard,
    bool? blockReelsImmediately,
    int? reelsDailyLimit,
    int? reelsTimeLimitMinutes,
    Set<int>? reelsWarningPercentages,
    int? scrollLimit,
    int? commitmentPercent,
    int? commitmentLockedUntilMillis,
  }) =>
      AppControlRule(
        packageName: packageName,
        label: label ?? this.label,
        category: category ?? this.category,
        enabled: enabled ?? this.enabled,
        blockApp: blockApp ?? this.blockApp,
        blockOutsideSchedule: blockOutsideSchedule ?? this.blockOutsideSchedule,
        allowedWeekdays: allowedWeekdays ?? this.allowedWeekdays,
        allowedStartMinute: allowedStartMinute ?? this.allowedStartMinute,
        allowedEndMinute: allowedEndMinute ?? this.allowedEndMinute,
        dailyLimitMinutes: dailyLimitMinutes ?? this.dailyLimitMinutes,
        reelsGuard: reelsGuard ?? this.reelsGuard,
        blockReelsImmediately:
            blockReelsImmediately ?? this.blockReelsImmediately,
        reelsDailyLimit: reelsDailyLimit ?? this.reelsDailyLimit,
        reelsTimeLimitMinutes:
            reelsTimeLimitMinutes ?? this.reelsTimeLimitMinutes,
        reelsWarningPercentages:
            reelsWarningPercentages ?? this.reelsWarningPercentages,
        scrollLimit: scrollLimit ?? this.scrollLimit,
        commitmentPercent: commitmentPercent ?? this.commitmentPercent,
        commitmentLockedUntilMillis:
            commitmentLockedUntilMillis ?? this.commitmentLockedUntilMillis,
      );

  bool isAllowedAt(DateTime value) {
    if (!enabled || !blockOutsideSchedule) return true;
    final int start = allowedStartMinute.clamp(0, 1439).toInt();
    final int end = allowedEndMinute.clamp(0, 1439).toInt();
    if (start == end) return true;
    final int weekday = value.weekday;
    final int minute = value.hour * 60 + value.minute;
    if (start < end) {
      return allowedWeekdays.contains(weekday) &&
          minute >= start &&
          minute < end;
    }
    final int previousWeekday = weekday == 1 ? 7 : weekday - 1;
    return (allowedWeekdays.contains(weekday) && minute >= start) ||
        (allowedWeekdays.contains(previousWeekday) && minute < end);
  }

  String scheduleLabel() =>
      '${formatMinuteOfDay(allowedStartMinute)}–${formatMinuteOfDay(allowedEndMinute)}';

  Map<String, Object?> toMap() => <String, Object?>{
        'packageName': packageName,
        'label': label,
        'category': category,
        'enabled': enabled,
        'blockApp': blockApp,
        'blockOutsideSchedule': blockOutsideSchedule,
        'allowedWeekdays': allowedWeekdays.toList(growable: false)..sort(),
        'allowedStartMinute': allowedStartMinute,
        'allowedEndMinute': allowedEndMinute,
        'dailyLimitMinutes': dailyLimitMinutes,
        'reelsGuard': reelsGuard,
        'blockReelsImmediately': blockReelsImmediately,
        'reelsDailyLimit': reelsDailyLimit,
        'reelsTimeLimitMinutes': reelsTimeLimitMinutes,
        'reelsWarningPercentages':
            reelsWarningPercentages.toList(growable: false)..sort(),
        'scrollLimit': scrollLimit,
        'commitmentPercent': commitmentPercent,
        'commitmentLockedUntilMillis': commitmentLockedUntilMillis,
      };

  factory AppControlRule.fromMap(Map<dynamic, dynamic> map) {
    final List<dynamic> rawDays =
        map['allowedWeekdays'] as List<dynamic>? ?? const <dynamic>[];
    final Set<int> days = rawDays
        .map((dynamic value) => (value as num).toInt())
        .where((int value) => value >= 1 && value <= 7)
        .toSet();
    final Set<int> warningPercentages =
        (map['reelsWarningPercentages'] as List<dynamic>? ??
                const <dynamic>[50, 75, 90])
            .whereType<num>()
            .map((num value) => value.toInt())
            .where((int value) => value >= 10 && value <= 100)
            .toSet();
    return AppControlRule(
      packageName: map['packageName']?.toString() ?? '',
      label: map['label']?.toString() ?? map['packageName']?.toString() ?? '',
      category: map['category']?.toString() ?? 'normal',
      enabled: map['enabled'] as bool? ?? true,
      blockApp: map['blockApp'] as bool? ?? false,
      blockOutsideSchedule: map['blockOutsideSchedule'] as bool? ?? false,
      allowedWeekdays: days.isEmpty ? const <int>{1, 2, 3, 4, 5, 6, 7} : days,
      allowedStartMinute: ((map['allowedStartMinute'] as num?)?.toInt() ?? 360)
          .clamp(0, 1439)
          .toInt(),
      allowedEndMinute: ((map['allowedEndMinute'] as num?)?.toInt() ?? 1320)
          .clamp(0, 1439)
          .toInt(),
      dailyLimitMinutes:
          math.max(0, (map['dailyLimitMinutes'] as num?)?.toInt() ?? 120),
      reelsGuard: map['reelsGuard'] as bool? ?? false,
      blockReelsImmediately: map.containsKey('blockReelsImmediately')
          ? map['blockReelsImmediately'] as bool? ?? false
          : map['reelsGuard'] as bool? ?? false,
      reelsDailyLimit:
          math.max(0, (map['reelsDailyLimit'] as num?)?.toInt() ?? 10),
      reelsTimeLimitMinutes: math.max(
        0,
        (map['reelsTimeLimitMinutes'] as num?)?.toInt() ?? 15,
      ),
      reelsWarningPercentages: warningPercentages.isEmpty
          ? const <int>{50, 75, 90}
          : Set<int>.unmodifiable(warningPercentages),
      scrollLimit: math.max(0, (map['scrollLimit'] as num?)?.toInt() ?? 0),
      commitmentPercent: ((map['commitmentPercent'] as num?)?.toInt() ?? 20)
          .clamp(20, 100)
          .toInt(),
      commitmentLockedUntilMillis: math.max(
          0, (map['commitmentLockedUntilMillis'] as num?)?.toInt() ?? 0),
    );
  }
}

class ScheduleProfile {
  const ScheduleProfile({
    required this.id,
    required this.name,
    this.enabled = true,
    this.blockedPackages = const <String>{},
    this.weekdays = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.startMinute = 19 * 60,
    this.endMinute = 23 * 60,
    this.emergencyUnlockMinutes = 10,
    this.maxEmergencyUnlocksPerDay = 2,
    this.silenceNotifications = false,
  });

  final String id;
  final String name;
  final bool enabled;
  final Set<String> blockedPackages;
  final Set<int> weekdays;
  final int startMinute;
  final int endMinute;
  final int emergencyUnlockMinutes;
  final int maxEmergencyUnlocksPerDay;
  final bool silenceNotifications;

  ScheduleProfile copyWith({
    String? id,
    String? name,
    bool? enabled,
    Set<String>? blockedPackages,
    Set<int>? weekdays,
    int? startMinute,
    int? endMinute,
    int? emergencyUnlockMinutes,
    int? maxEmergencyUnlocksPerDay,
    bool? silenceNotifications,
  }) =>
      ScheduleProfile(
        id: id ?? this.id,
        name: name ?? this.name,
        enabled: enabled ?? this.enabled,
        blockedPackages: blockedPackages ?? this.blockedPackages,
        weekdays: weekdays ?? this.weekdays,
        startMinute: startMinute ?? this.startMinute,
        endMinute: endMinute ?? this.endMinute,
        emergencyUnlockMinutes:
            emergencyUnlockMinutes ?? this.emergencyUnlockMinutes,
        maxEmergencyUnlocksPerDay:
            maxEmergencyUnlocksPerDay ?? this.maxEmergencyUnlocksPerDay,
        silenceNotifications: silenceNotifications ?? this.silenceNotifications,
      );

  bool isActiveAt(DateTime value) {
    if (!enabled || blockedPackages.isEmpty) return false;
    final int start = startMinute.clamp(0, 1439).toInt();
    final int end = endMinute.clamp(0, 1439).toInt();
    if (start == end) return weekdays.contains(value.weekday);
    final int minute = value.hour * 60 + value.minute;
    if (start < end) {
      return weekdays.contains(value.weekday) &&
          minute >= start &&
          minute < end;
    }
    final int previousWeekday = value.weekday == 1 ? 7 : value.weekday - 1;
    return (weekdays.contains(value.weekday) && minute >= start) ||
        (weekdays.contains(previousWeekday) && minute < end);
  }

  bool blocksPackageAt(String packageName, DateTime value) =>
      blockedPackages.contains(packageName) && isActiveAt(value);

  bool overlapsWith(ScheduleProfile other) {
    if (!enabled || !other.enabled) return false;
    if (blockedPackages.intersection(other.blockedPackages).isEmpty) {
      return false;
    }
    final DateTime monday = DateTime(2026, 7, 27);
    for (int offset = 0; offset < 7 * 24 * 60; offset += 1) {
      final DateTime instant = monday.add(Duration(minutes: offset));
      if (isActiveAt(instant) && other.isActiveAt(instant)) return true;
    }
    return false;
  }

  String scheduleLabel() =>
      '${formatMinuteOfDay(startMinute)}–${formatMinuteOfDay(endMinute)}';

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'name': name,
        'enabled': enabled,
        'blockedPackages': blockedPackages.toList(growable: false)..sort(),
        'weekdays': weekdays.toList(growable: false)..sort(),
        'startMinute': startMinute,
        'endMinute': endMinute,
        'emergencyUnlockMinutes': emergencyUnlockMinutes,
        'maxEmergencyUnlocksPerDay': maxEmergencyUnlocksPerDay,
        'silenceNotifications': silenceNotifications,
      };

  factory ScheduleProfile.fromMap(Map<dynamic, dynamic> map) {
    Set<int> readDays(dynamic raw) {
      if (raw is! List<dynamic>) return const <int>{1, 2, 3, 4, 5, 6, 7};
      final Set<int> values = raw
          .whereType<num>()
          .map((num value) => value.toInt())
          .where((int value) => value >= 1 && value <= 7)
          .toSet();
      return values.isEmpty ? const <int>{1, 2, 3, 4, 5, 6, 7} : values;
    }

    final List<dynamic> rawPackages =
        map['blockedPackages'] as List<dynamic>? ?? const <dynamic>[];
    return ScheduleProfile(
      id: map['id']?.toString() ?? '',
      name: map['name']?.toString() ?? 'Schedule profile',
      enabled: map['enabled'] as bool? ?? true,
      blockedPackages: rawPackages
          .map((dynamic value) => value.toString())
          .where((String value) => value.isNotEmpty)
          .toSet(),
      weekdays: readDays(map['weekdays']),
      startMinute: ((map['startMinute'] as num?)?.toInt() ?? 1140)
          .clamp(0, 1439)
          .toInt(),
      endMinute:
          ((map['endMinute'] as num?)?.toInt() ?? 1380).clamp(0, 1439).toInt(),
      emergencyUnlockMinutes: math.max(
        0,
        (map['emergencyUnlockMinutes'] as num?)?.toInt() ?? 10,
      ),
      maxEmergencyUnlocksPerDay: math.max(
        0,
        (map['maxEmergencyUnlocksPerDay'] as num?)?.toInt() ?? 2,
      ),
      silenceNotifications: map['silenceNotifications'] as bool? ?? false,
    );
  }
}

class ScheduleProfileRuntime {
  const ScheduleProfileRuntime({
    required this.profileId,
    this.unlockedUntilMillis = 0,
    this.unlocksUsedToday = 0,
    this.granted = true,
  });

  final String profileId;
  final int unlockedUntilMillis;
  final int unlocksUsedToday;
  final bool granted;

  bool get isUnlockedNow =>
      unlockedUntilMillis > DateTime.now().millisecondsSinceEpoch;

  factory ScheduleProfileRuntime.fromMap(Map<dynamic, dynamic> map) =>
      ScheduleProfileRuntime(
        profileId: map['profileId']?.toString() ?? '',
        unlockedUntilMillis: (map['unlockedUntilMillis'] as num?)?.toInt() ?? 0,
        unlocksUsedToday: (map['unlocksUsedToday'] as num?)?.toInt() ?? 0,
        granted: map['granted'] as bool? ?? true,
      );
}

class PhoneControlPolicy {
  const PhoneControlPolicy({
    this.masterEnabled = false,
    this.scheduleEnabled = true,
    this.scheduleProfilesEnabled = true,
    this.appLimitsEnabled = true,
    this.reelsBlockerEnabled = true,
    this.scrollLimitEnabled = true,
    this.notificationBlockerEnabled = false,
    this.notificationPackages = const <String>{},
    this.notificationScheduleEnabled = false,
    this.notificationWeekdays = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.notificationStartMinute = 22 * 60,
    this.notificationEndMinute = 7 * 60,
    this.notificationHistoryLimit = 100,
    this.studyModeEnabled = true,
    this.studyStrictAllowList = false,
    this.studyAllowedPackages = const <String>{},
    this.studyBlockedPackages = const <String>{},
    this.studySilenceNotifications = true,
    this.studyDefaultMinutes = 50,
    this.studyDailyGoalMinutes = 120,
    this.studyScheduleEnabled = false,
    this.studyWeekdays = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.studyStartMinute = 19 * 60,
    this.studyEndMinute = 23 * 60,
    this.focusUsesStudyRules = true,
    this.globalReelsWindowEnabled = false,
    this.globalReelsWindowStartMillis = 0,
    this.globalReelsWindowEndMillis = 0,
    this.globalReelsWindowLimit = 0,
    this.globalReelsWindowPackages = const <String>{},
    this.globalReelsWindowLocked = false,
    this.wellbeingWarningsEnabled = true,
    this.screenTimeGoalMinutes = 240,
    this.screenTimeWarningPercentages = const <int>{50, 75, 90, 100},
    this.screenTimeRepeatMinutes = 30,
    this.detailedWarningNotifications = true,
    this.rules = const <AppControlRule>[],
    this.profiles = const <ScheduleProfile>[],
  });

  final bool masterEnabled;
  final bool scheduleEnabled;
  final bool scheduleProfilesEnabled;
  final bool appLimitsEnabled;
  final bool reelsBlockerEnabled;
  final bool scrollLimitEnabled;
  final bool notificationBlockerEnabled;
  final Set<String> notificationPackages;
  final bool notificationScheduleEnabled;
  final Set<int> notificationWeekdays;
  final int notificationStartMinute;
  final int notificationEndMinute;
  final int notificationHistoryLimit;
  final bool studyModeEnabled;
  final bool studyStrictAllowList;
  final Set<String> studyAllowedPackages;
  final Set<String> studyBlockedPackages;
  final bool studySilenceNotifications;
  final int studyDefaultMinutes;
  final int studyDailyGoalMinutes;
  final bool studyScheduleEnabled;
  final Set<int> studyWeekdays;
  final int studyStartMinute;
  final int studyEndMinute;
  final bool focusUsesStudyRules;
  final bool globalReelsWindowEnabled;
  final int globalReelsWindowStartMillis;
  final int globalReelsWindowEndMillis;
  final int globalReelsWindowLimit;
  final Set<String> globalReelsWindowPackages;
  final bool globalReelsWindowLocked;
  final bool wellbeingWarningsEnabled;
  final int screenTimeGoalMinutes;
  final Set<int> screenTimeWarningPercentages;
  final int screenTimeRepeatMinutes;
  final bool detailedWarningNotifications;
  final List<AppControlRule> rules;
  final List<ScheduleProfile> profiles;

  int get activeFeatureCount => <bool>[
        masterEnabled && rules.isNotEmpty,
        masterEnabled && scheduleEnabled,
        masterEnabled && scheduleProfilesEnabled && profiles.isNotEmpty,
        masterEnabled && appLimitsEnabled,
        masterEnabled && reelsBlockerEnabled,
        masterEnabled && scrollLimitEnabled,
        masterEnabled &&
            (notificationBlockerEnabled ||
                profiles.any(
                  (ScheduleProfile profile) => profile.silenceNotifications,
                )),
        masterEnabled,
        studyModeEnabled,
        studyModeEnabled && studyScheduleEnabled,
        globalReelsWindowEnabled,
        true,
        profiles.any((ScheduleProfile profile) =>
            profile.emergencyUnlockMinutes > 0 &&
            profile.maxEmergencyUnlocksPerDay > 0),
      ].where((bool value) => value).length;

  List<ScheduleProfile> activeProfilesFor(
    String packageName,
    DateTime value,
  ) =>
      profiles
          .where(
            (ScheduleProfile profile) =>
                profile.blocksPackageAt(packageName, value),
          )
          .toList(growable: false);

  bool studyScheduleActiveAt(DateTime value) {
    if (!studyModeEnabled || !studyScheduleEnabled) return false;
    final int start = studyStartMinute.clamp(0, 1439).toInt();
    final int end = studyEndMinute.clamp(0, 1439).toInt();
    final int minute = value.hour * 60 + value.minute;
    if (start == end) return studyWeekdays.contains(value.weekday);
    if (start < end) {
      return studyWeekdays.contains(value.weekday) &&
          minute >= start &&
          minute < end;
    }
    final int previousWeekday = value.weekday == 1 ? 7 : value.weekday - 1;
    return (studyWeekdays.contains(value.weekday) && minute >= start) ||
        (studyWeekdays.contains(previousWeekday) && minute < end);
  }

  bool globalReelsWindowActiveAt(DateTime value) {
    if (!globalReelsWindowEnabled || globalReelsWindowLimit <= 0) return false;
    final int now = value.millisecondsSinceEpoch;
    return globalReelsWindowStartMillis > 0 &&
        globalReelsWindowEndMillis > globalReelsWindowStartMillis &&
        now >= globalReelsWindowStartMillis &&
        now < globalReelsWindowEndMillis;
  }

  bool globalReelsWindowAppliesTo(String packageName) =>
      globalReelsWindowPackages.isEmpty ||
      globalReelsWindowPackages.contains(packageName);

  bool notificationWindowActiveAt(DateTime value) {
    if (!notificationScheduleEnabled) return true;
    final int start = notificationStartMinute.clamp(0, 1439).toInt();
    final int end = notificationEndMinute.clamp(0, 1439).toInt();
    final int minute = value.hour * 60 + value.minute;
    if (start == end) return notificationWeekdays.contains(value.weekday);
    if (start < end) {
      return notificationWeekdays.contains(value.weekday) &&
          minute >= start &&
          minute < end;
    }
    final int previousWeekday = value.weekday == 1 ? 7 : value.weekday - 1;
    return (notificationWeekdays.contains(value.weekday) && minute >= start) ||
        (notificationWeekdays.contains(previousWeekday) && minute < end);
  }

  PhoneControlPolicy copyWith({
    bool? masterEnabled,
    bool? scheduleEnabled,
    bool? scheduleProfilesEnabled,
    bool? appLimitsEnabled,
    bool? reelsBlockerEnabled,
    bool? scrollLimitEnabled,
    bool? notificationBlockerEnabled,
    Set<String>? notificationPackages,
    bool? notificationScheduleEnabled,
    Set<int>? notificationWeekdays,
    int? notificationStartMinute,
    int? notificationEndMinute,
    int? notificationHistoryLimit,
    bool? studyModeEnabled,
    bool? studyStrictAllowList,
    Set<String>? studyAllowedPackages,
    Set<String>? studyBlockedPackages,
    bool? studySilenceNotifications,
    int? studyDefaultMinutes,
    int? studyDailyGoalMinutes,
    bool? studyScheduleEnabled,
    Set<int>? studyWeekdays,
    int? studyStartMinute,
    int? studyEndMinute,
    bool? focusUsesStudyRules,
    bool? globalReelsWindowEnabled,
    int? globalReelsWindowStartMillis,
    int? globalReelsWindowEndMillis,
    int? globalReelsWindowLimit,
    Set<String>? globalReelsWindowPackages,
    bool? globalReelsWindowLocked,
    bool? wellbeingWarningsEnabled,
    int? screenTimeGoalMinutes,
    Set<int>? screenTimeWarningPercentages,
    int? screenTimeRepeatMinutes,
    bool? detailedWarningNotifications,
    List<AppControlRule>? rules,
    List<ScheduleProfile>? profiles,
  }) =>
      PhoneControlPolicy(
        masterEnabled: masterEnabled ?? this.masterEnabled,
        scheduleEnabled: scheduleEnabled ?? this.scheduleEnabled,
        scheduleProfilesEnabled:
            scheduleProfilesEnabled ?? this.scheduleProfilesEnabled,
        appLimitsEnabled: appLimitsEnabled ?? this.appLimitsEnabled,
        reelsBlockerEnabled: reelsBlockerEnabled ?? this.reelsBlockerEnabled,
        scrollLimitEnabled: scrollLimitEnabled ?? this.scrollLimitEnabled,
        notificationBlockerEnabled:
            notificationBlockerEnabled ?? this.notificationBlockerEnabled,
        notificationPackages: notificationPackages ?? this.notificationPackages,
        notificationScheduleEnabled:
            notificationScheduleEnabled ?? this.notificationScheduleEnabled,
        notificationWeekdays: notificationWeekdays ?? this.notificationWeekdays,
        notificationStartMinute:
            notificationStartMinute ?? this.notificationStartMinute,
        notificationEndMinute:
            notificationEndMinute ?? this.notificationEndMinute,
        notificationHistoryLimit:
            notificationHistoryLimit ?? this.notificationHistoryLimit,
        studyModeEnabled: studyModeEnabled ?? this.studyModeEnabled,
        studyStrictAllowList: studyStrictAllowList ?? this.studyStrictAllowList,
        studyAllowedPackages: studyAllowedPackages ?? this.studyAllowedPackages,
        studyBlockedPackages: studyBlockedPackages ?? this.studyBlockedPackages,
        studySilenceNotifications:
            studySilenceNotifications ?? this.studySilenceNotifications,
        studyDefaultMinutes: studyDefaultMinutes ?? this.studyDefaultMinutes,
        studyDailyGoalMinutes:
            studyDailyGoalMinutes ?? this.studyDailyGoalMinutes,
        studyScheduleEnabled: studyScheduleEnabled ?? this.studyScheduleEnabled,
        studyWeekdays: studyWeekdays ?? this.studyWeekdays,
        studyStartMinute: studyStartMinute ?? this.studyStartMinute,
        studyEndMinute: studyEndMinute ?? this.studyEndMinute,
        focusUsesStudyRules: focusUsesStudyRules ?? this.focusUsesStudyRules,
        globalReelsWindowEnabled:
            globalReelsWindowEnabled ?? this.globalReelsWindowEnabled,
        globalReelsWindowStartMillis:
            globalReelsWindowStartMillis ?? this.globalReelsWindowStartMillis,
        globalReelsWindowEndMillis:
            globalReelsWindowEndMillis ?? this.globalReelsWindowEndMillis,
        globalReelsWindowLimit:
            globalReelsWindowLimit ?? this.globalReelsWindowLimit,
        globalReelsWindowPackages:
            globalReelsWindowPackages ?? this.globalReelsWindowPackages,
        globalReelsWindowLocked:
            globalReelsWindowLocked ?? this.globalReelsWindowLocked,
        wellbeingWarningsEnabled:
            wellbeingWarningsEnabled ?? this.wellbeingWarningsEnabled,
        screenTimeGoalMinutes:
            screenTimeGoalMinutes ?? this.screenTimeGoalMinutes,
        screenTimeWarningPercentages:
            screenTimeWarningPercentages ?? this.screenTimeWarningPercentages,
        screenTimeRepeatMinutes:
            screenTimeRepeatMinutes ?? this.screenTimeRepeatMinutes,
        detailedWarningNotifications:
            detailedWarningNotifications ?? this.detailedWarningNotifications,
        rules: rules ?? this.rules,
        profiles: profiles ?? this.profiles,
      );

  PhoneControlPolicy upsertRule(AppControlRule rule) {
    final List<AppControlRule> updated = <AppControlRule>[...rules];
    final int index = updated.indexWhere(
      (AppControlRule item) => item.packageName == rule.packageName,
    );
    if (index == -1) {
      updated.add(rule);
    } else {
      updated[index] = rule;
    }
    updated.sort(
      (AppControlRule a, AppControlRule b) =>
          a.label.toLowerCase().compareTo(b.label.toLowerCase()),
    );
    return copyWith(rules: List<AppControlRule>.unmodifiable(updated));
  }

  PhoneControlPolicy removeRule(String packageName) => copyWith(
        rules: rules
            .where((AppControlRule rule) => rule.packageName != packageName)
            .toList(growable: false),
      );

  PhoneControlPolicy upsertProfile(ScheduleProfile profile) {
    final List<ScheduleProfile> updated = <ScheduleProfile>[...profiles];
    final int index = updated.indexWhere(
      (ScheduleProfile item) => item.id == profile.id,
    );
    if (index == -1) {
      updated.add(profile);
    } else {
      updated[index] = profile;
    }
    updated.sort(
      (ScheduleProfile a, ScheduleProfile b) =>
          a.name.toLowerCase().compareTo(b.name.toLowerCase()),
    );
    return copyWith(profiles: List<ScheduleProfile>.unmodifiable(updated));
  }

  PhoneControlPolicy removeProfile(String id) => copyWith(
        profiles: profiles
            .where((ScheduleProfile profile) => profile.id != id)
            .toList(growable: false),
      );

  Map<String, Object?> toMap() => <String, Object?>{
        'masterEnabled': masterEnabled,
        'scheduleEnabled': scheduleEnabled,
        'scheduleProfilesEnabled': scheduleProfilesEnabled,
        'appLimitsEnabled': appLimitsEnabled,
        'reelsBlockerEnabled': reelsBlockerEnabled,
        'scrollLimitEnabled': scrollLimitEnabled,
        'notificationBlockerEnabled': notificationBlockerEnabled,
        'notificationPackages': notificationPackages.toList(growable: false)
          ..sort(),
        'notificationScheduleEnabled': notificationScheduleEnabled,
        'notificationWeekdays': notificationWeekdays.toList(growable: false)
          ..sort(),
        'notificationStartMinute': notificationStartMinute,
        'notificationEndMinute': notificationEndMinute,
        'notificationHistoryLimit': notificationHistoryLimit,
        'studyModeEnabled': studyModeEnabled,
        'studyStrictAllowList': studyStrictAllowList,
        'studyAllowedPackages': studyAllowedPackages.toList(growable: false)
          ..sort(),
        'studyBlockedPackages': studyBlockedPackages.toList(growable: false)
          ..sort(),
        'studySilenceNotifications': studySilenceNotifications,
        'studyDefaultMinutes': studyDefaultMinutes,
        'studyDailyGoalMinutes': studyDailyGoalMinutes,
        'studyScheduleEnabled': studyScheduleEnabled,
        'studyWeekdays': studyWeekdays.toList(growable: false)..sort(),
        'studyStartMinute': studyStartMinute,
        'studyEndMinute': studyEndMinute,
        'focusUsesStudyRules': focusUsesStudyRules,
        'globalReelsWindowEnabled': globalReelsWindowEnabled,
        'globalReelsWindowStartMillis': globalReelsWindowStartMillis,
        'globalReelsWindowEndMillis': globalReelsWindowEndMillis,
        'globalReelsWindowLimit': globalReelsWindowLimit,
        'globalReelsWindowPackages':
            globalReelsWindowPackages.toList(growable: false)..sort(),
        'globalReelsWindowLocked': globalReelsWindowLocked,
        'wellbeingWarningsEnabled': wellbeingWarningsEnabled,
        'screenTimeGoalMinutes': screenTimeGoalMinutes,
        'screenTimeWarningPercentages':
            screenTimeWarningPercentages.toList(growable: false)..sort(),
        'screenTimeRepeatMinutes': screenTimeRepeatMinutes,
        'detailedWarningNotifications': detailedWarningNotifications,
        'rules': rules.map((AppControlRule rule) => rule.toMap()).toList(),
        'profiles':
            profiles.map((ScheduleProfile profile) => profile.toMap()).toList(),
      };

  factory PhoneControlPolicy.fromMap(Map<dynamic, dynamic>? map) {
    if (map == null) return const PhoneControlPolicy();
    Set<String> readPackages(String key) =>
        (map[key] as List<dynamic>? ?? const <dynamic>[])
            .map((dynamic value) => value.toString())
            .where((String value) => value.isNotEmpty)
            .toSet();
    Set<int> readDays(String key) {
      final Set<int> values = (map[key] as List<dynamic>? ?? const <dynamic>[])
          .whereType<num>()
          .map((num value) => value.toInt())
          .where((int value) => value >= 1 && value <= 7)
          .toSet();
      return values.isEmpty ? const <int>{1, 2, 3, 4, 5, 6, 7} : values;
    }

    Set<int> readPercentages(String key, Set<int> fallback) {
      final Set<int> values = (map[key] as List<dynamic>? ?? const <dynamic>[])
          .whereType<num>()
          .map((num value) => value.toInt())
          .where((int value) => value >= 10 && value <= 100)
          .toSet();
      return values.isEmpty ? fallback : values;
    }

    final List<dynamic> rawRules =
        map['rules'] as List<dynamic>? ?? const <dynamic>[];
    final List<dynamic> rawProfiles =
        map['profiles'] as List<dynamic>? ?? const <dynamic>[];
    final List<AppControlRule> rules = rawRules
        .whereType<Map<dynamic, dynamic>>()
        .map(AppControlRule.fromMap)
        .where((AppControlRule rule) => rule.packageName.isNotEmpty)
        .toList(growable: false)
      ..sort(
        (AppControlRule a, AppControlRule b) =>
            a.label.toLowerCase().compareTo(b.label.toLowerCase()),
      );
    final List<ScheduleProfile> profiles = rawProfiles
        .whereType<Map<dynamic, dynamic>>()
        .map(ScheduleProfile.fromMap)
        .where((ScheduleProfile profile) => profile.id.isNotEmpty)
        .toList(growable: false)
      ..sort(
        (ScheduleProfile a, ScheduleProfile b) =>
            a.name.toLowerCase().compareTo(b.name.toLowerCase()),
      );
    return PhoneControlPolicy(
      masterEnabled: map['masterEnabled'] as bool? ?? false,
      scheduleEnabled: map['scheduleEnabled'] as bool? ?? true,
      scheduleProfilesEnabled: map['scheduleProfilesEnabled'] as bool? ?? true,
      appLimitsEnabled: map['appLimitsEnabled'] as bool? ?? true,
      reelsBlockerEnabled: map['reelsBlockerEnabled'] as bool? ?? true,
      scrollLimitEnabled: map['scrollLimitEnabled'] as bool? ?? true,
      notificationBlockerEnabled:
          map['notificationBlockerEnabled'] as bool? ?? false,
      notificationPackages:
          Set<String>.unmodifiable(readPackages('notificationPackages')),
      notificationScheduleEnabled:
          map['notificationScheduleEnabled'] as bool? ?? false,
      notificationWeekdays:
          Set<int>.unmodifiable(readDays('notificationWeekdays')),
      notificationStartMinute:
          ((map['notificationStartMinute'] as num?)?.toInt() ?? 1320)
              .clamp(0, 1439)
              .toInt(),
      notificationEndMinute:
          ((map['notificationEndMinute'] as num?)?.toInt() ?? 420)
              .clamp(0, 1439)
              .toInt(),
      notificationHistoryLimit: math.max(
        10,
        math.min(
            500, (map['notificationHistoryLimit'] as num?)?.toInt() ?? 100),
      ),
      studyModeEnabled: map['studyModeEnabled'] as bool? ?? true,
      studyStrictAllowList: map['studyStrictAllowList'] as bool? ?? false,
      studyAllowedPackages:
          Set<String>.unmodifiable(readPackages('studyAllowedPackages')),
      studyBlockedPackages:
          Set<String>.unmodifiable(readPackages('studyBlockedPackages')),
      studySilenceNotifications:
          map['studySilenceNotifications'] as bool? ?? true,
      studyDefaultMinutes: math.max(
        10,
        math.min(240, (map['studyDefaultMinutes'] as num?)?.toInt() ?? 50),
      ),
      studyDailyGoalMinutes: math.max(
        10,
        math.min(720, (map['studyDailyGoalMinutes'] as num?)?.toInt() ?? 120),
      ),
      studyScheduleEnabled: map['studyScheduleEnabled'] as bool? ?? false,
      studyWeekdays: Set<int>.unmodifiable(readDays('studyWeekdays')),
      studyStartMinute: ((map['studyStartMinute'] as num?)?.toInt() ?? 1140)
          .clamp(0, 1439)
          .toInt(),
      studyEndMinute: ((map['studyEndMinute'] as num?)?.toInt() ?? 1380)
          .clamp(0, 1439)
          .toInt(),
      focusUsesStudyRules: map['focusUsesStudyRules'] as bool? ?? true,
      globalReelsWindowEnabled:
          map['globalReelsWindowEnabled'] as bool? ?? false,
      globalReelsWindowStartMillis: math.max(
        0,
        (map['globalReelsWindowStartMillis'] as num?)?.toInt() ?? 0,
      ),
      globalReelsWindowEndMillis: math.max(
        0,
        (map['globalReelsWindowEndMillis'] as num?)?.toInt() ?? 0,
      ),
      globalReelsWindowLimit: math.max(
        0,
        (map['globalReelsWindowLimit'] as num?)?.toInt() ?? 0,
      ),
      globalReelsWindowPackages:
          Set<String>.unmodifiable(readPackages('globalReelsWindowPackages')),
      globalReelsWindowLocked: map['globalReelsWindowLocked'] as bool? ?? false,
      wellbeingWarningsEnabled:
          map['wellbeingWarningsEnabled'] as bool? ?? true,
      screenTimeGoalMinutes: math.max(
        30,
        math.min(1440, (map['screenTimeGoalMinutes'] as num?)?.toInt() ?? 240),
      ),
      screenTimeWarningPercentages: Set<int>.unmodifiable(
        readPercentages(
          'screenTimeWarningPercentages',
          const <int>{50, 75, 90, 100},
        ),
      ),
      screenTimeRepeatMinutes: math.max(
        15,
        math.min(240, (map['screenTimeRepeatMinutes'] as num?)?.toInt() ?? 30),
      ),
      detailedWarningNotifications:
          map['detailedWarningNotifications'] as bool? ?? true,
      rules: List<AppControlRule>.unmodifiable(rules),
      profiles: List<ScheduleProfile>.unmodifiable(profiles),
    );
  }
}

class PhoneControlUsage {
  const PhoneControlUsage({
    this.usageMillis = const <String, int>{},
    this.scrollCounts = const <String, int>{},
    this.blockedAttempts = const <String, int>{},
    this.reelsBlocked = const <String, int>{},
    this.reelsViewed = const <String, int>{},
    this.reelsWatchMillis = const <String, int>{},
    this.notificationsBlocked = const <String, int>{},
    this.totalScreenTimeMillis = 0,
    this.trackingDate = '',
    this.screenTimeWindowStartMillis = 0,
    this.screenTimeSource = 'unavailable',
    this.screenTimeEventCount = 0,
    this.globalReelsWindowViewed = 0,
  });

  final Map<String, int> usageMillis;
  final Map<String, int> scrollCounts;
  final Map<String, int> blockedAttempts;
  final Map<String, int> reelsBlocked;
  final Map<String, int> reelsViewed;
  final Map<String, int> reelsWatchMillis;
  final Map<String, int> notificationsBlocked;
  final int totalScreenTimeMillis;
  final String trackingDate;
  final int screenTimeWindowStartMillis;
  final String screenTimeSource;
  final int screenTimeEventCount;
  final int globalReelsWindowViewed;

  DateTime? get screenTimeWindowStart => screenTimeWindowStartMillis <= 0
      ? null
      : DateTime.fromMillisecondsSinceEpoch(screenTimeWindowStartMillis);

  String get screenTimeSourceLabel => switch (screenTimeSource) {
        'usage_events' => 'Android activity timeline',
        'aggregate_fallback' => 'Android usage summary',
        'accessibility_fallback' => 'Accessibility fallback',
        _ => 'Usage Access required',
      };

  int usageMinutesFor(String packageName) =>
      (usageMillis[packageName] ?? 0) ~/ 60000;
  int scrollCountFor(String packageName) => scrollCounts[packageName] ?? 0;
  int blockedCountFor(String packageName) => blockedAttempts[packageName] ?? 0;
  int reelsBlockedFor(String packageName) => reelsBlocked[packageName] ?? 0;
  int reelsViewedFor(String packageName) => reelsViewed[packageName] ?? 0;
  int reelsWatchMinutesFor(String packageName) =>
      (reelsWatchMillis[packageName] ?? 0) ~/ 60000;
  int notificationsBlockedFor(String packageName) =>
      notificationsBlocked[packageName] ?? 0;
  int get totalBlockedAttempts =>
      blockedAttempts.values.fold<int>(0, (int sum, int value) => sum + value);
  int get totalReelsBlocked =>
      reelsBlocked.values.fold<int>(0, (int sum, int value) => sum + value);
  int get totalNotificationsBlocked => notificationsBlocked.values
      .fold<int>(0, (int sum, int value) => sum + value);

  factory PhoneControlUsage.fromMap(Map<dynamic, dynamic>? map) {
    Map<String, int> intMap(dynamic raw) {
      if (raw is! Map<dynamic, dynamic>) return const <String, int>{};
      return Map<String, int>.unmodifiable(
        raw.map(
          (dynamic key, dynamic value) => MapEntry<String, int>(
            key.toString(),
            (value as num?)?.toInt() ?? 0,
          ),
        ),
      );
    }

    return PhoneControlUsage(
      usageMillis: intMap(map?['usageMillis']),
      scrollCounts: intMap(map?['scrollCounts']),
      blockedAttempts: intMap(map?['blockedAttempts']),
      reelsBlocked: intMap(map?['reelsBlocked']),
      reelsViewed: intMap(map?['reelsViewed']),
      reelsWatchMillis: intMap(map?['reelsWatchMillis']),
      notificationsBlocked: intMap(map?['notificationsBlocked']),
      totalScreenTimeMillis:
          (map?['totalScreenTimeMillis'] as num?)?.toInt() ?? 0,
      trackingDate: map?['trackingDate']?.toString() ?? '',
      screenTimeWindowStartMillis:
          (map?['screenTimeWindowStartMillis'] as num?)?.toInt() ?? 0,
      screenTimeSource: map?['screenTimeSource']?.toString() ?? 'unavailable',
      screenTimeEventCount:
          (map?['screenTimeEventCount'] as num?)?.toInt() ?? 0,
      globalReelsWindowViewed:
          (map?['globalReelsWindowViewed'] as num?)?.toInt() ?? 0,
    );
  }
}

class PhoneControlDayUsage {
  const PhoneControlDayUsage({
    required this.date,
    this.totalScreenTimeMillis = 0,
    this.distractionTimeMillis = 0,
  });

  final String date;
  final int totalScreenTimeMillis;
  final int distractionTimeMillis;

  DateTime? get parsedDate => DateTime.tryParse(date);

  factory PhoneControlDayUsage.fromMap(Map<dynamic, dynamic> map) =>
      PhoneControlDayUsage(
        date: map['date']?.toString() ?? '',
        totalScreenTimeMillis:
            math.max(0, (map['totalScreenTimeMillis'] as num?)?.toInt() ?? 0),
        distractionTimeMillis:
            math.max(0, (map['distractionTimeMillis'] as num?)?.toInt() ?? 0),
      );
}

class PhoneControlDashboardSnapshot {
  const PhoneControlDashboardSnapshot({
    this.usage = const PhoneControlUsage(),
    this.distractionTimeMillis = 0,
    this.weekly = const <PhoneControlDayUsage>[],
  });

  final PhoneControlUsage usage;
  final int distractionTimeMillis;
  final List<PhoneControlDayUsage> weekly;

  double get distractionRatio {
    if (usage.totalScreenTimeMillis <= 0) return 0;
    return (distractionTimeMillis / usage.totalScreenTimeMillis)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  int get weeklyDistractionMillis => weekly.fold<int>(
        0,
        (int total, PhoneControlDayUsage day) =>
            total + day.distractionTimeMillis,
      );

  factory PhoneControlDashboardSnapshot.fromMap(
    Map<dynamic, dynamic>? map,
  ) {
    final List<dynamic> rawWeekly =
        map?['weekly'] as List<dynamic>? ?? const <dynamic>[];
    return PhoneControlDashboardSnapshot(
      usage: PhoneControlUsage.fromMap(map),
      distractionTimeMillis: math.max(
        0,
        (map?['distractionTimeMillis'] as num?)?.toInt() ?? 0,
      ),
      weekly: List<PhoneControlDayUsage>.unmodifiable(
        rawWeekly
            .whereType<Map<dynamic, dynamic>>()
            .map(PhoneControlDayUsage.fromMap),
      ),
    );
  }
}

class NotificationHistoryItem {
  const NotificationHistoryItem({
    required this.packageName,
    required this.appLabel,
    required this.title,
    required this.text,
    required this.timestampMillis,
  });

  final String packageName;
  final String appLabel;
  final String title;
  final String text;
  final int timestampMillis;

  DateTime get timestamp =>
      DateTime.fromMillisecondsSinceEpoch(timestampMillis);

  factory NotificationHistoryItem.fromMap(Map<dynamic, dynamic> map) =>
      NotificationHistoryItem(
        packageName: map['packageName']?.toString() ?? '',
        appLabel: map['appLabel']?.toString() ??
            map['packageName']?.toString() ??
            'Unknown app',
        title: map['title']?.toString() ?? '',
        text: map['text']?.toString() ?? '',
        timestampMillis: (map['timestampMillis'] as num?)?.toInt() ?? 0,
      );
}

class SocialControlSnapshot {
  const SocialControlSnapshot({
    this.notificationAccessEnabled = false,
    this.reelsBlocked = const <String, int>{},
    this.reelsViewed = const <String, int>{},
    this.reelsWatchMillis = const <String, int>{},
    this.notificationsBlocked = const <String, int>{},
    this.scrollCounts = const <String, int>{},
    this.notificationHistory = const <NotificationHistoryItem>[],
  });

  final bool notificationAccessEnabled;
  final Map<String, int> reelsBlocked;
  final Map<String, int> reelsViewed;
  final Map<String, int> reelsWatchMillis;
  final Map<String, int> notificationsBlocked;
  final Map<String, int> scrollCounts;
  final List<NotificationHistoryItem> notificationHistory;

  int get totalReelsBlocked =>
      reelsBlocked.values.fold<int>(0, (int total, int value) => total + value);
  int get totalReelsViewed =>
      reelsViewed.values.fold<int>(0, (int total, int value) => total + value);
  int get totalReelsWatchMillis => reelsWatchMillis.values
      .fold<int>(0, (int total, int value) => total + value);
  int get totalNotificationsBlocked => notificationsBlocked.values
      .fold<int>(0, (int total, int value) => total + value);
  int get totalScrolls =>
      scrollCounts.values.fold<int>(0, (int total, int value) => total + value);

  factory SocialControlSnapshot.fromMap(Map<dynamic, dynamic>? map) {
    Map<String, int> intMap(dynamic raw) {
      if (raw is! Map<dynamic, dynamic>) return const <String, int>{};
      return Map<String, int>.unmodifiable(
        raw.map(
          (dynamic key, dynamic value) => MapEntry<String, int>(
            key.toString(),
            (value as num?)?.toInt() ?? 0,
          ),
        ),
      );
    }

    final List<dynamic> rawHistory =
        map?['notificationHistory'] as List<dynamic>? ?? const <dynamic>[];
    return SocialControlSnapshot(
      notificationAccessEnabled:
          map?['notificationAccessEnabled'] as bool? ?? false,
      reelsBlocked: intMap(map?['reelsBlocked']),
      reelsViewed: intMap(map?['reelsViewed']),
      reelsWatchMillis: intMap(map?['reelsWatchMillis']),
      notificationsBlocked: intMap(map?['notificationsBlocked']),
      scrollCounts: intMap(map?['scrollCounts']),
      notificationHistory: List<NotificationHistoryItem>.unmodifiable(
        rawHistory
            .whereType<Map<dynamic, dynamic>>()
            .map(NotificationHistoryItem.fromMap),
      ),
    );
  }
}

String formatMinuteOfDay(int value) {
  final int safe = value.clamp(0, 1439).toInt();
  final int hour = safe ~/ 60;
  final int minute = safe % 60;
  final int displayHour = hour == 0 ? 12 : (hour > 12 ? hour - 12 : hour);
  final String suffix = hour >= 12 ? 'PM' : 'AM';
  return '$displayHour:${minute.toString().padLeft(2, '0')} $suffix';
}

String formatUsageDuration(int milliseconds) {
  final int totalMinutes = math.max(0, milliseconds ~/ 60000);
  final int hours = totalMinutes ~/ 60;
  final int minutes = totalMinutes % 60;
  if (hours == 0) return '${minutes}m';
  return '${hours}h ${minutes}m';
}
