import 'dart:math' as math;

class StudyGameStats {
  const StudyGameStats({
    required this.level,
    required this.totalXp,
    required this.levelStartXp,
    required this.nextLevelXp,
    required this.rank,
    required this.stage,
    required this.focusMinutes,
    required this.completedTasks,
    required this.streak,
  });

  final int level;
  final int totalXp;
  final int levelStartXp;
  final int nextLevelXp;
  final String rank;
  final String stage;
  final int focusMinutes;
  final int completedTasks;
  final int streak;

  int get xpIntoLevel => totalXp - levelStartXp;
  int get xpNeededForLevel => math.max(1, nextLevelXp - levelStartXp);
  double get progress =>
      (xpIntoLevel / xpNeededForLevel).clamp(0.0, 1.0).toDouble();

  static StudyGameStats calculate({
    required int focusMinutes,
    required int completedTasks,
    required int streak,
  }) {
    final int safeFocus = math.max(0, focusMinutes);
    final int safeCompleted = math.max(0, completedTasks);
    final int safeStreak = math.max(0, streak);
    final int totalXp = safeFocus * 3 + safeCompleted * 15 + safeStreak * 30;

    int level = 1;
    int levelStart = 0;
    int nextLevel = 180;
    while (totalXp >= nextLevel && level < 100) {
      level += 1;
      levelStart = nextLevel;
      nextLevel += 140 + level * 35;
    }

    String rank;
    String stage;
    if (level >= 40) {
      rank = 'Focus Legend';
      stage = 'Golden Knowledge Tree';
    } else if (level >= 25) {
      rank = 'Master Scholar';
      stage = 'Ancient Learning Tree';
    } else if (level >= 15) {
      rank = 'Deep Work Expert';
      stage = 'Strong Knowledge Tree';
    } else if (level >= 8) {
      rank = 'Focused Learner';
      stage = 'Growing Study Tree';
    } else if (level >= 3) {
      rank = 'Consistent Student';
      stage = 'Young Study Plant';
    } else {
      rank = 'New Explorer';
      stage = 'Knowledge Seed';
    }

    return StudyGameStats(
      level: level,
      totalXp: totalXp,
      levelStartXp: levelStart,
      nextLevelXp: nextLevel,
      rank: rank,
      stage: stage,
      focusMinutes: safeFocus,
      completedTasks: safeCompleted,
      streak: safeStreak,
    );
  }
}
