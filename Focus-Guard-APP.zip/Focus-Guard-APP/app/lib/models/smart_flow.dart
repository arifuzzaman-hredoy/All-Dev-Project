enum ExperienceMode { simple, advanced }

extension ExperienceModeLabel on ExperienceMode {
  String get label => this == ExperienceMode.simple ? 'Simple' : 'Advanced';
}

class SmartFlowSettings {
  const SmartFlowSettings({
    this.version = 1,
    this.experienceMode = ExperienceMode.simple,
    this.dailyCoachEnabled = true,
    this.weeklyReportEnabled = true,
    this.smartRecommendationsEnabled = true,
    this.rulePreviewRequired = true,
    this.lastSafetyStopMillis = 0,
    this.userAlwaysAllowedPackages = const <String>{},
    this.simpleShortcutIds = const <String>{
      'coach',
      'phone-control',
      'study',
      'weekly-report',
      'safety',
    },
  });

  final int version;
  final ExperienceMode experienceMode;
  final bool dailyCoachEnabled;
  final bool weeklyReportEnabled;
  final bool smartRecommendationsEnabled;
  final bool rulePreviewRequired;
  final int lastSafetyStopMillis;
  final Set<String> userAlwaysAllowedPackages;
  final Set<String> simpleShortcutIds;

  bool get simpleMode => experienceMode == ExperienceMode.simple;

  SmartFlowSettings copyWith({
    ExperienceMode? experienceMode,
    bool? dailyCoachEnabled,
    bool? weeklyReportEnabled,
    bool? smartRecommendationsEnabled,
    bool? rulePreviewRequired,
    int? lastSafetyStopMillis,
    Set<String>? userAlwaysAllowedPackages,
    Set<String>? simpleShortcutIds,
  }) =>
      SmartFlowSettings(
        version: version,
        experienceMode: experienceMode ?? this.experienceMode,
        dailyCoachEnabled: dailyCoachEnabled ?? this.dailyCoachEnabled,
        weeklyReportEnabled: weeklyReportEnabled ?? this.weeklyReportEnabled,
        smartRecommendationsEnabled:
            smartRecommendationsEnabled ?? this.smartRecommendationsEnabled,
        rulePreviewRequired: rulePreviewRequired ?? this.rulePreviewRequired,
        lastSafetyStopMillis:
            lastSafetyStopMillis ?? this.lastSafetyStopMillis,
        userAlwaysAllowedPackages:
            userAlwaysAllowedPackages ?? this.userAlwaysAllowedPackages,
        simpleShortcutIds: simpleShortcutIds ?? this.simpleShortcutIds,
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'version': version,
        'experienceMode': experienceMode.name,
        'dailyCoachEnabled': dailyCoachEnabled,
        'weeklyReportEnabled': weeklyReportEnabled,
        'smartRecommendationsEnabled': smartRecommendationsEnabled,
        'rulePreviewRequired': rulePreviewRequired,
        'lastSafetyStopMillis': lastSafetyStopMillis,
        'userAlwaysAllowedPackages':
            userAlwaysAllowedPackages.toList(growable: false)..sort(),
        'simpleShortcutIds': simpleShortcutIds.toList(growable: false)..sort(),
      };

  factory SmartFlowSettings.fromJson(Map<String, Object?> json) {
    Set<String> readSet(Object? value) => value is List<Object?>
        ? value
            .map((Object? item) => item?.toString() ?? '')
            .where((String item) => item.isNotEmpty)
            .toSet()
        : <String>{};

    final String mode = json['experienceMode']?.toString() ?? 'simple';
    final Set<String> shortcuts = readSet(json['simpleShortcutIds']);
    return SmartFlowSettings(
      version: (json['version'] as num?)?.toInt() ?? 1,
      experienceMode:
          mode == 'advanced' ? ExperienceMode.advanced : ExperienceMode.simple,
      dailyCoachEnabled: json['dailyCoachEnabled'] as bool? ?? true,
      weeklyReportEnabled: json['weeklyReportEnabled'] as bool? ?? true,
      smartRecommendationsEnabled:
          json['smartRecommendationsEnabled'] as bool? ?? true,
      rulePreviewRequired: json['rulePreviewRequired'] as bool? ?? true,
      lastSafetyStopMillis:
          (json['lastSafetyStopMillis'] as num?)?.toInt() ?? 0,
      userAlwaysAllowedPackages: readSet(json['userAlwaysAllowedPackages']),
      simpleShortcutIds: shortcuts.isEmpty
          ? const <String>{
              'coach',
              'phone-control',
              'study',
              'weekly-report',
              'safety',
            }
          : shortcuts,
    );
  }
}

class SmartCoachItem {
  const SmartCoachItem({
    required this.title,
    required this.detail,
    required this.priority,
    required this.actionId,
  });

  final String title;
  final String detail;
  final int priority;
  final String actionId;
}

class WeeklyFlowReport {
  const WeeklyFlowReport({
    required this.completedTasks,
    required this.totalTasks,
    required this.focusMinutes,
    required this.productiveDays,
    required this.averageCompletion,
    required this.bestDayLabel,
  });

  final int completedTasks;
  final int totalTasks;
  final int focusMinutes;
  final int productiveDays;
  final int averageCompletion;
  final String bestDayLabel;

  String toShareText() =>
      'Hredoy Flow weekly report\n'
      'Tasks: $completedTasks/$totalTasks completed\n'
      'Focus: $focusMinutes minutes\n'
      'Productive days: $productiveDays/7\n'
      'Average completion: $averageCompletion%\n'
      'Best day: $bestDayLabel';
}
