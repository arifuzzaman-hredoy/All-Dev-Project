import 'package:flutter/material.dart';

class AlarmPreset {
  const AlarmPreset({
    required this.id,
    required this.title,
    required this.notes,
    required this.category,
    required this.hour,
    required this.minute,
    required this.durationMinutes,
    required this.icon,
  });

  final String id;
  final String title;
  final String notes;
  final String category;
  final int hour;
  final int minute;
  final int durationMinutes;
  final IconData icon;

  String timeLabel(BuildContext context) =>
      TimeOfDay(hour: hour, minute: minute).format(context);
}

abstract final class AlarmPresetCatalog {
  static const List<String> _categories = <String>[
    'Morning routine',
    'Study',
    'Class',
    'Revision',
    'Office',
    'Health',
    'Prayer & reflection',
    'Break',
    'Deep work',
  ];

  static const List<String> _actions = <String>[
    'Wake up and begin',
    'Start focused work',
    'Review the next topic',
    'Prepare and leave',
    'Finish the priority task',
    'Take a healthy break',
  ];

  static const List<int> _hours = <int>[5, 6, 7, 9, 11, 14, 16, 19, 21];
  static const List<int> _minutes = <int>[0, 15, 30, 45];
  static const List<int> _durations = <int>[15, 25, 30, 45, 50, 60];

  static final List<AlarmPreset> all = List<AlarmPreset>.unmodifiable(
    List<AlarmPreset>.generate(216, (int index) {
      final int categoryIndex = index % _categories.length;
      final int actionIndex = (index ~/ _categories.length) % _actions.length;
      final int timeIndex = index % (_hours.length * _minutes.length);
      final int hour = _hours[timeIndex % _hours.length];
      final int minute =
          _minutes[(timeIndex ~/ _hours.length) % _minutes.length];
      final int duration = _durations[index % _durations.length];
      final String category = _categories[categoryIndex];
      final String action = _actions[actionIndex];
      return AlarmPreset(
        id: 'preset-${index + 1}',
        title: '$category • $action',
        notes:
            'Preset ${index + 1}: $action for $duration minutes. Adjust the date before saving.',
        category: category,
        hour: hour,
        minute: minute,
        durationMinutes: duration,
        icon: _iconFor(categoryIndex),
      );
    }),
  );

  static IconData _iconFor(int index) => switch (index) {
        0 => Icons.wb_sunny_rounded,
        1 => Icons.school_rounded,
        2 => Icons.class_rounded,
        3 => Icons.history_edu_rounded,
        4 => Icons.work_rounded,
        5 => Icons.favorite_rounded,
        6 => Icons.self_improvement_rounded,
        7 => Icons.free_breakfast_rounded,
        _ => Icons.center_focus_strong_rounded,
      };
}
