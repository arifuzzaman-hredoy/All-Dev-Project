import 'package:flutter/widgets.dart';

abstract final class RootTabNavigation {
  static final ValueNotifier<int> selectedIndex = ValueNotifier<int>(0);

  static void select(int index) {
    if (index < 0 || index > 5 || selectedIndex.value == index) return;
    selectedIndex.value = index;
  }
}

class RootNavigationScope extends InheritedWidget {
  const RootNavigationScope({
    required this.selectedIndex,
    required this.selectTab,
    required super.child,
    super.key,
  });

  final int selectedIndex;
  final ValueChanged<int> selectTab;

  static RootNavigationScope? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<RootNavigationScope>();

  static RootNavigationScope of(BuildContext context) {
    final RootNavigationScope? scope = maybeOf(context);
    assert(scope != null, 'RootNavigationScope is missing.');
    return scope!;
  }

  @override
  bool updateShouldNotify(RootNavigationScope oldWidget) =>
      selectedIndex != oldWidget.selectedIndex ||
      selectTab != oldWidget.selectTab;
}
