import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../controllers/smart_flow_controller.dart';
import '../models/smart_flow.dart';
import '../screens/experience_settings_screen.dart';
import '../screens/focus_game_screen.dart';
import '../screens/goal_manager_screen.dart';
import '../screens/phone_control_dashboard_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/protection_center_screen.dart';
import '../screens/safety_center_screen.dart';
import '../screens/schedule_profiles_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/smart_coach_screen.dart';
import '../screens/smart_recommendations_screen.dart';
import '../screens/social_control_screen.dart';
import '../screens/study_mode_screen.dart';
import '../screens/weekly_report_screen.dart';
import 'app_logo.dart';
import 'profile_avatar.dart';
import 'root_navigation.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final SmartFlowController smart = SmartFlowScope.of(context);
    final RootNavigationScope? navigation =
        RootNavigationScope.maybeOf(context);
    final ColorScheme colors = Theme.of(context).colorScheme;

    void selectTab(int index) {
      final NavigatorState navigator = Navigator.of(context);
      navigator.pop();
      RootTabNavigation.select(index);
      navigation?.selectTab(index);
      if (navigation == null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (navigator.mounted) {
            navigator.popUntil((Route<dynamic> route) => route.isFirst);
          }
        });
      }
    }

    void openPage(Widget page) {
      Navigator.of(context).pop();
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
    }

    final String userName = controller.preferences.userName.trim();

    return NavigationDrawer(
      key: const ValueKey<String>('app-navigation-drawer'),
      selectedIndex: navigation?.selectedIndex,
      onDestinationSelected: selectTab,
      children: <Widget>[
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const AppLogo(size: 54, showWordmark: true),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: <Widget>[
                      ProfileAvatar(
                        name: userName,
                        imageBase64: controller.preferences.profileImageBase64,
                        radius: 22,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              userName.isEmpty ? 'Hredoy' : userName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            Text(
                              '${smart.settings.experienceMode.label} Mode • '
                              'Level ${controller.gameStats.level}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.today_outlined),
          selectedIcon: Icon(Icons.today_rounded),
          label: Text('Today'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.calendar_month_outlined),
          selectedIcon: Icon(Icons.calendar_month_rounded),
          label: Text('Planner'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.center_focus_strong_outlined),
          selectedIcon: Icon(Icons.center_focus_strong_rounded),
          label: Text('Focus'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.insights_outlined),
          selectedIcon: Icon(Icons.insights_rounded),
          label: Text('Insights'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.search_rounded),
          selectedIcon: Icon(Icons.manage_search_rounded),
          label: Text('Search'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.grid_view_outlined),
          selectedIcon: Icon(Icons.grid_view_rounded),
          label: Text('More'),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(28, 16, 28, 8),
          child: Text(
            'QUICK ACCESS',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
          ),
        ),
        ListTile(
          key: const ValueKey<String>('drawer-profile-shortcut'),
          leading: const Icon(Icons.person_rounded),
          title: const Text('Profile'),
          subtitle: const Text('Name, exam targets and routine restart'),
          onTap: () => openPage(const ProfileScreen()),
        ),
        ListTile(
          leading: const Icon(Icons.health_and_safety_rounded),
          title: const Text('Safety Center'),
          subtitle: const Text('Always allowed apps and stop all blocking'),
          onTap: () => openPage(const SafetyCenterScreen()),
        ),
        ListTile(
          leading: const Icon(Icons.shield_rounded),
          title: const Text('Protection Center'),
          subtitle: const Text('Web, DNS, Prime Mode and Keep Me Out'),
          onTap: () => openPage(const ProtectionCenterScreen()),
        ),
        if (smart.settings.dailyCoachEnabled)
          ListTile(
            leading: const Icon(Icons.auto_awesome_rounded),
            title: const Text('Daily Coach'),
            subtitle: const Text('Top actions and a safe daily plan'),
            onTap: () => openPage(const SmartCoachScreen()),
          ),
        ListTile(
          leading: const Icon(Icons.phonelink_lock_rounded),
          title: const Text('Phone Control'),
          subtitle: const Text('Limits, schedules and Reels controls'),
          onTap: () => openPage(const PhoneControlDashboardScreen()),
        ),
        ListTile(
          leading: const Icon(Icons.school_rounded),
          title: const Text('Study Mode'),
          subtitle: const Text('Study schedule and Focus-shared rules'),
          onTap: () => openPage(const StudyModeScreen()),
        ),
        if (smart.settings.weeklyReportEnabled)
          ListTile(
            leading: const Icon(Icons.summarize_rounded),
            title: const Text('Weekly Report'),
            subtitle: const Text('Tasks, focus and best day'),
            onTap: () => openPage(const WeeklyReportScreen()),
          ),
        ListTile(
          key: const ValueKey<String>('drawer-study-quest'),
          leading: const Icon(Icons.sports_esports_rounded),
          title: const Text('Study Quest'),
          subtitle: const Text('Study minutes become XP and rewards'),
          onTap: () => openPage(const FocusGameScreen()),
        ),
        ListTile(
          leading: const Icon(Icons.auto_awesome_motion_rounded),
          title: const Text('Simple & Advanced Mode'),
          subtitle: const Text('Choose how many tools are shown'),
          onTap: () => openPage(const ExperienceSettingsScreen()),
        ),
        if (!smart.settings.simpleMode) ...<Widget>[
          const Padding(
            padding: EdgeInsets.fromLTRB(28, 16, 28, 8),
            child: Text(
              'ADVANCED',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
            ),
          ),
          if (smart.settings.smartRecommendationsEnabled)
            ListTile(
              leading: const Icon(Icons.psychology_alt_rounded),
              title: const Text('Smart Recommendations'),
              subtitle:
                  const Text('Local app categories without auto-blocking'),
              onTap: () => openPage(const SmartRecommendationsScreen()),
            ),
          ListTile(
            leading: const Icon(Icons.flag_rounded),
            title: const Text('Goals & Targets'),
            subtitle: const Text('Progress and deadlines'),
            onTap: () => openPage(const GoalManagerScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.calendar_month_rounded),
            title: const Text('Schedule Profiles'),
            subtitle: const Text('Recurring app blocks'),
            onTap: () => openPage(const ScheduleProfilesScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.notifications_off_rounded),
            title: const Text('Social & Notifications'),
            subtitle: const Text('Notifications and short-video analytics'),
            onTap: () => openPage(const SocialControlScreen()),
          ),
          ListTile(
            leading: const Icon(Icons.settings_rounded),
            title: const Text('App Settings'),
            subtitle: const Text('Alarm, battery, permissions and theme'),
            onTap: () => openPage(const SettingsScreen()),
          ),
        ],
        const SizedBox(height: 24),
      ],
    );
  }
}
