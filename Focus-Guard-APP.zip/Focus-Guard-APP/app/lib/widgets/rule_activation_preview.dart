import 'package:flutter/material.dart';

import '../models/phone_control.dart';
import '../services/native_bridge.dart';

class RuleActivationPreviewSheet extends StatelessWidget {
  const RuleActivationPreviewSheet({
    required this.policy,
    required this.apps,
    required this.alwaysAllowedPackages,
    super.key,
  });

  final PhoneControlPolicy policy;
  final List<LaunchableAppInfo> apps;
  final Set<String> alwaysAllowedPackages;

  static Future<bool> show(
    BuildContext context, {
    required PhoneControlPolicy policy,
    required List<LaunchableAppInfo> apps,
    required Set<String> alwaysAllowedPackages,
  }) async =>
      await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (BuildContext context) => RuleActivationPreviewSheet(
          policy: policy,
          apps: apps,
          alwaysAllowedPackages: alwaysAllowedPackages,
        ),
      ) ??
      false;

  @override
  Widget build(BuildContext context) {
    final Map<String, LaunchableAppInfo> byPackage = <String, LaunchableAppInfo>{
      for (final LaunchableAppInfo app in apps) app.packageName: app,
    };
    final List<AppControlRule> activeRules = policy.rules
        .where((AppControlRule rule) => rule.enabled && rule.hasRestriction)
        .where(
          (AppControlRule rule) =>
              !alwaysAllowedPackages.contains(rule.packageName),
        )
        .toList(growable: false);
    final Set<String> scheduledPackages = policy.profiles
        .where((ScheduleProfile profile) => profile.enabled)
        .expand((ScheduleProfile profile) => profile.blockedPackages)
        .where((String packageName) =>
            !alwaysAllowedPackages.contains(packageName))
        .toSet();
    final int essentialCount = apps
        .where((LaunchableAppInfo app) => app.protected)
        .length;

    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .86,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    'Review before activation',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    policy.masterEnabled
                        ? 'Phone Control will be active after save.'
                        : 'Rules will be saved, but Master Phone Control remains off.',
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                children: <Widget>[
                  _PreviewSummary(
                    icon: Icons.shield_rounded,
                    title: '$essentialCount essential apps protected',
                    subtitle:
                        '${alwaysAllowedPackages.length} extra apps always allowed by you',
                  ),
                  _PreviewSummary(
                    icon: Icons.phonelink_lock_rounded,
                    title: '${activeRules.length} direct app rules',
                    subtitle:
                        '${scheduledPackages.length} apps also appear in recurring schedules',
                  ),
                  _PreviewSummary(
                    icon: Icons.school_rounded,
                    title: policy.studyScheduleEnabled
                        ? 'Automatic Study schedule is enabled'
                        : 'Automatic Study schedule is off',
                    subtitle: policy.focusUsesStudyRules
                        ? 'Focus sessions use the same Study app rules'
                        : 'Focus sessions do not inherit Study rules',
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Apps affected directly',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  if (activeRules.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No direct app rules are active. Saving cannot block an app directly.',
                        ),
                      ),
                    )
                  else
                    ...activeRules.map(
                      (AppControlRule rule) => Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(
                              rule.label.isEmpty
                                  ? '?'
                                  : rule.label.substring(0, 1).toUpperCase(),
                            ),
                          ),
                          title: Text(
                            rule.label,
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: Text(_ruleSummary(rule)),
                          trailing: byPackage[rule.packageName]?.protected == true
                              ? const Chip(label: Text('Protected'))
                              : null,
                        ),
                      ),
                    ),
                  const SizedBox(height: 10),
                  Card(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    child: const Padding(
                      padding: EdgeInsets.all(16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.info_outline_rounded),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Recommendations never create rules automatically. Only the apps listed above can be affected by this save.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(false),
                      child: const Text('Go back'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => Navigator.of(context).pop(true),
                      icon: const Icon(Icons.check_rounded),
                      label: const Text('Confirm save'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _ruleSummary(AppControlRule rule) {
    final List<String> parts = <String>[];
    if (rule.blockApp) parts.add('full app block');
    if (rule.blockOutsideSchedule) {
      parts.add('outside ${rule.scheduleLabel()}');
    }
    if (rule.dailyLimitMinutes > 0) {
      parts.add('${rule.dailyLimitMinutes} min/day');
    }
    if (rule.reelsGuard) {
      parts.add(
        rule.blockReelsImmediately
            ? 'Reels blocked'
            : '${rule.reelsDailyLimit} Reels • ${rule.reelsTimeLimitMinutes} min',
      );
    }
    if (rule.scrollLimit > 0) parts.add('${rule.scrollLimit} scrolls');
    return parts.isEmpty ? 'No active restriction' : parts.join(' • ');
  }
}

class _PreviewSummary extends StatelessWidget {
  const _PreviewSummary({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: CircleAvatar(child: Icon(icon)),
          title: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          subtitle: Text(subtitle),
        ),
      );
}
