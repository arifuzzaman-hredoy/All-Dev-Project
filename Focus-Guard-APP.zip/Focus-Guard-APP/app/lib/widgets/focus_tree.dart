import 'dart:math' as math;

import 'package:flutter/material.dart';

class FocusTree extends StatefulWidget {
  const FocusTree({
    required this.progress,
    this.level = 1,
    this.height = 230,
    this.showGround = true,
    this.semanticLabel = 'Growing focus forest',
    super.key,
  });

  final double progress;
  final int level;
  final double height;
  final bool showGround;
  final String semanticLabel;

  @override
  State<FocusTree> createState() => _FocusTreeState();
}

class _FocusTreeState extends State<FocusTree>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Semantics(
      label: widget.semanticLabel,
      value:
          '${(widget.progress.clamp(0, 1) * 100).round()} percent grown, level ${widget.level}',
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (BuildContext context, Widget? child) => CustomPaint(
            size: Size(double.infinity, widget.height),
            painter: _FocusForestPainter(
              progress: widget.progress.clamp(0.0, 1.0).toDouble(),
              level: widget.level.clamp(1, 100).toInt(),
              breeze: math.sin(_controller.value * math.pi * 2),
              trunkColor: colors.onSurfaceVariant,
              leafColor: colors.primary,
              secondaryLeafColor: colors.tertiary,
              groundColor: colors.primaryContainer,
              glowColor: colors.primary,
              surfaceColor: colors.surface,
              skyColor: colors.secondaryContainer,
              showGround: widget.showGround,
            ),
          ),
        ),
      ),
    );
  }
}

class _FocusForestPainter extends CustomPainter {
  const _FocusForestPainter({
    required this.progress,
    required this.level,
    required this.breeze,
    required this.trunkColor,
    required this.leafColor,
    required this.secondaryLeafColor,
    required this.groundColor,
    required this.glowColor,
    required this.surfaceColor,
    required this.skyColor,
    required this.showGround,
  });

  final double progress;
  final int level;
  final double breeze;
  final Color trunkColor;
  final Color leafColor;
  final Color secondaryLeafColor;
  final Color groundColor;
  final Color glowColor;
  final Color surfaceColor;
  final Color skyColor;
  final bool showGround;

  @override
  void paint(Canvas canvas, Size size) {
    final double maturity =
        (progress * 0.70 + ((level - 1) / 40).clamp(0.0, 1.0) * 0.30)
            .clamp(0.02, 1.0)
            .toDouble();
    final Offset groundCenter = Offset(size.width / 2, size.height * 0.88);

    _drawSky(canvas, size, maturity);
    _drawSunAndClouds(canvas, size, maturity);
    _drawMountains(canvas, size, maturity);
    _drawBackgroundForest(canvas, size, maturity);
    if (showGround) _drawGround(canvas, size, groundCenter, maturity);
    _drawMainTree(canvas, size, groundCenter, maturity);
    _drawGroundDetails(canvas, size, groundCenter, maturity);
    _drawBirds(canvas, size, maturity);
    _drawFireflies(canvas, size, maturity);
  }

  void _drawSky(Canvas canvas, Size size, double maturity) {
    final Rect rect = Offset.zero & size;
    final Paint paint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          skyColor.withValues(alpha: 0.58),
          surfaceColor.withValues(alpha: 0.92),
          groundColor.withValues(alpha: 0.28 + maturity * 0.18),
        ],
      ).createShader(rect);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(22)),
      paint,
    );
  }

  void _drawSunAndClouds(Canvas canvas, Size size, double maturity) {
    final Offset sun = Offset(size.width * 0.78, size.height * 0.18);
    final Paint glow = Paint()
      ..color = glowColor.withValues(alpha: 0.10 + maturity * 0.08)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
    canvas.drawCircle(sun, 22 + maturity * 8, glow);
    canvas.drawCircle(
      sun,
      8 + maturity * 4,
      Paint()..color = glowColor.withValues(alpha: 0.48),
    );

    final Paint cloudPaint = Paint()
      ..color = surfaceColor.withValues(alpha: 0.42);
    for (int cloud = 0; cloud < 2; cloud++) {
      final double x = size.width * (0.18 + cloud * 0.42) + breeze * 4;
      final double y = size.height * (0.16 + cloud * 0.07);
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, y), width: 46, height: 15),
        cloudPaint,
      );
      canvas.drawCircle(Offset(x - 13, y - 3), 10, cloudPaint);
      canvas.drawCircle(Offset(x + 8, y - 6), 13, cloudPaint);
    }
  }

  void _drawMountains(Canvas canvas, Size size, double maturity) {
    final Paint far = Paint()
      ..color = secondaryLeafColor.withValues(alpha: 0.10 + maturity * 0.04);
    final Paint near = Paint()
      ..color = leafColor.withValues(alpha: 0.11 + maturity * 0.05);
    final Path farPath = Path()
      ..moveTo(0, size.height * 0.58)
      ..lineTo(size.width * 0.18, size.height * 0.34)
      ..lineTo(size.width * 0.34, size.height * 0.55)
      ..lineTo(size.width * 0.52, size.height * 0.29)
      ..lineTo(size.width * 0.72, size.height * 0.55)
      ..lineTo(size.width * 0.88, size.height * 0.39)
      ..lineTo(size.width, size.height * 0.57)
      ..lineTo(size.width, size.height * 0.72)
      ..lineTo(0, size.height * 0.72)
      ..close();
    canvas.drawPath(farPath, far);
    final Path nearPath = Path()
      ..moveTo(0, size.height * 0.68)
      ..quadraticBezierTo(
        size.width * 0.24,
        size.height * 0.48,
        size.width * 0.46,
        size.height * 0.67,
      )
      ..quadraticBezierTo(
        size.width * 0.72,
        size.height * 0.43,
        size.width,
        size.height * 0.66,
      )
      ..lineTo(size.width, size.height * 0.78)
      ..lineTo(0, size.height * 0.78)
      ..close();
    canvas.drawPath(nearPath, near);
  }

  void _drawBackgroundForest(Canvas canvas, Size size, double maturity) {
    final int treeCount = 8 + (maturity * 12).floor() + level ~/ 10;
    for (int index = 0; index < treeCount; index++) {
      final double normalized = treeCount <= 1 ? 0.5 : index / (treeCount - 1);
      final double depth = 0.45 + (index % 4) * 0.10;
      final double x = size.width * normalized;
      final double baseY = size.height * (0.72 + (index % 3) * 0.025);
      final double height = size.height * (0.13 + depth * 0.12);
      final double sway = breeze * (1.0 + index % 3) * 0.7;
      _drawPine(
        canvas,
        Offset(x + sway, baseY),
        height,
        leafColor.withValues(alpha: 0.12 + depth * 0.10),
        trunkColor.withValues(alpha: 0.18),
      );
    }
  }

  void _drawPine(
    Canvas canvas,
    Offset base,
    double height,
    Color crownColor,
    Color stemColor,
  ) {
    canvas.drawRect(
      Rect.fromLTWH(base.dx - 1.2, base.dy - height * 0.55, 2.4, height * 0.55),
      Paint()..color = stemColor,
    );
    final Paint crown = Paint()..color = crownColor;
    for (int tier = 0; tier < 3; tier++) {
      final double top = base.dy - height + tier * height * 0.22;
      final double half = height * (0.20 + tier * 0.055);
      final Path triangle = Path()
        ..moveTo(base.dx, top)
        ..lineTo(base.dx - half, top + height * 0.44)
        ..lineTo(base.dx + half, top + height * 0.44)
        ..close();
      canvas.drawPath(triangle, crown);
    }
  }

  void _drawGround(
    Canvas canvas,
    Size size,
    Offset center,
    double maturity,
  ) {
    final Paint meadow = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          groundColor.withValues(alpha: 0.52),
          leafColor.withValues(alpha: 0.20 + maturity * 0.08),
        ],
      ).createShader(
        Rect.fromLTWH(0, size.height * 0.67, size.width, size.height * 0.33),
      );
    final Path ground = Path()
      ..moveTo(0, size.height * 0.70)
      ..quadraticBezierTo(
        size.width * 0.25,
        size.height * 0.64,
        size.width * 0.50,
        size.height * 0.72,
      )
      ..quadraticBezierTo(
        size.width * 0.77,
        size.height * 0.63,
        size.width,
        size.height * 0.70,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(ground, meadow);

    final Paint shadow = Paint()
      ..color = Colors.black.withValues(alpha: 0.14)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(center.dx, center.dy + 5),
        width: size.width * 0.42,
        height: 15,
      ),
      shadow,
    );
  }

  void _drawMainTree(
    Canvas canvas,
    Size size,
    Offset center,
    double maturity,
  ) {
    final double sway = breeze * 0.012;
    final Paint glowPaint = Paint()
      ..color = glowColor.withValues(alpha: 0.10 + maturity * 0.09)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 24 + maturity * 14);
    canvas.drawCircle(
      Offset(center.dx, center.dy - size.height * 0.38),
      size.shortestSide * (0.17 + maturity * 0.12),
      glowPaint,
    );

    final double trunkHeight = size.height * (0.18 + maturity * 0.48);
    final double trunkWidth = 5 + maturity * 12;
    final Offset top = Offset(
      center.dx + sway * size.width,
      center.dy - trunkHeight,
    );
    final Path trunk = Path()
      ..moveTo(center.dx - trunkWidth / 2, center.dy)
      ..cubicTo(
        center.dx - trunkWidth * 0.65,
        center.dy - trunkHeight * 0.32,
        top.dx - trunkWidth * 0.34,
        center.dy - trunkHeight * 0.72,
        top.dx - trunkWidth * 0.12,
        top.dy,
      )
      ..lineTo(top.dx + trunkWidth * 0.12, top.dy)
      ..cubicTo(
        top.dx + trunkWidth * 0.38,
        center.dy - trunkHeight * 0.72,
        center.dx + trunkWidth * 0.68,
        center.dy - trunkHeight * 0.30,
        center.dx + trunkWidth / 2,
        center.dy,
      )
      ..close();
    final Paint trunkPaint = Paint()
      ..shader = LinearGradient(
        colors: <Color>[
          trunkColor.withValues(alpha: 0.72),
          trunkColor,
        ],
        begin: Alignment.bottomLeft,
        end: Alignment.topRight,
      ).createShader(
        Rect.fromLTWH(
          center.dx - trunkWidth,
          top.dy,
          trunkWidth * 2,
          trunkHeight,
        ),
      );
    canvas.drawPath(trunk, trunkPaint);

    final int branchCount = (2 + maturity * 9).floor();
    for (int index = 0; index < branchCount; index++) {
      final double normalized =
          branchCount == 1 ? 0.5 : index / (branchCount - 1);
      final double branchProgress =
          ((maturity - normalized * 0.10) / (1 - normalized * 0.10))
              .clamp(0.0, 1.0)
              .toDouble();
      if (branchProgress <= 0) continue;
      final bool left = index.isEven;
      final double y = center.dy - trunkHeight * (0.34 + normalized * 0.59);
      final double baseX = center.dx + sway * size.width * normalized;
      final double length =
          size.width * (0.08 + maturity * 0.13) * branchProgress;
      final Offset branchEnd = Offset(
        baseX + (left ? -length : length),
        y - length * (0.38 + normalized * 0.18),
      );
      final Paint branchPaint = Paint()
        ..color = trunkColor.withValues(alpha: 0.88)
        ..strokeWidth = math.max(1.5, trunkWidth * (0.42 - normalized * 0.20))
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;
      final Path branch = Path()
        ..moveTo(baseX, y)
        ..quadraticBezierTo(
          baseX + (left ? -length * 0.42 : length * 0.42),
          y - length * 0.08,
          branchEnd.dx,
          branchEnd.dy,
        );
      canvas.drawPath(branch, branchPaint);
      _drawLeafCluster(
        canvas,
        branchEnd,
        0.55 + normalized * 0.50,
        branchProgress,
        index,
      );
    }
    _drawLeafCluster(canvas, top, 1.08, maturity, 99);
  }

  void _drawLeafCluster(
    Canvas canvas,
    Offset center,
    double scale,
    double clusterProgress,
    int seed,
  ) {
    final int leaves = (3 + clusterProgress * (9 + level ~/ 7)).floor();
    for (int index = 0; index < leaves; index++) {
      final double angle = (index * 2.399963 + seed * 0.37) + breeze * 0.07;
      final double radius = (5 + math.sqrt(index + 1) * 7) * scale;
      final Offset point = Offset(
        center.dx + math.cos(angle) * radius,
        center.dy + math.sin(angle) * radius * 0.64,
      );
      final double leafSize = (3.8 + (index % 4) * 0.9) * scale;
      final Paint leafPaint = Paint()
        ..color = (index % 4 == 0 ? secondaryLeafColor : leafColor)
            .withValues(alpha: 0.62 + clusterProgress * 0.35)
        ..style = PaintingStyle.fill;
      canvas.save();
      canvas.translate(point.dx, point.dy);
      canvas.rotate(angle * 0.35);
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset.zero,
          width: leafSize * 1.55,
          height: leafSize,
        ),
        leafPaint,
      );
      canvas.restore();
    }
    if (clusterProgress < 0.16) {
      canvas.drawCircle(center, 4.5 * scale, Paint()..color = leafColor);
    }
  }

  void _drawGroundDetails(
    Canvas canvas,
    Size size,
    Offset center,
    double maturity,
  ) {
    final int flowerCount = (maturity * 10).floor() + level ~/ 15;
    for (int index = 0; index < flowerCount; index++) {
      final double x = size.width * (0.08 + ((index * 37) % 84) / 100);
      final double y = size.height * (0.80 + (index % 3) * 0.035);
      final Color color = index.isEven ? secondaryLeafColor : glowColor;
      canvas.drawLine(
        Offset(x, y + 7),
        Offset(x, y),
        Paint()
          ..color = leafColor.withValues(alpha: 0.50)
          ..strokeWidth = 1.1,
      );
      canvas.drawCircle(
        Offset(x, y),
        1.8 + (index % 2),
        Paint()..color = color.withValues(alpha: 0.58),
      );
    }

    if (maturity > 0.55) {
      final Rect pond = Rect.fromCenter(
        center: Offset(size.width * 0.18, size.height * 0.90),
        width: size.width * 0.22,
        height: 13,
      );
      canvas.drawOval(
        pond,
        Paint()..color = skyColor.withValues(alpha: 0.30),
      );
      canvas.drawArc(
        pond.deflate(2),
        0,
        math.pi,
        false,
        Paint()
          ..color = surfaceColor.withValues(alpha: 0.55)
          ..strokeWidth = 1
          ..style = PaintingStyle.stroke,
      );
    }

    if (level >= 12) {
      final Paint pathPaint = Paint()
        ..color = surfaceColor.withValues(alpha: 0.36)
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;
      final Path path = Path()
        ..moveTo(center.dx, center.dy + 8)
        ..quadraticBezierTo(
          center.dx + size.width * 0.12,
          size.height * 0.94,
          center.dx + size.width * 0.24,
          size.height,
        );
      canvas.drawPath(path, pathPaint);
    }
  }

  void _drawBirds(Canvas canvas, Size size, double maturity) {
    if (maturity < 0.35) return;
    final Paint paint = Paint()
      ..color = trunkColor.withValues(alpha: 0.38)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final int count = 1 + level ~/ 25;
    for (int index = 0; index < count; index++) {
      final Offset origin = Offset(
        size.width * (0.16 + index * 0.12) + breeze * 3,
        size.height * (0.22 + index * 0.04),
      );
      final Path bird = Path()
        ..moveTo(origin.dx - 6, origin.dy)
        ..quadraticBezierTo(origin.dx - 3, origin.dy - 4, origin.dx, origin.dy)
        ..quadraticBezierTo(
            origin.dx + 3, origin.dy - 4, origin.dx + 6, origin.dy);
      canvas.drawPath(bird, paint);
    }
  }

  void _drawFireflies(Canvas canvas, Size size, double maturity) {
    if (maturity < 0.42) return;
    final int count = (maturity * 9).floor() + level ~/ 18;
    for (int index = 0; index < count; index++) {
      final double phase = index * 1.73 + breeze;
      final Offset point = Offset(
        size.width * (0.12 + ((index * 29) % 76) / 100),
        size.height * (0.38 + ((index * 17) % 42) / 100) + math.sin(phase) * 3,
      );
      final Paint glow = Paint()
        ..color = glowColor.withValues(alpha: 0.22 + (index % 3) * 0.07)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      canvas.drawCircle(point, 2.2, glow);
      canvas.drawCircle(
        point,
        0.8,
        Paint()..color = glowColor.withValues(alpha: 0.75),
      );
    }
  }

  @override
  bool shouldRepaint(_FocusForestPainter oldDelegate) =>
      progress != oldDelegate.progress ||
      level != oldDelegate.level ||
      breeze != oldDelegate.breeze ||
      trunkColor != oldDelegate.trunkColor ||
      leafColor != oldDelegate.leafColor ||
      secondaryLeafColor != oldDelegate.secondaryLeafColor ||
      groundColor != oldDelegate.groundColor ||
      glowColor != oldDelegate.glowColor ||
      surfaceColor != oldDelegate.surfaceColor ||
      skyColor != oldDelegate.skyColor ||
      showGround != oldDelegate.showGround;
}
