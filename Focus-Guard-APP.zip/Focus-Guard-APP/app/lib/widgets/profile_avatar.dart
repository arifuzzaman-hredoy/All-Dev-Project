import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';

class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({
    required this.name,
    required this.imageBase64,
    this.radius = 24,
    this.onTap,
    this.showCameraBadge = false,
    super.key,
  });

  final String name;
  final String imageBase64;
  final double radius;
  final VoidCallback? onTap;
  final bool showCameraBadge;

  Uint8List? _decodeImage() {
    final String value = imageBase64.trim();
    if (value.isEmpty) return null;
    try {
      final Uint8List bytes = base64Decode(value);
      return bytes.isEmpty ? null : bytes;
    } on FormatException {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final Uint8List? bytes = _decodeImage();
    final ColorScheme colors = Theme.of(context).colorScheme;
    final String safeName = name.trim();
    final String initial = safeName.isEmpty ? 'H' : safeName[0].toUpperCase();

    final Widget avatar = CircleAvatar(
      radius: radius,
      backgroundColor: colors.primaryContainer,
      foregroundColor: colors.onPrimaryContainer,
      backgroundImage: bytes == null ? null : MemoryImage(bytes),
      child: bytes == null
          ? Text(
              initial,
              style: TextStyle(
                fontSize: radius * .72,
                fontWeight: FontWeight.w900,
              ),
            )
          : null,
    );

    final Widget content = showCameraBadge
        ? Stack(
            clipBehavior: Clip.none,
            children: <Widget>[
              avatar,
              Positioned(
                right: -2,
                bottom: -2,
                child: Container(
                  width: radius * .72,
                  height: radius * .72,
                  decoration: BoxDecoration(
                    color: colors.primary,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: colors.surface,
                      width: 2,
                    ),
                  ),
                  child: Icon(
                    Icons.camera_alt_rounded,
                    size: radius * .38,
                    color: colors.onPrimary,
                  ),
                ),
              ),
            ],
          )
        : avatar;

    if (onTap == null) return content;
    return Semantics(
      button: true,
      label: 'Change profile picture',
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: content,
      ),
    );
  }
}
