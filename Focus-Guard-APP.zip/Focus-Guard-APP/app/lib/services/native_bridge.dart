import 'package:flutter/services.dart';

import '../models/alarm_sounds.dart';
import '../models/app_models.dart';
import '../models/phone_control.dart';
import '../models/protection_policy.dart';

class NativeSettings {
  const NativeSettings({
    required this.blockedPackages,
    required this.useDnd,
    required this.autoFocus,
    required this.focusUntilMillis,
  });

  final Set<String> blockedPackages;
  final bool useDnd;
  final bool autoFocus;
  final int focusUntilMillis;
}

class NativeSystemReadiness {
  const NativeSystemReadiness({
    required this.notificationsEnabled,
    required this.exactAlarmsEnabled,
    required this.fullScreenIntentEnabled,
    required this.accessibilityEnabled,
    required this.batteryOptimizationIgnored,
    required this.usageAccessEnabled,
    required this.notificationAccessEnabled,
  });

  final bool notificationsEnabled;
  final bool exactAlarmsEnabled;
  final bool fullScreenIntentEnabled;
  final bool accessibilityEnabled;
  final bool batteryOptimizationIgnored;
  final bool usageAccessEnabled;
  final bool notificationAccessEnabled;

  bool get alarmReady =>
      notificationsEnabled &&
      exactAlarmsEnabled &&
      fullScreenIntentEnabled &&
      batteryOptimizationIgnored;

  bool get focusReady => accessibilityEnabled;
}

class LaunchableAppInfo {
  const LaunchableAppInfo({
    required this.packageName,
    required this.label,
    this.category = 'other',
    this.recommendation = 'allow',
    this.protected = false,
    this.reason = 'Allowed until you choose to block it',
    this.suggestedDailyMinutes = 0,
    this.suggestedReelsGuard = false,
  });

  final String packageName;
  final String label;
  final String category;
  final String recommendation;
  final bool protected;
  final String reason;
  final int suggestedDailyMinutes;
  final bool suggestedReelsGuard;

  bool get suggestedForReview => recommendation == 'review' && !protected;
}

extension LaunchableAppCategory on LaunchableAppInfo {
  bool get isDistracting => suggestedForReview;

  bool get isUseful => const <String>{
        'productive',
        'communication',
        'navigation',
      }.contains(category);

  String get categoryLabel => switch (category) {
        'social' => 'Social media',
        'video' => 'Video / streaming',
        'game' => 'Games',
        'shopping' => 'Shopping',
        'education' => 'Education',
        'productive' => 'Productivity',
        'communication' => 'Communication',
        'navigation' => 'Navigation',
        'system' => 'System / safe',
        'essential' => 'Essential / protected',
        _ => 'Normal / safe',
      };

  bool matchesCategoryFilter(String filter) => switch (filter) {
        'all' => true,
        'distracting' => isDistracting,
        'useful' => isUseful,
        'normal' => !isDistracting && category != 'education' && !isUseful,
        _ => category == filter,
      };
}

class NativeBridge {
  NativeBridge._();

  static const MethodChannel _channel = MethodChannel(
    'com.hredoy.focus_guard/native',
  );

  static Future<void> initialize(
    List<TaskItem> tasks,
    String Function(String subjectId) subjectName, {
    bool forceReschedule = false,
  }) async {
    await _channel.invokeMethod<void>('initialize', <String, Object>{
      'forceReschedule': forceReschedule,
      'tasks': tasks
          .map((TaskItem task) => task.toNativeMap(subjectName(task.subjectId)))
          .toList(growable: false),
    });
  }

  static Future<Uint8List?> pickProfileImage() =>
      _channel.invokeMethod<Uint8List>('pickProfileImage');

  static Future<Uint8List?> captureProfileImage() =>
      _channel.invokeMethod<Uint8List>('captureProfileImage');

  static Future<String> appDataPath() async {
    final String? path = await _channel.invokeMethod<String>('getAppDataPath');
    if (path == null || path.trim().isEmpty) {
      throw StateError('App data path is unavailable.');
    }
    return path;
  }

  static Future<void> shareText(String subject, String text) =>
      _channel.invokeMethod<void>('shareText', <String, String>{
        'subject': subject,
        'text': text,
      });

  static Future<Set<String>> completedTaskIds() async {
    final List<dynamic>? values = await _channel.invokeMethod<List<dynamic>>(
      'getCompletedTasks',
    );
    return values?.map((dynamic value) => value.toString()).toSet() ??
        <String>{};
  }

  static Future<void> setTaskCompleted(String id, bool completed) =>
      _channel.invokeMethod<void>('setTaskCompleted', <String, Object>{
        'id': id,
        'completed': completed,
      });

  static Future<NativeSettings> settings() async {
    final Map<dynamic, dynamic>? data =
        await _channel.invokeMethod<Map<dynamic, dynamic>>('getSettings');
    return NativeSettings(
      blockedPackages:
          (data?['blockedPackages'] as List<dynamic>? ?? <dynamic>[])
              .map((dynamic value) => value.toString())
              .toSet(),
      useDnd: data?['useDnd'] as bool? ?? true,
      autoFocus: data?['autoFocus'] as bool? ?? false,
      focusUntilMillis: (data?['focusUntilMillis'] as num?)?.toInt() ?? 0,
    );
  }

  static Future<void> saveSettings({
    required Set<String> blockedPackages,
    required bool useDnd,
    required bool autoFocus,
  }) =>
      _channel.invokeMethod<void>('saveSettings', <String, Object>{
        'blockedPackages': blockedPackages.toList(growable: false),
        'useDnd': useDnd,
        'autoFocus': autoFocus,
      });

  static Future<AlarmSoundSelection?> pickSystemAlarmSound({
    String currentUri = '',
  }) async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'pickSystemAlarmSound',
      <String, String>{'currentUri': currentUri},
    );
    return raw == null ? null : AlarmSoundSelection.fromMap(raw);
  }

  static Future<AlarmSoundSelection?> pickCustomAlarmSound() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'pickCustomAlarmSound',
    );
    return raw == null ? null : AlarmSoundSelection.fromMap(raw);
  }

  static Future<void> previewAlarmSound({
    required AlarmSoundSelection selection,
    required String category,
    required String taskTitle,
  }) =>
      _channel.invokeMethod<void>('previewAlarmSound', <String, Object>{
        'soundId': selection.id,
        'soundLabel': selection.label,
        'soundUri': selection.uri,
        'category': category,
        'taskTitle': taskTitle,
      });

  static Future<void> stopAlarmSoundPreview() =>
      _channel.invokeMethod<void>('stopAlarmSoundPreview');

  static Future<void> requestNotificationPermission() =>
      _channel.invokeMethod<void>('requestNotificationPermission');

  static Future<void> openExactAlarmSettings() =>
      _channel.invokeMethod<void>('openExactAlarmSettings');

  static Future<void> openFullScreenAlarmSettings() =>
      _channel.invokeMethod<void>('openFullScreenAlarmSettings');

  static Future<void> openAccessibilitySettings() =>
      _channel.invokeMethod<void>('openAccessibilitySettings');

  static Future<void> openDndSettings() =>
      _channel.invokeMethod<void>('openDndSettings');

  static Future<void> openBatterySettings() =>
      _channel.invokeMethod<void>('openBatterySettings');

  static Future<void> openNotificationSettings() =>
      _channel.invokeMethod<void>('openNotificationSettings');

  static Future<void> openNotificationAccessSettings() =>
      _channel.invokeMethod<void>('openNotificationAccessSettings');

  static Future<void> openUsageAccessSettings() =>
      _channel.invokeMethod<void>('openUsageAccessSettings');

  static Future<ProtectionPolicy> protectionPolicy() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getProtectionPolicy',
    );
    return ProtectionPolicy.fromMap(raw);
  }

  static Future<void> saveProtectionPolicy(ProtectionPolicy policy) =>
      _channel.invokeMethod<void>('saveProtectionPolicy', policy.toMap());

  static Future<ProtectionSnapshot> protectionSnapshot() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getProtectionSnapshot',
    );
    return ProtectionSnapshot.fromMap(raw);
  }

  static Future<bool> requestProtectionVpnPermission() async =>
      await _channel.invokeMethod<bool>('requestProtectionVpnPermission') ??
      false;

  static Future<void> startProtectionVpn() =>
      _channel.invokeMethod<void>('startProtectionVpn');

  static Future<void> stopProtectionVpn() =>
      _channel.invokeMethod<void>('stopProtectionVpn');

  static Future<ProtectionActionResult> activatePrimeMode({
    required int minutes,
    required Set<String> blockedPackages,
    required Set<String> allowedPackages,
    required bool silenceNotifications,
  }) async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'activatePrimeMode',
      <String, Object>{
        'minutes': minutes,
        'blockedPackages': blockedPackages.toList(growable: false),
        'allowedPackages': allowedPackages.toList(growable: false),
        'silenceNotifications': silenceNotifications,
      },
    );
    return ProtectionActionResult.fromMap(raw);
  }

  static Future<ProtectionActionResult> activateKeepMeOut({
    required int minutes,
    required Set<String> packages,
  }) async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'activateKeepMeOut',
      <String, Object>{
        'minutes': minutes,
        'packages': packages.toList(growable: false),
      },
    );
    return ProtectionActionResult.fromMap(raw);
  }

  static Future<ProtectionActionResult> requestHardcoreEmergencyUnlock({
    required int minutes,
  }) async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'requestHardcoreEmergencyUnlock',
      <String, Object>{'minutes': minutes},
    );
    return ProtectionActionResult.fromMap(raw);
  }

  static Future<void> cancelHardcoreEmergencyUnlock() =>
      _channel.invokeMethod<void>('cancelHardcoreEmergencyUnlock');

  static Future<void> clearProtectionHistory() =>
      _channel.invokeMethod<void>('clearProtectionHistory');

  static Future<Map<String, bool>> runProtectionDiagnostics() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'runProtectionDiagnostics',
    );
    final Map<dynamic, dynamic>? checks =
        raw?['checks'] as Map<dynamic, dynamic>?;
    return <String, bool>{
      for (final MapEntry<dynamic, dynamic> entry
          in (checks ?? const <dynamic, dynamic>{}).entries)
        entry.key.toString(): entry.value as bool? ?? false,
    };
  }

  static Future<void> openVpnSettings() =>
      _channel.invokeMethod<void>('openVpnSettings');

  static Future<PhoneControlPolicy> phoneControlPolicy() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getPhoneControlPolicy',
    );
    return PhoneControlPolicy.fromMap(raw);
  }

  static Future<void> savePhoneControlPolicy(PhoneControlPolicy policy) =>
      _channel.invokeMethod<void>(
        'savePhoneControlPolicy',
        policy.toMap(),
      );

  static Future<PhoneControlPolicy> runPhoneControlSafeSetup() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'runPhoneControlSafeSetup',
    );
    return PhoneControlPolicy.fromMap(raw);
  }

  static Future<PhoneControlPolicy> emergencyStopAllBlocking() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'emergencyStopAllBlocking',
    );
    return PhoneControlPolicy.fromMap(raw);
  }

  static Future<List<ScheduleProfileRuntime>> scheduleProfileRuntime() async {
    final List<dynamic>? raw =
        await _channel.invokeMethod<List<dynamic>>('getScheduleProfileRuntime');
    return (raw ?? const <dynamic>[])
        .whereType<Map<dynamic, dynamic>>()
        .map(ScheduleProfileRuntime.fromMap)
        .where((ScheduleProfileRuntime value) => value.profileId.isNotEmpty)
        .toList(growable: false);
  }

  static Future<ScheduleProfileRuntime> requestScheduleProfileUnlock({
    required String profileId,
    required int minutes,
  }) async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'requestScheduleProfileUnlock',
      <String, Object>{
        'profileId': profileId,
        'minutes': minutes,
      },
    );
    return ScheduleProfileRuntime.fromMap(
      raw ?? <dynamic, dynamic>{'profileId': profileId, 'granted': false},
    );
  }

  static Future<void> cancelScheduleProfileUnlock(String profileId) =>
      _channel.invokeMethod<void>(
        'cancelScheduleProfileUnlock',
        <String, String>{'profileId': profileId},
      );

  static Future<PhoneControlUsage> phoneControlUsage() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getPhoneControlUsage',
    );
    return PhoneControlUsage.fromMap(raw);
  }

  static Future<PhoneControlDashboardSnapshot> phoneControlDashboard() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getPhoneControlDashboard',
    );
    return PhoneControlDashboardSnapshot.fromMap(raw);
  }

  static Future<void> resetPhoneControlUsage() =>
      _channel.invokeMethod<void>('resetPhoneControlUsage');

  static Future<SocialControlSnapshot> socialControlSnapshot() async {
    final Map<dynamic, dynamic>? raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>(
      'getSocialControlSnapshot',
    );
    return SocialControlSnapshot.fromMap(raw);
  }

  static Future<void> clearNotificationHistory() =>
      _channel.invokeMethod<void>('clearNotificationHistory');

  static Future<void> testTaskAlarm({
    AlarmSoundSelection selection = AlarmSoundCatalog.smart,
  }) =>
      _channel.invokeMethod<void>('testTaskAlarm', <String, Object>{
        'soundId': selection.id,
        'soundLabel': selection.label,
        'soundUri': selection.uri,
      });

  static Future<NativeSystemReadiness> systemReadiness() async {
    final Map<dynamic, dynamic>? data = await _channel
        .invokeMethod<Map<dynamic, dynamic>>('getSystemReadiness');
    return NativeSystemReadiness(
      notificationsEnabled: data?['notificationsEnabled'] as bool? ?? false,
      exactAlarmsEnabled: data?['exactAlarmsEnabled'] as bool? ?? false,
      fullScreenIntentEnabled:
          data?['fullScreenIntentEnabled'] as bool? ?? false,
      accessibilityEnabled: data?['accessibilityEnabled'] as bool? ?? false,
      batteryOptimizationIgnored:
          data?['batteryOptimizationIgnored'] as bool? ?? false,
      usageAccessEnabled: data?['usageAccessEnabled'] as bool? ?? false,
      notificationAccessEnabled:
          data?['notificationAccessEnabled'] as bool? ?? false,
    );
  }

  static Future<List<LaunchableAppInfo>> launchableApps() async {
    final List<dynamic>? raw =
        await _channel.invokeMethod<List<dynamic>>('listLaunchableApps');
    final List<LaunchableAppInfo> result = <LaunchableAppInfo>[];
    for (final dynamic item in raw ?? const <dynamic>[]) {
      if (item is! Map<dynamic, dynamic>) continue;
      final String packageName = item['packageName']?.toString() ?? '';
      final String label = item['label']?.toString() ?? packageName;
      if (packageName.isEmpty) continue;
      result.add(
        LaunchableAppInfo(
          packageName: packageName,
          label: label,
          category: item['category']?.toString() ?? 'other',
          recommendation: item['recommendation']?.toString() ?? 'allow',
          protected: item['protected'] as bool? ?? false,
          reason: item['reason']?.toString() ??
              'Allowed until you choose to block it',
          suggestedDailyMinutes:
              (item['suggestedDailyMinutes'] as num?)?.toInt() ?? 0,
          suggestedReelsGuard: item['suggestedReelsGuard'] as bool? ?? false,
        ),
      );
    }
    return result;
  }

  static Future<void> setKeepScreenOn(bool enabled) =>
      _channel.invokeMethod<void>('setKeepScreenOn', <String, bool>{
        'enabled': enabled,
      });

  static Future<void> requestBatteryOptimizationExemption() =>
      _channel.invokeMethod<void>('requestBatteryOptimizationExemption');

  static Future<int> startFocus(int minutes, String label) async {
    final int? until = await _channel.invokeMethod<int>(
      'startFocus',
      <String, Object>{'minutes': minutes, 'label': label},
    );
    return until ??
        DateTime.now().add(Duration(minutes: minutes)).millisecondsSinceEpoch;
  }

  static Future<void> endFocus() => _channel.invokeMethod<void>('endFocus');
}
