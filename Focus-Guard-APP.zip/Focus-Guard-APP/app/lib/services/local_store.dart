import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import '../models/app_models.dart';

class LocalStore {
  LocalStore(this.directoryPath);

  final String directoryPath;
  DateTime? _lastBackupAt;

  File get _dataFile => File('$directoryPath/hredoy_flow_data_v3.json');
  File get _backupFile =>
      File('$directoryPath/hredoy_flow_data_v3.backup.json');
  File get _legacyFile => File('$directoryPath/focus_guard_data_v2.json');
  File get _tempFile => File('$directoryPath/hredoy_flow_data_v3.tmp');

  Future<AppData?> load() async {
    await Directory(directoryPath).create(recursive: true);
    final List<File> candidates = <File>[
      _dataFile,
      _tempFile,
      _backupFile,
      _legacyFile,
    ];
    for (final File candidate in candidates) {
      if (!await candidate.exists()) continue;
      try {
        final String raw = await candidate.readAsString();
        return await _decodeAppData(raw);
      } catch (_) {
        // Try the next recovery candidate.
      }
    }
    return null;
  }

  Future<void> save(AppData data) async {
    final Directory directory = Directory(directoryPath);
    await directory.create(recursive: true);

    final String raw = await _encodeStorageData(data);
    await _tempFile.writeAsString(raw, flush: false);

    if (await _dataFile.exists()) {
      final DateTime now = DateTime.now();
      final DateTime? lastBackup = _lastBackupAt ?? await _backupModifiedAt();
      final bool rotateBackup = lastBackup == null ||
          now.difference(lastBackup) >= const Duration(seconds: 30);
      if (rotateBackup) {
        await _dataFile.copy(_backupFile.path);
        _lastBackupAt = now;
      }
      await _dataFile.delete();
    }
    await _tempFile.rename(_dataFile.path);
  }

  Future<DateTime?> _backupModifiedAt() async {
    if (!await _backupFile.exists()) return null;
    try {
      return (await _backupFile.stat()).modified;
    } catch (_) {
      return null;
    }
  }

  String encode(AppData data) =>
      const JsonEncoder.withIndent('  ').convert(data.toJson());

  Future<String> encodeAsync(AppData data) {
    final int itemCount = _itemCount(data);
    if (itemCount < 250) {
      return Future<String>.sync(() => encode(data));
    }
    return Isolate.run<String>(
      () => const JsonEncoder.withIndent('  ').convert(data.toJson()),
    );
  }

  AppData decode(String raw) {
    final Object? decoded = jsonDecode(raw);
    if (decoded is! Map<Object?, Object?>) {
      throw const FormatException('Backup JSON is invalid.');
    }
    return AppData.fromJson(decoded.cast<String, Object?>());
  }

  Future<AppData> decodeAsync(String raw) => _decodeAppData(raw);

  Future<AppData> _decodeAppData(String raw) {
    if (raw.length < 256 * 1024) {
      return Future<AppData>.sync(() => _decodeAppDataSync(raw));
    }
    // Build the model on the worker isolate as well. Returning a ready AppData
    // avoids copying a very large decoded Map back to the UI isolate and then
    // walking it again during startup or restore.
    return Isolate.run<AppData>(() => _decodeAppDataSync(raw));
  }

  static AppData _decodeAppDataSync(String raw) {
    final Object? decoded = jsonDecode(raw);
    if (decoded is! Map<Object?, Object?>) {
      throw const FormatException('Backup JSON is invalid.');
    }
    return AppData.fromJson(decoded.cast<String, Object?>());
  }

  Future<String> _encodeStorageData(AppData data) {
    if (_itemCount(data) < 250) {
      return Future<String>.sync(() => jsonEncode(data.toJson()));
    }
    // Both model-to-Map conversion and JSON encoding run away from the UI
    // isolate for large datasets.
    return Isolate.run<String>(() => jsonEncode(data.toJson()));
  }

  int _itemCount(AppData data) =>
      data.tasks.length + data.sessions.length + data.notes.length;
}
