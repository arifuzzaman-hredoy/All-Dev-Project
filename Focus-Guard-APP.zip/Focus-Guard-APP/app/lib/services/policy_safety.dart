import '../models/phone_control.dart';
import '../models/protection_policy.dart';

/// Removes user-designated always-allowed packages from every Phone Control
/// surface that could restrict them. This is intentionally pure so all editors
/// share the same safety behavior and it can be regression-tested.
PhoneControlPolicy sanitizePhoneControlForAlwaysAllowed(
  PhoneControlPolicy policy,
  Set<String> alwaysAllowedPackages,
) {
  if (alwaysAllowedPackages.isEmpty) return policy;
  final Set<String> safeReelsPackages =
      policy.globalReelsWindowPackages.difference(alwaysAllowedPackages);
  final bool canKeepGlobalReelsWindow =
      policy.globalReelsWindowPackages.isNotEmpty &&
      safeReelsPackages.isNotEmpty;
  return policy.copyWith(
    rules: policy.rules
        .where(
          (AppControlRule rule) =>
              !alwaysAllowedPackages.contains(rule.packageName),
        )
        .toList(growable: false),
    profiles: policy.profiles
        .map(
          (ScheduleProfile profile) => profile.copyWith(
            blockedPackages:
                profile.blockedPackages.difference(alwaysAllowedPackages),
          ),
        )
        .toList(growable: false),
    studyAllowedPackages: <String>{
      ...policy.studyAllowedPackages,
      ...alwaysAllowedPackages,
    },
    studyBlockedPackages:
        policy.studyBlockedPackages.difference(alwaysAllowedPackages),
    notificationPackages:
        policy.notificationPackages.difference(alwaysAllowedPackages),
    // An empty package set means "all supported apps". Disabling the
    // window is safer than accidentally broadening a selected-app budget when
    // the final selected package becomes always allowed.
    globalReelsWindowEnabled:
        policy.globalReelsWindowEnabled && canKeepGlobalReelsWindow,
    globalReelsWindowPackages: safeReelsPackages,
  );
}

/// Applies the same invariant to Prime Mode and Keep Me Out.
ProtectionPolicy sanitizeProtectionForAlwaysAllowed(
  ProtectionPolicy policy,
  Set<String> alwaysAllowedPackages,
) {
  if (alwaysAllowedPackages.isEmpty) return policy;
  return policy.copyWith(
    primeBlockedPackages:
        policy.primeBlockedPackages.difference(alwaysAllowedPackages),
    primeAllowedPackages: <String>{
      ...policy.primeAllowedPackages,
      ...alwaysAllowedPackages,
    },
    keepMeOutPackages:
        policy.keepMeOutPackages.difference(alwaysAllowedPackages),
  );
}
