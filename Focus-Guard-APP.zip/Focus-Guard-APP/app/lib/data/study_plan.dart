import 'package:flutter/material.dart';

import '../models/app_models.dart';

class StudyPlan {
  StudyPlan._();

  static const int currentDataVersion = 7;

  static const String math = 'math';
  static const String electronics = 'electronics';
  static const String chemistry = 'chemistry';
  static const String python = 'python';
  static const String bangla = 'bangla';
  static const String english = 'english';
  static const String work = 'work';
  static const String health = 'health';
  static const String revision = 'revision';
  static const String general = 'general';

  /// Clean routine restart: Sunday, 26 July 2026 at 6:30 AM.
  static final DateTime routineAnchor = DateTime(2026, 7, 26, 6, 30);

  static const String routineIdPrefix = 'routine-20260726-r4-';

  static List<SubjectItem> get subjects => <SubjectItem>[
        SubjectItem(
          id: math,
          name: 'Mathematics-2',
          colorValue: const Color(0xFF4F7CFF).toARGB32(),
          iconCodePoint: Icons.calculate_rounded.codePoint,
        ),
        SubjectItem(
          id: electronics,
          name: 'Basic Electronics',
          colorValue: const Color(0xFFFFA62B).toARGB32(),
          iconCodePoint: Icons.memory_rounded.codePoint,
        ),
        SubjectItem(
          id: chemistry,
          name: 'Chemistry',
          colorValue: const Color(0xFFB15CFF).toARGB32(),
          iconCodePoint: Icons.science_rounded.codePoint,
        ),
        SubjectItem(
          id: python,
          name: 'Python',
          colorValue: const Color(0xFF18B6A4).toARGB32(),
          iconCodePoint: Icons.code_rounded.codePoint,
        ),
        SubjectItem(
          id: bangla,
          name: 'Bangla',
          colorValue: const Color(0xFFE35768).toARGB32(),
          iconCodePoint: Icons.translate_rounded.codePoint,
        ),
        SubjectItem(
          id: english,
          name: 'English',
          colorValue: const Color(0xFF28A6E8).toARGB32(),
          iconCodePoint: Icons.language_rounded.codePoint,
        ),
        SubjectItem(
          id: work,
          name: 'Physical Office',
          colorValue: const Color(0xFF7D8A98).toARGB32(),
          iconCodePoint: Icons.work_rounded.codePoint,
        ),
        SubjectItem(
          id: health,
          name: 'Health, Break & Transition',
          colorValue: const Color(0xFF55B84D).toARGB32(),
          iconCodePoint: Icons.health_and_safety_rounded.codePoint,
        ),
        SubjectItem(
          id: revision,
          name: 'Revision & Test',
          colorValue: const Color(0xFFFFD24A).toARGB32(),
          iconCodePoint: Icons.fact_check_rounded.codePoint,
        ),
        SubjectItem(
          id: general,
          name: 'General',
          colorValue: const Color(0xFF8892A6).toARGB32(),
          iconCodePoint: Icons.category_rounded.codePoint,
        ),
      ];

  static bool isManagedRoutineId(String id) {
    if (id.startsWith('routine-')) return true;
    return RegExp(r'^2026-(07|08)-\d{2}-\d{4}$').hasMatch(id);
  }

  static List<TaskItem> buildRoutine([DateTime? anchor]) {
    final DateTime requested = anchor ?? routineAnchor;
    final DateTime start = DateTime(
      requested.year,
      requested.month,
      requested.day,
      requested.hour,
      requested.minute,
    );
    final DateTime endDate = DateTime(2026, 8, 6);
    final DateTime firstDay = DateTime(start.year, start.month, start.day);
    final DateTime now = DateTime.now();
    final List<TaskItem> tasks = <TaskItem>[];

    void add(
      DateTime startAt,
      int durationMinutes,
      String title,
      String subjectId, {
      String notes = '',
      bool autoFocus = false,
      int priority = 2,
      String soundId = 'smart',
      String soundLabel = 'Smart by task type',
    }) {
      if (startAt.isBefore(start)) return;
      final String compactDate = dateKey(startAt).replaceAll('-', '');
      final String compactTime =
          '${startAt.hour.toString().padLeft(2, '0')}${startAt.minute.toString().padLeft(2, '0')}';
      tasks.add(
        TaskItem(
          id: '$routineIdPrefix$compactDate-$compactTime',
          title: title,
          subjectId: subjectId,
          startAt: startAt,
          durationMinutes: durationMinutes,
          priority: priority,
          notes: notes.isNotEmpty
              ? notes
              : subjectId == health
                  ? 'This is planned recovery or transition time. Finish it on time so the next block starts without delay.'
                  : subjectId == work
                      ? 'Physical office block: work only on the planned priority list and record unfinished items before leaving.'
                      : 'Study actively, write key points, mark mistakes and finish with a two-minute closed-book recall.',
          reminderEnabled: true,
          alarmEnabled: true,
          snoozeMinutes: 5,
          alarmSoundId: soundId,
          alarmSoundLabel: soundLabel,
          autoFocus: autoFocus,
          createdAt: now,
          updatedAt: now,
        ),
      );
    }

    void at(
      DateTime day,
      int hour,
      int minute,
      int duration,
      String title,
      String subject, {
      String? notes,
      bool? autoFocus,
      int? priority,
      String? soundId,
      String? soundLabel,
    }) {
      add(
        DateTime(day.year, day.month, day.day, hour, minute),
        duration,
        title,
        subject,
        notes: notes ?? '',
        autoFocus: autoFocus ?? false,
        priority: priority ?? 2,
        soundId: soundId ?? 'smart',
        soundLabel: soundLabel ?? 'Smart by task type',
      );
    }

    // Fresh restart from Sunday, 26 July at 6:30 AM.
    // All older generated routine blocks are replaced during the version-7 migration.
    final List<String> mathBlocks = <String>[
      'Mathematics-2 Chapter 2 — examples and formulas',
      'Mathematics-2 Chapters 3–4 — core problems',
      'Mathematics-2 Chapter 5 — worked examples',
      'Mathematics-2 Chapter 6 — problem drill',
      'Mathematics-2 Chapter 7 — formula and mistakes',
      'Mathematics-2 Chapter 8 — problem drill',
      'Mathematics-2 Chapter 9 — hard questions',
      'Mathematics-2 Chapter 10 — chapter test',
      'Mathematics-2 Chapters 11–12 — final pass',
      'Mathematics-2 Chapter 13 — weak problems',
      'Mathematics full formula and mistake test',
      'Mathematics model test and correction',
      'Mathematics final recall',
    ];
    final List<String> electronicsBlocks = <String>[
      'Basic Electronics Chapter 2 — concepts and circuits',
      'Basic Electronics Chapters 3–4 — diagrams',
      'Basic Electronics Chapter 5 — numericals',
      'Basic Electronics Chapter 6 — circuit practice',
      'Basic Electronics Chapter 7 — formulas',
      'Basic Electronics Chapter 8 — concepts',
      'Basic Electronics Chapter 9 — numericals',
      'Basic Electronics Chapter 10 — first pass finish',
      'Electronics diagram and formula revision',
      'Electronics weak-topic repair',
      'Electronics full model test',
      'Electronics correction and recall',
      'Electronics final recall',
    ];
    final List<String> chemistryBlocks = <String>[
      'Chemistry Chapter 2 — definitions and reactions',
      'Chemistry Chapters 3–4 — reactions',
      'Chemistry Chapter 5 — theory and numericals',
      'Chemistry Chapter 6 — reactions',
      'Chemistry Chapter 7 — numerical drill',
      'Chemistry Chapter 8 — definitions',
      'Chemistry Chapter 9 — reactions',
      'Chemistry Chapter 10 — chapter test',
      'Chemistry Chapters 11–12 — final pass',
      'Chemistry Chapters 13–14 — final pass',
      'Chemistry full reaction and numerical test',
      'Chemistry correction and recall',
      'Chemistry final recall',
    ];
    final List<(String, String)> flexibleBlocks = <(String, String)>[
      ('Python Chapters 5–8 — code by hand', python),
      ('Python Chapters 9–12 — exercises', python),
      ('Bangla Chapters 2–3 and writing', bangla),
      ('English Chapters 2–3 and grammar', english),
      ('Bangla Chapters 4–5 and recall', bangla),
      ('English Chapters 4–5 and writing', english),
      ('Python full revision and practice', python),
      ('Bangla Chapters 6–8', bangla),
      ('English Chapters 6–7', english),
      ('Bangla Chapter 9–10 and final revision', bangla),
      ('Python, Bangla and English mixed test', revision),
      ('Backlog repair and flashcards', revision),
      ('Final short notes only', revision),
    ];

    DateTime day = firstDay;
    int dayIndex = 0;
    while (!day.isAfter(endDate)) {
      final String mathTitle = mathBlocks[dayIndex % mathBlocks.length];
      final String electronicsTitle =
          electronicsBlocks[dayIndex % electronicsBlocks.length];
      final String chemistryTitle =
          chemistryBlocks[dayIndex % chemistryBlocks.length];
      final (String, String) flexible =
          flexibleBlocks[dayIndex % flexibleBlocks.length];

      if (day.weekday == DateTime.friday) {
        _addFridayRoutine(
          day,
          at,
          mathTitle,
          electronicsTitle,
          chemistryTitle,
          flexible.$1,
          flexible.$2,
        );
      } else {
        _addOfficeRoutine(
          day,
          at,
          mathTitle,
          electronicsTitle,
          chemistryTitle,
          flexible.$1,
          flexible.$2,
        );
      }
      day = day.add(const Duration(days: 1));
      dayIndex += 1;
    }

    tasks.sort((TaskItem a, TaskItem b) => a.startAt.compareTo(b.startAt));
    return tasks;
  }

  static void _addOfficeRoutine(
    DateTime day,
    void Function(
      DateTime,
      int,
      int,
      int,
      String,
      String, {
      String? notes,
      bool? autoFocus,
      int? priority,
      String? soundId,
      String? soundLabel,
    }) at,
    String mathTitle,
    String electronicsTitle,
    String chemistryTitle,
    String flexibleTitle,
    String flexibleSubject,
  ) {
    at(day, 6, 30, 30, 'Wake, water, wash and make the bed', health,
        soundId: 'morning_sunrise', soundLabel: 'Morning Sunrise');
    at(day, 7, 0, 60, mathTitle, math,
        autoFocus: true,
        priority: 3,
        soundId: 'study_bell',
        soundLabel: 'Study Bell');
    at(day, 8, 0, 30, 'Breakfast and eyes-away recovery', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 8, 30, 60, electronicsTitle, electronics,
        autoFocus: true,
        priority: 3,
        soundId: 'coding_digital',
        soundLabel: 'Coding Digital');
    at(day, 9, 30, 15, 'Short break — water, stretch, no social apps', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 9, 45, 60, chemistryTitle, chemistry,
        autoFocus: true,
        priority: 3,
        soundId: 'science_signal',
        soundLabel: 'Science Signal');
    at(day, 10, 45, 15, 'Walk and reset the desk', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 11, 0, 60, flexibleTitle, flexibleSubject,
        autoFocus: true, soundId: 'reading_chime', soundLabel: 'Reading Chime');
    at(day, 12, 0, 30, 'Closed-book recall and mistake list', revision,
        autoFocus: true, soundId: 'bright_bell', soundLabel: 'Bright Bell');
    at(day, 12, 30, 60, 'Lunch, prayer and quiet rest', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 13, 30, 30, 'Travel to office and prepare the priority list', work,
        soundId: 'meeting_chime', soundLabel: 'Meeting Chime');
    at(
      day,
      14,
      0,
      300,
      'Physical office — five-hour priority work block',
      work,
      notes:
          'Office time is physically 2:00 PM–7:00 PM. Work from the priority list, record blockers and avoid unrelated scope.',
      priority: 3,
      soundId: 'deadline_beacon',
      soundLabel: 'Deadline Beacon',
    );
    at(day, 19, 0, 30, 'Return home and mentally close office work', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 19, 30, 30, 'Dinner', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(
      day,
      20,
      0,
      30,
      'Purposeful free time — family, walk or quiet rest; no endless scrolling',
      health,
      soundId: 'calm_waves',
      soundLabel: 'Calm Waves',
    );
    at(day, 20, 30, 50, 'Priority revision — today’s weakest topic', revision,
        autoFocus: true,
        priority: 3,
        soundId: 'exam_alert',
        soundLabel: 'Exam Alert');
    at(day, 21, 20, 10, 'Reset break — water and stretch', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 21, 30, 50, 'Second study block — backlog or short test', revision,
        autoFocus: true, soundId: 'focus_pulse', soundLabel: 'Focus Pulse');
    at(day, 22, 20, 30, 'Update goals, mark mistakes and plan tomorrow',
        revision,
        soundId: 'bright_bell', soundLabel: 'Bright Bell');
    at(day, 22, 50, 40, 'Shower, room reset and phone away', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 23, 30, 420, 'Sleep — protect tomorrow’s memory', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
  }

  static void _addFridayRoutine(
    DateTime day,
    void Function(
      DateTime,
      int,
      int,
      int,
      String,
      String, {
      String? notes,
      bool? autoFocus,
      int? priority,
      String? soundId,
      String? soundLabel,
    }) at,
    String mathTitle,
    String electronicsTitle,
    String chemistryTitle,
    String flexibleTitle,
    String flexibleSubject,
  ) {
    at(day, 6, 30, 30, 'Wake, water, wash and make the bed', health,
        soundId: 'morning_sunrise', soundLabel: 'Morning Sunrise');
    at(day, 7, 0, 120, mathTitle, math,
        autoFocus: true,
        priority: 3,
        soundId: 'study_bell',
        soundLabel: 'Study Bell');
    at(day, 9, 0, 30, 'Breakfast and recovery', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 9, 30, 120, electronicsTitle, electronics,
        autoFocus: true,
        priority: 3,
        soundId: 'coding_digital',
        soundLabel: 'Coding Digital');
    at(day, 11, 30, 60, 'Prayer, lunch and family time', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 12, 30, 60, 'Quiet rest — no guilt, no endless scrolling', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 13, 30, 120, chemistryTitle, chemistry,
        autoFocus: true,
        priority: 3,
        soundId: 'science_signal',
        soundLabel: 'Science Signal');
    at(day, 15, 30, 30, 'Walk, water and shower', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 16, 0, 120, flexibleTitle, flexibleSubject,
        autoFocus: true, soundId: 'reading_chime', soundLabel: 'Reading Chime');
    at(day, 18, 0, 60, 'Dinner and family recovery', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 19, 0, 60, 'Weekly model test', revision,
        autoFocus: true,
        priority: 3,
        soundId: 'exam_alert',
        soundLabel: 'Exam Alert');
    at(day, 20, 0, 30, 'Break and snack', health,
        soundId: 'gentle_reminder', soundLabel: 'Gentle Reminder');
    at(day, 20, 30, 90, 'Backlog repair and test correction', revision,
        autoFocus: true, soundId: 'focus_pulse', soundLabel: 'Focus Pulse');
    at(day, 22, 0, 30, 'Update goals and prepare next week', revision,
        soundId: 'bright_bell', soundLabel: 'Bright Bell');
    at(day, 22, 30, 60, 'Shower, quiet free time and phone away', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
    at(day, 23, 30, 420, 'Sleep — protect tomorrow’s memory', health,
        soundId: 'calm_waves', soundLabel: 'Calm Waves');
  }

  static List<GoalItem> buildGoals([DateTime? createdAt]) {
    final DateTime now = createdAt ?? DateTime.now();
    GoalItem goal(
      String id,
      String title,
      String subjectId,
      int target,
      DateTime deadline,
      String notes,
    ) =>
        GoalItem(
          id: id,
          title: title,
          subjectId: subjectId,
          target: target,
          progress: 0,
          deadline: deadline,
          notes: notes,
          createdAt: now,
          updatedAt: now,
        );

    return <GoalItem>[
      goal(
        'goal-math',
        'Complete all 13 Mathematics-2 chapters',
        math,
        13,
        DateTime(2026, 8, 2),
        'Formula sheet, important problems, model test and mistake list.',
      ),
      goal(
        'goal-electronics',
        'Complete all 10 Basic Electronics chapters',
        electronics,
        10,
        DateTime(2026, 8, 2),
        'Concepts, circuits, diagrams, formulas and numericals.',
      ),
      goal(
        'goal-chemistry',
        'Complete all 14 Chemistry chapters',
        chemistry,
        14,
        DateTime(2026, 8, 2),
        'Definitions, reactions, numericals and final recall.',
      ),
      goal(
        'goal-python',
        'Finish 12 Python chapters and practical exercises',
        python,
        12,
        DateTime(2026, 8, 3),
        'Write code by hand, run examples and keep an error notebook.',
      ),
      goal(
        'goal-bangla',
        'Finish 10 Bangla chapters and writing practice',
        bangla,
        10,
        DateTime(2026, 8, 3),
        'Chapter recall, grammar and at least two writing exercises.',
      ),
      goal(
        'goal-english',
        'Finish 7 English chapters and grammar revision',
        english,
        7,
        DateTime(2026, 8, 3),
        'Grammar, vocabulary, writing and closed-book recall.',
      ),
      goal(
        'goal-tests',
        'Complete 6 timed revision tests',
        revision,
        6,
        DateTime(2026, 8, 5),
        'Correct every test and add mistakes to the final revision list.',
      ),
    ];
  }

  static List<HabitItem> buildHabits([DateTime? createdAt]) {
    final DateTime now = createdAt ?? DateTime.now();
    return <HabitItem>[
      HabitItem(
        id: 'habit-sleep',
        title: 'Sleep by 11:30 PM',
        colorValue: const Color(0xFF6D7CFF).toARGB32(),
        iconCodePoint: Icons.bedtime_rounded.codePoint,
        weekdays: const <int>[1, 2, 3, 4, 5, 6, 7],
        completedDateKeys: const <String>[],
        createdAt: now,
      ),
      HabitItem(
        id: 'habit-food',
        title: 'Eat and hydrate on time',
        colorValue: const Color(0xFFFFA62B).toARGB32(),
        iconCodePoint: Icons.restaurant_rounded.codePoint,
        weekdays: const <int>[1, 2, 3, 4, 5, 6, 7],
        completedDateKeys: const <String>[],
        createdAt: now,
      ),
      HabitItem(
        id: 'habit-recall',
        title: 'Daily closed-book recall',
        colorValue: const Color(0xFF55B84D).toARGB32(),
        iconCodePoint: Icons.psychology_rounded.codePoint,
        weekdays: const <int>[1, 2, 3, 4, 5, 6, 7],
        completedDateKeys: const <String>[],
        createdAt: now,
      ),
      HabitItem(
        id: 'habit-no-scroll',
        title: 'No unplanned social scrolling',
        colorValue: const Color(0xFFE35768).toARGB32(),
        iconCodePoint: Icons.shield_rounded.codePoint,
        weekdays: const <int>[1, 2, 3, 4, 5, 6, 7],
        completedDateKeys: const <String>[],
        createdAt: now,
      ),
    ];
  }

  static AppData initialData() {
    final DateTime now = DateTime.now();
    return AppData(
      version: currentDataVersion,
      subjects: subjects,
      tasks: buildRoutine(),
      goals: buildGoals(now),
      habits: buildHabits(now),
      notes: <NoteItem>[
        NoteItem(
          id: 'note-study-method',
          title: 'Chapter complete rule',
          body:
              'Math: formula + 8–12 problems + mistake mark.\nElectronics: concept + diagram + formula + numerical.\nChemistry: theory + reaction + numerical + recall.\nEvery break has a purpose and ends when its transition alarm rings.',
          subjectId: revision,
          pinned: true,
          createdAt: now,
          updatedAt: now,
        ),
      ],
      sessions: const <FocusSession>[],
      preferences: AppPreferencesModel(
        userName: 'Md Arifuzzaman Hredoy',
        themeMode: 'dark',
        accentValue: const Color(0xFF55B84D).toARGB32(),
        syllabusTarget: DateTime(2026, 8, 2),
        examDate: DateTime(2026, 8, 6),
        defaultFocusMinutes: 50,
        strictFocus: true,
        showCompleted: true,
        onboardingComplete: false,
        defaultTaskAlarm: true,
        defaultSnoozeMinutes: 5,
        defaultAlarmSoundId: 'smart',
        defaultAlarmSoundLabel: 'Smart by task type',
        defaultAlarmSoundUri: '',
      ),
    );
  }
}
