import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../controllers/smart_flow_controller.dart';
import '../models/app_models.dart';
import '../models/smart_flow.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';

class WeeklyReportScreen extends StatelessWidget {
  const WeeklyReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController app = AppScope.of(context);
    final SmartFlowController smart = SmartFlowScope.of(context);
    final DateTime today = dateOnly(DateTime.now());
    final List<DateTime> days = List<DateTime>.generate(
      7,
      (int index) => today.subtract(Duration(days: 6 - index)),
    );
    final WeeklyFlowReport report = _buildReport(app, days);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Weekly Flow Report'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Share report',
            onPressed: () => NativeBridge.shareText(
              'Hredoy Flow weekly report',
              report.toShareText(),
            ),
            icon: const Icon(Icons.share_rounded),
          ),
        ],
      ),
      body: ListView(
        key: const ValueKey<String>('weekly-report-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
              final int columns = constraints.maxWidth < 360 ? 1 : 2;
              return GridView.count(
                crossAxisCount: columns,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: columns == 1 ? 3.1 : 1.15,
                children: <Widget>[
                  MetricCard(
                    label: 'Tasks completed',
                    value: '${report.completedTasks}/${report.totalTasks}',
                    icon: Icons.task_alt_rounded,
                  ),
                  MetricCard(
                    label: 'Focus time',
                    value: formatDuration(report.focusMinutes),
                    icon: Icons.timer_rounded,
                  ),
                  MetricCard(
                    label: 'Productive days',
                    value: '${report.productiveDays}/7',
                    icon: Icons.calendar_view_week_rounded,
                  ),
                  MetricCard(
                    label: 'Average completion',
                    value: '${report.averageCompletion}%',
                    icon: Icons.trending_up_rounded,
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                children: <Widget>[
                  const CircleAvatar(
                    child: Icon(Icons.emoji_events_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'Best day',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        Text(report.bestDayLabel),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionHeader(
            title: 'Daily breakdown',
            subtitle: 'Task completion and focus minutes for the last 7 days.',
          ),
          const SizedBox(height: 10),
          ...days.map(
            (DateTime day) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${day.day}')),
                title: Text(
                  formatDate(day),
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: LinearProgressIndicator(
                  value: app.completionPercent(day) / 100,
                  minHeight: 7,
                ),
                trailing: Text(
                  '${app.completionPercent(day)}%\n${app.focusMinutesFor(day)} min',
                  textAlign: TextAlign.end,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: SwitchListTile.adaptive(
              title: const Text(
                'Show Weekly Report shortcuts',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: const Text(
                'Keeps this report visible in Simple navigation. The report data remains local.',
              ),
              value: smart.settings.weeklyReportEnabled,
              onChanged: smart.setWeeklyReportEnabled,
            ),
          ),
        ],
      ),
    );
  }

  WeeklyFlowReport _buildReport(
    AppController app,
    List<DateTime> days,
  ) {
    int total = 0;
    int completed = 0;
    int focus = 0;
    int productiveDays = 0;
    int completionSum = 0;
    DateTime bestDay = days.first;
    int bestScore = -1;

    for (final DateTime day in days) {
      final List<TaskItem> tasks = app.activeTasks
          .where((TaskItem task) => dateKey(task.startAt) == dateKey(day))
          .toList(growable: false);
      final int done = tasks.where((TaskItem task) => task.isCompleted).length;
      final int dayFocus = app.focusMinutesFor(day);
      final int completion = app.completionPercent(day);
      total += tasks.length;
      completed += done;
      focus += dayFocus;
      completionSum += completion;
      if (done > 0 || dayFocus > 0) productiveDays += 1;
      final int score = completion * 2 + dayFocus;
      if (score > bestScore) {
        bestScore = score;
        bestDay = day;
      }
    }

    return WeeklyFlowReport(
      completedTasks: completed,
      totalTasks: total,
      focusMinutes: focus,
      productiveDays: productiveDays,
      averageCompletion: (completionSum / days.length).round(),
      bestDayLabel: '${formatDate(bestDay)} • ${app.completionPercent(bestDay)}% tasks • ${app.focusMinutesFor(bestDay)} focus min',
    );
  }
}
