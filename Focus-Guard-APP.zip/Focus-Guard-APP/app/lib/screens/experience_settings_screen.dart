import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/smart_flow.dart';
import '../widgets/common_widgets.dart';

class ExperienceSettingsScreen extends StatelessWidget {
  const ExperienceSettingsScreen({super.key});

  static const Map<String, String> _shortcutLabels = <String, String>{
    'coach': 'Daily Coach',
    'phone-control': 'Phone Control',
    'study': 'Study Mode',
    'weekly-report': 'Weekly Report',
    'safety': 'Safety Center',
    'recommendations': 'Smart Recommendations',
    'goals': 'Goals',
    'notes': 'Notes',
  };

  @override
  Widget build(BuildContext context) {
    final SmartFlowController smart = SmartFlowScope.of(context);
    final SmartFlowSettings settings = smart.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Simple & Advanced Mode')),
      body: ListView(
        key: const ValueKey<String>('experience-settings-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          SegmentedButton<ExperienceMode>(
            segments: const <ButtonSegment<ExperienceMode>>[
              ButtonSegment<ExperienceMode>(
                value: ExperienceMode.simple,
                icon: Icon(Icons.auto_awesome_rounded),
                label: Text('Simple'),
              ),
              ButtonSegment<ExperienceMode>(
                value: ExperienceMode.advanced,
                icon: Icon(Icons.tune_rounded),
                label: Text('Advanced'),
              ),
            ],
            selected: <ExperienceMode>{settings.experienceMode},
            onSelectionChanged: (Set<ExperienceMode> values) =>
                smart.setExperienceMode(values.first),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                settings.simpleMode
                    ? 'Simple Mode shows the Daily Coach and your chosen shortcuts first. Advanced tools stay available under one expandable section.'
                    : 'Advanced Mode shows every management tool directly, including schedules, social controls, categories, backup and diagnostics.',
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionHeader(
            title: 'Simple Mode shortcuts',
            subtitle: 'Choose the tools shown on the main More screen.',
          ),
          const SizedBox(height: 10),
          ..._shortcutLabels.entries.map(
            (MapEntry<String, String> entry) => CheckboxListTile(
              value: settings.simpleShortcutIds.contains(entry.key),
              title: Text(entry.value),
              onChanged: (bool? value) {
                final Set<String> next =
                    Set<String>.from(settings.simpleShortcutIds);
                if (value ?? false) {
                  next.add(entry.key);
                } else if (next.length > 1) {
                  next.remove(entry.key);
                }
                smart.setSimpleShortcuts(next);
              },
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Column(
              children: <Widget>[
                SwitchListTile.adaptive(
                  title: const Text('Show Daily Coach shortcuts'),
                  value: settings.dailyCoachEnabled,
                  onChanged: smart.setDailyCoachEnabled,
                ),
                SwitchListTile.adaptive(
                  title: const Text('Show Smart Recommendations'),
                  value: settings.smartRecommendationsEnabled,
                  onChanged: smart.setRecommendationsEnabled,
                ),
                SwitchListTile.adaptive(
                  title: const Text('Show Weekly Report shortcuts'),
                  value: settings.weeklyReportEnabled,
                  onChanged: smart.setWeeklyReportEnabled,
                ),
                SwitchListTile.adaptive(
                  title: const Text('Rule activation preview'),
                  value: settings.rulePreviewRequired,
                  onChanged: smart.setRulePreviewRequired,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
