import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/app_controller.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Backup & Restore')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: <Widget>[
          const EmptyState(
            icon: Icons.lock_rounded,
            title: 'Local-first data',
            message:
                'All tasks, goals, habits, notes and focus history stay in local app storage.',
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _busy ? null : () => _copyBackup(controller),
            icon: const Icon(Icons.copy_all_rounded),
            label: const Text('Copy backup JSON'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _busy ? null : () => _shareBackup(controller),
            icon: const Icon(Icons.share_rounded),
            label: const Text('Share backup'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _busy ? null : () => _import(controller),
            icon: const Icon(Icons.restore_rounded),
            label: const Text('Restore from pasted JSON'),
          ),
          const SizedBox(height: 22),
          Card(
            color: Theme.of(context).colorScheme.errorContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Danger zone',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Reset replaces current data with the preloaded exam routine.',
                  ),
                  const SizedBox(height: 12),
                  FilledButton.tonalIcon(
                    onPressed: _busy ? null : () => _reset(controller),
                    icon: const Icon(Icons.restart_alt_rounded),
                    label: const Text('Reset all data'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _copyBackup(AppController controller) async {
    setState(() => _busy = true);
    try {
      final String backup = await controller.exportJsonAsync();
      await Clipboard.setData(ClipboardData(text: backup));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Backup JSON copied to the clipboard.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not create backup: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _shareBackup(AppController controller) async {
    setState(() => _busy = true);
    try {
      final String backup = await controller.exportJsonAsync();
      await NativeBridge.shareText('Hredoy Flow Backup', backup);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not share backup: $error')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _import(AppController controller) async {
    String inputText = '';
    final bool? restore = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('Restore backup'),
        content: SizedBox(
          width: double.maxFinite,
          child: TextFormField(
            initialValue: inputText,
            minLines: 8,
            maxLines: 14,
            decoration: const InputDecoration(
              labelText: 'Paste backup JSON',
              alignLabelWithHint: true,
            ),
            onChanged: (String value) => inputText = value,
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Restore'),
          ),
        ],
      ),
    );
    final String raw = inputText.trim();
    if (restore != true || raw.isEmpty) {
      return;
    }
    setState(() => _busy = true);
    try {
      await controller.importJson(raw);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Backup restore successful')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Restore failed: $error')));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _reset(AppController controller) async {
    final bool confirmed = await confirmAction(
      context,
      title: 'Reset all data?',
      message: 'Current custom data will be replaced. Create a backup first.',
      confirmLabel: 'Reset all',
    );
    if (!confirmed) {
      return;
    }
    setState(() => _busy = true);
    await controller.resetAllData();
    if (mounted) {
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hredoy Flow data has been reset.')),
      );
    }
  }
}
