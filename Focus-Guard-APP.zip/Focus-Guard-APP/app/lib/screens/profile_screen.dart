import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../models/study_game.dart';
import '../services/native_bridge.dart';
import '../widgets/app_drawer.dart';
import '../widgets/common_widgets.dart';
import '../widgets/profile_avatar.dart';
import 'focus_game_screen.dart';
import 'goal_manager_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _photoBusy = false;

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final StudyGameStats game = controller.gameStats;
    final AppPreferencesModel preferences = controller.preferences;
    final DateTime today = dateOnly(DateTime.now());

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: const Text('Profile'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Edit profile name',
            onPressed: () => _editName(context, controller),
            icon: const Icon(Icons.edit_rounded),
          ),
        ],
      ),
      body: ListView(
        key: const ValueKey<String>('profile-scroll-view'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: <Color>[
                  Theme.of(context).colorScheme.primaryContainer,
                  Theme.of(context).colorScheme.surfaceContainerHighest,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(
              children: <Widget>[
                Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    ProfileAvatar(
                      name: preferences.userName,
                      imageBase64: preferences.profileImageBase64,
                      radius: 52,
                      showCameraBadge: true,
                      onTap: _photoBusy
                          ? null
                          : () => _showPhotoActions(context, controller),
                    ),
                    if (_photoBusy)
                      const SizedBox.square(
                        dimension: 42,
                        child: CircularProgressIndicator(strokeWidth: 3),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: _photoBusy
                      ? null
                      : () => _showPhotoActions(context, controller),
                  icon: const Icon(Icons.add_a_photo_rounded),
                  label: Text(
                    preferences.profileImageBase64.isEmpty
                        ? 'Add profile picture'
                        : 'Change profile picture',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  preferences.userName,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${game.rank} • Level ${game.level}',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Diploma student • TechTeam • Building a disciplined exam routine',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 18),
                LinearProgressIndicator(
                  value: game.progress,
                  minHeight: 10,
                  borderRadius: BorderRadius.circular(99),
                ),
                const SizedBox(height: 7),
                Text(
                  '${game.xpIntoLevel}/${game.xpNeededForLevel} XP to Level ${game.level + 1}',
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.32,
            children: <Widget>[
              MetricCard(
                icon: Icons.timer_rounded,
                value: '${controller.focusMinutesFor(today)}m',
                label: 'Focus today',
                subtitle: '${controller.totalFocusMinutes}m total',
              ),
              MetricCard(
                icon: Icons.task_alt_rounded,
                value: '${controller.completedTaskCountFor(today)}',
                label: 'Tasks today',
                subtitle: '${controller.completedTaskCount} completed total',
              ),
              MetricCard(
                icon: Icons.local_fire_department_rounded,
                value: '${controller.currentStreak}',
                label: 'Current streak',
                subtitle: 'Protect it today',
              ),
              MetricCard(
                icon: Icons.flag_rounded,
                value:
                    '${controller.completedGoalCount}/${controller.activeGoals.length}',
                label: 'Goals achieved',
                subtitle: 'Auto-synced with tasks',
              ),
            ],
          ),
          const SizedBox(height: 20),
          const SectionHeader(
            title: 'Exam command center',
            subtitle: 'Your deadlines and restart plan in one place.',
          ),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: <Widget>[
                ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.menu_book_rounded),
                  ),
                  title: const Text('Syllabus target'),
                  subtitle: Text(formatDate(preferences.syllabusTarget)),
                  trailing: Text(
                    '${controller.daysUntil(preferences.syllabusTarget).clamp(0, 999)} days',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.school_rounded),
                  ),
                  title: const Text('Exam date'),
                  subtitle: Text(formatDate(preferences.examDate)),
                  trailing: Text(
                    '${controller.daysUntil(preferences.examDate).clamp(0, 999)} days',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                const Divider(height: 1),
                const ListTile(
                  leading: CircleAvatar(
                    child: Icon(Icons.restart_alt_rounded),
                  ),
                  title: Text('Routine restart'),
                  subtitle: Text('26 July 2026 • 6:30 AM'),
                  trailing: Icon(Icons.verified_rounded),
                ),
                const Divider(height: 1),
                const ListTile(
                  leading: CircleAvatar(
                    child: Icon(Icons.work_rounded),
                  ),
                  title: Text('Physical office'),
                  subtitle: Text('2:00 PM–7:00 PM • five hours'),
                  trailing: Text(
                    '5h',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const FocusGameScreen(),
                    ),
                  ),
                  icon: const Icon(Icons.sports_esports_rounded),
                  label: const Text('Study Quest'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const GoalManagerScreen(),
                    ),
                  ),
                  icon: const Icon(Icons.flag_rounded),
                  label: const Text('Goals'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => _confirmRoutineReset(context, controller),
            icon: const Icon(Icons.restart_alt_rounded),
            label: const Text('Reset generated routine from 26 July'),
          ),
        ],
      ),
    );
  }

  Future<void> _showPhotoActions(
    BuildContext context,
    AppController controller,
  ) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                'Profile picture',
                style: Theme.of(sheetContext).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'The photo stays inside Hredoy Flow and is included in your local backup.',
              ),
              const SizedBox(height: 14),
              ListTile(
                leading: const Icon(Icons.photo_library_rounded),
                title: const Text('Choose from gallery'),
                subtitle: const Text('Pick and center-crop an existing photo'),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  _selectPhoto(controller, camera: false);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera_rounded),
                title: const Text('Take a photo'),
                subtitle: const Text(
                    'Use the phone camera for a quick profile photo'),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  _selectPhoto(controller, camera: true);
                },
              ),
              if (controller.preferences.profileImageBase64.isNotEmpty)
                ListTile(
                  leading: Icon(
                    Icons.delete_outline_rounded,
                    color: Theme.of(sheetContext).colorScheme.error,
                  ),
                  title: Text(
                    'Remove photo',
                    style: TextStyle(
                      color: Theme.of(sheetContext).colorScheme.error,
                    ),
                  ),
                  onTap: () {
                    Navigator.of(sheetContext).pop();
                    _removePhoto(controller);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _selectPhoto(
    AppController controller, {
    required bool camera,
  }) async {
    if (_photoBusy) return;
    setState(() => _photoBusy = true);
    try {
      final Uint8List? bytes = camera
          ? await NativeBridge.captureProfileImage()
          : await NativeBridge.pickProfileImage();
      if (bytes == null || bytes.isEmpty) return;
      await controller.updatePreferences(
        controller.preferences.copyWith(
          profileImageBase64: base64Encode(bytes),
        ),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile picture saved.')),
      );
    } on Exception catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save profile picture: $error')),
      );
    } finally {
      if (mounted) setState(() => _photoBusy = false);
    }
  }

  Future<void> _removePhoto(AppController controller) async {
    await controller.updatePreferences(
      controller.preferences.copyWith(profileImageBase64: ''),
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Profile picture removed.')),
    );
  }

  Future<void> _editName(
    BuildContext context,
    AppController controller,
  ) async {
    String value = controller.preferences.userName;
    final bool? save = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('Edit profile name'),
        content: TextFormField(
          initialValue: value,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Your name',
            prefixIcon: Icon(Icons.person_rounded),
          ),
          onChanged: (String next) => value = next,
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (save != true || value.trim().isEmpty) return;
    await controller.updatePreferences(
      controller.preferences.copyWith(userName: value.trim()),
    );
  }

  Future<void> _confirmRoutineReset(
    BuildContext context,
    AppController controller,
  ) async {
    final bool? reset = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('Restart the routine?'),
        content: const Text(
          'Generated routine blocks will restart from Sunday, 26 July at 6:30 AM. All older generated routine blocks are removed, custom tasks stay safe, goal templates reset and routine alarms are rescheduled.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Reset routine'),
          ),
        ],
      ),
    );
    if (reset != true) return;
    await controller.resetRoutineFromJuly26();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content:
            Text('Routine reset from 26 July 6:30 AM and alarms rescheduled.'),
      ),
    );
  }
}
