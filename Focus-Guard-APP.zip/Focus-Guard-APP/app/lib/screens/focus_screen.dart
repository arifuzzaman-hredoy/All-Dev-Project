import 'dart:async';

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../services/native_bridge.dart';
import '../widgets/focus_tree.dart';

class FocusScreen extends StatefulWidget {
  const FocusScreen({
    required this.minutes,
    required this.label,
    required this.subjectId,
    required this.taskId,
    required this.controller,
    super.key,
  });

  final int minutes;
  final String label;
  final String subjectId;
  final String? taskId;
  final AppController controller;

  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> with WidgetsBindingObserver {
  Timer? _timer;
  late final DateTime _startedAt;
  late int _remainingSeconds;
  int _activeSeconds = 0;
  bool _paused = false;
  bool _finishing = false;
  bool _canPop = false;
  DateTime? _deadline;
  NativeSystemReadiness? _readiness;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startedAt = DateTime.now();
    _remainingSeconds = widget.minutes * 60;
    NativeBridge.setKeepScreenOn(true).catchError((_) {});
    _loadReadiness();
    _resumeCountdown();
  }

  Future<void> _loadReadiness() async {
    try {
      final NativeSystemReadiness readiness =
          await NativeBridge.systemReadiness();
      if (mounted) setState(() => _readiness = readiness);
    } catch (_) {
      // Focus timer stays available when Android readiness checks are absent.
    }
  }

  void _resumeCountdown() {
    _deadline = DateTime.now().add(Duration(seconds: _remainingSeconds));
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    unawaited(_syncNativeFocus());
  }

  Future<void> _syncNativeFocus() async {
    try {
      await NativeBridge.startFocus(
        (_remainingSeconds / 60).ceil().clamp(1, 240).toInt(),
        widget.label,
      );
    } catch (_) {
      // The local timer remains usable when Android focus controls are absent.
    }
  }

  void _tick() {
    if (!mounted || _paused || _finishing || _deadline == null) return;
    final int milliseconds =
        _deadline!.difference(DateTime.now()).inMilliseconds;
    final int next = milliseconds <= 0 ? 0 : (milliseconds / 1000).ceil();
    final int progressed =
        (_remainingSeconds - next).clamp(0, _remainingSeconds).toInt();
    _activeSeconds += progressed;
    if (next <= 0) {
      _remainingSeconds = 0;
      _timer?.cancel();
      unawaited(_completeSession());
      return;
    }
    if (next != _remainingSeconds) {
      setState(() => _remainingSeconds = next);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      NativeBridge.setKeepScreenOn(true).catchError((_) {});
      _tick();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      NativeBridge.setKeepScreenOn(false).catchError((_) {});
    }
  }

  double get _focusProgress {
    final int totalSeconds = widget.minutes * 60;
    if (totalSeconds <= 0) return 0;
    return (1 - _remainingSeconds / totalSeconds).clamp(0.0, 1.0).toDouble();
  }

  String get _timerText {
    final int hours = _remainingSeconds ~/ 3600;
    final int minutes = (_remainingSeconds % 3600) ~/ 60;
    final int seconds = _remainingSeconds % 60;
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    }
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  Future<void> _togglePause() async {
    if (_finishing) {
      return;
    }
    if (_paused) {
      setState(() => _paused = false);
      _resumeCountdown();
    } else {
      _timer?.cancel();
      try {
        await NativeBridge.endFocus();
      } catch (_) {}
      if (mounted) {
        setState(() => _paused = true);
      }
    }
  }

  Future<void> _completeSession() async {
    if (_finishing) {
      return;
    }
    _finishing = true;
    _timer?.cancel();
    try {
      await NativeBridge.endFocus();
    } catch (_) {}
    if (!mounted) {
      await _saveSession(completed: true, markTaskDone: false);
      return;
    }
    final bool? markDone = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('Focus session complete'),
        content: Text(
          widget.taskId == null
              ? 'Great work. This session will be saved to your history.'
              : 'Mark the linked task as completed?',
        ),
        actions: <Widget>[
          if (widget.taskId != null)
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Save session only'),
            ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(widget.taskId == null ? 'Done' : 'Task complete'),
          ),
        ],
      ),
    );
    await _saveSession(completed: true, markTaskDone: markDone ?? false);
  }

  Future<void> _endEarly() async {
    if (_finishing || !mounted) return;
    final bool? end = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: const Text('End this focus session?'),
        content: const Text(
          'Ending restores app access and Do Not Disturb. Actual time will be saved.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Continue'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('End session'),
          ),
        ],
      ),
    );
    if (end == true) {
      _finishing = true;
      _timer?.cancel();
      try {
        await NativeBridge.endFocus();
      } catch (_) {}
      await _saveSession(completed: false, markTaskDone: false);
    }
  }

  Future<void> _saveSession({
    required bool completed,
    required bool markTaskDone,
  }) async {
    final DateTime endedAt = DateTime.now();
    final int actualMinutes =
        (_activeSeconds / 60).ceil().clamp(1, widget.minutes).toInt();
    await widget.controller.addSession(
      FocusSession(
        id: newId('session'),
        label: widget.label,
        taskId: widget.taskId,
        subjectId: widget.subjectId,
        startedAt: _startedAt,
        endedAt: endedAt,
        plannedMinutes: widget.minutes,
        actualMinutes: actualMinutes,
        completed: completed,
      ),
    );
    if (markTaskDone && widget.taskId != null) {
      final TaskItem? task = widget.controller.data.tasks
          .where((TaskItem item) => item.id == widget.taskId)
          .firstOrNull;
      if (task != null) {
        await widget.controller.setTaskCompleted(task, true);
      }
    }
    if (!mounted) {
      return;
    }
    setState(() => _canPop = true);
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    NativeBridge.setKeepScreenOn(false).catchError((_) {});
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope<Object?>(
        canPop: _canPop,
        onPopInvokedWithResult: (bool didPop, Object? result) async {
          if (!didPop) {
            await _endEarly();
          }
        },
        child: Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      IconButton(
                        tooltip: 'End focus',
                        onPressed: _endEarly,
                        icon: const Icon(Icons.close_rounded),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(_paused ? 'PAUSED' : 'FOCUS ACTIVE'),
                      ),
                    ],
                  ),
                  if (_readiness != null &&
                      !_readiness!.focusReady) ...<Widget>[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.errorContainer,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Row(
                        children: <Widget>[
                          Icon(Icons.warning_amber_rounded),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'App Blocker accessibility access is OFF. The timer works, but selected apps cannot be blocked until it is enabled.',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  Expanded(
                    child: Center(
                      child: FocusTree(
                        key: const ValueKey<String>('live-focus-tree'),
                        progress: _focusProgress,
                        level: widget.controller.gameStats.level,
                        height: 230,
                        semanticLabel: _paused
                            ? 'Paused focus tree'
                            : 'Live focus tree growing with study time',
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.label,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _timerText,
                    style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w900,
                      fontFeatures: const <FontFeature>[
                        FontFeature.tabularFigures(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _paused
                        ? 'Timer paused. App blocking will resume with the timer.'
                        : 'Stay focused. Your tree grows every second while selected distracting apps stay blocked.',
                    textAlign: TextAlign.center,
                  ),
                  const Spacer(),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _togglePause,
                          icon: Icon(
                            _paused
                                ? Icons.play_arrow_rounded
                                : Icons.pause_rounded,
                          ),
                          label: Text(_paused ? 'Resume' : 'Pause'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _endEarly,
                          icon: const Icon(Icons.stop_rounded),
                          label: const Text('End'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
