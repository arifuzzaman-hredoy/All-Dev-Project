import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';
import 'phone_control_screen.dart';

class SocialControlScreen extends StatefulWidget {
  const SocialControlScreen({super.key});

  @override
  State<SocialControlScreen> createState() => _SocialControlScreenState();
}

class _SocialControlScreenState extends State<SocialControlScreen>
    with WidgetsBindingObserver {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlPolicy _persistedPolicy = const PhoneControlPolicy();
  PhoneControlPolicy? _queuedPolicy;
  SocialControlSnapshot _snapshot = const SocialControlSnapshot();
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(showSpinner: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool showSpinner = true}) async {
    if (showSpinner && mounted) setState(() => _loading = true);
    PhoneControlPolicy policy = _policy;
    SocialControlSnapshot snapshot = _snapshot;
    List<LaunchableAppInfo> apps = _apps;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      snapshot = await NativeBridge.socialControlSnapshot();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _persistedPolicy = policy;
      _snapshot = snapshot;
      final Set<String> alwaysAllowed =
          SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
              const <String>{};
      _apps = apps.where((LaunchableAppInfo app) {
        return !_isProtectedPackage(app.packageName) &&
            !alwaysAllowed.contains(app.packageName);
      }).toList(growable: false);
      _loading = false;
    });
  }

  Future<void> _save(PhoneControlPolicy policy) async {
    final Set<String> alwaysAllowed =
        SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
            const <String>{};
    final PhoneControlPolicy safePolicy =
        sanitizePhoneControlForAlwaysAllowed(policy, alwaysAllowed);
    _queuedPolicy = safePolicy;
    if (mounted) setState(() => _policy = safePolicy);
    if (_saving) return;

    if (mounted) setState(() => _saving = true);
    while (_queuedPolicy != null) {
      final PhoneControlPolicy target = _queuedPolicy!;
      _queuedPolicy = null;
      try {
        await NativeBridge.savePhoneControlPolicy(target);
        _persistedPolicy = target;
      } catch (error) {
        _queuedPolicy = null;
        if (!mounted) return;
        setState(() => _policy = _persistedPolicy);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save social control: $error')),
        );
        break;
      }
    }
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _pickNotificationApps() async {
    final Set<String>? selected = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _NotificationAppPicker(
        apps: _apps,
        selected: _policy.notificationPackages,
      ),
    );
    if (selected != null && mounted) {
      await _save(_policy.copyWith(notificationPackages: selected));
    }
  }

  Future<void> _pickNotificationTime({required bool start}) async {
    final int minute =
        start ? _policy.notificationStartMinute : _policy.notificationEndMinute;
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: minute ~/ 60, minute: minute % 60),
    );
    if (picked == null) return;
    final int value = picked.hour * 60 + picked.minute;
    await _save(
      start
          ? _policy.copyWith(notificationStartMinute: value)
          : _policy.copyWith(notificationEndMinute: value),
    );
  }

  Future<void> _toggleNotificationDay(int day, bool selected) async {
    final Set<int> updated = <int>{..._policy.notificationWeekdays};
    if (selected) {
      updated.add(day);
    } else if (updated.length > 1) {
      updated.remove(day);
    }
    await _save(_policy.copyWith(notificationWeekdays: updated));
  }

  Future<void> _clearHistory() async {
    await NativeBridge.clearNotificationHistory();
    if (mounted) await _load(showSpinner: false);
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, String> labels = <String, String>{
      for (final LaunchableAppInfo app in _apps) app.packageName: app.label,
    };
    final List<AppControlRule> reelsRules = _policy.rules
        .where((AppControlRule rule) => rule.reelsGuard)
        .toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Social & Notifications'),
        actions: <Widget>[
          if (_saving)
            const Padding(
              padding: EdgeInsets.only(right: 18),
              child: Center(
                child: SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            )
          else
            IconButton(
              tooltip: 'Refresh',
              onPressed: () => _load(showSpinner: false),
              icon: const Icon(Icons.refresh_rounded),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _load(showSpinner: false),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                children: <Widget>[
                  _SocialControlHero(
                    notificationBlocks: _snapshot.totalNotificationsBlocked,
                    reelsViewed: _snapshot.totalReelsViewed,
                    scrolls: _snapshot.totalScrolls,
                  ),
                  const SizedBox(height: 16),
                  if (!_snapshot.notificationAccessEnabled)
                    Card(
                      color: Theme.of(context).colorScheme.errorContainer,
                      child: ListTile(
                        leading: const Icon(Icons.warning_amber_rounded),
                        title: const Text(
                          'Notification access is required',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: const Text(
                          'Enable Hredoy Flow Notification Control, then return here.',
                        ),
                        trailing: FilledButton.tonal(
                          onPressed:
                              NativeBridge.openNotificationAccessSettings,
                          child: const Text('Enable'),
                        ),
                      ),
                    )
                  else
                    const Card(
                      child: ListTile(
                        leading: Icon(Icons.verified_user_rounded),
                        title: Text(
                          'Notification access ready',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: Text(
                          'Calls, alarms, navigation, media and ongoing service notifications are never cancelled.',
                        ),
                      ),
                    ),
                  const SizedBox(height: 16),
                  SectionHeader(
                    title: 'Notification Blocker',
                    subtitle:
                        '${_policy.notificationPackages.length} apps selected',
                    action: FilledButton.tonalIcon(
                      onPressed: _pickNotificationApps,
                      icon: const Icon(Icons.apps_rounded),
                      label: const Text('Choose apps'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: Column(
                      children: <Widget>[
                        SwitchListTile.adaptive(
                          secondary: const CircleAvatar(
                              child: Icon(Icons.power_rounded)),
                          title: const Text(
                            'Master Phone Control',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: const Text(
                            'All Phone Control modules require this switch.',
                          ),
                          value: _policy.masterEnabled,
                          onChanged: (bool value) =>
                              _save(_policy.copyWith(masterEnabled: value)),
                        ),
                        const Divider(height: 1),
                        SwitchListTile.adaptive(
                          secondary: const CircleAvatar(
                            child: Icon(Icons.notifications_off_rounded),
                          ),
                          title: const Text(
                            'Block selected notifications',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: const Text(
                            'Cancels new notifications and records a private local history.',
                          ),
                          value: _policy.notificationBlockerEnabled,
                          onChanged: (bool value) => _save(
                            _policy.copyWith(
                              notificationBlockerEnabled: value,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (_policy.notificationPackages.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 7,
                      runSpacing: 7,
                      children: _policy.notificationPackages
                          .map((String packageName) {
                        return InputChip(
                          label: Text(labels[packageName] ?? packageName),
                          onDeleted: () {
                            final Set<String> updated = <String>{
                              ..._policy.notificationPackages
                            }..remove(packageName);
                            _save(_policy.copyWith(
                                notificationPackages: updated));
                          },
                        );
                      }).toList(growable: false),
                    ),
                  ],
                  const SizedBox(height: 16),
                  const SectionHeader(
                    title: 'Notification blocking schedule',
                    subtitle:
                        'Choose when selected-app notifications should be cancelled.',
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SwitchListTile.adaptive(
                            contentPadding: EdgeInsets.zero,
                            title: const Text(
                              'Use a quiet-time schedule',
                              style: TextStyle(fontWeight: FontWeight.w900),
                            ),
                            subtitle: Text(
                              _policy.notificationScheduleEnabled
                                  ? '${formatMinuteOfDay(_policy.notificationStartMinute)}–${formatMinuteOfDay(_policy.notificationEndMinute)}'
                                  : 'Block selected notifications all day',
                            ),
                            value: _policy.notificationScheduleEnabled,
                            onChanged: (bool value) => _save(
                              _policy.copyWith(
                                  notificationScheduleEnabled: value),
                            ),
                          ),
                          if (_policy.notificationScheduleEnabled) ...<Widget>[
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 7,
                              runSpacing: 7,
                              children: List<Widget>.generate(7, (int index) {
                                const List<String> labels = <String>[
                                  'Mon',
                                  'Tue',
                                  'Wed',
                                  'Thu',
                                  'Fri',
                                  'Sat',
                                  'Sun',
                                ];
                                final int day = index + 1;
                                return FilterChip(
                                  label: Text(labels[index]),
                                  selected: _policy.notificationWeekdays
                                      .contains(day),
                                  onSelected: (bool selected) =>
                                      _toggleNotificationDay(day, selected),
                                );
                              }),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: <Widget>[
                                OutlinedButton.icon(
                                  onPressed: () =>
                                      _pickNotificationTime(start: true),
                                  icon: const Icon(Icons.nightlight_round),
                                  label: Text(
                                    'From ${formatMinuteOfDay(_policy.notificationStartMinute)}',
                                  ),
                                ),
                                OutlinedButton.icon(
                                  onPressed: () =>
                                      _pickNotificationTime(start: false),
                                  icon: const Icon(Icons.wb_sunny_rounded),
                                  label: Text(
                                    'Until ${formatMinuteOfDay(_policy.notificationEndMinute)}',
                                  ),
                                ),
                              ],
                            ),
                          ],
                          const SizedBox(height: 12),
                          Text(
                            'History retention: ${_policy.notificationHistoryLimit} items',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          Slider(
                            value: _policy.notificationHistoryLimit.toDouble(),
                            min: 10,
                            max: 500,
                            divisions: 49,
                            label: '${_policy.notificationHistoryLimit}',
                            onChanged: (double value) => _save(
                              _policy.copyWith(
                                notificationHistoryLimit:
                                    ((value / 10).round() * 10),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  SectionHeader(
                    title: 'Reels, Shorts & scrolling',
                    subtitle:
                        '${reelsRules.length} apps • ${_snapshot.totalReelsViewed} viewed • ${formatUsageDuration(_snapshot.totalReelsWatchMillis)} watched',
                    action: FilledButton.tonalIcon(
                      onPressed: () async {
                        await Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const PhoneControlScreen(),
                          ),
                        );
                        if (mounted) await _load(showSpinner: false);
                      },
                      icon: const Icon(Icons.tune_rounded),
                      label: const Text('Configure'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: Column(
                      children: <Widget>[
                        SwitchListTile.adaptive(
                          secondary: const CircleAvatar(
                            child: Icon(Icons.smart_display_rounded),
                          ),
                          title: const Text(
                            'Reels & Shorts Guard',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: const Text(
                            'Detects supported short-video screens using Accessibility content signals.',
                          ),
                          value: _policy.reelsBlockerEnabled,
                          onChanged: (bool value) => _save(
                            _policy.copyWith(reelsBlockerEnabled: value),
                          ),
                        ),
                        const Divider(height: 1),
                        SwitchListTile.adaptive(
                          secondary: const CircleAvatar(
                            child: Icon(Icons.swap_vert_rounded),
                          ),
                          title: const Text(
                            'Scroll analytics & limits',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: const Text(
                            'Tracks controlled-app scroll gestures and enforces configured limits.',
                          ),
                          value: _policy.scrollLimitEnabled,
                          onChanged: (bool value) => _save(
                            _policy.copyWith(scrollLimitEnabled: value),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (reelsRules.isEmpty)
                    const EmptyState(
                      icon: Icons.smart_display_rounded,
                      title: 'No app has Reels Guard enabled',
                      message:
                          'Open Configure, edit Instagram, Facebook, YouTube or TikTok, and enable Reels Guard.',
                    )
                  else
                    ...reelsRules.map((AppControlRule rule) {
                      final int scrolls =
                          _snapshot.scrollCounts[rule.packageName] ?? 0;
                      final int blocked =
                          _snapshot.reelsBlocked[rule.packageName] ?? 0;
                      final int viewed =
                          _snapshot.reelsViewed[rule.packageName] ?? 0;
                      final int watchMillis =
                          _snapshot.reelsWatchMillis[rule.packageName] ?? 0;
                      final String countLimit = rule.blockReelsImmediately
                          ? 'Immediate block'
                          : rule.reelsDailyLimit == 0
                              ? 'No Reel count limit'
                              : '$viewed/${rule.reelsDailyLimit} Reels';
                      final String timeLimit = rule.reelsTimeLimitMinutes == 0
                          ? 'No Reel time limit'
                          : '${formatUsageDuration(watchMillis)}/${rule.reelsTimeLimitMinutes}m';
                      final String scrollLimit = rule.scrollLimit == 0
                          ? '$scrolls scrolls'
                          : '$scrolls/${rule.scrollLimit} scrolls';
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  const CircleAvatar(
                                    child:
                                        Icon(Icons.play_circle_outline_rounded),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      rule.label,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                  Text('$blocked blocked'),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 7,
                                runSpacing: 7,
                                children: <Widget>[
                                  _LimitChip(
                                    icon: Icons.video_library_rounded,
                                    label: countLimit,
                                  ),
                                  _LimitChip(
                                    icon: Icons.timer_rounded,
                                    label: timeLimit,
                                  ),
                                  _LimitChip(
                                    icon: Icons.swap_vert_rounded,
                                    label: scrollLimit,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  const SizedBox(height: 22),
                  SectionHeader(
                    title: 'Blocked notification history',
                    subtitle:
                        '${_snapshot.totalNotificationsBlocked} blocked today • stored only on this phone',
                    action: TextButton.icon(
                      onPressed: _snapshot.notificationHistory.isEmpty
                          ? null
                          : _clearHistory,
                      icon: const Icon(Icons.delete_sweep_rounded),
                      label: const Text('Clear'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_snapshot.notificationHistory.isEmpty)
                    const EmptyState(
                      icon: Icons.notifications_none_rounded,
                      title: 'No blocked notifications yet',
                      message:
                          'Enable access, select apps and turn on Notification Blocker.',
                    )
                  else
                    ..._snapshot.notificationHistory.take(30).map(
                          (NotificationHistoryItem item) => Card(
                            child: ListTile(
                              leading: const CircleAvatar(
                                child: Icon(Icons.notifications_off_rounded),
                              ),
                              title: Text(
                                item.appLabel,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900),
                              ),
                              subtitle: Text(
                                <String>[
                                  if (item.title.isNotEmpty) item.title,
                                  if (item.text.isNotEmpty) item.text,
                                  _formatTimestamp(item.timestamp),
                                ].join('\n'),
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        ),
                  const SizedBox(height: 14),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Android limitation: Hredoy Flow cancels notifications after Android delivers them to the listener. A very brief visual flash may still occur on some devices. Notification previews stay in app-private storage and are never uploaded.',
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  String _formatTimestamp(DateTime value) {
    final TimeOfDay time = TimeOfDay.fromDateTime(value);
    return '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')} ${time.format(context)}';
  }

  bool _isProtectedPackage(String packageName) {
    final String value = packageName.toLowerCase();
    return value == 'com.android.settings' ||
        value.contains('systemui') ||
        value.contains('launcher') ||
        value.contains('dialer') ||
        value.contains('incallui') ||
        value.contains('emergency') ||
        value.contains('authenticator') ||
        value.contains('permissioncontroller') ||
        value.contains('packageinstaller') ||
        value.contains('bank') ||
        value.contains('bkash') ||
        value.contains('nagad') ||
        value.contains('rocket') ||
        value.contains('wallet') ||
        value.contains('payment') ||
        value == 'com.hredoy.focus_guard_flutter';
  }
}

class _SocialControlHero extends StatelessWidget {
  const _SocialControlHero({
    required this.notificationBlocks,
    required this.reelsViewed,
    required this.scrolls,
  });

  final int notificationBlocks;
  final int reelsViewed;
  final int scrolls;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: colors.primaryContainer,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Row(
            children: <Widget>[
              CircleAvatar(
                child: Icon(Icons.shield_moon_rounded),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Social protection',
                      style:
                          TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                    ),
                    Text('Notifications, short videos and scroll analytics'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              Expanded(
                  child: _HeroMetric(
                      label: 'Notifications', value: '$notificationBlocks')),
              Expanded(
                  child: _HeroMetric(
                      label: 'Reels viewed', value: '$reelsViewed')),
              Expanded(child: _HeroMetric(label: 'Scrolls', value: '$scrolls')),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroMetric extends StatelessWidget {
  const _HeroMetric({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
        children: <Widget>[
          Text(value,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      );
}

class _LimitChip extends StatelessWidget {
  const _LimitChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 16),
            const SizedBox(width: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _NotificationAppPicker extends StatefulWidget {
  const _NotificationAppPicker({required this.apps, required this.selected});

  final List<LaunchableAppInfo> apps;
  final Set<String> selected;

  @override
  State<_NotificationAppPicker> createState() => _NotificationAppPickerState();
}

class _NotificationAppPickerState extends State<_NotificationAppPicker> {
  late Set<String> _selected;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _selected = <String>{...widget.selected};
  }

  @override
  Widget build(BuildContext context) {
    final String query = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered =
        widget.apps.where((LaunchableAppInfo app) {
      return query.isEmpty ||
          app.label.toLowerCase().contains(query) ||
          app.packageName.toLowerCase().contains(query);
    }).toList(growable: false);
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .88,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: TextField(
                onChanged: (String value) => setState(() => _query = value),
                decoration: InputDecoration(
                  labelText: 'Search apps',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixText: '${_selected.length} selected',
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (BuildContext context, int index) {
                  final LaunchableAppInfo app = filtered[index];
                  final bool selected = _selected.contains(app.packageName);
                  return CheckboxListTile(
                    value: selected,
                    title: Text(app.label,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(app.packageName),
                    onChanged: (bool? value) => setState(() {
                      if (value == true) {
                        _selected.add(app.packageName);
                      } else {
                        _selected.remove(app.packageName);
                      }
                    }),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: FilledButton.icon(
                onPressed: () => Navigator.of(context).pop(_selected),
                icon: const Icon(Icons.check_rounded),
                label: const Text('Save selected apps'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
