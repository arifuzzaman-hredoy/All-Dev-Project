import 'package:flutter/material.dart';

import '../models/alarm_sounds.dart';
import '../services/native_bridge.dart';

class AlarmSoundPickerScreen extends StatefulWidget {
  const AlarmSoundPickerScreen({
    required this.initialSelection,
    required this.category,
    required this.taskTitle,
    super.key,
  });

  final AlarmSoundSelection initialSelection;
  final String category;
  final String taskTitle;

  @override
  State<AlarmSoundPickerScreen> createState() => _AlarmSoundPickerScreenState();
}

class _AlarmSoundPickerScreenState extends State<AlarmSoundPickerScreen> {
  final TextEditingController _searchController = TextEditingController();

  String? _previewingId;
  bool _openingPicker = false;
  String _selectedGroup = 'All';
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    NativeBridge.stopAlarmSoundPreview().catchError((_) {});
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<AlarmSoundPreset> sounds = _filteredSounds();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose alarm sound'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Stop preview',
            onPressed: _previewingId == null ? null : _stopPreview,
            icon: const Icon(Icons.stop_circle_outlined),
          ),
        ],
      ),
      body: CustomScrollView(
        key: const PageStorageKey<String>('alarm-sound-list'),
        slivers: <Widget>[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: _LibraryHeader(
                soundCount: AlarmSoundCatalog.builtInSoundCount,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
              child: TextField(
                key: const ValueKey<String>('alarm-sound-search'),
                controller: _searchController,
                textInputAction: TextInputAction.search,
                onChanged: (String value) {
                  setState(() => _query = value.trim().toLowerCase());
                },
                decoration: InputDecoration(
                  hintText: 'Search 216 built-in sounds',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Clear search',
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _query = '');
                          },
                          icon: const Icon(Icons.close_rounded),
                        ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 48,
              child: ListView.separated(
                key: const ValueKey<String>('alarm-sound-group-filter'),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                scrollDirection: Axis.horizontal,
                itemCount: AlarmSoundCatalog.groups.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (BuildContext context, int index) {
                  final String group = AlarmSoundCatalog.groups[index];
                  return ChoiceChip(
                    label: Text(group),
                    selected: _selectedGroup == group,
                    onSelected: (_) {
                      setState(() => _selectedGroup = group);
                    },
                  );
                },
              ),
            ),
          ),
          if (sounds.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'No alarm sounds match this search.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 116),
              sliver: SliverList.separated(
                itemCount: sounds.length,
                separatorBuilder: (_, __) => const SizedBox(height: 2),
                itemBuilder: (BuildContext context, int index) {
                  final AlarmSoundPreset preset = sounds[index];
                  final bool selected = widget.initialSelection.id == preset.id;
                  final bool previewing = _previewingId == preset.id;
                  return Card(
                    elevation: 0,
                    child: ListTile(
                      key: ValueKey<String>('alarm-sound-${preset.id}'),
                      leading: CircleAvatar(
                        child: Icon(_iconFor(preset.id), size: 21),
                      ),
                      title: Text(
                        preset.label,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text('${preset.group} • ${preset.description}'),
                      selected: selected,
                      onTap: () => Navigator.of(context).pop(preset.selection),
                      trailing: IconButton(
                        tooltip: previewing ? 'Stop preview' : 'Preview sound',
                        onPressed: () => _preview(preset.selection),
                        icon: Icon(
                          previewing
                              ? Icons.stop_circle_rounded
                              : Icons.play_circle_outline_rounded,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _openingPicker ? null : _pickSystemSound,
                icon: const Icon(Icons.phone_android_rounded),
                label: const Text('Phone tones'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: _openingPicker ? null : _pickCustomAudio,
                icon: const Icon(Icons.audio_file_rounded),
                label: const Text('My audio'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<AlarmSoundPreset> _filteredSounds() {
    final List<AlarmSoundPreset> source = AlarmSoundCatalog.builtIns;
    return source.where((AlarmSoundPreset preset) {
      final bool isSmart = preset.id == AlarmSoundCatalog.smartId;
      final bool groupMatches = _selectedGroup == 'All' ||
          preset.group == _selectedGroup ||
          (isSmart && _selectedGroup == 'All');
      if (!groupMatches) return false;
      if (_query.isEmpty) return true;
      final String searchable = <String>[
        preset.label,
        preset.group,
        preset.description,
        preset.id,
      ].join(' ').toLowerCase();
      return searchable.contains(_query);
    }).toList(growable: false);
  }

  Future<void> _preview(AlarmSoundSelection selection) async {
    if (_previewingId == selection.id) {
      await _stopPreview();
      return;
    }
    setState(() => _previewingId = selection.id);
    try {
      await NativeBridge.previewAlarmSound(
        selection: selection,
        category: widget.category,
        taskTitle: widget.taskTitle,
      );
    } catch (error) {
      if (mounted) {
        setState(() => _previewingId = null);
        _showError('Could not preview this sound: $error');
      }
    }
  }

  Future<void> _stopPreview() async {
    if (mounted) setState(() => _previewingId = null);
    await NativeBridge.stopAlarmSoundPreview().catchError((_) {});
  }

  Future<void> _pickSystemSound() async {
    setState(() => _openingPicker = true);
    await _stopPreview();
    try {
      final AlarmSoundSelection? selected =
          await NativeBridge.pickSystemAlarmSound(
        currentUri: widget.initialSelection.uri,
      );
      if (selected != null && mounted) {
        Navigator.of(context).pop(selected);
      }
    } catch (error) {
      if (mounted) _showError('Could not open phone tones: $error');
    } finally {
      if (mounted) setState(() => _openingPicker = false);
    }
  }

  Future<void> _pickCustomAudio() async {
    setState(() => _openingPicker = true);
    await _stopPreview();
    try {
      final AlarmSoundSelection? selected =
          await NativeBridge.pickCustomAlarmSound();
      if (selected != null && mounted) {
        Navigator.of(context).pop(selected);
      }
    } catch (error) {
      if (mounted) _showError('Could not add this audio file: $error');
    } finally {
      if (mounted) setState(() => _openingPicker = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  IconData _iconFor(String id) {
    switch (id) {
      case AlarmSoundCatalog.smartId:
        return Icons.auto_awesome_rounded;
      case 'focus_pulse':
      case 'deep_work':
        return Icons.center_focus_strong_rounded;
      case 'study_bell':
      case 'reading_chime':
        return Icons.menu_book_rounded;
      case 'exam_alert':
      case 'deadline_beacon':
      case 'urgent_siren':
        return Icons.priority_high_rounded;
      case 'coding_digital':
      case 'science_signal':
        return Icons.memory_rounded;
      case 'meeting_chime':
        return Icons.groups_rounded;
      case 'morning_sunrise':
        return Icons.wb_sunny_rounded;
      case 'workout_energy':
        return Icons.fitness_center_rounded;
      case 'gentle_reminder':
      case 'calm_waves':
        return Icons.spa_rounded;
      default:
        return Icons.notifications_active_rounded;
    }
  }
}

class _LibraryHeader extends StatelessWidget {
  const _LibraryHeader({required this.soundCount});

  final int soundCount;

  @override
  Widget build(BuildContext context) => Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const CircleAvatar(
                child: Icon(Icons.library_music_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '$soundCount built-in alarm sounds',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Search, filter and preview every real bundled sound. Smart mode chooses one automatically.',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
