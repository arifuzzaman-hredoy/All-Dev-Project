import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../widgets/app_drawer.dart';
import '../widgets/profile_avatar.dart';
import 'active_features_screen.dart';
import 'command_search_screen.dart';
import 'focus_game_screen.dart';
import 'study_mode_screen.dart';
import 'phone_control_screen.dart';
import 'schedule_profiles_screen.dart';
import 'social_control_screen.dart';
import 'profile_screen.dart';
import 'safety_center_screen.dart';
import 'smart_coach_screen.dart';
import 'smart_recommendations_screen.dart';
import 'protection_center_screen.dart';
import 'reels_insights_screen.dart';
import 'wellbeing_alerts_screen.dart';

class PhoneControlDashboardScreen extends StatefulWidget {
  const PhoneControlDashboardScreen({super.key});

  @override
  State<PhoneControlDashboardScreen> createState() =>
      _PhoneControlDashboardScreenState();
}

class _PhoneControlDashboardScreenState
    extends State<PhoneControlDashboardScreen> with WidgetsBindingObserver {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlDashboardSnapshot _dashboard =
      const PhoneControlDashboardSnapshot();
  NativeSystemReadiness? _readiness;
  bool _loading = true;
  bool _savingMaster = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(showSpinner: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool showSpinner = true}) async {
    if (showSpinner && mounted) setState(() => _loading = true);
    PhoneControlPolicy policy = _policy;
    PhoneControlDashboardSnapshot dashboard = _dashboard;
    NativeSystemReadiness? readiness = _readiness;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      dashboard = await NativeBridge.phoneControlDashboard();
    } catch (_) {
      try {
        final PhoneControlUsage usage = await NativeBridge.phoneControlUsage();
        dashboard = PhoneControlDashboardSnapshot(usage: usage);
      } catch (_) {}
    }
    try {
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _dashboard = dashboard;
      _readiness = readiness;
      _loading = false;
    });
  }

  Future<void> _toggleMaster() async {
    if (_savingMaster) return;
    final PhoneControlPolicy previous = _policy;
    final PhoneControlPolicy updated = previous.copyWith(
      masterEnabled: !previous.masterEnabled,
    );
    setState(() {
      _policy = updated;
      _savingMaster = true;
    });
    try {
      await NativeBridge.savePhoneControlPolicy(updated);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            updated.masterEnabled
                ? 'Phone Control is active.'
                : 'Phone Control is paused. Your saved rules are preserved.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _policy = previous);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update Phone Control: $error')),
      );
    } finally {
      if (mounted) setState(() => _savingMaster = false);
    }
  }

  Future<void> _stopAllBlocking() async {
    if (_savingMaster) return;
    setState(() => _savingMaster = true);
    try {
      final PhoneControlPolicy safe =
          await NativeBridge.emergencyStopAllBlocking();
      if (!mounted) return;
      setState(() => _policy = safe);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content:
              Text('All blocking stopped. Rules and personal data are safe.'),
        ),
      );
    } finally {
      if (mounted) setState(() => _savingMaster = false);
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
    if (mounted) await _load(showSpinner: false);
  }

  void _showHelp() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext context) => const SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'How Phone Control works',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              SizedBox(height: 12),
              Text(
                '1. Hredoy Flow auto-detects essential and distraction apps.\n'
                '2. Essential apps stay allowed automatically.\n'
                '3. Choose only the app you want to block.\n'
                '4. Use Stop all blocking at any time.\n\n'
                'Your routine, tasks, alarms, goals and focus history are separate and remain unchanged.',
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final Set<String> protectedPackages = <String>{
      ..._policy.rules
          .where((AppControlRule rule) => rule.enabled && rule.blockApp)
          .map((AppControlRule rule) => rule.packageName),
      ..._policy.profiles
          .where((ScheduleProfile profile) => profile.enabled)
          .expand((ScheduleProfile profile) => profile.blockedPackages),
    };
    final int protectedApps = protectedPackages.length;
    final bool notificationControlConfigured =
        _policy.notificationBlockerEnabled ||
            _policy.profiles.any(
              (ScheduleProfile profile) => profile.silenceNotifications,
            );
    final bool permissionsReady = (_readiness?.accessibilityEnabled ?? false) &&
        (_readiness?.usageAccessEnabled ?? false) &&
        (_readiness?.batteryOptimizationIgnored ?? false) &&
        (!notificationControlConfigured ||
            (_readiness?.notificationAccessEnabled ?? false));

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: const Text('Phone Control'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Search commands',
            onPressed: () => _open(const CommandSearchScreen()),
            icon: const Icon(Icons.search_rounded),
          ),
          TextButton.icon(
            onPressed: _showHelp,
            icon: const Icon(Icons.info_outline_rounded, size: 18),
            label: const Text('Help'),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(99),
              onTap: () => _open(const ProfileScreen()),
              child: ProfileAvatar(
                name: controller.preferences.userName,
                imageBase64: controller.preferences.profileImageBase64,
                radius: 18,
              ),
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _load(),
              child: ListView(
                key: const ValueKey<String>('phone-control-dashboard-scroll'),
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                children: <Widget>[
                  _ScreenTimeHero(
                    usage: _dashboard.usage,
                    distractionTimeMillis: _dashboard.distractionTimeMillis,
                  ),
                  const SizedBox(height: 18),
                  Center(
                    child: _MasterControlButton(
                      active: _policy.masterEnabled,
                      busy: _savingMaster,
                      onTap: _toggleMaster,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Center(
                    child: OutlinedButton.icon(
                      onPressed: _savingMaster ? null : _stopAllBlocking,
                      icon: const Icon(Icons.lock_open_rounded),
                      label: const Text('Stop all blocking'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Center(
                    child: FilledButton.tonalIcon(
                      onPressed: () => _open(
                        ActiveFeaturesScreen(
                          initialPolicy: _policy,
                          initialReadiness: _readiness,
                        ),
                      ),
                      icon: const Icon(Icons.tune_rounded),
                      label: Text(
                        '${_policy.activeFeatureCount}/11 active features',
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  _SectionTitle(
                    title: 'Reduce distraction',
                    subtitle:
                        '$protectedApps blocked by you • ${_dashboard.usage.totalBlockedAttempts} blocks today',
                  ),
                  const SizedBox(height: 10),
                  LayoutBuilder(
                    builder:
                        (BuildContext context, BoxConstraints constraints) {
                      final int columns = constraints.maxWidth < 380 ? 2 : 3;
                      return GridView.count(
                        crossAxisCount: columns,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: columns == 2 ? 1.35 : 0.78,
                        children: <Widget>[
                          _QuickActionCard(
                            icon: Icons.auto_awesome_rounded,
                            title: 'Daily Coach',
                            subtitle: 'Today’s safe plan',
                            onTap: () => _open(const SmartCoachScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.psychology_alt_rounded,
                            title: 'Recommendations',
                            subtitle: 'Review detected distractions',
                            onTap: () =>
                                _open(const SmartRecommendationsScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.health_and_safety_rounded,
                            title: 'Safety Center',
                            subtitle: 'Preview & stop all',
                            onTap: () => _open(const SafetyCenterScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.menu_book_rounded,
                            title: 'Study Mode',
                            subtitle: 'Protected focus',
                            onTap: () => _open(const StudyModeScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.calendar_month_rounded,
                            title: 'Schedule profiles',
                            subtitle: '${_policy.profiles.length} recurring',
                            badge: _policy.scheduleProfilesEnabled &&
                                    _policy.profiles.isNotEmpty
                                ? 'ON'
                                : null,
                            onTap: () => _open(const ScheduleProfilesScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.smart_display_rounded,
                            title: 'Reels limits',
                            subtitle: 'Per-app counts & warnings',
                            badge: _policy.rules
                                    .where((AppControlRule rule) =>
                                        rule.reelsGuard)
                                    .isEmpty
                                ? null
                                : '${_policy.rules.where((AppControlRule rule) => rule.reelsGuard).length}',
                            onTap: () => _open(const ReelsInsightsScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.notifications_active_rounded,
                            title: 'Screen warnings',
                            subtitle: 'Goal & over-limit alerts',
                            badge:
                                _policy.wellbeingWarningsEnabled ? 'ON' : null,
                            onTap: () => _open(const WellbeingAlertsScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.notifications_off_rounded,
                            title: 'Social control',
                            subtitle: 'Notifications & Reels',
                            badge: _policy.notificationBlockerEnabled
                                ? 'ON'
                                : null,
                            onTap: () => _open(const SocialControlScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.shield_rounded,
                            title: 'Protection Center',
                            subtitle: 'Web, DNS & Prime Mode',
                            badge: _policy.masterEnabled ? 'READY' : null,
                            onTap: () => _open(const ProtectionCenterScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.rule_rounded,
                            title: 'App rules & limits',
                            subtitle: 'Hours and daily limits',
                            badge: _policy.rules.isEmpty
                                ? null
                                : '${_policy.rules.length}',
                            onTap: () => _open(const PhoneControlScreen()),
                          ),
                          _QuickActionCard(
                            icon: Icons.park_rounded,
                            title: 'Focus Tree',
                            subtitle: 'Grow with study',
                            onTap: () => _open(const FocusGameScreen()),
                          ),
                          _QuickActionCard(
                            icon: permissionsReady
                                ? Icons.verified_user_rounded
                                : Icons.warning_amber_rounded,
                            title: 'Permissions',
                            subtitle:
                                permissionsReady ? 'All ready' : 'Setup needed',
                            badge: permissionsReady ? 'READY' : 'FIX',
                            onTap: () => _open(
                              ActiveFeaturesScreen(
                                initialPolicy: _policy,
                                initialReadiness: _readiness,
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionTitle(
                    title: 'Distraction trend',
                    subtitle:
                        'Actual controlled-app usage from the last 7 days',
                  ),
                  const SizedBox(height: 10),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                      child: PhoneControlTrendChart(
                        days: _dashboard.weekly,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  _ReadinessSummary(
                    readiness: _readiness,
                    onAccessibility: NativeBridge.openAccessibilitySettings,
                    onUsage: NativeBridge.openUsageAccessSettings,
                    onBattery: NativeBridge.requestBatteryOptimizationExemption,
                    onNotification: NativeBridge.openNotificationAccessSettings,
                  ),
                  const SizedBox(height: 18),
                  _ControlledAppsSummary(
                    policy: _policy,
                    usage: _dashboard.usage,
                    onOpen: () => _open(const PhoneControlScreen()),
                  ),
                ],
              ),
            ),
    );
  }
}

class _ScreenTimeHero extends StatelessWidget {
  const _ScreenTimeHero({
    required this.usage,
    required this.distractionTimeMillis,
  });

  final PhoneControlUsage usage;
  final int distractionTimeMillis;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    final bool hasUsageData = usage.screenTimeSource != 'unavailable';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            colors.primaryContainer.withValues(alpha: .72),
            colors.surfaceContainerLow,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outlineVariant),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: colors.surface.withValues(alpha: .58),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.timelapse_rounded),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'TODAY’S SCREEN TIME',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        letterSpacing: .8,
                        fontSize: 11,
                      ),
                    ),
                    Text(
                      hasUsageData
                          ? '12:00 AM to now • ${usage.screenTimeSourceLabel}'
                          : 'Enable Usage Access for Android screen-time data',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              if (hasUsageData) const Icon(Icons.verified_rounded, size: 20),
            ],
          ),
          const SizedBox(height: 18),
          IntrinsicHeight(
            child: Row(
              children: <Widget>[
                Expanded(
                  child: _HeroMetric(
                    label: 'Total screen time',
                    value: formatUsageDuration(usage.totalScreenTimeMillis),
                    color: colors.onSurface,
                  ),
                ),
                VerticalDivider(color: colors.outlineVariant),
                Expanded(
                  child: _HeroMetric(
                    label: 'Controlled-app time',
                    value: formatUsageDuration(distractionTimeMillis),
                    color: colors.error,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Icon(
                hasUsageData
                    ? Icons.schedule_rounded
                    : Icons.info_outline_rounded,
                size: 16,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  hasUsageData
                      ? 'Daily totals automatically roll over at local midnight; manual counter clearing cannot reset app-minute limits.'
                      : 'Screen time is unavailable until Android grants Usage Access.',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroMetric extends StatelessWidget {
  const _HeroMetric({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => Column(
        children: <Widget>[
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: color,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.8,
                  ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.labelMedium,
          ),
        ],
      );
}

class _MasterControlButton extends StatelessWidget {
  const _MasterControlButton({
    required this.active,
    required this.busy,
    required this.onTap,
  });

  final bool active;
  final bool busy;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    final Color accent = active ? colors.primary : colors.outline;
    return Semantics(
      button: true,
      label: active ? 'Pause Phone Control' : 'Start Phone Control',
      child: InkWell(
        key: const ValueKey<String>('phone-control-master-button'),
        onTap: busy ? null : onTap,
        customBorder: const CircleBorder(),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          width: 124,
          height: 124,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: colors.surfaceContainerHigh,
            border: Border.all(color: accent, width: active ? 3 : 1.5),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: accent.withValues(alpha: active ? 0.24 : 0.08),
                blurRadius: active ? 28 : 14,
                spreadRadius: active ? 5 : 1,
              ),
            ],
          ),
          child: Center(
            child: busy
                ? const SizedBox.square(
                    dimension: 28,
                    child: CircularProgressIndicator(strokeWidth: 3),
                  )
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Icon(
                        active
                            ? Icons.shield_rounded
                            : Icons.play_arrow_rounded,
                        size: 42,
                        color: accent,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        active ? 'ACTIVE' : 'START',
                        style: TextStyle(
                          color: accent,
                          fontWeight: FontWeight.w900,
                          fontSize: 11,
                          letterSpacing: 1.1,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title.toUpperCase(),
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.9,
                ),
          ),
          const SizedBox(height: 3),
          Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
        ],
      );
}

class _QuickActionCard extends StatelessWidget {
  const _QuickActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badge,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    CircleAvatar(
                      radius: 19,
                      child: Icon(icon, size: 21),
                    ),
                    const Spacer(),
                    if (badge != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          badge!,
                          style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                  ],
                ),
                const Spacer(),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
      );
}

class PhoneControlTrendChart extends StatelessWidget {
  const PhoneControlTrendChart({required this.days, super.key});

  final List<PhoneControlDayUsage> days;

  @override
  Widget build(BuildContext context) {
    final List<PhoneControlDayUsage> visible =
        days.length <= 7 ? days : days.sublist(days.length - 7);
    final List<PhoneControlDayUsage> normalized = visible.isEmpty
        ? List<PhoneControlDayUsage>.generate(
            7,
            (int index) => PhoneControlDayUsage(
              date: DateTime.now()
                  .subtract(Duration(days: 6 - index))
                  .toIso8601String(),
            ),
          )
        : visible;
    final int weeklyMillis = normalized.fold<int>(
      0,
      (int total, PhoneControlDayUsage day) =>
          total + day.distractionTimeMillis,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'CONTROLLED-APP TIME',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    formatUsageDuration(weeklyMillis),
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                ],
              ),
            ),
            Text(
              'Last 7 days',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
        const SizedBox(height: 14),
        SizedBox(
          key: const ValueKey<String>('phone-control-weekly-chart'),
          height: 132,
          width: double.infinity,
          child: CustomPaint(
            painter: _PhoneControlTrendPainter(
              values: normalized
                  .map((PhoneControlDayUsage day) =>
                      day.distractionTimeMillis.toDouble())
                  .toList(growable: false),
              lineColor: Theme.of(context).colorScheme.primary,
              gridColor: Theme.of(context).colorScheme.outlineVariant,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: normalized.map((PhoneControlDayUsage day) {
            final DateTime? date = day.parsedDate;
            final String label = date == null
                ? '—'
                : const <String>[
                    'M',
                    'T',
                    'W',
                    'T',
                    'F',
                    'S',
                    'S'
                  ][date.weekday - 1];
            return SizedBox(
              width: 24,
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelSmall,
              ),
            );
          }).toList(growable: false),
        ),
      ],
    );
  }
}

class _PhoneControlTrendPainter extends CustomPainter {
  const _PhoneControlTrendPainter({
    required this.values,
    required this.lineColor,
    required this.gridColor,
  });

  final List<double> values;
  final Color lineColor;
  final Color gridColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty || size.width <= 0 || size.height <= 0) return;
    final Paint grid = Paint()
      ..color = gridColor.withValues(alpha: 0.45)
      ..strokeWidth = 1;
    for (int index = 1; index <= 3; index++) {
      final double y = size.height * index / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final double maximum = math.max(
      1.0,
      values.fold<double>(
        0.0,
        (double current, double value) => math.max(current, value),
      ),
    );
    final double step =
        values.length == 1 ? 0 : size.width / (values.length - 1);
    final List<Offset> points =
        List<Offset>.generate(values.length, (int index) {
      final double ratio = (values[index] / maximum).clamp(0.0, 1.0);
      return Offset(index * step, size.height - ratio * (size.height - 12) - 6);
    });

    final Path line = Path()..moveTo(points.first.dx, points.first.dy);
    for (int index = 1; index < points.length; index++) {
      final Offset previous = points[index - 1];
      final Offset current = points[index];
      final double midpoint = (previous.dx + current.dx) / 2;
      line.cubicTo(
        midpoint,
        previous.dy,
        midpoint,
        current.dy,
        current.dx,
        current.dy,
      );
    }

    final Path area = Path.from(line)
      ..lineTo(points.last.dx, size.height)
      ..lineTo(points.first.dx, size.height)
      ..close();
    final Paint fill = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          lineColor.withValues(alpha: 0.26),
          lineColor.withValues(alpha: 0.01),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawPath(area, fill);
    canvas.drawPath(
      line,
      Paint()
        ..color = lineColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    final Paint dot = Paint()..color = lineColor;
    final Paint dotCenter = Paint()..color = Colors.white;
    for (final Offset point in points) {
      canvas.drawCircle(point, 4, dot);
      canvas.drawCircle(point, 1.7, dotCenter);
    }
  }

  @override
  bool shouldRepaint(covariant _PhoneControlTrendPainter oldDelegate) =>
      oldDelegate.values != values ||
      oldDelegate.lineColor != lineColor ||
      oldDelegate.gridColor != gridColor;
}

class _ReadinessSummary extends StatelessWidget {
  const _ReadinessSummary({
    required this.readiness,
    required this.onAccessibility,
    required this.onUsage,
    required this.onBattery,
    required this.onNotification,
  });

  final NativeSystemReadiness? readiness;
  final VoidCallback onAccessibility;
  final VoidCallback onUsage;
  final VoidCallback onBattery;
  final VoidCallback onNotification;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'PERMISSIONS',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.9,
                ),
              ),
              const SizedBox(height: 8),
              _ReadinessRow(
                label: 'Accessibility Service',
                ready: readiness?.accessibilityEnabled ?? false,
                onTap: onAccessibility,
              ),
              _ReadinessRow(
                label: 'Usage Stats Access',
                ready: readiness?.usageAccessEnabled ?? false,
                onTap: onUsage,
              ),
              _ReadinessRow(
                label: 'Notification Access',
                ready: readiness?.notificationAccessEnabled ?? false,
                onTap: onNotification,
              ),
              _ReadinessRow(
                label: 'Background reliability',
                ready: readiness?.batteryOptimizationIgnored ?? false,
                onTap: onBattery,
              ),
            ],
          ),
        ),
      );
}

class _ReadinessRow extends StatelessWidget {
  const _ReadinessRow({
    required this.label,
    required this.ready,
    required this.onTap,
  });

  final String label;
  final bool ready;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        leading: Icon(
          ready ? Icons.check_circle_rounded : Icons.error_outline_rounded,
          color: ready
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.error,
        ),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(ready ? 'Enabled' : 'Required'),
        trailing: TextButton(
          onPressed: onTap,
          child: Text(ready ? 'View' : 'Enable'),
        ),
      );
}

class _ControlledAppsSummary extends StatelessWidget {
  const _ControlledAppsSummary({
    required this.policy,
    required this.usage,
    required this.onOpen,
  });

  final PhoneControlPolicy policy;
  final PhoneControlUsage usage;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final List<AppControlRule> rules = <AppControlRule>[...policy.rules]
      ..sort((AppControlRule a, AppControlRule b) {
        final int usageOrder = usage
            .usageMinutesFor(b.packageName)
            .compareTo(usage.usageMinutesFor(a.packageName));
        if (usageOrder != 0) return usageOrder;
        return a.label.toLowerCase().compareTo(b.label.toLowerCase());
      });
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Expanded(
                  child: Text(
                    'CONTROLLED APPS',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.9,
                    ),
                  ),
                ),
                TextButton.icon(
                  onPressed: onOpen,
                  icon: const Icon(Icons.tune_rounded, size: 18),
                  label: const Text('Manage'),
                ),
              ],
            ),
            if (rules.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'No apps added yet. Add distracting apps and set their allowed hours.',
                ),
              )
            else
              ...rules.take(4).map(
                    (AppControlRule rule) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      leading: CircleAvatar(
                        radius: 18,
                        child: Text(
                          rule.label.isEmpty
                              ? '?'
                              : rule.label.substring(0, 1).toUpperCase(),
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                      title: Text(
                        rule.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text(rule.scheduleLabel()),
                      trailing: Text(
                        formatUsageDuration(
                          usage.usageMillis[rule.packageName] ?? 0,
                        ),
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
