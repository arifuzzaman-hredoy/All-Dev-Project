import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../controllers/smart_flow_controller.dart';
import '../models/app_models.dart';
import '../models/smart_flow.dart';
import '../widgets/common_widgets.dart';
import '../widgets/root_navigation.dart';
import 'phone_control_dashboard_screen.dart';
import 'safety_center_screen.dart';
import 'study_mode_screen.dart';
import 'weekly_report_screen.dart';

class SmartCoachScreen extends StatelessWidget {
  const SmartCoachScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController app = AppScope.of(context);
    final SmartFlowController smart = SmartFlowScope.of(context);
    final DateTime now = DateTime.now();
    final List<SmartCoachItem> plan = _buildPlan(app, now);
    final TaskItem? current = app.currentTaskAt(now);
    final int completion = app.completionPercent(now);
    final int focusMinutes = app.focusMinutesFor(now);

    return Scaffold(
      appBar: AppBar(title: const Text('Daily Coach')),
      body: ListView(
        key: const ValueKey<String>('daily-coach-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.auto_awesome_rounded),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _greeting(now),
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                    ),
                    Switch.adaptive(
                      value: smart.settings.dailyCoachEnabled,
                      onChanged: smart.setDailyCoachEnabled,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  current == null
                      ? 'No task is active now. Your next useful action is ready below.'
                      : 'Current action: ${current.title} until ${formatTime(current.endAt)}.',
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    Chip(label: Text('$completion% tasks today')),
                    Chip(label: Text('$focusMinutes focus min')),
                    Chip(label: Text('${app.currentStreak} day streak')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const SectionHeader(
            title: 'Today’s top actions',
            subtitle:
                'Coach suggestions never activate blocking without your confirmation.',
          ),
          const SizedBox(height: 10),
          ...plan.map(
            (SmartCoachItem item) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${item.priority}')),
                title: Text(
                  item.title,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: Text(item.detail),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => _openAction(context, item.actionId),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionHeader(
            title: 'Quick plan',
            subtitle: 'Four clear places instead of duplicate controls.',
          ),
          const SizedBox(height: 10),
          LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
              final int columns = constraints.maxWidth < 380 ? 1 : 2;
              return GridView.count(
                crossAxisCount: columns,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: columns == 1 ? 3.2 : 1.35,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: <Widget>[
                  _CoachAction(
                    icon: Icons.school_rounded,
                    title: 'Study plan',
                    subtitle: 'Schedule and allowed apps',
                    onTap: () => _open(context, const StudyModeScreen()),
                  ),
                  _CoachAction(
                    icon: Icons.phonelink_lock_rounded,
                    title: 'Phone limits',
                    subtitle: 'Review recommendations first',
                    onTap: () =>
                        _open(context, const PhoneControlDashboardScreen()),
                  ),
                  _CoachAction(
                    icon: Icons.health_and_safety_rounded,
                    title: 'Safety Center',
                    subtitle: 'Preview and emergency stop',
                    onTap: () => _open(context, const SafetyCenterScreen()),
                  ),
                  _CoachAction(
                    icon: Icons.summarize_rounded,
                    title: 'Weekly report',
                    subtitle: 'Tasks, focus and best day',
                    onTap: () => _open(context, const WeeklyReportScreen()),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 16),
          Card(
            child: SwitchListTile.adaptive(
              title: const Text(
                'Show Daily Coach shortcuts',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: const Text(
                'Shows Daily Coach in Simple navigation. Task and focus analysis stays local.',
              ),
              value: smart.settings.dailyCoachEnabled,
              onChanged: smart.setDailyCoachEnabled,
            ),
          ),
        ],
      ),
    );
  }

  List<SmartCoachItem> _buildPlan(AppController app, DateTime now) {
    final List<SmartCoachItem> result = <SmartCoachItem>[];
    final TaskItem? current = app.currentTaskAt(now);
    if (current != null) {
      result.add(
        SmartCoachItem(
          title: current.title,
          detail:
              '${formatTime(current.startAt)}–${formatTime(current.endAt)} • finish the active task first',
          priority: 1,
          actionId: 'study',
        ),
      );
    }
    if (app.overdueTaskCount > 0) {
      result.add(
        SmartCoachItem(
          title: 'Clear ${app.overdueTaskCount} overdue task${app.overdueTaskCount == 1 ? '' : 's'}',
          detail: 'Pick the smallest overdue action and finish it before adding more.',
          priority: result.length + 1,
          actionId: 'planner',
        ),
      );
    }
    for (final TaskItem task in app.upcomingTasks.take(3)) {
      if (result.length >= 3) break;
      result.add(
        SmartCoachItem(
          title: task.title,
          detail: '${formatDate(task.startAt)} at ${formatTime(task.startAt)}',
          priority: result.length + 1,
          actionId: 'planner',
        ),
      );
    }
    if (result.isEmpty) {
      result.add(
        const SmartCoachItem(
          title: 'Plan one meaningful task',
          detail: 'Keep today simple: one task, one focus session, one review.',
          priority: 1,
          actionId: 'planner',
        ),
      );
    }
    return result.take(3).toList(growable: false);
  }

  String _greeting(DateTime now) {
    if (now.hour < 12) return 'Good morning — make the first hour count';
    if (now.hour < 18) return 'Good afternoon — protect the next action';
    return 'Good evening — finish calmly and review';
  }

  void _openAction(BuildContext context, String actionId) {
    switch (actionId) {
      case 'study':
        _open(context, const StudyModeScreen());
        return;
      case 'planner':
        RootTabNavigation.select(1);
        Navigator.of(context).popUntil((Route<dynamic> route) => route.isFirst);
        return;
      default:
        return;
    }
  }

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }
}

class _CoachAction extends StatelessWidget {
  const _CoachAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: <Widget>[
                CircleAvatar(child: Icon(icon)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        title,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text(subtitle),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}
