import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/alarm_sounds.dart';
import '../models/app_models.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';
import 'alarm_sound_picker_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with WidgetsBindingObserver {
  static const Map<String, String> _knownApps = <String, String>{
    'com.facebook.katana': 'Facebook',
    'com.facebook.orca': 'Messenger',
    'com.instagram.android': 'Instagram',
    'com.zhiliaoapp.musically': 'TikTok',
    'com.google.android.youtube': 'YouTube',
    'com.android.chrome': 'Chrome',
    'com.twitter.android': 'X / Twitter',
    'com.snapchat.android': 'Snapchat',
  };

  static const List<Color> _accentColors = <Color>[
    Color(0xFF55B84D),
    Color(0xFF4F7CFF),
    Color(0xFFB15CFF),
    Color(0xFFFFA62B),
    Color(0xFFE35768),
    Color(0xFF18B6A4),
  ];

  String _customPackage = '';
  String _appSearch = '';
  Key _customPackageFieldKey = UniqueKey();
  Set<String> _blocked = <String>{};
  List<LaunchableAppInfo> _installedApps = const <LaunchableAppInfo>[];
  NativeSystemReadiness? _readiness;
  bool _useDnd = true;
  bool _autoFocus = false;
  bool _loading = true;
  bool _refreshing = false;
  int? _focusMinutesDraft;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadNative();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshReadiness();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    NativeBridge.stopAlarmSoundPreview().catchError((_) {});
    super.dispose();
  }

  Future<void> _loadNative() async {
    NativeSettings? settings;
    NativeSystemReadiness? readiness;
    List<LaunchableAppInfo> apps = const <LaunchableAppInfo>[];

    try {
      settings = await NativeBridge.settings();
    } catch (_) {
      // Keep the page usable even before Android channels are available.
    }
    try {
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {
      // Status cards remain in an unknown state.
    }
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {
      // The package-name fallback remains available.
    }

    if (!mounted) return;
    setState(() {
      _blocked = settings?.blockedPackages ?? <String>{};
      _useDnd = settings?.useDnd ?? true;
      _autoFocus = settings?.autoFocus ?? false;
      _readiness = readiness;
      _installedApps = apps;
      _loading = false;
    });
  }

  Future<void> _refreshReadiness() async {
    if (_refreshing) return;
    setState(() => _refreshing = true);
    try {
      final NativeSystemReadiness readiness =
          await NativeBridge.systemReadiness();
      final List<LaunchableAppInfo> apps = _installedApps.isEmpty
          ? await NativeBridge.launchableApps()
          : _installedApps;
      if (mounted) {
        setState(() {
          _readiness = readiness;
          _installedApps = apps;
        });
      }
    } catch (_) {
      // Keep the previous status when Android cannot answer.
    } finally {
      if (mounted) setState(() => _refreshing = false);
    }
  }

  List<LaunchableAppInfo> get _filteredApps {
    final String query = _appSearch.trim().toLowerCase();
    return _installedApps
        .where((LaunchableAppInfo app) => !app.protected)
        .where(
          (LaunchableAppInfo app) =>
              query.isEmpty ||
              app.label.toLowerCase().contains(query) ||
              app.packageName.toLowerCase().contains(query),
        )
        .toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final AppPreferencesModel preferences = controller.preferences;

    return Scaffold(
      appBar: AppBar(
        title: const Text('App & Phone Control'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Refresh phone readiness',
            onPressed: _refreshing ? null : _refreshReadiness,
            icon: _refreshing
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: <Widget>[
                _SystemReadinessCard(
                  readiness: _readiness,
                  onNotifications: NativeBridge.requestNotificationPermission,
                  onExactAlarm: NativeBridge.openExactAlarmSettings,
                  onFullScreen: NativeBridge.openFullScreenAlarmSettings,
                  onAccessibility: NativeBridge.openAccessibilitySettings,
                  onBattery: NativeBridge.requestBatteryOptimizationExemption,
                ),
                const SizedBox(height: 22),
                const SectionHeader(
                  title: 'Profile & Exam',
                  subtitle: 'Countdowns, routine and default focus duration',
                ),
                const SizedBox(height: 10),
                TextFormField(
                  initialValue: preferences.userName,
                  decoration: const InputDecoration(
                    labelText: 'Your name',
                    prefixIcon: Icon(Icons.person_rounded),
                  ),
                  onFieldSubmitted: (String value) =>
                      controller.updatePreferences(
                    preferences.copyWith(
                      userName: value.trim().isEmpty ? 'Hredoy' : value.trim(),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            _pickTarget(controller, syllabus: true),
                        icon: const Icon(Icons.menu_book_rounded),
                        label: Text(
                          'Syllabus ${formatDate(preferences.syllabusTarget)}',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            _pickTarget(controller, syllabus: false),
                        icon: const Icon(Icons.school_rounded),
                        label: Text(
                          'Exam ${formatDate(preferences.examDate)}',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Default focus: ${_focusMinutesDraft ?? preferences.defaultFocusMinutes} min',
                ),
                Slider(
                  value: (_focusMinutesDraft ?? preferences.defaultFocusMinutes)
                      .toDouble(),
                  min: 10,
                  max: 180,
                  divisions: 17,
                  label:
                      '${_focusMinutesDraft ?? preferences.defaultFocusMinutes} min',
                  onChanged: (double value) =>
                      setState(() => _focusMinutesDraft = value.round()),
                  onChangeEnd: (double value) async {
                    final int minutes = value.round();
                    setState(() => _focusMinutesDraft = null);
                    await controller.updatePreferences(
                      controller.preferences.copyWith(
                        defaultFocusMinutes: minutes,
                      ),
                    );
                  },
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Show completed tasks'),
                  value: preferences.showCompleted,
                  onChanged: (bool value) => controller.updatePreferences(
                    preferences.copyWith(showCompleted: value),
                  ),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Full-screen alarm for new tasks'),
                  subtitle: const Text(
                    'New tasks ring and open the alarm screen by default.',
                  ),
                  value: preferences.defaultTaskAlarm,
                  onChanged: (bool value) => controller.updatePreferences(
                    preferences.copyWith(defaultTaskAlarm: value),
                  ),
                ),
                DropdownButtonFormField<int>(
                  isExpanded: true,
                  initialValue: preferences.defaultSnoozeMinutes,
                  decoration: const InputDecoration(
                    labelText: 'Default snooze duration',
                    prefixIcon: Icon(Icons.snooze_rounded),
                  ),
                  items: const <DropdownMenuItem<int>>[
                    DropdownMenuItem<int>(value: 5, child: Text('5 minutes')),
                    DropdownMenuItem<int>(value: 10, child: Text('10 minutes')),
                    DropdownMenuItem<int>(value: 15, child: Text('15 minutes')),
                    DropdownMenuItem<int>(value: 30, child: Text('30 minutes')),
                  ],
                  onChanged: (int? value) {
                    if (value == null) return;
                    controller.updatePreferences(
                      controller.preferences.copyWith(
                        defaultSnoozeMinutes: value,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 10),
                Card(
                  elevation: 0,
                  child: ListTile(
                    key: const ValueKey<String>('default-alarm-sound-tile'),
                    leading: const CircleAvatar(
                      child: Icon(Icons.music_note_rounded),
                    ),
                    title: const Text(
                      'Default alarm sound',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(
                      AlarmSoundCatalog.safeLabel(
                        preferences.defaultAlarmSoundId,
                        preferences.defaultAlarmSoundLabel,
                      ),
                    ),
                    onTap: () => _chooseDefaultAlarmSound(controller),
                    trailing: IconButton(
                      tooltip: 'Preview default sound',
                      onPressed: () => _previewDefaultAlarmSound(controller),
                      icon: const Icon(Icons.play_circle_outline_rounded),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const SectionHeader(title: 'Theme'),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: const <ButtonSegment<String>>[
                    ButtonSegment<String>(
                      value: 'system',
                      label: Text('System'),
                    ),
                    ButtonSegment<String>(value: 'light', label: Text('Light')),
                    ButtonSegment<String>(value: 'dark', label: Text('Dark')),
                  ],
                  selected: <String>{preferences.themeMode},
                  onSelectionChanged: (Set<String> value) =>
                      controller.updatePreferences(
                    preferences.copyWith(themeMode: value.first),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 9,
                  runSpacing: 9,
                  children: _accentColors.map((Color color) {
                    final bool selected =
                        preferences.accentValue == color.toARGB32();
                    return InkWell(
                      borderRadius: BorderRadius.circular(99),
                      onTap: () => controller.updatePreferences(
                        preferences.copyWith(accentValue: color.toARGB32()),
                      ),
                      child: CircleAvatar(
                        backgroundColor: color,
                        child: selected
                            ? const Icon(Icons.check_rounded,
                                color: Colors.white)
                            : null,
                      ),
                    );
                  }).toList(growable: false),
                ),
                const SizedBox(height: 24),
                const SectionHeader(
                  title: 'Alarm & Android access',
                  subtitle: 'Open any missing system permission, then refresh',
                ),
                const SizedBox(height: 10),
                _PermissionButton(
                  icon: Icons.notifications_active_rounded,
                  title: 'Notification settings',
                  onPressed: NativeBridge.openNotificationSettings,
                ),
                _PermissionButton(
                  icon: Icons.alarm_on_rounded,
                  title: 'Exact alarm access',
                  onPressed: NativeBridge.openExactAlarmSettings,
                ),
                _PermissionButton(
                  icon: Icons.fullscreen_rounded,
                  title: 'Full-screen alarm access',
                  onPressed: NativeBridge.openFullScreenAlarmSettings,
                ),
                _PermissionButton(
                  icon: Icons.app_blocking_rounded,
                  title: 'Accessibility App Blocker',
                  onPressed: NativeBridge.openAccessibilitySettings,
                ),
                _PermissionButton(
                  icon: Icons.do_not_disturb_on_rounded,
                  title: 'Do Not Disturb access',
                  onPressed: NativeBridge.openDndSettings,
                ),
                _PermissionButton(
                  icon: Icons.battery_saver_rounded,
                  title: 'Request battery Unrestricted access',
                  onPressed: NativeBridge.requestBatteryOptimizationExemption,
                ),
                _PermissionButton(
                  icon: Icons.alarm_add_rounded,
                  title: 'Test full-screen task alarm',
                  onPressed: () => NativeBridge.testTaskAlarm(
                    selection: AlarmSoundSelection(
                      id: preferences.defaultAlarmSoundId,
                      label: preferences.defaultAlarmSoundLabel,
                      uri: preferences.defaultAlarmSoundUri,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const SectionHeader(title: 'Focus Shield'),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Auto-start focus on eligible task'),
                  subtitle: const Text(
                    'Blocking begins automatically for routine tasks marked Auto Focus.',
                  ),
                  value: _autoFocus,
                  onChanged: (bool value) => setState(() => _autoFocus = value),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Do Not Disturb during focus'),
                  value: _useDnd,
                  onChanged: (bool value) => setState(() => _useDnd = value),
                ),
                const SizedBox(height: 8),
                _InstalledAppPicker(
                  apps: _filteredApps,
                  blocked: _blocked,
                  onSearchChanged: (String value) =>
                      setState(() => _appSearch = value),
                  onChanged: (String packageName, bool selected) {
                    setState(() {
                      selected
                          ? _blocked.add(packageName)
                          : _blocked.remove(packageName);
                    });
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: TextFormField(
                        key: _customPackageFieldKey,
                        initialValue: _customPackage,
                        decoration: const InputDecoration(
                          labelText: 'Manual package name',
                          hintText: 'Android package name',
                        ),
                        onChanged: (String value) => _customPackage = value,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      tooltip: 'Add package',
                      onPressed: _addCustomPackage,
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ],
                ),
                if (_blocked.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: _blocked
                        .where(
                          (String package) => !_installedApps.any(
                            (LaunchableAppInfo app) =>
                                app.packageName == package,
                          ),
                        )
                        .map(
                          (String package) => InputChip(
                            label: Text(_knownApps[package] ?? package),
                            onDeleted: () =>
                                setState(() => _blocked.remove(package)),
                          ),
                        )
                        .toList(growable: false),
                  ),
                ],
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: _saveNative,
                  icon: const Icon(Icons.shield_rounded),
                  label: const Text('Save Focus Shield settings'),
                ),
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'Do not block emergency, phone, banking, authenticator, launcher, Settings or trusted-contact apps.',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    Navigator.of(context)
                        .popUntil((Route<dynamic> route) => route.isFirst);
                    await controller.showOnboardingAgain();
                  },
                  icon: const Icon(Icons.slideshow_rounded),
                  label: const Text('Show welcome slider again'),
                ),
                const SizedBox(height: 12),
                const Card(
                  child: ListTile(
                    leading: Icon(Icons.favorite_rounded),
                    title: Text('Hredoy Flow'),
                    subtitle: Text(
                      'Personal productivity system for Md Arifuzzaman Hredoy.',
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _chooseDefaultAlarmSound(AppController controller) async {
    final AppPreferencesModel preferences = controller.preferences;
    final AlarmSoundSelection? selected =
        await Navigator.of(context).push<AlarmSoundSelection>(
      MaterialPageRoute<AlarmSoundSelection>(
        builder: (_) => AlarmSoundPickerScreen(
          initialSelection: AlarmSoundSelection(
            id: preferences.defaultAlarmSoundId,
            label: preferences.defaultAlarmSoundLabel,
            uri: preferences.defaultAlarmSoundUri,
          ),
          category: 'General',
          taskTitle: 'Hredoy Flow test alarm',
        ),
      ),
    );
    if (selected == null || !mounted) return;
    await controller.updatePreferences(
      controller.preferences.copyWith(
        defaultAlarmSoundId: selected.id,
        defaultAlarmSoundLabel: selected.label,
        defaultAlarmSoundUri: selected.uri,
      ),
    );
  }

  Future<void> _previewDefaultAlarmSound(AppController controller) async {
    final AppPreferencesModel preferences = controller.preferences;
    try {
      await NativeBridge.previewAlarmSound(
        selection: AlarmSoundSelection(
          id: preferences.defaultAlarmSoundId,
          label: preferences.defaultAlarmSoundLabel,
          uri: preferences.defaultAlarmSoundUri,
        ),
        category: 'General',
        taskTitle: 'Hredoy Flow test alarm',
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not preview alarm sound: $error')),
      );
    }
  }

  Future<void> _pickTarget(
    AppController controller, {
    required bool syllabus,
  }) async {
    final AppPreferencesModel preferences = controller.preferences;
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: syllabus ? preferences.syllabusTarget : preferences.examDate,
      firstDate: DateTime(2025),
      lastDate: DateTime(2030),
    );
    if (picked == null) return;
    await controller.updatePreferences(
      syllabus
          ? preferences.copyWith(syllabusTarget: picked)
          : preferences.copyWith(examDate: picked),
    );
  }

  void _addCustomPackage() {
    final String value = _customPackage.trim();
    if (value.isEmpty || !value.contains('.')) return;
    setState(() {
      _blocked.add(value);
      _customPackage = '';
      _customPackageFieldKey = UniqueKey();
    });
  }

  Future<void> _saveNative() async {
    try {
      await NativeBridge.saveSettings(
        blockedPackages: _blocked,
        useDnd: _useDnd,
        autoFocus: _autoFocus,
      );
      await _refreshReadiness();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Focus Shield settings saved')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save phone settings: $error')),
      );
    }
  }
}

class _SystemReadinessCard extends StatelessWidget {
  const _SystemReadinessCard({
    required this.readiness,
    required this.onNotifications,
    required this.onExactAlarm,
    required this.onFullScreen,
    required this.onAccessibility,
    required this.onBattery,
  });

  final NativeSystemReadiness? readiness;
  final Future<void> Function() onNotifications;
  final Future<void> Function() onExactAlarm;
  final Future<void> Function() onFullScreen;
  final Future<void> Function() onAccessibility;
  final Future<void> Function() onBattery;

  @override
  Widget build(BuildContext context) {
    final NativeSystemReadiness? status = readiness;
    final bool ready = status?.alarmReady == true && status?.focusReady == true;
    return Card(
      color: ready
          ? Theme.of(context).colorScheme.primaryContainer
          : Theme.of(context).colorScheme.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(ready ? Icons.verified_rounded : Icons.warning_rounded),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    ready
                        ? 'Phone protection is ready'
                        : 'Complete phone setup',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Reliable locked-screen alarms need alarm access, notifications and battery permission. App blocking needs the Accessibility App Blocker enabled.',
            ),
            const SizedBox(height: 12),
            _ReadinessRow(
              label: 'Notifications',
              value: status?.notificationsEnabled,
              onFix: onNotifications,
            ),
            _ReadinessRow(
              label: 'Exact alarms',
              value: status?.exactAlarmsEnabled,
              onFix: onExactAlarm,
            ),
            _ReadinessRow(
              label: 'Full-screen alarm',
              value: status?.fullScreenIntentEnabled,
              onFix: onFullScreen,
            ),
            _ReadinessRow(
              label: 'Accessibility blocker',
              value: status?.accessibilityEnabled,
              onFix: onAccessibility,
            ),
            _ReadinessRow(
              label: 'Battery unrestricted',
              value: status?.batteryOptimizationIgnored,
              onFix: onBattery,
            ),
          ],
        ),
      ),
    );
  }
}

class _ReadinessRow extends StatelessWidget {
  const _ReadinessRow({
    required this.label,
    required this.value,
    required this.onFix,
  });

  final String label;
  final bool? value;
  final Future<void> Function() onFix;

  @override
  Widget build(BuildContext context) => Row(
        children: <Widget>[
          Icon(
            value == true ? Icons.check_circle_rounded : Icons.cancel_rounded,
            size: 19,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(label)),
          TextButton(
            onPressed: value == true
                ? null
                : () async {
                    try {
                      await onFix();
                    } catch (_) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Could not open phone settings.'),
                          ),
                        );
                      }
                    }
                  },
            child: Text(value == true ? 'Ready' : 'Fix'),
          ),
        ],
      );
}

class _InstalledAppPicker extends StatelessWidget {
  const _InstalledAppPicker({
    required this.apps,
    required this.blocked,
    required this.onSearchChanged,
    required this.onChanged,
  });

  final List<LaunchableAppInfo> apps;
  final Set<String> blocked;
  final ValueChanged<String> onSearchChanged;
  final void Function(String packageName, bool selected) onChanged;

  @override
  Widget build(BuildContext context) => Card(
        child: ExpansionTile(
          initiallyExpanded: true,
          leading: const Icon(Icons.apps_rounded),
          title: const Text(
            'Choose focus-blocked apps',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          subtitle: Text(
            apps.isEmpty
                ? 'Installed-app list unavailable; use a package name below. Essential apps are rejected automatically.'
                : '${blocked.length} selected • ${apps.length} apps shown',
          ),
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: TextField(
                decoration: const InputDecoration(
                  labelText: 'Search installed apps',
                  prefixIcon: Icon(Icons.search_rounded),
                ),
                onChanged: onSearchChanged,
              ),
            ),
            if (apps.isNotEmpty)
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 360),
                child: ListView.builder(
                  itemCount: apps.length,
                  itemBuilder: (BuildContext context, int index) {
                    final LaunchableAppInfo app = apps[index];
                    return CheckboxListTile.adaptive(
                      dense: true,
                      title: Text(
                        app.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text(
                        app.packageName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      value: blocked.contains(app.packageName),
                      onChanged: (bool? selected) =>
                          onChanged(app.packageName, selected ?? false),
                    );
                  },
                ),
              ),
            const SizedBox(height: 8),
          ],
        ),
      );
}

class _PermissionButton extends StatelessWidget {
  const _PermissionButton({
    required this.icon,
    required this.title,
    required this.onPressed,
  });

  final IconData icon;
  final String title;
  final Future<void> Function() onPressed;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: OutlinedButton.icon(
          onPressed: () async {
            try {
              await onPressed();
            } catch (_) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Could not open system settings.'),
                  ),
                );
              }
            }
          },
          icon: Icon(icon),
          label: Align(alignment: Alignment.centerLeft, child: Text(title)),
        ),
      );
}
