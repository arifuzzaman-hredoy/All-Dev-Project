import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../models/study_game.dart';
import '../widgets/app_drawer.dart';
import '../widgets/common_widgets.dart';
import '../widgets/focus_tree.dart';

class FocusGameScreen extends StatelessWidget {
  const FocusGameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final StudyGameStats stats = controller.gameStats;
    final DateTime today = dateOnly(DateTime.now());
    final int todayFocus = controller.focusMinutesFor(today);
    final int todayDone = controller.completedTaskCountFor(today);
    final int todayTotal = controller.tasksFor(today).length;
    final List<_Quest> quests = <_Quest>[
      _Quest(
        title: 'Deep focus',
        subtitle: 'Complete 60 focused minutes today',
        current: todayFocus,
        target: 60,
        icon: Icons.timer_rounded,
      ),
      _Quest(
        title: 'Finish the plan',
        subtitle: 'Complete 3 routine blocks today',
        current: todayDone,
        target: 3,
        icon: Icons.task_alt_rounded,
      ),
      _Quest(
        title: 'Protect the streak',
        subtitle: 'Complete at least one task or focus session',
        current: todayDone > 0 || todayFocus > 0 ? 1 : 0,
        target: 1,
        icon: Icons.local_fire_department_rounded,
      ),
    ];

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(title: const Text('Study Quest')),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            sliver: SliverToBoxAdapter(
              child: _HeroCard(stats: stats),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
            sliver: SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Today’s quests',
                subtitle:
                    '$todayDone/$todayTotal tasks • $todayFocus focus minutes',
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) =>
                    _QuestCard(quest: quests[index]),
                childCount: quests.length,
                addAutomaticKeepAlives: false,
              ),
            ),
          ),
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
            sliver: SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Level rewards',
                subtitle: 'Every real study minute grows your level.',
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 110),
            sliver: SliverList(
              delegate: SliverChildListDelegate.fixed(
                <Widget>[
                  _RewardTile(
                    unlocked: stats.level >= 3,
                    title: 'Level 3 — Young Study Plant',
                    subtitle: 'Build your first consistent study rhythm.',
                    icon: Icons.eco_rounded,
                  ),
                  _RewardTile(
                    unlocked: stats.level >= 8,
                    title: 'Level 8 — Growing Study Tree',
                    subtitle: 'Strong focus habit and visible progress.',
                    icon: Icons.park_rounded,
                  ),
                  _RewardTile(
                    unlocked: stats.level >= 15,
                    title: 'Level 15 — Deep Work Expert',
                    subtitle: 'Long focused sessions and steady completion.',
                    icon: Icons.workspace_premium_rounded,
                  ),
                  _RewardTile(
                    unlocked: stats.level >= 25,
                    title: 'Level 25 — Master Scholar',
                    subtitle: 'A disciplined system that survives hard days.',
                    icon: Icons.school_rounded,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.stats});

  final StudyGameStats stats;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            colors.primaryContainer,
            colors.tertiaryContainer,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              CircleAvatar(
                radius: 27,
                backgroundColor: colors.surface.withValues(alpha: 0.75),
                child: Icon(
                  _stageIcon(stats.level),
                  color: colors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Level ${stats.level}',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                    ),
                    Text(
                      stats.rank,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                    Text(stats.stage),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          FocusTree(
            key: const ValueKey<String>('study-quest-tree'),
            progress: ((stats.level - 1) / 39 + stats.progress / 39)
                .clamp(0.03, 1.0)
                .toDouble(),
            level: stats.level,
            height: 190,
            semanticLabel: 'Persistent Study Quest tree',
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(
                child: LinearProgressIndicator(
                  value: stats.progress,
                  minHeight: 11,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${stats.xpIntoLevel}/${stats.xpNeededForLevel} XP',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _StatChip(
                icon: Icons.timer_rounded,
                label: '${stats.focusMinutes} focus min',
              ),
              _StatChip(
                icon: Icons.task_alt_rounded,
                label: '${stats.completedTasks} tasks',
              ),
              _StatChip(
                icon: Icons.local_fire_department_rounded,
                label: '${stats.streak} day streak',
              ),
            ],
          ),
        ],
      ),
    );
  }

  IconData _stageIcon(int level) {
    if (level >= 25) return Icons.forest_rounded;
    if (level >= 15) return Icons.park_rounded;
    if (level >= 8) return Icons.nature_rounded;
    if (level >= 3) return Icons.eco_rounded;
    return Icons.grass_rounded;
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 17),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _Quest {
  const _Quest({
    required this.title,
    required this.subtitle,
    required this.current,
    required this.target,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final int current;
  final int target;
  final IconData icon;

  double get progress => (current / target).clamp(0.0, 1.0).toDouble();
  bool get complete => current >= target;
}

class _QuestCard extends StatelessWidget {
  const _QuestCard({required this.quest});

  final _Quest quest;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 9),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            children: <Widget>[
              CircleAvatar(
                child: Icon(
                  quest.complete ? Icons.check_rounded : quest.icon,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      quest.title,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    Text(quest.subtitle),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: quest.progress,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '${quest.current.clamp(0, quest.target)}/${quest.target}',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      );
}

class _RewardTile extends StatelessWidget {
  const _RewardTile({
    required this.unlocked,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final bool unlocked;
  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: CircleAvatar(
            child: Icon(unlocked ? icon : Icons.lock_outline_rounded),
          ),
          title:
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: Icon(
            unlocked ? Icons.verified_rounded : Icons.lock_rounded,
            color: unlocked ? Theme.of(context).colorScheme.primary : null,
          ),
        ),
      );
}
