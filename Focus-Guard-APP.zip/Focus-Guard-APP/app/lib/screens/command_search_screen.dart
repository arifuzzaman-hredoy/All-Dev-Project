import 'package:flutter/material.dart';

import '../widgets/app_drawer.dart';
import 'experience_settings_screen.dart';
import 'phone_control_screen.dart';
import 'protection_center_screen.dart';
import 'reels_insights_screen.dart';
import 'safety_center_screen.dart';
import 'smart_coach_screen.dart';
import 'smart_recommendations_screen.dart';
import 'settings_screen.dart';
import 'study_mode_screen.dart';
import 'task_editor_screen.dart';
import 'weekly_report_screen.dart';
import 'wellbeing_alerts_screen.dart';

class CommandSearchScreen extends StatefulWidget {
  const CommandSearchScreen({super.key});

  @override
  State<CommandSearchScreen> createState() => _CommandSearchScreenState();
}

class _CommandSearchScreenState extends State<CommandSearchScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final List<_CommandItem> commands = <_CommandItem>[
      _CommandItem(
        title: 'Open Daily Coach',
        keywords: 'today plan coach priority next action smart',
        subtitle: 'See the top three actions and safe productivity plan',
        icon: Icons.auto_awesome_rounded,
        page: const SmartCoachScreen(),
      ),
      _CommandItem(
        title: 'Safety stop and always-allowed apps',
        keywords: 'unlock stop all blocking safe essential allow emergency',
        subtitle: 'Preview rules, protect personal apps and stop all blocking',
        icon: Icons.health_and_safety_rounded,
        page: const SafetyCenterScreen(),
      ),
      _CommandItem(
        title: 'Review smart app recommendations',
        keywords: 'recommend distracting app social games category education',
        subtitle:
            'See local categories without automatically blocking anything',
        icon: Icons.psychology_alt_rounded,
        page: const SmartRecommendationsScreen(),
      ),
      _CommandItem(
        title: 'Open weekly productivity report',
        keywords: 'weekly report focus tasks productive best day share',
        subtitle: 'Review seven days of tasks, focus and completion',
        icon: Icons.summarize_rounded,
        page: const WeeklyReportScreen(),
      ),
      _CommandItem(
        title: 'Switch Simple or Advanced Mode',
        keywords: 'simple advanced easy navigation shortcuts mode',
        subtitle: 'Reduce duplicate tools or show every advanced control',
        icon: Icons.auto_awesome_motion_rounded,
        page: const ExperienceSettingsScreen(),
      ),
      _CommandItem(
        title: 'Limit or block an app',
        keywords: 'app limit daily block distracting social game',
        subtitle: 'Auto-categorized app list, daily time and 20% commitment',
        icon: Icons.phonelink_lock_rounded,
        page: const PhoneControlScreen(),
      ),
      _CommandItem(
        title: 'Per-app Reels limits and live counts',
        keywords:
            'facebook youtube instagram reels shorts count viewed limit notification 50 75',
        subtitle:
            'See today’s count and set separate count/minute limits for every supported app',
        icon: Icons.smart_display_rounded,
        page: const ReelsInsightsScreen(),
      ),
      _CommandItem(
        title: 'Detailed screen-time warnings',
        keywords: 'screen time warning notification 50 75 90 goal wellbeing',
        subtitle:
            'Set large milestone and over-goal notifications with usage details',
        icon: Icons.notifications_active_rounded,
        page: const WellbeingAlertsScreen(),
      ),
      _CommandItem(
        title: 'Fixed Reels date-range budget',
        keywords: 'date time 5000 reels fixed budget window',
        subtitle: 'Set one locked count between exact start and end times',
        icon: Icons.date_range_rounded,
        page: const PhoneControlScreen(),
      ),
      _CommandItem(
        title: 'Automatic Study schedule',
        keywords: 'study time schedule focus block apps',
        subtitle:
            'Block selected apps during Study time and restore them after',
        icon: Icons.school_rounded,
        page: const StudyModeScreen(),
      ),
      _CommandItem(
        title: 'Protection Center',
        keywords: 'prime mode keep me out emergency web dns hardcore',
        subtitle: 'Open advanced protection without searching through menus',
        icon: Icons.shield_rounded,
        page: const ProtectionCenterScreen(),
      ),
      _CommandItem(
        title: 'Choose from 216 built-in alarm sounds',
        keywords:
            'alarm sound tone 216 preset routine reminder full screen task',
        subtitle:
            'Open a task alarm and choose, preview or search 216 real built-in tones',
        icon: Icons.alarm_add_rounded,
        page: const TaskEditorScreen(),
      ),
      _CommandItem(
        title: 'Alarm and permission settings',
        keywords: 'full screen alarm permission sound notification exact',
        subtitle: 'Check full-screen alarm, exact alarm and notification setup',
        icon: Icons.settings_rounded,
        page: const SettingsScreen(),
      ),
    ];
    final String normalized = _query.trim().toLowerCase();
    final List<_CommandItem> filtered = commands
        .where((item) =>
            normalized.isEmpty ||
            item.title.toLowerCase().contains(normalized) ||
            item.subtitle.toLowerCase().contains(normalized) ||
            item.keywords.contains(normalized))
        .toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Search & commands'),
        leading: Builder(
          builder: (BuildContext context) => IconButton(
            tooltip: 'Open navigation',
            onPressed: () => Scaffold.of(context).openDrawer(),
            icon: const Icon(Icons.menu_rounded),
          ),
        ),
      ),
      drawer: const AppDrawer(),
      body: ListView(
        key: const ValueKey<String>('command-search-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          TextField(
            key: const ValueKey<String>('command-search-field'),
            autofocus: false,
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search_rounded),
              labelText: 'Search an action',
              hintText: 'Try “Reels”, “Study time” or “Alarm”',
            ),
            onChanged: (String value) => setState(() => _query = value),
          ),
          const SizedBox(height: 14),
          Text(
            normalized.isEmpty ? 'Recommended commands' : 'Search results',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 8),
          if (filtered.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text(
                  'No command matched. Try coach, safety, app, Reels, Study, report or alarm.',
                ),
              ),
            )
          else
            ...filtered.map(
              (_CommandItem command) => Card(
                child: ListTile(
                  leading: CircleAvatar(child: Icon(command.icon)),
                  title: Text(
                    command.title,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(command.subtitle),
                  trailing: const Icon(Icons.arrow_forward_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => command.page),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CommandItem {
  const _CommandItem({
    required this.title,
    required this.keywords,
    required this.subtitle,
    required this.icon,
    required this.page,
  });

  final String title;
  final String keywords;
  final String subtitle;
  final IconData icon;
  final Widget page;
}
