import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<NoteItem> notes = controller.activeNotes.where((NoteItem note) {
      final String q = _query.toLowerCase();
      return q.isEmpty ||
          note.title.toLowerCase().contains(q) ||
          note.body.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context, controller, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add note'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        children: <Widget>[
          TextField(
            decoration: const InputDecoration(
              hintText: 'Notes search...',
              prefixIcon: Icon(Icons.search_rounded),
            ),
            onChanged: (String value) => setState(() => _query = value.trim()),
          ),
          const SizedBox(height: 14),
          if (notes.isEmpty)
            const EmptyState(
              icon: Icons.sticky_note_2_outlined,
              title: 'No notes found',
              message: 'Save formulas, mistake lists or important questions.',
            )
          else
            ...notes.map((NoteItem note) {
              final SubjectItem subject = controller.subjectById(
                note.subjectId,
              );
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _edit(context, controller, note),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            if (note.pinned) ...<Widget>[
                              const Icon(Icons.push_pin_rounded, size: 18),
                              const SizedBox(width: 7),
                            ],
                            Expanded(
                              child: Text(
                                note.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                            PopupMenuButton<String>(
                              onSelected: (String action) {
                                if (action == 'edit') {
                                  _edit(context, controller, note);
                                } else if (action == 'pin') {
                                  controller.updateNote(
                                    note.copyWith(
                                      pinned: !note.pinned,
                                      updatedAt: DateTime.now(),
                                    ),
                                  );
                                } else if (action == 'delete') {
                                  controller.deleteNote(note);
                                }
                              },
                              itemBuilder: (_) => <PopupMenuEntry<String>>[
                                const PopupMenuItem<String>(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                PopupMenuItem<String>(
                                  value: 'pin',
                                  child: Text(note.pinned ? 'Unpin' : 'Pin'),
                                ),
                                const PopupMenuItem<String>(
                                  value: 'delete',
                                  child: Text('Move to trash'),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        SubjectBadge(subject: subject),
                        if (note.body.isNotEmpty) ...<Widget>[
                          const SizedBox(height: 10),
                          Text(
                            note.body,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }

  Future<void> _edit(
    BuildContext context,
    AppController controller,
    NoteItem? note,
  ) async {
    String titleText = note?.title ?? '';
    String bodyText = note?.body ?? '';
    String subjectId = note?.subjectId ?? 'general';
    bool pinned = note?.pinned ?? false;

    final bool? save = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setDialogState) =>
            AlertDialog(
          title: Text(note == null ? 'Add note' : 'Edit note'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextFormField(
                  initialValue: titleText,
                  decoration: const InputDecoration(labelText: 'Title'),
                  onChanged: (String value) => titleText = value,
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  key: ValueKey<String>(subjectId),
                  initialValue: subjectId,
                  decoration: const InputDecoration(labelText: 'Subject'),
                  items: controller.activeSubjects
                      .map(
                        (SubjectItem item) => DropdownMenuItem<String>(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: (String? value) {
                    if (value != null) {
                      setDialogState(() => subjectId = value);
                    }
                  },
                ),
                const SizedBox(height: 10),
                TextFormField(
                  initialValue: bodyText,
                  minLines: 6,
                  maxLines: 12,
                  decoration: const InputDecoration(
                    labelText: 'Note body',
                    alignLabelWithHint: true,
                  ),
                  onChanged: (String value) => bodyText = value,
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Pin note'),
                  value: pinned,
                  onChanged: (bool value) =>
                      setDialogState(() => pinned = value),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    final String titleValue = titleText.trim();
    final String bodyValue = bodyText.trim();
    if (save != true || titleValue.isEmpty) {
      return;
    }
    final DateTime now = DateTime.now();
    if (note == null) {
      await controller.addNote(
        NoteItem(
          id: newId('note'),
          title: titleValue,
          body: bodyValue,
          subjectId: subjectId,
          pinned: pinned,
          createdAt: now,
          updatedAt: now,
        ),
      );
    } else {
      await controller.updateNote(
        note.copyWith(
          title: titleValue,
          body: bodyValue,
          subjectId: subjectId,
          pinned: pinned,
          updatedAt: now,
        ),
      );
    }
  }
}
