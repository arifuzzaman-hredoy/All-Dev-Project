import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';
import '../widgets/app_drawer.dart';
import 'focus_screen.dart';
import 'settings_screen.dart';

class FocusHubScreen extends StatefulWidget {
  const FocusHubScreen({super.key});

  @override
  State<FocusHubScreen> createState() => _FocusHubScreenState();
}

class _FocusHubScreenState extends State<FocusHubScreen> {
  int _minutes = 50;
  String? _taskId;

  Future<void> _startFocus(
    BuildContext context,
    AppController controller,
    TaskItem? selectedTask,
  ) async {
    NativeSettings? settings;
    NativeSystemReadiness? readiness;
    try {
      settings = await NativeBridge.settings();
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {
      // The timer remains usable on non-Android test hosts. The native layer
      // performs the final enforcement on a real phone.
    }

    if (!context.mounted) return;
    final List<String> problems = <String>[
      if (settings != null && settings.blockedPackages.isEmpty)
        'No distracting apps are selected.',
      if (readiness != null && !readiness.accessibilityEnabled)
        'Accessibility App Blocker is OFF.',
    ];

    if (problems.isNotEmpty) {
      final String? action = await showDialog<String>(
        context: context,
        builder: (BuildContext dialogContext) => AlertDialog(
          icon: const Icon(Icons.shield_outlined),
          title: const Text('Finish Focus Shield setup'),
          content: Text(
            '${problems.join(' ')} Open App & Phone Control, select apps, '
            'save the list and enable the accessibility service. You may still '
            'start a timer-only session, but apps will not be blocked.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop('timer'),
              child: const Text('Timer only'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop('setup'),
              icon: const Icon(Icons.settings_rounded),
              label: const Text('Open setup'),
            ),
          ],
        ),
      );
      if (!context.mounted || action == null) return;
      if (action == 'setup') {
        await Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
        );
        return;
      }
    }

    if (!context.mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => FocusScreen(
          minutes: _minutes,
          label: selectedTask?.title ?? 'Focused study',
          subjectId: selectedTask?.subjectId ?? 'general',
          taskId: selectedTask?.id,
          controller: controller,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<TaskItem> candidates = controller.activeTasks
        .where((TaskItem task) => !task.isCompleted)
        .take(30)
        .toList();
    final String? currentTaskId =
        _taskId != null && candidates.any((TaskItem task) => task.id == _taskId)
            ? _taskId
            : null;
    final TaskItem? selectedTask = currentTaskId == null
        ? null
        : candidates
            .where((TaskItem task) => task.id == currentTaskId)
            .firstOrNull;

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(title: const Text('Focus Center')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: <Widget>[
                Icon(
                  Icons.center_focus_strong_rounded,
                  size: 56,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(height: 12),
                Text(
                  '$_minutes minutes',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Selected distracting apps will be blocked and optional Do Not Disturb can be enabled.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <int>[15, 25, 50, 75, 90, 120]
                .map(
                  (int value) => ChoiceChip(
                    label: Text('$value min'),
                    selected: _minutes == value,
                    onSelected: (_) => setState(() => _minutes = value),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 16),
          Text('Custom duration: $_minutes min'),
          Slider(
            value: _minutes.toDouble(),
            min: 10,
            max: 180,
            divisions: 17,
            label: '$_minutes min',
            onChanged: (double value) =>
                setState(() => _minutes = value.round()),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String?>(
            isExpanded: true,
            key: ValueKey<String?>(currentTaskId),
            initialValue: currentTaskId,
            decoration: const InputDecoration(
              labelText: 'Optional task link',
              prefixIcon: Icon(Icons.link_rounded),
            ),
            items: <DropdownMenuItem<String?>>[
              const DropdownMenuItem<String?>(
                value: null,
                child: Text('General focused study'),
              ),
              ...candidates.map(
                (TaskItem task) => DropdownMenuItem<String?>(
                  value: task.id,
                  child: Text(task.title, overflow: TextOverflow.ellipsis),
                ),
              ),
            ],
            onChanged: (String? value) => setState(() => _taskId = value),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => _startFocus(
              context,
              controller,
              selectedTask,
            ),
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Start protected focus'),
          ),
          const SizedBox(height: 24),
          SectionHeader(
            title: 'Recent Sessions',
            subtitle: 'Total ${formatDuration(controller.totalFocusMinutes)}',
          ),
          const SizedBox(height: 10),
          if (controller.recentSessions.isEmpty)
            const EmptyState(
              icon: Icons.timer_outlined,
              title: 'No focus sessions yet',
              message:
                  'Your focus history will appear here after the first session.',
            )
          else
            ...controller.recentSessions.take(8).map(
                  (FocusSession session) => Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Icon(
                          session.completed
                              ? Icons.check_rounded
                              : Icons.stop_rounded,
                        ),
                      ),
                      title: Text(
                        session.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text(
                        '${formatDate(session.startedAt)} • ${formatTime(session.startedAt)}',
                      ),
                      trailing: Text(
                        formatDuration(session.actualMinutes),
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
