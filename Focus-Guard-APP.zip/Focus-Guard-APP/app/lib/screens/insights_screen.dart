import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';
import '../widgets/app_drawer.dart';
import 'weekly_report_screen.dart';

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final DateTime today = dateOnly(DateTime.now());
    final List<DateTime> days = List<DateTime>.generate(
      7,
      (int index) => today.subtract(Duration(days: 6 - index)),
    );
    final Map<String, int> subjectMinutes = controller.focusBySubject();
    final List<MapEntry<String, int>> subjectEntries =
        subjectMinutes.entries.toList()
          ..sort(
            (MapEntry<String, int> a, MapEntry<String, int> b) =>
                b.value.compareTo(a.value),
          );
    final int maxSubjectMinutes =
        subjectEntries.isEmpty ? 1 : subjectEntries.first.value;

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(title: const Text('Insights & Progress')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.18,
            children: <Widget>[
              MetricCard(
                label: 'Focus today',
                value: formatDuration(controller.focusMinutesFor(today)),
                icon: Icons.timer_rounded,
              ),
              MetricCard(
                label: 'Current streak',
                value: '${controller.currentStreak} days',
                icon: Icons.local_fire_department_rounded,
              ),
              MetricCard(
                label: 'Completed tasks',
                value: '${controller.completedTaskCount}',
                icon: Icons.task_alt_rounded,
              ),
              MetricCard(
                label: 'Total Focus',
                value: formatDuration(controller.totalFocusMinutes),
                icon: Icons.insights_rounded,
              ),
            ],
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.summarize_rounded),
              ),
              title: const Text(
                'Open Weekly Flow Report',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: const Text(
                'Tasks, focus minutes, productive days and your best day.',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const WeeklyReportScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 22),
          const SectionHeader(
            title: 'Last 7 days',
            subtitle: 'Task completion and focus minutes',
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 18, 14, 14),
              child: SizedBox(
                height: 190,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: days.map((DateTime day) {
                    final int completion = controller.completionPercent(day);
                    final int focus = controller.focusMinutesFor(day);
                    final double height = completion == 0 && focus > 0
                        ? 0.12
                        : (completion / 100).clamp(0.05, 1).toDouble();
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: <Widget>[
                            Text(
                              '$completion%',
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                            const SizedBox(height: 6),
                            Expanded(
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                child: FractionallySizedBox(
                                  heightFactor: height,
                                  widthFactor: 0.72,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.primary,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              const <String>[
                                'M',
                                'T',
                                'W',
                                'T',
                                'F',
                                'S',
                                'S',
                              ][day.weekday - 1],
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                            Text(
                              '$focus m',
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 22),
          const SectionHeader(
            title: 'Subject Focus',
            subtitle: 'Time spent by subject',
          ),
          const SizedBox(height: 10),
          if (subjectEntries.isEmpty)
            const EmptyState(
              icon: Icons.donut_large_rounded,
              title: 'No focus data yet',
              message: 'Complete focus sessions to see a subject breakdown.',
            )
          else
            ...subjectEntries.map((MapEntry<String, int> entry) {
              final SubjectItem subject = controller.subjectById(entry.key);
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(subject.icon, color: subject.color),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              subject.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Text(formatDuration(entry.value)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: entry.value / maxSubjectMinutes,
                        minHeight: 8,
                        color: subject.color,
                      ),
                    ],
                  ),
                ),
              );
            }),
          const SizedBox(height: 22),
          const SectionHeader(title: 'Goals'),
          const SizedBox(height: 10),
          if (controller.activeGoals.isEmpty)
            const EmptyState(
              icon: Icons.flag_outlined,
              title: 'No goals yet',
              message: 'Create a target from More → Goals.',
            )
          else
            ...controller.activeGoals.take(5).map(
                  (GoalItem goal) => Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            goal.title,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 7),
                          LinearProgressIndicator(
                            value: goal.ratio,
                            minHeight: 8,
                          ),
                          const SizedBox(height: 7),
                          Text(
                            '${goal.progress}/${goal.target} • Deadline ${formatDate(goal.deadline)}',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}
