import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../models/protection_policy.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';
import 'phone_control_screen.dart';

class SafetyCenterScreen extends StatefulWidget {
  const SafetyCenterScreen({super.key});

  @override
  State<SafetyCenterScreen> createState() => _SafetyCenterScreenState();
}

class _SafetyCenterScreenState extends State<SafetyCenterScreen> {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  NativeSystemReadiness? _readiness;
  bool _loading = true;
  bool _stopping = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    PhoneControlPolicy policy = const PhoneControlPolicy();
    List<LaunchableAppInfo> apps = const <LaunchableAppInfo>[];
    NativeSystemReadiness? readiness;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    try {
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _apps = apps;
      _readiness = readiness;
      _loading = false;
    });
  }

  Future<void> _stopAll() async {
    if (_stopping) return;
    final bool confirmed = await showDialog<bool>(
          context: context,
          builder: (BuildContext dialogContext) => AlertDialog(
            title: const Text('Stop all blocking now?'),
            content: const Text(
              'This pauses app blocks, schedules, Study enforcement, Prime Mode and Keep Me Out. Tasks, alarms, routines and saved rules stay safe.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton.icon(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                icon: const Icon(Icons.lock_open_rounded),
                label: const Text('Stop blocking'),
              ),
            ],
          ),
        ) ??
        false;
    if (!confirmed || !mounted) return;
    setState(() => _stopping = true);
    try {
      final PhoneControlPolicy safe =
          await NativeBridge.emergencyStopAllBlocking();
      try {
        await SmartFlowScope.of(context).recordSafetyStop();
      } catch (_) {
        // The native safety stop already succeeded. History persistence must
        // never make the emergency action look unsuccessful.
      }
      if (!mounted) return;
      setState(() => _policy = safe);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All blocking stopped. Personal data is unchanged.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not stop blocking: $error')),
      );
    } finally {
      if (mounted) setState(() => _stopping = false);
    }
  }

  Future<void> _editAlwaysAllowed() async {
    final SmartFlowController smart = SmartFlowScope.of(context);
    final Set<String> selected = <String>{
      ...smart.settings.userAlwaysAllowedPackages,
    };
    final List<LaunchableAppInfo> candidates = _apps
        .where((LaunchableAppInfo app) => !app.protected)
        .toList(growable: false)
      ..sort((LaunchableAppInfo a, LaunchableAppInfo b) =>
          a.label.toLowerCase().compareTo(b.label.toLowerCase()));

    final Set<String>? updated = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext sheetContext) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setSheetState) =>
            SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .82,
            child: Column(
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Always-allowed apps',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 18),
                  child: Text(
                    'Selected apps are removed from current blocking rules and excluded from future picker recommendations.',
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: candidates.length,
                    itemBuilder: (BuildContext context, int index) {
                      final LaunchableAppInfo app = candidates[index];
                      return CheckboxListTile(
                        title: Text(app.label),
                        subtitle: Text(app.categoryLabel),
                        value: selected.contains(app.packageName),
                        onChanged: (bool? value) {
                          setSheetState(() {
                            if (value ?? false) {
                              selected.add(app.packageName);
                            } else {
                              selected.remove(app.packageName);
                            }
                          });
                        },
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(sheetContext).pop(selected),
                    icon: const Icon(Icons.check_rounded),
                    label: const Text('Save always-allowed apps'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (updated == null || !mounted) return;

    final Set<String> alwaysAllowed = Set<String>.from(updated);
    final PhoneControlPolicy sanitized =
        sanitizePhoneControlForAlwaysAllowed(_policy, alwaysAllowed);
    try {
      await NativeBridge.savePhoneControlPolicy(sanitized);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save always-allowed apps: $error')),
      );
      return;
    }
    try {
      final ProtectionPolicy protection =
          await NativeBridge.protectionPolicy();
      await NativeBridge.saveProtectionPolicy(
        sanitizeProtectionForAlwaysAllowed(protection, alwaysAllowed),
      );
    } catch (_) {
      // Phone Control safety still applies even when Protection Center is unavailable.
    }
    try {
      await smart.setAlwaysAllowedPackages(alwaysAllowed);
    } catch (_) {
      // The controller updates in memory before writing. Native policies are
      // already safe, so a history-file write failure must not revert them.
    }
    if (!mounted) return;
    setState(() => _policy = sanitized);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${alwaysAllowed.length} apps are now always allowed.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final SmartFlowController smart = SmartFlowScope.of(context);
    final List<LaunchableAppInfo> protected = _apps
        .where((LaunchableAppInfo app) => app.protected)
        .toList(growable: false);
    final int activeRules = _policy.rules
        .where((AppControlRule rule) => rule.enabled && rule.hasRestriction)
        .length;
    final bool permissionsReady = (_readiness?.accessibilityEnabled ?? false) &&
        (_readiness?.usageAccessEnabled ?? false) &&
        (_readiness?.batteryOptimizationIgnored ?? false);

    return Scaffold(
      appBar: AppBar(title: const Text('Safety Center')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              key: const ValueKey<String>('safety-center-scroll'),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.errorContainer,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Row(
                        children: <Widget>[
                          Icon(Icons.emergency_rounded),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'One-tap safety stop',
                              style: TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Use this whenever the phone feels over-restricted. It never deletes tasks, routines, alarms or history.',
                      ),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: _stopping ? null : _stopAll,
                        icon: _stopping
                            ? const SizedBox.square(
                                dimension: 18,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.lock_open_rounded),
                        label: const Text('STOP ALL BLOCKING'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: ListTile(
                    leading: Icon(
                      permissionsReady
                          ? Icons.verified_user_rounded
                          : Icons.warning_amber_rounded,
                    ),
                    title: Text(
                      permissionsReady
                          ? 'Core permissions ready'
                          : 'Permission setup incomplete',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      '$activeRules active app rules • ${_policy.profiles.length} schedule profiles',
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const SectionHeader(
                  title: 'Always allowed',
                  subtitle:
                      'Essential apps are protected automatically. Add personal safety apps here.',
                ),
                const SizedBox(height: 10),
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.shield_rounded),
                    ),
                    title: Text(
                      '${protected.length} system-essential apps protected',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      '${smart.settings.userAlwaysAllowedPackages.length} additional apps always allowed by you',
                    ),
                    trailing: const Icon(Icons.edit_rounded),
                    onTap: _editAlwaysAllowed,
                  ),
                ),
                const SizedBox(height: 16),
                const SectionHeader(
                  title: 'Activation preview',
                  subtitle:
                      'See exactly what will be blocked before saving Phone Control rules.',
                ),
                const SizedBox(height: 10),
                Card(
                  child: SwitchListTile.adaptive(
                    title: const Text(
                      'Require rule preview before save',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Recommended. Prevents accidentally enabling a broad rule.',
                    ),
                    value: smart.settings.rulePreviewRequired,
                    onChanged: smart.setRulePreviewRequired,
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.preview_rounded),
                    ),
                    title: const Text(
                      'Review current app rules',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      '$activeRules active rules. Open the editor to review or change them.',
                    ),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const PhoneControlScreen(),
                      ),
                    ),
                  ),
                ),
                if (smart.settings.lastSafetyStopMillis > 0) ...<Widget>[
                  const SizedBox(height: 12),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.history_rounded),
                      title: const Text('Last safety stop'),
                      subtitle: Text(
                        DateTime.fromMillisecondsSinceEpoch(
                          smart.settings.lastSafetyStopMillis,
                        ).toLocal().toString(),
                      ),
                    ),
                  ),
                ],
              ],
            ),
    );
  }
}
