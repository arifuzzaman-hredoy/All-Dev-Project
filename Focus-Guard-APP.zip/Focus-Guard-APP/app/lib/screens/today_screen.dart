import 'dart:async';

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../models/study_game.dart';
import '../widgets/app_logo.dart';
import '../widgets/common_widgets.dart';
import '../widgets/profile_avatar.dart';
import '../widgets/app_drawer.dart';
import 'focus_screen.dart';
import 'profile_screen.dart';
import 'phone_control_dashboard_screen.dart';
import 'task_editor_screen.dart';

class TodayScreen extends StatefulWidget {
  const TodayScreen({super.key});

  @override
  State<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends State<TodayScreen> with WidgetsBindingObserver {
  final PageController _sliderController =
      PageController(viewportFraction: .94);
  Timer? _sliderTimer;
  Timer? _clockTimer;
  int _sliderPage = 0;
  bool _appResumed = true;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startSliderTimer();
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted || !_appResumed) return;
      setState(() => _now = DateTime.now());
    });
  }

  void _startSliderTimer() {
    _sliderTimer?.cancel();
    _sliderTimer = Timer.periodic(const Duration(seconds: 7), (_) {
      if (!_appResumed || !mounted || !_sliderController.hasClients) return;
      final int next = (_sliderPage + 1) % 4;
      _sliderController.animateToPage(
        next,
        duration: const Duration(milliseconds: 360),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _appResumed = state == AppLifecycleState.resumed;
    if (_appResumed && mounted) setState(() => _now = DateTime.now());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sliderTimer?.cancel();
    _clockTimer?.cancel();
    _sliderController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final DateTime now = _now;
    final DateTime today = dateOnly(now);
    final List<TaskItem> tasks = controller.todayTasks;
    final int completed = controller.completedTaskCountFor(today);
    final int progress = controller.completionPercent(today);
    final List<HabitItem> habits = controller.habitsFor(today);
    final List<TaskItem> upcoming = controller.upcomingTasks;
    final int overdueCount = controller.overdueTaskCount;
    final TaskItem? currentTask = controller.currentTaskAt(now);
    final TaskItem? nextTask = upcoming.isEmpty ? null : upcoming.first;
    final StudyGameStats game = controller.gameStats;
    final int focusToday = controller.focusMinutesFor(today);
    final double screenWidth = MediaQuery.sizeOf(context).width;
    final double textScale = MediaQuery.textScalerOf(context).scale(1);
    final double visualSliderHeight;
    if (textScale > 1.2) {
      visualSliderHeight = screenWidth < 340 ? 320 : 292;
    } else if (screenWidth < 340) {
      visualSliderHeight = 288;
    } else if (screenWidth < 380) {
      visualSliderHeight = 268;
    } else {
      visualSliderHeight = 252;
    }

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: Row(
          children: <Widget>[
            const AppLogo(size: 38),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text('Hredoy Flow'),
                  Text(
                    'Plan. Focus. Finish.',
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: <Widget>[
          IconButton(
            tooltip: 'Phone Control Center',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const PhoneControlDashboardScreen(),
              ),
            ),
            icon: const Icon(Icons.phonelink_lock_rounded),
          ),
          IconButton(
            tooltip: 'Refresh today',
            onPressed: () async {
              await controller.refreshNativeCompletions();
              controller.selectDate(today);
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: ProfileAvatar(
              name: controller.preferences.userName,
              imageBase64: controller.preferences.profileImageBase64,
              radius: 17,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const ProfileScreen(),
                ),
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await controller.refreshNativeCompletions();
          controller.selectDate(today);
        },
        child: CustomScrollView(
          key: const PageStorageKey<String>('today-scroll'),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: <Widget>[
            SliverToBoxAdapter(
              child: SizedBox(
                height: visualSliderHeight,
                child: RepaintBoundary(
                  child: NotificationListener<ScrollNotification>(
                    onNotification: (ScrollNotification notification) {
                      if (notification is ScrollStartNotification) {
                        _sliderTimer?.cancel();
                      } else if (notification is ScrollEndNotification) {
                        _startSliderTimer();
                      }
                      return false;
                    },
                    child: PageView(
                      key: const ValueKey<String>('dashboard-visual-slider'),
                      controller: _sliderController,
                      onPageChanged: (int value) {
                        if (value != _sliderPage) {
                          setState(() => _sliderPage = value);
                        }
                      },
                      children: <Widget>[
                        _ProgressSlide(
                          name: controller.preferences.userName,
                          progress: progress,
                          completed: completed,
                          total: tasks.length,
                        ),
                        _ActionSlide(
                          currentTask: currentTask,
                          nextTask: nextTask,
                          now: now,
                        ),
                        _CountdownSlide(
                          syllabusDays: controller.daysUntil(
                            controller.preferences.syllabusTarget,
                          ),
                          examDays: controller.daysUntil(
                            controller.preferences.examDate,
                          ),
                          streak: controller.currentStreak,
                        ),
                        _GameSlide(stats: game),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List<Widget>.generate(
                    4,
                    (int index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      width: index == _sliderPage ? 24 : 7,
                      height: 7,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        color: index == _sliderPage
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.outlineVariant,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                child: _DashboardOverview(
                  progress: progress,
                  focusMinutes: focusToday,
                  streak: controller.currentStreak,
                  level: game.level,
                ),
              ),
            ),
            if (overdueCount > 0)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                  child: Card(
                    color: Theme.of(context).colorScheme.errorContainer,
                    child: ListTile(
                      leading: const Icon(Icons.warning_amber_rounded),
                      title: Text(
                        '$overdueCount overdue task${overdueCount == 1 ? '' : 's'}',
                      ),
                      subtitle: const Text(
                        'Reschedule or complete them from Planner.',
                      ),
                    ),
                  ),
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 14)),
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: SectionHeader(
                  title: 'Current action',
                  subtitle: 'The task scheduled for this moment.',
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: _CurrentActionCard(
                  task: currentTask,
                  nextTask: nextTask,
                  now: now,
                  onStart: currentTask == null
                      ? null
                      : () => _startTaskFocus(context, currentTask),
                  onEdit: currentTask == null
                      ? null
                      : () => _editTask(context, currentTask),
                ),
              ),
            ),
            if (nextTask != null && nextTask.id != currentTask?.id) ...<Widget>[
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: SectionHeader(title: 'Next action'),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: TaskTile(
                    task: nextTask,
                    onToggle: (bool value) =>
                        controller.setTaskCompleted(nextTask, value),
                    onTap: () => _editTask(context, nextTask),
                  ),
                ),
              ),
            ],
            const SliverToBoxAdapter(child: SizedBox(height: 18)),
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: SectionHeader(
                  title: 'Quick Focus',
                  subtitle: 'Block distractions and start immediately.',
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: FilledButton(
                        onPressed: () => _startFocus(context, 25),
                        child: const Text('25 min'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _startFocus(context, 50),
                        child: const Text('50 min'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _startFocus(context, 90),
                        child: const Text('90 min'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                child: SectionHeader(
                  title: "Today's routine",
                  subtitle: '$completed/${tasks.length} complete • $progress%',
                ),
              ),
            ),
            if (tasks.isEmpty)
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: EmptyState(
                    icon: Icons.event_available_rounded,
                    title: 'No tasks today',
                    message: 'Use the New task button to build your day.',
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                      final TaskItem task = tasks[index];
                      return TaskTile(
                        task: task,
                        onToggle: (bool value) =>
                            controller.setTaskCompleted(task, value),
                        onTap: () => _editTask(context, task),
                        onMore: () => _showTaskMenu(context, task),
                      );
                    },
                    childCount: tasks.length,
                    addAutomaticKeepAlives: false,
                  ),
                ),
              ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                child: SectionHeader(
                  title: 'Daily habits',
                  subtitle:
                      '${habits.where((HabitItem habit) => habit.isDone(today)).length}/${habits.length} done',
                ),
              ),
            ),
            if (habits.isEmpty)
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: EmptyState(
                    icon: Icons.repeat_rounded,
                    title: 'No habits yet',
                    message: 'Create habits from More → Habits.',
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                      final HabitItem habit = habits[index];
                      return Card(
                        child: CheckboxListTile.adaptive(
                          value: habit.isDone(today),
                          onChanged: (_) =>
                              controller.toggleHabit(habit, today),
                          secondary: CircleAvatar(
                            backgroundColor:
                                habit.color.withValues(alpha: 0.15),
                            child: Icon(habit.icon, color: habit.color),
                          ),
                          title: Text(
                            habit.title,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                      );
                    },
                    childCount: habits.length,
                    addAutomaticKeepAlives: false,
                  ),
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 110)),
          ],
        ),
      ),
    );
  }

  void _startFocus(BuildContext context, int minutes) {
    final AppController controller = AppScope.read(context);
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => FocusScreen(
          minutes: minutes,
          label: 'Focused work',
          subjectId: 'general',
          taskId: null,
          controller: controller,
        ),
      ),
    );
  }

  void _startTaskFocus(BuildContext context, TaskItem task) {
    final AppController controller = AppScope.read(context);
    final int remainingMinutes = task.endAt.difference(_now).inMinutes;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => FocusScreen(
          minutes: remainingMinutes.clamp(1, task.durationMinutes).toInt(),
          label: task.title,
          subjectId: task.subjectId,
          taskId: task.id,
          controller: controller,
        ),
      ),
    );
  }

  void _editTask(BuildContext context, TaskItem task) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => TaskEditorScreen(task: task)),
    );
  }

  Future<void> _showTaskMenu(BuildContext context, TaskItem task) async {
    final AppController controller = AppScope.read(context);
    final String? action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.play_arrow_rounded),
              title: const Text('Start focus for this task'),
              onTap: () => Navigator.of(sheetContext).pop('focus'),
            ),
            ListTile(
              leading: const Icon(Icons.edit_rounded),
              title: const Text('Edit task'),
              onTap: () => Navigator.of(sheetContext).pop('edit'),
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Duplicate for tomorrow'),
              onTap: () => Navigator.of(sheetContext).pop('duplicate'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded),
              title: const Text('Move to Trash'),
              onTap: () => Navigator.of(sheetContext).pop('delete'),
            ),
          ],
        ),
      ),
    );

    if (!context.mounted) return;
    if (action == 'focus') {
      Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => FocusScreen(
            minutes: task.durationMinutes,
            label: task.title,
            subjectId: task.subjectId,
            taskId: task.id,
            controller: controller,
          ),
        ),
      );
    } else if (action == 'edit') {
      _editTask(context, task);
    } else if (action == 'duplicate') {
      await controller.duplicateTask(task);
    } else if (action == 'delete') {
      await controller.deleteTask(task);
    }
  }
}

class _CurrentActionCard extends StatelessWidget {
  const _CurrentActionCard({
    required this.task,
    required this.nextTask,
    required this.now,
    required this.onStart,
    required this.onEdit,
  });

  final TaskItem? task;
  final TaskItem? nextTask;
  final DateTime now;
  final VoidCallback? onStart;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    final TaskItem? active = task;
    if (active == null) {
      return Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: <Widget>[
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: colors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.free_breakfast_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'No scheduled task is active',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      nextTask == null
                          ? 'Your schedule is clear. Start a Quick Focus session or add a task.'
                          : 'Next: ${nextTask!.title} at ${formatTime(nextTask!.startAt)}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    final int totalSeconds =
        (active.durationMinutes * 60).clamp(1, 86400).toInt();
    final int elapsedSeconds =
        now.difference(active.startAt).inSeconds.clamp(0, totalSeconds).toInt();
    final double progress = elapsedSeconds / totalSeconds;
    final int remainingMinutes =
        ((totalSeconds - elapsedSeconds) / 60).ceil().clamp(1, 1440).toInt();
    return Card(
      key: const ValueKey<String>('current-action-card'),
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              colors.primaryContainer,
              colors.surfaceContainerLow,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Wrap(
              spacing: 10,
              runSpacing: 8,
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: <Widget>[
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: colors.primary,
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    'IN PROGRESS',
                    style: TextStyle(
                      color: colors.onPrimary,
                      fontWeight: FontWeight.w900,
                      fontSize: 10,
                      letterSpacing: .7,
                    ),
                  ),
                ),
                Text(
                  '$remainingMinutes min left',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              active.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              '${formatTime(active.startAt)}–${formatTime(active.endAt)} • ${formatDuration(active.durationMinutes)}',
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress,
              minHeight: 9,
              borderRadius: BorderRadius.circular(99),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onStart,
                    icon: const Icon(Icons.center_focus_strong_rounded),
                    label: const Text('Focus now'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  tooltip: 'Edit current task',
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_rounded),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardOverview extends StatelessWidget {
  const _DashboardOverview({
    required this.progress,
    required this.focusMinutes,
    required this.streak,
    required this.level,
  });

  final int progress;
  final int focusMinutes;
  final int streak;
  final int level;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          final bool compact = constraints.maxWidth < 360;
          final List<Widget> cards = <Widget>[
            _OverviewMetric(
              icon: Icons.task_alt_rounded,
              value: '$progress%',
              label: 'Routine',
            ),
            _OverviewMetric(
              icon: Icons.timer_rounded,
              value: '${focusMinutes}m',
              label: 'Focus',
            ),
            _OverviewMetric(
              icon: Icons.local_fire_department_rounded,
              value: '$streak',
              label: 'Streak',
            ),
            _OverviewMetric(
              icon: Icons.sports_esports_rounded,
              value: 'Lv $level',
              label: 'Quest',
            ),
          ];
          return GridView.count(
            crossAxisCount: compact ? 2 : 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: compact ? 1.7 : 1.15,
            children: cards,
          );
        },
      );
}

class _OverviewMetric extends StatelessWidget {
  const _OverviewMetric({
    required this.icon,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(icon, size: 22),
              const SizedBox(height: 5),
              Text(
                value,
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
              Text(label, style: Theme.of(context).textTheme.labelSmall),
            ],
          ),
        ),
      );
}

class _SlideShell extends StatelessWidget {
  const _SlideShell({
    required this.imageAsset,
    required this.child,
    this.pictureOnly = false,
    this.overlayStrength = .72,
  });

  final String imageAsset;
  final Widget child;
  final bool pictureOnly;
  final double overlayStrength;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 5),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color:
                  Theme.of(context).colorScheme.shadow.withValues(alpha: .16),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Image.asset(
              imageAsset,
              fit: BoxFit.cover,
              filterQuality: FilterQuality.high,
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    Colors.black.withValues(alpha: pictureOnly ? .04 : .10),
                    Colors.black.withValues(
                      alpha: pictureOnly ? .20 : overlayStrength,
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: child,
              ),
            ),
          ],
        ),
      );
}

class _GlassPanel extends StatelessWidget {
  const _GlassPanel({required this.child, this.maxWidth = 430});

  final Widget child;
  final double maxWidth;

  @override
  Widget build(BuildContext context) => ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: .38),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withValues(alpha: .16)),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: DefaultTextStyle.merge(
              style: const TextStyle(color: Colors.white),
              child: IconTheme.merge(
                data: const IconThemeData(color: Colors.white),
                child: child,
              ),
            ),
          ),
        ),
      );
}

class _SlideCopy extends StatelessWidget {
  const _SlideCopy({
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    this.footer,
  });

  final String eyebrow;
  final String title;
  final String subtitle;
  final Widget? footer;

  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            eyebrow.toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: Colors.white.withValues(alpha: .82),
                  fontWeight: FontWeight.w900,
                  letterSpacing: .9,
                ),
          ),
          const SizedBox(height: 5),
          Text(
            title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.5,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: Colors.white.withValues(alpha: .88)),
          ),
          if (footer != null) ...<Widget>[
            const SizedBox(height: 9),
            SizedBox(width: double.infinity, child: footer!),
          ],
        ],
      );
}

class _ProgressSlide extends StatelessWidget {
  const _ProgressSlide({
    required this.name,
    required this.progress,
    required this.completed,
    required this.total,
  });

  final String name;
  final int progress;
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) => _SlideShell(
        imageAsset: 'assets/slider/morning_focus.png',
        overlayStrength: .70,
        child: _GlassPanel(
          child: _SlideCopy(
            eyebrow: formatDate(DateTime.now()),
            title: 'Own your day, $name',
            subtitle: '$completed of $total routine tasks completed.',
            footer: Row(
              children: <Widget>[
                Expanded(
                  child: LinearProgressIndicator(
                    value: progress / 100,
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(99),
                    backgroundColor: Colors.white.withValues(alpha: .20),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '$progress%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _ActionSlide extends StatelessWidget {
  const _ActionSlide({
    required this.currentTask,
    required this.nextTask,
    required this.now,
  });

  final TaskItem? currentTask;
  final TaskItem? nextTask;
  final DateTime now;

  @override
  Widget build(BuildContext context) {
    final TaskItem? task = currentTask ?? nextTask;
    final bool active = currentTask != null;
    final String subtitle;
    if (task == null) {
      subtitle = 'Your schedule is clear. Start Quick Focus or add a task.';
    } else if (active) {
      final int remaining =
          task.endAt.difference(now).inMinutes.clamp(1, 1440).toInt();
      subtitle =
          '${formatTime(task.startAt)}–${formatTime(task.endAt)} • $remaining min remaining';
    } else {
      subtitle =
          '${formatDate(task.startAt)} • ${formatTime(task.startAt)} • ${formatDuration(task.durationMinutes)}';
    }
    return _SlideShell(
      imageAsset: 'assets/slider/current_action.png',
      overlayStrength: .76,
      child: _GlassPanel(
        child: _SlideCopy(
          eyebrow: active ? 'Current action' : 'Up next',
          title: task?.title ?? 'No active task',
          subtitle: subtitle,
          footer: task == null
              ? null
              : Row(
                  children: <Widget>[
                    Icon(
                      active ? Icons.bolt_rounded : Icons.schedule_rounded,
                      size: 18,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        active
                            ? 'Stay with this block'
                            : 'Prepare before it starts',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _CountdownSlide extends StatelessWidget {
  const _CountdownSlide({
    required this.syllabusDays,
    required this.examDays,
    required this.streak,
  });

  final int syllabusDays;
  final int examDays;
  final int streak;

  @override
  Widget build(BuildContext context) => _SlideShell(
        imageAsset: 'assets/slider/countdown_city.png',
        pictureOnly: true,
        child: Align(
          alignment: Alignment.bottomRight,
          child: _GlassPanel(
            maxWidth: 300,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Icon(Icons.calendar_month_rounded, size: 22),
                const SizedBox(width: 9),
                Flexible(
                  child: Text(
                    examDays >= 0
                        ? '$examDays days to exam • $streak day streak'
                        : 'Exam period active • $streak day streak',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _GameSlide extends StatelessWidget {
  const _GameSlide({required this.stats});

  final StudyGameStats stats;

  @override
  Widget build(BuildContext context) => _SlideShell(
        imageAsset: 'assets/slider/study_forest.png',
        pictureOnly: true,
        child: _GlassPanel(
          maxWidth: 330,
          child: _SlideCopy(
            eyebrow: 'Study Quest',
            title: 'Level ${stats.level} • ${stats.rank}',
            subtitle: '${stats.stage}. Focus minutes grow your tree.',
            footer: Row(
              children: <Widget>[
                Expanded(
                  child: LinearProgressIndicator(
                    value: stats.progress,
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(99),
                    backgroundColor: Colors.white.withValues(alpha: .20),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '${stats.xpIntoLevel}/${stats.xpNeededForLevel} XP',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}
