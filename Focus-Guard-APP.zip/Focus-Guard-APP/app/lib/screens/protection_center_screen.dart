import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/protection_policy.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';

class ProtectionCenterScreen extends StatefulWidget {
  const ProtectionCenterScreen({super.key});

  @override
  State<ProtectionCenterScreen> createState() => _ProtectionCenterScreenState();
}

class _ProtectionCenterScreenState extends State<ProtectionCenterScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  late final TabController _tabs;
  ProtectionPolicy _policy = const ProtectionPolicy();
  ProtectionPolicy _persistedPolicy = const ProtectionPolicy();
  ProtectionPolicy? _queuedPolicy;
  ProtectionSnapshot _snapshot = const ProtectionSnapshot();
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  bool _loading = true;
  bool _saving = false;
  bool _actionBusy = false;
  int _primeMinutes = 60;
  int _keepOutMinutes = 60;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(showSpinner: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _load({bool showSpinner = true}) async {
    if (showSpinner && mounted) setState(() => _loading = true);
    ProtectionPolicy policy = _policy;
    ProtectionSnapshot snapshot = _snapshot;
    List<LaunchableAppInfo> apps = _apps;
    try {
      policy = await NativeBridge.protectionPolicy();
    } catch (_) {}
    try {
      snapshot = await NativeBridge.protectionSnapshot();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _persistedPolicy = policy;
      _snapshot = snapshot;
      final Set<String> alwaysAllowed =
          SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
              const <String>{};
      _apps = apps
          .where(
            (LaunchableAppInfo app) =>
                !_isProtectedPackage(app.packageName) &&
                !alwaysAllowed.contains(app.packageName),
          )
          .toList(growable: false);
      _loading = false;
    });
  }

  Future<void> _save(ProtectionPolicy policy) async {
    final Set<String> alwaysAllowed =
        SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
            const <String>{};
    final ProtectionPolicy safePolicy =
        sanitizeProtectionForAlwaysAllowed(policy, alwaysAllowed);
    _queuedPolicy = safePolicy;
    if (mounted) setState(() => _policy = safePolicy);
    if (_saving) return;
    if (mounted) setState(() => _saving = true);

    while (_queuedPolicy != null) {
      final ProtectionPolicy target = _queuedPolicy!;
      _queuedPolicy = null;
      try {
        await NativeBridge.saveProtectionPolicy(target);
        _persistedPolicy = target;
      } catch (error) {
        _queuedPolicy = null;
        if (!mounted) return;
        setState(() => _policy = _persistedPolicy);
        _showMessage('Could not save protection settings: $error');
        break;
      }
    }
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _setVpnEnabled(bool enabled) async {
    final ProtectionPolicy next = _policy.copyWith(
      webProtectionEnabled: enabled ? true : _policy.webProtectionEnabled,
      vpnDnsEnabled: enabled,
    );
    await _save(next);
    if (!enabled) {
      await NativeBridge.stopProtectionVpn();
      await _load(showSpinner: false);
      return;
    }

    setState(() => _actionBusy = true);
    try {
      final bool granted = await NativeBridge.requestProtectionVpnPermission();
      if (granted) await NativeBridge.startProtectionVpn();
    } catch (error) {
      _showMessage('VPN permission/start failed: $error');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
      if (mounted) await _load(showSpinner: false);
    }
  }

  Future<void> _pickWebTime({required bool start}) async {
    final int minute = start ? _policy.webStartMinute : _policy.webEndMinute;
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: minute ~/ 60, minute: minute % 60),
    );
    if (picked == null) return;
    final int value = picked.hour * 60 + picked.minute;
    await _save(
      start
          ? _policy.copyWith(webStartMinute: value)
          : _policy.copyWith(webEndMinute: value),
    );
  }

  Future<void> _toggleWebDay(int day, bool selected) async {
    final Set<int> updated = <int>{..._policy.webWeekdays};
    if (selected) {
      updated.add(day);
    } else if (updated.length > 1) {
      updated.remove(day);
    }
    await _save(_policy.copyWith(webWeekdays: updated));
  }

  Future<void> _editTextList({
    required String title,
    required String hint,
    required Set<String> initial,
    required Future<void> Function(Set<String>) onSaved,
  }) async {
    final List<String> initialValues = initial.toList(growable: false)..sort();
    final TextEditingController controller = TextEditingController(
      text: initialValues.join('\n'),
    );
    final Set<String>? result = await showDialog<Set<String>>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 520,
          child: TextField(
            controller: controller,
            autofocus: true,
            minLines: 7,
            maxLines: 14,
            decoration: InputDecoration(
              hintText: hint,
              helperText: 'One item per line. Empty lines are ignored.',
              border: const OutlineInputBorder(),
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final Set<String> values = controller.text
                  .split(RegExp(r'[\r\n,]+'))
                  .map((String value) => value.trim().toLowerCase())
                  .where((String value) => value.isNotEmpty)
                  .toSet();
              Navigator.of(context).pop(values);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result != null) await onSaved(result);
  }

  Future<Set<String>?> _pickApps({
    required String title,
    required Set<String> selected,
  }) =>
      showModalBottomSheet<Set<String>>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => _ProtectionAppPicker(
          title: title,
          apps: _apps,
          selected: selected,
        ),
      );

  Future<void> _activatePrime() async {
    final Set<String> selected = _policy.primeBlockedPackages;
    if (selected.isEmpty) {
      _showMessage('Choose at least one app to block in Prime Mode.');
      return;
    }
    final bool confirmed = await _confirmCommitment(
      title: 'Start Prime Mode?',
      message:
          '${selected.length} apps selected by you will be locked for $_primeMinutes minutes. Essential, system, emergency, banking, authenticator and Hredoy Flow apps always stay available.',
    );
    if (!confirmed) return;

    setState(() => _actionBusy = true);
    try {
      final ProtectionActionResult result =
          await NativeBridge.activatePrimeMode(
        minutes: _primeMinutes,
        blockedPackages: selected,
        allowedPackages: const <String>{},
        silenceNotifications: _policy.primeSilenceNotifications,
      );
      _showMessage(result.message.isEmpty
          ? result.granted
              ? 'Prime Mode started.'
              : 'Prime Mode could not start.'
          : result.message);
    } catch (error) {
      _showMessage('Prime Mode failed: $error');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
      if (mounted) await _load(showSpinner: false);
    }
  }

  Future<void> _activateKeepOut() async {
    if (_policy.keepMeOutPackages.isEmpty) {
      _showMessage('Choose at least one app for Keep Me Out.');
      return;
    }
    final bool confirmed = await _confirmCommitment(
      title: 'Start Keep Me Out?',
      message:
          '${_policy.keepMeOutPackages.length} apps will be unavailable for $_keepOutMinutes minutes. The timer cannot be shortened without a limited emergency unlock.',
    );
    if (!confirmed) return;

    setState(() => _actionBusy = true);
    try {
      final ProtectionActionResult result =
          await NativeBridge.activateKeepMeOut(
        minutes: _keepOutMinutes,
        packages: _policy.keepMeOutPackages,
      );
      _showMessage(result.message.isEmpty
          ? result.granted
              ? 'Keep Me Out started.'
              : 'Keep Me Out could not start.'
          : result.message);
    } catch (error) {
      _showMessage('Keep Me Out failed: $error');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
      if (mounted) await _load(showSpinner: false);
    }
  }

  Future<void> _requestEmergencyUnlock() async {
    final bool confirmed = await _confirmCommitment(
      title: 'Use emergency unlock?',
      message:
          'This temporarily pauses Prime Mode and Keep Me Out for ${_policy.emergencyUnlockMinutes} minutes. Daily use is limited.',
    );
    if (!confirmed) return;
    setState(() => _actionBusy = true);
    try {
      final ProtectionActionResult result =
          await NativeBridge.requestHardcoreEmergencyUnlock(
        minutes: _policy.emergencyUnlockMinutes,
      );
      _showMessage(result.message.isEmpty
          ? result.granted
              ? 'Emergency unlock granted.'
              : 'Emergency unlock denied.'
          : result.message);
    } catch (error) {
      _showMessage('Emergency unlock failed: $error');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
      if (mounted) await _load(showSpinner: false);
    }
  }

  Future<void> _cancelEmergencyUnlock() async {
    await NativeBridge.cancelHardcoreEmergencyUnlock();
    await _load(showSpinner: false);
    _showMessage('Protection resumed immediately.');
  }

  Future<void> _runDiagnostics() async {
    setState(() => _actionBusy = true);
    try {
      final Map<String, bool> checks =
          await NativeBridge.runProtectionDiagnostics();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Protection diagnostics'),
          content: SizedBox(
            width: 480,
            child: ListView(
              shrinkWrap: true,
              children: checks.entries
                  .map(
                    (MapEntry<String, bool> entry) => ListTile(
                      dense: true,
                      leading: Icon(
                        entry.value
                            ? Icons.check_circle_rounded
                            : Icons.error_rounded,
                        color: entry.value
                            ? Colors.green
                            : Theme.of(context).colorScheme.error,
                      ),
                      title: Text(_humanize(entry.key)),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
          actions: <Widget>[
            FilledButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Done'),
            ),
          ],
        ),
      );
    } catch (error) {
      _showMessage('Diagnostics failed: $error');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
    }
  }

  Future<bool> _confirmCommitment({
    required String title,
    required String message,
  }) async =>
      await showDialog<bool>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Confirm'),
            ),
          ],
        ),
      ) ??
      false;

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Protection Center'),
          actions: <Widget>[
            if (_saving || _actionBusy)
              const Padding(
                padding: EdgeInsets.only(right: 18),
                child: Center(
                  child: SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              )
            else
              IconButton(
                tooltip: 'Refresh',
                onPressed: () => _load(showSpinner: false),
                icon: const Icon(Icons.refresh_rounded),
              ),
          ],
          bottom: TabBar(
            controller: _tabs,
            isScrollable: true,
            tabs: const <Widget>[
              Tab(icon: Icon(Icons.language_rounded), text: 'Web & DNS'),
              Tab(icon: Icon(Icons.lock_clock_rounded), text: 'Hardcore'),
              Tab(
                  icon: Icon(Icons.fact_check_rounded),
                  text: 'Status & history'),
            ],
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                controller: _tabs,
                children: <Widget>[
                  _buildWebTab(),
                  _buildHardcoreTab(),
                  _buildStatusTab(),
                ],
              ),
      );

  Widget _buildWebTab() => RefreshIndicator(
        onRefresh: () => _load(showSpinner: false),
        child: ListView(
          key: const ValueKey<String>('protection-web-scroll'),
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
          children: <Widget>[
            _ProtectionHero(
              title: 'Web & DNS protection',
              subtitle: _snapshot.vpnRunning
                  ? 'Local DNS protection is active on this phone.'
                  : 'Configure DNS, domain rules and browser fallback.',
              icon: Icons.shield_rounded,
              active: _snapshot.vpnRunning,
              metrics: <_HeroMetric>[
                _HeroMetric(
                  value: '${_snapshot.webBlockedToday}',
                  label: 'Blocked today',
                ),
                _HeroMetric(
                  value: _snapshot.vpnRunning ? 'ON' : 'OFF',
                  label: 'Local VPN',
                ),
                _HeroMetric(
                  value: '${_policy.blockedDomains.length}',
                  label: 'Custom domains',
                ),
              ],
            ),
            const SizedBox(height: 16),
            SectionHeader(
              title: 'Protection engine',
              subtitle:
                  'DNS protection covers most apps. Browser Guard is a fallback for visible browser URLs.',
              action: FilledButton.tonalIcon(
                onPressed: NativeBridge.openVpnSettings,
                icon: const Icon(Icons.vpn_key_rounded),
                label: const Text('Android VPN'),
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: <Widget>[
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.public_rounded),
                    ),
                    title: const Text(
                      'Web protection',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Applies custom domain, adult-content and Safe Search rules.',
                    ),
                    value: _policy.webProtectionEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(webProtectionEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.dns_rounded),
                    ),
                    title: const Text(
                      'Local DNS VPN',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _snapshot.vpnRunning
                          ? 'Running with a persistent Android protection notification.'
                          : 'Requires one-time Android VPN approval.',
                    ),
                    value: _policy.vpnDnsEnabled,
                    onChanged: _actionBusy ? null : _setVpnEnabled,
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.block_rounded),
                    ),
                    title: const Text(
                      'Adult-content protection',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Uses family DNS plus a local high-confidence domain classifier.',
                    ),
                    value: _policy.adultContentEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(adultContentEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.manage_search_rounded),
                    ),
                    title: const Text(
                      'Safe Search bypass guard',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Blocks visible attempts to disable Safe Search and configured search keywords.',
                    ),
                    value: _policy.safeSearchEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(safeSearchEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.travel_explore_rounded),
                    ),
                    title: const Text(
                      'Browser Guard fallback',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Uses Accessibility only when the browser exposes its address bar.',
                    ),
                    value: _policy.browserGuardEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(browserGuardEnabled: value),
                    ),
                  ),
                ],
              ),
            ),
            if (_snapshot.privateDnsActive) ...<Widget>[
              const SizedBox(height: 10),
              Card(
                color: Theme.of(context).colorScheme.errorContainer,
                child: ListTile(
                  leading: const Icon(Icons.warning_amber_rounded),
                  title: const Text(
                    'Private DNS may bypass the local DNS VPN',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: const Text(
                    'Set Android Private DNS to Automatic/Off, or rely on Browser Guard for supported browsers.',
                  ),
                ),
              ),
            ],
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'DNS provider & failure policy',
              subtitle:
                  'Family DNS is the recommended default. Fail-open preserves internet access if upstream DNS fails.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    DropdownButtonFormField<String>(
                      key: ValueKey<String>(_dnsPreset),
                      initialValue: _dnsPreset,
                      decoration: const InputDecoration(
                        labelText: 'DNS preset',
                        border: OutlineInputBorder(),
                      ),
                      items: const <DropdownMenuItem<String>>[
                        DropdownMenuItem<String>(
                          value: 'family',
                          child: Text('Cloudflare Family — malware + adult'),
                        ),
                        DropdownMenuItem<String>(
                          value: 'standard',
                          child: Text('Cloudflare Standard'),
                        ),
                        DropdownMenuItem<String>(
                          value: 'custom',
                          child: Text('Custom IPv4 DNS'),
                        ),
                      ],
                      onChanged: (String? value) async {
                        if (value == 'family') {
                          await _save(_policy.copyWith(
                            primaryDns: '1.1.1.3',
                            secondaryDns: '1.0.0.3',
                          ));
                        } else if (value == 'standard') {
                          await _save(_policy.copyWith(
                            primaryDns: '1.1.1.1',
                            secondaryDns: '1.0.0.1',
                          ));
                        } else if (value == 'custom') {
                          await _editDns();
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Primary: ${_policy.primaryDns}  •  Secondary: ${_policy.secondaryDns}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 10),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'Fail closed',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: const Text(
                        'When DNS servers fail, block requests instead of pausing protection. This can temporarily break internet access.',
                      ),
                      value: _policy.failClosed,
                      onChanged: (bool value) =>
                          _save(_policy.copyWith(failClosed: value)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            SectionHeader(
              title: 'Custom web rules',
              subtitle:
                  '${_policy.blockedDomains.length} blocked • ${_policy.allowedDomains.length} allowed • ${_policy.blockedKeywords.length} keywords',
            ),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: <Widget>[
                  ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.block_rounded),
                    ),
                    title: const Text(
                      'Blocked domains',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _previewSet(_policy.blockedDomains, 'No custom domains'),
                    ),
                    trailing: const Icon(Icons.edit_rounded),
                    onTap: () => _editTextList(
                      title: 'Blocked domains',
                      hint: 'One blocked domain per line',
                      initial: _policy.blockedDomains,
                      onSaved: (Set<String> value) =>
                          _save(_policy.copyWith(blockedDomains: value)),
                    ),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.check_circle_rounded),
                    ),
                    title: const Text(
                      'Allowed domains',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _previewSet(_policy.allowedDomains, 'No exceptions'),
                    ),
                    trailing: const Icon(Icons.edit_rounded),
                    onTap: () => _editTextList(
                      title: 'Allowed domains',
                      hint: 'One trusted domain per line',
                      initial: _policy.allowedDomains,
                      onSaved: (Set<String> value) =>
                          _save(_policy.copyWith(allowedDomains: value)),
                    ),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.key_rounded),
                    ),
                    title: const Text(
                      'Blocked search keywords',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _previewSet(_policy.blockedKeywords, 'No keywords'),
                    ),
                    trailing: const Icon(Icons.edit_rounded),
                    onTap: () => _editTextList(
                      title: 'Blocked search keywords',
                      hint: 'keyword\nphrase with spaces',
                      initial: _policy.blockedKeywords,
                      onSaved: (Set<String> value) =>
                          _save(_policy.copyWith(blockedKeywords: value)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'Protection schedule',
              subtitle:
                  'Choose when web protection is enforced. Equal start/end means all day.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'Use a weekly schedule',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: const Text(
                        'When off, protection runs whenever Web protection is enabled.',
                      ),
                      value: _policy.webScheduleEnabled,
                      onChanged: (bool value) => _save(
                        _policy.copyWith(webScheduleEnabled: value),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _WeekdaySelector(
                      selected: _policy.webWeekdays,
                      onChanged: _toggleWebDay,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _pickWebTime(start: true),
                            icon: const Icon(Icons.play_arrow_rounded),
                            label: Text(
                              'Start ${_formatMinute(_policy.webStartMinute)}',
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _pickWebTime(start: false),
                            icon: const Icon(Icons.stop_rounded),
                            label: Text(
                              'End ${_formatMinute(_policy.webEndMinute)}',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Limit: encrypted DNS/DoH and browsers that hide their address bar can bypass app-level inspection. The local VPN routes DNS only; it does not decrypt browsing traffic or inspect private images.',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildHardcoreTab() => RefreshIndicator(
        onRefresh: () => _load(showSpinner: false),
        child: ListView(
          key: const ValueKey<String>('protection-hardcore-scroll'),
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
          children: <Widget>[
            _ProtectionHero(
              title: 'Commitment protection',
              subtitle: _policy.primeModeActive
                  ? 'Prime Mode is active until ${_formatTimestamp(_policy.primeModeUntilMillis)}.'
                  : _policy.keepMeOutActive
                      ? 'Keep Me Out is active until ${_formatTimestamp(_policy.keepMeOutUntilMillis)}.'
                      : 'Configure a timed commitment lock with limited emergency access.',
              icon: Icons.lock_clock_rounded,
              active: _policy.primeModeActive || _policy.keepMeOutActive,
              metrics: <_HeroMetric>[
                _HeroMetric(
                  value: _policy.primeModeActive ? 'ON' : 'OFF',
                  label: 'Prime Mode',
                ),
                _HeroMetric(
                  value: _policy.keepMeOutActive ? 'ON' : 'OFF',
                  label: 'Keep Me Out',
                ),
                _HeroMetric(
                  value: '${_snapshot.emergencyUnlocksUsedToday}',
                  label: 'Unlocks used',
                ),
              ],
            ),
            if (_snapshot.emergencyUnlockedNow) ...<Widget>[
              const SizedBox(height: 12),
              Card(
                key: const ValueKey<String>('responsive-emergency-unlock-card'),
                color: Theme.of(context).colorScheme.errorContainer,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Icon(Icons.lock_open_rounded),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Text(
                                  'Emergency unlock is active',
                                  style: TextStyle(fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Protection resumes at ${_formatTimestamp(_snapshot.emergencyUnlockedUntilMillis)}.',
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      FilledButton(
                        onPressed: _cancelEmergencyUnlock,
                        child: const Text('Resume protection now'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'Prime Mode',
              subtitle:
                  'A commitment timer. Active timers cannot be shortened by editing settings.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Card(
                      margin: EdgeInsets.zero,
                      color: Theme.of(context).colorScheme.secondaryContainer,
                      child: const Padding(
                        padding: EdgeInsets.all(12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Icon(Icons.shield_outlined),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Manual block only: Prime Mode blocks only the apps you select below. It never locks the whole phone or essential apps.',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _DurationSelector(
                      label: 'Prime duration',
                      minutes: _primeMinutes,
                      values: const <int>[15, 30, 60, 120, 240, 480, 720, 1440],
                      onChanged: (int value) =>
                          setState(() => _primeMinutes = value),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        child: Icon(Icons.block_rounded),
                      ),
                      title: const Text(
                        'Apps to block',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: Text(
                        '${_policy.primeBlockedPackages.length} apps selected by you',
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () async {
                        final Set<String>? selected = await _pickApps(
                          title: 'Prime Mode apps to block',
                          selected: _policy.primeBlockedPackages,
                        );
                        if (selected == null) return;
                        await _save(
                          _policy.copyWith(
                            primeBlockedPackages: selected,
                            primeAllowedPackages: const <String>{},
                          ),
                        );
                      },
                    ),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'Silence non-critical notifications',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: const Text(
                        'Requires Notification Access. Calls, alarms and ongoing services remain allowed.',
                      ),
                      value: _policy.primeSilenceNotifications,
                      onChanged: (bool value) => _save(
                        _policy.copyWith(primeSilenceNotifications: value),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _actionBusy ? null : _activatePrime,
                        icon: const Icon(Icons.lock_clock_rounded),
                        label: const Text('Start Prime Mode'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'Keep Me Out',
              subtitle:
                  'A simpler timed lock for selected apps. Existing longer timers are preserved.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _DurationSelector(
                      label: 'Lock duration',
                      minutes: _keepOutMinutes,
                      values: const <int>[
                        5,
                        15,
                        30,
                        60,
                        120,
                        240,
                        480,
                        720,
                        1440
                      ],
                      onChanged: (int value) =>
                          setState(() => _keepOutMinutes = value),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        child: Icon(Icons.app_blocking_rounded),
                      ),
                      title: const Text(
                        'Locked apps',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: Text(
                        '${_policy.keepMeOutPackages.length} apps selected',
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () async {
                        final Set<String>? selected = await _pickApps(
                          title: 'Keep Me Out apps',
                          selected: _policy.keepMeOutPackages,
                        );
                        if (selected != null) {
                          await _save(
                            _policy.copyWith(keepMeOutPackages: selected),
                          );
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.tonalIcon(
                        onPressed: _actionBusy ? null : _activateKeepOut,
                        icon: const Icon(Icons.timer_off_rounded),
                        label: const Text('Start Keep Me Out'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'Anti-bypass controls',
              subtitle:
                  'Best-effort Accessibility protection. It is not Device Owner, root or MDM enforcement.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: <Widget>[
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.settings_suggest_rounded),
                    ),
                    title: const Text(
                      'Settings tamper protection',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'During an active commitment, protects only the selected blocked apps. Android Settings stays available for safety.',
                    ),
                    value: _policy.tamperProtectionEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(tamperProtectionEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.phonelink_erase_rounded),
                    ),
                    title: const Text(
                      'Uninstall warning guard',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Blocks visible uninstall/disable attempts while Prime Mode is active. Android can still remove a normal app through privileged tools.',
                    ),
                    value: _policy.uninstallGuardEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(uninstallGuardEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    secondary: const CircleAvatar(
                      child: Icon(Icons.restart_alt_rounded),
                    ),
                    title: const Text(
                      'Restore after reboot',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Restores active timers and attempts to reconnect DNS protection after Android restarts.',
                    ),
                    value: _policy.rebootRestoreEnabled,
                    onChanged: (bool value) => _save(
                      _policy.copyWith(rebootRestoreEnabled: value),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'Emergency policy',
              subtitle:
                  'Use a limited temporary unlock instead of silently weakening an active commitment.',
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Unlock duration: ${_policy.emergencyUnlockMinutes} minutes',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    Slider(
                      value: _policy.emergencyUnlockMinutes.toDouble(),
                      min: 1,
                      max: 30,
                      divisions: 29,
                      label: '${_policy.emergencyUnlockMinutes} min',
                      onChanged: (double value) => _save(
                        _policy.copyWith(
                          emergencyUnlockMinutes: value.round(),
                        ),
                      ),
                    ),
                    Text(
                      'Daily unlock limit: ${_policy.maxEmergencyUnlocksPerDay}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    Slider(
                      value: _policy.maxEmergencyUnlocksPerDay.toDouble(),
                      min: 0,
                      max: 10,
                      divisions: 10,
                      label: '${_policy.maxEmergencyUnlocksPerDay}',
                      onChanged: (double value) => _save(
                        _policy.copyWith(
                          maxEmergencyUnlocksPerDay: value.round(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _actionBusy ? null : _requestEmergencyUnlock,
                        icon: const Icon(Icons.lock_open_rounded),
                        label: const Text('Request emergency unlock'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildStatusTab() => RefreshIndicator(
        onRefresh: () => _load(showSpinner: false),
        child: ListView(
          key: const ValueKey<String>('protection-status-scroll'),
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
          children: <Widget>[
            const SectionHeader(
              title: 'Runtime status',
              subtitle:
                  'Native state from the VPN, Accessibility guard and persistent protection store.',
            ),
            const SizedBox(height: 8),
            LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final int columns = constraints.maxWidth < 620 ? 2 : 4;
                return GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: columns,
                  childAspectRatio: columns == 2 ? 1.2 : 1.05,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: <Widget>[
                    MetricCard(
                      label: 'VPN permission',
                      value: _snapshot.vpnPrepared ? 'Ready' : 'Needed',
                      icon: Icons.vpn_key_rounded,
                    ),
                    MetricCard(
                      label: 'DNS service',
                      value: _snapshot.vpnRunning ? 'Running' : 'Stopped',
                      icon: Icons.dns_rounded,
                    ),
                    MetricCard(
                      label: 'Web blocks today',
                      value: '${_snapshot.webBlockedToday}',
                      icon: Icons.public_off_rounded,
                    ),
                    MetricCard(
                      label: 'Tamper blocks today',
                      value: '${_snapshot.tamperBlockedToday}',
                      icon: Icons.admin_panel_settings_rounded,
                    ),
                  ],
                );
              },
            ),
            const SizedBox(height: 16),
            Card(
              child: Column(
                children: <Widget>[
                  ListTile(
                    leading: Icon(
                      _snapshot.vpnRunning
                          ? Icons.check_circle_rounded
                          : Icons.info_rounded,
                    ),
                    title: const Text(
                      'Last service message',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _snapshot.lastServiceMessage.isEmpty
                          ? 'No service message yet.'
                          : _snapshot.lastServiceMessage,
                    ),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.restart_alt_rounded),
                    title: const Text(
                      'Last reboot restore',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      _snapshot.lastBootRestoreAtMillis <= 0
                          ? 'Not recorded yet.'
                          : _formatTimestamp(
                              _snapshot.lastBootRestoreAtMillis,
                            ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: <Widget>[
                FilledButton.tonalIcon(
                  onPressed: _actionBusy ? null : _runDiagnostics,
                  icon: const Icon(Icons.health_and_safety_rounded),
                  label: const Text('Run diagnostics'),
                ),
                OutlinedButton.icon(
                  onPressed: NativeBridge.openAccessibilitySettings,
                  icon: const Icon(Icons.accessibility_new_rounded),
                  label: const Text('Accessibility'),
                ),
                OutlinedButton.icon(
                  onPressed: NativeBridge.openNotificationAccessSettings,
                  icon: const Icon(Icons.notifications_active_rounded),
                  label: const Text('Notification access'),
                ),
                OutlinedButton.icon(
                  onPressed: NativeBridge.requestBatteryOptimizationExemption,
                  icon: const Icon(Icons.battery_saver_rounded),
                  label: const Text('Battery unrestricted'),
                ),
              ],
            ),
            const SizedBox(height: 22),
            SectionHeader(
              title: 'Protection history',
              subtitle:
                  '${_snapshot.history.length} local events • maximum ${_policy.historyLimit}',
              action: TextButton.icon(
                onPressed: _snapshot.history.isEmpty
                    ? null
                    : () async {
                        await NativeBridge.clearProtectionHistory();
                        await _load(showSpinner: false);
                      },
                icon: const Icon(Icons.delete_sweep_rounded),
                label: const Text('Clear'),
              ),
            ),
            const SizedBox(height: 8),
            if (_snapshot.history.isEmpty)
              const EmptyState(
                icon: Icons.shield_outlined,
                title: 'No blocked events yet',
                message:
                    'Website, Prime Mode and tamper blocks will appear here locally.',
              )
            else
              Card(
                child: Column(
                  children: _snapshot.history
                      .take(_policy.historyLimit)
                      .map(
                        (ProtectionHistoryItem item) => Column(
                          children: <Widget>[
                            ListTile(
                              leading: CircleAvatar(
                                child: Icon(_historyIcon(item.kind)),
                              ),
                              title: Text(
                                item.target.isEmpty ? item.kind : item.target,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              subtitle: Text(
                                '${item.reason}\n${_formatTimestamp(item.timestampMillis)}',
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                              isThreeLine: true,
                            ),
                            if (item != _snapshot.history.last)
                              const Divider(height: 1),
                          ],
                        ),
                      )
                      .toList(growable: false),
                ),
              ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'History retention: ${_policy.historyLimit} events',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    Slider(
                      value: _policy.historyLimit.toDouble(),
                      min: 20,
                      max: 1000,
                      divisions: 49,
                      label: '${_policy.historyLimit}',
                      onChanged: (double value) => _save(
                        _policy.copyWith(
                          historyLimit: ((value / 20).round() * 20)
                              .clamp(20, 1000)
                              .toInt(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );

  String get _dnsPreset {
    if (_policy.primaryDns == '1.1.1.3' && _policy.secondaryDns == '1.0.0.3') {
      return 'family';
    }
    if (_policy.primaryDns == '1.1.1.1' && _policy.secondaryDns == '1.0.0.1') {
      return 'standard';
    }
    return 'custom';
  }

  Future<void> _editDns() async {
    final TextEditingController primary =
        TextEditingController(text: _policy.primaryDns);
    final TextEditingController secondary =
        TextEditingController(text: _policy.secondaryDns);
    final ProtectionPolicy? updated = await showDialog<ProtectionPolicy>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Custom DNS servers'),
        content: SizedBox(
          width: 440,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: primary,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Primary IPv4 DNS',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: secondary,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Secondary IPv4 DNS',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (!_isIpv4(primary.text) || !_isIpv4(secondary.text)) {
                _showMessage('Enter two valid IPv4 addresses.');
                return;
              }
              Navigator.of(context).pop(
                _policy.copyWith(
                  primaryDns: primary.text.trim(),
                  secondaryDns: secondary.text.trim(),
                ),
              );
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    primary.dispose();
    secondary.dispose();
    if (updated != null) await _save(updated);
  }

  bool _isIpv4(String raw) {
    final List<String> parts = raw.trim().split('.');
    if (parts.length != 4) return false;
    return parts.every((String part) {
      final int? value = int.tryParse(part);
      return value != null && value >= 0 && value <= 255;
    });
  }

  String _previewSet(Set<String> values, String fallback) {
    if (values.isEmpty) return fallback;
    final List<String> sorted = values.toList(growable: false)..sort();
    final String preview = sorted.take(3).join(', ');
    return sorted.length > 3 ? '$preview +${sorted.length - 3}' : preview;
  }

  String _formatMinute(int minute) {
    final int safe = minute.clamp(0, 1439).toInt();
    return TimeOfDay(hour: safe ~/ 60, minute: safe % 60).format(context);
  }

  String _formatTimestamp(int millis) {
    if (millis <= 0) return 'Not active';
    final DateTime value = DateTime.fromMillisecondsSinceEpoch(millis);
    final String day = value.day.toString().padLeft(2, '0');
    final String month = value.month.toString().padLeft(2, '0');
    return '$day/$month/${value.year} ${TimeOfDay.fromDateTime(value).format(context)}';
  }

  IconData _historyIcon(String kind) => switch (kind) {
        'web' => Icons.public_off_rounded,
        'prime' => Icons.lock_clock_rounded,
        'keep_out' => Icons.timer_off_rounded,
        'tamper' => Icons.admin_panel_settings_rounded,
        _ => Icons.shield_rounded,
      };

  String _humanize(String value) {
    final String spaced = value.replaceAllMapped(
      RegExp(r'([a-z])([A-Z])'),
      (Match match) => '${match.group(1)} ${match.group(2)}',
    );
    return spaced
        .replaceAll('_', ' ')
        .split(' ')
        .where((String part) => part.isNotEmpty)
        .map((String part) =>
            '${part.substring(0, 1).toUpperCase()}${part.substring(1)}')
        .join(' ');
  }

  bool _isProtectedPackage(String packageName) {
    final String value = packageName.toLowerCase();
    return value == 'com.android.settings' ||
        value.contains('systemui') ||
        value.contains('launcher') ||
        value.contains('dialer') ||
        value.contains('incallui') ||
        value.contains('emergency') ||
        value.contains('permissioncontroller') ||
        value.contains('packageinstaller') ||
        value.contains('authenticator') ||
        value.contains('bank') ||
        value.contains('bkash') ||
        value.contains('nagad') ||
        value.contains('rocket') ||
        value.contains('wallet') ||
        value.contains('payment') ||
        value == 'com.hredoy.focus_guard_flutter';
  }
}

class _ProtectionHero extends StatelessWidget {
  const _ProtectionHero({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.active,
    required this.metrics,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final bool active;
  final List<_HeroMetric> metrics;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: active ? colors.primaryContainer : colors.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              CircleAvatar(
                backgroundColor:
                    active ? colors.primary : colors.surfaceContainerHighest,
                foregroundColor:
                    active ? colors.onPrimary : colors.onSurfaceVariant,
                child: Icon(icon),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                    const SizedBox(height: 3),
                    Text(subtitle),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: metrics
                .map(
                  (_HeroMetric metric) => Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(
                          metric.value,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          metric.label,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ],
      ),
    );
  }
}

class _HeroMetric {
  const _HeroMetric({required this.value, required this.label});

  final String value;
  final String label;
}

class _WeekdaySelector extends StatelessWidget {
  const _WeekdaySelector({
    required this.selected,
    required this.onChanged,
  });

  final Set<int> selected;
  final Future<void> Function(int day, bool selected) onChanged;

  @override
  Widget build(BuildContext context) {
    const List<String> labels = <String>['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return Wrap(
      spacing: 7,
      runSpacing: 7,
      children: List<Widget>.generate(7, (int index) {
        final int day = index + 1;
        return FilterChip(
          label: Text(labels[index]),
          selected: selected.contains(day),
          onSelected: (bool value) => onChanged(day, value),
        );
      }),
    );
  }
}

class _DurationSelector extends StatelessWidget {
  const _DurationSelector({
    required this.label,
    required this.minutes,
    required this.values,
    required this.onChanged,
  });

  final String label;
  final int minutes;
  final List<int> values;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) => DropdownButtonFormField<int>(
        key: ValueKey<String>('$label-$minutes'),
        initialValue: values.contains(minutes) ? minutes : values.first,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        items: values
            .map(
              (int value) => DropdownMenuItem<int>(
                value: value,
                child: Text(formatDuration(value)),
              ),
            )
            .toList(growable: false),
        onChanged: (int? value) {
          if (value != null) onChanged(value);
        },
      );
}

class _ProtectionAppPicker extends StatefulWidget {
  const _ProtectionAppPicker({
    required this.title,
    required this.apps,
    required this.selected,
  });

  final String title;
  final List<LaunchableAppInfo> apps;
  final Set<String> selected;

  @override
  State<_ProtectionAppPicker> createState() => _ProtectionAppPickerState();
}

class _ProtectionAppPickerState extends State<_ProtectionAppPicker> {
  late Set<String> _selected;
  String _query = '';
  String _group = 'all';

  @override
  void initState() {
    super.initState();
    _selected = <String>{...widget.selected};
  }

  @override
  Widget build(BuildContext context) {
    final String normalized = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered =
        widget.apps.where((LaunchableAppInfo app) {
      final bool matchesQuery = normalized.isEmpty ||
          app.label.toLowerCase().contains(normalized) ||
          app.packageName.toLowerCase().contains(normalized);
      return matchesQuery && app.matchesCategoryFilter(_group);
    }).toList(growable: false)
          ..sort((LaunchableAppInfo a, LaunchableAppInfo b) {
            final int group = a.category.compareTo(b.category);
            return group != 0
                ? group
                : a.label.toLowerCase().compareTo(b.label.toLowerCase());
          });

    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * 0.88,
        child: Column(
          children: <Widget>[
            Padding(
              key:
                  const ValueKey<String>('responsive-protection-picker-header'),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    widget.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).pop(_selected),
                    icon: const Icon(Icons.check_rounded),
                    label: Text('Save ${_selected.length} selected apps'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (String value) => setState(() => _query = value),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Search installed apps',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: <Widget>[
                  for (final MapEntry<String, String> item
                      in const <String, String>{
                    'all': 'All',
                    'distracting': 'Distracting',
                    'social': 'Social',
                    'video': 'Video',
                    'game': 'Games',
                    'shopping': 'Shopping',
                    'education': 'Education',
                    'useful': 'Useful',
                    'normal': 'Normal / safe',
                  }.entries) ...<Widget>[
                    FilterChip(
                      label: Text(item.value),
                      selected: _group == item.key,
                      onSelected: (_) => setState(() => _group = item.key),
                    ),
                    const SizedBox(width: 7),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: filtered.isEmpty
                  ? const EmptyState(
                      icon: Icons.search_off_rounded,
                      title: 'No apps found',
                      message: 'Try another app name or category.',
                    )
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (BuildContext context, int index) {
                        final LaunchableAppInfo app = filtered[index];
                        final bool selected =
                            _selected.contains(app.packageName);
                        return CheckboxListTile(
                          value: selected,
                          title: Text(
                            app.label,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                app.packageName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 3),
                              Text(
                                app.categoryLabel,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                            ],
                          ),
                          secondary: CircleAvatar(
                            child: Text(
                              app.label.isEmpty
                                  ? '?'
                                  : app.label.substring(0, 1).toUpperCase(),
                            ),
                          ),
                          onChanged: (bool? value) {
                            setState(() {
                              if (value ?? false) {
                                _selected.add(app.packageName);
                              } else {
                                _selected.remove(app.packageName);
                              }
                            });
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
