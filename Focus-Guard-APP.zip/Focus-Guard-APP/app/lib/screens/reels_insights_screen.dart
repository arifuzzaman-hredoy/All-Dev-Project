import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';
import '../widgets/rule_activation_preview.dart';
import 'wellbeing_alerts_screen.dart';

class ReelsInsightsScreen extends StatefulWidget {
  const ReelsInsightsScreen({super.key});

  @override
  State<ReelsInsightsScreen> createState() => _ReelsInsightsScreenState();
}

class _ReelsInsightsScreenState extends State<ReelsInsightsScreen>
    with WidgetsBindingObserver {
  static const Set<String> _knownPackages = <String>{
    'com.instagram.android',
    'com.facebook.katana',
    'com.google.android.youtube',
    'com.zhiliaoapp.musically',
    'com.ss.android.ugc.trill',
  };

  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlUsage _usage = const PhoneControlUsage();
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  bool _loading = true;
  bool _saving = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refreshUsage();
  }

  Future<void> _load() async {
    PhoneControlPolicy policy = const PhoneControlPolicy();
    PhoneControlUsage usage = const PhoneControlUsage();
    List<LaunchableAppInfo> apps = const <LaunchableAppInfo>[];
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      usage = await NativeBridge.phoneControlUsage();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _usage = usage;
      _apps = apps;
      _loading = false;
    });
  }

  Future<void> _refreshUsage() async {
    try {
      final PhoneControlUsage usage = await NativeBridge.phoneControlUsage();
      if (mounted) setState(() => _usage = usage);
    } catch (_) {}
  }

  List<LaunchableAppInfo> get _supportedApps {
    final Set<String> existingPackages = _policy.rules
        .where((AppControlRule rule) => rule.reelsGuard)
        .map((AppControlRule rule) => rule.packageName)
        .toSet();
    final List<LaunchableAppInfo> values = _apps.where((LaunchableAppInfo app) {
      return !app.protected &&
          (_knownPackages.contains(app.packageName) ||
              app.suggestedReelsGuard ||
              app.category == 'social' ||
              app.category == 'video' ||
              existingPackages.contains(app.packageName));
    }).toList(growable: true);
    for (final AppControlRule rule in _policy.rules) {
      if (!rule.reelsGuard ||
          values.any(
              (LaunchableAppInfo app) => app.packageName == rule.packageName)) {
        continue;
      }
      values.add(
        LaunchableAppInfo(
          packageName: rule.packageName,
          label: rule.label,
          category: rule.category,
          recommendation: 'review',
          reason: 'Existing Reels rule',
          suggestedReelsGuard: true,
        ),
      );
    }
    values.sort((LaunchableAppInfo a, LaunchableAppInfo b) =>
        a.label.toLowerCase().compareTo(b.label.toLowerCase()));
    return values;
  }

  Future<void> _edit(LaunchableAppInfo app) async {
    final AppControlRule existing = _policy.rules.firstWhere(
      (AppControlRule rule) => rule.packageName == app.packageName,
      orElse: () => AppControlRule(
        packageName: app.packageName,
        label: app.label,
        category: app.category,
        enabled: true,
        dailyLimitMinutes: 0,
        reelsGuard: true,
        blockReelsImmediately: false,
        reelsDailyLimit: 50,
        reelsTimeLimitMinutes: 30,
        reelsWarningPercentages: const <int>{50, 75, 90},
        scrollLimit: 0,
      ),
    );
    final AppControlRule? edited = await showModalBottomSheet<AppControlRule>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _ReelsRuleSheet(rule: existing),
    );
    if (edited == null || !mounted) return;

    final PhoneControlPolicy next = _policy.upsertRule(edited).copyWith(
          masterEnabled: edited.reelsGuard || _policy.masterEnabled,
          reelsBlockerEnabled: edited.reelsGuard || _policy.reelsBlockerEnabled,
          wellbeingWarningsEnabled: true,
        );
    await _save(next);
  }

  Future<void> _save(PhoneControlPolicy requested) async {
    if (_saving) return;
    final SmartFlowController? smart = SmartFlowScope.maybeOf(context);
    final Set<String> alwaysAllowed =
        smart?.settings.userAlwaysAllowedPackages ?? const <String>{};
    final PhoneControlPolicy safe =
        sanitizePhoneControlForAlwaysAllowed(requested, alwaysAllowed);
    if (smart?.settings.rulePreviewRequired ?? true) {
      final bool confirmed = await RuleActivationPreviewSheet.show(
        context,
        policy: safe,
        apps: _apps,
        alwaysAllowedPackages: alwaysAllowed,
      );
      if (!confirmed || !mounted) return;
    }
    setState(() => _saving = true);
    try {
      await NativeBridge.savePhoneControlPolicy(safe);
      final PhoneControlPolicy saved = await NativeBridge.phoneControlPolicy();
      final PhoneControlUsage usage = await NativeBridge.phoneControlUsage();
      if (!mounted) return;
      setState(() {
        _policy = saved;
        _usage = usage;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Per-app Reels limit and warning milestones saved.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save Reels settings: $error')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<LaunchableAppInfo> supported = _supportedApps;
    final String normalized = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered = supported
        .where((LaunchableAppInfo app) =>
            normalized.isEmpty ||
            app.label.toLowerCase().contains(normalized) ||
            app.packageName.toLowerCase().contains(normalized))
        .toList(growable: false);
    final int totalViewed = _usage.reelsViewed.values
        .fold<int>(0, (int total, int value) => total + value);
    final int totalMinutes = _usage.reelsWatchMillis.values
            .fold<int>(0, (int total, int value) => total + value) ~/
        60000;
    final int tracked = _policy.rules
        .where((AppControlRule rule) => rule.enabled && rule.reelsGuard)
        .length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reels & Shorts limits'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Warning settings',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const WellbeingAlertsScreen(),
              ),
            ),
            icon: const Icon(Icons.notifications_active_rounded),
          ),
          IconButton(
            tooltip: 'Refresh counts',
            onPressed: _refreshUsage,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 110),
                children: <Widget>[
                  Card(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            'Today’s short-video dashboard',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _SummaryMetric(
                                  label: 'Confirmed Reels',
                                  value: '$totalViewed',
                                  icon: Icons.smart_display_rounded,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _SummaryMetric(
                                  label: 'Watch time',
                                  value: '$totalMinutes min',
                                  icon: Icons.timer_rounded,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _SummaryMetric(
                                  label: 'Apps limited',
                                  value: '$tracked',
                                  icon: Icons.apps_rounded,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.info_outline_rounded),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Hybrid confirmed-count mode is active. Accessibility callbacks only create a delayed full-screen pager candidate; they never increase the count directly. Stable creator/caption fingerprints are preferred, while apps that hide identity text use one guarded fallback count after the swipe burst settles. Comment, caption and nested scrolling are rejected, and watch time remains an enforcement fallback.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Search supported installed apps',
                      prefixIcon: Icon(Icons.search_rounded),
                    ),
                    onChanged: (String value) => setState(() => _query = value),
                  ),
                  const SizedBox(height: 18),
                  SectionHeader(
                    title: 'Per-app limits',
                    subtitle:
                        '${filtered.length} supported apps • tap an app to set count, minutes and 50%/75% warnings.',
                  ),
                  if (filtered.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(18),
                        child: Text(
                          'No supported social or short-video app was detected. Install or launch the app once, then refresh.',
                        ),
                      ),
                    )
                  else
                    ...filtered.map(
                      (LaunchableAppInfo app) => _ReelsAppCard(
                        app: app,
                        rule: _policy.rules.cast<AppControlRule?>().firstWhere(
                              (AppControlRule? rule) =>
                                  rule?.packageName == app.packageName,
                              orElse: () => null,
                            ),
                        usage: _usage,
                        onTap: _saving ? null : () => _edit(app),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

class _SummaryMetric extends StatelessWidget {
  const _SummaryMetric({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: <Widget>[
            Icon(icon, size: 20),
            const SizedBox(height: 5),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
            Text(
              label,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ],
        ),
      );
}

class _ReelsAppCard extends StatelessWidget {
  const _ReelsAppCard({
    required this.app,
    required this.rule,
    required this.usage,
    required this.onTap,
  });

  final LaunchableAppInfo app;
  final AppControlRule? rule;
  final PhoneControlUsage usage;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final int viewed = usage.reelsViewedFor(app.packageName);
    final int minutes = usage.reelsWatchMinutesFor(app.packageName);
    final int blocked = usage.reelsBlockedFor(app.packageName);
    final int limit = rule?.reelsDailyLimit ?? 0;
    final bool tracking = rule?.enabled == true && rule?.reelsGuard == true;
    final double progress = limit <= 0 ? 0 : (viewed / limit).clamp(0.0, 1.0);
    final List<int> warnings =
        (rule?.reelsWarningPercentages ?? const <int>{50, 75, 90}).toList()
          ..sort();
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    child: Text(
                      app.label.trim().isEmpty
                          ? '?'
                          : app.label.trim()[0].toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          app.label,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        Text(
                          tracking
                              ? rule!.blockReelsImmediately
                                  ? 'Reels blocked immediately'
                                  : limit <= 0
                                      ? 'Tracking with no count limit'
                                      : '$viewed of $limit confirmed • ${(limit - viewed).clamp(0, limit)} remaining'
                              : 'Not tracking yet',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.tune_rounded),
                ],
              ),
              const SizedBox(height: 12),
              if (tracking && limit > 0) ...<Widget>[
                LinearProgressIndicator(value: progress),
                const SizedBox(height: 8),
              ],
              Wrap(
                spacing: 7,
                runSpacing: 7,
                children: <Widget>[
                  _SmallChip(
                    icon: Icons.smart_display_rounded,
                    label: '$viewed confirmed',
                  ),
                  _SmallChip(
                    icon: Icons.timer_rounded,
                    label: '$minutes min',
                  ),
                  if (blocked > 0)
                    _SmallChip(
                      icon: Icons.block_rounded,
                      label: '$blocked blocked',
                    ),
                  if (tracking)
                    _SmallChip(
                      icon: Icons.notifications_active_rounded,
                      label: warnings.map((int value) => '$value%').join(' / '),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SmallChip extends StatelessWidget {
  const _SmallChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 15),
            const SizedBox(width: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _ReelsRuleSheet extends StatefulWidget {
  const _ReelsRuleSheet({required this.rule});

  final AppControlRule rule;

  @override
  State<_ReelsRuleSheet> createState() => _ReelsRuleSheetState();
}

class _ReelsRuleSheetState extends State<_ReelsRuleSheet> {
  late bool _enabled;
  late bool _blockImmediately;
  late int _countLimit;
  late int _timeLimit;
  late Set<int> _warnings;
  late int _commitment;

  @override
  void initState() {
    super.initState();
    _enabled = widget.rule.reelsGuard;
    _blockImmediately = widget.rule.blockReelsImmediately;
    _countLimit = widget.rule.reelsDailyLimit;
    _timeLimit = widget.rule.reelsTimeLimitMinutes;
    _warnings = <int>{...widget.rule.reelsWarningPercentages};
    _commitment = widget.rule.commitmentPercent;
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.88,
          child: Column(
            children: <Widget>[
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  children: <Widget>[
                    Text(
                      widget.rule.label,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                    Text(widget.rule.packageName),
                    const SizedBox(height: 12),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Track and limit Reels / Shorts'),
                      subtitle: const Text(
                        'The normal app remains usable unless another app rule blocks it.',
                      ),
                      value: _enabled,
                      onChanged: widget.rule.commitmentActive
                          ? null
                          : (bool value) => setState(() => _enabled = value),
                    ),
                    if (_enabled) ...<Widget>[
                      SwitchListTile.adaptive(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Block every Reel immediately'),
                        subtitle: const Text(
                          'Count and minute limits are ignored while this is enabled.',
                        ),
                        value: _blockImmediately,
                        onChanged: widget.rule.commitmentActive
                            ? null
                            : (bool value) =>
                                setState(() => _blockImmediately = value),
                      ),
                      if (!_blockImmediately) ...<Widget>[
                        _LimitSlider(
                          label: 'Daily Reel / Short count',
                          value: _countLimit,
                          min: 0,
                          max: 500,
                          step: 1,
                          offLabel: 'No count limit',
                          enabled: !widget.rule.commitmentActive,
                          onChanged: (int value) =>
                              setState(() => _countLimit = value),
                        ),
                        const SizedBox(height: 12),
                        _LimitSlider(
                          label: 'Daily short-video minutes',
                          value: _timeLimit,
                          min: 0,
                          max: 240,
                          step: 5,
                          offLabel: 'No minute limit',
                          enabled: !widget.rule.commitmentActive,
                          onChanged: (int value) =>
                              setState(() => _timeLimit = value),
                        ),
                      ],
                      const SizedBox(height: 20),
                      const SectionHeader(
                        title: 'Progress notifications',
                        subtitle:
                            'Receive a detailed warning when this percentage of the count limit is reached.',
                      ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: <int>[25, 50, 75, 90, 100]
                            .map(
                              (int value) => FilterChip(
                                label: Text('$value%'),
                                selected: _warnings.contains(value),
                                onSelected: widget.rule.commitmentActive
                                    ? null
                                    : (bool selected) {
                                        setState(() {
                                          if (selected) {
                                            _warnings.add(value);
                                          } else if (_warnings.length > 1) {
                                            _warnings.remove(value);
                                          }
                                        });
                                      },
                              ),
                            )
                            .toList(growable: false),
                      ),
                      const SizedBox(height: 20),
                      SectionHeader(
                        title: 'Minimum commitment',
                        subtitle:
                            'At least $_commitment% of the configured allowance cannot be weakened after saving.',
                      ),
                      Slider(
                        value: _commitment.toDouble(),
                        min: 20,
                        max: 100,
                        divisions: 8,
                        label: '$_commitment%',
                        onChanged: widget.rule.commitmentActive
                            ? null
                            : (double value) =>
                                setState(() => _commitment = value.round()),
                      ),
                    ],
                    if (widget.rule.commitmentActive)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(14),
                          child: Text(
                            'This rule is inside its commitment window. It can be viewed but not weakened yet.',
                            style: TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: widget.rule.commitmentActive ? null : _save,
                    icon: const Icon(Icons.save_rounded),
                    label: const Text('Save per-app Reels limit'),
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  void _save() {
    Navigator.of(context).pop(
      widget.rule.copyWith(
        enabled: _enabled || widget.rule.enabled,
        reelsGuard: _enabled,
        blockReelsImmediately: _enabled && _blockImmediately,
        reelsDailyLimit: _enabled ? _countLimit : 0,
        reelsTimeLimitMinutes: _enabled ? _timeLimit : 0,
        reelsWarningPercentages: Set<int>.unmodifiable(
            _warnings.isEmpty ? <int>{50, 75, 90} : _warnings),
        commitmentPercent: _commitment,
      ),
    );
  }
}

class _LimitSlider extends StatelessWidget {
  const _LimitSlider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.step,
    required this.offLabel,
    required this.enabled,
    required this.onChanged,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final int step;
  final String offLabel;
  final bool enabled;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
              Text(value == 0 ? offLabel : '$value per day'),
              Slider(
                value: value.clamp(min, max).toDouble(),
                min: min.toDouble(),
                max: max.toDouble(),
                divisions: ((max - min) / step).round(),
                label: value == 0 ? offLabel : '$value',
                onChanged: enabled
                    ? (double raw) {
                        final int snapped = ((raw / step).round() * step)
                            .clamp(min, max)
                            .toInt();
                        onChanged(snapped);
                      }
                    : null,
              ),
            ],
          ),
        ),
      );
}
