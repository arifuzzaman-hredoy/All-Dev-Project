import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';

class ScheduleProfilesScreen extends StatefulWidget {
  const ScheduleProfilesScreen({super.key});

  @override
  State<ScheduleProfilesScreen> createState() => _ScheduleProfilesScreenState();
}

class _ScheduleProfilesScreenState extends State<ScheduleProfilesScreen>
    with WidgetsBindingObserver {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  List<ScheduleProfileRuntime> _runtime = const <ScheduleProfileRuntime>[];
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(showSpinner: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool showSpinner = true}) async {
    if (showSpinner && mounted) setState(() => _loading = true);
    PhoneControlPolicy policy = _policy;
    List<LaunchableAppInfo> apps = _apps;
    List<ScheduleProfileRuntime> runtime = _runtime;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    try {
      runtime = await NativeBridge.scheduleProfileRuntime();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      final Set<String> alwaysAllowed =
          SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
              const <String>{};
      _apps = apps.where((LaunchableAppInfo app) {
        return !_isProtectedPackage(app.packageName) &&
            !alwaysAllowed.contains(app.packageName);
      }).toList(growable: false);
      _runtime = runtime;
      _loading = false;
    });
  }

  Future<void> _savePolicy(PhoneControlPolicy policy) async {
    if (_saving) return;
    final Set<String> alwaysAllowed =
        SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
            const <String>{};
    final PhoneControlPolicy safePolicy =
        sanitizePhoneControlForAlwaysAllowed(policy, alwaysAllowed);
    final PhoneControlPolicy previous = _policy;
    setState(() {
      _policy = safePolicy;
      _saving = true;
    });
    try {
      await NativeBridge.savePhoneControlPolicy(safePolicy);
      if (!mounted) return;
      setState(() => _policy = safePolicy);
    } catch (error) {
      if (!mounted) return;
      setState(() => _policy = previous);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save schedule profiles: $error')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _createProfile({ScheduleProfile? template}) async {
    final ScheduleProfile seed = template ??
        ScheduleProfile(
          id: 'profile-${DateTime.now().microsecondsSinceEpoch}',
          name: 'New schedule',
        );
    final ScheduleProfile? result = await Navigator.of(context).push(
      MaterialPageRoute<ScheduleProfile>(
        builder: (_) => _ScheduleProfileEditor(
          profile: seed,
          apps: _apps,
          existingProfiles: _policy.profiles,
        ),
      ),
    );
    if (result != null && mounted) {
      await _savePolicy(_policy.upsertProfile(result));
    }
  }

  Future<void> _editProfile(ScheduleProfile profile) async {
    final ScheduleProfile? result = await Navigator.of(context).push(
      MaterialPageRoute<ScheduleProfile>(
        builder: (_) => _ScheduleProfileEditor(
          profile: profile,
          apps: _apps,
          existingProfiles: _policy.profiles
              .where((ScheduleProfile item) => item.id != profile.id)
              .toList(growable: false),
        ),
      ),
    );
    if (result != null && mounted) {
      await _savePolicy(_policy.upsertProfile(result));
    }
  }

  Future<void> _duplicateProfile(ScheduleProfile profile) async {
    final ScheduleProfile duplicate = profile.copyWith(
      id: 'profile-${DateTime.now().microsecondsSinceEpoch}',
      name: '${profile.name} copy',
      enabled: false,
    );
    await _createProfile(template: duplicate);
  }

  Future<void> _removeProfile(ScheduleProfile profile) async {
    final bool? approved = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text('Delete ${profile.name}?'),
        content: const Text(
          'Only this schedule profile will be removed. Your routine, tasks, alarms, app rules and usage history stay unchanged.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete profile'),
          ),
        ],
      ),
    );
    if (approved == true) {
      await _savePolicy(_policy.removeProfile(profile.id));
    }
  }

  Future<void> _showTemplates() async {
    final Set<String> socialPackages = _apps
        .where((LaunchableAppInfo app) {
          final String value = app.packageName.toLowerCase();
          return value.contains('instagram') ||
              value.contains('facebook') ||
              value.contains('youtube') ||
              value.contains('tiktok') ||
              value.contains('musically') ||
              value.contains('twitter') ||
              value.contains('snapchat');
        })
        .map((LaunchableAppInfo app) => app.packageName)
        .toSet();
    final ScheduleProfile? selected =
        await showModalBottomSheet<ScheduleProfile>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'Quick schedule templates',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              const Text(
                'Templates open in the editor before saving, so you stay in control.',
              ),
              const SizedBox(height: 14),
              _TemplateTile(
                icon: Icons.school_rounded,
                title: 'Student Focus',
                subtitle: 'Sun–Thu • 7:00 PM–11:00 PM',
                onTap: () => Navigator.of(sheetContext).pop(
                  ScheduleProfile(
                    id: 'profile-${DateTime.now().microsecondsSinceEpoch}',
                    name: 'Student Focus',
                    blockedPackages: socialPackages,
                    weekdays: const <int>{7, 1, 2, 3, 4},
                    startMinute: 19 * 60,
                    endMinute: 23 * 60,
                    emergencyUnlockMinutes: 10,
                    maxEmergencyUnlocksPerDay: 1,
                    silenceNotifications: true,
                  ),
                ),
              ),
              _TemplateTile(
                icon: Icons.bedtime_rounded,
                title: 'Night Detox',
                subtitle: 'Every day • 10:00 PM–6:00 AM',
                onTap: () => Navigator.of(sheetContext).pop(
                  ScheduleProfile(
                    id: 'profile-${DateTime.now().microsecondsSinceEpoch}',
                    name: 'Night Detox',
                    blockedPackages: socialPackages,
                    startMinute: 22 * 60,
                    endMinute: 6 * 60,
                    emergencyUnlockMinutes: 5,
                    maxEmergencyUnlocksPerDay: 1,
                    silenceNotifications: true,
                  ),
                ),
              ),
              _TemplateTile(
                icon: Icons.work_history_rounded,
                title: 'Productive Work',
                subtitle: 'Sun–Thu • 2:00 PM–7:00 PM',
                onTap: () => Navigator.of(sheetContext).pop(
                  ScheduleProfile(
                    id: 'profile-${DateTime.now().microsecondsSinceEpoch}',
                    name: 'Productive Work',
                    blockedPackages: socialPackages,
                    weekdays: const <int>{7, 1, 2, 3, 4},
                    startMinute: 14 * 60,
                    endMinute: 19 * 60,
                    emergencyUnlockMinutes: 10,
                    maxEmergencyUnlocksPerDay: 2,
                    silenceNotifications: true,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (selected != null && mounted) await _createProfile(template: selected);
  }

  ScheduleProfileRuntime _runtimeFor(String id) => _runtime.firstWhere(
        (ScheduleProfileRuntime value) => value.profileId == id,
        orElse: () => ScheduleProfileRuntime(profileId: id),
      );

  Future<void> _requestUnlock(ScheduleProfile profile) async {
    final ScheduleProfileRuntime result =
        await NativeBridge.requestScheduleProfileUnlock(
      profileId: profile.id,
      minutes: profile.emergencyUnlockMinutes,
    );
    if (!mounted) return;
    await _load(showSpinner: false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result.granted
              ? '${profile.name} unlocked for ${profile.emergencyUnlockMinutes} minutes.'
              : 'Emergency unlock limit reached for today.',
        ),
      ),
    );
  }

  Future<void> _cancelUnlock(ScheduleProfile profile) async {
    await NativeBridge.cancelScheduleProfileUnlock(profile.id);
    if (mounted) await _load(showSpinner: false);
  }

  @override
  Widget build(BuildContext context) {
    final int activeNow = _policy.profiles.where((ScheduleProfile profile) {
      final ScheduleProfileRuntime runtime = _runtimeFor(profile.id);
      return profile.isActiveAt(DateTime.now()) && !runtime.isUnlockedNow;
    }).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Schedule Profiles'),
        actions: <Widget>[
          if (_saving)
            const Padding(
              padding: EdgeInsets.only(right: 18),
              child: Center(
                child: SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            )
          else
            IconButton(
              tooltip: 'Refresh',
              onPressed: () => _load(),
              icon: const Icon(Icons.refresh_rounded),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _loading ? null : () => _createProfile(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('New profile'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                key: const ValueKey<String>('schedule-profiles-scroll-view'),
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                children: <Widget>[
                  _ProfileHero(
                    enabled: _policy.scheduleProfilesEnabled,
                    profileCount: _policy.profiles.length,
                    activeNow: activeNow,
                    masterEnabled: _policy.masterEnabled,
                    onChanged: (bool value) => _savePolicy(
                      _policy.copyWith(scheduleProfilesEnabled: value),
                    ),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: () => _showTemplates(),
                    icon: const Icon(Icons.auto_awesome_rounded),
                    label: const Text('Use a quick template'),
                  ),
                  const SizedBox(height: 22),
                  SectionHeader(
                    title: 'Your recurring profiles',
                    subtitle:
                        'Multiple active profiles use block-wins overlap handling.',
                    action: IconButton.filledTonal(
                      tooltip: 'Create profile',
                      onPressed: () => _createProfile(),
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (_policy.profiles.isEmpty)
                    const EmptyState(
                      icon: Icons.schedule_rounded,
                      title: 'No schedule profiles yet',
                      message:
                          'Create Student Focus, Night Detox or a custom recurring profile. Existing app rules remain separate.',
                    )
                  else
                    ..._policy.profiles.map((ScheduleProfile profile) {
                      final ScheduleProfileRuntime runtime =
                          _runtimeFor(profile.id);
                      final int overlaps = _policy.profiles
                          .where(
                            (ScheduleProfile other) =>
                                other.id != profile.id &&
                                profile.overlapsWith(other),
                          )
                          .length;
                      return _ScheduleProfileCard(
                        profile: profile,
                        runtime: runtime,
                        activeNow: profile.isActiveAt(DateTime.now()),
                        appLabels: <String, String>{
                          for (final LaunchableAppInfo app in _apps)
                            app.packageName: app.label,
                        },
                        overlapCount: overlaps,
                        onToggle: (bool value) => _savePolicy(
                          _policy.upsertProfile(
                            profile.copyWith(enabled: value),
                          ),
                        ),
                        onEdit: () => _editProfile(profile),
                        onDuplicate: () => _duplicateProfile(profile),
                        onDelete: () => _removeProfile(profile),
                        onUnlock: profile.emergencyUnlockMinutes > 0 &&
                                profile.maxEmergencyUnlocksPerDay > 0
                            ? () => _requestUnlock(profile)
                            : null,
                        onCancelUnlock: runtime.isUnlockedNow
                            ? () => _cancelUnlock(profile)
                            : null,
                      );
                    }),
                  const SizedBox(height: 16),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.shield_outlined),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Schedule Profiles block selected apps during the active window. Per-app allowed-hour rules, daily limits and Reels Guard continue to work independently. If two profiles overlap, the stricter active block wins.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  bool _isProtectedPackage(String packageName) {
    final String value = packageName.toLowerCase();
    return value == 'com.android.settings' ||
        value.contains('systemui') ||
        value.contains('launcher') ||
        value.contains('dialer') ||
        value.contains('incallui') ||
        value.contains('emergency') ||
        value.contains('permissioncontroller') ||
        value.contains('packageinstaller') ||
        value.contains('authenticator') ||
        value.contains('bank') ||
        value.contains('bkash') ||
        value.contains('nagad') ||
        value.contains('rocket') ||
        value.contains('wallet') ||
        value.contains('payment') ||
        value == 'com.hredoy.focus_guard_flutter';
  }
}

class _ProfileHero extends StatelessWidget {
  const _ProfileHero({
    required this.enabled,
    required this.profileCount,
    required this.activeNow,
    required this.masterEnabled,
    required this.onChanged,
  });

  final bool enabled;
  final int profileCount;
  final int activeNow;
  final bool masterEnabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: colors.primaryContainer,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outlineVariant),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              CircleAvatar(
                radius: 25,
                backgroundColor: colors.primary,
                foregroundColor: colors.onPrimary,
                child: const Icon(Icons.calendar_month_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'Automatic schedule profiles',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                    ),
                    Text('$activeNow active now • $profileCount saved'),
                  ],
                ),
              ),
              Switch.adaptive(value: enabled, onChanged: onChanged),
            ],
          ),
          if (!masterEnabled) ...<Widget>[
            const SizedBox(height: 12),
            const Row(
              children: <Widget>[
                Icon(Icons.info_outline_rounded, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Profiles are saved, but Master Phone Control is currently paused.',
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _ScheduleProfileCard extends StatelessWidget {
  const _ScheduleProfileCard({
    required this.profile,
    required this.runtime,
    required this.activeNow,
    required this.appLabels,
    required this.overlapCount,
    required this.onToggle,
    required this.onEdit,
    required this.onDuplicate,
    required this.onDelete,
    required this.onUnlock,
    required this.onCancelUnlock,
  });

  final ScheduleProfile profile;
  final ScheduleProfileRuntime runtime;
  final bool activeNow;
  final Map<String, String> appLabels;
  final int overlapCount;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDuplicate;
  final VoidCallback onDelete;
  final VoidCallback? onUnlock;
  final VoidCallback? onCancelUnlock;

  @override
  Widget build(BuildContext context) {
    final bool effectiveActive = activeNow && !runtime.isUnlockedNow;
    final ColorScheme colors = Theme.of(context).colorScheme;
    final List<String> labels = profile.blockedPackages
        .map((String packageName) => appLabels[packageName] ?? packageName)
        .toList(growable: false)
      ..sort();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                CircleAvatar(
                  backgroundColor: effectiveActive
                      ? colors.primary
                      : colors.surfaceContainerHighest,
                  foregroundColor:
                      effectiveActive ? colors.onPrimary : colors.onSurface,
                  child: Icon(
                    runtime.isUnlockedNow
                        ? Icons.lock_open_rounded
                        : Icons.schedule_rounded,
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        profile.name,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text(
                        '${profile.scheduleLabel()} • ${_dayLabel(profile.weekdays)}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                Switch.adaptive(value: profile.enabled, onChanged: onToggle),
                PopupMenuButton<String>(
                  onSelected: (String value) {
                    if (value == 'edit') onEdit();
                    if (value == 'duplicate') onDuplicate();
                    if (value == 'delete') onDelete();
                  },
                  itemBuilder: (_) => const <PopupMenuEntry<String>>[
                    PopupMenuItem<String>(value: 'edit', child: Text('Edit')),
                    PopupMenuItem<String>(
                      value: 'duplicate',
                      child: Text('Duplicate'),
                    ),
                    PopupMenuItem<String>(
                      value: 'delete',
                      child: Text('Delete'),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 11),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: <Widget>[
                _SmallBadge(
                  icon: effectiveActive
                      ? Icons.lock_rounded
                      : Icons.lock_open_rounded,
                  label: runtime.isUnlockedNow
                      ? 'Emergency unlock active'
                      : effectiveActive
                          ? 'Blocking now'
                          : 'Not active now',
                  emphasized: effectiveActive,
                ),
                _SmallBadge(
                  icon: Icons.apps_rounded,
                  label: '${profile.blockedPackages.length} apps',
                ),
                if (overlapCount > 0)
                  _SmallBadge(
                    icon: Icons.layers_rounded,
                    label: '$overlapCount overlap • block wins',
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              labels.isEmpty
                  ? 'No apps selected yet'
                  : labels.take(4).join(' • ') +
                      (labels.length > 4 ? ' • +${labels.length - 4}' : ''),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    'Emergency unlocks: ${runtime.unlocksUsedToday}/${profile.maxEmergencyUnlocksPerDay} today',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                if (runtime.isUnlockedNow)
                  TextButton.icon(
                    onPressed: onCancelUnlock,
                    icon: const Icon(Icons.lock_rounded, size: 18),
                    label: const Text('Resume lock'),
                  )
                else if (activeNow && onUnlock != null)
                  TextButton.icon(
                    onPressed: onUnlock,
                    icon: const Icon(Icons.lock_open_rounded, size: 18),
                    label: Text('${profile.emergencyUnlockMinutes}m unlock'),
                  ),
              ],
            ),
            if (profile.silenceNotifications) ...<Widget>[
              const SizedBox(height: 7),
              const Align(
                alignment: Alignment.centerLeft,
                child: _SmallBadge(
                  icon: Icons.notifications_off_rounded,
                  label: 'Notifications silent',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _SmallBadge extends StatelessWidget {
  const _SmallBadge({
    required this.icon,
    required this.label,
    this.emphasized = false,
  });

  final IconData icon;
  final String label;
  final bool emphasized;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: emphasized
              ? Theme.of(context).colorScheme.primaryContainer
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 15),
            const SizedBox(width: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _TemplateTile extends StatelessWidget {
  const _TemplateTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(child: Icon(icon)),
          title:
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );
}

class _ScheduleProfileEditor extends StatefulWidget {
  const _ScheduleProfileEditor({
    required this.profile,
    required this.apps,
    required this.existingProfiles,
  });

  final ScheduleProfile profile;
  final List<LaunchableAppInfo> apps;
  final List<ScheduleProfile> existingProfiles;

  @override
  State<_ScheduleProfileEditor> createState() => _ScheduleProfileEditorState();
}

class _ScheduleProfileEditorState extends State<_ScheduleProfileEditor> {
  late final TextEditingController _nameController;
  late bool _enabled;
  late Set<String> _packages;
  late Set<int> _weekdays;
  late int _startMinute;
  late int _endMinute;
  late int _unlockMinutes;
  late int _maxUnlocks;
  late bool _silenceNotifications;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.profile.name);
    _enabled = widget.profile.enabled;
    _packages = <String>{...widget.profile.blockedPackages};
    _weekdays = <int>{...widget.profile.weekdays};
    _startMinute = widget.profile.startMinute;
    _endMinute = widget.profile.endMinute;
    _unlockMinutes = widget.profile.emergencyUnlockMinutes;
    _maxUnlocks = widget.profile.maxEmergencyUnlocksPerDay;
    _silenceNotifications = widget.profile.silenceNotifications;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  ScheduleProfile get _draft => widget.profile.copyWith(
        name: _nameController.text.trim(),
        enabled: _enabled,
        blockedPackages: _packages,
        weekdays: _weekdays,
        startMinute: _startMinute,
        endMinute: _endMinute,
        emergencyUnlockMinutes: _unlockMinutes,
        maxEmergencyUnlocksPerDay: _maxUnlocks,
        silenceNotifications: _silenceNotifications,
      );

  Future<void> _pickTime({required bool start}) async {
    final int current = start ? _startMinute : _endMinute;
    final TimeOfDay? selected = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: current ~/ 60, minute: current % 60),
    );
    if (selected == null || !mounted) return;
    setState(() {
      final int value = selected.hour * 60 + selected.minute;
      if (start) {
        _startMinute = value;
      } else {
        _endMinute = value;
      }
    });
  }

  Future<void> _pickApps() async {
    final Set<String>? selected = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _MultiAppPickerSheet(
        apps: widget.apps,
        selected: _packages,
      ),
    );
    if (selected != null && mounted) setState(() => _packages = selected);
  }

  void _save() {
    final String name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a profile name.')),
      );
      return;
    }
    if (_weekdays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one weekday.')),
      );
      return;
    }
    if (_packages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one app to block.')),
      );
      return;
    }
    Navigator.of(context).pop(_draft);
  }

  @override
  Widget build(BuildContext context) {
    final int overlapCount = widget.existingProfiles
        .where((ScheduleProfile profile) => _draft.overlapsWith(profile))
        .length;
    final Map<String, String> labels = <String, String>{
      for (final LaunchableAppInfo app in widget.apps)
        app.packageName: app.label,
    };
    return Scaffold(
      appBar: AppBar(title: const Text('Schedule profile')),
      body: ListView(
        key: const ValueKey<String>('schedule-profile-editor-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
        children: <Widget>[
          TextField(
            controller: _nameController,
            textInputAction: TextInputAction.done,
            decoration: const InputDecoration(
              labelText: 'Profile name',
              prefixIcon: Icon(Icons.badge_outlined),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Profile enabled'),
            subtitle:
                const Text('Automatically activates on selected days and time'),
            value: _enabled,
            onChanged: (bool value) => setState(() => _enabled = value),
          ),
          const SizedBox(height: 18),
          const SectionHeader(
            title: 'Recurring days',
            subtitle: 'Choose every day when this profile should run.',
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: List<Widget>.generate(7, (int index) {
              final int day = index + 1;
              return FilterChip(
                label: Text(_shortDay(day)),
                selected: _weekdays.contains(day),
                onSelected: (bool selected) => setState(() {
                  if (selected) {
                    _weekdays.add(day);
                  } else {
                    _weekdays.remove(day);
                  }
                }),
              );
            }),
          ),
          const SizedBox(height: 18),
          const SectionHeader(
            title: 'Active time',
            subtitle: 'Overnight windows such as 10 PM–6 AM are supported.',
          ),
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              Expanded(
                child: _TimeCard(
                  label: 'Starts',
                  value: formatMinuteOfDay(_startMinute),
                  onTap: () => _pickTime(start: true),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _TimeCard(
                  label: 'Ends',
                  value: formatMinuteOfDay(_endMinute),
                  onTap: () => _pickTime(start: false),
                ),
              ),
            ],
          ),
          if (overlapCount > 0) ...<Widget>[
            const SizedBox(height: 10),
            Card(
              color: Theme.of(context).colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(13),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.layers_rounded),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'Overlaps with $overlapCount profile${overlapCount == 1 ? '' : 's'}. Block-wins resolution will keep shared apps protected.',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 18),
          SectionHeader(
            title: 'Blocked apps',
            subtitle: '${_packages.length} apps selected',
            action: FilledButton.tonalIcon(
              onPressed: _pickApps,
              icon: const Icon(Icons.apps_rounded),
              label: const Text('Choose'),
            ),
          ),
          const SizedBox(height: 8),
          if (_packages.isEmpty)
            const EmptyState(
              icon: Icons.apps_rounded,
              title: 'No apps selected',
              message: 'Choose the distracting apps this profile will block.',
            )
          else
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: _packages.map((String packageName) {
                return InputChip(
                  label: Text(labels[packageName] ?? packageName),
                  onDeleted: () => setState(() {
                    _packages.remove(packageName);
                  }),
                );
              }).toList(growable: false),
            ),
          const SizedBox(height: 18),
          Card(
            child: SwitchListTile.adaptive(
              secondary: const CircleAvatar(
                child: Icon(Icons.notifications_off_rounded),
              ),
              title: const Text(
                'Silence selected app notifications',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: const Text(
                'Requires Notification Access and the global Notification Blocker.',
              ),
              value: _silenceNotifications,
              onChanged: (bool value) =>
                  setState(() => _silenceNotifications = value),
            ),
          ),
          const SizedBox(height: 22),
          const SectionHeader(
            title: 'Emergency unlock',
            subtitle: 'Optional short access without disabling the profile.',
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            key: ValueKey<int>(_unlockMinutes),
            initialValue: _unlockMinutes,
            decoration: const InputDecoration(
              labelText: 'Unlock duration',
              prefixIcon: Icon(Icons.lock_open_rounded),
            ),
            items: const <int>[0, 5, 10, 15, 20, 30]
                .map(
                  (int value) => DropdownMenuItem<int>(
                    value: value,
                    child: Text(value == 0 ? 'Disabled' : '$value minutes'),
                  ),
                )
                .toList(growable: false),
            onChanged: (int? value) => setState(() {
              _unlockMinutes = value ?? 0;
              if (_unlockMinutes == 0) _maxUnlocks = 0;
            }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            key: ValueKey<String>('max-unlocks-$_maxUnlocks-$_unlockMinutes'),
            initialValue: _maxUnlocks,
            decoration: const InputDecoration(
              labelText: 'Maximum unlocks per day',
              prefixIcon: Icon(Icons.pin_outlined),
            ),
            items: const <int>[0, 1, 2, 3, 4, 5]
                .map(
                  (int value) => DropdownMenuItem<int>(
                    value: value,
                    child: Text(
                        value == 0 ? 'No emergency unlock' : '$value times'),
                  ),
                )
                .toList(growable: false),
            onChanged: _unlockMinutes == 0
                ? null
                : (int? value) => setState(() => _maxUnlocks = value ?? 0),
          ),
          const SizedBox(height: 14),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Safety apps such as Phone, Settings, launcher, emergency, banking and authenticator apps should never be selected. Hredoy Flow filters core Android safety packages automatically.',
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.save_rounded),
          label: const Text('Save schedule profile'),
        ),
      ),
    );
  }
}

class _TimeCard extends StatelessWidget {
  const _TimeCard({
    required this.label,
    required this.value,
    required this.onTap,
  });

  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(label, style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ),
      );
}

class _MultiAppPickerSheet extends StatefulWidget {
  const _MultiAppPickerSheet({required this.apps, required this.selected});

  final List<LaunchableAppInfo> apps;
  final Set<String> selected;

  @override
  State<_MultiAppPickerSheet> createState() => _MultiAppPickerSheetState();
}

class _MultiAppPickerSheetState extends State<_MultiAppPickerSheet> {
  late Set<String> _selected;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _selected = <String>{...widget.selected};
  }

  @override
  Widget build(BuildContext context) {
    final String normalized = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered = widget.apps.where(
      (LaunchableAppInfo app) {
        return normalized.isEmpty ||
            app.label.toLowerCase().contains(normalized) ||
            app.packageName.toLowerCase().contains(normalized);
      },
    ).toList(growable: false);
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * 0.88,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Search installed apps',
                        prefixIcon: Icon(Icons.search_rounded),
                      ),
                      onChanged: (String value) =>
                          setState(() => _query = value),
                    ),
                  ),
                  const SizedBox(width: 10),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pop(_selected),
                    child: Text('Done (${_selected.length})'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(child: Text('No safe launchable apps found.'))
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (BuildContext context, int index) {
                        final LaunchableAppInfo app = filtered[index];
                        return CheckboxListTile(
                          value: _selected.contains(app.packageName),
                          secondary: CircleAvatar(
                            child: Text(
                              app.label.trim().isEmpty
                                  ? '?'
                                  : app.label
                                      .trim()
                                      .substring(0, 1)
                                      .toUpperCase(),
                            ),
                          ),
                          title: Text(app.label),
                          subtitle: Text(
                            app.packageName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          onChanged: (bool? value) => setState(() {
                            if (value == true) {
                              _selected.add(app.packageName);
                            } else {
                              _selected.remove(app.packageName);
                            }
                          }),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

String _shortDay(int day) =>
    const <int, String>{
      1: 'Mon',
      2: 'Tue',
      3: 'Wed',
      4: 'Thu',
      5: 'Fri',
      6: 'Sat',
      7: 'Sun',
    }[day] ??
    '?';

String _dayLabel(Set<int> days) {
  if (days.length == 7) return 'Every day';
  if (days.length == 5 && days.containsAll(const <int>{1, 2, 3, 4, 5})) {
    return 'Mon–Fri';
  }
  final List<int> sorted = days.toList(growable: false)..sort();
  return sorted.map(_shortDay).join(', ');
}
