import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../services/native_bridge.dart';
import '../widgets/app_logo.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  String _name = 'Hredoy';
  int _page = 0;
  bool _finishing = false;

  static const List<_SlideData> _slides = <_SlideData>[
    _SlideData(
      icon: Icons.dashboard_customize_rounded,
      eyebrow: 'COMMAND CENTER',
      title: 'See the next action, not a messy list',
      description:
          'Today combines your routine, current task, focus minutes, streak and exam countdown in one calm dashboard.',
      points: <String>[
        'Clear next-action card',
        'Routine progress at a glance',
        'Fast Today, Planner and Focus navigation',
      ],
    ),
    _SlideData(
      icon: Icons.restart_alt_rounded,
      eyebrow: 'FRESH ROUTINE',
      title: 'Restart fresh on 26 July',
      description:
          'The new routine begins on Sunday, 26 July 2026 at 6:30 AM. Older generated routine blocks are removed so the new schedule starts cleanly.',
      points: <String>[
        'Physical office fixed at 2:00–7:00 PM',
        'No unexplained empty gaps',
        'Custom tasks remain safe during reset',
      ],
    ),
    _SlideData(
      icon: Icons.shield_rounded,
      eyebrow: 'FOCUS SHIELD',
      title: 'Keep distracting apps outside the session',
      description:
          'Choose apps directly from your installed-app list. During focus, the Accessibility App Blocker returns selected apps to Home.',
      points: <String>[
        'Screen stays awake while the focus timer is visible',
        'Optional Do Not Disturb',
        'Installed-app picker avoids wrong package names',
      ],
    ),
    _SlideData(
      icon: Icons.alarm_on_rounded,
      eyebrow: 'RELIABLE ALARMS',
      title: 'Wake the task even with the screen locked',
      description:
          'Exact alarm scheduling, alarm-clock delivery, foreground sound, vibration and a wake lock work together for important routine blocks.',
      points: <String>[
        'Different sound for every kind of work',
        'Full-screen Stop and Snooze controls',
        'Built-in, phone and custom audio choices',
      ],
    ),
    _SlideData(
      icon: Icons.sports_esports_rounded,
      eyebrow: 'STUDY QUEST',
      title: 'Turn real study into levels',
      description:
          'Focus minutes, completed tasks and streaks earn XP. Your knowledge tree grows from a seed into a scholar-level system.',
      points: <String>[
        'Daily focus and completion quests',
        'Level rewards and rank progression',
        'Goals auto-sync with completed subject tasks',
      ],
    ),
    _SlideData(
      icon: Icons.verified_user_rounded,
      eyebrow: 'PHONE SETUP',
      title: 'Complete these permissions once',
      description:
          'Enable the items below for locked-screen alarms and app blocking. The Settings readiness card will show what is still missing.',
      points: <String>[
        'Notifications and exact alarms',
        'Full-screen alarm access',
        'Accessibility blocker and battery Unrestricted',
      ],
      setup: true,
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: <Widget>[
                  const Expanded(
                    child: AppLogo(
                      size: 44,
                      showWordmark: true,
                      compact: true,
                    ),
                  ),
                  TextButton(
                    onPressed: _finishing ? null : _finish,
                    child: const Text('Skip'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _slides.length,
                onPageChanged: (int value) => setState(() => _page = value),
                itemBuilder: (BuildContext context, int index) {
                  final _SlideData slide = _slides[index];
                  return SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(22, 22, 22, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Container(
                          constraints: const BoxConstraints(minHeight: 176),
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: <Color>[
                                colors.primaryContainer,
                                colors.tertiaryContainer,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: 92,
                                height: 92,
                                decoration: BoxDecoration(
                                  color: colors.surface.withValues(alpha: .78),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  slide.icon,
                                  size: 50,
                                  color: colors.primary,
                                ),
                              ),
                              const SizedBox(height: 18),
                              Text(
                                slide.eyebrow,
                                style: Theme.of(context)
                                    .textTheme
                                    .labelLarge
                                    ?.copyWith(
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.8,
                                      color: colors.primary,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 26),
                        Text(
                          slide.title,
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(
                                fontWeight: FontWeight.w900,
                                letterSpacing: -.5,
                              ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          slide.description,
                          textAlign: TextAlign.center,
                          style:
                              Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    height: 1.45,
                                    color: colors.onSurfaceVariant,
                                  ),
                        ),
                        const SizedBox(height: 18),
                        ...slide.points.map(
                          (String point) => Padding(
                            padding: const EdgeInsets.only(bottom: 9),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Icon(
                                  Icons.check_circle_rounded,
                                  size: 20,
                                  color: colors.primary,
                                ),
                                const SizedBox(width: 10),
                                Expanded(child: Text(point)),
                              ],
                            ),
                          ),
                        ),
                        if (slide.setup) ...<Widget>[
                          const SizedBox(height: 14),
                          TextFormField(
                            initialValue: _name,
                            textCapitalization: TextCapitalization.words,
                            decoration: const InputDecoration(
                              labelText: 'Your name',
                              prefixIcon: Icon(Icons.person_rounded),
                            ),
                            onChanged: (String value) => _name = value,
                          ),
                          const SizedBox(height: 12),
                          _PermissionButton(
                            icon: Icons.notifications_active_rounded,
                            label: 'Enable notifications',
                            onPressed:
                                NativeBridge.requestNotificationPermission,
                          ),
                          const SizedBox(height: 8),
                          _PermissionButton(
                            icon: Icons.alarm_rounded,
                            label: 'Allow exact alarms',
                            onPressed: NativeBridge.openExactAlarmSettings,
                          ),
                          const SizedBox(height: 8),
                          _PermissionButton(
                            icon: Icons.fullscreen_rounded,
                            label: 'Allow full-screen alarms',
                            onPressed: NativeBridge.openFullScreenAlarmSettings,
                          ),
                          const SizedBox(height: 8),
                          _PermissionButton(
                            icon: Icons.app_blocking_rounded,
                            label: 'Enable Accessibility App Blocker',
                            onPressed: NativeBridge.openAccessibilitySettings,
                          ),
                          const SizedBox(height: 8),
                          _PermissionButton(
                            icon: Icons.battery_saver_rounded,
                            label: 'Request battery Unrestricted',
                            onPressed: NativeBridge
                                .requestBatteryOptimizationExemption,
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
              child: Column(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List<Widget>.generate(
                      _slides.length,
                      (int index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: index == _page ? 26 : 8,
                        height: 8,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: index == _page
                              ? colors.primary
                              : colors.outlineVariant,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _finishing
                          ? null
                          : _page == _slides.length - 1
                              ? _finish
                              : _next,
                      icon: _finishing
                          ? const SizedBox.square(
                              dimension: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(
                              _page == _slides.length - 1
                                  ? Icons.check_rounded
                                  : Icons.arrow_forward_rounded,
                            ),
                      label: Text(
                        _page == _slides.length - 1
                            ? 'Start using Hredoy Flow'
                            : 'Continue',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _next() async {
    await _pageController.nextPage(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _finish() async {
    if (_finishing) return;
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() => _finishing = true);
    await Future<void>.delayed(const Duration(milliseconds: 80));
    if (!mounted) return;
    final String name = _name.trim().isEmpty ? 'Hredoy' : _name.trim();
    await AppScope.of(context).completeOnboarding(name);
  }
}

class _PermissionButton extends StatelessWidget {
  const _PermissionButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final Future<void> Function() onPressed;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () async {
            try {
              await onPressed();
            } catch (_) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Could not open system settings.'),
                  ),
                );
              }
            }
          },
          icon: Icon(icon),
          label: Text(label),
        ),
      );
}

class _SlideData {
  const _SlideData({
    required this.icon,
    required this.eyebrow,
    required this.title,
    required this.description,
    required this.points,
    this.setup = false,
  });

  final IconData icon;
  final String eyebrow;
  final String title;
  final String description;
  final List<String> points;
  final bool setup;
}
