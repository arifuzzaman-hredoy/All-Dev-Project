import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/app_controller.dart';
import '../models/alarm_presets.dart';
import '../models/alarm_sounds.dart';
import '../models/app_models.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';
import 'alarm_preset_screen.dart';
import 'alarm_sound_picker_screen.dart';

class TaskEditorScreen extends StatefulWidget {
  const TaskEditorScreen({this.task, this.initialDate, super.key});

  final TaskItem? task;
  final DateTime? initialDate;

  @override
  State<TaskEditorScreen> createState() => _TaskEditorScreenState();
}

class _TaskEditorScreenState extends State<TaskEditorScreen> {
  late String _title;
  late String _notes;
  late DateTime _date;
  late TimeOfDay _time;
  late String _subjectId;
  late int _duration;
  late int _priority;
  late bool _reminderEnabled;
  late bool _alarmEnabled;
  late int _snoozeMinutes;
  late String _alarmSoundId;
  late String _alarmSoundLabel;
  late String _alarmSoundUri;
  late bool _autoFocus;
  bool _saving = false;
  bool _defaultsApplied = false;

  @override
  void initState() {
    super.initState();
    final TaskItem? task = widget.task;
    _title = task?.title ?? '';
    _notes = task?.notes ?? '';
    final DateTime initial = task?.startAt ??
        (widget.initialDate == null
            ? DateTime.now().add(const Duration(minutes: 30))
            : DateTime(
                widget.initialDate!.year,
                widget.initialDate!.month,
                widget.initialDate!.day,
                DateTime.now().hour,
                DateTime.now().minute,
              ));
    _date = dateOnly(initial);
    _time = TimeOfDay.fromDateTime(initial);
    _subjectId = task?.subjectId ?? 'general';
    _duration = task?.durationMinutes ?? 50;
    _priority = task?.priority ?? 2;
    _reminderEnabled = task?.reminderEnabled ?? true;
    _alarmEnabled = task?.alarmEnabled ?? true;
    _snoozeMinutes = task?.snoozeMinutes ?? 5;
    _alarmSoundId = task?.alarmSoundId ?? AlarmSoundCatalog.smartId;
    _alarmSoundLabel = task?.alarmSoundLabel ?? AlarmSoundCatalog.smartLabel;
    _alarmSoundUri = task?.alarmSoundUri ?? '';
    _autoFocus = task?.autoFocus ?? false;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final AppController controller = AppScope.read(context);
    if (!_defaultsApplied && widget.task == null) {
      final AppPreferencesModel preferences = controller.preferences;
      _alarmEnabled = preferences.defaultTaskAlarm;
      _snoozeMinutes = preferences.defaultSnoozeMinutes;
      _alarmSoundId = preferences.defaultAlarmSoundId;
      _alarmSoundLabel = preferences.defaultAlarmSoundLabel;
      _alarmSoundUri = preferences.defaultAlarmSoundUri;
      _defaultsApplied = true;
    }
    final List<SubjectItem> subjects = controller.activeSubjects;
    if (!subjects.any((SubjectItem subject) => subject.id == _subjectId)) {
      _subjectId = subjects.first.id;
    }
  }

  @override
  void dispose() {
    NativeBridge.stopAlarmSoundPreview().catchError((_) {});
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.read(context);
    final List<SubjectItem> subjects = controller.activeSubjects;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.task == null ? 'Create task' : 'Edit task'),
        actions: <Widget>[
          IconButton(
            key: const ValueKey<String>('task-save-button'),
            tooltip: widget.task == null ? 'Create task' : 'Save changes',
            onPressed: _saving ? null : () => _save(controller),
            icon: _saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_rounded),
          ),
          if (widget.task != null)
            IconButton(
              tooltip: 'Move to trash',
              onPressed: _saving ? null : () => _delete(controller),
              icon: const Icon(Icons.delete_outline_rounded),
            ),
        ],
      ),
      body: SingleChildScrollView(
        key: const ValueKey<String>('task-editor-scroll'),
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (widget.task == null) ...<Widget>[
              Card(
                child: ListTile(
                  key: const ValueKey<String>('alarm-preset-library-tile'),
                  leading: const CircleAvatar(
                    child: Icon(Icons.alarm_add_rounded),
                  ),
                  title: const Text(
                    'Alarm preset library',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: const Text(
                    '216 ready-made alarm and routine templates',
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: _choosePreset,
                ),
              ),
              const SizedBox(height: 12),
            ],
            TextFormField(
              key: ValueKey<String>('task-title-$_title'),
              initialValue: _title,
              autofocus: widget.task == null,
              textCapitalization: TextCapitalization.sentences,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Task title',
                prefixIcon: Icon(Icons.task_alt_rounded),
              ),
              onChanged: (String value) => _title = value,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: ValueKey<String>(_subjectId),
              initialValue: _subjectId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Subject or category',
                prefixIcon: Icon(Icons.category_rounded),
              ),
              items: subjects
                  .map(
                    (SubjectItem subject) => DropdownMenuItem<String>(
                      value: subject.id,
                      child: Text(
                        subject.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (String? value) {
                if (value != null) {
                  setState(() => _subjectId = value);
                }
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: _PickerButton(
                    icon: Icons.calendar_today_rounded,
                    label: formatDate(_date),
                    onPressed: _pickDate,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _PickerButton(
                    icon: Icons.schedule_rounded,
                    label: _time.format(context),
                    onPressed: _pickTime,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Text(
              'Duration: ${formatDuration(_duration)}',
              style: Theme.of(
                context,
              ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
            ),
            Slider(
              value: _duration.toDouble(),
              min: 10,
              max: 240,
              divisions: 23,
              label: '$_duration min',
              onChanged: (double value) =>
                  setState(() => _duration = value.round()),
            ),
            const SizedBox(height: 6),
            Text(
              'Priority',
              style: Theme.of(
                context,
              ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            SegmentedButton<int>(
              segments: const <ButtonSegment<int>>[
                ButtonSegment<int>(value: 1, label: Text('Low')),
                ButtonSegment<int>(value: 2, label: Text('Normal')),
                ButtonSegment<int>(value: 3, label: Text('High')),
              ],
              selected: <int>{_priority},
              onSelectionChanged: (Set<int> value) =>
                  setState(() => _priority = value.first),
            ),
            const SizedBox(height: 16),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Notification reminder'),
              subtitle: const Text(
                'Keep a notification in the notification shade.',
              ),
              value: _reminderEnabled,
              onChanged: (bool value) =>
                  setState(() => _reminderEnabled = value),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Full-screen task alarm'),
              subtitle: const Text(
                'Ring like an alarm clock and show this task on the lock screen.',
              ),
              value: _alarmEnabled,
              onChanged: (bool value) => setState(() => _alarmEnabled = value),
            ),
            if (_alarmEnabled) ...<Widget>[
              const SizedBox(height: 4),
              Card(
                elevation: 0,
                child: ListTile(
                  key: const ValueKey<String>('task-alarm-sound-tile'),
                  leading: const CircleAvatar(
                    child: Icon(Icons.music_note_rounded),
                  ),
                  title: const Text(
                    'Alarm sound',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    AlarmSoundCatalog.safeLabel(
                      _alarmSoundId,
                      _alarmSoundLabel,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: _chooseAlarmSound,
                  trailing: IconButton(
                    tooltip: 'Preview sound',
                    onPressed: _previewAlarmSound,
                    icon: const Icon(Icons.play_circle_outline_rounded),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                key: ValueKey<int>(_snoozeMinutes),
                initialValue: _snoozeMinutes,
                decoration: const InputDecoration(
                  labelText: 'Snooze duration',
                  prefixIcon: Icon(Icons.snooze_rounded),
                ),
                items: const <DropdownMenuItem<int>>[
                  DropdownMenuItem<int>(value: 5, child: Text('5 minutes')),
                  DropdownMenuItem<int>(value: 10, child: Text('10 minutes')),
                  DropdownMenuItem<int>(value: 15, child: Text('15 minutes')),
                  DropdownMenuItem<int>(value: 30, child: Text('30 minutes')),
                ],
                onChanged: (int? value) {
                  if (value != null) {
                    setState(() => _snoozeMinutes = value);
                  }
                },
              ),
            ],
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Auto Focus'),
              subtitle: const Text(
                'Start app blocking and optional Do Not Disturb at task time.',
              ),
              value: _autoFocus,
              onChanged: (bool value) => setState(() => _autoFocus = value),
            ),
            const SizedBox(height: 10),
            TextFormField(
              key: ValueKey<String>('task-notes-$_notes'),
              initialValue: _notes,
              minLines: 4,
              maxLines: 8,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'What should you do now?',
                hintText: 'Write the exact outcome or steps for this task.',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.notes_rounded),
              ),
              onChanged: (String value) => _notes = value,
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              key: const ValueKey<String>('task-save-button-bottom'),
              onPressed: _saving ? null : () => _save(controller),
              icon: _saving
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_rounded),
              label: Text(widget.task == null ? 'Create' : 'Save changes'),
            ),
            if (widget.task != null) ...<Widget>[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _saving
                    ? null
                    : () async {
                        FocusManager.instance.primaryFocus?.unfocus();
                        await controller.duplicateTask(widget.task!);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Duplicated for tomorrow.'),
                            ),
                          );
                        }
                      },
                icon: const Icon(Icons.copy_rounded),
                label: const Text('Duplicate for tomorrow'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2025),
      lastDate: DateTime(2035),
    );
    if (picked != null && mounted) {
      setState(() => _date = dateOnly(picked));
    }
  }

  Future<void> _pickTime() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (picked != null && mounted) {
      setState(() => _time = picked);
    }
  }

  Future<void> _chooseAlarmSound() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final AppController controller = AppScope.read(context);
    final String category = controller.subjectById(_subjectId).name;
    final AlarmSoundSelection? selected =
        await Navigator.of(context).push<AlarmSoundSelection>(
      MaterialPageRoute<AlarmSoundSelection>(
        builder: (_) => AlarmSoundPickerScreen(
          initialSelection: AlarmSoundSelection(
            id: _alarmSoundId,
            label: _alarmSoundLabel,
            uri: _alarmSoundUri,
          ),
          category: category,
          taskTitle: _title.trim().isEmpty ? 'Task reminder' : _title.trim(),
        ),
      ),
    );
    if (selected != null && mounted) {
      setState(() {
        _alarmSoundId = selected.id;
        _alarmSoundLabel = selected.label;
        _alarmSoundUri = selected.uri;
      });
    }
  }

  Future<void> _previewAlarmSound() async {
    final AppController controller = AppScope.read(context);
    try {
      await NativeBridge.previewAlarmSound(
        selection: AlarmSoundSelection(
          id: _alarmSoundId,
          label: _alarmSoundLabel,
          uri: _alarmSoundUri,
        ),
        category: controller.subjectById(_subjectId).name,
        taskTitle: _title.trim().isEmpty ? 'Task reminder' : _title.trim(),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not preview alarm sound: $error')),
        );
      }
    }
  }

  Future<void> _choosePreset() async {
    final AlarmPreset? preset = await Navigator.of(context).push<AlarmPreset>(
      MaterialPageRoute<AlarmPreset>(
        builder: (_) => const AlarmPresetScreen(),
      ),
    );
    if (preset == null || !mounted) return;
    setState(() {
      _title = preset.title;
      _notes = preset.notes;
      _time = TimeOfDay(hour: preset.hour, minute: preset.minute);
      _duration = preset.durationMinutes;
      _reminderEnabled = true;
      _alarmEnabled = true;
    });
  }

  Future<void> _save(AppController controller) async {
    final String title = _title.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Enter a task title.')));
      return;
    }

    if (_saving) {
      return;
    }

    await _dismissKeyboard();
    if (!mounted) {
      return;
    }
    setState(() => _saving = true);

    final DateTime now = DateTime.now();
    final DateTime startAt = DateTime(
      _date.year,
      _date.month,
      _date.day,
      _time.hour,
      _time.minute,
    );
    final TaskItem? existing = widget.task;
    final TaskItem task = existing == null
        ? TaskItem(
            id: newId('task'),
            title: title,
            subjectId: _subjectId,
            startAt: startAt,
            durationMinutes: _duration,
            priority: _priority,
            notes: _notes.trim(),
            reminderEnabled: _reminderEnabled,
            alarmEnabled: _alarmEnabled,
            snoozeMinutes: _snoozeMinutes,
            alarmSoundId: _alarmSoundId,
            alarmSoundLabel: _alarmSoundLabel,
            alarmSoundUri: _alarmSoundUri,
            autoFocus: _autoFocus,
            createdAt: now,
            updatedAt: now,
          )
        : existing.copyWith(
            title: title,
            subjectId: _subjectId,
            startAt: startAt,
            durationMinutes: _duration,
            priority: _priority,
            notes: _notes.trim(),
            reminderEnabled: _reminderEnabled,
            alarmEnabled: _alarmEnabled,
            snoozeMinutes: _snoozeMinutes,
            alarmSoundId: _alarmSoundId,
            alarmSoundLabel: _alarmSoundLabel,
            alarmSoundUri: _alarmSoundUri,
            autoFocus: _autoFocus,
            updatedAt: now,
          );

    try {
      if (existing == null) {
        await controller.addTask(task);
      } else {
        await controller.updateTask(task);
      }
      if (mounted) {
        Navigator.of(context).pop();
      }
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not save task: $error')));
      }
    }
  }

  Future<void> _dismissKeyboard() async {
    FocusScope.of(context).unfocus(disposition: UnfocusDisposition.scope);
    try {
      await SystemChannels.textInput.invokeMethod<void>('TextInput.hide');
    } catch (_) {
      // Widget tests and non-Android platforms may not install a text-input
      // channel handler. Focus dismissal above is still sufficient there.
    }
    await Future<void>.delayed(Duration.zero);
  }

  Future<void> _delete(AppController controller) async {
    await _dismissKeyboard();
    if (!mounted) {
      return;
    }
    final bool confirmed = await confirmAction(
      context,
      title: 'Move this task to Trash?',
      message: 'You can restore it later from Trash.',
      confirmLabel: 'Move to Trash',
    );
    if (!confirmed || widget.task == null) {
      return;
    }
    setState(() => _saving = true);
    try {
      await controller.deleteTask(widget.task!);
      if (mounted) {
        Navigator.of(context).pop();
      }
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not delete task: $error')),
        );
      }
    }
  }
}

class _PickerButton extends StatelessWidget {
  const _PickerButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon),
        label: Text(label, overflow: TextOverflow.ellipsis),
      );
}
