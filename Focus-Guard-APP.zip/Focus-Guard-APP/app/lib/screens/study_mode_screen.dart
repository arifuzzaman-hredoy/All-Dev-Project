import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../controllers/smart_flow_controller.dart';
import '../models/app_models.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/app_drawer.dart';
import '../widgets/common_widgets.dart';
import 'focus_screen.dart';
import 'goal_manager_screen.dart';
import 'planner_screen.dart';
import 'subject_manager_screen.dart';

class StudyModeScreen extends StatefulWidget {
  const StudyModeScreen({super.key});

  @override
  State<StudyModeScreen> createState() => _StudyModeScreenState();
}

class _StudyModeScreenState extends State<StudyModeScreen>
    with WidgetsBindingObserver {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlPolicy _persistedPolicy = const PhoneControlPolicy();
  PhoneControlPolicy? _queuedPolicy;
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  bool _loading = true;
  bool _saving = false;
  String? _subjectId;
  String? _taskId;
  int _minutes = 50;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(showSpinner: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool showSpinner = true}) async {
    if (showSpinner && mounted) setState(() => _loading = true);
    PhoneControlPolicy policy = _policy;
    List<LaunchableAppInfo> apps = _apps;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _persistedPolicy = policy;
      _minutes = policy.studyDefaultMinutes;
      final Set<String> alwaysAllowed =
          SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
              const <String>{};
      _apps = apps
          .where(
            (LaunchableAppInfo app) =>
                !app.protected && !alwaysAllowed.contains(app.packageName),
          )
          .toList(growable: false);
      _loading = false;
    });
  }

  Future<void> _savePolicy(PhoneControlPolicy next) async {
    final Set<String> alwaysAllowed =
        SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
            const <String>{};
    final PhoneControlPolicy safeNext =
        sanitizePhoneControlForAlwaysAllowed(next, alwaysAllowed);
    _queuedPolicy = safeNext;
    if (mounted) setState(() => _policy = safeNext);
    if (_saving) return;

    if (mounted) setState(() => _saving = true);
    while (_queuedPolicy != null) {
      final PhoneControlPolicy target = _queuedPolicy!;
      _queuedPolicy = null;
      try {
        await NativeBridge.savePhoneControlPolicy(target);
        _persistedPolicy = target;
      } catch (error) {
        _queuedPolicy = null;
        if (!mounted) return;
        setState(() => _policy = _persistedPolicy);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save Study Mode: $error')),
        );
        break;
      }
    }
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _pickBlockedApps() async {
    final Set<String>? selected = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _StudyAppPicker(
        apps: _apps,
        selected: _policy.studyBlockedPackages,
      ),
    );
    if (selected != null && mounted) {
      await _savePolicy(_policy.copyWith(studyBlockedPackages: selected));
    }
  }

  Future<void> _startFocus(AppController controller) async {
    final List<SubjectItem> subjects = controller.activeSubjects;
    if (subjects.isEmpty) return;
    final String subjectId =
        subjects.any((SubjectItem item) => item.id == _subjectId)
            ? _subjectId!
            : subjects.first.id;
    final TaskItem? task = _taskId == null
        ? null
        : controller.activeTasks
            .where((TaskItem item) => item.id == _taskId)
            .firstOrNull;
    final SubjectItem subject = controller.subjectById(subjectId);

    if (!_policy.studyModeEnabled) {
      await _savePolicy(_policy.copyWith(studyModeEnabled: true));
      if (!mounted) return;
    }

    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => FocusScreen(
          minutes: _minutes,
          label: task?.title ?? '${subject.name} study',
          subjectId: task?.subjectId ?? subjectId,
          taskId: task?.id,
          controller: controller,
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<SubjectItem> subjects = controller.activeSubjects;
    final String? resolvedSubjectId = subjects.isEmpty
        ? null
        : subjects.any((SubjectItem item) => item.id == _subjectId)
            ? _subjectId
            : subjects.first.id;
    final List<TaskItem> pendingTasks = controller.activeTasks
        .where((TaskItem task) => !task.isCompleted)
        .take(80)
        .toList(growable: false);
    final String? resolvedTaskId =
        pendingTasks.any((TaskItem task) => task.id == _taskId)
            ? _taskId
            : null;

    return DefaultTabController(
      length: 6,
      child: Scaffold(
        drawer: const AppDrawer(),
        appBar: AppBar(
          title: const Text('Study Mode'),
          actions: <Widget>[
            if (_saving)
              const Padding(
                padding: EdgeInsets.only(right: 18),
                child: Center(
                  child: SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              )
            else
              IconButton(
                tooltip: 'Refresh Study Mode',
                onPressed: () => _load(showSpinner: false),
                icon: const Icon(Icons.refresh_rounded),
              ),
          ],
          bottom: const TabBar(
            isScrollable: true,
            tabs: <Widget>[
              Tab(icon: Icon(Icons.dashboard_rounded), text: 'Dashboard'),
              Tab(icon: Icon(Icons.menu_book_rounded), text: 'Subjects'),
              Tab(icon: Icon(Icons.checklist_rounded), text: 'Tasks'),
              Tab(icon: Icon(Icons.flag_rounded), text: 'Goals'),
              Tab(icon: Icon(Icons.insights_rounded), text: 'Insights'),
              Tab(icon: Icon(Icons.tune_rounded), text: 'Setup'),
            ],
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: <Widget>[
                  _DashboardTab(
                    controller: controller,
                    policy: _policy,
                    subjects: subjects,
                    pendingTasks: pendingTasks,
                    subjectId: resolvedSubjectId,
                    taskId: resolvedTaskId,
                    minutes: _minutes,
                    onSubjectChanged: (String? value) =>
                        setState(() => _subjectId = value),
                    onTaskChanged: (String? value) =>
                        setState(() => _taskId = value),
                    onMinutesChanged: (int value) =>
                        setState(() => _minutes = value),
                    onStart:
                        subjects.isEmpty ? null : () => _startFocus(controller),
                  ),
                  _SubjectsTab(controller: controller),
                  _TasksTab(controller: controller),
                  _GoalsTab(controller: controller),
                  _InsightsTab(
                    controller: controller,
                    dailyGoalMinutes: _policy.studyDailyGoalMinutes,
                  ),
                  _SetupTab(
                    policy: _policy,
                    appLabels: <String, String>{
                      for (final LaunchableAppInfo app in _apps)
                        app.packageName: app.label,
                    },
                    onSave: _savePolicy,
                    onPickApps: _pickBlockedApps,
                  ),
                ],
              ),
      ),
    );
  }
}

class _DashboardTab extends StatelessWidget {
  const _DashboardTab({
    required this.controller,
    required this.policy,
    required this.subjects,
    required this.pendingTasks,
    required this.subjectId,
    required this.taskId,
    required this.minutes,
    required this.onSubjectChanged,
    required this.onTaskChanged,
    required this.onMinutesChanged,
    required this.onStart,
  });

  final AppController controller;
  final PhoneControlPolicy policy;
  final List<SubjectItem> subjects;
  final List<TaskItem> pendingTasks;
  final String? subjectId;
  final String? taskId;
  final int minutes;
  final ValueChanged<String?> onSubjectChanged;
  final ValueChanged<String?> onTaskChanged;
  final ValueChanged<int> onMinutesChanged;
  final VoidCallback? onStart;

  @override
  Widget build(BuildContext context) {
    final int todayMinutes = controller.focusMinutesFor(DateTime.now());
    final int dailyGoal = policy.studyDailyGoalMinutes;
    final double progress = dailyGoal <= 0
        ? 0
        : (todayMinutes / dailyGoal).clamp(0.0, 1.0).toDouble();
    final List<DateTime> days = List<DateTime>.generate(
      7,
      (int index) =>
          dateOnly(DateTime.now()).subtract(Duration(days: 6 - index)),
    );

    return ListView(
      key: const ValueKey<String>('study-mode-dashboard'),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
      children: <Widget>[
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(26),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  const CircleAvatar(
                    radius: 25,
                    child: Icon(Icons.school_rounded, size: 28),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'Study Mode',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w900),
                        ),
                        Text('$todayMinutes of $dailyGoal minutes today'),
                      ],
                    ),
                  ),
                  Text(
                    '${(progress * 100).round()}%',
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              LinearProgressIndicator(
                value: progress,
                minHeight: 11,
                borderRadius: BorderRadius.circular(99),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: <Widget>[
                  _StudyStatusChip(
                    icon: Icons.local_fire_department_rounded,
                    label: '${controller.currentStreak} day streak',
                  ),
                  _StudyStatusChip(
                    icon: Icons.task_alt_rounded,
                    label:
                        '${controller.completedTaskCountFor(DateTime.now())} tasks today',
                  ),
                  _StudyStatusChip(
                    icon: Icons.shield_rounded,
                    label: policy.studyBlockedPackages.isEmpty
                        ? 'No apps blocked'
                        : '${policy.studyBlockedPackages.length} study blocks',
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionHeader(
          title: 'Start a protected session',
          subtitle: 'Choose a subject or link a real task before starting.',
        ),
        const SizedBox(height: 10),
        if (subjects.isEmpty)
          const EmptyState(
            icon: Icons.menu_book_outlined,
            title: 'No active subjects',
            message: 'Create at least one subject before starting Study Mode.',
          )
        else ...<Widget>[
          DropdownButtonFormField<String>(
            isExpanded: true,
            initialValue: subjectId,
            decoration: const InputDecoration(
              labelText: 'Study subject',
              prefixIcon: Icon(Icons.menu_book_rounded),
            ),
            items: subjects
                .map(
                  (SubjectItem subject) => DropdownMenuItem<String>(
                    value: subject.id,
                    child: Text(subject.name, overflow: TextOverflow.ellipsis),
                  ),
                )
                .toList(growable: false),
            onChanged: onSubjectChanged,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            isExpanded: true,
            initialValue: taskId,
            decoration: const InputDecoration(
              labelText: 'Optional task',
              prefixIcon: Icon(Icons.link_rounded),
            ),
            items: <DropdownMenuItem<String?>>[
              const DropdownMenuItem<String?>(
                value: null,
                child: Text('No linked task'),
              ),
              ...pendingTasks.map(
                (TaskItem task) => DropdownMenuItem<String?>(
                  value: task.id,
                  child: Text(task.title, overflow: TextOverflow.ellipsis),
                ),
              ),
            ],
            onChanged: onTaskChanged,
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <int>[15, 25, 50, 75, 90, 120]
                .map(
                  (int value) => ChoiceChip(
                    label: Text('$value min'),
                    selected: minutes == value,
                    onSelected: (_) => onMinutesChanged(value),
                  ),
                )
                .toList(growable: false),
          ),
          Slider(
            value: minutes.clamp(10, 240).toDouble(),
            min: 10,
            max: 240,
            divisions: 46,
            label: '$minutes min',
            onChanged: (double value) => onMinutesChanged(value.round()),
          ),
          FilledButton.icon(
            onPressed: onStart,
            icon: const Icon(Icons.play_arrow_rounded),
            label: Text('Start $minutes minute Study Mode'),
          ),
        ],
        const SizedBox(height: 24),
        const SectionHeader(
          title: 'Last 7 days',
          subtitle:
              'Focused minutes recorded from completed and early-ended sessions.',
        ),
        const SizedBox(height: 10),
        _WeeklyFocusChart(controller: controller, days: days),
        const SizedBox(height: 22),
        const SectionHeader(title: 'Recent sessions'),
        const SizedBox(height: 8),
        if (controller.recentSessions.isEmpty)
          const EmptyState(
            icon: Icons.timer_outlined,
            title: 'No study sessions yet',
            message: 'Your first Study Mode session will appear here.',
          )
        else
          ...controller.recentSessions.take(6).map(
                (FocusSession session) => Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Icon(
                        session.completed
                            ? Icons.check_rounded
                            : Icons.stop_rounded,
                      ),
                    ),
                    title: Text(
                      session.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      '${controller.subjectById(session.subjectId).name} • ${formatDate(session.startedAt)}',
                    ),
                    trailing: Text(
                      formatDuration(session.actualMinutes),
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ),
      ],
    );
  }
}

class _SubjectsTab extends StatelessWidget {
  const _SubjectsTab({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final Map<String, int> minutes = controller.focusBySubject();
    return ListView(
      key: const ValueKey<String>('study-mode-subjects'),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
      children: <Widget>[
        SectionHeader(
          title: 'Subjects',
          subtitle: '${controller.activeSubjects.length} active subjects',
          action: FilledButton.tonalIcon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                  builder: (_) => const SubjectManagerScreen()),
            ),
            icon: const Icon(Icons.edit_rounded),
            label: const Text('Manage'),
          ),
        ),
        const SizedBox(height: 10),
        if (controller.activeSubjects.isEmpty)
          const EmptyState(
            icon: Icons.menu_book_outlined,
            title: 'No subjects',
            message: 'Add subjects to get subject-wise timers and analytics.',
          )
        else
          ...controller.activeSubjects.map((SubjectItem subject) {
            final int subjectMinutes = minutes[subject.id] ?? 0;
            final int tasks = controller.taskCountForSubject(subject.id);
            final int completed =
                controller.completedTaskCountForSubject(subject.id);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        CircleAvatar(
                          backgroundColor:
                              subject.color.withValues(alpha: 0.15),
                          child: Icon(subject.icon, color: subject.color),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                subject.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900),
                              ),
                              Text('$subjectMinutes focused minutes'),
                            ],
                          ),
                        ),
                        Text(
                          '$completed/$tasks',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    LinearProgressIndicator(
                      value:
                          tasks == 0 ? 0 : (completed / tasks).clamp(0.0, 1.0),
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }
}

class _TasksTab extends StatelessWidget {
  const _TasksTab({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final List<TaskItem> pending = controller.activeTasks
        .where((TaskItem task) => !task.isCompleted)
        .take(80)
        .toList(growable: false);
    return ListView(
      key: const ValueKey<String>('study-mode-tasks'),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
      children: <Widget>[
        SectionHeader(
          title: 'Todo',
          subtitle: '${pending.length} pending study and routine tasks',
          action: FilledButton.tonalIcon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const PlannerScreen()),
            ),
            icon: const Icon(Icons.calendar_month_rounded),
            label: const Text('Planner'),
          ),
        ),
        const SizedBox(height: 10),
        if (pending.isEmpty)
          const EmptyState(
            icon: Icons.task_alt_rounded,
            title: 'Everything is complete',
            message: 'New pending tasks will appear here automatically.',
          )
        else
          ...pending.map(
            (TaskItem task) => Card(
              child: CheckboxListTile(
                value: task.isCompleted,
                onChanged: (bool? value) {
                  controller.setTaskCompleted(task, value == true);
                },
                secondary: CircleAvatar(
                  child: Icon(controller.subjectById(task.subjectId).icon),
                ),
                title: Text(
                  task.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text(
                  '${controller.subjectById(task.subjectId).name} • ${formatDate(task.startAt)} • ${formatTime(task.startAt)}',
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _GoalsTab extends StatelessWidget {
  const _GoalsTab({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) => ListView(
        key: const ValueKey<String>('study-mode-goals'),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
        children: <Widget>[
          SectionHeader(
            title: 'Goals',
            subtitle:
                '${controller.completedGoalCount}/${controller.activeGoals.length} completed',
            action: FilledButton.tonalIcon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                    builder: (_) => const GoalManagerScreen()),
              ),
              icon: const Icon(Icons.edit_rounded),
              label: const Text('Manage'),
            ),
          ),
          const SizedBox(height: 10),
          if (controller.activeGoals.isEmpty)
            const EmptyState(
              icon: Icons.flag_outlined,
              title: 'No goals yet',
              message: 'Create chapter, syllabus or exam goals.',
            )
          else
            ...controller.activeGoals.map((GoalItem goal) {
              final int progress = controller.effectiveGoalProgress(goal);
              final SubjectItem subject =
                  controller.subjectById(goal.subjectId);
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          CircleAvatar(
                            backgroundColor:
                                subject.color.withValues(alpha: 0.15),
                            child: Icon(subject.icon, color: subject.color),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              goal.title,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                          Text('$progress/${goal.target}'),
                        ],
                      ),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(
                        value: controller.effectiveGoalRatio(goal),
                        minHeight: 9,
                        borderRadius: BorderRadius.circular(99),
                      ),
                      const SizedBox(height: 8),
                      Text(
                          '${subject.name} • Due ${formatDate(goal.deadline)}'),
                    ],
                  ),
                ),
              );
            }),
        ],
      );
}

class _InsightsTab extends StatelessWidget {
  const _InsightsTab({
    required this.controller,
    required this.dailyGoalMinutes,
  });

  final AppController controller;
  final int dailyGoalMinutes;

  @override
  Widget build(BuildContext context) {
    final DateTime today = dateOnly(DateTime.now());
    final List<DateTime> week = List<DateTime>.generate(
      7,
      (int index) => today.subtract(Duration(days: 6 - index)),
    );
    final List<DateTime> month = List<DateTime>.generate(
      30,
      (int index) => today.subtract(Duration(days: 29 - index)),
    );
    final List<FocusSession> sessions = controller.data.sessions
        .where((FocusSession session) => session.actualMinutes > 0)
        .toList(growable: false);
    final int longest = sessions.fold<int>(
      0,
      (int value, FocusSession session) =>
          math.max(value, session.actualMinutes),
    );
    final int average = sessions.isEmpty
        ? 0
        : sessions.fold<int>(
              0,
              (int value, FocusSession session) =>
                  value + session.actualMinutes,
            ) ~/
            sessions.length;
    final int weekMinutes = week.fold<int>(
      0,
      (int value, DateTime day) => value + controller.focusMinutesFor(day),
    );
    final int productiveDays = week
        .where((DateTime day) => controller.focusMinutesFor(day) > 0)
        .length;
    final int completedSessions =
        sessions.where((FocusSession session) => session.completed).length;
    final double completionRate =
        sessions.isEmpty ? 0 : completedSessions / sessions.length;
    final double goalRate = dailyGoalMinutes <= 0
        ? 0
        : (weekMinutes / (dailyGoalMinutes * 7)).clamp(0.0, 1.0);
    final int productivityScore =
        ((goalRate * 60) + (completionRate * 25) + ((productiveDays / 7) * 15))
            .round()
            .clamp(0, 100);

    final Map<String, int> subjectMinutes = controller.focusBySubject();
    final List<MapEntry<String, int>> subjectEntries = subjectMinutes.entries
        .toList()
      ..sort((MapEntry<String, int> a, MapEntry<String, int> b) =>
          b.value.compareTo(a.value));
    final int maxSubject =
        subjectEntries.isEmpty ? 1 : subjectEntries.first.value;

    return ListView(
      key: const ValueKey<String>('study-mode-insights'),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
      children: <Widget>[
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1.25,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: <Widget>[
            MetricCard(
              label: 'Productivity score',
              value: '$productivityScore%',
              icon: Icons.auto_graph_rounded,
              subtitle: 'Local 7-day score',
            ),
            MetricCard(
              label: 'This week',
              value: formatDuration(weekMinutes),
              icon: Icons.date_range_rounded,
              subtitle: '$productiveDays productive days',
            ),
            MetricCard(
              label: 'Longest session',
              value: formatDuration(longest),
              icon: Icons.workspace_premium_rounded,
            ),
            MetricCard(
              label: 'Average session',
              value: formatDuration(average),
              icon: Icons.av_timer_rounded,
            ),
          ],
        ),
        const SizedBox(height: 22),
        const SectionHeader(title: 'Weekly focus trend'),
        const SizedBox(height: 10),
        _WeeklyFocusChart(controller: controller, days: week),
        const SizedBox(height: 22),
        const SectionHeader(
          title: '30-day study heatmap',
          subtitle: 'Darker cells mean more focused minutes.',
        ),
        const SizedBox(height: 10),
        _FocusHeatmap(controller: controller, days: month),
        const SizedBox(height: 22),
        const SectionHeader(title: 'Subject distribution'),
        const SizedBox(height: 10),
        if (subjectEntries.isEmpty)
          const EmptyState(
            icon: Icons.pie_chart_outline_rounded,
            title: 'No subject data yet',
            message: 'Complete Study Mode sessions to fill this chart.',
          )
        else
          ...subjectEntries.take(12).map((MapEntry<String, int> entry) {
            final SubjectItem subject = controller.subjectById(entry.key);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(subject.icon, color: subject.color),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            subject.name,
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Text(formatDuration(entry.value)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: entry.value / maxSubject,
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }
}

class _SetupTab extends StatelessWidget {
  const _SetupTab({
    required this.policy,
    required this.appLabels,
    required this.onSave,
    required this.onPickApps,
  });

  final PhoneControlPolicy policy;
  final Map<String, String> appLabels;
  final ValueChanged<PhoneControlPolicy> onSave;
  final VoidCallback onPickApps;

  Future<void> _pickStudyTime(
    BuildContext context, {
    required bool start,
  }) async {
    final int minute = start ? policy.studyStartMinute : policy.studyEndMinute;
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: minute ~/ 60, minute: minute % 60),
    );
    if (picked == null) return;
    final int value = picked.hour * 60 + picked.minute;
    onSave(
      start
          ? policy.copyWith(studyStartMinute: value)
          : policy.copyWith(studyEndMinute: value),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(
        key: const ValueKey<String>('study-mode-setup'),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
        children: <Widget>[
          const SectionHeader(
            title: 'Study Mode protection',
            subtitle:
                'Choose one list for scheduled Study Mode and Focus sessions.',
          ),
          const SizedBox(height: 10),
          Card(
            child: Column(
              children: <Widget>[
                SwitchListTile.adaptive(
                  secondary:
                      const CircleAvatar(child: Icon(Icons.school_rounded)),
                  title: const Text(
                    'Study Mode enabled',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle:
                      const Text('Use Study Mode rules during focus sessions.'),
                  value: policy.studyModeEnabled,
                  onChanged: (bool value) =>
                      onSave(policy.copyWith(studyModeEnabled: value)),
                ),
                const Divider(height: 1),
                const ListTile(
                  leading: CircleAvatar(
                      child: Icon(Icons.health_and_safety_rounded)),
                  title: Text(
                    'Manual block list only',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    'Study Mode blocks only the apps you select below. It never switches to a whole-phone allow-list.',
                  ),
                ),
                const Divider(height: 1),
                SwitchListTile.adaptive(
                  secondary: const CircleAvatar(
                    child: Icon(Icons.notifications_off_rounded),
                  ),
                  title: const Text(
                    'Silence notifications',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: const Text(
                    'Cancel non-critical notifications while Study Mode is active.',
                  ),
                  value: policy.studySilenceNotifications,
                  onChanged: (bool value) => onSave(
                    policy.copyWith(studySilenceNotifications: value),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const SectionHeader(
            title: 'Automatic study schedule',
            subtitle:
                'Selected apps turn off during this window and become available automatically when it ends.',
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    secondary: const CircleAvatar(
                      child: Icon(Icons.schedule_rounded),
                    ),
                    title: const Text(
                      'Run Study Mode automatically',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Fail-open: only the apps selected below are blocked.',
                    ),
                    value: policy.studyScheduleEnabled,
                    onChanged: (bool value) => onSave(
                      policy.copyWith(studyScheduleEnabled: value),
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Use the same rules in Focus sessions'),
                    subtitle: const Text(
                      'App and Reels rules selected for Study Mode also apply during Focus.',
                    ),
                    value: policy.focusUsesStudyRules,
                    onChanged: (bool value) => onSave(
                      policy.copyWith(focusUsesStudyRules: value),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: List<Widget>.generate(7, (int index) {
                      const List<String> labels = <String>[
                        'Mon',
                        'Tue',
                        'Wed',
                        'Thu',
                        'Fri',
                        'Sat',
                        'Sun',
                      ];
                      final int day = index + 1;
                      return FilterChip(
                        label: Text(labels[index]),
                        selected: policy.studyWeekdays.contains(day),
                        onSelected: (bool selected) {
                          final Set<int> days = <int>{...policy.studyWeekdays};
                          if (selected) {
                            days.add(day);
                          } else if (days.length > 1) {
                            days.remove(day);
                          }
                          onSave(policy.copyWith(studyWeekdays: days));
                        },
                      );
                    }),
                  ),
                  const SizedBox(height: 12),
                  LayoutBuilder(
                    builder:
                        (BuildContext context, BoxConstraints constraints) {
                      final bool compact = constraints.maxWidth < 360;
                      final Widget startButton = OutlinedButton.icon(
                        onPressed: () => _pickStudyTime(context, start: true),
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: Text(
                          'Start ${formatMinuteOfDay(policy.studyStartMinute)}',
                        ),
                      );
                      final Widget endButton = OutlinedButton.icon(
                        onPressed: () => _pickStudyTime(context, start: false),
                        icon: const Icon(Icons.stop_rounded),
                        label: Text(
                          'End ${formatMinuteOfDay(policy.studyEndMinute)}',
                        ),
                      );
                      if (compact) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            startButton,
                            const SizedBox(height: 8),
                            endButton,
                          ],
                        );
                      }
                      return Row(
                        children: <Widget>[
                          Expanded(child: startButton),
                          const SizedBox(width: 8),
                          Expanded(child: endButton),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SectionHeader(
            title: 'Apps to block during Study Mode',
            subtitle:
                '${policy.studyBlockedPackages.length} apps selected by you',
            action: FilledButton.tonalIcon(
              onPressed: onPickApps,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Choose apps'),
            ),
          ),
          const SizedBox(height: 8),
          if (policy.studyBlockedPackages.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Nothing is blocked during Study Mode. Choose only the distracting apps you want to stop.',
                ),
              ),
            )
          else
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: policy.studyBlockedPackages.map((String packageName) {
                return InputChip(
                  label: Text(appLabels[packageName] ?? packageName),
                  onDeleted: () {
                    final Set<String> updated = <String>{
                      ...policy.studyBlockedPackages
                    }..remove(packageName);
                    onSave(
                      policy.copyWith(
                        studyBlockedPackages: updated,
                        studyStrictAllowList: false,
                        studyAllowedPackages: const <String>{},
                      ),
                    );
                  },
                );
              }).toList(growable: false),
            ),
          const SizedBox(height: 22),
          SectionHeader(
            title: 'Default session length',
            subtitle: '${policy.studyDefaultMinutes} minutes',
          ),
          Slider(
            value: policy.studyDefaultMinutes.toDouble(),
            min: 10,
            max: 240,
            divisions: 46,
            label: '${policy.studyDefaultMinutes} min',
            onChanged: (double value) => onSave(
              policy.copyWith(studyDefaultMinutes: value.round()),
            ),
          ),
          const SizedBox(height: 16),
          SectionHeader(
            title: 'Daily study goal',
            subtitle: '${policy.studyDailyGoalMinutes} minutes per day',
          ),
          Slider(
            value: policy.studyDailyGoalMinutes.toDouble(),
            min: 10,
            max: 720,
            divisions: 71,
            label: '${policy.studyDailyGoalMinutes} min',
            onChanged: (double value) => onSave(
              policy.copyWith(
                studyDailyGoalMinutes: ((value / 10).round() * 10),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Safety: Hredoy Flow, Home, Settings, calls, alarms, emergency tools, keyboard, banking, payment and authenticator apps always remain available.',
              ),
            ),
          ),
        ],
      );
}

class _WeeklyFocusChart extends StatelessWidget {
  const _WeeklyFocusChart({required this.controller, required this.days});

  final AppController controller;
  final List<DateTime> days;

  @override
  Widget build(BuildContext context) {
    final List<int> values = days
        .map((DateTime day) => controller.focusMinutesFor(day))
        .toList(growable: false);
    final int maxValue = math.max(
      1,
      values.fold<int>(0, (int current, int value) => math.max(current, value)),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 18, 14, 12),
        child: SizedBox(
          height: 170,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: List<Widget>.generate(days.length, (int index) {
              final int value = values[index];
              final double ratio = value / maxValue;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text('$value',
                          style: Theme.of(context).textTheme.labelSmall),
                      const SizedBox(height: 5),
                      Expanded(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: FractionallySizedBox(
                            heightFactor: ratio == 0 ? .03 : ratio,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius: BorderRadius.circular(9),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        _weekday(days[index].weekday),
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  String _weekday(int day) =>
      const <String>['M', 'T', 'W', 'T', 'F', 'S', 'S'][day - 1];
}

class _FocusHeatmap extends StatelessWidget {
  const _FocusHeatmap({required this.controller, required this.days});

  final AppController controller;
  final List<DateTime> days;

  @override
  Widget build(BuildContext context) {
    final Color primary = Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Wrap(
          spacing: 6,
          runSpacing: 6,
          children: days.map((DateTime day) {
            final int minutes = controller.focusMinutesFor(day);
            final double opacity =
                minutes == 0 ? .08 : (minutes / 120).clamp(.22, 1.0).toDouble();
            return Tooltip(
              message: '${formatDate(day)} • $minutes min',
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: primary.withValues(alpha: opacity),
                  borderRadius: BorderRadius.circular(7),
                ),
                alignment: Alignment.center,
                child: Text(
                  '${day.day}',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
              ),
            );
          }).toList(growable: false),
        ),
      ),
    );
  }
}

class _StudyStatusChip extends StatelessWidget {
  const _StudyStatusChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withValues(alpha: .65),
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 16),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
      );
}

class _StudyAppPicker extends StatefulWidget {
  const _StudyAppPicker({required this.apps, required this.selected});

  final List<LaunchableAppInfo> apps;
  final Set<String> selected;

  @override
  State<_StudyAppPicker> createState() => _StudyAppPickerState();
}

class _StudyAppPickerState extends State<_StudyAppPicker> {
  late Set<String> _selected;
  String _query = '';
  String _group = 'distracting';

  @override
  void initState() {
    super.initState();
    _selected = <String>{...widget.selected};
  }

  @override
  Widget build(BuildContext context) {
    final String query = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered = widget.apps
        .where((LaunchableAppInfo app) {
      final bool text = query.isEmpty ||
          app.label.toLowerCase().contains(query) ||
          app.packageName.toLowerCase().contains(query);
      return text && app.matchesCategoryFilter(_group);
    }).toList(growable: false)
      ..sort((LaunchableAppInfo a, LaunchableAppInfo b) =>
          a.label.toLowerCase().compareTo(b.label.toLowerCase()));
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .88,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    'Apps blocked during Study & Focus',
                    maxLines: 2,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    onChanged: (String value) => setState(() => _query = value),
                    decoration: InputDecoration(
                      labelText: 'Search installed apps',
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixText: '${_selected.length} selected',
                    ),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: <Widget>[
                  for (final MapEntry<String, String> item
                      in const <String, String>{
                    'distracting': 'Distracting',
                    'social': 'Social',
                    'video': 'Video',
                    'game': 'Games',
                    'shopping': 'Shopping',
                    'education': 'Education',
                    'useful': 'Useful',
                    'normal': 'Normal / safe',
                    'all': 'All apps',
                  }.entries) ...<Widget>[
                    FilterChip(
                      label: Text(item.value),
                      selected: _group == item.key,
                      onSelected: (_) => setState(() => _group = item.key),
                    ),
                    const SizedBox(width: 7),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (BuildContext context, int index) {
                  final LaunchableAppInfo app = filtered[index];
                  final bool selected = _selected.contains(app.packageName);
                  return CheckboxListTile(
                    value: selected,
                    title: Text(
                      app.label,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${app.categoryLabel} • ${app.packageName}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    onChanged: (bool? value) => setState(() {
                      if (value == true) {
                        _selected.add(app.packageName);
                      } else {
                        _selected.remove(app.packageName);
                      }
                    }),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(context).pop(_selected),
                  icon: const Icon(Icons.check_rounded),
                  label: Text('Save ${_selected.length} blocked apps'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
