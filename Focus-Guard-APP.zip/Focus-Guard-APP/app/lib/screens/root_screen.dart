import 'package:flutter/material.dart';

import '../widgets/root_navigation.dart';
import 'command_search_screen.dart';
import 'focus_hub_screen.dart';
import 'insights_screen.dart';
import 'more_screen.dart';
import 'planner_screen.dart';
import 'task_editor_screen.dart';
import 'today_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  final PageStorageBucket _pageStorageBucket = PageStorageBucket();
  int _index = 0;

  static const List<Widget> _pages = <Widget>[
    TodayScreen(key: PageStorageKey<String>('today-tab')),
    PlannerScreen(key: PageStorageKey<String>('planner-tab')),
    FocusHubScreen(key: PageStorageKey<String>('focus-tab')),
    InsightsScreen(key: PageStorageKey<String>('insights-tab')),
    CommandSearchScreen(key: PageStorageKey<String>('search-tab')),
    MoreScreen(key: PageStorageKey<String>('more-tab')),
  ];

  @override
  void initState() {
    super.initState();
    RootTabNavigation.selectedIndex.value = 0;
    RootTabNavigation.selectedIndex.addListener(_handleGlobalTabSelection);
  }

  void _handleGlobalTabSelection() {
    final int value = RootTabNavigation.selectedIndex.value;
    if (!mounted || value == _index || value < 0 || value >= _pages.length) {
      return;
    }
    setState(() => _index = value);
  }

  void _selectTab(int value) {
    if (value < 0 || value >= _pages.length) return;
    RootTabNavigation.select(value);
    if (value != _index) setState(() => _index = value);
  }

  @override
  void dispose() {
    RootTabNavigation.selectedIndex.removeListener(_handleGlobalTabSelection);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => RootNavigationScope(
        selectedIndex: _index,
        selectTab: _selectTab,
        child: Scaffold(
          body: PageStorage(
            bucket: _pageStorageBucket,
            child: RepaintBoundary(child: _pages[_index]),
          ),
          floatingActionButton: _index == 0 || _index == 1
              ? FloatingActionButton.extended(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const TaskEditorScreen(),
                    ),
                  ),
                  icon: const Icon(Icons.add_task_rounded),
                  label: const Text('New task'),
                )
              : null,
          bottomNavigationBar: NavigationBar(
            labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
            selectedIndex: _index,
            onDestinationSelected: _selectTab,
            destinations: const <NavigationDestination>[
              NavigationDestination(
                icon: Icon(Icons.today_outlined),
                selectedIcon: Icon(Icons.today_rounded),
                label: 'Today',
              ),
              NavigationDestination(
                icon: Icon(Icons.calendar_month_outlined),
                selectedIcon: Icon(Icons.calendar_month_rounded),
                label: 'Planner',
              ),
              NavigationDestination(
                icon: Icon(Icons.center_focus_strong_outlined),
                selectedIcon: Icon(Icons.center_focus_strong_rounded),
                label: 'Focus',
              ),
              NavigationDestination(
                icon: Icon(Icons.insights_outlined),
                selectedIcon: Icon(Icons.insights_rounded),
                label: 'Insights',
              ),
              NavigationDestination(
                icon: Icon(Icons.search_rounded),
                selectedIcon: Icon(Icons.manage_search_rounded),
                label: 'Search',
              ),
              NavigationDestination(
                icon: Icon(Icons.grid_view_outlined),
                selectedIcon: Icon(Icons.grid_view_rounded),
                label: 'More',
              ),
            ],
          ),
        ),
      );
}
