import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';

class SubjectManagerScreen extends StatelessWidget {
  const SubjectManagerScreen({super.key});

  static const List<Color> _colors = <Color>[
    Color(0xFF4F7CFF),
    Color(0xFFFFA62B),
    Color(0xFFB15CFF),
    Color(0xFF18B6A4),
    Color(0xFFE35768),
    Color(0xFF28A6E8),
    Color(0xFF55B84D),
    Color(0xFFFFD24A),
    Color(0xFF8892A6),
  ];

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Subjects & Categories')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context, controller, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add subject'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        itemCount: controller.data.subjects.length,
        itemBuilder: (BuildContext context, int index) {
          final SubjectItem subject = controller.data.subjects[index];
          final int taskCount = controller.taskCountForSubject(subject.id);
          return Card(
            child: ListTile(
              onTap: () => _edit(context, controller, subject),
              leading: CircleAvatar(
                backgroundColor: subject.color.withValues(alpha: 0.15),
                child: Icon(subject.icon, color: subject.color),
              ),
              title: Text(
                subject.name,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  decoration:
                      subject.archived ? TextDecoration.lineThrough : null,
                ),
              ),
              subtitle: Text(
                '$taskCount tasks${subject.archived ? ' • Archived' : ''}',
              ),
              trailing: PopupMenuButton<String>(
                onSelected: (String value) {
                  if (value == 'edit') {
                    _edit(context, controller, subject);
                  } else if (value == 'archive') {
                    controller.updateSubject(
                      subject.copyWith(archived: !subject.archived),
                    );
                  }
                },
                itemBuilder: (_) => <PopupMenuEntry<String>>[
                  const PopupMenuItem<String>(
                    value: 'edit',
                    child: Text('Edit'),
                  ),
                  if (subject.id != 'general')
                    PopupMenuItem<String>(
                      value: 'archive',
                      child: Text(subject.archived ? 'Restore' : 'Archive'),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _edit(
    BuildContext context,
    AppController controller,
    SubjectItem? subject,
  ) async {
    String nameText = subject?.name ?? '';
    Color selectedColor = subject?.color ?? _colors.first;
    IconData selectedIcon = subject?.icon ?? Icons.menu_book_rounded;
    const List<IconData> icons = <IconData>[
      Icons.menu_book_rounded,
      Icons.calculate_rounded,
      Icons.memory_rounded,
      Icons.science_rounded,
      Icons.code_rounded,
      Icons.language_rounded,
      Icons.work_rounded,
      Icons.health_and_safety_rounded,
      Icons.fact_check_rounded,
      Icons.category_rounded,
    ];

    final bool? save = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setDialogState) =>
            AlertDialog(
          title: Text(subject == null ? 'Add subject' : 'Edit subject'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextFormField(
                  initialValue: nameText,
                  autofocus: true,
                  decoration: const InputDecoration(labelText: 'Name'),
                  onChanged: (String value) => nameText = value,
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _colors
                      .map(
                        (Color color) => InkWell(
                          borderRadius: BorderRadius.circular(99),
                          onTap: () =>
                              setDialogState(() => selectedColor = color),
                          child: CircleAvatar(
                            backgroundColor: color,
                            child: selectedColor.toARGB32() == color.toARGB32()
                                ? const Icon(
                                    Icons.check_rounded,
                                    color: Colors.white,
                                  )
                                : null,
                          ),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: icons
                      .map(
                        (IconData icon) => ChoiceChip(
                          avatar: Icon(icon, size: 18),
                          label: const Text(''),
                          selected: selectedIcon.codePoint == icon.codePoint,
                          onSelected: (_) =>
                              setDialogState(() => selectedIcon = icon),
                        ),
                      )
                      .toList(),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    final String name = nameText.trim();
    if (save != true || name.isEmpty) {
      return;
    }
    if (subject == null) {
      await controller.addSubject(
        SubjectItem(
          id: newId('subject'),
          name: name,
          colorValue: selectedColor.toARGB32(),
          iconCodePoint: selectedIcon.codePoint,
        ),
      );
    } else {
      await controller.updateSubject(
        subject.copyWith(
          name: name,
          colorValue: selectedColor.toARGB32(),
          iconCodePoint: selectedIcon.codePoint,
        ),
      );
    }
  }
}
