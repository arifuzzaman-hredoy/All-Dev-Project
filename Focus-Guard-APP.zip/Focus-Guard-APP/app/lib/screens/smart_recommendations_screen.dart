import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';
import 'phone_control_screen.dart';
import 'safety_center_screen.dart';

class SmartRecommendationsScreen extends StatefulWidget {
  const SmartRecommendationsScreen({super.key});

  @override
  State<SmartRecommendationsScreen> createState() =>
      _SmartRecommendationsScreenState();
}

class _SmartRecommendationsScreenState
    extends State<SmartRecommendationsScreen> {
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    List<LaunchableAppInfo> apps = const <LaunchableAppInfo>[];
    PhoneControlPolicy policy = const PhoneControlPolicy();
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _apps = apps;
      _policy = policy;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final SmartFlowController smart = SmartFlowScope.of(context);
    final Set<String> controlled = _policy.rules
        .where((AppControlRule rule) => rule.enabled)
        .map((AppControlRule rule) => rule.packageName)
        .toSet();
    final List<LaunchableAppInfo> review = _apps
        .where((LaunchableAppInfo app) => app.suggestedForReview)
        .toList(growable: false)
      ..sort((LaunchableAppInfo a, LaunchableAppInfo b) {
        final int category = a.category.compareTo(b.category);
        return category != 0 ? category : a.label.compareTo(b.label);
      });
    final List<LaunchableAppInfo> protected = _apps
        .where((LaunchableAppInfo app) => app.protected)
        .toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Recommendations'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Refresh installed apps',
            onPressed: _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              key: const ValueKey<String>('smart-recommendations-scroll'),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Row(
                        children: <Widget>[
                          Icon(Icons.psychology_alt_rounded),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Recommendation only — never auto-block',
                              style: TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${review.length} distracting apps suggested for review • '
                        '${protected.length} essential apps protected • '
                        '${controlled.length} apps controlled by you',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const SectionHeader(
                  title: 'Suggested for review',
                  subtitle:
                      'Social, games, video and shopping apps detected on this phone.',
                ),
                const SizedBox(height: 10),
                if (review.isEmpty)
                  const EmptyState(
                    icon: Icons.check_circle_outline_rounded,
                    title: 'No distracting apps detected',
                    message:
                        'Refresh after installing an app or open App Rules to add one manually.',
                  )
                else
                  ...review.take(30).map(
                        (LaunchableAppInfo app) => Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              child: Text(
                                app.label.isEmpty
                                    ? '?'
                                    : app.label.substring(0, 1).toUpperCase(),
                              ),
                            ),
                            title: Text(
                              app.label,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900),
                            ),
                            subtitle: Text(
                              '${app.categoryLabel} • ${app.reason}\n'
                              '${app.suggestedDailyMinutes > 0 ? 'Suggested ${app.suggestedDailyMinutes} min/day' : 'Choose your own limit'}',
                            ),
                            isThreeLine: true,
                            trailing: controlled.contains(app.packageName)
                                ? const Chip(label: Text('Controlled'))
                                : const Icon(Icons.chevron_right_rounded),
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) => const PhoneControlScreen(),
                              ),
                            ),
                          ),
                        ),
                      ),
                const SizedBox(height: 18),
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.health_and_safety_rounded),
                    ),
                    title: Text(
                      '${protected.length} essential apps always protected',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Review protected apps and add your own always-allowed apps.',
                    ),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const SafetyCenterScreen(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: SwitchListTile.adaptive(
                    title: const Text(
                      'Show Smart Recommendations',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'Classify installed apps locally. Recommendations do not activate rules.',
                    ),
                    value: smart.settings.smartRecommendationsEnabled,
                    onChanged: smart.setRecommendationsEnabled,
                  ),
                ),
              ],
            ),
    );
  }
}
