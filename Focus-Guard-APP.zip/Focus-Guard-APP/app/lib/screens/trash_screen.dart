import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';

class TrashScreen extends StatelessWidget {
  const TrashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<TaskItem> tasks =
        controller.data.tasks.where((TaskItem item) => item.isDeleted).toList();
    final List<GoalItem> goals =
        controller.data.goals.where((GoalItem item) => item.isDeleted).toList();
    final List<NoteItem> notes =
        controller.data.notes.where((NoteItem item) => item.isDeleted).toList();
    final bool empty = tasks.isEmpty && goals.isEmpty && notes.isEmpty;

    return Scaffold(
      appBar: AppBar(title: const Text('Trash')),
      body: empty
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: EmptyState(
                icon: Icons.delete_outline_rounded,
                title: 'Trash is empty',
                message: 'Deleted items appear here and can be restored.',
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              children: <Widget>[
                if (tasks.isNotEmpty) ...<Widget>[
                  const SectionHeader(title: 'Tasks'),
                  const SizedBox(height: 8),
                  ...tasks.map(
                    (TaskItem item) => _TrashTile(
                      title: item.title,
                      subtitle: 'Deleted task',
                      onRestore: () => controller.restoreTask(item),
                      onDelete: () => _permanent(
                        context,
                        () => controller.permanentlyDeleteTask(item.id),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                if (goals.isNotEmpty) ...<Widget>[
                  const SectionHeader(title: 'Goals'),
                  const SizedBox(height: 8),
                  ...goals.map(
                    (GoalItem item) => _TrashTile(
                      title: item.title,
                      subtitle: 'Deleted goal',
                      onRestore: () => controller.restoreGoal(item),
                      onDelete: () => _permanent(
                        context,
                        () => controller.permanentlyDeleteGoal(item.id),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                if (notes.isNotEmpty) ...<Widget>[
                  const SectionHeader(title: 'Notes'),
                  const SizedBox(height: 8),
                  ...notes.map(
                    (NoteItem item) => _TrashTile(
                      title: item.title,
                      subtitle: 'Deleted note',
                      onRestore: () => controller.restoreNote(item),
                      onDelete: () => _permanent(
                        context,
                        () => controller.permanentlyDeleteNote(item.id),
                      ),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Future<void> _permanent(
    BuildContext context,
    Future<void> Function() action,
  ) async {
    final bool confirmed = await confirmAction(
      context,
      title: 'Permanently delete?',
      message: 'This item cannot be restored after permanent deletion.',
      confirmLabel: 'Delete permanently',
    );
    if (confirmed) {
      await action();
    }
  }
}

class _TrashTile extends StatelessWidget {
  const _TrashTile({
    required this.title,
    required this.subtitle,
    required this.onRestore,
    required this.onDelete,
  });

  final String title;
  final String subtitle;
  final VoidCallback onRestore;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: const Icon(Icons.restore_from_trash_rounded),
          title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(subtitle),
          trailing: PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'restore') {
                onRestore();
              } else {
                onDelete();
              }
            },
            itemBuilder: (_) => const <PopupMenuEntry<String>>[
              PopupMenuItem<String>(value: 'restore', child: Text('Restore')),
              PopupMenuItem<String>(
                value: 'delete',
                child: Text('Delete permanently'),
              ),
            ],
          ),
        ),
      );
}
