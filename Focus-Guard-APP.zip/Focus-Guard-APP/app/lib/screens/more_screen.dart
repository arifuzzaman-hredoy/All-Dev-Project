import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../controllers/smart_flow_controller.dart';
import '../models/smart_flow.dart';
import '../widgets/app_drawer.dart';
import 'backup_screen.dart';
import 'experience_settings_screen.dart';
import 'focus_game_screen.dart';
import 'goal_manager_screen.dart';
import 'habit_manager_screen.dart';
import 'notes_screen.dart';
import 'phone_control_dashboard_screen.dart';
import 'profile_screen.dart';
import 'protection_center_screen.dart';
import 'reels_insights_screen.dart';
import 'safety_center_screen.dart';
import 'schedule_profiles_screen.dart';
import 'settings_screen.dart';
import 'smart_coach_screen.dart';
import 'smart_recommendations_screen.dart';
import 'social_control_screen.dart';
import 'study_mode_screen.dart';
import 'subject_manager_screen.dart';
import 'trash_screen.dart';
import 'weekly_report_screen.dart';
import 'wellbeing_alerts_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final SmartFlowController smart = SmartFlowScope.of(context);
    final SmartFlowSettings settings = smart.settings;
    final List<_ToolSpec> simpleTools = _simpleTools(context)
        .where((_ToolSpec tool) => settings.simpleShortcutIds.contains(tool.id))
        .where((_ToolSpec tool) => _featureVisible(tool.id, settings))
        .toList(growable: false);

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: Text(settings.simpleMode ? 'My tools' : 'All tools'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simple & Advanced Mode',
            onPressed: () => _open(
              context,
              const ExperienceSettingsScreen(),
            ),
            icon: Icon(
              settings.simpleMode
                  ? Icons.auto_awesome_rounded
                  : Icons.tune_rounded,
            ),
          ),
        ],
      ),
      body: ListView(
        key: const ValueKey<String>('more-tools-scroll'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: Text(
                    controller.preferences.userName.isEmpty
                        ? 'F'
                        : controller.preferences.userName
                            .trim()
                            .substring(0, 1)
                            .toUpperCase(),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        controller.preferences.userName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${controller.activeTasks.length} tasks • '
                        '${controller.activeGoals.length} goals • '
                        '${controller.currentStreak} day streak',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Icon(
                  settings.simpleMode
                      ? Icons.auto_awesome_rounded
                      : Icons.tune_rounded,
                ),
              ),
              title: Text(
                '${settings.experienceMode.label} Mode',
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(
                settings.simpleMode
                    ? 'Only your chosen shortcuts are shown first.'
                    : 'Every management tool is visible directly.',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _open(context, const ExperienceSettingsScreen()),
            ),
          ),
          const SizedBox(height: 8),
          if (settings.simpleMode) ...<Widget>[
            ...simpleTools.map((_ToolSpec tool) => _tile(context, tool)),
            const SizedBox(height: 8),
            Card(
              child: ExpansionTile(
                key: const ValueKey<String>('advanced-tools-expansion'),
                leading: const CircleAvatar(
                  child: Icon(Icons.more_horiz_rounded),
                ),
                title: const Text(
                  'Advanced tools',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: const Text(
                  'Schedules, social controls, subjects, backup and settings',
                ),
                children: _advancedTools(context)
                    .map(
                      (_ToolSpec tool) => ListTile(
                        leading: Icon(tool.icon),
                        title: Text(tool.title),
                        subtitle: Text(tool.subtitle),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: tool.onTap,
                      ),
                    )
                    .toList(growable: false),
              ),
            ),
          ] else ...<Widget>[
            ..._allTools(context).map((_ToolSpec tool) => _tile(context, tool)),
          ],
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(
                    Icons.security_rounded,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Safety: recommendations never auto-block. Essential, emergency, banking and authenticator apps remain protected.',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  bool _featureVisible(String id, SmartFlowSettings settings) => switch (id) {
        'coach' => settings.dailyCoachEnabled,
        'weekly-report' => settings.weeklyReportEnabled,
        'recommendations' => settings.smartRecommendationsEnabled,
        _ => true,
      };

  List<_ToolSpec> _simpleTools(BuildContext context) => <_ToolSpec>[
        _ToolSpec(
          id: 'coach',
          icon: Icons.auto_awesome_rounded,
          title: 'Daily Coach',
          subtitle: 'Today’s top actions and safe plan',
          onTap: () => _open(context, const SmartCoachScreen()),
        ),
        _ToolSpec(
          id: 'phone-control',
          icon: Icons.phonelink_lock_rounded,
          title: 'Phone Control',
          subtitle: 'Limits, schedules and Reels controls',
          onTap: () => _open(context, const PhoneControlDashboardScreen()),
        ),
        _ToolSpec(
          id: 'study',
          icon: Icons.school_rounded,
          title: 'Study Mode',
          subtitle: 'Study schedule and Focus-shared rules',
          onTap: () => _open(context, const StudyModeScreen()),
        ),
        _ToolSpec(
          id: 'weekly-report',
          icon: Icons.summarize_rounded,
          title: 'Weekly Report',
          subtitle: 'Tasks, focus, productive days and best day',
          onTap: () => _open(context, const WeeklyReportScreen()),
        ),
        _ToolSpec(
          id: 'safety',
          icon: Icons.health_and_safety_rounded,
          title: 'Safety Center',
          subtitle: 'Always allowed apps and one-tap safety stop',
          onTap: () => _open(context, const SafetyCenterScreen()),
        ),
        _ToolSpec(
          id: 'recommendations',
          icon: Icons.psychology_alt_rounded,
          title: 'Smart Recommendations',
          subtitle: 'Local app categories without automatic blocking',
          onTap: () => _open(context, const SmartRecommendationsScreen()),
        ),
        _ToolSpec(
          id: 'goals',
          icon: Icons.flag_rounded,
          title: 'Goals & Targets',
          subtitle: 'Progress and deadlines',
          onTap: () => _open(context, const GoalManagerScreen()),
        ),
        _ToolSpec(
          id: 'notes',
          icon: Icons.sticky_note_2_rounded,
          title: 'Notes',
          subtitle: 'Quick and pinned notes',
          onTap: () => _open(context, const NotesScreen()),
        ),
      ];

  List<_ToolSpec> _advancedTools(BuildContext context) => <_ToolSpec>[
        _ToolSpec(
          id: 'protection',
          icon: Icons.shield_rounded,
          title: 'Protection Center',
          subtitle: 'Web, DNS, Prime Mode and Keep Me Out',
          onTap: () => _open(context, const ProtectionCenterScreen()),
        ),
        _ToolSpec(
          id: 'schedules',
          icon: Icons.calendar_month_rounded,
          title: 'Schedule Profiles',
          subtitle: 'Recurring profiles and emergency unlocks',
          onTap: () => _open(context, const ScheduleProfilesScreen()),
        ),
        _ToolSpec(
          id: 'social',
          icon: Icons.notifications_off_rounded,
          title: 'Social & Notifications',
          subtitle: 'Notification and short-video controls',
          onTap: () => _open(context, const SocialControlScreen()),
        ),
        _ToolSpec(
          id: 'reels-insights',
          icon: Icons.smart_display_rounded,
          title: 'Reels & Shorts Limits',
          subtitle: 'Per-app counts, minutes and milestone warnings',
          onTap: () => _open(context, const ReelsInsightsScreen()),
        ),
        _ToolSpec(
          id: 'wellbeing-alerts',
          icon: Icons.notifications_active_rounded,
          title: 'Screen-time Warnings',
          subtitle: 'Detailed goal and over-limit notifications',
          onTap: () => _open(context, const WellbeingAlertsScreen()),
        ),
        _ToolSpec(
          id: 'profile',
          icon: Icons.person_rounded,
          title: 'Profile',
          subtitle: 'Identity, exam target and routine restart',
          onTap: () => _open(context, const ProfileScreen()),
        ),
        _ToolSpec(
          id: 'quest',
          icon: Icons.sports_esports_rounded,
          title: 'Study Quest',
          subtitle: 'XP, levels and achievements',
          onTap: () => _open(context, const FocusGameScreen()),
        ),
        _ToolSpec(
          id: 'subjects',
          icon: Icons.category_rounded,
          title: 'Subjects & Categories',
          subtitle: 'Create, archive and customize subjects',
          onTap: () => _open(context, const SubjectManagerScreen()),
        ),
        _ToolSpec(
          id: 'habits',
          icon: Icons.repeat_rounded,
          title: 'Habits',
          subtitle: 'Weekdays and streak tracking',
          onTap: () => _open(context, const HabitManagerScreen()),
        ),
        _ToolSpec(
          id: 'trash',
          icon: Icons.delete_sweep_rounded,
          title: 'Trash',
          subtitle: 'Restore deleted tasks, goals and notes',
          onTap: () => _open(context, const TrashScreen()),
        ),
        _ToolSpec(
          id: 'backup',
          icon: Icons.backup_rounded,
          title: 'Backup & Restore',
          subtitle: 'Local JSON export, import and reset',
          onTap: () => _open(context, const BackupScreen()),
        ),
        _ToolSpec(
          id: 'settings',
          icon: Icons.settings_rounded,
          title: 'App Settings',
          subtitle: 'Theme, alarms, battery and permissions',
          onTap: () => _open(context, const SettingsScreen()),
        ),
      ];

  List<_ToolSpec> _allTools(BuildContext context) {
    final SmartFlowSettings settings = SmartFlowScope.of(context).settings;
    return <_ToolSpec>[
      ..._simpleTools(context).where(
        (_ToolSpec tool) => _featureVisible(tool.id, settings),
      ),
      ..._advancedTools(context),
    ];
  }

  Widget _tile(BuildContext context, _ToolSpec tool) => Card(
        margin: const EdgeInsets.only(bottom: 9),
        child: ListTile(
          onTap: tool.onTap,
          leading: CircleAvatar(child: Icon(tool.icon)),
          title: Text(
            tool.title,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          subtitle: Text(tool.subtitle),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }
}

class _ToolSpec {
  const _ToolSpec({
    required this.id,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final String id;
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
}
