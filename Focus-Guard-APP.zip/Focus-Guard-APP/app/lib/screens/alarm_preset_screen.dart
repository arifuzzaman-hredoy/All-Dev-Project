import 'package:flutter/material.dart';

import '../models/alarm_presets.dart';
import '../widgets/common_widgets.dart';

class AlarmPresetScreen extends StatefulWidget {
  const AlarmPresetScreen({super.key});

  @override
  State<AlarmPresetScreen> createState() => _AlarmPresetScreenState();
}

class _AlarmPresetScreenState extends State<AlarmPresetScreen> {
  String _query = '';
  String _category = 'All';

  @override
  Widget build(BuildContext context) {
    final String query = _query.trim().toLowerCase();
    final List<String> categories = <String>{
      'All',
      ...AlarmPresetCatalog.all.map((AlarmPreset item) => item.category),
    }.toList(growable: false);
    final List<AlarmPreset> presets =
        AlarmPresetCatalog.all.where((AlarmPreset item) {
      final bool category = _category == 'All' || item.category == _category;
      final bool text = query.isEmpty ||
          item.title.toLowerCase().contains(query) ||
          item.notes.toLowerCase().contains(query);
      return category && text;
    }).toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Alarm preset library'),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              autofocus: false,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search_rounded),
                labelText: 'Search 216 alarm presets',
              ),
              onChanged: (String value) => setState(() => _query = value),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: categories
                  .map(
                    (String value) => Padding(
                      padding: const EdgeInsets.only(right: 7),
                      child: FilterChip(
                        label: Text(value),
                        selected: _category == value,
                        onSelected: (_) => setState(() => _category = value),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: presets.isEmpty
                ? const EmptyState(
                    icon: Icons.alarm_off_rounded,
                    title: 'No preset found',
                    message: 'Try another keyword or category.',
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    itemCount: presets.length,
                    itemBuilder: (BuildContext context, int index) {
                      final AlarmPreset preset = presets[index];
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(child: Icon(preset.icon)),
                          title: Text(
                            preset.title,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${preset.timeLabel(context)} • ${preset.durationMinutes} min • ${preset.category}',
                          ),
                          trailing: const Icon(Icons.add_task_rounded),
                          onTap: () => Navigator.of(context).pop(preset),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
