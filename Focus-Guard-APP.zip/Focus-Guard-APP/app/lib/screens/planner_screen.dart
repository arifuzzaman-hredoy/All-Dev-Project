import 'dart:async';

import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';
import '../widgets/app_drawer.dart';
import 'task_editor_screen.dart';

class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key});

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  String _query = '';
  String? _subjectFilter;
  Timer? _searchDebounce;

  @override
  void dispose() {
    _searchDebounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    _searchDebounce?.cancel();
    final String next = value.trim().toLowerCase();
    _searchDebounce = Timer(const Duration(milliseconds: 180), () {
      if (mounted && next != _query) {
        setState(() => _query = next);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final DateTime selected = controller.selectedDate;
    final List<TaskItem> source = controller.tasksFor(selected);
    final List<TaskItem> tasks = (_query.isEmpty && _subjectFilter == null)
        ? source
        : source.where((TaskItem task) {
            final bool matchesQuery = _query.isEmpty ||
                task.title.toLowerCase().contains(_query) ||
                task.notes.toLowerCase().contains(_query);
            final bool matchesSubject =
                _subjectFilter == null || task.subjectId == _subjectFilter;
            return matchesQuery && matchesSubject;
          }).toList(growable: false);

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: const Text('Planner & Tasks'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Jump to date',
            onPressed: () => _pickDate(controller),
            icon: const Icon(Icons.event_rounded),
          ),
        ],
      ),
      body: CustomScrollView(
        key: const PageStorageKey<String>('planner-scroll'),
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        slivers: <Widget>[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
              child: _DateStrip(controller: controller),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Search tasks...',
                  prefixIcon: Icon(Icons.search_rounded),
                ),
                onChanged: _onSearchChanged,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
              child: DropdownButtonFormField<String?>(
                isExpanded: true,
                key: ValueKey<String?>(_subjectFilter),
                initialValue: _subjectFilter,
                decoration: const InputDecoration(
                  labelText: 'Subject filter',
                  prefixIcon: Icon(Icons.filter_alt_rounded),
                ),
                items: <DropdownMenuItem<String?>>[
                  const DropdownMenuItem<String?>(
                    value: null,
                    child: Text('All subjects'),
                  ),
                  ...controller.activeSubjects.map(
                    (SubjectItem subject) => DropdownMenuItem<String?>(
                      value: subject.id,
                      child: Text(
                        subject.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
                onChanged: (String? value) {
                  if (value != _subjectFilter) {
                    setState(() => _subjectFilter = value);
                  }
                },
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
              child: SectionHeader(
                title: formatDate(selected),
                subtitle:
                    '${tasks.length} task${tasks.length == 1 ? '' : 's'} • ${controller.completionPercent(selected)}% complete',
              ),
            ),
          ),
          if (tasks.isEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: EmptyState(
                  icon: Icons.event_note_rounded,
                  title: 'No tasks on this date',
                  message: 'Add a task to customize the routine.',
                  action: FilledButton.icon(
                    onPressed: () => _addForSelectedDate(context, selected),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Add task'),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    final TaskItem task = tasks[index];
                    return TaskTile(
                      task: task,
                      onToggle: (bool value) =>
                          controller.setTaskCompleted(task, value),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => TaskEditorScreen(task: task),
                        ),
                      ),
                      onMore: () => _showMenu(context, controller, task),
                    );
                  },
                  childCount: tasks.length,
                  addAutomaticKeepAlives: false,
                ),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 110)),
        ],
      ),
    );
  }

  Future<void> _pickDate(AppController controller) async {
    FocusManager.instance.primaryFocus?.unfocus();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: controller.selectedDate,
      firstDate: DateTime(2025),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      controller.selectDate(picked);
    }
  }

  void _addForSelectedDate(BuildContext context, DateTime date) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => TaskEditorScreen(initialDate: date),
      ),
    );
  }

  Future<void> _showMenu(
    BuildContext context,
    AppController controller,
    TaskItem task,
  ) async {
    final String? action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.edit_rounded),
              title: const Text('Edit'),
              onTap: () => Navigator.of(sheetContext).pop('edit'),
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Duplicate for tomorrow'),
              onTap: () => Navigator.of(sheetContext).pop('duplicate'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded),
              title: const Text('Move to trash'),
              onTap: () => Navigator.of(sheetContext).pop('delete'),
            ),
          ],
        ),
      ),
    );
    if (!context.mounted) return;
    switch (action) {
      case 'edit':
        await Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => TaskEditorScreen(task: task)),
        );
        break;
      case 'duplicate':
        await controller.duplicateTask(task);
        break;
      case 'delete':
        await controller.deleteTask(task);
        break;
      default:
        break;
    }
  }
}

class _DateStrip extends StatelessWidget {
  const _DateStrip({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final DateTime selected = controller.selectedDate;
    final List<DateTime> dates = List<DateTime>.generate(
      9,
      (int index) => selected.add(Duration(days: index - 4)),
      growable: false,
    );
    return SizedBox(
      height: 82,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: dates.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (BuildContext context, int index) {
          final DateTime date = dates[index];
          final bool active = dateKey(date) == dateKey(selected);
          return InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => controller.selectDate(date),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 62,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: active
                    ? Theme.of(context).colorScheme.primaryContainer
                    : Theme.of(context).colorScheme.surfaceContainerLow,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: active
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outlineVariant,
                ),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      const <String>[
                        'Mon',
                        'Tue',
                        'Wed',
                        'Thu',
                        'Fri',
                        'Sat',
                        'Sun',
                      ][date.weekday - 1],
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${date.day}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                    Text(
                      '${controller.completionPercent(date)}%',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
