import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/app_drawer.dart';
import '../widgets/common_widgets.dart';

class GoalManagerScreen extends StatelessWidget {
  const GoalManagerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<GoalItem> goals = controller.activeGoals;
    final int totalTarget =
        goals.fold<int>(0, (int sum, GoalItem goal) => sum + goal.target);
    final int totalProgress = goals.fold<int>(
      0,
      (int sum, GoalItem goal) => sum + controller.effectiveGoalProgress(goal),
    );
    final double overall = totalTarget == 0
        ? 0
        : (totalProgress / totalTarget).clamp(0.0, 1.0).toDouble();

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(title: const Text('Goals & Targets')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context, controller, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add goal'),
      ),
      body: goals.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: EmptyState(
                icon: Icons.flag_outlined,
                title: 'No goals yet',
                message: 'Create a chapter target or deadline goal.',
              ),
            )
          : CustomScrollView(
              slivers: <Widget>[
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  sliver: SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              const Icon(Icons.flag_circle_rounded, size: 36),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      'Exam target dashboard',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge
                                          ?.copyWith(
                                            fontWeight: FontWeight.w900,
                                          ),
                                    ),
                                    Text(
                                      '${controller.completedGoalCount}/${goals.length} goals completed',
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                '${(overall * 100).round()}%',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.w900,
                                    ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          LinearProgressIndicator(
                            value: overall,
                            minHeight: 11,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          const SizedBox(height: 8),
                          Text(
                              '$totalProgress of $totalTarget tracked units complete'),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 110),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        final GoalItem goal = goals[index];
                        final SubjectItem subject =
                            controller.subjectById(goal.subjectId);
                        final int effective =
                            controller.effectiveGoalProgress(goal);
                        final bool autoSynced = effective > goal.progress;
                        final bool completed = effective >= goal.target;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(18),
                            onTap: () => _edit(context, controller, goal),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      CircleAvatar(
                                        backgroundColor: subject.color
                                            .withValues(alpha: 0.15),
                                        child: Icon(subject.icon,
                                            color: subject.color),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          goal.title,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w900),
                                        ),
                                      ),
                                      if (completed)
                                        Icon(
                                          Icons.verified_rounded,
                                          color: Theme.of(context)
                                              .colorScheme
                                              .primary,
                                        ),
                                      PopupMenuButton<String>(
                                        onSelected: (String action) {
                                          if (action == 'edit') {
                                            _edit(context, controller, goal);
                                          } else if (action == 'delete') {
                                            controller.deleteGoal(goal);
                                          }
                                        },
                                        itemBuilder: (_) =>
                                            const <PopupMenuEntry<String>>[
                                          PopupMenuItem<String>(
                                              value: 'edit',
                                              child: Text('Edit')),
                                          PopupMenuItem<String>(
                                              value: 'delete',
                                              child: Text('Move to trash')),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  Row(
                                    children: <Widget>[
                                      SubjectBadge(subject: subject),
                                      if (autoSynced) ...<Widget>[
                                        const SizedBox(width: 8),
                                        const Chip(
                                          visualDensity: VisualDensity.compact,
                                          avatar: Icon(Icons.sync_rounded,
                                              size: 16),
                                          label: Text('Auto-synced'),
                                        ),
                                      ],
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  LinearProgressIndicator(
                                    value: controller.effectiveGoalRatio(goal),
                                    minHeight: 9,
                                    borderRadius: BorderRadius.circular(99),
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: <Widget>[
                                      Text('$effective/${goal.target}',
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w800)),
                                      const Spacer(),
                                      Text(
                                          'Deadline ${formatDate(goal.deadline)}'),
                                    ],
                                  ),
                                  if (goal.notes.isNotEmpty) ...<Widget>[
                                    const SizedBox(height: 8),
                                    Text(goal.notes),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      childCount: goals.length,
                      addAutomaticKeepAlives: false,
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _edit(
      BuildContext context, AppController controller, GoalItem? goal) async {
    String titleText = goal?.title ?? '';
    String targetText = '${goal?.target ?? 10}';
    String progressText = '${goal?.progress ?? 0}';
    String notesText = goal?.notes ?? '';
    String subjectId = goal?.subjectId ?? controller.activeSubjects.first.id;
    DateTime deadline =
        goal?.deadline ?? DateTime.now().add(const Duration(days: 7));

    final bool? save = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setDialogState) =>
            AlertDialog(
          title: Text(goal == null ? 'Add goal' : 'Edit goal'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextFormField(
                  initialValue: titleText,
                  decoration: const InputDecoration(labelText: 'Goal title'),
                  onChanged: (String value) => titleText = value,
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  key: ValueKey<String>(subjectId),
                  initialValue: subjectId,
                  decoration: const InputDecoration(labelText: 'Subject'),
                  items: controller.activeSubjects
                      .map((SubjectItem item) => DropdownMenuItem<String>(
                          value: item.id, child: Text(item.name)))
                      .toList(),
                  onChanged: (String? value) {
                    if (value != null) setDialogState(() => subjectId = value);
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: TextFormField(
                        initialValue: targetText,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Target'),
                        onChanged: (String value) => targetText = value,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        initialValue: progressText,
                        keyboardType: TextInputType.number,
                        decoration:
                            const InputDecoration(labelText: 'Manual progress'),
                        onChanged: (String value) => progressText = value,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Completed tasks for this subject can automatically raise the displayed progress.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: deadline,
                      firstDate: DateTime(2025),
                      lastDate: DateTime(2030),
                    );
                    if (picked != null) setDialogState(() => deadline = picked);
                  },
                  icon: const Icon(Icons.event_rounded),
                  label: Text('Deadline ${formatDate(deadline)}'),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  initialValue: notesText,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Notes'),
                  onChanged: (String value) => notesText = value,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('Save')),
          ],
        ),
      ),
    );

    final String titleValue = titleText.trim();
    final int targetValue = int.tryParse(targetText.trim()) ?? 1;
    final int progressValue = int.tryParse(progressText.trim()) ?? 0;
    if (save != true || titleValue.isEmpty || targetValue < 1) return;

    final DateTime now = DateTime.now();
    if (goal == null) {
      await controller.addGoal(
        GoalItem(
          id: newId('goal'),
          title: titleValue,
          subjectId: subjectId,
          target: targetValue,
          progress: progressValue.clamp(0, targetValue).toInt(),
          deadline: deadline,
          notes: notesText.trim(),
          createdAt: now,
          updatedAt: now,
        ),
      );
    } else {
      await controller.updateGoal(
        goal.copyWith(
          title: titleValue,
          subjectId: subjectId,
          target: targetValue,
          progress: progressValue.clamp(0, targetValue).toInt(),
          deadline: deadline,
          notes: notesText.trim(),
          updatedAt: now,
        ),
      );
    }
  }
}
