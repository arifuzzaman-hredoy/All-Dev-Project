import 'package:flutter/material.dart';

import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import 'focus_game_screen.dart';
import 'study_mode_screen.dart';
import 'phone_control_screen.dart';
import 'protection_center_screen.dart';
import 'schedule_profiles_screen.dart';
import 'social_control_screen.dart';

class ActiveFeaturesScreen extends StatefulWidget {
  const ActiveFeaturesScreen({
    this.initialPolicy = const PhoneControlPolicy(),
    this.initialReadiness,
    super.key,
  });

  final PhoneControlPolicy initialPolicy;
  final NativeSystemReadiness? initialReadiness;

  @override
  State<ActiveFeaturesScreen> createState() => _ActiveFeaturesScreenState();
}

class _ActiveFeaturesScreenState extends State<ActiveFeaturesScreen>
    with WidgetsBindingObserver {
  late PhoneControlPolicy _policy;
  NativeSystemReadiness? _readiness;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _policy = widget.initialPolicy;
    _readiness = widget.initialReadiness;
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _refresh() async {
    PhoneControlPolicy policy = _policy;
    NativeSystemReadiness? readiness = _readiness;
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _readiness = readiness;
    });
  }

  Future<void> _setPolicy(PhoneControlPolicy policy) async {
    if (_saving) return;
    final PhoneControlPolicy previous = _policy;
    setState(() {
      _policy = policy;
      _saving = true;
    });
    try {
      await NativeBridge.savePhoneControlPolicy(policy);
    } catch (error) {
      if (!mounted) return;
      setState(() => _policy = previous);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save feature: $error')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
    if (mounted) await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final int liveCount = _policy.activeFeatureCount;
    return Scaffold(
      appBar: AppBar(
        title: Text('Phone Features $liveCount/11'),
        actions: <Widget>[
          if (_saving)
            const Padding(
              padding: EdgeInsets.only(right: 18),
              child: Center(
                child: SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            )
          else
            IconButton(
              tooltip: 'Refresh',
              onPressed: _refresh,
              icon: const Icon(Icons.refresh_rounded),
            ),
        ],
      ),
      body: ListView(
        key: const ValueKey<String>('active-features-scroll-view'),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
        children: <Widget>[
          _MasterFeatureCard(
            active: _policy.masterEnabled,
            onChanged: (bool value) =>
                _setPolicy(_policy.copyWith(masterEnabled: value)),
          ),
          const SizedBox(height: 16),
          _FeatureGroup(
            title: 'BLOCKING & LIMITS',
            children: <Widget>[
              _FeatureSwitchTile(
                icon: Icons.schedule_rounded,
                title: 'Schedule Blocker',
                subtitle: 'Apps work only during their allowed day and time',
                value: _policy.scheduleEnabled,
                onChanged: (bool value) =>
                    _setPolicy(_policy.copyWith(scheduleEnabled: value)),
              ),
              _FeatureSwitchTile(
                icon: Icons.calendar_month_rounded,
                title: 'Schedule Profiles',
                subtitle:
                    'Run named recurring profiles with multiple blocked apps',
                value: _policy.scheduleProfilesEnabled,
                onChanged: (bool value) => _setPolicy(
                  _policy.copyWith(scheduleProfilesEnabled: value),
                ),
              ),
              _FeatureSwitchTile(
                icon: Icons.timer_outlined,
                title: 'App Limits',
                subtitle: 'Set a daily minute limit for each controlled app',
                value: _policy.appLimitsEnabled,
                onChanged: (bool value) =>
                    _setPolicy(_policy.copyWith(appLimitsEnabled: value)),
              ),
              _FeatureSwitchTile(
                icon: Icons.smart_display_rounded,
                title: 'Reels & Shorts Guard',
                subtitle: 'Exit detected short-video loops on supported apps',
                value: _policy.reelsBlockerEnabled,
                onChanged: (bool value) => _setPolicy(
                  _policy.copyWith(reelsBlockerEnabled: value),
                ),
              ),
              _FeatureSwitchTile(
                icon: Icons.swap_vert_rounded,
                title: 'Scroll Limit',
                subtitle: 'Stop endless scrolling after your gesture limit',
                value: _policy.scrollLimitEnabled,
                onChanged: (bool value) =>
                    _setPolicy(_policy.copyWith(scrollLimitEnabled: value)),
              ),
              _FeatureSwitchTile(
                icon: Icons.notifications_off_rounded,
                title: 'Notification Blocker',
                subtitle:
                    'Cancel selected app notifications and keep local history',
                value: _policy.notificationBlockerEnabled,
                onChanged: (bool value) => _setPolicy(
                  _policy.copyWith(notificationBlockerEnabled: value),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _FeatureGroup(
            title: 'STUDY & FOCUS',
            children: <Widget>[
              _FeatureLinkTile(
                icon: Icons.menu_book_rounded,
                title: 'Study Mode',
                subtitle:
                    'Subjects, todo, goals, analytics and a manual distraction block list',
                badge: _policy.studyModeEnabled ? 'ON' : 'OFF',
                onTap: () => _open(const StudyModeScreen()),
              ),
              _FeatureLinkTile(
                icon: Icons.park_rounded,
                title: 'Focus Tree',
                subtitle: 'Grow a visual tree, XP and levels while studying',
                badge: 'READY',
                onTap: () => _open(const FocusGameScreen()),
              ),
              _FeatureLinkTile(
                icon: Icons.calendar_month_rounded,
                title: 'Recurring Schedule Profiles',
                subtitle: 'Student Focus, Night Detox and custom profiles',
                badge: '${_policy.profiles.length}',
                onTap: () => _open(const ScheduleProfilesScreen()),
              ),
              _FeatureLinkTile(
                icon: Icons.notifications_off_rounded,
                title: 'Social & Notification Control',
                subtitle: 'Selected notifications, Reels and scroll analytics',
                badge: 'READY',
                onTap: () => _open(const SocialControlScreen()),
              ),
              _FeatureLinkTile(
                icon: Icons.apps_rounded,
                title: 'Controlled Apps',
                subtitle: 'Add apps, allowed hours, limits and scroll rules',
                badge: '${_policy.rules.length}',
                onTap: () => _open(const PhoneControlScreen()),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _FeatureGroup(
            title: 'WEB & HARDCORE PROTECTION',
            children: <Widget>[
              _FeatureLinkTile(
                icon: Icons.shield_rounded,
                title: 'Protection Center',
                subtitle:
                    'Local DNS, custom domains, adult protection, Prime Mode and Keep Me Out',
                badge: 'READY',
                onTap: () => _open(const ProtectionCenterScreen()),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _PermissionPanel(readiness: _readiness),
          const SizedBox(height: 14),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(Icons.verified_user_outlined),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'All controls shown here are installed locally. Permissions and Android system limits are reported separately so protection status stays honest.',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MasterFeatureCard extends StatelessWidget {
  const _MasterFeatureCard({required this.active, required this.onChanged});

  final bool active;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: active ? colors.primaryContainer : colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(
          color: active ? colors.primary : colors.outlineVariant,
          width: active ? 2 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              CircleAvatar(
                radius: 26,
                backgroundColor:
                    active ? colors.primary : colors.surfaceContainerHighest,
                foregroundColor: active ? colors.onPrimary : colors.onSurface,
                child: const Icon(Icons.bolt_rounded, size: 30),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Master Phone Control',
                      style:
                          TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                    ),
                    SizedBox(height: 2),
                    Text(
                        'Runs every enabled schedule, limit and content guard'),
                  ],
                ),
              ),
              Switch.adaptive(value: active, onChanged: onChanged),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _StatusChip(
                  label: active ? 'Active' : 'Inactive', active: active),
              const _StatusChip(label: 'Rules preserved', active: true),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.label, required this.active});

  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: active
              ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.12)
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text(
          label,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
        ),
      );
}

class _FeatureGroup extends StatelessWidget {
  const _FeatureGroup({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            child: Text(
              title,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.9,
                  ),
            ),
          ),
          Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children:
                  List<Widget>.generate(children.length * 2 - 1, (int index) {
                if (index.isOdd) return const Divider(height: 1);
                return children[index ~/ 2];
              }),
            ),
          ),
        ],
      );
}

class _FeatureSwitchTile extends StatelessWidget {
  const _FeatureSwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => SwitchListTile.adaptive(
        secondary: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle),
        value: value,
        onChanged: onChanged,
      );
}

class _FeatureLinkTile extends StatelessWidget {
  const _FeatureLinkTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String badge;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        onTap: onTap,
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                badge,
                style:
                    const TextStyle(fontSize: 9, fontWeight: FontWeight.w900),
              ),
            ),
            const SizedBox(width: 5),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      );
}

class _PermissionPanel extends StatelessWidget {
  const _PermissionPanel({required this.readiness});

  final NativeSystemReadiness? readiness;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            child: Text(
              'PERMISSIONS',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.9,
                  ),
            ),
          ),
          Card(
            child: Column(
              children: <Widget>[
                _PermissionTile(
                  title: 'Accessibility Service',
                  subtitle: 'Required for app blocking and scroll detection',
                  ready: readiness?.accessibilityEnabled ?? false,
                  onTap: NativeBridge.openAccessibilitySettings,
                ),
                const Divider(height: 1),
                _PermissionTile(
                  title: 'Usage Stats Access',
                  subtitle:
                      'Required for accurate screen-time limits and charts',
                  ready: readiness?.usageAccessEnabled ?? false,
                  onTap: NativeBridge.openUsageAccessSettings,
                ),
                const Divider(height: 1),
                _PermissionTile(
                  title: 'Notification Access',
                  subtitle:
                      'Required for selected-app notification blocking and history',
                  ready: readiness?.notificationAccessEnabled ?? false,
                  onTap: NativeBridge.openNotificationAccessSettings,
                ),
                const Divider(height: 1),
                _PermissionTile(
                  title: 'Background Permission',
                  subtitle:
                      'Keeps schedules and alarms reliable with screen off',
                  ready: readiness?.batteryOptimizationIgnored ?? false,
                  onTap: NativeBridge.requestBatteryOptimizationExemption,
                ),
              ],
            ),
          ),
        ],
      );
}

class _PermissionTile extends StatelessWidget {
  const _PermissionTile({
    required this.title,
    required this.subtitle,
    required this.ready,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool ready;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        leading: Icon(
          ready ? Icons.verified_rounded : Icons.shield_outlined,
          color: ready
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.error,
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('$subtitle\n${ready ? 'Enabled' : 'Missing'}'),
        isThreeLine: true,
        trailing: TextButton(
          onPressed: onTap,
          child: Text(ready ? 'View' : 'Enable'),
        ),
      );
}
