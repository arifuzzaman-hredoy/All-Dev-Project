import 'package:flutter/material.dart';

import '../controllers/smart_flow_controller.dart';
import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../services/policy_safety.dart';
import '../widgets/common_widgets.dart';
import '../widgets/rule_activation_preview.dart';
import 'reels_insights_screen.dart';
import 'schedule_profiles_screen.dart';
import 'wellbeing_alerts_screen.dart';

class PhoneControlScreen extends StatefulWidget {
  const PhoneControlScreen({super.key});

  @override
  State<PhoneControlScreen> createState() => _PhoneControlScreenState();
}

class _PhoneControlScreenState extends State<PhoneControlScreen>
    with WidgetsBindingObserver {
  static const Set<String> _reelsPackages = <String>{
    'com.instagram.android',
    'com.facebook.katana',
    'com.google.android.youtube',
    'com.zhiliaoapp.musically',
    'com.ss.android.ugc.trill',
  };

  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlUsage _usage = const PhoneControlUsage();
  NativeSystemReadiness? _readiness;
  List<LaunchableAppInfo> _apps = const <LaunchableAppInfo>[];
  bool _loading = true;
  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refreshStatus();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load() async {
    PhoneControlPolicy policy = const PhoneControlPolicy();
    PhoneControlUsage usage = const PhoneControlUsage();
    NativeSystemReadiness? readiness;
    List<LaunchableAppInfo> apps = const <LaunchableAppInfo>[];
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      usage = await NativeBridge.phoneControlUsage();
    } catch (_) {}
    try {
      readiness = await NativeBridge.systemReadiness();
    } catch (_) {}
    try {
      apps = await NativeBridge.launchableApps();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _usage = usage;
      _readiness = readiness;
      _apps = apps;
      _loading = false;
      _dirty = false;
    });
  }

  Future<void> _refreshStatus() async {
    try {
      final NativeSystemReadiness readiness =
          await NativeBridge.systemReadiness();
      final PhoneControlUsage usage = await NativeBridge.phoneControlUsage();
      if (mounted) {
        setState(() {
          _readiness = readiness;
          _usage = usage;
        });
      }
    } catch (_) {}
  }

  void _updatePolicy(PhoneControlPolicy policy) {
    setState(() {
      _policy = policy;
      _dirty = true;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final SmartFlowController? smart = SmartFlowScope.maybeOf(context);
    final Set<String> alwaysAllowed =
        smart?.settings.userAlwaysAllowedPackages ?? const <String>{};
    final PhoneControlPolicy policyToSave =
        sanitizePhoneControlForAlwaysAllowed(_policy, alwaysAllowed);
    if (smart?.settings.rulePreviewRequired ?? true) {
      final bool confirmed = await RuleActivationPreviewSheet.show(
        context,
        policy: policyToSave,
        apps: _apps,
        alwaysAllowedPackages: alwaysAllowed,
      );
      if (!confirmed || !mounted) return;
    }
    setState(() => _saving = true);
    try {
      await NativeBridge.savePhoneControlPolicy(policyToSave);
      final PhoneControlPolicy saved = await NativeBridge.phoneControlPolicy();
      final PhoneControlUsage usage = await NativeBridge.phoneControlUsage();
      if (!mounted) return;
      setState(() {
        _policy = saved;
        _usage = usage;
        _dirty = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Saved. Only apps you selected can be blocked.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save Phone Control: $error')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _runSafeSetup() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final PhoneControlPolicy safe =
          await NativeBridge.runPhoneControlSafeSetup();
      if (!mounted) return;
      setState(() {
        _policy = safe;
        _dirty = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Safe setup complete. Everything is allowed until you block an app.',
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _emergencyStop() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final PhoneControlPolicy safe =
          await NativeBridge.emergencyStopAllBlocking();
      if (!mounted) return;
      setState(() {
        _policy = safe;
        _dirty = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('All blocking stopped. Your data is safe.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _addApp() async {
    final Set<String> alwaysAllowed =
        SmartFlowScope.maybeOf(context)?.settings.userAlwaysAllowedPackages ??
            const <String>{};
    final LaunchableAppInfo? selected =
        await showModalBottomSheet<LaunchableAppInfo>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext context) => _AppPickerSheet(
        apps: _apps
            .where(
              (LaunchableAppInfo app) =>
                  !_policy.rules.any(
                    (AppControlRule rule) =>
                        rule.packageName == app.packageName,
                  ) &&
                  !app.protected &&
                  !alwaysAllowed.contains(app.packageName),
            )
            .toList(growable: false),
      ),
    );
    if (selected == null || !mounted) return;
    final bool social = selected.suggestedReelsGuard ||
        _reelsPackages.contains(selected.packageName);
    final AppControlRule rule = AppControlRule(
      packageName: selected.packageName,
      label: selected.label,
      category: selected.category,
      enabled: true,
      blockApp: false,
      blockOutsideSchedule: false,
      dailyLimitMinutes: selected.suggestedDailyMinutes,
      reelsGuard: social,
      blockReelsImmediately: false,
      reelsDailyLimit: social ? 20 : 0,
      reelsTimeLimitMinutes: social ? 15 : 0,
      scrollLimit: 0,
    );
    final AppControlRule? edited =
        await Navigator.of(context).push<AppControlRule>(
      MaterialPageRoute<AppControlRule>(
        builder: (_) => _RuleEditorScreen(rule: rule),
      ),
    );
    if (edited != null && mounted) {
      _updatePolicy(
        _policy.upsertRule(edited).copyWith(
              masterEnabled: edited.hasRestriction || _policy.masterEnabled,
            ),
      );
    }
  }

  Future<void> _editRule(AppControlRule rule) async {
    final AppControlRule? edited =
        await Navigator.of(context).push<AppControlRule>(
      MaterialPageRoute<AppControlRule>(
        builder: (_) => _RuleEditorScreen(rule: rule),
      ),
    );
    if (edited != null && mounted) {
      _updatePolicy(
        _policy.upsertRule(edited).copyWith(
              masterEnabled: edited.hasRestriction || _policy.masterEnabled,
            ),
      );
    }
  }

  Future<void> _removeRule(AppControlRule rule) async {
    if (rule.commitmentActive) {
      final DateTime until = DateTime.fromMillisecondsSinceEpoch(
        rule.commitmentLockedUntilMillis,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'This commitment cannot be weakened before ${TimeOfDay.fromDateTime(until).format(context)}.',
          ),
        ),
      );
      return;
    }
    final bool? remove = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text('Remove ${rule.label}?'),
        content: const Text(
          'The app will no longer use schedule, daily-limit, Reels Guard or scroll-limit rules.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (remove == true) {
      _updatePolicy(_policy.removeRule(rule.packageName));
    }
  }

  Future<void> _editGlobalReelsWindow() async {
    final PhoneControlPolicy? updated =
        await Navigator.of(context).push<PhoneControlPolicy>(
      MaterialPageRoute<PhoneControlPolicy>(
        builder: (_) => _GlobalReelsWindowEditor(
          policy: _policy,
          apps: _apps
              .where((LaunchableAppInfo app) =>
                  !app.protected &&
                  (_reelsPackages.contains(app.packageName) ||
                      app.suggestedReelsGuard))
              .toList(growable: false),
        ),
      ),
    );
    if (updated != null && mounted) _updatePolicy(updated);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('App Rules & Limits'),
          actions: <Widget>[
            IconButton(
              tooltip: 'Refresh usage and permissions',
              onPressed: _refreshStatus,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  key: const ValueKey<String>('phone-control-scroll-view'),
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  children: <Widget>[
                    _OverviewCard(policy: _policy, usage: _usage),
                    const SizedBox(height: 12),
                    _SafeSetupCard(
                      policy: _policy,
                      apps: _apps,
                      busy: _saving,
                      onSafeSetup: _runSafeSetup,
                      onEmergencyStop: _emergencyStop,
                    ),
                    const SizedBox(height: 12),
                    _GlobalReelsWindowCard(
                      policy: _policy,
                      usage: _usage,
                      onTap: _editGlobalReelsWindow,
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.smart_display_rounded),
                        ),
                        title: const Text(
                          'Per-app Reels & Shorts limits',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: const Text(
                          'See how many were watched and set separate limits for each app.',
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const ReelsInsightsScreen(),
                            ),
                          );
                          if (mounted) await _load();
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.notifications_active_rounded),
                        ),
                        title: const Text(
                          'Detailed screen-time warnings',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: const Text(
                          '50%, 75%, 90% and over-goal reminders with full details.',
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const WellbeingAlertsScreen(),
                            ),
                          );
                          if (mounted) await _load();
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.calendar_month_rounded),
                        ),
                        title: const Text(
                          'Recurring Schedule Profiles',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: Text(
                          '${_policy.profiles.length} profiles • multiple apps per recurring schedule',
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const ScheduleProfilesScreen(),
                            ),
                          );
                          if (mounted) await _load();
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    _PermissionCard(readiness: _readiness),
                    const SizedBox(height: 22),
                    const SectionHeader(
                      title: 'Active features',
                      subtitle:
                          'Schedule apps, limit usage and stop distracting short-video loops.',
                    ),
                    const SizedBox(height: 10),
                    _FeaturePanel(
                      policy: _policy,
                      onChanged: _updatePolicy,
                    ),
                    const SizedBox(height: 22),
                    SectionHeader(
                      title: 'Controlled apps',
                      subtitle:
                          '${_policy.rules.where((AppControlRule rule) => rule.enabled && rule.blockApp).length} blocked • auto-allowed apps stay untouched',
                      action: IconButton.filledTonal(
                        tooltip: 'Add controlled app',
                        onPressed: _apps.isEmpty ? null : _addApp,
                        icon: const Icon(Icons.add_rounded),
                      ),
                    ),
                    const SizedBox(height: 10),
                    if (_policy.rules.isEmpty)
                      const EmptyState(
                        icon: Icons.phonelink_lock_rounded,
                        title: 'Everything is allowed',
                        message:
                            'Auto detection keeps essential apps safe. Tap + and choose only the app you want to block.',
                      )
                    else
                      ..._policy.rules.map(
                        (AppControlRule rule) => _RuleCard(
                          rule: rule,
                          usage: _usage,
                          scheduleEnabled: _policy.scheduleEnabled,
                          appLimitsEnabled: _policy.appLimitsEnabled,
                          reelsEnabled: _policy.reelsBlockerEnabled,
                          scrollEnabled: _policy.scrollLimitEnabled,
                          onToggle: (bool value) => _updatePolicy(
                            _policy.upsertRule(rule.copyWith(enabled: value)),
                          ),
                          onEdit: () => _editRule(rule),
                          onRemove: () => _removeRule(rule),
                        ),
                      ),
                    const SizedBox(height: 14),
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Icon(Icons.info_outline_rounded),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Safe mode never blocks Hredoy Flow, Home, Settings, Phone, keyboard, emergency, banking or authenticator apps. Auto detection only recommends apps; blocking happens after your choice.',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
        bottomNavigationBar: _loading
            ? null
            : SafeArea(
                minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          _dirty ? Icons.save_rounded : Icons.verified_rounded,
                        ),
                  label: Text(
                    _saving
                        ? 'Saving…'
                        : _dirty
                            ? 'Save selected blocks'
                            : 'Safe rules saved',
                  ),
                ),
              ),
      );
}

class _SafeSetupCard extends StatelessWidget {
  const _SafeSetupCard({
    required this.policy,
    required this.apps,
    required this.busy,
    required this.onSafeSetup,
    required this.onEmergencyStop,
  });

  final PhoneControlPolicy policy;
  final List<LaunchableAppInfo> apps;
  final bool busy;
  final VoidCallback onSafeSetup;
  final VoidCallback onEmergencyStop;

  @override
  Widget build(BuildContext context) {
    final int suggested =
        apps.where((LaunchableAppInfo app) => app.suggestedForReview).length;
    final int allowed =
        apps.where((LaunchableAppInfo app) => !app.suggestedForReview).length;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Icon(Icons.health_and_safety_rounded),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text(
                        'Auto Safe Setup',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text(
                        '$allowed auto-allowed • $suggested suggested to review',
                      ),
                    ],
                  ),
                ),
                Chip(
                  avatar: Icon(
                    policy.masterEnabled
                        ? Icons.shield_rounded
                        : Icons.pause_circle_rounded,
                    size: 18,
                  ),
                  label: Text(policy.masterEnabled ? 'ON' : 'SAFE'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              'The app scans installed apps and protects essential phone apps automatically. Nothing is blocked until you choose an app and save it.',
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                FilledButton.tonalIcon(
                  onPressed: busy ? null : onSafeSetup,
                  icon: const Icon(Icons.auto_fix_high_rounded),
                  label: const Text('Run safe setup'),
                ),
                OutlinedButton.icon(
                  onPressed: busy ? null : onEmergencyStop,
                  icon: const Icon(Icons.lock_open_rounded),
                  label: const Text('Stop all blocking'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  const _OverviewCard({required this.policy, required this.usage});

  final PhoneControlPolicy policy;
  final PhoneControlUsage usage;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            colors.primaryContainer,
            colors.surfaceContainerHighest,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              CircleAvatar(
                radius: 26,
                backgroundColor: colors.primary,
                foregroundColor: colors.onPrimary,
                child: const Icon(Icons.security_rounded, size: 29),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      policy.masterEnabled
                          ? 'Phone Control active'
                          : 'Phone Control paused',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                    Text(
                      '${policy.rules.where((AppControlRule rule) => rule.enabled && rule.blockApp).length} blocked by you • essential apps protected',
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: <Widget>[
              Expanded(
                child: _MiniMetric(
                  label: 'Screen time',
                  value: formatUsageDuration(usage.totalScreenTimeMillis),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MiniMetric(
                  label: 'Blocked today',
                  value: '${usage.totalBlockedAttempts}',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  const _MiniMetric({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(label, style: Theme.of(context).textTheme.labelMedium),
            const SizedBox(height: 3),
            Text(
              value,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ],
        ),
      );
}

class _PermissionCard extends StatelessWidget {
  const _PermissionCard({required this.readiness});

  final NativeSystemReadiness? readiness;

  @override
  Widget build(BuildContext context) {
    final bool accessibility = readiness?.accessibilityEnabled ?? false;
    final bool usage = readiness?.usageAccessEnabled ?? false;
    final bool battery = readiness?.batteryOptimizationIgnored ?? false;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: <Widget>[
            _PermissionRow(
              icon: Icons.accessibility_new_rounded,
              title: 'Accessibility App Blocker',
              ready: accessibility,
              onTap: NativeBridge.openAccessibilitySettings,
            ),
            const Divider(height: 18),
            _PermissionRow(
              icon: Icons.query_stats_rounded,
              title: 'Usage access for accurate limits',
              ready: usage,
              onTap: NativeBridge.openUsageAccessSettings,
            ),
            const Divider(height: 18),
            _PermissionRow(
              icon: Icons.battery_saver_rounded,
              title: 'Battery unrestricted',
              ready: battery,
              onTap: NativeBridge.requestBatteryOptimizationExemption,
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionRow extends StatelessWidget {
  const _PermissionRow({
    required this.icon,
    required this.title,
    required this.ready,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final bool ready;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Row(
        children: <Widget>[
          Icon(icon),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(
                  ready ? 'Ready' : 'Required',
                  style: TextStyle(
                    color: ready
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.error,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: onTap,
            child: Text(ready ? 'View' : 'Enable'),
          ),
        ],
      );
}

class _FeaturePanel extends StatelessWidget {
  const _FeaturePanel({required this.policy, required this.onChanged});

  final PhoneControlPolicy policy;
  final ValueChanged<PhoneControlPolicy> onChanged;

  @override
  Widget build(BuildContext context) => Card(
        child: Column(
          children: <Widget>[
            _FeatureSwitch(
              icon: Icons.shield_rounded,
              title: 'Master Phone Control',
              subtitle: 'Only your explicit block list can be enforced',
              value: policy.masterEnabled,
              onChanged: (bool value) =>
                  onChanged(policy.copyWith(masterEnabled: value)),
            ),
            const Divider(height: 1),
            _FeatureSwitch(
              icon: Icons.schedule_rounded,
              title: 'Schedule Blocker',
              subtitle: 'Apps open only inside their allowed time windows',
              value: policy.scheduleEnabled,
              onChanged: (bool value) =>
                  onChanged(policy.copyWith(scheduleEnabled: value)),
            ),
            const Divider(height: 1),
            _FeatureSwitch(
              icon: Icons.timer_outlined,
              title: 'Daily App Limits',
              subtitle: 'Block an app after its daily minutes are used',
              value: policy.appLimitsEnabled,
              onChanged: (bool value) =>
                  onChanged(policy.copyWith(appLimitsEnabled: value)),
            ),
            const Divider(height: 1),
            _FeatureSwitch(
              icon: Icons.smart_display_rounded,
              title: 'Reels & Shorts Guard',
              subtitle: 'Exit detected Reels, Shorts and short-video screens',
              value: policy.reelsBlockerEnabled,
              onChanged: (bool value) =>
                  onChanged(policy.copyWith(reelsBlockerEnabled: value)),
            ),
            const Divider(height: 1),
            _FeatureSwitch(
              icon: Icons.swap_vert_rounded,
              title: 'Scroll Limit',
              subtitle: 'Stop endless scrolling after the chosen gesture count',
              value: policy.scrollLimitEnabled,
              onChanged: (bool value) =>
                  onChanged(policy.copyWith(scrollLimitEnabled: value)),
            ),
          ],
        ),
      );
}

class _FeatureSwitch extends StatelessWidget {
  const _FeatureSwitch({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => SwitchListTile.adaptive(
        secondary: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        value: value,
        onChanged: onChanged,
      );
}

class _RuleCard extends StatelessWidget {
  const _RuleCard({
    required this.rule,
    required this.usage,
    required this.scheduleEnabled,
    required this.appLimitsEnabled,
    required this.reelsEnabled,
    required this.scrollEnabled,
    required this.onToggle,
    required this.onEdit,
    required this.onRemove,
  });

  final AppControlRule rule;
  final PhoneControlUsage usage;
  final bool scheduleEnabled;
  final bool appLimitsEnabled;
  final bool reelsEnabled;
  final bool scrollEnabled;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final int used = usage.usageMinutesFor(rule.packageName);
    final int scrolls = usage.scrollCountFor(rule.packageName);
    final int blocked = usage.blockedCountFor(rule.packageName);
    final int reelsViewed = usage.reelsViewedFor(rule.packageName);
    final int reelsMinutes = usage.reelsWatchMinutesFor(rule.packageName);
    final bool allowedNow = rule.isAllowedAt(DateTime.now());
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                _AppInitial(label: rule.label),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        rule.label,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text(
                        rule.packageName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Switch.adaptive(value: rule.enabled, onChanged: onToggle),
                PopupMenuButton<String>(
                  onSelected: (String value) {
                    if (value == 'edit') onEdit();
                    if (value == 'remove') onRemove();
                  },
                  itemBuilder: (_) => const <PopupMenuEntry<String>>[
                    PopupMenuItem<String>(
                        value: 'edit', child: Text('Edit rule')),
                    PopupMenuItem<String>(
                      value: 'remove',
                      child: Text('Remove app'),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: <Widget>[
                _RuleChip(
                  icon: rule.category == 'education'
                      ? Icons.school_rounded
                      : rule.category == 'social' ||
                              rule.category == 'video' ||
                              rule.category == 'game'
                          ? Icons.bolt_rounded
                          : Icons.apps_rounded,
                  label: rule.category == 'education'
                      ? 'Education'
                      : rule.category == 'social' ||
                              rule.category == 'video' ||
                              rule.category == 'game'
                          ? 'Distracting'
                          : 'Normal',
                ),
                if (rule.commitmentActive)
                  const _RuleChip(
                    icon: Icons.lock_clock_rounded,
                    label: 'Commitment active',
                  ),
                if (rule.blockApp)
                  const _RuleChip(
                    icon: Icons.block_rounded,
                    label: 'Blocked by you',
                  ),
                if (scheduleEnabled && rule.blockOutsideSchedule)
                  _RuleChip(
                    icon: allowedNow
                        ? Icons.lock_open_rounded
                        : Icons.lock_clock_rounded,
                    label: rule.scheduleLabel(),
                  ),
                if (appLimitsEnabled && rule.dailyLimitMinutes > 0)
                  _RuleChip(
                    icon: Icons.timer_rounded,
                    label: '$used/${rule.dailyLimitMinutes} min',
                  ),
                if (reelsEnabled && rule.reelsGuard)
                  _RuleChip(
                    icon: Icons.smart_display_rounded,
                    label: rule.blockReelsImmediately
                        ? 'Reels blocked'
                        : '${rule.reelsDailyLimit == 0 ? "∞" : reelsViewed}/${rule.reelsDailyLimit == 0 ? "∞" : rule.reelsDailyLimit} reels • ${rule.reelsTimeLimitMinutes == 0 ? "∞" : reelsMinutes}/${rule.reelsTimeLimitMinutes == 0 ? "∞" : rule.reelsTimeLimitMinutes} min',
                  ),
                if (scrollEnabled && rule.scrollLimit > 0)
                  _RuleChip(
                    icon: Icons.swap_vert_rounded,
                    label: '$scrolls/${rule.scrollLimit} scrolls',
                  ),
                if (blocked > 0)
                  _RuleChip(
                    icon: Icons.block_rounded,
                    label: '$blocked blocked',
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AppInitial extends StatelessWidget {
  const _AppInitial({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: 22,
        child: Text(
          label.trim().isEmpty
              ? '?'
              : label.trim().substring(0, 1).toUpperCase(),
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
      );
}

class _RuleChip extends StatelessWidget {
  const _RuleChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 16),
            const SizedBox(width: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _GlobalReelsWindowCard extends StatelessWidget {
  const _GlobalReelsWindowCard({
    required this.policy,
    required this.usage,
    required this.onTap,
  });

  final PhoneControlPolicy policy;
  final PhoneControlUsage usage;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool active = policy.globalReelsWindowActiveAt(DateTime.now());
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          child: Icon(
              active ? Icons.lock_clock_rounded : Icons.movie_filter_rounded),
        ),
        title: const Text(
          'Fixed Reels / Shorts budget',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(
          policy.globalReelsWindowEnabled
              ? '${usage.globalReelsWindowViewed}/${policy.globalReelsWindowLimit} viewed • ${active ? 'locked and active' : 'scheduled'}'
              : 'Set one count budget between exact start and end dates.',
        ),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}

class _GlobalReelsWindowEditor extends StatefulWidget {
  const _GlobalReelsWindowEditor({required this.policy, required this.apps});

  final PhoneControlPolicy policy;
  final List<LaunchableAppInfo> apps;

  @override
  State<_GlobalReelsWindowEditor> createState() =>
      _GlobalReelsWindowEditorState();
}

class _GlobalReelsWindowEditorState extends State<_GlobalReelsWindowEditor> {
  late bool _enabled;
  late DateTime _start;
  late DateTime _end;
  late int _limit;
  late Set<String> _packages;
  late bool _allApps;

  bool get _immutable =>
      widget.policy.globalReelsWindowLocked &&
      widget.policy.globalReelsWindowEndMillis >
          DateTime.now().millisecondsSinceEpoch;

  @override
  void initState() {
    super.initState();
    final DateTime now = DateTime.now();
    _enabled = widget.policy.globalReelsWindowEnabled;
    _start = widget.policy.globalReelsWindowStartMillis > 0
        ? DateTime.fromMillisecondsSinceEpoch(
            widget.policy.globalReelsWindowStartMillis,
          )
        : now.add(const Duration(minutes: 10));
    _end = widget.policy.globalReelsWindowEndMillis >
            widget.policy.globalReelsWindowStartMillis
        ? DateTime.fromMillisecondsSinceEpoch(
            widget.policy.globalReelsWindowEndMillis,
          )
        : now.add(const Duration(days: 2));
    _limit = widget.policy.globalReelsWindowLimit > 0
        ? widget.policy.globalReelsWindowLimit
        : 500;
    _packages = <String>{...widget.policy.globalReelsWindowPackages};
    _allApps = _packages.isEmpty;
  }

  Future<DateTime?> _pickDateTime(DateTime initial) async {
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date == null || !mounted) return null;
    final TimeOfDay? time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initial),
    );
    if (time == null) return null;
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  String _dateTimeLabel(DateTime value) =>
      '${value.day}/${value.month}/${value.year} • ${TimeOfDay.fromDateTime(value).format(context)}';

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Fixed Reels budget')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: <Widget>[
            Card(
              color: Theme.of(context).colorScheme.secondaryContainer,
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'Example: from 24 July 10:00 AM to 26 July 10:00 PM, allow 5,000 Reels across selected apps. Once active, the window cannot be weakened or edited.',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Enable fixed date-range budget'),
              value: _enabled,
              onChanged: _immutable
                  ? null
                  : (bool value) => setState(() => _enabled = value),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.play_circle_outline_rounded),
              title: const Text('Starts'),
              subtitle: Text(_dateTimeLabel(_start)),
              trailing: const Icon(Icons.edit_calendar_rounded),
              onTap: _immutable
                  ? null
                  : () async {
                      final DateTime? value = await _pickDateTime(_start);
                      if (value != null) setState(() => _start = value);
                    },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.stop_circle_outlined),
              title: const Text('Ends'),
              subtitle: Text(_dateTimeLabel(_end)),
              trailing: const Icon(Icons.edit_calendar_rounded),
              onTap: _immutable
                  ? null
                  : () async {
                      final DateTime? value = await _pickDateTime(_end);
                      if (value != null) setState(() => _end = value);
                    },
            ),
            const SizedBox(height: 8),
            _ExactLimitField(
              label: 'Total Reels / Shorts count',
              value: _limit,
              min: 1,
              max: 100000,
              step: 100,
              offLabel: 'Not allowed',
              enabled: !_immutable,
              onChanged: (int value) => setState(() => _limit = value),
            ),
            const SizedBox(height: 14),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('All supported short-video apps'),
              subtitle: const Text(
                  'Facebook, Instagram, YouTube, TikTok and detected equivalents.'),
              value: _allApps,
              onChanged: _immutable
                  ? null
                  : (bool value) => setState(() {
                        _allApps = value;
                        if (value) _packages.clear();
                      }),
            ),
            if (!_allApps) ...<Widget>[
              const SizedBox(height: 8),
              ...widget.apps.map(
                (LaunchableAppInfo app) => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _packages.contains(app.packageName),
                  title: Text(app.label),
                  subtitle: Text(app.packageName),
                  onChanged: _immutable
                      ? null
                      : (bool? value) => setState(() {
                            if (value ?? false) {
                              _packages.add(app.packageName);
                            } else {
                              _packages.remove(app.packageName);
                            }
                          }),
                ),
              ),
            ],
            if (_immutable)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    'This budget is already committed and cannot be changed until it ends.',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
          ],
        ),
        bottomNavigationBar: SafeArea(
          minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: FilledButton.icon(
            onPressed: _immutable ? null : _save,
            icon: const Icon(Icons.lock_clock_rounded),
            label: const Text('Save fixed budget'),
          ),
        ),
      );

  void _save() {
    if (_enabled && (!_end.isAfter(_start) || _limit <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choose a valid start, end and count.')),
      );
      return;
    }
    Navigator.of(context).pop(
      widget.policy.copyWith(
        globalReelsWindowEnabled: _enabled,
        globalReelsWindowStartMillis: _start.millisecondsSinceEpoch,
        globalReelsWindowEndMillis: _end.millisecondsSinceEpoch,
        globalReelsWindowLimit: _limit,
        globalReelsWindowPackages:
            _allApps ? const <String>{} : Set<String>.unmodifiable(_packages),
        globalReelsWindowLocked: _enabled,
        reelsBlockerEnabled: _enabled || widget.policy.reelsBlockerEnabled,
        masterEnabled: _enabled || widget.policy.masterEnabled,
      ),
    );
  }
}

class _AppPickerSheet extends StatefulWidget {
  const _AppPickerSheet({required this.apps});

  final List<LaunchableAppInfo> apps;

  @override
  State<_AppPickerSheet> createState() => _AppPickerSheetState();
}

class _AppPickerSheetState extends State<_AppPickerSheet> {
  String _query = '';
  String _group = 'distracting';

  @override
  Widget build(BuildContext context) {
    final String normalized = _query.trim().toLowerCase();
    final List<LaunchableAppInfo> filtered = widget.apps
        .where((LaunchableAppInfo app) {
      final bool query = normalized.isEmpty ||
          app.label.toLowerCase().contains(normalized) ||
          app.packageName.toLowerCase().contains(normalized);
      return query && app.matchesCategoryFilter(_group);
    }).toList(growable: false)
      ..sort((LaunchableAppInfo a, LaunchableAppInfo b) =>
          a.label.toLowerCase().compareTo(b.label.toLowerCase()));
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * 0.86,
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    'Choose an app to control',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    autofocus: true,
                    decoration: const InputDecoration(
                      labelText: 'Search installed apps',
                      prefixIcon: Icon(Icons.search_rounded),
                    ),
                    onChanged: (String value) => setState(() => _query = value),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: <Widget>[
                  for (final MapEntry<String, String> item
                      in const <String, String>{
                    'distracting': 'Distracting',
                    'social': 'Social',
                    'video': 'Video',
                    'game': 'Games',
                    'shopping': 'Shopping',
                    'education': 'Education',
                    'useful': 'Useful',
                    'normal': 'Normal / safe',
                    'all': 'All apps',
                  }.entries) ...<Widget>[
                    FilterChip(
                      label: Text(item.value),
                      selected: _group == item.key,
                      onSelected: (_) => setState(() => _group = item.key),
                    ),
                    const SizedBox(width: 7),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text('No matching launchable apps found.'))
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (BuildContext context, int index) {
                        final LaunchableAppInfo app = filtered[index];
                        return ListTile(
                          leading: _AppInitial(label: app.label),
                          title: Text(
                            app.label,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${app.categoryLabel} • ${app.reason}',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: const Icon(Icons.chevron_right_rounded),
                          onTap: () => Navigator.of(context).pop(app),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RuleEditorScreen extends StatefulWidget {
  const _RuleEditorScreen({required this.rule});

  final AppControlRule rule;

  @override
  State<_RuleEditorScreen> createState() => _RuleEditorScreenState();
}

class _RuleEditorScreenState extends State<_RuleEditorScreen> {
  late bool _enabled;
  late bool _blockApp;
  late bool _blockOutsideSchedule;
  late Set<int> _weekdays;
  late int _startMinute;
  late int _endMinute;
  late int _dailyLimit;
  late bool _reelsGuard;
  late bool _blockReelsImmediately;
  late int _reelsDailyLimit;
  late int _reelsTimeLimitMinutes;
  late Set<int> _reelsWarningPercentages;
  late int _scrollLimit;
  late int _commitmentPercent;

  @override
  void initState() {
    super.initState();
    _enabled = widget.rule.enabled;
    _blockApp = widget.rule.blockApp;
    _blockOutsideSchedule = widget.rule.blockOutsideSchedule;
    _weekdays = <int>{...widget.rule.allowedWeekdays};
    _startMinute = widget.rule.allowedStartMinute;
    _endMinute = widget.rule.allowedEndMinute;
    _dailyLimit = widget.rule.dailyLimitMinutes;
    _reelsGuard = widget.rule.reelsGuard;
    _blockReelsImmediately = widget.rule.blockReelsImmediately;
    _reelsDailyLimit = widget.rule.reelsDailyLimit;
    _reelsTimeLimitMinutes = widget.rule.reelsTimeLimitMinutes;
    _reelsWarningPercentages = <int>{...widget.rule.reelsWarningPercentages};
    _scrollLimit = widget.rule.scrollLimit;
    _commitmentPercent = widget.rule.commitmentPercent;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.rule.label)),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: <Widget>[
            Card(
              color: Theme.of(context).colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Icon(Icons.lock_clock_rounded),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        widget.rule.commitmentActive
                            ? 'Commitment active. This rule cannot be disabled, removed or weakened until the protected period ends.'
                            : 'When you save a restrictive rule, at least $_commitmentPercent% of its configured time becomes a non-removable commitment.',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Control this app'),
              subtitle:
                  const Text('Disable to keep the rule without enforcing it'),
              value: _enabled,
              onChanged: widget.rule.commitmentActive
                  ? null
                  : (bool value) => setState(() => _enabled = value),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Block this app'),
              subtitle: const Text(
                'Only this selected app is returned to Home. Essential phone apps remain allowed.',
              ),
              value: _blockApp,
              onChanged: widget.rule.commitmentActive
                  ? null
                  : (bool value) => setState(() => _blockApp = value),
            ),
            const SizedBox(height: 12),
            const SectionHeader(
              title: 'Allowed schedule',
              subtitle:
                  'Outside this window Hredoy Flow returns the phone to Home.',
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Block outside schedule'),
              value: _blockOutsideSchedule,
              onChanged: widget.rule.commitmentActive
                  ? null
                  : (bool value) =>
                      setState(() => _blockOutsideSchedule = value),
            ),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: List<Widget>.generate(7, (int index) {
                final int day = index + 1;
                const List<String> labels = <String>[
                  'Mon',
                  'Tue',
                  'Wed',
                  'Thu',
                  'Fri',
                  'Sat',
                  'Sun',
                ];
                return FilterChip(
                  label: Text(labels[index]),
                  selected: _weekdays.contains(day),
                  onSelected: widget.rule.commitmentActive
                      ? null
                      : (bool selected) {
                          setState(() {
                            if (selected) {
                              _weekdays.add(day);
                            } else if (_weekdays.length > 1) {
                              _weekdays.remove(day);
                            }
                          });
                        },
                );
              }),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.rule.commitmentActive
                        ? null
                        : () => _pickTime(start: true),
                    icon: const Icon(Icons.login_rounded),
                    label: Text('From ${formatMinuteOfDay(_startMinute)}'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.rule.commitmentActive
                        ? null
                        : () => _pickTime(start: false),
                    icon: const Icon(Icons.logout_rounded),
                    label: Text('Until ${formatMinuteOfDay(_endMinute)}'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            const SectionHeader(
              title: 'Daily app time',
              subtitle: 'Set an exact daily allowance for this app.',
            ),
            _ExactLimitField(
              label: 'Daily app minutes',
              value: _dailyLimit,
              min: 0,
              max: 1440,
              step: 5,
              offLabel: 'Unlimited',
              enabled: !widget.rule.commitmentActive,
              onChanged: (int value) => setState(() => _dailyLimit = value),
            ),
            const SizedBox(height: 22),
            const SectionHeader(
              title: 'Reels, Shorts & scrolling',
              subtitle:
                  'Choose immediate blocking or allow a daily count/time budget.',
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Reels & Shorts Guard'),
              subtitle: const Text(
                'Track supported short-video screens and enforce the limits below.',
              ),
              value: _reelsGuard,
              onChanged: widget.rule.commitmentActive
                  ? null
                  : (bool value) => setState(() => _reelsGuard = value),
            ),
            if (_reelsGuard) ...<Widget>[
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Block every Reel/Short immediately'),
                subtitle: const Text(
                  'When enabled, count and time allowances are ignored.',
                ),
                value: _blockReelsImmediately,
                onChanged: widget.rule.commitmentActive
                    ? null
                    : (bool value) =>
                        setState(() => _blockReelsImmediately = value),
              ),
              if (!_blockReelsImmediately) ...<Widget>[
                _ExactLimitField(
                  label: 'Daily short-video count',
                  value: _reelsDailyLimit,
                  min: 0,
                  max: 500,
                  step: 1,
                  offLabel: 'No count limit',
                  enabled: !widget.rule.commitmentActive,
                  onChanged: (int value) =>
                      setState(() => _reelsDailyLimit = value),
                ),
                const SizedBox(height: 12),
                _ExactLimitField(
                  label: 'Daily short-video minutes',
                  value: _reelsTimeLimitMinutes,
                  min: 0,
                  max: 240,
                  step: 5,
                  offLabel: 'No time limit',
                  enabled: !widget.rule.commitmentActive,
                  onChanged: (int value) =>
                      setState(() => _reelsTimeLimitMinutes = value),
                ),
                const SizedBox(height: 16),
                const SectionHeader(
                  title: 'Reels progress notifications',
                  subtitle:
                      'Send a detailed warning when this percentage of the count limit is reached.',
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <int>[25, 50, 75, 90, 100]
                      .map(
                        (int value) => FilterChip(
                          label: Text('$value%'),
                          selected: _reelsWarningPercentages.contains(value),
                          onSelected: widget.rule.commitmentActive
                              ? null
                              : (bool selected) {
                                  setState(() {
                                    if (selected) {
                                      _reelsWarningPercentages.add(value);
                                    } else if (_reelsWarningPercentages.length >
                                        1) {
                                      _reelsWarningPercentages.remove(value);
                                    }
                                  });
                                },
                        ),
                      )
                      .toList(growable: false),
                ),
              ],
            ],
            const SizedBox(height: 12),
            _ExactLimitField(
              label: 'Daily scroll gestures',
              value: _scrollLimit,
              min: 0,
              max: 2000,
              step: 10,
              offLabel: 'No scroll limit',
              enabled: !widget.rule.commitmentActive,
              onChanged: (int value) => setState(() => _scrollLimit = value),
            ),
            const SizedBox(height: 22),
            SectionHeader(
              title: 'Minimum commitment',
              subtitle:
                  'At least $_commitmentPercent% of the configured limit cannot be undone after saving.',
            ),
            Slider(
              value: _commitmentPercent.toDouble(),
              min: 20,
              max: 100,
              divisions: 8,
              label: '$_commitmentPercent%',
              onChanged: widget.rule.commitmentActive
                  ? null
                  : (double value) => setState(
                        () => _commitmentPercent = value.round(),
                      ),
            ),
          ],
        ),
        bottomNavigationBar: SafeArea(
          minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: FilledButton.icon(
            onPressed: widget.rule.commitmentActive ? null : _save,
            icon: const Icon(Icons.check_rounded),
            label: Text(
              widget.rule.commitmentActive
                  ? 'Rule locked until commitment ends'
                  : 'Save app rule',
            ),
          ),
        ),
      );

  Future<void> _pickTime({required bool start}) async {
    final int minute = start ? _startMinute : _endMinute;
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: minute ~/ 60, minute: minute % 60),
    );
    if (picked == null) return;
    setState(() {
      final int value = picked.hour * 60 + picked.minute;
      if (start) {
        _startMinute = value;
      } else {
        _endMinute = value;
      }
    });
  }

  void _save() {
    Navigator.of(context).pop(
      widget.rule.copyWith(
        enabled: _enabled,
        blockApp: _blockApp,
        blockOutsideSchedule: _blockOutsideSchedule,
        allowedWeekdays: Set<int>.unmodifiable(_weekdays),
        allowedStartMinute: _startMinute,
        allowedEndMinute: _endMinute,
        dailyLimitMinutes: _dailyLimit,
        reelsGuard: _reelsGuard,
        blockReelsImmediately: _blockReelsImmediately,
        reelsDailyLimit: _reelsDailyLimit,
        reelsTimeLimitMinutes: _reelsTimeLimitMinutes,
        reelsWarningPercentages: Set<int>.unmodifiable(
          _reelsWarningPercentages.isEmpty
              ? const <int>{50, 75, 90}
              : _reelsWarningPercentages,
        ),
        scrollLimit: _scrollLimit,
        commitmentPercent: _commitmentPercent,
      ),
    );
  }
}

class _ExactLimitField extends StatelessWidget {
  const _ExactLimitField({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.step,
    required this.offLabel,
    required this.onChanged,
    this.enabled = true,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final int step;
  final String offLabel;
  final ValueChanged<int> onChanged;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(label,
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                      Text(value == 0 ? offLabel : '$value per day'),
                    ],
                  ),
                ),
                SizedBox(
                  width: 92,
                  child: TextFormField(
                    key: ValueKey<String>('$label-$value'),
                    initialValue: value.toString(),
                    enabled: enabled,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      labelText: 'Exact',
                      isDense: true,
                    ),
                    onFieldSubmitted: enabled
                        ? (String raw) {
                            final int? parsed = int.tryParse(raw.trim());
                            if (parsed == null) return;
                            onChanged(parsed.clamp(min, max).toInt());
                          }
                        : null,
                  ),
                ),
              ],
            ),
            Slider(
              value: value.clamp(min, max).toDouble(),
              min: min.toDouble(),
              max: max.toDouble(),
              divisions: ((max - min) / step).round(),
              label: value == 0 ? offLabel : '$value',
              onChanged: enabled
                  ? (double next) {
                      final int snapped = ((next / step).round() * step)
                          .clamp(min, max)
                          .toInt();
                      onChanged(snapped);
                    }
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}
