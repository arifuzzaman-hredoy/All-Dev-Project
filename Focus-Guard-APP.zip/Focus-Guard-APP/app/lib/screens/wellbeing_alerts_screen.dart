import 'package:flutter/material.dart';

import '../models/phone_control.dart';
import '../services/native_bridge.dart';
import '../widgets/common_widgets.dart';

class WellbeingAlertsScreen extends StatefulWidget {
  const WellbeingAlertsScreen({super.key});

  @override
  State<WellbeingAlertsScreen> createState() => _WellbeingAlertsScreenState();
}

class _WellbeingAlertsScreenState extends State<WellbeingAlertsScreen> {
  PhoneControlPolicy _policy = const PhoneControlPolicy();
  PhoneControlUsage _usage = const PhoneControlUsage();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    PhoneControlPolicy policy = const PhoneControlPolicy();
    PhoneControlUsage usage = const PhoneControlUsage();
    try {
      policy = await NativeBridge.phoneControlPolicy();
    } catch (_) {}
    try {
      usage = await NativeBridge.phoneControlUsage();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _policy = policy;
      _usage = usage;
      _loading = false;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await NativeBridge.savePhoneControlPolicy(_policy);
      final PhoneControlPolicy saved = await NativeBridge.phoneControlPolicy();
      if (!mounted) return;
      setState(() => _policy = saved);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Detailed wellbeing warnings saved.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save warning settings: $error')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final int usedMinutes = _usage.totalScreenTimeMillis ~/ 60000;
    final int goal = _policy.screenTimeGoalMinutes;
    final int percent = goal <= 0 ? 0 : ((usedMinutes * 100) / goal).round();
    final List<int> thresholds = _policy.screenTimeWarningPercentages.toList()
      ..sort();
    return Scaffold(
      appBar: AppBar(title: const Text('Screen-time warnings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
              children: <Widget>[
                Card(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'Today’s screen-time status',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '$usedMinutes of $goal minutes • $percent%',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 10),
                        LinearProgressIndicator(
                          value: goal <= 0
                              ? 0
                              : (usedMinutes / goal).clamp(0.0, 1.0),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _usage.screenTimeSourceLabel,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Detailed wellbeing notifications'),
                  subtitle: const Text(
                    'Warn at selected screen-time and per-app Reels milestones.',
                  ),
                  value: _policy.wellbeingWarningsEnabled,
                  onChanged: (bool value) => setState(
                    () => _policy =
                        _policy.copyWith(wellbeingWarningsEnabled: value),
                  ),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Include full details and suggestions'),
                  subtitle: const Text(
                    'Large notifications include remaining time, the top controlled app and a recommended next step.',
                  ),
                  value: _policy.detailedWarningNotifications,
                  onChanged: _policy.wellbeingWarningsEnabled
                      ? (bool value) => setState(
                            () => _policy = _policy.copyWith(
                              detailedWarningNotifications: value,
                            ),
                          )
                      : null,
                ),
                const SizedBox(height: 16),
                const SectionHeader(
                  title: 'Daily screen-time goal',
                  subtitle:
                      'Notifications use this goal instead of applying a hard phone lock.',
                ),
                _NumberSlider(
                  label: 'Daily goal',
                  value: _policy.screenTimeGoalMinutes,
                  min: 30,
                  max: 720,
                  step: 15,
                  suffix: 'minutes',
                  enabled: _policy.wellbeingWarningsEnabled,
                  onChanged: (int value) => setState(
                    () => _policy =
                        _policy.copyWith(screenTimeGoalMinutes: value),
                  ),
                ),
                const SizedBox(height: 18),
                const SectionHeader(
                  title: 'Goal milestones',
                  subtitle:
                      'A large notification is sent once at each selected percentage.',
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <int>[25, 50, 75, 90, 100]
                      .map(
                        (int value) => FilterChip(
                          label: Text('$value%'),
                          selected: thresholds.contains(value),
                          onSelected: _policy.wellbeingWarningsEnabled
                              ? (bool selected) {
                                  final Set<int> next = <int>{
                                    ..._policy.screenTimeWarningPercentages,
                                  };
                                  if (selected) {
                                    next.add(value);
                                  } else if (next.length > 1) {
                                    next.remove(value);
                                  }
                                  setState(() {
                                    _policy = _policy.copyWith(
                                      screenTimeWarningPercentages:
                                          Set<int>.unmodifiable(next),
                                    );
                                  });
                                }
                              : null,
                        ),
                      )
                      .toList(growable: false),
                ),
                const SizedBox(height: 18),
                const SectionHeader(
                  title: 'Warnings after the goal',
                  subtitle:
                      'Once the goal is exceeded, send another detailed warning at this interval.',
                ),
                _NumberSlider(
                  label: 'Repeat warning',
                  value: _policy.screenTimeRepeatMinutes,
                  min: 15,
                  max: 240,
                  step: 15,
                  suffix: 'minutes over goal',
                  enabled: _policy.wellbeingWarningsEnabled,
                  onChanged: (int value) => setState(
                    () => _policy =
                        _policy.copyWith(screenTimeRepeatMinutes: value),
                  ),
                ),
                const SizedBox(height: 14),
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(Icons.notifications_active_rounded),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Reels warnings use each app’s own count limit and milestone choices. Open Reels & Shorts limits to configure Facebook, Instagram, YouTube or TikTok separately.',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving || _loading ? null : _save,
          icon: const Icon(Icons.save_rounded),
          label: Text(_saving ? 'Saving…' : 'Save warning settings'),
        ),
      ),
    );
  }
}

class _NumberSlider extends StatelessWidget {
  const _NumberSlider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.step,
    required this.suffix,
    required this.enabled,
    required this.onChanged,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final int step;
  final String suffix;
  final bool enabled;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
              Text('$value $suffix'),
              Slider(
                value: value.clamp(min, max).toDouble(),
                min: min.toDouble(),
                max: max.toDouble(),
                divisions: ((max - min) / step).round(),
                label: '$value',
                onChanged: enabled
                    ? (double raw) {
                        final int snapped = ((raw / step).round() * step)
                            .clamp(min, max)
                            .toInt();
                        onChanged(snapped);
                      }
                    : null,
              ),
            ],
          ),
        ),
      );
}
