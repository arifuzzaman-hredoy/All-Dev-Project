import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';

class HabitManagerScreen extends StatelessWidget {
  const HabitManagerScreen({super.key});

  static const List<Color> _colors = <Color>[
    Color(0xFF4F7CFF),
    Color(0xFFFFA62B),
    Color(0xFFB15CFF),
    Color(0xFF18B6A4),
    Color(0xFFE35768),
    Color(0xFF55B84D),
  ];

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final DateTime today = dateOnly(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: const Text('Habits')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context, controller, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add habit'),
      ),
      body: controller.data.habits.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: EmptyState(
                icon: Icons.repeat_rounded,
                title: 'No habits yet',
                message:
                    'Create sleep, food, revision or personal-boundary habits.',
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: controller.data.habits.map((HabitItem habit) {
                return Card(
                  child: ListTile(
                    onTap: () => controller.toggleHabit(habit, today),
                    leading: CircleAvatar(
                      backgroundColor: habit.color.withValues(alpha: 0.15),
                      child: Icon(habit.icon, color: habit.color),
                    ),
                    title: Text(
                      habit.title,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        decoration:
                            habit.active ? null : TextDecoration.lineThrough,
                      ),
                    ),
                    subtitle: Text(
                      '${habit.completedDateKeys.length} total checks • ${habit.weekdays.length} days/week',
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Checkbox.adaptive(
                          value: habit.isDone(today),
                          onChanged: (_) =>
                              controller.toggleHabit(habit, today),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (String action) {
                            if (action == 'edit') {
                              _edit(context, controller, habit);
                            } else if (action == 'active') {
                              controller.updateHabit(
                                habit.copyWith(active: !habit.active),
                              );
                            } else if (action == 'delete') {
                              _deleteHabit(context, controller, habit);
                            }
                          },
                          itemBuilder: (_) => <PopupMenuEntry<String>>[
                            const PopupMenuItem<String>(
                              value: 'edit',
                              child: Text('Edit'),
                            ),
                            PopupMenuItem<String>(
                              value: 'active',
                              child: Text(
                                habit.active ? 'Pause habit' : 'Activate habit',
                              ),
                            ),
                            const PopupMenuItem<String>(
                              value: 'delete',
                              child: Text('Delete permanently'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
    );
  }

  Future<void> _edit(
    BuildContext context,
    AppController controller,
    HabitItem? habit,
  ) async {
    String titleText = habit?.title ?? '';
    Color color = habit?.color ?? _colors.first;
    IconData icon = habit?.icon ?? Icons.check_circle_rounded;
    Set<int> weekdays = (habit?.weekdays ?? <int>[1, 2, 3, 4, 5, 6, 7]).toSet();
    const List<IconData> icons = <IconData>[
      Icons.bedtime_rounded,
      Icons.restaurant_rounded,
      Icons.psychology_rounded,
      Icons.shield_rounded,
      Icons.water_drop_rounded,
      Icons.fitness_center_rounded,
      Icons.menu_book_rounded,
      Icons.check_circle_rounded,
    ];

    final bool? save = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setDialogState) =>
            AlertDialog(
          title: Text(habit == null ? 'Add habit' : 'Edit habit'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextFormField(
                  initialValue: titleText,
                  decoration: const InputDecoration(
                    labelText: 'Habit title',
                  ),
                  onChanged: (String value) => titleText = value,
                ),
                const SizedBox(height: 14),
                const Text('Weekdays'),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  children: List<Widget>.generate(7, (int index) {
                    final int day = index + 1;
                    return FilterChip(
                      label: Text(
                        const <String>[
                          'M',
                          'T',
                          'W',
                          'T',
                          'F',
                          'S',
                          'S',
                        ][index],
                      ),
                      selected: weekdays.contains(day),
                      onSelected: (bool selected) {
                        setDialogState(() {
                          if (selected) {
                            weekdays.add(day);
                          } else {
                            weekdays.remove(day);
                          }
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _colors.map((Color item) {
                    return InkWell(
                      onTap: () => setDialogState(() => color = item),
                      child: CircleAvatar(
                        backgroundColor: item,
                        child: color.toARGB32() == item.toARGB32()
                            ? const Icon(
                                Icons.check_rounded,
                                color: Colors.white,
                              )
                            : null,
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: icons.map((IconData item) {
                    return ChoiceChip(
                      avatar: Icon(item, size: 18),
                      label: const Text(''),
                      selected: icon.codePoint == item.codePoint,
                      onSelected: (_) => setDialogState(() => icon = item),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    final String value = titleText.trim();
    if (save != true || value.isEmpty || weekdays.isEmpty) {
      return;
    }
    if (habit == null) {
      await controller.addHabit(
        HabitItem(
          id: newId('habit'),
          title: value,
          colorValue: color.toARGB32(),
          iconCodePoint: icon.codePoint,
          weekdays: weekdays.toList()..sort(),
          completedDateKeys: const <String>[],
          createdAt: DateTime.now(),
        ),
      );
    } else {
      await controller.updateHabit(
        habit.copyWith(
          title: value,
          colorValue: color.toARGB32(),
          iconCodePoint: icon.codePoint,
          weekdays: weekdays.toList()..sort(),
        ),
      );
    }
  }

  Future<void> _deleteHabit(
    BuildContext context,
    AppController controller,
    HabitItem habit,
  ) async {
    final bool confirmed = await confirmAction(
      context,
      title: 'Delete this habit permanently?',
      message: 'Habit history for this item will also be removed.',
      confirmLabel: 'Delete habit',
    );
    if (confirmed) {
      await controller.deleteHabit(habit.id);
    }
  }
}
