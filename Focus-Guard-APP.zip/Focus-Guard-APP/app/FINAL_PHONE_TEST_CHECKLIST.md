# Hredoy Flow 4.6.3 Phone Test Checklist

Keep the emergency ADB script ready and test one harmless application first.

## Safe start

- Accessibility initially off during installation.
- Master Phone Control off or contains only explicit user rules.
- Hredoy Flow, Home, Settings, Phone, keyboard, camera, clock and payment apps remain usable.

## Per-app Reels dashboard

- Open **Reels & Shorts limits**.
- Confirm supported installed apps are listed separately.
- Confirm the dashboard says **Hybrid confirmed-count mode** and shows **Confirmed Reels**.
- Give one app a small count limit, note the starting count, then change exactly 10 full-screen Reels slowly.
- Confirm the count increases by roughly 10 and never jumps by dozens from one swipe.
- Scroll comments/captions and confirm the count does not increase.
- Confirm counting still advances when the app hides creator/caption identity, and confirm watch minutes also update.
- Confirm the rest of the app remains usable when only Reels/Shorts are blocked.

## Notifications

- Configure a small test count with 50% and 75% milestones.
- Confirm each milestone sends one large detailed notification.
- Set a temporary low screen-time goal and confirm milestone and over-goal repeat warnings.
- Restore normal limits after the test.

## Focus Forest

- Run a two-minute Focus session.
- Confirm the animated forest card renders without overflow or jank.
- Confirm progress/level still follows existing Focus and Study Quest data.

## 216 alarm sounds

- Search and preview `tone_017`, a middle tone and `tone_216`.
- Select a generated sound for a two-minute alarm.
- Confirm the selected sound plays in the full-screen alarm path.
- Confirm old selected sounds, phone tones and custom audio remain usable.

## Final automation

Run:

```powershell
.\FINAL_VERIFY_ON_PHONE.ps1 -SkipQA -SkipInstall -RequirePermissions
```
