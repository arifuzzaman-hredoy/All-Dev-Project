param(
    [string]$DeviceId = "R38M800T0HD",
    [switch]$SkipQA,
    [int]$LaunchPasses = 3,
    [int]$MaxLaunchMilliseconds = 5000
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidSdk = "G:\Android\Sdk"
$FlutterSdk = "G:\sdk\flutter"
$ToolTemp = Join-Path $PSScriptRoot ".flutter-tool-temp"
$PackageId = "com.hredoy.focus_guard_flutter"
$Activity = "$PackageId/.MainActivity"
$LogFile = Join-Path $PSScriptRoot "phone-smoke-test.log"
$ReportFile = Join-Path $PSScriptRoot "phone-performance-report.txt"

New-Item -ItemType Directory -Force -Path $ToolTemp | Out-Null
$env:ANDROID_HOME = $AndroidSdk
$env:ANDROID_SDK_ROOT = $AndroidSdk
$env:GRADLE_USER_HOME = "G:\GradleCache"
$env:PUB_CACHE = "G:\PubCache"
$env:TEMP = $ToolTemp
$env:TMP = $ToolTemp
$env:FLUTTER_SUPPRESS_ANALYTICS = "true"
$env:Path = "$FlutterSdk\bin;$AndroidSdk\platform-tools;$AndroidSdk\cmdline-tools\latest\bin;$env:Path"

if (-not $SkipQA) {
    & "$PSScriptRoot\QA.ps1"
    if ($LASTEXITCODE -ne 0) { throw "Project QA failed." }
}

adb start-server
if ($LASTEXITCODE -ne 0) { throw "ADB server could not start." }

$DeviceReady = $false
for ($Attempt = 1; $Attempt -le 15; $Attempt += 1) {
    $DeviceOutput = adb devices -l | Out-String
    Write-Host $DeviceOutput
    if ($DeviceOutput -match "(?m)^$([regex]::Escape($DeviceId))\s+device\b") {
        $DeviceReady = $true
        break
    }
    Write-Host "Waiting for device authorization ($Attempt/15)..." -ForegroundColor Yellow
    Start-Sleep -Seconds 2
}
if (-not $DeviceReady) {
    throw "Device $DeviceId was not detected. Unlock the phone, enable USB debugging, reconnect USB, and approve this computer."
}

$ProfileApk = Join-Path $PSScriptRoot "build\app\outputs\flutter-apk\app-profile.apk"
if (-not (Test-Path $ProfileApk)) {
    flutter build apk --profile --no-pub
    if ($LASTEXITCODE -ne 0) { throw "Profile APK build failed." }
}

adb -s $DeviceId install -r -t $ProfileApk
if ($LASTEXITCODE -ne 0) { throw "Profile APK installation failed." }

$PackageDump = adb -s $DeviceId shell dumpsys package $PackageId | Out-String
$VersionMatch = [regex]::Match($PackageDump, "(?m)versionName=([^\s]+)")
if (-not $VersionMatch.Success) {
    throw "Installed package version could not be verified."
}
$InstalledVersion = $VersionMatch.Groups[1].Value
if ($InstalledVersion -ne "4.6.3") {
    throw "Expected Hredoy Flow 4.6.3, but installed version is $InstalledVersion."
}

$FatalPatterns = @(
    "FATAL EXCEPTION",
    "E/flutter",
    "Another exception was thrown",
    "Failed assertion",
    "Duplicate GlobalKeys",
    "RenderFlex overflowed",
    "used after being disposed",
    "ForegroundServiceStartNotAllowedException",
    "Unable to start service",
    "SecurityException",
    "ANR in $PackageId"
)

$AllLogs = New-Object System.Collections.Generic.List[string]
$LaunchTimes = New-Object System.Collections.Generic.List[int]

# The first launch after an APK install can include Android package/dex setup.
# Warm it once, scan that launch for crashes, then measure stable cold-process
# launches so the speed gate reflects the application rather than installer work.
Write-Host "Phone warm-up launch" -ForegroundColor Cyan
adb -s $DeviceId shell am force-stop $PackageId | Out-Null
adb -s $DeviceId logcat -c | Out-Null
Start-Sleep -Milliseconds 500
$WarmupOutput = adb -s $DeviceId shell am start -W -n $Activity | Out-String
if ($LASTEXITCODE -ne 0) { throw "Application warm-up launch failed." }
Write-Host $WarmupOutput
Start-Sleep -Seconds 4
$WarmupPid = (adb -s $DeviceId shell pidof -s $PackageId | Out-String).Trim()
if ([string]::IsNullOrWhiteSpace($WarmupPid)) {
    throw "The app process stopped during the warm-up launch."
}
$WarmupLogs = adb -s $DeviceId logcat --pid=$WarmupPid -d -v brief | Out-String
$AllLogs.Add("===== WARM-UP | PID $WarmupPid =====`r`n$WarmupLogs")
$WarmupFailures = foreach ($Pattern in $FatalPatterns) {
    $WarmupLogs | Select-String -SimpleMatch $Pattern
}
if ($WarmupFailures) {
    $AllLogs -join "`r`n" | Set-Content -LiteralPath $LogFile -Encoding utf8
    $WarmupFailures | ForEach-Object { Write-Host $_.Line -ForegroundColor Red }
    throw "Phone warm-up found a runtime error. Full log: $LogFile"
}

for ($Pass = 1; $Pass -le $LaunchPasses; $Pass += 1) {
    Write-Host "Phone launch pass $Pass/$LaunchPasses" -ForegroundColor Cyan
    adb -s $DeviceId shell am force-stop $PackageId | Out-Null
    adb -s $DeviceId logcat -c | Out-Null
    Start-Sleep -Milliseconds 500

    $LaunchOutput = adb -s $DeviceId shell am start -W -n $Activity | Out-String
    if ($LASTEXITCODE -ne 0) { throw "Application launch pass $Pass failed." }
    Write-Host $LaunchOutput

    $TotalTimeMatch = [regex]::Match($LaunchOutput, "(?m)^TotalTime:\s*(\d+)")
    if ($TotalTimeMatch.Success) {
        $LaunchMilliseconds = [int]$TotalTimeMatch.Groups[1].Value
        $LaunchTimes.Add($LaunchMilliseconds)
        if ($LaunchMilliseconds -gt $MaxLaunchMilliseconds) {
            throw "Profile launch pass $Pass took ${LaunchMilliseconds}ms, above the ${MaxLaunchMilliseconds}ms gate."
        }
    }

    Start-Sleep -Seconds 4
    $PidText = (adb -s $DeviceId shell pidof -s $PackageId | Out-String).Trim()
    if ([string]::IsNullOrWhiteSpace($PidText)) {
        throw "The app process stopped during launch pass $Pass."
    }

    $Logs = adb -s $DeviceId logcat --pid=$PidText -d -v brief | Out-String
    $AllLogs.Add("===== PASS $Pass | PID $PidText =====`r`n$Logs")

    $Failures = foreach ($Pattern in $FatalPatterns) {
        $Logs | Select-String -SimpleMatch $Pattern
    }
    if ($Failures) {
        $AllLogs -join "`r`n" | Set-Content -LiteralPath $LogFile -Encoding utf8
        $Failures | ForEach-Object { Write-Host $_.Line -ForegroundColor Red }
        throw "Phone smoke test found a runtime error. Full log: $LogFile"
    }
}

$CombinedLogs = $AllLogs -join "`r`n"
$CombinedLogs | Set-Content -LiteralPath $LogFile -Encoding utf8
$BlockLoopCount = ([regex]::Matches($CombinedLogs, "FocusAccessibilityService\.performBlock")).Count
if ($BlockLoopCount -gt 2) {
    throw "Accessibility block-loop guard failed: performBlock appeared $BlockLoopCount times during safe startup. Full log: $LogFile"
}

$Memory = adb -s $DeviceId shell dumpsys meminfo $PackageId | Out-String
$AverageLaunch = if ($LaunchTimes.Count -gt 0) {
    [math]::Round(($LaunchTimes | Measure-Object -Average).Average)
} else {
    -1
}
$MaximumLaunch = if ($LaunchTimes.Count -gt 0) {
    ($LaunchTimes | Measure-Object -Maximum).Maximum
} else {
    -1
}

$AccessibilityServices = (adb -s $DeviceId shell settings get secure enabled_accessibility_services | Out-String).Trim()
$NotificationListeners = (adb -s $DeviceId shell settings get secure enabled_notification_listeners | Out-String).Trim()
$BatteryWhitelist = adb -s $DeviceId shell dumpsys deviceidle whitelist | Out-String
$ExactAlarmAppOp = adb -s $DeviceId shell cmd appops get $PackageId SCHEDULE_EXACT_ALARM 2>&1 | Out-String
$NotificationAppOp = adb -s $DeviceId shell cmd appops get $PackageId POST_NOTIFICATION 2>&1 | Out-String
$UsageStatsAppOp = adb -s $DeviceId shell cmd appops get $PackageId GET_USAGE_STATS 2>&1 | Out-String
$AccessibilityReady = $AccessibilityServices -match [regex]::Escape("$PackageId/.FocusAccessibilityService") -or
    $AccessibilityServices -match [regex]::Escape("$PackageId/com.hredoy.focus_guard_flutter.FocusAccessibilityService")
$BatteryReady = $BatteryWhitelist -match [regex]::Escape($PackageId)
$UsageAccessReady = $UsageStatsAppOp -match "allow"
$NotificationAccessReady = $NotificationListeners -match [regex]::Escape("$PackageId/.NotificationControlService") -or
    $NotificationListeners -match [regex]::Escape("$PackageId/com.hredoy.focus_guard_flutter.NotificationControlService")
$ServiceDump = adb -s $DeviceId shell dumpsys activity services $PackageId | Out-String
$ProtectionVpnRunning = $ServiceDump -match "ProtectionVpnService"

@"
Hredoy Flow 4.6.3 production phone profile test
Device: $DeviceId
Installed version: $InstalledVersion
Warm-up launch: completed and fatal-log scanned
Measured launch passes: $LaunchPasses
Launch times (ms): $($LaunchTimes -join ', ')
Average launch (ms): $AverageLaunch
Maximum launch (ms): $MaximumLaunch
Maximum allowed (ms): $MaxLaunchMilliseconds
Accessibility blocker detected: $AccessibilityReady
Battery whitelist detected: $BatteryReady
Usage access detected: $UsageAccessReady
Notification listener detected: $NotificationAccessReady
Protection VPN service detected: $ProtectionVpnRunning
Accessibility performBlock startup count: $BlockLoopCount
Exact-alarm app-op:
$ExactAlarmAppOp
Notification app-op:
$NotificationAppOp
Usage-stats app-op:
$UsageStatsAppOp

Memory report:
$Memory
"@ | Set-Content -LiteralPath $ReportFile -Encoding utf8

Write-Host "Phone smoke and launch-performance test passed in PROFILE mode." -ForegroundColor Green
Write-Host "Launch times: $($LaunchTimes -join ', ') ms" -ForegroundColor Green
Write-Host "Runtime log: $LogFile" -ForegroundColor Green
Write-Host "Performance report: $ReportFile" -ForegroundColor Green
if (-not $AccessibilityReady) {
    Write-Host "Accessibility App Blocker is not enabled yet: More > Phone Control Center > Accessibility App Blocker." -ForegroundColor Yellow
}
if (-not $BatteryReady) {
    Write-Host "Battery unrestricted status was not detected. Open More > Phone Control Center > Battery unrestricted." -ForegroundColor Yellow
}
if (-not $UsageAccessReady) {
    Write-Host "Usage access is not enabled yet: More > Phone Control Center > Usage access for accurate limits." -ForegroundColor Yellow
}
if (-not $NotificationAccessReady) {
    Write-Host "Notification Access is not enabled yet: More > Social & Notifications > Enable." -ForegroundColor Yellow
}
Write-Host "Next: .\FINAL_VERIFY_ON_PHONE.ps1 -SkipQA -SkipInstall" -ForegroundColor Cyan
Write-Host "Manual production checks: first confirm Auto Safe Setup shows zero manually blocked apps and essential apps are unavailable in the picker; verify Today shows Current action and every full-picture slider; confirm Phone Control screen time says 12:00 AM to now; select one harmless app and set exact app minutes, Reel count, Reel minutes and scroll limits; verify the Social & Notifications header and quiet-time history; test Study Mode, the preserved 26 July routine and a 2-minute Focus Tree session; then approve the Protection Center VPN and test one blocked domain, Prime Mode, Keep Me Out, emergency unlock and history." -ForegroundColor Cyan
