# Hredoy Flow 4.6.3 Feature Matrix

| Area | Implemented behavior | Automated/source coverage | Physical-phone check |
|---|---|---|---|
| Daily Coach | Current action, top three priorities, completion, focus minutes, streak and safe shortcuts | Smart Flow model tests and QA source contracts | Open with active/upcoming tasks and verify the ordering |
| Simple Mode | Chosen shortcuts first; one expandable Advanced tools section | Safe default and settings round-trip tests | Toggle shortcuts and reopen More |
| Advanced Mode | Complete management surface shown directly | Mode persistence test and navigation source guards | Switch modes and confirm no data changes |
| Rule activation preview | Exact direct rules, schedules, Study/Focus state and protected-app totals before Phone Control save | Preview source contracts and Phone Control save guard | Create one harmless draft rule, review, cancel, then confirm |
| Always-allowed apps | Removes selected apps from app rules, schedules, Study, notifications, fixed Reels, Prime and Keep Me Out | Pure sanitizer tests for Phone and Protection policies | Add one personal safety app and confirm every picker excludes it |
| Smart Recommendations | Local categories and suggested review list; never auto-blocks | Classifier tests plus recommendation-only source guards | Refresh list and confirm zero automatic rules |
| One-tap safety stop | Stops active blocking without deleting planner data or saved rules | Native emergency-stop guards and Safety Center source checks | Start one harmless block, stop all, verify phone immediately usable |
| Weekly Flow Report | Seven-day task/focus metrics, productive days, average and best day | Share-text and existing controller-index tests | Compare report with Insights for the same dates |
| Simplified navigation | New features use More, drawer, Search, Insights and Phone dashboard; root tabs remain six | Root/sidebar regression tests and stable keys | Navigate every Simple shortcut and Advanced expansion |
| Responsive Protection Center | Picker and Emergency Unlock remain horizontal and bounded | Narrow-phone widget regression | Recheck the previously broken screenshots at current text scale |
| Per-app control | Manual block, schedules, daily minutes, Reels count/time and scroll limits | Dart/native model, engine and persistence tests | Limit one harmless app and confirm only it is affected |
| Per-app Reels dashboard | Supported installed apps show viewed count, watch minutes, blocked attempts, remaining allowance and saved warning milestones | Dart model round-trip, source contracts and native wellbeing tests | Open Facebook/Instagram/YouTube/TikTok Reels or Shorts, then refresh counts |
| Reels progress notifications | Per-app 25%, 50%, 75%, 90% and 100% selectable milestones based on that app's configured count limit | Native warning-marker, notification and model tests | Use a small test limit and confirm milestone notifications arrive once per day |
| Screen-time wellbeing alerts | Configurable daily goal, milestone warnings, detailed BigText status and repeated over-goal reminders | Dart/native persistence tests and notification source guards | Set a small test goal and verify used/remaining/top-app details |
| Study/Focus automation | Selected apps block only inside configured window; Focus can reuse rules | Same-day/overnight Dart and Kotlin tests | Test a two-minute schedule and automatic restore |
| Reels controls | Per-app Reels-only control and committed fixed date-range budget | Accessibility route and global budget tests | Test supported normal page versus Reels/Shorts route |
| Focus Forest | Animated sky, mountains, background forest, growing main tree, meadow, flowers, pond, path, birds and fireflies | Focus-tree source contracts plus existing Focus/Study tests | Run a short Focus session and confirm progress/level growth |
| Alarm sound library | 216 real bundled WAV alarm sounds with search, groups and preview; Smart, phone tones and custom audio remain | Exact file count, RIFF/WAVE header, unique SHA-256 and catalog tests | Search `tone_216`, preview multiple groups and trigger a two-minute alarm |
| Alarm templates | 216 ready-made alarm/routine templates remain separate from the 216 sound library | Catalog-count tests | Create a task from one template and choose a bundled sound |
| Full-screen alarms | Dedicated full-screen Activity attempt with notification fallback | Native source guards and Android build | Trigger a two-minute alarm over another app and from the lock screen |
| User data | Existing routine/tasks/goals/alarms/profile/XP remain compatible | Critical SHA continuity and storage tests | Reopen after update and reboot |

## Safety invariants

- App classification, coaching and wellbeing warnings never create or tighten a blocking rule by themselves.
- Rule preview is enabled by default.
- Hredoy Flow and native essential packages remain protected.
- User-selected always-allowed packages are sanitized through one shared pure function before policy persistence.
- Study/Focus/Prime/Keep Me Out affect only explicit selected package lists.
- `STOP ALL BLOCKING` and `EMERGENCY_UNLOCK_PHONE.ps1` preserve local personal data.
- Smart Flow settings live in a separate JSON file and do not alter the existing planner schema.
- Reels and screen-time warning markers reset at local midnight; warnings do not hard-lock the whole phone.

## Platform limits

- Reels/Shorts detection depends on third-party Accessibility route signals and may require maintenance after app UI updates.
- Counts are best-effort and begin only while Accessibility is enabled and a supported short-video route is detected.
- Android can suppress or delay notifications when notification permission, channel settings, battery policy or OEM background restrictions are changed.
- DNS protection cannot inspect encrypted HTTPS page bodies or images.
- Anti-bypass enforcement is best-effort Accessibility protection, not Device Owner/MDM or root.
- Bundling 216 real WAV files increases the source and APK size compared with the previous 16-sound build.

## Transparency

- **Web and DNS protection:** DNS-only filtering cannot inspect encrypted HTTPS page bodies or images.
- **Commitment protection:** best-effort Accessibility enforcement, not Device Owner/MDM or root.
- **AI NSFW image classification is intentionally not included.**

## Hybrid snapshot-and-pager Reels counter (v4.6.3)

- Raw Accessibility callbacks never increment counts.
- Route-confirmed full-screen pager callbacks only create a delayed candidate.
- Callback bursts within 700 ms are merged into one candidate token.
- Comments, replies, captions, sheets and small nested scroll containers are rejected.
- Two stable creator/caption fingerprints are preferred when available.
- Hidden or static identity can use one guarded pager fallback after settling.
- The initial detected Reel can count after the dwell guard without identity text.
- Duplicate candidate tokens and minimum transition gaps suppress repeat counts.
- Privacy: raw screen text is processed in memory and is not persisted.
- Watch-time limits remain an enforcement fallback because Android has no official per-Reel API.
