param(
    [string]$Alias = "hredoy_flow",
    [switch]$Force
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AndroidDir = Join-Path $PSScriptRoot "android"
$PropertiesFile = Join-Path $AndroidDir "release-signing.properties"
$KeystoreFile = Join-Path $AndroidDir "hredoy-flow-release.jks"

if (((Test-Path -LiteralPath $PropertiesFile) -or (Test-Path -LiteralPath $KeystoreFile)) -and -not $Force) {
    throw "Release signing already exists. Keep the existing key safe or rerun with -Force only when intentionally replacing it."
}

$Keytool = (Get-Command keytool.exe -ErrorAction SilentlyContinue).Source
if ([string]::IsNullOrWhiteSpace($Keytool)) {
    $JavaHome = $env:JAVA_HOME
    if ([string]::IsNullOrWhiteSpace($JavaHome)) {
        $JavaHome = "E:\Android Studio\jbr"
    }
    $Candidate = Join-Path $JavaHome "bin\keytool.exe"
    if (Test-Path -LiteralPath $Candidate) {
        $Keytool = $Candidate
    }
}
if ([string]::IsNullOrWhiteSpace($Keytool) -or -not (Test-Path -LiteralPath $Keytool)) {
    throw "keytool.exe was not found. Set JAVA_HOME or install Android Studio/JDK."
}

function ConvertTo-PlainText {
    param([Parameter(Mandatory = $true)][Security.SecureString]$SecureValue)
    $Pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Pointer)
    }
}

$SecurePassword = Read-Host "Create a release-key password (8-128 characters: letters, numbers, @ . _ -)" -AsSecureString
$Password = ConvertTo-PlainText $SecurePassword
if ($Password -notmatch '^[A-Za-z0-9@._-]{8,128}$') {
    throw "Use 8-128 characters containing only letters, numbers, @, dot, underscore or hyphen. This keeps Java properties parsing deterministic."
}

New-Item -ItemType Directory -Path $AndroidDir -Force | Out-Null
Remove-Item -LiteralPath $KeystoreFile,$PropertiesFile -Force -ErrorAction SilentlyContinue

& $Keytool `
    -genkeypair `
    -v `
    -keystore $KeystoreFile `
    -storetype PKCS12 `
    -storepass $Password `
    -keypass $Password `
    -alias $Alias `
    -keyalg RSA `
    -keysize 4096 `
    -validity 10000 `
    -dname "CN=Hredoy Flow, OU=Mobile, O=Hredoy Flow, C=BD"

if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $KeystoreFile)) {
    throw "Release keystore creation failed."
}

$Properties = @(
    "storeFile=hredoy-flow-release.jks",
    "storePassword=$Password",
    "keyAlias=$Alias",
    "keyPassword=$Password"
) -join [Environment]::NewLine

Set-Content -LiteralPath $PropertiesFile -Value $Properties -Encoding ascii
$Password = $null

Write-Host "Release signing configured." -ForegroundColor Green
Write-Host "Keystore: $KeystoreFile" -ForegroundColor Cyan
Write-Host "Properties: $PropertiesFile" -ForegroundColor Cyan
Write-Host "Keep both files private and backed up. Losing this key prevents signing future updates with the same identity." -ForegroundColor Yellow
