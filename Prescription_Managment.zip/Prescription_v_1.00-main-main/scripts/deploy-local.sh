#!/usr/bin/env bash
set -euo pipefail

cd /var/www/prescription

echo "==> Installing dependencies"
npm ci

echo "==> Generating Prisma client"
npm run db:generate

echo "==> Pushing database schema"
npm run db:push

echo "==> Seeding database"
npm run db:seed

echo "==> Building frontend"
npm run build

echo "==> Restarting PM2"
pm2 startOrReload ecosystem.config.cjs --env production
pm2 save

echo "==> Reloading Nginx"
nginx -t
systemctl reload nginx
