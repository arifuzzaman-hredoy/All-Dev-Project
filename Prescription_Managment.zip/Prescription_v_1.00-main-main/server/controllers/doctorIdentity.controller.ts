import {
  getIdentity,
  getPublicIdentity,
  saveIdentityPhoto,
  updateIdentity,
} from "../services/doctorIdentity.service";

export const getDoctorIdentity = async (_req, res) => {
  res.json({ ok: true, data: await getIdentity() });
};

export const putDoctorIdentity = async (req, res) => {
  const data = await updateIdentity(req.body || {});
  res.json({ ok: true, data, message: "Doctor identity saved successfully." });
};

export const uploadDoctorIdentityPhoto = async (req, res) => {
  const data = await saveIdentityPhoto(req.body || {});
  res.status(201).json({ ok: true, ...data, message: "Doctor photo uploaded successfully." });
};

export const getPublicDoctorIdentity = async (_req, res) => {
  res.json({ ok: true, data: await getPublicIdentity() });
};
