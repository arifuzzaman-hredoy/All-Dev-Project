import {
  bulkCreatePrescriptions,
  addPrescriptionAttachments,
  createPrescription,
  createPrescriptionOtp,
  deletePrescriptionAttachment,
  duplicateFollowUp,
  findPublicPrescriptions,
  listPrescriptions,
  publishPrescription,
  savePrescriptionDraft,
  searchPatients,
  serializePrescription,
  softDeletePrescription,
  updatePrescription,
  verifyPrescriptionOtp,
} from "../services/prescription.service";
import { prisma } from "../prisma";
import { getPrescriptionFilePath } from "../utils/prescriptionFiles";
import { verifyDownloadToken } from "../utils/secureDownloadToken";

export const getDoctorPrescriptions = async (_req, res) => {
  res.json({ ok: true, data: await listPrescriptions() });
};

export const getDoctorPrescription = async (req, res) => {
  const item = await prisma.prescription.findUnique({
    where: { id: req.params.id },
    include: { attachments: { orderBy: { sortOrder: "asc" } } },
  });
  if (!item || item.status === "deleted") return res.status(404).json({ ok: false, message: "Prescription not found." });
  res.json({ ok: true, item: serializePrescription(item) });
};

export const savePrescription = async (req, res) => {
  const item = await savePrescriptionDraft(req.body || {}, req.admin);
  res.status(201).json({ ok: true, item, message: "Prescription saved successfully." });
};

export const uploadPrescription = async (req, res) => {
  const item = await createPrescription(req.body || {}, req.admin);
  res.status(201).json({ ok: true, item, message: "Prescription uploaded successfully." });
};

export const publishSavedPrescription = async (req, res) => {
  const item = await publishPrescription(req.params.id, req.body || {}, req.admin);
  res.json({ ok: true, item, message: "Prescription uploaded successfully." });
};

export const bulkUploadPrescriptions = async (req, res) => {
  const result = await bulkCreatePrescriptions(Array.isArray(req.body?.rows) ? req.body.rows : [], req.admin);
  res.json({ ok: result.failed === 0, ...result });
};

export const editPrescription = async (req, res) => {
  const item = await updatePrescription(req.params.id, req.body || {}, req.admin);
  res.json({ ok: true, item, message: "Prescription updated successfully." });
};

export const deletePrescription = async (req, res) => {
  await softDeletePrescription(req.params.id);
  res.json({ ok: true, message: "Prescription deleted successfully." });
};

export const addAttachments = async (req, res) => {
  const attachments = Array.isArray(req.body?.attachments) ? req.body.attachments : [];
  const data = await addPrescriptionAttachments(req.params.id, attachments, req.admin);
  res.status(201).json({ ok: true, data, message: "Attachment saved successfully." });
};

export const removeAttachment = async (req, res) => {
  await deletePrescriptionAttachment(req.params.id, req.params.attachmentId);
  res.json({ ok: true, message: "Attachment deleted successfully." });
};

export const duplicatePrescriptionFollowUp = async (req, res) => {
  const item = await duplicateFollowUp(req.params.id, req.admin);
  res.status(201).json({ ok: true, item, message: "Follow-up prescription created from latest prescription." });
};

export const downloadDoctorPrescription = async (req, res) => {
  const item = await prisma.prescription.findUnique({ where: { id: req.params.id } });
  if (!item || item.status === "deleted") return res.status(404).json({ ok: false, message: "Prescription not found." });
  if (item.fileUrl) return res.download(getPrescriptionFilePath(item.fileUrl), item.originalFileName || item.fileName);
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(item.printableHtml || `<html><body><h1>${item.title}</h1><p>This is a digital prescription.</p></body></html>`);
};

export const searchDoctorPatients = async (req, res) => {
  res.json({ ok: true, data: await searchPatients(req.query.q || "") });
};

export const publicLookupPrescriptions = async (req, res) => {
  const data = await findPublicPrescriptions(req.body || {});
  res.json({ ok: true, data });
};

export const sendPrescriptionOtp = async (req, res) => {
  const result = await createPrescriptionOtp(req.body || {});
  res.json({ ok: true, message: "OTP sent successfully.", ...result });
};

export const verifyPublicPrescriptionOtp = async (req, res) => {
  const data = await verifyPrescriptionOtp(req.body || {});
  res.json({ ok: true, message: "OTP verified successfully.", data });
};

export const downloadPublicPrescription = async (req, res) => {
  const payload = verifyDownloadToken(req.params.secureToken);
  if (!payload) return res.status(403).json({ ok: false, message: "Invalid or expired download link." });

  const item = await prisma.prescription.findFirst({
    where: {
      id: payload.prescriptionId,
      phone: payload.phone,
      patientIdText: payload.patientCode,
      status: { in: ["uploaded", "active"] },
    },
    include: { attachments: { orderBy: { sortOrder: "asc" } } },
  });

  if (!item) return res.status(404).json({ ok: false, message: "File not available." });

  const publicItem = serializePrescription(item, false);
  res.setHeader("X-Prescription-Patient", publicItem.patientId);
  if (item.fileUrl) return res.download(getPrescriptionFilePath(item.fileUrl), item.originalFileName || item.fileName);

  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${item.prescriptionCode || item.id}.html"`);
  res.send(item.printableHtml || `<html><body><h1>${item.title}</h1><p>This is a digital prescription.</p></body></html>`);
};
