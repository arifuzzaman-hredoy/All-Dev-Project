import prisma from "../lib/prisma";
const PAYMENT_METHODS = ["CASH", "BKASH", "NAGAD", "BANK", "CARD", "OTHER"];

const PAYMENT_STATUSES = [
  "PAID",
  "PARTIAL_PAID",
  "DUE",
  "REFUNDED",
  "CANCELLED",
];

const EXPENSE_CATEGORIES = [
  "CLINIC_RENT",
  "STAFF_SALARY",
  "MEDICINE_PURCHASE",
  "UTILITY_BILL",
  "INTERNET_BILL",
  "CLEANING_COST",
  "EQUIPMENT_COST",
  "MARKETING_COST",
  "OTHER_EXPENSE",
];

const getTodayDate = () => new Date().toISOString().slice(0, 10);

const getMonthStartDate = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}-01`;
};

const isDateString = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));

const normalizeDateString = (value, fallback = getTodayDate()) => {
  return isDateString(value) ? value : fallback;
};

const startOfDay = (value) => {
  const date = normalizeDateString(value);
  return new Date(`${date}T00:00:00.000Z`);
};

const endOfDay = (value) => {
  const date = normalizeDateString(value);
  return new Date(`${date}T23:59:59.999Z`);
};

const toMoneyNumber = (value) => {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return 0;
  return Math.max(numberValue, 0);
};

const toMoneyString = (value) => toMoneyNumber(value).toFixed(2);

const toNumber = (value) => Number(value || 0);

const cleanString = (value) => {
  if (value === null || value === undefined) return "";
  return String(value).trim();
};

const optionalString = (value) => {
  const text = cleanString(value);
  return text.length ? text : null;
};

const normalizePaymentMethod = (value) => {
  const method = String(value || "").toUpperCase();
  return PAYMENT_METHODS.includes(method) ? method : "CASH";
};

const normalizePaymentStatus = (value) => {
  const status = String(value || "").toUpperCase();
  return PAYMENT_STATUSES.includes(status) ? status : "PAID";
};

const normalizeExpenseCategory = (value) => {
  const category = String(value || "").toUpperCase();
  return EXPENSE_CATEGORIES.includes(category) ? category : "OTHER_EXPENSE";
};

const buildDateWhere = (query = {}) => {
  const dateFrom = normalizeDateString(query.dateFrom, getMonthStartDate());
  const dateTo = normalizeDateString(query.dateTo, getTodayDate());

  return {
    dateFrom,
    dateTo,
    where: {
      gte: startOfDay(dateFrom),
      lte: endOfDay(dateTo),
    },
  };
};

const getTextFilter = (value) => {
  const text = cleanString(value);
  if (!text) return undefined;

  return {
    contains: text,
    mode: "insensitive",
  };
};

const getEnumFilter = (value, allowedValues) => {
  const text = String(value || "").toUpperCase();
  if (!text || text === "ALL") return undefined;
  return allowedValues.includes(text) ? text : undefined;
};

const mapAppointmentIncome = (item) => ({
  id: item.id,
  date: item.date.toISOString().slice(0, 10),
  serialNo: item.serialNo || "",
  patientName: item.patientName || "",
  phone: item.phone || "",
  doctorName: item.doctorName || "",
  appointmentType: item.appointmentType || "",
  visitFee: toNumber(item.visitFee),
  paidAmount: toNumber(item.paidAmount),
  dueAmount: toNumber(item.dueAmount),
  paymentMethod: item.paymentMethod,
  paymentStatus: item.paymentStatus,
  receivedBy: item.receivedBy || "",
  note: item.note || "",
  createdAt: item.createdAt,
  updatedAt: item.updatedAt,
});

const mapExpense = (item) => ({
  id: item.id,
  date: item.date.toISOString().slice(0, 10),
  title: item.title || "",
  category: item.category,
  amount: toNumber(item.amount),
  paymentMethod: item.paymentMethod,
  paidBy: item.paidBy || "",
  note: item.note || "",
  createdAt: item.createdAt,
  updatedAt: item.updatedAt,
});

const mapDueCollection = (item) => ({
  id: item.id,
  date: item.date.toISOString().slice(0, 10),
  patientName: item.patientName || "",
  phone: item.phone || "",
  amount: toNumber(item.amount),
  paymentMethod: item.paymentMethod,
  receivedBy: item.receivedBy || "",
  note: item.note || "",
  createdAt: item.createdAt,
  updatedAt: item.updatedAt,
});

const mapOtherIncome = (item) => ({
  id: item.id,
  date: item.date.toISOString().slice(0, 10),
  title: item.title || "",
  category: item.category || "",
  amount: toNumber(item.amount),
  paymentMethod: item.paymentMethod,
  receivedBy: item.receivedBy || "",
  note: item.note || "",
  createdAt: item.createdAt,
  updatedAt: item.updatedAt,
});

const isValidIncomeAppointment = (item) => {
  return !["REFUNDED", "CANCELLED"].includes(item.paymentStatus);
};

const calculateSummary = ({
  appointmentIncomes = [],
  expenses = [],
  dueCollections = [],
  otherIncomes = [],
}) => {
  const appointmentIncome = appointmentIncomes.reduce((total, item) => {
    if (!isValidIncomeAppointment(item)) return total;
    return total + toMoneyNumber(item.paidAmount);
  }, 0);

  const appointmentDue = appointmentIncomes.reduce((total, item) => {
    if (!isValidIncomeAppointment(item)) return total;
    return total + toMoneyNumber(item.dueAmount);
  }, 0);

  const expenseTotal = expenses.reduce(
    (total, item) => total + toMoneyNumber(item.amount),
    0
  );

  const dueCollectionTotal = dueCollections.reduce(
    (total, item) => total + toMoneyNumber(item.amount),
    0
  );

  const otherIncomeTotal = otherIncomes.reduce(
    (total, item) => total + toMoneyNumber(item.amount),
    0
  );

  const refundTotal = appointmentIncomes.reduce((total, item) => {
    if (item.paymentStatus !== "REFUNDED") return total;
    return total + toMoneyNumber(item.paidAmount);
  }, 0);

  const totalIncome = appointmentIncome + otherIncomeTotal + dueCollectionTotal;
  const totalExpense = expenseTotal + refundTotal;
  const netBalance = totalIncome - totalExpense;

  return {
    appointmentIncome,
    appointmentDue,
    otherIncome: otherIncomeTotal,
    dueCollection: dueCollectionTotal,
    expense: expenseTotal,
    refund: refundTotal,
    totalIncome,
    totalExpense,
    netBalance,
  };
};

const buildOverallRows = ({
  appointmentIncomes = [],
  expenses = [],
  dueCollections = [],
  otherIncomes = [],
}) => {
  const groups = new Map();

  const getGroup = (date) => {
    if (!groups.has(date)) {
      groups.set(date, {
        date,
        openingBalance: 0,
        totalAppointmentIncome: 0,
        otherIncome: 0,
        totalExpense: 0,
        dueCollection: 0,
        refund: 0,
        netBalance: 0,
        closingBalance: 0,
        note: "",
      });
    }

    return groups.get(date);
  };

  appointmentIncomes.forEach((item) => {
    const group = getGroup(item.date);

    if (item.paymentStatus === "REFUNDED") {
      group.refund += toMoneyNumber(item.paidAmount);
      return;
    }

    if (item.paymentStatus === "CANCELLED") return;

    group.totalAppointmentIncome += toMoneyNumber(item.paidAmount);
  });

  otherIncomes.forEach((item) => {
    const group = getGroup(item.date);
    group.otherIncome += toMoneyNumber(item.amount);
  });

  expenses.forEach((item) => {
    const group = getGroup(item.date);
    group.totalExpense += toMoneyNumber(item.amount);
  });

  dueCollections.forEach((item) => {
    const group = getGroup(item.date);
    group.dueCollection += toMoneyNumber(item.amount);
  });

  let openingBalance = 0;

  return Array.from(groups.values())
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((row) => {
      const totalIncome =
        row.totalAppointmentIncome + row.otherIncome + row.dueCollection;
      const totalExpense = row.totalExpense + row.refund;
      const netBalance = totalIncome - totalExpense;
      const closingBalance = openingBalance + netBalance;

      const finalRow = {
        ...row,
        openingBalance,
        netBalance,
        closingBalance,
      };

      openingBalance = closingBalance;

      return finalRow;
    });
};

const loadAccountData = async (query = {}) => {
  const { dateFrom, dateTo, where: dateWhere } = buildDateWhere(query);

  const paymentMethod = getEnumFilter(query.paymentMethod, PAYMENT_METHODS);
  const paymentStatus = getEnumFilter(query.status, PAYMENT_STATUSES);
  const patientName = getTextFilter(query.patientName);

  const appointmentWhere = {
    date: dateWhere,
    ...(patientName ? { patientName } : {}),
    ...(paymentMethod ? { paymentMethod } : {}),
    ...(paymentStatus ? { paymentStatus } : {}),
  };

  const expenseWhere = {
    date: dateWhere,
    ...(paymentMethod ? { paymentMethod } : {}),
  };

  const dueCollectionWhere = {
    date: dateWhere,
    ...(patientName ? { patientName } : {}),
    ...(paymentMethod ? { paymentMethod } : {}),
  };

  const otherIncomeWhere = {
    date: dateWhere,
    ...(paymentMethod ? { paymentMethod } : {}),
  };

  const [appointmentRaw, expenseRaw, dueRaw, otherIncomeRaw] =
    await Promise.all([
      prisma.accountAppointmentIncome.findMany({
        where: appointmentWhere,
        orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      }),
      prisma.accountExpense.findMany({
        where: expenseWhere,
        orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      }),
      prisma.accountDueCollection.findMany({
        where: dueCollectionWhere,
        orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      }),
      prisma.accountOtherIncome.findMany({
        where: otherIncomeWhere,
        orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      }),
    ]);

  const appointmentIncomes = appointmentRaw.map(mapAppointmentIncome);
  const expenses = expenseRaw.map(mapExpense);
  const dueCollections = dueRaw.map(mapDueCollection);
  const otherIncomes = otherIncomeRaw.map(mapOtherIncome);

  return {
    filters: {
      dateFrom,
      dateTo,
      paymentMethod: paymentMethod || "ALL",
      status: paymentStatus || "ALL",
      patientName: cleanString(query.patientName),
    },
    appointmentIncomes,
    expenses,
    dueCollections,
    otherIncomes,
    overallRows: buildOverallRows({
      appointmentIncomes,
      expenses,
      dueCollections,
      otherIncomes,
    }),
    selectedSummary: calculateSummary({
      appointmentIncomes,
      expenses,
      dueCollections,
      otherIncomes,
    }),
  };
};

const getAccounts = async (req, res) => {
  try {
    const selectedData = await loadAccountData(req.query);

    const today = getTodayDate();
    const monthStart = getMonthStartDate();

    const todayData = await loadAccountData({
      dateFrom: today,
      dateTo: today,
    });

    const monthData = await loadAccountData({
      dateFrom: monthStart,
      dateTo: today,
    });

    return res.status(200).json({
      success: true,
      message: "Accounts data loaded successfully.",
      data: {
        ...selectedData,
        summary: {
          todayIncome: todayData.selectedSummary.totalIncome,
          todayExpense: todayData.selectedSummary.totalExpense,
          todayDue: todayData.selectedSummary.appointmentDue,
          appointmentIncome: selectedData.selectedSummary.appointmentIncome,
          netBalance: selectedData.selectedSummary.netBalance,
          monthlyIncome: monthData.selectedSummary.totalIncome,
          monthlyExpense: monthData.selectedSummary.totalExpense,
          monthlyProfit: monthData.selectedSummary.netBalance,
        },
      },
    });
  } catch (error) {
    console.error("GET_ACCOUNTS_ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load accounts data.",
    });
  }
};

const parseAppointmentPayload = (payload = {}) => {
  const patientName = cleanString(payload.patientName);

  if (!patientName) {
    return {
      error: "Patient name is required.",
    };
  }

  const visitFee = toMoneyNumber(payload.visitFee);
  const paidAmount = toMoneyNumber(payload.paidAmount);
  const dueAmount = Math.max(visitFee - paidAmount, 0);

  return {
    data: {
      date: startOfDay(payload.date),
      serialNo: optionalString(payload.serialNo),
      patientName,
      phone: optionalString(payload.phone),
      doctorName: optionalString(payload.doctorName),
      appointmentType: optionalString(payload.appointmentType),
      visitFee: toMoneyString(visitFee),
      paidAmount: toMoneyString(paidAmount),
      dueAmount: toMoneyString(dueAmount),
      paymentMethod: normalizePaymentMethod(payload.paymentMethod),
      paymentStatus: normalizePaymentStatus(payload.paymentStatus),
      receivedBy: optionalString(payload.receivedBy),
      note: optionalString(payload.note),
    },
  };
};

const parseExpensePayload = (payload = {}) => {
  const title = cleanString(payload.title);

  if (!title) {
    return {
      error: "Expense title is required.",
    };
  }

  return {
    data: {
      date: startOfDay(payload.date),
      title,
      category: normalizeExpenseCategory(payload.category),
      amount: toMoneyString(payload.amount),
      paymentMethod: normalizePaymentMethod(payload.paymentMethod),
      paidBy: optionalString(payload.paidBy),
      note: optionalString(payload.note),
    },
  };
};

const parseDueCollectionPayload = (payload = {}) => {
  const patientName = cleanString(payload.patientName);

  if (!patientName) {
    return {
      error: "Patient name is required.",
    };
  }

  return {
    data: {
      date: startOfDay(payload.date),
      patientName,
      phone: optionalString(payload.phone),
      amount: toMoneyString(payload.amount),
      paymentMethod: normalizePaymentMethod(payload.paymentMethod),
      receivedBy: optionalString(payload.receivedBy),
      note: optionalString(payload.note),
    },
  };
};

const parseOtherIncomePayload = (payload = {}) => {
  const title = cleanString(payload.title);

  if (!title) {
    return {
      error: "Income title is required.",
    };
  }

  return {
    data: {
      date: startOfDay(payload.date),
      title,
      category: optionalString(payload.category),
      amount: toMoneyString(payload.amount),
      paymentMethod: normalizePaymentMethod(payload.paymentMethod),
      receivedBy: optionalString(payload.receivedBy),
      note: optionalString(payload.note),
    },
  };
};

const handlePrismaError = (res, error, fallbackMessage) => {
  console.error(fallbackMessage, error);

  if (error?.code === "P2025") {
    return res.status(404).json({
      success: false,
      message: "Record not found.",
    });
  }

  return res.status(500).json({
    success: false,
    message: fallbackMessage,
  });
};

const createAppointmentIncome = async (req, res) => {
  try {
    const parsed = parseAppointmentPayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountAppointmentIncome.create({
      data: parsed.data,
    });

    return res.status(201).json({
      success: true,
      message: "Appointment income added successfully.",
      data: mapAppointmentIncome(item),
    });
  } catch (error) {
    return handlePrismaError(
      res,
      error,
      "Failed to create appointment income."
    );
  }
};

const updateAppointmentIncome = async (req, res) => {
  try {
    const parsed = parseAppointmentPayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountAppointmentIncome.update({
      where: { id: req.params.id },
      data: parsed.data,
    });

    return res.status(200).json({
      success: true,
      message: "Appointment income updated successfully.",
      data: mapAppointmentIncome(item),
    });
  } catch (error) {
    return handlePrismaError(
      res,
      error,
      "Failed to update appointment income."
    );
  }
};

const deleteAppointmentIncome = async (req, res) => {
  try {
    await prisma.accountAppointmentIncome.delete({
      where: { id: req.params.id },
    });

    return res.status(200).json({
      success: true,
      message: "Appointment income deleted successfully.",
    });
  } catch (error) {
    return handlePrismaError(
      res,
      error,
      "Failed to delete appointment income."
    );
  }
};

const createExpense = async (req, res) => {
  try {
    const parsed = parseExpensePayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountExpense.create({
      data: parsed.data,
    });

    return res.status(201).json({
      success: true,
      message: "Expense added successfully.",
      data: mapExpense(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to create expense.");
  }
};

const updateExpense = async (req, res) => {
  try {
    const parsed = parseExpensePayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountExpense.update({
      where: { id: req.params.id },
      data: parsed.data,
    });

    return res.status(200).json({
      success: true,
      message: "Expense updated successfully.",
      data: mapExpense(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to update expense.");
  }
};

const deleteExpense = async (req, res) => {
  try {
    await prisma.accountExpense.delete({
      where: { id: req.params.id },
    });

    return res.status(200).json({
      success: true,
      message: "Expense deleted successfully.",
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to delete expense.");
  }
};

const createDueCollection = async (req, res) => {
  try {
    const parsed = parseDueCollectionPayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountDueCollection.create({
      data: parsed.data,
    });

    return res.status(201).json({
      success: true,
      message: "Due collection added successfully.",
      data: mapDueCollection(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to create due collection.");
  }
};

const updateDueCollection = async (req, res) => {
  try {
    const parsed = parseDueCollectionPayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountDueCollection.update({
      where: { id: req.params.id },
      data: parsed.data,
    });

    return res.status(200).json({
      success: true,
      message: "Due collection updated successfully.",
      data: mapDueCollection(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to update due collection.");
  }
};

const deleteDueCollection = async (req, res) => {
  try {
    await prisma.accountDueCollection.delete({
      where: { id: req.params.id },
    });

    return res.status(200).json({
      success: true,
      message: "Due collection deleted successfully.",
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to delete due collection.");
  }
};

const createOtherIncome = async (req, res) => {
  try {
    const parsed = parseOtherIncomePayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountOtherIncome.create({
      data: parsed.data,
    });

    return res.status(201).json({
      success: true,
      message: "Income added successfully.",
      data: mapOtherIncome(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to create income.");
  }
};

const updateOtherIncome = async (req, res) => {
  try {
    const parsed = parseOtherIncomePayload(req.body);

    if (parsed.error) {
      return res.status(400).json({
        success: false,
        message: parsed.error,
      });
    }

    const item = await prisma.accountOtherIncome.update({
      where: { id: req.params.id },
      data: parsed.data,
    });

    return res.status(200).json({
      success: true,
      message: "Income updated successfully.",
      data: mapOtherIncome(item),
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to update income.");
  }
};

const deleteOtherIncome = async (req, res) => {
  try {
    await prisma.accountOtherIncome.delete({
      where: { id: req.params.id },
    });

    return res.status(200).json({
      success: true,
      message: "Income deleted successfully.",
    });
  } catch (error) {
    return handlePrismaError(res, error, "Failed to delete income.");
  }
};

export {
  getAccounts,
  createAppointmentIncome,
  updateAppointmentIncome,
  deleteAppointmentIncome,
  createExpense,
  updateExpense,
  deleteExpense,
  createDueCollection,
  updateDueCollection,
  deleteDueCollection,
  createOtherIncome,
  updateOtherIncome,
  deleteOtherIncome,
};
