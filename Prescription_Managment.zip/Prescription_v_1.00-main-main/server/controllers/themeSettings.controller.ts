import { prisma } from "../prisma";

const SETTINGS_TYPE = "panelSettings";
const SETTINGS_KEY = "websiteThemeSettings";
const VARIANTS = ["variant-1", "variant-2", "variant-3", "variant-4", "variant-5"];
const HEX_COLOR = /^#(?:[0-9a-fA-F]{3}){1,2}$/;

export const defaultThemeSettings = {
  navbarVariant: "variant-1",
  heroVariant: "variant-1",
  aboutVariant: "variant-1",
  servicesVariant: "variant-1",
  doctorsVariant: "variant-1",
  appointmentVariant: "variant-1",
  blogsVariant: "variant-1",
  galleryVariant: "variant-1",
  qaVariant: "variant-1",
  contactVariant: "variant-1",
  footerVariant: "variant-1",
  primaryColor: "#00796b",
  secondaryColor: "#0891b2",
  accentColor: "#2563eb",
  backgroundColor: "#f8fafc",
  textColor: "#0f172a",
  buttonColor: "#0f766e",
  buttonTextColor: "#ffffff",
  borderRadius: "24px",
  sectionSpacing: "40px",
  fontStyle: "system",
};

const variantFields = [
  "navbarVariant",
  "heroVariant",
  "aboutVariant",
  "servicesVariant",
  "doctorsVariant",
  "appointmentVariant",
  "blogsVariant",
  "galleryVariant",
  "qaVariant",
  "contactVariant",
  "footerVariant",
];

const colorFields = [
  "primaryColor",
  "secondaryColor",
  "accentColor",
  "backgroundColor",
  "textColor",
  "buttonColor",
  "buttonTextColor",
];

const allowedRadius = ["8px", "12px", "16px", "24px", "32px"];
const allowedSpacing = ["24px", "32px", "40px", "56px", "72px"];
const allowedFonts = ["system", "serif", "mono"];

const pickValue = (value, allowed, fallback) =>
  allowed.includes(value) ? value : fallback;

export const normalizeThemeSettings = (payload = {}) => {
  const next = { ...defaultThemeSettings };

  variantFields.forEach((field) => {
    next[field] = pickValue(payload[field], VARIANTS, defaultThemeSettings[field]);
  });

  colorFields.forEach((field) => {
    next[field] = HEX_COLOR.test(String(payload[field] || ""))
      ? String(payload[field])
      : defaultThemeSettings[field];
  });

  next.borderRadius = pickValue(
    payload.borderRadius,
    allowedRadius,
    defaultThemeSettings.borderRadius
  );
  next.sectionSpacing = pickValue(
    payload.sectionSpacing,
    allowedSpacing,
    defaultThemeSettings.sectionSpacing
  );
  next.fontStyle = pickValue(payload.fontStyle, allowedFonts, defaultThemeSettings.fontStyle);

  return next;
};

export const getThemeSettings = async (_req, res) => {
  try {
    const saved = await prisma.siteContent.findUnique({
      where: { type: SETTINGS_TYPE },
    });
    const themeSettings = saved?.data?.[SETTINGS_KEY] || {};

    return res.json({
      success: true,
      message: "Theme settings loaded successfully.",
      data: normalizeThemeSettings(themeSettings),
    });
  } catch (error) {
    console.error("GET_THEME_SETTINGS_ERROR:", error);

    return res.json({
      success: true,
      message: "Default theme settings loaded.",
      data: defaultThemeSettings,
    });
  }
};

export const updateThemeSettings = async (req, res) => {
  try {
    const data = normalizeThemeSettings(req.body || {});
    const current = await prisma.siteContent.findUnique({
      where: { type: SETTINGS_TYPE },
    });
    const currentData =
      current?.data && typeof current.data === "object" && !Array.isArray(current.data)
        ? current.data
        : {};

    const saved = await prisma.siteContent.upsert({
      where: { type: SETTINGS_TYPE },
      update: {
        data: {
          ...currentData,
          [SETTINGS_KEY]: data,
        },
      },
      create: {
        type: SETTINGS_TYPE,
        data: {
          [SETTINGS_KEY]: data,
        },
      },
    });

    return res.json({
      success: true,
      message: "Theme settings saved successfully.",
      data: normalizeThemeSettings(saved.data?.[SETTINGS_KEY] || data),
    });
  } catch (error) {
    console.error("UPDATE_THEME_SETTINGS_ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to save theme settings.",
    });
  }
};
