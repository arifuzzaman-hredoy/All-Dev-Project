import prisma from "../lib/prisma";
import { writeAuditLog } from "../middleware/auditLog";
const ROLES = [
  "SUPER_ADMIN",
  "OWNER",
  "DOCTOR",
  "STAFF",
  "ASSISTANT",
  "RECEPTIONIST",
  "ACCOUNTANT",
  "LAB_USER",
  "PHARMACIST",
  "SUPPORT",
];

const FEATURES = [
  {
    key: "dashboard",
    label: "Dashboard",
    description: "Main overview, analytics, and quick stats.",
  },
  {
    key: "appointments",
    label: "Appointments",
    description: "Appointment booking, approval, serial, and schedule.",
  },
  {
    key: "patients",
    label: "Patients",
    description: "Patient list, history, profile, and records.",
  },
  {
    key: "prescriptions",
    label: "Prescription",
    description: "Prescription create, save, upload, download, and archive.",
  },
  {
    key: "follow_up",
    label: "Follow Up",
    description: "Follow-up schedule and patient tracking.",
  },
  {
    key: "messages",
    label: "Messages",
    description: "Patient messages, public queries, and replies.",
  },
  {
    key: "reports",
    label: "Reports",
    description: "Medical reports, analytics, and export data.",
  },
  {
    key: "accounts",
    label: "Accounts",
    description: "Billing, invoices, payment, and due management.",
  },
  {
    key: "website_cms",
    label: "Website CMS",
    description: "Public website content management.",
  },
  {
    key: "doctor_profile",
    label: "Doctor Profile",
    description: "Doctor profile, about, chamber, and public details.",
  },
  {
    key: "doctor_blog",
    label: "Doctor Blog",
    description: "Articles, health tips, and blog content.",
  },
  {
    key: "doctor_gallery",
    label: "Doctor Gallery",
    description: "Gallery photos and media management.",
  },
  {
    key: "panel_settings",
    label: "Panel Settings",
    description: "System settings, branding, and configuration.",
  },
  {
    key: "users",
    label: "Users",
    description: "Admin users, staff, and doctor accounts.",
  },
  {
    key: "access_control",
    label: "Access Control",
    description: "Role permissions and restricted panel features.",
  },
];

const createDefaultPermission = (role, featureKey) => {
  if (role === "SUPER_ADMIN" || role === "OWNER") {
    return {
      canView: true,
      canCreate: true,
      canUpdate: true,
      canDelete: true,
      restricted: false,
    };
  }

  if (role === "DOCTOR") {
    const fullDoctorFeatures = [
      "dashboard",
      "appointments",
      "patients",
      "prescriptions",
      "follow_up",
      "messages",
      "reports",
      "doctor_profile",
      "doctor_blog",
      "doctor_gallery",
    ];

    const viewOnlyDoctorFeatures = ["accounts"];

    if (fullDoctorFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }

    if (viewOnlyDoctorFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
    }

    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
      restricted: true,
    };
  }

  if (role === "STAFF") {
    const staffEditableFeatures = ["dashboard", "appointments", "messages"];
    const staffViewFeatures = ["patients", "follow_up", "reports"];

    if (staffEditableFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }

    if (staffViewFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
    }

    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
      restricted: true,
    };
  }

  if (role === "ASSISTANT" || role === "RECEPTIONIST") {
    const editableFeatures = ["dashboard", "appointments", "patients", "messages"];
    const viewFeatures = ["follow_up", "reports"];

    if (editableFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }

    if (viewFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
    }
  }

  if (role === "ACCOUNTANT") {
    const accountingFeatures = ["dashboard", "accounts", "reports"];

    if (accountingFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: featureKey === "accounts",
        canUpdate: featureKey === "accounts",
        canDelete: false,
        restricted: false,
      };
    }
  }

  if (role === "LAB_USER") {
    const labFeatures = ["dashboard", "patients", "reports"];

    if (labFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: featureKey === "reports",
        canUpdate: featureKey === "reports",
        canDelete: false,
        restricted: false,
      };
    }
  }

  if (role === "PHARMACIST") {
    const pharmacyFeatures = ["dashboard", "patients", "prescriptions"];

    if (pharmacyFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
    }
  }

  if (role === "SUPPORT") {
    const supportFeatures = ["dashboard", "messages"];

    if (supportFeatures.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }
  }

  return {
    canView: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false,
    restricted: true,
  };
};

const createDefaultAssistantAccess = (role) => {
  if (role === "SUPER_ADMIN" || role === "OWNER") {
    return {
      enabled: true,
      canReadPatients: true,
      canWritePrescriptions: true,
      canSendMessages: true,
      canManageSettings: true,
    };
  }

  if (role === "DOCTOR") {
    return {
      enabled: true,
      canReadPatients: true,
      canWritePrescriptions: true,
      canSendMessages: true,
      canManageSettings: false,
    };
  }

  return {
    enabled: false,
    canReadPatients: false,
    canWritePrescriptions: false,
    canSendMessages: false,
    canManageSettings: false,
  };
};

const buildDefaultState = () => {
  const permissions = {};
  const assistantAccess = {};

  ROLES.forEach((role) => {
    permissions[role] = {};
    FEATURES.forEach((feature) => {
      permissions[role][feature.key] = createDefaultPermission(role, feature.key);
    });

    assistantAccess[role] = createDefaultAssistantAccess(role);
  });

  return {
    roles: ROLES,
    features: FEATURES,
    permissions,
    assistantAccess,
  };
};

const normalizeBoolean = (value) => Boolean(value);

const normalizePermission = (role, permission) => {
  if (role === "SUPER_ADMIN" || role === "OWNER") {
    return {
      canView: true,
      canCreate: true,
      canUpdate: true,
      canDelete: true,
      restricted: false,
    };
  }

  const restricted = normalizeBoolean(permission.restricted);

  if (restricted) {
    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
      restricted: true,
    };
  }

  return {
    canView: normalizeBoolean(permission.canView),
    canCreate: normalizeBoolean(permission.canCreate),
    canUpdate: normalizeBoolean(permission.canUpdate),
    canDelete: normalizeBoolean(permission.canDelete),
    restricted: false,
  };
};

const normalizeAssistantAccess = (role, payload) => {
  if (role === "SUPER_ADMIN" || role === "OWNER") {
    return createDefaultAssistantAccess(role);
  }

  const enabled = normalizeBoolean(payload.enabled);

  return {
    enabled,
    canReadPatients: enabled && normalizeBoolean(payload.canReadPatients),
    canWritePrescriptions:
      enabled && normalizeBoolean(payload.canWritePrescriptions),
    canSendMessages: enabled && normalizeBoolean(payload.canSendMessages),
    canManageSettings: enabled && normalizeBoolean(payload.canManageSettings),
  };
};

const loadAccessControlState = async () => {
  const defaultState = buildDefaultState();

  const savedPermissions = await prisma.accessPermission.findMany();
  const savedAssistantAccess = await prisma.assistantAccessPolicy.findMany();

  savedPermissions.forEach((item) => {
    if (!defaultState.permissions[item.role]) return;
    if (!defaultState.permissions[item.role][item.feature]) return;

    defaultState.permissions[item.role][item.feature] = {
      canView: item.canView,
      canCreate: item.canCreate,
      canUpdate: item.canUpdate,
      canDelete: item.canDelete,
      restricted: item.restricted,
    };
  });

  savedAssistantAccess.forEach((item) => {
    if (!defaultState.assistantAccess[item.role]) return;

    defaultState.assistantAccess[item.role] = {
      enabled: item.enabled,
      canReadPatients: item.canReadPatients,
      canWritePrescriptions: item.canWritePrescriptions,
      canSendMessages: item.canSendMessages,
      canManageSettings: item.canManageSettings,
    };
  });

  return defaultState;
};

export const getAccessControl = async (req, res) => {
  try {
    const data = await loadAccessControlState();

    return res.status(200).json({
      success: true,
      message: "Access control loaded successfully.",
      data,
    });
  } catch (error) {
    console.error("GET_ACCESS_CONTROL_ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load access control data.",
    });
  }
};

export const updateAccessControl = async (req, res) => {
  try {
    const { permissions, assistantAccess } = req.body || {};

    if (!permissions || typeof permissions !== "object") {
      return res.status(400).json({
        success: false,
        message: "Invalid permissions payload.",
      });
    }

    const operations = [];

    ROLES.forEach((role) => {
      FEATURES.forEach((feature) => {
        const incomingPermission =
          permissions?.[role]?.[feature.key] ||
          createDefaultPermission(role, feature.key);

        const normalizedPermission = normalizePermission(
          role,
          incomingPermission
        );

        operations.push(
          prisma.accessPermission.upsert({
            where: {
              role_feature: {
                role,
                feature: feature.key,
              },
            },
            update: normalizedPermission,
            create: {
              role,
              feature: feature.key,
              ...normalizedPermission,
            },
          })
        );
      });

      const incomingAssistantAccess =
        assistantAccess?.[role] || createDefaultAssistantAccess(role);

      const normalizedAssistantAccess = normalizeAssistantAccess(
        role,
        incomingAssistantAccess
      );

      operations.push(
        prisma.assistantAccessPolicy.upsert({
          where: {
            role,
          },
          update: normalizedAssistantAccess,
          create: {
            role,
            ...normalizedAssistantAccess,
          },
        })
      );
    });

    await prisma.$transaction(operations);
    await writeAuditLog(req, "permission.change", {
      entityType: "AccessPermission",
      roles: ROLES,
    });

    const data = await loadAccessControlState();

    return res.status(200).json({
      success: true,
      message: "Access control saved successfully.",
      data,
    });
  } catch (error) {
    console.error("UPDATE_ACCESS_CONTROL_ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update access control data.",
    });
  }
};
