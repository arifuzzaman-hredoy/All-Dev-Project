import "dotenv/config";
import { prisma } from "./prisma";
import { hashPassword } from "./auth";
import { defaultContent } from "./defaults";

const defaultModules = [
  "CLINIC_PUBLIC_SITE",
  "CLINIC_CMS",
  "CLINIC_APPOINTMENT",
  "CLINIC_PATIENT",
  "CLINIC_ENCOUNTER",
  "CLINIC_PRESCRIPTION",
  "CLINIC_FOLLOW_UP",
  "CLINIC_BILLING_BASIC",
  "CLINIC_BILLING_ADVANCED",
  "CLINIC_PATIENT_LEDGER",
  "CLINIC_SMS",
  "CLINIC_REPORTS",
  "CLINIC_SUPPORT",
  "CLINIC_AUDIT",
  "CLINIC_DIAGNOSTIC",
  "CLINIC_LAB_REPORT",
  "CLINIC_INVENTORY",
  "CLINIC_EXPENSE",
  "CLINIC_IPD_FUTURE",
  "CLINIC_PHARMACY_FUTURE",
];

const defaultPackages = [
  { key: "single-doctor", name: "Single Doctor", userLimit: 2, doctorLimit: 1 },
  { key: "pro-doctor", name: "Pro Doctor", userLimit: 3, doctorLimit: 1 },
  { key: "clinic-basic", name: "Clinic Basic", userLimit: 8, doctorLimit: 5 },
  { key: "clinic-plus", name: "Clinic Plus", userLimit: 20, doctorLimit: 10 },
  { key: "diagnostic-center", name: "Diagnostic Center", userLimit: 20, doctorLimit: 2 },
  { key: "clinic-diagnostic", name: "Clinic + Diagnostic", userLimit: 30, doctorLimit: 12 },
  { key: "hospital-erp", name: "Hospital ERP", userLimit: 100, doctorLimit: 50 },
];

async function main() {
  const username = process.env.ADMIN_USERNAME || "admin";
  const adminEmail = process.env.ADMIN_EMAIL || `${username}@example.com`;
  const password = process.env.ADMIN_PASSWORD || "change-me-now";
  const passwordHash = await hashPassword(password);

  await prisma.adminUser.upsert({
    where: { username },
    update: { passwordHash },
    create: { username, passwordHash, role: "SUPER_ADMIN" }
  });

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: { passwordHash, isSuperAdmin: true, status: "ACTIVE" },
    create: {
      email: adminEmail,
      name: "Super Admin",
      passwordHash,
      isSuperAdmin: true,
      status: "ACTIVE",
    },
  });

  for (const key of defaultModules) {
    await prisma.module.upsert({
      where: { key },
      update: {},
      create: {
        key,
        name: key
          .toLowerCase()
          .split("_")
          .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
          .join(" "),
      },
    });
  }

  for (const item of defaultPackages) {
    await prisma.package.upsert({
      where: { key: item.key },
      update: {
        userLimit: item.userLimit,
        doctorLimit: item.doctorLimit,
      },
      create: item,
    });
  }

  const tenant = await prisma.tenant.upsert({
    where: { slug: "default-clinic" },
    update: {},
    create: {
      name: "Default Clinic",
      slug: "default-clinic",
      status: "TRIAL",
      deploymentMode: "CLOUD",
      contactEmail: adminEmail,
    },
  });

  await prisma.businessUnit.upsert({
    where: { id: "default-business-unit" },
    update: {},
    create: {
      id: "default-business-unit",
      tenantId: tenant.id,
      name: "Main Chamber",
      type: "SINGLE_DOCTOR",
    },
  });

  await prisma.publicSite.upsert({
    where: { tenantId_slug: { tenantId: tenant.id, slug: "default-clinic" } },
    update: {},
    create: {
      tenantId: tenant.id,
      slug: "default-clinic",
      title: "Default Clinic",
      isActive: true,
    },
  });

  for (const moduleKey of defaultModules.slice(0, 14)) {
    await prisma.tenantModule.upsert({
      where: { tenantId_moduleKey: { tenantId: tenant.id, moduleKey } },
      update: {},
      create: { tenantId: tenant.id, moduleKey, enabled: true },
    });
  }

  for (const [type, data] of Object.entries(defaultContent)) {
    await prisma.siteContent.upsert({
      where: { type },
      update: {},
      create: { type, data }
    });
  }

  console.log(`Seed completed. Admin username: ${username}; admin email: ${adminEmail}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
}).finally(async () => prisma.$disconnect());
