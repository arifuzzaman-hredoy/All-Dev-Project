import { prisma } from "../prisma";
import { forbidden } from "../utils/ApiError";
import { resolveTenantId } from "../utils/tenant-context";

export const requireModule = (moduleKey) => async (req, _res, next) => {
  try {
    const tenantId = resolveTenantId(req);
    if (!tenantId) return next(forbidden("Tenant context is required."));

    const enabled = await prisma.tenantModule.findFirst({
      where: { tenantId, moduleKey, enabled: true },
      select: { id: true },
    });

    if (!enabled) return next(forbidden(`Module is disabled: ${moduleKey}`));
    return next();
  } catch (error) {
    return next(error);
  }
};
