import { prisma } from "../prisma";
import { forbidden } from "../utils/ApiError";
import { resolveTenantId } from "../utils/tenant-context";

export const requireActiveSubscription = async (req, _res, next) => {
  try {
    const tenantId = resolveTenantId(req);
    if (!tenantId) return next(forbidden("Tenant context is required."));

    const subscription = await prisma.subscription.findFirst({
      where: {
        tenantId,
        status: { in: ["TRIAL", "ACTIVE"] },
        OR: [{ endsAt: null }, { endsAt: { gt: new Date() } }],
      },
      select: { id: true },
    });

    if (!subscription) return next(forbidden("Active subscription is required."));
    return next();
  } catch (error) {
    return next(error);
  }
};
