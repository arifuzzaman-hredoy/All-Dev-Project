import { prisma } from "../prisma";
import { resolveTenantId } from "../utils/tenant-context";

export const writeAuditLog = async (req, action, metadata = {}) => {
  try {
    await prisma.auditLog.create({
      data: {
        tenantId: resolveTenantId(req) || null,
        actorUserId: req.admin?.id || null,
        actorRole: req.admin?.role || null,
        action,
        entityType: metadata.entityType || null,
        entityId: metadata.entityId || null,
        ipAddress: req.ip || null,
        userAgent: req.headers?.["user-agent"] || null,
        metadata,
      },
    });
  } catch (error) {
    console.error("AUDIT_LOG_FAILED:", error);
  }
};
