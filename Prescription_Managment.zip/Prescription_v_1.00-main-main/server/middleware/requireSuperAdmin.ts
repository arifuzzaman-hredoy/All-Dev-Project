import { forbidden } from "../utils/ApiError";
import { requireAuth } from "./requireAuth";

export const requireSuperAdmin = [
  requireAuth,
  (req, _res, next) => {
    if (req.admin?.role !== "SUPER_ADMIN") {
      return next(forbidden("Super admin permission is required."));
    }

    return next();
  },
];
