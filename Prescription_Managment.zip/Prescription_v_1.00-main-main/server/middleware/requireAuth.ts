import jwt from "jsonwebtoken";
import { unauthorized } from "../utils/ApiError";

const getSecret = () =>
  process.env.JWT_SECRET ||
  process.env.ADMIN_SESSION_SECRET ||
  "change-this-secret-before-production";

export const requireAuth = (req, _res, next) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;

  if (!token) return next(unauthorized());

  try {
    req.admin = jwt.verify(token, getSecret());
    return next();
  } catch {
    return next(unauthorized("Invalid or expired session."));
  }
};
