import { prisma } from "../prisma";
import { forbidden } from "../utils/ApiError";
import { resolveTenantId } from "../utils/tenant-context";

export const requireLimit = ({ resource, count }) => async (req, _res, next) => {
  try {
    const tenantId = resolveTenantId(req);
    if (!tenantId) return next(forbidden("Tenant context is required."));

    const tenant = await prisma.tenant.findUnique({
      where: { id: tenantId },
      select: { userLimit: true, doctorLimit: true },
    });

    if (!tenant) return next(forbidden("Tenant context is invalid."));

    const limit = resource === "doctor" ? tenant.doctorLimit : tenant.userLimit;
    if (Number(count || 0) >= limit) {
      return next(forbidden(`${resource} limit reached for this tenant.`));
    }

    return next();
  } catch (error) {
    return next(error);
  }
};
