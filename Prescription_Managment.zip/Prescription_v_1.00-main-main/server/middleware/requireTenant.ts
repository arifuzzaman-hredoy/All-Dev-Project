import { prisma } from "../prisma";
import { unauthorized } from "../utils/ApiError";
import { getTenantSlugFromRequest } from "../utils/tenant-context";

export const requireTenant = async (req, _res, next) => {
  try {
    if (req.admin?.tenantId) {
      req.tenant = { id: req.admin.tenantId };
      return next();
    }

    const slug = getTenantSlugFromRequest(req);
    if (!slug) return next(unauthorized("Tenant context is required."));

    const site = await prisma.publicSite.findFirst({
      where: { slug, isActive: true },
      select: { tenantId: true },
    });

    if (!site?.tenantId) return next(unauthorized("Tenant context is invalid."));

    req.tenant = { id: site.tenantId, slug };
    return next();
  } catch (error) {
    return next(error);
  }
};
