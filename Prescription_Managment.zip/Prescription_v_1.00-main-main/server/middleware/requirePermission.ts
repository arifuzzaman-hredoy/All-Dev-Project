import { forbidden } from "../utils/ApiError";

export const requirePermission = (permissionKey) => (req, _res, next) => {
  const permissions = req.admin?.permissions || [];
  if (req.admin?.role === "SUPER_ADMIN" || permissions.includes(permissionKey)) {
    return next();
  }

  return next(forbidden(`Permission required: ${permissionKey}`));
};
