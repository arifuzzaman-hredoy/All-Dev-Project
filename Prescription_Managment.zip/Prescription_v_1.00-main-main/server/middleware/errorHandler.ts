export const errorHandler = (err, _req, res, _next) => {
  console.error(err);
  res.status(err.statusCode || 500).json({
    ok: false,
    code: err.code || "SERVER_ERROR",
    message: err.message || "Server error.",
  });
};
