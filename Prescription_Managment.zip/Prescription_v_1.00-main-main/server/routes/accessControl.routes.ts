import express from "express";

import {
  getAccessControl,
  updateAccessControl,
} from "../controllers/accessControl.controller";
import { requireAdmin } from "../auth";

const router = express.Router();

router.get("/", requireAdmin, getAccessControl);
router.post("/", requireAdmin, updateAccessControl);
router.put("/", requireAdmin, updateAccessControl);

export default router;
