import express from "express";
import { requireAdmin } from "../auth";
import { prisma } from "../prisma";
import {
  bulkUploadPrescriptions,
  addAttachments,
  deletePrescription,
  downloadDoctorPrescription,
  downloadPublicPrescription,
  duplicatePrescriptionFollowUp,
  editPrescription,
  getDoctorPrescription,
  getDoctorPrescriptions,
  publishSavedPrescription,
  publicLookupPrescriptions,
  removeAttachment,
  searchDoctorPatients,
  sendPrescriptionOtp,
  savePrescription,
  uploadPrescription,
  verifyPublicPrescriptionOtp,
} from "../controllers/prescription.controller";

const router = express.Router();

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const defaultPermission = (role) => {
  if (role === "SUPER_ADMIN") return { canView: true, canCreate: true, canUpdate: true, canDelete: true };
  if (role === "DOCTOR") return { canView: true, canCreate: true, canUpdate: true, canDelete: false };
  return { canView: false, canCreate: false, canUpdate: false, canDelete: false };
};

const requirePrescriptionPermission = (action) =>
  asyncHandler(async (req, res, next) => {
    const role = req.admin?.role || "STAFF";
    if (role === "SUPER_ADMIN") return next();

    const saved = await prisma.accessPermission.findUnique({
      where: { role_feature: { role, feature: "prescriptions" } },
    });
    const permission = saved || defaultPermission(role);
    const allowed =
      action === "view"
        ? permission.canView
        : action === "upload"
          ? permission.canCreate
          : action === "update"
            ? permission.canUpdate
            : action === "delete"
              ? permission.canDelete
              : permission.canView;

    if (!allowed || permission.restricted) {
      return res.status(403).json({ ok: false, message: "You do not have prescription permission." });
    }

    return next();
  });

router.get("/api/doctor/prescriptions", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(getDoctorPrescriptions));
router.get("/api/doctor/prescriptions/upload-table", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(getDoctorPrescriptions));
router.get("/api/doctor/prescriptions/history", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(getDoctorPrescriptions));
router.post("/api/doctor/prescriptions/save", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(savePrescription));
router.post("/api/doctor/prescriptions/upload", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(uploadPrescription));
router.post("/api/doctor/prescriptions/bulk-upload", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(bulkUploadPrescriptions));
router.get("/api/doctor/prescriptions/:id", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(getDoctorPrescription));
router.put("/api/doctor/prescriptions/:id", requireAdmin, requirePrescriptionPermission("update"), asyncHandler(editPrescription));
router.post("/api/doctor/prescriptions/:id/upload", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(publishSavedPrescription));
router.post("/api/doctor/prescriptions/:id/attachments", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(addAttachments));
router.delete("/api/doctor/prescriptions/:id/attachments/:attachmentId", requireAdmin, requirePrescriptionPermission("delete"), asyncHandler(removeAttachment));
router.post("/api/doctor/prescriptions/:id/duplicate-follow-up", requireAdmin, requirePrescriptionPermission("upload"), asyncHandler(duplicatePrescriptionFollowUp));
router.delete("/api/doctor/prescriptions/:id", requireAdmin, requirePrescriptionPermission("delete"), asyncHandler(deletePrescription));
router.get("/api/doctor/prescriptions/:id/print", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(downloadDoctorPrescription));
router.get("/api/doctor/prescriptions/:id/download", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(downloadDoctorPrescription));
router.get("/api/doctor/patients/search", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(searchDoctorPatients));
router.get("/api/doctor/patients/:patientId/prescriptions", requireAdmin, requirePrescriptionPermission("view"), asyncHandler(getDoctorPrescriptions));

router.post("/api/public/prescriptions/lookup", asyncHandler(publicLookupPrescriptions));
router.post("/api/public/prescriptions/send-otp", asyncHandler(sendPrescriptionOtp));
router.post("/api/public/prescriptions/verify-otp", asyncHandler(verifyPublicPrescriptionOtp));
router.get("/api/public/prescriptions/:secureToken/download", asyncHandler(downloadPublicPrescription));

export default router;
