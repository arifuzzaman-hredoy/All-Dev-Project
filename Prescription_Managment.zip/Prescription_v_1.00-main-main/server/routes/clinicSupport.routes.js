import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-support.json");

const defaultTickets = [
  {
    id: "SUP-ID-1001",
    ticketNo: "SUP-1001",
    tenantName: "Update Diagnostic Center",
    clinicName: "Update Clinic",
    contactEmail: "admin@updateclinic.test",
    subject: "Prescription PDF not downloading",
    category: "Technical",
    priority: "High",
    status: "In Progress",
    createdDate: "2026-06-20",
    lastUpdated: "2026-06-20",
    assignedTo: "Support Team",
    messages: [
      {
        id: "MSG-1001",
        sender: "Tenant",
        message: "Prescription PDF generate hocche kintu download hocche na.",
        createdAt: "2026-06-20 09:20 AM"
      },
      {
        id: "MSG-1002",
        sender: "Support",
        message: "Issue received. PDF route and browser console check kortesi.",
        createdAt: "2026-06-20 09:45 AM"
      }
    ]
  },
  {
    id: "SUP-ID-1002",
    ticketNo: "SUP-1002",
    tenantName: "Prime Care Clinic",
    clinicName: "Prime Care",
    contactEmail: "owner@primecare.test",
    subject: "SMS balance recharge record mismatch",
    category: "SMS",
    priority: "Medium",
    status: "Open",
    createdDate: "2026-06-20",
    lastUpdated: "2026-06-20",
    assignedTo: "SMS Desk",
    messages: [
      {
        id: "MSG-1003",
        sender: "Tenant",
        message: "Recharge 5000 SMS dekhacche, kintu usage balance kom show kortese.",
        createdAt: "2026-06-20 10:30 AM"
      }
    ]
  }
];

const allowedStatuses = ["Open", "In Progress", "Resolved", "Closed"];
const allowedPriorities = ["Low", "Medium", "High", "Urgent"];
const allowedCategories = ["Technical", "Billing", "Account", "SMS", "Report", "Feature"];
const allowedSenders = ["Tenant", "Support", "Admin"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultTickets, null, 2));
  }
};

const readTickets = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const tickets = JSON.parse(rawData);
    return Array.isArray(tickets) ? tickets : defaultTickets;
  } catch {
    return defaultTickets;
  }
};

const writeTickets = (tickets) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(tickets, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const today = () => new Date().toISOString().slice(0, 10);

const nowText = () =>
  new Date().toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "2-digit"
  });

const searchTickets = (tickets, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return tickets;

  return tickets.filter((item) =>
    [
      item.id,
      item.ticketNo,
      item.tenantName,
      item.clinicName,
      item.contactEmail,
      item.subject,
      item.category,
      item.priority,
      item.status,
      item.assignedTo
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterTickets = (tickets, reqQuery) => {
  let result = [...tickets];

  result = searchTickets(result, reqQuery.q);

  const status = cleanText(reqQuery.status);
  const priority = cleanText(reqQuery.priority);
  const category = cleanText(reqQuery.category);
  const assignedTo = cleanText(reqQuery.assignedTo);

  if (status) result = result.filter((item) => item.status === status);
  if (priority) result = result.filter((item) => item.priority === priority);
  if (category) result = result.filter((item) => item.category === category);
  if (assignedTo) result = result.filter((item) => item.assignedTo === assignedTo);

  return result;
};

router.get("/", (req, res) => {
  const tickets = readTickets();
  const filteredTickets = filterTickets(tickets, req.query);

  return res.json({ tickets: filteredTickets });
});

router.post("/", (req, res) => {
  const tickets = readTickets();

  const tenantName = cleanText(req.body && req.body.tenantName);
  const clinicName = cleanText(req.body && req.body.clinicName);
  const contactEmail = cleanText(req.body && req.body.contactEmail);
  const subject = cleanText(req.body && req.body.subject);
  const category = cleanText(req.body && req.body.category) || "Technical";
  const priority = cleanText(req.body && req.body.priority) || "Medium";
  const status = cleanText(req.body && req.body.status) || "Open";
  const assignedTo = cleanText(req.body && req.body.assignedTo) || "Support Team";
  const message = cleanText(req.body && req.body.message);

  if (
    !tenantName ||
    !clinicName ||
    !contactEmail ||
    !contactEmail.includes("@") ||
    !subject ||
    !message
  ) {
    return res.status(400).json({
      message: "Tenant, clinic, valid email, subject and message are required"
    });
  }

  if (!allowedCategories.includes(category)) {
    return res.status(400).json({ message: "Invalid ticket category" });
  }

  if (!allowedPriorities.includes(priority)) {
    return res.status(400).json({ message: "Invalid ticket priority" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid ticket status" });
  }

  const ticket = {
    id: `SUP-ID-${Date.now()}`,
    ticketNo: `SUP-${String(tickets.length + 1).padStart(4, "0")}`,
    tenantName,
    clinicName,
    contactEmail,
    subject,
    category,
    priority,
    status,
    createdDate: today(),
    lastUpdated: today(),
    assignedTo,
    messages: [
      {
        id: `MSG-${Date.now()}`,
        sender: "Tenant",
        message,
        createdAt: nowText()
      }
    ]
  };

  const nextTickets = [ticket, ...tickets];
  writeTickets(nextTickets);

  return res.status(201).json({ ticket });
});

router.patch("/:id/status", (req, res) => {
  const tickets = readTickets();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid ticket status"
    });
  }

  const foundTicket = tickets.find((item) => item.id === id);

  if (!foundTicket) {
    return res.status(404).json({
      message: "Support ticket not found"
    });
  }

  const nextTickets = tickets.map((item) =>
    item.id === id ? { ...item, status, lastUpdated: today() } : item
  );

  writeTickets(nextTickets);

  return res.json({
    ticket: nextTickets.find((item) => item.id === id)
  });
});

router.post("/:id/messages", (req, res) => {
  const tickets = readTickets();

  const id = cleanText(req.params.id);
  const sender = cleanText(req.body && req.body.sender) || "Support";
  const message = cleanText(req.body && req.body.message);

  if (!allowedSenders.includes(sender)) {
    return res.status(400).json({ message: "Invalid message sender" });
  }

  if (!message) {
    return res.status(400).json({ message: "Message is required" });
  }

  const foundTicket = tickets.find((item) => item.id === id);

  if (!foundTicket) {
    return res.status(404).json({
      message: "Support ticket not found"
    });
  }

  const supportMessage = {
    id: `MSG-${Date.now()}`,
    sender,
    message,
    createdAt: nowText()
  };

  const nextTickets = tickets.map((item) =>
    item.id === id
      ? {
          ...item,
          lastUpdated: today(),
          status: item.status === "Open" ? "In Progress" : item.status,
          messages: [...(item.messages || []), supportMessage]
        }
      : item
  );

  writeTickets(nextTickets);

  return res.json({
    ticket: nextTickets.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const tickets = readTickets();
  const id = cleanText(req.params.id);

  const foundTicket = tickets.find((item) => item.id === id);

  if (!foundTicket) {
    return res.status(404).json({
      message: "Support ticket not found"
    });
  }

  const nextTickets = tickets.filter((item) => item.id !== id);
  writeTickets(nextTickets);

  return res.json({ success: true });
});

export default router;
