import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();
const dataDir = path.join(process.cwd(), "server", "data");

const files = {
  appointments: "clinic-appointments.json",
  patients: "clinic-patients.json",
  doctors: "clinic-doctors.json",
  encounters: "clinic-encounters.json",
  prescriptions: "clinic-prescriptions.json",
  billing: "clinic-billing.json",
  payments: "clinic-payments.json",
  ledger: "clinic-patient-ledger.json",
  smsWallet: "clinic-sms-wallet.json",
  support: "clinic-support.json",
  diagnostic: "clinic-diagnostic-orders.json",
  inventory: "clinic-inventory.json",
};

const readArray = (fileName) => {
  try {
    const filePath = path.join(dataDir, fileName);
    if (!fs.existsSync(filePath)) return [];
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const number = (value) => {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
};

const cleanText = (value) => String(value || "").trim();
const todayKey = () => new Date().toISOString().slice(0, 10);
const dateKey = (value) => cleanText(value).slice(0, 10);

const toDate = (value) => {
  const key = dateKey(value);
  if (!key) return null;
  const date = new Date(`${key}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
};

const daysAgoKey = (offset) => {
  const date = new Date();
  date.setDate(date.getDate() - offset);
  return date.toISOString().slice(0, 10);
};

const inRange = (value, range) => {
  if (range === "all") return true;
  const date = toDate(value);
  if (!date) return false;
  if (range === "day") return dateKey(value) === todayKey();
  const today = new Date(`${todayKey()}T00:00:00`);
  const cutoff = new Date(today);
  cutoff.setDate(today.getDate() - (range === "30d" ? 29 : 6));
  return date >= cutoff && date <= today;
};

const trendKeys = (range) => {
  if (range === "day") return [todayKey()];
  const count = range === "30d" || range === "all" ? 14 : 7;
  const step = range === "30d" || range === "all" ? 2 : 1;
  const keys = [];
  for (let offset = (count - 1) * step; offset >= 0; offset -= step) keys.push(daysAgoKey(offset));
  return keys;
};

const labelFromKey = (key) =>
  key === todayKey()
    ? "Today"
    : new Date(`${key}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "2-digit" });

const latest = (items, dateField, limit = 3) =>
  [...items].sort((a, b) => String(b[dateField] || "").localeCompare(String(a[dateField] || ""))).slice(0, limit);

const smsBalance = (records) =>
  latest(records, "date", 1)[0]?.balanceAfter ? number(latest(records, "date", 1)[0].balanceAfter) : 0;

router.get("/", (req, res) => {
  const range = ["day", "7d", "30d", "all"].includes(req.query.range) ? req.query.range : "day";
  const appointments = readArray(files.appointments);
  const patients = readArray(files.patients);
  const doctors = readArray(files.doctors);
  const encounters = readArray(files.encounters);
  const prescriptions = readArray(files.prescriptions);
  const billing = readArray(files.billing);
  const payments = readArray(files.payments);
  const ledger = readArray(files.ledger);
  const smsWallet = readArray(files.smsWallet);
  const support = readArray(files.support);
  const diagnostic = readArray(files.diagnostic);
  const inventory = readArray(files.inventory);

  const rangeAppointments = appointments.filter((item) => inRange(item.appointmentDate, range));
  const rangePayments = payments.filter((item) => inRange(item.paymentDate, range));
  const rangePrescriptions = prescriptions.filter((item) => inRange(item.prescriptionDate, range));
  const rangePatients = patients.filter((item) => inRange(item.lastVisit || item.createdAt, range));
  const rangeDiagnostic = diagnostic.filter((item) => inRange(item.orderDate, range));
  const rangeEncounters = encounters.filter((item) => inRange(item.visitDate, range));

  const waitingPatients = appointments.filter((item) => ["Waiting", "Checked In", "Pending"].includes(item.status)).length;
  const completedVisits = rangeAppointments.filter((item) => item.status === "Completed").length + rangeEncounters.filter((item) => item.status === "Completed").length;
  const followUpDue = appointments.filter((item) => item.type === "Follow-up").length + prescriptions.filter((item) => item.type === "Follow-up").length + patients.filter((item) => item.status === "Follow-up").length;
  const todayCollection = rangePayments.filter((item) => item.status === "Completed" && (item.type === "Collection" || !item.type)).reduce((total, item) => total + number(item.amount), 0);
  const pendingDue = billing.reduce((total, item) => total + number(item.dueAmount), 0) || ledger.reduce((total, item) => total + Math.max(0, number(item.currentDue || item.due)), 0);
  const lowStock = inventory.filter((item) => item.status === "Low Stock" || number(item.stock) <= number(item.reorderLevel)).length;
  const expiredStock = inventory.filter((item) => item.status === "Expired").length;
  const supportOpen = support.filter((item) => !["Resolved", "Closed"].includes(item.status)).length;
  const reportReady = diagnostic.filter((item) => item.status === "Report Ready").length;

  const trend = trendKeys(range).map((key) => ({
    label: labelFromKey(key),
    visits: appointments.filter((item) => dateKey(item.appointmentDate) === key).length,
    revenue: payments.filter((item) => dateKey(item.paymentDate) === key && item.status === "Completed").reduce((total, item) => total + number(item.amount), 0),
    prescriptions: prescriptions.filter((item) => dateKey(item.prescriptionDate) === key).length,
    patients: patients.filter((item) => dateKey(item.lastVisit || item.createdAt) === key).length,
    labOrders: diagnostic.filter((item) => dateKey(item.orderDate) === key).length,
    lowStock,
  }));

  const dashboard = {
    stats: {
      todayAppointments: rangeAppointments.length,
      waitingPatients,
      completedVisits,
      followUpDue,
      todayCollection,
      pendingDue,
      prescriptionCount: rangePrescriptions.length,
      smsBalance: smsBalance(smsWallet),
      activeDoctors: doctors.filter((item) => item.status === "Active").length,
      labOrders: rangeDiagnostic.length,
      reportReady,
      lowStock,
      supportOpen,
    },
    trend,
    moduleSummary: [
      { label: "Appointments", value: rangeAppointments.length, note: `${waitingPatients} waiting`, status: waitingPatients > 10 ? "Warning" : "Good" },
      { label: "Patients", value: rangePatients.length, note: `${followUpDue} follow-up`, status: "Good" },
      { label: "Prescriptions", value: rangePrescriptions.length, note: "RX records", status: "Good" },
      { label: "Billing", value: todayCollection, note: `৳${pendingDue} due`, status: pendingDue ? "Warning" : "Good" },
      { label: "Diagnostic", value: rangeDiagnostic.length, note: `${reportReady} report ready`, status: reportReady ? "Warning" : "Good" },
      { label: "Inventory", value: lowStock, note: "Low stock", status: lowStock ? "Critical" : "Good" },
    ],
    recentAppointments: latest(appointments, "appointmentDate").map((item) => ({ id: item.id, title: item.patientName, subtitle: item.problem || item.doctorName, status: item.status, time: item.appointmentTime || item.appointmentDate })),
    recentPatients: latest(patients, "lastVisit").map((item) => ({ id: item.id, title: item.name || item.patientName, subtitle: item.diagnosis || item.assignedDoctor, status: item.status, time: item.lastVisit || "-" })),
    recentInvoices: latest(billing, "billDate").map((item) => ({ id: item.id, title: item.invoiceNo, subtitle: item.patientName, status: item.status, time: item.billDate, amount: number(item.paidAmount) })),
    recentLabOrders: latest(diagnostic, "orderDate").map((item) => ({ id: item.id, title: item.orderNo, subtitle: Array.isArray(item.tests) ? item.tests.slice(0, 2).join(", ") : item.patientName, status: item.status, time: item.deliveryDate || item.orderDate })),
    alerts: [
      pendingDue ? { id: "AL-DUE", title: "Pending due", note: `৳ ${pendingDue.toLocaleString()} patient due pending.`, level: pendingDue > 10000 ? "Critical" : "Warning" } : null,
      lowStock ? { id: "AL-STOCK", title: "Low stock", note: `${lowStock} inventory items need reorder.`, level: "Warning" } : null,
      expiredStock ? { id: "AL-EXP", title: "Expired stock", note: `${expiredStock} inventory items expired.`, level: "Critical" } : null,
      supportOpen ? { id: "AL-SUP", title: "Open support", note: `${supportOpen} support tickets open.`, level: "Info" } : null,
      reportReady ? { id: "AL-LAB", title: "Report ready", note: `${reportReady} reports ready for delivery.`, level: "Info" } : null,
    ].filter(Boolean),
    updatedAt: new Date().toISOString(),
  };

  return res.json({ dashboard });
});

export default router;
