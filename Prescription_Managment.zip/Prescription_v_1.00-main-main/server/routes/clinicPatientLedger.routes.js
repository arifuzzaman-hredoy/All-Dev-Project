import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-patient-ledger.json");

const defaultLedgers = [
  {
    id: "LED-ID-1001",
    ledgerNo: "LED-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    assignedDoctor: "Dr. Abdullah Rahman",
    openingBalance: 0,
    totalBilled: 1800,
    totalPaid: 1800,
    totalDiscount: 100,
    currentDue: 0,
    lastTransactionDate: "2026-06-20",
    nextDueDate: "No due",
    status: "Clear",
    transactions: [
      {
        id: "TRX-1001",
        date: "2026-06-20",
        type: "Invoice",
        refNo: "INV-1001",
        description: "Consultation and medicine bill",
        debit: 1800,
        credit: 0,
        method: "None"
      },
      {
        id: "TRX-1002",
        date: "2026-06-20",
        type: "Payment",
        refNo: "RCPT-1001",
        description: "Cash collection",
        debit: 0,
        credit: 1800,
        method: "Cash"
      }
    ]
  },
  {
    id: "LED-ID-1002",
    ledgerNo: "LED-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    assignedDoctor: "Dr. Mehedi Hasan",
    openingBalance: 0,
    totalBilled: 2500,
    totalPaid: 1200,
    totalDiscount: 100,
    currentDue: 1200,
    lastTransactionDate: "2026-06-20",
    nextDueDate: "2026-06-27",
    status: "Due",
    transactions: []
  }
];

const allowedStatuses = ["Clear", "Due", "Overdue", "Credit"];
const allowedTransactionTypes = [
  "Invoice",
  "Payment",
  "Discount",
  "Refund",
  "Adjustment"
];
const allowedMethods = ["Cash", "Card", "bKash", "Nagad", "Bank", "None"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultLedgers, null, 2));
  }
};

const readLedgers = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const ledgers = JSON.parse(rawData);
    return Array.isArray(ledgers) ? ledgers : defaultLedgers;
  } catch {
    return defaultLedgers;
  }
};

const writeLedgers = (ledgers) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(ledgers, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const calculateBalance = (openingBalance, totalBilled, totalPaid, totalDiscount) =>
  Number(openingBalance || 0) +
  Number(totalBilled || 0) -
  Number(totalPaid || 0) -
  Number(totalDiscount || 0);

const getStatusFromBalance = (balance, fallback) => {
  if (fallback === "Overdue") return "Overdue";
  if (balance < 0) return "Credit";
  if (balance === 0) return "Clear";
  return "Due";
};

const searchLedgers = (ledgers, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return ledgers;

  return ledgers.filter((item) =>
    [
      item.id,
      item.ledgerNo,
      item.patientId,
      item.patientName,
      item.phone,
      item.assignedDoctor,
      item.status,
      item.nextDueDate,
      item.lastTransactionDate
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterLedgers = (ledgers, reqQuery) => {
  let result = [...ledgers];

  result = searchLedgers(result, reqQuery.q);

  const status = cleanText(reqQuery.status);
  const doctor = cleanText(reqQuery.doctor);

  if (status) result = result.filter((item) => item.status === status);
  if (doctor) result = result.filter((item) => item.assignedDoctor === doctor);

  return result;
};

router.get("/", (req, res) => {
  const ledgers = readLedgers();
  const filteredLedgers = filterLedgers(ledgers, req.query);

  return res.json({ ledgers: filteredLedgers });
});

router.post("/", (req, res) => {
  const ledgers = readLedgers();

  const patientId = cleanText(req.body && req.body.patientId);
  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const assignedDoctor = cleanText(req.body && req.body.assignedDoctor);
  const openingBalance = Number(req.body && req.body.openingBalance);
  const totalBilled = Number(req.body && req.body.totalBilled);
  const totalPaid = Number(req.body && req.body.totalPaid);
  const totalDiscount = Number(req.body && req.body.totalDiscount);
  const nextDueDate = cleanText(req.body && req.body.nextDueDate) || "Not scheduled";
  const requestedStatus = cleanText(req.body && req.body.status) || "Due";

  if (
    !patientId ||
    !patientName ||
    !phone ||
    !assignedDoctor ||
    !Number.isFinite(openingBalance) ||
    !Number.isFinite(totalBilled) ||
    !Number.isFinite(totalPaid) ||
    !Number.isFinite(totalDiscount)
  ) {
    return res.status(400).json({
      message:
        "Patient, phone, doctor/desk and balance fields are required"
    });
  }

  if (!allowedStatuses.includes(requestedStatus)) {
    return res.status(400).json({ message: "Invalid ledger status" });
  }

  const currentDue = calculateBalance(
    openingBalance,
    totalBilled,
    totalPaid,
    totalDiscount
  );

  const ledger = {
    id: `LED-ID-${Date.now()}`,
    ledgerNo: `LED-${String(ledgers.length + 1).padStart(4, "0")}`,
    patientId,
    patientName,
    phone,
    assignedDoctor,
    openingBalance,
    totalBilled,
    totalPaid,
    totalDiscount,
    currentDue,
    lastTransactionDate: "Not recorded",
    nextDueDate,
    status: getStatusFromBalance(currentDue, requestedStatus),
    transactions: []
  };

  const nextLedgers = [ledger, ...ledgers];
  writeLedgers(nextLedgers);

  return res.status(201).json({ ledger });
});

router.post("/:id/transactions", (req, res) => {
  const ledgers = readLedgers();

  const id = cleanText(req.params.id);
  const foundLedger = ledgers.find((item) => item.id === id);

  if (!foundLedger) {
    return res.status(404).json({ message: "Ledger not found" });
  }

  const date = cleanText(req.body && req.body.date);
  const type = cleanText(req.body && req.body.type) || "Payment";
  const refNo = cleanText(req.body && req.body.refNo);
  const description = cleanText(req.body && req.body.description);
  const debit = Number(req.body && req.body.debit);
  const credit = Number(req.body && req.body.credit);
  const method = cleanText(req.body && req.body.method) || "None";

  if (
    !date ||
    !refNo ||
    !description ||
    !Number.isFinite(debit) ||
    !Number.isFinite(credit) ||
    debit < 0 ||
    credit < 0 ||
    debit + credit <= 0
  ) {
    return res.status(400).json({
      message: "Date, ref, description, debit or credit are required"
    });
  }

  if (!allowedTransactionTypes.includes(type)) {
    return res.status(400).json({ message: "Invalid transaction type" });
  }

  if (!allowedMethods.includes(method)) {
    return res.status(400).json({ message: "Invalid payment method" });
  }

  const transaction = {
    id: `TRX-${Date.now()}`,
    date,
    type,
    refNo,
    description,
    debit,
    credit,
    method
  };

  const nextLedgers = ledgers.map((ledger) => {
    if (ledger.id !== id) return ledger;

    const totalBilled =
      Number(ledger.totalBilled || 0) + (debit > 0 ? debit : 0);

    const totalPaid =
      Number(ledger.totalPaid || 0) + (type === "Payment" ? credit : 0);

    const totalDiscount =
      Number(ledger.totalDiscount || 0) + (type === "Discount" ? credit : 0);

    const currentDue = Number(ledger.currentDue || 0) + debit - credit;

    return {
      ...ledger,
      totalBilled,
      totalPaid,
      totalDiscount,
      currentDue,
      lastTransactionDate: date,
      status: getStatusFromBalance(currentDue, ledger.status),
      transactions: [transaction, ...(ledger.transactions || [])]
    };
  });

  writeLedgers(nextLedgers);

  return res.json({
    ledger: nextLedgers.find((ledger) => ledger.id === id)
  });
});

router.patch("/:id/status", (req, res) => {
  const ledgers = readLedgers();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid ledger status"
    });
  }

  const foundLedger = ledgers.find((item) => item.id === id);

  if (!foundLedger) {
    return res.status(404).json({
      message: "Ledger not found"
    });
  }

  const nextLedgers = ledgers.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writeLedgers(nextLedgers);

  return res.json({
    ledger: nextLedgers.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const ledgers = readLedgers();
  const id = cleanText(req.params.id);

  const foundLedger = ledgers.find((item) => item.id === id);

  if (!foundLedger) {
    return res.status(404).json({
      message: "Ledger not found"
    });
  }

  const nextLedgers = ledgers.filter((item) => item.id !== id);
  writeLedgers(nextLedgers);

  return res.json({ success: true });
});

export default router;
