import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-payments.json");

const defaultPayments = [
  {
    id: "PAY-ID-1001",
    receiptNo: "RCPT-1001",
    invoiceNo: "INV-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    paymentDate: "2026-06-20",
    paymentTime: "09:45 AM",
    paymentFor: "Consultation invoice",
    amount: 900,
    method: "Cash",
    type: "Collection",
    status: "Completed",
    collectedBy: "Front Desk",
    transactionId: "CASH-1001",
    notes: "Consultation fee collected."
  },
  {
    id: "PAY-ID-1002",
    receiptNo: "RCPT-1002",
    invoiceNo: "INV-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    paymentDate: "2026-06-20",
    paymentTime: "10:20 AM",
    paymentFor: "Diagnostics partial bill",
    amount: 800,
    method: "bKash",
    type: "Collection",
    status: "Completed",
    collectedBy: "Reception",
    transactionId: "BKASH-TXN-8831",
    notes: "Partial payment received."
  }
];

const allowedTypes = ["Collection", "Refund", "Settlement", "Adjustment"];
const allowedStatuses = ["Pending", "Completed", "Failed", "Refunded", "Cancelled"];
const allowedMethods = ["Cash", "Card", "bKash", "Nagad", "Bank", "Cheque"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultPayments, null, 2));
  }
};

const readPayments = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const payments = JSON.parse(rawData);
    return Array.isArray(payments) ? payments : defaultPayments;
  } catch {
    return defaultPayments;
  }
};

const writePayments = (payments) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(payments, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchPayments = (payments, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return payments;

  return payments.filter((item) =>
    [
      item.id,
      item.receiptNo,
      item.invoiceNo,
      item.patientId,
      item.patientName,
      item.phone,
      item.paymentDate,
      item.paymentTime,
      item.paymentFor,
      item.method,
      item.type,
      item.status,
      item.collectedBy,
      item.transactionId,
      item.notes
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterPayments = (payments, reqQuery) => {
  let result = [...payments];

  result = searchPayments(result, reqQuery.q);

  const status = cleanText(reqQuery.status);
  const type = cleanText(reqQuery.type);
  const method = cleanText(reqQuery.method);
  const collectedBy = cleanText(reqQuery.collectedBy);

  if (status) result = result.filter((item) => item.status === status);
  if (type) result = result.filter((item) => item.type === type);
  if (method) result = result.filter((item) => item.method === method);
  if (collectedBy) {
    result = result.filter((item) => item.collectedBy === collectedBy);
  }

  return result;
};

router.get("/", (req, res) => {
  const payments = readPayments();
  const filteredPayments = filterPayments(payments, req.query);

  return res.json({ payments: filteredPayments });
});

router.post("/", (req, res) => {
  const payments = readPayments();

  const invoiceNo = cleanText(req.body && req.body.invoiceNo);
  const patientId = cleanText(req.body && req.body.patientId);
  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const paymentDate = cleanText(req.body && req.body.paymentDate);
  const paymentTime = cleanText(req.body && req.body.paymentTime);
  const paymentFor = cleanText(req.body && req.body.paymentFor);
  const amount = Number(req.body && req.body.amount);
  const method = cleanText(req.body && req.body.method) || "Cash";
  const type = cleanText(req.body && req.body.type) || "Collection";
  const status = cleanText(req.body && req.body.status) || "Completed";
  const collectedBy = cleanText(req.body && req.body.collectedBy);
  const transactionId =
    cleanText(req.body && req.body.transactionId) || `${method}-${Date.now()}`;
  const notes = cleanText(req.body && req.body.notes) || "No payment note";

  if (
    !invoiceNo ||
    !patientId ||
    !patientName ||
    !phone ||
    !paymentDate ||
    !paymentTime ||
    !paymentFor ||
    !Number.isFinite(amount) ||
    amount <= 0 ||
    !collectedBy
  ) {
    return res.status(400).json({
      message:
        "Invoice, patient, phone, date, time, payment for, amount and collector are required"
    });
  }

  if (!allowedMethods.includes(method)) {
    return res.status(400).json({ message: "Invalid payment method" });
  }

  if (!allowedTypes.includes(type)) {
    return res.status(400).json({ message: "Invalid payment type" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid payment status" });
  }

  const payment = {
    id: `PAY-ID-${Date.now()}`,
    receiptNo: `RCPT-${String(payments.length + 1).padStart(4, "0")}`,
    invoiceNo,
    patientId,
    patientName,
    phone,
    paymentDate,
    paymentTime,
    paymentFor,
    amount,
    method,
    type,
    status,
    collectedBy,
    transactionId,
    notes
  };

  const nextPayments = [payment, ...payments];
  writePayments(nextPayments);

  return res.status(201).json({ payment });
});

router.patch("/:id/status", (req, res) => {
  const payments = readPayments();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid payment status"
    });
  }

  const foundPayment = payments.find((item) => item.id === id);

  if (!foundPayment) {
    return res.status(404).json({
      message: "Payment not found"
    });
  }

  const nextPayments = payments.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writePayments(nextPayments);

  return res.json({
    payment: nextPayments.find((item) => item.id === id)
  });
});

router.patch("/:id/refund", (req, res) => {
  const payments = readPayments();
  const id = cleanText(req.params.id);

  const foundPayment = payments.find((item) => item.id === id);

  if (!foundPayment) {
    return res.status(404).json({
      message: "Payment not found"
    });
  }

  const nextPayments = payments.map((item) =>
    item.id === id
      ? {
          ...item,
          type: "Refund",
          status: "Refunded",
          notes: item.notes
            ? `${item.notes} | Refunded`
            : "Refunded"
        }
      : item
  );

  writePayments(nextPayments);

  return res.json({
    payment: nextPayments.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const payments = readPayments();
  const id = cleanText(req.params.id);

  const foundPayment = payments.find((item) => item.id === id);

  if (!foundPayment) {
    return res.status(404).json({
      message: "Payment not found"
    });
  }

  const nextPayments = payments.filter((item) => item.id !== id);
  writePayments(nextPayments);

  return res.json({ success: true });
});

export default router;
