import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-users.json");

const defaultUsers = [
  {
    id: "USR-1001",
    name: "Clinic Owner",
    email: "owner@carebridge.demo",
    role: "Owner",
    access: "Active",
    lastActive: "Today",
  },
  {
    id: "USR-1002",
    name: "Dr. Rahman",
    email: "doctor@carebridge.demo",
    role: "Doctor",
    access: "Active",
    lastActive: "2 hours ago",
  },
  {
    id: "USR-1003",
    name: "Front Desk",
    email: "reception@carebridge.demo",
    role: "Receptionist",
    access: "Active",
    lastActive: "Yesterday",
  },
];

const allowedRoles = ["Owner", "Doctor", "Receptionist", "Accountant", "Staff"];
const allowedAccess = ["Active", "Suspended"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultUsers, null, 2));
  }
};

const readUsers = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const users = JSON.parse(rawData);

    return Array.isArray(users) ? users : defaultUsers;
  } catch {
    return defaultUsers;
  }
};

const writeUsers = (users) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(users, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchUsers = (users, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return users;

  return users.filter((user) =>
    [
      user.id,
      user.name,
      user.email,
      user.role,
      user.access,
      user.lastActive,
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText),
  );
};

router.get("/", (req, res) => {
  const users = readUsers();
  const searchedUsers = searchUsers(users, req.query.q);

  return res.json({ users: searchedUsers });
});

router.post("/", (req, res) => {
  const users = readUsers();

  const name = cleanText(req.body && req.body.name);
  const email = cleanText(req.body && req.body.email).toLowerCase();
  const role = cleanText(req.body && req.body.role);

  if (!name || !email || !role) {
    return res.status(400).json({
      message: "Name, email and role are required",
    });
  }

  if (!allowedRoles.includes(role)) {
    return res.status(400).json({
      message: "Invalid user role",
    });
  }

  const emailExists = users.some(
    (user) => String(user.email).toLowerCase() === email,
  );

  if (emailExists) {
    return res.status(409).json({
      message: "User email already exists",
    });
  }

  const user = {
    id: `USR-${Date.now()}`,
    name,
    email,
    role,
    access: "Active",
    lastActive: "Just now",
  };

  const nextUsers = [user, ...users];
  writeUsers(nextUsers);

  return res.status(201).json({ user });
});

router.patch("/:id/access", (req, res) => {
  const users = readUsers();

  const id = cleanText(req.params.id);
  const access = cleanText(req.body && req.body.access);

  if (!allowedAccess.includes(access)) {
    return res.status(400).json({
      message: "Invalid access status",
    });
  }

  const foundUser = users.find((user) => user.id === id);

  if (!foundUser) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  const nextUsers = users.map((user) =>
    user.id === id ? { ...user, access } : user,
  );

  writeUsers(nextUsers);

  return res.json({
    user: nextUsers.find((user) => user.id === id),
  });
});

router.delete("/:id", (req, res) => {
  const users = readUsers();
  const id = cleanText(req.params.id);

  const foundUser = users.find((user) => user.id === id);

  if (!foundUser) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  if (foundUser.role === "Owner") {
    return res.status(403).json({
      message: "Owner user cannot be removed",
    });
  }

  const nextUsers = users.filter((user) => user.id !== id);
  writeUsers(nextUsers);

  return res.json({ success: true });
});

export default router;
