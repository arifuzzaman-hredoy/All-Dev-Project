import express from "express";
import { prisma } from "../prisma";

const router = express.Router();

const fallbackPlan = {
  tenantName: "CareBridge Clinic",
  packageName: "Clinic ERP Pro",
  packageType: "Clinic SaaS Package",
  status: "Active",
  renewalDate: "30 Jun 2026",
  billingCycle: "Monthly",
  users: 12,
  maxUsers: 25,
  patients: 842,
  maxPatients: 2000,
  storageUsed: 38,
  storageLimit: 100,
  modules: [
    { name: "Appointment Management", status: "Active", used: 186, limit: 500 },
    { name: "Patient Records", status: "Active", used: 842, limit: 2000 },
    { name: "Prescription Workflow", status: "Active", used: 427, limit: 1000 },
    { name: "Billing & Payments", status: "Active", used: 92, limit: 300 },
    { name: "Website CMS", status: "Active", used: 18, limit: 50 },
    { name: "SMS Wallet", status: "Limited", used: 640, limit: 1000 },
    { name: "Diagnostic Add-on", status: "Limited", used: 21, limit: 100 },
    { name: "Hospital IPD Shell", status: "Disabled", used: 0, limit: 0 },
  ],
  billing: [
    {
      label: "Current subscription",
      date: "01 Jun 2026",
      amount: "৳ 4,500",
      status: "Paid",
    },
    {
      label: "SMS wallet top-up",
      date: "12 Jun 2026",
      amount: "৳ 1,000",
      status: "Paid",
    },
    {
      label: "Next renewal invoice",
      date: "30 Jun 2026",
      amount: "৳ 4,500",
      status: "Due",
    },
  ],
};

const formatDate = (value?: Date | null) =>
  value
    ? new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }).format(value)
    : fallbackPlan.renewalDate;

const titleFromKey = (key: string) =>
  key
    .replace(/^CLINIC_/, "")
    .split("_")
    .map((part) => part.charAt(0) + part.slice(1).toLowerCase())
    .join(" ");

router.get("/", async (_req, res) => {
  try {
    const tenant = await prisma.tenant.findFirst({
      orderBy: { createdAt: "asc" },
    });

    if (!tenant) return res.json(fallbackPlan);

    const [subscription, tenantModules, userCount, patientCount] =
      await Promise.all([
        prisma.subscription.findFirst({
          where: { tenantId: tenant.id },
          orderBy: { createdAt: "desc" },
        }),
        prisma.tenantModule.findMany({
          where: { tenantId: tenant.id },
          orderBy: { moduleKey: "asc" },
        }),
        prisma.user.count({ where: { tenantId: tenant.id } }),
        prisma.patient.count({ where: { tenantId: tenant.id } }),
      ]);

    const activeModuleKeys = tenantModules
      .filter((item) => item.enabled)
      .map((item) => item.moduleKey);

    const modules = activeModuleKeys.length
      ? activeModuleKeys.map((moduleKey) => ({
          name: titleFromKey(moduleKey),
          status: "Active",
        }))
      : fallbackPlan.modules;

    return res.json({
      ...fallbackPlan,
      tenantName: tenant.name,
      packageName: subscription?.packageKey || fallbackPlan.packageName,
      packageType: tenant.deploymentMode
        ? `${tenant.deploymentMode.toLowerCase()} deployment`
        : fallbackPlan.packageType,
      status:
        subscription?.status === "TRIAL"
          ? "Trial"
          : subscription?.status === "EXPIRED"
            ? "Expired"
            : subscription?.status === "SUSPENDED"
              ? "Suspended"
              : "Active",
      renewalDate: formatDate(subscription?.endsAt || tenant.trialEndsAt),
      users: userCount,
      maxUsers: subscription?.userLimit || tenant.userLimit,
      patients: patientCount,
      modules,
    });
  } catch (error) {
    console.error("CLINIC_MY_PLAN_FALLBACK:", error);
    return res.json(fallbackPlan);
  }
});

export default router;
