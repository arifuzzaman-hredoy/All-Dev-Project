import express from "express";

import {
  getAccounts,
  createAppointmentIncome,
  updateAppointmentIncome,
  deleteAppointmentIncome,
  createExpense,
  updateExpense,
  deleteExpense,
  createDueCollection,
  updateDueCollection,
  deleteDueCollection,
  createOtherIncome,
  updateOtherIncome,
  deleteOtherIncome,
} from "../controllers/accounts.controller";

const router = express.Router();

router.get("/", getAccounts);

router.post("/appointment-income", createAppointmentIncome);
router.put("/appointment-income/:id", updateAppointmentIncome);
router.delete("/appointment-income/:id", deleteAppointmentIncome);

router.post("/expenses", createExpense);
router.put("/expenses/:id", updateExpense);
router.delete("/expenses/:id", deleteExpense);

router.post("/due-collections", createDueCollection);
router.put("/due-collections/:id", updateDueCollection);
router.delete("/due-collections/:id", deleteDueCollection);

router.post("/other-incomes", createOtherIncome);
router.put("/other-incomes/:id", updateOtherIncome);
router.delete("/other-incomes/:id", deleteOtherIncome);

export default router;
