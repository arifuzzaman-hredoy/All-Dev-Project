import express from "express";
import { requireAdmin } from "../auth";
import prisma from "../lib/prisma";

const router = express.Router();

const DEFAULT_MODULES = [
  "CLINIC_PUBLIC_SITE",
  "CLINIC_CMS",
  "CLINIC_APPOINTMENT",
  "CLINIC_PATIENT",
  "CLINIC_ENCOUNTER",
  "CLINIC_PRESCRIPTION",
  "CLINIC_FOLLOW_UP",
  "CLINIC_BILLING_BASIC",
  "CLINIC_REPORTS",
  "CLINIC_SUPPORT",
  "CLINIC_AUDIT",
];

const normalizeAccessFeature = (feature) => String(feature || "").toLowerCase();

router.get("/context", requireAdmin, async (req, res) => {
  const role = req.admin?.role || "SUPER_ADMIN";

  try {
    const tenant = await prisma.tenant.findFirst({
      where: { slug: "default-clinic" },
      select: {
        id: true,
        name: true,
        slug: true,
        status: true,
        userLimit: true,
        doctorLimit: true,
      },
    });

    const tenantModules = tenant
      ? await prisma.tenantModule.findMany({
          where: { tenantId: tenant.id, enabled: true },
          select: { moduleKey: true },
        })
      : [];

    const permissions = await prisma.accessPermission.findMany({
      where: { role },
      select: {
        feature: true,
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: true,
        restricted: true,
      },
    });

    return res.json({
      ok: true,
      data: {
        user: {
          id: req.admin?.id || "",
          username: req.admin?.username || "",
          role,
        },
        tenant,
        modules: tenantModules.length
          ? tenantModules.map((item) => item.moduleKey)
          : DEFAULT_MODULES,
        permissions: Object.fromEntries(
          permissions.map((item) => [
            normalizeAccessFeature(item.feature),
            {
              canView: item.canView,
              canCreate: item.canCreate,
              canUpdate: item.canUpdate,
              canDelete: item.canDelete,
              restricted: item.restricted,
            },
          ])
        ),
      },
    });
  } catch (error) {
    console.error("APP_CONTEXT_FALLBACK:", error);
    return res.json({
      ok: true,
      fallback: true,
      data: {
        user: {
          id: req.admin?.id || "",
          username: req.admin?.username || "",
          role,
        },
        tenant: null,
        modules: DEFAULT_MODULES,
        permissions: {},
      },
    });
  }
});

export default router;
