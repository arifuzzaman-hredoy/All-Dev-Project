import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-doctors.json");

const defaultDoctors = [
  {
    id: "DR-1001",
    name: "Dr. Abdullah Rahman",
    email: "abdullah@carebridge.demo",
    phone: "+8801711000001",
    specialization: "Medicine",
    chamber: "Room 301",
    schedule: "Sat-Thu, 5:00 PM - 9:00 PM",
    dailyCapacity: 32,
    bookedToday: 18,
    status: "Active",
  },
  {
    id: "DR-1002",
    name: "Dr. Nusrat Jahan",
    email: "nusrat@carebridge.demo",
    phone: "+8801711000002",
    specialization: "Gynecology",
    chamber: "Room 204",
    schedule: "Sun-Wed, 4:00 PM - 8:00 PM",
    dailyCapacity: 24,
    bookedToday: 9,
    status: "Active",
  },
];

const allowedStatus = ["Active", "On Leave", "Suspended"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultDoctors, null, 2));
  }
};

const readDoctors = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const doctors = JSON.parse(rawData);
    return Array.isArray(doctors) ? doctors : defaultDoctors;
  } catch {
    return defaultDoctors;
  }
};

const writeDoctors = (doctors) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(doctors, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchDoctors = (doctors, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return doctors;

  return doctors.filter((doctor) =>
    [
      doctor.id,
      doctor.name,
      doctor.email,
      doctor.phone,
      doctor.specialization,
      doctor.chamber,
      doctor.schedule,
      doctor.status,
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText),
  );
};

router.get("/", (req, res) => {
  const doctors = readDoctors();
  const searchedDoctors = searchDoctors(doctors, req.query.q);

  return res.json({ doctors: searchedDoctors });
});

router.post("/", (req, res) => {
  const doctors = readDoctors();

  const name = cleanText(req.body && req.body.name);
  const email = cleanText(req.body && req.body.email).toLowerCase();
  const phone = cleanText(req.body && req.body.phone);
  const specialization = cleanText(req.body && req.body.specialization);
  const chamber = cleanText(req.body && req.body.chamber);
  const schedule = cleanText(req.body && req.body.schedule);
  const dailyCapacity = Number(req.body && req.body.dailyCapacity);
  const status = cleanText(req.body && req.body.status) || "Active";

  if (
    !name ||
    !email ||
    !phone ||
    !specialization ||
    !chamber ||
    !schedule ||
    !Number.isFinite(dailyCapacity) ||
    dailyCapacity <= 0
  ) {
    return res.status(400).json({
      message:
        "Name, email, phone, specialization, chamber, schedule and capacity are required",
    });
  }

  if (!allowedStatus.includes(status)) {
    return res.status(400).json({ message: "Invalid doctor status" });
  }

  const emailExists = doctors.some(
    (doctor) => String(doctor.email).toLowerCase() === email,
  );

  if (emailExists) {
    return res.status(409).json({
      message: "Doctor email already exists",
    });
  }

  const doctor = {
    id: `DR-${Date.now()}`,
    name,
    email,
    phone,
    specialization,
    chamber,
    schedule,
    dailyCapacity,
    bookedToday: 0,
    status,
  };

  const nextDoctors = [doctor, ...doctors];
  writeDoctors(nextDoctors);

  return res.status(201).json({ doctor });
});

router.patch("/:id/status", (req, res) => {
  const doctors = readDoctors();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatus.includes(status)) {
    return res.status(400).json({
      message: "Invalid doctor status",
    });
  }

  const foundDoctor = doctors.find((doctor) => doctor.id === id);

  if (!foundDoctor) {
    return res.status(404).json({
      message: "Doctor not found",
    });
  }

  const nextDoctors = doctors.map((doctor) =>
    doctor.id === id ? { ...doctor, status } : doctor,
  );

  writeDoctors(nextDoctors);

  return res.json({
    doctor: nextDoctors.find((doctor) => doctor.id === id),
  });
});

router.delete("/:id", (req, res) => {
  const doctors = readDoctors();
  const id = cleanText(req.params.id);

  const foundDoctor = doctors.find((doctor) => doctor.id === id);

  if (!foundDoctor) {
    return res.status(404).json({
      message: "Doctor not found",
    });
  }

  const nextDoctors = doctors.filter((doctor) => doctor.id !== id);
  writeDoctors(nextDoctors);

  return res.json({ success: true });
});

export default router;
