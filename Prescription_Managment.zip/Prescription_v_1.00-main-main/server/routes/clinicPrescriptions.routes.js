import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-prescriptions.json");

const defaultPrescriptions = [
  {
    id: "RX-ID-1001",
    rxNo: "RX-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    prescriptionDate: "2026-06-20",
    type: "Follow-up",
    diagnosis: "Migraine follow-up",
    medicines: "Tab. Paracetamol 500mg, Cap. Omeprazole 20mg",
    dosageNote: "After meal, 2 times daily for 5 days",
    advice: "Hydration, proper sleep, avoid trigger food",
    followUpDate: "2026-07-05",
    uploadName: "rx-nusrat-1001.pdf",
    uploadStatus: "Reviewed",
    status: "Delivered"
  },
  {
    id: "RX-ID-1002",
    rxNo: "RX-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    specialization: "Cardiology",
    prescriptionDate: "2026-06-20",
    type: "New",
    diagnosis: "Hypertension observation",
    medicines: "Tab. Amlodipine 5mg",
    dosageNote: "Once daily at night",
    advice: "BP chart maintain, low salt diet",
    followUpDate: "2026-06-27",
    uploadName: "bp-report-rx.pdf",
    uploadStatus: "Uploaded",
    status: "Pending Review"
  }
];

const allowedTypes = ["New", "Follow-up", "Repeat", "Emergency", "Report Review"];
const allowedStatuses = [
  "Draft",
  "Pending Review",
  "Reviewed",
  "Delivered",
  "Cancelled"
];
const allowedUploads = ["No Upload", "Uploaded", "Reviewed"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultPrescriptions, null, 2));
  }
};

const readPrescriptions = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const prescriptions = JSON.parse(rawData);
    return Array.isArray(prescriptions) ? prescriptions : defaultPrescriptions;
  } catch {
    return defaultPrescriptions;
  }
};

const writePrescriptions = (prescriptions) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(prescriptions, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchPrescriptions = (prescriptions, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return prescriptions;

  return prescriptions.filter((item) =>
    [
      item.id,
      item.rxNo,
      item.patientId,
      item.patientName,
      item.phone,
      item.doctorName,
      item.specialization,
      item.prescriptionDate,
      item.type,
      item.status,
      item.uploadStatus,
      item.diagnosis,
      item.medicines,
      item.dosageNote,
      item.advice,
      item.followUpDate,
      item.uploadName
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterPrescriptions = (prescriptions, reqQuery) => {
  let result = [...prescriptions];

  result = searchPrescriptions(result, reqQuery.q);

  const doctor = cleanText(reqQuery.doctor);
  const specialization = cleanText(reqQuery.specialization);
  const status = cleanText(reqQuery.status);
  const type = cleanText(reqQuery.type);
  const uploadStatus = cleanText(reqQuery.uploadStatus);

  if (doctor) result = result.filter((item) => item.doctorName === doctor);
  if (specialization) {
    result = result.filter((item) => item.specialization === specialization);
  }
  if (status) result = result.filter((item) => item.status === status);
  if (type) result = result.filter((item) => item.type === type);
  if (uploadStatus) {
    result = result.filter((item) => item.uploadStatus === uploadStatus);
  }

  return result;
};

router.get("/", (req, res) => {
  const prescriptions = readPrescriptions();
  const filteredPrescriptions = filterPrescriptions(prescriptions, req.query);

  return res.json({ prescriptions: filteredPrescriptions });
});

router.post("/", (req, res) => {
  const prescriptions = readPrescriptions();

  const patientId = cleanText(req.body && req.body.patientId);
  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const doctorName = cleanText(req.body && req.body.doctorName);
  const specialization = cleanText(req.body && req.body.specialization);
  const prescriptionDate = cleanText(req.body && req.body.prescriptionDate);
  const type = cleanText(req.body && req.body.type) || "New";
  const diagnosis = cleanText(req.body && req.body.diagnosis);
  const medicines = cleanText(req.body && req.body.medicines);
  const dosageNote = cleanText(req.body && req.body.dosageNote);
  const advice = cleanText(req.body && req.body.advice);
  const followUpDate =
    cleanText(req.body && req.body.followUpDate) || "Not scheduled";
  const uploadName = cleanText(req.body && req.body.uploadName);
  const uploadStatus = cleanText(req.body && req.body.uploadStatus) || "No Upload";
  const status = cleanText(req.body && req.body.status) || "Draft";

  if (
    !patientId ||
    !patientName ||
    !phone ||
    !doctorName ||
    !specialization ||
    !prescriptionDate ||
    !diagnosis ||
    !medicines ||
    !dosageNote ||
    !advice
  ) {
    return res.status(400).json({
      message:
        "Patient, doctor, date, diagnosis, medicines, dosage and advice are required"
    });
  }

  if (!allowedTypes.includes(type)) {
    return res.status(400).json({ message: "Invalid prescription type" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid prescription status" });
  }

  if (!allowedUploads.includes(uploadStatus)) {
    return res.status(400).json({ message: "Invalid upload status" });
  }

  const prescription = {
    id: `RX-ID-${Date.now()}`,
    rxNo: `RX-${String(prescriptions.length + 1).padStart(4, "0")}`,
    patientId,
    patientName,
    phone,
    doctorName,
    specialization,
    prescriptionDate,
    type,
    diagnosis,
    medicines,
    dosageNote,
    advice,
    followUpDate,
    uploadName,
    uploadStatus,
    status
  };

  const nextPrescriptions = [prescription, ...prescriptions];
  writePrescriptions(nextPrescriptions);

  return res.status(201).json({ prescription });
});

router.patch("/:id/status", (req, res) => {
  const prescriptions = readPrescriptions();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid prescription status"
    });
  }

  const foundPrescription = prescriptions.find((item) => item.id === id);

  if (!foundPrescription) {
    return res.status(404).json({
      message: "Prescription not found"
    });
  }

  const nextPrescriptions = prescriptions.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writePrescriptions(nextPrescriptions);

  return res.json({
    prescription: nextPrescriptions.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const prescriptions = readPrescriptions();
  const id = cleanText(req.params.id);

  const foundPrescription = prescriptions.find((item) => item.id === id);

  if (!foundPrescription) {
    return res.status(404).json({
      message: "Prescription not found"
    });
  }

  const nextPrescriptions = prescriptions.filter((item) => item.id !== id);
  writePrescriptions(nextPrescriptions);

  return res.json({ success: true });
});

export default router;
