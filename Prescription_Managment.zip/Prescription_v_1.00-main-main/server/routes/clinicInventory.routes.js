import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-inventory.json");

const defaultItems = [
  {
    id: "INV-STK-ID-1001",
    sku: "MED-1001",
    name: "Napa 500mg",
    category: "Medicine",
    unit: "Strip",
    batchNo: "NP-26-01",
    supplier: "Beximco Pharma",
    expiryDate: "2027-01-20",
    purchasePrice: 12,
    salePrice: 15,
    stock: 240,
    reorderLevel: 40,
    location: "Pharmacy Rack A1",
    status: "In Stock",
    notes: "Common fever medicine.",
    movements: [
      {
        id: "MOV-1001",
        date: "2026-06-20",
        type: "Stock In",
        quantity: 240,
        note: "Opening stock",
        by: "Admin"
      }
    ]
  },
  {
    id: "INV-STK-ID-1002",
    sku: "SUP-1002",
    name: "Disposable Syringe 5ml",
    category: "Consumable",
    unit: "Piece",
    batchNo: "SYR-5ML-88",
    supplier: "Medical Supply House",
    expiryDate: "2028-03-10",
    purchasePrice: 4,
    salePrice: 8,
    stock: 18,
    reorderLevel: 50,
    location: "Store Room B2",
    status: "Low Stock",
    notes: "Injection supply item.",
    movements: []
  }
];

const allowedCategories = [
  "Medicine",
  "Consumable",
  "Equipment",
  "Reagent",
  "Stationery",
  "Other"
];

const allowedStatuses = [
  "In Stock",
  "Low Stock",
  "Out of Stock",
  "Expired",
  "Inactive"
];

const allowedMovementTypes = ["Stock In", "Stock Out", "Damage", "Return"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultItems, null, 2));
  }
};

const readItems = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const items = JSON.parse(rawData);
    return Array.isArray(items) ? items : defaultItems;
  } catch {
    return defaultItems;
  }
};

const writeItems = (items) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(items, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const isExpired = (date) => {
  const text = cleanText(date);
  if (!text) return false;

  const expiry = new Date(`${text}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return !Number.isNaN(expiry.getTime()) && expiry < today;
};

const getStockStatus = (stock, reorderLevel, expiryDate, previousStatus) => {
  if (previousStatus === "Inactive") return "Inactive";
  if (isExpired(expiryDate)) return "Expired";
  if (Number(stock || 0) <= 0) return "Out of Stock";
  if (Number(stock || 0) <= Number(reorderLevel || 0)) return "Low Stock";
  return "In Stock";
};

const searchItems = (items, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return items;

  return items.filter((item) =>
    [
      item.id,
      item.sku,
      item.name,
      item.category,
      item.unit,
      item.batchNo,
      item.supplier,
      item.expiryDate,
      item.location,
      item.status,
      item.notes
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterItems = (items, reqQuery) => {
  let result = [...items];

  result = searchItems(result, reqQuery.q);

  const category = cleanText(reqQuery.category);
  const status = cleanText(reqQuery.status);
  const supplier = cleanText(reqQuery.supplier);
  const location = cleanText(reqQuery.location);

  if (category) result = result.filter((item) => item.category === category);
  if (status) result = result.filter((item) => item.status === status);
  if (supplier) result = result.filter((item) => item.supplier === supplier);
  if (location) result = result.filter((item) => item.location === location);

  return result;
};

router.get("/", (req, res) => {
  const items = readItems();
  const filteredItems = filterItems(items, req.query);

  return res.json({ items: filteredItems });
});

router.post("/", (req, res) => {
  const items = readItems();

  const sku = cleanText(req.body && req.body.sku);
  const name = cleanText(req.body && req.body.name);
  const category = cleanText(req.body && req.body.category) || "Medicine";
  const unit = cleanText(req.body && req.body.unit);
  const batchNo = cleanText(req.body && req.body.batchNo);
  const supplier = cleanText(req.body && req.body.supplier);
  const expiryDate = cleanText(req.body && req.body.expiryDate);
  const purchasePrice = Number(req.body && req.body.purchasePrice);
  const salePrice = Number(req.body && req.body.salePrice);
  const stock = Number(req.body && req.body.stock);
  const reorderLevel = Number(req.body && req.body.reorderLevel);
  const location = cleanText(req.body && req.body.location);
  const notes = cleanText(req.body && req.body.notes) || "No inventory note";

  if (
    !sku ||
    !name ||
    !unit ||
    !batchNo ||
    !supplier ||
    !expiryDate ||
    !location ||
    !Number.isFinite(purchasePrice) ||
    purchasePrice < 0 ||
    !Number.isFinite(salePrice) ||
    salePrice < 0 ||
    !Number.isFinite(stock) ||
    stock < 0 ||
    !Number.isFinite(reorderLevel) ||
    reorderLevel < 0
  ) {
    return res.status(400).json({
      message:
        "SKU, name, unit, batch, supplier, expiry, location, price and stock are required"
    });
  }

  if (!allowedCategories.includes(category)) {
    return res.status(400).json({ message: "Invalid inventory category" });
  }

  const exists = items.some(
    (item) => item.sku.toLowerCase() === sku.toLowerCase()
  );

  if (exists) {
    return res.status(409).json({ message: "SKU already exists" });
  }

  const item = {
    id: `INV-STK-ID-${Date.now()}`,
    sku,
    name,
    category,
    unit,
    batchNo,
    supplier,
    expiryDate,
    purchasePrice,
    salePrice,
    stock,
    reorderLevel,
    location,
    status: getStockStatus(stock, reorderLevel, expiryDate),
    notes,
    movements: [
      {
        id: `MOV-${Date.now()}`,
        date: new Date().toISOString().slice(0, 10),
        type: "Stock In",
        quantity: stock,
        note: "Opening stock",
        by: "Admin"
      }
    ]
  };

  const nextItems = [item, ...items];
  writeItems(nextItems);

  return res.status(201).json({ item });
});

router.patch("/:id/status", (req, res) => {
  const items = readItems();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid inventory status"
    });
  }

  const foundItem = items.find((item) => item.id === id);

  if (!foundItem) {
    return res.status(404).json({
      message: "Inventory item not found"
    });
  }

  const nextItems = items.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writeItems(nextItems);

  return res.json({
    item: nextItems.find((item) => item.id === id)
  });
});

router.patch("/:id/stock", (req, res) => {
  const items = readItems();

  const id = cleanText(req.params.id);
  const date = cleanText(req.body && req.body.date);
  const type = cleanText(req.body && req.body.type);
  const quantity = Number(req.body && req.body.quantity);
  const note = cleanText(req.body && req.body.note);
  const by = cleanText(req.body && req.body.by) || "Admin";

  if (
    !date ||
    !allowedMovementTypes.includes(type) ||
    !Number.isFinite(quantity) ||
    quantity <= 0 ||
    !note
  ) {
    return res.status(400).json({
      message: "Date, valid type, quantity and note are required"
    });
  }

  const foundItem = items.find((item) => item.id === id);

  if (!foundItem) {
    return res.status(404).json({
      message: "Inventory item not found"
    });
  }

  const movement = {
    id: `MOV-${Date.now()}`,
    date,
    type,
    quantity,
    note,
    by
  };

  const signedQuantity =
    type === "Stock In" || type === "Return" ? quantity : -quantity;

  const nextItems = items.map((item) => {
    if (item.id !== id) return item;

    const nextStock = Math.max(0, Number(item.stock || 0) + signedQuantity);

    return {
      ...item,
      stock: nextStock,
      status: getStockStatus(
        nextStock,
        item.reorderLevel,
        item.expiryDate,
        item.status === "Inactive" ? "Inactive" : undefined
      ),
      movements: [movement, ...(item.movements || [])]
    };
  });

  writeItems(nextItems);

  return res.json({
    item: nextItems.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const items = readItems();
  const id = cleanText(req.params.id);

  const foundItem = items.find((item) => item.id === id);

  if (!foundItem) {
    return res.status(404).json({
      message: "Inventory item not found"
    });
  }

  const nextItems = items.filter((item) => item.id !== id);
  writeItems(nextItems);

  return res.json({ success: true });
});

export default router;
