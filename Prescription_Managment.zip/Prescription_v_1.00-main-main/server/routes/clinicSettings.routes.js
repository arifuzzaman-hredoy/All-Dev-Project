import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-settings.json");

const defaultSettings = {
  profile: {
    clinicName: "Update Clinic",
    tenantName: "Update Diagnostic Center",
    ownerName: "Clinic Owner",
    phone: "+8801711000000",
    email: "admin@updateclinic.test",
    address: "Rangpur, Bangladesh",
    licenseNo: "DGHS-CLINIC-1001",
    timezone: "Asia/Dhaka",
    currency: "BDT"
  },
  branding: {
    logoUrl: "/logo.png",
    primaryColor: "#0f766e",
    secondaryColor: "#ecfeff",
    footerText: "Powered by TechTeam",
    invoicePrefix: "INV",
    prescriptionPrefix: "RX"
  },
  notifications: {
    appointmentSms: true,
    prescriptionSms: true,
    billingSms: true,
    emailAlerts: false,
    adminPush: true,
    lowSmsBalanceAlert: true
  },
  modules: [
    {
      key: "appointments",
      label: "Appointments",
      description: "Booking, queue and visit schedule.",
      enabled: true
    },
    {
      key: "patients",
      label: "Patients",
      description: "Patient registry and medical profile.",
      enabled: true
    },
    {
      key: "doctors",
      label: "Doctors",
      description: "Doctor profile and chamber settings.",
      enabled: true
    },
    {
      key: "prescriptions",
      label: "Prescriptions",
      description: "RX records, uploads and review.",
      enabled: true
    },
    {
      key: "billing",
      label: "Billing",
      description: "Invoices, due and collections.",
      enabled: true
    },
    {
      key: "payments",
      label: "Payments",
      description: "Receipts, refunds and settlements.",
      enabled: true
    },
    {
      key: "smsWallet",
      label: "SMS Wallet",
      description: "SMS balance, recharge and usage.",
      enabled: true
    },
    {
      key: "reports",
      label: "Reports",
      description: "Visits, revenue and trend reports.",
      enabled: true
    }
  ],
  roles: [
    {
      key: "Owner",
      description: "Full system access and subscription control.",
      enabled: true,
      users: 1,
      permissions: ["All Modules", "Billing", "Settings", "Users"]
    },
    {
      key: "Admin",
      description: "Clinic operation and admin panel control.",
      enabled: true,
      users: 2,
      permissions: ["Appointments", "Patients", "Doctors", "Reports"]
    },
    {
      key: "Doctor",
      description: "Patient visits, encounter and prescription access.",
      enabled: true,
      users: 4,
      permissions: ["Patients", "Encounters", "Prescriptions"]
    },
    {
      key: "Reception",
      description: "Front desk appointment and payment collection.",
      enabled: true,
      users: 3,
      permissions: ["Appointments", "Patients", "Billing"]
    },
    {
      key: "Accounts",
      description: "Billing, payments and ledger management.",
      enabled: true,
      users: 1,
      permissions: ["Billing", "Payments", "Ledger", "Reports"]
    }
  ]
};

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultSettings, null, 2));
  }
};

const readSettings = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const settings = JSON.parse(rawData);

    return {
      ...defaultSettings,
      ...settings,
      profile: {
        ...defaultSettings.profile,
        ...(settings.profile || {})
      },
      branding: {
        ...defaultSettings.branding,
        ...(settings.branding || {})
      },
      notifications: {
        ...defaultSettings.notifications,
        ...(settings.notifications || {})
      },
      modules: Array.isArray(settings.modules)
        ? settings.modules
        : defaultSettings.modules,
      roles: Array.isArray(settings.roles)
        ? settings.roles
        : defaultSettings.roles
    };
  } catch {
    return defaultSettings;
  }
};

const writeSettings = (settings) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(settings, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const cleanKey = (value) => cleanText(value);

const cleanPermissions = (permissions) => {
  if (Array.isArray(permissions)) {
    return permissions.map((item) => cleanText(item)).filter(Boolean);
  }

  return cleanText(permissions)
    .split(",")
    .map((item) => cleanText(item))
    .filter(Boolean);
};

const cleanProfile = (profile = {}) => ({
  clinicName: cleanText(profile.clinicName) || defaultSettings.profile.clinicName,
  tenantName: cleanText(profile.tenantName) || defaultSettings.profile.tenantName,
  ownerName: cleanText(profile.ownerName) || defaultSettings.profile.ownerName,
  phone: cleanText(profile.phone) || defaultSettings.profile.phone,
  email: cleanText(profile.email) || defaultSettings.profile.email,
  address: cleanText(profile.address) || defaultSettings.profile.address,
  licenseNo: cleanText(profile.licenseNo) || defaultSettings.profile.licenseNo,
  timezone: cleanText(profile.timezone) || defaultSettings.profile.timezone,
  currency: cleanText(profile.currency) || defaultSettings.profile.currency
});

const cleanBranding = (branding = {}) => ({
  logoUrl: cleanText(branding.logoUrl) || defaultSettings.branding.logoUrl,
  primaryColor:
    cleanText(branding.primaryColor) || defaultSettings.branding.primaryColor,
  secondaryColor:
    cleanText(branding.secondaryColor) || defaultSettings.branding.secondaryColor,
  footerText:
    cleanText(branding.footerText) || defaultSettings.branding.footerText,
  invoicePrefix:
    cleanText(branding.invoicePrefix) || defaultSettings.branding.invoicePrefix,
  prescriptionPrefix:
    cleanText(branding.prescriptionPrefix) ||
    defaultSettings.branding.prescriptionPrefix
});

const cleanNotifications = (notifications = {}) => ({
  appointmentSms: Boolean(notifications.appointmentSms),
  prescriptionSms: Boolean(notifications.prescriptionSms),
  billingSms: Boolean(notifications.billingSms),
  emailAlerts: Boolean(notifications.emailAlerts),
  adminPush: Boolean(notifications.adminPush),
  lowSmsBalanceAlert: Boolean(notifications.lowSmsBalanceAlert)
});

const cleanRole = (role = {}) => ({
  key: cleanKey(role.key),
  description: cleanText(role.description),
  enabled: Boolean(role.enabled),
  users: Number.isFinite(Number(role.users)) ? Number(role.users) : 0,
  permissions: cleanPermissions(role.permissions)
});

const cleanModule = (module = {}) => ({
  key: cleanKey(module.key),
  label: cleanText(module.label),
  description: cleanText(module.description),
  enabled: Boolean(module.enabled)
});

router.get("/", (req, res) => {
  const settings = readSettings();

  return res.json({ settings });
});

router.patch("/", (req, res) => {
  const currentSettings = readSettings();
  const body = req.body || {};

  const nextSettings = {
    ...currentSettings,
    profile: cleanProfile(body.profile || currentSettings.profile),
    branding: cleanBranding(body.branding || currentSettings.branding),
    notifications: cleanNotifications(
      body.notifications || currentSettings.notifications
    ),
    modules: Array.isArray(body.modules)
      ? body.modules.map(cleanModule).filter((item) => item.key && item.label)
      : currentSettings.modules,
    roles: Array.isArray(body.roles)
      ? body.roles.map(cleanRole).filter((item) => item.key)
      : currentSettings.roles
  };

  writeSettings(nextSettings);

  return res.json({ settings: nextSettings });
});

router.post("/roles", (req, res) => {
  const settings = readSettings();
  const role = cleanRole(req.body || {});

  if (!role.key || !role.description || role.permissions.length <= 0) {
    return res.status(400).json({
      message: "Role name, description and permissions are required"
    });
  }

  const exists = settings.roles.some(
    (item) => item.key.toLowerCase() === role.key.toLowerCase()
  );

  if (exists) {
    return res.status(409).json({
      message: "Role already exists"
    });
  }

  const nextSettings = {
    ...settings,
    roles: [role, ...settings.roles]
  };

  writeSettings(nextSettings);

  return res.status(201).json({ settings: nextSettings });
});

router.patch("/roles/:key", (req, res) => {
  const settings = readSettings();
  const key = cleanText(req.params.key);

  const foundRole = settings.roles.find((item) => item.key === key);

  if (!foundRole) {
    return res.status(404).json({ message: "Role not found" });
  }

  const body = req.body || {};

  const nextSettings = {
    ...settings,
    roles: settings.roles.map((item) =>
      item.key === key
        ? {
            ...item,
            description:
              body.description === undefined
                ? item.description
                : cleanText(body.description),
            enabled:
              body.enabled === undefined ? item.enabled : Boolean(body.enabled),
            users:
              body.users === undefined
                ? item.users
                : Number.isFinite(Number(body.users))
                  ? Number(body.users)
                  : item.users,
            permissions:
              body.permissions === undefined
                ? item.permissions
                : cleanPermissions(body.permissions)
          }
        : item
    )
  };

  writeSettings(nextSettings);

  return res.json({ settings: nextSettings });
});

router.delete("/roles/:key", (req, res) => {
  const settings = readSettings();
  const key = cleanText(req.params.key);

  const foundRole = settings.roles.find((item) => item.key === key);

  if (!foundRole) {
    return res.status(404).json({ message: "Role not found" });
  }

  const nextSettings = {
    ...settings,
    roles: settings.roles.filter((item) => item.key !== key)
  };

  writeSettings(nextSettings);

  return res.json({ settings: nextSettings });
});

router.post("/modules", (req, res) => {
  const settings = readSettings();
  const module = cleanModule(req.body || {});

  if (!module.key || !module.label || !module.description) {
    return res.status(400).json({
      message: "Module key, label and description are required"
    });
  }

  const exists = settings.modules.some(
    (item) => item.key.toLowerCase() === module.key.toLowerCase()
  );

  if (exists) {
    return res.status(409).json({
      message: "Module already exists"
    });
  }

  const nextSettings = {
    ...settings,
    modules: [module, ...settings.modules]
  };

  writeSettings(nextSettings);

  return res.status(201).json({ settings: nextSettings });
});

router.patch("/modules/:key", (req, res) => {
  const settings = readSettings();
  const key = cleanText(req.params.key);

  const foundModule = settings.modules.find((item) => item.key === key);

  if (!foundModule) {
    return res.status(404).json({ message: "Module not found" });
  }

  const body = req.body || {};

  const nextSettings = {
    ...settings,
    modules: settings.modules.map((item) =>
      item.key === key
        ? {
            ...item,
            label:
              body.label === undefined ? item.label : cleanText(body.label),
            description:
              body.description === undefined
                ? item.description
                : cleanText(body.description),
            enabled:
              body.enabled === undefined ? item.enabled : Boolean(body.enabled)
          }
        : item
    )
  };

  writeSettings(nextSettings);

  return res.json({ settings: nextSettings });
});

router.delete("/modules/:key", (req, res) => {
  const settings = readSettings();
  const key = cleanText(req.params.key);

  const foundModule = settings.modules.find((item) => item.key === key);

  if (!foundModule) {
    return res.status(404).json({ message: "Module not found" });
  }

  const nextSettings = {
    ...settings,
    modules: settings.modules.filter((item) => item.key !== key)
  };

  writeSettings(nextSettings);

  return res.json({ settings: nextSettings });
});

export default router;
