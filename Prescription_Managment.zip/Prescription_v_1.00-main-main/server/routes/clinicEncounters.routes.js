import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-encounters.json");

const defaultEncounters = [
  {
    id: "ENC-ID-1001",
    encounterNo: "ENC-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    visitDate: "2026-06-20",
    visitTime: "09:30 AM",
    encounterType: "Follow-up",
    chiefComplaint: "Headache follow-up and sleep issue",
    diagnosis: "Migraine follow-up",
    vitals: "BP 120/80, Pulse 78, Temp 98.4°F",
    prescriptionNote: "Continue medicine, hydration, sleep routine",
    labNote: "No new lab advised",
    followUpDate: "2026-07-05",
    status: "Follow-up",
    priority: "Normal"
  },
  {
    id: "ENC-ID-1002",
    encounterNo: "ENC-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    specialization: "Cardiology",
    visitDate: "2026-06-20",
    visitTime: "10:15 AM",
    encounterType: "Consultation",
    chiefComplaint: "Chest discomfort and high blood pressure",
    diagnosis: "Hypertension observation",
    vitals: "BP 150/95, Pulse 88, SpO2 98%",
    prescriptionNote: "BP monitoring, medicine adjustment",
    labNote: "ECG and lipid profile advised",
    followUpDate: "2026-06-27",
    status: "In Progress",
    priority: "Urgent"
  }
];

const allowedTypes = ["Consultation", "Follow-up", "Emergency", "Report Review"];
const allowedStatuses = ["Open", "In Progress", "Completed", "Follow-up", "Cancelled"];
const allowedPriorities = ["Normal", "Urgent", "Critical"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultEncounters, null, 2));
  }
};

const readEncounters = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const encounters = JSON.parse(rawData);
    return Array.isArray(encounters) ? encounters : defaultEncounters;
  } catch {
    return defaultEncounters;
  }
};

const writeEncounters = (encounters) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(encounters, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchEncounters = (encounters, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return encounters;

  return encounters.filter((item) =>
    [
      item.id,
      item.encounterNo,
      item.patientId,
      item.patientName,
      item.phone,
      item.doctorName,
      item.specialization,
      item.visitDate,
      item.visitTime,
      item.encounterType,
      item.status,
      item.priority,
      item.chiefComplaint,
      item.diagnosis,
      item.vitals,
      item.prescriptionNote,
      item.labNote,
      item.followUpDate
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterEncounters = (encounters, reqQuery) => {
  let result = [...encounters];

  result = searchEncounters(result, reqQuery.q);

  const doctor = cleanText(reqQuery.doctor);
  const specialization = cleanText(reqQuery.specialization);
  const status = cleanText(reqQuery.status);
  const type = cleanText(reqQuery.type);
  const priority = cleanText(reqQuery.priority);

  if (doctor) result = result.filter((item) => item.doctorName === doctor);
  if (specialization) {
    result = result.filter((item) => item.specialization === specialization);
  }
  if (status) result = result.filter((item) => item.status === status);
  if (type) result = result.filter((item) => item.encounterType === type);
  if (priority) result = result.filter((item) => item.priority === priority);

  return result;
};

router.get("/", (req, res) => {
  const encounters = readEncounters();
  const filteredEncounters = filterEncounters(encounters, req.query);

  return res.json({ encounters: filteredEncounters });
});

router.post("/", (req, res) => {
  const encounters = readEncounters();

  const patientId = cleanText(req.body && req.body.patientId);
  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const doctorName = cleanText(req.body && req.body.doctorName);
  const specialization = cleanText(req.body && req.body.specialization);
  const visitDate = cleanText(req.body && req.body.visitDate);
  const visitTime = cleanText(req.body && req.body.visitTime);
  const encounterType = cleanText(req.body && req.body.encounterType) || "Consultation";
  const chiefComplaint = cleanText(req.body && req.body.chiefComplaint);
  const diagnosis = cleanText(req.body && req.body.diagnosis);
  const vitals = cleanText(req.body && req.body.vitals);
  const prescriptionNote = cleanText(req.body && req.body.prescriptionNote);
  const labNote = cleanText(req.body && req.body.labNote) || "No lab note";
  const followUpDate = cleanText(req.body && req.body.followUpDate) || "Not scheduled";
  const status = cleanText(req.body && req.body.status) || "Open";
  const priority = cleanText(req.body && req.body.priority) || "Normal";

  if (
    !patientId ||
    !patientName ||
    !phone ||
    !doctorName ||
    !specialization ||
    !visitDate ||
    !visitTime ||
    !chiefComplaint ||
    !diagnosis ||
    !vitals ||
    !prescriptionNote
  ) {
    return res.status(400).json({
      message:
        "Patient, doctor, visit, complaint, diagnosis, vitals and prescription note are required"
    });
  }

  if (!allowedTypes.includes(encounterType)) {
    return res.status(400).json({ message: "Invalid encounter type" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid encounter status" });
  }

  if (!allowedPriorities.includes(priority)) {
    return res.status(400).json({ message: "Invalid encounter priority" });
  }

  const encounter = {
    id: `ENC-ID-${Date.now()}`,
    encounterNo: `ENC-${String(encounters.length + 1).padStart(4, "0")}`,
    patientId,
    patientName,
    phone,
    doctorName,
    specialization,
    visitDate,
    visitTime,
    encounterType,
    chiefComplaint,
    diagnosis,
    vitals,
    prescriptionNote,
    labNote,
    followUpDate,
    status,
    priority
  };

  const nextEncounters = [encounter, ...encounters];
  writeEncounters(nextEncounters);

  return res.status(201).json({ encounter });
});

router.patch("/:id/status", (req, res) => {
  const encounters = readEncounters();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid encounter status"
    });
  }

  const foundEncounter = encounters.find((item) => item.id === id);

  if (!foundEncounter) {
    return res.status(404).json({
      message: "Encounter not found"
    });
  }

  const nextEncounters = encounters.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writeEncounters(nextEncounters);

  return res.json({
    encounter: nextEncounters.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const encounters = readEncounters();
  const id = cleanText(req.params.id);

  const foundEncounter = encounters.find((item) => item.id === id);

  if (!foundEncounter) {
    return res.status(404).json({
      message: "Encounter not found"
    });
  }

  const nextEncounters = encounters.filter((item) => item.id !== id);
  writeEncounters(nextEncounters);

  return res.json({ success: true });
});

export default router;
