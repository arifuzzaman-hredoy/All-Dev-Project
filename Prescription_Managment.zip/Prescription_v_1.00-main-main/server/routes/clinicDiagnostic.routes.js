import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-diagnostic-orders.json");

const defaultOrders = [
  {
    id: "LAB-ID-1001",
    orderNo: "LAB-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    department: "Pathology",
    orderDate: "2026-06-20",
    deliveryDate: "2026-06-21",
    tests: ["CBC", "ESR", "Blood Sugar Fasting"],
    sampleType: "Blood",
    sampleStatus: "Collected",
    priority: "Routine",
    status: "In Lab",
    paymentStatus: "Paid",
    amount: 1200,
    paidAmount: 1200,
    labNote: "Sample received and processing.",
  },
  {
    id: "LAB-ID-1002",
    orderNo: "LAB-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    department: "Radiology",
    orderDate: "2026-06-20",
    deliveryDate: "2026-06-20",
    tests: ["ECG", "Chest X-Ray"],
    sampleType: "Imaging",
    sampleStatus: "Not Collected",
    priority: "Urgent",
    status: "Ordered",
    paymentStatus: "Partial",
    amount: 1800,
    paidAmount: 900,
    labNote: "Patient waiting for sample/imaging room.",
  },
];

const allowedStatuses = [
  "Draft",
  "Ordered",
  "Sample Collected",
  "In Lab",
  "Report Ready",
  "Delivered",
  "Cancelled",
];
const allowedSampleStatuses = ["Not Collected", "Collected", "Rejected"];
const allowedPriorities = ["Routine", "Urgent", "Critical"];
const allowedPayments = ["Paid", "Due", "Partial"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultOrders, null, 2));
  }
};

const readOrders = () => {
  ensureDataFile();
  try {
    const data = JSON.parse(fs.readFileSync(dataFile, "utf8"));
    return Array.isArray(data) ? data : defaultOrders;
  } catch {
    return defaultOrders;
  }
};

const writeOrders = (orders) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(orders, null, 2));
};

const cleanText = (value) => String(value || "").trim();
const toNumber = (value) => {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
};

const filterOrders = (orders, query) => {
  const searchText = cleanText(query.q).toLowerCase();
  const status = cleanText(query.status);
  const department = cleanText(query.department);
  const priority = cleanText(query.priority);
  const sampleStatus = cleanText(query.sampleStatus);
  const paymentStatus = cleanText(query.paymentStatus);

  return orders.filter((item) => {
    const matchedSearch =
      !searchText ||
      [
        item.id,
        item.orderNo,
        item.patientId,
        item.patientName,
        item.phone,
        item.doctorName,
        item.department,
        Array.isArray(item.tests) ? item.tests.join(" ") : "",
        item.sampleType,
        item.sampleStatus,
        item.priority,
        item.status,
        item.paymentStatus,
        item.labNote,
      ]
        .join(" ")
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!status || item.status === status) &&
      (!department || item.department === department) &&
      (!priority || item.priority === priority) &&
      (!sampleStatus || item.sampleStatus === sampleStatus) &&
      (!paymentStatus || item.paymentStatus === paymentStatus)
    );
  });
};

router.get("/", (req, res) => {
  return res.json({ orders: filterOrders(readOrders(), req.query) });
});

router.post("/", (req, res) => {
  const orders = readOrders();
  const patientId = cleanText(req.body?.patientId);
  const patientName = cleanText(req.body?.patientName);
  const phone = cleanText(req.body?.phone);
  const doctorName = cleanText(req.body?.doctorName);
  const department = cleanText(req.body?.department);
  const orderDate = cleanText(req.body?.orderDate);
  const deliveryDate = cleanText(req.body?.deliveryDate);
  const tests = Array.isArray(req.body?.tests)
    ? req.body.tests.map(cleanText).filter(Boolean)
    : cleanText(req.body?.tests)
        .split(",")
        .map(cleanText)
        .filter(Boolean);
  const sampleType = cleanText(req.body?.sampleType);
  const sampleStatus = cleanText(req.body?.sampleStatus) || "Not Collected";
  const priority = cleanText(req.body?.priority) || "Routine";
  const status = cleanText(req.body?.status) || "Ordered";
  const paymentStatus = cleanText(req.body?.paymentStatus) || "Due";
  const amount = toNumber(req.body?.amount);
  const paidAmount = toNumber(req.body?.paidAmount);
  const labNote = cleanText(req.body?.labNote);

  if (!patientId || !patientName || !phone || !doctorName || !department || !orderDate || !deliveryDate || !tests.length || !sampleType || amount < 0 || paidAmount < 0) {
    return res.status(400).json({ message: "Patient, doctor, dates, tests, sample type and amount are required" });
  }
  if (!allowedStatuses.includes(status)) return res.status(400).json({ message: "Invalid lab order status" });
  if (!allowedSampleStatuses.includes(sampleStatus)) return res.status(400).json({ message: "Invalid sample status" });
  if (!allowedPriorities.includes(priority)) return res.status(400).json({ message: "Invalid priority" });
  if (!allowedPayments.includes(paymentStatus)) return res.status(400).json({ message: "Invalid payment status" });

  const order = {
    id: `LAB-ID-${Date.now()}`,
    orderNo: `LAB-${String(orders.length + 1).padStart(4, "0")}`,
    patientId,
    patientName,
    phone,
    doctorName,
    department,
    orderDate,
    deliveryDate,
    tests,
    sampleType,
    sampleStatus,
    priority,
    status,
    paymentStatus,
    amount,
    paidAmount,
    labNote,
  };

  writeOrders([order, ...orders]);
  return res.status(201).json({ order });
});

router.patch("/:id/status", (req, res) => {
  const orders = readOrders();
  const status = cleanText(req.body?.status);
  if (!allowedStatuses.includes(status)) return res.status(400).json({ message: "Invalid lab order status" });
  const found = orders.find((item) => item.id === req.params.id);
  if (!found) return res.status(404).json({ message: "Lab order not found" });
  const next = orders.map((item) => (item.id === req.params.id ? { ...item, status } : item));
  writeOrders(next);
  return res.json({ order: next.find((item) => item.id === req.params.id) });
});

router.patch("/:id/sample", (req, res) => {
  const orders = readOrders();
  const sampleStatus = cleanText(req.body?.sampleStatus);
  if (!allowedSampleStatuses.includes(sampleStatus)) return res.status(400).json({ message: "Invalid sample status" });
  const found = orders.find((item) => item.id === req.params.id);
  if (!found) return res.status(404).json({ message: "Lab order not found" });
  const next = orders.map((item) =>
    item.id === req.params.id
      ? {
          ...item,
          sampleStatus,
          status: sampleStatus === "Collected" && item.status === "Ordered" ? "Sample Collected" : item.status,
        }
      : item,
  );
  writeOrders(next);
  return res.json({ order: next.find((item) => item.id === req.params.id) });
});

router.delete("/:id", (req, res) => {
  const orders = readOrders();
  const found = orders.find((item) => item.id === req.params.id);
  if (!found) return res.status(404).json({ message: "Lab order not found" });
  writeOrders(orders.filter((item) => item.id !== req.params.id));
  return res.json({ success: true });
});

export default router;
