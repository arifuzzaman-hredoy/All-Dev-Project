import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");

const files = {
  appointments: path.join(dataDir, "clinic-appointments.json"),
  billing: path.join(dataDir, "clinic-billing.json"),
  prescriptions: path.join(dataDir, "clinic-prescriptions.json"),
  patients: path.join(dataDir, "clinic-patients.json"),
  payments: path.join(dataDir, "clinic-payments.json")
};

const readJsonArray = (filePath, fallback = []) => {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const rawData = fs.readFileSync(filePath, "utf8");
    const data = JSON.parse(rawData);
    return Array.isArray(data) ? data : fallback;
  } catch {
    return fallback;
  }
};

const cleanText = (value) => String(value || "").trim();

const toDate = (value) => {
  const text = cleanText(value);
  if (!text || text === "No due" || text === "Not scheduled") return null;

  const date = new Date(`${text}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
};

const sameMonth = (date, now) =>
  date &&
  date.getFullYear() === now.getFullYear() &&
  date.getMonth() === now.getMonth();

const inRange = (value, range) => {
  if (!range || range === "All") return true;

  const date = toDate(value);
  if (!date) return false;

  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10);
  const dateKey = date.toISOString().slice(0, 10);

  if (range === "Today") return dateKey === todayKey;

  if (range === "This Month") return sameMonth(date, now);

  const days = range === "7 Days" ? 7 : 30;
  const cutoff = new Date(now);
  cutoff.setDate(now.getDate() - days);

  return date >= cutoff;
};

const formatDateLabel = (value) => {
  const date = toDate(value);
  if (!date) return "Unknown";

  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "2-digit"
  });
};

const matchesQuery = (item, query) => {
  const searchText = cleanText(query).toLowerCase();
  if (!searchText) return true;

  return Object.values(item)
    .join(" ")
    .toLowerCase()
    .includes(searchText);
};

const groupCount = (items, key) => {
  const map = {};

  items.forEach((item) => {
    const label = cleanText(item[key]) || "Unknown";
    map[label] = (map[label] || 0) + 1;
  });

  return Object.entries(map)
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value);
};

const groupAmount = (items, labelKey, amountKey) => {
  const map = {};

  items.forEach((item) => {
    const label = cleanText(item[labelKey]) || "Unknown";
    const amount = Number(item[amountKey] || 0);

    if (!map[label]) {
      map[label] = { label, value: 0, amount: 0 };
    }

    map[label].value += 1;
    map[label].amount += amount;
  });

  return Object.values(map).sort((a, b) => b.amount - a.amount);
};

const uniqueSorted = (items) =>
  Array.from(new Set(items.filter(Boolean))).sort((a, b) =>
    String(a).localeCompare(String(b))
  );

router.get("/", (req, res) => {
  const range = cleanText(req.query.range) || "30 Days";
  const doctor = cleanText(req.query.doctor);
  const specialization = cleanText(req.query.specialization);
  const q = cleanText(req.query.q);

  const appointmentsRaw = readJsonArray(files.appointments, []);
  const billingRaw = readJsonArray(files.billing, []);
  const prescriptionsRaw = readJsonArray(files.prescriptions, []);
  const patientsRaw = readJsonArray(files.patients, []);
  const paymentsRaw = readJsonArray(files.payments, []);

  const appointments = appointmentsRaw.filter(
    (item) =>
      inRange(item.appointmentDate, range) &&
      (!doctor || item.doctorName === doctor) &&
      (!specialization || item.specialization === specialization) &&
      matchesQuery(item, q)
  );

  const billing = billingRaw.filter(
    (item) =>
      inRange(item.billDate, range) &&
      (!doctor || item.doctorName === doctor) &&
      matchesQuery(item, q)
  );

  const prescriptions = prescriptionsRaw.filter(
    (item) =>
      inRange(item.prescriptionDate, range) &&
      (!doctor || item.doctorName === doctor) &&
      (!specialization || item.specialization === specialization) &&
      matchesQuery(item, q)
  );

  const patients = patientsRaw.filter(
    (item) =>
      inRange(item.lastVisit, range) &&
      (!doctor || item.assignedDoctor === doctor) &&
      matchesQuery(item, q)
  );

  const payments = paymentsRaw.filter(
    (item) => inRange(item.paymentDate, range) && matchesQuery(item, q)
  );

  const collection = payments
    .filter((item) => item.type === "Collection" && item.status === "Completed")
    .reduce((total, item) => total + Number(item.amount || 0), 0);

  const billingRevenue = billing.reduce(
    (total, item) => total + Number(item.paidAmount || 0),
    0
  );

  const revenue = collection || billingRevenue;

  const dueAmount = billing.reduce(
    (total, item) => total + Number(item.dueAmount || 0),
    0
  );

  const followUps =
    appointments.filter((item) => item.type === "Follow-up").length +
    prescriptions.filter((item) => item.type === "Follow-up").length +
    patients.filter((item) => item.status === "Follow-up").length;

  const dayMap = {};

  appointments.forEach((item) => {
    const label = formatDateLabel(item.appointmentDate);
    dayMap[label] = dayMap[label] || {
      label,
      visits: 0,
      revenue: 0,
      prescriptions: 0,
      patients: 0
    };
    dayMap[label].visits += 1;
  });

  payments.forEach((item) => {
    const label = formatDateLabel(item.paymentDate);
    dayMap[label] = dayMap[label] || {
      label,
      visits: 0,
      revenue: 0,
      prescriptions: 0,
      patients: 0
    };
    if (item.status === "Completed") {
      dayMap[label].revenue += Number(item.amount || 0);
    }
  });

  prescriptions.forEach((item) => {
    const label = formatDateLabel(item.prescriptionDate);
    dayMap[label] = dayMap[label] || {
      label,
      visits: 0,
      revenue: 0,
      prescriptions: 0,
      patients: 0
    };
    dayMap[label].prescriptions += 1;
  });

  patients.forEach((item) => {
    const label = formatDateLabel(item.lastVisit);
    dayMap[label] = dayMap[label] || {
      label,
      visits: 0,
      revenue: 0,
      prescriptions: 0,
      patients: 0
    };
    dayMap[label].patients += 1;
  });

  const visitTrends = Object.values(dayMap).slice(-14);

  const latestActivity = [
    ...appointments.map((item) => ({
      id: `VISIT-${item.id}`,
      date: item.appointmentDate || "Unknown",
      type: "Visit",
      title: `${item.patientName || "Patient"} appointment`,
      note: `${item.doctorName || "Doctor"} · ${item.status || "Status"}`
    })),
    ...payments.map((item) => ({
      id: `PAY-${item.id}`,
      date: item.paymentDate || "Unknown",
      type: "Revenue",
      title: `${item.receiptNo || "Receipt"} payment`,
      note: `${item.patientName || "Patient"} · ${item.method || "Method"}`,
      amount: Number(item.amount || 0)
    })),
    ...prescriptions.map((item) => ({
      id: `RX-${item.id}`,
      date: item.prescriptionDate || "Unknown",
      type: "Prescription",
      title: `${item.rxNo || "RX"} prescription`,
      note: `${item.patientName || "Patient"} · ${item.status || "Status"}`
    }))
  ]
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .slice(0, 10);

  const report = {
    summary: {
      visits: appointments.length,
      completedVisits: appointments.filter((item) => item.status === "Completed")
        .length,
      revenue,
      collection,
      dueAmount,
      prescriptions: prescriptions.length,
      patients: patients.length,
      followUps
    },
    visitTrends,
    visitsByDoctor: groupCount(appointments, "doctorName"),
    revenueByType: groupAmount(billing, "billType", "paidAmount"),
    prescriptionStatus: groupCount(prescriptions, "status"),
    patientStatus: groupCount(patients, "status"),
    latestActivity,
    doctorOptions: uniqueSorted([
      ...appointmentsRaw.map((item) => item.doctorName),
      ...prescriptionsRaw.map((item) => item.doctorName),
      ...patientsRaw.map((item) => item.assignedDoctor),
      ...billingRaw.map((item) => item.doctorName)
    ]),
    specializationOptions: uniqueSorted([
      ...appointmentsRaw.map((item) => item.specialization),
      ...prescriptionsRaw.map((item) => item.specialization)
    ])
  };

  return res.json({ report });
});

export default router;
