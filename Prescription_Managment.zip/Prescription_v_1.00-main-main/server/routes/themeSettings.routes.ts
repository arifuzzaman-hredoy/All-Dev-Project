import express from "express";
import { requireAdmin } from "../auth";
import {
  getThemeSettings,
  updateThemeSettings,
} from "../controllers/themeSettings.controller";

const router = express.Router();

router.get("/", getThemeSettings);
router.put("/", requireAdmin, updateThemeSettings);

export default router;
