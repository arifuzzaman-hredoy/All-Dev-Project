import express from "express";
import { requireAdmin } from "../auth";
import { prisma } from "../prisma";
import {
  getDoctorIdentity,
  getPublicDoctorIdentity,
  putDoctorIdentity,
  uploadDoctorIdentityPhoto,
} from "../controllers/doctorIdentity.controller";

const router = express.Router();
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const defaultAllowed = (role, action) => {
  if (role === "SUPER_ADMIN") return true;
  if (role === "DOCTOR") return true;
  return action === "view";
};

const requireIdentityPermission = (action) =>
  asyncHandler(async (req, res, next) => {
    const role = req.admin?.role || "STAFF";
    if (defaultAllowed(role, action) && role === "SUPER_ADMIN") return next();

    const permission = await prisma.accessPermission.findUnique({
      where: { role_feature: { role, feature: "doctor_profile" } },
    });
    const allowed =
      action === "view"
        ? permission?.canView ?? defaultAllowed(role, action)
        : action === "update"
          ? permission?.canUpdate ?? defaultAllowed(role, action)
          : permission?.canCreate ?? defaultAllowed(role, action);

    if (!allowed || permission?.restricted) {
      return res.status(403).json({ ok: false, message: "You do not have doctor identity permission." });
    }

    return next();
  });

router.get("/api/doctor/identity", requireAdmin, requireIdentityPermission("view"), asyncHandler(getDoctorIdentity));
router.put("/api/doctor/identity", requireAdmin, requireIdentityPermission("update"), asyncHandler(putDoctorIdentity));
router.post("/api/doctor/identity/photo", requireAdmin, requireIdentityPermission("photo"), asyncHandler(uploadDoctorIdentityPhoto));
router.get("/api/admin/site-identity", requireAdmin, requireIdentityPermission("view"), asyncHandler(getDoctorIdentity));
router.put("/api/admin/site-identity", requireAdmin, requireIdentityPermission("update"), asyncHandler(putDoctorIdentity));
router.get("/api/public/doctor-identity", asyncHandler(getPublicDoctorIdentity));

export default router;
