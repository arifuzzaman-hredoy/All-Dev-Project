import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-appointments.json");

const defaultAppointments = [
  {
    id: "APT-1001",
    tokenNo: "T-01",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    email: "nusrat.patient@demo.com",
    age: 32,
    gender: "Female",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    appointmentDate: "2026-06-20",
    appointmentTime: "09:30 AM",
    type: "Follow-up",
    status: "Waiting",
    problem: "Appointment and billing follow-up",
    fee: 700,
    paymentStatus: "Paid",
  },
  {
    id: "APT-1002",
    tokenNo: "T-02",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    email: "rafiqul.patient@demo.com",
    age: 45,
    gender: "Male",
    doctorName: "Dr. Nusrat Jahan",
    specialization: "Gynecology",
    appointmentDate: "2026-06-20",
    appointmentTime: "10:15 AM",
    type: "Report Review",
    status: "Checked In",
    problem: "Prescription review pending",
    fee: 900,
    paymentStatus: "Partial",
  },
];

const allowedTypes = ["New", "Follow-up", "Report Review", "Emergency"];
const allowedStatuses = [
  "Waiting",
  "Checked In",
  "Completed",
  "Cancelled",
  "No Show",
];
const allowedPayments = ["Paid", "Due", "Partial"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultAppointments, null, 2));
  }
};

const readAppointments = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const appointments = JSON.parse(rawData);
    return Array.isArray(appointments) ? appointments : defaultAppointments;
  } catch {
    return defaultAppointments;
  }
};

const writeAppointments = (appointments) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(appointments, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchAppointments = (appointments, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return appointments;

  return appointments.filter((item) =>
    [
      item.id,
      item.tokenNo,
      item.patientName,
      item.phone,
      item.email,
      item.doctorName,
      item.specialization,
      item.type,
      item.status,
      item.problem,
      item.paymentStatus,
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText),
  );
};

const filterAppointments = (appointments, reqQuery) => {
  let result = [...appointments];

  result = searchAppointments(result, reqQuery.q);

  const doctor = cleanText(reqQuery.doctor);
  const specialization = cleanText(reqQuery.specialization);
  const status = cleanText(reqQuery.status);
  const type = cleanText(reqQuery.type);

  if (doctor) result = result.filter((item) => item.doctorName === doctor);
  if (specialization) {
    result = result.filter((item) => item.specialization === specialization);
  }
  if (status) result = result.filter((item) => item.status === status);
  if (type) result = result.filter((item) => item.type === type);

  return result;
};

router.get("/", (req, res) => {
  const appointments = readAppointments();
  const filteredAppointments = filterAppointments(appointments, req.query);

  return res.json({ appointments: filteredAppointments });
});

router.post("/", (req, res) => {
  const appointments = readAppointments();

  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const email = cleanText(req.body && req.body.email).toLowerCase();
  const age = Number(req.body && req.body.age);
  const gender = cleanText(req.body && req.body.gender);
  const doctorName = cleanText(req.body && req.body.doctorName);
  const specialization = cleanText(req.body && req.body.specialization);
  const appointmentDate = cleanText(req.body && req.body.appointmentDate);
  const appointmentTime = cleanText(req.body && req.body.appointmentTime);
  const type = cleanText(req.body && req.body.type) || "New";
  const status = cleanText(req.body && req.body.status) || "Waiting";
  const problem = cleanText(req.body && req.body.problem);
  const fee = Number(req.body && req.body.fee);
  const paymentStatus = cleanText(req.body && req.body.paymentStatus) || "Due";

  if (
    !patientName ||
    !phone ||
    !Number.isFinite(age) ||
    age <= 0 ||
    !gender ||
    !doctorName ||
    !specialization ||
    !appointmentDate ||
    !appointmentTime ||
    !problem ||
    !Number.isFinite(fee) ||
    fee < 0
  ) {
    return res.status(400).json({
      message:
        "Patient, phone, age, gender, doctor, speciality, date, time, problem and fee are required",
    });
  }

  if (!allowedTypes.includes(type)) {
    return res.status(400).json({ message: "Invalid appointment type" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid appointment status" });
  }

  if (!allowedPayments.includes(paymentStatus)) {
    return res.status(400).json({ message: "Invalid payment status" });
  }

  const appointment = {
    id: `APT-${Date.now()}`,
    tokenNo: `T-${String(appointments.length + 1).padStart(2, "0")}`,
    patientName,
    phone,
    email,
    age,
    gender,
    doctorName,
    specialization,
    appointmentDate,
    appointmentTime,
    type,
    status,
    problem,
    fee,
    paymentStatus,
  };

  const nextAppointments = [appointment, ...appointments];
  writeAppointments(nextAppointments);

  return res.status(201).json({ appointment });
});

router.patch("/:id/status", (req, res) => {
  const appointments = readAppointments();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid appointment status",
    });
  }

  const foundAppointment = appointments.find((item) => item.id === id);

  if (!foundAppointment) {
    return res.status(404).json({
      message: "Appointment not found",
    });
  }

  const nextAppointments = appointments.map((item) =>
    item.id === id ? { ...item, status } : item,
  );

  writeAppointments(nextAppointments);

  return res.json({
    appointment: nextAppointments.find((item) => item.id === id),
  });
});

router.delete("/:id", (req, res) => {
  const appointments = readAppointments();
  const id = cleanText(req.params.id);

  const foundAppointment = appointments.find((item) => item.id === id);

  if (!foundAppointment) {
    return res.status(404).json({
      message: "Appointment not found",
    });
  }

  const nextAppointments = appointments.filter((item) => item.id !== id);
  writeAppointments(nextAppointments);

  return res.json({ success: true });
});

export default router;
