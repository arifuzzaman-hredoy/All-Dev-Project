import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-billing.json");

const defaultInvoices = [
  {
    id: "INV-ID-1001",
    invoiceNo: "INV-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    billDate: "2026-06-20",
    billType: "Consultation",
    subtotal: 1000,
    discount: 100,
    paidAmount: 900,
    dueAmount: 0,
    paymentMethod: "Cash",
    status: "Paid",
    notes: "Consultation fee collected."
  },
  {
    id: "INV-ID-1002",
    invoiceNo: "INV-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    billDate: "2026-06-20",
    billType: "Diagnostics",
    subtotal: 1800,
    discount: 100,
    paidAmount: 800,
    dueAmount: 900,
    paymentMethod: "bKash",
    status: "Partial",
    notes: "Diagnostic bill partially collected."
  }
];

const allowedTypes = [
  "Consultation",
  "Diagnostics",
  "Medicine",
  "Procedure",
  "Package"
];

const allowedStatuses = ["Paid", "Due", "Partial", "Overdue", "Cancelled"];

const allowedMethods = ["Cash", "Card", "bKash", "Nagad", "Bank", "Unpaid"];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultInvoices, null, 2));
  }
};

const readInvoices = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const invoices = JSON.parse(rawData);
    return Array.isArray(invoices) ? invoices : defaultInvoices;
  } catch {
    return defaultInvoices;
  }
};

const writeInvoices = (invoices) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(invoices, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const calculateDue = (subtotal, discount, paidAmount) =>
  Math.max(0, Number(subtotal || 0) - Number(discount || 0) - Number(paidAmount || 0));

const calculateNet = (subtotal, discount) =>
  Math.max(0, Number(subtotal || 0) - Number(discount || 0));

const getAutoStatus = (subtotal, discount, paidAmount) => {
  const net = calculateNet(subtotal, discount);

  if (net <= 0 || Number(paidAmount || 0) >= net) return "Paid";
  if (Number(paidAmount || 0) > 0) return "Partial";
  return "Due";
};

const searchInvoices = (invoices, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return invoices;

  return invoices.filter((item) =>
    [
      item.id,
      item.invoiceNo,
      item.patientId,
      item.patientName,
      item.phone,
      item.doctorName,
      item.billDate,
      item.billType,
      item.status,
      item.paymentMethod,
      item.notes
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterInvoices = (invoices, reqQuery) => {
  let result = [...invoices];

  result = searchInvoices(result, reqQuery.q);

  const status = cleanText(reqQuery.status);
  const billType = cleanText(reqQuery.billType);
  const paymentMethod = cleanText(reqQuery.paymentMethod);
  const doctor = cleanText(reqQuery.doctor);

  if (status) result = result.filter((item) => item.status === status);
  if (billType) result = result.filter((item) => item.billType === billType);
  if (paymentMethod) {
    result = result.filter((item) => item.paymentMethod === paymentMethod);
  }
  if (doctor) result = result.filter((item) => item.doctorName === doctor);

  return result;
};

router.get("/", (req, res) => {
  const invoices = readInvoices();
  const filteredInvoices = filterInvoices(invoices, req.query);

  return res.json({ invoices: filteredInvoices });
});

router.post("/", (req, res) => {
  const invoices = readInvoices();

  const patientId = cleanText(req.body && req.body.patientId);
  const patientName = cleanText(req.body && req.body.patientName);
  const phone = cleanText(req.body && req.body.phone);
  const doctorName = cleanText(req.body && req.body.doctorName);
  const billDate = cleanText(req.body && req.body.billDate);
  const billType = cleanText(req.body && req.body.billType) || "Consultation";
  const subtotal = Number(req.body && req.body.subtotal);
  const discount = Number(req.body && req.body.discount);
  const paidAmount = Number(req.body && req.body.paidAmount);
  const dueAmount = calculateDue(subtotal, discount, paidAmount);
  const paymentMethod =
    Number(paidAmount || 0) > 0
      ? cleanText(req.body && req.body.paymentMethod) || "Cash"
      : "Unpaid";
  const status = getAutoStatus(subtotal, discount, paidAmount);
  const notes = cleanText(req.body && req.body.notes) || "No billing note";

  if (
    !patientId ||
    !patientName ||
    !phone ||
    !doctorName ||
    !billDate ||
    !Number.isFinite(subtotal) ||
    subtotal < 0 ||
    !Number.isFinite(discount) ||
    discount < 0 ||
    !Number.isFinite(paidAmount) ||
    paidAmount < 0
  ) {
    return res.status(400).json({
      message:
        "Patient, phone, doctor/desk, date, subtotal, discount and paid amount are required"
    });
  }

  if (!allowedTypes.includes(billType)) {
    return res.status(400).json({ message: "Invalid bill type" });
  }

  if (!allowedMethods.includes(paymentMethod)) {
    return res.status(400).json({ message: "Invalid payment method" });
  }

  const invoice = {
    id: `INV-ID-${Date.now()}`,
    invoiceNo: `INV-${String(invoices.length + 1).padStart(4, "0")}`,
    patientId,
    patientName,
    phone,
    doctorName,
    billDate,
    billType,
    subtotal,
    discount,
    paidAmount,
    dueAmount,
    paymentMethod,
    status,
    notes
  };

  const nextInvoices = [invoice, ...invoices];
  writeInvoices(nextInvoices);

  return res.status(201).json({ invoice });
});

router.patch("/:id/status", (req, res) => {
  const invoices = readInvoices();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid invoice status"
    });
  }

  const foundInvoice = invoices.find((item) => item.id === id);

  if (!foundInvoice) {
    return res.status(404).json({
      message: "Invoice not found"
    });
  }

  const nextInvoices = invoices.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writeInvoices(nextInvoices);

  return res.json({
    invoice: nextInvoices.find((item) => item.id === id)
  });
});

router.patch("/:id/collect", (req, res) => {
  const invoices = readInvoices();

  const id = cleanText(req.params.id);
  const paymentMethod = cleanText(req.body && req.body.paymentMethod) || "Cash";

  if (!allowedMethods.includes(paymentMethod) || paymentMethod === "Unpaid") {
    return res.status(400).json({
      message: "Valid payment method is required"
    });
  }

  const foundInvoice = invoices.find((item) => item.id === id);

  if (!foundInvoice) {
    return res.status(404).json({
      message: "Invoice not found"
    });
  }

  const paidAmount = calculateNet(foundInvoice.subtotal, foundInvoice.discount);

  const nextInvoices = invoices.map((item) =>
    item.id === id
      ? {
          ...item,
          paidAmount,
          dueAmount: 0,
          paymentMethod,
          status: "Paid"
        }
      : item
  );

  writeInvoices(nextInvoices);

  return res.json({
    invoice: nextInvoices.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const invoices = readInvoices();
  const id = cleanText(req.params.id);

  const foundInvoice = invoices.find((item) => item.id === id);

  if (!foundInvoice) {
    return res.status(404).json({
      message: "Invoice not found"
    });
  }

  const nextInvoices = invoices.filter((item) => item.id !== id);
  writeInvoices(nextInvoices);

  return res.json({ success: true });
});

export default router;
