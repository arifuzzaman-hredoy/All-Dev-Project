import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-sms-wallet.json");

const defaultRecords = [
  {
    id: "SMS-ID-1001",
    refNo: "SMS-RECH-1001",
    date: "2026-06-20",
    title: "Monthly SMS wallet recharge",
    type: "Recharge",
    channel: "System",
    smsCount: 5000,
    unitCost: 0.35,
    amount: 1750,
    balanceAfter: 5000,
    status: "Completed",
    recipientGroup: "Clinic account",
    templateName: "Wallet Recharge",
    gatewayRef: "SSL-SMS-RECH-1001",
    note: "5000 SMS added to wallet."
  },
  {
    id: "SMS-ID-1002",
    refNo: "SMS-USE-1002",
    date: "2026-06-20",
    title: "Appointment confirmation SMS",
    type: "Usage",
    channel: "Appointment",
    smsCount: 82,
    unitCost: 0.35,
    amount: 28.7,
    balanceAfter: 4918,
    status: "Completed",
    recipientGroup: "Today appointments",
    templateName: "Appointment Confirmation",
    gatewayRef: "GATEWAY-BATCH-8821",
    note: "Appointment confirmation notification sent."
  }
];

const allowedTypes = ["Recharge", "Usage", "Refund", "Adjustment"];
const allowedStatuses = ["Pending", "Completed", "Failed", "Cancelled"];
const allowedChannels = [
  "Appointment",
  "Prescription",
  "Billing",
  "Report",
  "Marketing",
  "System"
];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultRecords, null, 2));
  }
};

const readRecords = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const records = JSON.parse(rawData);
    return Array.isArray(records) ? records : defaultRecords;
  } catch {
    return defaultRecords;
  }
};

const writeRecords = (records) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(records, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const calculateSummary = (records) => {
  const completedRecords = records.filter((item) => item.status === "Completed");

  const totalRecharge = completedRecords
    .filter((item) => item.type === "Recharge" || item.type === "Refund")
    .reduce((total, item) => total + Number(item.smsCount || 0), 0);

  const totalUsed = completedRecords
    .filter((item) => item.type === "Usage")
    .reduce((total, item) => total + Number(item.smsCount || 0), 0);

  const balanceSms = records.length
    ? Number(records[0].balanceAfter || 0)
    : Math.max(0, totalRecharge - totalUsed);

  const unitCost = records[0] ? Number(records[0].unitCost || 0.35) : 0.35;

  return {
    balanceSms,
    balanceAmount: balanceSms * unitCost,
    totalRecharge,
    totalUsed,
    delivered: completedRecords.filter((item) => item.type === "Usage").length,
    failed: records.filter((item) => item.status === "Failed").length
  };
};

const searchRecords = (records, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return records;

  return records.filter((item) =>
    [
      item.id,
      item.refNo,
      item.date,
      item.title,
      item.type,
      item.channel,
      item.status,
      item.recipientGroup,
      item.templateName,
      item.gatewayRef,
      item.note
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );
};

const filterRecords = (records, reqQuery) => {
  let result = [...records];

  result = searchRecords(result, reqQuery.q);

  const type = cleanText(reqQuery.type);
  const status = cleanText(reqQuery.status);
  const channel = cleanText(reqQuery.channel);

  if (type) result = result.filter((item) => item.type === type);
  if (status) result = result.filter((item) => item.status === status);
  if (channel) result = result.filter((item) => item.channel === channel);

  return result;
};

const nextBalance = (records, type, smsCount, status) => {
  const currentBalance = records.length ? Number(records[0].balanceAfter || 0) : 0;

  if (status !== "Completed") return currentBalance;

  if (type === "Recharge" || type === "Refund") {
    return currentBalance + smsCount;
  }

  if (type === "Usage") {
    return Math.max(0, currentBalance - smsCount);
  }

  return currentBalance;
};

router.get("/", (req, res) => {
  const records = readRecords();
  const filteredRecords = filterRecords(records, req.query);

  return res.json({
    wallet: {
      summary: calculateSummary(records),
      records: filteredRecords
    }
  });
});

router.post("/", (req, res) => {
  const records = readRecords();

  const date = cleanText(req.body && req.body.date);
  const title = cleanText(req.body && req.body.title);
  const type = cleanText(req.body && req.body.type) || "Recharge";
  const channel = cleanText(req.body && req.body.channel) || "System";
  const smsCount = Number(req.body && req.body.smsCount);
  const unitCost = Number(req.body && req.body.unitCost);
  const amount = Number(req.body && req.body.amount);
  const status = cleanText(req.body && req.body.status) || "Completed";
  const recipientGroup = cleanText(req.body && req.body.recipientGroup);
  const templateName = cleanText(req.body && req.body.templateName);
  const gatewayRef =
    cleanText(req.body && req.body.gatewayRef) || `GATEWAY-${Date.now()}`;
  const note = cleanText(req.body && req.body.note) || "No SMS wallet note";

  if (
    !date ||
    !title ||
    !Number.isFinite(smsCount) ||
    smsCount <= 0 ||
    !Number.isFinite(unitCost) ||
    unitCost < 0 ||
    !Number.isFinite(amount) ||
    amount < 0 ||
    !recipientGroup ||
    !templateName
  ) {
    return res.status(400).json({
      message:
        "Date, title, SMS count, unit cost, amount, recipient group and template are required"
    });
  }

  if (!allowedTypes.includes(type)) {
    return res.status(400).json({ message: "Invalid SMS record type" });
  }

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid SMS status" });
  }

  if (!allowedChannels.includes(channel)) {
    return res.status(400).json({ message: "Invalid SMS channel" });
  }

  const record = {
    id: `SMS-ID-${Date.now()}`,
    refNo: `SMS-${type.toUpperCase()}-${String(records.length + 1).padStart(4, "0")}`,
    date,
    title,
    type,
    channel,
    smsCount,
    unitCost,
    amount,
    balanceAfter: nextBalance(records, type, smsCount, status),
    status,
    recipientGroup,
    templateName,
    gatewayRef,
    note
  };

  const nextRecords = [record, ...records];
  writeRecords(nextRecords);

  return res.status(201).json({ record });
});

router.patch("/:id/status", (req, res) => {
  const records = readRecords();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid SMS record status"
    });
  }

  const foundRecord = records.find((item) => item.id === id);

  if (!foundRecord) {
    return res.status(404).json({
      message: "SMS wallet record not found"
    });
  }

  const nextRecords = records.map((item) =>
    item.id === id ? { ...item, status } : item
  );

  writeRecords(nextRecords);

  return res.json({
    record: nextRecords.find((item) => item.id === id)
  });
});

router.delete("/:id", (req, res) => {
  const records = readRecords();
  const id = cleanText(req.params.id);

  const foundRecord = records.find((item) => item.id === id);

  if (!foundRecord) {
    return res.status(404).json({
      message: "SMS wallet record not found"
    });
  }

  const nextRecords = records.filter((item) => item.id !== id);
  writeRecords(nextRecords);

  return res.json({ success: true });
});

export default router;
