import express from "express";
import fs from "node:fs";
import path from "node:path";

const router = express.Router();

const dataDir = path.join(process.cwd(), "server", "data");
const dataFile = path.join(dataDir, "clinic-patients.json");

const defaultPatients = [
  {
    id: "PT-1001",
    patientId: "P-1001",
    name: "Nusrat Jahan",
    phone: "+8801711000001",
    email: "nusrat.patient@demo.com",
    age: 32,
    gender: "Female",
    bloodGroup: "B+",
    address: "Rangpur Sadar, Rangpur",
    assignedDoctor: "Dr. Abdullah Rahman",
    diagnosis: "Migraine follow-up",
    lastVisit: "2026-06-20",
    nextFollowUp: "2026-07-05",
    totalVisits: 4,
    status: "Follow-up",
  },
  {
    id: "PT-1002",
    patientId: "P-1002",
    name: "Rafiqul Islam",
    phone: "+8801711000002",
    email: "rafiqul.patient@demo.com",
    age: 45,
    gender: "Male",
    bloodGroup: "O+",
    address: "Kotchandpur, Jhenaidah",
    assignedDoctor: "Dr. Mehedi Hasan",
    diagnosis: "Hypertension",
    lastVisit: "2026-06-18",
    nextFollowUp: "2026-07-18",
    totalVisits: 7,
    status: "Active",
  },
];

const allowedStatus = ["Active", "Follow-up", "Critical", "Inactive"];
const allowedGender = ["Male", "Female", "Other"];
const allowedBlood = [
  "A+",
  "A-",
  "B+",
  "B-",
  "AB+",
  "AB-",
  "O+",
  "O-",
  "Unknown",
];

const ensureDataFile = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultPatients, null, 2));
  }
};

const readPatients = () => {
  ensureDataFile();

  try {
    const rawData = fs.readFileSync(dataFile, "utf8");
    const patients = JSON.parse(rawData);
    return Array.isArray(patients) ? patients : defaultPatients;
  } catch {
    return defaultPatients;
  }
};

const writePatients = (patients) => {
  ensureDataFile();
  fs.writeFileSync(dataFile, JSON.stringify(patients, null, 2));
};

const cleanText = (value) => String(value || "").trim();

const searchPatients = (patients, query) => {
  const searchText = cleanText(query).toLowerCase();

  if (!searchText) return patients;

  return patients.filter((item) =>
    [
      item.id,
      item.patientId,
      item.name,
      item.phone,
      item.email,
      item.gender,
      item.bloodGroup,
      item.address,
      item.assignedDoctor,
      item.diagnosis,
      item.status,
      item.lastVisit,
      item.nextFollowUp,
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText),
  );
};

const filterPatients = (patients, reqQuery) => {
  let result = [...patients];

  result = searchPatients(result, reqQuery.q);

  const status = cleanText(reqQuery.status);
  const gender = cleanText(reqQuery.gender);
  const bloodGroup = cleanText(reqQuery.bloodGroup);
  const doctor = cleanText(reqQuery.doctor);

  if (status) result = result.filter((item) => item.status === status);
  if (gender) result = result.filter((item) => item.gender === gender);
  if (bloodGroup) {
    result = result.filter((item) => item.bloodGroup === bloodGroup);
  }
  if (doctor) {
    result = result.filter((item) => item.assignedDoctor === doctor);
  }

  return result;
};

router.get("/", (req, res) => {
  const patients = readPatients();
  const filteredPatients = filterPatients(patients, req.query);

  return res.json({ patients: filteredPatients });
});

router.post("/", (req, res) => {
  const patients = readPatients();

  const name = cleanText(req.body && req.body.name);
  const phone = cleanText(req.body && req.body.phone);
  const email = cleanText(req.body && req.body.email).toLowerCase();
  const age = Number(req.body && req.body.age);
  const gender = cleanText(req.body && req.body.gender) || "Male";
  const bloodGroup = cleanText(req.body && req.body.bloodGroup) || "Unknown";
  const address = cleanText(req.body && req.body.address);
  const assignedDoctor = cleanText(req.body && req.body.assignedDoctor);
  const diagnosis = cleanText(req.body && req.body.diagnosis);
  const lastVisit = cleanText(req.body && req.body.lastVisit) || "Not visited yet";
  const nextFollowUp =
    cleanText(req.body && req.body.nextFollowUp) || "Not scheduled";
  const totalVisits = Number(req.body && req.body.totalVisits);
  const status = cleanText(req.body && req.body.status) || "Active";

  if (
    !name ||
    !phone ||
    !Number.isFinite(age) ||
    age <= 0 ||
    !address ||
    !assignedDoctor ||
    !diagnosis ||
    !Number.isFinite(totalVisits) ||
    totalVisits < 0
  ) {
    return res.status(400).json({
      message:
        "Name, phone, age, address, assigned doctor, diagnosis and visits are required",
    });
  }

  if (!allowedGender.includes(gender)) {
    return res.status(400).json({ message: "Invalid gender" });
  }

  if (!allowedBlood.includes(bloodGroup)) {
    return res.status(400).json({ message: "Invalid blood group" });
  }

  if (!allowedStatus.includes(status)) {
    return res.status(400).json({ message: "Invalid patient status" });
  }

  const phoneExists = patients.some((item) => String(item.phone) === phone);

  if (phoneExists) {
    return res.status(409).json({
      message: "Patient phone already exists",
    });
  }

  const patient = {
    id: `PT-${Date.now()}`,
    patientId: `P-${String(patients.length + 1).padStart(4, "0")}`,
    name,
    phone,
    email,
    age,
    gender,
    bloodGroup,
    address,
    assignedDoctor,
    diagnosis,
    lastVisit,
    nextFollowUp,
    totalVisits,
    status,
  };

  const nextPatients = [patient, ...patients];
  writePatients(nextPatients);

  return res.status(201).json({ patient });
});

router.patch("/:id/status", (req, res) => {
  const patients = readPatients();

  const id = cleanText(req.params.id);
  const status = cleanText(req.body && req.body.status);

  if (!allowedStatus.includes(status)) {
    return res.status(400).json({
      message: "Invalid patient status",
    });
  }

  const foundPatient = patients.find((item) => item.id === id);

  if (!foundPatient) {
    return res.status(404).json({
      message: "Patient not found",
    });
  }

  const nextPatients = patients.map((item) =>
    item.id === id ? { ...item, status } : item,
  );

  writePatients(nextPatients);

  return res.json({
    patient: nextPatients.find((item) => item.id === id),
  });
});

router.delete("/:id", (req, res) => {
  const patients = readPatients();
  const id = cleanText(req.params.id);

  const foundPatient = patients.find((item) => item.id === id);

  if (!foundPatient) {
    return res.status(404).json({
      message: "Patient not found",
    });
  }

  const nextPatients = patients.filter((item) => item.id !== id);
  writePatients(nextPatients);

  return res.json({ success: true });
});

export default router;
