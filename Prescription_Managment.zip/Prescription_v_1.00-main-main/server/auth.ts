import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const getSecret = () => process.env.JWT_SECRET || process.env.ADMIN_SESSION_SECRET || "change-this-secret-before-production";

export const hashPassword = (password) => bcrypt.hash(String(password), 12);
export const verifyPassword = (password, hash) => bcrypt.compare(String(password), hash);

export const signToken = (payload, expiresIn = "7d") => jwt.sign(payload, getSecret(), { expiresIn });

export const requireAdmin = (req, res, next) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;

  if (!token) {
    return res.status(401).json({ ok: false, message: "Unauthorized." });
  }

  try {
    req.admin = jwt.verify(token, getSecret());
    return next();
  } catch {
    return res.status(401).json({ ok: false, message: "Invalid or expired session." });
  }
};
