import "dotenv/config";
import accountsRoutes from "./routes/accounts.routes";
import accessControlRoutes from "./routes/accessControl.routes";
import appContextRoutes from "./routes/appContext.routes";
import clinicAppointmentsRoutes from "./routes/clinicAppointments.routes.js";
import clinicBillingRoutes from "./routes/clinicBilling.routes.js";
import clinicDashboardRoutes from "./routes/clinicDashboard.routes.js";
import clinicDiagnosticRoutes from "./routes/clinicDiagnostic.routes.js";
import clinicDoctorsRoutes from "./routes/clinicDoctors.routes.js";
import clinicEncountersRoutes from "./routes/clinicEncounters.routes.js";
import clinicInventoryRoutes from "./routes/clinicInventory.routes.js";
import clinicMyPlanRoutes from "./routes/clinicMyPlan.routes";
import clinicPatientLedgerRoutes from "./routes/clinicPatientLedger.routes.js";
import clinicPatientsRoutes from "./routes/clinicPatients.routes.js";
import clinicPaymentsRoutes from "./routes/clinicPayments.routes.js";
import clinicPrescriptionsRoutes from "./routes/clinicPrescriptions.routes.js";
import clinicReportsRoutes from "./routes/clinicReports.routes.js";
import clinicSettingsRoutes from "./routes/clinicSettings.routes.js";
import clinicSmsWalletRoutes from "./routes/clinicSmsWallet.routes.js";
import clinicSupportRoutes from "./routes/clinicSupport.routes.js";
import clinicUsersRoutes from "./routes/clinicUsers.routes.js";
import doctorIdentityRoutes from "./routes/doctorIdentity.routes";
import prescriptionRoutes from "./routes/prescription.routes";
import themeSettingsRoutes from "./routes/themeSettings.routes";
import express from "express";
import cors from "cors";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { prisma } from "./prisma";
import { requireAdmin, signToken, verifyPassword, hashPassword } from "./auth";
import { defaultContent } from "./defaults";
import {
  generateAppointmentCode,
  generatePatientCode,
} from "./services/idGenerator.service";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3500);
const distPath = path.resolve(__dirname, "../dist");
const uploadsPath = path.resolve(__dirname, "../uploads");

app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") || true, credentials: true }));
app.use(express.json({ limit: "10mb" }));
app.use("/api/accounts", accountsRoutes);
app.use("/api/access-control", accessControlRoutes);
app.use("/api/app", appContextRoutes);
app.use("/api/cms/theme-settings", themeSettingsRoutes);
app.use("/api/clinic/appointments", clinicAppointmentsRoutes);
app.use("/api/clinic/billing", clinicBillingRoutes);
app.use("/api/clinic/dashboard", clinicDashboardRoutes);
app.use("/api/clinic/diagnostic", clinicDiagnosticRoutes);
app.use("/api/clinic/doctors", clinicDoctorsRoutes);
app.use("/api/clinic/encounters", clinicEncountersRoutes);
app.use("/api/clinic/inventory", clinicInventoryRoutes);
app.use("/api/clinic/my-plan", clinicMyPlanRoutes);
app.use("/api/clinic/patient-ledger", clinicPatientLedgerRoutes);
app.use("/api/clinic/patients", clinicPatientsRoutes);
app.use("/api/clinic/payments", clinicPaymentsRoutes);
app.use("/api/clinic/prescriptions", clinicPrescriptionsRoutes);
app.use("/api/clinic/reports", clinicReportsRoutes);
app.use("/api/clinic/settings", clinicSettingsRoutes);
app.use("/api/clinic/sms-wallet", clinicSmsWalletRoutes);
app.use("/api/clinic/support", clinicSupportRoutes);
app.use("/api/clinic/users", clinicUsersRoutes);
app.use(doctorIdentityRoutes);
app.use(prescriptionRoutes);

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const createId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`;
const allowedUploadTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["image/svg+xml", "svg"],
]);
const maxUploadBytes = 2.5 * 1024 * 1024;

const validateContentPayload = (type, data) => {
  if (data === null || data === undefined) return "Missing content data.";
  if (["blogs", "qa", "gallery", "services", "prescriptions"].includes(type) && !Array.isArray(data)) {
    return `${type} content must be an array.`;
  }
  if (["profile", "panelSettings"].includes(type) && (typeof data !== "object" || Array.isArray(data))) {
    return `${type} content must be an object.`;
  }
  return "";
};

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    app: "Clinic ERP SaaS",
    service: "Perception Management API",
    version: process.env.npm_package_version || "0.0.0",
    env: process.env.NODE_ENV || "development",
    time: new Date().toISOString(),
  });
});

app.post("/api/admin/login", asyncHandler(async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const admin = await prisma.adminUser.findUnique({ where: { username } });
  if (!admin || !(await verifyPassword(password, admin.passwordHash))) {
    return res.status(401).json({ ok: false, message: "Invalid username or password." });
  }
  const token = signToken({ id: admin.id, username: admin.username, role: admin.role });
  return res.json({ ok: true, token, admin: { username: admin.username, role: admin.role } });
}));

app.post("/api/admin/change-password", requireAdmin, asyncHandler(async (req, res) => {
  const password = String(req.body.password || "");
  if (password.length < 8) return res.status(400).json({ ok: false, message: "Password must be at least 8 characters." });
  await prisma.adminUser.update({ where: { id: req.admin.id }, data: { passwordHash: await hashPassword(password) } });
  res.json({ ok: true });
}));

app.get("/api/content", asyncHandler(async (_req, res) => {
  const content = { ...defaultContent };

  try {
    const rows = await prisma.siteContent.findMany();
    for (const row of rows) content[row.type] = row.data;
    const appointments = await prisma.appointment.findMany({ orderBy: { createdAt: "desc" } });
    const messages = await prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" } });
    content.appointments = appointments.map((item) => ({ id: item.id, status: item.status, createdAt: item.createdAt.toISOString(), ...item.data }));
    content.messages = messages.map((item) => ({ id: item.id, status: item.status, createdAt: item.createdAt.toISOString(), ...item.data }));
    return res.json({ ok: true, content });
  } catch (error) {
    console.error("GET_CONTENT_FALLBACK:", error);
    return res.json({ ok: true, content, fallback: true });
  }
}));

app.get("/api/content/:type", asyncHandler(async (req, res) => {
  const type = req.params.type;
  if (!(type in defaultContent)) return res.status(404).json({ ok: false, message: "Unknown content type." });

  try {
    const row = await prisma.siteContent.findUnique({ where: { type } });
    return res.json({ ok: true, data: row?.data ?? defaultContent[type] ?? null });
  } catch (error) {
    console.error("GET_CONTENT_TYPE_FALLBACK:", error);
    return res.json({ ok: true, data: defaultContent[type] ?? null, fallback: true });
  }
}));

app.put("/api/content/:type", requireAdmin, asyncHandler(async (req, res) => {
  const type = req.params.type;
  if (!(type in defaultContent)) return res.status(404).json({ ok: false, message: "Unknown content type." });
  const data = req.body.data ?? req.body;
  const error = validateContentPayload(type, data);
  if (error) return res.status(400).json({ ok: false, message: error });
  const row = await prisma.siteContent.upsert({ where: { type }, update: { data }, create: { type, data } });
  res.json({ ok: true, data: row.data });
}));

app.post("/api/admin/upload", requireAdmin, asyncHandler(async (req, res) => {
  const { fileName, mimeType, dataUrl } = req.body || {};
  const type = String(mimeType || "").toLowerCase();
  const extension = allowedUploadTypes.get(type);

  if (!extension) {
    return res.status(400).json({ ok: false, message: "Unsupported file type." });
  }

  const encoded = String(dataUrl || "").split(",").pop() || "";
  const buffer = Buffer.from(encoded, "base64");

  if (!buffer.length || buffer.length > maxUploadBytes) {
    return res.status(400).json({ ok: false, message: "File must be under 2.5MB." });
  }

  await fs.mkdir(uploadsPath, { recursive: true });
  const safeBase = String(fileName || "upload")
    .replace(/\.[^.]+$/, "")
    .replace(/[^a-z0-9_-]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "upload";
  const savedName = `${Date.now()}-${crypto.randomBytes(5).toString("hex")}-${safeBase}.${extension}`;
  const filePath = path.join(uploadsPath, savedName);

  await fs.writeFile(filePath, buffer);

  res.status(201).json({
    ok: true,
    file: {
      fileName: savedName,
      originalName: fileName || savedName,
      mimeType: type,
      size: buffer.length,
      url: `/uploads/${savedName}`,
    },
  });
}));

app.post("/api/appointments", asyncHandler(async (req, res) => {
  const patientName = String(req.body.patientName || req.body.name || "").trim();
  const phone = String(req.body.phone || "").trim();
  const problem = String(req.body.problem || req.body.message || "").trim();

  if (!patientName || !phone || !problem) {
    return res.status(400).json({
      ok: false,
      message: "Patient name, phone and problem are required.",
    });
  }

  const now = new Date();
  const row = await prisma.$transaction(async (tx) => {
    const appointmentCode = await generateAppointmentCode({ prisma: tx, date: now });
    const patientCode = await generatePatientCode({ prisma: tx, date: now });
    const data = {
      ...req.body,
      id: appointmentCode,
      appointmentCode,
      patientCode,
      patientName,
      phone,
      problem,
      appointmentStatus: req.body.appointmentStatus || "Pending",
      createdAt: now.toISOString(),
    };

    return tx.appointment.create({
      data: {
        data,
        status: "pending",
      },
    });
  });

  res.status(201).json({
    ok: true,
    item: {
      ...row.data,
      id: row.data?.id || row.id,
      recordId: row.id,
      status: row.status,
      createdAt: row.createdAt.toISOString(),
    },
  });
}));

app.get("/api/appointments", requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await prisma.appointment.findMany({ orderBy: { createdAt: "desc" } });
  res.json({
    ok: true,
    data: rows.map((item) => ({
      ...item.data,
      id: item.data?.id || item.id,
      recordId: item.id,
      status: item.status,
      createdAt: item.createdAt.toISOString(),
    })),
  });
}));

app.put("/api/appointments/:id/status", requireAdmin, asyncHandler(async (req, res) => {
  const row = await prisma.appointment.update({ where: { id: req.params.id }, data: { status: String(req.body.status || "pending") } });
  res.json({ ok: true, item: { ...row.data, id: row.data?.id || row.id, recordId: row.id, status: row.status, createdAt: row.createdAt.toISOString() } });
}));

app.delete("/api/appointments/:id", requireAdmin, asyncHandler(async (req, res) => {
  await prisma.appointment.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

app.post("/api/messages", asyncHandler(async (req, res) => {
  const row = await prisma.contactMessage.create({ data: { data: req.body, status: "new" } });
  res.status(201).json({ ok: true, item: { id: row.id, status: row.status, createdAt: row.createdAt.toISOString(), ...row.data } });
}));

app.get("/api/messages", requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" } });
  res.json({ ok: true, data: rows.map((item) => ({ id: item.id, status: item.status, createdAt: item.createdAt.toISOString(), ...item.data })) });
}));

app.post("/api/questions", asyncHandler(async (req, res) => {
  const current = await prisma.siteContent.findUnique({ where: { type: "qa" } });
  const qa = Array.isArray(current?.data) ? current.data : defaultContent.qa;
  const item = { id: createId("qa"), patientName: req.body.patientName, phone: req.body.phone, question: req.body.question, answer: "", status: "pending", createdAt: new Date().toISOString() };
  await prisma.siteContent.upsert({ where: { type: "qa" }, update: { data: [item, ...qa] }, create: { type: "qa", data: [item, ...qa] } });
  res.status(201).json({ ok: true, item });
}));

app.post("/api/public/register", asyncHandler(async (req, res) => {
  const { name, phone, email, password, age, gender, address } = req.body;
  if (!name || !phone || !email || !password) return res.status(400).json({ ok: false, message: "Name, phone, email and password are required." });
  const passwordHash = await hashPassword(password);
  const user = await prisma.publicUser.create({ data: { name, phone, email, passwordHash, age, gender, address } });
  const token = signToken({ id: user.id, email: user.email, type: "public" });
  res.status(201).json({ ok: true, token, user: { id: user.id, name: user.name, phone: user.phone, email: user.email, age: user.age, gender: user.gender, address: user.address, status: user.status } });
}));

app.post("/api/public/login", asyncHandler(async (req, res) => {
  const phoneOrEmail = String(req.body.phoneOrEmail || req.body.identifier || "").trim().toLowerCase();
  const user = await prisma.publicUser.findFirst({ where: { OR: [{ email: phoneOrEmail }, { phone: phoneOrEmail }] } });
  if (!user || !(await verifyPassword(req.body.password || "", user.passwordHash))) return res.status(401).json({ ok: false, message: "Invalid phone/email or password." });
  const token = signToken({ id: user.id, email: user.email, type: "public" });
  res.json({ ok: true, token, user: { id: user.id, name: user.name, phone: user.phone, email: user.email, age: user.age, gender: user.gender, address: user.address, status: user.status } });
}));


app.use("/uploads", express.static(uploadsPath, { maxAge: "30d" }));
app.use(express.static(distPath, { maxAge: "1h" }));
app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.statusCode || 500).json({ ok: false, message: err.message || "Server error." });
});

app.listen(port, () => console.log(`Perception Management running on port ${port}`));
