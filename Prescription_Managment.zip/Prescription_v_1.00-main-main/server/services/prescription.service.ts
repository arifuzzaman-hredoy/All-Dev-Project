import crypto from "node:crypto";
import { prisma } from "../prisma";
import { savePrescriptionDataUrl } from "../utils/prescriptionFiles";
import { createDownloadToken, hashOtp } from "../utils/secureDownloadToken";

const normalizePhone = (phone = "") => String(phone).replace(/[^\d+]/g, "").trim();
const normalizeText = (value = "") => String(value || "").trim();

const publicPrescriptionSelect = {
  id: true,
  prescriptionCode: true,
  patientIdText: true,
  patientName: true,
  phone: true,
  appointmentCode: true,
  doctorName: true,
  prescriptionDate: true,
  title: true,
  notes: true,
  templateData: true,
  printableHtml: true,
  originalFileName: true,
  fileMimeType: true,
  fileSize: true,
  status: true,
  createdAt: true,
  uploadedAt: true,
  attachments: true,
};

export const serializePrescription = (item, includeDownload = false) => {
  const base = {
    id: item.id,
    prescriptionCode: item.prescriptionCode,
    patientId: item.patientIdText,
    patientName: item.patientName,
    phone: item.phone,
    appointmentId: item.appointmentCode || item.appointmentId || "",
    doctorName: item.doctorName || "",
    age: item.age || "",
    gender: item.gender || "",
    prescriptionDate: item.prescriptionDate?.toISOString?.().slice(0, 10) || "",
    title: item.title,
    chiefComplaint: item.chiefComplaint || "",
    diagnosis: item.diagnosis || "",
    medicines: item.medicines || [],
    advice: item.advice || null,
    tests: item.tests || [],
    followUpDate: item.followUpDate?.toISOString?.().slice(0, 10) || "",
    notes: item.notes || "",
    templateData: item.templateData || null,
    printableHtml: item.printableHtml || "",
    fileName: item.originalFileName || item.fileName,
    fileMimeType: item.fileMimeType,
    fileSize: item.fileSize || 0,
    status: item.status,
    attachmentCount: Array.isArray(item.attachments) ? item.attachments.length : 0,
    attachments: Array.isArray(item.attachments)
      ? item.attachments.map((attachment) => ({
          id: attachment.id,
          fileName: attachment.fileName,
          originalName: attachment.originalName,
          fileUrl: attachment.fileUrl,
          fileMimeType: attachment.fileMimeType,
          fileSize: attachment.fileSize,
          attachmentType: attachment.attachmentType,
          title: attachment.title || "",
          note: attachment.note || "",
          sortOrder: attachment.sortOrder,
          createdAt: attachment.createdAt?.toISOString?.() || "",
        }))
      : [],
    uploadedBy: item.uploadedByName || "",
    savedAt: item.createdAt?.toISOString?.() || "",
    uploadedAt: item.uploadedAt?.toISOString?.() || "",
  };

  if (!includeDownload) return base;

  const token = createDownloadToken({
    prescriptionId: item.id,
    phone: item.phone,
    patientCode: item.patientIdText,
  });

  return {
    ...base,
    downloadUrl: `/api/public/prescriptions/${token}/download`,
  };
};

const validatePrescriptionPayload = (payload, requireFile = false) => {
  const patientIdText = normalizeText(payload.patientId || payload.patientIdText || payload.patientCode);
  const phone = normalizePhone(payload.phone);
  const prescriptionDate = normalizeText(payload.prescriptionDate || payload.date);

  if (!patientIdText) throw Object.assign(new Error("Patient ID is required."), { statusCode: 400 });
  if (!phone) throw Object.assign(new Error("Phone number is required."), { statusCode: 400 });
  if (!prescriptionDate) throw Object.assign(new Error("Prescription date is required."), { statusCode: 400 });
  if (requireFile && !payload.file?.dataUrl) {
    throw Object.assign(new Error("Prescription file is required."), { statusCode: 400 });
  }

  return {
    patientIdText,
    phone,
    prescriptionDate: new Date(prescriptionDate),
  };
};

export const listPrescriptions = async () => {
  const rows = await prisma.prescription.findMany({
    where: { status: { not: "deleted" } },
    include: { attachments: { orderBy: { sortOrder: "asc" } } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return rows.map((item) => serializePrescription(item));
};

const buildPrescriptionData = (payload, admin, status = "pending_upload") => {
  const validated = validatePrescriptionPayload(payload, false);

  return {
    patientIdText: validated.patientIdText,
    patientCode: validated.patientIdText,
    patientName: normalizeText(payload.patientName) || validated.patientIdText,
    phone: validated.phone,
    age: normalizeText(payload.age),
    gender: normalizeText(payload.gender),
    appointmentId: normalizeText(payload.appointmentId),
    appointmentCode: normalizeText(payload.appointmentId || payload.appointmentCode || payload.serial),
    doctorName: normalizeText(payload.doctorName),
    prescriptionDate: validated.prescriptionDate,
    title: normalizeText(payload.title) || normalizeText(payload.diagnosis) || "Prescription",
    chiefComplaint: normalizeText(payload.chiefComplaint),
    diagnosis: normalizeText(payload.diagnosis),
    medicines: payload.medicines || payload.templateData?.medicines || [],
    advice: payload.advice || payload.finalAdvice || payload.templateData?.finalAdvice || null,
    tests: payload.tests || [],
    followUpDate: payload.followUpDate ? new Date(payload.followUpDate) : null,
    notes: normalizeText(payload.notes),
    templateData: payload.templateData || payload.notesData || payload,
    printableHtml: normalizeText(payload.printableHtml),
    status,
    savedById: admin?.id || "",
    uploadedByName: admin?.username || admin?.role || "Admin",
  };
};

export const savePrescriptionDraft = async (payload, admin) => {
  const prescriptionCode = `RX-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  const data = buildPrescriptionData(payload, admin, "pending_upload");

  const row = await prisma.prescription.create({
    data: {
      prescriptionCode,
      ...data,
    },
    include: { attachments: true },
  });

  return serializePrescription(row);
};

export const createPrescription = async (payload, admin) => {
  const draft = await savePrescriptionDraft(payload, admin);
  if (payload.file?.dataUrl) {
    return publishPrescription(draft.id, { file: payload.file }, admin);
  }
  return publishPrescription(draft.id, {}, admin);
};

export const bulkCreatePrescriptions = async (rows, admin) => {
  const results = [];

  for (const [index, row] of rows.entries()) {
    try {
      const item = await createPrescription(row, admin);
      results.push({ index, ok: true, item });
    } catch (error) {
      results.push({
        index,
        ok: false,
        message: error.message || "Upload failed.",
      });
    }
  }

  return {
    total: rows.length,
    uploaded: results.filter((item) => item.ok).length,
    failed: results.filter((item) => !item.ok).length,
    results,
  };
};

export const updatePrescription = async (id, payload, admin) => {
  const data = {
    patientName: normalizeText(payload.patientName),
    phone: payload.phone ? normalizePhone(payload.phone) : undefined,
    appointmentCode: normalizeText(payload.appointmentId || payload.appointmentCode),
    doctorName: normalizeText(payload.doctorName),
    title: normalizeText(payload.title),
    notes: normalizeText(payload.notes),
    age: normalizeText(payload.age),
    gender: normalizeText(payload.gender),
    chiefComplaint: normalizeText(payload.chiefComplaint),
    diagnosis: normalizeText(payload.diagnosis),
    medicines: payload.medicines || payload.templateData?.medicines,
    advice: payload.advice || payload.finalAdvice || payload.templateData?.finalAdvice,
    tests: payload.tests,
    followUpDate: payload.followUpDate ? new Date(payload.followUpDate) : undefined,
    templateData: payload.templateData || payload.notesData,
    printableHtml: normalizeText(payload.printableHtml),
    savedById: admin?.id || undefined,
    uploadedById: admin?.id || undefined,
    uploadedByName: admin?.username || undefined,
  };

  if (payload.prescriptionDate) data.prescriptionDate = new Date(payload.prescriptionDate);

  if (payload.file?.dataUrl) {
    const savedFile = await savePrescriptionDataUrl(payload.file);
    delete savedFile.filePath;
    Object.assign(data, savedFile, { status: "uploaded", uploadedAt: new Date() });
  }

  Object.keys(data).forEach((key) => data[key] === undefined && delete data[key]);

  const row = await prisma.prescription.update({ where: { id }, data, include: { attachments: true } });
  return serializePrescription(row);
};

export const publishPrescription = async (id, payload, admin) => {
  const current = await prisma.prescription.findUnique({ where: { id }, include: { attachments: true } });
  if (!current || current.status === "deleted") {
    throw Object.assign(new Error("Prescription not found."), { statusCode: 404 });
  }

  const data = {
    status: "uploaded",
    uploadedAt: new Date(),
    uploadedById: admin?.id || "",
    uploadedByName: admin?.username || admin?.role || "Admin",
  };

  if (payload.file?.dataUrl) {
    const savedFile = await savePrescriptionDataUrl(payload.file);
    delete savedFile.filePath;
    Object.assign(data, savedFile);
  } else if (!current.fileUrl) {
    Object.assign(data, {
      fileName: `${current.prescriptionCode || current.id}.html`,
      originalFileName: `${current.prescriptionCode || current.id}.html`,
      fileUrl: "",
      fileMimeType: "text/html",
      fileSize: 0,
    });
  }

  const row = await prisma.prescription.update({
    where: { id },
    data,
    include: { attachments: { orderBy: { sortOrder: "asc" } } },
  });

  return serializePrescription(row);
};

export const addPrescriptionAttachments = async (id, attachments, admin) => {
  const prescription = await prisma.prescription.findUnique({ where: { id } });
  if (!prescription || prescription.status === "deleted") {
    throw Object.assign(new Error("Prescription not found."), { statusCode: 404 });
  }

  const saved = [];
  for (const [index, attachment] of attachments.entries()) {
    const file = await savePrescriptionDataUrl(attachment.file || attachment);
    delete file.filePath;
    const attachmentType = file.fileMimeType === "application/pdf" ? "pdf" : file.fileMimeType.startsWith("image/") ? "image" : "other";
    saved.push(
      await prisma.prescriptionAttachment.create({
        data: {
          prescriptionId: id,
          fileName: file.fileName,
          originalName: file.originalFileName,
          fileUrl: file.fileUrl,
          fileMimeType: file.fileMimeType,
          fileSize: file.fileSize,
          attachmentType,
          title: normalizeText(attachment.title) || file.originalFileName,
          note: normalizeText(attachment.note),
          sortOrder: Number(attachment.sortOrder ?? index),
          uploadedById: admin?.id || "",
        },
      }),
    );
  }

  return saved;
};

export const deletePrescriptionAttachment = async (prescriptionId, attachmentId) => {
  const attachment = await prisma.prescriptionAttachment.findFirst({
    where: { id: attachmentId, prescriptionId },
  });
  if (!attachment) {
    throw Object.assign(new Error("Attachment not found."), { statusCode: 404 });
  }
  await prisma.prescriptionAttachment.delete({ where: { id: attachmentId } });
};

export const duplicateFollowUp = async (id, admin) => {
  const current = await prisma.prescription.findUnique({
    where: { id },
    include: { attachments: { orderBy: { sortOrder: "asc" } } },
  });
  if (!current || current.status === "deleted") {
    throw Object.assign(new Error("Prescription not found."), { statusCode: 404 });
  }

  const prescriptionCode = `RX-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  const row = await prisma.prescription.create({
    data: {
      prescriptionCode,
      patientIdText: current.patientIdText,
      patientCode: current.patientCode,
      patientName: current.patientName,
      phone: current.phone,
      age: current.age,
      gender: current.gender,
      appointmentId: current.appointmentId,
      appointmentCode: current.appointmentCode,
      doctorName: current.doctorName,
      prescriptionDate: new Date(),
      title: current.title,
      chiefComplaint: current.chiefComplaint,
      diagnosis: current.diagnosis,
      medicines: current.medicines,
      advice: current.advice,
      tests: current.tests,
      notes: current.notes,
      templateData: current.templateData,
      printableHtml: current.printableHtml,
      status: "pending_upload",
      sourcePrescriptionId: current.id,
      savedById: admin?.id || "",
      uploadedByName: admin?.username || admin?.role || "Admin",
    },
    include: { attachments: true },
  });

  return serializePrescription(row);
};

export const softDeletePrescription = async (id) => {
  await prisma.prescription.update({ where: { id }, data: { status: "deleted" } });
};

export const searchPatients = async (query) => {
  const term = normalizeText(query).toLowerCase();
  const rows = await prisma.appointment.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
  const seen = new Set();

  return rows
    .map((row) => {
      const data = row.data || {};
      return {
        patientId: data.patientCode || data.patientId || data.id || "",
        patientName: data.patientName || data.name || "",
        phone: data.phone || data.mobile || "",
        appointmentId: data.appointmentCode || data.serial || data.id || row.id,
      };
    })
    .filter((item) => {
      const key = `${item.patientId}:${item.phone}`;
      if (seen.has(key)) return false;
      seen.add(key);
      if (!term) return true;
      return [item.patientId, item.patientName, item.phone, item.appointmentId]
        .join(" ")
        .toLowerCase()
        .includes(term);
    })
    .slice(0, 20);
};

export const findPublicPrescriptions = async ({ patientId, phone }) => {
  const patientIdText = normalizeText(patientId);
  const normalizedPhone = normalizePhone(phone);

  if (!patientIdText || !normalizedPhone) {
    throw Object.assign(new Error("Patient ID and phone number are required."), { statusCode: 400 });
  }

  const rows = await prisma.prescription.findMany({
    where: {
      patientIdText,
      phone: normalizedPhone,
      status: { in: ["uploaded", "active"] },
    },
    select: publicPrescriptionSelect,
    orderBy: { prescriptionDate: "desc" },
  });

  return rows.map((item) => serializePrescription(item, true));
};

export const createPrescriptionOtp = async ({ patientId, phone }) => {
  const matches = await findPublicPrescriptions({ patientId, phone });
  if (!matches.length) {
    throw Object.assign(new Error("Prescription not found for this Patient ID and phone."), { statusCode: 404 });
  }

  const otp = String(crypto.randomInt(100000, 999999));
  const patientCode = normalizeText(patientId);
  const normalizedPhone = normalizePhone(phone);

  await prisma.prescriptionOtp.create({
    data: {
      phone: normalizedPhone,
      patientCode,
      otpHash: hashOtp({ phone: normalizedPhone, patientCode, otp }),
      expiresAt: new Date(Date.now() + 5 * 60 * 1000),
    },
  });

  return {
    maskedPhone: normalizedPhone.replace(/(\d{3})\d+(\d{2})$/, "$1******$2"),
    demoOtp: process.env.NODE_ENV === "production" ? undefined : otp,
  };
};

export const verifyPrescriptionOtp = async ({ patientId, phone, otp }) => {
  const patientCode = normalizeText(patientId);
  const normalizedPhone = normalizePhone(phone);
  const code = normalizeText(otp);

  const row = await prisma.prescriptionOtp.findFirst({
    where: {
      phone: normalizedPhone,
      patientCode,
      verifiedAt: null,
      expiresAt: { gt: new Date() },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!row) throw Object.assign(new Error("OTP expired. Please send a new OTP."), { statusCode: 400 });
  if (row.attempts >= 5) throw Object.assign(new Error("Too many attempts. Please send a new OTP."), { statusCode: 429 });

  const valid = row.otpHash === hashOtp({ phone: normalizedPhone, patientCode, otp: code });
  if (!valid) {
    await prisma.prescriptionOtp.update({ where: { id: row.id }, data: { attempts: { increment: 1 } } });
    throw Object.assign(new Error("Invalid OTP."), { statusCode: 400 });
  }

  await prisma.prescriptionOtp.update({ where: { id: row.id }, data: { verifiedAt: new Date() } });
  return findPublicPrescriptions({ patientId: patientCode, phone: normalizedPhone });
};
