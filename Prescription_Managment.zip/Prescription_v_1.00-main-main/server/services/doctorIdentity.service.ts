import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { prisma } from "../prisma";
import { defaultContent } from "../defaults";

const identityUploadDir = path.resolve(process.cwd(), "uploads/identity");
const allowedImageTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);

const stringValue = (value, fallback = "") => {
  const text = String(value ?? "").trim();
  return text || fallback;
};

const cleanText = (value, max = 500) =>
  stringValue(value).replace(/[<>]/g, "").slice(0, max);

export const normalizeIdentity = (data = {}) => {
  const fallback = defaultContent.profile || {};
  const merged = { ...fallback, ...data };
  const doctorName = cleanText(merged.doctorName || merged.name || fallback.doctorName, 140);
  const doctorTitle = cleanText(merged.doctorTitle || merged.title || fallback.title, 180);
  const clinicName = cleanText(
    merged.clinicName || merged.siteName || merged.chamberName || merged.brandName || fallback.chamberName,
    180,
  );
  const profilePhotoUrl = cleanText(
    merged.profilePhotoUrl || merged.profileImageUrl || merged.photo || fallback.profileImageUrl,
    700,
  );

  return {
    ...merged,
    doctorName,
    name: doctorName,
    doctorTitle,
    title: doctorTitle,
    designation: cleanText(merged.designation || merged.department || fallback.title, 180),
    department: cleanText(merged.department || merged.designation || fallback.title, 180),
    specialization: cleanText(merged.specialization || fallback.specialization, 240),
    qualification: cleanText(merged.qualification || merged.specialization || fallback.specialization, 240),
    professionalBio: cleanText(merged.professionalBio || merged.longBio || fallback.longBio, 1200),
    longBio: cleanText(merged.longBio || merged.professionalBio || fallback.longBio, 1200),
    shortIntro: cleanText(merged.shortIntro || merged.shortBio || fallback.shortBio, 500),
    shortBio: cleanText(merged.shortBio || merged.shortIntro || fallback.shortBio, 500),
    profilePhotoUrl,
    profileImageUrl: profilePhotoUrl,
    photo: profilePhotoUrl,
    clinicName,
    siteName: cleanText(merged.siteName || clinicName, 180),
    brandName: cleanText(merged.brandName || fallback.brandName || "CareBridge", 120),
    navbarSubtitle: cleanText(merged.navbarSubtitle || doctorName, 180),
    chamberName: cleanText(merged.chamberName || clinicName, 180),
    chamberRoom: cleanText(merged.chamberRoom || merged.roomInfo || "", 120),
    chamberAddress: cleanText(merged.chamberAddress || fallback.chamberAddress, 300),
    phone: cleanText(merged.phone || fallback.phone, 80),
    email: cleanText(merged.email || fallback.email, 160),
    emergencyPhone: cleanText(merged.emergencyPhone || "", 80),
    consultationMode: cleanText(merged.consultationMode || merged.mode || "In-person", 120),
    consultationHours: cleanText(merged.consultationHours || merged.visitingTime || fallback.visitingTime, 180),
    visitingTime: cleanText(merged.visitingTime || merged.consultationHours || fallback.visitingTime, 180),
    scheduleText: cleanText(merged.scheduleText || merged.visitingDays || fallback.visitingDays, 180),
    visitingDays: cleanText(merged.visitingDays || merged.scheduleText || fallback.visitingDays, 180),
    startTime: cleanText(merged.startTime || "", 30),
    endTime: cleanText(merged.endTime || "", 30),
    dailyPatientLimit: Number(merged.dailyPatientLimit || 0) || undefined,
    availableStatus: cleanText(merged.availableStatus || "Available", 80),
    socialLinks: merged.socialLinks && typeof merged.socialLinks === "object" ? merged.socialLinks : fallback.socialLinks || {},
    ctaButtonText: cleanText(merged.ctaButtonText || merged.ctaText || fallback.ctaText, 80),
    ctaText: cleanText(merged.ctaText || merged.ctaButtonText || fallback.ctaText, 80),
    footerNotice: cleanText(merged.footerNotice || merged.footerText || "", 500),
    prescriptionHeaderTitle: cleanText(merged.prescriptionHeaderTitle || clinicName, 220),
    prescriptionFooterNote: cleanText(
      merged.prescriptionFooterNote || "This is a digital prescription / এটি একটি ডিজিটাল প্রেসক্রিপশন।",
      220,
    ),
  };
};

export const getIdentity = async () => {
  const row = await prisma.siteContent.findUnique({ where: { type: "profile" } });
  return normalizeIdentity(row?.data || defaultContent.profile);
};

export const updateIdentity = async (payload = {}) => {
  const current = await getIdentity();
  const next = normalizeIdentity({ ...current, ...payload });
  const row = await prisma.siteContent.upsert({
    where: { type: "profile" },
    update: { data: next },
    create: { type: "profile", data: next },
  });
  return normalizeIdentity(row.data);
};

export const getPublicIdentity = async () => {
  const identity = await getIdentity();
  const {
    doctorName,
    doctorTitle,
    title,
    designation,
    department,
    specialization,
    qualification,
    professionalBio,
    longBio,
    shortIntro,
    shortBio,
    profilePhotoUrl,
    profileImageUrl,
    clinicName,
    siteName,
    brandName,
    navbarSubtitle,
    chamberName,
    chamberRoom,
    chamberAddress,
    phone,
    email,
    emergencyPhone,
    consultationMode,
    consultationHours,
    visitingDays,
    visitingTime,
    scheduleText,
    availableStatus,
    socialLinks,
    ctaButtonText,
    ctaText,
    footerNotice,
    prescriptionHeaderTitle,
    prescriptionFooterNote,
  } = identity;

  return {
    doctorName,
    doctorTitle,
    title,
    designation,
    department,
    specialization,
    qualification,
    professionalBio,
    longBio,
    shortIntro,
    shortBio,
    profilePhotoUrl,
    profileImageUrl,
    clinicName,
    siteName,
    brandName,
    navbarSubtitle,
    chamberName,
    chamberRoom,
    chamberAddress,
    phone,
    email,
    emergencyPhone,
    consultationMode,
    consultationHours,
    visitingDays,
    visitingTime,
    scheduleText,
    availableStatus,
    socialLinks,
    ctaButtonText,
    ctaText,
    footerNotice,
    prescriptionHeaderTitle,
    prescriptionFooterNote,
  };
};

export const saveIdentityPhoto = async ({ fileName, mimeType, dataUrl }) => {
  const type = String(mimeType || "").toLowerCase();
  const extension = allowedImageTypes.get(type);
  if (!extension) {
    throw Object.assign(new Error("Only JPG, PNG and WEBP images are allowed."), { statusCode: 400 });
  }

  const encoded = String(dataUrl || "").split(",").pop() || "";
  const buffer = Buffer.from(encoded, "base64");
  if (!buffer.length || buffer.length > 2.5 * 1024 * 1024) {
    throw Object.assign(new Error("Photo must be under 2.5MB."), { statusCode: 400 });
  }

  await fs.mkdir(identityUploadDir, { recursive: true });
  const safeBase =
    String(fileName || "doctor-photo")
      .replace(/\.[^.]+$/, "")
      .replace(/[^a-z0-9_-]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "doctor-photo";
  const savedName = `${Date.now()}-${crypto.randomBytes(5).toString("hex")}-${safeBase}.${extension}`;
  await fs.writeFile(path.join(identityUploadDir, savedName), buffer);

  const url = `/uploads/identity/${savedName}`;
  const identity = await updateIdentity({ profilePhotoUrl: url, profileImageUrl: url, photo: url });
  return { url, identity };
};
