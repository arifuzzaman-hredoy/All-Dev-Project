const pad = (value, length = 2) => String(value).padStart(length, "0");

export const buildTrackingCode = ({
  prefix = "Demo",
  date = new Date(),
  serial = 1,
} = {}) => {
  const year = pad(date.getFullYear() % 100);
  const day = pad(date.getDate());
  const month = pad(date.getMonth() + 1);
  const serialText = pad(serial, 2);

  return `${prefix}-${year}${day}${month}${serialText}`;
};

export const getDateRange = (date = new Date()) => {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  return { start, end };
};

export const generatePublicTrackingCode = async ({
  prisma,
  prefix = "Demo",
  date = new Date(),
  field = "appointmentCode",
}) => {
  const { start, end } = getDateRange(date);
  const existing = await prisma.appointment.findMany({
    where: {
      createdAt: {
        gte: start,
        lt: end,
      },
    },
    select: {
      data: true,
    },
  });

  const usedSerials = existing
    .map((item) => String(item.data?.[field] || ""))
    .map((code) => Number(code.slice(-2)))
    .filter((serial) => Number.isFinite(serial) && serial > 0);

  const nextSerial = usedSerials.length ? Math.max(...usedSerials) + 1 : 1;

  return buildTrackingCode({ prefix, date, serial: nextSerial });
};

export const generateAppointmentCode = (options) =>
  generatePublicTrackingCode({ ...options, field: "appointmentCode" });

export const generatePatientCode = (options) =>
  generatePublicTrackingCode({ ...options, field: "patientCode" });
