import crypto from "node:crypto";

const getSecret = () =>
  process.env.JWT_SECRET ||
  process.env.ADMIN_SESSION_SECRET ||
  "change-this-secret-before-production";

const toBase64Url = (value) => Buffer.from(value).toString("base64url");
const fromBase64Url = (value) => Buffer.from(value, "base64url").toString("utf8");

export const createDownloadToken = ({ prescriptionId, phone, patientCode, expiresInSeconds = 900 }) => {
  const payload = {
    prescriptionId,
    phone,
    patientCode,
    exp: Date.now() + expiresInSeconds * 1000,
  };
  const encoded = toBase64Url(JSON.stringify(payload));
  const signature = crypto.createHmac("sha256", getSecret()).update(encoded).digest("base64url");
  return `${encoded}.${signature}`;
};

export const verifyDownloadToken = (token) => {
  const [encoded, signature] = String(token || "").split(".");
  if (!encoded || !signature) return null;

  const expected = crypto.createHmac("sha256", getSecret()).update(encoded).digest("base64url");
  if (signature.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;

  const payload = JSON.parse(fromBase64Url(encoded));
  if (!payload.exp || Date.now() > payload.exp) return null;
  return payload;
};

export const hashOtp = ({ phone, patientCode, otp }) => {
  return crypto
    .createHmac("sha256", getSecret())
    .update(`${patientCode}:${phone}:${otp}`)
    .digest("hex");
};
