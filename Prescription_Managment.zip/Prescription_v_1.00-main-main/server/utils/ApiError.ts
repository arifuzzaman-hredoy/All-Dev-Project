export class ApiError extends Error {
  statusCode: number;
  code: string;

  constructor(statusCode: number, message: string, code = "API_ERROR") {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

export const forbidden = (message = "Forbidden.") =>
  new ApiError(403, message, "FORBIDDEN");

export const unauthorized = (message = "Unauthorized.") =>
  new ApiError(401, message, "UNAUTHORIZED");
