import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

const allowedPrescriptionTypes = new Map([
  ["application/pdf", "pdf"],
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);

const maxPrescriptionBytes = 10 * 1024 * 1024;

export const prescriptionUploadDir = path.resolve(process.cwd(), "uploads/prescriptions");

const sanitizeBaseName = (fileName = "prescription") => {
  return (
    String(fileName)
      .replace(/\.[^.]+$/, "")
      .replace(/[^a-z0-9_-]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 70) || "prescription"
  );
};

export const savePrescriptionDataUrl = async ({ fileName, mimeType, dataUrl }) => {
  const type = String(mimeType || "").toLowerCase();
  const extension = allowedPrescriptionTypes.get(type);

  if (!extension) {
    const error = new Error("Only PDF, JPG, JPEG, PNG and WEBP files are allowed.");
    error.statusCode = 400;
    throw error;
  }

  const encoded = String(dataUrl || "").split(",").pop() || "";
  const buffer = Buffer.from(encoded, "base64");

  if (!buffer.length) {
    const error = new Error("Prescription file is required.");
    error.statusCode = 400;
    throw error;
  }

  if (buffer.length > maxPrescriptionBytes) {
    const error = new Error("Prescription file must be under 10MB.");
    error.statusCode = 400;
    throw error;
  }

  await fs.mkdir(prescriptionUploadDir, { recursive: true });

  const safeBase = sanitizeBaseName(fileName);
  const savedName = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}-${safeBase}.${extension}`;
  const filePath = path.join(prescriptionUploadDir, savedName);

  await fs.writeFile(filePath, buffer);

  return {
    fileName: savedName,
    originalFileName: fileName || savedName,
    fileUrl: `/uploads/prescriptions/${savedName}`,
    fileMimeType: type,
    fileSize: buffer.length,
    filePath,
  };
};

export const getPrescriptionFilePath = (fileUrl = "") => {
  const fileName = path.basename(String(fileUrl));
  return path.join(prescriptionUploadDir, fileName);
};
