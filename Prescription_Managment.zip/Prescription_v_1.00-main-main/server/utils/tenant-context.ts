export const DEFAULT_TENANT_HEADER = "x-tenant-slug";

export const getTenantSlugFromRequest = (req) => {
  const headerValue = req.headers?.[DEFAULT_TENANT_HEADER];
  const host = String(req.headers?.host || "");

  if (Array.isArray(headerValue)) return headerValue[0] || "";
  if (headerValue) return String(headerValue);

  const subdomain = host.split(".")[0];
  if (subdomain && !["localhost", "127", "www"].includes(subdomain)) {
    return subdomain;
  }

  return "";
};

export const resolveTenantId = (req) => {
  return req.admin?.tenantId || req.tenant?.id || "";
};
