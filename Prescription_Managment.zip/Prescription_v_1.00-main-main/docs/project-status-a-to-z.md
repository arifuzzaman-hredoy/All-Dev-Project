# Project Status A to Z

Last checked: 2026-06-21

Latest fix pass on 2026-06-21:

- Clinic API route files are now mounted in `server/index.ts`.
- Clinic route files were converted from CommonJS to ESM so they can run under the current `type: module` project setup.
- `/clinic/prescriptions` now opens the real CRUD page from `src/pages/ClinicPrescriptionsPage.tsx`.
- `/api/clinic/my-plan` now exists with Prisma-backed data when available and safe fallback data otherwise.
- Clinic appointment rows now include an `RX` action that opens `/clinic/prescriptions` with patient details prefilled.

এই ডকুমেন্টে প্রজেক্টে কী কী কাজ হয়েছে, কোনগুলো আংশিক হয়েছে, কোনগুলো UI shell মাত্র, আর কোনগুলো এখনো access/connected হয়নি সেটা এক জায়গায় লেখা হলো।

## Short Summary

- Frontend route system বড় করে তৈরি করা হয়েছে: SaaS public site, Super Admin, Clinic, Diagnostic, Hospital, Doctor panel, Public user auth, Public website pages।
- Doctor panel-এর prescription, appointment, CMS, Q&A, gallery, profile, accounts, access-control এর real backend/API কাজ আছে।
- Clinic panel-এর users, doctors, appointments, patients, encounters, prescriptions backend routes now mount through `server/index.ts`.
- Diagnostic এবং Hospital module মূলত future/demo shell হিসেবে আছে।
- Prisma schema অনেক বড় এবং production-level module model আছে, কিন্তু schema-এর অনেক model-এর জন্য route/service/controller এখনো তৈরি হয়নি।
- Duplicate prescription issue fixed: `/clinic/prescriptions` now points to the real CRUD page.

## Run/Build Foundation

Implemented:

- React 19 + Vite frontend।
- Express backend under `server/index.ts`।
- Prisma + PostgreSQL configured in `prisma/schema.prisma`।
- Scripts:
  - `npm run dev`
  - `npm run build`
  - `npm run typecheck`
  - `npm run lint`
  - `npm run dev:api`
  - `npm run start`
  - `npm run db:generate`
  - `npm run db:push`
  - `npm run db:migrate`
  - `npm run db:seed`
  - `npm run deploy:check`

Needs work:

- README এখনো default Vite template style, full project guide লেখা হয়নি।
- Automated test suite দেখা যায়নি।
- Some docs exist, but current implementation status fully synced ছিল না।

## Frontend Route Access

Main route file: `src/App.tsx`

Accessible route groups:

- SaaS public routes:
  - `/`
  - `/pricing`
  - `/demo`
  - `/book-demo`
  - `/contact-sales`
  - `/login`
- Demo public website routes:
  - `/demo/public/single-doctor`
  - `/demo/public/pro-doctor`
  - `/demo/public/clinic`
  - `/demo/public/diagnostic`
  - `/demo/public/hospital`
  - `/site/single-doctor-demo`
  - `/site/clinic-demo`
  - `/site/diagnostic-demo`
  - `/site/hospital-demo`
  - `/site/:tenantSlug`
- Public doctor/clinic website routes:
  - `/about`
  - `/services`
  - `/appointment`
  - `/blogs`
  - `/blogs/:slug`
  - `/qa`
  - `/gallery`
  - `/contact`
  - `/patient-prescription`
  - `/doctor-site`
- Public user auth routes:
  - `/user/register`
  - `/user/login`
  - `/user/forgot-password`
  - `/user/verify-otp`
  - `/user/reset-password`
- Admin login:
  - `/admin`
- Super Admin panel:
  - `/super-admin/dashboard`
  - `/super-admin/tenants`
  - `/super-admin/tenants/create`
  - `/super-admin/packages`
  - `/super-admin/modules`
  - `/super-admin/subscriptions`
  - `/super-admin/payments`
  - `/super-admin/sms`
  - `/super-admin/demo`
  - `/super-admin/support`
  - `/super-admin/leads`
  - `/super-admin/commission`
  - `/super-admin/audit-logs`
  - `/super-admin/settings`
- Clinic panel:
  - `/clinic/dashboard`
  - `/clinic/my-plan`
  - `/clinic/users`
  - `/clinic/doctors`
  - `/clinic/appointments`
  - `/clinic/patients`
  - `/clinic/encounters`
  - `/clinic/prescriptions`
  - `/clinic/billing`
  - `/clinic/payments`
  - `/clinic/patient-ledger`
  - `/clinic/reports`
  - `/clinic/sms-wallet`
  - `/clinic/support`
  - `/clinic/website-cms`
  - `/clinic/settings`
  - `/clinic/diagnostic`
  - `/clinic/inventory`
- Diagnostic panel:
  - `/diagnostic/dashboard`
  - `/diagnostic/test-catalog`
  - `/diagnostic/lab-orders`
  - `/diagnostic/sample-collection`
  - `/diagnostic/reports`
  - `/diagnostic/billing`
  - `/diagnostic/delivery`
- Hospital panel:
  - `/hospital/dashboard`
  - `/hospital/opd`
  - `/hospital/ipd`
  - `/hospital/admission`
  - `/hospital/beds`
  - `/hospital/billing`
  - `/hospital/discharge`
  - `/hospital/pharmacy`
  - `/hospital/reports`
- Doctor panel under protected route:
  - `/doctor/dashboard`
  - `/doctor/appointment-manager`
  - `/doctor/appointments`
  - `/doctor/patients`
  - `/doctor/users`
  - `/doctor/patient-records`
  - `/doctor/patients/:id`
  - `/doctor/patients/:patientId/prescriptions`
  - `/doctor/patients/:id/action/:actionType`
  - `/doctor/prescriptions`
  - `/doctor/prescription`
  - `/doctor/upload-prescription`
  - `/doctor/follow-up`
  - `/doctor/messages`
  - `/doctor/profile`
  - `/doctor/panel-settings`
  - `/doctor/open-settings`
  - `/doctor/website-cms`
  - `/doctor/blog-manager`
  - `/doctor/qa-manager`
  - `/doctor/gallery-manager`
  - `/doctor/access-control`
  - `/doctor/accounts`
  - `/doctor/reports`
  - `/doctor/settings`

## Backend Routes Currently Mounted

Mounted in `server/index.ts`:

- `/api/health`
- `/api/admin/login`
- `/api/admin/change-password`
- `/api/content`
- `/api/content/:type`
- `/api/admin/upload`
- `/api/appointments`
- `/api/messages`
- `/api/questions`
- `/api/public/register`
- `/api/public/login`
- `/api/accounts`
- `/api/access-control`
- `/api/app/context`
- `/api/cms/theme-settings`
- `/api/doctor/identity`
- `/api/admin/site-identity`
- `/api/public/doctor-identity`
- `/api/doctor/prescriptions`
- `/api/public/prescriptions`

Important note:

- `server/routes/clinicDoctors.routes.js`, `clinicAppointments.routes.js`, `clinicPatients.routes.js`, `clinicEncounters.routes.js`, `clinicPrescriptions.routes.js`, and `clinicUsers.routes.js` are now imported/mounted in `server/index.ts`.
- Frontend calls like `/api/clinic/doctors`, `/api/clinic/patients`, `/api/clinic/appointments`, `/api/clinic/encounters`, `/api/clinic/prescriptions`, `/api/clinic/users` now reach the main Express server.

## Completed / Mostly Working Areas

### Doctor Panel

Implemented:

- Doctor dashboard UI.
- Doctor appointment manager connected to `/api/appointments`.
- Public appointment request flow connected to `/api/appointments`.
- Doctor prescription module connected to Prisma:
  - list prescriptions
  - save draft
  - upload prescription
  - bulk upload
  - update prescription
  - delete/soft delete
  - attachments
  - duplicate follow-up
  - print/download
  - patient prescription history
- Public prescription lookup:
  - lookup by patient ID/phone
  - OTP send/verify
  - secure download token
- Doctor identity/profile API:
  - get/update identity
  - photo upload
  - public identity
- Doctor CMS sections:
  - website CMS
  - blogs
  - Q&A
  - gallery
  - theme settings
- Access control:
  - role-feature permissions
  - assistant access policy
  - protected doctor panel navigation permissions
- Accounts:
  - appointment income
  - expenses
  - due collections
  - other incomes
  - summary/overall reporting

Needs work:

- Some doctor pages may still use mock/local state for parts of UI.
- Strong tenant isolation middleware is documented but not fully applied everywhere.
- Audit log writing is not fully wired for sensitive actions.

### Public Website

Implemented:

- Public home/site demo routes.
- About, services, appointment, blogs, blog details, Q&A, gallery, contact, prescription lookup pages.
- CMS content is loaded from `SiteContent` with fallback defaults.
- Theme variants exist for hero, navbar, services, about, doctors, appointment, gallery, blogs, Q&A, contact, footer.

Needs work:

- Tenant-specific public site resolution is not complete across all APIs.
- Public user flows need full production auth lifecycle validation.

### Super Admin

Implemented:

- Super admin route group and sidebar.
- Dashboard UI.
- Tenants/modules/pages exist.
- Prisma schema includes SaaS foundation:
  - Tenant
  - BusinessUnit
  - Package
  - Module
  - Feature
  - PackageModule
  - PackageFeature
  - TenantModule
  - TenantFeature
  - Subscription
  - User/Role/Permission/UserRole/RolePermission
  - AuditLog
  - DemoConfig/DemoSession/DemoEvent
  - Lead/SalesActivity/CommissionRule/CommissionLedger

Needs work:

- Many super-admin pages are frontend/demo shell only.
- CRUD APIs for tenant/package/module/subscription/payment/SMS/demo/leads/commission/settings are not fully implemented.
- Tenant creation page is a shell.

## Clinic Panel Status

### Clinic Dashboard

Implemented:

- Dashboard route and UI.
- Quick actions and module navigation.

Needs work:

- Real dashboard analytics API is not implemented.

### Clinic Users

Implemented:

- Full frontend CRUD-style UI exists in `src/pages/clinic/ClinicUsersPage.tsx`.
- Backend route file exists: `server/routes/clinicUsers.routes.js`.

Access:

- `/api/clinic/users` is now mounted in `server/index.ts`.

### Clinic Doctors

Implemented:

- Full frontend CRUD-style UI exists in `src/pages/clinic/ClinicDoctorsPage.tsx`.
- Backend route file exists: `server/routes/clinicDoctors.routes.js`.

Access:

- `/api/clinic/doctors` is now mounted in `server/index.ts`.

### Clinic Appointments

Implemented:

- Full frontend CRUD-style UI exists in `src/pages/clinic/ClinicAppointmentsPage.tsx`.
- Backend route file exists: `server/routes/clinicAppointments.routes.js`.

Access:

- `/api/clinic/appointments` is now mounted in `server/index.ts`.

Separate working route:

- `/api/appointments` exists and is used by doctor appointment manager/public appointment flow.

### Clinic Patients

Implemented:

- Full frontend CRUD-style UI exists in `src/pages/clinic/ClinicPatientsPage.tsx`.
- Backend route file exists: `server/routes/clinicPatients.routes.js`.

Access:

- `/api/clinic/patients` is now mounted in `server/index.ts`.

### Clinic Encounters

Implemented:

- Full frontend CRUD-style UI exists in `src/pages/clinic/ClinicEncountersPage.tsx`.
- Backend route file exists: `server/routes/clinicEncounters.routes.js`.

Access:

- `/api/clinic/encounters` is now mounted in `server/index.ts`.

### Clinic Prescriptions

Current accessible route:

- `/clinic/prescriptions` imports `src/pages/ClinicPrescriptionsPage.tsx`.
- This route now opens the real CRUD page.

Previous issue:

- `src/pages/ClinicPrescriptionsPage.tsx` was previously unreachable from `/clinic/prescriptions`; this is fixed.

Backend route exists:

- `server/routes/clinicPrescriptions.routes.js`

Access:

- `/api/clinic/prescriptions` is now mounted in `server/index.ts`.

### Clinic My Plan

Implemented:

- UI exists in `src/pages/clinic/ClinicMyPlanPage.tsx`.
- It calls `/api/clinic/my-plan`.

Implemented/access:

- `/api/clinic/my-plan` is now mounted.
- It returns Prisma-backed tenant/subscription/module counts when available and safe fallback data otherwise.

### Clinic Billing / Payments / Ledger / Reports / SMS / Support / CMS / Settings / Diagnostic / Inventory

Implemented:

- Routes and sidebar links exist.
- Most of these are `DemoWorkspacePage` shells with descriptions.

Needs work:

- Real CRUD APIs and database integration are not done for these clinic modules.
- Prisma models exist for many of these domains, but services/routes/controllers are not implemented.

## Diagnostic Panel Status

Implemented:

- Dashboard and navigation routes exist.
- Pages exist for:
  - test catalog
  - lab orders
  - sample collection
  - reports
  - billing
  - delivery
- Prisma schema includes lab models:
  - LabTestCategory
  - LabTest
  - LabTestParameter
  - LabOrder
  - LabOrderItem
  - LabReport
  - LabReportResult
  - ReportTemplate

Needs work:

- Diagnostic pages are mostly future/demo shell.
- Real backend routes/services/controllers are not implemented.
- Lab order/report workflow is schema-ready but not app-ready.

## Hospital Panel Status

Implemented:

- Dashboard and navigation routes exist.
- Pages exist for:
  - OPD
  - IPD
  - Admission
  - Beds
  - Billing
  - Discharge
  - Pharmacy
  - Reports
- Prisma schema includes hospital/IPD models:
  - Ward
  - Bed
  - Admission
  - BedTransfer
  - NursingNote
  - DoctorRound
  - ProcedureOrder
  - DischargeSummary

Needs work:

- Hospital pages are future/demo shell.
- Real backend routes/services/controllers are not implemented.
- IPD/admission/beds/discharge workflow is schema-ready but not app-ready.

## Database Schema Status

Implemented schema groups:

- Authentication/admin/public user:
  - AdminUser
  - PublicUser
  - User
  - Role
  - Permission
  - UserRole
  - RolePermission
- Access:
  - AccessPermission
  - AssistantAccessPolicy
- CMS/public site:
  - SiteContent
  - PublicSite
  - CmsContent
  - UploadedFile
- Appointment/prescription:
  - Appointment
  - Prescription
  - PrescriptionAttachment
  - PrescriptionOtp
- Accounts legacy:
  - AccountAppointmentIncome
  - AccountExpense
  - AccountDueCollection
  - AccountOtherIncome
- SaaS tenant/package:
  - Tenant
  - BusinessUnit
  - Package
  - Module
  - Feature
  - PackageModule
  - PackageFeature
  - TenantModule
  - TenantFeature
  - Subscription
- Clinic clinical:
  - Department
  - DoctorProfile
  - DoctorSchedule
  - Holiday
  - Patient
  - PatientClinicalProfile
  - Encounter
  - MedicineCatalog
  - PrescriptionItem
  - PrescriptionTemplate
- Billing/payment/ledger:
  - ServiceCatalog
  - Invoice
  - InvoiceItem
  - Payment
  - PatientLedger
  - ExpenseCategory
  - Expense
  - CashbookEntry
- SMS/support/demo/sales:
  - SmsWallet
  - SmsTransaction
  - SupportTicket
  - SupportReply
  - DemoConfig
  - DemoSession
  - DemoEvent
  - Lead
  - SalesActivity
  - CommissionRule
  - CommissionLedger
- Inventory:
  - InventoryItem
  - Supplier
  - StockMovement
- Diagnostic:
  - LabTestCategory
  - LabTest
  - LabTestParameter
  - LabOrder
  - LabOrderItem
  - LabReport
  - LabReportResult
  - ReportTemplate
- Hospital:
  - Ward
  - Bed
  - Admission
  - BedTransfer
  - NursingNote
  - DoctorRound
  - ProcedureOrder
  - DischargeSummary

Needs work:

- Most newer schema models do not yet have matching production route/service/controller files.
- Tenant relationships are mostly represented by `tenantId` fields, but Prisma relation definitions are limited.
- Migration/deployment validation should be run before production.

## Files That Exist But Are Not Fully Accessed

Important unreachable or partially unreachable files:

- `src/pages/ClinicPrescriptionsPage.tsx`
  - Large CRUD page exists.
  - Now imported by `src/App.tsx` for `/clinic/prescriptions`.
- `server/routes/clinicUsers.routes.js`
  - Exists and is mounted.
- `server/routes/clinicDoctors.routes.js`
  - Exists and is mounted.
- `server/routes/clinicAppointments.routes.js`
  - Exists and is mounted.
- `server/routes/clinicPatients.routes.js`
  - Exists and is mounted.
- `server/routes/clinicEncounters.routes.js`
  - Exists and is mounted.
- `server/routes/clinicPrescriptions.routes.js`
  - Exists and is mounted.
- `src/pages/DoctorOpenSettingsPage.tsx`
  - File exists, but route maps `/doctor/open-settings` to `DoctorPanelSettingsPage`, not this file.
- Top-level older clinic shell files exist:
  - `src/pages/ClinicAppointmentsPage.tsx`
  - `src/pages/ClinicBillingPage.tsx`
  - `src/pages/ClinicDashboardPage.tsx`
  - `src/pages/ClinicPatientLedgerPage.tsx`
  - `src/pages/ClinicPatientsPage.tsx`
  - `src/pages/ClinicReportsPage.tsx`
  - `src/pages/ClinicSmsWalletPage.tsx`
  - `src/pages/ClinicSupportPage.tsx`
  - `src/pages/ClinicWebsiteCmsPage.tsx`
  - These are separate from the currently used `src/pages/clinic/...` files.

## Main Access Problems

1. Clinic API routes are mounted now.

   Needed imports/mounts in `server/index.ts`:

   - `app.use("/api/clinic/users", clinicUsersRoutes)`
   - `app.use("/api/clinic/doctors", clinicDoctorsRoutes)`
   - `app.use("/api/clinic/appointments", clinicAppointmentsRoutes)`
   - `app.use("/api/clinic/patients", clinicPatientsRoutes)`
   - `app.use("/api/clinic/encounters", clinicEncountersRoutes)`
   - `app.use("/api/clinic/prescriptions", clinicPrescriptionsRoutes)`

2. Clinic prescriptions big UI is routed now.

   Current:

   - `/clinic/prescriptions` -> `src/pages/ClinicPrescriptionsPage.tsx` CRUD page

   Remaining cleanup option:

   - Remove or repurpose the old shell file `src/pages/clinic/ClinicPrescriptionsPage.tsx` after confirming no future route needs it.

3. Clinic My Plan route added.

   Frontend calls:

   - `/api/clinic/my-plan`

   Backend route:

   - `/api/clinic/my-plan`

4. Many pages are visible but only demo shells.

   This is expected for future modules, but it should be clearly marked in UI/docs.

5. Tenant middleware is not consistently applied.

   Docs mention:

   - `requireAuth`
   - `requireTenant`
   - `requireModule`
   - `requirePermission`
   - audit logs

   But many current routes are legacy/simple and do not fully use this pattern.

## Suggested Next Work Order

1. Convert clinic JS routes from JSON-file storage to Prisma models if production data is required.
2. Add tenant/auth/module/permission middleware to clinic routes.
3. Add audit logging for create/update/delete/payment/permission actions.
4. Build real Super Admin APIs:
   - tenants
   - packages
   - modules
   - subscriptions
   - payments
   - SMS
   - leads
   - commission
5. Build real Diagnostic APIs:
   - test catalog
   - lab orders
   - sample collection
   - reports
   - delivery
6. Build real Hospital APIs:
   - OPD/IPD
   - admission
   - beds
   - discharge
   - pharmacy
   - reports
7. Update README with actual project setup, env variables, DB setup, run commands, and deployment.
8. Add tests/typecheck/lint verification in CI or deployment script.

## Quick Status Table

| Area | UI | Backend | DB Schema | Access Status |
| --- | --- | --- | --- | --- |
| SaaS public landing/pricing/demo | Done | Mostly static | Partial | Accessible |
| Public doctor website | Done | CMS/content APIs | SiteContent + CMS models | Accessible |
| Public appointment | Done | `/api/appointments` | Appointment | Accessible |
| Public prescription lookup | Done | `/api/public/prescriptions` | Prescription + OTP | Accessible |
| Admin login | Done | `/api/admin/login` | AdminUser | Accessible |
| Doctor dashboard | Done | Partial | Mixed | Accessible |
| Doctor appointments | Done | `/api/appointments` | Appointment | Accessible |
| Doctor prescriptions | Done | `/api/doctor/prescriptions` | Prescription | Accessible |
| Doctor CMS/blog/Q&A/gallery | Done | `/api/content`, theme/settings | SiteContent | Accessible |
| Doctor profile identity | Done | `/api/doctor/identity` | SiteContent profile | Accessible |
| Doctor accounts | Done | `/api/accounts` | Account models | Accessible |
| Doctor access control | Done | `/api/access-control` | AccessPermission | Accessible |
| Super Admin | Many pages | Mostly missing | Schema ready | Mostly shell |
| Clinic dashboard | Done | Missing analytics | Schema ready | UI accessible |
| Clinic users | Done | Mounted route file | Legacy JSON route | UI + API accessible |
| Clinic doctors | Done | Mounted route file | Legacy JSON route | UI + API accessible |
| Clinic appointments | Done | Mounted route file | Legacy JSON route + Appointment model | UI + API accessible |
| Clinic patients | Done | Mounted route file | Legacy JSON route + Patient model | UI + API accessible |
| Clinic encounters | Done | Mounted route file | Legacy JSON route + Encounter model | UI + API accessible |
| Clinic prescriptions | CRUD routed | Mounted route file | Legacy JSON route + Prescription model | UI + API accessible |
| Clinic my plan | Done | `/api/clinic/my-plan` | Subscription/Tenant schema + fallback | UI + API accessible |
| Clinic billing/payments/ledger | Shell | Mostly missing | Schema ready | Shell |
| Clinic reports/SMS/support/CMS/settings | Shell | Mostly missing | Schema ready | Shell |
| Diagnostic | Shell | Missing | Schema ready | Shell |
| Hospital | Shell | Missing | Schema ready | Shell |
| Inventory | Shell | Missing | Schema ready | Shell |

## Final Note

এই project-এর সবচেয়ে বড় কাজ এখন দুই ভাগে:

1. Existing working Doctor/Public/Admin modules stable করা।
2. Clinic/SuperAdmin/Diagnostic/Hospital shell pages-গুলোকে real backend + Prisma + permission + tenant access দিয়ে production-ready করা।
