# Testing Checklist

- Tenant isolation: tenant A cannot read tenant B patients, invoices, CMS, files, or appointments.
- Permission guard: protected routes reject users without the required permission.
- Module disabled: routes reject tenants without the enabled `TenantModule`.
- Appointment serial: serial numbers stay unique per tenant, doctor, and appointment date.
- Queue update: status changes render without a full dashboard reload.
- Billing calculation: invoice subtotal, discount, total, paid, and due are correct.
- Payment transaction: payment, invoice due, cashbook, and ledger update atomically.
- Refund transaction: refund and ledger reversal update atomically.
- Public site slug: tenant public content resolves by slug/header, not request body tenantId.
- Demo mode: destructive actions are blocked or isolated for demo sessions.
- Audit log: sensitive actions create `AuditLog` rows.
- File access: CMS assets can be public; patient/report/payment files require auth.
