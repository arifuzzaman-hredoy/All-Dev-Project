# Deployment Notes

## Required Environment

- `DATABASE_URL`
- `JWT_SECRET` or `ADMIN_SESSION_SECRET`
- `ADMIN_USERNAME`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `CORS_ORIGIN`
- `VITE_API_BASE_URL`
- `UPLOAD_DIR`

SMS placeholders are available in `.env.example`: `SMS_PROVIDER_NAME`,
`SMS_API_KEY`, and `SMS_SENDER_ID`.

## Commands

```bash
npm install
npm run db:generate
npm run db:push
npm run db:seed
npm run lint
npm run build
npm run start
```

Use `npm run dev` for the Vite frontend and `npm run dev:api` for the API in local development.
