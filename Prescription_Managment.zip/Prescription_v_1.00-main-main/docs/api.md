# API Foundation

This project is currently a Vite React app with an Express API under `server/`.
All new clinic ERP routes should keep UI components thin and place business logic
under `server/services`, with route/controller files only handling HTTP concerns.

## Common Rules

- Resolve tenant context from authenticated session or `x-tenant-slug`; do not trust `tenantId` in request body/query.
- Protect tenant routes with `requireAuth`, `requireTenant`, `requireModule`, and `requirePermission` as appropriate.
- Write `AuditLog` rows for sensitive create/update/delete, payment, package, permission, and support actions.
- Use Prisma transactions for invoice, payment, refund, ledger, and package entitlement updates.

## Existing Routes

| Route | Method | Permission | Module | Notes |
| --- | --- | --- | --- | --- |
| `/api/health` | GET | Public | None | Returns app, service, version, env, and timestamp. |
| `/api/admin/login` | POST | Public | None | Authenticates current admin user. |
| `/api/admin/change-password` | POST | Admin | None | Sensitive action; should write audit log when migrated. |
| `/api/content` | GET | Public | `CLINIC_PUBLIC_SITE` | Legacy public CMS aggregate with DB fallback. |
| `/api/content/:type` | GET | Public | `CLINIC_CMS` | Legacy CMS content by section. |
| `/api/content/:type` | PUT | Admin | `CLINIC_CMS` | Updates CMS data. |
| `/api/admin/upload` | POST | Admin | `CLINIC_CMS` | Public CMS image upload; private upload module will use `UploadedFile`. |
| `/api/appointments` | POST | Public | `CLINIC_APPOINTMENT` | Public appointment request. |
| `/api/appointments` | GET | Admin | `CLINIC_APPOINTMENT` | Legacy appointment list. |
| `/api/appointments/:id/status` | PUT | Admin | `CLINIC_APPOINTMENT` | Legacy status update. |
| `/api/messages` | GET/POST | Public/Admin | `CLINIC_SUPPORT` | Legacy patient message flow. |

## Target Route Shape

```ts
router.post(
  "/api/clinic/invoices",
  requireAuth,
  requireTenant,
  requireModule("CLINIC_BILLING_BASIC"),
  requirePermission("invoice:create"),
  asyncHandler(async (req, res) => {
    const tenantId = resolveTenantId(req);
    const invoice = await billingService.createInvoice({ tenantId, actor: req.admin, body: req.body });
    await writeAuditLog(req, "invoice.create", { entityType: "Invoice", entityId: invoice.id });
    res.status(201).json({ ok: true, data: invoice });
  }),
);
```

## Common Errors

| Code | Status | Meaning |
| --- | --- | --- |
| `UNAUTHORIZED` | 401 | Missing or invalid session/tenant context. |
| `FORBIDDEN` | 403 | Missing role, permission, or module entitlement. |
| `VALIDATION_ERROR` | 400 | Request body failed validation. |
| `CONFLICT` | 409 | Duplicate tenant slug, invoice number, or serial. |
