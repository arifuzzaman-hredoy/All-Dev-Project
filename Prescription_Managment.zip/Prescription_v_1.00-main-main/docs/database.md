# Database Foundation

`prisma/schema.prisma` now keeps the current single-doctor tables compatible and
adds a tenant-ready Clinic ERP SaaS foundation.

## Migration Strategy

1. Keep existing JSON-backed public CMS, appointment, and prescription APIs stable.
2. Backfill `tenantId` on legacy rows once a default tenant is created.
3. Move new APIs to first-class tables such as `Patient`, `Encounter`, `Invoice`,
   `Payment`, `PatientLedger`, `CmsContent`, and `PublicSite`.
4. Remove localStorage fallbacks only after DB-backed APIs are live for the same UI shape.

## Critical Integrity Rules

- Every business table has `tenantId` and tenant indexes.
- Appointment, prescription, invoice, lab order, and ledger data can link through `Encounter`.
- Financial writes must be transactional: invoice items, payments, due updates, and ledger rows belong in one `$transaction`.
- Module access is enforced by `TenantModule`, not by hidden frontend menu items.

## Future Hooks

Inventory, diagnostic reporting, SMS wallet, support, demo, lead/commission, and
basic IPD models exist as schema hooks. They are not full workflows yet.
