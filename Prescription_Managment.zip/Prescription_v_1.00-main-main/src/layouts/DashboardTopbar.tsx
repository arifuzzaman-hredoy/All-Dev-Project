import {
  BellDot,
  ChevronRight,
  LogOut,
  Power,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import {
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
} from "react";

const workspaceItems = [
  { label: "Dashboard", to: "/clinic/dashboard", hint: "Clinic overview" },
  { label: "My Plan", to: "/clinic/my-plan", hint: "Package and billing" },
  { label: "Users", to: "/clinic/users", hint: "Team access" },
  { label: "Doctors", to: "/clinic/doctors", hint: "Doctor profiles" },
  { label: "Appointments", to: "/clinic/appointments", hint: "Booking records" },
  { label: "Patients", to: "/clinic/patients", hint: "Patient database" },
  { label: "Prescriptions", to: "/clinic/prescriptions", hint: "Prescription flow" },
  { label: "Billing", to: "/clinic/billing", hint: "Invoices and due" },
  { label: "Payments", to: "/clinic/payments", hint: "Payment records" },
  { label: "Reports", to: "/clinic/reports", hint: "Clinic analytics" },
  { label: "Website CMS", to: "/clinic/website-cms", hint: "Public site content" },
  { label: "Settings", to: "/clinic/settings", hint: "Panel settings" },
];

const notifications = [
  {
    title: "Plan usage updated",
    description: "SMS wallet and patient usage synced.",
    time: "2 min ago",
    tone: "teal",
  },
  {
    title: "Renewal reminder",
    description: "Next subscription renewal is due soon.",
    time: "Today",
    tone: "amber",
  },
  {
    title: "Backend fallback active",
    description: "API unavailable হলে safe mock data দেখাবে।",
    time: "System",
    tone: "slate",
  },
];

const titleCase = (value: string) =>
  value
    .split("-")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");

const DashboardTopbar = () => {
  const { pathname } = useLocation();
  const navigate = useNavigate();

  const searchRef = useRef<HTMLDivElement | null>(null);
  const notificationRef = useRef<HTMLDivElement | null>(null);

  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);

  const crumbs = pathname.split("/").filter(Boolean);

  const filteredItems = useMemo(() => {
    const searchText = query.trim().toLowerCase();

    if (!searchText) return workspaceItems.slice(0, 6);

    return workspaceItems
      .filter((item) =>
        `${item.label} ${item.hint} ${item.to}`
          .toLowerCase()
          .includes(searchText),
      )
      .slice(0, 6);
  }, [query]);

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node;

      if (searchRef.current && !searchRef.current.contains(target)) {
        setSearchOpen(false);
      }

      if (
        notificationRef.current &&
        !notificationRef.current.contains(target)
      ) {
        setNotificationOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSearchOpen(false);
        setNotificationOpen(false);
      }
    };

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const goToItem = (to: string) => {
    setQuery("");
    setSearchOpen(false);
    navigate(to);
  };

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const firstItem = filteredItems[0];

    if (firstItem) {
      goToItem(firstItem.to);
    }
  };

  return (
    <header className="sticky top-3 z-40 w-full">
      <div className="flex min-h-[50px] items-center justify-between gap-3 rounded-[1.15rem] border border-teal-100 bg-white/92 px-3 py-2 shadow-[0_10px_34px_rgba(11,86,90,0.09)] backdrop-blur-2xl sm:px-4">
        <div className="flex min-w-0 flex-1 items-center gap-1 overflow-hidden">
          {crumbs.length ? (
            crumbs.map((chunk, index) => {
              const isLast = index === crumbs.length - 1;

              return (
                <span
                  key={`${chunk}-${index}`}
                  className="inline-flex min-w-0 shrink-0 items-center gap-1 text-[10px] font-black tracking-wide"
                >
                  {index > 0 ? (
                    <ChevronRight
                      size={12}
                      strokeWidth={2.6}
                      className="text-slate-300"
                    />
                  ) : (
                    <ShieldCheck
                      size={12}
                      strokeWidth={2.5}
                      className="text-teal-700"
                    />
                  )}

                  <span
                    className={[
                      "max-w-[106px] truncate transition-colors duration-300 sm:max-w-none",
                      isLast ? "text-teal-800" : "text-slate-500",
                    ].join(" ")}
                  >
                    {titleCase(chunk)}
                  </span>
                </span>
              );
            })
          ) : (
            <span className="inline-flex items-center gap-1 text-[10px] font-black tracking-wide text-teal-800">
              <ShieldCheck size={12} strokeWidth={2.5} />
              Workspace
            </span>
          )}
        </div>

        <div ref={searchRef} className="relative hidden w-full max-w-[285px] md:block">
          <form
            onSubmit={handleSearchSubmit}
            className="group flex min-h-9 items-center gap-2 rounded-full bg-cyan-50/75 px-3 text-slate-500 ring-1 ring-transparent transition-all duration-300 focus-within:bg-white focus-within:ring-teal-100"
          >
            <Search
              size={15}
              strokeWidth={2.4}
              className="text-slate-400 transition-colors duration-300 group-focus-within:text-teal-700"
            />

            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSearchOpen(true);
              }}
              onFocus={() => setSearchOpen(true)}
              placeholder="Search workspace"
              className="h-9 min-w-0 flex-1 bg-transparent text-[12px] font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
            />
          </form>

          {searchOpen && (
            <div className="absolute right-0 top-11 z-50 w-full overflow-hidden rounded-[1rem] border border-teal-100 bg-white/96 p-2 shadow-[0_18px_55px_rgba(15,23,42,0.14)] backdrop-blur-2xl">
              {filteredItems.length ? (
                filteredItems.map((item) => (
                  <button
                    key={item.to}
                    type="button"
                    onClick={() => goToItem(item.to)}
                    className="group flex w-full items-center justify-between gap-3 rounded-[0.75rem] px-3 py-2.5 text-left transition-all duration-300 hover:bg-cyan-50"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-[12px] font-black text-slate-800 group-hover:text-teal-800">
                        {item.label}
                      </span>
                      <span className="mt-0.5 block truncate text-[10px] font-bold text-slate-400">
                        {item.hint}
                      </span>
                    </span>

                    <ChevronRight
                      size={14}
                      className="shrink-0 text-slate-300 transition-transform duration-300 group-hover:translate-x-1 group-hover:text-teal-700"
                    />
                  </button>
                ))
              ) : (
                <div className="px-3 py-4 text-center text-[12px] font-bold text-slate-400">
                  No workspace result found
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-3">
          <div ref={notificationRef} className="relative">
            <button
              type="button"
              aria-label="Notifications"
              title="Notifications"
              onClick={() => setNotificationOpen((value) => !value)}
              className="group relative inline-flex h-8 w-8 items-center justify-center text-teal-800 transition-all duration-300 hover:-translate-y-0.5 hover:text-teal-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200"
            >
              <BellDot
                size={19}
                strokeWidth={2.35}
                className="transition-all duration-300 group-hover:rotate-[-8deg] group-hover:scale-110"
              />

              <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-teal-600 opacity-80 transition-all duration-300 group-hover:scale-125 group-hover:bg-cyan-500" />
              <span className="absolute bottom-0 left-1 right-1 h-px origin-left scale-x-0 bg-teal-600/60 transition-transform duration-300 group-hover:scale-x-100" />
            </button>

            {notificationOpen && (
              <div className="absolute right-0 top-11 z-50 w-[315px] overflow-hidden rounded-[1rem] border border-teal-100 bg-white/96 p-3 shadow-[0_18px_55px_rgba(15,23,42,0.14)] backdrop-blur-2xl">
                <div className="mb-2 flex items-center justify-between border-b border-slate-100 pb-2">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                      Notifications
                    </p>
                    <p className="mt-0.5 text-[11px] font-bold text-slate-400">
                      Clinic workspace updates
                    </p>
                  </div>

                  <Sparkles size={16} className="text-teal-700" />
                </div>

                <div className="grid gap-2">
                  {notifications.map((item) => (
                    <div
                      key={item.title}
                      className="group border border-slate-100 bg-slate-50/80 p-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-teal-100 hover:bg-white"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-[12px] font-black text-slate-800">
                            {item.title}
                          </p>
                          <p className="mt-1 text-[11px] font-bold leading-5 text-slate-500">
                            {item.description}
                          </p>
                        </div>

                        <span className="shrink-0 text-[10px] font-black uppercase tracking-[0.12em] text-slate-400">
                          {item.time}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setNotificationOpen(false)}
                  className="mt-3 w-full rounded-[0.75rem] bg-teal-700 px-3 py-2 text-[11px] font-black uppercase tracking-[0.14em] text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                >
                  Mark as viewed
                </button>
              </div>
            )}
          </div>

          <Link
            to="/admin"
            aria-label="Back to admin login"
            title="Back to admin login"
            className="group relative inline-flex h-8 w-8 items-center justify-center overflow-hidden text-slate-500 transition-all duration-300 hover:-translate-y-0.5 hover:text-red-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-200"
          >
            <LogOut
              size={19}
              strokeWidth={2.35}
              className="absolute transition-all duration-300 group-hover:-translate-y-5 group-hover:rotate-[-10deg] group-hover:opacity-0"
            />

            <Power
              size={18}
              strokeWidth={2.35}
              className="absolute translate-y-5 text-red-600 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:rotate-180 group-hover:opacity-100"
            />

            <span className="absolute bottom-0 left-1 right-1 h-px origin-center scale-x-0 bg-red-500/70 transition-transform duration-300 group-hover:scale-x-100" />
          </Link>
        </div>
      </div>
    </header>
  );
};

export default DashboardTopbar;