import { TestTube2 } from "lucide-react";
import { DIAGNOSTIC_ROUTES } from "../lib/routes";
import DashboardSidebar from "./DashboardSidebar";

const DiagnosticSidebar = () => (
  <DashboardSidebar
    label="Diagnostic"
    title="CareBridge"
    subtitle="Lab workspace"
    icon={TestTube2}
    items={DIAGNOSTIC_ROUTES}
  />
);

export default DiagnosticSidebar;
