import { useEffect, useRef, useState } from "react";
import { Outlet, Link, NavLink } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import SaasPublicFooter from "./SaasPublicFooter";

const navItems = [
  { label: "Home", to: "/" },
  { label: "Pricing", to: "/pricing" },
  { label: "Demo", to: "/demo" },
  { label: "Book Demo", to: "/book-demo" },
  { label: "Contact Sales", to: "/contact-sales" },
];

const SaasPublicLayout = () => {
  const [showNavbar, setShowNavbar] = useState(true);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentY = window.scrollY;
      const isScrollingUp = currentY < lastScrollY.current;

      setShowNavbar(currentY < 24 || isScrollingUp);
      lastScrollY.current = Math.max(currentY, 0);
    };

    lastScrollY.current = window.scrollY;
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative min-h-svh overflow-hidden bg-[#07080d] text-white">
      <style>
        {`
        @keyframes softNavbarGlowOne {
          0%, 100% { transform: translate3d(-8%, -4%, 0) scale(1); opacity: .55; }
          50% { transform: translate3d(8%, 5%, 0) scale(1.08); opacity: .78; }
        }

        @keyframes softNavbarGlowTwo {
          0%, 100% { transform: translate3d(8%, 6%, 0) scale(1); opacity: .45; }
          50% { transform: translate3d(-5%, -4%, 0) scale(1.06); opacity: .65; }
        }

        .saas-bg-orb-one {
          animation: softNavbarGlowOne 13s ease-in-out infinite;
        }

        .saas-bg-orb-two {
          animation: softNavbarGlowTwo 16s ease-in-out infinite;
        }
      `}
      </style>

      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="saas-bg-orb-one absolute -left-28 top-20 h-[420px] w-[420px] rounded-full bg-sky-500/[0.075] blur-3xl" />
        <div className="saas-bg-orb-two absolute right-0 top-32 h-[460px] w-[460px] rounded-full bg-fuchsia-500/[0.06] blur-3xl" />
        <div className="absolute bottom-0 left-1/2 h-[420px] w-[620px] -translate-x-1/2 rounded-full bg-emerald-500/[0.035] blur-3xl" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.022)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.022)_1px,transparent_1px)] bg-[size:78px_78px] opacity-20" />
      </div>

      <header
        className={[
          "fixed inset-x-0 top-0 z-50 border-b border-white/[0.08] bg-[#07080d]/86 shadow-[0_16px_55px_rgba(0,0,0,0.34)] backdrop-blur-2xl",
          "transition-transform duration-300 ease-out",
          showNavbar ? "translate-y-0" : "-translate-y-full",
        ].join(" ")}
      >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4">
        <Link to="/" className="group flex items-center gap-3">
          <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-[5px] border border-white/12 bg-white/[0.055] text-sm font-black text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] transition-all duration-300 group-hover:-translate-y-0.5 group-hover:border-white/30 group-hover:bg-white/[0.11]">
            <span className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-white/60 transition-transform duration-300 group-hover:scale-x-100" />
            <span className="relative z-10">CB</span>
          </span>

          <span className="leading-none">
            <span className="block text-sm font-black tracking-tight text-white">
              CareBridge ERP
            </span>
            <span className="mt-1 block text-[10px] font-black uppercase tracking-[0.22em] text-white/38 transition-colors duration-300 group-hover:text-white/62">
              Clinic SaaS demos
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-2 md:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                [
                  "group relative inline-flex min-w-[102px] items-center justify-center overflow-hidden rounded-[5px] border px-4 py-2.5 text-center text-[11px] font-black uppercase tracking-[0.16em]",
                  "transition-all duration-300 ease-out focus:outline-none focus-visible:ring-2 focus-visible:ring-white/20",
                  isActive
                    ? "border-white/28 bg-white/[0.105] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.11),0_10px_28px_rgba(0,0,0,0.25)]"
                    : "border-white/[0.08] bg-white/[0.025] text-white/48 hover:-translate-y-0.5 hover:border-white/26 hover:bg-white/[0.078] hover:text-white hover:shadow-[0_10px_30px_rgba(0,0,0,0.22)]",
                ].join(" ")
              }
            >
              {({ isActive }) => (
                <>
                  <span
                    className={[
                      "absolute left-2 top-1.5 h-px rounded-full bg-white/55 transition-all duration-300",
                      isActive
                        ? "right-2 opacity-70"
                        : "right-full opacity-0 group-hover:right-2 group-hover:opacity-70",
                    ].join(" ")}
                  />

                  <span
                    className={[
                      "absolute bottom-1.5 right-2 h-px rounded-full bg-white/65 transition-all duration-300",
                      isActive
                        ? "left-2 opacity-80"
                        : "left-full opacity-0 group-hover:left-2 group-hover:opacity-80",
                    ].join(" ")}
                  />

                  <span
                    className={[
                      "absolute inset-1 rounded-[4px] bg-white/[0.045] transition-all duration-300",
                      isActive
                        ? "scale-100 opacity-100"
                        : "scale-95 opacity-0 group-hover:scale-100 group-hover:opacity-100",
                    ].join(" ")}
                  />

                  <span className="relative z-10 block h-4 overflow-hidden whitespace-nowrap">
                    <span
                      className={[
                        "block transition-all duration-300 ease-out",
                        isActive
                          ? "translate-y-0 opacity-100"
                          : "translate-y-0 opacity-80 group-hover:-translate-y-5 group-hover:opacity-0",
                      ].join(" ")}
                    >
                      {item.label}
                    </span>

                    <span
                      className={[
                        "absolute left-0 top-0 block transition-all duration-300 ease-out",
                        isActive
                          ? "translate-y-5 opacity-0"
                          : "translate-y-5 opacity-0 group-hover:translate-y-0 group-hover:opacity-100",
                      ].join(" ")}
                    >
                      {item.label}
                    </span>
                  </span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <Link
          to="/login"
          className="group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-[5px] border border-white/18 bg-white/[0.075] px-5 py-2.5 text-[11px] font-black uppercase tracking-[0.16em] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.10)] transition-all duration-300 hover:-translate-y-0.5 hover:border-white hover:shadow-[0_14px_34px_rgba(0,0,0,0.28)] focus:outline-none focus-visible:ring-2 focus-visible:ring-white/20"
        >
          <span className="absolute inset-y-0 left-0 w-1/2 -translate-x-full bg-white transition-transform duration-300 ease-out group-hover:translate-x-0" />
          <span className="absolute inset-y-0 right-0 w-1/2 translate-x-full bg-white transition-transform duration-300 ease-out group-hover:translate-x-0" />

          <span className="relative z-10 block h-4 overflow-hidden whitespace-nowrap">
            <span className="block transition-all delay-75 duration-300 ease-out group-hover:-translate-y-5 group-hover:text-black">
              Login
            </span>
            <span className="absolute left-0 top-0 block translate-y-5 text-black transition-all delay-75 duration-300 ease-out group-hover:translate-y-0">
              Login
            </span>
          </span>

          <ArrowRight
            size={14}
            strokeWidth={2.6}
            className="relative z-10 transition-all delay-75 duration-300 group-hover:translate-x-1 group-hover:text-black"
          />
        </Link>
      </div>
      </header>

      <div className="relative z-10 pt-[73px]">
        <Outlet />
      </div>

      <SaasPublicFooter />
    </div>
  );
};

export default SaasPublicLayout;
