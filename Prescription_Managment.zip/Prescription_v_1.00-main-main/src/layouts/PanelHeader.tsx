import {
  Bell,
  CalendarClock,
  ChevronRight,
  FileText,
  LogOut,
  MessageCircle,
  Stethoscope,
  UserRound,
  X,
} from "lucide-react";
import { createElement, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import BackButton from "../components/common/BackButton";
import { logoutAdmin } from "../lib/adminAuth";

const pathTitleMap = {
  doctor: "Doctor",
  dashboard: "Dashboard",
  patients: "Patients",
  users: "Users",
  messages: "Messages",
  profile: "Profile",
  "patient-record": "Patient Record",
  appointments: "Appointments",
  blogs: "Blogs",
  "website-cms": "Website CMS",
  "q&a": "Q&A",
  gallery: "Gallery",
  prescriptions: "Prescription",
  "upload-prescription": "Upload Prescription",
  "follow-up": "Follow Up",
  "access-control": "Access Control",
  accounts: "Accounts",
  reports: "Reports",
  settings: "Settings",
};

const ACTIVE_PATIENT_KEY = "active_prescription_patient";

const notifications = [
  {
    id: 1,
    title: "New appointment request",
    text: "Sadia Islam requested a serial at 09:10 AM.",
    time: "2 min ago",
  },
  {
    id: 2,
    title: "Follow up reminder",
    text: "Nabila Akter follow-up case needs review.",
    time: "15 min ago",
  },
  {
    id: 3,
    title: "Assistant message",
    text: "Shafin forwarded an urgent patient note.",
    time: "28 min ago",
  },
];

const IconButton = ({ label, icon: Icon, onClick, badge, danger = false }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={[
        "group relative inline-flex h-8 w-8 shrink-0 items-center justify-center",
        "rounded-full bg-transparent text-teal-800",
        "transition-all duration-200 ease-out",
        "hover:-translate-y-0.5",
        danger ? "hover:text-red-600" : "hover:text-teal-600",
        "focus:outline-none focus:ring-2",
        danger ? "focus:ring-red-200" : "focus:ring-cyan-200",
      ].join(" ")}
    >
      {createElement(Icon, {
        size: 18,
        strokeWidth: 2.4,
        className: [
          "rotate-0 transition-transform duration-200 ease-out",
          danger
            ? "group-hover:translate-x-1 group-hover:rotate-[10deg]"
            : "group-hover:rotate-[10deg] group-hover:scale-110",
        ].join(" "),
      })}

      {badge ? (
        <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-teal-700 px-1 text-[9px] font-black leading-none text-white shadow-sm">
          {badge}
        </span>
      ) : null}

      <span className="pointer-events-none absolute -bottom-8 left-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-full bg-slate-950 px-2.5 py-1 text-[10px] font-bold text-white opacity-0 shadow-lg transition-all duration-200 group-hover:-bottom-9 group-hover:opacity-100">
        {label}
      </span>
    </button>
  );
};

const PanelHeader = () => {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const notificationRef = useRef(null);
  const [showNotifications, setShowNotifications] = useState(false);

  const chunks = pathname.split("/").filter(Boolean);
  const isDetailsPage = chunks[2] && chunks[1] === "patients";

  const currentTitle = useMemo(() => {
    if (!chunks.length) return "Dashboard";

    return chunks
      .map((chunk) => pathTitleMap[chunk] || chunk.replaceAll("-", " ").toUpperCase())
      .join(" / ");
  }, [chunks]);

  useEffect(() => {
    if (!showNotifications) return;

    const handleOutsideClick = (event) => {
      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setShowNotifications(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("touchstart", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("touchstart", handleOutsideClick);
    };
  }, [showNotifications]);

  const handleLogout = () => {
    logoutAdmin();
    navigate("/admin", { replace: true });
  };

  const goToPrescriptions = () => {
    setShowNotifications(false);
    window.sessionStorage.removeItem(ACTIVE_PATIENT_KEY);
    navigate("/doctor/prescriptions");
  };

  const goToFollowUp = () => {
    setShowNotifications(false);
    navigate("/doctor/follow-up");
  };

  const goToMessages = () => {
    setShowNotifications(false);
    navigate("/doctor/messages");
  };

  const toggleNotifications = () => {
    setShowNotifications((prev) => !prev);
  };

  return (
    <header className="relative z-40 w-full">
      <div className="flex min-h-[48px] items-center justify-between gap-2 rounded-[1.15rem] border border-teal-100 bg-white/90 px-3 py-2 shadow-[0_8px_28px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:min-h-[50px] sm:px-4">
        <div className="flex min-w-0 flex-1 items-center gap-2">
          {isDetailsPage ? (
            <BackButton label="Back to Patients" to="/doctor/patients" />
          ) : (
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-cyan-50 text-teal-800 sm:h-8 sm:w-8">
              <Stethoscope size={15} />
            </span>
          )}

          <div className="flex min-w-0 items-center gap-1 overflow-hidden">
            {chunks.map((chunk, index) => {
              const key = `${chunk}-${index}`;
              const title = pathTitleMap[chunk] || chunk.toUpperCase();

              return (
                <span
                  key={key}
                  className={[
                    "inline-flex shrink-0 items-center gap-1 text-[10px] font-black tracking-wide",
                    index < chunks.length - 2 ? "hidden sm:inline-flex" : "",
                  ].join(" ")}
                >
                  {index > 0 ? (
                    <ChevronRight size={12} className="text-slate-300" />
                  ) : null}

                  <span
                    className={[
                      "max-w-[92px] truncate sm:max-w-none",
                      index === chunks.length - 1 ? "text-teal-800" : "text-slate-500",
                    ].join(" ")}
                  >
                    {title}
                  </span>
                </span>
              );
            })}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 sm:gap-2">
          <IconButton label="Prescription" icon={FileText} onClick={goToPrescriptions} />
          <IconButton label="Follow Up" icon={CalendarClock} onClick={goToFollowUp} />
          <IconButton label="Messages" icon={MessageCircle} onClick={goToMessages} badge={2} />

          <div ref={notificationRef} className="relative">
            <IconButton
              label="Notifications"
              icon={Bell}
              onClick={toggleNotifications}
              badge={notifications.length}
            />

            {showNotifications ? (
              <div className="absolute right-[-42px] top-11 w-[calc(100vw-32px)] max-w-[320px] overflow-hidden rounded-2xl border border-teal-100 bg-white shadow-[0_18px_60px_rgba(11,86,90,0.18)] sm:right-0 sm:top-12">
                <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
                  <div>
                    <p className="text-sm font-black text-slate-950">Notifications</p>
                    <p className="text-[11px] font-semibold text-slate-500">
                      {notifications.length} new updates
                    </p>
                  </div>

                  <button
                    type="button"
                    aria-label="Close notifications"
                    title="Close"
                    onClick={() => setShowNotifications(false)}
                    className={[
                      "group grid h-8 w-8 place-items-center rounded-full",
                      "text-slate-500 transition-all duration-200 ease-out",
                      "hover:-translate-y-0.5 hover:text-red-600",
                      "focus:outline-none focus:ring-2 focus:ring-red-200",
                    ].join(" ")}
                  >
                    <X
                      size={17}
                      strokeWidth={2.6}
                      className="transition-transform duration-200 ease-out group-hover:rotate-180 group-hover:scale-110"
                    />
                  </button>
                </div>

                <div className="max-h-[280px] overflow-y-auto p-2">
                  {notifications.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setShowNotifications(false);
                        navigate("/doctor/messages");
                      }}
                      className="block w-full rounded-xl px-3 py-3 text-left transition hover:bg-cyan-50 focus:outline-none focus:ring-2 focus:ring-cyan-100"
                    >
                      <div className="flex items-start gap-3">
                        <span className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-teal-50 text-teal-800">
                          <UserRound size={15} />
                        </span>

                        <span className="min-w-0">
                          <span className="block text-xs font-black text-slate-950">
                            {item.title}
                          </span>
                          <span className="mt-1 block text-[11px] font-semibold leading-5 text-slate-500">
                            {item.text}
                          </span>
                          <span className="mt-1 block text-[10px] font-black text-teal-700">
                            {item.time}
                          </span>
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </div>

          <span className="mx-0.5 h-5 w-px bg-slate-200 sm:mx-1 sm:h-6" />

          <IconButton label="Logout" icon={LogOut} onClick={handleLogout} danger />
        </div>
      </div>

      <span className="sr-only">{currentTitle}</span>
    </header>
  );
};

export default PanelHeader;
