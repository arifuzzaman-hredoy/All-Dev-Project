import {
  ArrowRight,
  ExternalLink,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";
import ProductCredit from "../components/common/ProductCredit";

const footerGroups = [
  {
    title: "Product",
    links: [
      { label: "Pricing", to: "/pricing" },
      { label: "Demo selector", to: "/demo" },
      { label: "Book demo", to: "/book-demo" },
      { label: "Contact sales", to: "/contact-sales" },
    ],
  },
  {
    title: "Demo panels",
    links: [
      { label: "Super Admin", to: "/super-admin/dashboard" },
      { label: "Clinic Dashboard", to: "/clinic/dashboard" },
      { label: "Diagnostic Dashboard", to: "/diagnostic/dashboard" },
      { label: "Hospital Dashboard", to: "/hospital/dashboard" },
    ],
  },
  {
    title: "Public demos",
    links: [
      { label: "Single Doctor", to: "/demo/public/single-doctor" },
      { label: "Clinic Website", to: "/demo/public/clinic" },
      { label: "Diagnostic Website", to: "/demo/public/diagnostic" },
      { label: "Hospital Website", to: "/demo/public/hospital" },
    ],
  },
];

const SaasPublicFooter = () => (
  <footer className="relative z-10 overflow-hidden border-t border-white/[0.08] bg-[#05060a]/92">
    <style>
      {`
        @keyframes footerGlowOne {
          0%, 100% { transform: translate3d(-8%, -4%, 0) scale(1); opacity: .48; }
          50% { transform: translate3d(8%, 5%, 0) scale(1.08); opacity: .72; }
        }

        @keyframes footerGlowTwo {
          0%, 100% { transform: translate3d(8%, 7%, 0) scale(1); opacity: .38; }
          50% { transform: translate3d(-6%, -5%, 0) scale(1.06); opacity: .62; }
        }

        .footer-glow-one {
          animation: footerGlowOne 15s ease-in-out infinite;
        }

        .footer-glow-two {
          animation: footerGlowTwo 18s ease-in-out infinite;
        }
      `}
    </style>

    <div className="pointer-events-none absolute inset-0">
      <div className="footer-glow-one absolute -left-28 top-8 h-[360px] w-[360px] rounded-full bg-cyan-500/[0.08] blur-[90px]" />
      <div className="footer-glow-two absolute right-[-120px] bottom-0 h-[420px] w-[420px] rounded-full bg-fuchsia-500/[0.075] blur-[100px]" />
      <div className="absolute bottom-[-140px] left-1/2 h-[360px] w-[620px] -translate-x-1/2 rounded-full bg-emerald-500/[0.045] blur-[110px]" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.022)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.022)_1px,transparent_1px)] bg-[size:78px_78px] opacity-20" />
    </div>

    <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 lg:grid-cols-[1.05fr_1.55fr]">
      <section className="max-w-md">
        <Link to="/" className="group inline-flex items-center gap-3">
          <span className="relative grid h-11 w-11 place-items-center overflow-hidden border border-white/12 bg-white/[0.055] text-sm font-black text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] transition-all duration-300 group-hover:-translate-y-0.5 group-hover:border-white/30 group-hover:bg-white/[0.11]">
            <span className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-white/70 transition-transform duration-300 group-hover:scale-x-100" />
            <span className="relative z-10">CB</span>
          </span>

          <span>
            <span className="block text-base font-black tracking-tight text-white">
              CareBridge ERP
            </span>
            <span className="mt-1 block text-[10px] font-black uppercase tracking-[0.22em] text-white/38 transition-colors duration-300 group-hover:text-white/65">
              Clinic SaaS demos
            </span>
          </span>
        </Link>

        <p className="mt-5 text-sm font-semibold leading-7 text-white/56">
          Premium Clinic ERP SaaS demos for doctors, clinics, diagnostic centers
          and hospital-ready workflows.
        </p>

        <div className="mt-6 grid gap-2.5 text-[12px] font-bold text-white/50">
          <span className="group inline-flex items-center gap-2 transition-colors duration-300 hover:text-white">
            <Mail
              size={14}
              className="text-white/34 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:text-white"
            />
            sales@carebridge.demo
          </span>

          <span className="group inline-flex items-center gap-2 transition-colors duration-300 hover:text-white">
            <Phone
              size={14}
              className="text-white/34 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:text-white"
            />
            +880 1700 000000
          </span>

          <span className="group inline-flex items-center gap-2 transition-colors duration-300 hover:text-white">
            <MapPin
              size={14}
              className="text-white/34 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:text-white"
            />
            Dhaka, Bangladesh
          </span>
        </div>

        <a
          href="https://techteamlead.com/"
          target="_blank"
          rel="noreferrer"
          className="group mt-7 inline-flex items-center gap-2 border border-emerald-400/18 bg-emerald-400/[0.06] px-4 py-3 text-[11px] font-black uppercase tracking-[0.15em] text-emerald-100/78 transition-all duration-300 hover:-translate-y-0.5 hover:border-emerald-300/35 hover:bg-emerald-400/[0.10] hover:text-white"
        >
          <Sparkles
            size={14}
            className="transition-transform duration-300 group-hover:rotate-12 group-hover:scale-110"
          />
          Built by TechTeamLead
          <ExternalLink
            size={13}
            className="transition-transform duration-300 group-hover:translate-x-1"
          />
        </a>
      </section>

      <section className="grid gap-6 sm:grid-cols-3">
        {footerGroups.map((group) => (
          <div key={group.title}>
            <div className="mb-4 flex items-center gap-2 border-b border-white/[0.08] pb-3">
              <ShieldCheck size={14} className="text-white/36" />
              <h2 className="text-[11px] font-black uppercase tracking-[0.17em] text-white">
                {group.title}
              </h2>
            </div>

            <nav className="grid gap-2">
              {group.links.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  className="group relative inline-flex items-center justify-between gap-3 overflow-hidden border border-white/[0.07] bg-white/[0.028] px-3 py-2.5 text-[12px] font-black text-white/50 transition-all duration-300 hover:-translate-y-0.5 hover:border-white/22 hover:bg-white/[0.075] hover:text-white"
                >
                  <span className="relative z-10">{item.label}</span>

                  <span className="relative z-10 inline-flex h-5 w-6 items-center justify-end overflow-hidden">
                    <span className="absolute right-1 h-px w-0 bg-white/70 transition-all duration-300 group-hover:w-6" />
                    <ArrowRight
                      size={13}
                      className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
                    />
                  </span>

                  <span className="absolute bottom-0 left-0 h-px w-0 bg-white/45 transition-all duration-500 group-hover:w-full" />
                </Link>
              ))}
            </nav>
          </div>
        ))}
      </section>
    </div>

    <div className="relative border-t border-white/[0.08]">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-5 text-[11px] font-black uppercase tracking-[0.14em] text-white/36 sm:flex-row sm:items-center sm:justify-between">
        <span>© 2026 CareBridge ERP Demo. All rights reserved.</span>

        <ProductCredit variant="dark" />
      </div>
    </div>
  </footer>
);

export default SaasPublicFooter;
