import { Navigate, Outlet, useLocation } from "react-router-dom";
import { isAdminLoggedIn } from "../lib/adminAuth";

const ProtectedDoctorRoute = () => {
  const location = useLocation();

  if (!isAdminLoggedIn()) {
    return <Navigate to="/admin" replace state={{ from: location.pathname }} />;
  }

  return <Outlet />;
};

export default ProtectedDoctorRoute;
