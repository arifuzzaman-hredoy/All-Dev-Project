import { createElement, useState } from "react";
import { NavLink } from "react-router-dom";
import { LucideIcon, PanelLeftClose, PanelLeftOpen } from "lucide-react";

type DashboardRoute = {
  label: string;
  path: string;
  icon: LucideIcon;
};

type DashboardSidebarProps = {
  label: string;
  title: string;
  subtitle: string;
  icon: LucideIcon;
  items: DashboardRoute[];
};

const DashboardSidebar = ({ label, title, subtitle, icon: BrandIcon, items }: DashboardSidebarProps) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={[
        "hidden h-[calc(100svh-2rem)] flex-col rounded-[23px] border border-cyan-100/80 bg-white/88 shadow-[0_18px_45px_rgba(11,86,90,0.08)] backdrop-blur-2xl transition-all duration-300 lg:sticky lg:top-4 lg:flex",
        collapsed ? "w-[70px] px-2.5 py-3" : "w-[230px] p-3",
      ].join(" ")}
    >
      <div className={["flex items-center border-b border-cyan-100/80 pb-3", collapsed ? "justify-center" : "justify-between gap-2"].join(" ")}>
        <div className={["flex min-w-0 items-center", collapsed ? "justify-center" : "gap-2.5"].join(" ")}>
          <BrandIcon size={collapsed ? 22 : 21} strokeWidth={2.25} className="shrink-0 text-teal-700 transition duration-300 hover:-rotate-6" />
          {!collapsed ? (
            <div className="min-w-0">
              <p className="text-[10px] font-black uppercase tracking-[0.14em] text-teal-700">{label}</p>
              <h1 className="truncate text-[17px] font-black tracking-tight text-slate-950">{title}</h1>
              <p className="truncate text-[11px] font-semibold text-slate-400">{subtitle}</p>
            </div>
          ) : null}
        </div>

        {!collapsed ? (
          <button type="button" onClick={() => setCollapsed(true)} className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-slate-400 transition hover:-translate-y-0.5 hover:rotate-[8deg] hover:bg-cyan-50 hover:text-teal-700 focus:outline-none" aria-label="Collapse sidebar" title="Collapse sidebar">
            <PanelLeftClose size={17} />
          </button>
        ) : null}
      </div>

      {collapsed ? (
        <button type="button" onClick={() => setCollapsed(false)} className="mt-3 grid h-9 w-full place-items-center rounded-xl text-slate-400 transition hover:-translate-y-0.5 hover:rotate-[8deg] hover:bg-cyan-50 hover:text-teal-700 focus:outline-none" aria-label="Expand sidebar" title="Expand sidebar">
          <PanelLeftOpen size={18} />
        </button>
      ) : null}

      <nav className="mt-3 grid flex-1 content-start gap-1 overflow-y-auto pr-1">
        {items.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            title={item.label}
            className={({ isActive }) =>
              [
                "group relative flex min-h-9 items-center overflow-hidden rounded-xl text-[12px] font-black transition duration-300 focus:outline-none",
                collapsed ? "justify-center px-2" : "gap-2.5 px-3",
                isActive ? "bg-cyan-50/80 text-teal-800" : "text-slate-500 hover:bg-cyan-50/55 hover:text-teal-700",
              ].join(" ")
            }
          >
            {({ isActive }) => (
              <>
                <span className={["absolute left-0 top-1/2 h-5 w-[2px] -translate-y-1/2 rounded-r-full bg-gradient-to-b from-blue-600 to-teal-500 transition-all duration-300", isActive ? "opacity-100" : "opacity-0 group-hover:opacity-60"].join(" ")} />
                {createElement(item.icon, { size: collapsed ? 18 : 16, strokeWidth: 2.35, className: ["shrink-0 transition duration-300 group-hover:-rotate-6", isActive ? "text-teal-700" : "text-slate-400 group-hover:text-teal-700"].join(" ") })}
                {!collapsed ? <span className="min-w-0 truncate leading-none">{item.label}</span> : null}
              </>
            )}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default DashboardSidebar;
