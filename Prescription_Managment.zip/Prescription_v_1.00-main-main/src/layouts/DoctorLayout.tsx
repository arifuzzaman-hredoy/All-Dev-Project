import { Outlet } from "react-router-dom";
import ProductCredit from "../components/common/ProductCredit";
import DoctorSidebar from "./DoctorSidebar";
import MobileBottomNav from "./MobileBottomNav";
import PanelHeader from "./PanelHeader";

const DoctorLayout = () => {
  return (
    <div className="grid min-h-svh gap-4 bg-gradient-to-br from-cyan-50 via-white to-teal-50 p-3 text-slate-900 lg:grid-cols-[260px_1fr] lg:p-4">
      <DoctorSidebar />
      <main className="grid min-w-0 grid-rows-[auto_1fr_auto] gap-4">
        <PanelHeader />
        <div className="min-w-0 pb-24 lg:pb-4">
          <Outlet />
        </div>
        <div className="pb-20 lg:pb-2">
          <ProductCredit />
        </div>
      </main>
      <MobileBottomNav />
    </div>
  );
};

export default DoctorLayout;
