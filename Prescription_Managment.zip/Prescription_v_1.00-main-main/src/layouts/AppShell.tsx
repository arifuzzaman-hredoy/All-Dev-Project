import { ReactNode } from "react";
import { Outlet } from "react-router-dom";
import ProductCredit from "../components/common/ProductCredit";
import DashboardTopbar from "./DashboardTopbar";

type AppShellProps = {
  sidebar: ReactNode;
};

const AppShell = ({ sidebar }: AppShellProps) => {
  return (
    <div className="grid min-h-svh gap-4 bg-gradient-to-br from-cyan-50 via-white to-teal-50 p-3 text-slate-900 lg:grid-cols-[260px_1fr] lg:p-4">
      {sidebar}
      <main className="grid min-w-0 grid-rows-[auto_1fr_auto] gap-4">
        <DashboardTopbar />
        <div className="min-w-0 pb-6">
          <Outlet />
        </div>
        <div className="pb-2">
          <ProductCredit />
        </div>
      </main>
    </div>
  );
};

export default AppShell;
