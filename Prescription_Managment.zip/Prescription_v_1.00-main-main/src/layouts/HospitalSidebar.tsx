import { Building2 } from "lucide-react";
import { HOSPITAL_ROUTES } from "../lib/routes";
import DashboardSidebar from "./DashboardSidebar";

const HospitalSidebar = () => (
  <DashboardSidebar
    label="Hospital ERP"
    title="CareBridge"
    subtitle="Future shell"
    icon={Building2}
    items={HOSPITAL_ROUTES}
  />
);

export default HospitalSidebar;
