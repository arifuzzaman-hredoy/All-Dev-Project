import { createElement } from "react";
import { NavLink } from "react-router-dom";
import { useDashboardNavigation } from "../hooks/useDashboardNavigation";

const MobileBottomNav = () => {
  const { items } = useDashboardNavigation({ mobile: true });

  return (
    <nav
      className="fixed inset-x-3 bottom-3 z-50 grid grid-cols-5 gap-1 rounded-[1.5rem] border border-teal-100 bg-white/90 p-2 shadow-[0_18px_48px_rgba(11,86,90,0.18)] backdrop-blur-xl lg:hidden"
      aria-label="Mobile navigation"
    >
      {items.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) =>
            [
              "grid min-h-14 place-items-center rounded-2xl px-1 text-[10px] font-black transition focus:outline-none focus:ring-2 focus:ring-cyan-300",
              isActive ? "bg-cyan-100 text-teal-800" : "text-slate-500",
            ].join(" ")
          }
        >
          <span className="grid h-6 w-6 place-items-center">
            {createElement(item.icon, { size: 17, strokeWidth: 2.2 })}
          </span>
          <span className="mt-1 truncate">
            {item.mobileLabel || item.label}
          </span>
        </NavLink>
      ))}
    </nav>
  );
};

export default MobileBottomNav;
