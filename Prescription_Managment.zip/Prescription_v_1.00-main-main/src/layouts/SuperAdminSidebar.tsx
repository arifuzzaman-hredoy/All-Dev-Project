import { ShieldCheck } from "lucide-react";
import { SUPER_ADMIN_ROUTES } from "../lib/routes";
import DashboardSidebar from "./DashboardSidebar";

const SuperAdminSidebar = () => (
  <DashboardSidebar
    label="Super Admin"
    title="CareBridge"
    subtitle="Platform workspace"
    icon={ShieldCheck}
    items={SUPER_ADMIN_ROUTES}
  />
);

export default SuperAdminSidebar;
