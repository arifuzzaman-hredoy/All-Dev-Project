import { Hospital } from "lucide-react";
import { CLINIC_ROUTES } from "../lib/routes";
import DashboardSidebar from "./DashboardSidebar";

const ClinicSidebar = () => (
  <DashboardSidebar
    label="Clinic Panel"
    title="CareBridge"
    subtitle="Operations workspace"
    icon={Hospital}
    items={CLINIC_ROUTES}
  />
);

export default ClinicSidebar;
