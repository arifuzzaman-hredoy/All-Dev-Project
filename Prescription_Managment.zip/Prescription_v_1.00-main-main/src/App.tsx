import { useEffect } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import PatientRecords from "./components/patients/PatientRecords";
import PatientPrescriptionHistory from "./components/prescription/PatientPrescriptionHistory";
import AppShell from "./layouts/AppShell";
import ClinicSidebar from "./layouts/ClinicSidebar";
import DiagnosticSidebar from "./layouts/DiagnosticSidebar";
import DoctorLayout from "./layouts/DoctorLayout";
import HospitalSidebar from "./layouts/HospitalSidebar";
import ProtectedDoctorRoute from "./layouts/ProtectedDoctorRoute";
import SaasPublicLayout from "./layouts/SaasPublicLayout";
import SuperAdminSidebar from "./layouts/SuperAdminSidebar";
import { hydrateRemoteContent } from "./lib/hydrateRemoteContent";
import AdminLoginPage from "./pages/AdminLoginPage";
import BookDemoPage from "./pages/BookDemoPage";
import ContactSalesPage from "./pages/ContactSalesPage";
import DemoSelectorPage from "./pages/DemoSelectorPage";
import DoctorAppointmentManagerPage from "./pages/DoctorAppointmentManagerPage";
import DoctorBlogManagerPage from "./pages/DoctorBlogManagerPage";
import DoctorDashboardPage from "./pages/DoctorDashboardPage";
import DoctorGalleryManagerPage from "./pages/DoctorGalleryManagerPage";
import DoctorPanelSettingsPage from "./pages/DoctorPanelSettingsPage";
import DoctorPatientDetailsPage from "./pages/DoctorPatientDetailsPage";
import DoctorPatientsPage from "./pages/DoctorPatientsPage";
import DoctorPrescriptionActionPage from "./pages/DoctorPrescriptionActionPage";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import DoctorQaManagerPage from "./pages/DoctorQaManagerPage";
import DoctorWebsiteCmsPage from "./pages/DoctorWebsiteCmsPage";
import LoginSelectorPage from "./pages/LoginSelectorPage";
import PricingPage from "./pages/PricingPage";
import SaasHomePage from "./pages/SaasHomePage";
import TenantPublicSiteDemoPage from "./pages/TenantPublicSiteDemoPage";
import ClinicAppointmentsPage from "./pages/clinic/ClinicAppointmentsPage";
import ClinicBillingPage from "./pages/clinic/ClinicBillingPage";
import ClinicDashboardPage from "./pages/clinic/ClinicDashboardPage";
import ClinicDiagnosticPage from "./pages/clinic/ClinicDiagnosticPage";
import ClinicDoctorsPage from "./pages/clinic/ClinicDoctorsPage";
import ClinicEncountersPage from "./pages/clinic/ClinicEncountersPage";
import ClinicInventoryPage from "./pages/clinic/ClinicInventoryPage";
import ClinicMyPlanPage from "./pages/clinic/ClinicMyPlanPage";
import ClinicPatientLedgerPage from "./pages/clinic/ClinicPatientLedgerPage";
import ClinicPatientsPage from "./pages/clinic/ClinicPatientsPage";
import ClinicPaymentsPage from "./pages/clinic/ClinicPaymentsPage";
import ClinicPrescriptionsPage from "./pages/ClinicPrescriptionsPage";
import ClinicReportsPage from "./pages/clinic/ClinicReportsPage";
import ClinicSettingsPage from "./pages/clinic/ClinicSettingsPage";
import ClinicSmsWalletPage from "./pages/clinic/ClinicSmsWalletPage";
import ClinicSupportPage from "./pages/clinic/ClinicSupportPage";
import ClinicUsersPage from "./pages/clinic/ClinicUsersPage";
import ClinicWebsiteCmsPage from "./pages/clinic/ClinicWebsiteCmsPage";
import AccessControlPage from "./pages/doctor/AccessControlPage";
import AccountsPage from "./pages/doctor/AccountsPage";
import FollowUpPage from "./pages/doctor/FollowUpPage";
import MessagesPage from "./pages/doctor/MessagesPage";
import PrescriptionsPage from "./pages/doctor/PrescriptionsPage";
import ReportsPage from "./pages/doctor/ReportsPage";
import SettingsPage from "./pages/doctor/SettingsPage";
import UploadPrescriptionPage from "./pages/doctor/UploadPrescriptionPage";
import UsersPage from "./pages/doctor/UsersPage";
import DiagnosticBillingPage from "./pages/diagnostic/DiagnosticBillingPage";
import DiagnosticDashboardPage from "./pages/diagnostic/DiagnosticDashboardPage";
import DiagnosticDeliveryPage from "./pages/diagnostic/DiagnosticDeliveryPage";
import DiagnosticLabOrdersPage from "./pages/diagnostic/DiagnosticLabOrdersPage";
import DiagnosticReportsPage from "./pages/diagnostic/DiagnosticReportsPage";
import DiagnosticSampleCollectionPage from "./pages/diagnostic/DiagnosticSampleCollectionPage";
import DiagnosticTestCatalogPage from "./pages/diagnostic/DiagnosticTestCatalogPage";
import ClinicPublicDemoPage from "./pages/demo/ClinicPublicDemoPage";
import DiagnosticPublicDemoPage from "./pages/demo/DiagnosticPublicDemoPage";
import HospitalPublicDemoPage from "./pages/demo/HospitalPublicDemoPage";
import ProDoctorPublicDemoPage from "./pages/demo/ProDoctorPublicDemoPage";
import SingleDoctorPublicDemoPage from "./pages/demo/SingleDoctorPublicDemoPage";
import HospitalAdmissionPage from "./pages/hospital/HospitalAdmissionPage";
import HospitalBedsPage from "./pages/hospital/HospitalBedsPage";
import HospitalBillingPage from "./pages/hospital/HospitalBillingPage";
import HospitalDashboardPage from "./pages/hospital/HospitalDashboardPage";
import HospitalDischargePage from "./pages/hospital/HospitalDischargePage";
import HospitalIpdPage from "./pages/hospital/HospitalIpdPage";
import HospitalOpdPage from "./pages/hospital/HospitalOpdPage";
import HospitalPharmacyPage from "./pages/hospital/HospitalPharmacyPage";
import HospitalReportsPage from "./pages/hospital/HospitalReportsPage";
import UserForgotPasswordPage from "./pages/public/UserForgotPasswordPage";
import UserLoginPage from "./pages/public/UserLoginPage";
import UserRegisterPage from "./pages/public/UserRegisterPage";
import UserResetPasswordPage from "./pages/public/UserResetPasswordPage";
import UserVerifyOtpPage from "./pages/public/UserVerifyOtpPage";
import SuperAdminAuditLogsPage from "./pages/super-admin/SuperAdminAuditLogsPage";
import SuperAdminCommissionPage from "./pages/super-admin/SuperAdminCommissionPage";
import SuperAdminDashboardPage from "./pages/super-admin/SuperAdminDashboardPage";
import SuperAdminDemoPage from "./pages/super-admin/SuperAdminDemoPage";
import SuperAdminLeadsPage from "./pages/super-admin/SuperAdminLeadsPage";
import SuperAdminModulesPage from "./pages/super-admin/SuperAdminModulesPage";
import SuperAdminPackagesPage from "./pages/super-admin/SuperAdminPackagesPage";
import SuperAdminPaymentsPage from "./pages/super-admin/SuperAdminPaymentsPage";
import SuperAdminSettingsPage from "./pages/super-admin/SuperAdminSettingsPage";
import SuperAdminSmsPage from "./pages/super-admin/SuperAdminSmsPage";
import SuperAdminSubscriptionsPage from "./pages/super-admin/SuperAdminSubscriptionsPage";
import SuperAdminSupportPage from "./pages/super-admin/SuperAdminSupportPage";
import SuperAdminTenantCreatePage from "./pages/super-admin/SuperAdminTenantCreatePage";
import SuperAdminTenantsPage from "./pages/super-admin/SuperAdminTenantsPage";
import PublicAboutPage from "./publicSite/pages/PublicAboutPage";
import PublicAppointmentPage from "./publicSite/pages/PublicAppointmentPage";
import PublicBlogDetailsPage from "./publicSite/pages/PublicBlogDetailsPage";
import PublicBlogsPage from "./publicSite/pages/PublicBlogsPage";
import PublicContactPage from "./publicSite/pages/PublicContactPage";
import PublicGalleryPage from "./publicSite/pages/PublicGalleryPage";
import PublicHomePage from "./publicSite/pages/PublicHomePage";
import PublicPrescriptionPage from "./publicSite/pages/PublicPrescriptionPage";
import PublicQaPage from "./publicSite/pages/PublicQaPage";
import PublicServicesPage from "./publicSite/pages/PublicServicesPage";
import { fetchThemeSettings } from "./publicSite/lib/themeSettings";

function App() {
  useEffect(() => {
    hydrateRemoteContent();
    fetchThemeSettings().catch(() => null);
  }, []);

  return (
    <Routes>
      <Route element={<SaasPublicLayout />}>
        <Route index element={<SaasHomePage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/demo" element={<DemoSelectorPage />} />
        <Route path="/book-demo" element={<BookDemoPage />} />
        <Route path="/contact-sales" element={<ContactSalesPage />} />
        <Route path="/login" element={<LoginSelectorPage />} />
      </Route>

      <Route path="/demo/public/single-doctor" element={<SingleDoctorPublicDemoPage />} />
      <Route path="/demo/public/pro-doctor" element={<ProDoctorPublicDemoPage />} />
      <Route path="/demo/public/clinic" element={<ClinicPublicDemoPage />} />
      <Route path="/demo/public/diagnostic" element={<DiagnosticPublicDemoPage />} />
      <Route path="/demo/public/hospital" element={<HospitalPublicDemoPage />} />
      <Route path="/site/single-doctor-demo" element={<TenantPublicSiteDemoPage kind="single-doctor" />} />
      <Route path="/site/clinic-demo" element={<TenantPublicSiteDemoPage kind="clinic" />} />
      <Route path="/site/diagnostic-demo" element={<TenantPublicSiteDemoPage kind="diagnostic" />} />
      <Route path="/site/hospital-demo" element={<TenantPublicSiteDemoPage kind="hospital" />} />
      <Route path="/site/:tenantSlug" element={<TenantPublicSiteDemoPage />} />

      <Route path="/about" element={<PublicAboutPage />} />
      <Route path="/services" element={<PublicServicesPage />} />
      <Route path="/appointment" element={<PublicAppointmentPage />} />
      <Route path="/blogs" element={<PublicBlogsPage />} />
      <Route path="/blogs/:slug" element={<PublicBlogDetailsPage />} />
      <Route path="/qa" element={<PublicQaPage />} />
      <Route path="/gallery" element={<PublicGalleryPage />} />
      <Route path="/contact" element={<PublicContactPage />} />
      <Route path="/patient-prescription" element={<PublicPrescriptionPage />} />
      <Route path="/doctor-site" element={<PublicHomePage />} />

      <Route path="/user/register" element={<UserRegisterPage />} />
      <Route path="/user/login" element={<UserLoginPage />} />
      <Route path="/user/forgot-password" element={<UserForgotPasswordPage />} />
      <Route path="/user/verify-otp" element={<UserVerifyOtpPage />} />
      <Route path="/user/reset-password" element={<UserResetPasswordPage />} />
      <Route path="/admin" element={<AdminLoginPage />} />

      <Route path="/super-admin" element={<AppShell sidebar={<SuperAdminSidebar />} />}>
        <Route index element={<Navigate to="/super-admin/dashboard" replace />} />
        <Route path="dashboard" element={<SuperAdminDashboardPage />} />
        <Route path="tenants" element={<SuperAdminTenantsPage />} />
        <Route path="tenants/create" element={<SuperAdminTenantCreatePage />} />
        <Route path="packages" element={<SuperAdminPackagesPage />} />
        <Route path="modules" element={<SuperAdminModulesPage />} />
        <Route path="subscriptions" element={<SuperAdminSubscriptionsPage />} />
        <Route path="payments" element={<SuperAdminPaymentsPage />} />
        <Route path="sms" element={<SuperAdminSmsPage />} />
        <Route path="demo" element={<SuperAdminDemoPage />} />
        <Route path="support" element={<SuperAdminSupportPage />} />
        <Route path="leads" element={<SuperAdminLeadsPage />} />
        <Route path="commission" element={<SuperAdminCommissionPage />} />
        <Route path="audit-logs" element={<SuperAdminAuditLogsPage />} />
        <Route path="settings" element={<SuperAdminSettingsPage />} />
      </Route>

      <Route path="/clinic" element={<AppShell sidebar={<ClinicSidebar />} />}>
        <Route index element={<Navigate to="/clinic/dashboard" replace />} />
        <Route path="dashboard" element={<ClinicDashboardPage />} />
        <Route path="my-plan" element={<ClinicMyPlanPage />} />
        <Route path="users" element={<ClinicUsersPage />} />
        <Route path="doctors" element={<ClinicDoctorsPage />} />
        <Route path="appointments" element={<ClinicAppointmentsPage />} />
        <Route path="patients" element={<ClinicPatientsPage />} />
        <Route path="encounters" element={<ClinicEncountersPage />} />
        <Route path="prescriptions" element={<ClinicPrescriptionsPage />} />
        <Route path="billing" element={<ClinicBillingPage />} />
        <Route path="payments" element={<ClinicPaymentsPage />} />
        <Route path="patient-ledger" element={<ClinicPatientLedgerPage />} />
        <Route path="reports" element={<ClinicReportsPage />} />
        <Route path="sms-wallet" element={<ClinicSmsWalletPage />} />
        <Route path="support" element={<ClinicSupportPage />} />
        <Route path="website-cms" element={<ClinicWebsiteCmsPage />} />
        <Route path="settings" element={<ClinicSettingsPage />} />
        <Route path="diagnostic" element={<ClinicDiagnosticPage />} />
        <Route path="inventory" element={<ClinicInventoryPage />} />
      </Route>

      <Route path="/diagnostic" element={<AppShell sidebar={<DiagnosticSidebar />} />}>
        <Route index element={<Navigate to="/diagnostic/dashboard" replace />} />
        <Route path="dashboard" element={<DiagnosticDashboardPage />} />
        <Route path="test-catalog" element={<DiagnosticTestCatalogPage />} />
        <Route path="lab-orders" element={<DiagnosticLabOrdersPage />} />
        <Route path="sample-collection" element={<DiagnosticSampleCollectionPage />} />
        <Route path="reports" element={<DiagnosticReportsPage />} />
        <Route path="billing" element={<DiagnosticBillingPage />} />
        <Route path="delivery" element={<DiagnosticDeliveryPage />} />
      </Route>

      <Route path="/hospital" element={<AppShell sidebar={<HospitalSidebar />} />}>
        <Route index element={<Navigate to="/hospital/dashboard" replace />} />
        <Route path="dashboard" element={<HospitalDashboardPage />} />
        <Route path="opd" element={<HospitalOpdPage />} />
        <Route path="ipd" element={<HospitalIpdPage />} />
        <Route path="admission" element={<HospitalAdmissionPage />} />
        <Route path="beds" element={<HospitalBedsPage />} />
        <Route path="billing" element={<HospitalBillingPage />} />
        <Route path="discharge" element={<HospitalDischargePage />} />
        <Route path="pharmacy" element={<HospitalPharmacyPage />} />
        <Route path="reports" element={<HospitalReportsPage />} />
      </Route>

      <Route element={<ProtectedDoctorRoute />}>
        <Route path="/doctor" element={<DoctorLayout />}>
          <Route index element={<Navigate to="/doctor/dashboard" replace />} />
          <Route path="dashboard" element={<DoctorDashboardPage />} />
          <Route path="patients" element={<DoctorPatientsPage />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="patient-records" element={<PatientRecords />} />
          <Route path="patients/:id" element={<DoctorPatientDetailsPage />} />
          <Route path="patients/:patientId/prescriptions" element={<PatientPrescriptionHistory />} />
          <Route path="patients/:id/action/:actionType" element={<DoctorPrescriptionActionPage />} />
          <Route path="prescriptions" element={<PrescriptionsPage />} />
          <Route path="prescription" element={<PrescriptionsPage />} />
          <Route path="upload-prescription" element={<UploadPrescriptionPage />} />
          <Route path="follow-up" element={<FollowUpPage />} />
          <Route path="messages" element={<MessagesPage />} />
          <Route path="profile" element={<DoctorProfilePage />} />
          <Route path="panel-settings" element={<DoctorPanelSettingsPage />} />
          <Route path="open-settings" element={<DoctorPanelSettingsPage />} />
          <Route path="website-cms" element={<DoctorWebsiteCmsPage />} />
          <Route path="blog-manager" element={<DoctorBlogManagerPage />} />
          <Route path="qa-manager" element={<DoctorQaManagerPage />} />
          <Route path="gallery-manager" element={<DoctorGalleryManagerPage />} />
          <Route path="appointment-manager" element={<DoctorAppointmentManagerPage />} />
          <Route path="appointments" element={<DoctorAppointmentManagerPage />} />
          <Route path="access-control" element={<AccessControlPage />} />
          <Route path="accounts" element={<AccountsPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
