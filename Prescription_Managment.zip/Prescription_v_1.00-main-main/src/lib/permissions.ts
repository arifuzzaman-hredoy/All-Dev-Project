export const PERMISSIONS = {
  APPOINTMENT_READ: "appointment.read",
  APPOINTMENT_CREATE: "appointment.create",
  APPOINTMENT_UPDATE: "appointment.update",
  PATIENT_READ: "patient.read",
  PATIENT_CREATE: "patient.create",
  PATIENT_UPDATE: "patient.update",
  PRESCRIPTION_READ: "prescription.read",
  PRESCRIPTION_CREATE: "prescription.create",
  PRESCRIPTION_UPDATE: "prescription.update",
  BILLING_READ: "billing.read",
  BILLING_CREATE: "billing.create",
  PAYMENT_RECEIVE: "payment.receive",
  PAYMENT_VERIFY: "payment.verify",
  REPORT_VIEW: "report.view",
  CMS_UPDATE: "cms.update",
  USER_MANAGE: "user.manage",
  SUPPORT_CREATE: "support.create",
  AUDIT_VIEW: "audit.view",
} as const;

export const ACCESS_FEATURE_BY_PERMISSION = {
  [PERMISSIONS.APPOINTMENT_READ]: "appointments",
  [PERMISSIONS.APPOINTMENT_CREATE]: "appointments",
  [PERMISSIONS.APPOINTMENT_UPDATE]: "appointments",
  [PERMISSIONS.PATIENT_READ]: "patients",
  [PERMISSIONS.PATIENT_CREATE]: "patients",
  [PERMISSIONS.PATIENT_UPDATE]: "patients",
  [PERMISSIONS.PRESCRIPTION_READ]: "prescriptions",
  [PERMISSIONS.PRESCRIPTION_CREATE]: "prescriptions",
  [PERMISSIONS.PRESCRIPTION_UPDATE]: "prescriptions",
  [PERMISSIONS.BILLING_READ]: "accounts",
  [PERMISSIONS.BILLING_CREATE]: "accounts",
  [PERMISSIONS.PAYMENT_RECEIVE]: "accounts",
  [PERMISSIONS.PAYMENT_VERIFY]: "accounts",
  [PERMISSIONS.REPORT_VIEW]: "reports",
  [PERMISSIONS.CMS_UPDATE]: "website_cms",
  [PERMISSIONS.USER_MANAGE]: "users",
  [PERMISSIONS.SUPPORT_CREATE]: "messages",
  [PERMISSIONS.AUDIT_VIEW]: "access_control",
};

export const canUsePermission = ({ role, permissions, permission }) => {
  if (!permission || role === "SUPER_ADMIN" || role === "OWNER") return true;

  const direct = permissions?.[permission];
  if (direct) return Boolean(direct.canView) && !direct.restricted;

  const featureKey = ACCESS_FEATURE_BY_PERMISSION[permission];
  const feature = featureKey ? permissions?.[featureKey] : null;

  if (!feature) return role === "DOCTOR";
  return Boolean(feature.canView) && !feature.restricted;
};
