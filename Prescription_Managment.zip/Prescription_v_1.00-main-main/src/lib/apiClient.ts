const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";
const ADMIN_TOKEN_KEY = "carebridge_admin_token";

export const buildApiUrl = (path) => `${API_BASE_URL}${path}`;

export const getAdminToken = () => {
  if (typeof window === "undefined") return "";
  return window.localStorage.getItem(ADMIN_TOKEN_KEY) || "";
};

export const setAdminToken = (token) => {
  if (typeof window === "undefined") return;
  if (token) window.localStorage.setItem(ADMIN_TOKEN_KEY, token);
};

export const clearAdminToken = () => {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(ADMIN_TOKEN_KEY);
};

export const apiFetch = async (path, options = {}) => {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };
  const token = getAdminToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(buildApiUrl(path), {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "Request failed.");
  }
  return data;
};

export const fireAndForget = (path, payload, method = "POST") => {
  apiFetch(path, { method, body: JSON.stringify(payload) }).catch(() => null);
};
