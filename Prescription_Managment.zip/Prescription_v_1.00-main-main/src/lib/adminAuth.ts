import { apiFetch, clearAdminToken, setAdminToken } from "./apiClient";
const ADMIN_SESSION_KEY = "carebridge_admin_session";
const ADMIN_USER_KEY = "carebridge_admin_user";

export const ADMIN_CREDENTIALS = {
  username: "admin",
  password: "123456",
};

const canUseStorage = () => typeof window !== "undefined" && window.localStorage;

export const isAdminLoggedIn = () => {
  if (!canUseStorage()) return false;
  return window.localStorage.getItem(ADMIN_SESSION_KEY) === "active";
};

export const loginAdmin = ({ username, password }) => {
  const valid =
    username.trim() === ADMIN_CREDENTIALS.username &&
    password === ADMIN_CREDENTIALS.password;

  if (valid && canUseStorage()) {
    window.localStorage.setItem(ADMIN_SESSION_KEY, "active");
  }

  return valid;
};

export const logoutAdmin = () => {
  if (!canUseStorage()) return;
  window.localStorage.removeItem(ADMIN_SESSION_KEY);
  window.localStorage.removeItem(ADMIN_USER_KEY);
};

export const getAdminUser = () => {
  if (!canUseStorage()) return null;
  try {
    const saved = window.localStorage.getItem(ADMIN_USER_KEY);
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
};


export const loginAdminRemote = async ({ username, password }) => {
  const response = await apiFetch("/api/admin/login", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  if (response.token) setAdminToken(response.token);
  if (response.admin && canUseStorage()) {
    window.localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(response.admin));
  }
  if (canUseStorage()) window.localStorage.setItem(ADMIN_SESSION_KEY, "active");
  return response;
};

export const logoutAdminRemote = () => {
  clearAdminToken();
  logoutAdmin();
};
