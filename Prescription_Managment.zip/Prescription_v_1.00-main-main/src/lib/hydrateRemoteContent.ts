import { apiFetch } from "./apiClient";
import { STORAGE_KEYS } from "../publicSite/lib/publicStorage";
import { getPublicDoctorIdentity, notifyDoctorIdentityUpdated } from "../services/doctorIdentityApi";

export const hydrateRemoteContent = async () => {
  if (typeof window === "undefined") return;
  try {
    const response = await apiFetch("/api/content");
    const content = response.content || {};
    const map = {
      profile: STORAGE_KEYS.profile,
      services: STORAGE_KEYS.services,
      blogs: STORAGE_KEYS.blogs,
      qa: STORAGE_KEYS.qa,
      gallery: STORAGE_KEYS.gallery,
      appointments: STORAGE_KEYS.appointments,
      messages: STORAGE_KEYS.messages,
      prescriptions: STORAGE_KEYS.prescriptions,
    };
    Object.entries(map).forEach(([key, storageKey]) => {
      if (content[key] !== undefined) {
        window.localStorage.setItem(storageKey, JSON.stringify(content[key]));
      }
    });
    try {
      const identity = await getPublicDoctorIdentity();
      window.localStorage.setItem(STORAGE_KEYS.profile, JSON.stringify(identity));
      notifyDoctorIdentityUpdated(identity);
    } catch {
      // keep content profile fallback
    }
    window.dispatchEvent(new CustomEvent("carebridge-storage-updated", { detail: { key: "remote" } }));
  } catch {
    // Keep local fallback active when API is unavailable.
  }
};
