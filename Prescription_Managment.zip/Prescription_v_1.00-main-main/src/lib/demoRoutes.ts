export const demoRouteGroups = [
  {
    title: "Public Website Demo",
    routes: [
      { title: "Single Doctor Public Site", to: "/demo/public/single-doctor", description: "Doctor profile, services and appointment CTA." },
      { title: "Clinic Public Site", to: "/demo/public/clinic", description: "Clinic hero, doctors, services and emergency contact." },
      { title: "Diagnostic Public Site", to: "/demo/public/diagnostic", description: "Test packages, collection and report delivery." },
      { title: "Hospital Public Site", to: "/demo/public/hospital", description: "Departments, OPD/IPD and emergency flow." },
    ],
  },
  {
    title: "Admin Panel Demo",
    routes: [
      { title: "Super Admin Panel", to: "/super-admin/dashboard", description: "SaaS owner workspace for tenants and packages." },
      { title: "Clinic Dashboard", to: "/clinic/dashboard", description: "Clinic owner operations dashboard." },
      { title: "Doctor Dashboard", to: "/doctor/dashboard", description: "Existing doctor panel route." },
    ],
  },
  {
    title: "Clinic Operation Demo",
    routes: [
      { title: "Appointments", to: "/clinic/appointments", description: "Front desk queue and visit flow." },
      { title: "Patients", to: "/clinic/patients", description: "Patient registry shell." },
      { title: "Billing", to: "/clinic/billing", description: "Invoices and collections shell." },
    ],
  },
  {
    title: "Diagnostic Demo",
    routes: [
      { title: "Diagnostic Dashboard", to: "/diagnostic/dashboard", description: "Lab order and report overview." },
      { title: "Lab Orders", to: "/diagnostic/lab-orders", description: "Order tracking demo." },
      { title: "Reports", to: "/diagnostic/reports", description: "Report delivery shell." },
    ],
  },
  {
    title: "Hospital Future Demo",
    routes: [
      { title: "Hospital Dashboard", to: "/hospital/dashboard", description: "Future-ready hospital ERP overview." },
      { title: "OPD", to: "/hospital/opd", description: "Outpatient department shell." },
      { title: "Beds", to: "/hospital/beds", description: "Bed occupancy shell." },
    ],
  },
];

export const quickDemoRoutes = [
  { title: "Super Admin Panel", to: "/super-admin/dashboard", description: "Platform management" },
  { title: "Clinic Dashboard", to: "/clinic/dashboard", description: "Clinic operations" },
  { title: "Diagnostic Dashboard", to: "/diagnostic/dashboard", description: "Lab workflow" },
  { title: "Hospital Dashboard", to: "/hospital/dashboard", description: "Future hospital shell" },
  { title: "Single Doctor Public Site", to: "/site/single-doctor-demo", description: "Tenant public site" },
  { title: "Clinic Public Site", to: "/site/clinic-demo", description: "Tenant clinic site" },
  { title: "Diagnostic Public Site", to: "/site/diagnostic-demo", description: "Tenant diagnostic site" },
  { title: "Hospital Public Site", to: "/site/hospital-demo", description: "Tenant hospital site" },
];

export const demoModules = [
  { moduleKey: "CLINIC_PUBLIC_SITE", label: "Public Website", category: "Website", status: "Enabled", packages: ["Single Doctor", "Clinic Basic", "Hospital ERP"] },
  { moduleKey: "CLINIC_APPOINTMENT", label: "Appointment Queue", category: "Operations", status: "Enabled", packages: ["Single Doctor", "Clinic Plus"] },
  { moduleKey: "CLINIC_PATIENT", label: "Patient Registry", category: "Operations", status: "Enabled", packages: ["Clinic Basic", "Clinic Plus"] },
  { moduleKey: "CLINIC_PRESCRIPTION", label: "Prescription", category: "Clinical", status: "Enabled", packages: ["Single Doctor", "Clinic Basic"] },
  { moduleKey: "CLINIC_BILLING_BASIC", label: "Basic Billing", category: "Finance", status: "Enabled", packages: ["Clinic Basic", "Diagnostic Center"] },
  { moduleKey: "CLINIC_PATIENT_LEDGER", label: "Patient Ledger", category: "Finance", status: "Enabled", packages: ["Clinic Plus"] },
  { moduleKey: "CLINIC_DIAGNOSTIC", label: "Diagnostic Workflow", category: "Lab", status: "Enabled", packages: ["Diagnostic Center", "Clinic + Diagnostic"] },
  { moduleKey: "CLINIC_LAB_REPORT", label: "Lab Report Builder", category: "Lab", status: "Enabled", packages: ["Diagnostic Center"] },
  { moduleKey: "CLINIC_INVENTORY", label: "Inventory", category: "Stock", status: "Enabled", packages: ["Clinic Plus", "Hospital ERP"] },
  { moduleKey: "CLINIC_IPD_FUTURE", label: "IPD Future", category: "Hospital", status: "Disabled", packages: ["Hospital ERP"] },
  { moduleKey: "CLINIC_PHARMACY_FUTURE", label: "Pharmacy Future", category: "Hospital", status: "Disabled", packages: ["Hospital ERP"] },
];
