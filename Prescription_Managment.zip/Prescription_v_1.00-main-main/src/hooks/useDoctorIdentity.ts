import { useEffect, useState } from "react";
import { doctorIdentityEventName, getPublicDoctorIdentity, normalizeDoctorIdentity } from "../services/doctorIdentityApi";
import { getPublicProfile, savePublicProfile } from "../publicSite/lib/publicStorage";

export const useDoctorIdentity = () => {
  const [identity, setIdentity] = useState(() => normalizeDoctorIdentity(getPublicProfile()));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    getPublicDoctorIdentity()
      .then((data) => {
        if (cancelled) return;
        setIdentity(data);
        savePublicProfile(data);
      })
      .catch(() => null)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    const sync = (event) => {
      const next = normalizeDoctorIdentity(event.detail || getPublicProfile());
      setIdentity(next);
    };

    const storageSync = () => setIdentity(normalizeDoctorIdentity(getPublicProfile()));

    window.addEventListener(doctorIdentityEventName, sync);
    window.addEventListener("carebridge-storage-updated", storageSync);
    window.addEventListener("storage", storageSync);

    return () => {
      cancelled = true;
      window.removeEventListener(doctorIdentityEventName, sync);
      window.removeEventListener("carebridge-storage-updated", storageSync);
      window.removeEventListener("storage", storageSync);
    };
  }, []);

  return { identity, loading };
};
