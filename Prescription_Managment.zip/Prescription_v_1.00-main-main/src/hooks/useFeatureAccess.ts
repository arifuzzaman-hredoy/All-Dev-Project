import { useEffect, useMemo, useState } from "react";
import { apiFetch } from "../lib/apiClient";
import { getAdminUser } from "../lib/adminAuth";
import { DEFAULT_DOCTOR_PANEL_MODULES } from "../lib/modules";
import { canUsePermission } from "../lib/permissions";

const defaultContext = () => ({
  role: getAdminUser()?.role || "SUPER_ADMIN",
  modules: DEFAULT_DOCTOR_PANEL_MODULES,
  permissions: {},
  tenant: null,
  loading: true,
});

export const useFeatureAccess = () => {
  const [context, setContext] = useState(defaultContext);

  useEffect(() => {
    let alive = true;

    apiFetch("/api/app/context")
      .then((response) => {
        if (!alive) return;
        const data = response.data || {};
        setContext({
          role: data.user?.role || getAdminUser()?.role || "SUPER_ADMIN",
          modules: Array.isArray(data.modules) && data.modules.length
            ? data.modules
            : DEFAULT_DOCTOR_PANEL_MODULES,
          permissions: data.permissions || {},
          tenant: data.tenant || null,
          loading: false,
        });
      })
      .catch(() => {
        if (!alive) return;
        setContext((prev) => ({ ...prev, loading: false }));
      });

    return () => {
      alive = false;
    };
  }, []);

  return useMemo(() => {
    const moduleSet = new Set(context.modules);

    return {
      ...context,
      hasModule: (moduleKey) => !moduleKey || moduleSet.has(moduleKey),
      can: (permission) =>
        canUsePermission({
          role: context.role,
          permissions: context.permissions,
          permission,
        }),
    };
  }, [context]);
};
