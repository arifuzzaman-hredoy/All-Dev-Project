import { useMemo } from "react";
import { DOCTOR_PANEL_ROUTES, MOBILE_ROUTE_PATHS } from "../lib/routes";
import { useFeatureAccess } from "./useFeatureAccess";

const normalizePath = (path = "") => path.trim().replace(/\/+$/, "").toLowerCase();

const removeDuplicateItems = (items) => {
  const usedPaths = new Set();

  return items.filter((item) => {
    const pathKey = normalizePath(item.path);

    if (!pathKey || usedPaths.has(pathKey)) return false;

    usedPaths.add(pathKey);
    return true;
  });
};

export const useDashboardNavigation = ({ mobile = false } = {}) => {
  const access = useFeatureAccess();

  const items = useMemo(() => {
    const filtered = DOCTOR_PANEL_ROUTES.filter((item) => {
      return access.hasModule(item.module) && access.can(item.permission);
    });

    const unique = removeDuplicateItems(filtered);

    if (!mobile) return unique;

    const mobileItems = MOBILE_ROUTE_PATHS.map((path) =>
      unique.find((item) => item.path === path)
    ).filter(Boolean);

    return mobileItems.length >= 5 ? mobileItems.slice(0, 5) : unique.slice(0, 5);
  }, [access, mobile]);

  return {
    ...access,
    items,
  };
};
