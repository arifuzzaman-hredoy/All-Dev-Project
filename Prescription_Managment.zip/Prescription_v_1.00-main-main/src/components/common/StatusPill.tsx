import { statusColors } from "../../data/mockData";

const StatusPill = ({ status }) => {
  const tone = statusColors[status] || "teal";
  const toneClass =
    {
      urgent: "bg-red-50 text-red-700 ring-red-100",
      green: "bg-emerald-50 text-emerald-700 ring-emerald-100",
      amber: "bg-amber-50 text-amber-700 ring-amber-100",
      blue: "bg-blue-50 text-blue-700 ring-blue-100",
      purple: "bg-violet-50 text-violet-700 ring-violet-100",
      teal: "bg-cyan-50 text-teal-700 ring-cyan-100",
    }[tone] || "bg-cyan-50 text-teal-700 ring-cyan-100";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-black ring-1 ${toneClass}`}>
      <i className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
      <span>{status}</span>
    </span>
  );
};

export default StatusPill;
