import { LucideIcon } from "lucide-react";

type StatCardProps = {
  label: string;
  value: string;
  note: string;
  icon?: LucideIcon;
};

const StatCard = ({ label, value, note, icon: Icon }: StatCardProps) => (
  <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
    <div className="flex items-start justify-between gap-3">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.08em] text-slate-400">
          {label}
        </p>
        <h2 className="mt-2 text-2xl font-black text-slate-950">{value}</h2>
        <p className="mt-1 text-[12px] font-bold text-slate-500">{note}</p>
      </div>
      {Icon ? (
        <span className="grid h-10 w-10 place-items-center rounded-2xl bg-cyan-50 text-teal-700">
          <Icon size={19} />
        </span>
      ) : null}
    </div>
  </article>
);

export default StatCard;
