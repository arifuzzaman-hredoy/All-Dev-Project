const IconButton = ({
  icon: Icon,
  label,
  onClick,
  type = "button",
  variant = "primary",
  className = "",
}) => {
  const variantClass =
    variant === "ghost" || variant === "secondary"
      ? "border border-teal-100 bg-white/80 text-teal-800 hover:bg-cyan-50"
      : "bg-gradient-to-r from-teal-700 to-cyan-500 text-white shadow-lg hover:-translate-y-0.5";

  return (
    <button
      type={type}
      className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-full px-4 text-sm font-black transition focus:outline-none focus:ring-2 focus:ring-cyan-300 ${variantClass} ${className}`.trim()}
      onClick={onClick}
    >
      {Icon ? <Icon size={16} /> : null}
      <span>{label}</span>
    </button>
  );
};

export default IconButton;
