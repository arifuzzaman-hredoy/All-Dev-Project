import StatusBadge from "./StatusBadge";

type ModuleCardProps = {
  moduleKey: string;
  label: string;
  category: string;
  status: string;
  packages: string[];
};

const ModuleCard = ({ moduleKey, label, category, status, packages }: ModuleCardProps) => (
  <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <p className="truncate text-[11px] font-black uppercase tracking-[0.08em] text-teal-700">
          {moduleKey}
        </p>
        <h3 className="mt-1 text-sm font-black text-slate-950">{label}</h3>
        <p className="mt-1 text-[12px] font-bold text-slate-500">{category}</p>
      </div>
      <StatusBadge status={status} />
    </div>
    <p className="mt-3 text-[12px] font-semibold leading-5 text-slate-500">
      Included: {packages.join(", ")}
    </p>
    <div className="mt-3 flex flex-wrap gap-2">
      {["View", "Enable", "Disable", "Configure"].map((action) => (
        <button
          key={action}
          type="button"
          className="rounded-full bg-slate-50 px-3 py-1.5 text-[11px] font-black text-slate-600 transition hover:bg-cyan-50 hover:text-teal-700"
        >
          {action}
        </button>
      ))}
    </div>
  </article>
);

export default ModuleCard;
