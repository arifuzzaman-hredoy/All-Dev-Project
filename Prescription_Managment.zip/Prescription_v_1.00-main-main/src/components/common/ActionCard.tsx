import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

type ActionCardProps = {
  title: string;
  description: string;
  to: string;
  icon?: LucideIcon;
};

const ActionCard = ({ title, description, to, icon: Icon }: ActionCardProps) => (
  <Link
    to={to}
    className="group rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)] transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-[0_18px_38px_rgba(11,86,90,0.09)]"
  >
    <div className="flex items-start gap-3">
      {Icon ? (
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-cyan-50 text-teal-700 transition group-hover:-rotate-6">
          <Icon size={18} />
        </span>
      ) : null}
      <span className="min-w-0">
        <span className="block text-sm font-black text-slate-950">{title}</span>
        <span className="mt-1 block text-[12px] font-semibold leading-5 text-slate-500">
          {description}
        </span>
      </span>
    </div>
  </Link>
);

export default ActionCard;
