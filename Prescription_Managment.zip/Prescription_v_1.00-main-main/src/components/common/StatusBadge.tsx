type StatusBadgeProps = {
  status: string;
};

const statusClass = (status: string) => {
  const key = status.toLowerCase();
  if (key.includes("active") || key.includes("enabled") || key.includes("delivered")) {
    return "bg-emerald-50 text-emerald-700";
  }
  if (key.includes("pending") || key.includes("trial") || key.includes("waiting")) {
    return "bg-amber-50 text-amber-700";
  }
  if (key.includes("expired") || key.includes("disabled") || key.includes("due")) {
    return "bg-red-50 text-red-700";
  }
  return "bg-cyan-50 text-teal-700";
};

const StatusBadge = ({ status }: StatusBadgeProps) => (
  <span className={["inline-flex w-fit rounded-full px-2.5 py-1 text-[11px] font-black", statusClass(status)].join(" ")}>
    {status}
  </span>
);

export default StatusBadge;
