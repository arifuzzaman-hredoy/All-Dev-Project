import { Link } from "react-router-dom";

type RouteCardProps = {
  title: string;
  description: string;
  to: string;
};

const RouteCard = ({ title, description, to }: RouteCardProps) => (
  <Link
    to={to}
    className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)] transition hover:-translate-y-0.5 hover:border-cyan-200"
  >
    <span className="block text-sm font-black text-slate-950">{title}</span>
    <span className="mt-1 block text-[12px] font-semibold leading-5 text-slate-500">
      {description}
    </span>
    <span className="mt-3 block truncate rounded-full bg-cyan-50 px-3 py-1.5 text-[11px] font-black text-teal-800">
      {to}
    </span>
  </Link>
);

export default RouteCard;
