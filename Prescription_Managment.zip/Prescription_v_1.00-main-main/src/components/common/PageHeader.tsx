import { ReactNode } from "react";

type PageHeaderProps = {
  eyebrow?: string;
  title: string;
  description: string;
  actions?: ReactNode;
};

const PageHeader = ({ eyebrow, title, description, actions }: PageHeaderProps) => (
  <section className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
    <div className="min-w-0">
      {eyebrow ? (
        <p className="mb-1 text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">
          {eyebrow}
        </p>
      ) : null}
      <h1 className="text-[26px] font-black tracking-tight text-slate-950 sm:text-[30px]">
        {title}
      </h1>
      <p className="mt-1 max-w-3xl text-[13px] font-semibold leading-6 text-slate-500">
        {description}
      </p>
    </div>
    {actions ? <div className="flex shrink-0 flex-wrap gap-2">{actions}</div> : null}
  </section>
);

export default PageHeader;
