const GlassCard = ({ className = "", children }) => {
  return (
    <section
      className={`rounded-[1.5rem] border border-teal-100 bg-white/80 p-4 shadow-[0_12px_40px_rgba(11,86,90,0.12)] backdrop-blur-xl ${className}`.trim()}
    >
      {children}
    </section>
  );
};

export default GlassCard;
