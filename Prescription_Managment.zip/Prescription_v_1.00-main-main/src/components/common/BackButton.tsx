import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const BackButton = ({ label = "Back", to }) => {
  const navigate = useNavigate();

  const handleBack = () => {
    const historyIndex = window.history.state?.idx;
    const hasInAppHistory =
      typeof historyIndex === "number" && historyIndex > 0;

    if (hasInAppHistory) {
      navigate(-1);
      return;
    }

    if (to) {
      navigate(to);
      return;
    }

    navigate("/doctor/dashboard");
  };

  return (
    <button
      type="button"
      className="inline-flex min-h-10 items-center gap-2 rounded-full border border-teal-100 bg-white/80 px-4 text-sm font-black text-teal-800 shadow-sm transition hover:bg-cyan-50 focus:outline-none focus:ring-2 focus:ring-cyan-300"
      onClick={handleBack}
    >
      <ArrowLeft size={16} />
      <span>{label}</span>
    </button>
  );
};

export default BackButton;
