const SectionTitle = ({ title, subtitle, action }) => {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h2 className="text-lg font-black tracking-tight text-slate-900">{title}</h2>
        {subtitle ? (
          <p className="mt-1 text-sm font-semibold text-slate-500">{subtitle}</p>
        ) : null}
      </div>
      {action ? <div>{action}</div> : null}
    </div>
  );
};

export default SectionTitle;
