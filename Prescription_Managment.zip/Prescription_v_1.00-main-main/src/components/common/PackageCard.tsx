import { Link } from "react-router-dom";

type PackageCardProps = {
  name: string;
  target: string;
  modules: string[];
  limits: string;
  publicDemo: string;
  adminDemo: string;
  extraAdminDemo?: string;
};

const PackageCard = ({ name, target, modules, limits, publicDemo, adminDemo, extraAdminDemo }: PackageCardProps) => (
  <article className="flex h-full flex-col rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_16px_38px_rgba(15,23,42,0.06)]">
    <p className="text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">{target}</p>
    <h3 className="mt-1 text-xl font-black text-slate-950">{name}</h3>
    <p className="mt-2 text-[12px] font-bold text-slate-500">{limits}</p>
    <div className="mt-4 flex flex-wrap gap-2">
      {modules.map((module) => (
        <span key={module} className="rounded-full bg-cyan-50 px-2.5 py-1 text-[10px] font-black text-teal-800">
          {module}
        </span>
      ))}
    </div>
    <div className="mt-auto grid gap-2 pt-5">
      <Link to={publicDemo} className="rounded-full bg-teal-700 px-4 py-2 text-center text-[12px] font-black text-white transition hover:bg-teal-800">
        View Public Demo
      </Link>
      <Link to={adminDemo} className="rounded-full bg-cyan-50 px-4 py-2 text-center text-[12px] font-black text-teal-800 transition hover:bg-cyan-100">
        View Admin Demo
      </Link>
      {extraAdminDemo ? (
        <Link to={extraAdminDemo} className="rounded-full bg-blue-50 px-4 py-2 text-center text-[12px] font-black text-blue-700 transition hover:bg-blue-100">
          Diagnostic Dashboard
        </Link>
      ) : null}
      <div className="grid grid-cols-2 gap-2">
        <Link to="/contact-sales" className="rounded-full bg-slate-50 px-3 py-2 text-center text-[11px] font-black text-slate-700 transition hover:bg-slate-100">
          Start Trial
        </Link>
        <Link to="/book-demo" className="rounded-full bg-slate-50 px-3 py-2 text-center text-[11px] font-black text-slate-700 transition hover:bg-slate-100">
          Book Demo
        </Link>
      </div>
    </div>
  </article>
);

export default PackageCard;
