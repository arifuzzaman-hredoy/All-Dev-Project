import { Search } from "lucide-react";

const SearchInput = ({
  value,
  onChange,
  placeholder = "Search patients, ID, complaint...",
}) => {
  return (
    <label className="flex min-h-11 items-center gap-2 rounded-2xl border border-teal-100 bg-white/90 px-4 shadow-sm focus-within:ring-2 focus-within:ring-cyan-100">
      <Search size={16} className="shrink-0 text-slate-400" />
      <input
        className="min-w-0 flex-1 bg-transparent text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
    </label>
  );
};

export default SearchInput;
