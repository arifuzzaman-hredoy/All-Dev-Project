import { ExternalLink } from "lucide-react";

type ProductCreditProps = {
  variant?: "dark" | "light";
};

const ProductCredit = ({ variant = "light" }: ProductCreditProps) => {
  const isDark = variant === "dark";

  return (
    <span
      className={[
        "inline-flex flex-wrap items-center justify-center gap-2 text-[11px] font-black uppercase tracking-[0.14em]",
        isDark ? "text-white/36" : "text-slate-400",
      ].join(" ")}
    >
      <span>This is a product of</span>
      <a
        href="https://techteamlead.com/"
        target="_blank"
        rel="noreferrer"
        className={[
          "group inline-flex items-center gap-1 transition hover:underline",
          isDark ? "text-white/70 hover:text-white" : "text-teal-700 hover:text-teal-800",
        ].join(" ")}
      >
        TechTeamLead
        <ExternalLink
          size={12}
          className="transition-transform duration-300 group-hover:translate-x-0.5"
        />
      </a>
    </span>
  );
};

export default ProductCredit;
