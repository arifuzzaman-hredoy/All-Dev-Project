const DemoNotice = ({ text = "Demo Data: This page uses frontend mock data only." }) => (
  <div className="rounded-2xl border border-cyan-100 bg-cyan-50/80 px-4 py-3 text-[12px] font-bold text-teal-800">
    {text}
  </div>
);

export default DemoNotice;
