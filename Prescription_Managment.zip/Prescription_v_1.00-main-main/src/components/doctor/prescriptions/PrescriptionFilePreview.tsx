import { FileText, Image as ImageIcon } from "lucide-react";
import type { PrescriptionFilePayload } from "../../../types/prescription";

type Props = {
  file: PrescriptionFilePayload | null;
};

const PrescriptionFilePreview = ({ file }: Props) => {
  if (!file) {
    return (
      <div className="rounded-2xl border border-dashed border-cyan-200 bg-cyan-50/45 p-4 text-sm font-bold text-slate-500">
        No prescription file selected.
      </div>
    );
  }

  const isImage = file.mimeType.startsWith("image/");

  return (
    <div className="flex items-center gap-3 rounded-2xl border border-cyan-100 bg-cyan-50/50 p-3">
      {isImage ? (
        <ImageIcon className="shrink-0 text-teal-700" size={20} />
      ) : (
        <FileText className="shrink-0 text-blue-700" size={20} />
      )}
      <div className="min-w-0">
        <p className="truncate text-sm font-black text-slate-900">{file.fileName}</p>
        <p className="text-xs font-bold text-slate-500">{file.mimeType}</p>
      </div>
    </div>
  );
};

export default PrescriptionFilePreview;
