import { useState } from "react";
import { Plus, UploadCloud, X } from "lucide-react";
import { bulkUploadPrescriptions, fileToPrescriptionPayload } from "../../../services/prescriptionApi";
import type { PrescriptionItem, PrescriptionUploadPayload } from "../../../types/prescription";

const today = () => new Date().toISOString().slice(0, 10);
const makeRow = (): PrescriptionUploadPayload & { localId: string; error?: string } => ({
  localId: `${Date.now()}-${Math.random()}`,
  prescriptionDate: today(),
  patientId: "",
  phone: "",
  patientName: "",
  appointmentId: "",
  doctorName: "",
  title: "Prescription",
  notes: "",
  file: null,
});

const inputClass = "w-full rounded-xl border border-cyan-100 bg-white px-3 py-2 text-xs font-bold text-slate-700 outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100";

type Props = {
  onUploaded: (items: PrescriptionItem[]) => void;
  onNotice: (message: string, tone?: "success" | "error") => void;
  canUpload?: boolean;
};

const BulkPrescriptionUploadTable = ({ onUploaded, onNotice, canUpload = true }: Props) => {
  const [rows, setRows] = useState([makeRow()]);
  const [uploading, setUploading] = useState(false);

  const updateRow = (localId: string, key: string, value: unknown) => {
    setRows((prev) => prev.map((row) => (row.localId === localId ? { ...row, [key]: value, error: "" } : row)));
  };

  const addRow = () => setRows((prev) => [...prev, makeRow()]);
  const removeRow = (localId: string) => setRows((prev) => (prev.length === 1 ? prev : prev.filter((row) => row.localId !== localId)));

  const uploadAll = async () => {
    setUploading(true);
    try {
      const result = await bulkUploadPrescriptions(rows);
      const uploadedItems = (result.results || []).filter((item) => item.ok).map((item) => item.item);
      const failed = new Map((result.results || []).filter((item) => !item.ok).map((item) => [item.index, item.message]));
      setRows((prev) =>
        prev
          .map((row, index) => ({ ...row, error: failed.get(index) || row.error }))
          .filter((_, index) => failed.has(index)),
      );
      if (uploadedItems.length) onUploaded(uploadedItems);
      onNotice(`Bulk upload finished. Uploaded ${result.uploaded || 0}, failed ${result.failed || 0}.`, result.failed ? "error" : "success");
      if (!failed.size) setRows([makeRow()]);
    } catch (error) {
      onNotice(error.message || "Bulk upload failed.", "error");
    } finally {
      setUploading(false);
    }
  };

  return (
    <section className="grid gap-4 rounded-[28px] border border-cyan-100 bg-white/88 p-5 shadow-[0_16px_40px_rgba(11,86,90,0.08)]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black tracking-tight text-slate-950">Batch Upload</h2>
          <p className="mt-1 text-sm font-semibold text-slate-500">Upload multiple prescriptions for the selected date.</p>
        </div>
        <button type="button" onClick={addRow} className="inline-flex min-h-10 items-center gap-2 rounded-2xl border border-cyan-100 bg-white px-4 text-sm font-black text-teal-700 hover:bg-cyan-50">
          <Plus size={16} /> Add row
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[1040px] w-full border-separate border-spacing-y-2 text-left">
          <thead className="text-xs font-black uppercase text-slate-400">
            <tr>
              <th className="px-2">Date</th>
              <th className="px-2">Patient ID</th>
              <th className="px-2">Phone</th>
              <th className="px-2">Name</th>
              <th className="px-2">Serial</th>
              <th className="px-2">File</th>
              <th className="px-2">Notes</th>
              <th className="px-2">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.localId} className="align-top">
                <td className="px-2"><input type="date" className={inputClass} value={row.prescriptionDate} onChange={(event) => updateRow(row.localId, "prescriptionDate", event.target.value)} /></td>
                <td className="px-2"><input className={inputClass} value={row.patientId} onChange={(event) => updateRow(row.localId, "patientId", event.target.value)} /></td>
                <td className="px-2"><input className={inputClass} value={row.phone} onChange={(event) => updateRow(row.localId, "phone", event.target.value)} /></td>
                <td className="px-2"><input className={inputClass} value={row.patientName} onChange={(event) => updateRow(row.localId, "patientName", event.target.value)} /></td>
                <td className="px-2"><input className={inputClass} value={row.appointmentId} onChange={(event) => updateRow(row.localId, "appointmentId", event.target.value)} /></td>
                <td className="px-2">
                  <input
                    type="file"
                    className={inputClass}
                    accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                    onChange={async (event) => {
                      const file = event.target.files?.[0];
                      if (file) updateRow(row.localId, "file", await fileToPrescriptionPayload(file));
                    }}
                  />
                  <p className="mt-1 max-w-36 truncate text-[11px] font-bold text-slate-400">{row.file?.fileName}</p>
                  {row.error ? <p className="mt-1 text-[11px] font-black text-rose-600">{row.error}</p> : null}
                </td>
                <td className="px-2"><input className={inputClass} value={row.notes} onChange={(event) => updateRow(row.localId, "notes", event.target.value)} /></td>
                <td className="px-2">
                  <button type="button" onClick={() => removeRow(row.localId)} className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600">
                    <X size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {canUpload ? (
      <button type="button" onClick={uploadAll} disabled={uploading} className="inline-flex min-h-11 w-fit items-center justify-center gap-2 rounded-2xl bg-teal-700 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 disabled:opacity-60">
        <UploadCloud size={16} /> {uploading ? "Uploading rows..." : "Upload all prescriptions"}
      </button>
      ) : null}
    </section>
  );
};

export default BulkPrescriptionUploadTable;
