import { FormEvent, useEffect, useState } from "react";
import { Search, Send, X } from "lucide-react";
import {
  fileToPrescriptionPayload,
  searchPatients,
  uploadPrescription,
} from "../../../services/prescriptionApi";
import type {
  PatientSearchResult,
  PrescriptionFilePayload,
  PrescriptionItem,
  PrescriptionUploadPayload,
} from "../../../types/prescription";
import PrescriptionFilePreview from "./PrescriptionFilePreview";

const today = () => new Date().toISOString().slice(0, 10);

const emptyForm: PrescriptionUploadPayload = {
  prescriptionDate: today(),
  patientId: "",
  phone: "",
  patientName: "",
  appointmentId: "",
  doctorName: "",
  title: "",
  notes: "",
  file: null,
};

const inputClass =
  "w-full rounded-2xl border border-cyan-100 bg-white px-4 py-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100";

type Props = {
  onUploaded: (item: PrescriptionItem) => void;
  onNotice: (message: string, tone?: "success" | "error") => void;
  initialPatient?: Partial<PatientSearchResult> | null;
  canUpload?: boolean;
};

const PrescriptionUploadForm = ({ onUploaded, onNotice, initialPatient, canUpload = true }: Props) => {
  const [form, setForm] = useState(emptyForm);
  const [patientQuery, setPatientQuery] = useState("");
  const [patients, setPatients] = useState<PatientSearchResult[]>([]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!initialPatient) return;
    setForm((prev) => ({
      ...prev,
      patientId: initialPatient.patientId || "",
      patientName: initialPatient.patientName || "",
      phone: initialPatient.phone || "",
      appointmentId: initialPatient.appointmentId || "",
    }));
    setPatientQuery(initialPatient.patientName || initialPatient.patientId || "");
  }, [initialPatient]);

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      searchPatients(patientQuery)
        .then((items) => {
          if (!cancelled) setPatients(items);
        })
        .catch(() => {
          if (!cancelled) setPatients([]);
        });
    }, 250);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [patientQuery]);

  const setField = (key: keyof PrescriptionUploadPayload, value: string | PrescriptionFilePayload | null) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const selectPatient = (patient: PatientSearchResult) => {
    setForm((prev) => ({
      ...prev,
      patientId: patient.patientId,
      patientName: patient.patientName,
      phone: patient.phone,
      appointmentId: patient.appointmentId,
    }));
    setPatientQuery(patient.patientName || patient.patientId);
  };

  const onFile = async (file?: File) => {
    if (!file) return;
    setField("file", await fileToPrescriptionPayload(file));
  };

  const reset = () => {
    setForm({ ...emptyForm, prescriptionDate: today() });
    setPatientQuery("");
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setUploading(true);
    try {
      const item = await uploadPrescription(form);
      onUploaded(item);
      onNotice("Prescription uploaded successfully.");
      reset();
    } catch (error) {
      onNotice(error.message || "Prescription upload failed.", "error");
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={submit} className="grid gap-4 rounded-[28px] border border-cyan-100 bg-white/88 p-5 shadow-[0_16px_40px_rgba(11,86,90,0.08)]">
      <div>
        <h2 className="text-xl font-black tracking-tight text-slate-950">Single Upload</h2>
        <p className="mt-1 text-sm font-semibold text-slate-500">Search an existing patient or enter details manually.</p>
      </div>

      <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
        Patient search
        <div className="relative">
          <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-teal-700" />
          <input className={`${inputClass} pl-11`} value={patientQuery} onChange={(event) => setPatientQuery(event.target.value)} placeholder="Name, phone, Patient ID, appointment ID" />
        </div>
      </label>

      {patients.length ? (
        <div className="grid max-h-44 gap-2 overflow-y-auto rounded-2xl border border-cyan-100 bg-cyan-50/40 p-2">
          {patients.map((patient) => (
            <button
              type="button"
              key={`${patient.patientId}-${patient.appointmentId}`}
              onClick={() => selectPatient(patient)}
              className="rounded-xl bg-white px-3 py-2 text-left text-xs font-bold text-slate-600 transition hover:bg-cyan-50"
            >
              <span className="block text-sm font-black text-slate-900">{patient.patientName || patient.patientId}</span>
              {patient.patientId} · {patient.phone} · {patient.appointmentId}
            </button>
          ))}
        </div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Date<input type="date" className={inputClass} value={form.prescriptionDate} onChange={(event) => setField("prescriptionDate", event.target.value)} required /></label>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Patient ID<input className={inputClass} value={form.patientId} onChange={(event) => setField("patientId", event.target.value)} required /></label>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Phone<input className={inputClass} value={form.phone} onChange={(event) => setField("phone", event.target.value)} required /></label>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Patient name<input className={inputClass} value={form.patientName} onChange={(event) => setField("patientName", event.target.value)} /></label>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Appointment / Serial<input className={inputClass} value={form.appointmentId} onChange={(event) => setField("appointmentId", event.target.value)} /></label>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Doctor name<input className={inputClass} value={form.doctorName} onChange={(event) => setField("doctorName", event.target.value)} /></label>
      </div>

      <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Prescription title<input className={inputClass} value={form.title} onChange={(event) => setField("title", event.target.value)} placeholder="Follow-up prescription" /></label>
      <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Notes / diagnosis<textarea className={`${inputClass} min-h-24 resize-y`} value={form.notes} onChange={(event) => setField("notes", event.target.value)} /></label>
      <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">Prescription file<input type="file" className={inputClass} accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp" onChange={(event) => onFile(event.target.files?.[0])} required={!form.file} /></label>
      <PrescriptionFilePreview file={form.file || null} />

      <div className="flex flex-wrap gap-2">
        {canUpload ? (
        <button type="submit" disabled={uploading} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60">
          <Send size={16} /> {uploading ? "Uploading..." : "Upload"}
        </button>
        ) : null}
        <button type="button" onClick={reset} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-cyan-100 bg-white px-5 text-sm font-black text-teal-700 transition hover:bg-cyan-50">
          <X size={16} /> Reset
        </button>
      </div>
    </form>
  );
};

export default PrescriptionUploadForm;
