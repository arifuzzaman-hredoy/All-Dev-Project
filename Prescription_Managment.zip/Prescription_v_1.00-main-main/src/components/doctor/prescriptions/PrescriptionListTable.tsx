import { CopyPlus, Download, Eye, RefreshCw, Trash2, UploadCloud } from "lucide-react";
import { getAdminToken } from "../../../lib/apiClient";
import {
  deletePrescription,
  duplicateFollowUpPrescription,
  fileToPrescriptionPayload,
  publishPrescription,
  replacePrescriptionFile,
} from "../../../services/prescriptionApi";
import type { PrescriptionItem } from "../../../types/prescription";

type Props = {
  items: PrescriptionItem[];
  onChanged: () => void;
  onNotice: (message: string, tone?: "success" | "error") => void;
  canDelete?: boolean;
};

const PrescriptionListTable = ({ items, onChanged, onNotice, canDelete = true }: Props) => {
  const download = async (url: string) => {
    try {
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${getAdminToken()}` },
      });
      if (!response.ok) throw new Error("Download failed.");
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      window.open(objectUrl, "_blank", "noopener,noreferrer");
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
    } catch (error) {
      onNotice(error.message || "Download failed.", "error");
    }
  };

  const remove = async (id: string) => {
    if (!window.confirm("Delete this prescription?")) return;
    try {
      await deletePrescription(id);
      onNotice("Prescription deleted successfully.");
      onChanged();
    } catch (error) {
      onNotice(error.message || "Delete failed.", "error");
    }
  };

  const replaceFile = async (item: PrescriptionItem, file?: File) => {
    if (!file) return;
    try {
      await replacePrescriptionFile(item.id, { file: await fileToPrescriptionPayload(file) });
      onNotice("Prescription file replaced successfully.");
      onChanged();
    } catch (error) {
      onNotice(error.message || "Replace failed.", "error");
    }
  };

  const publish = async (item: PrescriptionItem) => {
    try {
      await publishPrescription(item.id);
      onNotice("Prescription uploaded successfully.");
      onChanged();
    } catch (error) {
      onNotice(error.message || "Upload failed.", "error");
    }
  };

  const duplicate = async (item: PrescriptionItem) => {
    try {
      await duplicateFollowUpPrescription(item.id);
      onNotice("Follow-up prescription created from latest prescription.");
      onChanged();
    } catch (error) {
      onNotice(error.message || "Duplicate failed.", "error");
    }
  };

  return (
    <section className="rounded-[28px] border border-cyan-100 bg-white/88 p-5 shadow-[0_16px_40px_rgba(11,86,90,0.08)]">
      <h2 className="text-xl font-black tracking-tight text-slate-950">Latest Uploaded Prescriptions</h2>
      <div className="mt-4 overflow-x-auto">
        <table className="min-w-[1060px] w-full text-left text-sm">
          <thead className="text-xs font-black uppercase text-slate-400">
            <tr>
              <th className="py-3">Date</th>
              <th>Patient ID</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Serial</th>
              <th>Title</th>
              <th>Attachments</th>
              <th>Status</th>
              <th>Uploaded by</th>
              <th>Uploaded at</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-cyan-50 font-bold text-slate-600">
            {items.map((item) => (
              <tr key={item.id}>
                <td className="py-3">{item.prescriptionDate}</td>
                <td>{item.patientId}</td>
                <td className="text-slate-900">{item.patientName}</td>
                <td>{item.phone}</td>
                <td>{item.appointmentId || "-"}</td>
                <td className="max-w-44 truncate">{item.title || item.fileName || "Prescription"}</td>
                <td>{item.attachmentCount || item.attachments?.length || 0}</td>
                <td><span className="rounded-full bg-teal-50 px-2.5 py-1 text-xs font-black text-teal-700">{item.status}</span></td>
                <td>{item.uploadedBy || "-"}</td>
                <td>{item.uploadedAt ? new Date(item.uploadedAt).toLocaleString() : "-"}</td>
                <td>
                  <div className="flex items-center gap-1">
                    <button type="button" title="View" onClick={() => download(`/api/doctor/prescriptions/${item.id}/download`)} className="grid h-9 w-9 place-items-center rounded-xl text-teal-700 hover:bg-cyan-50"><Eye size={16} /></button>
                    {item.status !== "uploaded" && item.status !== "active" ? (
                      <button type="button" title="Upload" onClick={() => publish(item)} className="grid h-9 w-9 place-items-center rounded-xl text-teal-700 hover:bg-cyan-50"><UploadCloud size={16} /></button>
                    ) : null}
                    <button type="button" title="Duplicate Latest" onClick={() => duplicate(item)} className="grid h-9 w-9 place-items-center rounded-xl text-indigo-700 hover:bg-indigo-50"><CopyPlus size={16} /></button>
                    <button type="button" title="Download" onClick={() => download(`/api/doctor/prescriptions/${item.id}/download`)} className="grid h-9 w-9 place-items-center rounded-xl text-blue-700 hover:bg-blue-50"><Download size={16} /></button>
                    <label title="Replace file" className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl text-slate-500 hover:bg-cyan-50 hover:text-teal-700">
                      <RefreshCw size={16} />
                      <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp" onChange={(event) => replaceFile(item, event.target.files?.[0])} />
                    </label>
                    {canDelete ? (
                      <button type="button" title="Delete" onClick={() => remove(item.id)} className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600"><Trash2 size={16} /></button>
                    ) : null}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {!items.length ? (
          <div className="grid min-h-32 place-items-center rounded-2xl border border-dashed border-cyan-100 bg-cyan-50/40 text-sm font-black text-slate-500">
            No uploaded prescriptions yet.
          </div>
        ) : null}
      </div>
    </section>
  );
};

export default PrescriptionListTable;
