import { Paperclip, Send, Video } from "lucide-react";

const MessageComposer = ({ value, onChange }) => {
  return (
    <div className="flex items-center gap-2 border-t border-teal-100 p-4">
      <button type="button" className="grid h-10 w-10 place-items-center rounded-full bg-cyan-50 text-teal-700">
        <Paperclip size={16} />
      </button>
      <input
        className="min-w-0 flex-1 rounded-2xl border border-teal-100 bg-white px-4 py-3 text-sm font-semibold outline-none focus:ring-2 focus:ring-cyan-100"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Type your message..."
      />
      <button type="button" className="grid h-10 w-10 place-items-center rounded-full bg-cyan-50 text-teal-700">
        <Video size={16} />
      </button>
      <button type="button" className="grid h-10 w-10 place-items-center rounded-full bg-teal-700 text-white">
        <Send size={16} />
      </button>
    </div>
  );
};

export default MessageComposer;
