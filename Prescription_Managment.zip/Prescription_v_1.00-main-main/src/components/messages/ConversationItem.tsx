const ConversationItem = ({ item, active, onClick }) => {
  return (
    <button
      type="button"
      className={[
        "flex w-full gap-3 rounded-2xl p-3 text-left transition focus:outline-none focus:ring-2 focus:ring-cyan-300",
        active ? "bg-cyan-50 ring-1 ring-cyan-100" : "hover:bg-white/80",
      ].join(" ")}
      onClick={onClick}
    >
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-teal-700 text-sm font-black text-white">{item.avatar}</div>
      <div className="min-w-0 flex-1">
        <div>
          <h4 className="truncate text-sm font-black text-slate-900">{item.name}</h4>
          <span className="text-xs font-semibold text-slate-500">{item.role}</span>
        </div>
        <p className="mt-1 truncate text-xs font-semibold text-slate-500">{item.lastMessage}</p>
      </div>
      <div className="grid justify-items-end gap-1">
        <small className="text-xs font-bold text-slate-400">{item.time}</small>
        {item.unread > 0 ? <strong className="grid h-5 min-w-5 place-items-center rounded-full bg-cyan-500 px-1 text-[10px] font-black text-white">{item.unread}</strong> : null}
      </div>
    </button>
  );
};

export default ConversationItem;
