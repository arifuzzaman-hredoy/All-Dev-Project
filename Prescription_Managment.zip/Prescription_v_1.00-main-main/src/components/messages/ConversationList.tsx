import GlassCard from "../common/GlassCard";
import ConversationItem from "./ConversationItem";

const ConversationList = ({ items, activeId, onSelect }) => {
  return (
    <GlassCard className="h-full">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-black text-slate-900">Conversations</h3>
          <p className="text-sm font-semibold text-slate-500">Patient and assistant threads</p>
        </div>
        <span className="rounded-full bg-cyan-50 px-3 py-1 text-xs font-black text-teal-700">{items.length}</span>
      </div>
      <div className="mt-4 grid gap-2">
        {items.map((item) => (
          <ConversationItem
            key={item.id}
            item={item}
            active={activeId === item.id}
            onClick={() => onSelect(item.id)}
          />
        ))}
      </div>
    </GlassCard>
  );
};

export default ConversationList;
