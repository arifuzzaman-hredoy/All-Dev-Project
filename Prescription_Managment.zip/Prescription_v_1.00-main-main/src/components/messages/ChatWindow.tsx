import GlassCard from "../common/GlassCard";
import EmptyState from "../common/EmptyState";
import MessageBubble from "./MessageBubble";
import MessageComposer from "./MessageComposer";

const ChatWindow = ({
  conversation,
  messages,
  composerValue,
  onComposerChange,
  onBack,
  inboxEnabled = true,
}) => {
  if (!inboxEnabled) {
    return (
      <GlassCard className="grid min-h-[520px] place-items-center">
        <EmptyState
          title="Inbox Off"
          subtitle="Turn Inbox ON to view conversations and messages."
        />
      </GlassCard>
    );
  }

  if (!conversation) {
    return (
      <GlassCard className="grid min-h-[520px] place-items-center">
        <EmptyState
          title="Select a conversation"
          subtitle="Choose a patient or assistant to start messaging."
        />
      </GlassCard>
    );
  }

  return (
    <GlassCard className="flex min-h-[620px] flex-col p-0">
      <div className="flex items-center gap-3 border-b border-teal-100 p-4">
        {onBack ? (
          <button
            type="button"
            className="inline-flex rounded-full border border-teal-100 bg-white px-3 py-1.5 text-xs font-black text-teal-700 lg:hidden"
            onClick={onBack}
          >
            Back
          </button>
        ) : null}
        <div>
          <h3 className="text-lg font-black text-slate-900">{conversation.name}</h3>
          <p className="text-sm font-semibold text-slate-500">{conversation.role}</p>
        </div>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
      </div>
      <MessageComposer value={composerValue} onChange={onComposerChange} />
    </GlassCard>
  );
};

export default ChatWindow;
