const MessageBubble = ({ message }) => {
  return (
    <div
      className={[
        "max-w-[78%] rounded-2xl px-4 py-3 text-sm font-semibold shadow-sm",
        message.from === "me"
          ? "ml-auto bg-teal-700 text-white"
          : "mr-auto bg-white text-slate-700 ring-1 ring-teal-100",
      ].join(" ")}
    >
      <p>{message.text}</p>
      <small className={message.from === "me" ? "mt-1 block text-xs text-cyan-100" : "mt-1 block text-xs text-slate-400"}>{message.time}</small>
    </div>
  );
};

export default MessageBubble;
