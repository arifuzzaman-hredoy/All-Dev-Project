const CmsToolbar = ({ title, description, action }) => (
  <div className="flex flex-col gap-4 rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur sm:flex-row sm:items-center sm:justify-between">
    <div>
      <h2 className="text-2xl font-black tracking-tight text-slate-900">{title}</h2>
      {description ? (
        <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
          {description}
        </p>
      ) : null}
    </div>
    {action}
  </div>
);

export default CmsToolbar;
