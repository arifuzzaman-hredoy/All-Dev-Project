const CmsTextarea = ({ label, value, onChange, rows = 4 }) => (
  <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
    <span>{label}</span>
    <textarea
      className="w-full resize-y rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
      rows={rows}
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
    />
  </label>
);

export default CmsTextarea;
