const CmsEmptyState = ({ title, message }) => (
  <div className="rounded-2xl border border-dashed border-teal-200 bg-white/60 p-6 text-center">
    <h3 className="text-lg font-black text-slate-900">{title}</h3>
    <p className="mt-1 text-sm font-semibold text-slate-500">{message}</p>
  </div>
);

export default CmsEmptyState;
