const CmsTextInput = ({ label, value, onChange, type = "text", placeholder }) => (
  <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
    <span>{label}</span>
    <input
      className="w-full rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
      type={type}
      value={value || ""}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  </label>
);

export default CmsTextInput;
