import CmsTextInput from "./CmsTextInput";

const CmsImageInput = ({ label, value, onChange }) => (
  <div className="grid gap-3">
    <CmsTextInput label={label} value={value} onChange={onChange} />
    {value ? (
      <img
        className="max-h-44 w-full rounded-2xl border border-teal-100 object-cover"
        src={value}
        alt={label}
      />
    ) : null}
  </div>
);

export default CmsImageInput;
