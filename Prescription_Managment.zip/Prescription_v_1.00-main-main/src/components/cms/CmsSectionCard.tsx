const CmsSectionCard = ({ title, description, children }) => (
  <section className="grid gap-4 rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur">
    <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
      <h3 className="text-xl font-black tracking-tight text-slate-900">{title}</h3>
      {description ? (
        <p className="text-sm font-semibold leading-6 text-slate-500">{description}</p>
      ) : null}
    </div>
    {children}
  </section>
);

export default CmsSectionCard;
