import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  Camera,
  CheckCircle2,
  Clock3,
  MonitorCog,
  Plus,
  RotateCcw,
  Save,
  Settings2,
  Trash2,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import GlassCard from "../common/GlassCard";

const APPOINTMENT_RULES_KEY = "doctor_appointment_rules";

type DayValue = 0 | 1 | 2 | 3 | 4 | 5 | 6;

type AppointmentSlot = {
  label: string;
  start: string;
  end: string;
  intervalMinutes: number;
  capacityPerSlot: number;
};

type AppointmentRules = {
  dailyCapacity: number;
  blockedDates: string[];
  dateLimits: Record<string, number>;
  dateSlots: Record<string, AppointmentSlot[]>;
  weeklySlots: Partial<Record<DayValue, AppointmentSlot[]>>;
};

type WeeklyRow = {
  day: DayValue;
  short: string;
  name: string;
  isOpen: boolean;
  label: string;
  start: string;
  end: string;
  intervalMinutes: number;
  capacityPerSlot: number;
};

type AppointmentSetup = {
  dailyCapacity: number;
  blockedDates: string[];
  dateLimits: Record<string, number>;
  dateSlots: Record<string, AppointmentSlot[]>;
  weeklyRows: WeeklyRow[];
};

export type DoctorProfileFormState = {
  name: string;
  department: string;
  specialization: string;
  consultationHours: string;
  sessionStart: string;
  sessionEnd: string;
  mode: string;
};

type EditProfileFormProps = {
  form: DoctorProfileFormState;
  onChange: (key: keyof DoctorProfileFormState, value: string) => void;
  onChangePhoto: () => void;
  onUpdateChamberTime: () => void;
  onSave?: (setup: {
    consultationHours: string;
    sessionStart: string;
    sessionEnd: string;
    dailyCapacity: number;
  }) => void | Promise<void>;
};

const defaultAppointmentRules: AppointmentRules = {
  dailyCapacity: 12,
  blockedDates: [],
  dateLimits: {},
  dateSlots: {},
  weeklySlots: {
    5: [
      {
        label: "Friday Evening",
        start: "14:00",
        end: "23:59",
        intervalMinutes: 30,
        capacityPerSlot: 1,
      },
    ],
    6: [
      {
        label: "Saturday Morning",
        start: "08:00",
        end: "12:00",
        intervalMinutes: 20,
        capacityPerSlot: 1,
      },
    ],
  },
};

const dayOptions: Array<{ value: DayValue; short: string; name: string }> = [
  { value: 0, short: "Sun", name: "Sunday" },
  { value: 1, short: "Mon", name: "Monday" },
  { value: 2, short: "Tue", name: "Tuesday" },
  { value: 3, short: "Wed", name: "Wednesday" },
  { value: 4, short: "Thu", name: "Thursday" },
  { value: 5, short: "Fri", name: "Friday" },
  { value: 6, short: "Sat", name: "Saturday" },
];

const readJson = <T,>(key: string, fallback: T): T => {
  if (typeof window === "undefined") return fallback;

  try {
    const saved = window.localStorage.getItem(key);
    return saved ? (JSON.parse(saved) as T) : fallback;
  } catch {
    return fallback;
  }
};

const safeNumber = (value: unknown, fallback: number) => {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
};

const to12Hour = (time: string) => {
  if (!time) return "";

  const [hourValue, minuteValue] = String(time).split(":").map(Number);

  if (!Number.isFinite(hourValue) || !Number.isFinite(minuteValue)) {
    return time;
  }

  const suffix = hourValue >= 12 ? "PM" : "AM";
  const hour = hourValue % 12 || 12;

  return `${String(hour).padStart(2, "0")}:${String(minuteValue).padStart(
    2,
    "0"
  )} ${suffix}`;
};

const normalizeAppointmentRules = (
  rules: Partial<AppointmentRules> = defaultAppointmentRules
): AppointmentSetup => {
  const weeklyRows = dayOptions.map((day) => {
    const rawSlots = rules.weeklySlots?.[day.value];
    const slots: AppointmentSlot[] = Array.isArray(rawSlots) ? rawSlots : [];

    const firstSlot = slots[0];

    return {
      day: day.value,
      short: day.short,
      name: day.name,
      isOpen: Boolean(firstSlot),
      label: firstSlot?.label || `${day.name} Chamber`,
      start: firstSlot?.start || "09:00",
      end: firstSlot?.end || "17:00",
      intervalMinutes: safeNumber(firstSlot?.intervalMinutes, 30),
      capacityPerSlot: safeNumber(firstSlot?.capacityPerSlot, 1),
    };
  });

  return {
    dailyCapacity: safeNumber(
      rules.dailyCapacity,
      defaultAppointmentRules.dailyCapacity
    ),
    blockedDates: Array.isArray(rules.blockedDates) ? rules.blockedDates : [],
    dateLimits:
      rules.dateLimits && typeof rules.dateLimits === "object"
        ? rules.dateLimits
        : {},
    dateSlots:
      rules.dateSlots && typeof rules.dateSlots === "object"
        ? rules.dateSlots
        : {},
    weeklyRows,
  };
};

const readAppointmentSetup = (): AppointmentSetup => {
  const saved = readJson(APPOINTMENT_RULES_KEY, defaultAppointmentRules);

  return normalizeAppointmentRules({
    ...defaultAppointmentRules,
    ...saved,
    weeklySlots: saved.weeklySlots || defaultAppointmentRules.weeklySlots,
  });
};

const buildRulesForStorage = (setup: AppointmentSetup): AppointmentRules => {
  const weeklySlots = setup.weeklyRows.reduce<Partial<Record<DayValue, AppointmentSlot[]>>>((acc, row) => {
    acc[row.day] = row.isOpen
      ? [
          {
            label: row.label || `${row.name} Chamber`,
            start: row.start || "09:00",
            end: row.end || "17:00",
            intervalMinutes: Math.max(Number(row.intervalMinutes) || 30, 5),
            capacityPerSlot: Math.max(Number(row.capacityPerSlot) || 1, 1),
          },
        ]
      : [];

    return acc;
  }, {});

  return {
    dailyCapacity: Math.max(Number(setup.dailyCapacity) || 1, 1),
    blockedDates: setup.blockedDates || [],
    dateLimits: setup.dateLimits || {},
    dateSlots: setup.dateSlots || {},
    weeklySlots,
  };
};

const buildConsultationText = (setup: AppointmentSetup) => {
  const openRows = setup.weeklyRows.filter((row) => row.isOpen);

  if (!openRows.length) return "No chamber schedule set";

  return openRows
    .map((row) => `${row.name}: ${to12Hour(row.start)} - ${to12Hour(row.end)}`)
    .join(" | ");
};

const EditProfileForm = ({
  form,
  onChange,
  onChangePhoto,
  onUpdateChamberTime,
  onSave,
}: EditProfileFormProps) => {
  const navigate = useNavigate();

  const [appointmentSetup, setAppointmentSetup] = useState(readAppointmentSetup);
  const [blockedDateInput, setBlockedDateInput] = useState("");
  const [savedMessage, setSavedMessage] = useState("");

  const summary = useMemo(() => {
    const openRows = appointmentSetup.weeklyRows.filter((row) => row.isOpen);
    const firstOpen = openRows[0];

    return {
      openDays: openRows.length,
      dailyCapacity: appointmentSetup.dailyCapacity,
      blockedDates: appointmentSetup.blockedDates.length,
      firstStart: firstOpen?.start || "",
      firstEnd: firstOpen?.end || "",
      consultationText: buildConsultationText(appointmentSetup),
    };
  }, [appointmentSetup]);

  useEffect(() => {
    if (!savedMessage) return;

    const timeoutId = window.setTimeout(() => setSavedMessage(""), 1800);
    return () => window.clearTimeout(timeoutId);
  }, [savedMessage]);

  const labelClass = "grid gap-1 text-[11px] font-black text-slate-600";

  const fieldClass =
    "h-9 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-800 outline-none transition placeholder:text-slate-400 disabled:bg-slate-50 disabled:text-slate-400 focus:border-teal-400 focus:ring-2 focus:ring-teal-50";

  const smallButtonClass =
    "inline-flex h-9 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11px] font-black text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-cyan-200";

  const primaryButtonClass =
    "inline-flex h-9 items-center justify-center gap-1.5 rounded-xl bg-teal-700 px-4 text-[11px] font-black text-white shadow-lg shadow-teal-700/15 transition hover:-translate-y-0.5 hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-teal-200";

  const updateSetup = <Key extends keyof AppointmentSetup>(
    key: Key,
    value: AppointmentSetup[Key]
  ) => {
    setAppointmentSetup((prev) => ({ ...prev, [key]: value }));
  };

  const updateWeeklyRow = <Key extends keyof WeeklyRow>(
    day: DayValue,
    key: Key,
    value: WeeklyRow[Key]
  ) => {
    setAppointmentSetup((prev) => ({
      ...prev,
      weeklyRows: prev.weeklyRows.map((row) =>
        row.day === day ? { ...row, [key]: value } : row
      ),
    }));
  };

  const addBlockedDate = () => {
    if (!blockedDateInput) return;

    setAppointmentSetup((prev) => {
      if (prev.blockedDates.includes(blockedDateInput)) return prev;

      return {
        ...prev,
        blockedDates: [...prev.blockedDates, blockedDateInput].sort(),
      };
    });

    setBlockedDateInput("");
    setSavedMessage("Off date added.");
  };

  const removeBlockedDate = (date: string) => {
    setAppointmentSetup((prev) => ({
      ...prev,
      blockedDates: prev.blockedDates.filter((item) => item !== date),
    }));

    setSavedMessage("Off date removed.");
  };

  const saveAll = async () => {
    const rules = buildRulesForStorage(appointmentSetup);
    window.localStorage.setItem(APPOINTMENT_RULES_KEY, JSON.stringify(rules));

    const openRows = appointmentSetup.weeklyRows.filter((row) => row.isOpen);
    const firstOpen = openRows[0];

    if (firstOpen) {
      onChange("sessionStart", firstOpen.start);
      onChange("sessionEnd", firstOpen.end);
    }

    onChange("consultationHours", buildConsultationText(appointmentSetup));

    await onSave?.({
      consultationHours: buildConsultationText(appointmentSetup),
      sessionStart: firstOpen?.start || form.sessionStart,
      sessionEnd: firstOpen?.end || form.sessionEnd,
      dailyCapacity: appointmentSetup.dailyCapacity,
    });

    setSavedMessage("Profile and appointment setup saved.");
  };

  const resetAppointmentSetup = () => {
    const freshSetup = normalizeAppointmentRules(defaultAppointmentRules);

    setAppointmentSetup(freshSetup);

    window.localStorage.setItem(
      APPOINTMENT_RULES_KEY,
      JSON.stringify(defaultAppointmentRules)
    );

    onChange("sessionStart", "14:00");
    onChange("sessionEnd", "23:59");
    onChange("consultationHours", buildConsultationText(freshSetup));

    setSavedMessage("Default appointment setup restored.");
  };

  return (
    <GlassCard>
      <div className="grid gap-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.22em] text-teal-700">
              <Settings2 size={13} />
              Doctor Setup
            </p>

            <h3 className="mt-1 text-xl font-black tracking-tight text-slate-950">
              Edit Profile & Appointment Rules
            </h3>

            <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
              Update profile, chamber schedule, daily limit and off dates.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <SummaryBox title="Daily" value={summary.dailyCapacity} />
            <SummaryBox title="Open" value={summary.openDays} />
            <SummaryBox title="Off" value={summary.blockedDates} />
          </div>
        </div>

        {savedMessage ? (
          <div className="flex items-center gap-2 rounded-xl border border-emerald-100 bg-emerald-50 px-3 py-2 text-xs font-black text-emerald-700">
            <CheckCircle2 size={15} />
            {savedMessage}
          </div>
        ) : null}

        <section className="rounded-2xl border border-cyan-100 bg-white/80 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-sm font-black text-slate-950">
              Doctor Profile
            </h4>

            <div className="flex flex-wrap gap-2">
              <button type="button" className={smallButtonClass} onClick={onChangePhoto}>
                <Camera size={14} />
                Photo
              </button>

              <button
                type="button"
                className={smallButtonClass}
                onClick={onUpdateChamberTime}
              >
                <Clock3 size={14} />
                Chamber
              </button>

              <button
                type="button"
                className={smallButtonClass}
                onClick={() => navigate("/doctor/panel-settings")}
              >
                <MonitorCog size={14} />
                Setting
              </button>
            </div>
          </div>

          <div className="mt-3 grid gap-2 md:grid-cols-4">
            <label className={labelClass}>
              Full Name
              <input
                className={fieldClass}
                value={form.name || ""}
                onChange={(e) => onChange("name", e.target.value)}
                placeholder="Doctor name"
              />
            </label>

            <label className={labelClass}>
              Department
              <input
                className={fieldClass}
                value={form.department || ""}
                onChange={(e) => onChange("department", e.target.value)}
                placeholder="Department"
              />
            </label>

            <label className={labelClass}>
              Specialization
              <input
                className={fieldClass}
                value={form.specialization || ""}
                onChange={(e) => onChange("specialization", e.target.value)}
                placeholder="Specialization"
              />
            </label>

            <label className={labelClass}>
              Mode
              <select
                className={fieldClass}
                value={form.mode || "In-person"}
                onChange={(e) => onChange("mode", e.target.value)}
              >
                <option value="In-person">In-person</option>
                <option value="Hybrid">Hybrid</option>
                <option value="Online">Online</option>
              </select>
            </label>

            <label className={labelClass}>
              Session Start
              <input
                className={fieldClass}
                type="time"
                value={form.sessionStart || summary.firstStart}
                onChange={(e) => onChange("sessionStart", e.target.value)}
              />
            </label>

            <label className={labelClass}>
              Session End
              <input
                className={fieldClass}
                type="time"
                value={form.sessionEnd || summary.firstEnd}
                onChange={(e) => onChange("sessionEnd", e.target.value)}
              />
            </label>

            <label className={`${labelClass} md:col-span-2`}>
              Consultation Hours
              <input
                className={fieldClass}
                value={form.consultationHours || summary.consultationText}
                onChange={(e) => onChange("consultationHours", e.target.value)}
                placeholder="Friday 02:00 PM - 12:00 AM"
              />
            </label>
          </div>
        </section>

        <section className="rounded-2xl border border-cyan-100 bg-cyan-50/40 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-black text-slate-950">
                Appointment Setup
              </h4>
              <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                Public booking calendar follows this setup.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className={smallButtonClass}
                onClick={resetAppointmentSetup}
              >
                <RotateCcw size={14} />
                Reset
              </button>

              <button type="button" className={primaryButtonClass} onClick={saveAll}>
                <Save size={14} />
                Save Setup
              </button>
            </div>
          </div>

          <div className="mt-3 grid gap-2 lg:grid-cols-[180px_1fr]">
            <div className="grid gap-2">
              <label className={labelClass}>
                Daily Patient Limit
                <input
                  className={fieldClass}
                  type="number"
                  min="1"
                  value={appointmentSetup.dailyCapacity}
                  onChange={(e) =>
                    updateSetup(
                      "dailyCapacity",
                      Math.max(Number(e.target.value) || 1, 1)
                    )
                  }
                />
              </label>

              <InfoBox icon={Users} title="Per Day" value={`${appointmentSetup.dailyCapacity} patients`} />
              <InfoBox icon={Clock3} title="Open Days" value={`${summary.openDays} days/week`} />
            </div>

            <div className="overflow-x-auto rounded-2xl border border-cyan-100 bg-white">
              <table className="w-full min-w-[720px] border-collapse text-left text-xs">
                <thead>
                  <tr className="bg-cyan-50 text-[10px] uppercase tracking-wide text-slate-500">
                    <th className="px-3 py-2 font-black">Day</th>
                    <th className="px-3 py-2 font-black">Open</th>
                    <th className="px-3 py-2 font-black">Start</th>
                    <th className="px-3 py-2 font-black">End</th>
                    <th className="px-3 py-2 font-black">Gap</th>
                    <th className="px-3 py-2 font-black">Per Slot</th>
                    <th className="px-3 py-2 font-black">Label</th>
                  </tr>
                </thead>

                <tbody>
                  {appointmentSetup.weeklyRows.map((row) => (
                    <tr key={row.day} className="border-t border-cyan-50">
                      <td className="px-3 py-2">
                        <p className="font-black text-slate-950">{row.short}</p>
                        <p className="text-[10px] font-bold text-slate-400">
                          {row.isOpen
                            ? `${to12Hour(row.start)} - ${to12Hour(row.end)}`
                            : "Closed"}
                        </p>
                      </td>

                      <td className="px-3 py-2">
                        <button
                          type="button"
                          onClick={() =>
                            updateWeeklyRow(row.day, "isOpen", !row.isOpen)
                          }
                          className={[
                            "relative h-6 w-11 rounded-full transition duration-300",
                            row.isOpen ? "bg-teal-600" : "bg-slate-300",
                          ].join(" ")}
                          aria-label={`Toggle ${row.name}`}
                        >
                          <span
                            className={[
                              "absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all duration-300",
                              row.isOpen ? "left-6" : "left-1",
                            ].join(" ")}
                          />
                        </button>
                      </td>

                      <td className="px-3 py-2">
                        <input
                          className={fieldClass}
                          type="time"
                          value={row.start}
                          disabled={!row.isOpen}
                          onChange={(e) =>
                            updateWeeklyRow(row.day, "start", e.target.value)
                          }
                        />
                      </td>

                      <td className="px-3 py-2">
                        <input
                          className={fieldClass}
                          type="time"
                          value={row.end}
                          disabled={!row.isOpen}
                          onChange={(e) =>
                            updateWeeklyRow(row.day, "end", e.target.value)
                          }
                        />
                      </td>

                      <td className="px-3 py-2">
                        <select
                          className={fieldClass}
                          value={row.intervalMinutes}
                          disabled={!row.isOpen}
                          onChange={(e) =>
                            updateWeeklyRow(
                              row.day,
                              "intervalMinutes",
                              Number(e.target.value)
                            )
                          }
                        >
                          <option value={10}>10 min</option>
                          <option value={15}>15 min</option>
                          <option value={20}>20 min</option>
                          <option value={30}>30 min</option>
                          <option value={45}>45 min</option>
                          <option value={60}>60 min</option>
                        </select>
                      </td>

                      <td className="px-3 py-2">
                        <input
                          className={fieldClass}
                          type="number"
                          min="1"
                          value={row.capacityPerSlot}
                          disabled={!row.isOpen}
                          onChange={(e) =>
                            updateWeeklyRow(
                              row.day,
                              "capacityPerSlot",
                              Math.max(Number(e.target.value) || 1, 1)
                            )
                          }
                        />
                      </td>

                      <td className="px-3 py-2">
                        <input
                          className={fieldClass}
                          value={row.label}
                          disabled={!row.isOpen}
                          onChange={(e) =>
                            updateWeeklyRow(row.day, "label", e.target.value)
                          }
                          placeholder="Chamber label"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-3 rounded-2xl border border-cyan-100 bg-white p-3">
            <div className="grid gap-2 sm:grid-cols-[1fr_auto] sm:items-end">
              <label className={labelClass}>
                Special Off Date
                <input
                  className={fieldClass}
                  type="date"
                  value={blockedDateInput}
                  onChange={(e) => setBlockedDateInput(e.target.value)}
                />
              </label>

              <button type="button" className={smallButtonClass} onClick={addBlockedDate}>
                <Plus size={14} />
                Add Off
              </button>
            </div>

            {appointmentSetup.blockedDates.length ? (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {appointmentSetup.blockedDates.map((date) => (
                  <button
                    key={date}
                    type="button"
                    onClick={() => removeBlockedDate(date)}
                    className="inline-flex h-8 items-center gap-1.5 rounded-xl border border-red-100 bg-red-50 px-2.5 text-[11px] font-black text-red-600 transition hover:bg-red-100"
                  >
                    {date}
                    <Trash2 size={12} />
                  </button>
                ))}
              </div>
            ) : (
              <p className="mt-2 text-[11px] font-bold text-slate-400">
                No special off date selected.
              </p>
            )}
          </div>
        </section>
      </div>
    </GlassCard>
  );
};

type InfoBoxProps = {
  icon: LucideIcon;
  title: string;
  value: string | number;
};

const InfoBox = ({ icon: Icon, title, value }: InfoBoxProps) => {
  return (
    <div className="rounded-xl border border-cyan-100 bg-white p-2">
      <Icon size={15} className="text-teal-700" />
      <p className="mt-1 text-[10px] font-black uppercase text-slate-400">
        {title}
      </p>
      <p className="text-sm font-black text-slate-950">{value}</p>
    </div>
  );
};

type SummaryBoxProps = {
  title: string;
  value: string | number;
};

const SummaryBox = ({ title, value }: SummaryBoxProps) => {
  return (
    <div className="min-w-[72px] rounded-2xl border border-cyan-100 bg-cyan-50/70 px-3 py-2 text-center">
      <p className="text-[9px] font-black uppercase tracking-wide text-slate-400">
        {title}
      </p>
      <p className="text-lg font-black text-teal-700">{value}</p>
    </div>
  );
};

export default EditProfileForm;
