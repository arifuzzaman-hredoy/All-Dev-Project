import GlassCard from "../common/GlassCard";

const ProfileInfoSection = ({ title, rows }) => {
  return (
    <GlassCard>
      <h3 className="text-lg font-black text-slate-900">{title}</h3>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {rows.map((row) => (
          <div key={row.label} className="rounded-2xl border border-teal-100 bg-white/70 p-3">
            <span className="text-xs font-black uppercase tracking-wide text-slate-400">{row.label}</span>
            <p className="mt-1 text-sm font-bold text-slate-700">{row.value}</p>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export default ProfileInfoSection;
