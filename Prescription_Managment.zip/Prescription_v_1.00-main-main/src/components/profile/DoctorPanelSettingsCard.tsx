import { BellRing, Globe, MonitorCog, ShieldCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";
import GlassCard from "../common/GlassCard";
import IconButton from "../common/IconButton";

const DoctorPanelSettingsCard = () => {
  const navigate = useNavigate();

  return (
    <GlassCard>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h3 className="text-lg font-black text-slate-900">Doctor Panel Settings</h3>
          <p className="mt-1 text-sm font-semibold text-slate-500">Control notification, privacy, and panel behavior preferences.</p>
        </div>
        <IconButton
          icon={MonitorCog}
          label="Open Settings"
          onClick={() => navigate("/doctor/panel-settings")}
        />
      </div>

      <div className="mt-4 grid gap-3">
        <article className="flex gap-3 rounded-2xl border border-teal-100 bg-white/70 p-3">
          <ShieldCheck size={16} className="mt-1 text-teal-700" />
          <div>
            <strong className="font-black text-slate-900">Privacy Mode</strong>
            <p className="text-sm font-semibold text-slate-500">Mask patient details on shared screens</p>
          </div>
        </article>
        <article className="flex gap-3 rounded-2xl border border-teal-100 bg-white/70 p-3">
          <BellRing size={16} className="mt-1 text-teal-700" />
          <div>
            <strong className="font-black text-slate-900">Notification Rules</strong>
            <p className="text-sm font-semibold text-slate-500">Set urgent-only alerts during consultation</p>
          </div>
        </article>
        <article className="flex gap-3 rounded-2xl border border-teal-100 bg-white/70 p-3">
          <Globe size={16} className="mt-1 text-teal-700" />
          <div>
            <strong className="font-black text-slate-900">Language & Region</strong>
            <p className="text-sm font-semibold text-slate-500">Choose local format for date and time</p>
          </div>
        </article>
      </div>
    </GlassCard>
  );
};

export default DoctorPanelSettingsCard;
