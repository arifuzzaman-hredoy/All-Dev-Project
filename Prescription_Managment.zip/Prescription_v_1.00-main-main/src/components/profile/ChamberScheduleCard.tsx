import GlassCard from "../common/GlassCard";

const ChamberScheduleCard = ({ schedule }) => {
  return (
    <GlassCard>
      <h3 className="text-lg font-black text-slate-900">Chamber Schedule</h3>
      <div className="mt-4 grid gap-3">
        {schedule.map((slot) => (
          <article key={slot.day} className="rounded-2xl border border-teal-100 bg-white/70 p-3">
            <strong className="font-black text-teal-800">{slot.day}</strong>
            <p className="mt-1 text-sm font-semibold text-slate-500">{slot.hours}</p>
          </article>
        ))}
      </div>
    </GlassCard>
  );
};

export default ChamberScheduleCard;
