import { SlidersHorizontal } from "lucide-react";
import { useNavigate } from "react-router-dom";
import GlassCard from "../common/GlassCard";
import IconButton from "../common/IconButton";

const DoctorProfileCard = ({ doctor }) => {
  const navigate = useNavigate();

  return (
    <GlassCard className="grid gap-4 md:grid-cols-[120px_minmax(0,1fr)_auto] md:items-center">
      <img className="h-28 w-28 rounded-3xl object-cover ring-1 ring-teal-100" src={doctor.photo} alt={doctor.name} />
      <div className="min-w-0">
        <h2 className="break-words text-2xl font-black tracking-tight text-slate-900">{doctor.name}</h2>
        <p className="mt-1 break-words text-sm font-semibold text-slate-500">{doctor.specialization}</p>
        <small className="mt-1 block text-xs font-bold text-slate-400">
          {doctor.id} • {doctor.department}
        </small>
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="max-w-full break-words rounded-full bg-cyan-50 px-3 py-1 text-xs font-bold text-teal-700">{doctor.qualification}</span>
          <span className="max-w-full break-words rounded-full bg-cyan-50 px-3 py-1 text-xs font-bold text-teal-700">{doctor.chamber}</span>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 md:justify-end">
        <span className="inline-flex rounded-full bg-emerald-50 px-3 py-2 text-xs font-black text-emerald-700 ring-1 ring-emerald-100">Available</span>
        <IconButton
          icon={SlidersHorizontal}
          label="Panel Settings"
          variant="ghost"
          onClick={() => navigate("/doctor/panel-settings")}
        />
      </div>
    </GlassCard>
  );
};

export default DoctorProfileCard;
