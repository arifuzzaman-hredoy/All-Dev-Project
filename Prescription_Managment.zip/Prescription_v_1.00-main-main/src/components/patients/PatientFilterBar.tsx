const PatientFilterBar = ({ filters, active, onChange }) => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {filters.map((filter) => (
        <button
          type="button"
          key={filter}
          className={[
            "shrink-0 rounded-full px-4 py-2 text-xs font-black ring-1 transition focus:outline-none focus:ring-2 focus:ring-cyan-300",
            active === filter
              ? "bg-teal-700 text-white ring-teal-700"
              : "bg-white/80 text-slate-500 ring-teal-100 hover:bg-cyan-50 hover:text-teal-700",
          ].join(" ")}
          onClick={() => onChange(filter)}
        >
          {filter}
        </button>
      ))}
    </div>
  );
};

export default PatientFilterBar;
