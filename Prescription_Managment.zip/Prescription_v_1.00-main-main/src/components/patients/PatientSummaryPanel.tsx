import GlassCard from "../common/GlassCard";

const PatientSummaryPanel = ({
  total,
  waiting,
  inProgress,
  completed,
  forwarded,
}) => {
  return (
    <GlassCard className="grid grid-cols-2 gap-3 sm:grid-cols-5">
      {[
        ["Total", total],
        ["Waiting", waiting],
        ["In Progress", inProgress],
        ["Completed", completed],
        ["Forwarded", forwarded],
      ].map(([label, value]) => (
        <div key={label} className="rounded-2xl bg-white/70 p-3 text-center ring-1 ring-teal-100">
          <p className="text-xs font-bold text-slate-500">{label}</p>
          <h4 className="mt-1 text-2xl font-black text-slate-900">{value}</h4>
        </div>
      ))}
    </GlassCard>
  );
};

export default PatientSummaryPanel;
