import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Download,
  Eye,
  FilePenLine,
  PhoneCall,
  Printer,
  RefreshCcw,
  Search,
  X,
} from "lucide-react";
import { patients } from "../../data/mockData";

const ACTIVE_PATIENT_KEY = "active_prescription_patient";

const patientRecordDetails = {
  "P-1001": {
    phone: "+880 1711-100001",
    diagnosis: "Migraine",
    history:
      "Recurrent headache for 2 years. Triggered by stress and lack of sleep.",
    prescription:
      "Pain management, hydration, sleep routine, follow-up after 14 days.",
    lab: "No lab report",
    lastVisit: "13 Apr 2026",
  },
  "P-1002": {
    phone: "+880 1711-100002",
    diagnosis: "Hypertension",
    history:
      "Known high blood pressure patient. Regular BP monitoring required.",
    prescription:
      "Continue BP medicine, low salt diet, BP chart review after 7 days.",
    lab: "BP chart uploaded",
    lastVisit: "13 Apr 2026",
  },
  "P-1003": {
    phone: "+880 1711-100003",
    diagnosis: "Fever with chest discomfort",
    history:
      "Persistent fever for 5 days. Assistant marked vitals as unstable.",
    prescription: "CBC, CXR, oxygen monitoring, urgent doctor review.",
    lab: "CBC + CXR suggested",
    lastVisit: "13 Apr 2026",
  },
  "P-1004": {
    phone: "+880 1711-100004",
    diagnosis: "Gastritis",
    history: "Recurrent gastritis pain after irregular meals.",
    prescription:
      "Antacid, food routine, avoid spicy food, follow-up if pain continues.",
    lab: "No lab report",
    lastVisit: "13 Apr 2026",
  },
  "P-1005": {
    phone: "+880 1711-100005",
    diagnosis: "Post viral fatigue",
    history: "Weakness and fatigue after recent fever recovery.",
    prescription: "Rest, hydration, vitamin support, review after 7 days.",
    lab: "No lab report",
    lastVisit: "13 Apr 2026",
  },
  "P-1006": {
    phone: "+880 1711-100006",
    diagnosis: "Diabetes follow-up",
    history: "Type-2 diabetes routine review. Diet chart update requested.",
    prescription:
      "Fasting glucose review, diet chart, medicine adjustment if needed.",
    lab: "Glucose report pending",
    lastVisit: "13 Apr 2026",
  },
};

const statusClass = {
  Next: "bg-cyan-50 text-cyan-700 border-cyan-100",
  Waiting: "bg-emerald-50 text-emerald-700 border-emerald-100",
  Urgent: "bg-rose-50 text-rose-700 border-rose-100",
  "In Progress": "bg-sky-50 text-sky-700 border-sky-100",
  Skipped: "bg-orange-50 text-orange-700 border-orange-100",
  Completed: "bg-slate-100 text-slate-600 border-slate-200",
};

const escapeCsv = (value) => {
  const safeValue = String(value ?? "");
  return `"${safeValue.replaceAll('"', '""')}"`;
};

const escapeHtml = (value) => {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
};

const PatientRecords = () => {
  const navigate = useNavigate();

  const [searchValue, setSearchValue] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("All");

  const recordRows = useMemo(() => {
    return patients.map((patient) => {
      const details = patientRecordDetails[patient.id] || {};

      return {
        ...patient,
        phone: details.phone || "Not available",
        diagnosis: details.diagnosis || patient.complaint,
        history: details.history || "No patient history added yet.",
        prescription: details.prescription || "No prescription added yet.",
        lab: details.lab || "No lab report",
        lastVisit: details.lastVisit || "Not available",
      };
    });
  }, []);

  const statusFilters = useMemo(() => {
    return ["All", ...new Set(recordRows.map((patient) => patient.status))];
  }, [recordRows]);

  const filteredRecords = useMemo(() => {
    const query = searchValue.toLowerCase().trim();

    return recordRows.filter((patient) => {
      const matchesStatus =
        selectedStatus === "All" || patient.status === selectedStatus;

      const matchesSearch =
        !query ||
        patient.id.toLowerCase().includes(query) ||
        patient.phone.toLowerCase().includes(query) ||
        patient.name.toLowerCase().includes(query) ||
        patient.complaint.toLowerCase().includes(query) ||
        patient.status.toLowerCase().includes(query) ||
        patient.diagnosis.toLowerCase().includes(query) ||
        patient.serial.toLowerCase().includes(query);

      return matchesStatus && matchesSearch;
    });
  }, [recordRows, searchValue, selectedStatus]);

  const urgentCount = recordRows.filter(
    (patient) => patient.status === "Urgent" || patient.forwarded,
  ).length;

  const todayLabel = new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date());

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
      return;
    }

    navigate("/doctor/dashboard");
  };

  const handleReset = () => {
    setSearchValue("");
    setSelectedStatus("All");
  };

  const openPrescriptionForPatient = (patient) => {
    window.sessionStorage.setItem(ACTIVE_PATIENT_KEY, JSON.stringify(patient));
    navigate("/doctor/prescriptions", { state: { patient } });
  };

  const handleExportCsv = () => {
    const headers = [
      "No",
      "Serial",
      "Patient ID",
      "Phone",
      "Patient Name",
      "Age",
      "Problem",
      "Diagnosis",
      "History",
      "Prescription",
      "Lab / Report",
      "Status",
      "Visit Time",
      "Last Visit",
    ];

    const rows = filteredRecords.map((patient, index) => [
      index + 1,
      patient.serial,
      patient.id,
      patient.phone,
      patient.name,
      patient.age,
      patient.complaint,
      patient.diagnosis,
      patient.history,
      patient.prescription,
      patient.lab,
      patient.status,
      patient.timeSlot,
      patient.lastVisit,
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map(escapeCsv).join(","))
      .join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `patient-records-${new Date()
      .toISOString()
      .slice(0, 10)}.csv`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  };

  const handlePrintA4 = () => {
    const printRows =
      filteredRecords.length > 0
        ? filteredRecords
            .map(
              (patient, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td>${escapeHtml(patient.serial)}</td>
                  <td>
                    <b>${escapeHtml(patient.id)}</b><br />
                    <span>${escapeHtml(patient.phone)}</span>
                  </td>
                  <td>
                    <b>${escapeHtml(patient.name)}</b><br />
                    <span>Age ${escapeHtml(patient.age)}</span>
                  </td>
                  <td>${escapeHtml(patient.complaint)}</td>
                  <td>${escapeHtml(patient.diagnosis)}</td>
                  <td>${escapeHtml(patient.history)}</td>
                  <td>${escapeHtml(patient.prescription)}</td>
                  <td>${escapeHtml(patient.lab)}</td>
                  <td>${escapeHtml(patient.status)}</td>
                  <td>${escapeHtml(patient.timeSlot)}</td>
                  <td>${escapeHtml(patient.lastVisit)}</td>
                </tr>
              `,
            )
            .join("")
        : `<tr><td colspan="12" class="empty">No patient record found</td></tr>`;

    const printWindow = window.open("", "_blank", "width=1400,height=900");

    if (!printWindow) {
      alert("Popup blocked. Please allow popup for print.");
      return;
    }

    printWindow.document.open();
    printWindow.document.write(`
      <!doctype html>
      <html>
        <head>
          <title>Patient Records</title>
          <style>
            @page {
              size: A4 landscape;
              margin: 8mm;
            }

            * {
              box-sizing: border-box;
            }

            body {
              margin: 0;
              color: #111827;
              background: #ffffff;
              font-family: Arial, Helvetica, sans-serif;
            }

            .header {
              display: flex;
              align-items: flex-end;
              justify-content: space-between;
              gap: 16px;
              margin-bottom: 8px;
              padding-bottom: 7px;
              border-bottom: 2px solid #111827;
            }

            h1 {
              margin: 0;
              font-size: 18px;
              font-weight: 800;
            }

            p {
              margin: 3px 0 0;
              font-size: 10px;
              font-weight: 700;
              color: #4b5563;
            }

            .meta {
              display: grid;
              grid-template-columns: repeat(4, auto);
              gap: 10px;
              font-size: 10px;
              font-weight: 700;
              color: #374151;
              text-align: right;
            }

            .meta strong {
              color: #111827;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              table-layout: fixed;
            }

            th,
            td {
              border: 1px solid #9ca3af;
              padding: 4px;
              font-size: 8px;
              line-height: 1.25;
              vertical-align: top;
              word-break: break-word;
            }

            th {
              background: #f3f4f6;
              color: #111827;
              text-transform: uppercase;
              font-size: 7px;
              font-weight: 800;
              text-align: left;
            }

            td span {
              color: #6b7280;
              font-size: 7px;
              font-weight: 700;
            }

            th:nth-child(1), td:nth-child(1) { width: 4%; text-align: center; }
            th:nth-child(2), td:nth-child(2) { width: 6%; }
            th:nth-child(3), td:nth-child(3) { width: 12%; }
            th:nth-child(4), td:nth-child(4) { width: 12%; }
            th:nth-child(5), td:nth-child(5) { width: 12%; }
            th:nth-child(6), td:nth-child(6) { width: 10%; }
            th:nth-child(7), td:nth-child(7) { width: 14%; }
            th:nth-child(8), td:nth-child(8) { width: 14%; }
            th:nth-child(9), td:nth-child(9) { width: 8%; }
            th:nth-child(10), td:nth-child(10) { width: 6%; }
            th:nth-child(11), td:nth-child(11) { width: 6%; }
            th:nth-child(12), td:nth-child(12) { width: 6%; }

            .empty {
              padding: 18px;
              text-align: center;
              font-weight: 800;
              color: #6b7280;
            }

            .footer {
              display: flex;
              justify-content: space-between;
              margin-top: 14px;
              font-size: 10px;
              font-weight: 700;
            }

            @media print {
              body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
            }
          </style>
        </head>

        <body>
          <div class="header">
            <div>
              <h1>Patient Record Management</h1>
              <p>Daily Patient Diagnosis & Treatment Record</p>
            </div>

            <div class="meta">
              <div>Total: <strong>${recordRows.length}</strong></div>
              <div>Showing: <strong>${filteredRecords.length}</strong></div>
              <div>Urgent: <strong>${urgentCount}</strong></div>
              <div>Date: <strong>${todayLabel}</strong></div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Serial</th>
                <th>ID / Phone</th>
                <th>Patient</th>
                <th>Problem</th>
                <th>Diagnosis</th>
                <th>History</th>
                <th>Prescription</th>
                <th>Report</th>
                <th>Status</th>
                <th>Time</th>
                <th>Last Visit</th>
              </tr>
            </thead>
            <tbody>
              ${printRows}
            </tbody>
          </table>

          <div class="footer">
            <div>Doctor Signature: ____________________</div>
            <div>Checked By: ____________________</div>
          </div>

          <script>
            window.onload = function () {
              window.focus();
              window.print();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <section className="min-h-screen bg-[#f6fbfb] px-3 py-3 text-slate-800 sm:px-4">
      <div className="mx-auto grid max-w-[1420px] gap-3">
        <div className="rounded-3xl border border-cyan-100 bg-white px-4 py-3 shadow-sm">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={handleBack}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-cyan-100 bg-white text-teal-700 transition hover:bg-cyan-50"
                title="Go back"
              >
                <ArrowLeft size={17} />
              </button>

              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-teal-600">
                    Doctor Workspace
                  </p>
                  <span className="hidden text-slate-300 sm:inline">/</span>
                  <h1 className="text-lg font-black tracking-tight text-slate-950 sm:text-xl">
                    Patient Record Management
                  </h1>
                </div>

                <p className="mt-0.5 truncate text-xs font-semibold text-slate-500">
                  Compact clinical records with patient phone, diagnosis, report
                  and Rx action.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex flex-wrap items-center gap-1.5 text-xs font-black">
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-700">
                  Total {recordRows.length}
                </span>
                <span className="rounded-full bg-cyan-50 px-2.5 py-1 text-cyan-700">
                  Showing {filteredRecords.length}
                </span>
                <span className="rounded-full bg-rose-50 px-2.5 py-1 text-rose-700">
                  Urgent {urgentCount}
                </span>
                <span className="rounded-full bg-teal-50 px-2.5 py-1 text-teal-700">
                  {todayLabel}
                </span>
              </div>

              <button
                type="button"
                onClick={handlePrintA4}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-slate-900 px-3 text-xs font-black text-white transition hover:bg-slate-800"
              >
                <Printer size={15} />
                Print A4
              </button>

              <button
                type="button"
                onClick={handleExportCsv}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-teal-600 px-3 text-xs font-black text-white transition hover:bg-teal-700"
              >
                <Download size={15} />
                Export
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-600 transition hover:bg-slate-50"
              >
                <RefreshCcw size={14} />
                Reset
              </button>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-cyan-100 bg-white px-4 py-3 shadow-sm">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex min-w-0 flex-wrap items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-teal-600">
                Today&apos;s Sheet
              </span>
              <span className="hidden text-slate-300 sm:inline">/</span>
              <h2 className="truncate text-base font-black text-slate-950">
                Daily Patient Diagnosis & Treatment Record
              </h2>
            </div>

            <div className="flex flex-col gap-2 lg:flex-row lg:items-center">
              <div className="flex max-w-full gap-1.5 overflow-x-auto pb-1 lg:pb-0">
                {statusFilters.map((status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() => setSelectedStatus(status)}
                    className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-black transition ${
                      selectedStatus === status
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {status}
                  </button>
                ))}
              </div>

              <label className="flex h-9 w-full items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 lg:w-72">
                <Search size={15} className="shrink-0 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search name, ID, phone..."
                  value={searchValue}
                  onChange={(event) => setSearchValue(event.target.value)}
                  className="w-full bg-transparent text-xs font-bold text-slate-700 outline-none placeholder:text-slate-400"
                />

                {searchValue ? (
                  <button
                    type="button"
                    onClick={() => setSearchValue("")}
                    className="text-slate-400 transition hover:text-rose-600"
                    title="Clear search"
                  >
                    <X size={14} />
                  </button>
                ) : null}
              </label>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-cyan-100 bg-white shadow-sm">
          <div className="max-h-[calc(100vh-230px)] min-h-[420px] overflow-auto">
            <table className="min-w-[1220px] w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 z-20">
                <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
                  <th className="w-12 px-3 py-2 font-black">No</th>
                  <th className="w-20 px-3 py-2 font-black">Serial</th>
                  <th className="w-36 px-3 py-2 font-black">ID / Phone</th>
                  <th className="w-40 px-3 py-2 font-black">Patient</th>
                  <th className="w-44 px-3 py-2 font-black">Problem</th>
                  <th className="w-40 px-3 py-2 font-black">Diagnosis</th>
                  <th className="w-56 px-3 py-2 font-black">History</th>
                  <th className="w-56 px-3 py-2 font-black">Prescription</th>
                  <th className="w-32 px-3 py-2 font-black">Report</th>
                  <th className="w-28 px-3 py-2 font-black">Status</th>
                  <th className="w-28 px-3 py-2 font-black">Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredRecords.map((patient, index) => (
                  <tr
                    key={patient.id}
                    className="border-b border-slate-100 transition hover:bg-cyan-50/40"
                  >
                    <td className="px-3 py-2 align-top font-black text-slate-500">
                      {index + 1}
                    </td>

                    <td className="px-3 py-2 align-top">
                      <p className="font-black text-slate-900">
                        {patient.serial}
                      </p>
                      <p className="text-[10px] font-bold text-slate-400">
                        {patient.timeSlot}
                      </p>
                    </td>

                    <td className="px-3 py-2 align-top">
                      <p className="font-black text-teal-700">{patient.id}</p>
                      <a
                        href={`tel:${patient.phone}`}
                        className="mt-0.5 inline-flex items-center gap-1 text-[10px] font-bold text-slate-500 hover:text-teal-700"
                      >
                        <PhoneCall size={10} />
                        {patient.phone}
                      </a>
                    </td>

                    <td className="px-3 py-2 align-top">
                      <p className="font-black leading-4 text-slate-950">
                        {patient.name}
                      </p>
                      <p className="mt-0.5 text-[10px] font-bold text-slate-400">
                        Age {patient.age} · Last {patient.lastVisit}
                      </p>
                    </td>

                    <td className="px-3 py-2 align-top font-semibold leading-5 text-slate-600">
                      <p className="line-clamp-2">{patient.complaint}</p>
                    </td>

                    <td className="px-3 py-2 align-top font-bold leading-5 text-slate-800">
                      <p className="line-clamp-2">{patient.diagnosis}</p>
                    </td>

                    <td className="px-3 py-2 align-top font-semibold leading-5 text-slate-600">
                      <p className="line-clamp-2">{patient.history}</p>
                    </td>

                    <td className="px-3 py-2 align-top font-semibold leading-5 text-slate-600">
                      <p className="line-clamp-2">{patient.prescription}</p>
                    </td>

                    <td className="px-3 py-2 align-top font-semibold leading-5 text-slate-600">
                      <p className="line-clamp-2">{patient.lab}</p>
                    </td>

                    <td className="px-3 py-2 align-top">
                      <span
                        className={`inline-flex rounded-full border px-2 py-0.5 text-[10px] font-black ${
                          statusClass[patient.status] ||
                          "border-slate-200 bg-slate-100 text-slate-600"
                        }`}
                      >
                        {patient.status}
                      </span>
                    </td>

                    <td className="px-3 py-2 align-top">
                      <div className="flex gap-1.5">
                        <Link
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-900 hover:text-white"
                          to={`/doctor/patients/${patient.id}`}
                          title="View"
                        >
                          <Eye size={14} />
                        </Link>

                        <button
                          type="button"
                          className="grid h-8 w-8 place-items-center rounded-lg bg-teal-600 text-white transition hover:bg-teal-700"
                          onClick={() => openPrescriptionForPatient(patient)}
                          title="Prescription"
                        >
                          <FilePenLine size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {filteredRecords.length === 0 ? (
                  <tr>
                    <td
                      colSpan="11"
                      className="px-4 py-14 text-center text-sm font-black text-slate-400"
                    >
                      No patient record found.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PatientRecords;