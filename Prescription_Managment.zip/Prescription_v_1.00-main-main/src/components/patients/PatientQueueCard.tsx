import { Link, useNavigate } from "react-router-dom";
import { UploadCloud } from "lucide-react";
import GlassCard from "../common/GlassCard";
import PatientStatusBadge from "./PatientStatusBadge";

const PatientQueueCard = ({ patient }) => {
  const navigate = useNavigate();
  const openUpload = (event) => {
    event.preventDefault();
    event.stopPropagation();
    navigate("/doctor/prescriptions", {
      state: {
        patient: {
          id: patient.id,
          patientId: patient.id,
          name: patient.name,
          patientName: patient.name,
          serial: patient.serial,
          appointmentId: patient.serial,
          phone: patient.phone || "",
        },
      },
    });
  };

  return (
    <Link
      to="/doctor/prescriptions"
      state={{ patient }}
      className="block focus:outline-none focus:ring-2 focus:ring-cyan-300"
    >
      <GlassCard className="transition hover:-translate-y-0.5 hover:bg-cyan-50/70">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-black text-slate-900">{patient.name}</h3>
            <p className="mt-1 text-sm font-semibold text-slate-500">{patient.complaint}</p>
          </div>
          <PatientStatusBadge status={patient.status} />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-bold text-slate-500">
          <span>ID: {patient.id}</span>
          <span>Age: {patient.age}</span>
          <span>Serial: {patient.serial}</span>
          <span>Slot: {patient.timeSlot}</span>
        </div>

        {patient.forwarded ? (
          <div className="mt-4 rounded-full bg-amber-50 px-3 py-1.5 text-xs font-black text-amber-700 ring-1 ring-amber-100">Forwarded by assistant</div>
        ) : null}

        <button
          type="button"
          onClick={openUpload}
          className="mt-4 inline-flex min-h-9 items-center justify-center gap-2 rounded-xl border border-cyan-100 bg-white px-3 text-xs font-black text-teal-700 transition hover:bg-cyan-50"
        >
          <UploadCloud size={14} />
          Prescription
        </button>
      </GlassCard>
    </Link>
  );
};

export default PatientQueueCard;
