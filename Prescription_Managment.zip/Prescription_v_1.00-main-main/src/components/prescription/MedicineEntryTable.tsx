import { Plus } from "lucide-react";
import IconButton from "../common/IconButton";

const MedicineEntryTable = ({ medicines, onAddRow, onUpdate }) => {
  return (
    <section className="grid gap-3">
      <div className="flex justify-end">
        <IconButton
          icon={Plus}
          label="Add Medicine"
          onClick={onAddRow}
          variant="secondary"
        />
      </div>
      <div className="overflow-x-auto rounded-2xl border border-teal-100 bg-white/80">
        <div className="grid min-w-[720px] grid-cols-4 bg-teal-700 text-xs font-black uppercase tracking-wide text-white">
          <span className="px-3 py-2">Medicine</span>
          <span className="px-3 py-2">Dose</span>
          <span className="px-3 py-2">Frequency</span>
          <span className="px-3 py-2">Duration</span>
        </div>
        {medicines.map((medicine, index) => (
          <div className="grid min-w-[720px] grid-cols-4 border-t border-teal-100" key={`med-${index + 1}`}>
            <input
              className="border-r border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:bg-cyan-50"
              value={medicine.name}
              onChange={(e) => onUpdate(index, "name", e.target.value)}
              placeholder="Name"
            />
            <input
              className="border-r border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:bg-cyan-50"
              value={medicine.dose}
              onChange={(e) => onUpdate(index, "dose", e.target.value)}
              placeholder="Dose"
            />
            <input
              className="border-r border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:bg-cyan-50"
              value={medicine.frequency}
              onChange={(e) => onUpdate(index, "frequency", e.target.value)}
              placeholder="Frequency"
            />
            <input
              className="bg-white px-3 py-2 text-sm font-semibold outline-none focus:bg-cyan-50"
              value={medicine.duration}
              onChange={(e) => onUpdate(index, "duration", e.target.value)}
              placeholder="Duration"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default MedicineEntryTable;
