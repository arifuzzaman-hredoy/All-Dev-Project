import { Stethoscope } from "lucide-react";
import { useState } from "react";

const PrescriptionHeader = ({ details }) => {
  const [meta, setMeta] = useState({
    patientName: details.patientName,
    date: details.visitDate,
    age: String(details.age),
    gender: details.gender,
    weight: "",
    diagnosis: details.complaint,
  });

  const updateMeta = (key, value) => {
    setMeta((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-teal-100 bg-white">
      <div className="flex flex-col gap-4 border-b border-teal-100 bg-gradient-to-r from-white via-cyan-50 to-teal-50 p-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h2 className="text-xl font-black text-rose-700">{details.doctorNameBn || details.doctorName}</h2>
          <p className="mt-1 text-sm font-bold text-slate-600">
            {details.hospitalNameBn || details.department}
          </p>
          <p className="text-xs font-semibold text-slate-500">
            {details.doctorTitleBn || details.department}
          </p>
          <p className="text-xs font-semibold text-slate-500">{details.hospitalNameEn}</p>
          <p className="text-xs font-semibold text-slate-500">
            {details.doctorNameEn || details.doctorName}
          </p>
          <p className="text-xs font-semibold text-slate-500">
            {details.doctorTitleEn || details.department}
          </p>
          <p className="text-xs font-semibold text-slate-500">{details.designationEn || ""}</p>
        </div>
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white text-teal-700 shadow-sm">
          <Stethoscope size={24} />
        </span>
      </div>

      <div className="grid gap-2 border-b border-teal-100 bg-white p-4 text-sm font-bold text-slate-600 md:grid-cols-3">
        <label className="grid gap-1">
          Patient Name:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.patientName}
            onChange={(e) => updateMeta("patientName", e.target.value)}
          />
        </label>
        <label className="grid gap-1">
          Date:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.date}
            onChange={(e) => updateMeta("date", e.target.value)}
          />
        </label>
        <label className="grid gap-1">
          Age:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.age}
            onChange={(e) => updateMeta("age", e.target.value)}
          />
        </label>
        <label className="grid gap-1">
          Gender:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.gender}
            onChange={(e) => updateMeta("gender", e.target.value)}
          />
        </label>
        <label className="grid gap-1">
          Weight:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.weight}
            onChange={(e) => updateMeta("weight", e.target.value)}
            placeholder="kg"
          />
        </label>
        <label className="grid gap-1 md:col-span-2">
          Diagnosis:
          <input
            className="rounded-xl border border-teal-100 px-3 py-2 outline-none focus:ring-2 focus:ring-cyan-100"
            value={meta.diagnosis}
            onChange={(e) => updateMeta("diagnosis", e.target.value)}
          />
        </label>
      </div>

      {details.assistantNote ? (
        <blockquote className="m-4 rounded-2xl bg-amber-50 p-3 text-sm font-bold text-amber-800 ring-1 ring-amber-100">
          Assistant Note: {details.assistantNote}
        </blockquote>
      ) : null}
    </div>
  );
};

export default PrescriptionHeader;
