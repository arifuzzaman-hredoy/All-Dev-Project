import GlassCard from "../common/GlassCard";

const StatCard = ({ title, value, trend, icon: Icon }) => {
  return (
    <GlassCard>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-bold text-slate-500">{title}</p>
          <h3 className="mt-2 text-3xl font-black tracking-tight text-slate-900">{value}</h3>
        </div>
        {Icon ? <Icon size={18} className="text-teal-700" /> : null}
      </div>
      <small className="mt-3 block text-xs font-bold text-slate-500">{trend}</small>
    </GlassCard>
  );
};

export default StatCard;
