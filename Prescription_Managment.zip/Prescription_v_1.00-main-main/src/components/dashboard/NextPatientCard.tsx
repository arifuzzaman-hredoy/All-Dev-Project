import { Link } from "react-router-dom";
import GlassCard from "../common/GlassCard";
import StatusPill from "../common/StatusPill";

const NextPatientCard = ({ patient }) => {
  if (!patient) return null;

  return (
    <Link to={`/doctor/patients/${patient.id}`} className="block focus:outline-none focus:ring-2 focus:ring-cyan-300">
      <GlassCard>
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-lg font-black text-slate-900">Next Serial Patient</h3>
          <StatusPill status={patient.status} />
        </div>
        <h4 className="mt-4 text-2xl font-black tracking-tight text-slate-900">{patient.name}</h4>
        <p className="mt-1 text-sm font-semibold text-slate-500">{patient.complaint}</p>
        <div className="mt-4 grid grid-cols-3 gap-2 text-xs font-black text-slate-500">
          <span>{patient.id}</span>
          <span>Serial {patient.serial}</span>
          <span>{patient.timeSlot}</span>
        </div>
        <span className="mt-4 inline-flex text-sm font-black text-teal-700">Open clinical details</span>
      </GlassCard>
    </Link>
  );
};

export default NextPatientCard;
