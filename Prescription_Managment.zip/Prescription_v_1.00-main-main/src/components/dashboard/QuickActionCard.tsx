import { Link } from "react-router-dom";
import GlassCard from "../common/GlassCard";

const ACTIVE_PATIENT_KEY = "active_prescription_patient";

const QuickActionCard = ({ action }) => {
  const Icon = action.icon;

  return (
    <Link
      to={action.path}
      onClick={() => {
        if (action.path === "/doctor/prescriptions") {
          window.sessionStorage.removeItem(ACTIVE_PATIENT_KEY);
        }
      }}
      className="block focus:outline-none focus:ring-2 focus:ring-cyan-300"
    >
      <GlassCard className="flex min-h-24 items-center gap-3 transition hover:-translate-y-0.5 hover:bg-cyan-50/80">
        <Icon size={18} className="text-teal-700" />
        <strong className="font-black text-slate-900">{action.title}</strong>
      </GlassCard>
    </Link>
  );
};

export default QuickActionCard;
