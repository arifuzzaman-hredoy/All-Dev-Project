import { Link } from "react-router-dom";
import GlassCard from "../common/GlassCard";
import StatusPill from "../common/StatusPill";

const ForwardedCasesCard = ({ cases }) => {
  return (
    <GlassCard>
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-lg font-black text-slate-900">Assistant Forwarded Cases</h3>
        <Link to="/doctor/patients" className="text-sm font-black text-teal-700">
          View all
        </Link>
      </div>
      <div className="mt-4 grid gap-3">
        {cases.map((item) => (
          <Link
            key={item.id}
            to={`/doctor/patients/${item.patientId}`}
            className="block focus:outline-none focus:ring-2 focus:ring-cyan-300"
          >
            <article className="flex gap-3 rounded-2xl border border-teal-100 bg-white/70 p-4 transition hover:bg-cyan-50/60 sm:items-start sm:justify-between">
              <div>
                <h4 className="font-black text-slate-900">{item.name}</h4>
                <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">{item.summary}</p>
                <small className="mt-1 block text-xs font-semibold leading-5 text-slate-400">{item.assistantNote}</small>
              </div>
              <StatusPill
                status={item.priority === "Urgent" ? "Urgent" : "Forwarded"}
              />
            </article>
          </Link>
        ))}
      </div>
    </GlassCard>
  );
};

export default ForwardedCasesCard;
