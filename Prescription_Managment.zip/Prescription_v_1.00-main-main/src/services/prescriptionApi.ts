import { apiFetch } from "../lib/apiClient";
import type {
  PatientSearchResult,
  PrescriptionFilePayload,
  PrescriptionItem,
  PrescriptionUploadPayload,
} from "../types/prescription";

export const fileToPrescriptionPayload = (file: File): Promise<PrescriptionFilePayload> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      resolve({
        fileName: file.name,
        mimeType: file.type,
        dataUrl: String(reader.result || ""),
      });
    reader.onerror = () => reject(new Error("Could not read selected file."));
    reader.readAsDataURL(file);
  });

export const getPrescriptions = async (): Promise<PrescriptionItem[]> => {
  const response = await apiFetch("/api/doctor/prescriptions");
  return response.data || [];
};

export const uploadPrescription = async (payload: PrescriptionUploadPayload) => {
  const response = await apiFetch("/api/doctor/prescriptions/upload", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  return response.item as PrescriptionItem;
};

export const savePrescription = async (payload: Partial<PrescriptionUploadPayload>) => {
  const response = await apiFetch("/api/doctor/prescriptions/save", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  return response.item as PrescriptionItem;
};

export const publishPrescription = async (
  id: string,
  payload: Partial<PrescriptionUploadPayload> = {},
) => {
  const response = await apiFetch(`/api/doctor/prescriptions/${id}/upload`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
  return response.item as PrescriptionItem;
};

export const duplicateFollowUpPrescription = async (id: string) => {
  const response = await apiFetch(`/api/doctor/prescriptions/${id}/duplicate-follow-up`, {
    method: "POST",
  });
  return response.item as PrescriptionItem;
};

export const addPrescriptionAttachments = async (
  id: string,
  attachments: Array<{ file: PrescriptionFilePayload; title?: string; note?: string }>,
) => {
  return apiFetch(`/api/doctor/prescriptions/${id}/attachments`, {
    method: "POST",
    body: JSON.stringify({ attachments }),
  });
};

export const bulkUploadPrescriptions = async (rows: PrescriptionUploadPayload[]) => {
  return apiFetch("/api/doctor/prescriptions/bulk-upload", {
    method: "POST",
    body: JSON.stringify({ rows }),
  });
};

export const replacePrescriptionFile = async (
  id: string,
  payload: Partial<PrescriptionUploadPayload>,
) => {
  const response = await apiFetch(`/api/doctor/prescriptions/${id}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
  return response.item as PrescriptionItem;
};

export const deletePrescription = async (id: string) => {
  return apiFetch(`/api/doctor/prescriptions/${id}`, { method: "DELETE" });
};

export const searchPatients = async (query: string): Promise<PatientSearchResult[]> => {
  const response = await apiFetch(`/api/doctor/patients/search?q=${encodeURIComponent(query)}`);
  return response.data || [];
};

export const sendPrescriptionOtp = async (payload: { patientId: string; phone: string }) => {
  return apiFetch("/api/public/prescriptions/send-otp", {
    method: "POST",
    body: JSON.stringify(payload),
  });
};

export const verifyPrescriptionOtp = async (payload: {
  patientId: string;
  phone: string;
  otp: string;
}): Promise<PrescriptionItem[]> => {
  const response = await apiFetch("/api/public/prescriptions/verify-otp", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  return response.data || [];
};
