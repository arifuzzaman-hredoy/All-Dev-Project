import { apiFetch } from "../lib/apiClient";
import defaults from "../publicSite/data/publicDefaults";

const IDENTITY_EVENT = "doctor-identity-updated";

export const normalizeDoctorIdentity = (identity = {}) => {
  const fallback = defaults.profile || {};
  const doctorName = identity.doctorName || identity.name || fallback.doctorName || "Doctor Name";
  const doctorTitle = identity.doctorTitle || identity.title || fallback.title || "";
  const profilePhotoUrl =
    identity.profilePhotoUrl ||
    identity.profileImageUrl ||
    identity.photo ||
    fallback.profileImageUrl ||
    "";

  return {
    ...fallback,
    ...identity,
    doctorName,
    name: doctorName,
    doctorTitle,
    title: doctorTitle,
    designation: identity.designation || identity.department || doctorTitle,
    department: identity.department || identity.designation || doctorTitle,
    specialization: identity.specialization || fallback.specialization || "",
    qualification: identity.qualification || identity.specialization || fallback.specialization || "",
    professionalBio: identity.professionalBio || identity.longBio || fallback.longBio || "",
    longBio: identity.longBio || identity.professionalBio || fallback.longBio || "",
    shortIntro: identity.shortIntro || identity.shortBio || fallback.shortBio || "",
    shortBio: identity.shortBio || identity.shortIntro || fallback.shortBio || "",
    profilePhotoUrl,
    profileImageUrl: profilePhotoUrl,
    photo: profilePhotoUrl,
    clinicName:
      identity.clinicName ||
      identity.siteName ||
      identity.chamberName ||
      identity.brandName ||
      fallback.chamberName ||
      "",
    brandName: identity.brandName || fallback.brandName || "CareBridge",
    navbarSubtitle: identity.navbarSubtitle || doctorName,
    chamberName: identity.chamberName || identity.clinicName || fallback.chamberName || "",
    chamberAddress: identity.chamberAddress || fallback.chamberAddress || "",
    phone: identity.phone || fallback.phone || "",
    email: identity.email || fallback.email || "",
    consultationHours: identity.consultationHours || identity.visitingTime || fallback.visitingTime || "",
    visitingTime: identity.visitingTime || identity.consultationHours || fallback.visitingTime || "",
    scheduleText: identity.scheduleText || identity.visitingDays || fallback.visitingDays || "",
    visitingDays: identity.visitingDays || identity.scheduleText || fallback.visitingDays || "",
    ctaButtonText: identity.ctaButtonText || identity.ctaText || fallback.ctaText || "Book Appointment",
    ctaText: identity.ctaText || identity.ctaButtonText || fallback.ctaText || "Book Appointment",
    prescriptionHeaderTitle:
      identity.prescriptionHeaderTitle ||
      identity.clinicName ||
      identity.chamberName ||
      fallback.chamberName ||
      "",
    prescriptionFooterNote:
      identity.prescriptionFooterNote ||
      "This is a digital prescription / এটি একটি ডিজিটাল প্রেসক্রিপশন।",
  };
};

export const notifyDoctorIdentityUpdated = (identity) => {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(IDENTITY_EVENT, { detail: identity }));
  window.dispatchEvent(new CustomEvent("carebridge-storage-updated", { detail: { key: "profile" } }));
};

export const getDoctorIdentity = async () => {
  const response = await apiFetch("/api/doctor/identity");
  return normalizeDoctorIdentity(response.data || {});
};

export const updateDoctorIdentity = async (payload) => {
  const response = await apiFetch("/api/doctor/identity", {
    method: "PUT",
    body: JSON.stringify(payload),
  });
  const identity = normalizeDoctorIdentity(response.data || {});
  notifyDoctorIdentityUpdated(identity);
  return identity;
};

export const uploadDoctorIdentityPhoto = async ({ fileName, mimeType, dataUrl }) => {
  const response = await apiFetch("/api/doctor/identity/photo", {
    method: "POST",
    body: JSON.stringify({ fileName, mimeType, dataUrl }),
  });
  const identity = normalizeDoctorIdentity(response.identity || response.data || {});
  notifyDoctorIdentityUpdated(identity);
  return { url: response.url, identity };
};

export const getPublicDoctorIdentity = async () => {
  const response = await apiFetch("/api/public/doctor-identity");
  return normalizeDoctorIdentity(response.data || {});
};

export const doctorIdentityEventName = IDENTITY_EVENT;
