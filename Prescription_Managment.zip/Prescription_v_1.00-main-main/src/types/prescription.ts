export type PrescriptionFilePayload = {
  fileName: string;
  mimeType: string;
  dataUrl: string;
};

export type PrescriptionUploadPayload = {
  prescriptionDate: string;
  patientId: string;
  phone: string;
  patientName: string;
  appointmentId?: string;
  doctorName?: string;
  title: string;
  notes?: string;
  file?: PrescriptionFilePayload | null;
};

export type PrescriptionItem = {
  id: string;
  patientId: string;
  patientName: string;
  phone: string;
  appointmentId?: string;
  doctorName?: string;
  prescriptionDate: string;
  title: string;
  notes?: string;
  chiefComplaint?: string;
  diagnosis?: string;
  medicines?: Array<Record<string, string>>;
  advice?: unknown;
  templateData?: Record<string, unknown> | null;
  fileName: string;
  fileMimeType: string;
  fileSize: number;
  status: string;
  attachmentCount?: number;
  attachments?: Array<{
    id: string;
    originalName: string;
    fileName: string;
    fileUrl: string;
    fileMimeType: string;
    fileSize: number;
    title?: string;
    note?: string;
  }>;
  uploadedBy?: string;
  savedAt?: string;
  uploadedAt?: string;
  downloadUrl?: string;
};

export type PatientSearchResult = {
  patientId: string;
  patientName: string;
  phone: string;
  appointmentId: string;
};
