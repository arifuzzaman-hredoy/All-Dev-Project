import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalIpdPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="IPD" description="Inpatient department overview, ward allocation and patient status shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalIpdPage;
