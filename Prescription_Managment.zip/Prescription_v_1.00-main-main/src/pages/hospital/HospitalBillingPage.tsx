import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalBillingPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Billing" description="Hospital billing, deposits, package charges and due clearance shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalBillingPage;
