import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalBedsPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Beds" description="Ward, cabin, ICU and bed occupancy future shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalBedsPage;
