import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalOpdPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="OPD" description="Outpatient registration, doctor queue and billing shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalOpdPage;
