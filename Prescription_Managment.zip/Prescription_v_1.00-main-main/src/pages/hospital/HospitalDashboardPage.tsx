import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalDashboardPage = () => (
  <DemoWorkspacePage
    eyebrow="Hospital ERP"
    title="Hospital dashboard"
    description="Future-ready hospital shell for OPD, IPD, beds, emergency, billing and discharge."
    notice="Hospital/IPD is future-ready demo shell. No backend workflow is connected in this step."
    stats={[
      { label: "OPD today", value: "118", note: "Registered" },
      { label: "IPD admitted", value: "42", note: "Current" },
      { label: "Available beds", value: "18", note: "Across wards" },
      { label: "Emergency cases", value: "07", note: "Today" },
      { label: "Today billing", value: "$4.8k", note: "Mock collection" },
      { label: "Discharge pending", value: "05", note: "Needs clearance" },
    ]}
  />
);
export default HospitalDashboardPage;
