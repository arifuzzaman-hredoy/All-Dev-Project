import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalPharmacyPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Pharmacy" description="Future pharmacy sales, inventory and prescription fulfillment shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalPharmacyPage;
