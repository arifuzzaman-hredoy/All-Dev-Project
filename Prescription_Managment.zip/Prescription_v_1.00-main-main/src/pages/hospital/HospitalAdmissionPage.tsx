import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalAdmissionPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Admission" description="Admission request, patient details and bed assignment shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalAdmissionPage;
