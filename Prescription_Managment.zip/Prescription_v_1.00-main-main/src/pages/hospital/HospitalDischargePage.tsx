import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalDischargePage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Discharge" description="Discharge summary, pharmacy clearance and billing approval shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalDischargePage;
