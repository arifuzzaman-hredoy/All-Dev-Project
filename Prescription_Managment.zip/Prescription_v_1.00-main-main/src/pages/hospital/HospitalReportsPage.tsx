import DemoWorkspacePage from "../DemoWorkspacePage";
const HospitalReportsPage = () => <DemoWorkspacePage eyebrow="Hospital ERP" title="Reports" description="Hospital OPD, IPD, beds, billing and discharge reporting shell." notice="Hospital/IPD is future-ready demo shell" />;
export default HospitalReportsPage;
