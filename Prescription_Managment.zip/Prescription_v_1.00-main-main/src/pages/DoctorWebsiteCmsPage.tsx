import { useEffect, useMemo, useState } from "react";
import {
  BadgeInfo,
  CheckCircle2,
  Eye,
  Globe2,
  Image,
  ListChecks,
  MapPin,
  Navigation,
  Palette,
  RefreshCcw,
  Save,
  Search,
  Settings,
  Share2,
  UploadCloud,
  X,
} from "lucide-react";
import CmsSectionCard from "../components/cms/CmsSectionCard";
import CmsTextInput from "../components/cms/CmsTextInput";
import CmsTextarea from "../components/cms/CmsTextarea";
import {
  getPublicProfile,
  getPublicServices,
  loadPublicContent,
  savePublicContent,
  savePublicProfile,
  savePublicServices,
  uploadPublicFile,
} from "../publicSite/lib/publicStorage";
import {
  fetchThemeSettings,
  getThemeSettings,
  resetThemeSettings,
  themeSections,
  themeVariantOptions,
  updateThemeSettings,
} from "../publicSite/lib/themeSettings";

const defaultNavbarLinks = {
  home: "Home",
  about: "About",
  services: "Services",
  blogs: "Blogs",
  qa: "Q&A",
  gallery: "Gallery",
  contact: "Contact",
  prescription: "Prescription",
  appointment: "Book Appointment",
};

const defaultSeo = {
  siteTitle: "",
  metaTitle: "",
  metaDescription: "",
  metaKeywords: "",
  faviconUrl: "",
  logoUrl: "",
  ogImageUrl: "",
};

const defaultTheme = {
  primaryColor: "#00796b",
  accentColor: "#2563eb",
  backgroundColor: "#f8fafc",
  cardRadius: "24px",
  buttonRadius: "999px",
  headerStyle: "clean",
  layoutWidth: "wide",
  showTopBar: true,
  showSocialLinks: true,
  showEmergencyNotice: true,
};

const mergeProfileDefaults = (profile = {}) => ({
  ...profile,
  navbarLinks: {
    ...defaultNavbarLinks,
    ...(profile.navbarLinks || {}),
  },
  seo: {
    ...defaultSeo,
    ...(profile.seo || {}),
  },
  theme: {
    ...defaultTheme,
    ...(profile.theme || {}),
  },
  socialLinks: {
    facebook: "",
    twitter: "",
    instagram: "",
    linkedin: "",
    youtube: "",
    whatsapp: "",
    ...(profile.socialLinks || {}),
  },
});

const cmsTabs = [
  {
    key: "identity",
    label: "Identity",
    icon: Globe2,
    text: "Doctor & website info",
  },
  {
    key: "navbar",
    label: "Navbar",
    icon: Navigation,
    text: "Menu labels",
  },
  {
    key: "contact",
    label: "Contact",
    icon: MapPin,
    text: "Phone & chamber",
  },
  {
    key: "services",
    label: "Services",
    icon: ListChecks,
    text: "Public service cards",
  },
  {
    key: "media",
    label: "Media",
    icon: Image,
    text: "Upload images",
  },
  {
    key: "seo",
    label: "SEO",
    icon: Search,
    text: "Search metadata",
  },
  {
    key: "customize",
    label: "Customize",
    icon: Palette,
    text: "Theme & layout",
  },
  {
    key: "notes",
    label: "Notes",
    icon: BadgeInfo,
    text: "Footer & notices",
  },
];

const navbarFields = [
  ["home", "Home"],
  ["about", "About"],
  ["services", "Services"],
  ["blogs", "Blogs"],
  ["qa", "Q&A"],
  ["gallery", "Gallery"],
  ["contact", "Contact"],
  ["prescription", "Prescription"],
  ["appointment", "Appointment Button"],
];

const socialFields = [
  ["facebook", "Facebook"],
  ["twitter", "X / Twitter"],
  ["instagram", "Instagram"],
  ["linkedin", "LinkedIn"],
  ["youtube", "YouTube"],
  ["whatsapp", "WhatsApp"],
];

const imageFields = [
  {
    key: "logoUrl",
    group: "root",
    label: "Website Logo",
    hint: "Used in navbar and footer",
    recommended: "PNG / SVG / JPG",
  },
  {
    key: "faviconUrl",
    group: "seo",
    label: "Favicon",
    hint: "Browser tab icon",
    recommended: "PNG / ICO",
  },
  {
    key: "profileImageUrl",
    group: "root",
    label: "Doctor Profile Image",
    hint: "Used in about/profile sections",
    recommended: "Square JPG / PNG",
  },
  {
    key: "heroImageUrl",
    group: "root",
    label: "Hero Image",
    hint: "Homepage hero image",
    recommended: "Wide JPG / PNG",
  },
  {
    key: "ogImageUrl",
    group: "seo",
    label: "Social Share Image",
    hint: "Facebook/WhatsApp preview",
    recommended: "1200 x 630 image",
  },
];

const layoutOptions = [
  { value: "wide", label: "Wide Layout" },
  { value: "boxed", label: "Boxed Layout" },
  { value: "compact", label: "Compact Layout" },
];

const headerOptions = [
  { value: "clean", label: "Clean Header" },
  { value: "glass", label: "Glass Header" },
  { value: "solid", label: "Solid Header" },
];

const radiusOptions = [
  { value: "12px", label: "Small Radius" },
  { value: "18px", label: "Medium Radius" },
  { value: "24px", label: "Large Radius" },
  { value: "32px", label: "Extra Rounded" },
];

const buttonRadiusOptions = [
  { value: "10px", label: "Square Button" },
  { value: "16px", label: "Soft Button" },
  { value: "24px", label: "Rounded Button" },
  { value: "999px", label: "Pill Button" },
];

const themeRadiusOptions = [
  { value: "8px", label: "Small Radius" },
  { value: "12px", label: "Soft Radius" },
  { value: "16px", label: "Medium Radius" },
  { value: "24px", label: "Large Radius" },
  { value: "32px", label: "Extra Rounded" },
];

const spacingOptions = [
  { value: "24px", label: "Compact" },
  { value: "32px", label: "Comfortable" },
  { value: "40px", label: "Default" },
  { value: "56px", label: "Roomy" },
  { value: "72px", label: "Large" },
];

const fontOptions = [
  { value: "system", label: "System Sans" },
  { value: "serif", label: "Serif" },
  { value: "mono", label: "Classic Mono" },
];

const ColorInput = ({ label, value, onChange }) => (
  <label className="grid gap-1.5">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>
    <span className="flex h-10 overflow-hidden rounded-xl border border-slate-200 bg-white">
      <input
        type="color"
        value={value || "#000000"}
        onChange={(event) => onChange(event.target.value)}
        className="h-10 w-12 cursor-pointer border-0 bg-transparent p-1"
      />
      <input
        value={value || ""}
        onChange={(event) => onChange(event.target.value)}
        className="min-w-0 flex-1 px-3 text-sm font-bold text-slate-800 outline-none"
      />
    </span>
  </label>
);

const getImageValue = (profile, item) => {
  if (item.group === "seo") return profile.seo?.[item.key] || "";
  return profile[item.key] || "";
};

const PremiumIcon = ({
  icon: Icon,
  active = false,
  size = 18,
  className = "",
}) => (
  <Icon
    size={size}
    strokeWidth={2.35}
    className={[
      "shrink-0 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3",
      active ? "text-white" : "text-teal-700",
      className,
    ].join(" ")}
  />
);

const SmallSelect = ({ label, value, onChange, options }) => (
  <label className="grid gap-1.5">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>
    <select
      value={value || ""}
      onChange={(event) => onChange(event.target.value)}
      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
    >
      {options.map((item) => (
        <option key={item.value} value={item.value}>
          {item.label}
        </option>
      ))}
    </select>
  </label>
);

const ToggleRow = ({ label, text, checked, onChange }) => (
  <button
    type="button"
    onClick={() => onChange(!checked)}
    className={[
      "group flex items-center justify-between gap-3 rounded-2xl border p-3 text-left transition hover:-translate-y-0.5 hover:shadow-sm",
      checked
        ? "border-emerald-200 bg-emerald-50"
        : "border-slate-200 bg-white hover:bg-slate-50",
    ].join(" ")}
  >
    <span>
      <span className="block text-sm font-black text-slate-950">{label}</span>
      <span className="mt-0.5 block text-xs font-semibold text-slate-500">
        {text}
      </span>
    </span>

    <span
      className={[
        "inline-flex h-7 min-w-[58px] items-center justify-center rounded-full text-xs font-black transition-transform duration-300 group-hover:scale-105",
        checked ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-500",
      ].join(" ")}
    >
      {checked ? "ON" : "OFF"}
    </span>
  </button>
);

const SectionHead = ({ icon: Icon, title, text }) => (
  <div className="mb-4 flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
    <div className="group flex min-w-0 items-start gap-2.5">
      <PremiumIcon icon={Icon} size={18} />
      <div className="min-w-0">
        <h3 className="text-base font-black tracking-tight text-slate-950">
          {title}
        </h3>
        <p className="mt-0.5 text-xs font-semibold leading-5 text-slate-500">
          {text}
        </p>
      </div>
    </div>
  </div>
);

const ImageUploadCard = ({ item, value, onChange, onClear }) => {
  const [dragging, setDragging] = useState(false);

  const handleFile = async (file) => {
    if (!file) return;

    try {
      const uploaded = await uploadPublicFile(file);
      onChange(uploaded.url);
    } catch (error) {
      alert(error.message || "Image upload failed.");
    }
  };

  return (
    <div className="group overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-sm">
      <div className="flex items-start justify-between gap-3 border-b border-slate-100 p-3">
        <div className="flex items-start gap-2">
          <PremiumIcon icon={Image} size={17} />
          <div>
            <h4 className="text-sm font-black text-slate-950">{item.label}</h4>
            <p className="mt-0.5 text-xs font-semibold text-slate-500">
              {item.hint}
            </p>
          </div>
        </div>

        {value ? (
          <button
            type="button"
            onClick={onClear}
            className="group/clear text-red-600 transition hover:-translate-y-0.5 hover:text-red-700"
            title="Remove image"
          >
            <X
              size={18}
              strokeWidth={2.4}
              className="transition-transform group-hover/clear:rotate-90"
            />
          </button>
        ) : null}
      </div>

      <label
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          handleFile(event.dataTransfer.files?.[0]);
        }}
        className={[
          "m-3 grid cursor-pointer place-items-center rounded-2xl border border-dashed p-4 text-center transition",
          dragging
            ? "border-cyan-500 bg-cyan-50"
            : "border-slate-300 bg-slate-50 hover:border-cyan-400 hover:bg-cyan-50",
        ].join(" ")}
      >
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(event) => handleFile(event.target.files?.[0])}
        />

        {value ? (
          <img
            src={value}
            alt={item.label}
            className="h-28 max-w-full rounded-xl object-contain"
          />
        ) : (
          <span className="grid place-items-center gap-2">
            <UploadCloud
              size={34}
              strokeWidth={2.1}
              className="text-cyan-700 transition-transform duration-300 group-hover:-translate-y-1 group-hover:scale-105"
            />
            <span className="text-sm font-black text-slate-800">
              Click or drop image
            </span>
            <span className="text-xs font-semibold text-slate-500">
              {item.recommended}
            </span>
          </span>
        )}
      </label>

      <div className="border-t border-slate-100 p-3">
        <CmsTextInput
          label="Image URL / Uploaded data"
          value={value || ""}
          onChange={onChange}
        />
      </div>
    </div>
  );
};

const TabButton = ({ tab, active, onClick }) => {
  const Icon = tab.icon;

  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "group flex min-h-[58px] items-center gap-2.5 rounded-2xl border p-3 text-left transition hover:-translate-y-0.5 hover:shadow-sm",
        active
          ? "border-slate-950 bg-slate-950 text-white shadow-sm"
          : "border-slate-200 bg-white text-slate-600 hover:border-cyan-200 hover:bg-cyan-50 hover:text-cyan-800",
      ].join(" ")}
    >
      <PremiumIcon
        icon={Icon}
        active={active}
        size={18}
        className={active ? "text-white" : "text-teal-700"}
      />

      <span className="min-w-0">
        <span className="block truncate text-sm font-black">{tab.label}</span>
        <span
          className={[
            "mt-0.5 block truncate text-[11px] font-semibold",
            active ? "text-white/70" : "text-slate-400",
          ].join(" ")}
        >
          {tab.text}
        </span>
      </span>
    </button>
  );
};

const PreviewPanel = ({ profile }) => {
  const primary = profile.theme?.primaryColor || "#00796b";
  const accent = profile.theme?.accentColor || "#2563eb";
  const logo = profile.logoUrl || profile.seo?.logoUrl;
  const hero = profile.heroImageUrl || profile.profileImageUrl;

  return (
    <div className="sticky top-[92px] grid gap-3">
      <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="group mb-3 flex items-center gap-2">
          <PremiumIcon icon={Eye} size={17} />
          <p className="text-xs font-black uppercase tracking-wider text-slate-500">
            Live Preview
          </p>
        </div>

        <div
          className="overflow-hidden rounded-3xl border border-slate-200 bg-slate-50"
          style={{ borderRadius: profile.theme?.cardRadius || "24px" }}
        >
          <div
            className="flex items-center justify-between gap-2 px-4 py-3"
            style={{
              background:
                profile.theme?.headerStyle === "solid"
                  ? primary
                  : "rgba(255,255,255,0.85)",
              color:
                profile.theme?.headerStyle === "solid" ? "#ffffff" : "#0f172a",
            }}
          >
            <div className="flex min-w-0 items-center gap-2">
              {logo ? (
                <img
                  src={logo}
                  alt="Logo"
                  className="h-8 w-8 rounded-xl object-cover"
                />
              ) : (
                <Globe2
                  size={24}
                  strokeWidth={2.2}
                  style={{ color: primary }}
                  className="shrink-0"
                />
              )}

              <div className="min-w-0">
                <p className="truncate text-xs font-black">
                  {profile.siteName || profile.chamberName || "Clinic Website"}
                </p>
                <p className="truncate text-[10px] font-bold opacity-70">
                  {profile.navbarSubtitle || "Clinical workspace"}
                </p>
              </div>
            </div>

            <button
              type="button"
              className="h-7 rounded-full px-3 text-[10px] font-black text-white"
              style={{
                backgroundColor: accent,
                borderRadius: profile.theme?.buttonRadius || "999px",
              }}
            >
              {profile.ctaText || profile.navbarLinks?.appointment || "Book"}
            </button>
          </div>

          <div className="grid gap-3 p-4">
            <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
              <div>
                <p className="text-[11px] font-black uppercase tracking-wider text-cyan-700">
                  {profile.specialization || "Specialist Doctor"}
                </p>
                <h3 className="mt-1 text-lg font-black leading-6 text-slate-950">
                  {profile.doctorName || "Doctor Name"}
                </h3>
                <p className="mt-1 text-xs font-bold leading-5 text-slate-500">
                  {profile.shortBio ||
                    "Short doctor profile introduction will appear here."}
                </p>
              </div>

              <div className="grid h-28 place-items-center overflow-hidden rounded-2xl bg-white">
                {hero ? (
                  <img
                    src={hero}
                    alt="Hero preview"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <Image size={34} className="text-slate-300" />
                )}
              </div>
            </div>

            <div className="grid gap-2 rounded-2xl bg-white p-3">
              <p className="text-xs font-black text-slate-950">
                {profile.chamberName || "Chamber Name"}
              </p>
              <p className="text-[11px] font-bold text-slate-500">
                {profile.visitingDays || "Visiting days"} ·{" "}
                {profile.visitingTime || "Visiting time"}
              </p>
              <p className="text-[11px] font-bold text-slate-500">
                {profile.phone || "Phone number"}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="group rounded-3xl border border-cyan-100 bg-cyan-50 p-4">
        <div className="flex items-center gap-2">
          <PremiumIcon icon={BadgeInfo} size={17} />
          <p className="text-xs font-black uppercase tracking-wider text-cyan-700">
            Smart Tip
          </p>
        </div>
        <p className="mt-1 text-xs font-semibold leading-5 text-slate-600">
          Upload image under 2.5MB. Local CMS হলে image base64 হিসেবে save হবে।
          Production server হলে backend upload API best.
        </p>
      </div>
    </div>
  );
};

const DoctorWebsiteCmsPage = () => {
  const [profile, setProfile] = useState(() =>
    mergeProfileDefaults(getPublicProfile())
  );
  const [services, setServices] = useState(() => getPublicServices());
  const [themeSettings, setThemeSettings] = useState(getThemeSettings);
  const [activeTab, setActiveTab] = useState("identity");
  const [saved, setSaved] = useState(false);
  const [themeLoading, setThemeLoading] = useState(false);
  const [themeError, setThemeError] = useState("");

  const activeTabInfo = useMemo(
    () => cmsTabs.find((item) => item.key === activeTab) || cmsTabs[0],
    [activeTab]
  );

  const update = (key, value) => {
    setProfile((prev) => ({ ...prev, [key]: value }));
  };

  const updateNested = (group, key, value) => {
    setProfile((prev) => ({
      ...prev,
      [group]: {
        ...(prev[group] || {}),
        [key]: value,
      },
    }));
  };

  const updateThemeField = (key, value) => {
    setThemeSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const updateService = (id, key, value) => {
    setServices((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [key]: value } : item))
    );
  };

  const addService = () => {
    setServices((prev) => [
      {
        id: `service-${Date.now()}`,
        title: "New Service",
        description: "",
        category: "General",
        status: "active",
      },
      ...prev,
    ]);
  };

  const deleteService = (id) => {
    const confirmed = window.confirm("Delete this service?");
    if (!confirmed) return;
    setServices((prev) => prev.filter((item) => item.id !== id));
  };

  useEffect(() => {
    loadPublicContent("profile", getPublicProfile())
      .then((data) => {
        const merged = mergeProfileDefaults(data);
        savePublicProfile(merged);
        setProfile(merged);
      })
      .catch(() => null);

    loadPublicContent("services", getPublicServices())
      .then((data) => {
        const next = Array.isArray(data) ? data : getPublicServices();
        setServices(next);
        savePublicServices(next);
      })
      .catch(() => null);

    setThemeLoading(true);
    fetchThemeSettings()
      .then((settings) => {
        setThemeSettings(settings);
        setThemeError("");
      })
      .catch((error) => {
        setThemeError(error.message || "Theme API unavailable. Local defaults are loaded.");
      })
      .finally(() => setThemeLoading(false));
  }, []);

  const updateImage = (item, value) => {
    if (item.group === "seo") {
      updateNested("seo", item.key, value);

      if (item.key === "logoUrl") {
        update("logoUrl", value);
      }

      return;
    }

    update(item.key, value);

    if (item.key === "logoUrl") {
      updateNested("seo", "logoUrl", value);
    }
  };

  const save = async () => {
    const mergedProfile = mergeProfileDefaults(profile);
    savePublicProfile(mergedProfile);
    setProfile(mergedProfile);

    try {
      const savedProfile = await savePublicContent("profile", mergedProfile);
      const savedServices = await savePublicContent("services", services);
      const nextProfile = mergeProfileDefaults(savedProfile);
      const savedTheme = await updateThemeSettings(themeSettings);
      savePublicProfile(nextProfile);
      if (Array.isArray(savedServices)) {
        savePublicServices(savedServices);
        setServices(savedServices);
      }
      setProfile(nextProfile);
      setThemeSettings(savedTheme);
      setThemeError("");
    } catch (error) {
      setThemeError(error.message || "Theme settings could not be saved to backend.");
    } finally {
      setSaved(true);
      setTimeout(() => setSaved(false), 1800);
    }
  };

  const resetTheme = () => {
    const defaults = resetThemeSettings();
    setThemeSettings(defaults);
    setThemeError("");
  };

  const renderActiveSection = () => {
    if (activeTab === "identity") {
      return (
        <CmsSectionCard title="Website Identity">
          <SectionHead
            icon={Globe2}
            title="Basic Website Identity"
            text="Doctor branding, website title, short intro and profile content."
          />

          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <CmsTextInput
              label="Website / clinic name"
              value={profile.siteName || profile.chamberName || ""}
              onChange={(v) => update("siteName", v)}
            />
            <CmsTextInput
              label="Doctor name"
              value={profile.doctorName || ""}
              onChange={(v) => update("doctorName", v)}
            />
            <CmsTextInput
              label="Doctor title"
              value={profile.title || ""}
              onChange={(v) => update("title", v)}
            />
            <CmsTextInput
              label="Specialization"
              value={profile.specialization || ""}
              onChange={(v) => update("specialization", v)}
            />
            <CmsTextInput
              label="Navbar subtitle"
              value={profile.navbarSubtitle || ""}
              onChange={(v) => update("navbarSubtitle", v)}
            />
            <CmsTextInput
              label="CTA button text"
              value={profile.ctaText || ""}
              onChange={(v) => update("ctaText", v)}
            />
          </div>

          <div className="mt-3 grid gap-3 xl:grid-cols-2">
            <CmsTextarea
              label="Short homepage intro"
              value={profile.shortBio || ""}
              onChange={(v) => update("shortBio", v)}
              rows={4}
            />

            <CmsTextarea
              label="Long profile bio"
              value={profile.longBio || ""}
              onChange={(v) => update("longBio", v)}
              rows={4}
            />
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "navbar") {
      return (
        <CmsSectionCard title="Navbar Content">
          <SectionHead
            icon={Navigation}
            title="Navbar Menu Labels"
            text="Change only label text. Page content should stay in separate managers."
          />

          <div className="grid gap-3 md:grid-cols-3">
            {navbarFields.map(([key, label]) => (
              <CmsTextInput
                key={key}
                label={label}
                value={profile.navbarLinks?.[key] || ""}
                onChange={(v) => updateNested("navbarLinks", key, v)}
              />
            ))}
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "contact") {
      return (
        <CmsSectionCard title="Contact & Location">
          <SectionHead
            icon={MapPin}
            title="Chamber & Contact Information"
            text="Used in homepage, appointment, contact section and footer."
          />

          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <CmsTextInput
              label="Phone"
              value={profile.phone || ""}
              onChange={(v) => update("phone", v)}
            />
            <CmsTextInput
              label="Email"
              value={profile.email || ""}
              onChange={(v) => update("email", v)}
            />
            <CmsTextInput
              label="Chamber name"
              value={profile.chamberName || ""}
              onChange={(v) => update("chamberName", v)}
            />
            <CmsTextInput
              label="Room / department"
              value={profile.roomInfo || ""}
              onChange={(v) => update("roomInfo", v)}
            />
            <CmsTextInput
              label="Visiting days"
              value={profile.visitingDays || ""}
              onChange={(v) => update("visitingDays", v)}
            />
            <CmsTextInput
              label="Visiting time"
              value={profile.visitingTime || ""}
              onChange={(v) => update("visitingTime", v)}
            />
            <CmsTextInput
              label="Google map URL"
              value={profile.mapUrl || ""}
              onChange={(v) => update("mapUrl", v)}
            />
            <CmsTextInput
              label="Emergency notice"
              value={profile.emergencyNotice || ""}
              onChange={(v) => update("emergencyNotice", v)}
            />
          </div>

          <div className="mt-3">
            <CmsTextarea
              label="Full chamber address"
              value={profile.chamberAddress || ""}
              onChange={(v) => update("chamberAddress", v)}
              rows={3}
            />
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "services") {
      return (
        <CmsSectionCard title="Public Services">
          <SectionHead
            icon={ListChecks}
            title="Service Cards"
            text="Manage service items shown on the public website services section."
          />

          <div className="mb-4 flex justify-end">
            <button
              type="button"
              onClick={addService}
              className="inline-flex min-h-10 items-center justify-center rounded-xl bg-slate-950 px-4 text-sm font-black text-white transition hover:bg-slate-800"
            >
              Add Service
            </button>
          </div>

          <div className="grid gap-3">
            {services.length ? (
              services.map((service, index) => (
                <div
                  key={service.id}
                  className="rounded-2xl border border-slate-200 bg-white p-4"
                >
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <p className="text-xs font-black uppercase tracking-wider text-slate-500">
                      Service #{index + 1}
                    </p>
                    <button
                      type="button"
                      onClick={() => deleteService(service.id)}
                      className="text-xs font-black text-red-600"
                    >
                      Delete
                    </button>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <CmsTextInput
                      label="Title"
                      value={service.title || ""}
                      onChange={(v) => updateService(service.id, "title", v)}
                    />
                    <CmsTextInput
                      label="Category"
                      value={service.category || ""}
                      onChange={(v) => updateService(service.id, "category", v)}
                    />
                  </div>

                  <div className="mt-3">
                    <CmsTextarea
                      label="Description"
                      value={service.description || ""}
                      onChange={(v) => updateService(service.id, "description", v)}
                      rows={3}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-center text-sm font-bold text-slate-500">
                No services yet.
              </div>
            )}
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "media") {
      return (
        <CmsSectionCard title="Media Upload">
          <SectionHead
            icon={Image}
            title="Website Images & Upload"
            text="Upload image file or paste image URL. Upload is functional using browser FileReader."
          />

          <div className="grid gap-3 xl:grid-cols-2">
            {imageFields.map((item) => {
              const value = getImageValue(profile, item);

              return (
                <ImageUploadCard
                  key={`${item.group}-${item.key}`}
                  item={item}
                  value={value}
                  onChange={(v) => updateImage(item, v)}
                  onClear={() => updateImage(item, "")}
                />
              );
            })}
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "seo") {
      return (
        <CmsSectionCard title="SEO Settings">
          <SectionHead
            icon={Search}
            title="Search Engine Metadata"
            text="Used for browser title, Google search result and social media preview."
          />

          <div className="grid gap-3 md:grid-cols-2">
            <CmsTextInput
              label="Site title"
              value={profile.seo?.siteTitle || ""}
              onChange={(v) => updateNested("seo", "siteTitle", v)}
            />
            <CmsTextInput
              label="Meta title"
              value={profile.seo?.metaTitle || ""}
              onChange={(v) => updateNested("seo", "metaTitle", v)}
            />
          </div>

          <div className="mt-3 grid gap-3 xl:grid-cols-2">
            <CmsTextarea
              label="Meta description"
              value={profile.seo?.metaDescription || ""}
              onChange={(v) => updateNested("seo", "metaDescription", v)}
              rows={4}
            />
            <CmsTextarea
              label="Meta keywords"
              value={profile.seo?.metaKeywords || ""}
              onChange={(v) => updateNested("seo", "metaKeywords", v)}
              rows={4}
            />
          </div>
        </CmsSectionCard>
      );
    }

    if (activeTab === "customize") {
      return (
        <CmsSectionCard title="Customize Website">
          <SectionHead
            icon={Palette}
            title="Theme, Layout & Social"
            text="Website section design variants, colors and layout values saved to backend."
          />

          <div className="mb-4 grid gap-3 rounded-2xl border border-cyan-100 bg-cyan-50 p-4 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <p className="text-sm font-black text-slate-950">Theme Overview</p>
              <p className="mt-1 text-xs font-semibold leading-5 text-slate-600">
                Select 5 design variants per public section. Missing settings always fall back to Variant 1.
              </p>
              {themeError ? (
                <p className="mt-2 text-xs font-black text-rose-600">{themeError}</p>
              ) : null}
              {themeLoading ? (
                <p className="mt-2 text-xs font-black text-cyan-700">Loading theme settings...</p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={resetTheme}
              className="inline-flex min-h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-black text-slate-700 transition hover:bg-slate-50"
            >
              <RefreshCcw size={15} />
              Reset to Default
            </button>
          </div>

          <div className="mb-4 grid gap-3">
            <div className="group flex items-center gap-2">
              <PremiumIcon icon={Palette} size={17} />
              <p className="text-xs font-black uppercase tracking-[0.1em] text-slate-500">
                Section Design Selector
              </p>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {themeSections.map((section) => (
                <div
                  key={section.key}
                  className="rounded-2xl border border-slate-200 bg-white p-3"
                >
                  <SmallSelect
                    label={section.label}
                    value={themeSettings[section.key] || "variant-1"}
                    onChange={(v) => updateThemeField(section.key, v)}
                    options={themeVariantOptions}
                  />
                  <p className="mt-2 text-[11px] font-semibold leading-4 text-slate-500">
                    {
                      themeVariantOptions.find(
                        (item) => item.value === themeSettings[section.key]
                      )?.description
                    }
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-4 grid gap-3">
            <div className="group flex items-center gap-2">
              <PremiumIcon icon={Palette} size={17} />
              <p className="text-xs font-black uppercase tracking-[0.1em] text-slate-500">
                Color Customization
              </p>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              <ColorInput
                label="Primary color"
                value={themeSettings.primaryColor}
                onChange={(v) => updateThemeField("primaryColor", v)}
              />
              <ColorInput
                label="Secondary color"
                value={themeSettings.secondaryColor}
                onChange={(v) => updateThemeField("secondaryColor", v)}
              />
              <ColorInput
                label="Accent color"
                value={themeSettings.accentColor}
                onChange={(v) => updateThemeField("accentColor", v)}
              />
              <ColorInput
                label="Background color"
                value={themeSettings.backgroundColor}
                onChange={(v) => updateThemeField("backgroundColor", v)}
              />
              <ColorInput
                label="Text color"
                value={themeSettings.textColor}
                onChange={(v) => updateThemeField("textColor", v)}
              />
              <ColorInput
                label="Button color"
                value={themeSettings.buttonColor}
                onChange={(v) => updateThemeField("buttonColor", v)}
              />
              <ColorInput
                label="Button text color"
                value={themeSettings.buttonTextColor}
                onChange={(v) => updateThemeField("buttonTextColor", v)}
              />
              <SmallSelect
                label="Border radius"
                value={themeSettings.borderRadius || "24px"}
                onChange={(v) => updateThemeField("borderRadius", v)}
                options={themeRadiusOptions}
              />
              <SmallSelect
                label="Section spacing"
                value={themeSettings.sectionSpacing || "40px"}
                onChange={(v) => updateThemeField("sectionSpacing", v)}
                options={spacingOptions}
              />
              <SmallSelect
                label="Font style"
                value={themeSettings.fontStyle || "system"}
                onChange={(v) => updateThemeField("fontStyle", v)}
                options={fontOptions}
              />
            </div>
          </div>

          <div className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
            <div className="grid content-start gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <CmsTextInput
                  label="Primary color"
                  value={profile.theme?.primaryColor || ""}
                  onChange={(v) => updateNested("theme", "primaryColor", v)}
                />
                <CmsTextInput
                  label="Accent color"
                  value={profile.theme?.accentColor || ""}
                  onChange={(v) => updateNested("theme", "accentColor", v)}
                />
                <CmsTextInput
                  label="Background color"
                  value={profile.theme?.backgroundColor || ""}
                  onChange={(v) => updateNested("theme", "backgroundColor", v)}
                />
                <SmallSelect
                  label="Layout width"
                  value={profile.theme?.layoutWidth || "wide"}
                  onChange={(v) => updateNested("theme", "layoutWidth", v)}
                  options={layoutOptions}
                />
                <SmallSelect
                  label="Header style"
                  value={profile.theme?.headerStyle || "clean"}
                  onChange={(v) => updateNested("theme", "headerStyle", v)}
                  options={headerOptions}
                />
                <SmallSelect
                  label="Card radius"
                  value={profile.theme?.cardRadius || "24px"}
                  onChange={(v) => updateNested("theme", "cardRadius", v)}
                  options={radiusOptions}
                />
                <SmallSelect
                  label="Button radius"
                  value={profile.theme?.buttonRadius || "999px"}
                  onChange={(v) => updateNested("theme", "buttonRadius", v)}
                  options={buttonRadiusOptions}
                />
              </div>

              <div className="grid gap-2">
                <ToggleRow
                  label="Show top bar"
                  text="Show small contact bar on public website."
                  checked={Boolean(profile.theme?.showTopBar)}
                  onChange={(v) => updateNested("theme", "showTopBar", v)}
                />
                <ToggleRow
                  label="Show social links"
                  text="Show social icons in footer/contact area."
                  checked={Boolean(profile.theme?.showSocialLinks)}
                  onChange={(v) => updateNested("theme", "showSocialLinks", v)}
                />
                <ToggleRow
                  label="Show emergency notice"
                  text="Show emergency notice when available."
                  checked={Boolean(profile.theme?.showEmergencyNotice)}
                  onChange={(v) =>
                    updateNested("theme", "showEmergencyNotice", v)
                  }
                />
              </div>
            </div>

            <div>
              <div className="group mb-3 flex items-center gap-2">
                <PremiumIcon icon={Share2} size={17} />
                <p className="text-xs font-black uppercase tracking-[0.1em] text-slate-500">
                  Social Links
                </p>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                {socialFields.map(([key, label]) => (
                  <CmsTextInput
                    key={key}
                    label={label}
                    value={profile.socialLinks?.[key] || ""}
                    onChange={(v) => updateNested("socialLinks", key, v)}
                  />
                ))}
              </div>
            </div>
          </div>
        </CmsSectionCard>
      );
    }

    return (
      <CmsSectionCard title="Global Notes">
        <SectionHead
          icon={BadgeInfo}
          title="Public Notices & Footer Text"
          text="Keep these short. Blog, Q&A or gallery content should not be placed here."
        />

        <div className="grid gap-3 xl:grid-cols-2">
          <CmsTextarea
            label="Homepage notice"
            value={profile.homepageIntro || ""}
            onChange={(v) => update("homepageIntro", v)}
            rows={5}
          />
          <CmsTextarea
            label="Footer short text"
            value={profile.footerText || ""}
            onChange={(v) => update("footerText", v)}
            rows={5}
          />
        </div>

        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <CmsTextInput
            label="Footer credit"
            value={profile.footerCredit || ""}
            onChange={(v) => update("footerCredit", v)}
          />
          <CmsTextInput
            label="Footer credit link"
            value={profile.footerCreditLink || ""}
            onChange={(v) => update("footerCreditLink", v)}
          />
        </div>
      </CmsSectionCard>
    );
  };

  return (
    <section className="mx-auto grid max-w-7xl gap-3">
      <div className="sticky top-0 z-40 rounded-3xl border border-slate-200/70 bg-white/90 p-3 shadow-sm backdrop-blur">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="group flex min-w-0 items-center gap-3">
            <PremiumIcon icon={Settings} size={25} />
            <div className="min-w-0">
              <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-600">
                Doctor Website CMS
              </p>
              <h2 className="truncate text-2xl font-black tracking-tight text-slate-950">
                {activeTabInfo.label} Settings
              </h2>
              <p className="truncate text-sm font-semibold text-slate-500">
                Modern compact website settings with upload and live preview.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={save}
            className={[
              "group inline-flex h-11 items-center justify-center gap-2 rounded-2xl px-5 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5 active:scale-[0.98]",
              saved
                ? "bg-emerald-600 hover:bg-emerald-700"
                : "bg-slate-950 hover:bg-slate-800",
            ].join(" ")}
          >
            {saved ? (
              <CheckCircle2
                size={16}
                className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3"
              />
            ) : (
              <Save
                size={16}
                className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3"
              />
            )}
            {saved ? "Saved Successfully" : "Save Changes"}
          </button>
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
          {cmsTabs.map((tab) => (
            <TabButton
              key={tab.key}
              tab={tab}
              active={activeTab === tab.key}
              onClick={() => setActiveTab(tab.key)}
            />
          ))}
        </div>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1fr_360px]">
        <main className="min-w-0">{renderActiveSection()}</main>

        <aside className="hidden xl:block">
          <PreviewPanel profile={profile} />
        </aside>
      </div>

      <div className="grid rounded-3xl border border-slate-200 bg-white p-4 shadow-sm xl:hidden">
        <PreviewPanel profile={profile} />
      </div>
    </section>
  );
};

export default DoctorWebsiteCmsPage;
