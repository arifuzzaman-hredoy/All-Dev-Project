import TenantPublicSiteDemoPage from "../TenantPublicSiteDemoPage";

const SingleDoctorPublicDemoPage = () => <TenantPublicSiteDemoPage kind="single-doctor" />;

export default SingleDoctorPublicDemoPage;
