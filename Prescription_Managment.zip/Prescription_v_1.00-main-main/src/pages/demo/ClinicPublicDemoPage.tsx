import TenantPublicSiteDemoPage from "../TenantPublicSiteDemoPage";

const ClinicPublicDemoPage = () => <TenantPublicSiteDemoPage kind="clinic" />;

export default ClinicPublicDemoPage;
