import TenantPublicSiteDemoPage from "../TenantPublicSiteDemoPage";

const ProDoctorPublicDemoPage = () => <TenantPublicSiteDemoPage kind="pro-doctor" />;

export default ProDoctorPublicDemoPage;
