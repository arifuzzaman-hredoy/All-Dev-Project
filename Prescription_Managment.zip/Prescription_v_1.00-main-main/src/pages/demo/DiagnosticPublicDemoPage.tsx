import TenantPublicSiteDemoPage from "../TenantPublicSiteDemoPage";

const DiagnosticPublicDemoPage = () => <TenantPublicSiteDemoPage kind="diagnostic" />;

export default DiagnosticPublicDemoPage;
