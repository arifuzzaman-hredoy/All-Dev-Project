import TenantPublicSiteDemoPage from "../TenantPublicSiteDemoPage";

const HospitalPublicDemoPage = () => <TenantPublicSiteDemoPage kind="hospital" />;

export default HospitalPublicDemoPage;
