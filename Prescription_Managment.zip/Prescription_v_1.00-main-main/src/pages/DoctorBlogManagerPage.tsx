import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  CheckCircle2,
  FileText,
  ImagePlus,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";
import CmsEmptyState from "../components/cms/CmsEmptyState";
import CmsSectionCard from "../components/cms/CmsSectionCard";
import CmsTextInput from "../components/cms/CmsTextInput";
import CmsTextarea from "../components/cms/CmsTextarea";
import slugify from "../publicSite/lib/slugify";
import {
  getPublicBlogs,
  loadPublicContent,
  savePublicBlogs,
  savePublicContent,
  uploadPublicFile,
} from "../publicSite/lib/publicStorage";

const MAX_IMAGE_SIZE = 2.5 * 1024 * 1024;

const getTodayDate = () => new Date().toISOString().slice(0, 10);

const getBlankForm = () => ({
  title: "",
  category: "General",
  excerpt: "",
  content: "",
  coverImageUrl: "",
  publishDate: getTodayDate(),
  status: "published",
});

const categoryOptions = [
  "Neuro Care",
  "Spine",
  "Health Tips",
  "Patient Notes",
  "Medicine",
  "Lifestyle",
  "General",
];

const statusOptions = [
  { value: "published", label: "Published" },
  { value: "draft", label: "Draft" },
];

const inputClass =
  "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100";

const selectClass =
  "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100";

const iconClass =
  "shrink-0 text-teal-700 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3";

const readFileAsDataUrl = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Image read failed."));
    reader.readAsDataURL(file);
  });
};

const notifyPublicBlogsUpdated = (blogs) => {
  if (typeof window === "undefined") return;

  window.dispatchEvent(
    new CustomEvent("public-blogs-updated", {
      detail: blogs,
    })
  );

  window.dispatchEvent(
    new CustomEvent("public-content-updated", {
      detail: {
        key: "blogs",
        value: blogs,
      },
    })
  );
};

const normalizeBlog = (blog) => ({
  ...blog,
  id: blog.id || `blog-${Date.now()}`,
  title: blog.title || "",
  category: blog.category || "General",
  excerpt: blog.excerpt || "",
  content: blog.content || "",
  coverImageUrl: blog.coverImageUrl || "",
  publishDate: blog.publishDate || getTodayDate(),
  status: blog.status || "published",
  slug: blog.slug || slugify(blog.title || `blog-${Date.now()}`),
});

const SelectInput = ({ label, value, onChange, options }) => (
  <label className="grid gap-1.5">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>

    <select
      value={value || ""}
      onChange={(event) => onChange(event.target.value)}
      className={selectClass}
    >
      {options.map((item) =>
        typeof item === "string" ? (
          <option key={item} value={item}>
            {item}
          </option>
        ) : (
          <option key={item.value} value={item.value}>
            {item.label}
          </option>
        )
      )}
    </select>
  </label>
);

const CoverUpload = ({ value, onChange, onNotice }) => {
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file) => {
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      onNotice("Only image file allowed.");
      return;
    }

    if (file.size > MAX_IMAGE_SIZE) {
      onNotice("Image size must be under 2.5MB.");
      return;
    }

    try {
      setUploading(true);

      try {
        const uploaded = await uploadPublicFile(file);

        if (uploaded?.url) {
          onChange(uploaded.url);
          onNotice("Cover image uploaded successfully.");
          return;
        }
      } catch {
        // fallback below
      }

      const dataUrl = await readFileAsDataUrl(file);
      onChange(dataUrl);
      onNotice("Cover image added from device.");
    } catch (error) {
      onNotice(error.message || "Image upload failed.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3">
      <div className="group mb-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ImagePlus size={17} className={iconClass} />
          <p className="text-sm font-black text-slate-950">Cover Image</p>
        </div>

        {value ? (
          <button
            type="button"
            onClick={() => {
              onChange("");
              onNotice("Cover image removed.");
            }}
            className="text-red-600 transition hover:-translate-y-0.5 hover:text-red-700"
            title="Remove image"
          >
            <X size={18} />
          </button>
        ) : null}
      </div>

      <label
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          handleFile(event.dataTransfer.files?.[0]);
        }}
        className={[
          "grid cursor-pointer place-items-center rounded-2xl border border-dashed p-4 text-center transition",
          dragging
            ? "border-cyan-500 bg-cyan-50"
            : "border-slate-300 bg-slate-50 hover:border-cyan-400 hover:bg-cyan-50",
        ].join(" ")}
      >
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(event) => handleFile(event.target.files?.[0])}
        />

        {value ? (
          <img
            src={value}
            alt="Blog cover"
            className="h-40 w-full rounded-xl object-cover"
          />
        ) : (
          <span className="grid place-items-center gap-2">
            <UploadCloud
              size={34}
              className="text-cyan-700 transition-transform duration-300 hover:-translate-y-1"
            />
            <span className="text-sm font-black text-slate-800">
              {uploading ? "Uploading image..." : "Click or drop cover image"}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              JPG / PNG / WEBP, max 2.5MB
            </span>
          </span>
        )}
      </label>

      <div className="mt-3">
        <CmsTextInput
          label="Cover image URL / uploaded data"
          value={value || ""}
          onChange={(nextValue) => {
            onChange(nextValue);
            if (nextValue) onNotice("Cover image URL updated.");
          }}
        />
      </div>
    </div>
  );
};

const BlogPreviewCard = ({ blog, onEdit, onDelete }) => (
  <article className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-md">
    <div className="grid gap-3 sm:grid-cols-[150px_1fr]">
      <div className="h-36 bg-slate-100 sm:h-full">
        {blog.coverImageUrl ? (
          <img
            src={blog.coverImageUrl}
            alt={blog.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="grid h-full place-items-center text-slate-300">
            <ImagePlus size={34} />
          </div>
        )}
      </div>

      <div className="grid gap-2 p-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-cyan-50 px-3 py-1 text-[11px] font-black uppercase tracking-wider text-cyan-700">
            {blog.category || "General"}
          </span>

          <span
            className={[
              "rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wider",
              blog.status === "published"
                ? "bg-emerald-50 text-emerald-700"
                : "bg-amber-50 text-amber-700",
            ].join(" ")}
          >
            {blog.status || "draft"}
          </span>
        </div>

        <div>
          <h3 className="text-base font-black leading-6 text-slate-950">
            {blog.title}
          </h3>

          <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
            /blogs/{blog.slug}
          </p>

          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
            {blog.excerpt || "No excerpt added."}
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
          <div className="flex items-center gap-1.5 text-xs font-black text-slate-500">
            <CalendarDays size={14} />
            {blog.publishDate || "-"}
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-700 transition hover:bg-slate-50"
            >
              <Pencil size={14} />
              Edit
            </button>

            <button
              type="button"
              onClick={onDelete}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 text-xs font-black text-red-700 transition hover:bg-red-100"
            >
              <Trash2 size={14} />
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  </article>
);

const DoctorBlogManagerPage = () => {
  const [blogs, setBlogs] = useState(() =>
    getPublicBlogs().map((item) => normalizeBlog(item))
  );
  const [form, setForm] = useState(getBlankForm);
  const [editingId, setEditingId] = useState(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    let alive = true;

    loadPublicContent("blogs", getPublicBlogs())
      .then((data) => {
        if (!alive) return;

        const next = Array.isArray(data)
          ? data.map((item) => normalizeBlog(item))
          : [];

        setBlogs(next);
        savePublicBlogs(next);
        notifyPublicBlogsUpdated(next);
      })
      .catch(() => {
        setNotice("Remote content load failed. Local blogs are showing.");
      });

    const syncBlogs = () => {
      const latest = getPublicBlogs().map((item) => normalizeBlog(item));
      setBlogs(latest);
    };

    window.addEventListener("storage", syncBlogs);
    window.addEventListener("public-blogs-updated", syncBlogs);
    window.addEventListener("public-content-updated", syncBlogs);

    return () => {
      alive = false;
      window.removeEventListener("storage", syncBlogs);
      window.removeEventListener("public-blogs-updated", syncBlogs);
      window.removeEventListener("public-content-updated", syncBlogs);
    };
  }, []);

  useEffect(() => {
    if (!saved && !notice) return;

    const timeoutId = window.setTimeout(() => {
      setSaved(false);
      setNotice("");
    }, 2200);

    return () => window.clearTimeout(timeoutId);
  }, [saved, notice]);

  const filteredBlogs = useMemo(() => {
    const keyword = query.trim().toLowerCase();

    if (!keyword) return blogs;

    return blogs.filter((blog) =>
      [blog.title, blog.category, blog.status, blog.excerpt]
        .join(" ")
        .toLowerCase()
        .includes(keyword)
    );
  }, [blogs, query]);

  const stats = useMemo(() => {
    const published = blogs.filter((item) => item.status === "published").length;
    const draft = blogs.filter((item) => item.status !== "published").length;

    return {
      total: blogs.length,
      published,
      draft,
    };
  }, [blogs]);

  const showNotice = (message) => {
    setNotice(message);
  };

  const update = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const persist = async (next) => {
    const normalizedNext = next.map((item) => normalizeBlog(item));

    setBlogs(normalizedNext);
    savePublicBlogs(normalizedNext);
    notifyPublicBlogsUpdated(normalizedNext);

    try {
      const savedData = await savePublicContent("blogs", normalizedNext);
      const normalizedSaved = Array.isArray(savedData)
        ? savedData.map((item) => normalizeBlog(item))
        : normalizedNext;

      setBlogs(normalizedSaved);
      savePublicBlogs(normalizedSaved);
      notifyPublicBlogsUpdated(normalizedSaved);

      return normalizedSaved;
    } catch {
      return normalizedNext;
    }
  };

  const resetForm = () => {
    setForm(getBlankForm());
    setEditingId(null);
  };

  const save = async () => {
    const title = form.title.trim();

    if (!title) {
      showNotice("Blog title is required.");
      return;
    }

    const item = normalizeBlog({
      ...form,
      title,
      category: form.category || "General",
      publishDate: form.publishDate || getTodayDate(),
      status: form.status || "published",
      id: editingId || `blog-${Date.now()}`,
      slug: slugify(title),
    });

    const next = editingId
      ? blogs.map((blog) => (blog.id === editingId ? item : blog))
      : [item, ...blogs];

    try {
      setSaving(true);
      await persist(next);
      resetForm();
      setSaved(true);
      setNotice(
        editingId
          ? "Blog updated successfully."
          : "Blog uploaded successfully."
      );
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) {
      showNotice(error.message || "Blog could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  const editBlog = (blog) => {
    setEditingId(blog.id);
    setForm({
      ...getBlankForm(),
      ...blog,
      publishDate: blog.publishDate || getTodayDate(),
      status: blog.status || "published",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const deleteBlog = async (id) => {
    const confirmed = window.confirm("Delete this blog?");
    if (!confirmed) return;

    try {
      setSaving(true);
      await persist(blogs.filter((item) => item.id !== id));
      showNotice("Blog deleted successfully.");
      setSaved(true);
    } catch (error) {
      showNotice(error.message || "Blog could not be deleted.");
    } finally {
      setSaving(false);
    }

    if (editingId === id) {
      resetForm();
    }
  };

  return (
    <section className="mx-auto grid max-w-7xl gap-3">
      <div className="sticky top-0 z-40 rounded-3xl border border-slate-200/70 bg-white/90 p-3 shadow-sm backdrop-blur">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="group flex min-w-0 items-center gap-3">
            <FileText size={25} className={iconClass} />

            <div className="min-w-0">
              <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-600">
                Blog Manager
              </p>
              <h2 className="truncate text-2xl font-black tracking-tight text-slate-950">
                {editingId ? "Edit Blog Article" : "Create Blog Article"}
              </h2>
              <p className="truncate text-sm font-semibold text-slate-500">
                Upload cover image, write content and publish health articles.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {editingId ? (
              <button
                type="button"
                onClick={resetForm}
                className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-50"
              >
                <X size={16} />
                Cancel Edit
              </button>
            ) : null}

            <button
              type="button"
              onClick={save}
              disabled={saving}
              className={[
                "inline-flex h-11 items-center justify-center gap-2 rounded-2xl px-5 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-70",
                saved
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-slate-950 hover:bg-slate-800",
              ].join(" ")}
            >
              {saved ? <CheckCircle2 size={16} /> : <Save size={16} />}
              {saving
                ? "Saving..."
                : saved
                  ? "Saved"
                  : editingId
                    ? "Update Blog"
                    : "Add Blog"}
            </button>
          </div>
        </div>

        {notice ? (
          <div
            className={[
              "mt-3 flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-black",
              notice.toLowerCase().includes("failed") ||
              notice.toLowerCase().includes("required") ||
              notice.toLowerCase().includes("allowed")
                ? "border border-red-100 bg-red-50 text-red-700"
                : "border border-emerald-100 bg-emerald-50 text-emerald-700",
            ].join(" ")}
          >
            <CheckCircle2 size={16} />
            {notice}
          </div>
        ) : null}

        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <div className="rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-cyan-700">
              Total Blogs
            </p>
            <p className="mt-1 text-xl font-black text-slate-950">
              {stats.total}
            </p>
          </div>

          <div className="rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
              Published
            </p>
            <p className="mt-1 text-xl font-black text-emerald-700">
              {stats.published}
            </p>
          </div>

          <div className="rounded-2xl border border-amber-100 bg-amber-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-amber-700">
              Draft
            </p>
            <p className="mt-1 text-xl font-black text-amber-700">
              {stats.draft}
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-3 xl:grid-cols-[0.95fr_1.05fr]">
        <CmsSectionCard title="Blog Form">
          <div className="mb-4 flex items-center gap-2 border-b border-slate-100 pb-3">
            <Plus size={17} className={iconClass} />
            <div>
              <h3 className="text-base font-black text-slate-950">
                Article Information
              </h3>
              <p className="text-xs font-semibold text-slate-500">
                Save korlei public blog page realtime update hobe.
              </p>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <CmsTextInput
              label="Blog title"
              value={form.title}
              onChange={(v) => update("title", v)}
            />

            <SelectInput
              label="Category"
              value={form.category}
              onChange={(v) => update("category", v)}
              options={categoryOptions}
            />

            <label className="grid gap-1.5">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
                Publish date
              </span>
              <input
                type="date"
                value={form.publishDate || ""}
                onChange={(event) => update("publishDate", event.target.value)}
                className={inputClass}
              />
            </label>

            <SelectInput
              label="Status"
              value={form.status}
              onChange={(v) => update("status", v)}
              options={statusOptions}
            />
          </div>

          <div className="mt-3">
            <CoverUpload
              value={form.coverImageUrl}
              onChange={(v) => update("coverImageUrl", v)}
              onNotice={showNotice}
            />
          </div>

          <div className="mt-3 grid gap-3">
            <CmsTextarea
              label="Short excerpt"
              value={form.excerpt}
              onChange={(v) => update("excerpt", v)}
              rows={3}
            />

            <CmsTextarea
              label="Full blog content"
              value={form.content}
              onChange={(v) => update("content", v)}
              rows={8}
            />
          </div>

          <div className="mt-4 flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={resetForm}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 transition hover:bg-slate-50"
            >
              Clear
            </button>

            <button
              type="button"
              onClick={save}
              disabled={saving}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-slate-950 px-5 text-sm font-black text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70"
            >
              <Save size={15} />
              {saving ? "Saving..." : editingId ? "Update Blog" : "Save Blog"}
            </button>
          </div>
        </CmsSectionCard>

        <div className="grid content-start gap-3">
          <CmsSectionCard title="All Blogs">
            <div className="mb-4 flex flex-col gap-3 border-b border-slate-100 pb-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <Search size={17} className={iconClass} />
                <div>
                  <h3 className="text-base font-black text-slate-950">
                    Blog List
                  </h3>
                  <p className="text-xs font-semibold text-slate-500">
                    Edit, draft, publish or delete articles.
                  </p>
                </div>
              </div>

              <div className="relative w-full sm:max-w-xs">
                <Search
                  size={15}
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search blogs..."
                  className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
                />
              </div>
            </div>

            <div className="grid max-h-[780px] gap-3 overflow-y-auto pr-1">
              {filteredBlogs.length ? (
                filteredBlogs.map((blog) => (
                  <BlogPreviewCard
                    key={blog.id}
                    blog={blog}
                    onEdit={() => editBlog(blog)}
                    onDelete={() => deleteBlog(blog.id)}
                  />
                ))
              ) : (
                <CmsEmptyState
                  title="No blogs found"
                  message="Add the first article or change your search keyword."
                />
              )}
            </div>
          </CmsSectionCard>
        </div>
      </div>
    </section>
  );
};

export default DoctorBlogManagerPage;