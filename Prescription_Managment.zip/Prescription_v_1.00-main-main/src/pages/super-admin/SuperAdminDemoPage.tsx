import DemoSelectorPage from "../DemoSelectorPage";
const SuperAdminDemoPage = () => <DemoSelectorPage />;
export default SuperAdminDemoPage;
