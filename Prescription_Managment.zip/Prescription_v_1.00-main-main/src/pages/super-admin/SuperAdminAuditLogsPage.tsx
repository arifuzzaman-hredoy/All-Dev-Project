import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminAuditLogsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Audit logs" description="Administrative events, tenant changes and security activity logs." />;
export default SuperAdminAuditLogsPage;
