import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminSupportPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Support" description="Open tickets, tenant requests and support workload preview." />;
export default SuperAdminSupportPage;
