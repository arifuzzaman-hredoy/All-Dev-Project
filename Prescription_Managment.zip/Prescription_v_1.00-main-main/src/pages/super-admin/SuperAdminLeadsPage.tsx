import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminLeadsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Leads" description="Sales leads from book-demo, contact-sales and trial start flows." />;
export default SuperAdminLeadsPage;
