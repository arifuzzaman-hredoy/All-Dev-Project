import { Link } from "react-router-dom";
import DemoNotice from "../../components/common/DemoNotice";
import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import { mockTenants } from "../../lib/demoPackages";

const SuperAdminTenantsPage = () => (
  <main className="min-h-[calc(100svh-6rem)] rounded-[1.35rem] bg-[#f7f9fb] p-4 text-slate-900 sm:p-5">
    <div className="grid gap-4">
      <PageHeader eyebrow="Super admin" title="Tenants" description="Mock tenant registry with package, expiry, public demo URL, admin demo URL and actions." actions={<Link to="/super-admin/tenants/create" className="rounded-full bg-teal-700 px-4 py-2 text-[12px] font-black text-white">Create Tenant</Link>} />
      <DemoNotice />
      <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
        <div className="grid gap-2">
          {mockTenants.map((tenant) => (
            <div key={tenant.name} className="grid gap-3 rounded-2xl bg-slate-50 p-3 text-[12px] font-bold text-slate-600 lg:grid-cols-[1.2fr_0.9fr_90px_110px_1fr_1fr_120px] lg:items-center">
              <strong className="text-slate-950">{tenant.name}</strong>
              <span>{tenant.packageName}</span>
              <StatusBadge status={tenant.status} />
              <span>{tenant.expiry}</span>
              <Link to={tenant.publicUrl} className="truncate text-teal-700">{tenant.publicUrl}</Link>
              <Link to={tenant.adminUrl} className="truncate text-blue-700">{tenant.adminUrl}</Link>
              <button type="button" className="rounded-full bg-white px-3 py-1.5 text-[11px] font-black text-slate-700">Actions</button>
            </div>
          ))}
        </div>
      </article>
    </div>
  </main>
);

export default SuperAdminTenantsPage;
