import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminSettingsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Settings" description="Platform configuration, branding, notification and billing settings shell." />;
export default SuperAdminSettingsPage;
