import { Banknote, Building2, LifeBuoy, Package, ScrollText } from "lucide-react";
import ActionCard from "../../components/common/ActionCard";
import DemoNotice from "../../components/common/DemoNotice";
import PageHeader from "../../components/common/PageHeader";
import StatCard from "../../components/common/StatCard";

const stats = [
  { label: "Total Clients", value: "124", note: "Across packages" },
  { label: "Active Clients", value: "98", note: "Paid and live" },
  { label: "Trial Clients", value: "17", note: "In onboarding" },
  { label: "Expired Clients", value: "09", note: "Needs follow-up" },
  { label: "Monthly Revenue", value: "$18.4k", note: "Mock MRR" },
  { label: "Pending Payment", value: "$2.1k", note: "Invoices due" },
  { label: "SMS Usage", value: "48k", note: "This month" },
  { label: "Open Tickets", value: "12", note: "Support queue" },
];

const SuperAdminDashboardPage = () => (
  <main className="min-h-[calc(100svh-6rem)] rounded-[1.35rem] bg-[#f7f9fb] p-4 text-slate-900 sm:p-5">
    <div className="grid gap-4">
      <PageHeader eyebrow="Super admin" title="Platform dashboard" description="SaaS owner overview for tenants, subscriptions, payments, SMS usage and support workload." />
      <DemoNotice />
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((item, index) => (
          <StatCard key={item.label} {...item} icon={[Building2, Package, Banknote, LifeBuoy][index % 4]} />
        ))}
      </section>
      <section>
        <h2 className="mb-3 text-lg font-black text-slate-950">Quick Actions</h2>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          <ActionCard title="Create Tenant" description="Start a demo tenant" to="/super-admin/tenants/create" icon={Building2} />
          <ActionCard title="Manage Packages" description="Plans and limits" to="/super-admin/packages" icon={Package} />
          <ActionCard title="Manage Modules" description="Feature access" to="/super-admin/modules" icon={ScrollText} />
          <ActionCard title="View Demo Tenants" description="Open demo routes" to="/super-admin/demo" icon={LifeBuoy} />
          <ActionCard title="View Audit Logs" description="Platform events" to="/super-admin/audit-logs" icon={ScrollText} />
        </div>
      </section>
    </div>
  </main>
);

export default SuperAdminDashboardPage;
