import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminCommissionPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Commission" description="Partner commission, sales attribution and payout preview shell." />;
export default SuperAdminCommissionPage;
