import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminPaymentsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Payments" description="Preview SaaS payment collection, invoices and settlement records." />;
export default SuperAdminPaymentsPage;
