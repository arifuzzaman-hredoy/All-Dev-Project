import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminSmsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="SMS usage" description="Platform-wide SMS usage, wallet activity and tenant consumption demo shell." />;
export default SuperAdminSmsPage;
