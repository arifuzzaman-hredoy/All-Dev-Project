import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminTenantCreatePage = () => <DemoWorkspacePage eyebrow="Super admin" title="Create tenant" description="Frontend shell for tenant onboarding, package selection, demo slug and admin access setup." />;
export default SuperAdminTenantCreatePage;
