import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminPackagesPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Packages" description="Manage SaaS package tiers, module inclusion, trial limits and demo entry points." />;
export default SuperAdminPackagesPage;
