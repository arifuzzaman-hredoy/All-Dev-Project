import DemoNotice from "../../components/common/DemoNotice";
import ModuleCard from "../../components/common/ModuleCard";
import PageHeader from "../../components/common/PageHeader";
import { demoModules } from "../../lib/demoRoutes";

const SuperAdminModulesPage = () => (
  <main className="min-h-[calc(100svh-6rem)] rounded-[1.35rem] bg-[#f7f9fb] p-4 text-slate-900 sm:p-5">
    <div className="grid gap-4">
      <PageHeader eyebrow="Super admin" title="Modules" description="Visible module management UI with mock SaaS feature flags, package inclusion and action buttons." />
      <DemoNotice />
      <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {demoModules.map((module) => <ModuleCard key={module.moduleKey} {...module} />)}
      </section>
    </div>
  </main>
);

export default SuperAdminModulesPage;
