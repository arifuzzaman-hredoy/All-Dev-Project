import DemoWorkspacePage from "../DemoWorkspacePage";
const SuperAdminSubscriptionsPage = () => <DemoWorkspacePage eyebrow="Super admin" title="Subscriptions" description="Track active, trial, expired and suspended subscriptions using mock data." />;
export default SuperAdminSubscriptionsPage;
