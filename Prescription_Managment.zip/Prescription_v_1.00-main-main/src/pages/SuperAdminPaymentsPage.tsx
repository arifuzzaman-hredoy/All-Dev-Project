import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminPaymentsPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Payments"
    description="Review payment activity, invoices and settlement signals using frontend mock data."
  />
);

export default SuperAdminPaymentsPage;
