import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  ArrowUpRight,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  Clock3,
  FileText,
  Phone,
  RefreshCcw,
  Search,
  Stethoscope,
  TrendingUp,
  UsersRound,
} from "lucide-react";

const ACTIVE_PATIENT_KEY = "active_prescription_patient";
const FOLLOW_UP_STORAGE_KEY = "doctor_follow_ups";
const DASHBOARD_STORAGE_KEY = "doctor_dashboard_snapshot";

const safeReadList = (key) => {
  try {
    return JSON.parse(window.localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
};

const safeReadObject = (key, fallback) => {
  try {
    const saved = window.localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
};

const safeWriteObject = (key, value) => {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event("doctor-dashboard-updated"));
  } catch {
    // local fallback only
  }
};

const defaultDashboardSnapshot = {
  doctorTitle: "Clinical Desk",
  doctorSubtitle: "Patient queue, reports and prescriptions",
  chamberTime: "5:00 PM - 9:00 PM",
  avgPatients: 14,
  reportReviewCount: 2,
  weeklyVisits: [
    { day: "Sun", value: 8 },
    { day: "Mon", value: 12 },
    { day: "Tue", value: 10 },
    { day: "Wed", value: 15 },
    { day: "Thu", value: 13 },
    { day: "Fri", value: 7 },
    { day: "Sat", value: 5 },
  ],
  problemStats: [
    { label: "Fever", value: 32 },
    { label: "Diabetes", value: 24 },
    { label: "Pressure", value: 18 },
    { label: "Follow-up", value: 14 },
  ],
  appointments: [
    {
      serial: "01",
      name: "Nusrat Jahan",
      time: "09:30 AM",
      problem: "Fever and headache",
      status: "Waiting",
    },
    {
      serial: "02",
      name: "Rafiqul Islam",
      time: "10:00 AM",
      problem: "Blood pressure follow-up",
      status: "In progress",
    },
    {
      serial: "03",
      name: "Tamanna Akter",
      time: "10:30 AM",
      problem: "Diabetes checkup",
      status: "Scheduled",
    },
    {
      serial: "04",
      name: "Hasan Mahmud",
      time: "11:00 AM",
      problem: "Report review",
      status: "Scheduled",
    },
  ],
};

const getDashboardSnapshot = () => {
  const saved = safeReadObject(DASHBOARD_STORAGE_KEY, defaultDashboardSnapshot);

  return {
    ...defaultDashboardSnapshot,
    ...saved,
    weeklyVisits: Array.isArray(saved.weeklyVisits)
      ? saved.weeklyVisits
      : defaultDashboardSnapshot.weeklyVisits,
    problemStats: Array.isArray(saved.problemStats)
      ? saved.problemStats
      : defaultDashboardSnapshot.problemStats,
    appointments: Array.isArray(saved.appointments)
      ? saved.appointments
      : defaultDashboardSnapshot.appointments,
  };
};

const getGreetingInfo = (date = new Date()) => {
  const hour = date.getHours();

  if (hour >= 5 && hour < 12) {
    return {
      label: "Good morning",
      title: "Check today’s reports",
      note: "Morning queue and report review are ready.",
    };
  }

  if (hour >= 12 && hour < 17) {
    return {
      label: "Good afternoon",
      title: "Continue patient care",
      note: "Review waiting patients, prescriptions and follow-ups.",
    };
  }

  if (hour >= 17 && hour < 21) {
    return {
      label: "Good evening",
      title: "Chamber time is active",
      note: "Keep appointment flow, reports and prescriptions updated.",
    };
  }

  return {
    label: "Good night",
    title: "Review pending reports",
    note: "Check urgent follow-ups before closing the day.",
  };
};

const formatLiveTime = (date = new Date()) => {
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatLiveDate = (date = new Date()) => {
  return date.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const getStatusClass = (status) => {
  if (status === "Waiting") return "status waiting";
  if (status === "In progress") return "status active";
  return "status normal";
};

const LineChart = ({ data }) => {
  const safeData = data.length ? data : defaultDashboardSnapshot.weeklyVisits;

  const points = useMemo(() => {
    const max = Math.max(...safeData.map((item) => item.value), 1);

    return safeData
      .map((item, index) => {
        const x = 20 + index * 52;
        const y = 112 - (item.value / max) * 78;
        return `${x},${y}`;
      })
      .join(" ");
  }, [safeData]);

  return (
    <div className="chartBox">
      <svg viewBox="0 0 360 130" className="lineChart">
        <line x1="20" y1="112" x2="340" y2="112" />
        <line x1="20" y1="30" x2="20" y2="112" />
        <polyline points={points} />

        {safeData.map((item, index) => {
          const max = Math.max(...safeData.map((row) => row.value), 1);
          const x = 20 + index * 52;
          const y = 112 - (item.value / max) * 78;

          return (
            <g key={item.day}>
              <circle cx={x} cy={y} r="3.5" />
              <text x={x} y="127">
                {item.day}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

const MiniBarChart = ({ data }) => {
  const safeData = data.length ? data : defaultDashboardSnapshot.problemStats;
  const max = Math.max(...safeData.map((item) => item.value), 1);

  return (
    <div className="barList">
      {safeData.map((item) => (
        <div className="barItem" key={item.label}>
          <div className="barMeta">
            <span>{item.label}</span>
            <strong>{item.value}%</strong>
          </div>

          <div className="barTrack">
            <div
              className="barFill"
              style={{ width: `${(item.value / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

const DoctorDashboard = () => {
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState("");
  const [followUps, setFollowUps] = useState([]);
  const [snapshot, setSnapshot] = useState(getDashboardSnapshot);
  const [liveNow, setLiveNow] = useState(() => new Date());

  useEffect(() => {
    const loadFollowUps = () => {
      setFollowUps(safeReadList(FOLLOW_UP_STORAGE_KEY));
    };

    loadFollowUps();
    window.addEventListener("storage", loadFollowUps);
    window.addEventListener("doctor-follow-ups-updated", loadFollowUps);

    return () => {
      window.removeEventListener("storage", loadFollowUps);
      window.removeEventListener("doctor-follow-ups-updated", loadFollowUps);
    };
  }, []);

  useEffect(() => {
    const loadDashboard = () => {
      setSnapshot(getDashboardSnapshot());
    };

    loadDashboard();
    window.addEventListener("storage", loadDashboard);
    window.addEventListener("doctor-dashboard-updated", loadDashboard);

    return () => {
      window.removeEventListener("storage", loadDashboard);
      window.removeEventListener("doctor-dashboard-updated", loadDashboard);
    };
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setLiveNow(new Date());
    }, 15000);

    return () => window.clearInterval(timer);
  }, []);

  const pendingFollowUpCount = useMemo(() => {
    return followUps.filter((item) => item.status !== "Done").length;
  }, [followUps]);

  const greeting = useMemo(() => getGreetingInfo(liveNow), [liveNow]);

  const appointments = useMemo(
    () => snapshot.appointments || [],
    [snapshot.appointments],
  );

  const metrics = useMemo(() => {
    const waitingCount = appointments.filter(
      (item) => item.status === "Waiting",
    ).length;

    const completedCount = appointments.filter(
      (item) => item.status === "Completed" || item.status === "Done",
    ).length;

    return [
      {
        label: "Today appointments",
        value: String(appointments.length).padStart(2, "0"),
        note: "Live queue",
        icon: CalendarClock,
      },
      {
        label: "Waiting patients",
        value: String(waitingCount).padStart(2, "0"),
        note: "Now",
        icon: UsersRound,
      },
      {
        label: "Completed visits",
        value: String(completedCount).padStart(2, "0"),
        note: "Today",
        icon: CheckCircle2,
      },
      {
        label: "Follow-up due",
        value: String(pendingFollowUpCount).padStart(2, "0"),
        note: "This week",
        icon: ClipboardList,
      },
    ];
  }, [appointments, pendingFollowUpCount]);

  const filteredAppointments = useMemo(() => {
    const keyword = searchTerm.trim().toLowerCase();

    if (!keyword) return appointments;

    return appointments.filter((item) => {
      return (
        item.name.toLowerCase().includes(keyword) ||
        item.problem.toLowerCase().includes(keyword) ||
        item.status.toLowerCase().includes(keyword) ||
        item.time.toLowerCase().includes(keyword)
      );
    });
  }, [appointments, searchTerm]);

  const openPrescriptionForPatient = (patient = null) => {
    if (patient) {
      window.sessionStorage.setItem(
        ACTIVE_PATIENT_KEY,
        JSON.stringify(patient),
      );
      navigate("/doctor/prescriptions", { state: { patient } });
      return;
    }

    window.sessionStorage.removeItem(ACTIVE_PATIENT_KEY);
    navigate("/doctor/prescriptions");
  };

  const refreshDashboard = () => {
    const fresh = getDashboardSnapshot();
    safeWriteObject(DASHBOARD_STORAGE_KEY, fresh);
    setSnapshot(fresh);
    setLiveNow(new Date());
  };

  return (
    <main className="doctorDashboard">
      <style>{dashboardStyles}</style>

      <section className="dashboardHeader">
        <div className="headerText">
          <p className="eyebrow">{greeting.label} · {formatLiveTime(liveNow)}</p>
          <h1>{greeting.title}</h1>
          <p className="subText">
            {greeting.note} <span>{formatLiveDate(liveNow)}</span>
          </p>
        </div>

        <div className="headerActions">
          <label className="searchBox">
            <Search size={16} />
            <input
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search patient..."
            />
          </label>

          <button
            className="ghostBtn"
            type="button"
            onClick={refreshDashboard}
          >
            <RefreshCcw size={16} />
            Refresh
          </button>

          <button
            className="primaryBtn"
            type="button"
            onClick={() => openPrescriptionForPatient()}
          >
            <FileText size={16} />
            New prescription
          </button>
        </div>
      </section>

      <section className="metricGrid">
        {metrics.map((item) => {
          const Icon = item.icon;

          return (
            <article className="metricCard" key={item.label}>
              <Icon size={18} className="plainIcon metricPlainIcon" />
              <div className="metricText">
                <p>{item.label}</p>
                <div>
                  <h2>{item.value}</h2>
                  <span>{item.note}</span>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      <section className="dashboardGrid">
        <div className="leftColumn">
          <article className="panel chartPanel">
            <div className="panelHead compactHead">
              <div>
                <p className="eyebrow">Analytics</p>
                <h3>Weekly patient visits</h3>
              </div>

              <span className="softBadge">
                <ArrowUpRight size={13} />
                Realtime
              </span>
            </div>

            <LineChart data={snapshot.weeklyVisits || []} />
          </article>

          <article className="panel">
            <div className="panelHead compactHead">
              <div>
                <p className="eyebrow">Schedule</p>
                <h3>Today&apos;s appointments</h3>
              </div>

              <button
                className="tinyBtn"
                type="button"
                onClick={() => navigate("/doctor/appointments")}
              >
                View all
              </button>
            </div>

            <div className="appointmentList">
              {filteredAppointments.map((item) => (
                <div className="appointmentRow" key={item.serial}>
                  <div className="serial">{item.serial}</div>

                  <div className="appointmentInfo">
                    <h4>{item.name}</h4>
                    <p>{item.problem}</p>
                  </div>

                  <div className="timeBox">
                    <Clock3 size={13} />
                    {item.time}
                  </div>

                  <span className={getStatusClass(item.status)}>
                    {item.status}
                  </span>

                  <button
                    type="button"
                    className="rowAction"
                    onClick={() => openPrescriptionForPatient(item)}
                  >
                    Rx
                  </button>
                </div>
              ))}

              {!filteredAppointments.length ? (
                <div className="emptyState">No patient found.</div>
              ) : null}
            </div>
          </article>
        </div>

        <aside className="rightColumn">
          <article className="panel doctorCard">
            <div className="doctorTop">
              <Stethoscope size={24} className="plainIcon" />
              <div>
                <h3>{snapshot.doctorTitle || "Clinical Desk"}</h3>
                <p>{snapshot.doctorSubtitle || "Patient care workspace"}</p>
              </div>
            </div>

            <div className="doctorMeta">
              <span>
                <Activity size={14} className="plainIcon" />
                Avg. {snapshot.avgPatients || 0} patients/day
              </span>

              <span>
                <Phone size={14} className="plainIcon" />
                Chamber: {snapshot.chamberTime || "Not set"}
              </span>
            </div>
          </article>

          <article className="panel commonPanel">
            <div className="panelHead compactHead">
              <div>
                <p className="eyebrow">Patient type</p>
                <h3>Common cases</h3>
              </div>
            </div>

            <MiniBarChart data={snapshot.problemStats || []} />
          </article>

          <article className="panel lightPanel">
            <p className="eyebrow">Next action</p>
            <h3>Check report review</h3>
            <p>
              {snapshot.reportReviewCount || 0} reports need quick review before
              next prescription.
            </p>

            <button
              className="fullBtn"
              type="button"
              onClick={() => navigate("/doctor/prescriptions")}
            >
              <TrendingUp size={15} />
              Review reports
            </button>
          </article>
        </aside>
      </section>
    </main>
  );
};

const dashboardStyles = `
.doctorDashboard {
  min-height: 100vh;
  padding: 16px;
  background: #f7f9fb;
  color: #172033;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.dashboardHeader {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 12px;
}

.headerText {
  min-width: 0;
}

.eyebrow {
  margin: 0 0 4px;
  font-size: 10px;
  font-weight: 900;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #0f766e;
}

.dashboardHeader h1 {
  margin: 0;
  font-size: clamp(22px, 2.4vw, 30px);
  letter-spacing: -0.05em;
  color: #101828;
}

.subText {
  margin: 5px 0 0;
  color: #667085;
  font-size: 13px;
  font-weight: 650;
}

.subText span {
  color: #2563eb;
  font-weight: 900;
}

.headerActions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.searchBox {
  min-height: 38px;
  width: 230px;
  padding: 0 12px;
  border-radius: 13px;
  background: #ffffff;
  border: 1px solid #e5eaf1;
  color: #667085;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.searchBox svg {
  transition: 0.2s ease;
}

.searchBox:focus-within svg {
  color: #0f766e;
  transform: translateY(-1px) rotate(5deg);
}

.searchBox input {
  width: 100%;
  border: 0;
  outline: 0;
  background: transparent;
  color: #101828;
  font-size: 13px;
  font-weight: 700;
}

.primaryBtn,
.ghostBtn,
.tinyBtn,
.fullBtn {
  border: 0;
  border-radius: 13px;
  font-weight: 900;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  transition: 0.2s ease;
}

.primaryBtn svg,
.ghostBtn svg,
.tinyBtn svg,
.fullBtn svg,
.plainIcon {
  transition: 0.2s ease;
}

.primaryBtn:hover svg,
.ghostBtn:hover svg,
.tinyBtn:hover svg,
.fullBtn:hover svg,
.metricCard:hover .plainIcon,
.doctorTop:hover .plainIcon,
.doctorMeta span:hover .plainIcon {
  transform: translateY(-1px) rotate(6deg);
}

.primaryBtn {
  min-height: 38px;
  padding: 0 14px;
  background: #172033;
  color: #ffffff;
}

.ghostBtn {
  min-height: 38px;
  padding: 0 12px;
  background: #ffffff;
  color: #475467;
  border: 1px solid #e5eaf1;
}

.primaryBtn:hover,
.fullBtn:hover {
  transform: translateY(-1px);
  background: #0f172a;
}

.ghostBtn:hover,
.tinyBtn:hover {
  transform: translateY(-1px);
  background: #f8fafc;
}

.metricGrid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 10px;
}

.metricCard,
.panel {
  background: rgba(255, 255, 255, 0.96);
  border: 1px solid #e8edf3;
  border-radius: 18px;
  box-shadow: 0 12px 30px rgba(16, 24, 40, 0.035);
}

.metricCard {
  min-height: 66px;
  padding: 12px 13px;
  display: flex;
  align-items: center;
  gap: 10px;
  transition: 0.2s ease;
}

.metricCard:hover {
  transform: translateY(-1px);
  border-color: #bae6fd;
}

.metricPlainIcon {
  flex: 0 0 auto;
  color: #2563eb;
}

.metricText {
  min-width: 0;
  flex: 1;
}

.metricText p {
  margin: 0;
  font-size: 11px;
  color: #667085;
  font-weight: 850;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.metricText div {
  margin-top: 4px;
  display: flex;
  align-items: baseline;
  gap: 7px;
}

.metricText h2 {
  margin: 0;
  font-size: 23px;
  line-height: 1;
  letter-spacing: -0.05em;
  color: #101828;
}

.metricText span {
  font-size: 11px;
  color: #98a2b3;
  font-weight: 850;
  white-space: nowrap;
}

.dashboardGrid {
  display: grid;
  grid-template-columns: minmax(0, 1.7fr) minmax(270px, 0.72fr);
  gap: 10px;
}

.leftColumn,
.rightColumn {
  display: grid;
  gap: 10px;
}

.panel {
  padding: 14px;
}

.chartPanel {
  padding-bottom: 8px;
}

.panelHead {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.compactHead {
  margin-bottom: 10px;
}

.panel h3 {
  margin: 0;
  font-size: 15px;
  letter-spacing: -0.02em;
  color: #101828;
}

.softBadge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border-radius: 999px;
  padding: 5px 8px;
  background: #ecfdf3;
  color: #067647;
  font-size: 11px;
  font-weight: 900;
}

.tinyBtn {
  min-height: 30px;
  padding: 0 10px;
  background: #f3f6fa;
  color: #344054;
  font-size: 12px;
}

.chartBox {
  width: 100%;
  overflow: hidden;
}

.lineChart {
  width: 100%;
  height: 140px;
}

.lineChart line {
  stroke: #e5eaf1;
  stroke-width: 2;
}

.lineChart polyline {
  fill: none;
  stroke: #2563eb;
  stroke-width: 4;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.lineChart circle {
  fill: #ffffff;
  stroke: #2563eb;
  stroke-width: 3;
}

.lineChart text {
  font-size: 10px;
  font-weight: 850;
  fill: #98a2b3;
  text-anchor: middle;
}

.appointmentList {
  display: grid;
  gap: 7px;
}

.appointmentRow {
  display: grid;
  grid-template-columns: 34px minmax(0, 1fr) 92px 92px 42px;
  align-items: center;
  gap: 8px;
  padding: 8px 9px;
  border: 1px solid #edf1f6;
  border-radius: 14px;
  background: #ffffff;
  transition: 0.2s ease;
}

.appointmentRow:hover {
  transform: translateY(-1px);
  border-color: #bae6fd;
  background: #f8fdff;
}

.serial {
  width: 30px;
  height: 30px;
  border-radius: 11px;
  background: #f3f6fa;
  display: grid;
  place-items: center;
  font-size: 12px;
  font-weight: 950;
  color: #475467;
}

.appointmentInfo {
  min-width: 0;
}

.appointmentInfo h4 {
  margin: 0;
  font-size: 13px;
  color: #101828;
}

.appointmentInfo p {
  margin: 3px 0 0;
  color: #667085;
  font-size: 11px;
  font-weight: 700;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.timeBox {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: #667085;
  font-size: 11px;
  font-weight: 850;
}

.timeBox svg {
  transition: 0.2s ease;
}

.appointmentRow:hover .timeBox svg {
  transform: translateY(-1px) rotate(6deg);
  color: #2563eb;
}

.status {
  border-radius: 999px;
  padding: 5px 8px;
  font-size: 10px;
  font-weight: 950;
  text-align: center;
}

.status.waiting {
  background: #fff7ed;
  color: #c2410c;
}

.status.active {
  background: #eff6ff;
  color: #1d4ed8;
}

.status.normal {
  background: #f3f6fa;
  color: #475467;
}

.rowAction {
  min-height: 28px;
  border: 0;
  border-radius: 10px;
  background: #172033;
  color: #ffffff;
  font-size: 11px;
  font-weight: 950;
  cursor: pointer;
  transition: 0.2s ease;
}

.rowAction:hover {
  transform: translateY(-1px);
  background: #0f172a;
}

.emptyState {
  padding: 16px;
  border-radius: 14px;
  background: #f8fafc;
  text-align: center;
  color: #667085;
  font-size: 13px;
  font-weight: 850;
}

.doctorCard {
  padding: 14px;
}

.doctorTop {
  display: flex;
  align-items: center;
  gap: 10px;
}

.doctorTop svg {
  color: #172033;
  flex: 0 0 auto;
}

.doctorTop h3 {
  font-size: 15px;
}

.doctorTop p {
  margin: 3px 0 0;
  color: #667085;
  font-size: 12px;
  font-weight: 800;
}

.doctorMeta {
  display: grid;
  gap: 7px;
  margin-top: 12px;
}

.doctorMeta span {
  display: flex;
  align-items: center;
  gap: 7px;
  color: #475467;
  font-size: 12px;
  font-weight: 800;
  padding: 8px 0;
  border-bottom: 1px solid #edf1f6;
}

.doctorMeta span:last-child {
  border-bottom: 0;
}

.commonPanel {
  padding-bottom: 15px;
}

.barList {
  display: grid;
  gap: 10px;
}

.barMeta {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #475467;
  font-weight: 900;
  margin-bottom: 6px;
}

.barTrack {
  height: 7px;
  background: #edf1f6;
  border-radius: 999px;
  overflow: hidden;
}

.barFill {
  height: 100%;
  border-radius: inherit;
  background: #2563eb;
}

.lightPanel {
  background: linear-gradient(135deg, #ffffff, #f0f7ff);
}

.lightPanel p:last-of-type {
  margin: 8px 0 0;
  color: #667085;
  font-size: 12px;
  line-height: 1.5;
  font-weight: 700;
}

.fullBtn {
  width: 100%;
  min-height: 36px;
  margin-top: 10px;
  background: #172033;
  color: #ffffff;
  font-size: 12px;
}

@media (max-width: 1120px) {
  .metricGrid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .dashboardGrid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .doctorDashboard {
    padding: 14px;
  }

  .dashboardHeader {
    display: grid;
  }

  .headerActions,
  .searchBox {
    width: 100%;
  }

  .primaryBtn,
  .ghostBtn {
    flex: 1;
  }

  .metricGrid {
    grid-template-columns: 1fr;
  }

  .appointmentRow {
    grid-template-columns: 32px minmax(0, 1fr) 38px;
  }

  .timeBox,
  .status {
    grid-column: 2;
    justify-content: flex-start;
    width: fit-content;
  }

  .rowAction {
    grid-column: 3;
    grid-row: 1 / span 2;
  }
}
`;

export default DoctorDashboard;
