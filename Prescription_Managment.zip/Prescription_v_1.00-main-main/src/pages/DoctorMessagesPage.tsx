import { useEffect, useMemo, useRef, useState } from "react";
import {
  Bell,
  BellOff,
  Check,
  CheckCheck,
  ChevronLeft,
  File,
  Mic,
  MicOff,
  MessageCircle,
  Paperclip,
  PhoneCall,
  Power,
  Search,
  Send,
  Settings,
  ShieldCheck,
  TimerReset,
  Video,
  VideoOff,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import GlassCard from "../components/common/GlassCard";
import {
  PUBLIC_MESSAGES_KEY,
  safeReadList,
  safeWriteList,
} from "../publicSite/lib/publicUserStorage";

const PANEL_SETTINGS_STORAGE_KEY = "doctorPanelSettings";
const DOCTOR_CONVERSATIONS_STORAGE_KEY = "doctorPanelConversations";
const DOCTOR_MESSAGES_STORAGE_KEY = "doctorPanelMessages";

const defaultPatientAccess = {
  audio: true,
  video: true,
  files: true,
};

const defaultSettings = {
  inboxEnabled: true,
  pausedUntil: "",
  autoReplyEnabled: true,
  autoReplyText:
    "Doctor is currently busy with consultation. Please wait for a reply.",
  showSeenStatus: true,
  notificationEnabled: true,
  patientAccess: {},
};

const initialConversations = [
  {
    id: "c1",
    name: "Rahim Uddin",
    phone: "01712345678",
    lastMessage: "Doctor, amar report ready hoyeche.",
    time: "1:48 PM",
    unread: 2,
    tag: "Patient",
  },
  {
    id: "c2",
    name: "Nusrat Jahan",
    phone: "01812345678",
    lastMessage: "Follow-up date confirm korben?",
    time: "12:20 PM",
    unread: 1,
    tag: "Follow-up",
  },
  {
    id: "c3",
    name: "Hasan Mahmud",
    phone: "01912345678",
    lastMessage: "Medicine ta dinner er pore khabo?",
    time: "11:05 AM",
    unread: 0,
    tag: "Medicine",
  },
  {
    id: "c4",
    name: "Tamanna Akter",
    phone: "01612345678",
    lastMessage: "Thank you doctor.",
    time: "10:15 AM",
    unread: 0,
    tag: "Done",
  },
];

const initialMessages = {
  c1: [
    {
      id: "m1",
      sender: "patient",
      text: "Assalamu alaikum doctor.",
      time: "1:40 PM",
    },
    {
      id: "m2",
      sender: "patient",
      text: "Doctor, amar report ready hoyeche.",
      time: "1:48 PM",
    },
  ],
  c2: [
    {
      id: "m3",
      sender: "patient",
      text: "Follow-up date confirm korben?",
      time: "12:20 PM",
    },
  ],
  c3: [
    {
      id: "m4",
      sender: "patient",
      text: "Medicine ta dinner er pore khabo?",
      time: "11:05 AM",
    },
    {
      id: "m5",
      sender: "doctor",
      text: "Yes, dinner er pore khaben.",
      time: "11:08 AM",
      status: "seen",
    },
  ],
  c4: [
    {
      id: "m6",
      sender: "patient",
      text: "Thank you doctor.",
      time: "10:15 AM",
    },
  ],
};

const readStoredObject = (key, fallback) => {
  if (typeof window === "undefined") return fallback;

  try {
    const saved = window.localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
};

const getStoredSettings = () => {
  const stored = readStoredObject(PANEL_SETTINGS_STORAGE_KEY, defaultSettings);

  return {
    ...defaultSettings,
    ...stored,
    patientAccess: stored?.patientAccess || {},
  };
};

const getStoredConversations = () => {
  const saved = readStoredObject(
    DOCTOR_CONVERSATIONS_STORAGE_KEY,
    initialConversations
  );

  return Array.isArray(saved) && saved.length ? saved : initialConversations;
};

const getStoredMessages = () => {
  const saved = readStoredObject(DOCTOR_MESSAGES_STORAGE_KEY, initialMessages);
  return saved && typeof saved === "object" ? saved : initialMessages;
};

const getPatientAccess = (settings, patientId) => {
  if (!patientId) return defaultPatientAccess;

  return {
    ...defaultPatientAccess,
    ...(settings.patientAccess?.[patientId] || {}),
  };
};

const cleanKey = (value) => {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

const getMessageSender = (message) => {
  const sender = String(message?.sender || message?.from || "patient").toLowerCase();
  return sender === "doctor" ? "doctor" : "patient";
};

const getMessageText = (message) => {
  return message?.message || message?.text || message?.body || "";
};

const getPublicThreadId = (message) => {
  if (message?.threadId) return message.threadId;
  return `public-${cleanKey(message?.phone || message?.userName || message?.id)}`;
};

const getMessageSortTime = (message) => {
  const time = new Date(message?.createdAt || message?.updatedAt || 0).getTime();

  if (Number.isFinite(time) && time > 0) return time;

  const idTime = String(message?.id || "").match(/(\d{10,})/);
  if (idTime) return Number(idTime[1]);

  return 0;
};

const formatTime = () => {
  return new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatMessageTime = (value) => {
  if (!value) return "";

  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "";

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatMessageDate = (value) => {
  if (!value) return "";

  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "";

  return date.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatFileSize = (bytes) => {
  if (!bytes) return "0 KB";

  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;

  return `${(kb / 1024).toFixed(1)} MB`;
};

const fileToDataUrl = (file) => {
  return new Promise((resolve) => {
    const reader = new FileReader();

    reader.onload = () => {
      resolve(reader.result);
    };

    reader.onerror = () => {
      resolve("");
    };

    reader.readAsDataURL(file);
  });
};

const normalizeAttachment = (attachment) => {
  if (!attachment) return null;

  const type = attachment.type || "application/octet-stream";
  const name = attachment.name || "Attachment";

  return {
    ...attachment,
    name,
    type,
    dataUrl: attachment.dataUrl || "",
    isImage: Boolean(
      attachment.isImage ||
        type.startsWith("image/") ||
        String(name).match(/\.(png|jpg|jpeg|webp|gif)$/i)
    ),
  };
};

const buildDoctorPublicReply = ({
  activeConversation,
  text = "",
  attachment = null,
}) => {
  const now = new Date().toISOString();

  return {
    id: `doctor-reply-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    threadId: activeConversation.id,
    sender: "doctor",
    from: "doctor",
    userName: activeConversation.name,
    patientName: activeConversation.name,
    phone: activeConversation.phone || "",
    category: "General",
    subject: "Doctor reply",
    message: text || (attachment ? "Attachment" : ""),
    status: "Read",
    deliveryStatus: "seen",
    replyStatus: "seen",
    createdAt: now,
    updatedAt: now,
    attachment,
  };
};

const getRemainingText = (milliseconds) => {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes <= 0) return `${seconds}s`;
  return `${minutes}m ${seconds}s`;
};

const getPauseUntilText = (isoValue) => {
  if (!isoValue) return "";

  return new Date(isoValue).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatCallDuration = (milliseconds) => {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");

  return `${minutes}:${seconds}`;
};

const MessageStatus = ({ status, show }) => {
  if (!show || !status) return null;

  if (status === "seen" || status === "Read") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-black text-teal-500">
        <CheckCheck size={12} />
        Seen
      </span>
    );
  }

  if (status === "delivered") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-black text-slate-400">
        <CheckCheck size={12} />
        Delivered
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-black text-slate-400">
      <Check size={12} />
      Sent
    </span>
  );
};

const DoctorMessagesPage = () => {
  const fileInputRef = useRef(null);
  const localVideoRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const messageBoxRef = useRef(null);

  const [settings, setSettings] = useState(getStoredSettings);
  const [publicMessages, setPublicMessages] = useState([]);
  const [manualConversations, setManualConversations] =
    useState(getStoredConversations);
  const [doctorMessagesByConversation, setDoctorMessagesByConversation] =
    useState(getStoredMessages);

  const [activeId, setActiveId] = useState(initialConversations[0]?.id || null);
  const [composerText, setComposerText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [showListMobile, setShowListMobile] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [now, setNow] = useState(() => Date.now());

  const [formInboxEnabled, setFormInboxEnabled] = useState(
    settings.inboxEnabled
  );
  const [formPausePreset, setFormPausePreset] = useState("0");
  const [customPauseMinutes, setCustomPauseMinutes] = useState("20");
  const [formAutoReplyEnabled, setFormAutoReplyEnabled] = useState(
    settings.autoReplyEnabled
  );
  const [formAutoReplyText, setFormAutoReplyText] = useState(
    settings.autoReplyText
  );
  const [formSeenStatus, setFormSeenStatus] = useState(settings.showSeenStatus);
  const [formNotification, setFormNotification] = useState(
    settings.notificationEnabled
  );

  const [accessPatientId, setAccessPatientId] = useState(
    initialConversations[0]?.id || ""
  );
  const [formAllowAudio, setFormAllowAudio] = useState(true);
  const [formAllowVideo, setFormAllowVideo] = useState(true);
  const [formAllowFiles, setFormAllowFiles] = useState(true);

  const [callSession, setCallSession] = useState({
    open: false,
    type: "audio",
    status: "idle",
    patient: null,
    startedAt: 0,
    duration: 0,
    micOn: true,
    cameraOn: true,
    mediaError: false,
  });

  const publicThreads = useMemo(() => {
    const grouped = new Map();

    [...publicMessages]
      .sort((a, b) => getMessageSortTime(a) - getMessageSortTime(b))
      .forEach((message) => {
        const threadId = getPublicThreadId(message);

        if (!grouped.has(threadId)) {
          grouped.set(threadId, []);
        }

        grouped.get(threadId).push(message);
      });

    const conversations = [];
    const messagesByConversation = {};

    grouped.forEach((items, threadId) => {
      const sortedItems = [...items].sort(
        (a, b) => getMessageSortTime(a) - getMessageSortTime(b)
      );

      const lastPatientMessage =
        [...sortedItems]
          .reverse()
          .find((message) => getMessageSender(message) === "patient") ||
        sortedItems[sortedItems.length - 1];

      const publicThreadMessages = sortedItems.map((message) => ({
        id: `public-${message.id}`,
        rawId: message.id,
        sender: getMessageSender(message),
        text: getMessageText(message),
        time: formatMessageTime(message.createdAt || message.updatedAt),
        sortTime: getMessageSortTime(message),
        source: "public",
        publicMessageId: message.id,
        attachment: normalizeAttachment(message.attachment),
        status: message.deliveryStatus || message.replyStatus || message.status,
      }));

      const legacyDoctorReplies = (doctorMessagesByConversation[threadId] || [])
        .filter((message) => getMessageSender(message) === "doctor")
        .map((message, index) => ({
          ...message,
          sortTime:
            message.sortTime ||
            getMessageSortTime(message) ||
            Date.now() + index,
          attachment: normalizeAttachment(message.attachment),
        }));

      const fullThread = [...publicThreadMessages, ...legacyDoctorReplies].sort(
        (a, b) => (a.sortTime || 0) - (b.sortTime || 0)
      );

      const lastThreadMessage = fullThread[fullThread.length - 1];

      messagesByConversation[threadId] = fullThread;

      conversations.push({
        id: threadId,
        name:
          lastPatientMessage?.userName ||
          lastPatientMessage?.patientName ||
          "Public User",
        phone: lastPatientMessage?.phone || "-",
        lastMessage: lastThreadMessage?.attachment
          ? `Attachment: ${lastThreadMessage.attachment.name || "File"}`
          : lastThreadMessage?.text || "Patient message",
        time:
          lastThreadMessage?.time ||
          formatMessageTime(
            lastPatientMessage?.createdAt || lastPatientMessage?.updatedAt
          ),
        unread: sortedItems.filter(
          (message) =>
            getMessageSender(message) === "patient" &&
            message.status !== "Read"
        ).length,
        tag: "Website",
        isPublicThread: true,
      });
    });

    return {
      conversations: conversations.sort((a, b) => b.unread - a.unread),
      messagesByConversation,
      ids: new Set(conversations.map((item) => item.id)),
    };
  }, [publicMessages, doctorMessagesByConversation]);

  const conversations = useMemo(() => {
    return [
      ...publicThreads.conversations,
      ...manualConversations.filter((item) => !publicThreads.ids.has(item.id)),
    ];
  }, [manualConversations, publicThreads]);

  const messagesByConversation = useMemo(() => {
    return {
      ...doctorMessagesByConversation,
      ...publicThreads.messagesByConversation,
    };
  }, [doctorMessagesByConversation, publicThreads.messagesByConversation]);

  const activeConversation = conversations.find((item) => item.id === activeId);
  const activeMessages = messagesByConversation[activeId] || [];

  const activeAccess = useMemo(
    () => getPatientAccess(settings, activeId),
    [settings, activeId]
  );

  useEffect(() => {
    window.localStorage.setItem(
      PANEL_SETTINGS_STORAGE_KEY,
      JSON.stringify(settings)
    );
  }, [settings]);

  useEffect(() => {
    window.localStorage.setItem(
      DOCTOR_CONVERSATIONS_STORAGE_KEY,
      JSON.stringify(manualConversations)
    );
  }, [manualConversations]);

  useEffect(() => {
    window.localStorage.setItem(
      DOCTOR_MESSAGES_STORAGE_KEY,
      JSON.stringify(doctorMessagesByConversation)
    );
  }, [doctorMessagesByConversation]);

  useEffect(() => {
    const loadPublicMessages = () => {
      setPublicMessages(safeReadList(PUBLIC_MESSAGES_KEY));
    };

    loadPublicMessages();
    window.addEventListener("storage", loadPublicMessages);
    window.addEventListener("public-user-messages-updated", loadPublicMessages);
    window.addEventListener("public-doctor-reply-updated", loadPublicMessages);

    return () => {
      window.removeEventListener("storage", loadPublicMessages);
      window.removeEventListener(
        "public-user-messages-updated",
        loadPublicMessages
      );
      window.removeEventListener(
        "public-doctor-reply-updated",
        loadPublicMessages
      );
    };
  }, []);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setNow(Date.now());
    }, 1000);

    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    if (!settings.pausedUntil) return;

    const pausedUntilTime = new Date(settings.pausedUntil).getTime();

    if (pausedUntilTime <= now) {
      const timeoutId = window.setTimeout(() => {
        setSettings((prev) => ({
          ...prev,
          pausedUntil: "",
        }));
      }, 0);

      return () => window.clearTimeout(timeoutId);
    }

    return undefined;
  }, [now, settings.pausedUntil]);

  useEffect(() => {
    if (!conversations.length) return;

    const exists = conversations.some((item) => item.id === activeId);

    if (!activeId || !exists) {
      const timeoutId = window.setTimeout(() => {
        setActiveId(conversations[0].id);
      }, 0);

      return () => window.clearTimeout(timeoutId);
    }

    return undefined;
  }, [activeId, conversations]);

  useEffect(() => {
    const access = getPatientAccess(settings, accessPatientId);

    const timeoutId = window.setTimeout(() => {
      setFormAllowAudio(access.audio);
      setFormAllowVideo(access.video);
      setFormAllowFiles(access.files);
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [accessPatientId, settings]);

  useEffect(() => {
    if (localVideoRef.current && mediaStreamRef.current) {
      localVideoRef.current.srcObject = mediaStreamRef.current;
    }
  }, [callSession.open, callSession.type]);

  useEffect(() => {
    if (!callSession.open || callSession.status !== "live") return undefined;

    const intervalId = window.setInterval(() => {
      setCallSession((prev) => ({
        ...prev,
        duration: Date.now() - prev.startedAt,
      }));
    }, 1000);

    return () => window.clearInterval(intervalId);
  }, [callSession.open, callSession.status, callSession.startedAt]);

  useEffect(() => {
    messageBoxRef.current?.scrollTo({
      top: messageBoxRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [activeId, activeMessages.length]);

  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
    };
  }, []);

  const pausedUntilTime = settings.pausedUntil
    ? new Date(settings.pausedUntil).getTime()
    : 0;

  const isPaused = pausedUntilTime > now;
  const inboxActive = settings.inboxEnabled && !isPaused;

  const unreadCount = conversations.reduce(
    (total, item) => total + item.unread,
    0
  );

  const sortedPublicMessages = useMemo(() => {
    return [...publicMessages]
      .filter((message) => getMessageSender(message) === "patient")
      .sort((a, b) => getMessageSortTime(b) - getMessageSortTime(a));
  }, [publicMessages]);

  const filteredConversations = useMemo(() => {
    const keyword = searchTerm.toLowerCase().trim();

    if (!keyword) return conversations;

    return conversations.filter((item) => {
      const searchableText =
        `${item.name} ${item.phone} ${item.lastMessage} ${item.tag}`.toLowerCase();

      return searchableText.includes(keyword);
    });
  }, [conversations, searchTerm]);

  const showToast = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  };

  const writePublicMessages = (nextMessages) => {
    setPublicMessages(nextMessages);
    safeWriteList(PUBLIC_MESSAGES_KEY, nextMessages);
    window.dispatchEvent(new Event("public-user-messages-updated"));
    window.dispatchEvent(new Event("public-doctor-reply-updated"));
  };

  const setPublicMessageStatus = (messageId, status) => {
    writePublicMessages(
      safeReadList(PUBLIC_MESSAGES_KEY).map((message) =>
        message.id === messageId
          ? { ...message, status, updatedAt: new Date().toISOString() }
          : message
      )
    );
  };

  const deletePublicMessage = (messageId) => {
    writePublicMessages(
      safeReadList(PUBLIC_MESSAGES_KEY).filter(
        (message) => message.id !== messageId
      )
    );
  };

  const markPublicThreadRead = (threadId) => {
    writePublicMessages(
      safeReadList(PUBLIC_MESSAGES_KEY).map((message) =>
        getPublicThreadId(message) === threadId &&
        getMessageSender(message) === "patient"
          ? { ...message, status: "Read", updatedAt: new Date().toISOString() }
          : message
      )
    );
  };

  const markMessageStatus = (conversationId, messageIds, status) => {
    setDoctorMessagesByConversation((prev) => ({
      ...prev,
      [conversationId]: (prev[conversationId] || []).map((message) =>
        messageIds.includes(message.id) ? { ...message, status } : message
      ),
    }));
  };

  const openThreadFromPublicMessage = (message) => {
    if (!inboxActive) {
      showToast("Turn messages ON to reply.");
      return;
    }

    const threadId = getPublicThreadId(message);

    setActiveId(threadId);
    setShowListMobile(false);
    markPublicThreadRead(threadId);

    window.setTimeout(() => {
      document
        .getElementById("doctor-message-inbox")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
  };

  const openSettings = (patientId = activeId) => {
    setFormInboxEnabled(settings.inboxEnabled);
    setFormPausePreset("0");
    setCustomPauseMinutes("20");
    setFormAutoReplyEnabled(settings.autoReplyEnabled);
    setFormAutoReplyText(settings.autoReplyText);
    setFormSeenStatus(settings.showSeenStatus);
    setFormNotification(settings.notificationEnabled);
    setAccessPatientId(patientId || conversations[0]?.id || "");
    setSettingsOpen(true);
  };

  const handleSaveSettings = () => {
    const selectedMinutes =
      formPausePreset === "custom"
        ? Number(customPauseMinutes)
        : Number(formPausePreset);

    const safeMinutes = Number.isFinite(selectedMinutes)
      ? Math.max(0, selectedMinutes)
      : 0;

    const pausedUntil =
      formInboxEnabled && safeMinutes > 0
        ? new Date(Date.now() + safeMinutes * 60 * 1000).toISOString()
        : "";

    const nextPatientAccess = accessPatientId
      ? {
          ...settings.patientAccess,
          [accessPatientId]: {
            audio: formAllowAudio,
            video: formAllowVideo,
            files: formAllowFiles,
          },
        }
      : settings.patientAccess;

    const nextSettings = {
      inboxEnabled: formInboxEnabled,
      pausedUntil,
      autoReplyEnabled: formAutoReplyEnabled,
      autoReplyText: formAutoReplyText.trim() || defaultSettings.autoReplyText,
      showSeenStatus: formSeenStatus,
      notificationEnabled: formNotification,
      patientAccess: nextPatientAccess,
    };

    const patientName =
      conversations.find((item) => item.id === accessPatientId)?.name ||
      "patient";

    setSettings(nextSettings);
    setSettingsOpen(false);

    const statusText = !formInboxEnabled
      ? "Messages OFF"
      : safeMinutes > 0
        ? `Messages paused for ${safeMinutes} minutes`
        : "Messages ON";

    showToast(
      `${statusText}. ${patientName}: audio ${
        formAllowAudio ? "ON" : "OFF"
      }, video ${formAllowVideo ? "ON" : "OFF"}, file ${
        formAllowFiles ? "ON" : "OFF"
      }.`
    );
  };

  const handleToggleInbox = () => {
    if (inboxActive) {
      setSettings((prev) => ({
        ...prev,
        inboxEnabled: false,
        pausedUntil: "",
      }));
      showToast("Messages turned OFF.");
      return;
    }

    setSettings((prev) => ({
      ...prev,
      inboxEnabled: true,
      pausedUntil: "",
    }));
    showToast("Messages turned ON.");
  };

  const handleSelectConversation = (id) => {
    if (!inboxActive) return;

    setActiveId(id);
    setShowListMobile(false);

    if (id.startsWith("public-")) {
      markPublicThreadRead(id);
      return;
    }

    setManualConversations((prev) =>
      prev.map((item) => (item.id === id ? { ...item, unread: 0 } : item))
    );
  };

  const handleSendMessage = () => {
    const text = composerText.trim();

    if (!text || !activeId || !inboxActive || !activeConversation) return;

    const time = formatTime();

    if (activeId.startsWith("public-")) {
      const newPublicReply = buildDoctorPublicReply({
        activeConversation,
        text,
        attachment: null,
      });

      writePublicMessages([
        ...safeReadList(PUBLIC_MESSAGES_KEY),
        newPublicReply,
      ]);

      setComposerText("");
      showToast("Reply sent to public patient inbox.");
      return;
    }

    const messageId = `doctor-${Date.now()}`;

    const newMessage = {
      id: messageId,
      sender: "doctor",
      text,
      time,
      sortTime: Date.now(),
      status: "sent",
    };

    setDoctorMessagesByConversation((prev) => ({
      ...prev,
      [activeId]: [...(prev[activeId] || []), newMessage],
    }));

    setManualConversations((prev) =>
      prev.map((item) =>
        item.id === activeId
          ? {
              ...item,
              lastMessage: text,
              time,
            }
          : item
      )
    );

    setComposerText("");

    window.setTimeout(() => {
      markMessageStatus(activeId, [messageId], "delivered");
    }, 700);

    window.setTimeout(() => {
      markMessageStatus(activeId, [messageId], "seen");
    }, 1700);
  };

  const handlePickFile = () => {
    if (!activeAccess.files) {
      showToast("File attachment is disabled for this patient.");
      return;
    }

    fileInputRef.current?.click();
  };

  const handleAttachFiles = async (event) => {
    const files = Array.from(event.target.files || []);

    if (!files.length || !activeId || !inboxActive || !activeConversation) {
      return;
    }

    if (!activeAccess.files) {
      showToast("File attachment is disabled for this patient.");
      event.target.value = "";
      return;
    }

    const time = formatTime();

    const preparedFiles = await Promise.all(
      files.map(async (file, index) => {
        const dataUrl = await fileToDataUrl(file);

        return {
          id: `file-${Date.now()}-${index}`,
          sender: "doctor",
          text: "Attachment",
          time,
          sortTime: Date.now() + index,
          status: "sent",
          attachment: {
            name: file.name,
            size: file.size,
            type: file.type || "application/octet-stream",
            dataUrl,
            isImage:
              file.type.startsWith("image/") ||
              Boolean(String(file.name).match(/\.(png|jpg|jpeg|webp|gif)$/i)),
          },
        };
      })
    );

    if (activeId.startsWith("public-")) {
      const publicFileReplies = preparedFiles.map((message) =>
        buildDoctorPublicReply({
          activeConversation,
          text: message.attachment?.isImage ? "" : "Attachment",
          attachment: message.attachment,
        })
      );

      writePublicMessages([
        ...safeReadList(PUBLIC_MESSAGES_KEY),
        ...publicFileReplies,
      ]);

      event.target.value = "";
      showToast(`${files.length} attachment sent to public patient inbox.`);
      return;
    }

    setDoctorMessagesByConversation((prev) => ({
      ...prev,
      [activeId]: [...(prev[activeId] || []), ...preparedFiles],
    }));

    setManualConversations((prev) =>
      prev.map((item) =>
        item.id === activeId
          ? {
              ...item,
              lastMessage: `Attachment: ${files[files.length - 1].name}`,
              time,
            }
          : item
      )
    );

    const messageIds = preparedFiles.map((item) => item.id);

    window.setTimeout(() => {
      markMessageStatus(activeId, messageIds, "delivered");
    }, 700);

    window.setTimeout(() => {
      markMessageStatus(activeId, messageIds, "seen");
    }, 1700);

    event.target.value = "";
    showToast(`${files.length} file attached.`);
  };

  const stopCurrentStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
  };

  const handleStartCall = async (type) => {
    if (!activeConversation || !inboxActive) return;

    const access = getPatientAccess(settings, activeConversation.id);

    if (type === "audio" && !access.audio) {
      showToast("Audio call is disabled for this patient.");
      return;
    }

    if (type === "video" && !access.video) {
      showToast("Video call is disabled for this patient.");
      return;
    }

    stopCurrentStream();

    setCallSession({
      open: true,
      type,
      status: "connecting",
      patient: activeConversation,
      startedAt: 0,
      duration: 0,
      micOn: true,
      cameraOn: type === "video",
      mediaError: false,
    });

    try {
      if (navigator.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: type === "video",
        });

        mediaStreamRef.current = stream;

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      }

      window.setTimeout(() => {
        setCallSession((prev) => ({
          ...prev,
          status: "live",
          startedAt: Date.now(),
        }));
      }, 600);

      showToast(
        `${type === "video" ? "Video" : "Audio"} call started with ${
          activeConversation.name
        }.`
      );
    } catch {
      setCallSession((prev) => ({
        ...prev,
        status: "live",
        startedAt: Date.now(),
        mediaError: true,
      }));

      showToast("Mic/camera permission blocked. Call UI started in demo mode.");
    }
  };

  const handleEndCall = () => {
    stopCurrentStream();

    setCallSession({
      open: false,
      type: "audio",
      status: "idle",
      patient: null,
      startedAt: 0,
      duration: 0,
      micOn: true,
      cameraOn: true,
      mediaError: false,
    });

    showToast("Call ended.");
  };

  const handleToggleMic = () => {
    const nextValue = !callSession.micOn;

    mediaStreamRef.current?.getAudioTracks().forEach((track) => {
      track.enabled = nextValue;
    });

    setCallSession((prev) => ({
      ...prev,
      micOn: nextValue,
    }));
  };

  const handleToggleCamera = () => {
    if (callSession.type !== "video") return;

    const nextValue = !callSession.cameraOn;

    mediaStreamRef.current?.getVideoTracks().forEach((track) => {
      track.enabled = nextValue;
    });

    setCallSession((prev) => ({
      ...prev,
      cameraOn: nextValue,
    }));
  };

  const handleOverlayClose = (event) => {
    if (event.target === event.currentTarget) {
      setSettingsOpen(false);
    }
  };

  const handleCallOverlayClose = (event) => {
    if (event.target === event.currentTarget) {
      handleEndCall();
    }
  };

  return (
    <section className="mx-auto grid max-w-6xl gap-3">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleAttachFiles}
      />

      {toast ? (
        <div className="fixed right-5 top-5 z-50 max-w-sm rounded-2xl border border-teal-100 bg-white px-4 py-3 text-sm font-black text-slate-800 shadow-2xl">
          {toast}
        </div>
      ) : null}

      <GlassCard className="px-4 py-3">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <MessageCircle size={18} className="text-teal-700" />
              <h2 className="text-xl font-black tracking-tight text-slate-900">
                Messages
              </h2>

              <span
                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-black ${
                  inboxActive
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-rose-50 text-rose-700"
                }`}
              >
                {inboxActive ? <Wifi size={12} /> : <WifiOff size={12} />}
                {inboxActive ? "Online" : isPaused ? "Paused" : "Offline"}
              </span>

              {isPaused ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-black text-amber-700">
                  <TimerReset size={12} />
                  Back in {getRemainingText(pausedUntilTime - now)}
                </span>
              ) : null}
            </div>

            <p className="mt-1 truncate text-xs font-bold text-slate-500">
              {inboxActive
                ? `${unreadCount} unread message request${
                    unreadCount === 1 ? "" : "s"
                  }. Doctor reply public page-e save হবে।`
                : isPaused
                  ? `Message request off until ${getPauseUntilText(
                      settings.pausedUntil
                    )}.`
                  : "Message request is currently off."}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleToggleInbox}
              className={`inline-flex h-9 items-center gap-2 rounded-xl px-3 text-xs font-black transition ${
                inboxActive
                  ? "bg-rose-50 text-rose-700 hover:bg-rose-100"
                  : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
              }`}
            >
              <Power size={15} />
              {inboxActive ? "Turn Off" : "Turn On"}
            </button>

            <button
              type="button"
              onClick={() => openSettings(activeId)}
              className="inline-flex h-9 items-center gap-2 rounded-xl bg-slate-900 px-3 text-xs font-black text-white transition hover:bg-slate-800"
            >
              <Settings size={15} />
              Settings
            </button>
          </div>
        </div>
      </GlassCard>

      {sortedPublicMessages.length ? (
        <GlassCard className="overflow-hidden p-0">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-2.5">
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Public user messages
              </h3>
              <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                Reply click করলে নিচের inbox-এ সেই patient-এর chat open হবে।
              </p>
            </div>

            <span className="rounded-full bg-cyan-50 px-2.5 py-1 text-[10px] font-black text-teal-700">
              {sortedPublicMessages.length} total
            </span>
          </div>

          <div className="max-h-[235px] overflow-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 z-10">
                <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
                  <th className="min-w-32 px-3 py-2 font-black">User</th>
                  <th className="min-w-28 px-3 py-2 font-black">Phone</th>
                  <th className="min-w-28 px-3 py-2 font-black">Subject</th>
                  <th className="min-w-52 px-3 py-2 font-black">Message</th>
                  <th className="min-w-20 px-3 py-2 font-black">Status</th>
                  <th className="min-w-24 px-3 py-2 font-black">Time</th>
                  <th className="min-w-44 px-3 py-2 font-black">Actions</th>
                </tr>
              </thead>

              <tbody>
                {sortedPublicMessages.map((message) => (
                  <tr
                    key={message.id}
                    onClick={() => openThreadFromPublicMessage(message)}
                    className={`cursor-pointer border-b border-slate-100 transition hover:bg-cyan-50/70 ${
                      activeId === getPublicThreadId(message)
                        ? "bg-cyan-50"
                        : "bg-white"
                    }`}
                  >
                    <td className="px-3 py-2 font-black text-slate-900">
                      {message.userName || message.patientName || "Public User"}
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-600">
                      {message.phone || "-"}
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-700">
                      {message.subject || message.category || "-"}
                    </td>

                    <td className="max-w-[360px] px-3 py-2 font-semibold text-slate-500">
                      <p className="truncate">
                        {message.attachment
                          ? `Attachment: ${message.attachment.name || "File"}`
                          : getMessageText(message)}
                      </p>
                    </td>

                    <td className="px-3 py-2">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-black ${
                          message.status === "Read"
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-amber-50 text-amber-700"
                        }`}
                      >
                        {message.status || "Unread"}
                      </span>
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-500">
                      {formatMessageDate(message.createdAt || message.updatedAt)}
                    </td>

                    <td className="px-3 py-2">
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            openThreadFromPublicMessage(message);
                          }}
                          className="rounded-lg bg-slate-900 px-2.5 py-1 text-[10px] font-black text-white transition hover:bg-slate-800"
                        >
                          Reply
                        </button>

                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            setPublicMessageStatus(
                              message.id,
                              message.status === "Read" ? "Unread" : "Read"
                            );
                          }}
                          className="rounded-lg bg-cyan-50 px-2 py-1 text-[10px] font-black text-teal-700"
                        >
                          {message.status === "Read" ? "Unread" : "Read"}
                        </button>

                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            deletePublicMessage(message.id);
                          }}
                          className="rounded-lg bg-rose-50 px-2 py-1 text-[10px] font-black text-rose-700"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      ) : null}

      {!inboxActive ? (
        <GlassCard className="grid min-h-[360px] place-items-center px-4 py-10 text-center">
          <div>
            <BellOff size={30} className="mx-auto text-rose-600" />
            <h3 className="mt-3 text-xl font-black text-slate-900">
              Message request is off
            </h3>
            <p className="mx-auto mt-2 max-w-md text-sm font-semibold leading-6 text-slate-500">
              {isPaused
                ? `Inbox will be online automatically at ${getPauseUntilText(
                    settings.pausedUntil
                  )}.`
                : "Turn messages on when you are ready to reply."}
            </p>

            <div className="mt-4 flex justify-center gap-2">
              <button
                type="button"
                onClick={handleToggleInbox}
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-slate-900 px-4 text-sm font-black text-white"
              >
                <Wifi size={16} />
                Go Online
              </button>

              <button
                type="button"
                onClick={() => openSettings(activeId)}
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-slate-100 px-4 text-sm font-black text-slate-700"
              >
                <Settings size={16} />
                Change
              </button>
            </div>
          </div>
        </GlassCard>
      ) : (
        <section
          id="doctor-message-inbox"
          className="grid min-h-[430px] gap-3 lg:grid-cols-[285px_1fr]"
        >
          <GlassCard
            className={`overflow-hidden p-0 ${
              showListMobile ? "block" : "hidden"
            } lg:block`}
          >
            <div className="border-b border-slate-100 px-3 py-2.5">
              <label className="flex h-9 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3">
                <Search size={15} className="text-slate-400" />
                <input
                  type="search"
                  placeholder="Search patient..."
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  className="w-full bg-transparent text-xs font-bold text-slate-700 outline-none placeholder:text-slate-400"
                />
              </label>
            </div>

            <div className="max-h-[470px] overflow-y-auto">
              {filteredConversations.map((item) => {
                const access = getPatientAccess(settings, item.id);

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectConversation(item.id)}
                    className={`grid w-full gap-1 border-b border-slate-100 px-3 py-2.5 text-left transition hover:bg-slate-50 ${
                      activeId === item.id ? "bg-cyan-50/70" : "bg-white"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="truncate text-sm font-black text-slate-900">
                        {item.name}
                      </h3>
                      <span className="shrink-0 text-[10px] font-black text-slate-400">
                        {item.time}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs font-bold text-slate-500">
                        {item.lastMessage}
                      </p>

                      {item.unread > 0 ? (
                        <span className="grid h-5 min-w-5 place-items-center rounded-full bg-teal-600 px-1.5 text-[10px] font-black text-white">
                          {item.unread}
                        </span>
                      ) : null}
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-black text-slate-400">
                        {item.phone}
                      </span>

                      <span className="flex items-center gap-1 text-slate-400">
                        <PhoneCall
                          size={11}
                          className={
                            access.audio ? "text-emerald-600" : "text-slate-300"
                          }
                        />
                        <Video
                          size={12}
                          className={
                            access.video ? "text-emerald-600" : "text-slate-300"
                          }
                        />
                        <Paperclip
                          size={12}
                          className={
                            access.files ? "text-emerald-600" : "text-slate-300"
                          }
                        />
                      </span>
                    </div>
                  </button>
                );
              })}

              {filteredConversations.length === 0 ? (
                <div className="px-3 py-8 text-center text-xs font-black text-slate-400">
                  No conversation found.
                </div>
              ) : null}
            </div>
          </GlassCard>

          <GlassCard
            className={`overflow-hidden p-0 ${
              showListMobile ? "hidden" : "block"
            } lg:block`}
          >
            {activeConversation ? (
              <div className="grid h-[520px] grid-rows-[auto_1fr_auto]">
                <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-3">
                  <div className="flex min-w-0 items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowListMobile(true)}
                      className="lg:hidden"
                    >
                      <ChevronLeft size={20} className="text-slate-600" />
                    </button>

                    <div className="min-w-0">
                      <h3 className="truncate text-base font-black text-slate-900">
                        {activeConversation.name}
                      </h3>
                      <p className="truncate text-xs font-bold text-slate-500">
                        {activeConversation.phone} · {activeConversation.tag}
                      </p>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleStartCall("audio")}
                      disabled={!activeAccess.audio}
                      title={
                        activeAccess.audio
                          ? "Start audio call"
                          : "Audio call disabled"
                      }
                      className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100 text-slate-700 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <PhoneCall size={16} />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStartCall("video")}
                      disabled={!activeAccess.video}
                      title={
                        activeAccess.video
                          ? "Start video call"
                          : "Video call disabled"
                      }
                      className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100 text-slate-700 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <Video size={17} />
                    </button>

                    <button
                      type="button"
                      onClick={() => openSettings(activeConversation.id)}
                      className="inline-flex h-9 items-center gap-1 rounded-xl bg-teal-50 px-2.5 text-xs font-black text-teal-700 transition hover:bg-teal-100"
                    >
                      <ShieldCheck size={15} />
                      Access
                    </button>
                  </div>
                </div>

                <div
                  ref={messageBoxRef}
                  className="space-y-2 overflow-y-auto bg-slate-50/70 px-4 py-3"
                >
                  {activeMessages.map((message) => {
                    const isDoctor = getMessageSender(message) === "doctor";

                    return (
                      <div
                        key={message.id}
                        className={`flex ${
                          isDoctor ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[78%] rounded-2xl px-3 py-2 ${
                            isDoctor
                              ? "bg-slate-900 text-white"
                              : "bg-white text-slate-800 shadow-sm"
                          }`}
                        >
                          {message.attachment ? (
                            <div className="grid gap-1.5">
                              {message.attachment.isImage &&
                              message.attachment.dataUrl ? (
                                <a
                                  href={message.attachment.dataUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className={[
                                    "block overflow-hidden rounded-xl",
                                    isDoctor ? "bg-white/10" : "bg-white",
                                  ].join(" ")}
                                  title="Open image"
                                >
                                  <img
                                    src={message.attachment.dataUrl}
                                    alt={
                                      message.attachment.name || "Attachment"
                                    }
                                    className="max-h-56 max-w-[280px] rounded-xl object-cover"
                                  />
                                </a>
                              ) : (
                                <a
                                  href={message.attachment.dataUrl || undefined}
                                  download={
                                    message.attachment.name || "attachment"
                                  }
                                  className={`flex items-center gap-2 rounded-xl p-2 ${
                                    isDoctor ? "bg-white/10" : "bg-slate-50"
                                  }`}
                                  title="Download file"
                                >
                                  <File size={18} />
                                  <div className="min-w-0">
                                    <p className="truncate text-sm font-black">
                                      {message.attachment.name || "Attachment"}
                                    </p>
                                    <p
                                      className={`text-[10px] font-bold ${
                                        isDoctor
                                          ? "text-slate-300"
                                          : "text-slate-400"
                                      }`}
                                    >
                                      {formatFileSize(message.attachment.size)}
                                    </p>
                                  </div>
                                </a>
                              )}

                              {message.text && message.text !== "Attachment" ? (
                                <p className="text-sm font-semibold leading-5">
                                  {message.text}
                                </p>
                              ) : null}
                            </div>
                          ) : (
                            <p className="text-sm font-semibold leading-5">
                              {message.text}
                            </p>
                          )}

                          <div
                            className={`mt-1 flex items-center gap-2 ${
                              isDoctor ? "justify-end" : "justify-start"
                            }`}
                          >
                            <span
                              className={`text-[10px] font-black ${
                                isDoctor ? "text-slate-300" : "text-slate-400"
                              }`}
                            >
                              {message.time}
                            </span>

                            {isDoctor ? (
                              <MessageStatus
                                status={message.status || "seen"}
                                show={settings.showSeenStatus}
                              />
                            ) : null}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="border-t border-slate-100 bg-white px-3 py-3">
                  <form
                    className="flex items-end gap-2"
                    onSubmit={(event) => {
                      event.preventDefault();
                      handleSendMessage();
                    }}
                  >
                    <button
                      type="button"
                      onClick={handlePickFile}
                      disabled={!activeAccess.files}
                      title={
                        activeAccess.files
                          ? "Attach file"
                          : "File attachment disabled"
                      }
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-700 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <Paperclip size={17} />
                    </button>

                    <textarea
                      rows="1"
                      value={composerText}
                      onChange={(event) => setComposerText(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" && !event.shiftKey) {
                          event.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder="Write reply..."
                      className="max-h-28 min-h-10 flex-1 resize-none rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-cyan-300"
                    />

                    <button
                      type="submit"
                      disabled={!composerText.trim()}
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-900 text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300"
                    >
                      <Send size={16} />
                    </button>
                  </form>
                </div>
              </div>
            ) : (
              <div className="grid min-h-[430px] place-items-center text-center">
                <div>
                  <MessageCircle size={30} className="mx-auto text-slate-400" />
                  <h3 className="mt-3 text-lg font-black text-slate-900">
                    Select a conversation
                  </h3>
                </div>
              </div>
            )}
          </GlassCard>
        </section>
      )}

      {settingsOpen ? (
        <div
          className="fixed inset-0 z-40 grid place-items-center bg-slate-950/30 px-4 backdrop-blur-sm"
          onMouseDown={handleOverlayClose}
        >
          <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-5 shadow-2xl">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <Settings size={18} className="text-teal-700" />
                  <h3 className="text-lg font-black text-slate-900">
                    Message Settings
                  </h3>
                </div>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Control inbox, pause time, call, video, and file access.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSettingsOpen(false)}
                className="p-0 text-slate-500 transition hover:text-rose-600"
              >
                <X size={22} className="transition-transform hover:rotate-90" />
              </button>
            </div>

            <div className="grid gap-3">
              <label className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 px-3 py-3">
                <span>
                  <strong className="block text-sm font-black text-slate-900">
                    Message request
                  </strong>
                  <small className="text-xs font-bold text-slate-500">
                    Doctor can turn inbox on or off.
                  </small>
                </span>

                <button
                  type="button"
                  onClick={() => setFormInboxEnabled((prev) => !prev)}
                  className={`relative h-7 w-12 rounded-full transition ${
                    formInboxEnabled ? "bg-teal-600" : "bg-slate-300"
                  }`}
                >
                  <span
                    className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${
                      formInboxEnabled ? "left-6" : "left-1"
                    }`}
                  />
                </button>
              </label>

              <div className="grid gap-2 rounded-2xl border border-slate-100 px-3 py-3">
                <div>
                  <strong className="block text-sm font-black text-slate-900">
                    Pause message request
                  </strong>
                  <small className="text-xs font-bold text-slate-500">
                    Set how long inbox will stay off, then auto online.
                  </small>
                </div>

                <div className="grid gap-2 sm:grid-cols-[1fr_120px]">
                  <select
                    value={formPausePreset}
                    onChange={(event) => setFormPausePreset(event.target.value)}
                    disabled={!formInboxEnabled}
                    className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 outline-none disabled:bg-slate-100 disabled:text-slate-400"
                  >
                    <option value="0">No pause</option>
                    <option value="5">5 minutes</option>
                    <option value="15">15 minutes</option>
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="120">2 hours</option>
                    <option value="custom">Custom</option>
                  </select>

                  <input
                    type="number"
                    min="1"
                    value={customPauseMinutes}
                    onChange={(event) =>
                      setCustomPauseMinutes(event.target.value)
                    }
                    disabled={!formInboxEnabled || formPausePreset !== "custom"}
                    className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 outline-none disabled:bg-slate-100 disabled:text-slate-400"
                    placeholder="Minutes"
                  />
                </div>
              </div>

              <div className="grid gap-3 rounded-2xl border border-teal-100 bg-teal-50/40 px-3 py-3">
                <div>
                  <strong className="block text-sm font-black text-slate-900">
                    Patient access control
                  </strong>
                  <small className="text-xs font-bold text-slate-500">
                    Disable call, video, or file for a specific patient.
                  </small>
                </div>

                <select
                  value={accessPatientId}
                  onChange={(event) => setAccessPatientId(event.target.value)}
                  className="h-10 rounded-xl border border-teal-100 bg-white px-3 text-sm font-bold text-slate-700 outline-none"
                >
                  {conversations.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} — {item.phone}
                    </option>
                  ))}
                </select>

                <div className="grid gap-2 sm:grid-cols-3">
                  <label className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2">
                    <span className="flex items-center gap-2 text-xs font-black text-slate-700">
                      <PhoneCall size={14} />
                      Audio
                    </span>
                    <input
                      type="checkbox"
                      checked={formAllowAudio}
                      onChange={(event) =>
                        setFormAllowAudio(event.target.checked)
                      }
                      className="h-4 w-4 accent-teal-600"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2">
                    <span className="flex items-center gap-2 text-xs font-black text-slate-700">
                      <Video size={15} />
                      Video
                    </span>
                    <input
                      type="checkbox"
                      checked={formAllowVideo}
                      onChange={(event) =>
                        setFormAllowVideo(event.target.checked)
                      }
                      className="h-4 w-4 accent-teal-600"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2">
                    <span className="flex items-center gap-2 text-xs font-black text-slate-700">
                      <Paperclip size={15} />
                      File
                    </span>
                    <input
                      type="checkbox"
                      checked={formAllowFiles}
                      onChange={(event) =>
                        setFormAllowFiles(event.target.checked)
                      }
                      className="h-4 w-4 accent-teal-600"
                    />
                  </label>
                </div>
              </div>

              <label className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 px-3 py-3">
                <span>
                  <strong className="block text-sm font-black text-slate-900">
                    Auto reply when paused
                  </strong>
                  <small className="text-xs font-bold text-slate-500">
                    Patient will understand doctor is busy.
                  </small>
                </span>

                <button
                  type="button"
                  onClick={() => setFormAutoReplyEnabled((prev) => !prev)}
                  className={`relative h-7 w-12 rounded-full transition ${
                    formAutoReplyEnabled ? "bg-teal-600" : "bg-slate-300"
                  }`}
                >
                  <span
                    className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${
                      formAutoReplyEnabled ? "left-6" : "left-1"
                    }`}
                  />
                </button>
              </label>

              <textarea
                rows="3"
                value={formAutoReplyText}
                onChange={(event) => setFormAutoReplyText(event.target.value)}
                disabled={!formAutoReplyEnabled}
                className="resize-none rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 outline-none disabled:bg-slate-100 disabled:text-slate-400"
              />

              <div className="grid gap-2 sm:grid-cols-2">
                <label className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 px-3 py-3">
                  <span className="flex items-center gap-2 text-sm font-black text-slate-900">
                    <CheckCheck size={16} />
                    Seen status
                  </span>

                  <input
                    type="checkbox"
                    checked={formSeenStatus}
                    onChange={(event) => setFormSeenStatus(event.target.checked)}
                    className="h-4 w-4 accent-teal-600"
                  />
                </label>

                <label className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 px-3 py-3">
                  <span className="flex items-center gap-2 text-sm font-black text-slate-900">
                    <Bell size={16} />
                    Notify
                  </span>

                  <input
                    type="checkbox"
                    checked={formNotification}
                    onChange={(event) =>
                      setFormNotification(event.target.checked)
                    }
                    className="h-4 w-4 accent-teal-600"
                  />
                </label>
              </div>

              <button
                type="button"
                onClick={handleSaveSettings}
                className="mt-1 h-11 rounded-2xl bg-slate-900 text-sm font-black text-white transition hover:bg-slate-800"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {callSession.open ? (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-slate-950/50 px-4 backdrop-blur-sm"
          onMouseDown={handleCallOverlayClose}
        >
          <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-black uppercase tracking-wider text-teal-600">
                  {callSession.type === "video" ? "Video Call" : "Audio Call"}
                </p>
                <h3 className="mt-1 text-xl font-black text-slate-900">
                  {callSession.patient?.name}
                </h3>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {callSession.status === "connecting"
                    ? "Connecting..."
                    : `Live · ${formatCallDuration(callSession.duration)}`}
                </p>
              </div>

              <button
                type="button"
                onClick={handleEndCall}
                className="p-0 text-slate-500 transition hover:text-rose-600"
              >
                <X size={23} className="transition-transform hover:rotate-90" />
              </button>
            </div>

            {callSession.type === "video" ? (
              <div className="grid gap-3">
                <div className="grid h-52 place-items-center overflow-hidden rounded-3xl bg-slate-900 text-white">
                  <div className="text-center">
                    <Video size={34} className="mx-auto opacity-80" />
                    <p className="mt-2 text-sm font-black">
                      Patient video area
                    </p>
                    <p className="text-xs font-bold text-slate-300">
                      Waiting for patient connection
                    </p>
                  </div>
                </div>

                <div className="overflow-hidden rounded-2xl bg-slate-100">
                  {callSession.cameraOn && !callSession.mediaError ? (
                    <video
                      ref={localVideoRef}
                      autoPlay
                      muted
                      playsInline
                      className="h-28 w-full object-cover"
                    />
                  ) : (
                    <div className="grid h-28 place-items-center text-xs font-black text-slate-500">
                      Camera off
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="grid h-52 place-items-center rounded-3xl bg-slate-900 text-white">
                <div className="text-center">
                  <PhoneCall size={42} className="mx-auto opacity-90" />
                  <p className="mt-3 text-lg font-black">
                    {callSession.status === "connecting"
                      ? "Calling..."
                      : "Audio call live"}
                  </p>
                  <p className="text-sm font-bold text-slate-300">
                    {formatCallDuration(callSession.duration)}
                  </p>
                </div>
              </div>
            )}

            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleToggleMic}
                className={`grid h-11 w-11 place-items-center rounded-2xl ${
                  callSession.micOn
                    ? "bg-slate-100 text-slate-700"
                    : "bg-amber-100 text-amber-700"
                }`}
              >
                {callSession.micOn ? <Mic size={18} /> : <MicOff size={18} />}
              </button>

              {callSession.type === "video" ? (
                <button
                  type="button"
                  onClick={handleToggleCamera}
                  className={`grid h-11 w-11 place-items-center rounded-2xl ${
                    callSession.cameraOn
                      ? "bg-slate-100 text-slate-700"
                      : "bg-amber-100 text-amber-700"
                  }`}
                >
                  {callSession.cameraOn ? (
                    <Video size={19} />
                  ) : (
                    <VideoOff size={19} />
                  )}
                </button>
              ) : null}

              <button
                type="button"
                onClick={handleEndCall}
                className="grid h-12 w-12 place-items-center rounded-2xl bg-rose-600 text-white"
              >
                <PhoneCall size={20} />
              </button>
            </div>

            {callSession.mediaError ? (
              <p className="mt-3 text-center text-xs font-bold text-amber-700">
                Browser mic/camera permission blocked. This is running in demo
                mode.
              </p>
            ) : null}
          </div>
        </div>
      ) : null}
    </section>
  );
};

export default DoctorMessagesPage;
