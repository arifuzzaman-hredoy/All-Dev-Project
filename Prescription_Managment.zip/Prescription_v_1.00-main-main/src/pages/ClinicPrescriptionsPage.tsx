import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { useLocation } from "react-router-dom";
import {
  CalendarClock,
  CheckCircle2,
  ClipboardCheck,
  Eye,
  FileText,
  Filter,
  Pill,
  Phone,
  Search,
  ShieldCheck,
  Stethoscope,
  Trash2,
  UploadCloud,
  UserPlus,
  X,
  type LucideIcon,
} from "lucide-react";

type PrescriptionType =
  | "New"
  | "Follow-up"
  | "Repeat"
  | "Emergency"
  | "Report Review";

type PrescriptionStatus =
  | "Draft"
  | "Pending Review"
  | "Reviewed"
  | "Delivered"
  | "Cancelled";

type UploadStatus = "No Upload" | "Uploaded" | "Reviewed";

type ClinicPrescription = {
  id: string;
  rxNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  doctorName: string;
  specialization: string;
  prescriptionDate: string;
  type: PrescriptionType;
  diagnosis: string;
  medicines: string;
  dosageNote: string;
  advice: string;
  followUpDate: string;
  uploadName: string;
  uploadStatus: UploadStatus;
  status: PrescriptionStatus;
};

const prescriptionTypes: PrescriptionType[] = [
  "New",
  "Follow-up",
  "Repeat",
  "Emergency",
  "Report Review",
];

const prescriptionStatuses: PrescriptionStatus[] = [
  "Draft",
  "Pending Review",
  "Reviewed",
  "Delivered",
  "Cancelled",
];

const uploadStatuses: UploadStatus[] = ["No Upload", "Uploaded", "Reviewed"];

const mockPrescriptions: ClinicPrescription[] = [
  {
    id: "RX-ID-1001",
    rxNo: "RX-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    prescriptionDate: "2026-06-20",
    type: "Follow-up",
    diagnosis: "Migraine follow-up",
    medicines: "Tab. Paracetamol 500mg, Cap. Omeprazole 20mg",
    dosageNote: "After meal, 2 times daily for 5 days",
    advice: "Hydration, proper sleep, avoid trigger food",
    followUpDate: "2026-07-05",
    uploadName: "rx-nusrat-1001.pdf",
    uploadStatus: "Reviewed",
    status: "Delivered",
  },
  {
    id: "RX-ID-1002",
    rxNo: "RX-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    specialization: "Cardiology",
    prescriptionDate: "2026-06-20",
    type: "New",
    diagnosis: "Hypertension observation",
    medicines: "Tab. Amlodipine 5mg",
    dosageNote: "Once daily at night",
    advice: "BP chart maintain, low salt diet",
    followUpDate: "2026-06-27",
    uploadName: "bp-report-rx.pdf",
    uploadStatus: "Uploaded",
    status: "Pending Review",
  },
  {
    id: "RX-ID-1003",
    rxNo: "RX-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    doctorName: "Dr. Nusrat Jahan",
    specialization: "Gynecology",
    prescriptionDate: "2026-06-19",
    type: "Report Review",
    diagnosis: "Report reviewed",
    medicines: "Continue previous medication",
    dosageNote: "As previously advised",
    advice: "Follow-up after report completion",
    followUpDate: "2026-07-01",
    uploadName: "",
    uploadStatus: "No Upload",
    status: "Reviewed",
  },
];

const emptyForm = {
  patientId: "",
  patientName: "",
  phone: "",
  doctorName: "",
  specialization: "",
  prescriptionDate: "",
  type: "New" as PrescriptionType,
  diagnosis: "",
  medicines: "",
  dosageNote: "",
  advice: "",
  followUpDate: "",
  uploadName: "",
  uploadStatus: "No Upload" as UploadStatus,
  status: "Draft" as PrescriptionStatus,
};

const statusClass: Record<PrescriptionStatus, string> = {
  Draft: "border-slate-200 bg-slate-50 text-slate-600",
  "Pending Review": "border-amber-200 bg-amber-50 text-amber-700",
  Reviewed: "border-blue-200 bg-blue-50 text-blue-700",
  Delivered: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Cancelled: "border-rose-200 bg-rose-50 text-rose-700",
};

const typeClass: Record<PrescriptionType, string> = {
  New: "border-teal-200 bg-teal-50 text-teal-800",
  "Follow-up": "border-cyan-200 bg-cyan-50 text-cyan-700",
  Repeat: "border-violet-200 bg-violet-50 text-violet-700",
  Emergency: "border-rose-200 bg-rose-50 text-rose-700",
  "Report Review": "border-indigo-200 bg-indigo-50 text-indigo-700",
};

const uploadClass: Record<UploadStatus, string> = {
  "No Upload": "border-slate-200 bg-slate-50 text-slate-500",
  Uploaded: "border-amber-200 bg-amber-50 text-amber-700",
  Reviewed: "border-emerald-200 bg-emerald-50 text-emerald-700",
};

const localFilter = (
  items: ClinicPrescription[],
  filters: {
    query: string;
    doctor: string;
    specialization: string;
    status: string;
    type: string;
    uploadStatus: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.rxNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.doctorName} ${item.specialization} ${item.type} ${item.status} ${item.uploadStatus} ${item.diagnosis} ${item.medicines} ${item.advice}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.doctor || item.doctorName === filters.doctor) &&
      (!filters.specialization ||
        item.specialization === filters.specialization) &&
      (!filters.status || item.status === filters.status) &&
      (!filters.type || item.type === filters.type) &&
      (!filters.uploadStatus || item.uploadStatus === filters.uploadStatus)
    );
  });
};

const loadPrescriptions = async (
  filters = {
    query: "",
    doctor: "",
    specialization: "",
    status: "",
    type: "",
    uploadStatus: "",
  },
  fallback = mockPrescriptions,
): Promise<ClinicPrescription[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.doctor) params.set("doctor", filters.doctor);
    if (filters.specialization) {
      params.set("specialization", filters.specialization);
    }
    if (filters.status) params.set("status", filters.status);
    if (filters.type) params.set("type", filters.type);
    if (filters.uploadStatus) params.set("uploadStatus", filters.uploadStatus);

    const url = params.toString()
      ? `/api/clinic/prescriptions?${params.toString()}`
      : "/api/clinic/prescriptions";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as {
      prescriptions?: ClinicPrescription[];
    };

    return Array.isArray(data.prescriptions)
      ? data.prescriptions
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createPrescriptionApi = async (
  payload: Omit<ClinicPrescription, "id" | "rxNo">,
): Promise<ClinicPrescription> => {
  const response = await fetch("/api/clinic/prescriptions", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create prescription failed");

  const data = (await response.json()) as {
    prescription?: ClinicPrescription;
  };

  if (!data.prescription) throw new Error("Invalid prescription response");

  return data.prescription;
};

const updatePrescriptionStatusApi = async (
  id: string,
  status: PrescriptionStatus,
): Promise<ClinicPrescription> => {
  const response = await fetch(`/api/clinic/prescriptions/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update prescription status failed");

  const data = (await response.json()) as {
    prescription?: ClinicPrescription;
  };

  if (!data.prescription) throw new Error("Invalid status response");

  return data.prescription;
};

const deletePrescriptionApi = async (id: string) => {
  const response = await fetch(`/api/clinic/prescriptions/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete prescription failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicPrescriptionsPage = () => {
  const location = useLocation();
  const [prescriptions, setPrescriptions] =
    useState<ClinicPrescription[]>(mockPrescriptions);
  const [visiblePrescriptions, setVisiblePrescriptions] =
    useState<ClinicPrescription[]>(mockPrescriptions);
  const [selectedPrescription, setSelectedPrescription] =
    useState<ClinicPrescription | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [specializationFilter, setSpecializationFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [uploadFilter, setUploadFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      doctor: doctorFilter,
      specialization: specializationFilter,
      status: statusFilter,
      type: typeFilter,
      uploadStatus: uploadFilter,
    }),
    [
      query,
      doctorFilter,
      specializationFilter,
      statusFilter,
      typeFilter,
      uploadFilter,
    ],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(prescriptions.map((item) => item.doctorName))),
    [prescriptions],
  );

  const specializationOptions = useMemo(
    () => Array.from(new Set(prescriptions.map((item) => item.specialization))),
    [prescriptions],
  );

  const formReady =
    form.patientId.trim().length >= 2 &&
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    form.doctorName.trim().length >= 2 &&
    form.specialization.trim().length >= 2 &&
    form.prescriptionDate.trim().length >= 4 &&
    form.diagnosis.trim().length >= 2 &&
    form.medicines.trim().length >= 2 &&
    form.dosageNote.trim().length >= 2 &&
    form.advice.trim().length >= 2;

  useEffect(() => {
    let active = true;

    loadPrescriptions().then((data) => {
      if (!active) return;
      setPrescriptions(data);
      setVisiblePrescriptions(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const statePatient = (location.state as { patient?: Record<string, unknown> } | null)
      ?.patient;
    const storedPatient = sessionStorage.getItem("clinic-active-patient");
    const patient =
      statePatient ||
      (storedPatient ? (JSON.parse(storedPatient) as Record<string, unknown>) : null);

    if (!patient) return;

    const today = new Date().toISOString().slice(0, 10);
    const prescriptionType =
      patient.type === "Emergency" ||
      patient.type === "Follow-up" ||
      patient.type === "Report Review"
        ? patient.type
        : "New";

    setForm((prev) => ({
      ...prev,
      patientId: String(patient.patientId || patient.appointmentId || ""),
      patientName: String(patient.patientName || ""),
      phone: String(patient.phone || ""),
      doctorName: String(patient.doctorName || ""),
      specialization: String(patient.specialization || ""),
      prescriptionDate: prev.prescriptionDate || today,
      type: prescriptionType as PrescriptionType,
      diagnosis: String(patient.problem || prev.diagnosis),
    }));
    setAddOpen(true);
    setMessage("Appointment patient details loaded into prescription form.");
  }, [location.state]);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadPrescriptions(filters, prescriptions).then((data) => {
        if (!active) return;
        setVisiblePrescriptions(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, prescriptions]);

  const stats = useMemo(
    () => [
      {
        label: "Total RX",
        value: String(prescriptions.length),
        icon: FileText,
      },
      {
        label: "Pending",
        value: String(
          prescriptions.filter((item) => item.status === "Pending Review")
            .length,
        ),
        icon: CalendarClock,
      },
      {
        label: "Reviewed",
        value: String(
          prescriptions.filter((item) => item.status === "Reviewed").length,
        ),
        icon: ClipboardCheck,
      },
      {
        label: "Delivered",
        value: String(
          prescriptions.filter((item) => item.status === "Delivered").length,
        ),
        icon: CheckCircle2,
      },
    ],
    [prescriptions],
  );

  const syncPrescriptions = (nextPrescriptions: ClinicPrescription[]) => {
    setPrescriptions(nextPrescriptions);
    setVisiblePrescriptions(localFilter(nextPrescriptions, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setDoctorFilter("");
    setSpecializationFilter("");
    setStatusFilter("");
    setTypeFilter("");
    setUploadFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Prescription full form complete korle Add RX button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      patientId: form.patientId.trim(),
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      doctorName: form.doctorName.trim(),
      specialization: form.specialization.trim(),
      prescriptionDate: form.prescriptionDate.trim(),
      type: form.type,
      diagnosis: form.diagnosis.trim(),
      medicines: form.medicines.trim(),
      dosageNote: form.dosageNote.trim(),
      advice: form.advice.trim(),
      followUpDate: form.followUpDate.trim() || "Not scheduled",
      uploadName: form.uploadName.trim(),
      uploadStatus: form.uploadName.trim()
        ? form.uploadStatus === "No Upload"
          ? "Uploaded"
          : form.uploadStatus
        : form.uploadStatus,
      status: form.status,
    };

    const fallbackPrescription: ClinicPrescription = {
      id: `RX-ID-${Date.now()}`,
      rxNo: `RX-${String(prescriptions.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdPrescription = await createPrescriptionApi(payload);
      syncPrescriptions([createdPrescription, ...prescriptions]);
      setMessage("Prescription added successfully.");
    } catch {
      syncPrescriptions([fallbackPrescription, ...prescriptions]);
      setMessage(
        "Prescription added locally. Backend route connect korle database save hobe.",
      );
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    prescription: ClinicPrescription,
    status: PrescriptionStatus,
  ) => {
    const previousPrescriptions = prescriptions;

    const nextPrescriptions = prescriptions.map((item) =>
      item.id === prescription.id ? { ...item, status } : item,
    );

    syncPrescriptions(nextPrescriptions);
    setMessage("");

    try {
      const updatedPrescription = await updatePrescriptionStatusApi(
        prescription.id,
        status,
      );

      syncPrescriptions(
        nextPrescriptions.map((item) =>
          item.id === updatedPrescription.id ? updatedPrescription : item,
        ),
      );
    } catch {
      syncPrescriptions(previousPrescriptions);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemovePrescription = async (prescription: ClinicPrescription) => {
    const previousPrescriptions = prescriptions;
    const nextPrescriptions = prescriptions.filter(
      (item) => item.id !== prescription.id,
    );

    syncPrescriptions(nextPrescriptions);
    setMessage("");

    try {
      await deletePrescriptionApi(prescription.id);
      setMessage("Prescription removed successfully.");
    } catch {
      syncPrescriptions(previousPrescriptions);
      setMessage("Backend delete failed, prescription restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Prescriptions
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Preview prescription activity, uploads, reviews and
                patient-linked records.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading prescriptions from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/filter/view/status/remove functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add RX
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_180px_180px_160px_150px_150px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search RX, patient, doctor, diagnosis, medicine"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <select
              value={specializationFilter}
              onChange={(event) => setSpecializationFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Specialities</option>
              {specializationOptions.map((speciality) => (
                <option key={speciality} value={speciality}>
                  {speciality}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {prescriptionStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Type</option>
              {prescriptionTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <select
              value={uploadFilter}
              onChange={(event) => setUploadFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Upload</option>
              {uploadStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1280px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Patient / RX
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Prescription
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Upload
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visiblePrescriptions.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.rxNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Stethoscope size={14} />
                        {item.doctorName}
                      </p>
                      <p className="mt-1 text-[11px] font-black text-teal-700">
                        {item.specialization}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.prescriptionDate}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <Badge label={item.type} className={typeClass[item.type]} />
                      <p className="mt-1 max-w-[320px] truncate text-xs font-black text-slate-700">
                        {item.diagnosis}
                      </p>
                      <p className="mt-1 max-w-[320px] truncate text-[11px] font-bold text-slate-500">
                        {item.medicines}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-xs font-black text-slate-700">
                        <UploadCloud size={13} />
                        {item.uploadName || "No file"}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.uploadStatus}
                          className={uploadClass[item.uploadStatus]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as PrescriptionStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {prescriptionStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedPrescription(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Reviewed")}
                          className="inline-flex items-center gap-1 border border-blue-100 bg-blue-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-blue-700 transition hover:border-blue-200 hover:bg-blue-100"
                        >
                          <ShieldCheck size={13} />
                          Review
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Delivered")}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100"
                        >
                          <CheckCircle2 size={13} />
                          Done
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemovePrescription(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visiblePrescriptions.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No prescription found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <Pill size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedPrescription && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Prescription Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedPrescription.rxNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedPrescription.patientName} ·{" "}
                  {selectedPrescription.type}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedPrescription(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                [
                  "Patient",
                  `${selectedPrescription.patientName} (${selectedPrescription.patientId})`,
                ],
                ["Phone", selectedPrescription.phone],
                ["Doctor", selectedPrescription.doctorName],
                ["Speciality", selectedPrescription.specialization],
                ["Date", selectedPrescription.prescriptionDate],
                ["Follow-up", selectedPrescription.followUpDate],
                ["Status", selectedPrescription.status],
                ["Upload", selectedPrescription.uploadName || "No file"],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              {[
                ["Diagnosis", selectedPrescription.diagnosis],
                ["Medicines", selectedPrescription.medicines],
                ["Dosage Note", selectedPrescription.dosageNote],
                ["Advice", selectedPrescription.advice],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3 md:col-span-2"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                    {value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Prescription
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New prescription record
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient, doctor, medicine, dosage and review status fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient ID">
                  <input
                    value={form.patientId}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        patientId: event.target.value,
                      }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        patientName: event.target.value,
                      }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        phone: event.target.value,
                      }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Doctor Name">
                  <input
                    value={form.doctorName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        doctorName: event.target.value,
                      }))
                    }
                    placeholder="Dr. Abdullah Rahman"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Specialization">
                  <input
                    value={form.specialization}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        specialization: event.target.value,
                      }))
                    }
                    placeholder="Medicine / Cardiology"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Prescription Date">
                  <input
                    value={form.prescriptionDate}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        prescriptionDate: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Type">
                  <select
                    value={form.type}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        type: event.target.value as PrescriptionType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {prescriptionTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as PrescriptionStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {prescriptionStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Follow-up Date">
                  <input
                    value={form.followUpDate}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        followUpDate: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Upload File Name">
                  <input
                    value={form.uploadName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        uploadName: event.target.value,
                      }))
                    }
                    placeholder="rx-file.pdf"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Upload Status">
                  <select
                    value={form.uploadStatus}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        uploadStatus: event.target.value as UploadStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {uploadStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Diagnosis">
                  <input
                    value={form.diagnosis}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        diagnosis: event.target.value,
                      }))
                    }
                    placeholder="Diagnosis"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Medicines">
                  <input
                    value={form.medicines}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        medicines: event.target.value,
                      }))
                    }
                    placeholder="Tab. Napa 500mg, Cap. Omeprazole"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Dosage Note">
                  <input
                    value={form.dosageNote}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        dosageNote: event.target.value,
                      }))
                    }
                    placeholder="After meal, 2 times daily"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Advice">
                  <input
                    value={form.advice}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        advice: event.target.value,
                      }))
                    }
                    placeholder="Rest, hydration, follow-up after 7 days"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Prescription form complete. Add RX button enabled."
                  : "Patient + doctor + diagnosis + medicines + dosage + advice complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add RX"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicPrescriptionsPage;
