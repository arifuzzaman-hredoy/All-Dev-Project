import { useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CheckCircle2, Printer, Save, UploadCloud, XCircle } from "lucide-react";
import GlassCard from "../../components/common/GlassCard";
import ConsultationNotesForm from "../../components/prescription/ConsultationNotesForm";
import {
  addPrescriptionAttachments,
  fileToPrescriptionPayload,
  publishPrescription,
  savePrescription,
} from "../../services/prescriptionApi";
import { useDoctorIdentity } from "../../hooks/useDoctorIdentity";

const ACTIVE_PATIENT_KEY = "active_prescription_patient";

const today = () => new Date().toISOString().slice(0, 10);

const readStoredPatient = () => {
  if (typeof window === "undefined") return null;
  try {
    const saved = window.sessionStorage.getItem(ACTIVE_PATIENT_KEY);
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
};

const normalizePatient = (patient = {}) => ({
  id: patient.id || patient.patientId || "",
  serial: patient.serial || patient.appointmentId || "",
  name: patient.name || patient.patientName || "",
  age: patient.age ? String(patient.age) : "",
  gender: patient.gender || "",
  phone: patient.phone || patient.mobile || "",
  problem: patient.problem || patient.complaint || patient.chiefComplaint || "",
  time: patient.time || patient.timeSlot || "",
  diagnosis: patient.diagnosis || patient.problem || patient.complaint || "",
});

const createInitialNotes = (patient) => {
  const selected = patient ? normalizePatient(patient) : null;
  return {
    patientName: selected?.name || "",
    patientId: selected?.id || "",
    appointmentId: selected?.serial || "",
    mobile: selected?.phone || "",
    age: selected?.age || "",
    gender: selected?.gender || "",
    weight: "",
    date: today(),
    chiefComplaint: selected?.problem || "",
    history: "",
    onExamination: "",
    diagnosis: selected?.diagnosis || "",
    advice: "",
    notes: "",
    finalAdvice: "",
    followUpDate: "",
    medicines: [{ name: "", dose: "1+0+1", duration: "7 din", instruction: "" }],
  };
};

const buildPayload = (notes) => ({
  patientId: notes.patientId,
  phone: notes.mobile,
  patientName: notes.patientName,
  appointmentId: notes.appointmentId,
  age: notes.age,
  gender: notes.gender,
  prescriptionDate: notes.date || today(),
  title: notes.diagnosis || notes.chiefComplaint || "Prescription",
  chiefComplaint: notes.chiefComplaint,
  diagnosis: notes.diagnosis,
  medicines: notes.medicines || [],
  advice: notes.finalAdvice || notes.advice || "",
  notes: notes.notes,
  followUpDate: notes.followUpDate || "",
  templateData: notes,
});

const PrescriptionPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const printRef = useRef(null);
  const patientFromRoute = location.state?.patient;
  const patientFromStorage = useMemo(() => (patientFromRoute ? null : readStoredPatient()), [patientFromRoute]);
  const activePatient = patientFromRoute || patientFromStorage;
  const { identity } = useDoctorIdentity();
  const [notes, setNotes] = useState(() => createInitialNotes(activePatient));
  const [savedId, setSavedId] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [notice, setNotice] = useState(null);
  const [saving, setSaving] = useState(false);

  const showNotice = (message, tone = "success") => {
    setNotice({ message, tone });
    window.setTimeout(() => setNotice(null), 3600);
  };

  const updateNote = (key, value) => {
    setNotice(null);
    setNotes((prev) => ({ ...prev, [key]: value }));
  };

  const save = async () => {
    setSaving(true);
    try {
      const item = await savePrescription({
        ...buildPayload(notes),
        doctorName: identity.doctorName,
      });
      if (attachments.length) {
        await addPrescriptionAttachments(item.id, attachments);
      }
      setSavedId(item.id);
      showNotice("Prescription saved successfully.");
      return item;
    } catch (error) {
      showNotice(error.message || "Prescription save failed.", "error");
      return null;
    } finally {
      setSaving(false);
    }
  };

  const upload = async () => {
    const saved = savedId ? { id: savedId } : await save();
    if (!saved?.id) return;
    try {
      if (savedId && attachments.length) {
        await addPrescriptionAttachments(saved.id, attachments);
      }
      const item = await publishPrescription(saved.id, {
        ...buildPayload(notes),
        doctorName: identity.doctorName,
      });
      setSavedId(item.id);
      showNotice("Prescription uploaded successfully.");
      window.dispatchEvent(new Event("prescriptions-updated"));
    } catch (error) {
      showNotice(error.message || "Prescription upload failed.", "error");
    }
  };

  const addAttachmentFiles = async (files) => {
    const selected = Array.from(files || []);
    const payloads = await Promise.all(
      selected.map(async (file) => ({
        file: await fileToPrescriptionPayload(file),
        title: file.name,
        note: "",
      })),
    );
    setAttachments((prev) => [...prev, ...payloads]);
  };

  const removeAttachment = (index) => {
    setAttachments((prev) => prev.filter((_, itemIndex) => itemIndex !== index));
  };

  const print = () => {
    window.print();
  };

  return (
    <section className="mx-auto grid max-w-6xl gap-3">
      <style>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 0;
          }

          html,
          body {
            width: 297mm !important;
            height: 210mm !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
            background: #ffffff !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body * {
            visibility: hidden !important;
          }

          #prescription-print-area,
          #prescription-print-area * {
            visibility: visible !important;
          }

          #prescription-print-area {
            position: fixed !important;
            inset: 0 !important;
            width: 297mm !important;
            height: 210mm !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
            border: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
            background: #fffdf8 !important;
          }

          .no-print {
            display: none !important;
          }

          .prescription-form-root,
          .prescription-sheet {
            width: 297mm !important;
            max-width: none !important;
            height: 202mm !important;
            min-height: 202mm !important;
            margin: 0 !important;
            overflow: hidden !important;
            border-radius: 0 !important;
            box-shadow: none !important;
            background: #fffdf8 !important;
          }

          .prescription-soft-bg {
            display: none !important;
          }

          .prescription-sheet {
            border: 0 !important;
            border-top: 1.6mm solid #2a7fa6 !important;
          }

          .prescription-header {
            min-height: 30mm !important;
            padding: 3mm 6mm 3mm 6mm !important;
          }

          .prescription-header p {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          .prescription-patient-grid {
            display: grid !important;
            grid-template-columns: 1.35fr 1fr 0.72fr 0.72fr 1.45fr 1.15fr !important;
            min-height: 9mm !important;
            font-size: 10px !important;
            line-height: 1.2 !important;
          }

          .prescription-patient-grid label {
            border-bottom: 0 !important;
            padding: 1.6mm 3mm !important;
          }

          .prescription-body {
            display: grid !important;
            grid-template-columns: 64mm 1fr !important;
            min-height: 158mm !important;
            height: 158mm !important;
          }

          .prescription-left-panel {
            padding: 4mm !important;
            border-right: 1px solid #d4e6e8 !important;
            border-bottom: 0 !important;
          }

          .prescription-rx-panel {
            padding: 5mm 7mm !important;
          }

          #prescription-print-area input,
          #prescription-print-area textarea {
            border: 0 !important;
            box-shadow: none !important;
            resize: none !important;
            background-color: transparent !important;
            color: inherit !important;
            opacity: 1 !important;
            -webkit-text-fill-color: currentColor !important;
          }

          #prescription-print-area textarea {
            overflow: hidden !important;
          }

          #prescription-print-area button {
            display: none !important;
          }

          .digital-prescription-footer {
            height: 8mm !important;
            padding: 1.5mm 0 0 0 !important;
            background: #fffdf8 !important;
            font-size: 10px !important;
            line-height: 1.2 !important;
          }
        }
      `}</style>

      <GlassCard className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-wider text-cyan-600">Prescription</p>
          <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-900">
            {activePatient ? `Create Rx for ${normalizePatient(activePatient).name || "selected patient"}` : "Blank Prescription Template"}
          </h2>
          <p className="mt-1 text-sm font-semibold text-slate-500">
            Save keeps it pending. Upload publishes it for public secure download.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={save} disabled={saving} className="inline-flex min-h-10 items-center gap-2 rounded-full bg-teal-700 px-4 text-sm font-black text-white shadow-sm transition hover:bg-teal-800 disabled:opacity-60">
            <Save size={16} /> {saving ? "Saving..." : "Save"}
          </button>
          <button type="button" onClick={print} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-teal-100 bg-white/80 px-4 text-sm font-black text-teal-800 shadow-sm transition hover:bg-cyan-50">
            <Printer size={16} /> Print
          </button>
          <button type="button" onClick={upload} className="inline-flex min-h-10 items-center gap-2 rounded-full bg-blue-700 px-4 text-sm font-black text-white shadow-sm transition hover:bg-blue-800">
            <UploadCloud size={16} /> Upload
          </button>
          <button type="button" onClick={() => navigate("/doctor/upload-prescription")} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-cyan-100 bg-white/80 px-4 text-sm font-black text-slate-600 shadow-sm transition hover:bg-cyan-50">
            Upload Table
          </button>
        </div>
      </GlassCard>

      {notice ? (
        <div className={`no-print flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm font-black ${notice.tone === "success" ? "border-emerald-100 bg-emerald-50 text-emerald-700" : "border-rose-100 bg-rose-50 text-rose-700"}`}>
          {notice.tone === "success" ? <CheckCircle2 size={17} /> : <XCircle size={17} />}
          {notice.message}
        </div>
      ) : null}

      <div id="prescription-print-area" ref={printRef} className="overflow-hidden rounded-[1.5rem] border border-teal-100 bg-white/80 p-2 shadow-[0_12px_40px_rgba(11,86,90,0.12)]">
        <ConsultationNotesForm values={notes} onChange={updateNote} identity={identity} />
        <div className="digital-prescription-footer bg-[#fffdf8] px-6 pb-5 text-center text-xs font-bold text-slate-500">
          {identity.prescriptionFooterNote || "This is a digital prescription / এটি একটি ডিজিটাল প্রেসক্রিপশন।"}
        </div>
      </div>

      <GlassCard className="no-print">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-black text-slate-900">Reports & Attachments</h3>
            <p className="mt-1 text-sm font-semibold text-slate-500">
              Add lab reports, X-rays, previous PDFs, or image reports before saving.
            </p>
          </div>
          <label className="inline-flex min-h-10 cursor-pointer items-center justify-center rounded-full border border-cyan-100 bg-white px-4 text-sm font-black text-teal-700 transition hover:bg-cyan-50">
            Add report
            <input
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
              onChange={(event) => addAttachmentFiles(event.target.files)}
            />
          </label>
        </div>

        <div className="mt-4 grid gap-2">
          {attachments.map((attachment, index) => (
            <div key={`${attachment.file.fileName}-${index}`} className="flex items-center justify-between gap-3 rounded-2xl border border-cyan-100 bg-cyan-50/45 px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-black text-slate-900">{attachment.title}</p>
                <p className="text-xs font-bold text-slate-500">{attachment.file.mimeType}</p>
              </div>
              <button type="button" onClick={() => removeAttachment(index)} className="rounded-full px-3 py-1 text-xs font-black text-rose-600 hover:bg-rose-50">
                Remove
              </button>
            </div>
          ))}
          {!attachments.length ? (
            <div className="rounded-2xl border border-dashed border-cyan-100 bg-cyan-50/40 p-4 text-sm font-bold text-slate-500">
              No attachment selected.
            </div>
          ) : null}
        </div>
      </GlassCard>
    </section>
  );
};

export default PrescriptionPage;
