export { default } from "../DoctorPanelSettingsPage";
