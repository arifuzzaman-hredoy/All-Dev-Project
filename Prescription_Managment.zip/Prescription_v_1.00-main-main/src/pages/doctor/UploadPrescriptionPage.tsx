import { useCallback, useEffect, useMemo, useState } from "react";
import type { ElementType } from "react";
import { useLocation } from "react-router-dom";
import {
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  FileSpreadsheet,
  FileText,
  Filter,
  ListChecks,
  PlusCircle,
  RefreshCcw,
  Search,
  UploadCloud,
  UserRound,
  XCircle,
} from "lucide-react";
import BulkPrescriptionUploadTable from "../../components/doctor/prescriptions/BulkPrescriptionUploadTable";
import PrescriptionListTable from "../../components/doctor/prescriptions/PrescriptionListTable";
import PrescriptionUploadForm from "../../components/doctor/prescriptions/PrescriptionUploadForm";
import { getPrescriptions } from "../../services/prescriptionApi";
import type { PrescriptionItem } from "../../types/prescription";
import { apiFetch } from "../../lib/apiClient";
import { getAdminUser } from "../../lib/adminAuth";

type PermissionState = {
  canCreate: boolean;
  canDelete: boolean;
};

type NoticeState = {
  message: string;
  tone: "success" | "error";
};

type ActivePanel = "manual" | "bulk" | "list";

type RoutePatientState = {
  patient?: {
    id?: string;
    patientId?: string;
    patientName?: string;
    name?: string;
    phone?: string;
    appointmentId?: string;
    serial?: string;
  };
};

const PRESCRIPTION_REFRESH_EVENT = "prescriptions-updated";

const getRecordValue = (
  item: PrescriptionItem,
  keys: string[],
  fallback = ""
) => {
  const record = item as unknown as Record<string, unknown>;

  for (const key of keys) {
    const value = record[key];

    if (value !== undefined && value !== null && String(value).trim() !== "") {
      return String(value);
    }
  }

  return fallback;
};

const getItemId = (item: PrescriptionItem) => {
  return getRecordValue(item, ["id", "_id", "prescriptionId"], "");
};

const getPatientName = (item: PrescriptionItem) => {
  return getRecordValue(
    item,
    ["patientName", "name", "patient", "fullName"],
    "Unknown Patient"
  );
};

const getPatientId = (item: PrescriptionItem) => {
  return getRecordValue(
    item,
    ["patientId", "patientID", "serialNo", "registrationNo"],
    "-"
  );
};

const getPhone = (item: PrescriptionItem) => {
  return getRecordValue(item, ["phone", "mobile", "phoneNumber", "contact"], "-");
};

const getCategory = (item: PrescriptionItem) => {
  return getRecordValue(
    item,
    ["category", "type", "department", "prescriptionType"],
    "General"
  );
};

const getStatus = (item: PrescriptionItem) => {
  return getRecordValue(item, ["status", "uploadStatus"], "Uploaded");
};

const getCreatedDate = (item: PrescriptionItem) => {
  const raw = getRecordValue(
    item,
    ["createdAt", "uploadedAt", "date", "prescriptionDate"],
    ""
  );

  if (!raw) return "";

  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) return raw.slice(0, 10);

  return date.toISOString().slice(0, 10);
};

const formatDate = (value: string) => {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const UploadPrescriptionPage = () => {
  const location = useLocation();
  const routeState = location.state as RoutePatientState | null;

  const initialPatient = routeState?.patient
    ? {
        patientId: routeState.patient.patientId || routeState.patient.id || "",
        patientName:
          routeState.patient.patientName || routeState.patient.name || "",
        phone: routeState.patient.phone || "",
        appointmentId:
          routeState.patient.appointmentId || routeState.patient.serial || "",
      }
    : null;

  const [items, setItems] = useState<PrescriptionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activePanel, setActivePanel] = useState<ActivePanel>("manual");
  const [permission, setPermission] = useState<PermissionState>({
    canCreate: true,
    canDelete: true,
  });
  const [notice, setNotice] = useState<NoticeState | null>(null);

  const [query, setQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const showNotice = (
    message: string,
    tone: "success" | "error" = "success"
  ) => {
    setNotice({ message, tone });
    window.setTimeout(() => setNotice(null), 3600);
  };

  const refresh = useCallback((withLoading = true) => {
    if (withLoading) setLoading(true);

    return getPrescriptions()
      .then((data) => {
        setItems(Array.isArray(data) ? data : []);
      })
      .catch((error) => {
        showNotice(error.message || "Could not load prescriptions.", "error");
      })
      .finally(() => {
        if (withLoading) setLoading(false);
      });
  }, []);

  useEffect(() => {
    const role = getAdminUser()?.role || "SUPER_ADMIN";

    apiFetch("/api/access-control")
      .then((response) => {
        const saved = response.data?.permissions?.[role]?.prescriptions;

        if (saved) {
          setPermission({
            canCreate: Boolean(saved.canCreate) && !saved.restricted,
            canDelete: Boolean(saved.canDelete) && !saved.restricted,
          });
        }
      })
      .catch(() => null);

    getPrescriptions()
      .then((data) => {
        setItems(Array.isArray(data) ? data : []);
      })
      .catch((error) => {
        showNotice(error.message || "Could not load prescriptions.", "error");
      })
      .finally(() => setLoading(false));

    const timer = window.setInterval(() => refresh(false), 25000);

    const realtimeRefresh = () => {
      refresh(false);
    };

    window.addEventListener(PRESCRIPTION_REFRESH_EVENT, realtimeRefresh);
    window.addEventListener("storage", realtimeRefresh);

    return () => {
      window.clearInterval(timer);
      window.removeEventListener(PRESCRIPTION_REFRESH_EVENT, realtimeRefresh);
      window.removeEventListener("storage", realtimeRefresh);
    };
  }, [refresh]);

  const prependUploaded = (uploaded: PrescriptionItem | PrescriptionItem[]) => {
    const list = Array.isArray(uploaded) ? uploaded : [uploaded];

    setItems((prev) => [
      ...list,
      ...prev.filter(
        (item) => !list.some((next) => getItemId(next) === getItemId(item))
      ),
    ]);

    setActivePanel("list");
    setSelectedIds([]);
    showNotice(`${list.length} prescription uploaded successfully.`);

    window.dispatchEvent(new Event(PRESCRIPTION_REFRESH_EVENT));
    window.setTimeout(() => refresh(false), 700);
  };

  const categories = useMemo(() => {
    return Array.from(new Set(items.map(getCategory).filter(Boolean))).sort();
  }, [items]);

  const filteredItems = useMemo(() => {
    const keyword = query.trim().toLowerCase();

    return items.filter((item) => {
      const itemDate = getCreatedDate(item);
      const itemCategory = getCategory(item);

      const matchesDate = dateFilter ? itemDate === dateFilter : true;
      const matchesCategory =
        categoryFilter === "all" ? true : itemCategory === categoryFilter;

      const matchesSearch = keyword
        ? [
            getPatientName(item),
            getPatientId(item),
            getPhone(item),
            getCategory(item),
            getStatus(item),
            itemDate,
          ]
            .join(" ")
            .toLowerCase()
            .includes(keyword)
        : true;

      return matchesDate && matchesCategory && matchesSearch;
    });
  }, [items, query, dateFilter, categoryFilter]);

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);

    return {
      total: items.length,
      today: items.filter((item) => getCreatedDate(item) === today).length,
      category: categories.length,
      visible: filteredItems.length,
    };
  }, [items, categories.length, filteredItems.length]);

  const allVisibleSelected =
    filteredItems.length > 0 &&
    filteredItems.every((item) => selectedIds.includes(getItemId(item)));

  const toggleSelectAllVisible = () => {
    const visibleIds = filteredItems.map(getItemId).filter(Boolean);

    setSelectedIds((prev) => {
      if (allVisibleSelected) {
        return prev.filter((id) => !visibleIds.includes(id));
      }

      return Array.from(new Set([...prev, ...visibleIds]));
    });
  };

  const toggleSelected = (id: string) => {
    if (!id) return;

    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const resetFilters = () => {
    setQuery("");
    setDateFilter("");
    setCategoryFilter("all");
    setSelectedIds([]);
  };

  return (
    <section className="mx-auto grid max-w-7xl gap-3">
      <div className="rounded-[24px] border border-cyan-100 bg-white/90 px-4 py-3 shadow-sm">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <UploadCloud
                size={19}
                className="text-teal-700 transition duration-300 hover:-translate-y-1 hover:rotate-6"
              />
              <p className="text-[11px] font-black uppercase tracking-[0.16em] text-teal-700">
                Prescription
              </p>
            </div>

            <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
              Upload Prescription
            </h1>

            <p className="mt-0.5 text-xs font-semibold text-slate-500">
              Patient select করো, file upload করো, saved list-এ instantly দেখবে।
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatItem title="Total" value={stats.total} icon={FileText} />
            <StatItem title="Today" value={stats.today} icon={CalendarDays} />
            <StatItem title="Category" value={stats.category} icon={Filter} />
            <StatItem title="Showing" value={stats.visible} icon={ListChecks} />
          </div>
        </div>
      </div>

      {notice ? (
        <div
          className={[
            "flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm font-black",
            notice.tone === "success"
              ? "border-emerald-100 bg-emerald-50 text-emerald-700"
              : "border-rose-100 bg-rose-50 text-rose-700",
          ].join(" ")}
        >
          {notice.tone === "success" ? (
            <CheckCircle2 size={17} />
          ) : (
            <XCircle size={17} />
          )}
          {notice.message}
        </div>
      ) : null}

      <div className="rounded-[22px] border border-cyan-100 bg-white/90 px-3 py-3 shadow-sm">
        <div className="grid gap-3 xl:grid-cols-[auto_1fr_auto] xl:items-center">
          <div className="flex flex-wrap gap-2">
            <PanelButton
              active={activePanel === "manual"}
              icon={PlusCircle}
              label="Manual"
              onClick={() => setActivePanel("manual")}
            />

            <PanelButton
              active={activePanel === "bulk"}
              icon={FileSpreadsheet}
              label="Bulk"
              onClick={() => setActivePanel("bulk")}
            />

            <PanelButton
              active={activePanel === "list"}
              icon={ClipboardList}
              label="Saved List"
              onClick={() => setActivePanel("list")}
            />
          </div>

          <div className="grid gap-2 sm:grid-cols-[1fr_155px_170px]">
            <label className="relative">
              <Search
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search name, phone, ID..."
                className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-xs font-bold text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
              />
            </label>

            <input
              type="date"
              value={dateFilter}
              onChange={(event) => setDateFilter(event.target.value)}
              className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
            />

            <select
              value={categoryFilter}
              onChange={(event) => setCategoryFilter(event.target.value)}
              className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
            >
              <option value="all">All Category</option>
              {categories.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={resetFilters}
            className="group inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-600 transition hover:bg-slate-50"
          >
            <RefreshCcw
              size={14}
              className="transition duration-300 group-hover:-rotate-45"
            />
            Reset
          </button>
        </div>
      </div>

      {activePanel === "manual" ? (
        <div className="grid gap-3 xl:grid-cols-[390px_minmax(0,1fr)] xl:items-start">
          <PrescriptionUploadForm
            canUpload={permission.canCreate}
            initialPatient={initialPatient}
            onUploaded={prependUploaded}
            onNotice={showNotice}
          />

          <CompactRegisterTable
            title="Recent Uploads"
            items={filteredItems.slice(0, 8)}
            selectedIds={selectedIds}
            allVisibleSelected={allVisibleSelected}
            loading={loading}
            onSelectAll={toggleSelectAllVisible}
            onToggle={toggleSelected}
          />
        </div>
      ) : null}

      {activePanel === "bulk" ? (
        <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_420px] xl:items-start">
          <BulkPrescriptionUploadTable
            canUpload={permission.canCreate}
            onUploaded={prependUploaded}
            onNotice={showNotice}
          />

          <CompactRegisterTable
            title="Upload Preview"
            items={filteredItems.slice(0, 10)}
            selectedIds={selectedIds}
            allVisibleSelected={allVisibleSelected}
            loading={loading}
            onSelectAll={toggleSelectAllVisible}
            onToggle={toggleSelected}
          />
        </div>
      ) : null}

      {activePanel === "list" ? (
        <div className="grid gap-3">
          <CompactRegisterTable
            title="Saved Prescriptions"
            items={filteredItems}
            selectedIds={selectedIds}
            allVisibleSelected={allVisibleSelected}
            loading={loading}
            onSelectAll={toggleSelectAllVisible}
            onToggle={toggleSelected}
          />

          <PrescriptionListTable
            canDelete={permission.canDelete}
            items={filteredItems}
            onChanged={refresh}
            onNotice={showNotice}
          />
        </div>
      ) : null}
    </section>
  );
};

const StatItem = ({
  title,
  value,
  icon: Icon,
}: {
  title: string;
  value: number;
  icon: ElementType;
}) => {
  return (
    <div className="flex min-w-[90px] items-center gap-2 rounded-2xl border border-cyan-100 bg-cyan-50/50 px-3 py-2">
      <Icon
        size={16}
        className="text-teal-700 transition duration-300 hover:-translate-y-1 hover:rotate-6"
      />
      <div>
        <p className="text-[9px] font-black uppercase tracking-wide text-slate-400">
          {title}
        </p>
        <p className="text-base font-black text-slate-950">{value}</p>
      </div>
    </div>
  );
};

const PanelButton = ({
  active,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: ElementType;
  label: string;
  onClick: () => void;
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "group inline-flex h-10 items-center gap-2 rounded-xl px-3 text-xs font-black transition",
        active
          ? "bg-slate-950 text-white"
          : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50",
      ].join(" ")}
    >
      <Icon
        size={15}
        className="transition duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6"
      />
      {label}
    </button>
  );
};

const CompactRegisterTable = ({
  title,
  items,
  selectedIds,
  allVisibleSelected,
  loading,
  onSelectAll,
  onToggle,
}: {
  title: string;
  items: PrescriptionItem[];
  selectedIds: string[];
  allVisibleSelected: boolean;
  loading: boolean;
  onSelectAll: () => void;
  onToggle: (id: string) => void;
}) => {
  return (
    <div className="overflow-hidden rounded-[24px] border border-cyan-100 bg-white/90 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3">
        <div>
          <h2 className="text-base font-black text-slate-950">{title}</h2>
          <p className="text-xs font-semibold text-slate-500">
            Select করে review করা যাবে। Upload হলে এখানেই জমা হবে।
          </p>
        </div>

        <span className="rounded-full bg-teal-50 px-3 py-1 text-[11px] font-black text-teal-700">
          {selectedIds.length} selected
        </span>
      </div>

      <div className="max-h-[330px] overflow-auto">
        <table className="w-full border-collapse text-left text-xs">
          <thead className="sticky top-0 z-10">
            <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
              <th className="w-10 px-3 py-2">
                <input
                  type="checkbox"
                  checked={allVisibleSelected}
                  onChange={onSelectAll}
                  className="h-4 w-4 accent-teal-600"
                />
              </th>
              <th className="min-w-40 px-3 py-2 font-black">Patient</th>
              <th className="min-w-28 px-3 py-2 font-black">ID</th>
              <th className="min-w-28 px-3 py-2 font-black">Phone</th>
              <th className="min-w-28 px-3 py-2 font-black">Category</th>
              <th className="min-w-28 px-3 py-2 font-black">Date</th>
              <th className="min-w-28 px-3 py-2 font-black">Status</th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-10 text-center text-sm font-black text-slate-400"
                >
                  Loading prescriptions...
                </td>
              </tr>
            ) : items.length ? (
              items.map((item) => {
                const id = getItemId(item);
                const selected = selectedIds.includes(id);

                return (
                  <tr
                    key={id || `${getPatientName(item)}-${getCreatedDate(item)}`}
                    className={[
                      "border-b border-slate-100 transition hover:bg-cyan-50/60",
                      selected ? "bg-cyan-50" : "bg-white",
                    ].join(" ")}
                  >
                    <td className="px-3 py-2">
                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={() => onToggle(id)}
                        className="h-4 w-4 accent-teal-600"
                      />
                    </td>

                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <UserRound
                          size={15}
                          className="text-teal-700 transition duration-300 hover:-translate-y-1 hover:rotate-6"
                        />
                        <span className="font-black text-slate-900">
                          {getPatientName(item)}
                        </span>
                      </div>
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-600">
                      {getPatientId(item)}
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-600">
                      {getPhone(item)}
                    </td>

                    <td className="px-3 py-2">
                      <span className="font-black text-teal-700">
                        {getCategory(item)}
                      </span>
                    </td>

                    <td className="px-3 py-2 font-bold text-slate-500">
                      {formatDate(getCreatedDate(item))}
                    </td>

                    <td className="px-3 py-2">
                      <span className="font-black text-emerald-700">
                        {getStatus(item)}
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-10 text-center text-sm font-black text-slate-400"
                >
                  No prescription found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UploadPrescriptionPage;
