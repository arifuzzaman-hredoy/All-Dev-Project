import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  ChevronDown,
  KeyRound,
  LockKeyhole,
  Mail,
  Pencil,
  RefreshCcw,
  Save,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  UserRound,
  UsersRound,
  XCircle,
} from "lucide-react";
import GlassCard from "../../components/common/GlassCard";

const API_URL = "/api/access-control";
const USER_ACCESS_STORAGE_KEY = "doctor_panel_user_access_assignments";

const roleLabels = {
  SUPER_ADMIN: "Super Admin",
  DOCTOR: "Doctor",
  STAFF: "Staff",
};

const defaultAccounts = [
  {
    id: "default-super-admin",
    userName: "Super Admin",
    userEmail: "admin@doctorpanel.local",
    role: "SUPER_ADMIN",
  },
  {
    id: "default-doctor",
    userName: "Doctor",
    userEmail: "doctor@doctorpanel.local",
    role: "DOCTOR",
  },
  {
    id: "default-staff",
    userName: "Staff",
    userEmail: "staff@doctorpanel.local",
    role: "STAFF",
  },
];

const accessPresets = [
  {
    key: "FULL_ACCESS",
    label: "Full Access",
    text: "Everything allowed.",
  },
  {
    key: "DOCTOR_CLINICAL",
    label: "Doctor Clinical",
    text: "Patients, prescriptions, follow-up, reports.",
  },
  {
    key: "STAFF_FRONT_DESK",
    label: "Staff Front Desk",
    text: "Appointment, messages, limited patient view.",
  },
  {
    key: "READ_ONLY",
    label: "Read Only",
    text: "View only. No create, update, delete.",
  },
  {
    key: "LOCKED_DOWN",
    label: "Locked Down",
    text: "Everything blocked.",
  },
  {
    key: "CUSTOM",
    label: "Custom",
    text: "Manual access selection.",
  },
];

const permissionColumns = [
  { key: "canView", label: "View" },
  { key: "canCreate", label: "Create" },
  { key: "canUpdate", label: "Update" },
  { key: "canDelete", label: "Delete" },
  { key: "restricted", label: "Blocked", danger: true },
];

const assistantFields = [
  {
    key: "enabled",
    label: "Assistant",
    description: "Allow assistant access.",
  },
  {
    key: "canReadPatients",
    label: "Read Patients",
    description: "Read patient info.",
  },
  {
    key: "canWritePrescriptions",
    label: "Write Rx",
    description: "Prepare prescription.",
  },
  {
    key: "canSendMessages",
    label: "Messages",
    description: "Help with replies.",
  },
  {
    key: "canManageSettings",
    label: "Settings",
    description: "Setting actions.",
  },
];

const fallbackFeatures = [
  {
    key: "dashboard",
    label: "Dashboard",
    description: "Main overview, analytics, and quick stats.",
  },
  {
    key: "appointments",
    label: "Appointments",
    description: "Appointment booking, approval, serial, and schedule.",
  },
  {
    key: "patients",
    label: "Patients",
    description: "Patient list, history, profile, and records.",
  },
  {
    key: "prescriptions",
    label: "Prescription",
    description: "Prescription create, save, upload, download, and archive.",
  },
  {
    key: "follow_up",
    label: "Follow Up",
    description: "Follow-up schedule and patient tracking.",
  },
  {
    key: "messages",
    label: "Messages",
    description: "Patient messages, public queries, and replies.",
  },
  {
    key: "reports",
    label: "Reports",
    description: "Medical reports, analytics, and export data.",
  },
  {
    key: "accounts",
    label: "Accounts",
    description: "Billing, invoices, payment, and due management.",
  },
  {
    key: "website_cms",
    label: "Website CMS",
    description: "Public website content management.",
  },
  {
    key: "doctor_profile",
    label: "Doctor Profile",
    description: "Doctor profile, about, chamber, and public details.",
  },
  {
    key: "doctor_blog",
    label: "Doctor Blog",
    description: "Articles, health tips, and blog content.",
  },
  {
    key: "doctor_gallery",
    label: "Doctor Gallery",
    description: "Gallery photos and media management.",
  },
  {
    key: "panel_settings",
    label: "Panel Settings",
    description: "System settings, branding, and configuration.",
  },
  {
    key: "users",
    label: "Users",
    description: "Admin users, staff, and doctor accounts.",
  },
  {
    key: "access_control",
    label: "Access Control",
    description: "Role permissions and restricted panel features.",
  },
];

const inputClass =
  "h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-600 focus:ring-2 focus:ring-teal-100";

const selectClass =
  "h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-100";

const iconClass =
  "shrink-0 text-teal-700 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3";

const createDefaultPermission = (role, featureKey) => {
  if (role === "SUPER_ADMIN") {
    return {
      canView: true,
      canCreate: true,
      canUpdate: true,
      canDelete: true,
      restricted: false,
    };
  }

  if (role === "DOCTOR") {
    const editable = [
      "dashboard",
      "appointments",
      "patients",
      "prescriptions",
      "follow_up",
      "messages",
      "reports",
      "doctor_profile",
      "doctor_blog",
      "doctor_gallery",
    ];

    if (editable.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }

    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
      restricted: true,
    };
  }

  if (role === "STAFF") {
    const editable = ["dashboard", "appointments", "messages"];
    const viewOnly = ["patients", "follow_up", "reports"];

    if (editable.includes(featureKey)) {
      return {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        restricted: false,
      };
    }

    if (viewOnly.includes(featureKey)) {
      return {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
    }
  }

  return {
    canView: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false,
    restricted: true,
  };
};

const createDefaultAssistantAccess = (role) => {
  if (role === "SUPER_ADMIN") {
    return {
      enabled: true,
      canReadPatients: true,
      canWritePrescriptions: true,
      canSendMessages: true,
      canManageSettings: true,
    };
  }

  if (role === "DOCTOR") {
    return {
      enabled: true,
      canReadPatients: true,
      canWritePrescriptions: true,
      canSendMessages: true,
      canManageSettings: false,
    };
  }

  return {
    enabled: false,
    canReadPatients: false,
    canWritePrescriptions: false,
    canSendMessages: false,
    canManageSettings: false,
  };
};

const createFallbackPayload = () => {
  const roles = ["SUPER_ADMIN", "DOCTOR", "STAFF"];
  const permissions = {};
  const assistantAccess = {};

  roles.forEach((role) => {
    permissions[role] = {};

    fallbackFeatures.forEach((feature) => {
      permissions[role][feature.key] = createDefaultPermission(
        role,
        feature.key
      );
    });

    assistantAccess[role] = createDefaultAssistantAccess(role);
  });

  return {
    roles,
    features: fallbackFeatures,
    permissions,
    assistantAccess,
  };
};

const createPermissionSet = (role, presetKey, features) => {
  const next = {};

  features.forEach((feature) => {
    const key = feature.key;

    if (presetKey === "FULL_ACCESS") {
      next[key] = {
        canView: true,
        canCreate: true,
        canUpdate: true,
        canDelete: true,
        restricted: false,
      };
      return;
    }

    if (presetKey === "READ_ONLY") {
      next[key] = {
        canView: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: false,
      };
      return;
    }

    if (presetKey === "LOCKED_DOWN") {
      next[key] = {
        canView: false,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        restricted: true,
      };
      return;
    }

    if (presetKey === "DOCTOR_CLINICAL") {
      next[key] = createDefaultPermission("DOCTOR", key);
      return;
    }

    if (presetKey === "STAFF_FRONT_DESK") {
      next[key] = createDefaultPermission("STAFF", key);
      return;
    }

    next[key] = createDefaultPermission(role, key);
  });

  return next;
};

const loadUserAssignments = () => {
  try {
    const raw = localStorage.getItem(USER_ACCESS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const saveUserAssignments = (items) => {
  localStorage.setItem(USER_ACCESS_STORAGE_KEY, JSON.stringify(items));
};

const getDefaultPresetByRole = (role) => {
  if (role === "SUPER_ADMIN") return "FULL_ACCESS";
  if (role === "DOCTOR") return "DOCTOR_CLINICAL";
  return "STAFF_FRONT_DESK";
};

const createEmptyForm = (features) => {
  const role = "DOCTOR";
  const preset = getDefaultPresetByRole(role);

  return {
    id: "",
    selectedAccountId: "",
    userName: "",
    userEmail: "",
    role,
    preset,
    note: "",
    permissions: createPermissionSet(role, preset, features),
    assistantAccess: createDefaultAssistantAccess(role),
  };
};

const buildPermissionSummary = (permissionSet = {}, features = []) => {
  const total = features.length;
  const allowed = features.filter(
    (feature) => permissionSet?.[feature.key]?.canView
  ).length;
  const restricted = features.filter(
    (feature) => permissionSet?.[feature.key]?.restricted
  ).length;

  return {
    total,
    allowed,
    restricted,
  };
};

const getAllowedFeatureNames = (permissionSet = {}, features = []) => {
  return features
    .filter((feature) => permissionSet?.[feature.key]?.canView)
    .map((feature) => feature.label);
};

const NoticeToast = ({ notice }) => {
  if (!notice) return null;

  const styles = {
    success: "border-emerald-200 bg-emerald-50 text-emerald-700",
    warning: "border-amber-200 bg-amber-50 text-amber-700",
    error: "border-red-200 bg-red-50 text-red-700",
  };

  const Icon =
    notice.type === "success"
      ? CheckCircle2
      : notice.type === "warning"
      ? AlertTriangle
      : XCircle;

  return (
    <div className="fixed right-5 top-5 z-50 w-[min(440px,calc(100vw-40px))]">
      <div
        className={[
          "flex items-start gap-3 rounded-xl border px-4 py-3 text-sm font-black shadow-xl shadow-slate-900/10 backdrop-blur",
          styles[notice.type] || styles.error,
        ].join(" ")}
      >
        <Icon size={18} className="mt-0.5 shrink-0" />
        <span className="leading-5">{notice.text}</span>
      </div>
    </div>
  );
};

const TogglePill = ({ checked, disabled, onChange, danger = false }) => {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={[
        "inline-flex h-8 min-w-[60px] items-center justify-center rounded-lg border px-2 text-[11px] font-black uppercase tracking-wide transition",
        checked && danger
          ? "border-red-300 bg-red-50 text-red-700"
          : checked
          ? "border-emerald-300 bg-emerald-50 text-emerald-700"
          : "border-slate-300 bg-white text-slate-400 hover:bg-slate-50",
        disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer",
      ].join(" ")}
    >
      {checked ? "On" : "Off"}
    </button>
  );
};

const FeaturePermissionRow = ({ feature, row, disabled, onChange, index }) => {
  return (
    <tr className={index % 2 === 0 ? "bg-white" : "bg-slate-50/60"}>
      <td className="sticky left-0 z-10 border-b border-r border-slate-200 bg-inherit px-4 py-3">
        <p className="text-sm font-black text-slate-950">{feature.label}</p>
        <p className="mt-0.5 max-w-md text-xs font-semibold leading-5 text-slate-500">
          {feature.description}
        </p>
      </td>

      {permissionColumns.map((column) => (
        <td
          key={column.key}
          className="border-b border-r border-slate-200 px-3 py-3 text-center"
        >
          <TogglePill
            checked={Boolean(row?.[column.key])}
            disabled={
              disabled || (column.key !== "restricted" && row?.restricted)
            }
            danger={column.danger}
            onChange={(value) => onChange(column.key, value)}
          />
        </td>
      ))}
    </tr>
  );
};

const AccessTable = ({
  items,
  features,
  onEdit,
  onDelete,
  search,
  setSearch,
}) => {
  return (
    <GlassCard className="overflow-hidden p-0">
      <div className="flex flex-col gap-3 border-b border-slate-200 bg-white p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="group flex items-center gap-2">
          <UsersRound size={22} className={iconClass} />
          <div>
            <h3 className="text-lg font-black text-slate-950">
              Saved Access Sheet
            </h3>
            <p className="text-sm font-semibold text-slate-500">
              Excel style list. Scroll kore full user access dekho.
            </p>
          </div>
        </div>

        <div className="relative w-full lg:w-80">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search name, email, role..."
            className="h-10 w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 text-sm font-semibold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
          />
        </div>
      </div>

      <div className="max-h-[560px] overflow-auto">
        <table className="w-full min-w-[1280px] border-separate border-spacing-0 text-sm">
          <thead className="sticky top-0 z-30">
            <tr>
              {[
                "SL",
                "User Name",
                "Email",
                "Role",
                "Category",
                "Allowed",
                "Blocked",
                "Assistant",
                "Allowed Modules",
                "Note",
                "Updated",
                "Action",
              ].map((head, index) => (
                <th
                  key={head}
                  className={[
                    "border-b border-r border-slate-300 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600",
                    index === 0 ? "sticky left-0 z-40" : "",
                  ].join(" ")}
                >
                  {head}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {items.length ? (
              items.map((item, index) => {
                const summary =
                  item.summary ||
                  buildPermissionSummary(item.permissions, features);
                const allowedModules = getAllowedFeatureNames(
                  item.permissions,
                  features
                );

                return (
                  <tr
                    key={item.id}
                    className={[
                      "transition hover:bg-cyan-50",
                      index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
                    ].join(" ")}
                  >
                    <td className="sticky left-0 z-10 border-b border-r border-slate-200 bg-inherit px-3 py-3 text-xs font-black text-slate-500">
                      {String(index + 1).padStart(2, "0")}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <p className="font-black text-slate-950">
                        {item.userName || "Unnamed User"}
                      </p>
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3 text-xs font-semibold text-slate-600">
                      {item.userEmail || "-"}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <span className="rounded-md border border-cyan-200 bg-cyan-50 px-2 py-1 text-[11px] font-black uppercase text-cyan-700">
                        {roleLabels[item.role] || item.role}
                      </span>
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3 text-xs font-black text-slate-700">
                      {item.preset || "CUSTOM"}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3 text-center font-black text-emerald-700">
                      {summary.allowed}/{summary.total}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3 text-center font-black text-red-600">
                      {summary.restricted}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <span
                        className={[
                          "rounded-md px-2 py-1 text-[11px] font-black uppercase",
                          item.assistantAccess?.enabled
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-slate-100 text-slate-500",
                        ].join(" ")}
                      >
                        {item.assistantAccess?.enabled ? "On" : "Off"}
                      </span>
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <p className="line-clamp-2 max-w-[360px] text-xs font-semibold leading-5 text-slate-600">
                        {allowedModules.length
                          ? allowedModules.join(", ")
                          : "No allowed module"}
                      </p>
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <p className="line-clamp-2 max-w-[220px] text-xs font-semibold leading-5 text-slate-500">
                        {item.note || "-"}
                      </p>
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3 text-xs font-semibold text-slate-500">
                      {item.updatedAt
                        ? new Date(item.updatedAt).toLocaleDateString()
                        : "-"}
                    </td>

                    <td className="border-b border-r border-slate-200 px-3 py-3">
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-300 bg-white px-2 text-[11px] font-black text-slate-700 transition hover:bg-slate-100"
                        >
                          <Pencil size={13} />
                          Edit
                        </button>

                        <button
                          type="button"
                          onClick={() => onDelete(item.id)}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2 text-[11px] font-black text-red-700 transition hover:bg-red-100"
                        >
                          <Trash2 size={13} />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td
                  colSpan={12}
                  className="px-4 py-12 text-center text-sm font-black text-slate-400"
                >
                  No access profile found. Form fill kore Save User Access চাপো।
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </GlassCard>
  );
};

const AccessControlPage = () => {
  const fallbackPayload = useMemo(() => createFallbackPayload(), []);

  const [roles, setRoles] = useState(fallbackPayload.roles);
  const [features, setFeatures] = useState(fallbackPayload.features);
  const [permissions, setPermissions] = useState(fallbackPayload.permissions);
  const [assistantAccess, setAssistantAccess] = useState(
    fallbackPayload.assistantAccess
  );
  const [assignments, setAssignments] = useState(() => loadUserAssignments());
  const [form, setForm] = useState(() =>
    createEmptyForm(fallbackPayload.features)
  );
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState(null);
  const [search, setSearch] = useState("");

  const formSummary = useMemo(
    () => buildPermissionSummary(form.permissions, features),
    [form.permissions, features]
  );

  const filteredAssignments = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    if (!keyword) return assignments;

    return assignments.filter((item) =>
      [item.userName, item.userEmail, item.role, item.preset, item.note]
        .join(" ")
        .toLowerCase()
        .includes(keyword)
    );
  }, [assignments, search]);

  const assignmentStats = useMemo(() => {
    return {
      total: assignments.length,
      superAdmin: assignments.filter((item) => item.role === "SUPER_ADMIN")
        .length,
      doctor: assignments.filter((item) => item.role === "DOCTOR").length,
      staff: assignments.filter((item) => item.role === "STAFF").length,
    };
  }, [assignments]);

  const accountOptions = useMemo(() => {
    const map = new Map();

    defaultAccounts.forEach((item) => {
      map.set(item.id, item);
    });

    assignments.forEach((item) => {
      map.set(item.id, item);
    });

    return Array.from(map.values());
  }, [assignments]);

  const updateForm = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const resetForm = () => {
    setForm(createEmptyForm(features));
  };

  const syncAssignments = (next) => {
    setAssignments(next);
    saveUserAssignments(next);
  };

  const changeAccount = (accountId) => {
    const account = accountOptions.find((item) => item.id === accountId);

    if (!account) {
      updateForm("selectedAccountId", "");
      return;
    }

    const role = account.role || "DOCTOR";
    const preset = account.preset || getDefaultPresetByRole(role);
    const permissionSet =
      account.permissions || createPermissionSet(role, preset, features);

    setForm({
      id: account.id?.startsWith("default-") ? "" : account.id || "",
      selectedAccountId: accountId,
      userName: account.userName || "",
      userEmail: account.userEmail || "",
      role,
      preset,
      note: account.note || "",
      permissions: permissionSet,
      assistantAccess:
        account.assistantAccess || createDefaultAssistantAccess(role),
    });
  };

  const changeRole = (role) => {
    const preset = getDefaultPresetByRole(role);

    setForm((prev) => ({
      ...prev,
      role,
      preset,
      permissions: createPermissionSet(role, preset, features),
      assistantAccess: createDefaultAssistantAccess(role),
    }));
  };

  const changePreset = (preset) => {
    setForm((prev) => ({
      ...prev,
      preset,
      permissions:
        preset === "CUSTOM"
          ? prev.permissions
          : createPermissionSet(prev.role, preset, features),
    }));
  };

  const updateFormPermission = (featureKey, field, value) => {
    setForm((prev) => {
      const current =
        prev.permissions?.[featureKey] ||
        createDefaultPermission(prev.role, featureKey);

      const nextPermission = {
        ...current,
        [field]: value,
      };

      if (field === "restricted" && value) {
        nextPermission.canView = false;
        nextPermission.canCreate = false;
        nextPermission.canUpdate = false;
        nextPermission.canDelete = false;
      }

      if (field === "restricted" && !value) {
        nextPermission.restricted = false;
      }

      if (field !== "restricted" && value) {
        nextPermission.restricted = false;

        if (["canCreate", "canUpdate", "canDelete"].includes(field)) {
          nextPermission.canView = true;
        }
      }

      if (field === "canView" && !value) {
        nextPermission.canCreate = false;
        nextPermission.canUpdate = false;
        nextPermission.canDelete = false;
      }

      return {
        ...prev,
        preset: "CUSTOM",
        permissions: {
          ...(prev.permissions || {}),
          [featureKey]: nextPermission,
        },
      };
    });
  };

  const updateFormAssistantAccess = (field, value) => {
    setForm((prev) => {
      const next = {
        ...(prev.assistantAccess || {}),
        [field]: value,
      };

      if (field === "enabled" && !value) {
        next.canReadPatients = false;
        next.canWritePrescriptions = false;
        next.canSendMessages = false;
        next.canManageSettings = false;
      }

      if (field !== "enabled" && value) {
        next.enabled = true;
      }

      return {
        ...prev,
        assistantAccess: next,
      };
    });
  };

  const saveUserAccess = () => {
    const userName = form.userName.trim();
    const userEmail = form.userEmail.trim();

    if (!userName && !userEmail) {
      setNotice({
        type: "error",
        text: "User name or email is required.",
      });
      return;
    }

    const item = {
      id: form.id || `access-user-${Date.now()}`,
      userName,
      userEmail,
      role: form.role,
      preset: form.preset,
      note: form.note,
      permissions: form.permissions,
      assistantAccess: form.assistantAccess,
      summary: buildPermissionSummary(form.permissions, features),
      updatedAt: new Date().toISOString(),
    };

    const next = form.id
      ? assignments.map((entry) => (entry.id === form.id ? item : entry))
      : [item, ...assignments];

    syncAssignments(next);

    setNotice({
      type: "success",
      text: "User access saved in access sheet.",
    });

    resetForm();
  };

  const editAssignment = (item) => {
    setForm({
      id: item.id,
      selectedAccountId: item.id,
      userName: item.userName || "",
      userEmail: item.userEmail || "",
      role: item.role || "DOCTOR",
      preset: item.preset || "CUSTOM",
      note: item.note || "",
      permissions:
        item.permissions ||
        createPermissionSet(
          item.role || "DOCTOR",
          item.preset || "CUSTOM",
          features
        ),
      assistantAccess:
        item.assistantAccess ||
        createDefaultAssistantAccess(item.role || "DOCTOR"),
    });

    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const deleteAssignment = (id) => {
    const confirmed = window.confirm("Delete this user access profile?");
    if (!confirmed) return;

    syncAssignments(assignments.filter((item) => item.id !== id));

    if (form.id === id) {
      resetForm();
    }
  };

  const applyFormToRoleTemplate = () => {
    if (form.role === "SUPER_ADMIN") return;

    setPermissions((prev) => ({
      ...prev,
      [form.role]: form.permissions,
    }));

    setAssistantAccess((prev) => ({
      ...prev,
      [form.role]: form.assistantAccess,
    }));

    setNotice({
      type: "success",
      text: `${roleLabels[form.role] || form.role} role template updated from form.`,
    });
  };

  const loadAccessControl = async () => {
    try {
      setLoading(true);
      setNotice(null);

      const response = await fetch(API_URL, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Backend API response failed.");
      }

      const result = await response.json();

      if (!result?.success || !result?.data) {
        throw new Error(result?.message || "Invalid API response.");
      }

      const nextFeatures = result.data.features || fallbackPayload.features;

      setRoles(result.data.roles || fallbackPayload.roles);
      setFeatures(nextFeatures);
      setPermissions(result.data.permissions || fallbackPayload.permissions);
      setAssistantAccess(
        result.data.assistantAccess || fallbackPayload.assistantAccess
      );

      setForm((prev) => ({
        ...prev,
        permissions:
          prev.permissions ||
          createPermissionSet(prev.role, prev.preset, nextFeatures),
      }));

      setNotice({
        type: "success",
        text: "Access control data loaded from backend.",
      });
    } catch (error) {
      console.error(error);

      setRoles(fallbackPayload.roles);
      setFeatures(fallbackPayload.features);
      setPermissions(fallbackPayload.permissions);
      setAssistantAccess(fallbackPayload.assistantAccess);

      setNotice({
        type: "warning",
        text: "Backend API not connected. Default local permissions are showing.",
      });
    } finally {
      setLoading(false);
    }
  };

  const saveRoleTemplatesToBackend = async () => {
    try {
      setSaving(true);
      setNotice(null);

      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          permissions,
          assistantAccess,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result?.success) {
        throw new Error(result?.message || "Failed to save access control.");
      }

      if (result?.data) {
        setRoles(result.data.roles || roles);
        setFeatures(result.data.features || features);
        setPermissions(result.data.permissions || permissions);
        setAssistantAccess(result.data.assistantAccess || assistantAccess);
      }

      setNotice({
        type: "success",
        text: "Role templates saved to backend successfully.",
      });
    } catch (error) {
      console.error(error);

      setNotice({
        type: "error",
        text: error.message || "Could not save role templates.",
      });
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    loadAccessControl();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="mx-auto grid max-w-7xl gap-4">
      <NoticeToast notice={notice} />

      <GlassCard className="p-4">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="group flex min-w-0 items-center gap-3">
            <KeyRound size={26} className={iconClass} />
            <div className="min-w-0">
              <p className="text-[11px] font-black uppercase tracking-[0.2em] text-teal-700">
                Access Control
              </p>
              <h2 className="truncate text-2xl font-black tracking-tight text-slate-950">
                User Access Entry Form
              </h2>
              <p className="truncate text-sm font-semibold text-slate-500">
                User select/type করো, role দাও, access category দাও, permission
                set করে নিচের sheet-এ save করো।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={loadAccessControl}
              disabled={loading || saving}
              className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 text-sm font-black text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <RefreshCcw size={15} className={loading ? "animate-spin" : ""} />
              Refresh
            </button>

            <button
              type="button"
              onClick={saveRoleTemplatesToBackend}
              disabled={loading || saving}
              className="inline-flex h-10 items-center gap-2 rounded-lg bg-slate-900 px-5 text-sm font-black text-white shadow-sm transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Save size={15} />
              {saving ? "Saving..." : "Save Role Templates"}
            </button>
          </div>
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              Saved Profiles
            </p>
            <p className="mt-1 text-xl font-black text-slate-950">
              {assignmentStats.total}
            </p>
          </div>

          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
              Doctors
            </p>
            <p className="mt-1 text-xl font-black text-emerald-700">
              {assignmentStats.doctor}
            </p>
          </div>

          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-amber-700">
              Staff
            </p>
            <p className="mt-1 text-xl font-black text-amber-700">
              {assignmentStats.staff}
            </p>
          </div>

          <div className="rounded-xl border border-cyan-200 bg-cyan-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-cyan-700">
              Super Admin
            </p>
            <p className="mt-1 text-xl font-black text-cyan-800">
              {assignmentStats.superAdmin}
            </p>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="grid gap-4 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="group flex items-center gap-2">
            <SlidersHorizontal size={21} className={iconClass} />
            <div>
              <h3 className="text-lg font-black text-slate-950">
                Access Entry Form
              </h3>
              <p className="text-sm font-semibold text-slate-500">
                Form fill kore permission save korle niche table-e list show
                korbe।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {form.id ? (
              <button
                type="button"
                onClick={resetForm}
                className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 text-sm font-black text-slate-700 transition hover:bg-slate-50"
              >
                <XCircle size={15} />
                Cancel Edit
              </button>
            ) : null}

            <button
              type="button"
              onClick={saveUserAccess}
              className="inline-flex h-10 items-center gap-2 rounded-lg bg-teal-700 px-5 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-teal-800"
            >
              <Save size={15} />
              {form.id ? "Update User Access" : "Save User Access"}
            </button>
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <label className="grid gap-1.5 xl:col-span-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              Select User / Email
            </span>
            <div className="relative">
              <select
                value={form.selectedAccountId || ""}
                onChange={(event) => changeAccount(event.target.value)}
                className={`${selectClass} appearance-none pr-9`}
              >
                <option value="">Manual Entry</option>
                {accountOptions.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.userName || "Unnamed"} —{" "}
                    {account.userEmail || "No email"}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={16}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
            </div>
          </label>

          <label className="grid gap-1.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              User Name
            </span>
            <div className="relative">
              <UserRound
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                value={form.userName}
                onChange={(event) => updateForm("userName", event.target.value)}
                placeholder="Example: Dr. Rahim"
                className={`${inputClass} pl-9`}
              />
            </div>
          </label>

          <label className="grid gap-1.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              User Email
            </span>
            <div className="relative">
              <Mail
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="email"
                value={form.userEmail}
                onChange={(event) => updateForm("userEmail", event.target.value)}
                placeholder="user@email.com"
                className={`${inputClass} pl-9`}
              />
            </div>
          </label>

          <label className="grid gap-1.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              Role
            </span>
            <select
              value={form.role}
              onChange={(event) => changeRole(event.target.value)}
              className={selectClass}
            >
              {roles.map((role) => (
                <option key={role} value={role}>
                  {roleLabels[role] || role}
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              Access Category
            </span>
            <select
              value={form.preset}
              onChange={(event) => changePreset(event.target.value)}
              className={selectClass}
            >
              {accessPresets.map((preset) => (
                <option key={preset.key} value={preset.key}>
                  {preset.label}
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1.5 xl:col-span-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              Note
            </span>
            <input
              value={form.note}
              onChange={(event) => updateForm("note", event.target.value)}
              placeholder="Optional note"
              className={inputClass}
            />
          </label>
        </div>

        <div className="grid gap-2 md:grid-cols-3">
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-slate-400">
              Current Role
            </p>
            <p className="mt-1 text-lg font-black text-slate-950">
              {roleLabels[form.role] || form.role}
            </p>
          </div>

          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-emerald-600">
              Allowed Modules
            </p>
            <p className="mt-1 text-lg font-black text-emerald-700">
              {formSummary.allowed}/{formSummary.total}
            </p>
          </div>

          <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3">
            <p className="text-[11px] font-black uppercase tracking-wider text-red-500">
              Blocked Modules
            </p>
            <p className="mt-1 text-lg font-black text-red-700">
              {formSummary.restricted}
            </p>
          </div>
        </div>

        <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-6">
          {accessPresets.map((preset) => (
            <button
              key={preset.key}
              type="button"
              onClick={() => changePreset(preset.key)}
              className={[
                "rounded-xl border p-3 text-left transition hover:-translate-y-0.5 hover:shadow-sm",
                form.preset === preset.key
                  ? "border-slate-900 bg-slate-900 text-white"
                  : "border-slate-300 bg-white hover:bg-slate-50",
              ].join(" ")}
            >
              <p className="text-sm font-black">{preset.label}</p>
              <p
                className={[
                  "mt-1 text-xs font-semibold leading-5",
                  form.preset === preset.key
                    ? "text-white/70"
                    : "text-slate-500",
                ].join(" ")}
              >
                {preset.text}
              </p>
            </button>
          ))}
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-300 bg-white">
          <div className="flex flex-col gap-3 border-b border-slate-200 bg-slate-50 p-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="group flex items-center gap-2">
              <ShieldCheck size={20} className={iconClass} />
              <div>
                <h3 className="text-base font-black text-slate-950">
                  Panel Permission Sheet
                </h3>
                <p className="text-xs font-semibold text-slate-500">
                  Excel-er moto module-wise access on/off koro।
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={applyFormToRoleTemplate}
              disabled={form.role === "SUPER_ADMIN"}
              className="inline-flex h-10 items-center gap-2 rounded-lg border border-teal-300 bg-teal-50 px-4 text-xs font-black text-teal-700 transition hover:bg-teal-100 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <ShieldCheck size={14} />
              Apply To Role Template
            </button>
          </div>

          <div className="max-h-[420px] overflow-auto">
            <table className="w-full min-w-[920px] border-separate border-spacing-0 text-sm">
              <thead className="sticky top-0 z-20">
                <tr>
                  <th className="sticky left-0 z-30 border-b border-r border-slate-300 bg-slate-100 px-4 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600">
                    Panel Feature
                  </th>

                  {permissionColumns.map((column) => (
                    <th
                      key={column.key}
                      className={[
                        "border-b border-r border-slate-300 bg-slate-100 px-3 py-3 text-center text-[11px] font-black uppercase tracking-wider",
                        column.danger ? "text-red-500" : "text-slate-600",
                      ].join(" ")}
                    >
                      {column.label}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {features.map((feature, index) => (
                  <FeaturePermissionRow
                    key={feature.key}
                    index={index}
                    feature={feature}
                    row={
                      form.permissions?.[feature.key] ||
                      createDefaultPermission(form.role, feature.key)
                    }
                    disabled={form.role === "SUPER_ADMIN"}
                    onChange={(field, value) =>
                      updateFormPermission(feature.key, field, value)
                    }
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <GlassCard className="grid gap-3 p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="group flex items-center gap-2">
              <Bot size={20} className={iconClass} />
              <div>
                <h3 className="text-base font-black text-slate-950">
                  Assistant Access
                </h3>
                <p className="text-xs font-semibold text-slate-500">
                  Assistant-er kon kon kaj allowed hobe select koro।
                </p>
              </div>
            </div>

            <div
              className={[
                "inline-flex w-fit items-center gap-2 rounded-lg border px-3 py-2 text-xs font-black uppercase tracking-wide",
                form.assistantAccess?.enabled
                  ? "border-emerald-300 bg-emerald-50 text-emerald-700"
                  : "border-slate-300 bg-slate-50 text-slate-500",
              ].join(" ")}
            >
              {form.assistantAccess?.enabled ? (
                <CheckCircle2 size={15} />
              ) : (
                <LockKeyhole size={15} />
              )}
              {form.assistantAccess?.enabled ? "Assistant On" : "Assistant Off"}
            </div>
          </div>

          <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-5">
            {assistantFields.map((field) => {
              const checked = Boolean(form.assistantAccess?.[field.key]);
              const disabled = form.role === "SUPER_ADMIN";

              return (
                <button
                  key={field.key}
                  type="button"
                  disabled={disabled}
                  onClick={() => updateFormAssistantAccess(field.key, !checked)}
                  className={[
                    "rounded-xl border p-3 text-left transition hover:-translate-y-0.5 hover:shadow-sm",
                    checked
                      ? "border-teal-300 bg-teal-50"
                      : "border-slate-300 bg-white hover:bg-slate-50",
                    disabled ? "cursor-not-allowed opacity-65" : "cursor-pointer",
                  ].join(" ")}
                >
                  <span
                    className={[
                      "rounded-md px-2 py-1 text-[10px] font-black uppercase tracking-wider",
                      checked
                        ? "bg-white text-teal-700"
                        : "bg-slate-100 text-slate-400",
                    ].join(" ")}
                  >
                    {checked ? "On" : "Off"}
                  </span>

                  <p className="mt-2 text-sm font-black text-slate-950">
                    {field.label}
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    {field.description}
                  </p>
                </button>
              );
            })}
          </div>
        </GlassCard>
      </GlassCard>

      <AccessTable
        items={filteredAssignments}
        features={features}
        onEdit={editAssignment}
        onDelete={deleteAssignment}
        search={search}
        setSearch={setSearch}
      />

      <GlassCard className="p-4">
        <div className="flex items-start gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-bold leading-6 text-amber-800">
          <AlertTriangle size={18} className="mt-0.5 shrink-0" />
          <span>
            Brutal truth: frontend access form real security না। এই sheet
            localStorage-এ save হচ্ছে। Real lock চাইলে backend middleware/login
            guard-এ userEmail অনুযায়ী permission check লাগবে।
          </span>
        </div>
      </GlassCard>
    </section>
  );
};

export default AccessControlPage;
