export { default } from "../DoctorMessagesPage";
