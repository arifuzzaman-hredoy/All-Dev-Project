import { useEffect, useMemo, useState } from "react";
import { Eye, Trash2, UsersRound } from "lucide-react";
import GlassCard from "../../components/common/GlassCard";
import {
  PUBLIC_USERS_KEY,
  safeReadList,
  safeWriteList,
} from "../../publicSite/lib/publicUserStorage";

const formatDate = (value) => {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("en-GB");
};

const UsersPage = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const loadUsers = () => setUsers(safeReadList(PUBLIC_USERS_KEY));

    loadUsers();
    window.addEventListener("storage", loadUsers);
    window.addEventListener("public-users-updated", loadUsers);

    return () => {
      window.removeEventListener("storage", loadUsers);
      window.removeEventListener("public-users-updated", loadUsers);
    };
  }, []);

  const sortedUsers = useMemo(() => {
    return [...users].sort(
      (a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0),
    );
  }, [users]);

  const writeUsers = (nextUsers) => {
    setUsers(nextUsers);
    safeWriteList(PUBLIC_USERS_KEY, nextUsers);
    window.dispatchEvent(new Event("public-users-updated"));
  };

  const toggleStatus = (id) => {
    writeUsers(
      users.map((user) =>
        user.id === id
          ? {
              ...user,
              status: user.status === "Inactive" ? "Active" : "Inactive",
              updatedAt: new Date().toISOString(),
            }
          : user,
      ),
    );
  };

  const deleteUser = (id) => {
    writeUsers(users.filter((user) => user.id !== id));
    if (selectedUser?.id === id) setSelectedUser(null);
  };

  return (
    <section className="mx-auto grid max-w-6xl gap-3">
      <GlassCard className="flex items-center justify-between gap-3 px-4 py-3">
        <div className="flex min-w-0 items-center gap-2">
          <UsersRound size={19} className="shrink-0 text-teal-700" />
          <div>
            <p className="text-[11px] font-black uppercase tracking-wider text-cyan-600">
              Public Users
            </p>
            <h2 className="text-xl font-black tracking-tight text-slate-900">
              Registered Patients
            </h2>
          </div>
        </div>
        <span className="rounded-full bg-cyan-50 px-3 py-1 text-xs font-black text-teal-700">
          {users.length} users
        </span>
      </GlassCard>

      <GlassCard className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
                <th className="min-w-40 px-3 py-2 font-black">Name</th>
                <th className="min-w-28 px-3 py-2 font-black">Phone</th>
                <th className="min-w-40 px-3 py-2 font-black">Email</th>
                <th className="px-3 py-2 font-black">Age</th>
                <th className="px-3 py-2 font-black">Gender</th>
                <th className="px-3 py-2 font-black">Password</th>
                <th className="px-3 py-2 font-black">Status</th>
                <th className="min-w-28 px-3 py-2 font-black">Created</th>
                <th className="min-w-44 px-3 py-2 font-black">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedUsers.map((user) => (
                <tr
                  key={user.id}
                  className="border-b border-slate-100 transition hover:bg-slate-50"
                >
                  <td className="px-3 py-2 font-black text-slate-900">
                    {user.name}
                  </td>
                  <td className="px-3 py-2 font-bold text-slate-600">
                    {user.phone}
                  </td>
                  <td className="px-3 py-2 font-bold text-slate-600">
                    {user.email || "-"}
                  </td>
                  <td className="px-3 py-2 font-bold text-slate-600">
                    {user.age || "-"}
                  </td>
                  <td className="px-3 py-2 font-bold text-slate-600">
                    {user.gender || "-"}
                  </td>
                  <td className="px-3 py-2 font-black text-slate-500">
                    ******
                  </td>
                  <td className="px-3 py-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-black ${
                        user.status === "Inactive"
                          ? "bg-rose-50 text-rose-700"
                          : "bg-emerald-50 text-emerald-700"
                      }`}
                    >
                      {user.status || "Active"}
                    </span>
                  </td>
                  <td className="px-3 py-2 font-bold text-slate-600">
                    {formatDate(user.createdAt)}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedUser(user)}
                        className="inline-flex items-center gap-1 rounded-lg bg-cyan-50 px-2 py-1 text-[10px] font-black text-teal-700"
                      >
                        <Eye size={11} />
                        View
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleStatus(user.id)}
                        className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-black text-slate-700"
                      >
                        {user.status === "Inactive" ? "Mark Active" : "Mark Inactive"}
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteUser(user.id)}
                        className="inline-flex items-center gap-1 rounded-lg bg-rose-50 px-2 py-1 text-[10px] font-black text-rose-700"
                      >
                        <Trash2 size={11} />
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {!sortedUsers.length ? (
                <tr>
                  <td
                    colSpan="9"
                    className="px-3 py-8 text-center text-xs font-black text-slate-400"
                  >
                    No registered public user found.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {selectedUser ? (
        <GlassCard className="grid gap-2 px-4 py-3 text-sm font-bold text-slate-600">
          <div className="flex items-center justify-between gap-3">
            <h3 className="text-base font-black text-slate-900">
              {selectedUser.name}
            </h3>
            <button
              type="button"
              onClick={() => setSelectedUser(null)}
              className="text-xs font-black text-teal-700"
            >
              Close
            </button>
          </div>
          <p>Phone: {selectedUser.phone}</p>
          <p>Email: {selectedUser.email || "-"}</p>
          <p>Address: {selectedUser.address || "-"}</p>
          <p>Password: ******</p>
        </GlassCard>
      ) : null}
    </section>
  );
};

export default UsersPage;
