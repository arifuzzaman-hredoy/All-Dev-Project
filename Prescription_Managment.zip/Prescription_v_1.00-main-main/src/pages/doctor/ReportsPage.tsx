import { TrendingUp } from "lucide-react";
import GlassCard from "../../components/common/GlassCard";

const ReportsPage = () => {
  return (
    <section className="mx-auto grid max-w-6xl gap-4">
      <GlassCard className="grid gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-cyan-50 text-teal-700">
            <TrendingUp size={20} />
          </span>
          <div>
            <p className="text-xs font-black uppercase tracking-wider text-cyan-600">
              Reports
            </p>
            <h2 className="text-3xl font-black tracking-tight text-slate-900">
              Clinical Reports
            </h2>
          </div>
        </div>
        <p className="max-w-2xl text-sm font-semibold leading-6 text-slate-500">
          View patient flow, appointment trends, prescription activity, and
          operational reporting here.
        </p>
      </GlassCard>
    </section>
  );
};

export default ReportsPage;
