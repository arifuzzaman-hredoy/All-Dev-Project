import { useEffect, useMemo, useState } from "react";
import {
  CalendarClock,
  CheckCircle2,
  Clock3,
  Printer,
  Search,
  Trash2,
  TriangleAlert,
  UsersRound,
} from "lucide-react";
import GlassCard from "../../components/common/GlassCard";

const FOLLOW_UP_STORAGE_KEY = "doctor_follow_ups";

const safeReadList = (key) => {
  try {
    return JSON.parse(window.localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
};

const safeWriteList = (key, value) => {
  window.localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event("doctor-follow-ups-updated"));
};

const getTodayDate = () => new Date().toISOString().slice(0, 10);

const formatMedicineText = (medicines) => {
  if (Array.isArray(medicines)) {
    return medicines
      .filter((item) => item?.name || item?.dose || item?.duration)
      .map((item) =>
        [item.name, item.dose, item.duration, item.instruction]
          .filter(Boolean)
          .join(" - "),
      )
      .join("; ");
  }

  return medicines || "";
};

const getDisplayStatus = (item) => {
  if (item.status === "Done") return "Done";
  if (!item.followUpDate) return "Pending";

  const today = getTodayDate();
  if (item.followUpDate < today) return "Overdue";
  if (item.followUpDate === today) return "Today";
  return "Pending";
};

const sortFollowUps = (items) => {
  return [...items].sort((a, b) => {
    const aDone = a.status === "Done" ? 1 : 0;
    const bDone = b.status === "Done" ? 1 : 0;

    if (aDone !== bDone) return aDone - bDone;
    return String(a.followUpDate || "").localeCompare(
      String(b.followUpDate || ""),
    );
  });
};

const filters = ["All", "Today", "Overdue", "Pending", "Done"];

const statusClass = {
  Today: "bg-amber-50 text-amber-700 border-amber-100",
  Pending: "bg-sky-50 text-sky-700 border-sky-100",
  Overdue: "bg-rose-50 text-rose-700 border-rose-100",
  Done: "bg-emerald-50 text-emerald-700 border-emerald-100",
};

const escapeHtml = (value) =>
  String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const buildPrintHtml = (rows) => {
  const printedDate = new Date().toLocaleDateString("en-GB");

  const tableRows =
    rows.length > 0
      ? rows
          .map((item, index) => {
            const status = getDisplayStatus(item);

            return `
              <tr>
                <td>${index + 1}</td>
                <td>
                  <b>${escapeHtml(item.patientName)}</b>
                  <small>${escapeHtml(item.patientId || item.id)}</small>
                </td>
                <td>${escapeHtml(item.phone)}</td>
                <td>${escapeHtml(item.followUpDate)}</td>
                <td>${escapeHtml(item.chiefComplaint || item.diagnosis)}</td>
                <td>${escapeHtml(item.advice)}</td>
                <td>${escapeHtml(formatMedicineText(item.medicines))}</td>
                <td><b>${escapeHtml(status)}</b></td>
              </tr>
            `;
          })
          .join("")
      : `<tr><td colspan="8" class="empty">No follow-up found</td></tr>`;

  return `
    <!doctype html>
    <html>
      <head>
        <title>Follow-up Schedule</title>
        <style>
          @page { size: A4 portrait; margin: 10mm; }
          * { box-sizing: border-box; }
          body { margin: 0; color: #111827; background: #ffffff; font-family: Arial, Helvetica, sans-serif; }
          .header { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 2px solid #111827; }
          h1 { margin: 0; font-size: 18px; font-weight: 800; }
          p { margin: 3px 0 0; font-size: 10px; font-weight: 700; color: #4b5563; }
          .meta { text-align: right; font-size: 10px; font-weight: 700; color: #374151; }
          table { width: 100%; border-collapse: collapse; table-layout: fixed; }
          th, td { border: 1px solid #9ca3af; padding: 5px; font-size: 9px; line-height: 1.25; vertical-align: top; word-break: break-word; }
          th { background: #f3f4f6; text-transform: uppercase; font-size: 8px; font-weight: 800; text-align: left; }
          small { display: block; margin-top: 2px; color: #6b7280; font-size: 8px; font-weight: 700; }
          .empty { padding: 18px; text-align: center; font-weight: 800; color: #6b7280; }
          .footer { display: flex; justify-content: space-between; margin-top: 20px; font-size: 10px; font-weight: 700; }
          @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>Follow-up Schedule</h1>
            <p>Prescription generated patient follow-up list</p>
          </div>
          <div class="meta">
            <div>Total: ${rows.length}</div>
            <div>Printed: ${printedDate}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>SL</th>
              <th>Patient</th>
              <th>Phone</th>
              <th>Follow-up</th>
              <th>Complaint / Diagnosis</th>
              <th>Advice</th>
              <th>Medicines</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
        </table>

        <div class="footer">
          <div>Doctor Signature: ____________________</div>
          <div>Checked By: ____________________</div>
        </div>

        <script>
          window.onload = function () {
            window.focus();
            window.print();
          };
        </script>
      </body>
    </html>
  `;
};

const FollowUpPage = () => {
  const [followUps, setFollowUps] = useState([]);
  const [activeFilter, setActiveFilter] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const loadFollowUps = () => {
      setFollowUps(safeReadList(FOLLOW_UP_STORAGE_KEY));
    };

    loadFollowUps();
    window.addEventListener("storage", loadFollowUps);
    window.addEventListener("doctor-follow-ups-updated", loadFollowUps);

    return () => {
      window.removeEventListener("storage", loadFollowUps);
      window.removeEventListener("doctor-follow-ups-updated", loadFollowUps);
    };
  }, []);

  const sortedFollowUps = useMemo(() => sortFollowUps(followUps), [followUps]);

  const filteredFollowUps = useMemo(() => {
    return sortedFollowUps.filter((item) => {
      const displayStatus = getDisplayStatus(item);
      const matchesFilter =
        activeFilter === "All" || displayStatus === activeFilter;
      const searchText = [
        item.patientName,
        item.phone,
        item.chiefComplaint,
        item.diagnosis,
        item.advice,
        displayStatus,
      ]
        .join(" ")
        .toLowerCase();

      return matchesFilter && searchText.includes(searchTerm.toLowerCase());
    });
  }, [activeFilter, searchTerm, sortedFollowUps]);

  const stats = useMemo(() => {
    return {
      total: followUps.length,
      today: followUps.filter((item) => getDisplayStatus(item) === "Today")
        .length,
      overdue: followUps.filter((item) => getDisplayStatus(item) === "Overdue")
        .length,
      done: followUps.filter((item) => item.status === "Done").length,
    };
  }, [followUps]);

  const updateStatus = (id, status) => {
    const nextFollowUps = followUps.map((item) =>
      item.id === id
        ? { ...item, status, updatedAt: new Date().toISOString() }
        : item,
    );

    setFollowUps(nextFollowUps);
    safeWriteList(FOLLOW_UP_STORAGE_KEY, nextFollowUps);
  };

  const deleteFollowUp = (id) => {
    const nextFollowUps = followUps.filter((item) => item.id !== id);
    setFollowUps(nextFollowUps);
    safeWriteList(FOLLOW_UP_STORAGE_KEY, nextFollowUps);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank", "width=1000,height=800");

    if (!printWindow) {
      alert("Popup blocked. Please allow popup for print.");
      return;
    }

    printWindow.document.open();
    printWindow.document.write(buildPrintHtml(filteredFollowUps));
    printWindow.document.close();
  };

  return (
    <section className="mx-auto grid max-w-6xl gap-3">
      <GlassCard className="px-4 py-3">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex min-w-0 items-center gap-2">
            <CalendarClock size={19} className="shrink-0 text-teal-700" />

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <p className="text-[11px] font-black uppercase tracking-wider text-cyan-600">
                  Follow Up
                </p>
                <span className="hidden text-slate-300 sm:inline">/</span>
                <h2 className="text-xl font-black tracking-tight text-slate-900 sm:text-2xl">
                  Follow-up Schedule
                </h2>
              </div>

              <p className="mt-0.5 text-xs font-semibold text-slate-500">
                Prescription follow-up dates from saved prescriptions.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap items-center gap-2 text-xs font-black">
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-50 px-2.5 py-1 text-slate-700">
                <UsersRound size={13} />
                Total {stats.total}
              </span>

              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-amber-700">
                <Clock3 size={13} />
                Today {stats.today}
              </span>

              <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2.5 py-1 text-rose-700">
                <TriangleAlert size={13} />
                Overdue {stats.overdue}
              </span>

              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-emerald-700">
                <CheckCircle2 size={13} />
                Done {stats.done}
              </span>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex h-9 items-center gap-2 rounded-xl bg-slate-900 px-3 text-xs font-black text-white shadow-sm transition hover:bg-slate-800"
            >
              <Printer size={15} />
              Print A4
            </button>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="px-4 py-3">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-1.5">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`rounded-full px-3 py-1.5 text-xs font-black transition ${
                  activeFilter === filter
                    ? "bg-slate-900 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <label className="flex h-9 w-full items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 lg:w-72">
            <Search size={15} className="shrink-0 text-slate-400" />
            <input
              type="search"
              placeholder="Search patient, phone..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              className="w-full bg-transparent text-xs font-bold text-slate-700 outline-none placeholder:text-slate-400"
            />
          </label>
        </div>
      </GlassCard>

      <GlassCard className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
                <th className="w-12 px-3 py-2 font-black">SL</th>
                <th className="min-w-40 px-3 py-2 font-black">Patient</th>
                <th className="min-w-28 px-3 py-2 font-black">Phone</th>
                <th className="min-w-52 px-3 py-2 font-black">
                  Complaint / Diagnosis
                </th>
                <th className="min-w-44 px-3 py-2 font-black">
                  Doctor Advice
                </th>
                <th className="min-w-28 px-3 py-2 font-black">Follow-up</th>
                <th className="min-w-24 px-3 py-2 font-black">Status</th>
                <th className="min-w-44 px-3 py-2 font-black">Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredFollowUps.length > 0 ? (
                filteredFollowUps.map((item, index) => {
                  const displayStatus = getDisplayStatus(item);

                  return (
                    <tr
                      key={item.id}
                      className="border-b border-slate-100 transition hover:bg-slate-50"
                    >
                      <td className="px-3 py-2 font-black text-slate-500">
                        {index + 1}
                      </td>

                      <td className="px-3 py-2">
                        <p className="font-black leading-4 text-slate-900">
                          {item.patientName || "Unnamed patient"}
                        </p>
                        <p className="text-[10px] font-bold leading-4 text-slate-400">
                          {item.patientId || item.id}
                        </p>
                      </td>

                      <td className="px-3 py-2 font-bold text-slate-600">
                        {item.phone || "-"}
                      </td>

                      <td className="px-3 py-2 font-bold text-slate-700">
                        {item.chiefComplaint || item.diagnosis || "-"}
                      </td>

                      <td className="px-3 py-2 font-semibold text-slate-500">
                        {item.advice || "-"}
                      </td>

                      <td className="px-3 py-2 font-black text-slate-900">
                        {item.followUpDate}
                      </td>

                      <td className="px-3 py-2">
                        <span
                          className={`inline-flex rounded-full border px-2 py-0.5 text-[10px] font-black ${
                            statusClass[displayStatus]
                          }`}
                        >
                          {displayStatus}
                        </span>
                      </td>

                      <td className="px-3 py-2">
                        <div className="flex flex-wrap gap-1.5">
                          <button
                            type="button"
                            onClick={() => updateStatus(item.id, "Done")}
                            className="rounded-lg bg-emerald-50 px-2 py-1 text-[10px] font-black text-emerald-700 transition hover:bg-emerald-100"
                          >
                            Mark Done
                          </button>
                          <button
                            type="button"
                            onClick={() => updateStatus(item.id, "Pending")}
                            className="rounded-lg bg-sky-50 px-2 py-1 text-[10px] font-black text-sky-700 transition hover:bg-sky-100"
                          >
                            Mark Pending
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteFollowUp(item.id)}
                            className="inline-flex items-center gap-1 rounded-lg bg-rose-50 px-2 py-1 text-[10px] font-black text-rose-700 transition hover:bg-rose-100"
                          >
                            <Trash2 size={11} />
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td
                    colSpan="8"
                    className="px-3 py-8 text-center text-xs font-black text-slate-400"
                  >
                    No follow-up found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </section>
  );
};

export default FollowUpPage;
