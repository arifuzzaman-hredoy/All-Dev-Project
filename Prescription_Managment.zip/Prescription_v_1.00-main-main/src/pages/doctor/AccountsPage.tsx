import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Banknote,
  CheckCircle2,
  Download,
  FileText,
  Filter,
  Pencil,
  Plus,
  Printer,
  RefreshCcw,
  Save,
  Search,
  Trash2,
  X,
} from "lucide-react";
import GlassCard from "../../components/common/GlassCard";

const API_BASE = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");
const API_URL = `${API_BASE}/api/accounts`;

const accountPageStyles = `
.accounts-print-area {
  display: none;
}

@media print {
  @page {
    size: A4 landscape;
    margin: 8mm;
  }

  html,
  body {
    width: 297mm;
    min-height: 210mm;
    background: #ffffff !important;
    overflow: visible !important;
  }

  body * {
    visibility: hidden !important;
  }

  .accounts-print-area,
  .accounts-print-area * {
    visibility: visible !important;
  }

  .accounts-screen-area {
    display: none !important;
  }

  .accounts-print-area {
    display: block !important;
    position: absolute !important;
    inset: 0 auto auto 0 !important;
    width: 100% !important;
    padding: 0 !important;
    margin: 0 !important;
    background: #ffffff !important;
    color: #0f172a !important;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  .accounts-print-page {
    width: 100%;
    background: #ffffff;
    color: #0f172a;
    font-family: Arial, sans-serif;
  }

  .accounts-print-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    border-bottom: 2px solid #0f766e;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }

  .accounts-print-title {
    font-size: 20px;
    font-weight: 900;
    margin: 0;
    color: #0f172a;
  }

  .accounts-print-subtitle {
    margin: 3px 0 0;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
  }

  .accounts-print-meta {
    text-align: right;
    font-size: 10px;
    font-weight: 700;
    color: #334155;
    line-height: 1.5;
  }

  .accounts-print-summary {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 5px;
    margin-bottom: 10px;
  }

  .accounts-print-summary-card {
    border: 1px solid #bae6fd;
    background: #f0fdfa;
    padding: 6px;
    min-height: 42px;
  }

  .accounts-print-summary-label {
    margin: 0;
    font-size: 7px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #0f766e;
  }

  .accounts-print-summary-value {
    margin: 3px 0 0;
    font-size: 12px;
    font-weight: 900;
    color: #0f172a;
  }

  .accounts-print-section-title {
    margin: 0 0 6px;
    font-size: 13px;
    font-weight: 900;
    color: #0f172a;
  }

  .accounts-print-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: auto;
  }

  .accounts-print-table th {
    border: 1px solid #94a3b8;
    background: #0f766e !important;
    color: #ffffff !important;
    padding: 5px 4px;
    font-size: 7px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    white-space: nowrap;
  }

  .accounts-print-table td {
    border: 1px solid #cbd5e1;
    padding: 4px;
    font-size: 7.5px;
    font-weight: 700;
    color: #0f172a;
    vertical-align: top;
    word-break: break-word;
  }

  .accounts-print-table tbody tr:nth-child(even) td {
    background: #f8fafc !important;
  }

  .accounts-print-table .money-in {
    color: #047857 !important;
    font-weight: 900;
  }

  .accounts-print-table .money-out {
    color: #dc2626 !important;
    font-weight: 900;
  }

  .accounts-print-footer {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    margin-top: 12px;
    padding-top: 8px;
    border-top: 1px solid #cbd5e1;
    font-size: 9px;
    font-weight: 700;
    color: #475569;
  }
}
`;

const pad = (value) => String(value).padStart(2, "0");

const formatDateInput = (date) => {
  const year = date.getFullYear();
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  return `${year}-${month}-${day}`;
};

const getTodayDate = () => formatDateInput(new Date());

const getMonthStartDate = () => {
  const date = new Date();
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-01`;
};

const paymentMethods = [
  { value: "ALL", label: "All Methods" },
  { value: "CASH", label: "Cash" },
  { value: "BKASH", label: "bKash" },
  { value: "NAGAD", label: "Nagad" },
  { value: "BANK", label: "Bank" },
  { value: "CARD", label: "Card" },
  { value: "OTHER", label: "Other" },
];

const paymentStatuses = [
  { value: "ALL", label: "All Status" },
  { value: "PAID", label: "Paid" },
  { value: "PARTIAL_PAID", label: "Partial Paid" },
  { value: "DUE", label: "Due" },
  { value: "REFUNDED", label: "Refunded" },
  { value: "CANCELLED", label: "Cancelled" },
];

const expenseCategories = [
  { value: "CLINIC_RENT", label: "Clinic Rent" },
  { value: "STAFF_SALARY", label: "Staff Salary" },
  { value: "MEDICINE_PURCHASE", label: "Medicine Purchase" },
  { value: "UTILITY_BILL", label: "Utility Bill" },
  { value: "INTERNET_BILL", label: "Internet Bill" },
  { value: "CLEANING_COST", label: "Cleaning Cost" },
  { value: "EQUIPMENT_COST", label: "Equipment Cost" },
  { value: "MARKETING_COST", label: "Marketing Cost" },
  { value: "OTHER_EXPENSE", label: "Other Expense" },
];

const tabs = [
  { key: "appointments", label: "Appointment Income" },
  { key: "expenses", label: "Expense" },
  { key: "dueCollections", label: "Due Collection" },
  { key: "otherIncomes", label: "Other Income" },
  { key: "overall", label: "Overall Report" },
];

const emptyAccountData = {
  summary: {
    todayIncome: 0,
    appointmentIncome: 0,
    todayExpense: 0,
    todayDue: 0,
    netBalance: 0,
    monthlyIncome: 0,
    monthlyExpense: 0,
    monthlyProfit: 0,
  },
  appointmentIncomes: [],
  expenses: [],
  dueCollections: [],
  otherIncomes: [],
  overallRows: [],
};

const defaultForm = {
  date: getTodayDate(),
  serialNo: "",
  patientName: "",
  phone: "",
  doctorName: "",
  appointmentType: "",
  visitFee: "",
  paidAmount: "",
  paymentMethod: "CASH",
  paymentStatus: "PAID",
  receivedBy: "",
  note: "",
  title: "",
  category: "OTHER_EXPENSE",
  amount: "",
  paidBy: "",
};

const pathMap = {
  appointment: "appointment-income",
  expense: "expenses",
  due: "due-collections",
  income: "other-incomes",
};

const money = (value) =>
  Number(value || 0).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

const getMethodLabel = (value) =>
  paymentMethods.find((item) => item.value === value)?.label || value || "-";

const getStatusLabel = (value) =>
  paymentStatuses.find((item) => item.value === value)?.label || value || "-";

const getCategoryLabel = (value) =>
  expenseCategories.find((item) => item.value === value)?.label || value || "-";

const statusClass = (value) => {
  if (value === "PAID") return "border-emerald-200 bg-emerald-50 text-emerald-700";
  if (value === "PARTIAL_PAID") return "border-amber-200 bg-amber-50 text-amber-700";
  if (value === "DUE") return "border-red-200 bg-red-50 text-red-700";
  if (value === "REFUNDED") return "border-violet-200 bg-violet-50 text-violet-700";
  if (value === "CANCELLED") return "border-slate-200 bg-slate-100 text-slate-500";
  return "border-slate-200 bg-slate-100 text-slate-600";
};

const modalTitleMap = {
  appointment: "Appointment Income",
  expense: "Expense",
  due: "Due Collection",
  income: "Other Income",
};

const TextInput = ({ label, value, onChange, type = "text", placeholder }) => (
  <label className="grid gap-1">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>
    <input
      type={type}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
    />
  </label>
);

const SelectInput = ({ label, value, onChange, options }) => (
  <label className="grid gap-1">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
    >
      {options.map((item) => (
        <option key={item.value} value={item.value}>
          {item.label}
        </option>
      ))}
    </select>
  </label>
);

const TextAreaInput = ({ label, value, onChange, placeholder }) => (
  <label className="grid gap-1 md:col-span-2">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>
    <textarea
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      rows={3}
      className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
    />
  </label>
);

const Notice = ({ notice }) => {
  if (!notice) return null;

  const isSuccess = notice.type === "success";

  return (
    <div
      className={[
        "flex items-start gap-2 rounded-xl border px-3 py-2 text-sm font-bold",
        isSuccess
          ? "border-emerald-200 bg-emerald-50 text-emerald-700"
          : "border-red-200 bg-red-50 text-red-700",
      ].join(" ")}
    >
      {isSuccess ? <CheckCircle2 size={17} /> : <AlertTriangle size={17} />}
      <span>{notice.text}</span>
    </div>
  );
};

const AccountsPage = () => {
  const [activeTab, setActiveTab] = useState("appointments");
  const [data, setData] = useState(emptyAccountData);
  const [filters, setFilters] = useState({
    dateFrom: getMonthStartDate(),
    dateTo: getTodayDate(),
    paymentMethod: "ALL",
    patientName: "",
    status: "ALL",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState(null);
  const [modalType, setModalType] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [form, setForm] = useState(defaultForm);

  const summaryCards = useMemo(
    () => [
      {
        label: "Today Income",
        value: data.summary.todayIncome,
        hint: "Today cash in",
        tone: "emerald",
      },
      {
        label: "Appointment Income",
        value: data.summary.appointmentIncome,
        hint: "Selected range",
        tone: "cyan",
      },
      {
        label: "Today Expense",
        value: data.summary.todayExpense,
        hint: "Today cost",
        tone: "red",
      },
      {
        label: "Today Due",
        value: data.summary.todayDue,
        hint: "Unpaid fee",
        tone: "amber",
      },
      {
        label: "Net Balance",
        value: data.summary.netBalance,
        hint: "Range profit",
        tone: "slate",
      },
      {
        label: "Monthly Income",
        value: data.summary.monthlyIncome,
        hint: "This month cash in",
        tone: "emerald",
      },
      {
        label: "Monthly Expense",
        value: data.summary.monthlyExpense,
        hint: "This month cost",
        tone: "red",
      },
      {
        label: "Monthly Profit",
        value: data.summary.monthlyProfit,
        hint: "This month net",
        tone: "violet",
      },
    ],
    [data.summary]
  );

  const activeTabLabel =
    tabs.find((item) => item.key === activeTab)?.label || "Accounts Report";

  const toneClass = (tone, value) => {
    if (Number(value || 0) < 0) return "border-red-200 bg-red-50 text-red-700";

    const map = {
      emerald: "border-emerald-200 bg-emerald-50 text-emerald-700",
      cyan: "border-cyan-200 bg-cyan-50 text-cyan-700",
      red: "border-red-200 bg-red-50 text-red-700",
      amber: "border-amber-200 bg-amber-50 text-amber-700",
      violet: "border-violet-200 bg-violet-50 text-violet-700",
      slate: "border-slate-200 bg-slate-50 text-slate-800",
    };

    return map[tone] || map.slate;
  };

  const updateFilter = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const updateForm = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const buildQueryString = () => {
    const params = new URLSearchParams();

    Object.entries(filters).forEach(([key, value]) => {
      if (!value) return;
      if (value === "ALL") return;
      params.set(key, value);
    });

    return params.toString();
  };

  const loadAccounts = async () => {
    try {
      setLoading(true);
      setNotice(null);

      const query = buildQueryString();
      const response = await fetch(`${API_URL}${query ? `?${query}` : ""}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        credentials: "include",
      });

      const result = await response.json();

      if (!response.ok || !result?.success) {
        throw new Error(result?.message || "Failed to load accounts data.");
      }

      setData({
        ...emptyAccountData,
        ...result.data,
      });
    } catch (error) {
      console.error(error);
      setNotice({
        type: "error",
        text:
          error.message ||
          "Accounts backend not connected. Check server and database.",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetFilters = () => {
    setFilters({
      dateFrom: getMonthStartDate(),
      dateTo: getTodayDate(),
      paymentMethod: "ALL",
      patientName: "",
      status: "ALL",
    });
  };

  const openAddModal = (type) => {
    setModalType(type);
    setEditingItem(null);
    setForm({
      ...defaultForm,
      date: getTodayDate(),
    });
  };

  const openEditModal = (type, item) => {
    setModalType(type);
    setEditingItem(item);

    setForm({
      ...defaultForm,
      ...item,
      title: item.title || "",
      amount: item.amount || "",
      visitFee: item.visitFee || "",
      paidAmount: item.paidAmount || "",
      category: item.category || "OTHER_EXPENSE",
      paymentMethod: item.paymentMethod || "CASH",
      paymentStatus: item.paymentStatus || "PAID",
    });
  };

  const closeModal = () => {
    if (saving) return;
    setModalType(null);
    setEditingItem(null);
    setForm(defaultForm);
  };

  const getPayload = () => {
    if (modalType === "appointment") {
      return {
        date: form.date,
        serialNo: form.serialNo,
        patientName: form.patientName,
        phone: form.phone,
        doctorName: form.doctorName,
        appointmentType: form.appointmentType,
        visitFee: form.visitFee,
        paidAmount: form.paidAmount,
        paymentMethod: form.paymentMethod,
        paymentStatus: form.paymentStatus,
        receivedBy: form.receivedBy,
        note: form.note,
      };
    }

    if (modalType === "expense") {
      return {
        date: form.date,
        title: form.title,
        category: form.category,
        amount: form.amount,
        paymentMethod: form.paymentMethod,
        paidBy: form.paidBy,
        note: form.note,
      };
    }

    if (modalType === "due") {
      return {
        date: form.date,
        patientName: form.patientName,
        phone: form.phone,
        amount: form.amount,
        paymentMethod: form.paymentMethod,
        receivedBy: form.receivedBy,
        note: form.note,
      };
    }

    return {
      date: form.date,
      title: form.title,
      category: form.category,
      amount: form.amount,
      paymentMethod: form.paymentMethod,
      receivedBy: form.receivedBy,
      note: form.note,
    };
  };

  const saveRecord = async (event) => {
    event.preventDefault();

    if (!modalType) return;

    try {
      setSaving(true);
      setNotice(null);

      const path = pathMap[modalType];
      const endpoint = editingItem
        ? `${API_URL}/${path}/${editingItem.id}`
        : `${API_URL}/${path}`;

      const response = await fetch(endpoint, {
        method: editingItem ? "PUT" : "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(getPayload()),
      });

      const result = await response.json();

      if (!response.ok || !result?.success) {
        throw new Error(result?.message || "Failed to save record.");
      }

      setNotice({
        type: "success",
        text: result.message || "Record saved successfully.",
      });

      closeModal();
      await loadAccounts();
    } catch (error) {
      console.error(error);
      setNotice({
        type: "error",
        text: error.message || "Could not save record.",
      });
    } finally {
      setSaving(false);
    }
  };

  const deleteRecord = async (type, id) => {
    const confirmed = window.confirm("Are you sure you want to delete this?");
    if (!confirmed) return;

    try {
      setSaving(true);
      setNotice(null);

      const response = await fetch(`${API_URL}/${pathMap[type]}/${id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
        },
        credentials: "include",
      });

      const result = await response.json();

      if (!response.ok || !result?.success) {
        throw new Error(result?.message || "Failed to delete record.");
      }

      setNotice({
        type: "success",
        text: result.message || "Record deleted successfully.",
      });

      await loadAccounts();
    } catch (error) {
      console.error(error);
      setNotice({
        type: "error",
        text: error.message || "Could not delete record.",
      });
    } finally {
      setSaving(false);
    }
  };

  const csvEscape = (value) => {
    const text = String(value ?? "");
    if (text.includes(",") || text.includes('"') || text.includes("\n")) {
      return `"${text.replace(/"/g, '""')}"`;
    }
    return text;
  };

  const getExportRows = () => {
    if (activeTab === "appointments") {
      return data.appointmentIncomes.map((item) => ({
        Date: item.date,
        "Serial No": item.serialNo,
        "Patient Name": item.patientName,
        Phone: item.phone,
        "Doctor Name": item.doctorName,
        "Appointment Type": item.appointmentType,
        "Visit Fee": item.visitFee,
        "Paid Amount": item.paidAmount,
        "Due Amount": item.dueAmount,
        "Payment Method": getMethodLabel(item.paymentMethod),
        "Payment Status": getStatusLabel(item.paymentStatus),
        "Received By": item.receivedBy,
        Note: item.note,
      }));
    }

    if (activeTab === "expenses") {
      return data.expenses.map((item) => ({
        Date: item.date,
        "Expense Title": item.title,
        Category: getCategoryLabel(item.category),
        Amount: item.amount,
        "Payment Method": getMethodLabel(item.paymentMethod),
        "Paid By": item.paidBy,
        Note: item.note,
      }));
    }

    if (activeTab === "dueCollections") {
      return data.dueCollections.map((item) => ({
        Date: item.date,
        "Patient Name": item.patientName,
        Phone: item.phone,
        Amount: item.amount,
        "Payment Method": getMethodLabel(item.paymentMethod),
        "Received By": item.receivedBy,
        Note: item.note,
      }));
    }

    if (activeTab === "otherIncomes") {
      return data.otherIncomes.map((item) => ({
        Date: item.date,
        Title: item.title,
        Category: item.category,
        Amount: item.amount,
        "Payment Method": getMethodLabel(item.paymentMethod),
        "Received By": item.receivedBy,
        Note: item.note,
      }));
    }

    return data.overallRows.map((item) => ({
      Date: item.date,
      "Opening Balance": item.openingBalance,
      "Total Appointment Income": item.totalAppointmentIncome,
      "Other Income": item.otherIncome,
      "Total Expense": item.totalExpense,
      "Due Collection": item.dueCollection,
      Refund: item.refund,
      "Net Balance": item.netBalance,
      "Closing Balance": item.closingBalance,
      Note: item.note,
    }));
  };

  const exportExcel = () => {
    const rows = getExportRows();

    if (!rows.length) {
      setNotice({
        type: "error",
        text: "No data available to export.",
      });
      return;
    }

    const headers = Object.keys(rows[0]);
    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        headers.map((header) => csvEscape(row[header])).join(",")
      ),
    ].join("\n");

    const blob = new Blob([`\uFEFF${csv}`], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `accounts-${activeTab}-${getTodayDate()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const printReport = () => {
    window.print();
  };

  const duePreview = Math.max(
    Number(form.visitFee || 0) - Number(form.paidAmount || 0),
    0
  );

  const getScreenRows = () => {
    if (activeTab === "appointments") return data.appointmentIncomes;
    if (activeTab === "expenses") return data.expenses;
    if (activeTab === "dueCollections") return data.dueCollections;
    if (activeTab === "otherIncomes") return data.otherIncomes;
    return data.overallRows;
  };

  const printRows = getExportRows();
  const printHeaders = printRows[0] ? Object.keys(printRows[0]) : [];

  useEffect(() => {
    loadAccounts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const renderActionButtons = (type, item) => (
    <div className="flex items-center gap-1.5">
      <button
        type="button"
        onClick={() => openEditModal(type, item)}
        className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 text-xs font-black text-slate-600 transition hover:bg-slate-50"
      >
        <Pencil size={13} />
        Edit
      </button>
      <button
        type="button"
        onClick={() => deleteRecord(type, item.id)}
        className="inline-flex h-8 items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2 text-xs font-black text-red-700 transition hover:bg-red-100"
      >
        <Trash2 size={13} />
        Delete
      </button>
    </div>
  );

  const renderTable = () => {
    if (activeTab === "appointments") {
      return (
        <table className="w-full min-w-[1380px] border-separate border-spacing-0">
          <thead className="sticky top-0 z-20">
            <tr>
              {[
                "Date",
                "Serial",
                "Patient",
                "Phone",
                "Doctor",
                "Type",
                "Visit Fee",
                "Paid",
                "Due",
                "Method",
                "Status",
                "Received",
                "Note",
                "Action",
              ].map((head) => (
                <th
                  key={head}
                  className="border-b border-r border-slate-200 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600 first:border-l"
                >
                  {head}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {data.appointmentIncomes.map((item, index) => (
              <tr
                key={item.id}
                className={[
                  "transition hover:bg-cyan-50/60",
                  index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
                ].join(" ")}
              >
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700 first:border-l">
                  {item.date}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.serialNo || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950">
                  {item.patientName || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.phone || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.doctorName || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.appointmentType || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950">
                  ৳ {money(item.visitFee)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                  ৳ {money(item.paidAmount)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-red-600">
                  ৳ {money(item.dueAmount)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {getMethodLabel(item.paymentMethod)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5">
                  <span
                    className={[
                      "inline-flex rounded-full border px-2.5 py-1 text-[11px] font-black",
                      statusClass(item.paymentStatus),
                    ].join(" ")}
                  >
                    {getStatusLabel(item.paymentStatus)}
                  </span>
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.receivedBy || "-"}
                </td>
                <td className="max-w-[220px] border-b border-r border-slate-100 px-3 py-2.5 text-sm font-semibold text-slate-500">
                  {item.note || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5">
                  {renderActionButtons("appointment", item)}
                </td>
              </tr>
            ))}

            {!data.appointmentIncomes.length && (
              <tr>
                <td
                  colSpan={14}
                  className="px-4 py-12 text-center text-sm font-black text-slate-400"
                >
                  No appointment income found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    }

    if (activeTab === "expenses") {
      return (
        <table className="w-full min-w-[1050px] border-separate border-spacing-0">
          <thead className="sticky top-0 z-20">
            <tr>
              {[
                "Date",
                "Expense Title",
                "Category",
                "Amount",
                "Method",
                "Paid By",
                "Note",
                "Action",
              ].map((head) => (
                <th
                  key={head}
                  className="border-b border-r border-slate-200 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600 first:border-l"
                >
                  {head}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {data.expenses.map((item, index) => (
              <tr
                key={item.id}
                className={[
                  "transition hover:bg-red-50/40",
                  index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
                ].join(" ")}
              >
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700 first:border-l">
                  {item.date}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950">
                  {item.title || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {getCategoryLabel(item.category)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-red-600">
                  ৳ {money(item.amount)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {getMethodLabel(item.paymentMethod)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.paidBy || "-"}
                </td>
                <td className="max-w-[260px] border-b border-r border-slate-100 px-3 py-2.5 text-sm font-semibold text-slate-500">
                  {item.note || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5">
                  {renderActionButtons("expense", item)}
                </td>
              </tr>
            ))}

            {!data.expenses.length && (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-12 text-center text-sm font-black text-slate-400"
                >
                  No expense found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    }

    if (activeTab === "dueCollections") {
      return (
        <table className="w-full min-w-[950px] border-separate border-spacing-0">
          <thead className="sticky top-0 z-20">
            <tr>
              {[
                "Date",
                "Patient",
                "Phone",
                "Amount",
                "Method",
                "Received By",
                "Note",
                "Action",
              ].map((head) => (
                <th
                  key={head}
                  className="border-b border-r border-slate-200 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600 first:border-l"
                >
                  {head}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {data.dueCollections.map((item, index) => (
              <tr
                key={item.id}
                className={[
                  "transition hover:bg-amber-50/50",
                  index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
                ].join(" ")}
              >
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700 first:border-l">
                  {item.date}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950">
                  {item.patientName || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.phone || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                  ৳ {money(item.amount)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {getMethodLabel(item.paymentMethod)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.receivedBy || "-"}
                </td>
                <td className="max-w-[260px] border-b border-r border-slate-100 px-3 py-2.5 text-sm font-semibold text-slate-500">
                  {item.note || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5">
                  {renderActionButtons("due", item)}
                </td>
              </tr>
            ))}

            {!data.dueCollections.length && (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-12 text-center text-sm font-black text-slate-400"
                >
                  No due collection found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    }

    if (activeTab === "otherIncomes") {
      return (
        <table className="w-full min-w-[950px] border-separate border-spacing-0">
          <thead className="sticky top-0 z-20">
            <tr>
              {[
                "Date",
                "Income Title",
                "Category",
                "Amount",
                "Method",
                "Received By",
                "Note",
                "Action",
              ].map((head) => (
                <th
                  key={head}
                  className="border-b border-r border-slate-200 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600 first:border-l"
                >
                  {head}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {data.otherIncomes.map((item, index) => (
              <tr
                key={item.id}
                className={[
                  "transition hover:bg-emerald-50/50",
                  index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
                ].join(" ")}
              >
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700 first:border-l">
                  {item.date}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950">
                  {item.title || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.category || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                  ৳ {money(item.amount)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {getMethodLabel(item.paymentMethod)}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                  {item.receivedBy || "-"}
                </td>
                <td className="max-w-[260px] border-b border-r border-slate-100 px-3 py-2.5 text-sm font-semibold text-slate-500">
                  {item.note || "-"}
                </td>
                <td className="border-b border-r border-slate-100 px-3 py-2.5">
                  {renderActionButtons("income", item)}
                </td>
              </tr>
            ))}

            {!data.otherIncomes.length && (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-12 text-center text-sm font-black text-slate-400"
                >
                  No other income found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    }

    return (
      <table className="w-full min-w-[1180px] border-separate border-spacing-0">
        <thead className="sticky top-0 z-20">
          <tr>
            {[
              "Date",
              "Opening",
              "Appointment Income",
              "Other Income",
              "Expense",
              "Due Collection",
              "Refund",
              "Net Balance",
              "Closing",
              "Note",
            ].map((head) => (
              <th
                key={head}
                className="border-b border-r border-slate-200 bg-slate-100 px-3 py-3 text-left text-[11px] font-black uppercase tracking-wider text-slate-600 first:border-l"
              >
                {head}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {data.overallRows.map((item, index) => (
            <tr
              key={item.date}
              className={[
                "transition hover:bg-cyan-50/50",
                index % 2 === 0 ? "bg-white" : "bg-slate-50/70",
              ].join(" ")}
            >
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-slate-950 first:border-l">
                {item.date}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-bold text-slate-700">
                ৳ {money(item.openingBalance)}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                ৳ {money(item.totalAppointmentIncome)}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                ৳ {money(item.otherIncome)}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-red-600">
                ৳ {money(item.totalExpense)}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-emerald-700">
                ৳ {money(item.dueCollection)}
              </td>
              <td className="border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black text-violet-700">
                ৳ {money(item.refund)}
              </td>
              <td
                className={[
                  "border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black",
                  item.netBalance < 0 ? "text-red-600" : "text-slate-950",
                ].join(" ")}
              >
                ৳ {money(item.netBalance)}
              </td>
              <td
                className={[
                  "border-b border-r border-slate-100 px-3 py-2.5 text-sm font-black",
                  item.closingBalance < 0 ? "text-red-600" : "text-slate-950",
                ].join(" ")}
              >
                ৳ {money(item.closingBalance)}
              </td>
              <td className="max-w-[260px] border-b border-r border-slate-100 px-3 py-2.5 text-sm font-semibold text-slate-500">
                {item.note || "-"}
              </td>
            </tr>
          ))}

          {!data.overallRows.length && (
            <tr>
              <td
                colSpan={10}
                className="px-4 py-12 text-center text-sm font-black text-slate-400"
              >
                No overall report data found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    );
  };

  return (
    <>
      <style>{accountPageStyles}</style>

      <section className="accounts-screen-area mx-auto grid max-w-7xl gap-3">
        <GlassCard className="p-4">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Banknote size={20} className="text-cyan-700" />
                <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
                  Accounts
                </p>
              </div>

              <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                Accounts Overview
              </h2>

              <p className="mt-1 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Daily income, appointment fee, expense, due collection, and
                overall balance — all in one Excel-style account sheet.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={loadAccounts}
                disabled={loading || saving}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:opacity-60"
              >
                <RefreshCcw size={15} className={loading ? "animate-spin" : ""} />
                Refresh
              </button>

              <button
                type="button"
                onClick={exportExcel}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-black text-emerald-700 shadow-sm transition hover:bg-emerald-100"
              >
                <Download size={15} />
                Export
              </button>

              <button
                type="button"
                onClick={printReport}
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-slate-950 px-4 text-sm font-black text-white shadow-sm transition hover:bg-slate-800"
              >
                <Printer size={15} />
                Print / PDF
              </button>
            </div>
          </div>

          <div className="mt-3">
            <Notice notice={notice} />
          </div>
        </GlassCard>

        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          {summaryCards.map((item) => (
            <div
              key={item.label}
              className={[
                "rounded-2xl border px-4 py-3 shadow-sm",
                toneClass(item.tone, item.value),
              ].join(" ")}
            >
              <p className="text-[11px] font-black uppercase tracking-wider opacity-80">
                {item.label}
              </p>
              <h3 className="mt-1 text-xl font-black">
                ৳ {money(item.value)}
              </h3>
              <p className="mt-0.5 text-xs font-bold opacity-80">{item.hint}</p>
            </div>
          ))}
        </div>

        <GlassCard className="p-4">
          <div className="mb-3 flex items-center gap-2">
            <Filter size={17} className="text-slate-600" />
            <h3 className="text-base font-black text-slate-950">
              Filter Account Data
            </h3>
          </div>

          <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-5">
            <TextInput
              label="Date From"
              type="date"
              value={filters.dateFrom}
              onChange={(value) => updateFilter("dateFrom", value)}
            />

            <TextInput
              label="Date To"
              type="date"
              value={filters.dateTo}
              onChange={(value) => updateFilter("dateTo", value)}
            />

            <SelectInput
              label="Payment Method"
              value={filters.paymentMethod}
              onChange={(value) => updateFilter("paymentMethod", value)}
              options={paymentMethods}
            />

            <SelectInput
              label="Status"
              value={filters.status}
              onChange={(value) => updateFilter("status", value)}
              options={paymentStatuses}
            />

            <TextInput
              label="Patient Name"
              value={filters.patientName}
              onChange={(value) => updateFilter("patientName", value)}
              placeholder="Search patient"
            />
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={loadAccounts}
              disabled={loading}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-cyan-700 px-4 text-sm font-black text-white transition hover:bg-cyan-800 disabled:opacity-60"
            >
              <Search size={15} />
              Apply
            </button>

            <button
              type="button"
              onClick={resetFilters}
              className="h-10 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 transition hover:bg-slate-50"
            >
              Reset
            </button>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <h3 className="text-base font-black text-slate-950">
                Quick Entry
              </h3>
              <p className="text-sm font-semibold text-slate-500">
                Add income, expense, due collection, and appointment payment.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => openAddModal("appointment")}
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-cyan-700 px-4 text-sm font-black text-white transition hover:bg-cyan-800"
              >
                <Plus size={15} />
                Appointment
              </button>

              <button
                type="button"
                onClick={() => openAddModal("income")}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-black text-emerald-700 transition hover:bg-emerald-100"
              >
                <Plus size={15} />
                Income
              </button>

              <button
                type="button"
                onClick={() => openAddModal("expense")}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 text-sm font-black text-red-700 transition hover:bg-red-100"
              >
                <Plus size={15} />
                Expense
              </button>

              <button
                type="button"
                onClick={() => openAddModal("due")}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 text-sm font-black text-amber-700 transition hover:bg-amber-100"
              >
                <Plus size={15} />
                Due Collection
              </button>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="overflow-hidden p-0">
          <div className="flex flex-col gap-3 border-b border-slate-100 bg-white p-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-center gap-2">
              <FileText size={18} className="text-cyan-700" />
              <div>
                <h3 className="text-base font-black text-slate-950">
                  Account Sheet
                </h3>
                <p className="text-sm font-semibold text-slate-500">
                  {getScreenRows().length} records showing
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 rounded-2xl border border-slate-100 bg-slate-50 p-1">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setActiveTab(tab.key)}
                  className={[
                    "rounded-xl px-3 py-2 text-xs font-black transition",
                    activeTab === tab.key
                      ? "bg-slate-950 text-white shadow-sm"
                      : "text-slate-600 hover:bg-white hover:text-slate-950",
                  ].join(" ")}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="grid min-h-60 place-items-center p-10 text-sm font-black text-slate-500">
              Loading accounts data...
            </div>
          ) : (
            <div className="max-h-[650px] overflow-auto">{renderTable()}</div>
          )}
        </GlassCard>

        {modalType && (
          <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/50 p-4">
            <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
              <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-5 py-4">
                <div>
                  <p className="text-xs font-black uppercase tracking-wider text-cyan-600">
                    {editingItem ? "Edit Record" : "Add Record"}
                  </p>
                  <h3 className="text-xl font-black text-slate-950">
                    {modalTitleMap[modalType]}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={closeModal}
                  className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:bg-slate-50"
                >
                  <X size={17} />
                </button>
              </div>

              <form onSubmit={saveRecord} className="grid gap-4 p-5">
                <div className="grid gap-3 md:grid-cols-2">
                  <TextInput
                    label="Date"
                    type="date"
                    value={form.date}
                    onChange={(value) => updateForm("date", value)}
                  />

                  <SelectInput
                    label="Payment Method"
                    value={form.paymentMethod}
                    onChange={(value) => updateForm("paymentMethod", value)}
                    options={paymentMethods.filter((item) => item.value !== "ALL")}
                  />

                  {modalType === "appointment" && (
                    <>
                      <TextInput
                        label="Serial No"
                        value={form.serialNo}
                        onChange={(value) => updateForm("serialNo", value)}
                        placeholder="Example: A-101"
                      />

                      <TextInput
                        label="Patient Name"
                        value={form.patientName}
                        onChange={(value) => updateForm("patientName", value)}
                        placeholder="Patient name"
                      />

                      <TextInput
                        label="Phone"
                        value={form.phone}
                        onChange={(value) => updateForm("phone", value)}
                        placeholder="01XXXXXXXXX"
                      />

                      <TextInput
                        label="Doctor Name"
                        value={form.doctorName}
                        onChange={(value) => updateForm("doctorName", value)}
                        placeholder="Doctor name"
                      />

                      <TextInput
                        label="Appointment Type"
                        value={form.appointmentType}
                        onChange={(value) => updateForm("appointmentType", value)}
                        placeholder="New / Follow-up / Online"
                      />

                      <SelectInput
                        label="Payment Status"
                        value={form.paymentStatus}
                        onChange={(value) => updateForm("paymentStatus", value)}
                        options={paymentStatuses.filter(
                          (item) => item.value !== "ALL"
                        )}
                      />

                      <TextInput
                        label="Visit Fee"
                        type="number"
                        value={form.visitFee}
                        onChange={(value) => updateForm("visitFee", value)}
                        placeholder="0"
                      />

                      <TextInput
                        label="Paid Amount"
                        type="number"
                        value={form.paidAmount}
                        onChange={(value) => updateForm("paidAmount", value)}
                        placeholder="0"
                      />

                      <div className="rounded-xl border border-red-200 bg-red-50 p-3">
                        <p className="text-[11px] font-black uppercase tracking-wider text-red-500">
                          Auto Due Amount
                        </p>
                        <p className="mt-1 text-xl font-black text-red-700">
                          ৳ {money(duePreview)}
                        </p>
                      </div>

                      <TextInput
                        label="Received By"
                        value={form.receivedBy}
                        onChange={(value) => updateForm("receivedBy", value)}
                        placeholder="Admin / Staff name"
                      />
                    </>
                  )}

                  {modalType === "expense" && (
                    <>
                      <TextInput
                        label="Expense Title"
                        value={form.title}
                        onChange={(value) => updateForm("title", value)}
                        placeholder="Expense title"
                      />

                      <SelectInput
                        label="Category"
                        value={form.category}
                        onChange={(value) => updateForm("category", value)}
                        options={expenseCategories}
                      />

                      <TextInput
                        label="Amount"
                        type="number"
                        value={form.amount}
                        onChange={(value) => updateForm("amount", value)}
                        placeholder="0"
                      />

                      <TextInput
                        label="Paid By"
                        value={form.paidBy}
                        onChange={(value) => updateForm("paidBy", value)}
                        placeholder="Admin / Staff name"
                      />
                    </>
                  )}

                  {modalType === "due" && (
                    <>
                      <TextInput
                        label="Patient Name"
                        value={form.patientName}
                        onChange={(value) => updateForm("patientName", value)}
                        placeholder="Patient name"
                      />

                      <TextInput
                        label="Phone"
                        value={form.phone}
                        onChange={(value) => updateForm("phone", value)}
                        placeholder="01XXXXXXXXX"
                      />

                      <TextInput
                        label="Amount"
                        type="number"
                        value={form.amount}
                        onChange={(value) => updateForm("amount", value)}
                        placeholder="0"
                      />

                      <TextInput
                        label="Received By"
                        value={form.receivedBy}
                        onChange={(value) => updateForm("receivedBy", value)}
                        placeholder="Admin / Staff name"
                      />
                    </>
                  )}

                  {modalType === "income" && (
                    <>
                      <TextInput
                        label="Income Title"
                        value={form.title}
                        onChange={(value) => updateForm("title", value)}
                        placeholder="Example: Other service income"
                      />

                      <TextInput
                        label="Category"
                        value={form.category}
                        onChange={(value) => updateForm("category", value)}
                        placeholder="Example: Other Income"
                      />

                      <TextInput
                        label="Amount"
                        type="number"
                        value={form.amount}
                        onChange={(value) => updateForm("amount", value)}
                        placeholder="0"
                      />

                      <TextInput
                        label="Received By"
                        value={form.receivedBy}
                        onChange={(value) => updateForm("receivedBy", value)}
                        placeholder="Admin / Staff name"
                      />
                    </>
                  )}

                  <TextAreaInput
                    label="Note"
                    value={form.note}
                    onChange={(value) => updateForm("note", value)}
                    placeholder="Optional note"
                  />
                </div>

                <div className="flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="h-10 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-50"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={saving}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-slate-950 px-5 text-sm font-black text-white transition hover:bg-slate-800 disabled:opacity-60"
                  >
                    <Save size={15} />
                    {saving ? "Saving..." : "Save Record"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </section>

      <div className="accounts-print-area">
        <div className="accounts-print-page">
          <div className="accounts-print-header">
            <div>
              <h1 className="accounts-print-title">Accounts Report</h1>
              <p className="accounts-print-subtitle">
                {activeTabLabel} | Date Range: {filters.dateFrom || "-"} to{" "}
                {filters.dateTo || "-"}
              </p>
            </div>

            <div className="accounts-print-meta">
              <div>Generated: {getTodayDate()}</div>
              <div>Payment Method: {getMethodLabel(filters.paymentMethod)}</div>
              <div>Status: {getStatusLabel(filters.status)}</div>
              <div>Patient: {filters.patientName || "All"}</div>
            </div>
          </div>

          <div className="accounts-print-summary">
            {summaryCards.map((item) => (
              <div key={item.label} className="accounts-print-summary-card">
                <p className="accounts-print-summary-label">{item.label}</p>
                <p className="accounts-print-summary-value">
                  Tk {money(item.value)}
                </p>
              </div>
            ))}
          </div>

          <h2 className="accounts-print-section-title">{activeTabLabel}</h2>

          <table className="accounts-print-table">
            <thead>
              <tr>
                {printHeaders.map((head) => (
                  <th key={head}>{head}</th>
                ))}
              </tr>
            </thead>

            <tbody>
              {printRows.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {printHeaders.map((head) => {
                    const value = row[head];
                    const lowerHead = head.toLowerCase();
                    const isMoneyIn =
                      lowerHead.includes("income") ||
                      lowerHead.includes("paid") ||
                      lowerHead.includes("collection") ||
                      lowerHead.includes("closing");
                    const isMoneyOut =
                      lowerHead.includes("expense") ||
                      lowerHead.includes("due") ||
                      lowerHead.includes("refund");

                    return (
                      <td
                        key={head}
                        className={
                          isMoneyOut ? "money-out" : isMoneyIn ? "money-in" : ""
                        }
                      >
                        {value || "-"}
                      </td>
                    );
                  })}
                </tr>
              ))}

              {!printRows.length && (
                <tr>
                  <td colSpan={printHeaders.length || 1}>
                    No data available for print.
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="accounts-print-footer">
            <div>Prepared By: ____________________</div>
            <div>Checked By: ____________________</div>
            <div>Authorized Signature: ____________________</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AccountsPage;