import PrescriptionPage from "./PrescriptionPage";

export default PrescriptionPage;
