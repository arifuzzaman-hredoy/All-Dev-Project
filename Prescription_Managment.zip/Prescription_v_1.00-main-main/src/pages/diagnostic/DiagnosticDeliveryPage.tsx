import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticDeliveryPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Delivery" description="Report delivery, SMS notification and patient pickup shell." />;
export default DiagnosticDeliveryPage;
