import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticDashboardPage = () => (
  <DemoWorkspacePage
    eyebrow="Diagnostic"
    title="Diagnostic dashboard"
    description="Lab workflow shell for orders, sample collection, pending reports, delivery and collections."
    stats={[
      { label: "Today lab orders", value: "46", note: "Registered" },
      { label: "Sample collected", value: "31", note: "In lab" },
      { label: "Reports pending", value: "14", note: "Needs review" },
      { label: "Reports delivered", value: "22", note: "Today" },
      { label: "Today collection", value: "$960", note: "Billing desk" },
      { label: "Due amount", value: "$180", note: "Pending" },
    ]}
  />
);
export default DiagnosticDashboardPage;
