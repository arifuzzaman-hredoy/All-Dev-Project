import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticTestCatalogPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Test catalog" description="Test list, package pricing, sample type and report timing shell." />;
export default DiagnosticTestCatalogPage;
