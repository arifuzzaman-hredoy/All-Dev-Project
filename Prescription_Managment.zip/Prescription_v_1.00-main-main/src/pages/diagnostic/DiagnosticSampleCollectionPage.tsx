import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticSampleCollectionPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Sample collection" description="Sample pickup, collection desk and lab handoff shell." />;
export default DiagnosticSampleCollectionPage;
