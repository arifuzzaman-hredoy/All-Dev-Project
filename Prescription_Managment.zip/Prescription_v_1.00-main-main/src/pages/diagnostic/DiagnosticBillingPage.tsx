import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticBillingPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Billing" description="Diagnostic billing, discounts, dues and receipts shell." />;
export default DiagnosticBillingPage;
