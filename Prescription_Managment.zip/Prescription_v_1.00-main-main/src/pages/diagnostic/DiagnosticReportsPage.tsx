import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticReportsPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Reports" description="Pending, reviewed, delivered and printed lab report shell." />;
export default DiagnosticReportsPage;
