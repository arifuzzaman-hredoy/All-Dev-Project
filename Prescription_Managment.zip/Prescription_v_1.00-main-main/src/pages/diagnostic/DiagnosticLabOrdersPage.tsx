import DemoWorkspacePage from "../DemoWorkspacePage";
const DiagnosticLabOrdersPage = () => <DemoWorkspacePage eyebrow="Diagnostic" title="Lab orders" description="Lab order tracking, patient billing and report status shell." />;
export default DiagnosticLabOrdersPage;
