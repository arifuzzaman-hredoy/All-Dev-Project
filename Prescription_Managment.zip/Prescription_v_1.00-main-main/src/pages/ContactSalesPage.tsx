import { Link } from "react-router-dom";
import PageHeader from "../components/common/PageHeader";

const ContactSalesPage = () => (
  <main className="mx-auto max-w-4xl px-4 py-10">
    <PageHeader eyebrow="Contact sales" title="Talk to the SaaS team" description="Use this demo page to preview the sales handoff flow for clinics, diagnostics and hospitals." />
    <div className="mt-6 rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_16px_38px_rgba(15,23,42,0.06)]">
      <p className="text-sm font-semibold leading-7 text-slate-600">Sales can qualify package, tenant setup, custom modules, SMS volume and future hospital/IPD readiness from here.</p>
      <Link to="/book-demo" className="mt-4 inline-flex rounded-full bg-teal-700 px-5 py-3 text-sm font-black text-white">Book a demo</Link>
    </div>
  </main>
);

export default ContactSalesPage;
