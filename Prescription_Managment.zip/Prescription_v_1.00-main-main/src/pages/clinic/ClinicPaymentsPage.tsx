import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Banknote,
  CalendarClock,
  CheckCircle2,
  Eye,
  Filter,
  Phone,
  ReceiptText,
  RotateCcw,
  Search,
  Trash2,
  UserPlus,
  WalletCards,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type PaymentType = "Collection" | "Refund" | "Settlement" | "Adjustment";
type PaymentStatus = "Pending" | "Completed" | "Failed" | "Refunded" | "Cancelled";
type PaymentMethod = "Cash" | "Card" | "bKash" | "Nagad" | "Bank" | "Cheque";

type ClinicPayment = {
  id: string;
  receiptNo: string;
  invoiceNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  paymentDate: string;
  paymentTime: string;
  paymentFor: string;
  amount: number;
  method: PaymentMethod;
  type: PaymentType;
  status: PaymentStatus;
  collectedBy: string;
  transactionId: string;
  notes: string;
};

const paymentTypes: PaymentType[] = [
  "Collection",
  "Refund",
  "Settlement",
  "Adjustment",
];

const paymentStatuses: PaymentStatus[] = [
  "Pending",
  "Completed",
  "Failed",
  "Refunded",
  "Cancelled",
];

const paymentMethods: PaymentMethod[] = [
  "Cash",
  "Card",
  "bKash",
  "Nagad",
  "Bank",
  "Cheque",
];

const mockPayments: ClinicPayment[] = [
  {
    id: "PAY-ID-1001",
    receiptNo: "RCPT-1001",
    invoiceNo: "INV-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    paymentDate: "2026-06-20",
    paymentTime: "09:45 AM",
    paymentFor: "Consultation invoice",
    amount: 900,
    method: "Cash",
    type: "Collection",
    status: "Completed",
    collectedBy: "Front Desk",
    transactionId: "CASH-1001",
    notes: "Consultation fee collected.",
  },
  {
    id: "PAY-ID-1002",
    receiptNo: "RCPT-1002",
    invoiceNo: "INV-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    paymentDate: "2026-06-20",
    paymentTime: "10:20 AM",
    paymentFor: "Diagnostics partial bill",
    amount: 800,
    method: "bKash",
    type: "Collection",
    status: "Completed",
    collectedBy: "Reception",
    transactionId: "BKASH-TXN-8831",
    notes: "Partial payment received.",
  },
  {
    id: "PAY-ID-1003",
    receiptNo: "RCPT-1003",
    invoiceNo: "INV-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    paymentDate: "2026-06-19",
    paymentTime: "04:15 PM",
    paymentFor: "Package bill refund",
    amount: 300,
    method: "Nagad",
    type: "Refund",
    status: "Refunded",
    collectedBy: "Account Desk",
    transactionId: "NAGAD-RFD-1003",
    notes: "Refund completed for package adjustment.",
  },
];

const emptyForm = {
  invoiceNo: "",
  patientId: "",
  patientName: "",
  phone: "",
  paymentDate: "",
  paymentTime: "",
  paymentFor: "",
  amount: "700",
  method: "Cash" as PaymentMethod,
  type: "Collection" as PaymentType,
  status: "Completed" as PaymentStatus,
  collectedBy: "",
  transactionId: "",
  notes: "",
};

const statusClass: Record<PaymentStatus, string> = {
  Pending: "border-amber-200 bg-amber-50 text-amber-700",
  Completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Failed: "border-rose-200 bg-rose-50 text-rose-700",
  Refunded: "border-blue-200 bg-blue-50 text-blue-700",
  Cancelled: "border-slate-200 bg-slate-50 text-slate-500",
};

const typeClass: Record<PaymentType, string> = {
  Collection: "border-teal-200 bg-teal-50 text-teal-800",
  Refund: "border-blue-200 bg-blue-50 text-blue-700",
  Settlement: "border-violet-200 bg-violet-50 text-violet-700",
  Adjustment: "border-amber-200 bg-amber-50 text-amber-700",
};

const methodClass: Record<PaymentMethod, string> = {
  Cash: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Card: "border-blue-200 bg-blue-50 text-blue-700",
  bKash: "border-pink-200 bg-pink-50 text-pink-700",
  Nagad: "border-orange-200 bg-orange-50 text-orange-700",
  Bank: "border-indigo-200 bg-indigo-50 text-indigo-700",
  Cheque: "border-slate-200 bg-slate-50 text-slate-600",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const localFilter = (
  items: ClinicPayment[],
  filters: {
    query: string;
    status: string;
    type: string;
    method: string;
    collectedBy: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.receiptNo} ${item.invoiceNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.paymentFor} ${item.method} ${item.type} ${item.status} ${item.collectedBy} ${item.transactionId} ${item.notes}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.status || item.status === filters.status) &&
      (!filters.type || item.type === filters.type) &&
      (!filters.method || item.method === filters.method) &&
      (!filters.collectedBy || item.collectedBy === filters.collectedBy)
    );
  });
};

const loadPayments = async (
  filters = {
    query: "",
    status: "",
    type: "",
    method: "",
    collectedBy: "",
  },
  fallback = mockPayments,
): Promise<ClinicPayment[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.type) params.set("type", filters.type);
    if (filters.method) params.set("method", filters.method);
    if (filters.collectedBy) params.set("collectedBy", filters.collectedBy);

    const url = params.toString()
      ? `/api/clinic/payments?${params.toString()}`
      : "/api/clinic/payments";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { payments?: ClinicPayment[] };

    return Array.isArray(data.payments)
      ? data.payments
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createPaymentApi = async (
  payload: Omit<ClinicPayment, "id" | "receiptNo">,
): Promise<ClinicPayment> => {
  const response = await fetch("/api/clinic/payments", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create payment failed");

  const data = (await response.json()) as { payment?: ClinicPayment };
  if (!data.payment) throw new Error("Invalid payment response");

  return data.payment;
};

const updatePaymentStatusApi = async (
  id: string,
  status: PaymentStatus,
): Promise<ClinicPayment> => {
  const response = await fetch(`/api/clinic/payments/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update payment status failed");

  const data = (await response.json()) as { payment?: ClinicPayment };
  if (!data.payment) throw new Error("Invalid status response");

  return data.payment;
};

const refundPaymentApi = async (id: string): Promise<ClinicPayment> => {
  const response = await fetch(`/api/clinic/payments/${id}/refund`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({}),
  });

  if (!response.ok) throw new Error("Refund payment failed");

  const data = (await response.json()) as { payment?: ClinicPayment };
  if (!data.payment) throw new Error("Invalid refund response");

  return data.payment;
};

const deletePaymentApi = async (id: string) => {
  const response = await fetch(`/api/clinic/payments/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete payment failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicPaymentsPage = () => {
  const [payments, setPayments] = useState<ClinicPayment[]>(mockPayments);
  const [visiblePayments, setVisiblePayments] =
    useState<ClinicPayment[]>(mockPayments);
  const [selectedPayment, setSelectedPayment] =
    useState<ClinicPayment | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [methodFilter, setMethodFilter] = useState("");
  const [collectorFilter, setCollectorFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      type: typeFilter,
      method: methodFilter,
      collectedBy: collectorFilter,
    }),
    [query, statusFilter, typeFilter, methodFilter, collectorFilter],
  );

  const collectorOptions = useMemo(
    () => Array.from(new Set(payments.map((item) => item.collectedBy))),
    [payments],
  );

  const formAmount = Number(form.amount);

  const formReady =
    form.invoiceNo.trim().length >= 2 &&
    form.patientId.trim().length >= 2 &&
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    form.paymentDate.trim().length >= 4 &&
    form.paymentTime.trim().length >= 2 &&
    form.paymentFor.trim().length >= 2 &&
    Number.isFinite(formAmount) &&
    formAmount > 0 &&
    form.collectedBy.trim().length >= 2 &&
    paymentMethods.includes(form.method) &&
    paymentTypes.includes(form.type) &&
    paymentStatuses.includes(form.status);

  useEffect(() => {
    let active = true;

    loadPayments().then((data) => {
      if (!active) return;
      setPayments(data);
      setVisiblePayments(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadPayments(filters, payments).then((data) => {
        if (!active) return;
        setVisiblePayments(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, payments]);

  const stats = useMemo(() => {
    const collected = payments
      .filter((item) => item.type === "Collection" && item.status === "Completed")
      .reduce((total, item) => total + Number(item.amount || 0), 0);

    const refunds = payments
      .filter((item) => item.type === "Refund" || item.status === "Refunded")
      .reduce((total, item) => total + Number(item.amount || 0), 0);

    const pending = payments.filter((item) => item.status === "Pending").length;

    return [
      {
        label: "Receipts",
        value: String(payments.length),
        icon: ReceiptText,
      },
      {
        label: "Collected",
        value: money(collected),
        icon: Banknote,
      },
      {
        label: "Refunds",
        value: money(refunds),
        icon: RotateCcw,
      },
      {
        label: "Pending",
        value: String(pending),
        icon: CalendarClock,
      },
    ];
  }, [payments]);

  const syncPayments = (nextPayments: ClinicPayment[]) => {
    setPayments(nextPayments);
    setVisiblePayments(localFilter(nextPayments, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setTypeFilter("");
    setMethodFilter("");
    setCollectorFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Payment form complete korle Add Payment button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      invoiceNo: form.invoiceNo.trim(),
      patientId: form.patientId.trim(),
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      paymentDate: form.paymentDate.trim(),
      paymentTime: form.paymentTime.trim(),
      paymentFor: form.paymentFor.trim(),
      amount: Number(form.amount),
      method: form.method,
      type: form.type,
      status: form.status,
      collectedBy: form.collectedBy.trim(),
      transactionId: form.transactionId.trim() || `${form.method}-${Date.now()}`,
      notes: form.notes.trim() || "No payment note",
    };

    const fallbackPayment: ClinicPayment = {
      id: `PAY-ID-${Date.now()}`,
      receiptNo: `RCPT-${String(payments.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdPayment = await createPaymentApi(payload);
      syncPayments([createdPayment, ...payments]);
      setMessage("Payment added successfully.");
    } catch {
      syncPayments([fallbackPayment, ...payments]);
      setMessage("Payment added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    payment: ClinicPayment,
    status: PaymentStatus,
  ) => {
    const previousPayments = payments;

    const nextPayments = payments.map((item) =>
      item.id === payment.id ? { ...item, status } : item,
    );

    syncPayments(nextPayments);
    setMessage("");

    try {
      const updatedPayment = await updatePaymentStatusApi(payment.id, status);

      syncPayments(
        nextPayments.map((item) =>
          item.id === updatedPayment.id ? updatedPayment : item,
        ),
      );
    } catch {
      syncPayments(previousPayments);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRefundPayment = async (payment: ClinicPayment) => {
    const previousPayments = payments;

    const nextPayments = payments.map((item) =>
      item.id === payment.id
        ? { ...item, status: "Refunded" as PaymentStatus, type: "Refund" as PaymentType }
        : item,
    );

    syncPayments(nextPayments);
    setMessage("");

    try {
      const updatedPayment = await refundPaymentApi(payment.id);

      syncPayments(
        nextPayments.map((item) =>
          item.id === updatedPayment.id ? updatedPayment : item,
        ),
      );
      setMessage("Payment refunded successfully.");
    } catch {
      syncPayments(previousPayments);
      setMessage("Backend refund failed. Previous payment restored.");
    }
  };

  const handleRemovePayment = async (payment: ClinicPayment) => {
    const previousPayments = payments;
    const nextPayments = payments.filter((item) => item.id !== payment.id);

    syncPayments(nextPayments);
    setMessage("");

    try {
      await deletePaymentApi(payment.id);
      setMessage("Payment removed successfully.");
    } catch {
      syncPayments(previousPayments);
      setMessage("Backend delete failed, payment restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Payments
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Payment collection, refunds, receipts and settlement records.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading payments from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/filter/view/refund/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Payment
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_160px_180px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search receipt, invoice, patient, phone, transaction"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {paymentStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Type</option>
              {paymentTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <select
              value={methodFilter}
              onChange={(event) => setMethodFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Method</option>
              {paymentMethods.map((method) => (
                <option key={method} value={method}>
                  {method}
                </option>
              ))}
            </select>

            <select
              value={collectorFilter}
              onChange={(event) => setCollectorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Collector</option>
              {collectorOptions.map((collector) => (
                <option key={collector} value={collector}>
                  {collector}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1240px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Receipt / Patient
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Payment For
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Amount
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Method
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visiblePayments.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.receiptNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId} · {item.invoiceNo}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="max-w-[260px] truncate text-sm font-black text-slate-800">
                        {item.paymentFor}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.paymentDate} · {item.paymentTime}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Collected by {item.collectedBy}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-900">
                        {money(item.amount)}
                      </p>
                      <div className="mt-1">
                        <Badge label={item.type} className={typeClass[item.type]} />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <Badge label={item.method} className={methodClass[item.method]} />
                      <p className="mt-1 max-w-[180px] truncate text-[11px] font-bold text-slate-500">
                        {item.transactionId}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as PaymentStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {paymentStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedPayment(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Completed")}
                          disabled={item.status === "Completed" || item.status === "Refunded"}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Complete
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRefundPayment(item)}
                          disabled={item.status === "Refunded" || item.status === "Cancelled"}
                          className="inline-flex items-center gap-1 border border-blue-100 bg-blue-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-blue-700 transition hover:border-blue-200 hover:bg-blue-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <RotateCcw size={13} />
                          Refund
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Cancelled")}
                          disabled={item.status === "Cancelled"}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <XCircle size={13} />
                          Cancel
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemovePayment(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visiblePayments.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No payment found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <WalletCards size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedPayment && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Payment Receipt Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedPayment.receiptNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedPayment.patientName} · {selectedPayment.type}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedPayment(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Invoice", selectedPayment.invoiceNo],
                ["Patient", `${selectedPayment.patientName} (${selectedPayment.patientId})`],
                ["Phone", selectedPayment.phone],
                ["Payment For", selectedPayment.paymentFor],
                ["Amount", money(selectedPayment.amount)],
                ["Method", selectedPayment.method],
                ["Type", selectedPayment.type],
                ["Status", selectedPayment.status],
                ["Date & Time", `${selectedPayment.paymentDate} · ${selectedPayment.paymentTime}`],
                ["Collected By", selectedPayment.collectedBy],
                ["Transaction ID", selectedPayment.transactionId],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Notes
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedPayment.notes}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-3xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Payment
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New payment receipt
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Invoice, patient, amount, method and transaction info fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Invoice No">
                  <input
                    value={form.invoiceNo}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, invoiceNo: event.target.value }))
                    }
                    placeholder="INV-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient ID">
                  <input
                    value={form.patientId}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientId: event.target.value }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientName: event.target.value }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, phone: event.target.value }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment Date">
                  <input
                    value={form.paymentDate}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        paymentDate: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment Time">
                  <input
                    value={form.paymentTime}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        paymentTime: event.target.value,
                      }))
                    }
                    placeholder="09:30 AM"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment For">
                  <input
                    value={form.paymentFor}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        paymentFor: event.target.value,
                      }))
                    }
                    placeholder="Consultation / Diagnostic bill"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Amount">
                  <input
                    value={form.amount}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, amount: event.target.value }))
                    }
                    type="number"
                    min={1}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment Method">
                  <select
                    value={form.method}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        method: event.target.value as PaymentMethod,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {paymentMethods.map((method) => (
                      <option key={method} value={method}>
                        {method}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Payment Type">
                  <select
                    value={form.type}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        type: event.target.value as PaymentType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {paymentTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as PaymentStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {paymentStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Collected By">
                  <input
                    value={form.collectedBy}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        collectedBy: event.target.value,
                      }))
                    }
                    placeholder="Front Desk / Account Desk"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Transaction ID">
                  <input
                    value={form.transactionId}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        transactionId: event.target.value,
                      }))
                    }
                    placeholder="TXN-12345 / Cash reference"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Notes">
                  <input
                    value={form.notes}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, notes: event.target.value }))
                    }
                    placeholder="Payment note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>
              </div>

              <div className="border border-teal-100 bg-teal-50/70 p-3">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                  Live Summary
                </p>
                <p className="mt-1 text-sm font-black text-slate-800">
                  {form.type} · {form.method} · {money(Number(form.amount || 0))}
                </p>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Payment form complete. Add Payment button enabled."
                  : "Invoice + patient + date + time + amount + collector complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Payment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicPaymentsPage;