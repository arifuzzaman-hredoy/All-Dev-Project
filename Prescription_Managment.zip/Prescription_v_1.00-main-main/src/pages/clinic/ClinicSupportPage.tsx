import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Eye,
  Filter,
  LifeBuoy,
  MessageSquareText,
  Search,
  Send,
  Trash2,
  UserPlus,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type TicketStatus = "Open" | "In Progress" | "Resolved" | "Closed";
type TicketPriority = "Low" | "Medium" | "High" | "Urgent";
type TicketCategory =
  | "Technical"
  | "Billing"
  | "Account"
  | "SMS"
  | "Report"
  | "Feature";

type MessageSender = "Tenant" | "Support" | "Admin";

type SupportMessage = {
  id: string;
  sender: MessageSender;
  message: string;
  createdAt: string;
};

type SupportTicket = {
  id: string;
  ticketNo: string;
  tenantName: string;
  clinicName: string;
  contactEmail: string;
  subject: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  createdDate: string;
  lastUpdated: string;
  assignedTo: string;
  messages: SupportMessage[];
};

const ticketStatuses: TicketStatus[] = [
  "Open",
  "In Progress",
  "Resolved",
  "Closed",
];

const priorities: TicketPriority[] = ["Low", "Medium", "High", "Urgent"];

const categories: TicketCategory[] = [
  "Technical",
  "Billing",
  "Account",
  "SMS",
  "Report",
  "Feature",
];

const mockTickets: SupportTicket[] = [
  {
    id: "SUP-ID-1001",
    ticketNo: "SUP-1001",
    tenantName: "Update Diagnostic Center",
    clinicName: "Update Clinic",
    contactEmail: "admin@updateclinic.test",
    subject: "Prescription PDF not downloading",
    category: "Technical",
    priority: "High",
    status: "In Progress",
    createdDate: "2026-06-20",
    lastUpdated: "2026-06-20",
    assignedTo: "Support Team",
    messages: [
      {
        id: "MSG-1001",
        sender: "Tenant",
        message: "Prescription PDF generate hocche kintu download hocche na.",
        createdAt: "2026-06-20 09:20 AM",
      },
      {
        id: "MSG-1002",
        sender: "Support",
        message: "Issue received. PDF route and browser console check kortesi.",
        createdAt: "2026-06-20 09:45 AM",
      },
    ],
  },
  {
    id: "SUP-ID-1002",
    ticketNo: "SUP-1002",
    tenantName: "Prime Care Clinic",
    clinicName: "Prime Care",
    contactEmail: "owner@primecare.test",
    subject: "SMS balance recharge record mismatch",
    category: "SMS",
    priority: "Medium",
    status: "Open",
    createdDate: "2026-06-20",
    lastUpdated: "2026-06-20",
    assignedTo: "SMS Desk",
    messages: [
      {
        id: "MSG-1003",
        sender: "Tenant",
        message: "Recharge 5000 SMS dekhacche, kintu usage balance kom show kortese.",
        createdAt: "2026-06-20 10:30 AM",
      },
    ],
  },
  {
    id: "SUP-ID-1003",
    ticketNo: "SUP-1003",
    tenantName: "Rangpur Health Point",
    clinicName: "Health Point",
    contactEmail: "support@healthpoint.test",
    subject: "Billing invoice status stuck",
    category: "Billing",
    priority: "Urgent",
    status: "Resolved",
    createdDate: "2026-06-19",
    lastUpdated: "2026-06-20",
    assignedTo: "Billing Support",
    messages: [
      {
        id: "MSG-1004",
        sender: "Tenant",
        message: "Paid korar poreo invoice partial show kortese.",
        createdAt: "2026-06-19 04:15 PM",
      },
      {
        id: "MSG-1005",
        sender: "Admin",
        message: "Payment sync issue fixed. Invoice status updated.",
        createdAt: "2026-06-20 11:05 AM",
      },
    ],
  },
];

const emptyForm = {
  tenantName: "",
  clinicName: "",
  contactEmail: "",
  subject: "",
  category: "Technical" as TicketCategory,
  priority: "Medium" as TicketPriority,
  status: "Open" as TicketStatus,
  assignedTo: "Support Team",
  message: "",
};

const statusClass: Record<TicketStatus, string> = {
  Open: "border-blue-200 bg-blue-50 text-blue-700",
  "In Progress": "border-amber-200 bg-amber-50 text-amber-700",
  Resolved: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Closed: "border-slate-200 bg-slate-50 text-slate-500",
};

const priorityClass: Record<TicketPriority, string> = {
  Low: "border-slate-200 bg-slate-50 text-slate-600",
  Medium: "border-cyan-200 bg-cyan-50 text-cyan-700",
  High: "border-orange-200 bg-orange-50 text-orange-700",
  Urgent: "border-rose-200 bg-rose-50 text-rose-700",
};

const categoryClass: Record<TicketCategory, string> = {
  Technical: "border-teal-200 bg-teal-50 text-teal-800",
  Billing: "border-orange-200 bg-orange-50 text-orange-700",
  Account: "border-blue-200 bg-blue-50 text-blue-700",
  SMS: "border-violet-200 bg-violet-50 text-violet-700",
  Report: "border-indigo-200 bg-indigo-50 text-indigo-700",
  Feature: "border-emerald-200 bg-emerald-50 text-emerald-700",
};

const localFilter = (
  items: SupportTicket[],
  filters: {
    query: string;
    status: string;
    priority: string;
    category: string;
    assignedTo: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.ticketNo} ${item.tenantName} ${item.clinicName} ${item.contactEmail} ${item.subject} ${item.category} ${item.priority} ${item.status} ${item.assignedTo}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.status || item.status === filters.status) &&
      (!filters.priority || item.priority === filters.priority) &&
      (!filters.category || item.category === filters.category) &&
      (!filters.assignedTo || item.assignedTo === filters.assignedTo)
    );
  });
};

const loadTickets = async (
  filters = {
    query: "",
    status: "",
    priority: "",
    category: "",
    assignedTo: "",
  },
  fallback = mockTickets,
): Promise<SupportTicket[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.priority) params.set("priority", filters.priority);
    if (filters.category) params.set("category", filters.category);
    if (filters.assignedTo) params.set("assignedTo", filters.assignedTo);

    const url = params.toString()
      ? `/api/clinic/support?${params.toString()}`
      : "/api/clinic/support";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { tickets?: SupportTicket[] };

    return Array.isArray(data.tickets)
      ? data.tickets
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createTicketApi = async (
  payload: Omit<SupportTicket, "id" | "ticketNo" | "createdDate" | "lastUpdated" | "messages"> & {
    message: string;
  },
): Promise<SupportTicket> => {
  const response = await fetch("/api/clinic/support", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create ticket failed");

  const data = (await response.json()) as { ticket?: SupportTicket };
  if (!data.ticket) throw new Error("Invalid ticket response");

  return data.ticket;
};

const updateTicketStatusApi = async (
  id: string,
  status: TicketStatus,
): Promise<SupportTicket> => {
  const response = await fetch(`/api/clinic/support/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update ticket status failed");

  const data = (await response.json()) as { ticket?: SupportTicket };
  if (!data.ticket) throw new Error("Invalid status response");

  return data.ticket;
};

const addMessageApi = async (
  id: string,
  payload: Omit<SupportMessage, "id" | "createdAt">,
): Promise<SupportTicket> => {
  const response = await fetch(`/api/clinic/support/${id}/messages`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Add support message failed");

  const data = (await response.json()) as { ticket?: SupportTicket };
  if (!data.ticket) throw new Error("Invalid message response");

  return data.ticket;
};

const deleteTicketApi = async (id: string) => {
  const response = await fetch(`/api/clinic/support/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete support ticket failed");
};

const today = () => new Date().toISOString().slice(0, 10);

const nowText = () =>
  new Date().toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "2-digit",
  });

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicSupportPage = () => {
  const [tickets, setTickets] = useState<SupportTicket[]>(mockTickets);
  const [visibleTickets, setVisibleTickets] =
    useState<SupportTicket[]>(mockTickets);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(
    null,
  );
  const [form, setForm] = useState(emptyForm);
  const [replyText, setReplyText] = useState("");
  const [replySender, setReplySender] = useState<MessageSender>("Support");
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [assignedFilter, setAssignedFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      priority: priorityFilter,
      category: categoryFilter,
      assignedTo: assignedFilter,
    }),
    [query, statusFilter, priorityFilter, categoryFilter, assignedFilter],
  );

  const assignedOptions = useMemo(
    () => Array.from(new Set(tickets.map((item) => item.assignedTo))),
    [tickets],
  );

  const formReady =
    form.tenantName.trim().length >= 2 &&
    form.clinicName.trim().length >= 2 &&
    form.contactEmail.includes("@") &&
    form.subject.trim().length >= 4 &&
    form.assignedTo.trim().length >= 2 &&
    form.message.trim().length >= 5 &&
    categories.includes(form.category) &&
    priorities.includes(form.priority) &&
    ticketStatuses.includes(form.status);

  const replyReady =
    selectedTicket &&
    replyText.trim().length >= 2 &&
    ["Tenant", "Support", "Admin"].includes(replySender);

  useEffect(() => {
    let active = true;

    loadTickets().then((data) => {
      if (!active) return;
      setTickets(data);
      setVisibleTickets(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadTickets(filters, tickets).then((data) => {
        if (!active) return;
        setVisibleTickets(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, tickets]);

  const stats = useMemo(
    () => [
      {
        label: "Tickets",
        value: String(tickets.length),
        icon: LifeBuoy,
      },
      {
        label: "Open",
        value: String(tickets.filter((item) => item.status === "Open").length),
        icon: CalendarClock,
      },
      {
        label: "Urgent",
        value: String(tickets.filter((item) => item.priority === "Urgent").length),
        icon: AlertTriangle,
      },
      {
        label: "Resolved",
        value: String(tickets.filter((item) => item.status === "Resolved").length),
        icon: CheckCircle2,
      },
    ],
    [tickets],
  );

  const syncTickets = (nextTickets: SupportTicket[]) => {
    setTickets(nextTickets);
    setVisibleTickets(localFilter(nextTickets, filters));

    if (selectedTicket) {
      setSelectedTicket(
        nextTickets.find((item) => item.id === selectedTicket.id) || null,
      );
    }
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setPriorityFilter("");
    setCategoryFilter("");
    setAssignedFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleCreateTicket = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Support ticket form complete korle Add Ticket button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      tenantName: form.tenantName.trim(),
      clinicName: form.clinicName.trim(),
      contactEmail: form.contactEmail.trim(),
      subject: form.subject.trim(),
      category: form.category,
      priority: form.priority,
      status: form.status,
      assignedTo: form.assignedTo.trim(),
      message: form.message.trim(),
    };

    const fallbackTicket: SupportTicket = {
      id: `SUP-ID-${Date.now()}`,
      ticketNo: `SUP-${String(tickets.length + 1).padStart(4, "0")}`,
      createdDate: today(),
      lastUpdated: today(),
      messages: [
        {
          id: `MSG-${Date.now()}`,
          sender: "Tenant",
          message: payload.message,
          createdAt: nowText(),
        },
      ],
      ...payload,
    };

    try {
      const createdTicket = await createTicketApi(payload);
      syncTickets([createdTicket, ...tickets]);
      setMessage("Support ticket added successfully.");
    } catch {
      syncTickets([fallbackTicket, ...tickets]);
      setMessage("Ticket added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    ticket: SupportTicket,
    status: TicketStatus,
  ) => {
    const previousTickets = tickets;

    const nextTickets = tickets.map((item) =>
      item.id === ticket.id
        ? { ...item, status, lastUpdated: today() }
        : item,
    );

    syncTickets(nextTickets);
    setMessage("");

    try {
      const updatedTicket = await updateTicketStatusApi(ticket.id, status);

      syncTickets(
        nextTickets.map((item) =>
          item.id === updatedTicket.id ? updatedTicket : item,
        ),
      );
    } catch {
      syncTickets(previousTickets);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleAddMessage = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!selectedTicket || !replyReady || saving) {
      setMessage("Message write korle Send Reply button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const localMessage: SupportMessage = {
      id: `MSG-${Date.now()}`,
      sender: replySender,
      message: replyText.trim(),
      createdAt: nowText(),
    };

    const previousTickets = tickets;

    const nextTickets = tickets.map((item) =>
      item.id === selectedTicket.id
        ? {
            ...item,
            lastUpdated: today(),
            status: item.status === "Open" ? "In Progress" : item.status,
            messages: [...item.messages, localMessage],
          }
        : item,
    );

    syncTickets(nextTickets);

    try {
      const updatedTicket = await addMessageApi(selectedTicket.id, {
        sender: replySender,
        message: replyText.trim(),
      });

      syncTickets(
        nextTickets.map((item) =>
          item.id === updatedTicket.id ? updatedTicket : item,
        ),
      );

      setReplyText("");
      setMessage("Reply/message added successfully.");
    } catch {
      syncTickets(previousTickets);
      setMessage("Backend reply failed. Previous message restored.");
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveTicket = async (ticket: SupportTicket) => {
    const previousTickets = tickets;
    const nextTickets = tickets.filter((item) => item.id !== ticket.id);

    syncTickets(nextTickets);
    setMessage("");

    try {
      await deleteTicketApi(ticket.id);
      setMessage("Support ticket removed successfully.");
    } catch {
      syncTickets(previousTickets);
      setMessage("Backend delete failed, ticket restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Support
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Tenant support tickets, messages and issue status.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading support tickets from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: ticket/message/status/support tracking functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Ticket
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_160px_190px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search ticket, tenant, clinic, email, subject"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {ticketStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={priorityFilter}
              onChange={(event) => setPriorityFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Priority</option>
              {priorities.map((priority) => (
                <option key={priority} value={priority}>
                  {priority}
                </option>
              ))}
            </select>

            <select
              value={categoryFilter}
              onChange={(event) => setCategoryFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Category</option>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            <select
              value={assignedFilter}
              onChange={(event) => setAssignedFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Assignee</option>
              {assignedOptions.map((assignee) => (
                <option key={assignee} value={assignee}>
                  {assignee}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1240px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Ticket / Tenant
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Issue
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Category
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Messages
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleTickets.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.ticketNo} · {item.tenantName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.clinicName}
                      </p>
                      <p className="mt-1 max-w-[220px] truncate text-[11px] font-bold text-slate-500">
                        {item.contactEmail}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="max-w-[310px] truncate text-sm font-black text-slate-800">
                        {item.subject}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Created {item.createdDate} · Updated {item.lastUpdated}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Assigned: {item.assignedTo}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        <Badge
                          label={item.category}
                          className={categoryClass[item.category]}
                        />
                        <Badge
                          label={item.priority}
                          className={priorityClass[item.priority]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <MessageSquareText size={14} />
                        {item.messages.length}
                      </p>
                      <p className="mt-1 max-w-[220px] truncate text-[11px] font-bold text-slate-500">
                        {item.messages[item.messages.length - 1]?.message || "No message"}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as TicketStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {ticketStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTicket(item);
                            setReplyText("");
                            setReplySender("Support");
                          }}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Resolved")}
                          disabled={item.status === "Resolved" || item.status === "Closed"}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Resolve
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Closed")}
                          disabled={item.status === "Closed"}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <XCircle size={13} />
                          Close
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveTicket(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleTickets.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No support ticket found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <LifeBuoy size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedTicket && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Support Ticket Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedTicket.ticketNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedTicket.subject}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedTicket(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Tenant", selectedTicket.tenantName],
                ["Clinic", selectedTicket.clinicName],
                ["Email", selectedTicket.contactEmail],
                ["Assigned To", selectedTicket.assignedTo],
                ["Created", selectedTicket.createdDate],
                ["Last Updated", selectedTicket.lastUpdated],
                ["Category", selectedTicket.category],
                ["Priority", selectedTicket.priority],
                ["Status", selectedTicket.status],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-4 border border-teal-100">
              <div className="border-b border-teal-100 bg-slate-50 px-3 py-2">
                <p className="text-[10px] font-black uppercase tracking-[0.16em] text-slate-500">
                  Ticket Messages
                </p>
              </div>

              <div className="grid gap-2 p-3">
                {selectedTicket.messages.map((item) => (
                  <div
                    key={item.id}
                    className="border border-slate-100 bg-slate-50 p-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <Badge
                        label={item.sender}
                        className={
                          item.sender === "Tenant"
                            ? "border-blue-200 bg-blue-50 text-blue-700"
                            : item.sender === "Admin"
                              ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                              : "border-teal-200 bg-teal-50 text-teal-800"
                        }
                      />
                      <p className="text-[11px] font-bold text-slate-400">
                        {item.createdAt}
                      </p>
                    </div>

                    <p className="mt-2 text-sm font-bold leading-6 text-slate-700">
                      {item.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <form
              onSubmit={handleAddMessage}
              className="mt-4 grid gap-2 border border-teal-100 bg-teal-50/50 p-3"
            >
              <div className="grid gap-2 md:grid-cols-[160px_1fr_auto]">
                <select
                  value={replySender}
                  onChange={(event) =>
                    setReplySender(event.target.value as MessageSender)
                  }
                  className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
                >
                  <option value="Support">Support</option>
                  <option value="Admin">Admin</option>
                  <option value="Tenant">Tenant</option>
                </select>

                <input
                  value={replyText}
                  onChange={(event) => setReplyText(event.target.value)}
                  placeholder="Write support reply/message"
                  className="border border-teal-100 bg-white px-3 py-2 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <button
                  type="submit"
                  disabled={!replyReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    replyReady
                      ? "border-emerald-700 bg-emerald-700 text-white hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <Send size={14} />
                  Send Reply
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-3xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Support Ticket
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New tenant issue
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Tenant, issue subject, priority and first message fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Tenant Name">
                  <input
                    value={form.tenantName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        tenantName: event.target.value,
                      }))
                    }
                    placeholder="Update Diagnostic Center"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Clinic Name">
                  <input
                    value={form.clinicName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        clinicName: event.target.value,
                      }))
                    }
                    placeholder="Clinic display name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Contact Email">
                  <input
                    value={form.contactEmail}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        contactEmail: event.target.value,
                      }))
                    }
                    placeholder="admin@clinic.com"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Assigned To">
                  <input
                    value={form.assignedTo}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        assignedTo: event.target.value,
                      }))
                    }
                    placeholder="Support Team"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Category">
                  <select
                    value={form.category}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        category: event.target.value as TicketCategory,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Priority">
                  <select
                    value={form.priority}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        priority: event.target.value as TicketPriority,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {priorities.map((priority) => (
                      <option key={priority} value={priority}>
                        {priority}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as TicketStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {ticketStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Subject">
                  <input
                    value={form.subject}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        subject: event.target.value,
                      }))
                    }
                    placeholder="Issue subject"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="First Message">
                    <textarea
                      value={form.message}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          message: event.target.value,
                        }))
                      }
                      rows={4}
                      placeholder="Tenant issue details"
                      className="resize-none border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Support ticket form complete. Add Ticket button enabled."
                  : "Tenant + clinic + valid email + subject + message complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Ticket"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicSupportPage;