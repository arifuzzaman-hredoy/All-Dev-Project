import DemoWorkspacePage from "../DemoWorkspacePage";
const ClinicPrescriptionsPage = () => <DemoWorkspacePage eyebrow="Clinic panel" title="Prescriptions" description="Prescription activity, uploads, reviews and patient-linked records." />;
export default ClinicPrescriptionsPage;
