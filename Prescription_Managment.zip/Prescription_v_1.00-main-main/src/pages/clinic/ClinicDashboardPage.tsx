import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  AlertTriangle,
  Banknote,
  Boxes,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  FlaskConical,
  LifeBuoy,
  MessageCircle,
  Pill,
  RefreshCw,
  Stethoscope,
  UsersRound,
  WalletCards,
  type LucideIcon,
} from "lucide-react";

type RangeKey = "day" | "7d" | "30d" | "all";
type ChartMetric =
  | "visits"
  | "revenue"
  | "prescriptions"
  | "patients"
  | "labOrders"
  | "lowStock";

type DashboardStats = {
  todayAppointments: number;
  waitingPatients: number;
  completedVisits: number;
  followUpDue: number;
  todayCollection: number;
  pendingDue: number;
  prescriptionCount: number;
  smsBalance: number;
  activeDoctors: number;
  labOrders: number;
  reportReady: number;
  lowStock: number;
  supportOpen: number;
};

type TrendPoint = {
  label: string;
  visits: number;
  revenue: number;
  prescriptions: number;
  patients: number;
  labOrders: number;
  lowStock: number;
};

type ModuleRow = {
  label: string;
  value: number;
  note: string;
  status: "Good" | "Warning" | "Critical";
};

type RecentRow = {
  id: string;
  title: string;
  subtitle: string;
  status: string;
  time: string;
  amount?: number;
};

type AlertRow = {
  id: string;
  title: string;
  note: string;
  level: "Info" | "Warning" | "Critical";
};

type DashboardData = {
  stats: DashboardStats;
  trend: TrendPoint[];
  moduleSummary: ModuleRow[];
  recentAppointments: RecentRow[];
  recentPatients: RecentRow[];
  recentInvoices: RecentRow[];
  recentLabOrders: RecentRow[];
  alerts: AlertRow[];
  updatedAt: string;
};

const mockDashboard: DashboardData = {
  stats: {
    todayAppointments: 32,
    waitingPatients: 8,
    completedVisits: 21,
    followUpDue: 6,
    todayCollection: 1800,
    pendingDue: 420,
    prescriptionCount: 27,
    smsBalance: 9200,
    activeDoctors: 6,
    labOrders: 12,
    reportReady: 4,
    lowStock: 3,
    supportOpen: 2,
  },
  trend: [
    { label: "Jun 15", visits: 8, revenue: 900, prescriptions: 6, patients: 5, labOrders: 4, lowStock: 2 },
    { label: "Jun 16", visits: 12, revenue: 1300, prescriptions: 9, patients: 7, labOrders: 6, lowStock: 2 },
    { label: "Jun 17", visits: 10, revenue: 1200, prescriptions: 8, patients: 6, labOrders: 5, lowStock: 3 },
    { label: "Jun 18", visits: 15, revenue: 1700, prescriptions: 13, patients: 10, labOrders: 8, lowStock: 3 },
    { label: "Jun 19", visits: 18, revenue: 2200, prescriptions: 15, patients: 12, labOrders: 9, lowStock: 3 },
    { label: "Today", visits: 32, revenue: 1800, prescriptions: 27, patients: 18, labOrders: 12, lowStock: 3 },
  ],
  moduleSummary: [
    { label: "Appointments", value: 32, note: "8 waiting", status: "Warning" },
    { label: "Patients", value: 18, note: "6 follow-up", status: "Good" },
    { label: "Prescriptions", value: 27, note: "Generated today", status: "Good" },
    { label: "Billing", value: 1800, note: "৳420 due", status: "Warning" },
    { label: "Diagnostic", value: 12, note: "4 report ready", status: "Warning" },
    { label: "Inventory", value: 3, note: "Low stock", status: "Critical" },
  ],
  recentAppointments: [
    { id: "A1", title: "Nusrat Jahan", subtitle: "Fever and headache", status: "Waiting", time: "09:30 AM" },
    { id: "A2", title: "Rafiqul Islam", subtitle: "BP follow-up", status: "Active", time: "10:00 AM" },
    { id: "A3", title: "Tamanna Akter", subtitle: "Diabetes checkup", status: "Pending", time: "10:30 AM" },
  ],
  recentPatients: [
    { id: "P1", title: "Nusrat Jahan", subtitle: "Active patient", status: "Active", time: "Today" },
    { id: "P2", title: "Rafiqul Islam", subtitle: "Follow-up due", status: "Follow-up", time: "This week" },
  ],
  recentInvoices: [
    { id: "I1", title: "INV-1001", subtitle: "Consultation bill", status: "Paid", time: "Today", amount: 900 },
    { id: "I2", title: "INV-1002", subtitle: "Diagnostic partial", status: "Partial", time: "Today", amount: 800 },
  ],
  recentLabOrders: [
    { id: "L1", title: "LAB-1001", subtitle: "CBC, ESR", status: "In Lab", time: "Today" },
    { id: "L2", title: "LAB-1002", subtitle: "ECG, X-Ray", status: "Report Ready", time: "Today" },
  ],
  alerts: [
    { id: "AL1", title: "Low stock", note: "3 inventory items need reorder.", level: "Warning" },
    { id: "AL2", title: "Support tickets", note: "2 tickets are still open.", level: "Info" },
  ],
  updatedAt: new Date().toISOString(),
};

const ranges: { key: RangeKey; label: string }[] = [
  { key: "day", label: "Day" },
  { key: "7d", label: "7D" },
  { key: "30d", label: "30D" },
  { key: "all", label: "All" },
];

const metrics: { key: ChartMetric; label: string }[] = [
  { key: "visits", label: "Visits" },
  { key: "revenue", label: "Revenue" },
  { key: "prescriptions", label: "RX" },
  { key: "patients", label: "Patients" },
  { key: "labOrders", label: "Lab" },
  { key: "lowStock", label: "Stock" },
];

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const shortMoney = (value: number) => {
  if (value >= 1000) return `৳${Number(value / 1000).toFixed(1)}k`;
  return `৳${value}`;
};

const loadDashboard = async (range: RangeKey): Promise<DashboardData> => {
  try {
    const response = await fetch(`/api/clinic/dashboard?range=${range}`, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return mockDashboard;

    const data = (await response.json()) as { dashboard?: DashboardData };
    return data.dashboard || mockDashboard;
  } catch {
    return mockDashboard;
  }
};

const statusClass = (status: string) => {
  const text = status.toLowerCase();

  if (
    text.includes("good") ||
    text.includes("paid") ||
    text.includes("completed") ||
    text.includes("ready") ||
    text.includes("active")
  ) {
    return "border-emerald-200 bg-emerald-50 text-emerald-700";
  }

  if (
    text.includes("warning") ||
    text.includes("due") ||
    text.includes("waiting") ||
    text.includes("pending") ||
    text.includes("lab") ||
    text.includes("partial")
  ) {
    return "border-amber-200 bg-amber-50 text-amber-700";
  }

  if (
    text.includes("critical") ||
    text.includes("low") ||
    text.includes("expired") ||
    text.includes("failed")
  ) {
    return "border-rose-200 bg-rose-50 text-rose-700";
  }

  return "border-slate-200 bg-slate-50 text-slate-600";
};

const Badge = ({ label }: { label: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      statusClass(label),
    ].join(" ")}
  >
    {label}
  </span>
);

const Button = ({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) => (
  <button
    type="button"
    onClick={onClick}
    className={[
      "border px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] transition",
      active
        ? "border-emerald-700 bg-emerald-700 text-white"
        : "border-slate-200 bg-white text-slate-500 hover:border-teal-200 hover:text-teal-800",
    ].join(" ")}
  >
    {children}
  </button>
);

const StatTile = ({
  label,
  value,
  note,
  icon: Icon,
}: {
  label: string;
  value: string;
  note: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white p-2.5">
    <div className="flex items-center justify-between gap-2">
      <div className="min-w-0">
        <p className="truncate text-[9px] font-black uppercase tracking-[0.14em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 truncate text-lg font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 truncate text-[10px] font-bold text-slate-400">
          {note}
        </p>
      </div>

      <Icon size={17} className="shrink-0 text-teal-700" />
    </div>
  </div>
);

const Panel = ({
  title,
  note,
  children,
}: {
  title: string;
  note: string;
  children: ReactNode;
}) => (
  <article className="border border-teal-100 bg-white p-3">
    <div className="mb-2 flex items-center justify-between gap-3 border-b border-slate-100 pb-2">
      <div>
        <h3 className="text-sm font-black text-slate-950">{title}</h3>
        <p className="mt-0.5 text-[10px] font-bold text-slate-400">{note}</p>
      </div>
    </div>

    {children}
  </article>
);

const MiniRows = ({ rows }: { rows: RecentRow[] }) => (
  <div className="grid gap-1.5">
    {rows.slice(0, 3).map((row) => (
      <div
        key={row.id}
        className="grid gap-2 border border-slate-100 bg-slate-50 px-2 py-1.5 text-[11px] font-bold text-slate-600 sm:grid-cols-[1fr_68px_82px] sm:items-center"
      >
        <span className="min-w-0">
          <span className="block truncate text-[12px] font-black text-slate-950">
            {row.title}
          </span>
          <span className="block truncate text-[10px] text-slate-500">
            {row.subtitle}
          </span>
        </span>

        <span className="text-[10px] font-black text-slate-500">
          {row.amount ? money(row.amount) : row.time}
        </span>

        <Badge label={row.status} />
      </div>
    ))}

    {!rows.length && (
      <p className="border border-slate-100 bg-slate-50 p-3 text-center text-xs font-bold text-slate-400">
        No recent data found.
      </p>
    )}
  </div>
);

const ClinicDashboardPage = () => {
  const [dashboard, setDashboard] = useState<DashboardData>(mockDashboard);
  const [range, setRange] = useState<RangeKey>("day");
  const [chartMetric, setChartMetric] = useState<ChartMetric>("visits");
  const [chartMode, setChartMode] = useState<"area" | "bar">("area");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const refreshDashboard = async (nextRange = range) => {
    setRefreshing(true);
    const data = await loadDashboard(nextRange);
    setDashboard(data);
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => {
    let active = true;

    loadDashboard(range).then((data) => {
      if (!active) return;
      setDashboard(data);
      setLoading(false);
    });

    const timer = window.setInterval(() => {
      loadDashboard(range).then((data) => {
        if (!active) return;
        setDashboard(data);
      });
    }, 10000);

    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [range]);

  const chartData = useMemo(
    () =>
      dashboard.trend.map((item) => ({
        label: item.label,
        value: Number(item[chartMetric] || 0),
      })),
    [dashboard.trend, chartMetric],
  );

  const activeMetric = metrics.find((item) => item.key === chartMetric)?.label || "Chart";

  const formatChartValue = (value: number) =>
    chartMetric === "revenue" ? money(value) : String(value);

  const statTiles = useMemo(
    () => [
      {
        label: "Appointments",
        value: String(dashboard.stats.todayAppointments),
        note: "Selected range",
        icon: CalendarClock,
      },
      {
        label: "Waiting",
        value: String(dashboard.stats.waitingPatients),
        note: "Queue patients",
        icon: UsersRound,
      },
      {
        label: "Completed",
        value: String(dashboard.stats.completedVisits),
        note: "Visits done",
        icon: CheckCircle2,
      },
      {
        label: "Follow-up",
        value: String(dashboard.stats.followUpDue),
        note: "Due follow-up",
        icon: CalendarClock,
      },
      {
        label: "Collection",
        value: money(dashboard.stats.todayCollection),
        note: "Payment received",
        icon: Banknote,
      },
      {
        label: "Due",
        value: money(dashboard.stats.pendingDue),
        note: "Ledger/billing",
        icon: WalletCards,
      },
      {
        label: "RX",
        value: String(dashboard.stats.prescriptionCount),
        note: "Prescriptions",
        icon: Pill,
      },
      {
        label: "SMS",
        value: String(dashboard.stats.smsBalance),
        note: "Balance left",
        icon: MessageCircle,
      },
      {
        label: "Doctors",
        value: String(dashboard.stats.activeDoctors),
        note: "Active",
        icon: Stethoscope,
      },
      {
        label: "Lab",
        value: String(dashboard.stats.labOrders),
        note: `${dashboard.stats.reportReady} ready`,
        icon: FlaskConical,
      },
      {
        label: "Stock",
        value: String(dashboard.stats.lowStock),
        note: "Low stock",
        icon: Boxes,
      },
      {
        label: "Support",
        value: String(dashboard.stats.supportOpen),
        note: "Open tickets",
        icon: LifeBuoy,
      },
    ],
    [dashboard],
  );

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-4">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-3 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1 text-3xl font-black tracking-tight text-slate-950">
                Clinic Dashboard
              </h1>
              <p className="mt-1 max-w-4xl text-sm font-semibold leading-6 text-slate-500">
                Chart button change korlei dashboard chart update hobe. Data backend JSON database theke live read hobe.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading live dashboard..."
                    : `Auto refresh 10s · ${new Date(dashboard.updatedAt).toLocaleTimeString()}`}
                </p>
              </div>

              <button
                type="button"
                onClick={() => refreshDashboard()}
                disabled={refreshing}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <RefreshCw size={14} className={refreshing ? "animate-spin" : ""} />
                Refresh
              </button>
            </div>
          </div>

          <section className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-6">
            {statTiles.map((item) => (
              <StatTile key={item.label} {...item} />
            ))}
          </section>

          <section className="mt-3 grid gap-3 2xl:grid-cols-[1.5fr_0.8fr]">
            <Panel
              title={`${activeMetric} analytics chart`}
              note="Range button backend data reload kore, metric button chart data change kore."
            >
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {ranges.map((item) => (
                    <Button
                      key={item.key}
                      active={range === item.key}
                      onClick={() => {
                        setRange(item.key);
                        refreshDashboard(item.key);
                      }}
                    >
                      {item.label}
                    </Button>
                  ))}
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {metrics.map((item) => (
                    <Button
                      key={item.key}
                      active={chartMetric === item.key}
                      onClick={() => setChartMetric(item.key)}
                    >
                      {item.label}
                    </Button>
                  ))}

                  <Button
                    active={chartMode === "area"}
                    onClick={() => setChartMode("area")}
                  >
                    Area
                  </Button>

                  <Button
                    active={chartMode === "bar"}
                    onClick={() => setChartMode("bar")}
                  >
                    Bar
                  </Button>
                </div>
              </div>

              <div className="h-[245px] border border-slate-100 bg-slate-50 p-2">
                <ResponsiveContainer width="100%" height="100%">
                  {chartMode === "area" ? (
                    <AreaChart data={chartData} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
                      <defs>
                        <linearGradient id="mainChartFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#0f766e" stopOpacity={0.35} />
                          <stop offset="95%" stopColor="#0f766e" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="label" tick={{ fontSize: 10, fontWeight: 700 }} stroke="#94a3b8" />
                      <YAxis
                        tickFormatter={(value) =>
                          chartMetric === "revenue"
                            ? shortMoney(Number(value))
                            : String(value)
                        }
                        tick={{ fontSize: 10, fontWeight: 700 }}
                        stroke="#94a3b8"
                      />
                      <Tooltip
                        formatter={(value: string | number) =>
                          formatChartValue(Number(value))
                        }
                        contentStyle={{
                          border: "1px solid #ccfbf1",
                          background: "#ffffff",
                          color: "#0f172a",
                          fontSize: 12,
                          fontWeight: 700,
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#0f766e"
                        strokeWidth={2}
                        fill="url(#mainChartFill)"
                        animationDuration={900}
                      />
                    </AreaChart>
                  ) : (
                    <BarChart data={chartData} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="label" tick={{ fontSize: 10, fontWeight: 700 }} stroke="#94a3b8" />
                      <YAxis
                        tickFormatter={(value) =>
                          chartMetric === "revenue"
                            ? shortMoney(Number(value))
                            : String(value)
                        }
                        tick={{ fontSize: 10, fontWeight: 700 }}
                        stroke="#94a3b8"
                      />
                      <Tooltip
                        formatter={(value: string | number) =>
                          formatChartValue(Number(value))
                        }
                        contentStyle={{
                          border: "1px solid #ccfbf1",
                          background: "#ffffff",
                          color: "#0f172a",
                          fontSize: 12,
                          fontWeight: 700,
                        }}
                      />
                      <Bar
                        dataKey="value"
                        fill="#0f766e"
                        animationDuration={900}
                      />
                    </BarChart>
                  )}
                </ResponsiveContainer>
              </div>
            </Panel>

            <Panel title="Module health" note="All module summary compact view.">
              <div className="grid max-h-[312px] gap-1.5 overflow-y-auto pr-1">
                {dashboard.moduleSummary.map((item) => (
                  <div
                    key={item.label}
                    className="grid grid-cols-[1fr_76px_82px] items-center gap-2 border border-slate-100 bg-slate-50 px-2 py-1.5"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-[12px] font-black text-slate-950">
                        {item.label}
                      </p>
                      <p className="truncate text-[10px] font-bold text-slate-500">
                        {item.note}
                      </p>
                    </div>
                    <p className="text-right text-sm font-black text-slate-800">
                      {item.label === "Billing" ? money(item.value) : item.value}
                    </p>
                    <Badge label={item.status} />
                  </div>
                ))}
              </div>
            </Panel>
          </section>

          <section className="mt-3 grid gap-3 2xl:grid-cols-4">
            <Panel title="Appointments" note="Small live table.">
              <MiniRows rows={dashboard.recentAppointments} />
            </Panel>

            <Panel title="Patients" note="Recent patient activity.">
              <MiniRows rows={dashboard.recentPatients} />
            </Panel>

            <Panel title="Invoices" note="Billing and collection.">
              <MiniRows rows={dashboard.recentInvoices} />
            </Panel>

            <Panel title="Diagnostic" note="Lab order status.">
              <MiniRows rows={dashboard.recentLabOrders} />
            </Panel>
          </section>

          <section className="mt-3 grid gap-3 2xl:grid-cols-[1fr_1fr]">
            <Panel title="Live alerts" note="Inventory, support, due, SMS and lab alerts.">
              <div className="grid gap-1.5">
                {dashboard.alerts.slice(0, 5).map((alert) => (
                  <div
                    key={alert.id}
                    className="grid grid-cols-[24px_1fr_82px] items-center gap-2 border border-slate-100 bg-slate-50 px-2 py-1.5"
                  >
                    <AlertTriangle size={14} className="text-amber-600" />
                    <div className="min-w-0">
                      <p className="truncate text-[12px] font-black text-slate-950">
                        {alert.title}
                      </p>
                      <p className="truncate text-[10px] font-bold text-slate-500">
                        {alert.note}
                      </p>
                    </div>
                    <Badge label={alert.level} />
                  </div>
                ))}

                {!dashboard.alerts.length && (
                  <p className="border border-slate-100 bg-slate-50 p-3 text-center text-xs font-bold text-slate-400">
                    No alert right now.
                  </p>
                )}
              </div>
            </Panel>

            <Panel title="Quick interpretation" note="Current operational status.">
              <div className="grid gap-1.5">
                <div className="border border-slate-100 bg-slate-50 px-2 py-1.5 text-xs font-bold text-slate-600">
                  Waiting queue:{" "}
                  <span className="font-black text-slate-950">
                    {dashboard.stats.waitingPatients}
                  </span>{" "}
                  patients.
                </div>
                <div className="border border-slate-100 bg-slate-50 px-2 py-1.5 text-xs font-bold text-slate-600">
                  Today collection:{" "}
                  <span className="font-black text-emerald-700">
                    {money(dashboard.stats.todayCollection)}
                  </span>
                  .
                </div>
                <div className="border border-slate-100 bg-slate-50 px-2 py-1.5 text-xs font-bold text-slate-600">
                  Pending due:{" "}
                  <span className="font-black text-rose-600">
                    {money(dashboard.stats.pendingDue)}
                  </span>
                  .
                </div>
                <div className="border border-slate-100 bg-slate-50 px-2 py-1.5 text-xs font-bold text-slate-600">
                  Diagnostic report ready:{" "}
                  <span className="font-black text-teal-700">
                    {dashboard.stats.reportReady}
                  </span>
                  .
                </div>
              </div>
            </Panel>
          </section>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <Activity size={14} />
            Dashboard chart + compact tables + backend realtime JSON database connected.
          </div>
        </div>
      </section>
    </main>
  );
};

export default ClinicDashboardPage;