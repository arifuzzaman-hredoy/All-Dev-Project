import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Banknote,
  CalendarClock,
  CheckCircle2,
  CreditCard,
  Eye,
  FileText,
  Filter,
  Phone,
  ReceiptText,
  Search,
  Trash2,
  UserPlus,
  WalletCards,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type BillType =
  | "Consultation"
  | "Diagnostics"
  | "Medicine"
  | "Procedure"
  | "Package";

type InvoiceStatus = "Paid" | "Due" | "Partial" | "Overdue" | "Cancelled";

type PaymentMethod = "Cash" | "Card" | "bKash" | "Nagad" | "Bank" | "Unpaid";

type ClinicInvoice = {
  id: string;
  invoiceNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  doctorName: string;
  billDate: string;
  billType: BillType;
  subtotal: number;
  discount: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  status: InvoiceStatus;
  notes: string;
};

const billTypes: BillType[] = [
  "Consultation",
  "Diagnostics",
  "Medicine",
  "Procedure",
  "Package",
];

const invoiceStatuses: InvoiceStatus[] = [
  "Paid",
  "Due",
  "Partial",
  "Overdue",
  "Cancelled",
];

const paymentMethods: PaymentMethod[] = [
  "Cash",
  "Card",
  "bKash",
  "Nagad",
  "Bank",
  "Unpaid",
];

const mockInvoices: ClinicInvoice[] = [
  {
    id: "INV-ID-1001",
    invoiceNo: "INV-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    billDate: "2026-06-20",
    billType: "Consultation",
    subtotal: 1000,
    discount: 100,
    paidAmount: 900,
    dueAmount: 0,
    paymentMethod: "Cash",
    status: "Paid",
    notes: "Consultation fee collected.",
  },
  {
    id: "INV-ID-1002",
    invoiceNo: "INV-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    billDate: "2026-06-20",
    billType: "Diagnostics",
    subtotal: 1800,
    discount: 100,
    paidAmount: 800,
    dueAmount: 900,
    paymentMethod: "bKash",
    status: "Partial",
    notes: "Diagnostic bill partially collected.",
  },
  {
    id: "INV-ID-1003",
    invoiceNo: "INV-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    doctorName: "Front Desk",
    billDate: "2026-06-19",
    billType: "Package",
    subtotal: 2500,
    discount: 0,
    paidAmount: 0,
    dueAmount: 2500,
    paymentMethod: "Unpaid",
    status: "Overdue",
    notes: "Package bill due.",
  },
];

const emptyForm = {
  patientId: "",
  patientName: "",
  phone: "",
  doctorName: "",
  billDate: "",
  billType: "Consultation" as BillType,
  subtotal: "700",
  discount: "0",
  paidAmount: "0",
  paymentMethod: "Unpaid" as PaymentMethod,
  status: "Due" as InvoiceStatus,
  notes: "",
};

const statusClass: Record<InvoiceStatus, string> = {
  Paid: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Due: "border-rose-200 bg-rose-50 text-rose-700",
  Partial: "border-amber-200 bg-amber-50 text-amber-700",
  Overdue: "border-orange-200 bg-orange-50 text-orange-700",
  Cancelled: "border-slate-200 bg-slate-50 text-slate-500",
};

const typeClass: Record<BillType, string> = {
  Consultation: "border-teal-200 bg-teal-50 text-teal-800",
  Diagnostics: "border-blue-200 bg-blue-50 text-blue-700",
  Medicine: "border-violet-200 bg-violet-50 text-violet-700",
  Procedure: "border-amber-200 bg-amber-50 text-amber-700",
  Package: "border-cyan-200 bg-cyan-50 text-cyan-700",
};

const methodClass: Record<PaymentMethod, string> = {
  Cash: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Card: "border-blue-200 bg-blue-50 text-blue-700",
  bKash: "border-pink-200 bg-pink-50 text-pink-700",
  Nagad: "border-orange-200 bg-orange-50 text-orange-700",
  Bank: "border-indigo-200 bg-indigo-50 text-indigo-700",
  Unpaid: "border-slate-200 bg-slate-50 text-slate-500",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const netAmount = (invoice: Pick<ClinicInvoice, "subtotal" | "discount">) =>
  Math.max(0, Number(invoice.subtotal || 0) - Number(invoice.discount || 0));

const calculateDue = (subtotal: number, discount: number, paidAmount: number) =>
  Math.max(0, subtotal - discount - paidAmount);

const getAutoStatus = (
  subtotal: number,
  discount: number,
  paidAmount: number,
): InvoiceStatus => {
  const net = Math.max(0, subtotal - discount);

  if (net <= 0 || paidAmount >= net) return "Paid";
  if (paidAmount > 0) return "Partial";
  return "Due";
};

const localFilter = (
  items: ClinicInvoice[],
  filters: {
    query: string;
    status: string;
    billType: string;
    paymentMethod: string;
    doctor: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.invoiceNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.doctorName} ${item.billType} ${item.status} ${item.paymentMethod} ${item.notes}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.status || item.status === filters.status) &&
      (!filters.billType || item.billType === filters.billType) &&
      (!filters.paymentMethod || item.paymentMethod === filters.paymentMethod) &&
      (!filters.doctor || item.doctorName === filters.doctor)
    );
  });
};

const loadInvoices = async (
  filters = {
    query: "",
    status: "",
    billType: "",
    paymentMethod: "",
    doctor: "",
  },
  fallback = mockInvoices,
): Promise<ClinicInvoice[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.billType) params.set("billType", filters.billType);
    if (filters.paymentMethod) {
      params.set("paymentMethod", filters.paymentMethod);
    }
    if (filters.doctor) params.set("doctor", filters.doctor);

    const url = params.toString()
      ? `/api/clinic/billing?${params.toString()}`
      : "/api/clinic/billing";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { invoices?: ClinicInvoice[] };

    return Array.isArray(data.invoices)
      ? data.invoices
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createInvoiceApi = async (
  payload: Omit<ClinicInvoice, "id" | "invoiceNo">,
): Promise<ClinicInvoice> => {
  const response = await fetch("/api/clinic/billing", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create invoice failed");

  const data = (await response.json()) as { invoice?: ClinicInvoice };
  if (!data.invoice) throw new Error("Invalid invoice response");

  return data.invoice;
};

const updateInvoiceStatusApi = async (
  id: string,
  status: InvoiceStatus,
): Promise<ClinicInvoice> => {
  const response = await fetch(`/api/clinic/billing/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update invoice status failed");

  const data = (await response.json()) as { invoice?: ClinicInvoice };
  if (!data.invoice) throw new Error("Invalid status response");

  return data.invoice;
};

const collectInvoiceApi = async (
  id: string,
  paymentMethod: PaymentMethod,
): Promise<ClinicInvoice> => {
  const response = await fetch(`/api/clinic/billing/${id}/collect`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ paymentMethod }),
  });

  if (!response.ok) throw new Error("Collect invoice failed");

  const data = (await response.json()) as { invoice?: ClinicInvoice };
  if (!data.invoice) throw new Error("Invalid collect response");

  return data.invoice;
};

const deleteInvoiceApi = async (id: string) => {
  const response = await fetch(`/api/clinic/billing/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete invoice failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicBillingPage = () => {
  const [invoices, setInvoices] = useState<ClinicInvoice[]>(mockInvoices);
  const [visibleInvoices, setVisibleInvoices] =
    useState<ClinicInvoice[]>(mockInvoices);
  const [selectedInvoice, setSelectedInvoice] =
    useState<ClinicInvoice | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [methodFilter, setMethodFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      billType: typeFilter,
      paymentMethod: methodFilter,
      doctor: doctorFilter,
    }),
    [query, statusFilter, typeFilter, methodFilter, doctorFilter],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(invoices.map((item) => item.doctorName))),
    [invoices],
  );

  const formSubtotal = Number(form.subtotal);
  const formDiscount = Number(form.discount);
  const formPaid = Number(form.paidAmount);
  const formDue = calculateDue(formSubtotal, formDiscount, formPaid);
  const formNet = Math.max(0, formSubtotal - formDiscount);

  const formReady =
    form.patientId.trim().length >= 2 &&
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    form.doctorName.trim().length >= 2 &&
    form.billDate.trim().length >= 4 &&
    Number.isFinite(formSubtotal) &&
    formSubtotal >= 0 &&
    Number.isFinite(formDiscount) &&
    formDiscount >= 0 &&
    Number.isFinite(formPaid) &&
    formPaid >= 0;

  useEffect(() => {
    let active = true;

    loadInvoices().then((data) => {
      if (!active) return;
      setInvoices(data);
      setVisibleInvoices(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadInvoices(filters, invoices).then((data) => {
        if (!active) return;
        setVisibleInvoices(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, invoices]);

  const stats = useMemo(() => {
    const collected = invoices.reduce(
      (total, item) => total + Number(item.paidAmount || 0),
      0,
    );
    const due = invoices.reduce(
      (total, item) => total + Number(item.dueAmount || 0),
      0,
    );
    const overdue = invoices.filter((item) => item.status === "Overdue").length;

    return [
      {
        label: "Invoices",
        value: String(invoices.length),
        icon: ReceiptText,
      },
      {
        label: "Collected",
        value: money(collected),
        icon: CheckCircle2,
      },
      {
        label: "Due Amount",
        value: money(due),
        icon: WalletCards,
      },
      {
        label: "Overdue",
        value: String(overdue),
        icon: CalendarClock,
      },
    ];
  }, [invoices]);

  const syncInvoices = (nextInvoices: ClinicInvoice[]) => {
    setInvoices(nextInvoices);
    setVisibleInvoices(localFilter(nextInvoices, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setTypeFilter("");
    setMethodFilter("");
    setDoctorFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Billing form complete korle Add Invoice button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const subtotal = Number(form.subtotal);
    const discount = Number(form.discount);
    const paidAmount = Number(form.paidAmount);
    const dueAmount = calculateDue(subtotal, discount, paidAmount);
    const autoStatus =
      form.status === "Cancelled"
        ? "Cancelled"
        : getAutoStatus(subtotal, discount, paidAmount);

    const payload = {
      patientId: form.patientId.trim(),
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      doctorName: form.doctorName.trim(),
      billDate: form.billDate.trim(),
      billType: form.billType,
      subtotal,
      discount,
      paidAmount,
      dueAmount,
      paymentMethod: paidAmount > 0 ? form.paymentMethod : "Unpaid",
      status: autoStatus,
      notes: form.notes.trim() || "No billing note",
    };

    const fallbackInvoice: ClinicInvoice = {
      id: `INV-ID-${Date.now()}`,
      invoiceNo: `INV-${String(invoices.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdInvoice = await createInvoiceApi(payload);
      syncInvoices([createdInvoice, ...invoices]);
      setMessage("Invoice added successfully.");
    } catch {
      syncInvoices([fallbackInvoice, ...invoices]);
      setMessage("Invoice added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    invoice: ClinicInvoice,
    status: InvoiceStatus,
  ) => {
    const previousInvoices = invoices;

    const nextInvoices = invoices.map((item) =>
      item.id === invoice.id ? { ...item, status } : item,
    );

    syncInvoices(nextInvoices);
    setMessage("");

    try {
      const updatedInvoice = await updateInvoiceStatusApi(invoice.id, status);

      syncInvoices(
        nextInvoices.map((item) =>
          item.id === updatedInvoice.id ? updatedInvoice : item,
        ),
      );
    } catch {
      syncInvoices(previousInvoices);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleCollectInvoice = async (invoice: ClinicInvoice) => {
    const previousInvoices = invoices;
    const net = netAmount(invoice);

    const nextInvoices = invoices.map((item) =>
      item.id === invoice.id
        ? {
            ...item,
            paidAmount: net,
            dueAmount: 0,
            paymentMethod: item.paymentMethod === "Unpaid" ? "Cash" : item.paymentMethod,
            status: "Paid" as InvoiceStatus,
          }
        : item,
    );

    syncInvoices(nextInvoices);
    setMessage("");

    try {
      const updatedInvoice = await collectInvoiceApi(
        invoice.id,
        invoice.paymentMethod === "Unpaid" ? "Cash" : invoice.paymentMethod,
      );

      syncInvoices(
        nextInvoices.map((item) =>
          item.id === updatedInvoice.id ? updatedInvoice : item,
        ),
      );
      setMessage("Invoice collection completed.");
    } catch {
      syncInvoices(previousInvoices);
      setMessage("Backend collection failed. Previous invoice restored.");
    }
  };

  const handleRemoveInvoice = async (invoice: ClinicInvoice) => {
    const previousInvoices = invoices;
    const nextInvoices = invoices.filter((item) => item.id !== invoice.id);

    syncInvoices(nextInvoices);
    setMessage("");

    try {
      await deleteInvoiceApi(invoice.id);
      setMessage("Invoice removed successfully.");
    } catch {
      syncInvoices(previousInvoices);
      setMessage("Backend delete failed, invoice restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Billing
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Invoices, collection, due amounts and billing quick actions.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading invoices from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/filter/view/collect/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Invoice
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_160px_180px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search invoice, patient, phone, doctor, note"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {invoiceStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Type</option>
              {billTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <select
              value={methodFilter}
              onChange={(event) => setMethodFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Method</option>
              {paymentMethods.map((method) => (
                <option key={method} value={method}>
                  {method}
                </option>
              ))}
            </select>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1240px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Invoice / Patient
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor / Type
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Amount
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Payment
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleInvoices.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.invoiceNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-800">
                        {item.doctorName}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.billType}
                          className={typeClass[item.billType]}
                        />
                      </div>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.billDate}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        Net: {money(netAmount(item))}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Subtotal {money(item.subtotal)} · Discount{" "}
                        {money(item.discount)}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-emerald-700">
                        Paid: {money(item.paidAmount)}
                      </p>
                      <p className="mt-1 text-xs font-black text-rose-600">
                        Due: {money(item.dueAmount)}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.paymentMethod}
                          className={methodClass[item.paymentMethod]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as InvoiceStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {invoiceStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedInvoice(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleCollectInvoice(item)}
                          disabled={item.status === "Paid" || item.status === "Cancelled"}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <Banknote size={13} />
                          Collect
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Cancelled")}
                          disabled={item.status === "Cancelled"}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <XCircle size={13} />
                          Cancel
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveInvoice(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleInvoices.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No invoice found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <ReceiptText size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedInvoice && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Billing Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedInvoice.invoiceNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedInvoice.patientName} · {selectedInvoice.billType}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedInvoice(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                [
                  "Patient",
                  `${selectedInvoice.patientName} (${selectedInvoice.patientId})`,
                ],
                ["Phone", selectedInvoice.phone],
                ["Doctor", selectedInvoice.doctorName],
                ["Bill Date", selectedInvoice.billDate],
                ["Subtotal", money(selectedInvoice.subtotal)],
                ["Discount", money(selectedInvoice.discount)],
                ["Paid", money(selectedInvoice.paidAmount)],
                ["Due", money(selectedInvoice.dueAmount)],
                ["Payment Method", selectedInvoice.paymentMethod],
                ["Status", selectedInvoice.status],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Notes
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedInvoice.notes}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-3xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Invoice
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New billing record
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient, billing type, amount and collection info fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient ID">
                  <input
                    value={form.patientId}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        patientId: event.target.value,
                      }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        patientName: event.target.value,
                      }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        phone: event.target.value,
                      }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Doctor / Desk">
                  <input
                    value={form.doctorName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        doctorName: event.target.value,
                      }))
                    }
                    placeholder="Dr. Abdullah Rahman / Front Desk"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Bill Date">
                  <input
                    value={form.billDate}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        billDate: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Bill Type">
                  <select
                    value={form.billType}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        billType: event.target.value as BillType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {billTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Subtotal">
                  <input
                    value={form.subtotal}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        subtotal: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Discount">
                  <input
                    value={form.discount}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        discount: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Paid Amount">
                  <input
                    value={form.paidAmount}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        paidAmount: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment Method">
                  <select
                    value={form.paymentMethod}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        paymentMethod: event.target.value as PaymentMethod,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {paymentMethods.map((method) => (
                      <option key={method} value={method}>
                        {method}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Notes">
                  <input
                    value={form.notes}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        notes: event.target.value,
                      }))
                    }
                    placeholder="Billing note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Live Calculation
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    Net {money(formNet)} · Paid {money(formPaid)} · Due{" "}
                    {money(formDue)}
                  </p>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Billing form complete. Add Invoice button enabled."
                  : "Patient + phone + doctor/desk + date + amount complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Invoice"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicBillingPage;