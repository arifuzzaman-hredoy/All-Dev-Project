import DemoWorkspacePage from "../DemoWorkspacePage";
const ClinicWebsiteCmsPage = () => <DemoWorkspacePage eyebrow="Clinic panel" title="Website CMS" description="Public website content controls, sections and publishing status." />;
export default ClinicWebsiteCmsPage;
