import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Activity,
  Banknote,
  CalendarClock,
  ChartColumnIncreasing,
  CheckCircle2,
  ClipboardList,
  Download,
  FileText,
  Filter,
  Pill,
  RefreshCw,
  Search,
  Stethoscope,
  TrendingUp,
  Users,
  WalletCards,
  type LucideIcon,
} from "lucide-react";

type ReportRange = "Today" | "7 Days" | "30 Days" | "This Month" | "All";

type ReportMetric = {
  visits: number;
  completedVisits: number;
  revenue: number;
  collection: number;
  dueAmount: number;
  prescriptions: number;
  patients: number;
  followUps: number;
};

type TrendReport = {
  label: string;
  visits: number;
  revenue: number;
  prescriptions: number;
  patients: number;
};

type BreakdownReport = {
  label: string;
  value: number;
  amount?: number;
};

type ActivityReport = {
  id: string;
  date: string;
  type: string;
  title: string;
  note: string;
  amount?: number;
};

type ClinicReportData = {
  summary: ReportMetric;
  visitTrends: TrendReport[];
  visitsByDoctor: BreakdownReport[];
  revenueByType: BreakdownReport[];
  prescriptionStatus: BreakdownReport[];
  patientStatus: BreakdownReport[];
  latestActivity: ActivityReport[];
  doctorOptions: string[];
  specializationOptions: string[];
};

const ranges: ReportRange[] = ["Today", "7 Days", "30 Days", "This Month", "All"];

const mockReport: ClinicReportData = {
  summary: {
    visits: 42,
    completedVisits: 28,
    revenue: 48200,
    collection: 39100,
    dueAmount: 9100,
    prescriptions: 31,
    patients: 24,
    followUps: 9,
  },
  visitTrends: [
    { label: "Jun 16", visits: 6, revenue: 5200, prescriptions: 4, patients: 3 },
    { label: "Jun 17", visits: 8, revenue: 7400, prescriptions: 7, patients: 5 },
    { label: "Jun 18", visits: 5, revenue: 4200, prescriptions: 3, patients: 4 },
    { label: "Jun 19", visits: 10, revenue: 11600, prescriptions: 8, patients: 6 },
    { label: "Jun 20", visits: 13, revenue: 19800, prescriptions: 9, patients: 6 },
  ],
  visitsByDoctor: [
    { label: "Dr. Abdullah Rahman", value: 16 },
    { label: "Dr. Mehedi Hasan", value: 14 },
    { label: "Dr. Nusrat Jahan", value: 12 },
  ],
  revenueByType: [
    { label: "Consultation", value: 12, amount: 12500 },
    { label: "Diagnostics", value: 9, amount: 18400 },
    { label: "Medicine", value: 7, amount: 9300 },
    { label: "Package", value: 4, amount: 8000 },
  ],
  prescriptionStatus: [
    { label: "Delivered", value: 14 },
    { label: "Reviewed", value: 9 },
    { label: "Pending Review", value: 6 },
    { label: "Draft", value: 2 },
  ],
  patientStatus: [
    { label: "Active", value: 14 },
    { label: "Follow-up", value: 7 },
    { label: "Critical", value: 2 },
    { label: "Inactive", value: 1 },
  ],
  latestActivity: [
    {
      id: "ACT-1001",
      date: "2026-06-20",
      type: "Visit",
      title: "Nusrat Jahan completed visit",
      note: "Medicine follow-up completed.",
    },
    {
      id: "ACT-1002",
      date: "2026-06-20",
      type: "Revenue",
      title: "Invoice INV-1002 collected",
      note: "bKash partial collection received.",
      amount: 800,
    },
    {
      id: "ACT-1003",
      date: "2026-06-20",
      type: "Prescription",
      title: "RX-1002 pending review",
      note: "Cardiology prescription waiting for review.",
    },
  ],
  doctorOptions: ["Dr. Abdullah Rahman", "Dr. Mehedi Hasan", "Dr. Nusrat Jahan"],
  specializationOptions: ["Medicine", "Cardiology", "Gynecology"],
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const loadReports = async (
  filters: {
    range: ReportRange;
    doctor: string;
    specialization: string;
    query: string;
  },
  fallback = mockReport,
): Promise<ClinicReportData> => {
  try {
    const params = new URLSearchParams();

    params.set("range", filters.range);
    if (filters.doctor) params.set("doctor", filters.doctor);
    if (filters.specialization) {
      params.set("specialization", filters.specialization);
    }
    if (filters.query.trim()) params.set("q", filters.query.trim());

    const response = await fetch(`/api/clinic/reports?${params.toString()}`, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return fallback;

    const data = (await response.json()) as { report?: ClinicReportData };

    return data.report ? data.report : fallback;
  } catch {
    return fallback;
  }
};

const StatCard = ({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string;
  hint: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{hint}</p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Badge = ({ label }: { label: string }) => (
  <span className="inline-flex border border-teal-200 bg-teal-50 px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em] text-teal-800">
    {label}
  </span>
);

const ReportPanel = ({
  title,
  subtitle,
  icon: Icon,
  children,
}: {
  title: string;
  subtitle: string;
  icon: LucideIcon;
  children: ReactNode;
}) => (
  <div className="border border-teal-100 bg-white p-4">
    <div className="mb-4 flex items-start justify-between gap-3">
      <div>
        <p className="text-sm font-black text-slate-950">{title}</p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{subtitle}</p>
      </div>
      <Icon size={18} className="text-teal-700" />
    </div>
    {children}
  </div>
);

const BarList = ({
  rows,
  amountMode = false,
}: {
  rows: BreakdownReport[];
  amountMode?: boolean;
}) => {
  const max = Math.max(1, ...rows.map((row) => amountMode ? Number(row.amount || 0) : row.value));

  return (
    <div className="grid gap-3">
      {rows.map((row) => {
        const currentValue = amountMode ? Number(row.amount || 0) : row.value;
        const width = Math.max(6, Math.round((currentValue / max) * 100));

        return (
          <div key={row.label}>
            <div className="mb-1 flex items-center justify-between gap-3">
              <p className="truncate text-xs font-black text-slate-700">
                {row.label}
              </p>
              <p className="text-xs font-black text-slate-500">
                {amountMode ? money(Number(row.amount || 0)) : row.value}
              </p>
            </div>

            <div className="h-2 border border-teal-100 bg-slate-50">
              <div
                className="h-full bg-teal-700 transition-all duration-500"
                style={{ width: `${width}%` }}
              />
            </div>
          </div>
        );
      })}

      {!rows.length && (
        <p className="py-6 text-center text-sm font-bold text-slate-400">
          No report data found.
        </p>
      )}
    </div>
  );
};

const ClinicReportsPage = () => {
  const [report, setReport] = useState<ClinicReportData>(mockReport);
  const [range, setRange] = useState<ReportRange>("30 Days");
  const [doctor, setDoctor] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      range,
      doctor,
      specialization,
      query,
    }),
    [range, doctor, specialization, query],
  );

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setLoading(true);
      loadReports(filters).then((data) => {
        if (!active) return;
        setReport(data);
        setLoading(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters]);

  const trendMax = useMemo(
    () => Math.max(1, ...report.visitTrends.map((item) => item.visits)),
    [report.visitTrends],
  );

  const stats = useMemo(
    () => [
      {
        label: "Visits",
        value: String(report.summary.visits),
        hint: `${report.summary.completedVisits} completed`,
        icon: ClipboardList,
      },
      {
        label: "Revenue",
        value: money(report.summary.revenue),
        hint: `${money(report.summary.collection)} collected`,
        icon: Banknote,
      },
      {
        label: "Prescriptions",
        value: String(report.summary.prescriptions),
        hint: `${report.summary.followUps} follow-ups`,
        icon: Pill,
      },
      {
        label: "Patients",
        value: String(report.summary.patients),
        hint: `${money(report.summary.dueAmount)} due`,
        icon: Users,
      },
    ],
    [report],
  );

  const resetFilters = () => {
    setRange("30 Days");
    setDoctor("");
    setSpecialization("");
    setQuery("");
    setMessage("");
  };

  const refreshReport = () => {
    setLoading(true);

    loadReports(filters).then((data) => {
      setReport(data);
      setLoading(false);
      setMessage("Report refreshed from backend/database.");
    });
  };

  const exportCsv = () => {
    const lines = [
      "Report,Value",
      `Visits,${report.summary.visits}`,
      `Completed Visits,${report.summary.completedVisits}`,
      `Revenue,${report.summary.revenue}`,
      `Collection,${report.summary.collection}`,
      `Due Amount,${report.summary.dueAmount}`,
      `Prescriptions,${report.summary.prescriptions}`,
      `Patients,${report.summary.patients}`,
      "",
      "Trend Date,Visits,Revenue,Prescriptions,Patients",
      ...report.visitTrends.map(
        (item) =>
          `${item.label},${item.visits},${item.revenue},${item.prescriptions},${item.patients}`,
      ),
    ];

    const csv = lines.join("\n");
    const url = `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`;
    const link = document.createElement("a");

    link.href = url;
    link.download = "clinic-reports.csv";
    link.click();

    setMessage("CSV report exported.");
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Reports
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Visits, revenue, prescriptions and patient trend reports.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading report from backend/database..."
                    : "Ready: visits/revenue/RX/patient reports functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={refreshReport}
                className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
              >
                <RefreshCw size={14} />
                Refresh
              </button>

              <button
                type="button"
                onClick={exportCsv}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <Download size={14} />
                Export CSV
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_150px_190px_190px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search patient, doctor, invoice, prescription or activity"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={range}
              onChange={(event) => setRange(event.target.value as ReportRange)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              {ranges.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>

            <select
              value={doctor}
              onChange={(event) => setDoctor(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {report.doctorOptions.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>

            <select
              value={specialization}
              onChange={(event) => setSpecialization(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Specialities</option>
              {report.specializationOptions.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 grid gap-4 xl:grid-cols-[1.4fr_1fr]">
            <ReportPanel
              title="Visit, revenue and patient trend"
              subtitle="Daily trend from appointments, payments, prescriptions and patients."
              icon={TrendingUp}
            >
              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse text-left">
                  <thead className="bg-slate-50">
                    <tr className="border border-slate-100">
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Date
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Visits
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Revenue
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        RX
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Patients
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {report.visitTrends.map((item) => (
                      <tr key={item.label} className="border border-slate-100">
                        <td className="px-3 py-2 text-xs font-black text-slate-700">
                          {item.label}
                        </td>
                        <td className="px-3 py-2">
                          <div className="flex items-center gap-2">
                            <div className="h-2 w-24 border border-teal-100 bg-slate-50">
                              <div
                                className="h-full bg-teal-700"
                                style={{
                                  width: `${Math.max(
                                    6,
                                    Math.round((item.visits / trendMax) * 100),
                                  )}%`,
                                }}
                              />
                            </div>
                            <span className="text-xs font-black text-slate-700">
                              {item.visits}
                            </span>
                          </div>
                        </td>
                        <td className="px-3 py-2 text-xs font-black text-emerald-700">
                          {money(item.revenue)}
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-slate-600">
                          {item.prescriptions}
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-slate-600">
                          {item.patients}
                        </td>
                      </tr>
                    ))}

                    {!report.visitTrends.length && (
                      <tr>
                        <td
                          colSpan={5}
                          className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                        >
                          No trend data found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </ReportPanel>

            <ReportPanel
              title="Visits by doctor"
              subtitle="Doctor wise appointment/visit performance."
              icon={Stethoscope}
            >
              <BarList rows={report.visitsByDoctor} />
            </ReportPanel>

            <ReportPanel
              title="Revenue by billing type"
              subtitle="Consultation, diagnostics, medicine and package revenue."
              icon={WalletCards}
            >
              <BarList rows={report.revenueByType} amountMode />
            </ReportPanel>

            <div className="grid gap-4">
              <ReportPanel
                title="Prescription status"
                subtitle="Draft, pending, reviewed and delivered RX report."
                icon={Pill}
              >
                <BarList rows={report.prescriptionStatus} />
              </ReportPanel>

              <ReportPanel
                title="Patient status trend"
                subtitle="Active, follow-up, critical and inactive patients."
                icon={Users}
              >
                <BarList rows={report.patientStatus} />
              </ReportPanel>
            </div>
          </div>

          <div className="mt-4 border border-teal-100 bg-white">
            <div className="flex items-center justify-between border-b border-teal-100 bg-slate-50 px-4 py-3">
              <div>
                <p className="text-sm font-black text-slate-950">
                  Latest report activity
                </p>
                <p className="mt-1 text-[11px] font-bold text-slate-400">
                  Latest visits, payments, prescriptions and patient events.
                </p>
              </div>
              <Activity size={18} className="text-teal-700" />
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[900px] border-collapse bg-white text-left">
                <thead className="bg-slate-50">
                  <tr className="border-b border-slate-100">
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Date
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Type
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Title
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Note
                    </th>
                    <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Amount
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {report.latestActivity.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-slate-100 transition hover:bg-teal-50/45"
                    >
                      <td className="px-4 py-3 text-xs font-black text-slate-700">
                        {item.date}
                      </td>
                      <td className="px-4 py-3">
                        <Badge label={item.type} />
                      </td>
                      <td className="px-4 py-3 text-sm font-black text-slate-800">
                        {item.title}
                      </td>
                      <td className="px-4 py-3 text-xs font-bold text-slate-500">
                        {item.note}
                      </td>
                      <td className="px-4 py-3 text-right text-xs font-black text-emerald-700">
                        {item.amount ? money(item.amount) : "-"}
                      </td>
                    </tr>
                  ))}

                  {!report.latestActivity.length && (
                    <tr>
                      <td
                        colSpan={5}
                        className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                      >
                        No report activity found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <ChartColumnIncreasing size={14} />
            Reports read from backend/database JSON files and update with filters.
          </div>
        </div>
      </section>
    </main>
  );
};

export default ClinicReportsPage;
