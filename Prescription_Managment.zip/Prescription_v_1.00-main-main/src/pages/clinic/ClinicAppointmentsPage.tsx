import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import {
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  Eye,
  FileText,
  Filter,
  Mail,
  Phone,
  Search,
  Stethoscope,
  Trash2,
  UserPlus,
  UserRound,
  Users,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type AppointmentType = "New" | "Follow-up" | "Report Review" | "Emergency";
type AppointmentStatus =
  | "Waiting"
  | "Checked In"
  | "Completed"
  | "Cancelled"
  | "No Show";
type PaymentStatus = "Paid" | "Due" | "Partial";

type ClinicAppointment = {
  id: string;
  tokenNo: string;
  patientName: string;
  phone: string;
  email: string;
  age: number;
  gender: string;
  doctorName: string;
  specialization: string;
  appointmentDate: string;
  appointmentTime: string;
  type: AppointmentType;
  status: AppointmentStatus;
  problem: string;
  fee: number;
  paymentStatus: PaymentStatus;
};

const appointmentTypes: AppointmentType[] = [
  "New",
  "Follow-up",
  "Report Review",
  "Emergency",
];

const appointmentStatuses: AppointmentStatus[] = [
  "Waiting",
  "Checked In",
  "Completed",
  "Cancelled",
  "No Show",
];

const paymentStatuses: PaymentStatus[] = ["Paid", "Due", "Partial"];

const mockAppointments: ClinicAppointment[] = [
  {
    id: "APT-1001",
    tokenNo: "T-01",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    email: "nusrat.patient@demo.com",
    age: 32,
    gender: "Female",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    appointmentDate: "2026-06-20",
    appointmentTime: "09:30 AM",
    type: "Follow-up",
    status: "Waiting",
    problem: "Appointment and billing follow-up",
    fee: 700,
    paymentStatus: "Paid",
  },
  {
    id: "APT-1002",
    tokenNo: "T-02",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    email: "rafiqul.patient@demo.com",
    age: 45,
    gender: "Male",
    doctorName: "Dr. Nusrat Jahan",
    specialization: "Gynecology",
    appointmentDate: "2026-06-20",
    appointmentTime: "10:15 AM",
    type: "Report Review",
    status: "Checked In",
    problem: "Prescription review pending",
    fee: 900,
    paymentStatus: "Partial",
  },
  {
    id: "APT-1003",
    tokenNo: "T-03",
    patientName: "Prime Diagnostic",
    phone: "+8801711000003",
    email: "report@prime.demo",
    age: 28,
    gender: "Male",
    doctorName: "Dr. Mehedi Hasan",
    specialization: "Cardiology",
    appointmentDate: "2026-06-20",
    appointmentTime: "11:45 AM",
    type: "New",
    status: "Completed",
    problem: "Report delivery and collection",
    fee: 1200,
    paymentStatus: "Paid",
  },
];

const emptyForm = {
  patientName: "",
  phone: "",
  email: "",
  age: "",
  gender: "Male",
  doctorName: "",
  specialization: "",
  appointmentDate: "",
  appointmentTime: "",
  type: "New" as AppointmentType,
  status: "Waiting" as AppointmentStatus,
  problem: "",
  fee: "700",
  paymentStatus: "Due" as PaymentStatus,
};

const statusClass: Record<AppointmentStatus, string> = {
  Waiting: "border-amber-200 bg-amber-50 text-amber-700",
  "Checked In": "border-blue-200 bg-blue-50 text-blue-700",
  Completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Cancelled: "border-rose-200 bg-rose-50 text-rose-700",
  "No Show": "border-slate-200 bg-slate-50 text-slate-500",
};

const typeClass: Record<AppointmentType, string> = {
  New: "border-teal-200 bg-teal-50 text-teal-800",
  "Follow-up": "border-cyan-200 bg-cyan-50 text-cyan-700",
  "Report Review": "border-violet-200 bg-violet-50 text-violet-700",
  Emergency: "border-rose-200 bg-rose-50 text-rose-700",
};

const paymentClass: Record<PaymentStatus, string> = {
  Paid: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Due: "border-rose-200 bg-rose-50 text-rose-700",
  Partial: "border-amber-200 bg-amber-50 text-amber-700",
};

const isValidEmail = (email: string) => {
  if (!email.trim()) return true;
  return /\S+@\S+\.\S+/.test(email);
};

const localFilter = (
  items: ClinicAppointment[],
  filters: {
    query: string;
    doctor: string;
    specialization: string;
    status: string;
    type: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.tokenNo} ${item.patientName} ${item.phone} ${item.email} ${item.doctorName} ${item.specialization} ${item.type} ${item.status} ${item.problem}`
        .toLowerCase()
        .includes(searchText);

    const matchedDoctor =
      !filters.doctor || item.doctorName === filters.doctor;

    const matchedSpecialization =
      !filters.specialization || item.specialization === filters.specialization;

    const matchedStatus = !filters.status || item.status === filters.status;

    const matchedType = !filters.type || item.type === filters.type;

    return (
      matchedSearch &&
      matchedDoctor &&
      matchedSpecialization &&
      matchedStatus &&
      matchedType
    );
  });
};

const loadAppointments = async (
  filters = {
    query: "",
    doctor: "",
    specialization: "",
    status: "",
    type: "",
  },
  fallback = mockAppointments,
): Promise<ClinicAppointment[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.doctor) params.set("doctor", filters.doctor);
    if (filters.specialization) {
      params.set("specialization", filters.specialization);
    }
    if (filters.status) params.set("status", filters.status);
    if (filters.type) params.set("type", filters.type);

    const queryString = params.toString();
    const url = queryString
      ? `/api/clinic/appointments?${queryString}`
      : "/api/clinic/appointments";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as {
      appointments?: ClinicAppointment[];
    };

    return Array.isArray(data.appointments)
      ? data.appointments
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createAppointmentApi = async (
  payload: Omit<ClinicAppointment, "id" | "tokenNo">,
): Promise<ClinicAppointment> => {
  const response = await fetch("/api/clinic/appointments", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create appointment failed");

  const data = (await response.json()) as {
    appointment?: ClinicAppointment;
  };

  if (!data.appointment) throw new Error("Invalid appointment response");

  return data.appointment;
};

const updateAppointmentStatusApi = async (
  id: string,
  status: AppointmentStatus,
): Promise<ClinicAppointment> => {
  const response = await fetch(`/api/clinic/appointments/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update status failed");

  const data = (await response.json()) as {
    appointment?: ClinicAppointment;
  };

  if (!data.appointment) throw new Error("Invalid status response");

  return data.appointment;
};

const deleteAppointmentApi = async (id: string) => {
  const response = await fetch(`/api/clinic/appointments/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete appointment failed");
};

const Badge = ({
  label,
  className,
}: {
  label: string;
  className: string;
}) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const ClinicAppointmentsPage = () => {
  const navigate = useNavigate();
  const [appointments, setAppointments] =
    useState<ClinicAppointment[]>(mockAppointments);
  const [visibleAppointments, setVisibleAppointments] =
    useState<ClinicAppointment[]>(mockAppointments);
  const [selectedAppointment, setSelectedAppointment] =
    useState<ClinicAppointment | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [specializationFilter, setSpecializationFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      doctor: doctorFilter,
      specialization: specializationFilter,
      status: statusFilter,
      type: typeFilter,
    }),
    [query, doctorFilter, specializationFilter, statusFilter, typeFilter],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(appointments.map((item) => item.doctorName))),
    [appointments],
  );

  const specializationOptions = useMemo(
    () => Array.from(new Set(appointments.map((item) => item.specialization))),
    [appointments],
  );

  const formReady =
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    isValidEmail(form.email) &&
    Number(form.age) > 0 &&
    form.gender.trim().length >= 2 &&
    form.doctorName.trim().length >= 2 &&
    form.specialization.trim().length >= 2 &&
    form.appointmentDate.trim().length >= 4 &&
    form.appointmentTime.trim().length >= 2 &&
    form.problem.trim().length >= 2 &&
    Number(form.fee) >= 0;

  useEffect(() => {
    let active = true;

    loadAppointments().then((data) => {
      if (!active) return;
      setAppointments(data);
      setVisibleAppointments(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadAppointments(filters, appointments).then((data) => {
        if (!active) return;
        setVisibleAppointments(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, appointments]);

  const stats = useMemo(
    () => [
      {
        label: "Total",
        value: String(appointments.length),
        icon: ClipboardList,
      },
      {
        label: "Waiting",
        value: String(
          appointments.filter((item) => item.status === "Waiting").length,
        ),
        icon: CalendarClock,
      },
      {
        label: "Completed",
        value: String(
          appointments.filter((item) => item.status === "Completed").length,
        ),
        icon: CheckCircle2,
      },
      {
        label: "Follow-up",
        value: String(
          appointments.filter((item) => item.type === "Follow-up").length,
        ),
        icon: Users,
      },
    ],
    [appointments],
  );

  const syncAppointments = (nextAppointments: ClinicAppointment[]) => {
    setAppointments(nextAppointments);
    setVisibleAppointments(localFilter(nextAppointments, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setDoctorFilter("");
    setSpecializationFilter("");
    setStatusFilter("");
    setTypeFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Full appointment form complete korle Add button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      email: form.email.trim().toLowerCase(),
      age: Number(form.age),
      gender: form.gender.trim(),
      doctorName: form.doctorName.trim(),
      specialization: form.specialization.trim(),
      appointmentDate: form.appointmentDate.trim(),
      appointmentTime: form.appointmentTime.trim(),
      type: form.type,
      status: form.status,
      problem: form.problem.trim(),
      fee: Number(form.fee),
      paymentStatus: form.paymentStatus,
    };

    const fallbackAppointment: ClinicAppointment = {
      id: `APT-${Date.now()}`,
      tokenNo: `T-${appointments.length + 1}`.padStart(4, "0"),
      ...payload,
    };

    try {
      const createdAppointment = await createAppointmentApi(payload);
      syncAppointments([createdAppointment, ...appointments]);
      setMessage("Appointment added successfully.");
    } catch {
      syncAppointments([fallbackAppointment, ...appointments]);
      setMessage(
        "Appointment added locally. Backend route connect korle database save hobe.",
      );
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    appointment: ClinicAppointment,
    status: AppointmentStatus,
  ) => {
    const previousAppointments = appointments;

    const nextAppointments = appointments.map((item) =>
      item.id === appointment.id ? { ...item, status } : item,
    );

    syncAppointments(nextAppointments);
    setMessage("");

    try {
      const updatedAppointment = await updateAppointmentStatusApi(
        appointment.id,
        status,
      );

      syncAppointments(
        nextAppointments.map((item) =>
          item.id === updatedAppointment.id ? updatedAppointment : item,
        ),
      );
    } catch {
      syncAppointments(previousAppointments);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemoveAppointment = async (appointment: ClinicAppointment) => {
    const previousAppointments = appointments;
    const nextAppointments = appointments.filter(
      (item) => item.id !== appointment.id,
    );

    syncAppointments(nextAppointments);
    setMessage("");

    try {
      await deleteAppointmentApi(appointment.id);
      setMessage("Appointment removed successfully.");
    } catch {
      syncAppointments(previousAppointments);
      setMessage("Backend delete failed, appointment restored.");
    }
  };

  const openPrescription = (appointment: ClinicAppointment) => {
    const patient = {
      patientId: appointment.id,
      appointmentId: appointment.id,
      patientName: appointment.patientName,
      phone: appointment.phone,
      age: appointment.age,
      gender: appointment.gender,
      doctorName: appointment.doctorName,
      specialization: appointment.specialization,
      problem: appointment.problem,
      type: appointment.type,
    };

    sessionStorage.setItem("clinic-active-patient", JSON.stringify(patient));
    navigate("/clinic/prescriptions", { state: { patient } });
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Appointments
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Appointment queue, waiting patients, completed visits, follow-up
                list and front desk workflow.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading appointments from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: table/search/filter/details/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Appointment
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_180px_180px_160px_160px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search patient, phone, doctor, speciality, token, problem"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <select
              value={specializationFilter}
              onChange={(event) => setSpecializationFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Specialities</option>
              {specializationOptions.map((speciality) => (
                <option key={speciality} value={speciality}>
                  {speciality}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {appointmentStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Category</option>
              {appointmentTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1280px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Patient Details
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor / Speciality
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Date & Time
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Category
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Payment
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleAppointments.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-sm font-black text-slate-950">
                          {item.tokenNo} · {item.patientName}
                        </p>
                        <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                          {item.age} yrs · {item.gender}
                        </p>
                        <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                          <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                            <Phone size={12} />
                            {item.phone}
                          </p>
                          <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                            <Mail size={12} />
                            {item.email || "No email"}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Stethoscope size={14} />
                        {item.doctorName}
                      </p>
                      <p className="mt-1 text-[11px] font-black text-teal-700">
                        {item.specialization}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        {item.appointmentDate}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.appointmentTime}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <Badge label={item.type} className={typeClass[item.type]} />
                      <p className="mt-1 max-w-[220px] truncate text-[11px] font-bold text-slate-500">
                        {item.problem}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as AppointmentStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {appointmentStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        ৳ {item.fee}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.paymentStatus}
                          className={paymentClass[item.paymentStatus]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedAppointment(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            handleStatusChange(item, "Completed")
                          }
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100"
                        >
                          <CheckCircle2 size={13} />
                          Done
                        </button>

                        <button
                          type="button"
                          onClick={() => openPrescription(item)}
                          className="inline-flex items-center gap-1 border border-teal-100 bg-teal-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-teal-700 transition hover:border-teal-200 hover:bg-teal-100"
                        >
                          <FileText size={13} />
                          RX
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveAppointment(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleAppointments.length && (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No appointment found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <ClipboardList size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedAppointment && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Patient Personal Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedAppointment.patientName}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Token {selectedAppointment.tokenNo} ·{" "}
                  {selectedAppointment.type}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedAppointment(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Phone", selectedAppointment.phone],
                ["Email", selectedAppointment.email || "No email"],
                ["Age / Gender", `${selectedAppointment.age} / ${selectedAppointment.gender}`],
                ["Doctor", selectedAppointment.doctorName],
                ["Speciality", selectedAppointment.specialization],
                ["Date & Time", `${selectedAppointment.appointmentDate} · ${selectedAppointment.appointmentTime}`],
                ["Status", selectedAppointment.status],
                ["Payment", `৳ ${selectedAppointment.fee} · ${selectedAppointment.paymentStatus}`],
              ].map(([label, value]) => (
                <div key={label} className="border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Patient Problem
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedAppointment.problem}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Appointment
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New appointment entry
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient, doctor, speciality and visit category fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <input
                  value={form.patientName}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      patientName: event.target.value,
                    }))
                  }
                  placeholder="Patient name"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.phone}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, phone: event.target.value }))
                  }
                  placeholder="Phone number"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.email}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, email: event.target.value }))
                  }
                  placeholder="Email optional"
                  type="email"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <div className="grid grid-cols-2 gap-3">
                  <input
                    value={form.age}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, age: event.target.value }))
                    }
                    placeholder="Age"
                    type="number"
                    min={1}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />

                  <select
                    value={form.gender}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        gender: event.target.value,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <input
                  value={form.doctorName}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      doctorName: event.target.value,
                    }))
                  }
                  placeholder="Doctor name"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.specialization}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      specialization: event.target.value,
                    }))
                  }
                  placeholder="Speciality"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.appointmentDate}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      appointmentDate: event.target.value,
                    }))
                  }
                  type="date"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.appointmentTime}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      appointmentTime: event.target.value,
                    }))
                  }
                  placeholder="09:30 AM"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <select
                  value={form.type}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      type: event.target.value as AppointmentType,
                    }))
                  }
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                >
                  {appointmentTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>

                <select
                  value={form.paymentStatus}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      paymentStatus: event.target.value as PaymentStatus,
                    }))
                  }
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                >
                  {paymentStatuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>

                <input
                  value={form.fee}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, fee: event.target.value }))
                  }
                  placeholder="Fee"
                  type="number"
                  min={0}
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />

                <input
                  value={form.problem}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      problem: event.target.value,
                    }))
                  }
                  placeholder="Patient problem / note"
                  className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                />
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Appointment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicAppointmentsPage;
