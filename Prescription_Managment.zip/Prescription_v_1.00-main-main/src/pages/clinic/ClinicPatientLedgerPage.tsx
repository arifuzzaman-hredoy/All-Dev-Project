import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Banknote,
  CalendarClock,
  CheckCircle2,
  Eye,
  Filter,
  History,
  Phone,
  ReceiptText,
  Search,
  Trash2,
  UserPlus,
  WalletCards,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type LedgerStatus = "Clear" | "Due" | "Overdue" | "Credit";
type TransactionType = "Invoice" | "Payment" | "Discount" | "Refund" | "Adjustment";
type PaymentMethod = "Cash" | "Card" | "bKash" | "Nagad" | "Bank" | "None";

type LedgerTransaction = {
  id: string;
  date: string;
  type: TransactionType;
  refNo: string;
  description: string;
  debit: number;
  credit: number;
  method: PaymentMethod;
};

type PatientLedger = {
  id: string;
  ledgerNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  assignedDoctor: string;
  openingBalance: number;
  totalBilled: number;
  totalPaid: number;
  totalDiscount: number;
  currentDue: number;
  lastTransactionDate: string;
  nextDueDate: string;
  status: LedgerStatus;
  transactions: LedgerTransaction[];
};

const ledgerStatuses: LedgerStatus[] = ["Clear", "Due", "Overdue", "Credit"];

const transactionTypes: TransactionType[] = [
  "Invoice",
  "Payment",
  "Discount",
  "Refund",
  "Adjustment",
];

const paymentMethods: PaymentMethod[] = [
  "Cash",
  "Card",
  "bKash",
  "Nagad",
  "Bank",
  "None",
];

const mockLedgers: PatientLedger[] = [
  {
    id: "LED-ID-1001",
    ledgerNo: "LED-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    assignedDoctor: "Dr. Abdullah Rahman",
    openingBalance: 0,
    totalBilled: 1800,
    totalPaid: 1800,
    totalDiscount: 100,
    currentDue: 0,
    lastTransactionDate: "2026-06-20",
    nextDueDate: "No due",
    status: "Clear",
    transactions: [
      {
        id: "TRX-1001",
        date: "2026-06-20",
        type: "Invoice",
        refNo: "INV-1001",
        description: "Consultation and medicine bill",
        debit: 1800,
        credit: 0,
        method: "None",
      },
      {
        id: "TRX-1002",
        date: "2026-06-20",
        type: "Payment",
        refNo: "RCPT-1001",
        description: "Cash collection",
        debit: 0,
        credit: 1800,
        method: "Cash",
      },
    ],
  },
  {
    id: "LED-ID-1002",
    ledgerNo: "LED-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    assignedDoctor: "Dr. Mehedi Hasan",
    openingBalance: 0,
    totalBilled: 2500,
    totalPaid: 1200,
    totalDiscount: 100,
    currentDue: 1200,
    lastTransactionDate: "2026-06-20",
    nextDueDate: "2026-06-27",
    status: "Due",
    transactions: [
      {
        id: "TRX-1003",
        date: "2026-06-20",
        type: "Invoice",
        refNo: "INV-1002",
        description: "Diagnostics bill",
        debit: 2500,
        credit: 0,
        method: "None",
      },
      {
        id: "TRX-1004",
        date: "2026-06-20",
        type: "Payment",
        refNo: "RCPT-1002",
        description: "bKash partial payment",
        debit: 0,
        credit: 1200,
        method: "bKash",
      },
      {
        id: "TRX-1005",
        date: "2026-06-20",
        type: "Discount",
        refNo: "DISC-1002",
        description: "Doctor discount",
        debit: 0,
        credit: 100,
        method: "None",
      },
    ],
  },
  {
    id: "LED-ID-1003",
    ledgerNo: "LED-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    assignedDoctor: "Front Desk",
    openingBalance: 300,
    totalBilled: 2200,
    totalPaid: 0,
    totalDiscount: 0,
    currentDue: 2500,
    lastTransactionDate: "2026-06-19",
    nextDueDate: "2026-06-21",
    status: "Overdue",
    transactions: [
      {
        id: "TRX-1006",
        date: "2026-06-19",
        type: "Invoice",
        refNo: "INV-1003",
        description: "Package bill",
        debit: 2500,
        credit: 0,
        method: "None",
      },
    ],
  },
];

const emptyLedgerForm = {
  patientId: "",
  patientName: "",
  phone: "",
  assignedDoctor: "",
  openingBalance: "0",
  totalBilled: "0",
  totalPaid: "0",
  totalDiscount: "0",
  nextDueDate: "",
  status: "Due" as LedgerStatus,
};

const emptyTransactionForm = {
  date: "",
  type: "Payment" as TransactionType,
  refNo: "",
  description: "",
  debit: "0",
  credit: "0",
  method: "Cash" as PaymentMethod,
};

const statusClass: Record<LedgerStatus, string> = {
  Clear: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Due: "border-amber-200 bg-amber-50 text-amber-700",
  Overdue: "border-rose-200 bg-rose-50 text-rose-700",
  Credit: "border-blue-200 bg-blue-50 text-blue-700",
};

const typeClass: Record<TransactionType, string> = {
  Invoice: "border-teal-200 bg-teal-50 text-teal-800",
  Payment: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Discount: "border-cyan-200 bg-cyan-50 text-cyan-700",
  Refund: "border-blue-200 bg-blue-50 text-blue-700",
  Adjustment: "border-amber-200 bg-amber-50 text-amber-700",
};

const methodClass: Record<PaymentMethod, string> = {
  Cash: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Card: "border-blue-200 bg-blue-50 text-blue-700",
  bKash: "border-pink-200 bg-pink-50 text-pink-700",
  Nagad: "border-orange-200 bg-orange-50 text-orange-700",
  Bank: "border-indigo-200 bg-indigo-50 text-indigo-700",
  None: "border-slate-200 bg-slate-50 text-slate-500",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const calculateBalance = (
  openingBalance: number,
  totalBilled: number,
  totalPaid: number,
  totalDiscount: number,
) => Number(openingBalance || 0) + Number(totalBilled || 0) - Number(totalPaid || 0) - Number(totalDiscount || 0);

const getStatusFromBalance = (
  balance: number,
  fallback: LedgerStatus,
): LedgerStatus => {
  if (fallback === "Overdue") return "Overdue";
  if (balance < 0) return "Credit";
  if (balance === 0) return "Clear";
  return "Due";
};

const localFilter = (
  items: PatientLedger[],
  filters: {
    query: string;
    status: string;
    doctor: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.ledgerNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.assignedDoctor} ${item.status} ${item.nextDueDate}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.status || item.status === filters.status) &&
      (!filters.doctor || item.assignedDoctor === filters.doctor)
    );
  });
};

const loadLedgers = async (
  filters = {
    query: "",
    status: "",
    doctor: "",
  },
  fallback = mockLedgers,
): Promise<PatientLedger[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.doctor) params.set("doctor", filters.doctor);

    const url = params.toString()
      ? `/api/clinic/patient-ledger?${params.toString()}`
      : "/api/clinic/patient-ledger";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { ledgers?: PatientLedger[] };

    return Array.isArray(data.ledgers)
      ? data.ledgers
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createLedgerApi = async (
  payload: Omit<PatientLedger, "id" | "ledgerNo" | "transactions">,
): Promise<PatientLedger> => {
  const response = await fetch("/api/clinic/patient-ledger", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create ledger failed");

  const data = (await response.json()) as { ledger?: PatientLedger };
  if (!data.ledger) throw new Error("Invalid ledger response");

  return data.ledger;
};

const addTransactionApi = async (
  id: string,
  payload: Omit<LedgerTransaction, "id">,
): Promise<PatientLedger> => {
  const response = await fetch(`/api/clinic/patient-ledger/${id}/transactions`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Add transaction failed");

  const data = (await response.json()) as { ledger?: PatientLedger };
  if (!data.ledger) throw new Error("Invalid transaction response");

  return data.ledger;
};

const updateLedgerStatusApi = async (
  id: string,
  status: LedgerStatus,
): Promise<PatientLedger> => {
  const response = await fetch(`/api/clinic/patient-ledger/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update ledger status failed");

  const data = (await response.json()) as { ledger?: PatientLedger };
  if (!data.ledger) throw new Error("Invalid status response");

  return data.ledger;
};

const deleteLedgerApi = async (id: string) => {
  const response = await fetch(`/api/clinic/patient-ledger/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete ledger failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicPatientLedgerPage = () => {
  const [ledgers, setLedgers] = useState<PatientLedger[]>(mockLedgers);
  const [visibleLedgers, setVisibleLedgers] =
    useState<PatientLedger[]>(mockLedgers);
  const [selectedLedger, setSelectedLedger] = useState<PatientLedger | null>(
    null,
  );
  const [transactionLedger, setTransactionLedger] =
    useState<PatientLedger | null>(null);
  const [ledgerForm, setLedgerForm] = useState(emptyLedgerForm);
  const [transactionForm, setTransactionForm] = useState(emptyTransactionForm);
  const [addOpen, setAddOpen] = useState(false);
  const [transactionOpen, setTransactionOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      doctor: doctorFilter,
    }),
    [query, statusFilter, doctorFilter],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(ledgers.map((item) => item.assignedDoctor))),
    [ledgers],
  );

  const openingBalance = Number(ledgerForm.openingBalance);
  const totalBilled = Number(ledgerForm.totalBilled);
  const totalPaid = Number(ledgerForm.totalPaid);
  const totalDiscount = Number(ledgerForm.totalDiscount);
  const liveBalance = calculateBalance(
    openingBalance,
    totalBilled,
    totalPaid,
    totalDiscount,
  );

  const ledgerFormReady =
    ledgerForm.patientId.trim().length >= 2 &&
    ledgerForm.patientName.trim().length >= 2 &&
    ledgerForm.phone.trim().length >= 5 &&
    ledgerForm.assignedDoctor.trim().length >= 2 &&
    Number.isFinite(openingBalance) &&
    Number.isFinite(totalBilled) &&
    Number.isFinite(totalPaid) &&
    Number.isFinite(totalDiscount);

  const transactionDebit = Number(transactionForm.debit);
  const transactionCredit = Number(transactionForm.credit);

  const transactionFormReady =
    transactionLedger &&
    transactionForm.date.trim().length >= 4 &&
    transactionForm.refNo.trim().length >= 2 &&
    transactionForm.description.trim().length >= 2 &&
    Number.isFinite(transactionDebit) &&
    Number.isFinite(transactionCredit) &&
    transactionDebit >= 0 &&
    transactionCredit >= 0 &&
    transactionDebit + transactionCredit > 0;

  useEffect(() => {
    let active = true;

    loadLedgers().then((data) => {
      if (!active) return;
      setLedgers(data);
      setVisibleLedgers(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadLedgers(filters, ledgers).then((data) => {
        if (!active) return;
        setVisibleLedgers(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, ledgers]);

  const stats = useMemo(() => {
    const totalPositiveDue = ledgers
      .filter((item) => item.currentDue > 0)
      .reduce((total, item) => total + Number(item.currentDue || 0), 0);

    const totalPaidAmount = ledgers.reduce(
      (total, item) => total + Number(item.totalPaid || 0),
      0,
    );

    const overdueCount = ledgers.filter(
      (item) => item.status === "Overdue",
    ).length;

    return [
      {
        label: "Ledgers",
        value: String(ledgers.length),
        icon: ReceiptText,
      },
      {
        label: "Total Due",
        value: money(totalPositiveDue),
        icon: WalletCards,
      },
      {
        label: "Total Paid",
        value: money(totalPaidAmount),
        icon: Banknote,
      },
      {
        label: "Overdue",
        value: String(overdueCount),
        icon: CalendarClock,
      },
    ];
  }, [ledgers]);

  const syncLedgers = (nextLedgers: PatientLedger[]) => {
    setLedgers(nextLedgers);
    setVisibleLedgers(localFilter(nextLedgers, filters));

    if (selectedLedger) {
      setSelectedLedger(
        nextLedgers.find((item) => item.id === selectedLedger.id) || null,
      );
    }

    if (transactionLedger) {
      setTransactionLedger(
        nextLedgers.find((item) => item.id === transactionLedger.id) || null,
      );
    }
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setDoctorFilter("");
  };

  const resetLedgerForm = () => {
    setLedgerForm(emptyLedgerForm);
    setMessage("");
  };

  const resetTransactionForm = () => {
    setTransactionForm(emptyTransactionForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetLedgerForm();
  };

  const closeTransactionModal = () => {
    setTransactionOpen(false);
    setTransactionLedger(null);
    resetTransactionForm();
  };

  const openTransactionModal = (ledger: PatientLedger) => {
    setTransactionLedger(ledger);
    setTransactionForm(emptyTransactionForm);
    setTransactionOpen(true);
    setMessage("");
  };

  const handleCreateLedger = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!ledgerFormReady || saving) {
      setMessage("Patient ledger form complete korle Add Ledger button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const currentDue = liveBalance;
    const autoStatus = getStatusFromBalance(currentDue, ledgerForm.status);

    const payload = {
      patientId: ledgerForm.patientId.trim(),
      patientName: ledgerForm.patientName.trim(),
      phone: ledgerForm.phone.trim(),
      assignedDoctor: ledgerForm.assignedDoctor.trim(),
      openingBalance,
      totalBilled,
      totalPaid,
      totalDiscount,
      currentDue,
      lastTransactionDate: "Not recorded",
      nextDueDate: ledgerForm.nextDueDate.trim() || "Not scheduled",
      status: autoStatus,
    };

    const fallbackLedger: PatientLedger = {
      id: `LED-ID-${Date.now()}`,
      ledgerNo: `LED-${String(ledgers.length + 1).padStart(4, "0")}`,
      ...payload,
      transactions: [],
    };

    try {
      const createdLedger = await createLedgerApi(payload);
      syncLedgers([createdLedger, ...ledgers]);
      setMessage("Patient ledger added successfully.");
    } catch {
      syncLedgers([fallbackLedger, ...ledgers]);
      setMessage("Ledger added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const applyTransactionLocal = (
    ledger: PatientLedger,
    transaction: LedgerTransaction,
  ): PatientLedger => {
    const totalBilledNext =
      ledger.totalBilled + (transaction.debit > 0 ? transaction.debit : 0);

    const totalPaidNext =
      ledger.totalPaid +
      (transaction.type === "Payment" ? transaction.credit : 0);

    const totalDiscountNext =
      ledger.totalDiscount +
      (transaction.type === "Discount" ? transaction.credit : 0);

    const currentDueNext =
      ledger.currentDue + transaction.debit - transaction.credit;

    return {
      ...ledger,
      totalBilled: totalBilledNext,
      totalPaid: totalPaidNext,
      totalDiscount: totalDiscountNext,
      currentDue: currentDueNext,
      lastTransactionDate: transaction.date,
      status: getStatusFromBalance(currentDueNext, ledger.status),
      transactions: [transaction, ...ledger.transactions],
    };
  };

  const handleAddTransaction = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!transactionLedger || !transactionFormReady || saving) {
      setMessage("Transaction form complete korle Add Transaction button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      date: transactionForm.date.trim(),
      type: transactionForm.type,
      refNo: transactionForm.refNo.trim(),
      description: transactionForm.description.trim(),
      debit: Number(transactionForm.debit),
      credit: Number(transactionForm.credit),
      method: transactionForm.method,
    };

    const fallbackTransaction: LedgerTransaction = {
      id: `TRX-${Date.now()}`,
      ...payload,
    };

    const previousLedgers = ledgers;

    const localUpdatedLedger = applyTransactionLocal(
      transactionLedger,
      fallbackTransaction,
    );

    const nextLedgers = ledgers.map((item) =>
      item.id === transactionLedger.id ? localUpdatedLedger : item,
    );

    syncLedgers(nextLedgers);

    try {
      const updatedLedger = await addTransactionApi(transactionLedger.id, payload);

      syncLedgers(
        nextLedgers.map((item) =>
          item.id === updatedLedger.id ? updatedLedger : item,
        ),
      );

      setMessage("Transaction added successfully.");
    } catch {
      syncLedgers(nextLedgers);
      setMessage("Transaction added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeTransactionModal();
    }

    return previousLedgers;
  };

  const handleStatusChange = async (
    ledger: PatientLedger,
    status: LedgerStatus,
  ) => {
    const previousLedgers = ledgers;

    const nextLedgers = ledgers.map((item) =>
      item.id === ledger.id ? { ...item, status } : item,
    );

    syncLedgers(nextLedgers);
    setMessage("");

    try {
      const updatedLedger = await updateLedgerStatusApi(ledger.id, status);

      syncLedgers(
        nextLedgers.map((item) =>
          item.id === updatedLedger.id ? updatedLedger : item,
        ),
      );
    } catch {
      syncLedgers(previousLedgers);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemoveLedger = async (ledger: PatientLedger) => {
    const previousLedgers = ledgers;
    const nextLedgers = ledgers.filter((item) => item.id !== ledger.id);

    syncLedgers(nextLedgers);
    setMessage("");

    try {
      await deleteLedgerApi(ledger.id);
      setMessage("Ledger removed successfully.");
    } catch {
      syncLedgers(previousLedgers);
      setMessage("Backend delete failed, ledger restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Patient Ledger
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Patient balances, transaction history and due tracking.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading ledgers from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: balance/search/filter/history/due tracking functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetLedgerForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Ledger
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_200px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search ledger, patient, phone, doctor, due status"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {ledgerStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1240px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Patient / Ledger
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Billing Summary
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Balance
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Due Tracking
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleLedgers.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.ledgerNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId} · {item.assignedDoctor}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        Billed: {money(item.totalBilled)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-emerald-700">
                        Paid: {money(item.totalPaid)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-cyan-700">
                        Discount: {money(item.totalDiscount)}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p
                        className={[
                          "text-sm font-black",
                          item.currentDue > 0
                            ? "text-rose-600"
                            : item.currentDue < 0
                              ? "text-blue-700"
                              : "text-emerald-700",
                        ].join(" ")}
                      >
                        {money(item.currentDue)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Opening: {money(item.openingBalance)}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-xs font-black text-slate-700">
                        <CalendarClock size={13} />
                        {item.nextDueDate}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Last: {item.lastTransactionDate}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as LedgerStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {ledgerStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedLedger(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => openTransactionModal(item)}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100"
                        >
                          <History size={13} />
                          Add Txn
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Clear")}
                          disabled={item.status === "Clear"}
                          className="inline-flex items-center gap-1 border border-blue-100 bg-blue-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-blue-700 transition hover:border-blue-200 hover:bg-blue-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Clear
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveLedger(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleLedgers.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No patient ledger found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <WalletCards size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedLedger && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Patient Ledger Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedLedger.ledgerNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedLedger.patientName} · {selectedLedger.status}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedLedger(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Patient", `${selectedLedger.patientName} (${selectedLedger.patientId})`],
                ["Phone", selectedLedger.phone],
                ["Doctor", selectedLedger.assignedDoctor],
                ["Opening Balance", money(selectedLedger.openingBalance)],
                ["Total Billed", money(selectedLedger.totalBilled)],
                ["Total Paid", money(selectedLedger.totalPaid)],
                ["Discount", money(selectedLedger.totalDiscount)],
                ["Current Balance", money(selectedLedger.currentDue)],
                ["Next Due Date", selectedLedger.nextDueDate],
                ["Last Transaction", selectedLedger.lastTransactionDate],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-4 border border-teal-100">
              <div className="border-b border-teal-100 bg-slate-50 px-3 py-2">
                <p className="text-[10px] font-black uppercase tracking-[0.16em] text-slate-500">
                  Transaction History
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse bg-white text-left">
                  <thead className="bg-slate-50">
                    <tr className="border-b border-slate-100">
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Date
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Type
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Ref
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Description
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Debit
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Credit
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Method
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {selectedLedger.transactions.map((transaction) => (
                      <tr
                        key={transaction.id}
                        className="border-b border-slate-100"
                      >
                        <td className="px-3 py-2 text-xs font-bold text-slate-600">
                          {transaction.date}
                        </td>
                        <td className="px-3 py-2">
                          <Badge
                            label={transaction.type}
                            className={typeClass[transaction.type]}
                          />
                        </td>
                        <td className="px-3 py-2 text-xs font-black text-slate-700">
                          {transaction.refNo}
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-slate-500">
                          {transaction.description}
                        </td>
                        <td className="px-3 py-2 text-xs font-black text-rose-600">
                          {money(transaction.debit)}
                        </td>
                        <td className="px-3 py-2 text-xs font-black text-emerald-700">
                          {money(transaction.credit)}
                        </td>
                        <td className="px-3 py-2">
                          <Badge
                            label={transaction.method}
                            className={methodClass[transaction.method]}
                          />
                        </td>
                      </tr>
                    ))}

                    {!selectedLedger.transactions.length && (
                      <tr>
                        <td
                          colSpan={7}
                          className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                        >
                          No transaction history found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-3xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Patient Ledger
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New balance record
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient balance, billing, paid amount and due tracking setup.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateLedger} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient ID">
                  <input
                    value={ledgerForm.patientId}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        patientId: event.target.value,
                      }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={ledgerForm.patientName}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        patientName: event.target.value,
                      }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={ledgerForm.phone}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        phone: event.target.value,
                      }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Assigned Doctor / Desk">
                  <input
                    value={ledgerForm.assignedDoctor}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        assignedDoctor: event.target.value,
                      }))
                    }
                    placeholder="Dr. Abdullah Rahman / Front Desk"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Opening Balance">
                  <input
                    value={ledgerForm.openingBalance}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        openingBalance: event.target.value,
                      }))
                    }
                    type="number"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Total Billed">
                  <input
                    value={ledgerForm.totalBilled}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        totalBilled: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Total Paid">
                  <input
                    value={ledgerForm.totalPaid}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        totalPaid: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Total Discount">
                  <input
                    value={ledgerForm.totalDiscount}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        totalDiscount: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Next Due Date">
                  <input
                    value={ledgerForm.nextDueDate}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        nextDueDate: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Status">
                  <select
                    value={ledgerForm.status}
                    onChange={(event) =>
                      setLedgerForm((prev) => ({
                        ...prev,
                        status: event.target.value as LedgerStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {ledgerStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Live Balance
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    Balance: {money(liveBalance)}
                  </p>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {ledgerFormReady
                  ? "Ledger form complete. Add Ledger button enabled."
                  : "Patient + phone + doctor/desk + balance fields complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!ledgerFormReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    ledgerFormReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Ledger"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {transactionOpen && transactionLedger && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-2xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Transaction
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {transactionLedger.patientName}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Current balance: {money(transactionLedger.currentDue)}
                </p>
              </div>

              <button
                type="button"
                onClick={closeTransactionModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddTransaction} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Date">
                  <input
                    value={transactionForm.date}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        date: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Type">
                  <select
                    value={transactionForm.type}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        type: event.target.value as TransactionType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {transactionTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Reference No">
                  <input
                    value={transactionForm.refNo}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        refNo: event.target.value,
                      }))
                    }
                    placeholder="INV-1001 / RCPT-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Payment Method">
                  <select
                    value={transactionForm.method}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        method: event.target.value as PaymentMethod,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {paymentMethods.map((method) => (
                      <option key={method} value={method}>
                        {method}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Debit">
                  <input
                    value={transactionForm.debit}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        debit: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    placeholder="Bill amount"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Credit">
                  <input
                    value={transactionForm.credit}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        credit: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    placeholder="Payment/discount"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Description">
                  <input
                    value={transactionForm.description}
                    onChange={(event) =>
                      setTransactionForm((prev) => ({
                        ...prev,
                        description: event.target.value,
                      }))
                    }
                    placeholder="Transaction note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none md:col-span-2"
                  />
                </Field>
              </div>

              <div className="border border-teal-100 bg-teal-50/70 p-3">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                  Transaction Effect
                </p>
                <p className="mt-1 text-sm font-black text-slate-800">
                  Debit {money(transactionDebit)} · Credit {money(transactionCredit)}
                </p>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeTransactionModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!transactionFormReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    transactionFormReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <History size={15} />
                  {saving ? "Adding..." : "Add Transaction"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicPatientLedgerPage;