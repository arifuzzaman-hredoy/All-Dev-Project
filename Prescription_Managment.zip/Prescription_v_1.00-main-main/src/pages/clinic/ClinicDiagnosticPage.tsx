import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Activity,
  Beaker,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  Eye,
  Filter,
  FlaskConical,
  Microscope,
  Phone,
  Search,
  Stethoscope,
  TestTube2,
  Trash2,
  UserPlus,
  X,
  type LucideIcon,
} from "lucide-react";

type LabOrderStatus =
  | "Draft"
  | "Ordered"
  | "Sample Collected"
  | "In Lab"
  | "Report Ready"
  | "Delivered"
  | "Cancelled";

type LabPriority = "Routine" | "Urgent" | "Critical";
type SampleStatus = "Not Collected" | "Collected" | "Rejected";
type PaymentStatus = "Paid" | "Due" | "Partial";

type LabOrder = {
  id: string;
  orderNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  doctorName: string;
  department: string;
  orderDate: string;
  deliveryDate: string;
  tests: string[];
  sampleType: string;
  sampleStatus: SampleStatus;
  priority: LabPriority;
  status: LabOrderStatus;
  paymentStatus: PaymentStatus;
  amount: number;
  paidAmount: number;
  labNote: string;
};

const orderStatuses: LabOrderStatus[] = [
  "Draft",
  "Ordered",
  "Sample Collected",
  "In Lab",
  "Report Ready",
  "Delivered",
  "Cancelled",
];

const priorities: LabPriority[] = ["Routine", "Urgent", "Critical"];

const sampleStatuses: SampleStatus[] = [
  "Not Collected",
  "Collected",
  "Rejected",
];

const paymentStatuses: PaymentStatus[] = ["Paid", "Due", "Partial"];

const mockOrders: LabOrder[] = [
  {
    id: "LAB-ID-1001",
    orderNo: "LAB-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    department: "Pathology",
    orderDate: "2026-06-20",
    deliveryDate: "2026-06-21",
    tests: ["CBC", "ESR", "Blood Sugar Fasting"],
    sampleType: "Blood",
    sampleStatus: "Collected",
    priority: "Routine",
    status: "In Lab",
    paymentStatus: "Paid",
    amount: 1200,
    paidAmount: 1200,
    labNote: "Sample received and processing.",
  },
  {
    id: "LAB-ID-1002",
    orderNo: "LAB-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    department: "Radiology",
    orderDate: "2026-06-20",
    deliveryDate: "2026-06-20",
    tests: ["ECG", "Chest X-Ray"],
    sampleType: "Imaging",
    sampleStatus: "Not Collected",
    priority: "Urgent",
    status: "Ordered",
    paymentStatus: "Partial",
    amount: 1800,
    paidAmount: 900,
    labNote: "Patient waiting for sample/imaging room.",
  },
  {
    id: "LAB-ID-1003",
    orderNo: "LAB-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    doctorName: "Front Desk",
    department: "Biochemistry",
    orderDate: "2026-06-19",
    deliveryDate: "2026-06-20",
    tests: ["Lipid Profile", "SGPT", "Creatinine"],
    sampleType: "Blood",
    sampleStatus: "Collected",
    priority: "Critical",
    status: "Report Ready",
    paymentStatus: "Due",
    amount: 2200,
    paidAmount: 0,
    labNote: "Report ready but payment due.",
  },
];

const emptyForm = {
  patientId: "",
  patientName: "",
  phone: "",
  doctorName: "",
  department: "Pathology",
  orderDate: "",
  deliveryDate: "",
  tests: "",
  sampleType: "Blood",
  sampleStatus: "Not Collected" as SampleStatus,
  priority: "Routine" as LabPriority,
  status: "Ordered" as LabOrderStatus,
  paymentStatus: "Due" as PaymentStatus,
  amount: "1000",
  paidAmount: "0",
  labNote: "",
};

const statusClass: Record<LabOrderStatus, string> = {
  Draft: "border-slate-200 bg-slate-50 text-slate-600",
  Ordered: "border-blue-200 bg-blue-50 text-blue-700",
  "Sample Collected": "border-cyan-200 bg-cyan-50 text-cyan-700",
  "In Lab": "border-amber-200 bg-amber-50 text-amber-700",
  "Report Ready": "border-emerald-200 bg-emerald-50 text-emerald-700",
  Delivered: "border-teal-200 bg-teal-50 text-teal-800",
  Cancelled: "border-rose-200 bg-rose-50 text-rose-700",
};

const priorityClass: Record<LabPriority, string> = {
  Routine: "border-slate-200 bg-slate-50 text-slate-600",
  Urgent: "border-orange-200 bg-orange-50 text-orange-700",
  Critical: "border-rose-200 bg-rose-50 text-rose-700",
};

const sampleClass: Record<SampleStatus, string> = {
  "Not Collected": "border-slate-200 bg-slate-50 text-slate-500",
  Collected: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Rejected: "border-rose-200 bg-rose-50 text-rose-700",
};

const paymentClass: Record<PaymentStatus, string> = {
  Paid: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Due: "border-rose-200 bg-rose-50 text-rose-700",
  Partial: "border-amber-200 bg-amber-50 text-amber-700",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const parseTests = (value: string) =>
  value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

const localFilter = (
  items: LabOrder[],
  filters: {
    query: string;
    status: string;
    department: string;
    priority: string;
    sampleStatus: string;
    paymentStatus: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.orderNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.doctorName} ${item.department} ${item.tests.join(" ")} ${item.sampleType} ${item.status} ${item.priority} ${item.paymentStatus} ${item.labNote}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.status || item.status === filters.status) &&
      (!filters.department || item.department === filters.department) &&
      (!filters.priority || item.priority === filters.priority) &&
      (!filters.sampleStatus || item.sampleStatus === filters.sampleStatus) &&
      (!filters.paymentStatus || item.paymentStatus === filters.paymentStatus)
    );
  });
};

const loadOrders = async (
  filters = {
    query: "",
    status: "",
    department: "",
    priority: "",
    sampleStatus: "",
    paymentStatus: "",
  },
  fallback = mockOrders,
): Promise<LabOrder[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.department) params.set("department", filters.department);
    if (filters.priority) params.set("priority", filters.priority);
    if (filters.sampleStatus) params.set("sampleStatus", filters.sampleStatus);
    if (filters.paymentStatus) params.set("paymentStatus", filters.paymentStatus);

    const url = params.toString()
      ? `/api/clinic/diagnostic?${params.toString()}`
      : "/api/clinic/diagnostic";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { orders?: LabOrder[] };

    return Array.isArray(data.orders)
      ? data.orders
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createOrderApi = async (
  payload: Omit<LabOrder, "id" | "orderNo">,
): Promise<LabOrder> => {
  const response = await fetch("/api/clinic/diagnostic", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create lab order failed");

  const data = (await response.json()) as { order?: LabOrder };
  if (!data.order) throw new Error("Invalid lab order response");

  return data.order;
};

const updateOrderStatusApi = async (
  id: string,
  status: LabOrderStatus,
): Promise<LabOrder> => {
  const response = await fetch(`/api/clinic/diagnostic/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update lab order status failed");

  const data = (await response.json()) as { order?: LabOrder };
  if (!data.order) throw new Error("Invalid status response");

  return data.order;
};

const updateSampleStatusApi = async (
  id: string,
  sampleStatus: SampleStatus,
): Promise<LabOrder> => {
  const response = await fetch(`/api/clinic/diagnostic/${id}/sample`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ sampleStatus }),
  });

  if (!response.ok) throw new Error("Update sample status failed");

  const data = (await response.json()) as { order?: LabOrder };
  if (!data.order) throw new Error("Invalid sample response");

  return data.order;
};

const deleteOrderApi = async (id: string) => {
  const response = await fetch(`/api/clinic/diagnostic/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete lab order failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string;
  hint: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{hint}</p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicDiagnosticPage = () => {
  const [orders, setOrders] = useState<LabOrder[]>(mockOrders);
  const [visibleOrders, setVisibleOrders] = useState<LabOrder[]>(mockOrders);
  const [selectedOrder, setSelectedOrder] = useState<LabOrder | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("");
  const [sampleFilter, setSampleFilter] = useState("");
  const [paymentFilter, setPaymentFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      department: departmentFilter,
      priority: priorityFilter,
      sampleStatus: sampleFilter,
      paymentStatus: paymentFilter,
    }),
    [
      query,
      statusFilter,
      departmentFilter,
      priorityFilter,
      sampleFilter,
      paymentFilter,
    ],
  );

  const departmentOptions = useMemo(
    () => Array.from(new Set(orders.map((item) => item.department))),
    [orders],
  );

  const amount = Number(form.amount);
  const paidAmount = Number(form.paidAmount);
  const dueAmount = Math.max(0, amount - paidAmount);

  const formReady =
    form.patientId.trim().length >= 2 &&
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    form.doctorName.trim().length >= 2 &&
    form.department.trim().length >= 2 &&
    form.orderDate.trim().length >= 4 &&
    form.deliveryDate.trim().length >= 4 &&
    parseTests(form.tests).length > 0 &&
    form.sampleType.trim().length >= 2 &&
    Number.isFinite(amount) &&
    amount >= 0 &&
    Number.isFinite(paidAmount) &&
    paidAmount >= 0;

  useEffect(() => {
    let active = true;

    loadOrders().then((data) => {
      if (!active) return;
      setOrders(data);
      setVisibleOrders(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadOrders(filters, orders).then((data) => {
        if (!active) return;
        setVisibleOrders(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, orders]);

  const stats = useMemo(() => {
    const totalAmount = orders.reduce(
      (total, item) => total + Number(item.amount || 0),
      0,
    );
    const inLab = orders.filter((item) => item.status === "In Lab").length;
    const reportReady = orders.filter(
      (item) => item.status === "Report Ready",
    ).length;
    const sampleCollected = orders.filter(
      (item) => item.sampleStatus === "Collected",
    ).length;

    return [
      {
        label: "Lab Orders",
        value: String(orders.length),
        hint: `${sampleCollected} sample collected`,
        icon: ClipboardList,
      },
      {
        label: "In Lab",
        value: String(inLab),
        hint: "Processing tests",
        icon: Microscope,
      },
      {
        label: "Report Ready",
        value: String(reportReady),
        hint: "Ready for delivery",
        icon: CheckCircle2,
      },
      {
        label: "Revenue",
        value: money(totalAmount),
        hint: "Diagnostic billing",
        icon: Activity,
      },
    ];
  }, [orders]);

  const syncOrders = (nextOrders: LabOrder[]) => {
    setOrders(nextOrders);
    setVisibleOrders(localFilter(nextOrders, filters));

    if (selectedOrder) {
      setSelectedOrder(
        nextOrders.find((item) => item.id === selectedOrder.id) || null,
      );
    }
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setDepartmentFilter("");
    setPriorityFilter("");
    setSampleFilter("");
    setPaymentFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Lab order form complete korle Add Lab Order button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload: Omit<LabOrder, "id" | "orderNo"> = {
      patientId: form.patientId.trim(),
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      doctorName: form.doctorName.trim(),
      department: form.department.trim(),
      orderDate: form.orderDate.trim(),
      deliveryDate: form.deliveryDate.trim(),
      tests: parseTests(form.tests),
      sampleType: form.sampleType.trim(),
      sampleStatus: form.sampleStatus,
      priority: form.priority,
      status: form.status,
      paymentStatus:
        paidAmount >= amount ? "Paid" : paidAmount > 0 ? "Partial" : "Due",
      amount,
      paidAmount,
      labNote: form.labNote.trim() || "No lab note",
    };

    const fallbackOrder: LabOrder = {
      id: `LAB-ID-${Date.now()}`,
      orderNo: `LAB-${String(orders.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdOrder = await createOrderApi(payload);
      syncOrders([createdOrder, ...orders]);
      setMessage("Lab order added successfully.");
    } catch {
      syncOrders([fallbackOrder, ...orders]);
      setMessage("Lab order added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    order: LabOrder,
    status: LabOrderStatus,
  ) => {
    const previousOrders = orders;

    const nextOrders = orders.map((item) =>
      item.id === order.id ? { ...item, status } : item,
    );

    syncOrders(nextOrders);
    setMessage("");

    try {
      const updatedOrder = await updateOrderStatusApi(order.id, status);

      syncOrders(
        nextOrders.map((item) =>
          item.id === updatedOrder.id ? updatedOrder : item,
        ),
      );
    } catch {
      syncOrders(previousOrders);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleSampleChange = async (
    order: LabOrder,
    sampleStatus: SampleStatus,
  ) => {
    const previousOrders = orders;

    const nextStatus: LabOrderStatus =
      sampleStatus === "Collected" && order.status === "Ordered"
        ? "Sample Collected"
        : order.status;

    const nextOrders = orders.map((item) =>
      item.id === order.id ? { ...item, sampleStatus, status: nextStatus } : item,
    );

    syncOrders(nextOrders);
    setMessage("");

    try {
      const updatedOrder = await updateSampleStatusApi(order.id, sampleStatus);

      syncOrders(
        nextOrders.map((item) =>
          item.id === updatedOrder.id ? updatedOrder : item,
        ),
      );
    } catch {
      syncOrders(previousOrders);
      setMessage("Backend sample update failed. Previous sample status restored.");
    }
  };

  const handleRemoveOrder = async (order: LabOrder) => {
    const previousOrders = orders;
    const nextOrders = orders.filter((item) => item.id !== order.id);

    syncOrders(nextOrders);
    setMessage("");

    try {
      await deleteOrderApi(order.id);
      setMessage("Lab order removed successfully.");
    } catch {
      syncOrders(previousOrders);
      setMessage("Backend delete failed, lab order restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Diagnostic
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Hybrid clinic diagnostic workflow shortcut and lab order shell.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading lab orders from backend API..."
                    : searching
                      ? "Searching diagnostic database..."
                      : "Ready: lab order/sample/report/payment workflow functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Lab Order
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_150px_170px_150px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search lab order, patient, doctor, test, sample"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {orderStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={departmentFilter}
              onChange={(event) => setDepartmentFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Department</option>
              {departmentOptions.map((department) => (
                <option key={department} value={department}>
                  {department}
                </option>
              ))}
            </select>

            <select
              value={priorityFilter}
              onChange={(event) => setPriorityFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Priority</option>
              {priorities.map((priority) => (
                <option key={priority} value={priority}>
                  {priority}
                </option>
              ))}
            </select>

            <select
              value={sampleFilter}
              onChange={(event) => setSampleFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Sample</option>
              {sampleStatuses.map((sample) => (
                <option key={sample} value={sample}>
                  {sample}
                </option>
              ))}
            </select>

            <select
              value={paymentFilter}
              onChange={(event) => setPaymentFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Payment</option>
              {paymentStatuses.map((payment) => (
                <option key={payment} value={payment}>
                  {payment}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1320px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Order / Patient
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor / Department
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Tests
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Sample
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Billing
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleOrders.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.orderNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Stethoscope size={14} />
                        {item.doctorName}
                      </p>
                      <p className="mt-1 text-[11px] font-black text-teal-700">
                        {item.department}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.orderDate} → {item.deliveryDate}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex max-w-[340px] flex-wrap gap-1">
                        {item.tests.slice(0, 3).map((test) => (
                          <span
                            key={`${item.id}-${test}`}
                            className="border border-teal-100 bg-teal-50 px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em] text-teal-800"
                          >
                            {test}
                          </span>
                        ))}
                        {item.tests.length > 3 ? (
                          <span className="border border-slate-200 bg-slate-50 px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em] text-slate-500">
                            +{item.tests.length - 3}
                          </span>
                        ) : null}
                      </div>
                      <div className="mt-1">
                        <Badge
                          label={item.priority}
                          className={priorityClass[item.priority]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-xs font-black text-slate-700">
                        <TestTube2 size={13} />
                        {item.sampleType}
                      </p>

                      <div className="mt-1">
                        <select
                          value={item.sampleStatus}
                          onChange={(event) =>
                            handleSampleChange(
                              item,
                              event.target.value as SampleStatus,
                            )
                          }
                          className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                        >
                          {sampleStatuses.map((status) => (
                            <option key={status} value={status}>
                              {status}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="mt-1">
                        <Badge
                          label={item.sampleStatus}
                          className={sampleClass[item.sampleStatus]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-800">
                        {money(item.amount)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-emerald-700">
                        Paid {money(item.paidAmount)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-rose-600">
                        Due {money(item.amount - item.paidAmount)}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.paymentStatus}
                          className={paymentClass[item.paymentStatus]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as LabOrderStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {orderStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedOrder(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            handleSampleChange(item, "Collected")
                          }
                          disabled={item.sampleStatus === "Collected"}
                          className="inline-flex items-center gap-1 border border-cyan-100 bg-cyan-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-cyan-700 transition hover:border-cyan-200 hover:bg-cyan-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <Beaker size={13} />
                          Sample
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Report Ready")}
                          disabled={item.status === "Report Ready" || item.status === "Delivered"}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Ready
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveOrder(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleOrders.length && (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No diagnostic lab order found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <FlaskConical size={14} />
            Clinic diagnostic workflow + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedOrder && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Diagnostic Order Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedOrder.orderNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedOrder.patientName} · {selectedOrder.department}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Patient", `${selectedOrder.patientName} (${selectedOrder.patientId})`],
                ["Phone", selectedOrder.phone],
                ["Doctor", selectedOrder.doctorName],
                ["Department", selectedOrder.department],
                ["Order Date", selectedOrder.orderDate],
                ["Delivery Date", selectedOrder.deliveryDate],
                ["Sample Type", selectedOrder.sampleType],
                ["Sample Status", selectedOrder.sampleStatus],
                ["Priority", selectedOrder.priority],
                ["Status", selectedOrder.status],
                ["Amount", money(selectedOrder.amount)],
                ["Paid", money(selectedOrder.paidAmount)],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Test List
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {selectedOrder.tests.map((test) => (
                    <span
                      key={test}
                      className="border border-teal-100 bg-teal-50 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-teal-800"
                    >
                      {test}
                    </span>
                  ))}
                </div>
              </div>

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Lab Note
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedOrder.labNote}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Diagnostic Order
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New lab order
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient, doctor, tests, sample, payment and report workflow add koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient ID">
                  <input
                    value={form.patientId}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientId: event.target.value }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientName: event.target.value }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, phone: event.target.value }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Doctor / Referred By">
                  <input
                    value={form.doctorName}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, doctorName: event.target.value }))
                    }
                    placeholder="Dr. Abdullah Rahman / Front Desk"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Department">
                  <input
                    value={form.department}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, department: event.target.value }))
                    }
                    placeholder="Pathology / Radiology"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Sample Type">
                  <input
                    value={form.sampleType}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, sampleType: event.target.value }))
                    }
                    placeholder="Blood / Urine / Imaging"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Order Date">
                  <input
                    value={form.orderDate}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, orderDate: event.target.value }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Delivery Date">
                  <input
                    value={form.deliveryDate}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, deliveryDate: event.target.value }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Priority">
                  <select
                    value={form.priority}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        priority: event.target.value as LabPriority,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {priorities.map((priority) => (
                      <option key={priority} value={priority}>
                        {priority}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Sample Status">
                  <select
                    value={form.sampleStatus}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        sampleStatus: event.target.value as SampleStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {sampleStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Order Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as LabOrderStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {orderStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Amount">
                  <input
                    value={form.amount}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, amount: event.target.value }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Paid Amount">
                  <input
                    value={form.paidAmount}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, paidAmount: event.target.value }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="Tests">
                    <input
                      value={form.tests}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, tests: event.target.value }))
                      }
                      placeholder="CBC, ESR, Blood Sugar, ECG"
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>
                </div>

                <div className="md:col-span-2">
                  <Field label="Lab Note">
                    <textarea
                      value={form.labNote}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, labNote: event.target.value }))
                      }
                      rows={3}
                      placeholder="Sample instruction, lab note or report note"
                      className="resize-none border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>
                </div>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Live Billing Summary
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    Amount {money(amount)} · Paid {money(paidAmount)} · Due {money(dueAmount)}
                  </p>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Lab order form complete. Add Lab Order button enabled."
                  : "Patient + doctor + date + tests + sample + amount complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Lab Order"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicDiagnosticPage;