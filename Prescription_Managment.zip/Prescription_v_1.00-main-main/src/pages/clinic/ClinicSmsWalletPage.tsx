import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Banknote,
  BellRing,
  CheckCircle2,
  Eye,
  Filter,
  MessageSquareText,
  Search,
  Send,
  Trash2,
  UserPlus,
  WalletCards,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type SmsRecordType = "Recharge" | "Usage" | "Refund" | "Adjustment";
type SmsRecordStatus = "Pending" | "Completed" | "Failed" | "Cancelled";
type SmsChannel = "Appointment" | "Prescription" | "Billing" | "Report" | "Marketing" | "System";

type SmsWalletRecord = {
  id: string;
  refNo: string;
  date: string;
  title: string;
  type: SmsRecordType;
  channel: SmsChannel;
  smsCount: number;
  unitCost: number;
  amount: number;
  balanceAfter: number;
  status: SmsRecordStatus;
  recipientGroup: string;
  templateName: string;
  gatewayRef: string;
  note: string;
};

type SmsWalletSummary = {
  balanceSms: number;
  balanceAmount: number;
  totalRecharge: number;
  totalUsed: number;
  delivered: number;
  failed: number;
};

type SmsWalletResponse = {
  summary: SmsWalletSummary;
  records: SmsWalletRecord[];
};

const recordTypes: SmsRecordType[] = ["Recharge", "Usage", "Refund", "Adjustment"];

const recordStatuses: SmsRecordStatus[] = [
  "Pending",
  "Completed",
  "Failed",
  "Cancelled",
];

const channels: SmsChannel[] = [
  "Appointment",
  "Prescription",
  "Billing",
  "Report",
  "Marketing",
  "System",
];

const mockRecords: SmsWalletRecord[] = [
  {
    id: "SMS-ID-1001",
    refNo: "SMS-RECH-1001",
    date: "2026-06-20",
    title: "Monthly SMS wallet recharge",
    type: "Recharge",
    channel: "System",
    smsCount: 5000,
    unitCost: 0.35,
    amount: 1750,
    balanceAfter: 5000,
    status: "Completed",
    recipientGroup: "Clinic account",
    templateName: "Wallet Recharge",
    gatewayRef: "SSL-SMS-RECH-1001",
    note: "5000 SMS added to wallet.",
  },
  {
    id: "SMS-ID-1002",
    refNo: "SMS-USE-1002",
    date: "2026-06-20",
    title: "Appointment confirmation SMS",
    type: "Usage",
    channel: "Appointment",
    smsCount: 82,
    unitCost: 0.35,
    amount: 28.7,
    balanceAfter: 4918,
    status: "Completed",
    recipientGroup: "Today appointments",
    templateName: "Appointment Confirmation",
    gatewayRef: "GATEWAY-BATCH-8821",
    note: "Appointment confirmation notification sent.",
  },
  {
    id: "SMS-ID-1003",
    refNo: "SMS-USE-1003",
    date: "2026-06-19",
    title: "Billing due reminder",
    type: "Usage",
    channel: "Billing",
    smsCount: 26,
    unitCost: 0.35,
    amount: 9.1,
    balanceAfter: 4892,
    status: "Failed",
    recipientGroup: "Due patients",
    templateName: "Payment Due Reminder",
    gatewayRef: "GATEWAY-BATCH-8818",
    note: "3 numbers failed due to invalid phone.",
  },
];

const emptyForm = {
  date: "",
  title: "",
  type: "Recharge" as SmsRecordType,
  channel: "System" as SmsChannel,
  smsCount: "1000",
  unitCost: "0.35",
  amount: "350",
  status: "Completed" as SmsRecordStatus,
  recipientGroup: "",
  templateName: "",
  gatewayRef: "",
  note: "",
};

const statusClass: Record<SmsRecordStatus, string> = {
  Pending: "border-amber-200 bg-amber-50 text-amber-700",
  Completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Failed: "border-rose-200 bg-rose-50 text-rose-700",
  Cancelled: "border-slate-200 bg-slate-50 text-slate-500",
};

const typeClass: Record<SmsRecordType, string> = {
  Recharge: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Usage: "border-blue-200 bg-blue-50 text-blue-700",
  Refund: "border-violet-200 bg-violet-50 text-violet-700",
  Adjustment: "border-amber-200 bg-amber-50 text-amber-700",
};

const channelClass: Record<SmsChannel, string> = {
  Appointment: "border-teal-200 bg-teal-50 text-teal-800",
  Prescription: "border-cyan-200 bg-cyan-50 text-cyan-700",
  Billing: "border-orange-200 bg-orange-50 text-orange-700",
  Report: "border-indigo-200 bg-indigo-50 text-indigo-700",
  Marketing: "border-pink-200 bg-pink-50 text-pink-700",
  System: "border-slate-200 bg-slate-50 text-slate-600",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const calculateSummary = (records: SmsWalletRecord[]): SmsWalletSummary => {
  const completedRecords = records.filter((item) => item.status === "Completed");

  const totalRecharge = completedRecords
    .filter((item) => item.type === "Recharge" || item.type === "Refund")
    .reduce((total, item) => total + Number(item.smsCount || 0), 0);

  const totalUsed = completedRecords
    .filter((item) => item.type === "Usage")
    .reduce((total, item) => total + Number(item.smsCount || 0), 0);

  const balanceSms = records.length
    ? Number(records[0].balanceAfter || 0)
    : Math.max(0, totalRecharge - totalUsed);

  const unitCost = records[0]?.unitCost || 0.35;

  return {
    balanceSms,
    balanceAmount: balanceSms * unitCost,
    totalRecharge,
    totalUsed,
    delivered: completedRecords.filter((item) => item.type === "Usage").length,
    failed: records.filter((item) => item.status === "Failed").length,
  };
};

const mockWallet: SmsWalletResponse = {
  summary: calculateSummary(mockRecords),
  records: mockRecords,
};

const localFilter = (
  items: SmsWalletRecord[],
  filters: {
    query: string;
    type: string;
    status: string;
    channel: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.refNo} ${item.title} ${item.type} ${item.channel} ${item.status} ${item.recipientGroup} ${item.templateName} ${item.gatewayRef} ${item.note}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.type || item.type === filters.type) &&
      (!filters.status || item.status === filters.status) &&
      (!filters.channel || item.channel === filters.channel)
    );
  });
};

const loadSmsWallet = async (
  filters = {
    query: "",
    type: "",
    status: "",
    channel: "",
  },
  fallback = mockWallet,
): Promise<SmsWalletResponse> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.type) params.set("type", filters.type);
    if (filters.status) params.set("status", filters.status);
    if (filters.channel) params.set("channel", filters.channel);

    const url = params.toString()
      ? `/api/clinic/sms-wallet?${params.toString()}`
      : "/api/clinic/sms-wallet";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) {
      const records = localFilter(fallback.records, filters);
      return { summary: calculateSummary(fallback.records), records };
    }

    const data = (await response.json()) as {
      wallet?: SmsWalletResponse;
    };

    return data.wallet ? data.wallet : fallback;
  } catch {
    const records = localFilter(fallback.records, filters);
    return { summary: calculateSummary(fallback.records), records };
  }
};

const createSmsRecordApi = async (
  payload: Omit<SmsWalletRecord, "id" | "refNo" | "balanceAfter">,
): Promise<SmsWalletRecord> => {
  const response = await fetch("/api/clinic/sms-wallet", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create SMS wallet record failed");

  const data = (await response.json()) as { record?: SmsWalletRecord };
  if (!data.record) throw new Error("Invalid SMS wallet response");

  return data.record;
};

const updateSmsRecordStatusApi = async (
  id: string,
  status: SmsRecordStatus,
): Promise<SmsWalletRecord> => {
  const response = await fetch(`/api/clinic/sms-wallet/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update SMS wallet status failed");

  const data = (await response.json()) as { record?: SmsWalletRecord };
  if (!data.record) throw new Error("Invalid status response");

  return data.record;
};

const deleteSmsRecordApi = async (id: string) => {
  const response = await fetch(`/api/clinic/sms-wallet/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete SMS wallet record failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string;
  hint: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{hint}</p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicSmsWalletPage = () => {
  const [records, setRecords] = useState<SmsWalletRecord[]>(mockRecords);
  const [visibleRecords, setVisibleRecords] =
    useState<SmsWalletRecord[]>(mockRecords);
  const [summary, setSummary] = useState<SmsWalletSummary>(mockWallet.summary);
  const [selectedRecord, setSelectedRecord] = useState<SmsWalletRecord | null>(
    null,
  );
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [channelFilter, setChannelFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      type: typeFilter,
      status: statusFilter,
      channel: channelFilter,
    }),
    [query, typeFilter, statusFilter, channelFilter],
  );

  const formSmsCount = Number(form.smsCount);
  const formUnitCost = Number(form.unitCost);
  const formAmount =
    form.type === "Recharge" || form.type === "Refund"
      ? Number(form.amount)
      : formSmsCount * formUnitCost;

  const currentBalance = records[0]?.balanceAfter || summary.balanceSms || 0;
  const liveBalance =
    form.type === "Recharge" || form.type === "Refund"
      ? currentBalance + formSmsCount
      : form.type === "Usage"
        ? Math.max(0, currentBalance - formSmsCount)
        : currentBalance;

  const formReady =
    form.date.trim().length >= 4 &&
    form.title.trim().length >= 2 &&
    Number.isFinite(formSmsCount) &&
    formSmsCount > 0 &&
    Number.isFinite(formUnitCost) &&
    formUnitCost >= 0 &&
    Number.isFinite(formAmount) &&
    formAmount >= 0 &&
    form.recipientGroup.trim().length >= 2 &&
    form.templateName.trim().length >= 2 &&
    recordTypes.includes(form.type) &&
    recordStatuses.includes(form.status) &&
    channels.includes(form.channel);

  useEffect(() => {
    let active = true;

    loadSmsWallet().then((data) => {
      if (!active) return;
      setSummary(data.summary);
      setRecords(data.records);
      setVisibleRecords(data.records);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadSmsWallet(filters, { summary, records }).then((data) => {
        if (!active) return;
        setSummary(data.summary);
        setVisibleRecords(data.records);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, records, summary]);

  const stats = useMemo(
    () => [
      {
        label: "SMS Balance",
        value: String(summary.balanceSms),
        hint: money(summary.balanceAmount),
        icon: WalletCards,
      },
      {
        label: "Recharged",
        value: String(summary.totalRecharge),
        hint: "Total SMS added",
        icon: Banknote,
      },
      {
        label: "Used SMS",
        value: String(summary.totalUsed),
        hint: "Notification usage",
        icon: Send,
      },
      {
        label: "Failed",
        value: String(summary.failed),
        hint: `${summary.delivered} delivered batches`,
        icon: BellRing,
      },
    ],
    [summary],
  );

  const syncRecords = (nextRecords: SmsWalletRecord[]) => {
    const nextSummary = calculateSummary(nextRecords);

    setRecords(nextRecords);
    setSummary(nextSummary);
    setVisibleRecords(localFilter(nextRecords, filters));

    if (selectedRecord) {
      setSelectedRecord(
        nextRecords.find((item) => item.id === selectedRecord.id) || null,
      );
    }
  };

  const resetFilters = () => {
    setQuery("");
    setTypeFilter("");
    setStatusFilter("");
    setChannelFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("SMS wallet form complete korle Add Record button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      date: form.date.trim(),
      title: form.title.trim(),
      type: form.type,
      channel: form.channel,
      smsCount: Number(form.smsCount),
      unitCost: Number(form.unitCost),
      amount: Number(formAmount.toFixed(2)),
      status: form.status,
      recipientGroup: form.recipientGroup.trim(),
      templateName: form.templateName.trim(),
      gatewayRef: form.gatewayRef.trim() || `GATEWAY-${Date.now()}`,
      note: form.note.trim() || "No SMS wallet note",
    };

    const fallbackRecord: SmsWalletRecord = {
      id: `SMS-ID-${Date.now()}`,
      refNo: `SMS-${form.type.toUpperCase()}-${String(records.length + 1).padStart(4, "0")}`,
      balanceAfter: liveBalance,
      ...payload,
    };

    try {
      const createdRecord = await createSmsRecordApi(payload);
      syncRecords([createdRecord, ...records]);
      setMessage("SMS wallet record added successfully.");
    } catch {
      syncRecords([fallbackRecord, ...records]);
      setMessage("SMS record added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    record: SmsWalletRecord,
    status: SmsRecordStatus,
  ) => {
    const previousRecords = records;

    const nextRecords = records.map((item) =>
      item.id === record.id ? { ...item, status } : item,
    );

    syncRecords(nextRecords);
    setMessage("");

    try {
      const updatedRecord = await updateSmsRecordStatusApi(record.id, status);

      syncRecords(
        nextRecords.map((item) =>
          item.id === updatedRecord.id ? updatedRecord : item,
        ),
      );
    } catch {
      syncRecords(previousRecords);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemoveRecord = async (record: SmsWalletRecord) => {
    const previousRecords = records;
    const nextRecords = records.filter((item) => item.id !== record.id);

    syncRecords(nextRecords);
    setMessage("");

    try {
      await deleteSmsRecordApi(record.id);
      setMessage("SMS wallet record removed successfully.");
    } catch {
      syncRecords(previousRecords);
      setMessage("Backend delete failed, SMS record restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                SMS Wallet
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                SMS balance, recharge records and notification usage.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading SMS wallet from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: balance/recharge/usage/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Record
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_170px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search ref, template, gateway, channel, note"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Type</option>
              {recordTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {recordStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={channelFilter}
              onChange={(event) => setChannelFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Channel</option>
              {channels.map((channel) => (
                <option key={channel} value={channel}>
                  {channel}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1240px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    SMS Record
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Channel / Template
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    SMS / Amount
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Balance
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleRecords.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.refNo}
                      </p>
                      <p className="mt-0.5 max-w-[260px] truncate text-[11px] font-bold text-slate-500">
                        {item.title}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.date}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        <Badge label={item.channel} className={channelClass[item.channel]} />
                        <Badge label={item.type} className={typeClass[item.type]} />
                      </div>
                      <p className="mt-1 text-xs font-black text-slate-700">
                        {item.templateName}
                      </p>
                      <p className="mt-1 max-w-[220px] truncate text-[11px] font-bold text-slate-500">
                        {item.recipientGroup}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-900">
                        {item.smsCount} SMS
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Unit {money(item.unitCost)} · Total {money(item.amount)}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-emerald-700">
                        {item.balanceAfter} SMS
                      </p>
                      <p className="mt-1 max-w-[200px] truncate text-[11px] font-bold text-slate-500">
                        {item.gatewayRef}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as SmsRecordStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {recordStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedRecord(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Completed")}
                          disabled={item.status === "Completed"}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Done
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Cancelled")}
                          disabled={item.status === "Cancelled"}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <XCircle size={13} />
                          Cancel
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveRecord(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleRecords.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No SMS wallet record found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <MessageSquareText size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedRecord && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  SMS Wallet Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedRecord.refNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedRecord.title} · {selectedRecord.type}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Date", selectedRecord.date],
                ["Channel", selectedRecord.channel],
                ["Type", selectedRecord.type],
                ["Status", selectedRecord.status],
                ["SMS Count", String(selectedRecord.smsCount)],
                ["Amount", money(selectedRecord.amount)],
                ["Balance After", `${selectedRecord.balanceAfter} SMS`],
                ["Gateway Ref", selectedRecord.gatewayRef],
                ["Recipient Group", selectedRecord.recipientGroup],
                ["Template", selectedRecord.templateName],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Note
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedRecord.note}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-3xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add SMS Wallet Record
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  Recharge or notification usage
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  SMS recharge, usage, refund and gateway reference add koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Date">
                  <input
                    value={form.date}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, date: event.target.value }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Title">
                  <input
                    value={form.title}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, title: event.target.value }))
                    }
                    placeholder="Appointment SMS / Wallet recharge"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Type">
                  <select
                    value={form.type}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        type: event.target.value as SmsRecordType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {recordTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Channel">
                  <select
                    value={form.channel}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        channel: event.target.value as SmsChannel,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {channels.map((channel) => (
                      <option key={channel} value={channel}>
                        {channel}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="SMS Count">
                  <input
                    value={form.smsCount}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        smsCount: event.target.value,
                        amount:
                          prev.type === "Recharge"
                            ? prev.amount
                            : String(
                                Number(event.target.value || 0) *
                                  Number(prev.unitCost || 0),
                              ),
                      }))
                    }
                    type="number"
                    min={1}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Unit Cost">
                  <input
                    value={form.unitCost}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        unitCost: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    step="0.01"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Amount">
                  <input
                    value={form.amount}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        amount: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    step="0.01"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as SmsRecordStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {recordStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Recipient Group">
                  <input
                    value={form.recipientGroup}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        recipientGroup: event.target.value,
                      }))
                    }
                    placeholder="Today appointments / Due patients"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Template Name">
                  <input
                    value={form.templateName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        templateName: event.target.value,
                      }))
                    }
                    placeholder="Appointment Confirmation"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Gateway Reference">
                  <input
                    value={form.gatewayRef}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        gatewayRef: event.target.value,
                      }))
                    }
                    placeholder="GATEWAY-BATCH-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Note">
                  <input
                    value={form.note}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, note: event.target.value }))
                    }
                    placeholder="SMS wallet note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Live Summary
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    Current {currentBalance} SMS · After this record {liveBalance} SMS · Amount {money(formAmount)}
                  </p>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "SMS wallet form complete. Add Record button enabled."
                  : "Date + title + SMS count + recipient group + template complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Record"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicSmsWalletPage;