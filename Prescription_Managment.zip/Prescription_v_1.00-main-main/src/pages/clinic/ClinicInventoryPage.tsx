import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  AlertTriangle,
  Boxes,
  CalendarClock,
  CheckCircle2,
  Eye,
  Filter,
  PackagePlus,
  Pill,
  Search,
  Trash2,
  Truck,
  X,
  type LucideIcon,
} from "lucide-react";

type InventoryCategory =
  | "Medicine"
  | "Consumable"
  | "Equipment"
  | "Reagent"
  | "Stationery"
  | "Other";

type InventoryStatus =
  | "In Stock"
  | "Low Stock"
  | "Out of Stock"
  | "Expired"
  | "Inactive";

type MovementType = "Stock In" | "Stock Out" | "Damage" | "Return";

type StockMovement = {
  id: string;
  date: string;
  type: MovementType;
  quantity: number;
  note: string;
  by: string;
};

type InventoryItem = {
  id: string;
  sku: string;
  name: string;
  category: InventoryCategory;
  unit: string;
  batchNo: string;
  supplier: string;
  expiryDate: string;
  purchasePrice: number;
  salePrice: number;
  stock: number;
  reorderLevel: number;
  location: string;
  status: InventoryStatus;
  notes: string;
  movements: StockMovement[];
};

const categories: InventoryCategory[] = [
  "Medicine",
  "Consumable",
  "Equipment",
  "Reagent",
  "Stationery",
  "Other",
];

const statuses: InventoryStatus[] = [
  "In Stock",
  "Low Stock",
  "Out of Stock",
  "Expired",
  "Inactive",
];

const movementTypes: MovementType[] = [
  "Stock In",
  "Stock Out",
  "Damage",
  "Return",
];

const mockItems: InventoryItem[] = [
  {
    id: "INV-STK-ID-1001",
    sku: "MED-1001",
    name: "Napa 500mg",
    category: "Medicine",
    unit: "Strip",
    batchNo: "NP-26-01",
    supplier: "Beximco Pharma",
    expiryDate: "2027-01-20",
    purchasePrice: 12,
    salePrice: 15,
    stock: 240,
    reorderLevel: 40,
    location: "Pharmacy Rack A1",
    status: "In Stock",
    notes: "Common fever medicine.",
    movements: [
      {
        id: "MOV-1001",
        date: "2026-06-20",
        type: "Stock In",
        quantity: 240,
        note: "Opening stock",
        by: "Admin",
      },
    ],
  },
  {
    id: "INV-STK-ID-1002",
    sku: "SUP-1002",
    name: "Disposable Syringe 5ml",
    category: "Consumable",
    unit: "Piece",
    batchNo: "SYR-5ML-88",
    supplier: "Medical Supply House",
    expiryDate: "2028-03-10",
    purchasePrice: 4,
    salePrice: 8,
    stock: 18,
    reorderLevel: 50,
    location: "Store Room B2",
    status: "Low Stock",
    notes: "Injection supply item.",
    movements: [
      {
        id: "MOV-1002",
        date: "2026-06-19",
        type: "Stock Out",
        quantity: 32,
        note: "Used in clinic procedure room",
        by: "Reception",
      },
    ],
  },
  {
    id: "INV-STK-ID-1003",
    sku: "REG-1003",
    name: "CBC Reagent",
    category: "Reagent",
    unit: "Bottle",
    batchNo: "CBC-RG-77",
    supplier: "Lab Tech Supplier",
    expiryDate: "2026-06-10",
    purchasePrice: 900,
    salePrice: 1200,
    stock: 7,
    reorderLevel: 5,
    location: "Lab Cold Storage",
    status: "Expired",
    notes: "Expired batch. Do not use.",
    movements: [],
  },
];

const emptyForm = {
  sku: "",
  name: "",
  category: "Medicine" as InventoryCategory,
  unit: "Piece",
  batchNo: "",
  supplier: "",
  expiryDate: "",
  purchasePrice: "0",
  salePrice: "0",
  stock: "0",
  reorderLevel: "5",
  location: "",
  notes: "",
};

const emptyMovementForm = {
  date: "",
  type: "Stock In" as MovementType,
  quantity: "1",
  note: "",
  by: "Admin",
};

const statusClass: Record<InventoryStatus, string> = {
  "In Stock": "border-emerald-200 bg-emerald-50 text-emerald-700",
  "Low Stock": "border-amber-200 bg-amber-50 text-amber-700",
  "Out of Stock": "border-rose-200 bg-rose-50 text-rose-700",
  Expired: "border-orange-200 bg-orange-50 text-orange-700",
  Inactive: "border-slate-200 bg-slate-50 text-slate-500",
};

const categoryClass: Record<InventoryCategory, string> = {
  Medicine: "border-teal-200 bg-teal-50 text-teal-800",
  Consumable: "border-cyan-200 bg-cyan-50 text-cyan-700",
  Equipment: "border-blue-200 bg-blue-50 text-blue-700",
  Reagent: "border-violet-200 bg-violet-50 text-violet-700",
  Stationery: "border-slate-200 bg-slate-50 text-slate-600",
  Other: "border-amber-200 bg-amber-50 text-amber-700",
};

const movementClass: Record<MovementType, string> = {
  "Stock In": "border-emerald-200 bg-emerald-50 text-emerald-700",
  "Stock Out": "border-blue-200 bg-blue-50 text-blue-700",
  Damage: "border-rose-200 bg-rose-50 text-rose-700",
  Return: "border-violet-200 bg-violet-50 text-violet-700",
};

const money = (value: number) => `৳ ${Number(value || 0).toLocaleString()}`;

const isExpired = (date: string) => {
  if (!date) return false;
  const expiry = new Date(`${date}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return !Number.isNaN(expiry.getTime()) && expiry < today;
};

const getStockStatus = (
  stock: number,
  reorderLevel: number,
  expiryDate: string,
  previousStatus?: InventoryStatus,
): InventoryStatus => {
  if (previousStatus === "Inactive") return "Inactive";
  if (isExpired(expiryDate)) return "Expired";
  if (stock <= 0) return "Out of Stock";
  if (stock <= reorderLevel) return "Low Stock";
  return "In Stock";
};

const localFilter = (
  items: InventoryItem[],
  filters: {
    query: string;
    category: string;
    status: string;
    supplier: string;
    location: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.sku} ${item.name} ${item.category} ${item.batchNo} ${item.supplier} ${item.location} ${item.status} ${item.notes}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.category || item.category === filters.category) &&
      (!filters.status || item.status === filters.status) &&
      (!filters.supplier || item.supplier === filters.supplier) &&
      (!filters.location || item.location === filters.location)
    );
  });
};

const loadItems = async (
  filters = {
    query: "",
    category: "",
    status: "",
    supplier: "",
    location: "",
  },
  fallback = mockItems,
): Promise<InventoryItem[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.category) params.set("category", filters.category);
    if (filters.status) params.set("status", filters.status);
    if (filters.supplier) params.set("supplier", filters.supplier);
    if (filters.location) params.set("location", filters.location);

    const url = params.toString()
      ? `/api/clinic/inventory?${params.toString()}`
      : "/api/clinic/inventory";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { items?: InventoryItem[] };

    return Array.isArray(data.items)
      ? data.items
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createItemApi = async (
  payload: Omit<InventoryItem, "id" | "movements">,
): Promise<InventoryItem> => {
  const response = await fetch("/api/clinic/inventory", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create inventory item failed");

  const data = (await response.json()) as { item?: InventoryItem };
  if (!data.item) throw new Error("Invalid inventory response");

  return data.item;
};

const updateStatusApi = async (
  id: string,
  status: InventoryStatus,
): Promise<InventoryItem> => {
  const response = await fetch(`/api/clinic/inventory/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update inventory status failed");

  const data = (await response.json()) as { item?: InventoryItem };
  if (!data.item) throw new Error("Invalid status response");

  return data.item;
};

const adjustStockApi = async (
  id: string,
  payload: Omit<StockMovement, "id">,
): Promise<InventoryItem> => {
  const response = await fetch(`/api/clinic/inventory/${id}/stock`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Stock adjustment failed");

  const data = (await response.json()) as { item?: InventoryItem };
  if (!data.item) throw new Error("Invalid stock response");

  return data.item;
};

const deleteItemApi = async (id: string) => {
  const response = await fetch(`/api/clinic/inventory/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete inventory item failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string;
  hint: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{hint}</p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const inputClass =
  "border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none";

const ClinicInventoryPage = () => {
  const [items, setItems] = useState<InventoryItem[]>(mockItems);
  const [visibleItems, setVisibleItems] = useState<InventoryItem[]>(mockItems);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [movementItem, setMovementItem] = useState<InventoryItem | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [movementForm, setMovementForm] = useState(emptyMovementForm);
  const [addOpen, setAddOpen] = useState(false);
  const [movementOpen, setMovementOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [supplierFilter, setSupplierFilter] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      category: categoryFilter,
      status: statusFilter,
      supplier: supplierFilter,
      location: locationFilter,
    }),
    [query, categoryFilter, statusFilter, supplierFilter, locationFilter],
  );

  const supplierOptions = useMemo(
    () => Array.from(new Set(items.map((item) => item.supplier))).filter(Boolean),
    [items],
  );

  const locationOptions = useMemo(
    () => Array.from(new Set(items.map((item) => item.location))).filter(Boolean),
    [items],
  );

  const purchasePrice = Number(form.purchasePrice);
  const salePrice = Number(form.salePrice);
  const stock = Number(form.stock);
  const reorderLevel = Number(form.reorderLevel);
  const formStatus = getStockStatus(stock, reorderLevel, form.expiryDate);

  const formReady =
    form.sku.trim().length >= 2 &&
    form.name.trim().length >= 2 &&
    form.unit.trim().length >= 1 &&
    form.batchNo.trim().length >= 2 &&
    form.supplier.trim().length >= 2 &&
    form.expiryDate.trim().length >= 4 &&
    form.location.trim().length >= 2 &&
    Number.isFinite(purchasePrice) &&
    purchasePrice >= 0 &&
    Number.isFinite(salePrice) &&
    salePrice >= 0 &&
    Number.isFinite(stock) &&
    stock >= 0 &&
    Number.isFinite(reorderLevel) &&
    reorderLevel >= 0;

  const movementQuantity = Number(movementForm.quantity);

  const movementReady =
    movementItem &&
    movementForm.date.trim().length >= 4 &&
    Number.isFinite(movementQuantity) &&
    movementQuantity > 0 &&
    movementForm.by.trim().length >= 2 &&
    movementForm.note.trim().length >= 2;

  useEffect(() => {
    let active = true;

    loadItems().then((data) => {
      if (!active) return;
      setItems(data);
      setVisibleItems(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadItems(filters, items).then((data) => {
        if (!active) return;
        setVisibleItems(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, items]);

  const stats = useMemo(() => {
    const totalValue = items.reduce(
      (total, item) => total + Number(item.stock || 0) * Number(item.purchasePrice || 0),
      0,
    );

    const lowStock = items.filter((item) => item.status === "Low Stock").length;
    const expired = items.filter((item) => item.status === "Expired").length;
    const medicine = items.filter((item) => item.category === "Medicine").length;

    return [
      {
        label: "Items",
        value: String(items.length),
        hint: `${medicine} medicine items`,
        icon: Boxes,
      },
      {
        label: "Stock Value",
        value: money(totalValue),
        hint: "Purchase value",
        icon: Pill,
      },
      {
        label: "Low Stock",
        value: String(lowStock),
        hint: "Need reorder",
        icon: AlertTriangle,
      },
      {
        label: "Expired",
        value: String(expired),
        hint: "Do not use",
        icon: CalendarClock,
      },
    ];
  }, [items]);

  const syncItems = (nextItems: InventoryItem[]) => {
    setItems(nextItems);
    setVisibleItems(localFilter(nextItems, filters));

    if (selectedItem) {
      setSelectedItem(nextItems.find((item) => item.id === selectedItem.id) || null);
    }

    if (movementItem) {
      setMovementItem(nextItems.find((item) => item.id === movementItem.id) || null);
    }
  };

  const resetFilters = () => {
    setQuery("");
    setCategoryFilter("");
    setStatusFilter("");
    setSupplierFilter("");
    setLocationFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    setForm(emptyForm);
  };

  const closeMovementModal = () => {
    setMovementOpen(false);
    setMovementItem(null);
    setMovementForm(emptyMovementForm);
  };

  const openMovementModal = (item: InventoryItem) => {
    setMovementItem(item);
    setMovementForm(emptyMovementForm);
    setMovementOpen(true);
    setMessage("");
  };

  const handleCreateItem = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Inventory item form complete korle Add Item button enable hobe.");
      return;
    }

    const payload: Omit<InventoryItem, "id" | "movements"> = {
      sku: form.sku.trim(),
      name: form.name.trim(),
      category: form.category,
      unit: form.unit.trim(),
      batchNo: form.batchNo.trim(),
      supplier: form.supplier.trim(),
      expiryDate: form.expiryDate.trim(),
      purchasePrice,
      salePrice,
      stock,
      reorderLevel,
      location: form.location.trim(),
      status: formStatus,
      notes: form.notes.trim() || "No inventory note",
    };

    const fallbackItem: InventoryItem = {
      id: `INV-STK-ID-${Date.now()}`,
      ...payload,
      movements: [
        {
          id: `MOV-${Date.now()}`,
          date: new Date().toISOString().slice(0, 10),
          type: "Stock In",
          quantity: stock,
          note: "Opening stock",
          by: "Admin",
        },
      ],
    };

    setSaving(true);
    setMessage("");

    try {
      const createdItem = await createItemApi(payload);
      syncItems([createdItem, ...items]);
      setMessage("Inventory item added successfully.");
    } catch {
      syncItems([fallbackItem, ...items]);
      setMessage("Inventory item added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    item: InventoryItem,
    status: InventoryStatus,
  ) => {
    const previousItems = items;

    const nextItems = items.map((entry) =>
      entry.id === item.id ? { ...entry, status } : entry,
    );

    syncItems(nextItems);
    setMessage("");

    try {
      const updatedItem = await updateStatusApi(item.id, status);

      syncItems(
        nextItems.map((entry) =>
          entry.id === updatedItem.id ? updatedItem : entry,
        ),
      );
    } catch {
      syncItems(previousItems);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleAdjustStock = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!movementItem || !movementReady || saving) {
      setMessage("Stock movement form complete korle Apply Stock button enable hobe.");
      return;
    }

    const movementPayload: Omit<StockMovement, "id"> = {
      date: movementForm.date.trim(),
      type: movementForm.type,
      quantity: movementQuantity,
      note: movementForm.note.trim(),
      by: movementForm.by.trim(),
    };

    const signedQuantity =
      movementForm.type === "Stock In" || movementForm.type === "Return"
        ? movementQuantity
        : -movementQuantity;

    const previousItems = items;

    const localMovement: StockMovement = {
      id: `MOV-${Date.now()}`,
      ...movementPayload,
    };

    const nextItems = items.map((item) => {
      if (item.id !== movementItem.id) return item;

      const nextStock = Math.max(0, item.stock + signedQuantity);

      return {
        ...item,
        stock: nextStock,
        status: getStockStatus(nextStock, item.reorderLevel, item.expiryDate, item.status),
        movements: [localMovement, ...item.movements],
      };
    });

    setSaving(true);
    syncItems(nextItems);
    setMessage("");

    try {
      const updatedItem = await adjustStockApi(movementItem.id, movementPayload);

      syncItems(
        nextItems.map((item) =>
          item.id === updatedItem.id ? updatedItem : item,
        ),
      );

      setMessage("Stock movement applied successfully.");
    } catch {
      syncItems(previousItems);
      setMessage("Backend stock update failed. Previous stock restored.");
    } finally {
      setSaving(false);
      closeMovementModal();
    }
  };

  const handleRemoveItem = async (item: InventoryItem) => {
    const previousItems = items;
    const nextItems = items.filter((entry) => entry.id !== item.id);

    syncItems(nextItems);
    setMessage("");

    try {
      await deleteItemApi(item.id);
      setMessage("Inventory item removed successfully.");
    } catch {
      syncItems(previousItems);
      setMessage("Backend delete failed, inventory item restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Inventory
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Stock, medicine, supplies and future pharmacy inventory shell.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading inventory from backend API..."
                    : searching
                      ? "Searching inventory database..."
                      : "Ready: stock/medicine/supplies/pharmacy workflow functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <PackagePlus size={15} />
                Add Item
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_160px_160px_190px_190px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search stock, medicine, supplier, batch, location"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={categoryFilter}
              onChange={(event) => setCategoryFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Category</option>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={supplierFilter}
              onChange={(event) => setSupplierFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Supplier</option>
              {supplierOptions.map((supplier) => (
                <option key={supplier} value={supplier}>
                  {supplier}
                </option>
              ))}
            </select>

            <select
              value={locationFilter}
              onChange={(event) => setLocationFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Location</option>
              {locationOptions.map((location) => (
                <option key={location} value={location}>
                  {location}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1320px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Item / SKU
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Category / Batch
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Stock
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Price
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Supplier / Location
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleItems.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.name}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.sku} · {item.unit}
                      </p>
                      <p className="mt-1 max-w-[220px] truncate text-[11px] font-bold text-slate-500">
                        {item.notes}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <Badge label={item.category} className={categoryClass[item.category]} />
                      <p className="mt-1 text-xs font-black text-slate-700">
                        Batch: {item.batchNo}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <CalendarClock size={12} />
                        Exp: {item.expiryDate}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-lg font-black text-slate-950">
                        {item.stock}
                      </p>
                      <p className="text-[11px] font-bold text-slate-500">
                        Reorder at {item.reorderLevel}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        Buy: {money(item.purchasePrice)}
                      </p>
                      <p className="mt-1 text-xs font-black text-emerald-700">
                        Sell: {money(item.salePrice)}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Value: {money(item.stock * item.purchasePrice)}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Truck size={14} />
                        {item.supplier}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.location}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as InventoryStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {statuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge label={item.status} className={statusClass[item.status]} />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedItem(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => openMovementModal(item)}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100"
                        >
                          <Boxes size={13} />
                          Stock
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Inactive")}
                          disabled={item.status === "Inactive"}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <CheckCircle2 size={13} />
                          Inactive
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleItems.length && (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No inventory item found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <Boxes size={14} />
            Medicine, supplies, stock movement and future pharmacy inventory ready.
          </div>
        </div>
      </section>

      {selectedItem && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Inventory Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedItem.name}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedItem.sku} · {selectedItem.category} · {selectedItem.status}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["SKU", selectedItem.sku],
                ["Unit", selectedItem.unit],
                ["Batch No", selectedItem.batchNo],
                ["Supplier", selectedItem.supplier],
                ["Expiry Date", selectedItem.expiryDate],
                ["Location", selectedItem.location],
                ["Stock", String(selectedItem.stock)],
                ["Reorder Level", String(selectedItem.reorderLevel)],
                ["Purchase Price", money(selectedItem.purchasePrice)],
                ["Sale Price", money(selectedItem.salePrice)],
                ["Stock Value", money(selectedItem.stock * selectedItem.purchasePrice)],
                ["Status", selectedItem.status],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="border border-slate-100 bg-slate-50 p-3"
                >
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Notes
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedItem.notes}
                </p>
              </div>
            </div>

            <div className="mt-4 border border-teal-100">
              <div className="border-b border-teal-100 bg-slate-50 px-3 py-2">
                <p className="text-[10px] font-black uppercase tracking-[0.16em] text-slate-500">
                  Stock Movement History
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse bg-white text-left">
                  <thead className="bg-slate-50">
                    <tr className="border-b border-slate-100">
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Date
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Type
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Qty
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        By
                      </th>
                      <th className="px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">
                        Note
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {selectedItem.movements.map((movement) => (
                      <tr key={movement.id} className="border-b border-slate-100">
                        <td className="px-3 py-2 text-xs font-bold text-slate-600">
                          {movement.date}
                        </td>
                        <td className="px-3 py-2">
                          <Badge
                            label={movement.type}
                            className={movementClass[movement.type]}
                          />
                        </td>
                        <td className="px-3 py-2 text-xs font-black text-slate-800">
                          {movement.quantity}
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-slate-600">
                          {movement.by}
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-slate-500">
                          {movement.note}
                        </td>
                      </tr>
                    ))}

                    {!selectedItem.movements.length && (
                      <tr>
                        <td
                          colSpan={5}
                          className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                        >
                          No stock movement found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="max-h-[92svh] w-full max-w-4xl overflow-y-auto border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Inventory Item
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New medicine or supply
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Stock, batch, supplier, expiry and pharmacy inventory info add koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateItem} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="SKU">
                  <input
                    value={form.sku}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, sku: event.target.value }))
                    }
                    placeholder="MED-1001"
                    className={inputClass}
                  />
                </Field>

                <Field label="Item Name">
                  <input
                    value={form.name}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, name: event.target.value }))
                    }
                    placeholder="Napa 500mg"
                    className={inputClass}
                  />
                </Field>

                <Field label="Category">
                  <select
                    value={form.category}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        category: event.target.value as InventoryCategory,
                      }))
                    }
                    className={inputClass}
                  >
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Unit">
                  <input
                    value={form.unit}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, unit: event.target.value }))
                    }
                    placeholder="Piece / Strip / Bottle"
                    className={inputClass}
                  />
                </Field>

                <Field label="Batch No">
                  <input
                    value={form.batchNo}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, batchNo: event.target.value }))
                    }
                    placeholder="Batch number"
                    className={inputClass}
                  />
                </Field>

                <Field label="Supplier">
                  <input
                    value={form.supplier}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, supplier: event.target.value }))
                    }
                    placeholder="Supplier name"
                    className={inputClass}
                  />
                </Field>

                <Field label="Expiry Date">
                  <input
                    value={form.expiryDate}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, expiryDate: event.target.value }))
                    }
                    type="date"
                    className={inputClass}
                  />
                </Field>

                <Field label="Location">
                  <input
                    value={form.location}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, location: event.target.value }))
                    }
                    placeholder="Pharmacy Rack A1"
                    className={inputClass}
                  />
                </Field>

                <Field label="Purchase Price">
                  <input
                    value={form.purchasePrice}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        purchasePrice: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className={inputClass}
                  />
                </Field>

                <Field label="Sale Price">
                  <input
                    value={form.salePrice}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, salePrice: event.target.value }))
                    }
                    type="number"
                    min={0}
                    className={inputClass}
                  />
                </Field>

                <Field label="Opening Stock">
                  <input
                    value={form.stock}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, stock: event.target.value }))
                    }
                    type="number"
                    min={0}
                    className={inputClass}
                  />
                </Field>

                <Field label="Reorder Level">
                  <input
                    value={form.reorderLevel}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        reorderLevel: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className={inputClass}
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="Notes">
                    <textarea
                      value={form.notes}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, notes: event.target.value }))
                      }
                      rows={3}
                      placeholder="Inventory note"
                      className={`${inputClass} resize-none`}
                    />
                  </Field>
                </div>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Live Stock Summary
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    Status {formStatus} · Stock Value {money(stock * purchasePrice)}
                  </p>
                </div>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Inventory form complete. Add Item button enabled."
                  : "SKU + item + batch + supplier + expiry + stock complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <PackagePlus size={15} />
                  {saving ? "Adding..." : "Add Item"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {movementOpen && movementItem && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Stock Movement
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {movementItem.name}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Current stock: {movementItem.stock} {movementItem.unit}
                </p>
              </div>

              <button
                type="button"
                onClick={closeMovementModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAdjustStock} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Date">
                  <input
                    value={movementForm.date}
                    onChange={(event) =>
                      setMovementForm((prev) => ({
                        ...prev,
                        date: event.target.value,
                      }))
                    }
                    type="date"
                    className={inputClass}
                  />
                </Field>

                <Field label="Movement Type">
                  <select
                    value={movementForm.type}
                    onChange={(event) =>
                      setMovementForm((prev) => ({
                        ...prev,
                        type: event.target.value as MovementType,
                      }))
                    }
                    className={inputClass}
                  >
                    {movementTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Quantity">
                  <input
                    value={movementForm.quantity}
                    onChange={(event) =>
                      setMovementForm((prev) => ({
                        ...prev,
                        quantity: event.target.value,
                      }))
                    }
                    type="number"
                    min={1}
                    className={inputClass}
                  />
                </Field>

                <Field label="Handled By">
                  <input
                    value={movementForm.by}
                    onChange={(event) =>
                      setMovementForm((prev) => ({
                        ...prev,
                        by: event.target.value,
                      }))
                    }
                    placeholder="Admin / Pharmacy Desk"
                    className={inputClass}
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="Note">
                    <input
                      value={movementForm.note}
                      onChange={(event) =>
                        setMovementForm((prev) => ({
                          ...prev,
                          note: event.target.value,
                        }))
                      }
                      placeholder="Stock received / used / damaged"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Movement Preview
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {movementForm.type} · {movementQuantity || 0} {movementItem.unit}
                  </p>
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeMovementModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!movementReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    movementReady
                      ? "border-emerald-700 bg-emerald-700 text-white hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <Boxes size={15} />
                  {saving ? "Applying..." : "Apply Stock"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicInventoryPage;