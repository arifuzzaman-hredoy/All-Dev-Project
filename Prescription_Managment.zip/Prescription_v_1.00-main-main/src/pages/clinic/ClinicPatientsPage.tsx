import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  CalendarClock,
  CheckCircle2,
  Eye,
  Filter,
  HeartPulse,
  Mail,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
  Stethoscope,
  Trash2,
  UserPlus,
  UserRound,
  Users,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type PatientStatus = "Active" | "Follow-up" | "Critical" | "Inactive";
type Gender = "Male" | "Female" | "Other";
type BloodGroup =
  | "A+"
  | "A-"
  | "B+"
  | "B-"
  | "AB+"
  | "AB-"
  | "O+"
  | "O-"
  | "Unknown";

type ClinicPatient = {
  id: string;
  patientId: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  gender: Gender;
  bloodGroup: BloodGroup;
  address: string;
  assignedDoctor: string;
  diagnosis: string;
  lastVisit: string;
  nextFollowUp: string;
  totalVisits: number;
  status: PatientStatus;
};

const statusOptions: PatientStatus[] = [
  "Active",
  "Follow-up",
  "Critical",
  "Inactive",
];

const genderOptions: Gender[] = ["Male", "Female", "Other"];

const bloodGroupOptions: BloodGroup[] = [
  "Unknown",
  "A+",
  "A-",
  "B+",
  "B-",
  "AB+",
  "AB-",
  "O+",
  "O-",
];

const mockPatients: ClinicPatient[] = [
  {
    id: "PT-1001",
    patientId: "P-1001",
    name: "Nusrat Jahan",
    phone: "+8801711000001",
    email: "nusrat.patient@demo.com",
    age: 32,
    gender: "Female",
    bloodGroup: "B+",
    address: "Rangpur Sadar, Rangpur",
    assignedDoctor: "Dr. Abdullah Rahman",
    diagnosis: "Migraine follow-up",
    lastVisit: "2026-06-20",
    nextFollowUp: "2026-07-05",
    totalVisits: 4,
    status: "Follow-up",
  },
  {
    id: "PT-1002",
    patientId: "P-1002",
    name: "Rafiqul Islam",
    phone: "+8801711000002",
    email: "rafiqul.patient@demo.com",
    age: 45,
    gender: "Male",
    bloodGroup: "O+",
    address: "Kotchandpur, Jhenaidah",
    assignedDoctor: "Dr. Mehedi Hasan",
    diagnosis: "Hypertension",
    lastVisit: "2026-06-18",
    nextFollowUp: "2026-07-18",
    totalVisits: 7,
    status: "Active",
  },
  {
    id: "PT-1003",
    patientId: "P-1003",
    name: "Prime Diagnostic Case",
    phone: "+8801711000003",
    email: "report@prime.demo",
    age: 28,
    gender: "Male",
    bloodGroup: "A+",
    address: "Dhaka Medical Road",
    assignedDoctor: "Dr. Nusrat Jahan",
    diagnosis: "Report review",
    lastVisit: "2026-06-17",
    nextFollowUp: "2026-06-24",
    totalVisits: 2,
    status: "Critical",
  },
];

const emptyForm = {
  name: "",
  phone: "",
  email: "",
  age: "",
  gender: "Male" as Gender,
  bloodGroup: "Unknown" as BloodGroup,
  address: "",
  assignedDoctor: "",
  diagnosis: "",
  lastVisit: "",
  nextFollowUp: "",
  totalVisits: "1",
  status: "Active" as PatientStatus,
};

const statusClass: Record<PatientStatus, string> = {
  Active: "border-emerald-200 bg-emerald-50 text-emerald-700",
  "Follow-up": "border-cyan-200 bg-cyan-50 text-cyan-700",
  Critical: "border-rose-200 bg-rose-50 text-rose-700",
  Inactive: "border-slate-200 bg-slate-50 text-slate-500",
};

const isValidEmail = (email: string) => {
  if (!email.trim()) return true;
  return /\S+@\S+\.\S+/.test(email);
};

const localFilter = (
  items: ClinicPatient[],
  filters: {
    query: string;
    status: string;
    gender: string;
    bloodGroup: string;
    doctor: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.patientId} ${item.name} ${item.phone} ${item.email} ${item.gender} ${item.bloodGroup} ${item.address} ${item.assignedDoctor} ${item.diagnosis} ${item.status}`
        .toLowerCase()
        .includes(searchText);

    const matchedStatus = !filters.status || item.status === filters.status;
    const matchedGender = !filters.gender || item.gender === filters.gender;
    const matchedBlood =
      !filters.bloodGroup || item.bloodGroup === filters.bloodGroup;
    const matchedDoctor =
      !filters.doctor || item.assignedDoctor === filters.doctor;

    return (
      matchedSearch &&
      matchedStatus &&
      matchedGender &&
      matchedBlood &&
      matchedDoctor
    );
  });
};

const loadPatients = async (
  filters = {
    query: "",
    status: "",
    gender: "",
    bloodGroup: "",
    doctor: "",
  },
  fallback = mockPatients,
): Promise<ClinicPatient[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.status) params.set("status", filters.status);
    if (filters.gender) params.set("gender", filters.gender);
    if (filters.bloodGroup) params.set("bloodGroup", filters.bloodGroup);
    if (filters.doctor) params.set("doctor", filters.doctor);

    const queryString = params.toString();
    const url = queryString
      ? `/api/clinic/patients?${queryString}`
      : "/api/clinic/patients";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { patients?: ClinicPatient[] };

    return Array.isArray(data.patients)
      ? data.patients
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createPatientApi = async (
  payload: Omit<ClinicPatient, "id" | "patientId">,
): Promise<ClinicPatient> => {
  const response = await fetch("/api/clinic/patients", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create patient failed");

  const data = (await response.json()) as { patient?: ClinicPatient };
  if (!data.patient) throw new Error("Invalid patient response");

  return data.patient;
};

const updatePatientStatusApi = async (
  id: string,
  status: PatientStatus,
): Promise<ClinicPatient> => {
  const response = await fetch(`/api/clinic/patients/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update patient status failed");

  const data = (await response.json()) as { patient?: ClinicPatient };
  if (!data.patient) throw new Error("Invalid status response");

  return data.patient;
};

const deletePatientApi = async (id: string) => {
  const response = await fetch(`/api/clinic/patients/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete patient failed");
};

const Badge = ({
  label,
  className,
}: {
  label: string;
  className: string;
}) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicPatientsPage = () => {
  const [patients, setPatients] = useState<ClinicPatient[]>(mockPatients);
  const [visiblePatients, setVisiblePatients] =
    useState<ClinicPatient[]>(mockPatients);
  const [selectedPatient, setSelectedPatient] =
    useState<ClinicPatient | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [bloodFilter, setBloodFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      status: statusFilter,
      gender: genderFilter,
      bloodGroup: bloodFilter,
      doctor: doctorFilter,
    }),
    [query, statusFilter, genderFilter, bloodFilter, doctorFilter],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(patients.map((item) => item.assignedDoctor))),
    [patients],
  );

  const formReady =
    form.name.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    isValidEmail(form.email) &&
    Number(form.age) > 0 &&
    form.address.trim().length >= 2 &&
    form.assignedDoctor.trim().length >= 2 &&
    form.diagnosis.trim().length >= 2 &&
    Number(form.totalVisits) >= 0 &&
    statusOptions.includes(form.status);

  useEffect(() => {
    let active = true;

    loadPatients().then((data) => {
      if (!active) return;
      setPatients(data);
      setVisiblePatients(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadPatients(filters, patients).then((data) => {
        if (!active) return;
        setVisiblePatients(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, patients]);

  const stats = useMemo(
    () => [
      {
        label: "Total Patients",
        value: String(patients.length),
        icon: Users,
      },
      {
        label: "Active",
        value: String(
          patients.filter((item) => item.status === "Active").length,
        ),
        icon: CheckCircle2,
      },
      {
        label: "Follow-up",
        value: String(
          patients.filter((item) => item.status === "Follow-up").length,
        ),
        icon: CalendarClock,
      },
      {
        label: "Critical",
        value: String(
          patients.filter((item) => item.status === "Critical").length,
        ),
        icon: HeartPulse,
      },
    ],
    [patients],
  );

  const syncPatients = (nextPatients: ClinicPatient[]) => {
    setPatients(nextPatients);
    setVisiblePatients(localFilter(nextPatients, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("");
    setGenderFilter("");
    setBloodFilter("");
    setDoctorFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Patient full form complete korle Add Patient button enable hobe.");
      return;
    }

    const name = form.name.trim();
    const phone = form.phone.trim();
    const email = form.email.trim().toLowerCase();

    const duplicatePhone = patients.some((item) => item.phone === phone);

    if (duplicatePhone) {
      setMessage("This patient phone already exists.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      name,
      phone,
      email,
      age: Number(form.age),
      gender: form.gender,
      bloodGroup: form.bloodGroup,
      address: form.address.trim(),
      assignedDoctor: form.assignedDoctor.trim(),
      diagnosis: form.diagnosis.trim(),
      lastVisit: form.lastVisit.trim() || "Not visited yet",
      nextFollowUp: form.nextFollowUp.trim() || "Not scheduled",
      totalVisits: Number(form.totalVisits),
      status: form.status,
    };

    const fallbackPatient: ClinicPatient = {
      id: `PT-${Date.now()}`,
      patientId: `P-${String(patients.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdPatient = await createPatientApi(payload);
      syncPatients([createdPatient, ...patients]);
      setMessage("Patient added successfully.");
    } catch {
      syncPatients([fallbackPatient, ...patients]);
      setMessage("Patient added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    patient: ClinicPatient,
    status: PatientStatus,
  ) => {
    const previousPatients = patients;

    const nextPatients = patients.map((item) =>
      item.id === patient.id ? { ...item, status } : item,
    );

    syncPatients(nextPatients);
    setMessage("");

    try {
      const updatedPatient = await updatePatientStatusApi(patient.id, status);

      syncPatients(
        nextPatients.map((item) =>
          item.id === updatedPatient.id ? updatedPatient : item,
        ),
      );
    } catch {
      syncPatients(previousPatients);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemovePatient = async (patient: ClinicPatient) => {
    const previousPatients = patients;
    const nextPatients = patients.filter((item) => item.id !== patient.id);

    syncPatients(nextPatients);
    setMessage("");

    try {
      await deletePatientApi(patient.id);
      setMessage("Patient removed successfully.");
    } catch {
      syncPatients(previousPatients);
      setMessage("Backend delete failed, patient restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Patients
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Patient registry, recent visits, contact details, follow-up
                tracking and quick actions.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading patients from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/filter/details/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Patient
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_150px_150px_150px_180px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search patient, phone, doctor, diagnosis, address"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {statusOptions.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={genderFilter}
              onChange={(event) => setGenderFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Gender</option>
              {genderOptions.map((gender) => (
                <option key={gender} value={gender}>
                  {gender}
                </option>
              ))}
            </select>

            <select
              value={bloodFilter}
              onChange={(event) => setBloodFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Blood</option>
              {bloodGroupOptions.map((blood) => (
                <option key={blood} value={blood}>
                  {blood}
                </option>
              ))}
            </select>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1280px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Patient Details
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor / Diagnosis
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Visits
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Follow-up
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visiblePatients.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-sm font-black text-slate-950">
                          {item.patientId} · {item.name}
                        </p>
                        <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                          {item.age} yrs · {item.gender} · Blood {item.bloodGroup}
                        </p>

                        <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                          <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                            <Phone size={12} />
                            {item.phone}
                          </p>
                          <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                            <Mail size={12} />
                            {item.email || "No email"}
                          </p>
                        </div>

                        <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                          <MapPin size={12} />
                          {item.address}
                        </p>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Stethoscope size={14} />
                        {item.assignedDoctor}
                      </p>
                      <p className="mt-1 max-w-[260px] text-[11px] font-bold leading-5 text-slate-500">
                        {item.diagnosis}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        Total: {item.totalVisits}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        Last: {item.lastVisit}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-xs font-black text-slate-700">
                        <CalendarClock size={13} />
                        {item.nextFollowUp}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as PatientStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {statusOptions.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1">
                        <Badge
                          label={item.status}
                          className={statusClass[item.status]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedPatient(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            handleStatusChange(item, "Follow-up")
                          }
                          className="inline-flex items-center gap-1 border border-cyan-100 bg-cyan-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-cyan-700 transition hover:border-cyan-200 hover:bg-cyan-100"
                        >
                          <ShieldCheck size={13} />
                          Follow
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemovePatient(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visiblePatients.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No patient found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <UserRound size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedPatient && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Patient Personal Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedPatient.name}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedPatient.patientId} · {selectedPatient.status}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedPatient(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Phone", selectedPatient.phone],
                ["Email", selectedPatient.email || "No email"],
                ["Age / Gender", `${selectedPatient.age} / ${selectedPatient.gender}`],
                ["Blood Group", selectedPatient.bloodGroup],
                ["Assigned Doctor", selectedPatient.assignedDoctor],
                ["Total Visits", String(selectedPatient.totalVisits)],
                ["Last Visit", selectedPatient.lastVisit],
                ["Next Follow-up", selectedPatient.nextFollowUp],
                ["Address", selectedPatient.address],
              ].map(([label, value]) => (
                <div key={label} className="border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              <div className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Diagnosis / Note
                </p>
                <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                  {selectedPatient.diagnosis}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Patient
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New patient registry
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient details, doctor and follow-up information fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient Name">
                  <input
                    value={form.name}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, name: event.target.value }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone Number">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, phone: event.target.value }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Email Optional">
                  <input
                    value={form.email}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, email: event.target.value }))
                    }
                    placeholder="patient@email.com"
                    type="email"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="grid grid-cols-3 gap-3">
                  <Field label="Age">
                    <input
                      value={form.age}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, age: event.target.value }))
                      }
                      placeholder="Age"
                      type="number"
                      min={1}
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>

                  <Field label="Gender">
                    <select
                      value={form.gender}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          gender: event.target.value as Gender,
                        }))
                      }
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                    >
                      {genderOptions.map((gender) => (
                        <option key={gender} value={gender}>
                          {gender}
                        </option>
                      ))}
                    </select>
                  </Field>

                  <Field label="Blood">
                    <select
                      value={form.bloodGroup}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          bloodGroup: event.target.value as BloodGroup,
                        }))
                      }
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                    >
                      {bloodGroupOptions.map((blood) => (
                        <option key={blood} value={blood}>
                          {blood}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>

                <Field label="Assigned Doctor">
                  <input
                    value={form.assignedDoctor}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        assignedDoctor: event.target.value,
                      }))
                    }
                    placeholder="Dr. Abdullah Rahman"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Address">
                  <input
                    value={form.address}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, address: event.target.value }))
                    }
                    placeholder="Patient address"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Last Visit">
                  <input
                    value={form.lastVisit}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        lastVisit: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Next Follow-up">
                  <input
                    value={form.nextFollowUp}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        nextFollowUp: event.target.value,
                      }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Total Visits">
                  <input
                    value={form.totalVisits}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        totalVisits: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as PatientStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {statusOptions.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Diagnosis / Note">
                  <input
                    value={form.diagnosis}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        diagnosis: event.target.value,
                      }))
                    }
                    placeholder="Diagnosis or patient note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Patient form complete. Add Patient button enabled."
                  : "Name + phone + age + address + doctor + diagnosis complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Patient"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicPatientsPage;