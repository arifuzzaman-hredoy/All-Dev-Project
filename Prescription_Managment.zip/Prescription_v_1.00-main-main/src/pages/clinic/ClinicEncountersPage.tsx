import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  Activity,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  Eye,
  FileText,
  Filter,
  HeartPulse,
  Phone,
  Search,
  Stethoscope,
  Trash2,
  UserPlus,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type EncounterType = "Consultation" | "Follow-up" | "Emergency" | "Report Review";
type EncounterStatus = "Open" | "In Progress" | "Completed" | "Follow-up" | "Cancelled";
type EncounterPriority = "Normal" | "Urgent" | "Critical";

type ClinicEncounter = {
  id: string;
  encounterNo: string;
  patientId: string;
  patientName: string;
  phone: string;
  doctorName: string;
  specialization: string;
  visitDate: string;
  visitTime: string;
  encounterType: EncounterType;
  chiefComplaint: string;
  diagnosis: string;
  vitals: string;
  prescriptionNote: string;
  labNote: string;
  followUpDate: string;
  status: EncounterStatus;
  priority: EncounterPriority;
};

const encounterTypes: EncounterType[] = [
  "Consultation",
  "Follow-up",
  "Emergency",
  "Report Review",
];

const encounterStatuses: EncounterStatus[] = [
  "Open",
  "In Progress",
  "Completed",
  "Follow-up",
  "Cancelled",
];

const priorities: EncounterPriority[] = ["Normal", "Urgent", "Critical"];

const mockEncounters: ClinicEncounter[] = [
  {
    id: "ENC-ID-1001",
    encounterNo: "ENC-1001",
    patientId: "P-1001",
    patientName: "Nusrat Jahan",
    phone: "+8801711000001",
    doctorName: "Dr. Abdullah Rahman",
    specialization: "Medicine",
    visitDate: "2026-06-20",
    visitTime: "09:30 AM",
    encounterType: "Follow-up",
    chiefComplaint: "Headache follow-up and sleep issue",
    diagnosis: "Migraine follow-up",
    vitals: "BP 120/80, Pulse 78, Temp 98.4°F",
    prescriptionNote: "Continue medicine, hydration, sleep routine",
    labNote: "No new lab advised",
    followUpDate: "2026-07-05",
    status: "Follow-up",
    priority: "Normal",
  },
  {
    id: "ENC-ID-1002",
    encounterNo: "ENC-1002",
    patientId: "P-1002",
    patientName: "Rafiqul Islam",
    phone: "+8801711000002",
    doctorName: "Dr. Mehedi Hasan",
    specialization: "Cardiology",
    visitDate: "2026-06-20",
    visitTime: "10:15 AM",
    encounterType: "Consultation",
    chiefComplaint: "Chest discomfort and high blood pressure",
    diagnosis: "Hypertension observation",
    vitals: "BP 150/95, Pulse 88, SpO2 98%",
    prescriptionNote: "BP monitoring, medicine adjustment",
    labNote: "ECG and lipid profile advised",
    followUpDate: "2026-06-27",
    status: "In Progress",
    priority: "Urgent",
  },
  {
    id: "ENC-ID-1003",
    encounterNo: "ENC-1003",
    patientId: "P-1003",
    patientName: "Prime Diagnostic Case",
    phone: "+8801711000003",
    doctorName: "Dr. Nusrat Jahan",
    specialization: "Gynecology",
    visitDate: "2026-06-19",
    visitTime: "11:45 AM",
    encounterType: "Report Review",
    chiefComplaint: "Report review and follow-up plan",
    diagnosis: "Report reviewed",
    vitals: "Stable",
    prescriptionNote: "Follow previous prescription",
    labNote: "Report attached by diagnostic desk",
    followUpDate: "2026-07-01",
    status: "Completed",
    priority: "Normal",
  },
];

const emptyForm = {
  patientId: "",
  patientName: "",
  phone: "",
  doctorName: "",
  specialization: "",
  visitDate: "",
  visitTime: "",
  encounterType: "Consultation" as EncounterType,
  chiefComplaint: "",
  diagnosis: "",
  vitals: "",
  prescriptionNote: "",
  labNote: "",
  followUpDate: "",
  status: "Open" as EncounterStatus,
  priority: "Normal" as EncounterPriority,
};

const statusClass: Record<EncounterStatus, string> = {
  Open: "border-blue-200 bg-blue-50 text-blue-700",
  "In Progress": "border-amber-200 bg-amber-50 text-amber-700",
  Completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
  "Follow-up": "border-cyan-200 bg-cyan-50 text-cyan-700",
  Cancelled: "border-rose-200 bg-rose-50 text-rose-700",
};

const typeClass: Record<EncounterType, string> = {
  Consultation: "border-teal-200 bg-teal-50 text-teal-800",
  "Follow-up": "border-cyan-200 bg-cyan-50 text-cyan-700",
  Emergency: "border-rose-200 bg-rose-50 text-rose-700",
  "Report Review": "border-violet-200 bg-violet-50 text-violet-700",
};

const priorityClass: Record<EncounterPriority, string> = {
  Normal: "border-slate-200 bg-slate-50 text-slate-600",
  Urgent: "border-amber-200 bg-amber-50 text-amber-700",
  Critical: "border-rose-200 bg-rose-50 text-rose-700",
};

const localFilter = (
  items: ClinicEncounter[],
  filters: {
    query: string;
    doctor: string;
    specialization: string;
    status: string;
    type: string;
    priority: string;
  },
) => {
  const searchText = filters.query.trim().toLowerCase();

  return items.filter((item) => {
    const matchedSearch =
      !searchText ||
      `${item.encounterNo} ${item.patientId} ${item.patientName} ${item.phone} ${item.doctorName} ${item.specialization} ${item.encounterType} ${item.status} ${item.priority} ${item.chiefComplaint} ${item.diagnosis}`
        .toLowerCase()
        .includes(searchText);

    return (
      matchedSearch &&
      (!filters.doctor || item.doctorName === filters.doctor) &&
      (!filters.specialization || item.specialization === filters.specialization) &&
      (!filters.status || item.status === filters.status) &&
      (!filters.type || item.encounterType === filters.type) &&
      (!filters.priority || item.priority === filters.priority)
    );
  });
};

const loadEncounters = async (
  filters = {
    query: "",
    doctor: "",
    specialization: "",
    status: "",
    type: "",
    priority: "",
  },
  fallback = mockEncounters,
): Promise<ClinicEncounter[]> => {
  try {
    const params = new URLSearchParams();

    if (filters.query.trim()) params.set("q", filters.query.trim());
    if (filters.doctor) params.set("doctor", filters.doctor);
    if (filters.specialization) params.set("specialization", filters.specialization);
    if (filters.status) params.set("status", filters.status);
    if (filters.type) params.set("type", filters.type);
    if (filters.priority) params.set("priority", filters.priority);

    const url = params.toString()
      ? `/api/clinic/encounters?${params.toString()}`
      : "/api/clinic/encounters";

    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localFilter(fallback, filters);

    const data = (await response.json()) as { encounters?: ClinicEncounter[] };
    return Array.isArray(data.encounters)
      ? data.encounters
      : localFilter(fallback, filters);
  } catch {
    return localFilter(fallback, filters);
  }
};

const createEncounterApi = async (
  payload: Omit<ClinicEncounter, "id" | "encounterNo">,
): Promise<ClinicEncounter> => {
  const response = await fetch("/api/clinic/encounters", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create encounter failed");

  const data = (await response.json()) as { encounter?: ClinicEncounter };
  if (!data.encounter) throw new Error("Invalid encounter response");

  return data.encounter;
};

const updateEncounterStatusApi = async (
  id: string,
  status: EncounterStatus,
): Promise<ClinicEncounter> => {
  const response = await fetch(`/api/clinic/encounters/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update encounter status failed");

  const data = (await response.json()) as { encounter?: ClinicEncounter };
  if (!data.encounter) throw new Error("Invalid status response");

  return data.encounter;
};

const deleteEncounterApi = async (id: string) => {
  const response = await fetch(`/api/clinic/encounters/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete encounter failed");
};

const Badge = ({ label, className }: { label: string; className: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      className,
    ].join(" ")}
  >
    {label}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>
      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicEncountersPage = () => {
  const [encounters, setEncounters] = useState<ClinicEncounter[]>(mockEncounters);
  const [visibleEncounters, setVisibleEncounters] =
    useState<ClinicEncounter[]>(mockEncounters);
  const [selectedEncounter, setSelectedEncounter] =
    useState<ClinicEncounter | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [addOpen, setAddOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [specializationFilter, setSpecializationFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const filters = useMemo(
    () => ({
      query,
      doctor: doctorFilter,
      specialization: specializationFilter,
      status: statusFilter,
      type: typeFilter,
      priority: priorityFilter,
    }),
    [query, doctorFilter, specializationFilter, statusFilter, typeFilter, priorityFilter],
  );

  const doctorOptions = useMemo(
    () => Array.from(new Set(encounters.map((item) => item.doctorName))),
    [encounters],
  );

  const specializationOptions = useMemo(
    () => Array.from(new Set(encounters.map((item) => item.specialization))),
    [encounters],
  );

  const formReady =
    form.patientId.trim().length >= 2 &&
    form.patientName.trim().length >= 2 &&
    form.phone.trim().length >= 5 &&
    form.doctorName.trim().length >= 2 &&
    form.specialization.trim().length >= 2 &&
    form.visitDate.trim().length >= 4 &&
    form.visitTime.trim().length >= 2 &&
    form.chiefComplaint.trim().length >= 2 &&
    form.diagnosis.trim().length >= 2 &&
    form.vitals.trim().length >= 2 &&
    form.prescriptionNote.trim().length >= 2;

  useEffect(() => {
    let active = true;

    loadEncounters().then((data) => {
      if (!active) return;
      setEncounters(data);
      setVisibleEncounters(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadEncounters(filters, encounters).then((data) => {
        if (!active) return;
        setVisibleEncounters(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [filters, encounters]);

  const stats = useMemo(
    () => [
      {
        label: "Total Encounters",
        value: String(encounters.length),
        icon: ClipboardList,
      },
      {
        label: "In Progress",
        value: String(encounters.filter((item) => item.status === "In Progress").length),
        icon: Activity,
      },
      {
        label: "Completed",
        value: String(encounters.filter((item) => item.status === "Completed").length),
        icon: CheckCircle2,
      },
      {
        label: "Follow-up",
        value: String(encounters.filter((item) => item.status === "Follow-up").length),
        icon: CalendarClock,
      },
    ],
    [encounters],
  );

  const syncEncounters = (nextEncounters: ClinicEncounter[]) => {
    setEncounters(nextEncounters);
    setVisibleEncounters(localFilter(nextEncounters, filters));
  };

  const resetFilters = () => {
    setQuery("");
    setDoctorFilter("");
    setSpecializationFilter("");
    setStatusFilter("");
    setTypeFilter("");
    setPriorityFilter("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeAddModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!formReady || saving) {
      setMessage("Encounter full form complete korle Add Encounter button enable hobe.");
      return;
    }

    setSaving(true);
    setMessage("");

    const payload = {
      patientId: form.patientId.trim(),
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      doctorName: form.doctorName.trim(),
      specialization: form.specialization.trim(),
      visitDate: form.visitDate.trim(),
      visitTime: form.visitTime.trim(),
      encounterType: form.encounterType,
      chiefComplaint: form.chiefComplaint.trim(),
      diagnosis: form.diagnosis.trim(),
      vitals: form.vitals.trim(),
      prescriptionNote: form.prescriptionNote.trim(),
      labNote: form.labNote.trim() || "No lab note",
      followUpDate: form.followUpDate.trim() || "Not scheduled",
      status: form.status,
      priority: form.priority,
    };

    const fallbackEncounter: ClinicEncounter = {
      id: `ENC-ID-${Date.now()}`,
      encounterNo: `ENC-${String(encounters.length + 1).padStart(4, "0")}`,
      ...payload,
    };

    try {
      const createdEncounter = await createEncounterApi(payload);
      syncEncounters([createdEncounter, ...encounters]);
      setMessage("Encounter added successfully.");
    } catch {
      syncEncounters([fallbackEncounter, ...encounters]);
      setMessage("Encounter added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
      closeAddModal();
    }
  };

  const handleStatusChange = async (
    encounter: ClinicEncounter,
    status: EncounterStatus,
  ) => {
    const previousEncounters = encounters;
    const nextEncounters = encounters.map((item) =>
      item.id === encounter.id ? { ...item, status } : item,
    );

    syncEncounters(nextEncounters);
    setMessage("");

    try {
      const updatedEncounter = await updateEncounterStatusApi(encounter.id, status);
      syncEncounters(
        nextEncounters.map((item) =>
          item.id === updatedEncounter.id ? updatedEncounter : item,
        ),
      );
    } catch {
      syncEncounters(previousEncounters);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemoveEncounter = async (encounter: ClinicEncounter) => {
    const previousEncounters = encounters;
    const nextEncounters = encounters.filter((item) => item.id !== encounter.id);

    syncEncounters(nextEncounters);
    setMessage("");

    try {
      await deleteEncounterApi(encounter.id);
      setMessage("Encounter removed successfully.");
    } catch {
      syncEncounters(previousEncounters);
      setMessage("Backend delete failed, encounter restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Encounters
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Clinical encounter records, notes, diagnosis, vitals and
                follow-up status.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading encounters from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/filter/details/status functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Encounter
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 grid gap-2 xl:grid-cols-[1fr_180px_180px_150px_160px_140px_auto]">
            <div className="flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
              <Search size={15} className="text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search encounter, patient, doctor, diagnosis, notes"
                className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
              />
            </div>

            <select
              value={doctorFilter}
              onChange={(event) => setDoctorFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Doctors</option>
              {doctorOptions.map((doctor) => (
                <option key={doctor} value={doctor}>
                  {doctor}
                </option>
              ))}
            </select>

            <select
              value={specializationFilter}
              onChange={(event) => setSpecializationFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Specialities</option>
              {specializationOptions.map((speciality) => (
                <option key={speciality} value={speciality}>
                  {speciality}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Status</option>
              {encounterStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Type</option>
              {encounterTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            <select
              value={priorityFilter}
              onChange={(event) => setPriorityFilter(event.target.value)}
              className="border border-teal-100 bg-white px-3 py-2 text-xs font-black text-slate-600 focus:border-teal-300 focus:outline-none"
            >
              <option value="">All Priority</option>
              {priorities.map((priority) => (
                <option key={priority} value={priority}>
                  {priority}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
            >
              <Filter size={14} />
              Reset
            </button>
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-[1360px] border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Patient / Encounter
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Visit
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Clinical Note
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleEncounters.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-4 py-3">
                      <p className="text-sm font-black text-slate-950">
                        {item.encounterNo} · {item.patientName}
                      </p>
                      <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                        {item.patientId}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                        <Phone size={12} />
                        {item.phone}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="inline-flex items-center gap-1 text-sm font-black text-slate-800">
                        <Stethoscope size={14} />
                        {item.doctorName}
                      </p>
                      <p className="mt-1 text-[11px] font-black text-teal-700">
                        {item.specialization}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="text-xs font-black text-slate-700">
                        {item.visitDate}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.visitTime}
                      </p>
                      <div className="mt-1">
                        <Badge
                          label={item.encounterType}
                          className={typeClass[item.encounterType]}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <p className="max-w-[340px] truncate text-xs font-black text-slate-700">
                        {item.chiefComplaint}
                      </p>
                      <p className="mt-1 max-w-[340px] truncate text-[11px] font-bold text-slate-500">
                        Diagnosis: {item.diagnosis}
                      </p>
                      <p className="mt-1 max-w-[340px] truncate text-[11px] font-bold text-slate-500">
                        Vitals: {item.vitals}
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={item.status}
                        onChange={(event) =>
                          handleStatusChange(
                            item,
                            event.target.value as EncounterStatus,
                          )
                        }
                        className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                      >
                        {encounterStatuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>

                      <div className="mt-1 grid gap-1">
                        <Badge label={item.status} className={statusClass[item.status]} />
                        <Badge label={item.priority} className={priorityClass[item.priority]} />
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedEncounter(item)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <Eye size={13} />
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item, "Completed")}
                          className="inline-flex items-center gap-1 border border-emerald-100 bg-emerald-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700 transition hover:border-emerald-200 hover:bg-emerald-100"
                        >
                          <CheckCircle2 size={13} />
                          Done
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveEncounter(item)}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleEncounters.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No encounter found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <FileText size={14} />
            Frontend realtime table + backend API fallback ready.
          </div>
        </div>
      </section>

      {selectedEncounter && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Clinical Encounter Details
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  {selectedEncounter.encounterNo}
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  {selectedEncounter.patientName} · {selectedEncounter.encounterType}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedEncounter(null)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                ["Patient", `${selectedEncounter.patientName} (${selectedEncounter.patientId})`],
                ["Phone", selectedEncounter.phone],
                ["Doctor", selectedEncounter.doctorName],
                ["Speciality", selectedEncounter.specialization],
                ["Visit", `${selectedEncounter.visitDate} · ${selectedEncounter.visitTime}`],
                ["Follow-up Date", selectedEncounter.followUpDate],
                ["Status", selectedEncounter.status],
                ["Priority", selectedEncounter.priority],
              ].map(([label, value]) => (
                <div key={label} className="border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-black text-slate-800">
                    {value}
                  </p>
                </div>
              ))}

              {[
                ["Chief Complaint", selectedEncounter.chiefComplaint],
                ["Diagnosis", selectedEncounter.diagnosis],
                ["Vitals", selectedEncounter.vitals],
                ["Prescription Note", selectedEncounter.prescriptionNote],
                ["Lab Note", selectedEncounter.labNote],
              ].map(([label, value]) => (
                <div key={label} className="border border-slate-100 bg-slate-50 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-bold leading-6 text-slate-700">
                    {value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-4xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Encounter
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New clinical encounter
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Patient, doctor, diagnosis, vitals and follow-up note fill koro.
                </p>
              </div>

              <button
                type="button"
                onClick={closeAddModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Patient ID">
                  <input
                    value={form.patientId}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientId: event.target.value }))
                    }
                    placeholder="P-1001"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Patient Name">
                  <input
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, patientName: event.target.value }))
                    }
                    placeholder="Patient name"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, phone: event.target.value }))
                    }
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Doctor Name">
                  <input
                    value={form.doctorName}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, doctorName: event.target.value }))
                    }
                    placeholder="Dr. Abdullah Rahman"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Specialization">
                  <input
                    value={form.specialization}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, specialization: event.target.value }))
                    }
                    placeholder="Medicine / Cardiology"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="Visit Date">
                    <input
                      value={form.visitDate}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, visitDate: event.target.value }))
                      }
                      type="date"
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>

                  <Field label="Visit Time">
                    <input
                      value={form.visitTime}
                      onChange={(event) =>
                        setForm((prev) => ({ ...prev, visitTime: event.target.value }))
                      }
                      placeholder="09:30 AM"
                      className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                    />
                  </Field>
                </div>

                <Field label="Encounter Type">
                  <select
                    value={form.encounterType}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        encounterType: event.target.value as EncounterType,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {encounterTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Priority">
                  <select
                    value={form.priority}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        priority: event.target.value as EncounterPriority,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {priorities.map((priority) => (
                      <option key={priority} value={priority}>
                        {priority}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as EncounterStatus,
                      }))
                    }
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {encounterStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Follow-up Date">
                  <input
                    value={form.followUpDate}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, followUpDate: event.target.value }))
                    }
                    type="date"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Chief Complaint">
                  <input
                    value={form.chiefComplaint}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        chiefComplaint: event.target.value,
                      }))
                    }
                    placeholder="Main patient problem"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Diagnosis">
                  <input
                    value={form.diagnosis}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, diagnosis: event.target.value }))
                    }
                    placeholder="Diagnosis"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Vitals">
                  <input
                    value={form.vitals}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, vitals: event.target.value }))
                    }
                    placeholder="BP 120/80, Pulse 78"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Prescription Note">
                  <input
                    value={form.prescriptionNote}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        prescriptionNote: event.target.value,
                      }))
                    }
                    placeholder="Medicine / instruction note"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Lab Note">
                  <input
                    value={form.labNote}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, labNote: event.target.value }))
                    }
                    placeholder="Lab test / report note optional"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>
              </div>

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Encounter form complete. Add Encounter button enabled."
                  : "Patient + doctor + visit + diagnosis + vitals + prescription note complete korte hobe."}
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Encounter"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicEncountersPage;