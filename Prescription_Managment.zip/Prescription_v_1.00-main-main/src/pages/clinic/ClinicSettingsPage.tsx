import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  BellRing,
  Building2,
  CheckCircle2,
  KeyRound,
  LayoutGrid,
  Palette,
  Plus,
  RefreshCw,
  Save,
  ShieldCheck,
  SlidersHorizontal,
  ToggleLeft,
  ToggleRight,
  Trash2,
  X,
  type LucideIcon,
} from "lucide-react";

type ModuleKey = string;
type RoleKey = string;

type ClinicProfile = {
  clinicName: string;
  tenantName: string;
  ownerName: string;
  phone: string;
  email: string;
  address: string;
  licenseNo: string;
  timezone: string;
  currency: string;
};

type BrandingSettings = {
  logoUrl: string;
  primaryColor: string;
  secondaryColor: string;
  footerText: string;
  invoicePrefix: string;
  prescriptionPrefix: string;
};

type NotificationSettings = {
  appointmentSms: boolean;
  prescriptionSms: boolean;
  billingSms: boolean;
  emailAlerts: boolean;
  adminPush: boolean;
  lowSmsBalanceAlert: boolean;
};

type ModuleSetting = {
  key: ModuleKey;
  label: string;
  description: string;
  enabled: boolean;
};

type RoleSetting = {
  key: RoleKey;
  description: string;
  enabled: boolean;
  users: number;
  permissions: string[];
};

type ClinicSettings = {
  profile: ClinicProfile;
  branding: BrandingSettings;
  notifications: NotificationSettings;
  modules: ModuleSetting[];
  roles: RoleSetting[];
};

const defaultSettings: ClinicSettings = {
  profile: {
    clinicName: "Update Clinic",
    tenantName: "Update Diagnostic Center",
    ownerName: "Clinic Owner",
    phone: "+8801711000000",
    email: "admin@updateclinic.test",
    address: "Rangpur, Bangladesh",
    licenseNo: "DGHS-CLINIC-1001",
    timezone: "Asia/Dhaka",
    currency: "BDT",
  },
  branding: {
    logoUrl: "/logo.png",
    primaryColor: "#0f766e",
    secondaryColor: "#ecfeff",
    footerText: "Powered by TechTeam",
    invoicePrefix: "INV",
    prescriptionPrefix: "RX",
  },
  notifications: {
    appointmentSms: true,
    prescriptionSms: true,
    billingSms: true,
    emailAlerts: false,
    adminPush: true,
    lowSmsBalanceAlert: true,
  },
  modules: [
    {
      key: "appointments",
      label: "Appointments",
      description: "Booking, queue and visit schedule.",
      enabled: true,
    },
    {
      key: "patients",
      label: "Patients",
      description: "Patient registry and medical profile.",
      enabled: true,
    },
    {
      key: "doctors",
      label: "Doctors",
      description: "Doctor profile and chamber settings.",
      enabled: true,
    },
    {
      key: "prescriptions",
      label: "Prescriptions",
      description: "RX records, uploads and review.",
      enabled: true,
    },
    {
      key: "billing",
      label: "Billing",
      description: "Invoices, due and collections.",
      enabled: true,
    },
    {
      key: "payments",
      label: "Payments",
      description: "Receipts, refunds and settlements.",
      enabled: true,
    },
    {
      key: "smsWallet",
      label: "SMS Wallet",
      description: "SMS balance, recharge and usage.",
      enabled: true,
    },
    {
      key: "reports",
      label: "Reports",
      description: "Visits, revenue and trend reports.",
      enabled: true,
    },
  ],
  roles: [
    {
      key: "Owner",
      description: "Full system access and subscription control.",
      enabled: true,
      users: 1,
      permissions: ["All Modules", "Billing", "Settings", "Users"],
    },
    {
      key: "Admin",
      description: "Clinic operation and admin panel control.",
      enabled: true,
      users: 2,
      permissions: ["Appointments", "Patients", "Doctors", "Reports"],
    },
    {
      key: "Doctor",
      description: "Patient visits, encounter and prescription access.",
      enabled: true,
      users: 4,
      permissions: ["Patients", "Encounters", "Prescriptions"],
    },
    {
      key: "Reception",
      description: "Front desk appointment and payment collection.",
      enabled: true,
      users: 3,
      permissions: ["Appointments", "Patients", "Billing"],
    },
    {
      key: "Accounts",
      description: "Billing, payments and ledger management.",
      enabled: true,
      users: 1,
      permissions: ["Billing", "Payments", "Ledger", "Reports"],
    },
  ],
};

const emptyRoleForm = {
  key: "",
  description: "",
  users: "0",
  permissions: "",
  enabled: true,
};

const emptyModuleForm = {
  key: "",
  label: "",
  description: "",
  enabled: true,
};

const inputClass =
  "border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none";

const loadSettings = async (): Promise<ClinicSettings> => {
  try {
    const response = await fetch("/api/clinic/settings", {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return defaultSettings;

    const data = (await response.json()) as { settings?: ClinicSettings };
    return data.settings || defaultSettings;
  } catch {
    return defaultSettings;
  }
};

const saveSettingsApi = async (
  settings: ClinicSettings,
): Promise<ClinicSettings> => {
  const response = await fetch("/api/clinic/settings", {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(settings),
  });

  if (!response.ok) throw new Error("Settings save failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid settings response");

  return data.settings;
};

const createRoleApi = async (payload: RoleSetting): Promise<ClinicSettings> => {
  const response = await fetch("/api/clinic/settings/roles", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Role create failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid role create response");

  return data.settings;
};

const updateRoleApi = async (
  key: RoleKey,
  payload: Partial<RoleSetting>,
): Promise<ClinicSettings> => {
  const response = await fetch(
    `/api/clinic/settings/roles/${encodeURIComponent(key)}`,
    {
      method: "PATCH",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      credentials: "include",
      body: JSON.stringify(payload),
    },
  );

  if (!response.ok) throw new Error("Role update failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid role update response");

  return data.settings;
};

const deleteRoleApi = async (key: RoleKey): Promise<ClinicSettings> => {
  const response = await fetch(
    `/api/clinic/settings/roles/${encodeURIComponent(key)}`,
    {
      method: "DELETE",
      credentials: "include",
    },
  );

  if (!response.ok) throw new Error("Role delete failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid role delete response");

  return data.settings;
};

const createModuleApi = async (
  payload: ModuleSetting,
): Promise<ClinicSettings> => {
  const response = await fetch("/api/clinic/settings/modules", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Module create failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid module create response");

  return data.settings;
};

const updateModuleApi = async (
  key: ModuleKey,
  payload: Partial<ModuleSetting>,
): Promise<ClinicSettings> => {
  const response = await fetch(
    `/api/clinic/settings/modules/${encodeURIComponent(key)}`,
    {
      method: "PATCH",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      credentials: "include",
      body: JSON.stringify(payload),
    },
  );

  if (!response.ok) throw new Error("Module update failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid module update response");

  return data.settings;
};

const deleteModuleApi = async (key: ModuleKey): Promise<ClinicSettings> => {
  const response = await fetch(
    `/api/clinic/settings/modules/${encodeURIComponent(key)}`,
    {
      method: "DELETE",
      credentials: "include",
    },
  );

  if (!response.ok) throw new Error("Module delete failed");

  const data = (await response.json()) as { settings?: ClinicSettings };
  if (!data.settings) throw new Error("Invalid module delete response");

  return data.settings;
};

const slugifyKey = (value: string) =>
  value
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^a-zA-Z0-9-_]/g, "")
    .toLowerCase();

const parsePermissions = (value: string) =>
  value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

const StatCard = ({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string;
  value: string;
  hint: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{hint}</p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const Panel = ({
  title,
  subtitle,
  icon: Icon,
  children,
}: {
  title: string;
  subtitle: string;
  icon: LucideIcon;
  children: ReactNode;
}) => (
  <div className="border border-teal-100 bg-white p-4">
    <div className="mb-4 flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
      <div>
        <p className="text-sm font-black text-slate-950">{title}</p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{subtitle}</p>
      </div>
      <Icon size={18} className="text-teal-700" />
    </div>

    {children}
  </div>
);

const ToggleButton = ({
  enabled,
  onClick,
}: {
  enabled: boolean;
  onClick: () => void;
}) => (
  <button
    type="button"
    onClick={onClick}
    className={[
      "inline-flex items-center gap-1 border px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] transition",
      enabled
        ? "border-emerald-200 bg-emerald-50 text-emerald-700"
        : "border-slate-200 bg-slate-50 text-slate-500",
    ].join(" ")}
  >
    {enabled ? <ToggleRight size={14} /> : <ToggleLeft size={14} />}
    {enabled ? "Enabled" : "Disabled"}
  </button>
);

const ClinicSettingsPage = () => {
  const [settings, setSettings] = useState<ClinicSettings>(defaultSettings);
  const [roleForm, setRoleForm] = useState(emptyRoleForm);
  const [moduleForm, setModuleForm] = useState(emptyModuleForm);
  const [roleModalOpen, setRoleModalOpen] = useState(false);
  const [moduleModalOpen, setModuleModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const stats = useMemo(() => {
    const enabledModules = settings.modules.filter((item) => item.enabled).length;
    const enabledRoles = settings.roles.filter((item) => item.enabled).length;
    const notificationCount = Object.values(settings.notifications).filter(Boolean).length;
    const totalUsers = settings.roles.reduce(
      (total, item) => total + Number(item.users || 0),
      0,
    );

    return [
      {
        label: "Modules",
        value: `${enabledModules}/${settings.modules.length}`,
        hint: "Active module access",
        icon: LayoutGrid,
      },
      {
        label: "Roles",
        value: `${enabledRoles}/${settings.roles.length}`,
        hint: `${totalUsers} users mapped`,
        icon: KeyRound,
      },
      {
        label: "Alerts",
        value: String(notificationCount),
        hint: "Notification rules",
        icon: BellRing,
      },
      {
        label: "Clinic",
        value: settings.profile.currency,
        hint: settings.profile.timezone,
        icon: Building2,
      },
    ];
  }, [settings]);

  const roleFormReady =
    roleForm.key.trim().length >= 2 &&
    roleForm.description.trim().length >= 4 &&
    Number.isFinite(Number(roleForm.users)) &&
    Number(roleForm.users) >= 0 &&
    parsePermissions(roleForm.permissions).length > 0;

  const moduleFormReady =
    moduleForm.key.trim().length >= 2 &&
    moduleForm.label.trim().length >= 2 &&
    moduleForm.description.trim().length >= 4;

  useEffect(() => {
    let active = true;

    loadSettings().then((data) => {
      if (!active) return;
      setSettings(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  const updateProfile = (key: keyof ClinicProfile, value: string) => {
    setSettings((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        [key]: value,
      },
    }));
  };

  const updateBranding = (key: keyof BrandingSettings, value: string) => {
    setSettings((prev) => ({
      ...prev,
      branding: {
        ...prev.branding,
        [key]: value,
      },
    }));
  };

  const updateNotification = (key: keyof NotificationSettings) => {
    setSettings((prev) => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [key]: !prev.notifications[key],
      },
    }));
  };

  const handleModuleToggle = async (moduleKey: ModuleKey) => {
    const previousSettings = settings;
    const foundModule = settings.modules.find((item) => item.key === moduleKey);
    const nextEnabled = !foundModule?.enabled;

    const nextSettings = {
      ...settings,
      modules: settings.modules.map((item) =>
        item.key === moduleKey ? { ...item, enabled: nextEnabled } : item,
      ),
    };

    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await updateModuleApi(moduleKey, {
        enabled: nextEnabled,
      });
      setSettings(updatedSettings);
      setMessage("Module setting updated.");
    } catch {
      setSettings(previousSettings);
      setMessage("Backend module update failed. Previous setting restored.");
    }
  };

  const handleRoleToggle = async (roleKey: RoleKey) => {
    const previousSettings = settings;
    const foundRole = settings.roles.find((item) => item.key === roleKey);
    const nextEnabled = !foundRole?.enabled;

    const nextSettings = {
      ...settings,
      roles: settings.roles.map((item) =>
        item.key === roleKey ? { ...item, enabled: nextEnabled } : item,
      ),
    };

    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await updateRoleApi(roleKey, {
        enabled: nextEnabled,
      });
      setSettings(updatedSettings);
      setMessage("Role access updated.");
    } catch {
      setSettings(previousSettings);
      setMessage("Backend role update failed. Previous setting restored.");
    }
  };

  const handleCreateRole = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!roleFormReady || saving) {
      setMessage("Role name, description, users and permissions complete korte hobe.");
      return;
    }

    const roleKey = roleForm.key.trim();
    const exists = settings.roles.some(
      (item) => item.key.toLowerCase() === roleKey.toLowerCase(),
    );

    if (exists) {
      setMessage("Ei role already ache. Onno role name dao.");
      return;
    }

    const newRole: RoleSetting = {
      key: roleKey,
      description: roleForm.description.trim(),
      enabled: roleForm.enabled,
      users: Number(roleForm.users),
      permissions: parsePermissions(roleForm.permissions),
    };

    const previousSettings = settings;
    const nextSettings = {
      ...settings,
      roles: [newRole, ...settings.roles],
    };

    setSaving(true);
    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await createRoleApi(newRole);
      setSettings(updatedSettings);
      setRoleForm(emptyRoleForm);
      setRoleModalOpen(false);
      setMessage("New role added successfully.");
    } catch {
      setSettings(nextSettings);
      setRoleForm(emptyRoleForm);
      setRoleModalOpen(false);
      setMessage("Role added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
    }

    return previousSettings;
  };

  const handleDeleteRole = async (roleKey: RoleKey) => {
    const previousSettings = settings;
    const nextSettings = {
      ...settings,
      roles: settings.roles.filter((item) => item.key !== roleKey),
    };

    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await deleteRoleApi(roleKey);
      setSettings(updatedSettings);
      setMessage("Role deleted successfully.");
    } catch {
      setSettings(previousSettings);
      setMessage("Backend role delete failed. Previous role restored.");
    }
  };

  const handleCreateModule = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!moduleFormReady || saving) {
      setMessage("Module key, label and description complete korte hobe.");
      return;
    }

    const moduleKey = slugifyKey(moduleForm.key);
    const exists = settings.modules.some(
      (item) => item.key.toLowerCase() === moduleKey.toLowerCase(),
    );

    if (exists) {
      setMessage("Ei module already ache. Onno module key dao.");
      return;
    }

    const newModule: ModuleSetting = {
      key: moduleKey,
      label: moduleForm.label.trim(),
      description: moduleForm.description.trim(),
      enabled: moduleForm.enabled,
    };

    const nextSettings = {
      ...settings,
      modules: [newModule, ...settings.modules],
    };

    setSaving(true);
    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await createModuleApi(newModule);
      setSettings(updatedSettings);
      setModuleForm(emptyModuleForm);
      setModuleModalOpen(false);
      setMessage("New module added successfully.");
    } catch {
      setModuleForm(emptyModuleForm);
      setModuleModalOpen(false);
      setMessage("Module added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteModule = async (moduleKey: ModuleKey) => {
    const previousSettings = settings;
    const nextSettings = {
      ...settings,
      modules: settings.modules.filter((item) => item.key !== moduleKey),
    };

    setSettings(nextSettings);
    setMessage("");

    try {
      const updatedSettings = await deleteModuleApi(moduleKey);
      setSettings(updatedSettings);
      setMessage("Module deleted successfully.");
    } catch {
      setSettings(previousSettings);
      setMessage("Backend module delete failed. Previous module restored.");
    }
  };

  const handleSave = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (saving) return;

    setSaving(true);
    setMessage("");

    try {
      const savedSettings = await saveSettingsApi(settings);
      setSettings(savedSettings);
      setMessage("Settings saved successfully.");
    } catch {
      setMessage("Settings saved locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setSettings(defaultSettings);
    setMessage("Settings reset locally. Save korle backend/database update hobe.");
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <form
          onSubmit={handleSave}
          className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl"
        >
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Settings
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm font-semibold leading-6 text-slate-500">
                Clinic profile, branding, roles, notifications and module
                settings.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading settings from backend API..."
                    : "Ready: add role/module/profile/branding/settings functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center justify-center gap-2 border border-slate-200 bg-white px-3 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
              >
                <RefreshCw size={14} />
                Reset
              </button>

              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Save size={14} />
                {saving ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 grid gap-4 xl:grid-cols-2">
            <Panel
              title="Clinic Profile"
              subtitle="Main tenant and clinic identity information."
              icon={Building2}
            >
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Clinic Name">
                  <input
                    value={settings.profile.clinicName}
                    onChange={(event) =>
                      updateProfile("clinicName", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Tenant Name">
                  <input
                    value={settings.profile.tenantName}
                    onChange={(event) =>
                      updateProfile("tenantName", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Owner Name">
                  <input
                    value={settings.profile.ownerName}
                    onChange={(event) =>
                      updateProfile("ownerName", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Phone">
                  <input
                    value={settings.profile.phone}
                    onChange={(event) =>
                      updateProfile("phone", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Email">
                  <input
                    value={settings.profile.email}
                    onChange={(event) =>
                      updateProfile("email", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="License No">
                  <input
                    value={settings.profile.licenseNo}
                    onChange={(event) =>
                      updateProfile("licenseNo", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Timezone">
                  <input
                    value={settings.profile.timezone}
                    onChange={(event) =>
                      updateProfile("timezone", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Currency">
                  <select
                    value={settings.profile.currency}
                    onChange={(event) =>
                      updateProfile("currency", event.target.value)
                    }
                    className={inputClass}
                  >
                    <option value="BDT">BDT</option>
                    <option value="USD">USD</option>
                    <option value="INR">INR</option>
                  </select>
                </Field>

                <div className="md:col-span-2">
                  <Field label="Address">
                    <textarea
                      value={settings.profile.address}
                      onChange={(event) =>
                        updateProfile("address", event.target.value)
                      }
                      rows={3}
                      className={`${inputClass} resize-none`}
                    />
                  </Field>
                </div>
              </div>
            </Panel>

            <Panel
              title="Branding"
              subtitle="Logo, invoice, prescription and theme branding."
              icon={Palette}
            >
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Logo URL">
                  <input
                    value={settings.branding.logoUrl}
                    onChange={(event) =>
                      updateBranding("logoUrl", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Footer Text">
                  <input
                    value={settings.branding.footerText}
                    onChange={(event) =>
                      updateBranding("footerText", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Primary Color">
                  <input
                    value={settings.branding.primaryColor}
                    onChange={(event) =>
                      updateBranding("primaryColor", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Secondary Color">
                  <input
                    value={settings.branding.secondaryColor}
                    onChange={(event) =>
                      updateBranding("secondaryColor", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Invoice Prefix">
                  <input
                    value={settings.branding.invoicePrefix}
                    onChange={(event) =>
                      updateBranding("invoicePrefix", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <Field label="Prescription Prefix">
                  <input
                    value={settings.branding.prescriptionPrefix}
                    onChange={(event) =>
                      updateBranding("prescriptionPrefix", event.target.value)
                    }
                    className={inputClass}
                  />
                </Field>

                <div className="border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-teal-700">
                    Brand Preview
                  </p>
                  <div className="mt-2 flex items-center gap-3">
                    <span
                      className="grid h-10 w-10 place-items-center text-xs font-black text-white"
                      style={{ backgroundColor: settings.branding.primaryColor }}
                    >
                      CL
                    </span>
                    <div>
                      <p className="text-sm font-black text-slate-900">
                        {settings.profile.clinicName}
                      </p>
                      <p className="text-[11px] font-bold text-slate-500">
                        {settings.branding.footerText}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Panel>

            <Panel
              title="Notification Settings"
              subtitle="SMS, email and admin notification control."
              icon={BellRing}
            >
              <div className="grid gap-2">
                {[
                  ["appointmentSms", "Appointment SMS", "Send confirmation and reminder SMS."],
                  ["prescriptionSms", "Prescription SMS", "Notify patient when RX is ready."],
                  ["billingSms", "Billing SMS", "Send due, paid and receipt SMS."],
                  ["emailAlerts", "Email Alerts", "Send important email notifications."],
                  ["adminPush", "Admin Push", "Show admin panel alerts."],
                  ["lowSmsBalanceAlert", "Low SMS Balance", "Alert when SMS balance is low."],
                ].map(([key, title, note]) => {
                  const typedKey = key as keyof NotificationSettings;

                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between gap-3 border border-slate-100 bg-slate-50 p-3"
                    >
                      <div>
                        <p className="text-sm font-black text-slate-800">
                          {title}
                        </p>
                        <p className="mt-1 text-[11px] font-bold text-slate-400">
                          {note}
                        </p>
                      </div>

                      <ToggleButton
                        enabled={settings.notifications[typedKey]}
                        onClick={() => updateNotification(typedKey)}
                      />
                    </div>
                  );
                })}
              </div>
            </Panel>

            <Panel
              title="Module Settings"
              subtitle="Enable, disable, add or remove clinic panel modules."
              icon={LayoutGrid}
            >
              <div className="mb-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setModuleForm(emptyModuleForm);
                    setModuleModalOpen(true);
                  }}
                  className="inline-flex items-center gap-2 border border-emerald-700 bg-emerald-700 px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-white transition hover:bg-emerald-800"
                >
                  <Plus size={14} />
                  Add Module
                </button>
              </div>

              <div className="grid gap-2">
                {settings.modules.map((item) => (
                  <div
                    key={item.key}
                    className="flex items-center justify-between gap-3 border border-slate-100 bg-slate-50 p-3"
                  >
                    <div>
                      <p className="text-sm font-black text-slate-800">
                        {item.label}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-400">
                        {item.description}
                      </p>
                      <p className="mt-1 text-[10px] font-black uppercase tracking-[0.12em] text-slate-400">
                        Key: {item.key}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <ToggleButton
                        enabled={item.enabled}
                        onClick={() => handleModuleToggle(item.key)}
                      />

                      <button
                        type="button"
                        onClick={() => handleDeleteModule(item.key)}
                        className="grid h-8 w-8 place-items-center border border-rose-100 bg-rose-50 text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Panel>
          </div>

          <div className="mt-4 border border-teal-100 bg-white">
            <div className="flex items-center justify-between border-b border-teal-100 bg-slate-50 px-4 py-3">
              <div>
                <p className="text-sm font-black text-slate-950">
                  Roles & Permissions
                </p>
                <p className="mt-1 text-[11px] font-bold text-slate-400">
                  Add custom role, set users, permissions and access status.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setRoleForm(emptyRoleForm);
                  setRoleModalOpen(true);
                }}
                className="inline-flex items-center gap-2 border border-emerald-700 bg-emerald-700 px-3 py-2 text-xs font-black uppercase tracking-[0.12em] text-white transition hover:bg-emerald-800"
              >
                <Plus size={14} />
                Add Role
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[980px] border-collapse bg-white text-left">
                <thead className="bg-slate-50">
                  <tr className="border-b border-slate-100">
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Role
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Description
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Users
                    </th>
                    <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Permissions
                    </th>
                    <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                      Action
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {settings.roles.map((role) => (
                    <tr
                      key={role.key}
                      className="border-b border-slate-100 transition hover:bg-teal-50/45"
                    >
                      <td className="px-4 py-3">
                        <p className="text-sm font-black text-slate-950">
                          {role.key}
                        </p>
                        <p className="mt-1 text-[11px] font-bold text-slate-500">
                          {role.enabled ? "Active role" : "Disabled role"}
                        </p>
                      </td>

                      <td className="px-4 py-3 text-xs font-bold text-slate-500">
                        {role.description}
                      </td>

                      <td className="px-4 py-3 text-sm font-black text-slate-800">
                        {role.users}
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {role.permissions.map((permission) => (
                            <span
                              key={`${role.key}-${permission}`}
                              className="border border-teal-100 bg-teal-50 px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em] text-teal-800"
                            >
                              {permission}
                            </span>
                          ))}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-2">
                          <ToggleButton
                            enabled={role.enabled}
                            onClick={() => handleRoleToggle(role.key)}
                          />

                          <button
                            type="button"
                            onClick={() => handleDeleteRole(role.key)}
                            className="grid h-8 w-8 place-items-center border border-rose-100 bg-rose-50 text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {!settings.roles.length && (
                    <tr>
                      <td
                        colSpan={5}
                        className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                      >
                        No role found. Add custom role.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <SlidersHorizontal size={14} />
            Full settings, role add, module add and backend API fallback ready.
          </div>
        </form>
      </section>

      {roleModalOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Role
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New access role
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Role name, users and permissions comma diye add koro.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setRoleModalOpen(false)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateRole} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Role Name">
                  <input
                    value={roleForm.key}
                    onChange={(event) =>
                      setRoleForm((prev) => ({
                        ...prev,
                        key: event.target.value,
                      }))
                    }
                    placeholder="Manager / Lab Assistant / Nurse"
                    className={inputClass}
                  />
                </Field>

                <Field label="Users Count">
                  <input
                    value={roleForm.users}
                    onChange={(event) =>
                      setRoleForm((prev) => ({
                        ...prev,
                        users: event.target.value,
                      }))
                    }
                    type="number"
                    min={0}
                    className={inputClass}
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="Description">
                    <input
                      value={roleForm.description}
                      onChange={(event) =>
                        setRoleForm((prev) => ({
                          ...prev,
                          description: event.target.value,
                        }))
                      }
                      placeholder="What this role can do"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <div className="md:col-span-2">
                  <Field label="Permissions">
                    <input
                      value={roleForm.permissions}
                      onChange={(event) =>
                        setRoleForm((prev) => ({
                          ...prev,
                          permissions: event.target.value,
                        }))
                      }
                      placeholder="Appointments, Patients, Billing, Reports"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <div className="flex items-center justify-between border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <div>
                    <p className="text-sm font-black text-slate-800">
                      Role Access
                    </p>
                    <p className="mt-1 text-[11px] font-bold text-slate-500">
                      New role initially enabled/disabled.
                    </p>
                  </div>

                  <ToggleButton
                    enabled={roleForm.enabled}
                    onClick={() =>
                      setRoleForm((prev) => ({
                        ...prev,
                        enabled: !prev.enabled,
                      }))
                    }
                  />
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setRoleModalOpen(false)}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!roleFormReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    roleFormReady
                      ? "border-emerald-700 bg-emerald-700 text-white hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <Plus size={14} />
                  {saving ? "Adding..." : "Add Role"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {moduleModalOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Module
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  New clinic module
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Module key, label and description add koro.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setModuleModalOpen(false)}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateModule} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Module Key">
                  <input
                    value={moduleForm.key}
                    onChange={(event) =>
                      setModuleForm((prev) => ({
                        ...prev,
                        key: event.target.value,
                      }))
                    }
                    placeholder="lab-reports"
                    className={inputClass}
                  />
                </Field>

                <Field label="Module Label">
                  <input
                    value={moduleForm.label}
                    onChange={(event) =>
                      setModuleForm((prev) => ({
                        ...prev,
                        label: event.target.value,
                      }))
                    }
                    placeholder="Lab Reports"
                    className={inputClass}
                  />
                </Field>

                <div className="md:col-span-2">
                  <Field label="Description">
                    <input
                      value={moduleForm.description}
                      onChange={(event) =>
                        setModuleForm((prev) => ({
                          ...prev,
                          description: event.target.value,
                        }))
                      }
                      placeholder="Module description"
                      className={inputClass}
                    />
                  </Field>
                </div>

                <div className="flex items-center justify-between border border-teal-100 bg-teal-50/70 p-3 md:col-span-2">
                  <div>
                    <p className="text-sm font-black text-slate-800">
                      Module Access
                    </p>
                    <p className="mt-1 text-[11px] font-bold text-slate-500">
                      New module initially enabled/disabled.
                    </p>
                  </div>

                  <ToggleButton
                    enabled={moduleForm.enabled}
                    onClick={() =>
                      setModuleForm((prev) => ({
                        ...prev,
                        enabled: !prev.enabled,
                      }))
                    }
                  />
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setModuleModalOpen(false)}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!moduleFormReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    moduleFormReady
                      ? "border-emerald-700 bg-emerald-700 text-white hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <Plus size={14} />
                  {saving ? "Adding..." : "Add Module"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicSettingsPage;