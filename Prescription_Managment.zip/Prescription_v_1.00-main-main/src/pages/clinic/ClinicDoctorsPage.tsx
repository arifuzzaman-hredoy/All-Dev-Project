import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  CalendarClock,
  CheckCircle2,
  Mail,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
  Stethoscope,
  Trash2,
  UserPlus,
  Users,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type DoctorStatus = "Active" | "On Leave" | "Suspended";

type ClinicDoctor = {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  chamber: string;
  schedule: string;
  dailyCapacity: number;
  bookedToday: number;
  status: DoctorStatus;
};

const statusOptions: DoctorStatus[] = ["Active", "On Leave", "Suspended"];

const mockDoctors: ClinicDoctor[] = [
  {
    id: "DR-1001",
    name: "Dr. Abdullah Rahman",
    email: "abdullah@carebridge.demo",
    phone: "+8801711000001",
    specialization: "Medicine",
    chamber: "Room 301",
    schedule: "Sat-Thu, 5:00 PM - 9:00 PM",
    dailyCapacity: 32,
    bookedToday: 18,
    status: "Active",
  },
  {
    id: "DR-1002",
    name: "Dr. Nusrat Jahan",
    email: "nusrat@carebridge.demo",
    phone: "+8801711000002",
    specialization: "Gynecology",
    chamber: "Room 204",
    schedule: "Sun-Wed, 4:00 PM - 8:00 PM",
    dailyCapacity: 24,
    bookedToday: 9,
    status: "Active",
  },
  {
    id: "DR-1003",
    name: "Dr. Mehedi Hasan",
    email: "mehedi@carebridge.demo",
    phone: "+8801711000003",
    specialization: "Cardiology",
    chamber: "Room 402",
    schedule: "Mon-Thu, 6:00 PM - 10:00 PM",
    dailyCapacity: 18,
    bookedToday: 0,
    status: "On Leave",
  },
];

const emptyForm = {
  name: "",
  email: "",
  phone: "",
  specialization: "",
  chamber: "",
  schedule: "",
  dailyCapacity: "20",
  status: "Active" as DoctorStatus,
};

const statusClass: Record<DoctorStatus, string> = {
  Active: "border-emerald-200 bg-emerald-50 text-emerald-700",
  "On Leave": "border-amber-200 bg-amber-50 text-amber-700",
  Suspended: "border-rose-200 bg-rose-50 text-rose-700",
};

const isValidEmail = (email: string) => /\S+@\S+\.\S+/.test(email);

const localSearch = (items: ClinicDoctor[], query: string) => {
  const searchText = query.trim().toLowerCase();

  if (!searchText) return items;

  return items.filter((doctor) =>
    `${doctor.name} ${doctor.email} ${doctor.phone} ${doctor.specialization} ${doctor.chamber} ${doctor.schedule} ${doctor.status}`
      .toLowerCase()
      .includes(searchText),
  );
};

const capacityPercent = (booked: number, capacity: number) => {
  if (!capacity) return 0;
  return Math.min(100, Math.round((booked / capacity) * 100));
};

const loadDoctors = async (
  query = "",
  fallback = mockDoctors,
): Promise<ClinicDoctor[]> => {
  try {
    const params = query.trim()
      ? `?q=${encodeURIComponent(query.trim())}`
      : "";

    const response = await fetch(`/api/clinic/doctors${params}`, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localSearch(fallback, query);

    const data = (await response.json()) as { doctors?: ClinicDoctor[] };

    return Array.isArray(data.doctors)
      ? data.doctors
      : localSearch(fallback, query);
  } catch {
    return localSearch(fallback, query);
  }
};

const createDoctorApi = async (
  payload: Omit<ClinicDoctor, "id" | "bookedToday">,
): Promise<ClinicDoctor> => {
  const response = await fetch("/api/clinic/doctors", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create doctor failed");

  const data = (await response.json()) as { doctor?: ClinicDoctor };
  if (!data.doctor) throw new Error("Invalid response");

  return data.doctor;
};

const updateDoctorStatusApi = async (
  id: string,
  status: DoctorStatus,
): Promise<ClinicDoctor> => {
  const response = await fetch(`/api/clinic/doctors/${id}/status`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ status }),
  });

  if (!response.ok) throw new Error("Update doctor status failed");

  const data = (await response.json()) as { doctor?: ClinicDoctor };
  if (!data.doctor) throw new Error("Invalid response");

  return data.doctor;
};

const deleteDoctorApi = async (id: string) => {
  const response = await fetch(`/api/clinic/doctors/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete doctor failed");
};

const StatusBadge = ({ status }: { status: DoctorStatus }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      statusClass[status],
    ].join(" ")}
  >
    {status}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/90 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.9} className="text-teal-700" />
    </div>
  </div>
);

const Field = ({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) => (
  <label className="grid gap-1">
    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
      {label}
    </span>
    {children}
  </label>
);

const ClinicDoctorsPage = () => {
  const [doctors, setDoctors] = useState<ClinicDoctor[]>(mockDoctors);
  const [visibleDoctors, setVisibleDoctors] =
    useState<ClinicDoctor[]>(mockDoctors);
  const [form, setForm] = useState(emptyForm);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [addOpen, setAddOpen] = useState(false);

  const capacityNumber = Number(form.dailyCapacity);

  const formReady =
    form.name.trim().length >= 2 &&
    isValidEmail(form.email.trim()) &&
    form.phone.trim().length >= 5 &&
    form.specialization.trim().length >= 2 &&
    form.chamber.trim().length >= 2 &&
    form.schedule.trim().length >= 2 &&
    Number.isFinite(capacityNumber) &&
    capacityNumber > 0 &&
    statusOptions.includes(form.status);

  useEffect(() => {
    let active = true;

    loadDoctors().then((data) => {
      if (!active) return;
      setDoctors(data);
      setVisibleDoctors(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadDoctors(query, doctors).then((data) => {
        if (!active) return;
        setVisibleDoctors(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [query, doctors]);

  const stats = useMemo(
    () => [
      {
        label: "Total Doctors",
        value: String(doctors.length),
        icon: Users,
      },
      {
        label: "Active",
        value: String(
          doctors.filter((doctor) => doctor.status === "Active").length,
        ),
        icon: CheckCircle2,
      },
      {
        label: "On Leave",
        value: String(
          doctors.filter((doctor) => doctor.status === "On Leave").length,
        ),
        icon: CalendarClock,
      },
      {
        label: "Suspended",
        value: String(
          doctors.filter((doctor) => doctor.status === "Suspended").length,
        ),
        icon: XCircle,
      },
    ],
    [doctors],
  );

  const syncDoctors = (nextDoctors: ClinicDoctor[]) => {
    setDoctors(nextDoctors);
    setVisibleDoctors(localSearch(nextDoctors, query));
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
  };

  const closeModal = () => {
    setAddOpen(false);
    resetForm();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const name = form.name.trim();
    const email = form.email.trim().toLowerCase();
    const phone = form.phone.trim();
    const specialization = form.specialization.trim();
    const chamber = form.chamber.trim();
    const schedule = form.schedule.trim();
    const dailyCapacity = Number(form.dailyCapacity);

    if (!formReady || saving) {
      setMessage("Doctor full form complete korle Add Doctor button enable hobe.");
      return;
    }

    const duplicate = doctors.some(
      (doctor) => doctor.email.toLowerCase() === email,
    );

    if (duplicate) {
      setMessage("This doctor email already exists.");
      return;
    }

    setSaving(true);
    setMessage("");

    const fallbackDoctor: ClinicDoctor = {
      id: `DR-${Date.now()}`,
      name,
      email,
      phone,
      specialization,
      chamber,
      schedule,
      dailyCapacity,
      bookedToday: 0,
      status: form.status,
    };

    try {
      const createdDoctor = await createDoctorApi({
        name,
        email,
        phone,
        specialization,
        chamber,
        schedule,
        dailyCapacity,
        status: form.status,
      });

      syncDoctors([createdDoctor, ...doctors]);
      setAddOpen(false);
      setForm(emptyForm);
      setMessage("Doctor added successfully.");
    } catch {
      syncDoctors([fallbackDoctor, ...doctors]);
      setAddOpen(false);
      setForm(emptyForm);
      setMessage("Doctor added locally. Backend route connect korle database save hobe.");
    } finally {
      setSaving(false);
    }
  };

  const handleStatusChange = async (
    doctor: ClinicDoctor,
    status: DoctorStatus,
  ) => {
    const previousDoctors = doctors;
    const nextDoctors = doctors.map((item) =>
      item.id === doctor.id ? { ...item, status } : item,
    );

    syncDoctors(nextDoctors);
    setMessage("");

    try {
      const updatedDoctor = await updateDoctorStatusApi(doctor.id, status);

      syncDoctors(
        nextDoctors.map((item) =>
          item.id === updatedDoctor.id ? updatedDoctor : item,
        ),
      );
    } catch {
      syncDoctors(previousDoctors);
      setMessage("Backend status update failed. Previous status restored.");
    }
  };

  const handleRemoveDoctor = async (doctor: ClinicDoctor) => {
    const previousDoctors = doctors;
    const nextDoctors = doctors.filter((item) => item.id !== doctor.id);

    syncDoctors(nextDoctors);
    setMessage("");

    try {
      await deleteDoctorApi(doctor.id);
      setMessage("Doctor removed successfully.");
    } catch {
      syncDoctors(previousDoctors);
      setMessage("Backend delete failed, doctor restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="w-full px-4 py-6">
        <div className="border border-teal-100 bg-white/90 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Doctors
              </h1>
              <p className="mt-1.5 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
                Doctor directory, chamber schedule and appointment capacity.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
                <p className="text-[11px] font-black text-teal-800">
                  {loading
                    ? "Loading doctors from backend API..."
                    : searching
                      ? "Searching database..."
                      : "Ready: add/search/status/remove functional."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setAddOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-emerald-700 px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-white shadow-[0_12px_30px_rgba(5,150,105,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-emerald-800"
              >
                <UserPlus size={15} />
                Add Doctor
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <div className="mt-4 flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
            <Search size={15} className="text-slate-400" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search doctor, email, phone, speciality, chamber or status"
              className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
            />
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-full border-collapse bg-white text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Doctor
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Chamber
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Schedule
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Capacity
                  </th>
                  <th className="px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Status
                  </th>
                  <th className="px-4 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleDoctors.map((doctor) => {
                  const usedPercent = capacityPercent(
                    doctor.bookedToday,
                    doctor.dailyCapacity,
                  );

                  return (
                    <tr
                      key={doctor.id}
                      className="border-b border-slate-100 transition hover:bg-teal-50/45"
                    >
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm font-black text-slate-950">
                            {doctor.name}
                          </p>

                          <p className="mt-0.5 text-[11px] font-black text-teal-700">
                            {doctor.specialization}
                          </p>

                          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                            <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                              <Mail size={12} />
                              {doctor.email}
                            </p>

                            <p className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                              <Phone size={12} />
                              {doctor.phone}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <p className="inline-flex items-center gap-1 text-xs font-bold text-slate-600">
                          <MapPin size={13} />
                          {doctor.chamber}
                        </p>
                      </td>

                      <td className="px-4 py-3 text-xs font-bold text-slate-500">
                        {doctor.schedule}
                      </td>

                      <td className="px-4 py-3">
                        <p className="text-xs font-black text-slate-700">
                          {doctor.bookedToday}/{doctor.dailyCapacity}
                        </p>
                        <div className="mt-2 h-1.5 w-24 border border-teal-100 bg-slate-50">
                          <div
                            className="h-full bg-teal-700 transition-all duration-500"
                            style={{ width: `${usedPercent}%` }}
                          />
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="grid gap-1">
                          <select
                            value={doctor.status}
                            onChange={(event) =>
                              handleStatusChange(
                                doctor,
                                event.target.value as DoctorStatus,
                              )
                            }
                            className="border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 focus:border-teal-300 focus:outline-none"
                          >
                            {statusOptions.map((status) => (
                              <option key={status} value={status}>
                                {status}
                              </option>
                            ))}
                          </select>

                          <StatusBadge status={doctor.status} />
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              handleStatusChange(
                                doctor,
                                doctor.status === "Active" ? "On Leave" : "Active",
                              )
                            }
                            className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                          >
                            <ShieldCheck size={13} />
                            {doctor.status === "Active" ? "Leave" : "Active"}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleRemoveDoctor(doctor)}
                            className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100"
                          >
                            <Trash2 size={13} />
                            Remove
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {!visibleDoctors.length && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No doctor found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex items-center gap-2 border border-teal-100 bg-teal-50/70 px-3 py-2 text-[11px] font-black text-teal-800">
            <Stethoscope size={14} />
            Frontend realtime update + backend API fallback ready.
          </div>
        </div>
      </section>

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/45 px-4 backdrop-blur-sm">
          <div className="w-full max-w-3xl border border-teal-100 bg-white p-4 shadow-[0_24px_80px_rgba(15,23,42,0.22)]">
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                  Add Doctor
                </p>
                <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                  Doctor profile setup
                </h2>
                <p className="mt-1 text-xs font-bold text-slate-500">
                  Full form complete করলে Add Doctor button strong green হবে।
                </p>
              </div>

              <button
                type="button"
                onClick={closeModal}
                className="grid h-8 w-8 place-items-center border border-slate-100 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Field label="Doctor Name">
                  <input
                    value={form.name}
                    onChange={(event) => {
                      setForm((prev) => ({ ...prev, name: event.target.value }));
                      setMessage("");
                    }}
                    placeholder="Dr. Karim Ahmed"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Email Address">
                  <input
                    value={form.email}
                    onChange={(event) => {
                      setForm((prev) => ({ ...prev, email: event.target.value }));
                      setMessage("");
                    }}
                    placeholder="doctor@clinic.com"
                    type="email"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Phone Number">
                  <input
                    value={form.phone}
                    onChange={(event) => {
                      setForm((prev) => ({ ...prev, phone: event.target.value }));
                      setMessage("");
                    }}
                    placeholder="+88017xxxxxxxx"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Specialization">
                  <input
                    value={form.specialization}
                    onChange={(event) => {
                      setForm((prev) => ({
                        ...prev,
                        specialization: event.target.value,
                      }));
                      setMessage("");
                    }}
                    placeholder="Medicine / Cardiology / Gynecology"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Chamber">
                  <input
                    value={form.chamber}
                    onChange={(event) => {
                      setForm((prev) => ({
                        ...prev,
                        chamber: event.target.value,
                      }));
                      setMessage("");
                    }}
                    placeholder="Room 301"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Schedule">
                  <input
                    value={form.schedule}
                    onChange={(event) => {
                      setForm((prev) => ({
                        ...prev,
                        schedule: event.target.value,
                      }));
                      setMessage("");
                    }}
                    placeholder="Sat-Thu, 5:00 PM - 9:00 PM"
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Daily Capacity">
                  <input
                    value={form.dailyCapacity}
                    onChange={(event) => {
                      setForm((prev) => ({
                        ...prev,
                        dailyCapacity: event.target.value,
                      }));
                      setMessage("");
                    }}
                    placeholder="20"
                    type="number"
                    min={1}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
                  />
                </Field>

                <Field label="Status">
                  <select
                    value={form.status}
                    onChange={(event) => {
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value as DoctorStatus,
                      }));
                      setMessage("");
                    }}
                    className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
                  >
                    {statusOptions.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              {message ? (
                <div className="border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
                  {message}
                </div>
              ) : null}

              <div className="mt-1 text-[11px] font-bold text-slate-400">
                {formReady
                  ? "Doctor form complete. Add Doctor button enabled."
                  : "Name + valid email + phone + speciality + chamber + schedule + capacity complete korte hobe."}
              </div>

              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="border border-slate-200 bg-white px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={!formReady || saving}
                  className={[
                    "inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition disabled:cursor-not-allowed",
                    formReady
                      ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:bg-emerald-800"
                      : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
                  ].join(" ")}
                >
                  <UserPlus size={15} />
                  {saving ? "Adding..." : "Add Doctor"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
};

export default ClinicDoctorsPage;