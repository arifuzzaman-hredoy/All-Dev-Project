import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  CheckCircle2,
  LockKeyhole,
  Mail,
  Search,
  ShieldCheck,
  Trash2,
  UserPlus,
  Users,
  XCircle,
  type LucideIcon,
} from "lucide-react";

type UserRole = "Owner" | "Doctor" | "Receptionist" | "Accountant" | "Staff";
type AccessStatus = "Active" | "Suspended";

type ClinicUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  access: AccessStatus;
  lastActive: string;
};

const roleOptions: UserRole[] = [
  "Owner",
  "Doctor",
  "Receptionist",
  "Accountant",
  "Staff",
];

const mockUsers: ClinicUser[] = [
  {
    id: "USR-1001",
    name: "Clinic Owner",
    email: "owner@carebridge.demo",
    role: "Owner",
    access: "Active",
    lastActive: "Today",
  },
  {
    id: "USR-1002",
    name: "Dr. Rahman",
    email: "doctor@carebridge.demo",
    role: "Doctor",
    access: "Active",
    lastActive: "2 hours ago",
  },
  {
    id: "USR-1003",
    name: "Front Desk",
    email: "reception@carebridge.demo",
    role: "Receptionist",
    access: "Active",
    lastActive: "Yesterday",
  },
];

const emptyForm = {
  name: "",
  email: "",
  role: "Staff" as UserRole,
};

const accessClass: Record<AccessStatus, string> = {
  Active: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Suspended: "border-rose-200 bg-rose-50 text-rose-700",
};

const roleClass: Record<UserRole, string> = {
  Owner: "border-teal-200 bg-teal-50 text-teal-800",
  Doctor: "border-blue-200 bg-blue-50 text-blue-700",
  Receptionist: "border-cyan-200 bg-cyan-50 text-cyan-700",
  Accountant: "border-amber-200 bg-amber-50 text-amber-700",
  Staff: "border-slate-200 bg-slate-50 text-slate-600",
};

const isValidEmail = (email: string) => /\S+@\S+\.\S+/.test(email);

const localSearch = (items: ClinicUser[], query: string) => {
  const searchText = query.trim().toLowerCase();

  if (!searchText) return items;

  return items.filter((user) =>
    `${user.name} ${user.email} ${user.role} ${user.access} ${user.lastActive}`
      .toLowerCase()
      .includes(searchText),
  );
};

const loadUsers = async (
  query = "",
  fallback = mockUsers,
): Promise<ClinicUser[]> => {
  try {
    const params = query.trim()
      ? `?q=${encodeURIComponent(query.trim())}`
      : "";

    const response = await fetch(`/api/clinic/users${params}`, {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return localSearch(fallback, query);

    const data = (await response.json()) as { users?: ClinicUser[] };
    return Array.isArray(data.users) ? data.users : localSearch(fallback, query);
  } catch {
    return localSearch(fallback, query);
  }
};

const createUserApi = async (
  payload: Pick<ClinicUser, "name" | "email" | "role">,
): Promise<ClinicUser> => {
  const response = await fetch("/api/clinic/users", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Create user failed");

  const data = (await response.json()) as { user?: ClinicUser };
  if (!data.user) throw new Error("Invalid response");

  return data.user;
};

const updateAccessApi = async (
  id: string,
  access: AccessStatus,
): Promise<ClinicUser> => {
  const response = await fetch(`/api/clinic/users/${id}/access`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify({ access }),
  });

  if (!response.ok) throw new Error("Update access failed");

  const data = (await response.json()) as { user?: ClinicUser };
  if (!data.user) throw new Error("Invalid response");

  return data.user;
};

const deleteUserApi = async (id: string) => {
  const response = await fetch(`/api/clinic/users/${id}`, {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) throw new Error("Delete user failed");
};

const StatusBadge = ({ status }: { status: AccessStatus }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      accessClass[status],
    ].join(" ")}
  >
    {status}
  </span>
);

const RoleBadge = ({ role }: { role: UserRole }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      roleClass[role],
    ].join(" ")}
  >
    {role}
  </span>
);

const StatCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="border border-teal-100 bg-white/88 p-3">
    <div className="flex items-center justify-between gap-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1 text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
      </div>

      <Icon size={19} strokeWidth={1.8} className="text-teal-700" />
    </div>
  </div>
);

const ClinicUsersPage = () => {
  const [users, setUsers] = useState<ClinicUser[]>(mockUsers);
  const [visibleUsers, setVisibleUsers] = useState<ClinicUser[]>(mockUsers);
  const [form, setForm] = useState(emptyForm);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const formReady =
    form.name.trim().length >= 2 &&
    isValidEmail(form.email.trim()) &&
    roleOptions.includes(form.role);

  useEffect(() => {
    let active = true;

    loadUsers().then((data) => {
      if (!active) return;
      setUsers(data);
      setVisibleUsers(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      setSearching(true);

      loadUsers(query, users).then((data) => {
        if (!active) return;
        setVisibleUsers(data);
        setSearching(false);
      });
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [query, users]);

  const stats = useMemo(
    () => [
      {
        label: "Total Users",
        value: String(users.length),
        icon: Users,
      },
      {
        label: "Active",
        value: String(users.filter((user) => user.access === "Active").length),
        icon: CheckCircle2,
      },
      {
        label: "Suspended",
        value: String(
          users.filter((user) => user.access === "Suspended").length,
        ),
        icon: XCircle,
      },
      {
        label: "Roles",
        value: String(new Set(users.map((user) => user.role)).size),
        icon: ShieldCheck,
      },
    ],
    [users],
  );

  const addUserToState = (newUser: ClinicUser) => {
    setUsers((prev) => {
      const nextUsers = [newUser, ...prev];
      setVisibleUsers(localSearch(nextUsers, query));
      return nextUsers;
    });
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const name = form.name.trim();
    const email = form.email.trim().toLowerCase();

    if (!formReady || saving) {
      setMessage("Name, valid email and role complete korle Add User button enable hobe.");
      return;
    }

    const duplicate = users.some((user) => user.email.toLowerCase() === email);

    if (duplicate) {
      setMessage("This email already exists.");
      return;
    }

    setSaving(true);
    setMessage("");

    const fallbackUser: ClinicUser = {
      id: `USR-${Date.now()}`,
      name,
      email,
      role: form.role,
      access: "Active",
      lastActive: "Just now",
    };

    try {
      const createdUser = await createUserApi({
        name,
        email,
        role: form.role,
      });

      addUserToState(createdUser);
      setMessage("User added successfully.");
    } catch {
      addUserToState(fallbackUser);
      setMessage("User added locally. Backend route connect korle database save hobe.");
    } finally {
      setForm(emptyForm);
      setSaving(false);
    }
  };

  const handleToggleAccess = async (user: ClinicUser) => {
    const nextAccess: AccessStatus =
      user.access === "Active" ? "Suspended" : "Active";

    const updateLocal = (items: ClinicUser[]) =>
      items.map((item) =>
        item.id === user.id ? { ...item, access: nextAccess } : item,
      );

    setUsers((prev) => {
      const nextUsers = updateLocal(prev);
      setVisibleUsers(localSearch(nextUsers, query));
      return nextUsers;
    });

    setMessage("");

    try {
      const updatedUser = await updateAccessApi(user.id, nextAccess);

      setUsers((prev) => {
        const nextUsers = prev.map((item) =>
          item.id === updatedUser.id ? updatedUser : item,
        );
        setVisibleUsers(localSearch(nextUsers, query));
        return nextUsers;
      });
    } catch {
      setMessage("Access updated locally. Backend route connect korle database save hobe.");
    }
  };

  const handleRemoveUser = async (user: ClinicUser) => {
    if (user.role === "Owner") {
      setMessage("Owner user remove kora jabe na.");
      return;
    }

    const previousUsers = users;
    const previousVisibleUsers = visibleUsers;

    setUsers((prev) => prev.filter((item) => item.id !== user.id));
    setVisibleUsers((prev) => prev.filter((item) => item.id !== user.id));
    setMessage("");

    try {
      await deleteUserApi(user.id);
      setMessage("User removed successfully.");
    } catch {
      setUsers(previousUsers);
      setVisibleUsers(previousVisibleUsers);
      setMessage("Backend delete failed, user restored.");
    }
  };

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="mx-auto max-w-7xl px-4 py-6">
        <div className="border border-teal-100 bg-white/88 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                Users
              </h1>
              <p className="mt-1.5 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
                Add user, remove user, search from database and manage access.
              </p>
            </div>

            <div className="border border-teal-100 bg-teal-50/70 px-3 py-2">
              <p className="text-[11px] font-black text-teal-800">
                {loading
                  ? "Loading users from backend API..."
                  : searching
                    ? "Searching database..."
                    : "Ready: fill full form then Add User button will enable."}
              </p>
            </div>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard key={item.label} {...item} />
            ))}
          </div>

          <form
            onSubmit={handleSubmit}
            className="mt-4 grid gap-2 lg:grid-cols-[1fr_1fr_170px_150px]"
          >
            <input
              value={form.name}
              onChange={(event) => {
                setForm((prev) => ({ ...prev, name: event.target.value }));
                setMessage("");
              }}
              placeholder="User name"
              className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
            />

            <input
              value={form.email}
              onChange={(event) => {
                setForm((prev) => ({ ...prev, email: event.target.value }));
                setMessage("");
              }}
              placeholder="Email address"
              type="email"
              className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:border-teal-300 focus:outline-none"
            />

            <select
              value={form.role}
              onChange={(event) => {
                setForm((prev) => ({
                  ...prev,
                  role: event.target.value as UserRole,
                }));
                setMessage("");
              }}
              className="border border-teal-100 bg-white px-3 py-2.5 text-sm font-black text-slate-700 focus:border-teal-300 focus:outline-none"
            >
              {roleOptions.map((role) => (
                <option key={role} value={role}>
                  {role}
                </option>
              ))}
            </select>

            <button
              type="submit"
              disabled={!formReady || saving}
              title={
                formReady
                  ? "Click to add user"
                  : "Fill name, valid email and role first"
              }
              className={[
                "group inline-flex items-center justify-center gap-2 border px-4 py-2.5 text-xs font-black uppercase tracking-[0.12em] transition-all duration-300 disabled:cursor-not-allowed",
                formReady
                  ? "border-emerald-700 bg-emerald-700 text-white shadow-[0_12px_30px_rgba(5,150,105,0.22)] hover:-translate-y-0.5 hover:bg-emerald-800 hover:shadow-[0_16px_40px_rgba(5,150,105,0.28)]"
                  : "border-emerald-100 bg-emerald-50 text-emerald-300 opacity-70",
              ].join(" ")}
            >
              <UserPlus
                size={15}
                className={formReady ? "text-white" : "text-emerald-300"}
              />
              {saving ? "Adding..." : "Add User"}
            </button>
          </form>

          <div className="mt-2 text-[11px] font-bold text-slate-400">
            {formReady
              ? "Form complete. Add User button enabled."
              : "Name minimum 2 characters + valid email + role select korlei button strong green hobe."}
          </div>

          <div className="mt-4 flex items-center gap-2 border border-teal-100 bg-slate-50/80 px-3 py-2">
            <Search size={15} className="text-slate-400" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search from database by user, email, role or access"
              className="min-w-0 flex-1 bg-transparent text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none"
            />
          </div>

          {message ? (
            <div className="mt-3 border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
              {message}
            </div>
          ) : null}

          <div className="mt-4 overflow-x-auto border border-teal-100">
            <table className="min-w-full border-collapse bg-white/90 text-left">
              <thead className="bg-slate-50">
                <tr className="border-b border-slate-100">
                  <th className="px-3 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    User
                  </th>
                  <th className="px-3 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Role
                  </th>
                  <th className="px-3 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Access
                  </th>
                  <th className="px-3 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Last Active
                  </th>
                  <th className="px-3 py-3 text-right text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {visibleUsers.map((user) => (
                  <tr
                    key={user.id}
                    className="border-b border-slate-100 transition hover:bg-teal-50/45"
                  >
                    <td className="px-3 py-3">
                      <div>
                        <p className="text-sm font-black text-slate-950">
                          {user.name}
                        </p>
                        <p className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                          <Mail size={12} />
                          {user.email}
                        </p>
                      </div>
                    </td>

                    <td className="px-3 py-3">
                      <RoleBadge role={user.role} />
                    </td>

                    <td className="px-3 py-3">
                      <StatusBadge status={user.access} />
                    </td>

                    <td className="px-3 py-3 text-xs font-bold text-slate-500">
                      {user.lastActive}
                    </td>

                    <td className="px-3 py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => handleToggleAccess(user)}
                          className="inline-flex items-center gap-1 border border-slate-200 bg-white px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-slate-600 transition hover:border-teal-200 hover:text-teal-800"
                        >
                          <LockKeyhole size={13} />
                          {user.access === "Active" ? "Suspend" : "Activate"}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveUser(user)}
                          disabled={user.role === "Owner"}
                          className="inline-flex items-center gap-1 border border-rose-100 bg-rose-50 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-rose-600 transition hover:border-rose-200 hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-45"
                        >
                          <Trash2 size={13} />
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {!visibleUsers.length && (
                  <tr>
                    <td
                      colSpan={5}
                      className="px-3 py-8 text-center text-sm font-bold text-slate-400"
                    >
                      No user found from database search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>
  );
};

export default ClinicUsersPage;