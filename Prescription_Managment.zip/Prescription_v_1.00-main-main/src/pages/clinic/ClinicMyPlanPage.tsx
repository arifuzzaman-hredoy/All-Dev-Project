import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  CreditCard,
  Database,
  Download,
  FileText,
  Gauge,
  Layers,
  LockKeyhole,
  PackageCheck,
  Server,
  ShieldCheck,
  Sparkles,
  Users,
  type LucideIcon,
} from "lucide-react";

type ModuleAccess = {
  name: string;
  status: "Active" | "Limited" | "Disabled";
  used?: number;
  limit?: number;
};

type BillingItem = {
  label: string;
  date: string;
  amount: string;
  status: "Paid" | "Due" | "Pending";
};

type PlanPayload = {
  tenantName: string;
  packageName: string;
  packageType: string;
  status: "Active" | "Trial" | "Expired" | "Suspended";
  renewalDate: string;
  billingCycle: string;
  users: number;
  maxUsers: number;
  patients: number;
  maxPatients: number;
  storageUsed: number;
  storageLimit: number;
  modules: ModuleAccess[];
  billing: BillingItem[];
};

const mockPlan: PlanPayload = {
  tenantName: "CareBridge Clinic",
  packageName: "Clinic ERP Pro",
  packageType: "Clinic SaaS Package",
  status: "Active",
  renewalDate: "30 Jun 2026",
  billingCycle: "Monthly",
  users: 12,
  maxUsers: 25,
  patients: 842,
  maxPatients: 2000,
  storageUsed: 38,
  storageLimit: 100,
  modules: [
    { name: "Appointment Management", status: "Active", used: 186, limit: 500 },
    { name: "Patient Records", status: "Active", used: 842, limit: 2000 },
    { name: "Prescription Workflow", status: "Active", used: 427, limit: 1000 },
    { name: "Billing & Payments", status: "Active", used: 92, limit: 300 },
    { name: "Website CMS", status: "Active", used: 18, limit: 50 },
    { name: "SMS Wallet", status: "Limited", used: 640, limit: 1000 },
    { name: "Diagnostic Add-on", status: "Limited", used: 21, limit: 100 },
    { name: "Hospital IPD Shell", status: "Disabled", used: 0, limit: 0 },
  ],
  billing: [
    {
      label: "Current subscription",
      date: "01 Jun 2026",
      amount: "৳ 4,500",
      status: "Paid",
    },
    {
      label: "SMS wallet top-up",
      date: "12 Jun 2026",
      amount: "৳ 1,000",
      status: "Paid",
    },
    {
      label: "Next renewal invoice",
      date: "30 Jun 2026",
      amount: "৳ 4,500",
      status: "Due",
    },
  ],
};

const stackItems = [
  {
    label: "Frontend",
    value: "Clinic UI",
    icon: Layers,
  },
  {
    label: "Backend API",
    value: "/api/clinic/my-plan",
    icon: Server,
  },
  {
    label: "Database",
    value: "Tenant + billing",
    icon: Database,
  },
  {
    label: "Access",
    value: "Login + roles",
    icon: LockKeyhole,
  },
];

const statusClass: Record<string, string> = {
  Active: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Trial: "border-blue-200 bg-blue-50 text-blue-700",
  Expired: "border-rose-200 bg-rose-50 text-rose-700",
  Suspended: "border-amber-200 bg-amber-50 text-amber-700",
  Limited: "border-amber-200 bg-amber-50 text-amber-700",
  Disabled: "border-slate-200 bg-slate-50 text-slate-500",
  Paid: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Due: "border-rose-200 bg-rose-50 text-rose-700",
  Pending: "border-amber-200 bg-amber-50 text-amber-700",
};

const percent = (used: number, limit: number) => {
  if (!limit) return 0;
  return Math.min(100, Math.round((used / limit) * 100));
};

const loadPlan = async (): Promise<PlanPayload> => {
  try {
    const response = await fetch("/api/clinic/my-plan", {
      method: "GET",
      headers: { Accept: "application/json" },
      credentials: "include",
    });

    if (!response.ok) return mockPlan;

    const data = (await response.json()) as Partial<PlanPayload>;

    return {
      ...mockPlan,
      ...data,
      modules: Array.isArray(data.modules) ? data.modules : mockPlan.modules,
      billing: Array.isArray(data.billing) ? data.billing : mockPlan.billing,
    };
  } catch {
    return mockPlan;
  }
};

const StatusBadge = ({ status }: { status: string }) => (
  <span
    className={[
      "inline-flex border px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.12em]",
      statusClass[status] ?? "border-slate-200 bg-slate-50 text-slate-600",
    ].join(" ")}
  >
    {status}
  </span>
);

const Panel = ({
  eyebrow,
  title,
  icon: Icon,
  children,
}: {
  eyebrow: string;
  title: string;
  icon: LucideIcon;
  children: ReactNode;
}) => (
  <section className="border border-teal-100 bg-white/88 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
    <div className="mb-3 flex items-center justify-between gap-3 border-b border-slate-100 pb-3">
      <div>
        <p className="text-[9px] font-black uppercase tracking-[0.17em] text-teal-700">
          {eyebrow}
        </p>
        <h2 className="mt-1 text-lg font-black tracking-tight text-slate-950">
          {title}
        </h2>
      </div>

      <Icon size={20} strokeWidth={1.8} className="text-teal-700" />
    </div>

    {children}
  </section>
);

const MetricCard = ({
  label,
  value,
  helper,
  icon: Icon,
}: {
  label: string;
  value: string;
  helper: string;
  icon: LucideIcon;
}) => (
  <div className="group border border-teal-100 bg-white/90 p-3 shadow-[0_12px_34px_rgba(15,23,42,0.045)] transition-all duration-300 hover:-translate-y-0.5 hover:border-teal-200 hover:bg-white">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
          {label}
        </p>
        <p className="mt-1.5 truncate text-2xl font-black leading-none text-slate-950">
          {value}
        </p>
        <p className="mt-1 truncate text-[11px] font-bold text-slate-500">
          {helper}
        </p>
      </div>

      <Icon
        size={20}
        strokeWidth={1.8}
        className="shrink-0 text-teal-700 transition-all duration-300 group-hover:-translate-y-0.5"
      />
    </div>
  </div>
);

const ProgressBar = ({ value }: { value: number }) => (
  <div className="mt-2 h-1.5 border border-teal-100 bg-slate-50">
    <div
      className="h-full bg-teal-700 transition-all duration-500"
      style={{ width: `${value}%` }}
    />
  </div>
);

const StackInfoCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="group border border-teal-100 bg-slate-50/80 p-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-teal-200 hover:bg-white">
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="truncate text-[9px] font-black uppercase tracking-[0.15em] text-teal-700">
          {label}
        </p>
        <p className="mt-1 truncate text-[11px] font-bold text-slate-500">
          {value}
        </p>
      </div>

      <Icon
        size={18}
        strokeWidth={1.8}
        className="shrink-0 text-slate-400 transition-all duration-300 group-hover:text-teal-700"
      />
    </div>
  </div>
);

const ActionButton = ({
  to,
  label,
  icon: Icon,
}: {
  to: string;
  label: string;
  icon: LucideIcon;
}) => (
  <Link
    to={to}
    className="group flex items-center justify-between border border-slate-100 bg-slate-50/80 px-3 py-2.5 text-xs font-black text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-teal-200 hover:bg-white hover:text-teal-800"
  >
    <span className="inline-flex items-center gap-2">
      <Icon size={15} />
      {label}
    </span>
    <ArrowRight
      size={14}
      className="transition-transform duration-300 group-hover:translate-x-1"
    />
  </Link>
);

const ClinicMyPlanPage = () => {
  const [plan, setPlan] = useState<PlanPayload>(mockPlan);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    loadPlan().then((data) => {
      if (!active) return;
      setPlan(data);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, []);

  const usageMetrics = useMemo(
    () => [
      {
        label: "Users",
        value: `${plan.users}/${plan.maxUsers}`,
        helper: `${percent(plan.users, plan.maxUsers)}% used`,
        icon: Users,
      },
      {
        label: "Patients",
        value: `${plan.patients}/${plan.maxPatients}`,
        helper: `${percent(plan.patients, plan.maxPatients)}% limit`,
        icon: Activity,
      },
      {
        label: "Storage",
        value: `${plan.storageUsed}GB`,
        helper: `${plan.storageLimit}GB total`,
        icon: Database,
      },
      {
        label: "Renewal",
        value: plan.renewalDate,
        helper: plan.billingCycle,
        icon: CalendarClock,
      },
    ],
    [plan],
  );

  const activeModules = plan.modules.filter((item) => item.status !== "Disabled");
  const disabledModules = plan.modules.filter((item) => item.status === "Disabled");

  return (
    <main className="min-h-svh bg-[#f6faf9] text-slate-950">
      <section className="mx-auto max-w-7xl px-4 py-6">
        <div className="mb-4 border border-teal-100 bg-white/88 p-4 shadow-[0_14px_42px_rgba(15,23,42,0.05)] backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-teal-700">
                Clinic Panel
              </p>
              <h1 className="mt-1.5 text-3xl font-black tracking-tight text-slate-950">
                My plan
              </h1>
              <p className="mt-1.5 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
                Current tenant package, module access, usage limits and renewal
                status.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Link
                to="/demo"
                className="group inline-flex items-center gap-2 border border-teal-100 bg-white px-3.5 py-2.5 text-xs font-black text-teal-800 transition-all duration-300 hover:-translate-y-0.5 hover:border-teal-200"
              >
                Demo routes
                <ArrowRight
                  size={14}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>

              <Link
                to="/book-demo"
                className="group inline-flex items-center gap-2 border border-teal-700 bg-teal-700 px-3.5 py-2.5 text-xs font-black text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
              >
                Book demo
                <ArrowRight
                  size={14}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
            </div>
          </div>

          <div className="mt-4 border border-teal-100 bg-teal-50/70 px-3 py-2">
            <p className="text-[11px] font-black text-teal-800">
              {loading
                ? "Loading tenant plan from backend API..."
                : "Backend ready: /api/clinic/my-plan connected with safe fallback."}
            </p>
          </div>
        </div>

        <div className="grid gap-3 xl:grid-cols-[1.15fr_0.85fr]">
          <Panel
            eyebrow="Tenant Package"
            title="Subscription overview"
            icon={PackageCheck}
          >
            <div className="grid gap-3 md:grid-cols-2">
              <div className="border border-slate-100 bg-slate-50/80 p-3">
                <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
                  Tenant
                </p>
                <p className="mt-1.5 truncate text-lg font-black text-slate-950">
                  {plan.tenantName}
                </p>
                <p className="mt-1 truncate text-[11px] font-bold text-slate-500">
                  {plan.packageType}
                </p>
              </div>

              <div className="border border-slate-100 bg-slate-50/80 p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[9px] font-black uppercase tracking-[0.15em] text-slate-400">
                      Current Package
                    </p>
                    <p className="mt-1.5 truncate text-lg font-black text-slate-950">
                      {plan.packageName}
                    </p>
                    <p className="mt-1 truncate text-[11px] font-bold text-slate-500">
                      Renewal: {plan.renewalDate}
                    </p>
                  </div>

                  <StatusBadge status={plan.status} />
                </div>
              </div>
            </div>

            <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
              {stackItems.map((item) => (
                <StackInfoCard key={item.label} {...item} />
              ))}
            </div>
          </Panel>

          <Panel eyebrow="Quick Actions" title="Plan controls" icon={Sparkles}>
            <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
              <ActionButton
                label="Upgrade package"
                to="/pricing"
                icon={PackageCheck}
              />
              <ActionButton
                label="Renew subscription"
                to="/clinic/payments"
                icon={CreditCard}
              />
              <ActionButton
                label="Export usage report"
                to="/clinic/reports"
                icon={Download}
              />
              <ActionButton
                label="Access settings"
                to="/clinic/settings"
                icon={ShieldCheck}
              />
            </div>
          </Panel>
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {usageMetrics.map((item) => (
            <MetricCard key={item.label} {...item} />
          ))}
        </div>

        <div className="mt-3 grid gap-3 xl:grid-cols-[1.15fr_0.85fr]">
          <Panel eyebrow="Module Access" title="Allowed modules" icon={Gauge}>
            <div className="grid gap-2 lg:grid-cols-2">
              {activeModules.map((module) => {
                const progress = percent(module.used ?? 0, module.limit ?? 0);

                return (
                  <div
                    key={module.name}
                    className="border border-slate-100 bg-slate-50/80 p-3 transition-all duration-300 hover:border-teal-200 hover:bg-white"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-black text-slate-950">
                          {module.name}
                        </p>
                        <p className="mt-1 text-[11px] font-bold text-slate-500">
                          {module.used ?? 0}/{module.limit ?? 0} usage
                        </p>
                      </div>

                      <StatusBadge status={module.status} />
                    </div>

                    <ProgressBar value={progress} />
                  </div>
                );
              })}

              {disabledModules.length > 0 && (
                <div className="border border-slate-100 bg-slate-50/80 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-black text-slate-950">
                        Disabled Add-ons
                      </p>
                      <p className="mt-1 text-[11px] font-bold leading-5 text-slate-500">
                        {disabledModules.map((item) => item.name).join(", ")}
                      </p>
                    </div>

                    <StatusBadge status="Disabled" />
                  </div>
                </div>
              )}
            </div>
          </Panel>

          <Panel eyebrow="Billing" title="Renewal ledger" icon={FileText}>
            <div className="grid gap-2">
              {plan.billing.map((item) => (
                <div
                  key={`${item.label}-${item.date}`}
                  className="border border-slate-100 bg-slate-50/80 p-3 transition-all duration-300 hover:border-teal-200 hover:bg-white"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-black text-slate-950">
                        {item.label}
                      </p>
                      <p className="mt-1 text-[11px] font-bold text-slate-500">
                        {item.date}
                      </p>
                    </div>

                    <StatusBadge status={item.status} />
                  </div>

                  <p className="mt-2 text-xl font-black text-slate-950">
                    {item.amount}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-3 border border-teal-100 bg-teal-50/70 p-3">
              <div className="flex items-start gap-2">
                <CheckCircle2 size={17} className="mt-0.5 text-teal-700" />
                <div>
                  <p className="text-xs font-black text-teal-900">
                    Backend login remains protected
                  </p>
                  <p className="mt-1 text-[11px] font-bold leading-5 text-teal-800/70">
                    This page reads plan data only. Existing login, session and
                    protected clinic routes are not changed.
                  </p>
                </div>
              </div>
            </div>
          </Panel>
        </div>
      </section>
    </main>
  );
};

export default ClinicMyPlanPage;