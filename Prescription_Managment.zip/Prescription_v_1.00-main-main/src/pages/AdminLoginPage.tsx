import { LockKeyhole, Stethoscope } from "lucide-react";
import { useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { ADMIN_CREDENTIALS, isAdminLoggedIn, loginAdminRemote, loginAdmin } from "../lib/adminAuth";

const AdminLoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const labelClass = "grid gap-1.5 text-sm font-extrabold text-slate-600";
  const fieldClass =
    "w-full rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100";

  if (isAdminLoggedIn()) {
    return <Navigate to="/doctor/dashboard" replace />;
  }

  const submit = async (event) => {
    event.preventDefault();
    setError("");

    try {
      await loginAdminRemote(form);
      navigate(location.state?.from || "/doctor/dashboard", { replace: true });
    } catch {
      const ok = loginAdmin(form);
      if (!ok) {
        setError("Invalid username or password.");
        return;
      }
      navigate(location.state?.from || "/doctor/dashboard", { replace: true });
    }
  };

  return (
    <main className="grid min-h-svh place-items-center bg-gradient-to-br from-cyan-50 via-white to-teal-50 p-4">
      <section className="w-[min(440px,100%)] rounded-[1.75rem] border border-teal-100 bg-white/85 p-5 shadow-[0_20px_55px_rgba(13,78,86,0.12)] backdrop-blur-xl">
        <div className="mb-5 flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-r from-teal-700 to-cyan-500 text-white">
            <Stethoscope size={20} />
          </span>
          <div>
            <p className="text-sm font-black text-slate-500">CareBridge Admin</p>
            <h1 className="text-2xl font-black tracking-tight text-slate-900">
              Doctor Panel Login
            </h1>
          </div>
        </div>
        <form className="grid gap-4" onSubmit={submit}>
          <label className={labelClass}>
            Username
            <input
              className={fieldClass}
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              autoComplete="username"
              placeholder={ADMIN_CREDENTIALS.username}
            />
          </label>
          <label className={labelClass}>
            Password
            <input
              className={fieldClass}
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              autoComplete="current-password"
              placeholder={ADMIN_CREDENTIALS.password}
            />
          </label>
          {error ? <p className="text-sm font-extrabold text-red-600">{error}</p> : null}
          <button
            type="submit"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-cyan-300"
          >
            <LockKeyhole size={18} />
            Login to Panel
          </button>
        </form>
        <p className="mt-4 text-sm font-semibold text-slate-500">
          Configured admin login. Demo fallback: {ADMIN_CREDENTIALS.username} / {ADMIN_CREDENTIALS.password}
        </p>
      </section>
    </main>
  );
};

export default AdminLoginPage;
