import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  ImagePlus,
  Images,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";
import CmsEmptyState from "../components/cms/CmsEmptyState";
import CmsSectionCard from "../components/cms/CmsSectionCard";
import CmsTextInput from "../components/cms/CmsTextInput";
import CmsTextarea from "../components/cms/CmsTextarea";
import CmsToolbar from "../components/cms/CmsToolbar";
import {
  getPublicGallery,
  loadPublicContent,
  savePublicContent,
  savePublicGallery,
  uploadPublicFile,
} from "../publicSite/lib/publicStorage";

const MAX_IMAGE_SIZE = 2.5 * 1024 * 1024;

const getBlankForm = () => ({
  title: "",
  imageUrl: "",
  category: "Chamber",
  description: "",
});

const categoryOptions = [
  "Chamber",
  "Awareness",
  "Clinic",
  "Doctor",
  "Patient Care",
  "Medical Event",
  "Education",
  "Other",
];

const selectClass =
  "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100";

const iconClass =
  "shrink-0 text-teal-700 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3";

const shortText = (text, limit = 85) => {
  const value = String(text || "").trim();
  if (value.length <= limit) return value;
  return `${value.slice(0, limit)}...`;
};

const hasFormData = (form) => {
  return Boolean(
    form.title?.trim() ||
      form.imageUrl?.trim() ||
      form.category?.trim() ||
      form.description?.trim()
  );
};

const readFileAsDataUrl = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Image read failed."));
    reader.readAsDataURL(file);
  });
};

const notifyPublicGalleryUpdated = (gallery) => {
  if (typeof window === "undefined") return;

  window.dispatchEvent(
    new CustomEvent("public-gallery-updated", {
      detail: gallery,
    })
  );

  window.dispatchEvent(
    new CustomEvent("public-content-updated", {
      detail: {
        key: "gallery",
        value: gallery,
      },
    })
  );
};

const normalizeGalleryItem = (item) => ({
  ...item,
  id: item.id || `gallery-${Date.now()}-${Math.random().toString(16).slice(2)}`,
  title: item.title || "",
  imageUrl: item.imageUrl || item.coverImageUrl || "",
  category: item.category || "Other",
  description: item.description || "",
});

const SelectInput = ({ label, value, onChange, options }) => (
  <label className="grid gap-1.5">
    <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
      {label}
    </span>

    <select
      value={value || ""}
      onChange={(event) => onChange(event.target.value)}
      className={selectClass}
    >
      {options.map((item) => (
        <option key={item} value={item}>
          {item}
        </option>
      ))}
    </select>
  </label>
);

const GalleryImageUpload = ({ value, onChange, onNotice }) => {
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file) => {
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      onNotice("Only image file allowed.");
      return;
    }

    if (file.size > MAX_IMAGE_SIZE) {
      onNotice("Image size must be under 2.5MB.");
      return;
    }

    try {
      setUploading(true);

      try {
        const uploaded = await uploadPublicFile(file);

        if (uploaded?.url) {
          onChange(uploaded.url);
          onNotice("Gallery image uploaded successfully.");
          return;
        }
      } catch {
        // fallback below
      }

      const dataUrl = await readFileAsDataUrl(file);
      onChange(dataUrl);
      onNotice("Gallery image added from device.");
    } catch (error) {
      onNotice(error.message || "Image upload failed.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3">
      <div className="group mb-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ImagePlus size={18} className={iconClass} />
          <div>
            <p className="text-sm font-black text-slate-950">Gallery Image</p>
            <p className="text-xs font-semibold text-slate-500">
              Device upload, drag/drop or direct image URL.
            </p>
          </div>
        </div>

        {value ? (
          <button
            type="button"
            onClick={() => {
              onChange("");
              onNotice("Gallery image removed.");
            }}
            className="group/remove text-red-500 transition hover:-translate-y-0.5 hover:text-red-700"
            title="Remove image"
          >
            <X
              size={20}
              className="transition-transform duration-300 group-hover/remove:rotate-90"
            />
          </button>
        ) : null}
      </div>

      <label
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          handleFile(event.dataTransfer.files?.[0]);
        }}
        className={[
          "grid cursor-pointer place-items-center overflow-hidden rounded-2xl border border-dashed p-3 text-center transition",
          dragging
            ? "border-cyan-500 bg-cyan-50"
            : "border-slate-300 bg-slate-50 hover:border-cyan-400 hover:bg-cyan-50",
        ].join(" ")}
      >
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(event) => handleFile(event.target.files?.[0])}
        />

        {value ? (
          <img
            src={value}
            alt="Gallery preview"
            className="h-52 w-full rounded-xl object-cover"
          />
        ) : (
          <span className="grid min-h-44 place-items-center gap-2">
            <UploadCloud
              size={38}
              className="text-cyan-700 transition-transform duration-300 hover:-translate-y-1"
            />
            <span className="text-sm font-black text-slate-800">
              {uploading ? "Uploading image..." : "Click or drop image here"}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              JPG / PNG / WEBP, max 2.5MB
            </span>
          </span>
        )}
      </label>

      <div className="mt-3">
        <CmsTextInput
          label="Image URL / uploaded data"
          value={value || ""}
          onChange={(nextValue) => {
            onChange(nextValue);
            if (nextValue) onNotice("Gallery image URL updated.");
          }}
        />
      </div>
    </div>
  );
};

const GalleryCard = ({ item, onEdit, onDelete }) => (
  <article className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-md">
    <div className="relative h-44 bg-slate-100">
      {item.imageUrl ? (
        <img
          src={item.imageUrl}
          alt={item.title}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="grid h-full place-items-center text-slate-300">
          <Images size={38} />
        </div>
      )}

      <div className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[11px] font-black uppercase tracking-wider text-teal-700 shadow-sm backdrop-blur">
        {item.category || "Gallery"}
      </div>
    </div>

    <div className="grid gap-2 p-4">
      <div>
        <h3 className="text-base font-black leading-6 text-slate-950">
          {item.title || "Untitled Gallery Image"}
        </h3>
        <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
          {shortText(item.description, 95) || "No description added."}
        </p>
      </div>

      <div className="flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-3">
        <button
          type="button"
          onClick={onEdit}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-700 transition hover:bg-slate-50"
        >
          <Pencil size={14} />
          Edit
        </button>

        <button
          type="button"
          onClick={onDelete}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 text-xs font-black text-red-700 transition hover:bg-red-100"
        >
          <Trash2 size={14} />
          Delete
        </button>
      </div>
    </div>
  </article>
);

const GalleryModal = ({
  open,
  form,
  editingId,
  saved,
  saving,
  lockNotice,
  update,
  save,
  resetForm,
  closeModal,
  setLockNotice,
  setNotice,
}) => {
  if (!open) return null;

  const dirty = hasFormData(form);

  const handleBackdropClose = () => {
    if (dirty) {
      setLockNotice(true);
      setTimeout(() => setLockNotice(false), 1800);
      return;
    }

    closeModal();
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-slate-950/55 p-4 backdrop-blur-sm"
      onMouseDown={handleBackdropClose}
    >
      <div
        className="max-h-[92vh] w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 p-5">
          <div className="group flex min-w-0 items-start gap-3">
            <Images size={26} className={iconClass} />
            <div className="min-w-0">
              <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-600">
                Gallery Manager
              </p>
              <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
                {editingId ? "Edit Gallery Image" : "Add Gallery Image"}
              </h2>
              <p className="mt-1 text-sm font-semibold text-slate-500">
                Upload image and publish it to public chamber gallery.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={closeModal}
            className="group/close text-slate-400 transition hover:-translate-y-0.5 hover:text-red-600"
            title="Close"
          >
            <X
              size={28}
              strokeWidth={2.4}
              className="transition-transform duration-300 group-hover/close:rotate-90"
            />
          </button>
        </div>

        {lockNotice ? (
          <div className="mx-5 mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-bold text-amber-700">
            Form-e data ache. Outside click করলে popup close হবে না. Save,
            Clear, Cancel অথবা cross button use করো.
          </div>
        ) : null}

        <div className="grid max-h-[70vh] gap-4 overflow-y-auto p-5 xl:grid-cols-[0.95fr_1.05fr]">
          <div className="grid content-start gap-3">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-1">
              <CmsTextInput
                label="Title"
                value={form.title}
                onChange={(v) => update("title", v)}
              />

              <SelectInput
                label="Category"
                value={form.category}
                onChange={(v) => update("category", v)}
                options={categoryOptions}
              />
            </div>

            <CmsTextarea
              label="Description"
              value={form.description}
              onChange={(v) => update("description", v)}
              rows={6}
            />
          </div>

          <GalleryImageUpload
            value={form.imageUrl}
            onChange={(v) => update("imageUrl", v)}
            onNotice={setNotice}
          />
        </div>

        <div className="flex flex-wrap justify-between gap-2 border-t border-slate-100 bg-slate-50 p-4">
          <button
            type="button"
            onClick={resetForm}
            className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-100"
          >
            <X size={16} />
            Clear
          </button>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={closeModal}
              className="h-11 rounded-2xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-100"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={save}
              disabled={saving}
              className={[
                "inline-flex h-11 items-center gap-2 rounded-2xl px-5 text-sm font-black text-white transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-70",
                saved
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-slate-950 hover:bg-slate-800",
              ].join(" ")}
            >
              {saved ? <CheckCircle2 size={16} /> : <Save size={16} />}
              {saving
                ? "Saving..."
                : saved
                  ? "Saved"
                  : editingId
                    ? "Update Image"
                    : "Save Image"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const DoctorGalleryManagerPage = () => {
  const [gallery, setGallery] = useState(() =>
    getPublicGallery().map((item) => normalizeGalleryItem(item))
  );
  const [form, setForm] = useState(getBlankForm);
  const [editingId, setEditingId] = useState(null);
  const [saved, setSaved] = useState(false);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [lockNotice, setLockNotice] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    let alive = true;

    loadPublicContent("gallery", getPublicGallery())
      .then((data) => {
        if (!alive) return;

        const next = Array.isArray(data)
          ? data.map((item) => normalizeGalleryItem(item))
          : [];

        setGallery(next);
        savePublicGallery(next);
        notifyPublicGalleryUpdated(next);
      })
      .catch(() => {
        setNotice("Remote gallery load failed. Local gallery is showing.");
      });

    const syncGallery = () => {
      const latest = getPublicGallery().map((item) =>
        normalizeGalleryItem(item)
      );
      setGallery(latest);
    };

    window.addEventListener("storage", syncGallery);
    window.addEventListener("public-gallery-updated", syncGallery);
    window.addEventListener("public-content-updated", syncGallery);

    return () => {
      alive = false;
      window.removeEventListener("storage", syncGallery);
      window.removeEventListener("public-gallery-updated", syncGallery);
      window.removeEventListener("public-content-updated", syncGallery);
    };
  }, []);

  useEffect(() => {
    if (!saved && !notice) return;

    const timeoutId = window.setTimeout(() => {
      setSaved(false);
      setNotice("");
    }, 2200);

    return () => window.clearTimeout(timeoutId);
  }, [saved, notice]);

  const persist = async (next) => {
    const normalizedNext = next.map((item) => normalizeGalleryItem(item));

    setGallery(normalizedNext);
    savePublicGallery(normalizedNext);
    notifyPublicGalleryUpdated(normalizedNext);

    try {
      const savedData = await savePublicContent("gallery", normalizedNext);
      const normalizedSaved = Array.isArray(savedData)
        ? savedData.map((item) => normalizeGalleryItem(item))
        : normalizedNext;

      setGallery(normalizedSaved);
      savePublicGallery(normalizedSaved);
      notifyPublicGalleryUpdated(normalizedSaved);

      return normalizedSaved;
    } catch {
      return normalizedNext;
    }
  };

  const update = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const resetForm = () => {
    setForm(getBlankForm());
    setEditingId(null);
    setSaved(false);
    setLockNotice(false);
  };

  const openAddModal = () => {
    resetForm();
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    resetForm();
  };

  const stats = useMemo(() => {
    const categories = new Set(
      gallery.map((item) => item.category).filter(Boolean)
    );

    return {
      total: gallery.length,
      categories: categories.size,
    };
  }, [gallery]);

  const filteredGallery = useMemo(() => {
    const keyword = query.trim().toLowerCase();

    return gallery.filter((item) => {
      const matchesCategory =
        categoryFilter === "all" ? true : item.category === categoryFilter;

      const matchesSearch = keyword
        ? [item.title, item.category, item.description]
            .join(" ")
            .toLowerCase()
            .includes(keyword)
        : true;

      return matchesCategory && matchesSearch;
    });
  }, [gallery, query, categoryFilter]);

  const save = async () => {
    const title = form.title.trim();
    const imageUrl = form.imageUrl.trim();

    if (!title) {
      setNotice("Gallery title is required.");
      return;
    }

    if (!imageUrl) {
      setNotice("Gallery image is required.");
      return;
    }

    const item = normalizeGalleryItem({
      ...form,
      title,
      imageUrl,
      category: form.category || "Other",
      id: editingId || `gallery-${Date.now()}`,
    });

    const next = editingId
      ? gallery.map((entry) => (entry.id === editingId ? item : entry))
      : [item, ...gallery];

    try {
      setSaving(true);
      await persist(next);
      setSaved(true);
      setNotice(
        editingId
          ? "Gallery image updated successfully."
          : "Gallery image uploaded successfully."
      );

      setTimeout(() => {
        setSaved(false);
        setModalOpen(false);
        resetForm();
      }, 700);
    } catch (error) {
      setNotice(error.message || "Gallery item could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  const editItem = (item) => {
    setEditingId(item.id);
    setForm({
      ...getBlankForm(),
      ...item,
    });
    setSaved(false);
    setLockNotice(false);
    setModalOpen(true);
  };

  const deleteItem = async (id) => {
    const confirmed = window.confirm("Delete this gallery item?");
    if (!confirmed) return;

    try {
      setSaving(true);
      await persist(gallery.filter((entry) => entry.id !== id));
      setSaved(true);
      setNotice("Gallery image deleted successfully.");
    } catch (error) {
      setNotice(error.message || "Gallery item could not be deleted.");
    } finally {
      setSaving(false);
    }

    if (editingId === id) {
      closeModal();
    }
  };

  return (
    <section className="mx-auto grid max-w-7xl gap-3">
      <CmsToolbar
        title="Gallery Manager"
        description={
          notice ||
          "Add chamber photos, awareness images, doctor media and public gallery items."
        }
        action={
          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-cyan-300"
          >
            <Plus size={16} />
            Add Item
          </button>
        }
      />

      {notice ? (
        <div
          className={[
            "flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-black",
            notice.toLowerCase().includes("failed") ||
            notice.toLowerCase().includes("required")
              ? "border border-red-100 bg-red-50 text-red-700"
              : "border border-emerald-100 bg-emerald-50 text-emerald-700",
          ].join(" ")}
        >
          <CheckCircle2 size={16} />
          {notice}
        </div>
      ) : null}

      <div className="grid gap-2 sm:grid-cols-2">
        <div className="rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-cyan-700">
            Total Images
          </p>
          <p className="mt-1 text-xl font-black text-slate-950">
            {stats.total}
          </p>
        </div>

        <div className="rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
            Categories
          </p>
          <p className="mt-1 text-xl font-black text-emerald-700">
            {stats.categories}
          </p>
        </div>
      </div>

      <CmsSectionCard title="Gallery Items">
        <div className="mb-4 flex flex-col gap-3 border-b border-slate-100 pb-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="group flex items-center gap-2">
            <ImagePlus size={18} className={iconClass} />
            <div>
              <h3 className="text-base font-black text-slate-950">
                Public Gallery Grid
              </h3>
              <p className="text-xs font-semibold text-slate-500">
                Add Item click করে device থেকে image upload করো।
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="relative min-w-0 sm:w-72">
              <Search
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search gallery..."
                className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
              />
            </div>

            <select
              value={categoryFilter}
              onChange={(event) => setCategoryFilter(event.target.value)}
              className={selectClass}
            >
              <option value="all">All Category</option>
              {categoryOptions.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid max-h-[760px] gap-3 overflow-y-auto pr-1 md:grid-cols-2 xl:grid-cols-3">
          {filteredGallery.length ? (
            filteredGallery.map((item) => (
              <GalleryCard
                key={item.id}
                item={item}
                onEdit={() => editItem(item)}
                onDelete={() => deleteItem(item.id)}
              />
            ))
          ) : (
            <div className="md:col-span-2 xl:col-span-3">
              <CmsEmptyState
                title="No gallery items"
                message="Click Add Item and upload the first gallery image."
              />
            </div>
          )}
        </div>
      </CmsSectionCard>

      <GalleryModal
        open={modalOpen}
        form={form}
        editingId={editingId}
        saved={saved}
        saving={saving}
        lockNotice={lockNotice}
        update={update}
        save={save}
        resetForm={resetForm}
        closeModal={closeModal}
        setLockNotice={setLockNotice}
        setNotice={setNotice}
      />
    </section>
  );
};

export default DoctorGalleryManagerPage;