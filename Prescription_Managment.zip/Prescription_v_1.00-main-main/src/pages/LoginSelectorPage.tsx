import PageHeader from "../components/common/PageHeader";
import RouteCard from "../components/common/RouteCard";

const LoginSelectorPage = () => (
  <main className="mx-auto max-w-5xl px-4 py-10">
    <PageHeader eyebrow="Login" title="Choose a demo workspace" description="Open role-specific demo panels without a backend login during this frontend visibility step." />
    <div className="mt-6 grid gap-3 sm:grid-cols-3">
      <RouteCard title="Super Admin" description="SaaS owner panel" to="/super-admin/dashboard" />
      <RouteCard title="Clinic Owner" description="Clinic operations panel" to="/clinic/dashboard" />
      <RouteCard title="Doctor / Staff" description="Existing doctor panel" to="/doctor/dashboard" />
    </div>
  </main>
);

export default LoginSelectorPage;
