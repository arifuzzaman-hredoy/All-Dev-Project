import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicWebsiteCmsPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Website CMS"
    description="Preview clinic website content controls, sections and publishing status."
  />
);

export default ClinicWebsiteCmsPage;
