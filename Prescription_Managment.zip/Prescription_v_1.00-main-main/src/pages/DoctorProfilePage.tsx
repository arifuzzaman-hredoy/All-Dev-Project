import type { ChangeEvent } from "react";
import { useEffect, useState } from "react";
import { Camera, Check, Clock3, Plus, Trash2, X } from "lucide-react";
import ChamberScheduleCard from "../components/profile/ChamberScheduleCard";
import DoctorPanelSettingsCard from "../components/profile/DoctorPanelSettingsCard";
import DoctorProfileCard from "../components/profile/DoctorProfileCard";
import EditProfileForm from "../components/profile/EditProfileForm";
import ProfileInfoSection from "../components/profile/ProfileInfoSection";
import { doctorInfo } from "../data/mockData";
import {
  getDoctorIdentity,
  updateDoctorIdentity,
  uploadDoctorIdentityPhoto,
} from "../services/doctorIdentityApi";

type ActiveModal = "photo" | "schedule" | null;

type Schedule = {
  day: string;
  hours: string;
};

type ScheduleDraftSlot = {
  id: string;
  day: string;
  start: string;
  end: string;
  mode: string;
};

type ProfileForm = {
  name: string;
  department: string;
  specialization: string;
  consultationHours: string;
  sessionStart: string;
  sessionEnd: string;
  mode: string;
};

const createScheduleDraft = (schedule: Schedule[]): ScheduleDraftSlot[] =>
  schedule.map((slot, index) => ({
    id: `${slot.day}-${index}`,
    day: slot.day,
    start: "09:00",
    end: "13:00",
    mode: "In-person",
  }));

const formatTime = (value: string) => {
  if (!value) return "";

  const [hourValue, minute] = value.split(":");
  const hour = Number(hourValue);
  const period = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;

  return `${displayHour}:${minute} ${period}`;
};

const formatSlotHours = (slot: ScheduleDraftSlot) =>
  `${formatTime(slot.start)} - ${formatTime(slot.end)}${
    slot.mode ? ` • ${slot.mode}` : ""
  }`;

const DoctorProfilePage = () => {
  const [profilePhoto, setProfilePhoto] = useState(doctorInfo.photo);
  const [identityData, setIdentityData] = useState(null);
  const [selectedPhotoFile, setSelectedPhotoFile] = useState<File | null>(null);
  const [schedule, setSchedule] = useState<Schedule[]>(doctorInfo.schedule);
  const [scheduleSlots, setScheduleSlots] = useState(() =>
    createScheduleDraft(doctorInfo.schedule),
  );
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [photoPreview, setPhotoPreview] = useState(doctorInfo.photo);
  const [scheduleDraft, setScheduleDraft] = useState(() =>
    createScheduleDraft(doctorInfo.schedule),
  );
  const [form, setForm] = useState<ProfileForm>({
    name: doctorInfo.name,
    department: doctorInfo.department,
    specialization: doctorInfo.specialization,
    consultationHours: "09:00 AM - 01:00 PM",
    sessionStart: "09:00",
    sessionEnd: "13:00",
    mode: "In-person",
  });

  useEffect(() => {
    getDoctorIdentity()
      .then((identity) => {
        setIdentityData(identity);
        const scheduleText = identity.consultationHours || identity.visitingTime || "09:00 AM - 01:00 PM";
        setProfilePhoto(identity.profilePhotoUrl || doctorInfo.photo);
        setPhotoPreview(identity.profilePhotoUrl || doctorInfo.photo);
        setSchedule([
          {
            day: identity.scheduleText || identity.visitingDays || "Sun - Tue",
            hours: scheduleText,
          },
        ]);
        setForm({
          name: identity.doctorName || doctorInfo.name,
          department: identity.department || identity.designation || doctorInfo.department,
          specialization: identity.specialization || doctorInfo.specialization,
          consultationHours: scheduleText,
          sessionStart: identity.startTime || "09:00",
          sessionEnd: identity.endTime || "13:00",
          mode: identity.consultationMode || "In-person",
        });
      })
      .catch(() => null);
  }, []);

  const updateForm = (key: keyof ProfileForm, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const openPhotoModal = () => {
    setPhotoPreview(profilePhoto);
    setActiveModal("photo");
  };

  const openScheduleModal = () => {
    setScheduleDraft(scheduleSlots);
    setActiveModal("schedule");
  };

  const handlePhotoFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setSelectedPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const readPhotoDataUrl = (file: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(new Error("Could not read photo."));
      reader.readAsDataURL(file);
    });

  const handleSavePhoto = async () => {
    try {
      if (selectedPhotoFile) {
        const dataUrl = await readPhotoDataUrl(selectedPhotoFile);
        const result = await uploadDoctorIdentityPhoto({
          fileName: selectedPhotoFile.name,
          mimeType: selectedPhotoFile.type,
          dataUrl,
        });
        setProfilePhoto(result.url || result.identity.profilePhotoUrl);
        setPhotoPreview(result.url || result.identity.profilePhotoUrl);
        setIdentityData(result.identity);
      } else {
        const identity = await updateDoctorIdentity({
          profilePhotoUrl: photoPreview,
          profileImageUrl: photoPreview,
          photo: photoPreview,
        });
        setProfilePhoto(identity.profilePhotoUrl);
        setPhotoPreview(identity.profilePhotoUrl);
        setIdentityData(identity);
      }
      setSelectedPhotoFile(null);
      setActiveModal(null);
    } catch (error) {
      window.alert(error.message || "Photo save failed.");
    }
  };

  const saveIdentity = async (setup = {}) => {
    const identity = await updateDoctorIdentity({
      doctorName: form.name,
      name: form.name,
      doctorTitle: form.department,
      title: form.department,
      department: form.department,
      designation: form.department,
      specialization: form.specialization,
      qualification: form.specialization,
      profilePhotoUrl: profilePhoto,
      profileImageUrl: profilePhoto,
      photo: profilePhoto,
      consultationHours: setup.consultationHours || form.consultationHours,
      visitingTime: setup.consultationHours || form.consultationHours,
      startTime: setup.sessionStart || form.sessionStart,
      endTime: setup.sessionEnd || form.sessionEnd,
      consultationMode: form.mode,
      dailyPatientLimit: setup.dailyCapacity,
    });
    setIdentityData(identity);
  };

  const updateScheduleSlot = (
    slotId: string,
    key: keyof Omit<ScheduleDraftSlot, "id">,
    value: string
  ) => {
    setScheduleDraft((prev) =>
      prev.map((slot) =>
        slot.id === slotId ? { ...slot, [key]: value } : slot,
      ),
    );
  };

  const addScheduleSlot = () => {
    setScheduleDraft((prev) => [
      ...prev,
      {
        id: `slot-${Date.now()}`,
        day: "Sat - Thu",
        start: "09:00",
        end: "13:00",
        mode: "In-person",
      },
    ]);
  };

  const removeScheduleSlot = (slotId: string) => {
    setScheduleDraft((prev) => prev.filter((slot) => slot.id !== slotId));
  };

  const handleSaveSchedule = () => {
    const validSlots = scheduleDraft.filter(
      (slot) => slot.day.trim() && slot.start && slot.end,
    );
    const nextSchedule = validSlots.map((slot) => ({
      day: slot.day.trim(),
      hours: formatSlotHours(slot),
    }));

    setScheduleSlots(validSlots);
    setSchedule(nextSchedule);
    setForm((prev) => ({
      ...prev,
      consultationHours: nextSchedule[0]?.hours || prev.consultationHours,
      sessionStart: validSlots[0]?.start || prev.sessionStart,
      sessionEnd: validSlots[0]?.end || prev.sessionEnd,
      mode: validSlots[0]?.mode || prev.mode,
    }));
    setActiveModal(null);
  };

  const doctorProfile = {
    ...doctorInfo,
    name: form.name,
    department: form.department,
    specialization: form.specialization,
    photo: profilePhoto,
    qualification: identityData?.qualification || form.specialization,
    chamber: identityData?.chamberName || identityData?.chamberAddress || doctorInfo.chamber,
  };

  const profileRows = [
    {
      title: "Professional Details",
      rows: [
        { label: "Doctor Name", value: form.name },
        { label: "Title", value: form.department },
        { label: "Specialization", value: form.specialization },
        { label: "Qualification", value: identityData?.qualification || form.specialization },
      ],
    },
    {
      title: "Contact & Chamber",
      rows: [
        { label: "Phone", value: identityData?.phone || doctorInfo.contact },
        { label: "Email", value: identityData?.email || doctorInfo.email },
        { label: "Chamber", value: identityData?.chamberName || doctorInfo.chamber },
        { label: "Address", value: identityData?.chamberAddress || doctorInfo.chamber },
      ],
    },
  ];

  return (
    <section className="mx-auto grid max-w-7xl gap-4">
      <DoctorProfileCard doctor={doctorProfile} />
      <div className="grid gap-4 xl:grid-cols-2">
        <ProfileInfoSection
          title={profileRows[0].title}
          rows={profileRows[0].rows}
        />
        <ProfileInfoSection
          title={profileRows[1].title}
          rows={profileRows[1].rows}
        />
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <ChamberScheduleCard schedule={schedule} />
        <DoctorPanelSettingsCard />
      </div>
      <EditProfileForm
        form={form}
        onChange={updateForm}
        onChangePhoto={openPhotoModal}
        onUpdateChamberTime={openScheduleModal}
        onSave={saveIdentity}
      />

      {activeModal === "photo" && (
        <div className="fixed inset-0 z-[90] grid place-items-center bg-slate-950/35 p-4" role="presentation">
          <div
            className="w-[min(520px,100%)] rounded-[1.75rem] border border-teal-100 bg-white p-5 shadow-[0_26px_80px_rgba(6,45,49,0.25)]"
            role="dialog"
            aria-modal="true"
            aria-labelledby="photo-modal-title"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-black uppercase tracking-wide text-teal-700">Profile Photo</span>
                <h3 className="mt-1 text-2xl font-black tracking-tight text-slate-900" id="photo-modal-title">Change Profile Photo</h3>
              </div>
              <button
                type="button"
                className="grid h-9 w-9 place-items-center rounded-full bg-cyan-50 text-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
                onClick={() => setActiveModal(null)}
                aria-label="Close photo dialog"
              >
                <X size={18} />
              </button>
            </div>

            <div className="mt-5 grid gap-4">
              <img className="mx-auto h-40 w-40 rounded-[2rem] object-cover ring-1 ring-teal-100" src={photoPreview} alt="Profile preview" />
              <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-full border border-teal-100 bg-white px-4 py-3 text-sm font-black text-teal-700 shadow-sm transition hover:bg-cyan-50">
                <Camera size={17} />
                <span>Choose Photo</span>
                <input
                  className="sr-only"
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoFile}
                />
              </label>
              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Photo URL
                <input
                  className="w-full rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
                  value={photoPreview}
                  onChange={(event) => setPhotoPreview(event.target.value)}
                  placeholder="Paste image URL"
                />
              </label>
            </div>

            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button className="inline-flex min-h-11 items-center justify-center rounded-full border border-teal-100 bg-white px-5 text-sm font-black text-teal-700 shadow-sm" type="button" onClick={() => setActiveModal(null)}>
                Cancel
              </button>
              <button className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg" type="button" onClick={handleSavePhoto}>
                <Check size={16} />
                Save Photo
              </button>
            </div>
          </div>
        </div>
      )}

      {activeModal === "schedule" && (
        <div className="fixed inset-0 z-[90] grid place-items-center bg-slate-950/35 p-4" role="presentation">
          <div
            className="max-h-[calc(100svh-2rem)] w-[min(880px,100%)] overflow-auto rounded-[1.75rem] border border-teal-100 bg-white p-5 shadow-[0_26px_80px_rgba(6,45,49,0.25)]"
            role="dialog"
            aria-modal="true"
            aria-labelledby="schedule-modal-title"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-black uppercase tracking-wide text-teal-700">Chamber Time</span>
                <h3 className="mt-1 text-2xl font-black tracking-tight text-slate-900" id="schedule-modal-title">Update Time Slots</h3>
              </div>
              <button
                type="button"
                className="grid h-9 w-9 place-items-center rounded-full bg-cyan-50 text-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
                onClick={() => setActiveModal(null)}
                aria-label="Close schedule dialog"
              >
                <X size={18} />
              </button>
            </div>

            <div className="mt-5 grid gap-3">
              {scheduleDraft.map((slot, index) => (
                <article key={slot.id} className="grid gap-3 rounded-2xl border border-teal-100 bg-cyan-50/40 p-3 md:grid-cols-[80px_1fr_1fr_1fr_1fr_auto] md:items-end">
                  <div className="inline-flex h-11 items-center justify-center gap-2 rounded-2xl bg-white px-3 text-sm font-black text-teal-700">
                    <Clock3 size={15} />
                    <span>{index + 1}</span>
                  </div>

                  <label className="grid gap-1 text-sm font-extrabold text-slate-600">
                    Day
                    <input
                      className="rounded-2xl border border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:ring-2 focus:ring-cyan-100"
                      value={slot.day}
                      onChange={(event) =>
                        updateScheduleSlot(slot.id, "day", event.target.value)
                      }
                    />
                  </label>

                  <label className="grid gap-1 text-sm font-extrabold text-slate-600">
                    Start
                    <input
                      className="rounded-2xl border border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:ring-2 focus:ring-cyan-100"
                      type="time"
                      value={slot.start}
                      onChange={(event) =>
                        updateScheduleSlot(slot.id, "start", event.target.value)
                      }
                    />
                  </label>

                  <label className="grid gap-1 text-sm font-extrabold text-slate-600">
                    End
                    <input
                      className="rounded-2xl border border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:ring-2 focus:ring-cyan-100"
                      type="time"
                      value={slot.end}
                      onChange={(event) =>
                        updateScheduleSlot(slot.id, "end", event.target.value)
                      }
                    />
                  </label>

                  <label className="grid gap-1 text-sm font-extrabold text-slate-600">
                    Mode
                    <select
                      className="rounded-2xl border border-teal-100 bg-white px-3 py-2 text-sm font-semibold outline-none focus:ring-2 focus:ring-cyan-100"
                      value={slot.mode}
                      onChange={(event) =>
                        updateScheduleSlot(slot.id, "mode", event.target.value)
                      }
                    >
                      <option value="In-person">In-person</option>
                      <option value="Hybrid">Hybrid</option>
                      <option value="Online">Online</option>
                    </select>
                  </label>

                  <button
                    type="button"
                    className="grid h-11 w-11 place-items-center rounded-2xl bg-white text-red-600 ring-1 ring-red-100 disabled:cursor-not-allowed disabled:opacity-40"
                    onClick={() => removeScheduleSlot(slot.id)}
                    disabled={scheduleDraft.length === 1}
                    aria-label="Remove time slot"
                  >
                    <Trash2 size={16} />
                  </button>
                </article>
              ))}
            </div>

            <button
              type="button"
              className="mt-4 inline-flex min-h-11 w-fit items-center justify-center gap-2 rounded-full border border-teal-100 bg-white px-5 text-sm font-black text-teal-700 shadow-sm"
              onClick={addScheduleSlot}
            >
              <Plus size={16} />
              Add Time Slot
            </button>

            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button className="inline-flex min-h-11 items-center justify-center rounded-full border border-teal-100 bg-white px-5 text-sm font-black text-teal-700 shadow-sm" type="button" onClick={() => setActiveModal(null)}>
                Cancel
              </button>
              <button
                type="button"
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg"
                onClick={handleSaveSchedule}
              >
                <Check size={16} />
                Save Chamber Time
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default DoctorProfilePage;
