import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Bell,
  BellOff,
  BellRing,
  CheckCircle2,
  EyeOff,
  LayoutDashboard,
  MessageSquareText,
  RotateCcw,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Zap,
} from "lucide-react";
import BackButton from "../components/common/BackButton";
import GlassCard from "../components/common/GlassCard";

const PANEL_SETTINGS_STORAGE_KEY = "doctorPanelSettings";

const getDefaultSettings = () => ({
  privacyMode: true,
  urgentOnlyAlerts: true,
  focusMode: false,
  inboxEnabled: true,
});

const readStoredSettings = () => {
  if (typeof window === "undefined") return getDefaultSettings();

  const saved = window.localStorage.getItem(PANEL_SETTINGS_STORAGE_KEY);
  if (!saved) return getDefaultSettings();

  try {
    return { ...getDefaultSettings(), ...JSON.parse(saved) };
  } catch {
    return getDefaultSettings();
  }
};

const settingsPageStyles = `
  @keyframes settingsFadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes switchPop {
    0% { transform: scale(.94); }
    60% { transform: scale(1.04); }
    100% { transform: scale(1); }
  }

  @keyframes iconFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-3px); }
  }

  .settings-fade-up {
    animation: settingsFadeUp 360ms ease both;
  }

  .settings-switch-pop {
    animation: switchPop 260ms ease both;
  }

  .settings-icon-float {
    animation: iconFloat 3s ease-in-out infinite;
  }
`;

const settingItems = [
  {
    key: "privacyMode",
    title: "Privacy Mode",
    short: "Mask sensitive patient info on shared views.",
    enabledText: "Patient-sensitive details are masked.",
    disabledText: "All patient details remain visible.",
    icon: EyeOff,
  },
  {
    key: "urgentOnlyAlerts",
    title: "Urgent Alerts",
    short: "Show only emergency notifications during visits.",
    enabledText: "Only emergency alerts are visible.",
    disabledText: "All notifications can appear.",
    icon: BellRing,
  },
  {
    key: "focusMode",
    title: "Focus Mode",
    short: "Reduce distraction during consultation workflow.",
    enabledText: "Low-distraction consultation mode is active.",
    disabledText: "Standard panel workflow is active.",
    icon: LayoutDashboard,
  },
  {
    key: "inboxEnabled",
    title: "Messages Inbox",
    short: "Control doctor message inbox visibility.",
    enabledText: "Inbox is active and message list is visible.",
    disabledText: "Inbox is hidden and sender list is blocked.",
    icon: MessageSquareText,
  },
];

const DoctorPanelSettingsPage = () => {
  const [settings, setSettings] = useState(readStoredSettings);

  useEffect(() => {
    window.localStorage.setItem(
      PANEL_SETTINGS_STORAGE_KEY,
      JSON.stringify(settings)
    );
  }, [settings]);

  const activeCount = useMemo(
    () => Object.values(settings).filter(Boolean).length,
    [settings]
  );

  const toggleSetting = (key) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const resetSettings = () => {
    setSettings(getDefaultSettings());
  };

  const renderSwitch = (enabled) => (
    <span
      className={[
        "settings-switch-pop relative h-6 w-11 shrink-0 rounded-full transition duration-300",
        enabled ? "bg-teal-600 shadow-sm shadow-teal-600/20" : "bg-slate-300",
      ].join(" ")}
      aria-hidden="true"
    >
      <span
        className={[
          "absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all duration-300",
          enabled ? "left-6" : "left-1",
        ].join(" ")}
      />
    </span>
  );

  return (
    <>
      <style>{settingsPageStyles}</style>

      <section className="mx-auto grid max-w-6xl gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <BackButton label="Back to Profile" to="/doctor/profile" />

          <button
            type="button"
            onClick={resetSettings}
            className="inline-flex h-9 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-cyan-200"
          >
            <RotateCcw size={14} />
            Reset Default
          </button>
        </div>

        <GlassCard className="settings-fade-up">
          <div className="grid gap-3 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="inline-flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.22em] text-cyan-600">
                <SlidersHorizontal size={14} />
                Panel Settings
              </p>

              <h2 className="mt-2 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl">
                Doctor Panel Configuration
              </h2>

              <p className="mt-1.5 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
                Privacy, notification, focus mode and message visibility control
                from one clean place.
              </p>
            </div>

            <div className="grid gap-2 sm:grid-cols-2 lg:min-w-[300px]">
              <div className="rounded-2xl border border-cyan-100 bg-cyan-50/70 px-4 py-3">
                <p className="text-[10px] font-black uppercase tracking-wide text-slate-400">
                  Active Settings
                </p>
                <p className="mt-1 text-2xl font-black text-teal-700">
                  {activeCount}/4
                </p>
              </div>

              <Link
                to="/doctor/messages"
                className="group inline-flex items-center justify-between rounded-2xl border border-cyan-100 bg-white px-4 py-3 text-sm font-black text-teal-800 shadow-sm transition hover:-translate-y-0.5 hover:bg-cyan-50"
              >
                Messages
                <BellRing
                  size={17}
                  className="transition duration-300 group-hover:-rotate-12"
                />
              </Link>
            </div>
          </div>
        </GlassCard>

        <div id="panel-controls" className="grid gap-3 lg:grid-cols-4">
          {settingItems.map((item, index) => (
            <SettingCard
              key={item.key}
              item={item}
              enabled={settings[item.key]}
              onToggle={() => toggleSetting(item.key)}
              renderSwitch={renderSwitch}
              delay={index * 50}
            />
          ))}
        </div>

        <GlassCard className="settings-fade-up">
          <div className="grid gap-3 md:grid-cols-[1fr_auto] md:items-center">
            <div className="flex items-start gap-3">
              {settings.inboxEnabled ? (
                <Bell size={18} className="mt-0.5 text-teal-700" />
              ) : (
                <BellOff size={18} className="mt-0.5 text-red-600" />
              )}

              <div>
                <h3 className="text-base font-black text-slate-900">
                  Current Panel Status
                </h3>
                <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
                  {settings.privacyMode
                    ? "Privacy is active, patient sensitive info will stay protected."
                    : "Privacy is off, all patient info can be visible."}{" "}
                  {settings.inboxEnabled
                    ? "Message inbox is visible."
                    : "Message inbox is currently hidden."}
                </p>
              </div>
            </div>

            <div className="inline-flex items-center gap-2 rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-2 text-xs font-black text-emerald-700">
              <CheckCircle2 size={15} />
              Auto saved
            </div>
          </div>
        </GlassCard>
      </section>
    </>
  );
};

const SettingCard = ({ item, enabled, onToggle, renderSwitch, delay = 0 }) => {
  const Icon = item.icon;

  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={enabled}
      className={[
        "settings-fade-up group rounded-3xl border p-4 text-left shadow-sm transition duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-200",
        enabled
          ? "border-teal-100 bg-white shadow-teal-900/5"
          : "border-slate-200 bg-white/80",
      ].join(" ")}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between gap-3">
        <Icon
          size={20}
          strokeWidth={2.1}
          className={[
            "settings-icon-float transition duration-300",
            enabled ? "text-teal-700" : "text-slate-400",
          ].join(" ")}
        />

        {renderSwitch(enabled)}
      </div>

      <h3 className="mt-3 text-sm font-black text-slate-950">{item.title}</h3>

      <p className="mt-1 min-h-[38px] text-xs font-semibold leading-5 text-slate-500">
        {item.short}
      </p>

      <div
        className={[
          "mt-3 rounded-2xl px-3 py-2 text-xs font-black transition duration-300",
          enabled
            ? "bg-teal-50 text-teal-700"
            : "bg-slate-100 text-slate-500",
        ].join(" ")}
      >
        {enabled ? item.enabledText : item.disabledText}
      </div>
    </button>
  );
};

export default DoctorPanelSettingsPage;