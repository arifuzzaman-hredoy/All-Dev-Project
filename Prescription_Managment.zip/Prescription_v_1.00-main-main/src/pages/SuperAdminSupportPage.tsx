import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminSupportPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Support"
    description="Monitor open tickets, platform conversations and tenant issue queues."
  />
);

export default SuperAdminSupportPage;
