import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminTenantsPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Tenants"
    description="Browse clinics, onboarding status, active plans and account health using mock tenant data."
  />
);

export default SuperAdminTenantsPage;
