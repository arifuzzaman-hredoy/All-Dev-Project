import PageHeader from "../components/common/PageHeader";
import RouteCard from "../components/common/RouteCard";
import { demoRouteGroups } from "../lib/demoRoutes";

const DemoSelectorPage = () => (
  <main className="mx-auto max-w-7xl px-4 py-10">
    <PageHeader
      eyebrow="Demo selector"
      title="Open every major route"
      description="Choose public websites, admin panels, clinic operations, diagnostic workflows, or hospital future shells."
    />
    <div className="mt-6 grid gap-6">
      {demoRouteGroups.map((group) => (
        <section key={group.title}>
          <h2 className="mb-3 text-lg font-black text-slate-950">{group.title}</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {group.routes.map((route) => <RouteCard key={route.to} {...route} />)}
          </div>
        </section>
      ))}
    </div>
  </main>
);

export default DemoSelectorPage;
