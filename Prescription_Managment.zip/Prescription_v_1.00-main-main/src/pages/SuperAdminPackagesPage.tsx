import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminPackagesPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Packages"
    description="Preview package tiers, pricing cards and feature availability before backend wiring."
  />
);

export default SuperAdminPackagesPage;
