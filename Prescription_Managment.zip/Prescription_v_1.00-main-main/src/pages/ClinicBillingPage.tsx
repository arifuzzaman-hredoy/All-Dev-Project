import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicBillingPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Billing"
    description="Review invoices, collections, due amounts and payment summaries in a frontend shell."
  />
);

export default ClinicBillingPage;
