import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  Building2,
  CheckCircle2,
  Database,
  Hospital,
  Layers,
  LockKeyhole,
  Server,
  ShieldCheck,
  Stethoscope,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { demoPackages } from "../lib/demoPackages";

type DemoRecord = Record<string, unknown>;

type PricingCategory = {
  key: string;
  title: string;
  eyebrow: string;
  description: string;
  icon: LucideIcon;
  matchWords: string[];
};

const categories: PricingCategory[] = [
  {
    key: "doctors",
    title: "Doctors",
    eyebrow: "Single & Pro Doctor",
    description:
      "Individual doctor website, appointment, prescription and patient workflow.",
    icon: Stethoscope,
    matchWords: ["doctor", "single doctor", "pro doctor", "physician"],
  },
  {
    key: "clinics",
    title: "Clinics",
    eyebrow: "Clinic ERP",
    description:
      "Clinic dashboard, appointment, billing, patient and multi-user operation.",
    icon: Building2,
    matchWords: ["clinic", "clinic basic", "clinic pro"],
  },
  {
    key: "diagnostic",
    title: "Diagnostic",
    eyebrow: "Lab & Report",
    description:
      "Diagnostic center workflow, lab module, report and billing system.",
    icon: Activity,
    matchWords: ["diagnostic", "lab", "report", "pathology"],
  },
  {
    key: "hospitals",
    title: "Hospitals",
    eyebrow: "Hospital Ready",
    description:
      "Hospital-ready shell with future IPD, department and advanced modules.",
    icon: Hospital,
    matchWords: ["hospital", "ipd", "ward", "department"],
  },
];

const backendStack = [
  { label: "Frontend", value: "Public website + dashboard UI", icon: Layers },
  { label: "Backend API", value: "Routes, controllers, tenant logic", icon: Server },
  { label: "Database", value: "Packages, users, billing, CMS", icon: Database },
  { label: "Login & Access", value: "Auth, roles, protected panels", icon: LockKeyhole },
];

const getText = (
  source: DemoRecord,
  keys: string[],
  fallback = "",
): string => {
  for (const key of keys) {
    const value = source[key];

    if (typeof value === "string" && value.trim()) return value;
    if (typeof value === "number") return String(value);
  }

  return fallback;
};

const getList = (
  source: DemoRecord,
  keys: string[],
  fallback: string[] = [],
): string[] => {
  for (const key of keys) {
    const value = source[key];

    if (Array.isArray(value)) {
      return value
        .map((item) => {
          if (typeof item === "string") return item;
          if (typeof item === "number") return String(item);
          if (item && typeof item === "object") return JSON.stringify(item);
          return "";
        })
        .filter(Boolean);
    }
  }

  return fallback;
};

const getPath = (
  source: DemoRecord,
  keys: string[],
  fallback: string,
): string => {
  const path = getText(source, keys, fallback);
  return path.startsWith("/") ? path : fallback;
};

const readPackageSearchText = (item: DemoRecord) =>
  [
    getText(item, ["name", "title", "label"]),
    getText(item, ["target", "targetClient", "audience"]),
    getText(item, ["description", "subtitle"]),
    getList(item, ["modules", "features", "includedModules"]).join(" "),
  ]
    .join(" ")
    .toLowerCase();

const getPackageCategory = (item: DemoRecord, index: number) => {
  const searchText = readPackageSearchText(item);

  const matched = categories.find((category) =>
    category.matchWords.some((word) => searchText.includes(word)),
  );

  return matched?.key ?? categories[index % categories.length].key;
};

const getDisplayValue = (value: unknown): string => {
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  if (typeof value === "boolean") return value ? "Yes" : "No";

  if (Array.isArray(value)) {
    return value
      .map((item) => {
        if (typeof item === "string") return item;
        if (typeof item === "number") return String(item);
        if (typeof item === "boolean") return item ? "Yes" : "No";
        if (item && typeof item === "object") return JSON.stringify(item);
        return "";
      })
      .filter(Boolean)
      .join(", ");
  }

  if (value && typeof value === "object") {
    return JSON.stringify(value);
  }

  return "";
};

const useCountUp = (end: number, duration = 1050) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let frame = 0;
    const totalFrames = Math.max(1, Math.round(duration / 16));

    const timer = window.setInterval(() => {
      frame += 1;

      const progress = Math.min(frame / totalFrames, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      setValue(Math.round(end * eased));

      if (progress >= 1) window.clearInterval(timer);
    }, 16);

    return () => window.clearInterval(timer);
  }, [end, duration]);

  return value;
};

const PremiumAction = ({
  to,
  children,
  variant = "ghost",
}: {
  to: string;
  children: ReactNode;
  variant?: "primary" | "ghost";
}) => (
  <Link
    to={to}
    className={[
      "group/btn relative inline-flex items-center justify-center gap-2 overflow-hidden border px-3 py-2.5 text-center text-[11px] font-black uppercase tracking-[0.1em] backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5",
      variant === "primary"
        ? "border-white bg-white text-black hover:bg-white/90"
        : "border-white/[0.12] bg-white/[0.045] text-white/68 hover:border-white/30 hover:bg-white/[0.095] hover:text-white",
    ].join(" ")}
  >
    <span className="relative z-10">{children}</span>
    <ArrowRight
      size={13}
      className="relative z-10 transition-transform duration-300 group-hover/btn:translate-x-1"
    />
    <span className="absolute bottom-0 left-0 h-px w-0 bg-current opacity-45 transition-all duration-500 group-hover/btn:w-full" />
  </Link>
);

const StackCard = ({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
}) => (
  <div className="group relative min-h-[86px] overflow-hidden border border-white/[0.10] bg-white/[0.045] p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.07),0_14px_45px_rgba(0,0,0,0.22)] backdrop-blur-2xl transition-all duration-300 hover:-translate-y-1 hover:border-white/26 hover:bg-white/[0.085]">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <p className="text-[9px] font-black uppercase tracking-[0.17em] text-white/38">
          {label}
        </p>
        <p className="mt-1.5 line-clamp-2 text-[12px] font-bold leading-5 text-white/65">
          {value}
        </p>
      </div>

      <Icon
        size={19}
        strokeWidth={1.8}
        className="shrink-0 text-white/34 transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-[-4deg] group-hover:scale-110 group-hover:text-white"
      />
    </div>

    <span className="absolute bottom-0 left-0 h-px w-0 bg-white/50 transition-all duration-500 group-hover:w-full" />
  </div>
);

const CategorySummaryCard = ({
  category,
  count,
}: {
  category: PricingCategory;
  count: number;
}) => {
  const Icon = category.icon;
  const value = useCountUp(count);

  return (
    <a
      href={`#${category.key}`}
      className="group relative min-h-[116px] overflow-hidden border border-white/[0.10] bg-white/[0.045] p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.07),0_14px_45px_rgba(0,0,0,0.22)] backdrop-blur-2xl transition-all duration-300 hover:-translate-y-1 hover:border-blue-300/40 hover:bg-white/[0.09] hover:shadow-[0_20px_58px_rgba(37,99,235,0.18)]"
    >
      <div className="flex items-start justify-between gap-3">
        <Icon
          size={21}
          strokeWidth={1.8}
          className="text-white/42 transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-[-4deg] group-hover:scale-110 group-hover:text-blue-100"
        />
        <span className="text-xl font-black leading-none text-white">
          {value}
        </span>
      </div>

      <p className="mt-3 text-[9px] font-black uppercase tracking-[0.16em] text-white/38">
        {category.eyebrow}
      </p>
      <h3 className="mt-1 text-base font-black text-white">{category.title}</h3>
      <p className="mt-1.5 line-clamp-2 text-[11px] font-semibold leading-4 text-white/48">
        {category.description}
      </p>

      <span className="absolute bottom-0 left-0 h-px w-0 bg-blue-200/70 transition-all duration-500 group-hover:w-full" />
    </a>
  );
};

const PackagePricingCard = ({
  item,
  index,
  category,
}: {
  item: DemoRecord;
  index: number;
  category: PricingCategory;
}) => {
  const Icon = category.icon;

  const name = getText(item, ["name", "title", "label"], `Package ${index + 1}`);
  const target = getText(
    item,
    ["target", "targetClient", "audience"],
    category.description,
  );
  const description = getText(
    item,
    ["description", "subtitle"],
    "A ready-to-preview Clinic ERP SaaS package with public website and dashboard demo.",
  );

  const price = getText(item, ["price", "monthlyPrice", "amount", "fee"], "Custom");
  const period = getText(item, ["period", "billingCycle", "duration"], "Package");
  const modules = getList(item, ["modules", "features", "includedModules"], []);
  const limits = getList(item, ["limits", "restrictions", "usageLimits"], []);

  const publicDemoTo = getPath(
    item,
    ["publicDemoTo", "publicDemo", "publicUrl", "publicDemoUrl"],
    "/demo",
  );
  const adminDemoTo = getPath(
    item,
    ["adminDemoTo", "adminDemo", "dashboardUrl", "adminUrl"],
    "/clinic/dashboard",
  );

  const usedKeys = new Set([
    "name",
    "title",
    "label",
    "target",
    "targetClient",
    "audience",
    "description",
    "subtitle",
    "price",
    "monthlyPrice",
    "amount",
    "fee",
    "period",
    "billingCycle",
    "duration",
    "modules",
    "features",
    "includedModules",
    "limits",
    "restrictions",
    "usageLimits",
    "publicDemoTo",
    "publicDemo",
    "publicUrl",
    "publicDemoUrl",
    "adminDemoTo",
    "adminDemo",
    "dashboardUrl",
    "adminUrl",
  ]);

  const extraFields = Object.entries(item)
    .filter(([key, value]) => !usedKeys.has(key) && getDisplayValue(value))
    .slice(0, 8);

  return (
    <article className="group/card relative z-0 overflow-visible border border-white/[0.10] bg-white/[0.045] p-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.07),0_22px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl transition-all duration-300 hover:z-20 hover:-translate-y-2 hover:border-blue-300/55 hover:bg-white/[0.085] hover:shadow-[0_0_0_1px_rgba(59,130,246,0.16),0_30px_95px_rgba(37,99,235,0.28)]">
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover/card:opacity-100">
        <div className="absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-blue-200/80 to-transparent" />
        <div className="absolute -inset-1 bg-[radial-gradient(circle_at_50%_0%,rgba(59,130,246,0.20),transparent_36%)]" />
      </div>

      <div className="relative">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <Icon
              size={30}
              strokeWidth={1.8}
              className="text-white/42 transition-all duration-500 group-hover/card:-translate-y-1 group-hover/card:rotate-[-4deg] group-hover/card:scale-110 group-hover/card:text-blue-100"
            />

            <p className="mt-4 text-[10px] font-black uppercase tracking-[0.18em] text-white/40">
              {category.title} Package
            </p>

            <h3 className="mt-2 truncate text-2xl font-black tracking-tight text-white">
              {name}
            </h3>
          </div>

          <span className="shrink-0 text-[10px] font-black text-white/36">
            #{String(index + 1).padStart(2, "0")}
          </span>
        </div>

        <div className="mt-5 border-y border-white/[0.10] py-4">
          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-blue-100/72">
            Pricing
          </p>
          <div className="mt-2 flex items-end gap-2">
            <span className="text-4xl font-black text-white">{price}</span>
            <span className="pb-1 text-xs font-bold uppercase tracking-[0.14em] text-white/45">
              {period}
            </span>
          </div>
        </div>

        <p className="mt-4 text-sm font-semibold leading-6 text-white/58 group-hover/card:text-white/72">
          {description}
        </p>

        <div className="mt-5">
          <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/40">
            Target Client
          </p>
          <p className="mt-2 text-sm font-bold leading-6 text-white/72">
            {target}
          </p>
        </div>

        {modules.length > 0 && (
          <div className="mt-5">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/40">
              Included Modules
            </p>

            <div className="mt-3 grid gap-2">
              {modules.map((module) => (
                <div
                  key={module}
                  className="flex items-start gap-2 text-xs font-semibold leading-5 text-white/60"
                >
                  <CheckCircle2
                    size={14}
                    className="mt-0.5 shrink-0 text-blue-100/78"
                  />
                  <span>{module}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {limits.length > 0 && (
          <div className="mt-5">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/40">
              Limits
            </p>

            <div className="mt-3 grid gap-2">
              {limits.map((limit) => (
                <div
                  key={limit}
                  className="flex items-start gap-2 text-xs font-semibold leading-5 text-white/56"
                >
                  <ShieldCheck
                    size={14}
                    className="mt-0.5 shrink-0 text-emerald-100/75"
                  />
                  <span>{limit}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {extraFields.length > 0 && (
          <div className="mt-5 border-t border-white/[0.10] pt-4">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/40">
              More Information
            </p>

            <div className="mt-3 grid gap-2">
              {extraFields.map(([key, value]) => (
                <div
                  key={key}
                  className="grid gap-1 border border-white/[0.08] bg-black/20 p-2.5 backdrop-blur-xl"
                >
                  <span className="text-[9px] font-black uppercase tracking-[0.16em] text-white/34">
                    {key}
                  </span>
                  <span className="break-words text-xs font-semibold leading-5 text-white/58">
                    {getDisplayValue(value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6 grid gap-2 sm:grid-cols-2">
          <PremiumAction to={publicDemoTo}>Public Demo</PremiumAction>
          <PremiumAction to={adminDemoTo} variant="primary">
            Admin Demo
          </PremiumAction>
        </div>
      </div>
    </article>
  );
};

const PricingPage = () => {
  const groupedPackages = useMemo(() => {
    const base: Record<string, DemoRecord[]> = categories.reduce(
      (acc, category) => {
        acc[category.key] = [];
        return acc;
      },
      {} as Record<string, DemoRecord[]>,
    );

    demoPackages.forEach((item, index) => {
      const record = item as DemoRecord;
      const categoryKey = getPackageCategory(record, index);
      base[categoryKey].push(record);
    });

    return base;
  }, []);

  return (
    <main className="relative overflow-hidden text-white">
      <style>
        {`
          @keyframes pricingAuroraOne {
            0%, 100% { transform: translate3d(-8%, -4%, 0) scale(1); opacity: .64; }
            50% { transform: translate3d(8%, 5%, 0) scale(1.12); opacity: .92; }
          }

          @keyframes pricingAuroraTwo {
            0%, 100% { transform: translate3d(7%, 6%, 0) scale(1); opacity: .54; }
            50% { transform: translate3d(-6%, -4%, 0) scale(1.08); opacity: .82; }
          }

          @keyframes pricingAuroraThree {
            0%, 100% { transform: translate3d(-2%, 5%, 0) scale(1); opacity: .42; }
            50% { transform: translate3d(5%, -5%, 0) scale(1.08); opacity: .70; }
          }

          @keyframes pricingGridMove {
            0% { background-position: 0 0; }
            100% { background-position: 78px 78px; }
          }

          .pricing-aurora-one {
            animation: pricingAuroraOne 14s ease-in-out infinite;
          }

          .pricing-aurora-two {
            animation: pricingAuroraTwo 17s ease-in-out infinite;
          }

          .pricing-aurora-three {
            animation: pricingAuroraThree 20s ease-in-out infinite;
          }

          .pricing-grid {
            animation: pricingGridMove 22s linear infinite;
          }
        `}
      </style>

      <div className="pointer-events-none absolute inset-0 z-0">
        <div className="pricing-aurora-one absolute -left-32 top-6 h-[560px] w-[560px] rounded-full bg-blue-500/[0.16] blur-[115px]" />
        <div className="pricing-aurora-two absolute right-[-140px] top-24 h-[600px] w-[600px] rounded-full bg-fuchsia-500/[0.12] blur-[120px]" />
        <div className="pricing-aurora-three absolute bottom-0 left-1/2 h-[520px] w-[780px] -translate-x-1/2 rounded-full bg-cyan-500/[0.08] blur-[120px]" />
        <div className="absolute left-[18%] top-[36%] h-[320px] w-[320px] rounded-full bg-emerald-400/[0.045] blur-[105px]" />
        <div className="pricing-grid absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.024)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.024)_1px,transparent_1px)] bg-[size:78px_78px] opacity-20" />
      </div>

      <section className="relative z-10 mx-auto max-w-7xl px-4 py-10">
        <div className="mx-auto max-w-4xl text-center">
          <p className="inline-flex border border-blue-200/20 bg-white/[0.055] px-4 py-2 text-[11px] font-black uppercase tracking-[0.2em] text-blue-100/78 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] backdrop-blur-2xl">
            Pricing
          </p>

          <h1 className="mt-5 text-4xl font-black tracking-tight text-white sm:text-6xl lg:text-7xl">
            Package comparison
          </h1>

          <p className="mx-auto mt-4 max-w-2xl text-sm font-semibold leading-7 text-white/58">
            Compare the demo packages by target client, included modules, limits
            and admin/public demo routes.
          </p>
        </div>

        <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {categories.map((category) => (
            <CategorySummaryCard
              key={category.key}
              category={category}
              count={groupedPackages[category.key]?.length ?? 0}
            />
          ))}
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {backendStack.map((item) => (
            <StackCard key={item.label} {...item} />
          ))}
        </div>
      </section>

      {categories.map((category) => {
        const packages = groupedPackages[category.key] ?? [];
        const Icon = category.icon;

        return (
          <section
            key={category.key}
            id={category.key}
            className="relative z-10 mx-auto max-w-7xl px-4 pb-14"
          >
            <div className="mb-6 flex flex-col justify-between gap-4 border-t border-white/[0.10] pt-10 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-3">
                  <Icon size={24} className="text-white/45" />
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-white/40">
                    {category.eyebrow}
                  </p>
                </div>

                <h2 className="mt-3 text-3xl font-black text-white sm:text-4xl">
                  {category.title} packages
                </h2>

                <p className="mt-2 max-w-2xl text-sm font-semibold leading-7 text-white/52">
                  {category.description}
                </p>
              </div>

              <span className="border border-white/[0.10] bg-white/[0.045] px-4 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-white/48 backdrop-blur-2xl">
                {packages.length} Package
              </span>
            </div>

            {packages.length > 0 ? (
              <div className="grid items-start gap-4 md:grid-cols-2 xl:grid-cols-3">
                {packages.map((item, index) => (
                  <PackagePricingCard
                    key={getText(
                      item,
                      ["name", "title"],
                      `${category.key}-${index}`,
                    )}
                    item={item}
                    index={index}
                    category={category}
                  />
                ))}
              </div>
            ) : (
              <div className="border border-white/[0.10] bg-white/[0.045] p-6 backdrop-blur-2xl">
                <p className="text-sm font-bold leading-7 text-white/55">
                  No package data found for this category yet. Add a package name,
                  target, description, modules or features with “{category.title}”
                  related text inside <code>demoPackages</code>.
                </p>
              </div>
            )}
          </section>
        );
      })}
    </main>
  );
};

export default PricingPage;