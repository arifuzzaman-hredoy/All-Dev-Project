import PageHeader from "../components/common/PageHeader";

const BookDemoPage = () => (
  <main className="mx-auto max-w-4xl px-4 py-10">
    <PageHeader eyebrow="Book demo" title="Schedule a Clinic ERP walkthrough" description="Frontend-only demo form for package inquiries and guided product tours." />
    <form className="mt-6 grid gap-3 rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_16px_38px_rgba(15,23,42,0.06)]">
      {["Clinic name", "Contact person", "Phone or email", "Preferred package"].map((label) => (
        <label key={label} className="grid gap-1 text-[12px] font-black text-slate-700">
          {label}
          <input className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-semibold outline-none focus:border-teal-400" placeholder={label} />
        </label>
      ))}
      <button type="button" className="mt-2 rounded-full bg-teal-700 px-5 py-3 text-sm font-black text-white">Submit demo request</button>
    </form>
  </main>
);

export default BookDemoPage;
