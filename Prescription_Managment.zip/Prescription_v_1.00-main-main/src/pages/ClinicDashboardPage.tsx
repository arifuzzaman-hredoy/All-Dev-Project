import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicDashboardPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Clinic dashboard"
    description="Operational snapshot for appointments, patients, billing, reports and support."
  />
);

export default ClinicDashboardPage;
