import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminDashboardPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Platform dashboard"
    description="Overview of tenant growth, package health, subscriptions, payments and support workload."
  />
);

export default SuperAdminDashboardPage;
