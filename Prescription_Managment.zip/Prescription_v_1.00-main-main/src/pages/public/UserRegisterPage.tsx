import { useState } from "react";
import {
  ArrowLeft,
  Eye,
  EyeOff,
  HeartPulse,
  LockKeyhole,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  UserRound,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import {
  getPasswordStrength,
  PUBLIC_REMEMBER_USER_KEY,
  registerPublicUser,
} from "../../lib/publicUserStorage";

const emptyRegisterForm = {
  name: "",
  phone: "",
  email: "",
  age: "",
  gender: "Female",
  address: "",
  password: "",
  confirmPassword: "",
  rememberMe: true,
};

const registerPageCss = `
  @keyframes authPageIn {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes softFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: 0.55; transform: scale(1); }
    50% { opacity: 0.9; transform: scale(1.06); }
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .auth-page-shell {
    animation: authPageIn 360ms cubic-bezier(.2,.8,.2,1) both;
  }

  .auth-float-icon {
    animation: softFloat 4s ease-in-out infinite;
  }

  .auth-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .auth-fade-up {
    animation: fadeUp 420ms ease both;
  }
`;

const FieldIcon = ({ icon: Icon }) => (
  <Icon
    size={16}
    strokeWidth={2.25}
    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 group-focus-within:-translate-y-[55%] group-focus-within:text-teal-700"
  />
);

const PasswordToggle = ({ visible, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 hover:-translate-y-[55%] hover:text-teal-700"
    aria-label={visible ? "Hide password" : "Show password"}
  >
    {visible ? <EyeOff size={17} /> : <Eye size={17} />}
  </button>
);

const StrengthBar = ({ strength }) => {
  const value =
    typeof strength === "string"
      ? strength
      : strength?.level || strength?.type || strength?.label || "empty";

  const normalized = String(value).toLowerCase();

  const config = {
    empty: {
      label: "Password strength",
      width: "w-0",
      line: "bg-slate-200",
      text: "text-slate-400",
    },
    weak: {
      label: "Weak password",
      width: "w-1/3",
      line: "bg-rose-500",
      text: "text-rose-600",
    },
    medium: {
      label: "Medium password",
      width: "w-2/3",
      line: "bg-amber-500",
      text: "text-amber-600",
    },
    strong: {
      label: "Strong password",
      width: "w-full",
      line: "bg-emerald-500",
      text: "text-emerald-600",
    },
  };

  const active =
    config[normalized] ||
    (normalized.includes("strong")
      ? config.strong
      : normalized.includes("medium")
      ? config.medium
      : normalized.includes("weak")
      ? config.weak
      : config.empty);

  return (
    <div className="grid gap-1">
      <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
        <div
          className={`h-full rounded-full transition-all duration-300 ${active.width} ${active.line}`}
        />
      </div>
      <p className={`text-[11px] font-black ${active.text}`}>
        {active.label}
      </p>
    </div>
  );
};

const UserRegisterPage = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [status, setStatus] = useState({ type: "", message: "" });
  const [form, setForm] = useState(emptyRegisterForm);

  const strength = getPasswordStrength(form.password);

  const inputClass =
    "h-11 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 focus:border-teal-500 focus:ring-4 focus:ring-teal-50";

  const iconInputClass = `${inputClass} pl-10`;
  const passwordInputClass = `${inputClass} pl-10 pr-10`;

  const update = (key, value) => {
    setStatus({ type: "", message: "" });

    if (key === "phone") {
      const onlyDigits = value.replace(/\D/g, "").slice(0, 11);
      setForm((prev) => ({ ...prev, phone: onlyDigits }));
      return;
    }

    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const submit = (event) => {
    event.preventDefault();
    setStatus({ type: "", message: "" });

    if (!form.name.trim() || !form.phone.trim() || !form.email.trim()) {
      setStatus({
        type: "error",
        message: "Full name, phone and email are required.",
      });
      return;
    }

    if (form.phone.length !== 11) {
      setStatus({
        type: "error",
        message: "Mobile number must be exactly 11 digits.",
      });
      return;
    }

    if (!form.password || !form.confirmPassword) {
      setStatus({
        type: "error",
        message: "Password and confirm password are required.",
      });
      return;
    }

    if (form.password !== form.confirmPassword) {
      setStatus({ type: "error", message: "Passwords do not match." });
      return;
    }

    const result = registerPublicUser(form);
    const success = result?.success ?? result?.ok;

    if (!success) {
      setStatus({
        type: "error",
        message: result?.message || "Registration failed. Please try again.",
      });
      return;
    }

    if (form.rememberMe) {
      window.localStorage.setItem(
        PUBLIC_REMEMBER_USER_KEY,
        form.email || form.phone
      );
    }

    setStatus({ type: "success", message: "Registration successful." });

    window.setTimeout(() => navigate("/"), 500);
  };

  return (
    <>
      <style>{registerPageCss}</style>

      <section className="min-h-screen bg-slate-50 px-4 py-6">
        <div className="mx-auto flex min-h-[calc(100vh-48px)] max-w-5xl items-center justify-center">
          <div className="auth-page-shell relative grid w-full overflow-hidden rounded-[34px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/10 md:grid-cols-[0.92fr_1.08fr]">
            <Link
              to="/"
              className="group absolute left-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-slate-500 shadow-sm ring-1 ring-slate-100 transition duration-300 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:text-teal-700 hover:shadow-md"
              aria-label="Back to website"
              title="Back to website"
            >
              <ArrowLeft
                size={18}
                className="transition-transform duration-300 group-hover:-translate-x-0.5"
              />
            </Link>

            <aside className="relative hidden min-h-[680px] overflow-hidden bg-gradient-to-br from-teal-900 via-teal-700 to-cyan-700 p-8 text-white md:grid">
              <span className="auth-glow absolute -left-20 top-16 h-44 w-44 rounded-full bg-white/15 blur-3xl" />
              <span className="auth-glow absolute -bottom-16 right-6 h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl" />

              <div className="relative z-10 flex h-full flex-col justify-between pt-12">
                <div>
                  <div className="flex items-center gap-3">
                    <Stethoscope
                      size={40}
                      strokeWidth={2.05}
                      className="auth-float-icon text-white"
                    />
                    <Sparkles
                      size={18}
                      className="text-cyan-100 transition-transform duration-500 hover:rotate-12"
                    />
                  </div>

                  <h1 className="mt-7 text-4xl font-black leading-tight">
                    Create Profile
                  </h1>

                  <p className="mt-4 max-w-xs text-sm font-semibold leading-7 text-white/75">
                    Register once and use appointment, messages and follow-up
                    faster from your patient profile.
                  </p>
                </div>

                <div className="grid gap-4">
                  <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={18} />
                      <p className="text-sm font-black">
                        Secure patient access
                      </p>
                    </div>
                    <p className="mt-2 text-xs font-semibold leading-6 text-white/70">
                      Remember me দিলে next time phone/email auto fill হবে।
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-black text-white/65">
                    <HeartPulse size={16} />
                    Faster healthcare communication
                  </div>
                </div>
              </div>
            </aside>

            <main className="flex min-h-[680px] items-center p-5 pt-20 sm:p-8 sm:pt-20">
              <div className="auth-fade-up mx-auto w-full max-w-md">
                <p className="text-[11px] font-black uppercase tracking-[0.22em] text-teal-700">
                  Patient Portal
                </p>

                <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-950">
                  Create account
                </h2>

                <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                  Register once for appointment and messages.
                </p>

                {status.message ? (
                  <p
                    className={[
                      "mt-5 rounded-2xl border px-4 py-3 text-xs font-black",
                      status.type === "success"
                        ? "border-emerald-100 bg-emerald-50 text-emerald-700"
                        : "border-rose-100 bg-rose-50 text-rose-700",
                    ].join(" ")}
                  >
                    {status.message}
                  </p>
                ) : null}

                <form className="mt-5 grid gap-3" onSubmit={submit}>
                  <label className="group relative">
                    <FieldIcon icon={UserRound} />
                    <input
                      className={iconInputClass}
                      placeholder="Full name *"
                      value={form.name}
                      onChange={(event) => update("name", event.target.value)}
                    />
                  </label>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <label className="group relative">
                      <FieldIcon icon={Phone} />
                      <input
                        className={iconInputClass}
                        inputMode="numeric"
                        maxLength={11}
                        placeholder="Mobile number *"
                        value={form.phone}
                        onChange={(event) =>
                          update("phone", event.target.value)
                        }
                      />
                    </label>

                    <label className="group relative">
                      <FieldIcon icon={Mail} />
                      <input
                        className={iconInputClass}
                        type="email"
                        placeholder="Email *"
                        value={form.email}
                        onChange={(event) =>
                          update("email", event.target.value)
                        }
                      />
                    </label>

                    <input
                      className={inputClass}
                      type="number"
                      placeholder="Age"
                      value={form.age}
                      onChange={(event) => update("age", event.target.value)}
                    />

                    <select
                      className={inputClass}
                      value={form.gender}
                      onChange={(event) =>
                        update("gender", event.target.value)
                      }
                    >
                      <option>Female</option>
                      <option>Male</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <label className="group relative">
                    <FieldIcon icon={MapPin} />
                    <input
                      className={iconInputClass}
                      placeholder="Address"
                      value={form.address}
                      onChange={(event) =>
                        update("address", event.target.value)
                      }
                    />
                  </label>

                  <label className="group relative">
                    <FieldIcon icon={LockKeyhole} />
                    <input
                      className={passwordInputClass}
                      type={showPassword ? "text" : "password"}
                      placeholder="Password *"
                      value={form.password}
                      onChange={(event) =>
                        update("password", event.target.value)
                      }
                    />
                    <PasswordToggle
                      visible={showPassword}
                      onClick={() => setShowPassword((prev) => !prev)}
                    />
                  </label>

                  <StrengthBar strength={strength} />

                  <label className="group relative">
                    <FieldIcon icon={LockKeyhole} />
                    <input
                      className={passwordInputClass}
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Confirm password *"
                      value={form.confirmPassword}
                      onChange={(event) =>
                        update("confirmPassword", event.target.value)
                      }
                    />
                    <PasswordToggle
                      visible={showConfirmPassword}
                      onClick={() => setShowConfirmPassword((prev) => !prev)}
                    />
                  </label>

                  <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-slate-500">
                    <input
                      type="checkbox"
                      checked={form.rememberMe}
                      onChange={(event) =>
                        update("rememberMe", event.target.checked)
                      }
                      className="h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-500"
                    />
                    Remember me
                  </label>

                  <button
                    type="submit"
                    className="mt-1 h-12 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                  >
                    Register
                  </button>
                </form>

                <div className="mt-5 rounded-3xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:-translate-y-0.5 hover:shadow-sm">
                  <p className="text-sm font-black text-slate-950">
                    Already have an account?
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    Login and continue your saved patient profile.
                  </p>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <Link
                      to="/user/login"
                      className="inline-flex h-10 items-center justify-center rounded-2xl bg-white px-4 text-xs font-black text-teal-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-teal-50"
                    >
                      Login now
                    </Link>

                    <Link
                      to="/user/forgot-password"
                      className="inline-flex h-10 items-center justify-center rounded-2xl bg-white px-4 text-xs font-black text-blue-600 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-blue-50"
                    >
                      Forgot password?
                    </Link>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </section>
    </>
  );
};

export default UserRegisterPage;