import { useState } from "react";
import {
  ArrowLeft,
  Eye,
  EyeOff,
  HeartPulse,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  UserPlus,
} from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  getRememberedPublicUser,
  loginPublicUser,
} from "../../lib/publicUserStorage";

const initialLoginForm = {
  phoneOrEmail: "",
  password: "",
  rememberMe: false,
};

const loginPageCss = `
  @keyframes authPageIn {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes softFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: 0.55; transform: scale(1); }
    50% { opacity: 0.9; transform: scale(1.06); }
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .auth-page-shell {
    animation: authPageIn 360ms cubic-bezier(.2,.8,.2,1) both;
  }

  .auth-float-icon {
    animation: softFloat 4s ease-in-out infinite;
  }

  .auth-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .auth-fade-up {
    animation: fadeUp 420ms ease both;
  }
`;

const FieldIcon = ({ icon: Icon }) => (
  <Icon
    size={16}
    strokeWidth={2.25}
    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 group-focus-within:-translate-y-[55%] group-focus-within:text-teal-700"
  />
);

const PasswordToggle = ({ visible, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 hover:-translate-y-[55%] hover:text-teal-700"
    aria-label={visible ? "Hide password" : "Show password"}
  >
    {visible ? <EyeOff size={17} /> : <Eye size={17} />}
  </button>
);

const UserLoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rememberedUser = getRememberedPublicUser();

  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState({ type: "", message: "" });
  const [form, setForm] = useState({
    ...initialLoginForm,
    phoneOrEmail: rememberedUser || "",
    rememberMe: Boolean(rememberedUser),
  });

  const inputClass =
    "h-11 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 focus:border-teal-500 focus:ring-4 focus:ring-teal-50";

  const iconInputClass = `${inputClass} pl-10`;
  const passwordInputClass = `${inputClass} pl-10 pr-10`;

  const update = (key, value) => {
    setStatus({ type: "", message: "" });
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const submit = (event) => {
    event.preventDefault();
    setStatus({ type: "", message: "" });

    if (!form.phoneOrEmail.trim() || !form.password) {
      setStatus({
        type: "error",
        message: "Phone/email and password are required.",
      });
      return;
    }

    const result = loginPublicUser(form);
    const success = result?.success ?? result?.ok;

    if (!success) {
      setStatus({
        type: "error",
        message: result?.message || "Login failed. Please try again.",
      });
      return;
    }

    setStatus({
      type: "success",
      message: "Login successful. Redirecting...",
    });

    const from = location.state?.from;

    window.setTimeout(() => {
      if (from === "message") {
        window.sessionStorage.setItem("open_public_message_after_login", "true");
        navigate("/");
        return;
      }

      navigate("/");
    }, 450);
  };

  return (
    <>
      <style>{loginPageCss}</style>

      <section className="min-h-screen bg-slate-50 px-4 py-6">
        <div className="mx-auto flex min-h-[calc(100vh-48px)] max-w-5xl items-center justify-center">
          <div className="auth-page-shell relative grid w-full overflow-hidden rounded-[34px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/10 md:grid-cols-[0.92fr_1.08fr]">
            <Link
              to="/"
              className="group absolute left-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-slate-500 shadow-sm ring-1 ring-slate-100 transition duration-300 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:text-teal-700 hover:shadow-md"
              aria-label="Back to website"
              title="Back to website"
            >
              <ArrowLeft
                size={18}
                className="transition-transform duration-300 group-hover:-translate-x-0.5"
              />
            </Link>

            <aside className="relative hidden min-h-[620px] overflow-hidden bg-gradient-to-br from-teal-900 via-teal-700 to-cyan-700 p-8 text-white md:grid">
              <span className="auth-glow absolute -left-20 top-16 h-44 w-44 rounded-full bg-white/15 blur-3xl" />
              <span className="auth-glow absolute -bottom-16 right-6 h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl" />

              <div className="relative z-10 flex h-full flex-col justify-between pt-12">
                <div>
                  <div className="flex items-center gap-3">
                    <Stethoscope
                      size={40}
                      strokeWidth={2.05}
                      className="auth-float-icon text-white"
                    />
                    <Sparkles
                      size={18}
                      className="text-cyan-100 transition-transform duration-500 hover:rotate-12"
                    />
                  </div>

                  <h1 className="mt-7 text-4xl font-black leading-tight">
                    Patient Login
                  </h1>

                  <p className="mt-4 max-w-xs text-sm font-semibold leading-7 text-white/75">
                    Login korle appointment, message, report follow-up and saved
                    patient profile faster manage kora jabe.
                  </p>
                </div>

                <div className="grid gap-4">
                  <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={18} />
                      <p className="text-sm font-black">
                        Secure patient access
                      </p>
                    </div>
                    <p className="mt-2 text-xs font-semibold leading-6 text-white/70">
                      Remember me দিলে next time phone/email auto fill হবে।
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-black text-white/65">
                    <HeartPulse size={16} />
                    Faster healthcare communication
                  </div>
                </div>
              </div>
            </aside>

            <main className="flex min-h-[620px] items-center p-5 pt-20 sm:p-8 sm:pt-20">
              <div className="auth-fade-up mx-auto w-full max-w-md">
                <p className="text-[11px] font-black uppercase tracking-[0.22em] text-teal-700">
                  Patient Portal
                </p>

                <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-950">
                  Welcome back
                </h2>

                <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                  Login with phone/email and continue your patient profile.
                </p>

                {status.message ? (
                  <p
                    className={[
                      "mt-5 rounded-2xl border px-4 py-3 text-xs font-black",
                      status.type === "success"
                        ? "border-emerald-100 bg-emerald-50 text-emerald-700"
                        : "border-rose-100 bg-rose-50 text-rose-700",
                    ].join(" ")}
                  >
                    {status.message}
                  </p>
                ) : null}

                <form className="mt-5 grid gap-3" onSubmit={submit}>
                  <label className="group relative">
                    <FieldIcon icon={Mail} />
                    <input
                      className={iconInputClass}
                      placeholder="Phone or Email *"
                      value={form.phoneOrEmail}
                      onChange={(event) =>
                        update("phoneOrEmail", event.target.value)
                      }
                    />
                  </label>

                  <label className="group relative">
                    <FieldIcon icon={LockKeyhole} />
                    <input
                      className={passwordInputClass}
                      type={showPassword ? "text" : "password"}
                      placeholder="Password *"
                      value={form.password}
                      onChange={(event) => update("password", event.target.value)}
                    />

                    <PasswordToggle
                      visible={showPassword}
                      onClick={() => setShowPassword((prev) => !prev)}
                    />
                  </label>

                  <div className="flex items-center justify-between gap-3">
                    <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-slate-500">
                      <input
                        type="checkbox"
                        checked={form.rememberMe}
                        onChange={(event) =>
                          update("rememberMe", event.target.checked)
                        }
                        className="h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-500"
                      />
                      Remember me
                    </label>

                    <Link
                      to="/user/forgot-password"
                      className="text-xs font-black text-blue-600 transition hover:text-blue-700"
                    >
                      Forgot password?
                    </Link>
                  </div>

                  <button
                    type="submit"
                    className="mt-1 h-12 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                  >
                    Sign in
                  </button>
                </form>

                <div className="mt-5 rounded-3xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:-translate-y-0.5 hover:shadow-sm">
                  <p className="text-sm font-black text-slate-950">
                    New patient?
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    Create profile once and use faster appointment/message
                    access next time.
                  </p>

                  <Link
                    to="/user/register"
                    className="mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-xs font-black text-teal-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-teal-50"
                  >
                    <UserPlus size={15} />
                    Signup now
                  </Link>
                </div>
              </div>
            </main>
          </div>
        </div>
      </section>
    </>
  );
};

export default UserLoginPage;