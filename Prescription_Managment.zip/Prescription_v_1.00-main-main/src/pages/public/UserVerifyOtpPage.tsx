import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  HeartPulse,
  LockKeyhole,
  LockOpen,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import {
  startPasswordReset,
  verifyPasswordResetOtp,
} from "../../lib/publicUserStorage";

const OTP_LENGTH = 6;
const TIMER_SECONDS = 60;

const verifyPageCss = `
  @keyframes authPageIn {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes softFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: 0.55; transform: scale(1); }
    50% { opacity: 0.9; transform: scale(1.06); }
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes otpFill {
    0% { opacity: 0; transform: translateY(8px) scale(0.9); }
    55% { opacity: 1; transform: translateY(-2px) scale(1.08); }
    100% { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes otpClear {
    0% { opacity: 1; transform: translateY(0) scale(1); }
    50% { opacity: 0.8; transform: translateY(3px) scale(0.94); }
    100% { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes otpShake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-3px); }
    75% { transform: translateX(3px); }
  }

  @keyframes lockPop {
    0% { opacity: 0; transform: translateY(4px) scale(0.86) rotate(-8deg); }
    60% { opacity: 1; transform: translateY(-1px) scale(1.08) rotate(4deg); }
    100% { opacity: 1; transform: translateY(0) scale(1) rotate(0); }
  }

  .auth-page-shell {
    animation: authPageIn 360ms cubic-bezier(.2,.8,.2,1) both;
  }

  .auth-float-icon {
    animation: softFloat 4s ease-in-out infinite;
  }

  .auth-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .auth-fade-up {
    animation: fadeUp 420ms ease both;
  }

  .otp-fill {
    animation: otpFill 310ms cubic-bezier(.2,.9,.2,1) both;
  }

  .otp-clear {
    animation: otpClear 260ms ease both;
  }

  .otp-shake {
    animation: otpShake 260ms ease both;
  }

  .lock-pop {
    animation: lockPop 340ms cubic-bezier(.2,.9,.2,1) both;
  }
`;

const UserVerifyOtpPage = () => {
  const navigate = useNavigate();
  const inputRefs = useRef([]);

  const [otpDigits, setOtpDigits] = useState(Array(OTP_LENGTH).fill(""));
  const [status, setStatus] = useState({ type: "", message: "" });
  const [timer, setTimer] = useState(TIMER_SECONDS);
  const [verified, setVerified] = useState(false);
  const [animatingIndexes, setAnimatingIndexes] = useState([]);
  const [clearingIndexes, setClearingIndexes] = useState([]);
  const [resending, setResending] = useState(false);
  const [lockAnimationKey, setLockAnimationKey] = useState(0);

  const otp = useMemo(() => otpDigits.join(""), [otpDigits]);
  const hasAnyDigit = otpDigits.some(Boolean);
  const isComplete = otp.length === OTP_LENGTH && otpDigits.every(Boolean);

  useEffect(() => {
    if (timer <= 0) return;

    const interval = window.setInterval(() => {
      setTimer((prev) => Math.max(prev - 1, 0));
    }, 1000);

    return () => window.clearInterval(interval);
  }, [timer]);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setLockAnimationKey((prev) => prev + 1);
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [hasAnyDigit]);

  const markAnimated = (index) => {
    setAnimatingIndexes((prev) => [...new Set([...prev, index])]);

    window.setTimeout(() => {
      setAnimatingIndexes((prev) => prev.filter((item) => item !== index));
    }, 340);
  };

  const markClearing = (index) => {
    setClearingIndexes((prev) => [...new Set([...prev, index])]);

    window.setTimeout(() => {
      setClearingIndexes((prev) => prev.filter((item) => item !== index));
    }, 300);
  };

  const focusInput = (index) => {
    inputRefs.current[index]?.focus();
  };

  const fillDigitsSequentially = (digits, startIndex = 0) => {
    const cleanDigits = digits.replace(/\D/g, "").slice(0, OTP_LENGTH);
    if (!cleanDigits) return;

    setStatus({ type: "", message: "" });
    setVerified(false);

    cleanDigits.split("").forEach((digit, digitIndex) => {
      const targetIndex = startIndex + digitIndex;
      if (targetIndex >= OTP_LENGTH) return;

      window.setTimeout(() => {
        setOtpDigits((prev) => {
          const next = [...prev];
          next[targetIndex] = digit;
          return next;
        });

        markAnimated(targetIndex);

        if (targetIndex < OTP_LENGTH - 1) {
          focusInput(targetIndex + 1);
        } else {
          focusInput(targetIndex);
        }
      }, digitIndex * 110);
    });
  };

  const updateDigit = (index, value) => {
    const cleanValue = value.replace(/\D/g, "");

    setStatus({ type: "", message: "" });
    setVerified(false);

    if (cleanValue.length > 1) {
      fillDigitsSequentially(cleanValue, index);
      return;
    }

    setOtpDigits((prev) => {
      const next = [...prev];
      next[index] = cleanValue;
      return next;
    });

    if (cleanValue) {
      markAnimated(index);

      if (index < OTP_LENGTH - 1) {
        focusInput(index + 1);
      }
    }
  };

  const handlePaste = (event, index) => {
    event.preventDefault();
    const pastedText = event.clipboardData.getData("text");
    fillDigitsSequentially(pastedText, index);
  };

  const handleKeyDown = (event, index) => {
    if (event.key === "Backspace") {
      if (otpDigits[index]) {
        setOtpDigits((prev) => {
          const next = [...prev];
          next[index] = "";
          return next;
        });
        markClearing(index);
        return;
      }

      if (index > 0) {
        focusInput(index - 1);
      }
    }

    if (event.key === "ArrowLeft" && index > 0) {
      focusInput(index - 1);
    }

    if (event.key === "ArrowRight" && index < OTP_LENGTH - 1) {
      focusInput(index + 1);
    }
  };

  const animateClearOtp = () => {
    setVerified(false);
    setStatus({ type: "", message: "" });

    const reversedIndexes = Array.from({ length: OTP_LENGTH }, (_, index) =>
      OTP_LENGTH - 1 - index
    );

    reversedIndexes.forEach((boxIndex, step) => {
      window.setTimeout(() => {
        setOtpDigits((prev) => {
          const next = [...prev];
          next[boxIndex] = "0";
          return next;
        });

        markClearing(boxIndex);
      }, step * 80);
    });

    window.setTimeout(() => {
      setOtpDigits(Array(OTP_LENGTH).fill(""));
      focusInput(0);
    }, OTP_LENGTH * 85 + 180);
  };

  const animateResendReset = () => {
    setResending(true);
    animateClearOtp();

    window.setTimeout(() => {
      setResending(false);
    }, OTP_LENGTH * 85 + 260);
  };

  const submit = (event) => {
    event.preventDefault();
    setStatus({ type: "", message: "" });

    if (!isComplete) {
      setStatus({
        type: "error",
        message: "Please enter the full 6 digit OTP.",
      });

      setAnimatingIndexes([0, 1, 2, 3, 4, 5]);
      window.setTimeout(() => setAnimatingIndexes([]), 340);
      return;
    }

    const result = verifyPasswordResetOtp(otp);
    const success = result?.success ?? result?.ok;

    if (!success) {
      setVerified(false);
      setStatus({
        type: "error",
        message: result?.message || "Invalid OTP. Please try again.",
      });

      setAnimatingIndexes([0, 1, 2, 3, 4, 5]);
      window.setTimeout(() => setAnimatingIndexes([]), 340);
      return;
    }

    setVerified(true);
    setStatus({
      type: "success",
      message: "OTP verified successfully. Redirecting...",
    });

    window.setTimeout(() => navigate("/user/reset-password"), 650);
  };

  const resend = () => {
    if (timer > 0 || resending) return;

    setStatus({ type: "", message: "" });

    let request = null;

    try {
      request = JSON.parse(
        window.localStorage.getItem("public_password_reset_request") || "null"
      );
    } catch {
      request = null;
    }

    if (!request?.email) {
      setStatus({
        type: "error",
        message: "Start reset again with email.",
      });
      return;
    }

    const result = startPasswordReset(request.email);
    const success = result?.success ?? result?.ok;

    if (!success) {
      setStatus({
        type: "error",
        message: result?.message || "Could not resend OTP.",
      });
      return;
    }

    animateResendReset();
    setTimer(TIMER_SECONDS);

    window.setTimeout(() => {
      setStatus({
        type: "success",
        message: "New OTP sent successfully.",
      });
    }, 760);
  };

  const otpBoxClass = (index) => {
    const hasValue = Boolean(otpDigits[index]);
    const animated = animatingIndexes.includes(index);
    const clearing = clearingIndexes.includes(index);

    return [
      "h-14 w-full rounded-2xl border bg-white text-center text-xl font-black tracking-widest outline-none transition duration-300 placeholder:text-slate-300 sm:h-16 sm:text-2xl",
      verified
        ? "border-emerald-300 bg-emerald-50 text-emerald-700 ring-2 ring-emerald-100"
        : status.type === "error"
        ? "border-rose-300 bg-rose-50 text-rose-700 ring-2 ring-rose-100"
        : hasValue
        ? "border-teal-300 bg-teal-50 text-teal-800 ring-2 ring-teal-100"
        : "border-slate-200 text-slate-900 focus:border-teal-400 focus:ring-2 focus:ring-teal-100",
      animated && status.type === "error" ? "otp-shake" : "",
      animated && status.type !== "error" ? "otp-fill" : "",
      clearing ? "otp-clear" : "",
    ].join(" ");
  };

  return (
    <>
      <style>{verifyPageCss}</style>

      <section className="min-h-screen bg-slate-50 px-4 py-6">
        <div className="mx-auto flex min-h-[calc(100vh-48px)] max-w-5xl items-center justify-center">
          <div className="auth-page-shell relative grid w-full overflow-hidden rounded-[34px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/10 md:grid-cols-[0.92fr_1.08fr]">
            <Link
              to="/"
              className="group absolute left-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-slate-500 shadow-sm ring-1 ring-slate-100 transition duration-300 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:text-teal-700 hover:shadow-md"
              aria-label="Back to website"
              title="Back to website"
            >
              <ArrowLeft
                size={18}
                className="transition-transform duration-300 group-hover:-translate-x-0.5"
              />
            </Link>

            <aside className="relative hidden min-h-[620px] overflow-hidden bg-gradient-to-br from-teal-900 via-teal-700 to-cyan-700 p-8 text-white md:grid">
              <span className="auth-glow absolute -left-20 top-16 h-44 w-44 rounded-full bg-white/15 blur-3xl" />
              <span className="auth-glow absolute -bottom-16 right-6 h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl" />

              <div className="relative z-10 flex h-full flex-col justify-between pt-12">
                <div>
                  <div className="flex items-center gap-3">
                    <Stethoscope
                      size={40}
                      strokeWidth={2.05}
                      className="auth-float-icon text-white"
                    />
                    <Sparkles
                      size={18}
                      className="text-cyan-100 transition-transform duration-500 hover:rotate-12"
                    />
                  </div>

                  <h1 className="mt-7 text-4xl font-black leading-tight">
                    Verify OTP
                  </h1>

                  <p className="mt-4 max-w-xs text-sm font-semibold leading-7 text-white/75">
                    First box-e OTP paste korleo smooth animation diye shob box
                    fill hobe.
                  </p>
                </div>

                <div className="grid gap-4">
                  <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={18} />
                      <p className="text-sm font-black">OTP security check</p>
                    </div>
                    <p className="mt-2 text-xs font-semibold leading-6 text-white/70">
                      OTP na dile lock thakbe. Input dile unlock animation
                      active hobe.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-black text-white/65">
                    <HeartPulse size={16} />
                    Fast account recovery
                  </div>
                </div>
              </div>
            </aside>

            <main className="flex min-h-[620px] items-center p-5 pt-20 sm:p-8 sm:pt-20">
              <div className="auth-fade-up mx-auto w-full max-w-md">
                <p className="text-[11px] font-black uppercase tracking-[0.22em] text-teal-700">
                  Patient Portal
                </p>

                <div className="mt-2 flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-3xl font-black tracking-tight text-slate-950">
                      Verify OTP
                    </h2>
                    <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                      Enter the 6 digit demo OTP sent to your registered email.
                    </p>
                  </div>

                  <div
                    key={lockAnimationKey}
                    className={[
                      "lock-pop shrink-0 transition",
                      hasAnyDigit ? "text-teal-700" : "text-slate-400",
                    ].join(" ")}
                    title={hasAnyDigit ? "OTP unlocked" : "OTP locked"}
                  >
                    {hasAnyDigit ? (
                      <LockOpen size={28} strokeWidth={2.05} />
                    ) : (
                      <LockKeyhole size={28} strokeWidth={2.05} />
                    )}
                  </div>
                </div>

                <div className="mt-5 flex items-center justify-between gap-3 rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3">
                  <p className="text-xs font-black text-slate-700">
                    OTP expires in
                  </p>

                  <span
                    className={[
                      "rounded-full px-3 py-1 text-xs font-black",
                      timer > 0
                        ? "bg-white text-teal-700"
                        : "bg-amber-100 text-amber-700",
                    ].join(" ")}
                  >
                    {timer > 0 ? `${timer}s` : "Expired"}
                  </span>
                </div>

                {status.message ? (
                  <p
                    className={[
                      "mt-4 rounded-2xl border px-4 py-3 text-xs font-black",
                      status.type === "success"
                        ? "border-emerald-100 bg-emerald-50 text-emerald-700"
                        : "border-rose-100 bg-rose-50 text-rose-700",
                    ].join(" ")}
                  >
                    {status.message}
                  </p>
                ) : null}

                <form className="mt-5 grid gap-4" onSubmit={submit}>
                  <div className="grid grid-cols-6 gap-2 sm:gap-3">
                    {otpDigits.map((digit, index) => (
                      <input
                        key={index}
                        ref={(node) => {
                          inputRefs.current[index] = node;
                        }}
                        className={otpBoxClass(index)}
                        value={digit}
                        placeholder="0"
                        inputMode="numeric"
                        autoComplete={index === 0 ? "one-time-code" : "off"}
                        maxLength={1}
                        disabled={verified || resending}
                        onChange={(event) =>
                          updateDigit(index, event.target.value)
                        }
                        onPaste={(event) => handlePaste(event, index)}
                        onKeyDown={(event) => handleKeyDown(event, index)}
                        onFocus={(event) => event.target.select()}
                        aria-label={`OTP digit ${index + 1}`}
                      />
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={!isComplete || verified || resending}
                    className="mt-1 h-12 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"
                  >
                    Verify OTP
                  </button>
                </form>

                <div className="mt-5 rounded-3xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:-translate-y-0.5 hover:shadow-sm">
                  <p className="text-sm font-black text-slate-950">
                    Did not receive OTP?
                  </p>

                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    Reset OTP চাপলে box গুলো animation দিয়ে clear হবে। Timer
                    শেষ হলে resend OTP করতে পারবে।
                  </p>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={animateClearOtp}
                      disabled={resending || verified || !hasAnyDigit}
                      className="inline-flex h-10 items-center justify-center rounded-2xl bg-white px-4 text-xs font-black text-slate-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-slate-50 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:translate-y-0"
                    >
                      Reset OTP
                    </button>

                    <button
                      type="button"
                      onClick={resend}
                      disabled={timer > 0 || resending}
                      className="inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-xs font-black text-blue-600 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-blue-50 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:translate-y-0"
                    >
                      <RotateCcw
                        size={14}
                        strokeWidth={2}
                        className={resending ? "animate-spin" : ""}
                      />
                      {timer > 0 ? `Resend in ${timer}s` : "Resend OTP"}
                    </button>

                    <Link
                      to="/user/forgot-password"
                      className="inline-flex h-10 items-center justify-center rounded-2xl bg-white px-4 text-xs font-black text-teal-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-teal-50"
                    >
                      Back
                    </Link>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </section>
    </>
  );
};

export default UserVerifyOtpPage;
