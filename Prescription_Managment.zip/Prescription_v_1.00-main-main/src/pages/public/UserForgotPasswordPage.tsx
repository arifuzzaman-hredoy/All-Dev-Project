import { useState } from "react";
import {
  ArrowLeft,
  HeartPulse,
  Mail,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { startPasswordReset } from "../../lib/publicUserStorage";

const forgotPageCss = `
  @keyframes authPageIn {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes softFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: 0.55; transform: scale(1); }
    50% { opacity: 0.9; transform: scale(1.06); }
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .auth-page-shell {
    animation: authPageIn 360ms cubic-bezier(.2,.8,.2,1) both;
  }

  .auth-float-icon {
    animation: softFloat 4s ease-in-out infinite;
  }

  .auth-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .auth-fade-up {
    animation: fadeUp 420ms ease both;
  }
`;

const FieldIcon = ({ icon: Icon }) => (
  <Icon
    size={16}
    strokeWidth={2.25}
    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 group-focus-within:-translate-y-[55%] group-focus-within:text-teal-700"
  />
);

const UserForgotPasswordPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState({ type: "", message: "" });

  const submit = (event) => {
    event.preventDefault();
    setStatus({ type: "", message: "" });

    if (!email.trim()) {
      setStatus({
        type: "error",
        message: "Registered email is required.",
      });
      return;
    }

    const result = startPasswordReset(email.trim());
    const success = result?.success ?? result?.ok;

    if (!success) {
      setStatus({
        type: "error",
        message: result?.message || "Could not send OTP. Please try again.",
      });
      return;
    }

    setStatus({
      type: "success",
      message: "OTP sent successfully. Redirecting...",
    });

    window.setTimeout(() => navigate("/user/verify-otp"), 450);
  };

  const inputClass =
    "h-11 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 focus:border-teal-500 focus:ring-4 focus:ring-teal-50";

  const iconInputClass = `${inputClass} pl-10`;

  return (
    <>
      <style>{forgotPageCss}</style>

      <section className="min-h-screen bg-slate-50 px-4 py-6">
        <div className="mx-auto flex min-h-[calc(100vh-48px)] max-w-5xl items-center justify-center">
          <div className="auth-page-shell relative grid w-full overflow-hidden rounded-[34px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/10 md:grid-cols-[0.92fr_1.08fr]">
            <Link
              to="/"
              className="group absolute left-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-slate-500 shadow-sm ring-1 ring-slate-100 transition duration-300 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:text-teal-700 hover:shadow-md"
              aria-label="Back to website"
              title="Back to website"
            >
              <ArrowLeft
                size={18}
                className="transition-transform duration-300 group-hover:-translate-x-0.5"
              />
            </Link>

            <aside className="relative hidden min-h-[620px] overflow-hidden bg-gradient-to-br from-teal-900 via-teal-700 to-cyan-700 p-8 text-white md:grid">
              <span className="auth-glow absolute -left-20 top-16 h-44 w-44 rounded-full bg-white/15 blur-3xl" />
              <span className="auth-glow absolute -bottom-16 right-6 h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl" />

              <div className="relative z-10 flex h-full flex-col justify-between pt-12">
                <div>
                  <div className="flex items-center gap-3">
                    <Stethoscope
                      size={40}
                      strokeWidth={2.05}
                      className="auth-float-icon text-white"
                    />
                    <Sparkles
                      size={18}
                      className="text-cyan-100 transition-transform duration-500 hover:rotate-12"
                    />
                  </div>

                  <h1 className="mt-7 text-4xl font-black leading-tight">
                    Password Reset
                  </h1>

                  <p className="mt-4 max-w-xs text-sm font-semibold leading-7 text-white/75">
                    Registered email diye OTP request koro, then verify kore new
                    password set koro.
                  </p>
                </div>

                <div className="grid gap-4">
                  <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={18} />
                      <p className="text-sm font-black">Secure recovery</p>
                    </div>
                    <p className="mt-2 text-xs font-semibold leading-6 text-white/70">
                      Demo OTP flow local storage based. Production-e email/SMS
                      OTP backend API লাগবে।
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-black text-white/65">
                    <HeartPulse size={16} />
                    Fast account recovery
                  </div>
                </div>
              </div>
            </aside>

            <main className="flex min-h-[620px] items-center p-5 pt-20 sm:p-8 sm:pt-20">
              <div className="auth-fade-up mx-auto w-full max-w-md">
                <p className="text-[11px] font-black uppercase tracking-[0.22em] text-teal-700">
                  Patient Portal
                </p>

                <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-950">
                  Forgot password
                </h2>

                <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                  Enter your registered email to receive a demo OTP.
                </p>

                {status.message ? (
                  <p
                    className={[
                      "mt-5 rounded-2xl border px-4 py-3 text-xs font-black",
                      status.type === "success"
                        ? "border-emerald-100 bg-emerald-50 text-emerald-700"
                        : "border-rose-100 bg-rose-50 text-rose-700",
                    ].join(" ")}
                  >
                    {status.message}
                  </p>
                ) : null}

                <form className="mt-5 grid gap-3" onSubmit={submit}>
                  <label className="group relative">
                    <FieldIcon icon={Mail} />
                    <input
                      className={iconInputClass}
                      type="email"
                      placeholder="Registered email *"
                      value={email}
                      onChange={(event) => {
                        setStatus({ type: "", message: "" });
                        setEmail(event.target.value);
                      }}
                    />
                  </label>

                  <button
                    type="submit"
                    className="mt-1 h-12 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                  >
                    Send OTP
                  </button>
                </form>

                <div className="mt-5 rounded-3xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:-translate-y-0.5 hover:shadow-sm">
                  <p className="text-sm font-black text-slate-950">
                    Remember password?
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    Go back and login with your phone/email and password.
                  </p>

                  <Link
                    to="/user/login"
                    className="mt-3 inline-flex h-10 items-center justify-center rounded-2xl bg-white px-4 text-xs font-black text-teal-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-teal-50"
                  >
                    Back to login
                  </Link>
                </div>
              </div>
            </main>
          </div>
        </div>
      </section>
    </>
  );
};

export default UserForgotPasswordPage;