import { Link } from "react-router-dom";
import { Stethoscope } from "lucide-react";

const AuthShell = ({ title, subtitle, children }) => {
  return (
    <main className="grid min-h-svh place-items-center bg-gradient-to-br from-cyan-50 via-white to-blue-50 px-4 py-8 text-slate-900">
      <section className="w-full max-w-md rounded-[28px] border border-cyan-100 bg-white/92 p-5 shadow-[0_28px_80px_rgba(13,78,86,0.16)] backdrop-blur-xl">
        <Link
          to="/"
          className="mb-5 inline-flex items-center gap-2 text-sm font-black text-teal-700"
        >
          <span className="grid h-9 w-9 place-items-center rounded-2xl bg-cyan-50">
            <Stethoscope size={18} />
          </span>
          CareBridge
        </Link>
        <h1 className="text-2xl font-black tracking-tight text-slate-950">
          {title}
        </h1>
        <p className="mt-1 text-sm font-bold leading-6 text-slate-500">
          {subtitle}
        </p>
        <div className="mt-5">{children}</div>
      </section>
    </main>
  );
};

export const authFieldClass =
  "h-11 rounded-2xl border border-cyan-100 bg-white px-3 text-sm font-bold text-slate-700 outline-none transition focus:border-teal-300";

export const authButtonClass =
  "inline-flex h-11 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5";

export const AuthStatus = ({ message, type = "error" }) => {
  if (!message) return null;

  return (
    <p
      className={`mb-3 rounded-xl px-3 py-2 text-xs font-black ${
        type === "success"
          ? "bg-emerald-50 text-emerald-700"
          : "bg-rose-50 text-rose-700"
      }`}
    >
      {message}
    </p>
  );
};

export const PasswordStrength = ({ strength }) => {
  const colorClass = {
    red: "bg-rose-500 text-rose-600",
    yellow: "bg-amber-500 text-amber-600",
    green: "bg-emerald-500 text-emerald-600",
  }[strength.color];

  const widthClass = {
    1: "w-1/3",
    2: "w-2/3",
    3: "w-full",
  }[strength.score];

  return (
    <div>
      <div className="h-1 overflow-hidden rounded-full bg-slate-100">
        <div className={`h-full rounded-full ${widthClass} ${colorClass}`} />
      </div>
      <p className={`mt-1 text-[11px] font-black ${colorClass?.split(" ")[1]}`}>
        {strength.label} password
      </p>
    </div>
  );
};

export default AuthShell;
