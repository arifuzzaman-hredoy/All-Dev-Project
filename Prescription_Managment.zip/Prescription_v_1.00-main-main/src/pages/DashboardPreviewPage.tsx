import { ArrowUpRight, CalendarClock, CheckCircle2, Clock3, UsersRound } from "lucide-react";

type DashboardPreviewPageProps = {
  title: string;
  eyebrow: string;
  description: string;
};

const stats = [
  { label: "Today activity", value: "128", note: "Live preview", icon: CalendarClock },
  { label: "Active records", value: "42", note: "Mock data", icon: UsersRound },
  { label: "Completed", value: "86%", note: "This week", icon: CheckCircle2 },
  { label: "Pending review", value: "09", note: "Needs action", icon: Clock3 },
];

const rows = [
  { id: "01", name: "Central Care Clinic", detail: "Subscription renewal", status: "Active", time: "09:30 AM" },
  { id: "02", name: "North Point Chamber", detail: "Billing follow-up", status: "Pending", time: "10:15 AM" },
  { id: "03", name: "Green Valley Health", detail: "Support request", status: "Review", time: "11:45 AM" },
];

const statusClass = (status: string) => {
  if (status === "Active") return "bg-emerald-50 text-emerald-700";
  if (status === "Pending") return "bg-amber-50 text-amber-700";
  return "bg-cyan-50 text-teal-700";
};

const DashboardPreviewPage = ({ title, eyebrow, description }: DashboardPreviewPageProps) => {
  return (
    <main className="min-h-[calc(100svh-6rem)] rounded-[1.35rem] bg-[#f7f9fb] p-4 text-slate-900 sm:p-5">
      <section className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
        <div className="min-w-0">
          <p className="mb-1 text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">{eyebrow}</p>
          <h1 className="text-[26px] font-black tracking-tight text-slate-950 sm:text-[30px]">{title}</h1>
          <p className="mt-1 max-w-2xl text-[13px] font-semibold leading-6 text-slate-500">{description}</p>
        </div>

        <span className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-white px-3 text-[11px] font-black text-teal-800 shadow-[0_10px_26px_rgba(11,86,90,0.08)]">
          <ArrowUpRight size={14} />
          UI shell
        </span>
      </section>

      <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((item) => {
          const Icon = item.icon;

          return (
            <article key={item.label} className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.08em] text-slate-400">{item.label}</p>
                  <h2 className="mt-2 text-2xl font-black text-slate-950">{item.value}</h2>
                  <p className="mt-1 text-[12px] font-bold text-slate-500">{item.note}</p>
                </div>
                <span className="grid h-10 w-10 place-items-center rounded-2xl bg-cyan-50 text-teal-700">
                  <Icon size={19} />
                </span>
              </div>
            </article>
          );
        })}
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-[1.4fr_0.8fr]">
        <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">Workspace</p>
              <h3 className="text-base font-black text-slate-950">Recent activity</h3>
            </div>
          </div>

          <div className="grid gap-2">
            {rows.map((row) => (
              <div key={row.id} className="grid gap-3 rounded-2xl bg-slate-50 px-3 py-3 text-[12px] font-bold text-slate-600 sm:grid-cols-[40px_1fr_100px_86px] sm:items-center">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[11px] font-black text-teal-800">{row.id}</span>
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-black text-slate-950">{row.name}</span>
                  <span className="block truncate text-[11px] text-slate-500">{row.detail}</span>
                </span>
                <span className="inline-flex w-fit rounded-full bg-white px-2.5 py-1 text-[11px] font-black text-slate-500">{row.time}</span>
                <span className={["inline-flex w-fit rounded-full px-2.5 py-1 text-[11px] font-black", statusClass(row.status)].join(" ")}>{row.status}</span>
              </div>
            ))}
          </div>
        </article>

        <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
          <p className="text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">Preview note</p>
          <h3 className="mt-1 text-base font-black text-slate-950">Frontend only</h3>
          <p className="mt-2 text-[13px] font-semibold leading-6 text-slate-500">
            This route is wired with local mock data so the browser can show the new product areas before backend integration.
          </p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-blue-600 to-teal-500" />
          </div>
        </article>
      </section>
    </main>
  );
};

export default DashboardPreviewPage;
