import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicPatientsPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Patients"
    description="Browse patient records, visit history and quick operational status using mock rows."
  />
);

export default ClinicPatientsPage;
