import { CalendarClock, CheckCircle2, Clock3, CreditCard, FileText, UsersRound } from "lucide-react";
import { Link } from "react-router-dom";
import DemoNotice from "../components/common/DemoNotice";
import PageHeader from "../components/common/PageHeader";
import StatCard from "../components/common/StatCard";
import StatusBadge from "../components/common/StatusBadge";

type DemoWorkspacePageProps = {
  eyebrow: string;
  title: string;
  description: string;
  stats?: Array<{ label: string; value: string; note: string }>;
  notice?: string;
};

const defaultStats = [
  { label: "Today activity", value: "128", note: "Live preview" },
  { label: "Active records", value: "42", note: "Mock data" },
  { label: "Completed", value: "86%", note: "This week" },
  { label: "Pending review", value: "09", note: "Needs action" },
];

const icons = [CalendarClock, UsersRound, CheckCircle2, Clock3, CreditCard, FileText];

const rows = [
  { id: "01", name: "Nusrat Jahan", detail: "Appointment and billing follow-up", status: "Active", time: "09:30 AM" },
  { id: "02", name: "Rafiqul Islam", detail: "Prescription review pending", status: "Pending", time: "10:15 AM" },
  { id: "03", name: "Prime Diagnostic", detail: "Report delivery and collection", status: "Review", time: "11:45 AM" },
];

const DemoWorkspacePage = ({ eyebrow, title, description, stats = defaultStats, notice }: DemoWorkspacePageProps) => (
  <main className="min-h-[calc(100svh-6rem)] rounded-[1.35rem] bg-[#f7f9fb] p-4 text-slate-900 sm:p-5">
    <div className="grid gap-4">
      <PageHeader
        eyebrow={eyebrow}
        title={title}
        description={description}
        actions={
          <>
            <Link to="/demo" className="rounded-full bg-cyan-50 px-4 py-2 text-[12px] font-black text-teal-800 transition hover:bg-cyan-100">
              Demo routes
            </Link>
            <Link to="/book-demo" className="rounded-full bg-teal-700 px-4 py-2 text-[12px] font-black text-white transition hover:bg-teal-800">
              Book demo
            </Link>
          </>
        }
      />
      <DemoNotice text={notice} />
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((item, index) => (
          <StatCard key={item.label} {...item} icon={icons[index % icons.length]} />
        ))}
      </section>
      <section className="grid gap-4 xl:grid-cols-[1.35fr_0.85fr]">
        <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
          <div className="mb-3">
            <p className="text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">Demo table</p>
            <h3 className="text-base font-black text-slate-950">Recent records</h3>
          </div>
          <div className="grid gap-2">
            {rows.map((row) => (
              <div key={row.id} className="grid gap-3 rounded-2xl bg-slate-50 px-3 py-3 text-[12px] font-bold text-slate-600 sm:grid-cols-[40px_1fr_96px_86px] sm:items-center">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[11px] font-black text-teal-800">{row.id}</span>
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-black text-slate-950">{row.name}</span>
                  <span className="block truncate text-[11px] text-slate-500">{row.detail}</span>
                </span>
                <span className="inline-flex w-fit rounded-full bg-white px-2.5 py-1 text-[11px] font-black text-slate-500">{row.time}</span>
                <StatusBadge status={row.status} />
              </div>
            ))}
          </div>
        </article>
        <article className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_12px_30px_rgba(15,23,42,0.04)]">
          <p className="text-[10px] font-black uppercase tracking-[0.1em] text-teal-700">Quick actions</p>
          <div className="mt-3 grid gap-2">
            {["Create record", "Export report", "Send SMS", "Open settings"].map((action) => (
              <button key={action} type="button" className="rounded-xl bg-slate-50 px-3 py-2 text-left text-[12px] font-black text-slate-700 transition hover:bg-cyan-50 hover:text-teal-700">
                {action}
              </button>
            ))}
          </div>
        </article>
      </section>
    </div>
  </main>
);

export default DemoWorkspacePage;
