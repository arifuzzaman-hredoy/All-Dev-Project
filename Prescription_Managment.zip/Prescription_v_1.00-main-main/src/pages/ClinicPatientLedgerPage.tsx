import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicPatientLedgerPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Patient ledger"
    description="Preview patient balances, transaction history and ledger notes."
  />
);

export default ClinicPatientLedgerPage;
