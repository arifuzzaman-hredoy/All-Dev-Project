import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicReportsPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Reports"
    description="Inspect operational reporting shells for visits, revenue and care activity."
  />
);

export default ClinicReportsPage;
