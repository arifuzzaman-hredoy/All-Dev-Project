import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminSubscriptionsPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Subscriptions"
    description="Track trial, active, expiring and suspended subscriptions with placeholder records."
  />
);

export default SuperAdminSubscriptionsPage;
