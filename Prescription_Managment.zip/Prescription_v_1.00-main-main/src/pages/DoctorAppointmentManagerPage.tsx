import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CalendarDays,
  CheckCircle2,
  FileText,
  Filter,
  Phone,
  Printer,
  Search,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import CmsEmptyState from "../components/cms/CmsEmptyState";
import CmsSectionCard from "../components/cms/CmsSectionCard";
import CmsToolbar from "../components/cms/CmsToolbar";
import { apiFetch } from "../lib/apiClient";
import { formatDate } from "../publicSite/lib/dateFormat";
import {
  getPublicAppointments,
  savePublicAppointments,
} from "../publicSite/lib/publicStorage";

const ACTIVE_PATIENT_KEY = "active_prescription_patient";

const printStyles = `
  @media print {
    @page {
      size: A4 portrait;
      margin: 7mm;
    }

    html,
    body {
      width: 210mm !important;
      min-height: 297mm !important;
      margin: 0 !important;
      padding: 0 !important;
      background: #ffffff !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    body * {
      visibility: hidden !important;
    }

    #appointments-print-area,
    #appointments-print-area * {
      visibility: visible !important;
    }

    #appointments-print-area {
      position: absolute !important;
      inset: 0 auto auto 0 !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
      border: 0 !important;
      border-radius: 0 !important;
      box-shadow: none !important;
      background: #ffffff !important;
      overflow: visible !important;
    }

    .no-print {
      display: none !important;
      visibility: hidden !important;
    }

    .print-scroll {
      overflow: visible !important;
      width: 100% !important;
    }

    .print-sheet {
      width: 100% !important;
      max-width: 100% !important;
      border: 0 !important;
      border-radius: 0 !important;
      box-shadow: none !important;
      padding: 0 !important;
      margin: 0 !important;
      background: #ffffff !important;
    }

    .print-table {
      width: 100% !important;
      min-width: 0 !important;
      table-layout: fixed !important;
      border-collapse: collapse !important;
      font-size: 8.2px !important;
      line-height: 1.22 !important;
      color: #0f172a !important;
    }

    .print-table th,
    .print-table td {
      border: 1px solid #dbeafe !important;
      padding: 4px 4px !important;
      vertical-align: top !important;
      word-break: break-word !important;
      overflow-wrap: anywhere !important;
      white-space: normal !important;
    }

    .print-table th {
      background: #ecfeff !important;
      color: #334155 !important;
      font-size: 7px !important;
      letter-spacing: 0.03em !important;
      text-transform: uppercase !important;
      font-weight: 900 !important;
    }

    .print-title {
      font-size: 17px !important;
      line-height: 1.1 !important;
      margin: 0 !important;
    }

    .print-subtitle {
      font-size: 9px !important;
      margin-top: 2px !important;
      color: #475569 !important;
    }

    .print-meta {
      font-size: 8px !important;
      line-height: 1.45 !important;
      color: #334155 !important;
    }

    .print-badge {
      padding: 2px 5px !important;
      border-radius: 999px !important;
      font-size: 6.8px !important;
      line-height: 1 !important;
      white-space: nowrap !important;
    }

    .print-icon {
      display: none !important;
    }

    .print-problem {
      max-height: none !important;
      overflow: visible !important;
      display: block !important;
    }

    .screen-action {
      display: none !important;
      visibility: hidden !important;
    }
  }
`;

const statusOptions = ["all", "pending", "confirmed", "completed", "cancelled"];

const getStatus = (item) => {
  return String(item.status || item.appointmentStatus || "pending").toLowerCase();
};

const toTitleStatus = (status) => {
  const value = String(status || "pending").toLowerCase();
  return value.charAt(0).toUpperCase() + value.slice(1);
};

const getPatientId = (item, index = 0) => {
  return (
    item.patientId ||
    item.patientID ||
    item.patientCode ||
    item.publicUserId ||
    item.userId ||
    item.patient?.id ||
    (item.phone
      ? `PID-${String(item.phone).slice(-4)}`
      : `PID-${String(index + 1).padStart(4, "0")}`)
  );
};

const getAssignedDate = (item) => {
  return item.assignedDate || item.preferredDate || "";
};

const getAssignedTime = (item) => {
  return item.assignedTime || item.preferredTime || "";
};

const padSerial = (value) => {
  if (!value) return "-";
  return String(value).padStart(2, "0");
};

const formatTimeLabel = (time) => {
  if (!time) return "-";

  const [hour, minute] = String(time).split(":").map(Number);

  if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
    return time;
  }

  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;

  return `${String(displayHour).padStart(2, "0")}:${String(minute).padStart(
    2,
    "0"
  )} ${suffix}`;
};

const statusBadgeClass = (status) => {
  const value = String(status || "pending").toLowerCase();

  if (value === "confirmed") return "bg-blue-50 text-blue-700 ring-blue-100";
  if (value === "completed")
    return "bg-emerald-50 text-emerald-700 ring-emerald-100";
  if (value === "cancelled") return "bg-red-50 text-red-700 ring-red-100";

  return "bg-amber-50 text-amber-700 ring-amber-100";
};

const buildPrescriptionPatientPayload = (item, index = 0) => {
  const patientId = getPatientId(item, index);
  const appointmentId =
    item.appointmentId ||
    item.appointmentCode ||
    item.trackingId ||
    item.recordId ||
    item.id ||
    item.serialNo ||
    "";

  return {
    id: patientId,
    patientId,
    patientName: item.patientName || item.name || item.patient?.name || "",
    name: item.patientName || item.name || item.patient?.name || "",
    phone: item.phone || item.mobile || item.patient?.phone || "",
    age: item.age || "",
    gender: item.gender || "",
    problem: item.problem || "",
    message: item.message || "",
    appointmentId,
    appointmentCode: item.appointmentCode || "",
    trackingId: item.trackingId || "",
    recordId: item.recordId || "",
    serial: item.serialNo || appointmentId,
    serialNo: item.serialNo || "",
    preferredDate: item.preferredDate || "",
    preferredTime: item.preferredTime || "",
    assignedDate: getAssignedDate(item),
    assignedTime: getAssignedTime(item),
    status: getStatus(item),
  };
};

const DoctorAppointmentManagerPage = () => {
  const navigate = useNavigate();

  const [appointments, setAppointments] = useState(getPublicAppointments);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(false);

  const persist = (next) => {
    setAppointments(next);
    savePublicAppointments(next);
  };

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setLoading(true);

      apiFetch("/api/appointments")
        .then((response) => {
          const next = Array.isArray(response.data) ? response.data : [];
          persist(next);
          setNotice("");
        })
        .catch((error) => {
          setNotice(
            error.message ||
              "Could not load backend appointments. Showing local fallback."
          );
        })
        .finally(() => setLoading(false));
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const openPrescription = (item, index = 0) => {
    const patient = buildPrescriptionPatientPayload(item, index);

    window.sessionStorage.setItem(ACTIVE_PATIENT_KEY, JSON.stringify(patient));

    navigate("/doctor/prescriptions", {
      state: {
        patient,
      },
    });
  };

  const updateStatus = async (id, status) => {
    const current = appointments.find(
      (item) => item.id === id || item.recordId === id
    );
    const recordId = current?.recordId;

    const next = appointments.map((item) =>
      item.id === id || item.recordId === id
        ? {
            ...item,
            status,
            appointmentStatus: toTitleStatus(status),
          }
        : item
    );

    persist(next);

    if (!recordId) return;

    try {
      await apiFetch(`/api/appointments/${recordId}/status`, {
        method: "PUT",
        body: JSON.stringify({ status }),
      });
      setNotice("");
    } catch (error) {
      setNotice(error.message || "Status updated locally but backend save failed.");
    }
  };

  const deleteAppointment = async (id) => {
    const ok = window.confirm("Delete this appointment request?");
    if (!ok) return;

    const current = appointments.find(
      (item) => item.id === id || item.recordId === id
    );

    persist(
      appointments.filter((entry) => entry.id !== id && entry.recordId !== id)
    );

    if (!current?.recordId) return;

    try {
      await apiFetch(`/api/appointments/${current.recordId}`, {
        method: "DELETE",
      });
      setNotice("");
    } catch (error) {
      setNotice(
        error.message || "Appointment deleted locally but backend delete failed."
      );
    }
  };

  const filteredAppointments = useMemo(() => {
    const query = search.trim().toLowerCase();

    return appointments.filter((item, index) => {
      const status = getStatus(item);
      const assignedDate = getAssignedDate(item);
      const patientId = getPatientId(item, index);

      const matchesStatus =
        statusFilter === "all" || status === statusFilter.toLowerCase();

      const matchesDate = !dateFilter || assignedDate === dateFilter;

      const searchableText = [
        patientId,
        item.appointmentCode,
        item.trackingId,
        item.patientName,
        item.phone,
        item.age,
        item.gender,
        item.problem,
        item.message,
        item.preferredDate,
        item.preferredTime,
        item.assignedDate,
        item.assignedTime,
        item.serialNo,
        status,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return (
        matchesStatus &&
        matchesDate &&
        (!query || searchableText.includes(query))
      );
    });
  }, [appointments, search, statusFilter, dateFilter]);

  const stats = useMemo(() => {
    return {
      total: appointments.length,
      pending: appointments.filter((item) => getStatus(item) === "pending")
        .length,
      confirmed: appointments.filter((item) => getStatus(item) === "confirmed")
        .length,
      completed: appointments.filter((item) => getStatus(item) === "completed")
        .length,
      cancelled: appointments.filter((item) => getStatus(item) === "cancelled")
        .length,
    };
  }, [appointments]);

  const resetFilters = () => {
    setSearch("");
    setStatusFilter("all");
    setDateFilter("");
  };

  return (
    <>
      <style>{printStyles}</style>

      <section className="mx-auto grid max-w-7xl gap-4">
        <div className="no-print">
          <CmsToolbar
            title="Appointments"
            description={
              notice ||
              (loading
                ? "Loading backend appointments..."
                : "Click any appointment row or Prescription button to open RX with patient details.")
            }
          />
        </div>

        <CmsSectionCard title="Appointment Requests">
          <div className="no-print grid gap-3">
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
              <StatCard
                title="Total"
                value={stats.total}
                icon={FileText}
                className="text-slate-700"
              />
              <StatCard
                title="Pending"
                value={stats.pending}
                icon={CalendarDays}
                className="text-amber-700"
              />
              <StatCard
                title="Confirmed"
                value={stats.confirmed}
                icon={CheckCircle2}
                className="text-blue-700"
              />
              <StatCard
                title="Completed"
                value={stats.completed}
                icon={CheckCircle2}
                className="text-emerald-700"
              />
              <StatCard
                title="Cancelled"
                value={stats.cancelled}
                icon={X}
                className="text-red-700"
              />
            </div>

            <div className="grid gap-2 rounded-2xl border border-cyan-100 bg-white/80 p-2.5 lg:grid-cols-[1fr_155px_155px_78px_108px]">
              <label className="relative">
                <Search
                  size={15}
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  className="h-9 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-xs font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-teal-400 focus:ring-2 focus:ring-teal-50"
                  placeholder="Search ID, name, phone, problem..."
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                />
              </label>

              <label className="relative">
                <Filter
                  size={15}
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <select
                  className="h-9 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-xs font-black text-slate-700 outline-none transition focus:border-teal-400 focus:ring-2 focus:ring-teal-50"
                  value={statusFilter}
                  onChange={(event) => setStatusFilter(event.target.value)}
                >
                  {statusOptions.map((item) => (
                    <option key={item} value={item}>
                      {item === "all" ? "All Status" : toTitleStatus(item)}
                    </option>
                  ))}
                </select>
              </label>

              <input
                className="h-9 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-700 outline-none transition focus:border-teal-400 focus:ring-2 focus:ring-teal-50"
                type="date"
                value={dateFilter}
                onChange={(event) => setDateFilter(event.target.value)}
              />

              <button
                type="button"
                onClick={resetFilters}
                className="h-9 rounded-xl border border-slate-200 bg-white px-3 text-[11px] font-black text-slate-600 transition hover:bg-slate-50"
              >
                Clear
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex h-9 items-center justify-center gap-1.5 rounded-xl bg-teal-700 px-3 text-[11px] font-black text-white shadow-lg shadow-teal-700/15 transition hover:bg-teal-800"
              >
                <Printer size={14} />
                Print
              </button>
            </div>
          </div>

          <div
            id="appointments-print-area"
            className="print-sheet mt-3 rounded-2xl border border-cyan-100 bg-white p-3 shadow-sm"
          >
            <div className="mb-2 flex items-start justify-between gap-3">
              <div>
                <p className="text-[9px] font-black uppercase tracking-[0.22em] text-teal-700">
                  Doctor Panel
                </p>
                <h2 className="print-title text-lg font-black leading-tight text-slate-950">
                  Appointment List
                </h2>
                <p className="print-subtitle text-[11px] font-bold text-slate-500">
                  Showing {filteredAppointments.length} of {appointments.length}{" "}
                  requests
                </p>
              </div>

              <div className="print-meta text-right text-[11px] font-bold text-slate-500">
                <p>Printed: {new Date().toLocaleDateString("en-GB")}</p>
                <p>
                  Status:{" "}
                  {statusFilter === "all" ? "All" : toTitleStatus(statusFilter)}
                </p>
                {dateFilter ? <p>Date: {dateFilter}</p> : null}
              </div>
            </div>

            {filteredAppointments.length ? (
              <div className="print-scroll overflow-x-auto">
                <table className="print-table w-full min-w-[960px] border-collapse text-left text-[11px]">
                  <colgroup>
                    <col className="w-[4%]" />
                    <col className="w-[12%]" />
                    <col className="w-[18%]" />
                    <col className="w-[12%]" />
                    <col className="w-[8%]" />
                    <col className="w-[14%]" />
                    <col className="w-[21%]" />
                    <col className="w-[9%]" />
                    <col className="screen-action w-[16%]" />
                  </colgroup>

                  <thead>
                    <tr className="bg-cyan-50 text-[10px] uppercase tracking-wide text-slate-600">
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        SL
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        ID / Serial
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Patient
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Phone
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Age/Sex
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Date / Time
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Problem
                      </th>
                      <th className="border border-cyan-100 px-2 py-1.5 font-black">
                        Status
                      </th>
                      <th className="screen-action border border-cyan-100 px-2 py-1.5 font-black">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredAppointments.map((item, index) => {
                      const status = getStatus(item);
                      const assignedDate = getAssignedDate(item);
                      const assignedTime = getAssignedTime(item);
                      const patientId = getPatientId(item, index);
                      const appointmentCode =
                        item.appointmentCode || item.trackingId || item.id;

                      return (
                        <tr
                          key={item.id || item.recordId || index}
                          onClick={() => openPrescription(item, index)}
                          className="cursor-pointer border-b border-cyan-50 bg-white align-top transition hover:bg-cyan-50/50"
                          title="Click to open prescription with patient details"
                        >
                          <td className="border border-cyan-50 px-2 py-1.5 font-black text-slate-500">
                            {index + 1}
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5">
                            <p className="font-black text-blue-700">
                              {patientId}
                            </p>
                            <p className="text-[10px] font-black text-teal-700">
                              Apt {appointmentCode}
                            </p>
                            <p className="text-[10px] font-black text-slate-500">
                              Serial #{padSerial(item.serialNo)}
                            </p>
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5">
                            <div className="flex items-start gap-1.5">
                              <UserRound
                                size={13}
                                className="print-icon mt-0.5 shrink-0 text-slate-400"
                              />
                              <div>
                                <p className="font-black text-slate-950">
                                  {item.patientName || "-"}
                                </p>
                                <p className="text-[10px] font-bold text-slate-400">
                                  {formatDate(item.createdAt)}
                                </p>
                              </div>
                            </div>
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5">
                            <div className="flex items-center gap-1.5 font-bold text-slate-700">
                              <Phone
                                size={12}
                                className="print-icon text-slate-400"
                              />
                              {item.phone || "-"}
                            </div>
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5 font-bold text-slate-600">
                            {item.age || "-"} / {item.gender || "-"}
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5 font-bold text-slate-700">
                            <p>
                              {assignedDate || item.preferredDate || "Any date"}
                            </p>
                            <p className="text-[10px] font-black text-teal-700">
                              {formatTimeLabel(
                                assignedTime || item.preferredTime
                              )}
                            </p>
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5">
                            <p className="print-problem font-semibold leading-4 text-slate-600">
                              {item.problem || "-"}
                            </p>
                            {item.message ? (
                              <p className="mt-0.5 text-[10px] font-bold leading-4 text-slate-400">
                                Note: {item.message}
                              </p>
                            ) : null}
                          </td>

                          <td className="border border-cyan-50 px-2 py-1.5">
                            <span
                              className={[
                                "print-badge inline-flex rounded-full px-2 py-1 text-[9px] font-black uppercase tracking-wide ring-1",
                                statusBadgeClass(status),
                              ].join(" ")}
                            >
                              {status}
                            </span>
                          </td>

                          <td
                            className="screen-action border border-cyan-50 px-2 py-1.5"
                            onClick={(event) => event.stopPropagation()}
                          >
                            <div className="flex min-w-[150px] items-center gap-1.5">
                              <select
                                className="h-8 flex-1 rounded-lg border border-slate-200 bg-white px-2 text-[10px] font-black text-slate-700 outline-none focus:border-teal-400 focus:ring-2 focus:ring-teal-50"
                                value={status}
                                onChange={(event) =>
                                  updateStatus(item.id || item.recordId, event.target.value)
                                }
                              >
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                              </select>

                              <button
                                type="button"
                                onClick={() => openPrescription(item, index)}
                                className="inline-flex h-8 items-center gap-1 rounded-lg border border-blue-100 bg-blue-50 px-2 text-[10px] font-black text-blue-700 transition hover:bg-blue-100"
                                title="Open prescription"
                              >
                                <FileText size={12} />
                                Rx
                              </button>

                              <button
                                type="button"
                                onClick={() =>
                                  deleteAppointment(item.id || item.recordId)
                                }
                                className="grid h-8 w-8 place-items-center rounded-lg border border-red-100 bg-red-50 text-red-600 transition hover:bg-red-100"
                                title="Delete appointment"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <CmsEmptyState
                title="No appointments found"
                message="Try changing search, status or date filter."
              />
            )}
          </div>
        </CmsSectionCard>
      </section>
    </>
  );
};

const StatCard = ({ title, value, icon: Icon, className = "" }) => {
  return (
    <div className="rounded-2xl border border-cyan-100 bg-white/80 p-3 shadow-sm">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[10px] font-black uppercase tracking-wide text-slate-400">
            {title}
          </p>
          <p className="mt-0.5 text-xl font-black text-slate-950">{value}</p>
        </div>

        <Icon size={17} className={className} />
      </div>
    </div>
  );
};

export default DoctorAppointmentManagerPage;