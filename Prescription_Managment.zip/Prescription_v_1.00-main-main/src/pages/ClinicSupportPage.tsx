import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicSupportPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Support"
    description="Preview clinic support tickets, messages and issue status."
  />
);

export default ClinicSupportPage;
