import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  Building2,
  CalendarDays,
  Database,
  Gauge,
  Hospital,
  Layers,
  LockKeyhole,
  Server,
  ShieldCheck,
  Stethoscope,
  Users,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { demoPackages } from "../lib/demoPackages";
import { quickDemoRoutes } from "../lib/demoRoutes";

type DemoRecord = Record<string, unknown>;

const heroTitle =
  "Clinic ERP SaaS for Doctors, Clinics, Diagnostic Centers and Hospitals";

const routeIcons: LucideIcon[] = [
  Activity,
  CalendarDays,
  Database,
  Building2,
  Hospital,
  ShieldCheck,
  Users,
  Layers,
];

const packageIcons: LucideIcon[] = [
  Stethoscope,
  Building2,
  Activity,
  Hospital,
  Database,
  ShieldCheck,
  Users,
  Layers,
];

const backendFlow = [
  {
    label: "Frontend",
    value: "Public site, dashboards, CMS UI",
    icon: Layers,
  },
  {
    label: "Backend API",
    value: "Tenant-aware routes and controllers",
    icon: Server,
  },
  {
    label: "Database",
    value: "Patient, billing, package, subscription data",
    icon: Database,
  },
  {
    label: "Auth & Access",
    value: "Login, role permission, module entitlement",
    icon: LockKeyhole,
  },
];

const getText = (
  source: DemoRecord,
  keys: string[],
  fallback: string,
): string => {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "string" && value.trim()) return value;
  }

  return fallback;
};

const getList = (
  source: DemoRecord,
  keys: string[],
  fallback: string[],
): string[] => {
  for (const key of keys) {
    const value = source[key];

    if (Array.isArray(value)) {
      return value.filter((item): item is string => typeof item === "string");
    }
  }

  return fallback;
};

const getPath = (
  source: DemoRecord,
  keys: string[],
  fallback: string,
): string => {
  const path = getText(source, keys, fallback);
  return path.startsWith("/") ? path : fallback;
};

const useTypingText = (text: string, speed = 30) => {
  const [typingState, setTypingState] = useState({
    source: text,
    index: 0,
  });

  useEffect(() => {
    let index = 0;

    const interval = window.setInterval(() => {
      index += 1;
      setTypingState({ source: text, index });

      if (index >= text.length) {
        window.clearInterval(interval);
      }
    }, speed);

    return () => window.clearInterval(interval);
  }, [text, speed]);

  return typingState.source === text ? text.slice(0, typingState.index) : "";
};

const useCountUp = (end: number, duration = 1300) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let frame = 0;
    const totalFrames = Math.max(1, Math.round(duration / 16));

    const timer = window.setInterval(() => {
      frame += 1;

      const progress = Math.min(frame / totalFrames, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      setValue(Math.round(end * eased));

      if (progress >= 1) {
        window.clearInterval(timer);
      }
    }, 16);

    return () => window.clearInterval(timer);
  }, [end, duration]);

  return value;
};

const PremiumButton = ({
  to,
  children,
  variant = "primary",
}: {
  to: string;
  children: ReactNode;
  variant?: "primary" | "ghost";
}) => (
  <Link
    to={to}
    className={[
      "group relative inline-flex min-w-[132px] items-center justify-center gap-2 overflow-hidden border px-4 py-2.5 text-xs font-black uppercase tracking-[0.08em]",
      "transition-all duration-300 ease-out hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/20",
      variant === "primary"
        ? "border-white bg-white text-black hover:bg-white/90"
        : "border-white/[0.12] bg-white/[0.04] text-white/72 hover:border-white/30 hover:bg-white/[0.09] hover:text-white",
    ].join(" ")}
  >
    <span className="relative z-10 whitespace-nowrap">{children}</span>
    <ArrowRight
      size={14}
      strokeWidth={2.7}
      className="relative z-10 shrink-0 transition-transform duration-300 group-hover:translate-x-1"
    />
    <span className="absolute bottom-1.5 left-4 right-4 h-px origin-left scale-x-0 bg-current opacity-40 transition-transform duration-300 group-hover:scale-x-100" />
  </Link>
);

const PremiumIcon = ({
  icon: Icon,
  size = 28,
}: {
  icon: LucideIcon;
  size?: number;
}) => (
  <span className="relative inline-flex">
    <Icon
      size={size}
      strokeWidth={1.8}
      className="relative z-10 text-white/40 transition-all duration-500 ease-out group-hover:-translate-y-1 group-hover:rotate-[-3deg] group-hover:scale-110 group-hover:text-white"
    />
    <Icon
      size={size}
      strokeWidth={1.8}
      className="absolute inset-0 text-white/[0.09] opacity-0 blur-[1px] transition-all duration-500 ease-out group-hover:translate-x-1 group-hover:translate-y-1 group-hover:opacity-100"
    />
  </span>
);

const StatCard = ({
  end,
  suffix,
  label,
  icon: Icon,
}: {
  end: number;
  suffix?: string;
  label: string;
  icon: LucideIcon;
}) => {
  const value = useCountUp(end);

  return (
    <div className="group relative overflow-hidden border border-white/[0.09] bg-white/[0.035] px-4 py-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-white/24 hover:bg-white/[0.075]">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-2xl font-black leading-none text-white">
            {value}
            {suffix}
          </p>
          <p className="mt-1 truncate text-[10px] font-bold uppercase tracking-[0.13em] text-white/42 group-hover:text-white/65">
            {label}
          </p>
        </div>

        <Icon
          size={19}
          strokeWidth={1.8}
          className="shrink-0 text-white/28 transition-all duration-500 group-hover:-translate-y-0.5 group-hover:scale-110 group-hover:text-white/75"
        />
      </div>

      <span className="absolute bottom-0 left-0 h-px w-0 bg-white/50 transition-all duration-500 group-hover:w-full" />
    </div>
  );
};

const BackendFlowPanel = () => (
  <section className="border border-white/[0.09] bg-white/[0.035] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.30)]">
    <div className="mb-5 flex items-end justify-between gap-3 border-b border-white/[0.08] pb-4">
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/38">
          Frontend + Backend
        </p>
        <h2 className="mt-2 text-xl font-black text-white">
          Logical SaaS architecture
        </h2>
      </div>

      <Workflow size={26} strokeWidth={1.7} className="text-white/38" />
    </div>

    <div className="grid gap-3">
      {backendFlow.map((item, index) => {
        const Icon = item.icon;

        return (
          <div
            key={item.label}
            className="group relative grid grid-cols-[30px_1fr_auto] items-center gap-3 border border-white/[0.08] bg-black/25 p-3.5 transition-all duration-300 hover:-translate-y-0.5 hover:border-white/24 hover:bg-white/[0.065]"
          >
            <Icon
              size={22}
              strokeWidth={1.8}
              className="text-white/42 transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-[-4deg] group-hover:scale-110 group-hover:text-white"
            />

            <div className="min-w-0">
              <p className="truncate text-sm font-black text-white">
                {item.label}
              </p>
              <p className="mt-0.5 truncate text-xs font-semibold text-white/44">
                {item.value}
              </p>
            </div>

            <span className="relative inline-flex h-6 w-8 items-center justify-end overflow-hidden">
              <span className="absolute right-1 h-px w-0 bg-white/70 transition-all duration-300 group-hover:w-7" />
              <ArrowRight
                size={17}
                className="relative z-10 text-white/35 transition-all duration-300 group-hover:translate-x-1 group-hover:text-white"
              />
            </span>

            {index < backendFlow.length - 1 && (
              <span className="absolute -bottom-3 left-[24px] h-3 w-px bg-white/[0.10]" />
            )}
          </div>
        );
      })}
    </div>

    <div className="mt-4 border border-emerald-400/20 bg-emerald-400/[0.06] p-3">
      <p className="text-[10px] font-black uppercase tracking-[0.18em] text-emerald-200/80">
        Backend Login Protected
      </p>
      <p className="mt-1 text-xs font-semibold leading-5 text-white/50">
        Login route and backend authentication flow stay separate. This page only
        shows the SaaS frontend presentation layer.
      </p>
    </div>
  </section>
);

const RoutePreviewCard = ({
  item,
  index,
}: {
  item: DemoRecord;
  index: number;
}) => {
  const title = getText(item, ["label", "title", "name"], "Demo Route");
  const description = getText(
    item,
    ["description", "subtitle"],
    "Open this demo flow and test the route instantly.",
  );
  const to = getPath(item, ["to", "url", "path", "href"], "/demo");
  const Icon = routeIcons[index % routeIcons.length];

  return (
    <Link
      to={to}
      className="group relative min-h-[128px] overflow-hidden border border-white/[0.09] bg-white/[0.035] p-4 transition-all duration-300 ease-out hover:-translate-y-1 hover:border-white/24 hover:bg-white/[0.075] hover:shadow-[0_18px_52px_rgba(0,0,0,0.32)]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <PremiumIcon icon={Icon} size={24} />

          <p className="mt-4 text-[10px] font-black uppercase tracking-[0.18em] text-white/38">
            Route
          </p>

          <h3 className="mt-2 truncate text-sm font-black text-white">
            {title}
          </h3>
        </div>

        <span className="relative mt-1 inline-flex h-6 w-8 shrink-0 items-center justify-end overflow-hidden">
          <span className="absolute right-1 h-px w-0 bg-white/75 transition-all duration-300 group-hover:w-7" />
          <ArrowRight
            size={18}
            strokeWidth={2.3}
            className="relative z-10 text-white/38 transition-all duration-300 group-hover:translate-x-1 group-hover:text-white"
          />
        </span>
      </div>

      <p className="mt-3 line-clamp-2 text-xs font-semibold leading-5 text-white/45 transition-colors duration-300 group-hover:text-white/62">
        {description}
      </p>

      <span className="absolute bottom-0 left-0 h-px w-0 bg-white/50 transition-all duration-500 group-hover:w-full" />
    </Link>
  );
};

const QuickPreviewPanel = () => (
  <section className="border border-white/[0.09] bg-white/[0.035] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.30)]">
    <div className="mb-5 flex items-end justify-between gap-3 border-b border-white/[0.08] pb-4">
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/38">
          Quick Preview
        </p>
        <h2 className="mt-2 text-xl font-black text-white">
          Open demo routes
        </h2>
      </div>

      <Link
        to="/demo"
        className="group inline-flex items-center gap-1 text-xs font-black text-white/45 transition hover:text-white"
      >
        View all
        <ArrowRight
          size={14}
          className="transition-transform duration-300 group-hover:translate-x-1"
        />
      </Link>
    </div>

    <div className="grid gap-3 sm:grid-cols-2">
      {quickDemoRoutes.slice(0, 4).map((route, index) => (
        <RoutePreviewCard
          key={getPath(route as DemoRecord, ["to"], String(index))}
          item={route as DemoRecord}
          index={index}
        />
      ))}
    </div>
  </section>
);

const PackagePreviewCard = ({
  item,
  index,
}: {
  item: DemoRecord;
  index: number;
}) => {
  const name = getText(item, ["name", "title", "label"], `Package ${index + 1}`);
  const target = getText(
    item,
    ["target", "targetClient", "audience"],
    "Doctors, clinics and healthcare teams",
  );
  const description = getText(
    item,
    ["description", "subtitle"],
    "A ready-to-preview Clinic ERP SaaS package with public website and dashboard demo.",
  );
  const modules = getList(item, ["modules", "features", "includedModules"], [
    "Public Website",
    "Appointment",
    "Patient",
    "Prescription",
  ]).slice(0, 5);

  const publicDemoTo = getPath(
    item,
    ["publicDemoTo", "publicDemo", "publicUrl", "publicDemoUrl"],
    "/demo",
  );
  const adminDemoTo = getPath(
    item,
    ["adminDemoTo", "adminDemo", "dashboardUrl", "adminUrl"],
    "/clinic/dashboard",
  );

  const Icon = packageIcons[index % packageIcons.length];

  return (
    <article className="group relative overflow-hidden border border-white/[0.09] bg-white/[0.035] p-5 transition-all duration-300 ease-out hover:-translate-y-1 hover:border-white/24 hover:bg-white/[0.075] hover:shadow-[0_20px_58px_rgba(0,0,0,0.32)]">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <PremiumIcon icon={Icon} size={29} />

          <p className="mt-4 text-[10px] font-black uppercase tracking-[0.18em] text-white/38">
            Package
          </p>

          <h3 className="mt-2 truncate text-xl font-black tracking-tight text-white">
            {name}
          </h3>
        </div>

        <span className="shrink-0 text-[10px] font-black text-white/34 transition-all duration-300 group-hover:text-white/65">
          #{String(index + 1).padStart(2, "0")}
        </span>
      </div>

      <p className="mt-4 line-clamp-3 text-sm font-semibold leading-6 text-white/50 transition-colors duration-300 group-hover:text-white/65">
        {description}
      </p>

      <div className="mt-5 border-t border-white/[0.09] pt-4">
        <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/38">
          Target Client
        </p>
        <p className="mt-2 truncate text-sm font-bold text-white/70">
          {target}
        </p>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {modules.map((module) => (
          <span
            key={module}
            className="border border-white/[0.09] bg-black/25 px-2.5 py-1 text-[10px] font-bold text-white/52 transition-all duration-300 group-hover:border-white/18 group-hover:text-white/65"
          >
            {module}
          </span>
        ))}
      </div>

      <div className="mt-6 grid gap-2 sm:grid-cols-2">
        <Link
          to={publicDemoTo}
          className="group/btn inline-flex items-center justify-center gap-2 border border-white/12 bg-white/[0.045] px-3 py-2.5 text-center text-xs font-black text-white/72 transition-all duration-300 hover:border-white/30 hover:bg-white/[0.09] hover:text-white"
        >
          Public Demo
          <ArrowRight
            size={14}
            className="transition-transform duration-300 group-hover/btn:translate-x-1"
          />
        </Link>

        <Link
          to={adminDemoTo}
          className="group/btn inline-flex items-center justify-center gap-2 border border-white bg-white px-3 py-2.5 text-center text-xs font-black text-black transition-all duration-300 hover:bg-white/90"
        >
          Admin Demo
          <ArrowRight
            size={14}
            className="transition-transform duration-300 group-hover/btn:translate-x-1"
          />
        </Link>
      </div>

      <span className="absolute bottom-0 left-0 h-px w-0 bg-white/50 transition-all duration-500 group-hover:w-full" />
    </article>
  );
};

const SaasHomePage = () => {
  const typedTitle = useTypingText(heroTitle, 30);

  const highlights = useMemo(
    () => [
      {
        label: "Doctors",
        className:
          "border-sky-400/25 bg-sky-400/[0.08] text-sky-200 after:bg-sky-300/70",
      },
      {
        label: "Clinics",
        className:
          "border-emerald-400/25 bg-emerald-400/[0.08] text-emerald-200 after:bg-emerald-300/70",
      },
      {
        label: "Diagnostic",
        className:
          "border-amber-400/25 bg-amber-400/[0.08] text-amber-200 after:bg-amber-300/70",
      },
      {
        label: "Hospitals",
        className:
          "border-fuchsia-400/25 bg-fuchsia-400/[0.08] text-fuchsia-200 after:bg-fuchsia-300/70",
      },
    ],
    [],
  );

  return (
    <main className="relative overflow-hidden text-white">
      <style>
        {`
          @keyframes clinicHomeAuroraOne {
            0%, 100% { transform: translate3d(-8%, -4%, 0) scale(1); opacity: .60; }
            50% { transform: translate3d(8%, 5%, 0) scale(1.12); opacity: .90; }
          }

          @keyframes clinicHomeAuroraTwo {
            0%, 100% { transform: translate3d(7%, 6%, 0) scale(1); opacity: .52; }
            50% { transform: translate3d(-6%, -4%, 0) scale(1.08); opacity: .78; }
          }

          @keyframes clinicHomeAuroraThree {
            0%, 100% { transform: translate3d(-3%, 6%, 0) scale(1); opacity: .42; }
            50% { transform: translate3d(5%, -6%, 0) scale(1.1); opacity: .68; }
          }

          .clinic-home-aurora-one {
            animation: clinicHomeAuroraOne 14s ease-in-out infinite;
          }

          .clinic-home-aurora-two {
            animation: clinicHomeAuroraTwo 17s ease-in-out infinite;
          }

          .clinic-home-aurora-three {
            animation: clinicHomeAuroraThree 20s ease-in-out infinite;
          }
        `}
      </style>

      <div className="pointer-events-none absolute inset-0 z-0">
        <div className="clinic-home-aurora-one absolute -left-24 top-10 h-[520px] w-[520px] rounded-full bg-cyan-500/[0.12] blur-[105px]" />
        <div className="clinic-home-aurora-two absolute right-[-120px] top-24 h-[560px] w-[560px] rounded-full bg-fuchsia-500/[0.10] blur-[110px]" />
        <div className="clinic-home-aurora-three absolute bottom-0 left-1/2 h-[520px] w-[760px] -translate-x-1/2 rounded-full bg-emerald-500/[0.07] blur-[115px]" />
        <div className="absolute left-[20%] top-[42%] h-[300px] w-[300px] rounded-full bg-blue-500/[0.055] blur-[95px]" />
        <div className="absolute right-[22%] top-[62%] h-[280px] w-[280px] rounded-full bg-amber-400/[0.035] blur-[95px]" />
      </div>

      <section className="relative z-10 mx-auto grid max-w-7xl gap-8 px-4 py-14 lg:grid-cols-[1.05fr_0.95fr] lg:items-start lg:py-16">
        <div className="min-w-0">
          <p className="inline-flex border border-white/[0.10] bg-white/[0.04] px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-white/52">
            Clinic ERP SaaS
          </p>

          <h1 className="mt-6 min-h-[170px] max-w-5xl text-4xl font-black tracking-tight text-white sm:min-h-[170px] sm:text-5xl lg:min-h-[215px] lg:text-6xl">
            {typedTitle}
            <span className="ml-1 inline-block h-10 w-[3px] translate-y-1 bg-white/75 animate-pulse sm:h-12 lg:h-14" />
          </h1>

          <div className="mt-4 flex flex-wrap gap-2">
            {highlights.map((item) => (
              <span
                key={item.label}
                className={[
                  "relative overflow-hidden border px-3.5 py-1.5 text-[11px] font-black uppercase tracking-[0.15em] transition-all duration-300 hover:-translate-y-0.5",
                  "after:absolute after:bottom-1 after:left-3 after:h-[2px] after:w-[calc(100%-1.5rem)] after:origin-left after:scale-x-75 after:transition-transform after:duration-300 hover:after:scale-x-100",
                  item.className,
                ].join(" ")}
              >
                {item.label}
              </span>
            ))}
          </div>

          <p className="mt-6 max-w-3xl text-base font-semibold leading-8 text-white/56">
            Manage appointments, patients, prescriptions, billing, diagnostic
            workflow, public website and hospital-ready modules from one
            platform.
          </p>

          <div className="mt-7 flex w-full max-w-3xl flex-nowrap gap-2 overflow-x-auto pb-1">
            <PremiumButton to="/pricing">View Pricing</PremiumButton>
            <PremiumButton to="/demo" variant="ghost">
              Open Demo
            </PremiumButton>
            <PremiumButton to="/super-admin" variant="ghost">
              Super Admin
            </PremiumButton>
            <PremiumButton to="/clinic/dashboard" variant="ghost">
              Clinic Dashboard
            </PremiumButton>
          </div>

          <div className="mt-7 grid max-w-[540px] grid-cols-3 gap-2">
            <StatCard end={7} label="ERP Packages" icon={Layers} />
            <StatCard end={40} suffix="+" label="Demo Routes" icon={Workflow} />
            <StatCard end={100} suffix="%" label="Tenant Ready UI" icon={Gauge} />
          </div>
        </div>

        <div className="grid gap-4">
          <BackendFlowPanel />
          <QuickPreviewPanel />
        </div>
      </section>

      <section className="relative z-10 mx-auto max-w-7xl px-4 pb-14">
        <div className="mb-6 flex flex-col justify-between gap-3 border-t border-white/[0.10] pt-10 sm:flex-row sm:items-end">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.18em] text-white/40">
              Packages
            </p>
            <h2 className="mt-2 text-3xl font-black text-white">
              Choose a demo package
            </h2>
          </div>

          <Link
            to="/pricing"
            className="group inline-flex items-center gap-1 text-sm font-black text-white/48 transition hover:text-white"
          >
            Compare pricing
            <ArrowRight
              size={15}
              className="transition-transform duration-300 group-hover:translate-x-1"
            />
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {demoPackages.map((item, index) => (
            <PackagePreviewCard
              key={getText(item as DemoRecord, ["name", "title"], String(index))}
              item={item as DemoRecord}
              index={index}
            />
          ))}
        </div>
      </section>

      <section className="relative z-10 mx-auto max-w-7xl px-4 pb-20">
        <div className="mb-6 border-t border-white/[0.10] pt-10">
          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-white/40">
            Quick Open Demo Routes
          </p>
          <h2 className="mt-2 text-3xl font-black text-white">
            Jump into any demo flow
          </h2>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {quickDemoRoutes.map((route, index) => (
            <RoutePreviewCard
              key={getPath(route as DemoRecord, ["to"], String(index))}
              item={route as DemoRecord}
              index={index}
            />
          ))}
        </div>
      </section>
    </main>
  );
};

export default SaasHomePage;