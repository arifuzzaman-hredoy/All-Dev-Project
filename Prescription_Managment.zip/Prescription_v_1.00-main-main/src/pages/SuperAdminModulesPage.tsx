import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminModulesPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Modules"
    description="Inspect module availability, access flags and platform feature groupings."
  />
);

export default SuperAdminModulesPage;
