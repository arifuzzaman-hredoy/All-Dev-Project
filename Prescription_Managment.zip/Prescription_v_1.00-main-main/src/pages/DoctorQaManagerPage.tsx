import { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  EyeOff,
  HelpCircle,
  MessageCircleQuestion,
  Pencil,
  Save,
  Search,
  Trash2,
  X,
} from "lucide-react";
import CmsEmptyState from "../components/cms/CmsEmptyState";
import CmsSectionCard from "../components/cms/CmsSectionCard";
import CmsToolbar from "../components/cms/CmsToolbar";
import {
  getPublicQa,
  loadPublicContent,
  savePublicContent,
  savePublicQa,
} from "../publicSite/lib/publicStorage";

const PUBLIC_QA_REQUESTS_KEY = "public_qa_requests";

const statusOptions = [
  { value: "pending", label: "Pending" },
  { value: "answered", label: "Answered" },
  { value: "hidden", label: "Hidden" },
];

const statusConfig = {
  pending: {
    label: "Pending",
    className: "border-amber-200 bg-amber-50 text-amber-700",
    icon: AlertCircle,
  },
  answered: {
    label: "Answered",
    className: "border-emerald-200 bg-emerald-50 text-emerald-700",
    icon: CheckCircle2,
  },
  hidden: {
    label: "Hidden",
    className: "border-slate-200 bg-slate-100 text-slate-600",
    icon: EyeOff,
  },
};

const fieldClass =
  "w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100";

const iconClass =
  "shrink-0 text-teal-700 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-3";

const safeReadList = (key) => {
  if (typeof window === "undefined") return [];

  try {
    const saved = window.localStorage.getItem(key);
    const parsed = saved ? JSON.parse(saved) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const safeWriteList = (key, list, notify = true) => {
  if (typeof window === "undefined") return;

  window.localStorage.setItem(key, JSON.stringify(list));

  if (notify) {
    window.dispatchEvent(new Event("public-qa-updated"));
    window.dispatchEvent(new Event("public-content-updated"));
  }
};

const normalizeStatus = (status, answer = "") => {
  const value = String(status || "").toLowerCase();

  if (value === "answered") return "answered";
  if (value === "published") return "answered";
  if (value === "publish") return "answered";
  if (value === "hidden") return "hidden";
  if (answer?.trim()) return "answered";

  return "pending";
};

const getTimeValue = (item) => {
  const time = new Date(item?.updatedAt || item?.createdAt || 0).getTime();
  return Number.isFinite(time) ? time : 0;
};

const normalizeQaItem = (item, index = 0) => {
  const createdAt = item.createdAt || new Date().toISOString();
  const answer = item.answer || item.reply || item.doctorAnswer || "";

  return {
    id: item.id || `qa-${getTimeValue(item) || Date.now()}-${index}`,
    patientId: item.patientId || item.patientID || item.userId || "",
    patientName:
      item.patientName ||
      item.name ||
      item.userName ||
      item.fullName ||
      "Patient",
    phone: item.phone || item.mobile || item.phoneNumber || "",
    question: item.question || item.message || item.text || "",
    answer,
    status: normalizeStatus(item.status, answer),
    createdAt,
    updatedAt: item.updatedAt || createdAt,
  };
};

const mergeQaLists = (...lists) => {
  const map = new Map();

  lists
    .flat()
    .filter(Boolean)
    .forEach((item, index) => {
      const normalized = normalizeQaItem(item, index);
      const existing = map.get(normalized.id);

      if (!existing || getTimeValue(normalized) >= getTimeValue(existing)) {
        map.set(normalized.id, normalized);
      }
    });

  return Array.from(map.values()).sort(
    (a, b) => getTimeValue(b) - getTimeValue(a)
  );
};

const mirrorQaStorage = (list, notify = true) => {
  savePublicQa(list);
  safeWriteList(PUBLIC_QA_REQUESTS_KEY, list, notify);
};

const getStatusInfo = (status) => {
  return statusConfig[normalizeStatus(status)] || statusConfig.pending;
};

const shortText = (text, limit = 120) => {
  const value = String(text || "").trim();
  if (value.length <= limit) return value;
  return `${value.slice(0, limit)}...`;
};

const formatDateTime = (value) => {
  if (!value) return "-";

  return new Date(value).toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
};

const StatusBadge = ({ status }) => {
  const info = getStatusInfo(status);
  const Icon = info.icon;

  return (
    <span
      className={[
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-black uppercase tracking-wider",
        info.className,
      ].join(" ")}
    >
      <Icon size={13} />
      {info.label}
    </span>
  );
};

const QaRow = ({ item, index, onOpen, onDelete }) => {
  return (
    <article className="group rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:bg-cyan-50/40 hover:shadow-md">
      <div className="grid gap-3 lg:grid-cols-[1fr_auto] lg:items-center">
        <button type="button" onClick={onOpen} className="min-w-0 text-left">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <span className="text-xs font-black text-slate-400">
              #{String(index + 1).padStart(2, "0")}
            </span>

            <StatusBadge status={item.status} />

            <span className="text-xs font-bold text-slate-400">
              {item.patientName || "Patient"}
              {item.phone ? ` • ${item.phone}` : ""}
            </span>

            <span className="text-xs font-bold text-slate-400">
              {formatDateTime(item.createdAt)}
            </span>
          </div>

          <div className="flex items-start gap-2">
            <MessageCircleQuestion size={18} className={iconClass} />

            <div className="min-w-0">
              <h3 className="text-base font-black leading-6 text-slate-950">
                {shortText(item.question, 150) || "No question text"}
              </h3>

              <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
                {item.answer
                  ? shortText(item.answer, 170)
                  : "No answer yet. Click Answer button to reply."}
              </p>
            </div>
          </div>
        </button>

        <div className="flex shrink-0 flex-wrap gap-2 lg:justify-end">
          <button
            type="button"
            onClick={onOpen}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-cyan-200 bg-cyan-50 px-3 text-xs font-black text-cyan-700 transition hover:-translate-y-0.5 hover:bg-cyan-100"
          >
            <Pencil size={14} />
            {item.answer ? "View / Edit" : "Answer"}
          </button>

          <button
            type="button"
            onClick={onDelete}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 text-xs font-black text-red-700 transition hover:-translate-y-0.5 hover:bg-red-100"
          >
            <Trash2 size={14} />
            Delete
          </button>
        </div>
      </div>
    </article>
  );
};

const QaModal = ({
  item,
  draft,
  setDraft,
  error,
  onClose,
  onSave,
  onDelete,
  saving,
}) => {
  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-slate-950/55 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !saving) {
          onClose();
        }
      }}
    >
      <div
        className="w-full max-w-3xl overflow-hidden rounded-3xl bg-white shadow-2xl"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 p-5">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-600">
              Patient Q&A
            </p>
            <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950">
              {item.answer ? "View / Edit Answer" : "Answer Question"}
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500">
              Patient: {item.patientName || "Patient"}
              {item.phone ? ` • ${item.phone}` : ""}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="group grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-slate-400 transition duration-300 hover:-translate-y-0.5 hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
            title="Close"
          >
            <X
              size={25}
              strokeWidth={2.4}
              className="transition-transform duration-300 group-hover:rotate-90"
            />
          </button>
        </div>

        <div className="grid max-h-[75vh] gap-4 overflow-y-auto p-5">
          <div className="rounded-2xl border border-cyan-100 bg-cyan-50 p-4">
            <div className="mb-2 flex items-center gap-2">
              <HelpCircle size={18} className="text-cyan-700" />
              <p className="text-xs font-black uppercase tracking-wider text-cyan-700">
                Patient Question
              </p>
            </div>

            <p className="text-base font-bold leading-7 text-slate-900">
              {item.question || "No question text"}
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_220px]">
            <label className="grid gap-1.5">
              <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                Doctor Answer
              </span>
              <textarea
                value={draft.answer || ""}
                onChange={(event) =>
                  setDraft((prev) => ({
                    ...prev,
                    answer: event.target.value,
                  }))
                }
                placeholder="Write doctor answer here..."
                rows={10}
                className={`${fieldClass} resize-y leading-6`}
              />
            </label>

            <div className="grid content-start gap-3">
              <label className="grid gap-1.5">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  Status
                </span>
                <select
                  value={draft.status || "pending"}
                  onChange={(event) =>
                    setDraft((prev) => ({
                      ...prev,
                      status: event.target.value,
                    }))
                  }
                  className={fieldClass}
                >
                  {statusOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>

              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-wider text-slate-500">
                  Public Visibility
                </p>
                <div className="mt-2">
                  <StatusBadge status={draft.status} />
                </div>
                <p className="mt-3 text-xs font-semibold leading-5 text-slate-500">
                  Answer submit করলে public Q&A page-এ answer show হবে। Hidden
                  করলে public page-এ show হবে না।
                </p>
              </div>
            </div>
          </div>

          {error ? (
            <p className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-black text-red-700">
              {error}
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap justify-between gap-2 border-t border-slate-100 bg-slate-50 p-4">
          <button
            type="button"
            onClick={onDelete}
            disabled={saving}
            className="inline-flex h-11 items-center gap-2 rounded-2xl border border-red-200 bg-white px-5 text-sm font-black text-red-700 transition hover:-translate-y-0.5 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Trash2 size={16} />
            Delete Question
          </button>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="h-11 rounded-2xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:-translate-y-0.5 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onSave}
              disabled={saving}
              className="inline-flex h-11 items-center gap-2 rounded-2xl bg-slate-950 px-5 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Save size={16} />
              {saving ? "Saving..." : "Submit Answer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const DoctorQaManagerPage = () => {
  const [items, setItems] = useState(() =>
    mergeQaLists(getPublicQa(), safeReadList(PUBLIC_QA_REQUESTS_KEY))
  );
  const [selectedItem, setSelectedItem] = useState(null);
  const [draft, setDraft] = useState({ answer: "", status: "pending" });
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [toast, setToast] = useState("");
  const [modalError, setModalError] = useState("");

  useEffect(() => {
    const syncLocal = () => {
      const next = mergeQaLists(
        getPublicQa(),
        safeReadList(PUBLIC_QA_REQUESTS_KEY)
      );
      setItems(next);
    };

    syncLocal();

    loadPublicContent("qa", getPublicQa())
      .then((data) => {
        const remote = Array.isArray(data) ? data : [];
        const next = mergeQaLists(
          remote,
          getPublicQa(),
          safeReadList(PUBLIC_QA_REQUESTS_KEY)
        );

        setItems(next);
        mirrorQaStorage(next, true);
      })
      .catch(() => {
        setNotice("Remote sync not available. Local realtime Q&A is active.");
      });

    window.addEventListener("storage", syncLocal);
    window.addEventListener("public-qa-updated", syncLocal);
    window.addEventListener("public-content-updated", syncLocal);

    return () => {
      window.removeEventListener("storage", syncLocal);
      window.removeEventListener("public-qa-updated", syncLocal);
      window.removeEventListener("public-content-updated", syncLocal);
    };
  }, []);

  useEffect(() => {
    if (!toast) return;

    const timeoutId = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(timeoutId);
  }, [toast]);

  const persistLocalNow = (next, successMessage) => {
    const normalized = mergeQaLists(next);

    setItems(normalized);
    mirrorQaStorage(normalized, true);
    setToast(successMessage);

    return normalized;
  };

  const syncRemoteInBackground = async (normalized) => {
    try {
      const savedData = await savePublicContent("qa", normalized);
      const finalData = Array.isArray(savedData)
        ? mergeQaLists(savedData, normalized)
        : normalized;

      setItems(finalData);
      mirrorQaStorage(finalData, true);
      setNotice("");
    } catch {
      setNotice("Saved locally. Remote server sync failed or unavailable.");
    }
  };

  const stats = useMemo(() => {
    return {
      total: items.length,
      pending: items.filter((item) => item.status === "pending").length,
      answered: items.filter((item) => item.status === "answered").length,
      hidden: items.filter((item) => item.status === "hidden").length,
    };
  }, [items]);

  const filteredItems = useMemo(() => {
    const keyword = query.trim().toLowerCase();

    return items.filter((item) => {
      const matchesStatus =
        statusFilter === "all" ? true : item.status === statusFilter;

      const matchesSearch = keyword
        ? [item.patientName, item.phone, item.question, item.answer, item.status]
            .join(" ")
            .toLowerCase()
            .includes(keyword)
        : true;

      return matchesStatus && matchesSearch;
    });
  }, [items, query, statusFilter]);

  const openQuestion = (item) => {
    setSelectedItem(item);
    setDraft({
      answer: item.answer || "",
      status: item.status || "pending",
    });
    setModalError("");
  };

  const closeQuestion = () => {
    if (saving) return;

    setSelectedItem(null);
    setDraft({ answer: "", status: "pending" });
    setModalError("");
  };

  const saveAnswer = () => {
    if (!selectedItem || saving) return;

    const answer = String(draft.answer || "").trim();
    const selectedStatus = draft.status || "pending";

    if (!answer && selectedStatus !== "hidden") {
      setModalError("Doctor answer লিখে Submit করো অথবা status Hidden করো.");
      return;
    }

    const finalStatus = selectedStatus === "hidden" ? "hidden" : "answered";
    const now = new Date().toISOString();

    const next = items.map((item) =>
      item.id === selectedItem.id
        ? {
            ...item,
            answer,
            status: finalStatus,
            updatedAt: now,
          }
        : item
    );

    setSaving(true);

    const normalized = persistLocalNow(
      next,
      "Answer submitted successfully. Public page updated."
    );

    setSelectedItem(null);
    setDraft({ answer: "", status: "pending" });
    setModalError("");
    setSaving(false);

    syncRemoteInBackground(normalized);
  };

  const deleteQuestion = (id) => {
    if (saving) return;

    const confirmed = window.confirm("Delete this question?");
    if (!confirmed) return;

    setSaving(true);

    const normalized = persistLocalNow(
      items.filter((item) => item.id !== id),
      "Question deleted successfully."
    );

    if (selectedItem?.id === id) {
      setSelectedItem(null);
      setDraft({ answer: "", status: "pending" });
      setModalError("");
    }

    setSaving(false);
    syncRemoteInBackground(normalized);
  };

  return (
    <section className="mx-auto grid max-w-7xl gap-3">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 flex max-w-sm items-center gap-2 rounded-2xl border border-emerald-100 bg-white px-4 py-3 text-sm font-black text-emerald-700 shadow-2xl">
          <CheckCircle2 size={17} />
          {toast}
        </div>
      ) : null}

      <CmsToolbar
        title="Q&A Manager"
        description={
          notice ||
          "Public page থেকে submitted questions এখানে realtime আসবে। Answer submit করলে public Q&A page-এ show হবে."
        }
      />

      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-cyan-700">
            Total Questions
          </p>
          <p className="mt-1 text-xl font-black text-slate-950">
            {stats.total}
          </p>
        </div>

        <div className="rounded-2xl border border-amber-100 bg-amber-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-amber-700">
            Pending
          </p>
          <p className="mt-1 text-xl font-black text-amber-700">
            {stats.pending}
          </p>
        </div>

        <div className="rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
            Answered
          </p>
          <p className="mt-1 text-xl font-black text-emerald-700">
            {stats.answered}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
          <p className="text-[11px] font-black uppercase tracking-wider text-slate-500">
            Hidden
          </p>
          <p className="mt-1 text-xl font-black text-slate-700">
            {stats.hidden}
          </p>
        </div>
      </div>

      <CmsSectionCard title="Patient Questions">
        <div className="mb-4 flex flex-col gap-3 border-b border-slate-100 pb-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="group flex items-center gap-2">
            <MessageCircleQuestion size={20} className={iconClass} />
            <div>
              <h3 className="text-lg font-black text-slate-950">
                Question List
              </h3>
              <p className="text-sm font-semibold text-slate-500">
                Answer button click করলে popup form open হবে.
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="relative min-w-0 sm:w-72">
              <Search
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search question..."
                className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
            >
              <option value="all">All Status</option>
              {statusOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid gap-3">
          {filteredItems.length ? (
            filteredItems.map((item, index) => (
              <QaRow
                key={item.id}
                item={item}
                index={index}
                onOpen={() => openQuestion(item)}
                onDelete={() => deleteQuestion(item.id)}
              />
            ))
          ) : (
            <CmsEmptyState
              title="No questions"
              message="Public Q&A page থেকে submit করলে question এখানে আসবে."
            />
          )}
        </div>
      </CmsSectionCard>

      <QaModal
        item={selectedItem}
        draft={draft}
        setDraft={setDraft}
        error={modalError}
        onClose={closeQuestion}
        onSave={saveAnswer}
        onDelete={() => selectedItem && deleteQuestion(selectedItem.id)}
        saving={saving}
      />
    </section>
  );
};

export default DoctorQaManagerPage;