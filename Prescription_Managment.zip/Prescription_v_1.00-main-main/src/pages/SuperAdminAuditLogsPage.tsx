import DashboardPreviewPage from "./DashboardPreviewPage";

const SuperAdminAuditLogsPage = () => (
  <DashboardPreviewPage
    eyebrow="Super admin"
    title="Audit logs"
    description="Preview administrative events, account changes and security log entries."
  />
);

export default SuperAdminAuditLogsPage;
