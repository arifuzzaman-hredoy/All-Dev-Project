import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicSmsWalletPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="SMS wallet"
    description="Track SMS balance, recharge activity and patient notification usage."
  />
);

export default ClinicSmsWalletPage;
