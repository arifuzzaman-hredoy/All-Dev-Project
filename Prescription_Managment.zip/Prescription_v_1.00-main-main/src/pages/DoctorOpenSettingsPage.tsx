import { useEffect, useState } from "react";
import { Bell, BellOff, Settings2 } from "lucide-react";
import BackButton from "../components/common/BackButton";
import GlassCard from "../components/common/GlassCard";

const INBOX_TOGGLE_KEY = "doctorInboxEnabled";

const DoctorOpenSettingsPage = () => {
  const [inboxEnabled, setInboxEnabled] = useState(() => {
    if (typeof window === "undefined") return true;
    const stored = window.localStorage.getItem(INBOX_TOGGLE_KEY);
    if (stored === null) return true;
    return stored === "true";
  });

  useEffect(() => {
    window.localStorage.setItem(INBOX_TOGGLE_KEY, String(inboxEnabled));
  }, [inboxEnabled]);

  return (
    <section className="mx-auto grid max-w-4xl gap-4">
      <BackButton label="Back to Panel Settings" to="/doctor/panel-settings" />

      <GlassCard>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-wider text-cyan-600">Open Settings</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900">Inbox Visibility Control</h2>
            <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
              Toggle message inbox visibility. When OFF, doctor cannot see who
              sent messages until it is turned ON again.
            </p>
          </div>
          <Settings2 size={22} className="text-teal-700" />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-[auto_1fr] md:items-center">
          <button
            type="button"
            className="inline-flex items-center gap-3 rounded-2xl border border-teal-100 bg-white/80 p-3 text-left shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-300"
            onClick={() => setInboxEnabled((prev) => !prev)}
          >
            <span className={`relative h-7 w-12 rounded-full transition ${inboxEnabled ? "bg-teal-600" : "bg-slate-300"}`}>
              <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${inboxEnabled ? "left-6" : "left-1"}`} />
            </span>
            <span className="grid">
              <strong className="text-sm font-black text-slate-900">Messages</strong>
              <small className="text-xs font-bold text-slate-500">{inboxEnabled ? "ON" : "OFF"}</small>
            </span>
          </button>

          <div className="flex items-center gap-2 rounded-2xl bg-cyan-50 p-3 text-sm font-bold text-teal-800 ring-1 ring-cyan-100">
            {inboxEnabled ? <Bell size={16} /> : <BellOff size={16} />}
            <span>
              {inboxEnabled
                ? "Inbox is active. Message list is visible."
                : "Inbox is hidden. Sender list is blocked."}
            </span>
          </div>
        </div>
      </GlassCard>
    </section>
  );
};

export default DoctorOpenSettingsPage;
