import DashboardPreviewPage from "./DashboardPreviewPage";

const ClinicAppointmentsPage = () => (
  <DashboardPreviewPage
    eyebrow="Clinic panel"
    title="Appointments"
    description="Preview appointment queue, timing, status and daily chamber flow."
  />
);

export default ClinicAppointmentsPage;
