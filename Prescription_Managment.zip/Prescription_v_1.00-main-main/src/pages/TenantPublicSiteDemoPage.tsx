import { Link, useParams } from "react-router-dom";
import DemoNotice from "../components/common/DemoNotice";
import ProductCredit from "../components/common/ProductCredit";

const siteContent = {
  "single-doctor": {
    eyebrow: "Single Doctor Public Demo",
    title: "Dr. Ayesha Rahman",
    subtitle: "Medicine specialist with evening chamber, appointment booking, blogs, Q&A and gallery links.",
    sections: ["Speciality: Internal Medicine", "Chamber time: 5:00 PM - 9:00 PM", "Services: Fever, diabetes, hypertension", "Blogs, Q&A and gallery ready"],
    cta: "Book Appointment",
  },
  "pro-doctor": {
    eyebrow: "Pro Doctor Public Demo",
    title: "CareBridge Pro Doctor",
    subtitle: "Enhanced doctor profile site with CMS sections, services, appointment CTA and patient communication.",
    sections: ["Advanced CMS", "Patient education blogs", "Gallery and service blocks", "Online appointment CTA"],
    cta: "Open Doctor Demo",
  },
  clinic: {
    eyebrow: "Clinic Public Demo",
    title: "City Care Clinic",
    subtitle: "Public clinic website with doctors, services, appointment CTA, emergency contact, blogs and footer.",
    sections: ["Doctors directory", "Services and departments", "Emergency contact", "Appointment request"],
    cta: "Request Serial",
  },
  diagnostic: {
    eyebrow: "Diagnostic Public Demo",
    title: "Prime Diagnostic Center",
    subtitle: "Diagnostic center public site with test packages, sample collection, report delivery and contact CTA.",
    sections: ["Health check packages", "Home sample collection", "Digital report delivery", "Diagnostic services"],
    cta: "Book Test",
  },
  hospital: {
    eyebrow: "Hospital Public Demo",
    title: "Green Life Hospital",
    subtitle: "Hospital public website shell with departments, doctors, emergency, OPD/IPD, diagnostic and pharmacy highlights.",
    sections: ["Departments", "OPD and IPD info", "Emergency desk", "Diagnostic and pharmacy"],
    cta: "Contact Hospital",
  },
};

const resolveKind = (slug?: string) => {
  if (!slug) return "clinic";
  if (slug.includes("single-doctor")) return "single-doctor";
  if (slug.includes("pro-doctor")) return "pro-doctor";
  if (slug.includes("diagnostic")) return "diagnostic";
  if (slug.includes("hospital")) return "hospital";
  return "clinic";
};

type TenantPublicSiteDemoPageProps = {
  kind?: keyof typeof siteContent;
};

const TenantPublicSiteDemoPage = ({ kind }: TenantPublicSiteDemoPageProps) => {
  const { tenantSlug } = useParams();
  const content = siteContent[kind || resolveKind(tenantSlug)];

  return (
    <main className="min-h-svh bg-gradient-to-br from-cyan-50 via-white to-teal-50 text-slate-900">
      <header className="border-b border-cyan-100 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="text-sm font-black text-teal-800">CareBridge Public Demo</Link>
          <nav className="hidden gap-2 text-[12px] font-black text-slate-500 sm:flex">
            <Link to="/demo">Demos</Link>
            <Link to="/pricing">Pricing</Link>
            <Link to="/book-demo">Appointment</Link>
          </nav>
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl gap-8 px-4 py-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <div>
          <DemoNotice />
          <p className="mt-6 text-[11px] font-black uppercase tracking-[0.14em] text-teal-700">{content.eyebrow}</p>
          <h1 className="mt-3 text-4xl font-black tracking-tight text-slate-950 sm:text-5xl">{content.title}</h1>
          <p className="mt-4 max-w-2xl text-base font-semibold leading-8 text-slate-600">{content.subtitle}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/book-demo" className="rounded-full bg-teal-700 px-5 py-3 text-sm font-black text-white">{content.cta}</Link>
            <Link to="/clinic/dashboard" className="rounded-full bg-white px-5 py-3 text-sm font-black text-teal-800 shadow-sm">Admin Demo</Link>
          </div>
        </div>
        <div className="rounded-[2rem] border border-cyan-100 bg-white p-5 shadow-[0_24px_70px_rgba(11,86,90,0.12)]">
          <div className="grid gap-3">
            {content.sections.map((section) => (
              <article key={section} className="rounded-2xl bg-slate-50 p-4">
                <h3 className="text-sm font-black text-slate-950">{section}</h3>
                <p className="mt-1 text-[12px] font-semibold leading-5 text-slate-500">Presentation-ready demo section with clean medical SaaS styling.</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-4 px-4 pb-12 md:grid-cols-3">
        {["Doctors", "Services", "Blogs"].map((item) => (
          <article key={item} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_16px_38px_rgba(15,23,42,0.05)]">
            <h2 className="text-lg font-black text-slate-950">{item}</h2>
            <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">Demo content block for the tenant public website flow.</p>
          </article>
        ))}
      </section>

      <footer className="border-t border-cyan-100 bg-white/70 px-4 py-5 text-center">
        <ProductCredit />
      </footer>
    </main>
  );
};

export default TenantPublicSiteDemoPage;
