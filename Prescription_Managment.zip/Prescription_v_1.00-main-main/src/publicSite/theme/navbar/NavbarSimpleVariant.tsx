import { CalendarDays, Menu, Stethoscope, X } from "lucide-react";
import { useState } from "react";
import { NavLink } from "react-router-dom";

const links = [
  { path: "/", key: "home", label: "Home" },
  { path: "/about", key: "about", label: "About" },
  { path: "/services", key: "services", label: "Services" },
  { path: "/blogs", key: "blogs", label: "Blogs" },
  { path: "/qa", key: "qa", label: "Q&A" },
  { path: "/gallery", key: "gallery", label: "Gallery" },
  { path: "/contact", key: "contact", label: "Contact" },
  { path: "/patient-prescription", key: "prescription", label: "Prescription" },
];

const styles = {
  "variant-2": {
    header: "sticky top-3 z-50 mx-auto mt-3 w-[min(1180px,calc(100%-1rem))] border border-[var(--site-primary)] bg-white",
    link: "border border-transparent hover:border-[var(--site-primary)]",
    brand: "text-[var(--site-primary)]",
  },
  "variant-3": {
    header: "sticky top-3 z-50 mx-auto mt-3 w-[min(1180px,calc(100%-1rem))] rounded-[var(--site-radius)] border border-slate-200 bg-white p-2 shadow-sm",
    link: "rounded-xl hover:bg-slate-100",
    brand: "text-slate-950",
  },
  "variant-4": {
    header: "sticky top-0 z-50 border-b border-slate-200 bg-white",
    link: "hover:text-[var(--site-primary)]",
    brand: "text-slate-950",
  },
  "variant-5": {
    header: "sticky top-0 z-50 border-y border-slate-300 bg-slate-50 font-mono",
    link: "border-l border-slate-300 hover:bg-white",
    brand: "text-slate-900",
  },
};

const NavbarSimpleVariant = ({ profile = {}, onAppointment, variant = "variant-2" }) => {
  const [open, setOpen] = useState(false);
  const style = styles[variant] || styles["variant-2"];

  const navLinks = links.map((item) => ({
    ...item,
    label: profile.navbarLinks?.[item.key] || item.label,
  }));

  return (
    <header className={style.header}>
      <div className="mx-auto flex min-h-16 max-w-[1180px] items-center justify-between gap-3 px-4">
        <NavLink to="/" className="flex min-w-0 items-center gap-2" onClick={() => setOpen(false)}>
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-[var(--site-primary)]">
            <Stethoscope size={18} />
          </span>
          <span className="min-w-0">
            <strong className={["block truncate text-base font-black", style.brand].join(" ")}>
              {profile.brandName || profile.siteName || "CareBridge"}
            </strong>
            <small className="block truncate text-[11px] font-bold text-slate-500">
              {profile.navbarSubtitle || profile.doctorName || "Doctor Profile"}
            </small>
          </span>
        </NavLink>

        <nav className={variant === "variant-4" ? "hidden flex-1 justify-center gap-2 lg:flex" : "hidden gap-1 lg:flex"}>
          {navLinks.map(({ path, label }) => (
            <NavLink
              key={path}
              to={path}
              end={path === "/"}
              className={({ isActive }) =>
                [
                  "px-3 py-2 text-xs font-black",
                  style.link,
                  isActive ? "text-[var(--site-primary)]" : "text-slate-600",
                ].join(" ")
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onAppointment}
            className="inline-flex min-h-10 items-center gap-2 rounded-[var(--site-radius)] bg-[var(--site-button)] px-4 text-xs font-black text-[var(--site-button-text)]"
          >
            <CalendarDays size={15} />
            {profile.ctaText || profile.navbarLinks?.appointment || "Book"}
          </button>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center border border-slate-200 bg-white lg:hidden"
            onClick={() => setOpen((value) => !value)}
            aria-label="Toggle navigation"
          >
            {open ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </div>

      {open ? (
        <nav className="grid border-t border-slate-200 bg-white p-2 lg:hidden">
          {navLinks.map(({ path, label }) => (
            <NavLink
              key={path}
              to={path}
              end={path === "/"}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                [
                  "px-3 py-2 text-sm font-bold",
                  isActive ? "text-[var(--site-primary)]" : "text-slate-700",
                ].join(" ")
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>
      ) : null}
    </header>
  );
};

export default NavbarSimpleVariant;
