import NavbarSimpleVariant from "./NavbarSimpleVariant";

const NavbarVariant4 = (props) => <NavbarSimpleVariant {...props} variant="variant-4" />;

export default NavbarVariant4;
