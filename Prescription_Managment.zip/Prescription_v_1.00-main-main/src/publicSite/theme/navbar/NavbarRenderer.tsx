import { getThemeSettings } from "../../lib/themeSettings";
import NavbarVariant1 from "./NavbarVariant1";
import NavbarVariant2 from "./NavbarVariant2";
import NavbarVariant3 from "./NavbarVariant3";
import NavbarVariant4 from "./NavbarVariant4";
import NavbarVariant5 from "./NavbarVariant5";

const variants = {
  "variant-1": NavbarVariant1,
  "variant-2": NavbarVariant2,
  "variant-3": NavbarVariant3,
  "variant-4": NavbarVariant4,
  "variant-5": NavbarVariant5,
};

const NavbarRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.navbarVariant] || NavbarVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default NavbarRenderer;
