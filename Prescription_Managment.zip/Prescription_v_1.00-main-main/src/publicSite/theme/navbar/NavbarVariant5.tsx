import NavbarSimpleVariant from "./NavbarSimpleVariant";

const NavbarVariant5 = (props) => <NavbarSimpleVariant {...props} variant="variant-5" />;

export default NavbarVariant5;
