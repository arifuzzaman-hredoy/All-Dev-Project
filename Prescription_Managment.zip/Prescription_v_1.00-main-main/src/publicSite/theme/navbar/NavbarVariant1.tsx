import PublicNavbar from "../../components/PublicNavbar";

const NavbarVariant1 = (props) => <PublicNavbar {...props} />;

export default NavbarVariant1;
