import NavbarSimpleVariant from "./NavbarSimpleVariant";

const NavbarVariant2 = (props) => <NavbarSimpleVariant {...props} variant="variant-2" />;

export default NavbarVariant2;
