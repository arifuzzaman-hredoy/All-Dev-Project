import NavbarSimpleVariant from "./NavbarSimpleVariant";

const NavbarVariant3 = (props) => <NavbarSimpleVariant {...props} variant="variant-3" />;

export default NavbarVariant3;
