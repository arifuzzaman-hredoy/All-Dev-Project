import ContactSimpleVariant from "./ContactSimpleVariant";

const ContactVariant2 = (props) => <ContactSimpleVariant {...props} variant="variant-2" />;

export default ContactVariant2;
