import ContactSimpleVariant from "./ContactSimpleVariant";

const ContactVariant4 = (props) => <ContactSimpleVariant {...props} variant="variant-4" />;

export default ContactVariant4;
