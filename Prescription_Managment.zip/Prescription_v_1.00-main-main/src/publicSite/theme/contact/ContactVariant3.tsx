import ContactSimpleVariant from "./ContactSimpleVariant";

const ContactVariant3 = (props) => <ContactSimpleVariant {...props} variant="variant-3" />;

export default ContactVariant3;
