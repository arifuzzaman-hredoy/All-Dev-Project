import { Link } from "react-router-dom";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const ContactSimpleVariant = ({ profile = {}, onAppointment, variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Contact"
    title="Need an appointment or follow-up?"
    description={profile.emergencyNotice}
    actions={
      <>
        <button
          type="button"
          className="inline-flex min-h-11 items-center justify-center rounded-[var(--site-radius)] bg-[var(--site-button)] px-5 text-sm font-black text-[var(--site-button-text)]"
          onClick={onAppointment}
        >
          {profile.ctaText || "Book Appointment"}
        </button>
        <Link
          className="inline-flex min-h-11 items-center justify-center rounded-[var(--site-radius)] border border-slate-200 bg-white px-5 text-sm font-black text-slate-700"
          to="/contact"
        >
          Contact chamber
        </Link>
      </>
    }
  >
    <SimplePanel title={profile.phone || "Phone"} text={profile.email} meta={profile.chamberName} variant={variant} />
  </ThemeSection>
);

export default ContactSimpleVariant;
