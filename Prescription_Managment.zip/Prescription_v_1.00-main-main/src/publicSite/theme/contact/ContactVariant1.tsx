import ContactSimpleVariant from "./ContactSimpleVariant";

const ContactVariant1 = (props) => <ContactSimpleVariant {...props} variant="variant-1" />;

export default ContactVariant1;
