import { getThemeSettings } from "../../lib/themeSettings";
import ContactVariant1 from "./ContactVariant1";
import ContactVariant2 from "./ContactVariant2";
import ContactVariant3 from "./ContactVariant3";
import ContactVariant4 from "./ContactVariant4";
import ContactVariant5 from "./ContactVariant5";

const variants = {
  "variant-1": ContactVariant1,
  "variant-2": ContactVariant2,
  "variant-3": ContactVariant3,
  "variant-4": ContactVariant4,
  "variant-5": ContactVariant5,
};

const ContactRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.contactVariant] || ContactVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default ContactRenderer;
