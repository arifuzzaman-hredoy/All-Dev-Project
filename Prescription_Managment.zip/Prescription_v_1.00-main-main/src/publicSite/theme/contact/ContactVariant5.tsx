import ContactSimpleVariant from "./ContactSimpleVariant";

const ContactVariant5 = (props) => <ContactSimpleVariant {...props} variant="variant-5" />;

export default ContactVariant5;
