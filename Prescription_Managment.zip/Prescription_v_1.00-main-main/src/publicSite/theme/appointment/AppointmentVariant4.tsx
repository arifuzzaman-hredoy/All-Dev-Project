import AppointmentSimpleVariant from "./AppointmentSimpleVariant";

const AppointmentVariant4 = (props) => <AppointmentSimpleVariant {...props} variant="variant-4" />;

export default AppointmentVariant4;
