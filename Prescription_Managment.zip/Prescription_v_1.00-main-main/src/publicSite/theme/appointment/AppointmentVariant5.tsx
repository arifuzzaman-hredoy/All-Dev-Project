import AppointmentSimpleVariant from "./AppointmentSimpleVariant";

const AppointmentVariant5 = (props) => <AppointmentSimpleVariant {...props} variant="variant-5" />;

export default AppointmentVariant5;
