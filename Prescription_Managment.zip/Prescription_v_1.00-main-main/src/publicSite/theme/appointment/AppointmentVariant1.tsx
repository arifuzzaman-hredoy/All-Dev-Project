import AppointmentSimpleVariant from "./AppointmentSimpleVariant";

const AppointmentVariant1 = (props) => <AppointmentSimpleVariant {...props} variant="variant-1" />;

export default AppointmentVariant1;
