import { Link } from "react-router-dom";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const AppointmentSimpleVariant = ({ profile = {}, onAppointment, variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Chamber Schedule"
    title={profile.chamberName || "Chamber Schedule"}
    description={profile.chamberAddress}
    actions={
      <>
        <button
          type="button"
          className="inline-flex min-h-11 items-center justify-center rounded-[var(--site-radius)] bg-[var(--site-button)] px-5 text-sm font-black text-[var(--site-button-text)]"
          onClick={onAppointment}
        >
          {profile.ctaText || "Book Appointment"}
        </button>
        <Link
          className="inline-flex min-h-11 items-center justify-center rounded-[var(--site-radius)] border border-slate-200 bg-white px-5 text-sm font-black text-slate-700"
          to="/contact"
        >
          Contact chamber
        </Link>
      </>
    }
  >
    <SimplePanel
      title={profile.visitingDays || "Visiting days"}
      text={profile.visitingTime || "Visiting time"}
      meta={`Assistant: ${profile.assistant || profile.assistantName || "Available"}`}
      variant={variant}
    />
  </ThemeSection>
);

export default AppointmentSimpleVariant;
