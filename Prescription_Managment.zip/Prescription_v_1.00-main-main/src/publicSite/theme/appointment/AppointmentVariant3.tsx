import AppointmentSimpleVariant from "./AppointmentSimpleVariant";

const AppointmentVariant3 = (props) => <AppointmentSimpleVariant {...props} variant="variant-3" />;

export default AppointmentVariant3;
