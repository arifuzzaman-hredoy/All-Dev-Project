import AppointmentSimpleVariant from "./AppointmentSimpleVariant";

const AppointmentVariant2 = (props) => <AppointmentSimpleVariant {...props} variant="variant-2" />;

export default AppointmentVariant2;
