import { getThemeSettings } from "../../lib/themeSettings";
import AppointmentVariant1 from "./AppointmentVariant1";
import AppointmentVariant2 from "./AppointmentVariant2";
import AppointmentVariant3 from "./AppointmentVariant3";
import AppointmentVariant4 from "./AppointmentVariant4";
import AppointmentVariant5 from "./AppointmentVariant5";

const variants = {
  "variant-1": AppointmentVariant1,
  "variant-2": AppointmentVariant2,
  "variant-3": AppointmentVariant3,
  "variant-4": AppointmentVariant4,
  "variant-5": AppointmentVariant5,
};

const AppointmentRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.appointmentVariant] || AppointmentVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default AppointmentRenderer;
