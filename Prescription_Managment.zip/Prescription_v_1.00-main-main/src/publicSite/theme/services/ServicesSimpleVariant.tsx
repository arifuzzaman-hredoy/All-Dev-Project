import PublicServiceCard from "../../components/PublicServiceCard";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const ServicesSimpleVariant = ({ services = [], profile = {}, variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Services"
    title="Focused Neuro Care"
    description={profile.homepageIntro}
    items={services}
    renderItem={(service) =>
      variant === "variant-1" ? (
        <PublicServiceCard key={service.id} service={service} />
      ) : (
        <SimplePanel key={service.id} title={service.title} text={service.description} meta={service.category || "Service"} variant={variant} />
      )
    }
  />
);

export default ServicesSimpleVariant;
