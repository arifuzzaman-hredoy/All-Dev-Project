import ServicesSimpleVariant from "./ServicesSimpleVariant";

const ServicesVariant4 = (props) => <ServicesSimpleVariant {...props} variant="variant-4" />;

export default ServicesVariant4;
