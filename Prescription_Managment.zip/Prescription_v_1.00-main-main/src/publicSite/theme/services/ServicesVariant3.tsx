import ServicesSimpleVariant from "./ServicesSimpleVariant";

const ServicesVariant3 = (props) => <ServicesSimpleVariant {...props} variant="variant-3" />;

export default ServicesVariant3;
