import ServicesSimpleVariant from "./ServicesSimpleVariant";

const ServicesVariant1 = (props) => <ServicesSimpleVariant {...props} variant="variant-1" />;

export default ServicesVariant1;
