import ServicesSimpleVariant from "./ServicesSimpleVariant";

const ServicesVariant2 = (props) => <ServicesSimpleVariant {...props} variant="variant-2" />;

export default ServicesVariant2;
