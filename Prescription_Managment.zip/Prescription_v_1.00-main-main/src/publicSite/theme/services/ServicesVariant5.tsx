import ServicesSimpleVariant from "./ServicesSimpleVariant";

const ServicesVariant5 = (props) => <ServicesSimpleVariant {...props} variant="variant-5" />;

export default ServicesVariant5;
