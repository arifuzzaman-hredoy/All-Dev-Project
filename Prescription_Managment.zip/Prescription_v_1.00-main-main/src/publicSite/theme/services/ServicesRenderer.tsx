import { getThemeSettings } from "../../lib/themeSettings";
import ServicesVariant1 from "./ServicesVariant1";
import ServicesVariant2 from "./ServicesVariant2";
import ServicesVariant3 from "./ServicesVariant3";
import ServicesVariant4 from "./ServicesVariant4";
import ServicesVariant5 from "./ServicesVariant5";

const variants = {
  "variant-1": ServicesVariant1,
  "variant-2": ServicesVariant2,
  "variant-3": ServicesVariant3,
  "variant-4": ServicesVariant4,
  "variant-5": ServicesVariant5,
};

const ServicesRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.servicesVariant] || ServicesVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default ServicesRenderer;
