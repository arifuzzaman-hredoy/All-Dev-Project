import QaSimpleVariant from "./QaSimpleVariant";

const QaVariant1 = (props) => <QaSimpleVariant {...props} variant="variant-1" />;

export default QaVariant1;
