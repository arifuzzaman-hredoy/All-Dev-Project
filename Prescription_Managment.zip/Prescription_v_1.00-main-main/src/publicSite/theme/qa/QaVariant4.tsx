import QaSimpleVariant from "./QaSimpleVariant";

const QaVariant4 = (props) => <QaSimpleVariant {...props} variant="variant-4" />;

export default QaVariant4;
