import PublicQaCard from "../../components/PublicQaCard";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const QaSimpleVariant = ({ qa = [], variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Q&A"
    title="Answered Patient Questions"
    items={qa}
    columns="two"
    emptyTitle="No answered questions"
    emptyMessage="Answered patient questions will appear here."
    renderItem={(item) =>
      variant === "variant-1" ? (
        <PublicQaCard key={item.id} item={item} />
      ) : (
        <SimplePanel key={item.id} title={item.question} text={item.answer} meta={item.patientName || "Patient"} variant={variant} />
      )
    }
  />
);

export default QaSimpleVariant;
