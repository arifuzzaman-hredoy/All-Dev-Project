import QaSimpleVariant from "./QaSimpleVariant";

const QaVariant2 = (props) => <QaSimpleVariant {...props} variant="variant-2" />;

export default QaVariant2;
