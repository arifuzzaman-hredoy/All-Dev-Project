import QaSimpleVariant from "./QaSimpleVariant";

const QaVariant3 = (props) => <QaSimpleVariant {...props} variant="variant-3" />;

export default QaVariant3;
