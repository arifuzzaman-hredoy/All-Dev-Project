import { getThemeSettings } from "../../lib/themeSettings";
import QaVariant1 from "./QaVariant1";
import QaVariant2 from "./QaVariant2";
import QaVariant3 from "./QaVariant3";
import QaVariant4 from "./QaVariant4";
import QaVariant5 from "./QaVariant5";

const variants = {
  "variant-1": QaVariant1,
  "variant-2": QaVariant2,
  "variant-3": QaVariant3,
  "variant-4": QaVariant4,
  "variant-5": QaVariant5,
};

const QaRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.qaVariant] || QaVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default QaRenderer;
