import QaSimpleVariant from "./QaSimpleVariant";

const QaVariant5 = (props) => <QaSimpleVariant {...props} variant="variant-5" />;

export default QaVariant5;
