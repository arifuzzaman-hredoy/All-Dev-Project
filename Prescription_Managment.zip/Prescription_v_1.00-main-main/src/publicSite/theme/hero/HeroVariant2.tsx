import HeroSimpleVariant from "./HeroSimpleVariant";

const HeroVariant2 = (props) => <HeroSimpleVariant {...props} variant="variant-2" />;

export default HeroVariant2;
