import HeroSimpleVariant from "./HeroSimpleVariant";

const HeroVariant4 = (props) => <HeroSimpleVariant {...props} variant="variant-4" />;

export default HeroVariant4;
