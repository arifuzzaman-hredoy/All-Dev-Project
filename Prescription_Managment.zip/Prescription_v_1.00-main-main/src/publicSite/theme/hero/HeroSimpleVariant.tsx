import { CalendarDays, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";

const fallbackHeroImage =
  "https://images.unsplash.com/photo-1582750433449-648ed127bb54?q=80&w=1100&auto=format&fit=crop";

const styleMap = {
  "variant-2": "border border-[var(--site-primary)]/30 bg-white",
  "variant-3": "rounded-[var(--site-radius)] border border-slate-200 bg-white shadow-sm",
  "variant-4": "bg-transparent text-center",
  "variant-5": "border-y border-slate-300 bg-slate-50 font-mono",
};

const HeroSimpleVariant = ({ profile = {}, onAppointment, variant = "variant-2" }) => {
  const centered = variant === "variant-4";
  const classic = variant === "variant-5";
  const image = profile.heroImageUrl || profile.profileImageUrl || fallbackHeroImage;

  return (
    <section
      className={[
        "mx-auto mt-6 w-[min(1180px,calc(100%-1rem))] overflow-hidden sm:w-[min(1180px,calc(100%-1.75rem))]",
        "py-[var(--site-section-spacing)]",
        classic ? "px-4" : "px-5 sm:px-8",
        styleMap[variant],
      ].join(" ")}
    >
      <div
        className={[
          "grid gap-8",
          centered ? "justify-items-center" : "lg:grid-cols-[1fr_420px] lg:items-center",
        ].join(" ")}
      >
        <div className={centered ? "max-w-3xl" : "max-w-2xl"}>
          <p className="text-xs font-black uppercase tracking-wider text-[var(--site-primary)]">
            {profile.specialization || "Specialist Doctor"}
          </p>
          <h1 className="mt-3 text-4xl font-black leading-tight text-slate-950 md:text-5xl">
            {profile.heroTitle || profile.doctorName || "Get Appointment Easy and Fast"}
          </h1>
          <p className="mt-4 text-base font-semibold leading-7 text-slate-600">
            {profile.shortBio || "Focused clinical care with clear guidance and appointment support."}
          </p>
          <div className={["mt-6 flex flex-wrap gap-3", centered ? "justify-center" : ""].join(" ")}>
            <button
              type="button"
              onClick={onAppointment}
              className="inline-flex min-h-12 items-center gap-2 rounded-[var(--site-radius)] bg-[var(--site-button)] px-5 text-sm font-black text-[var(--site-button-text)]"
            >
              <CalendarDays size={17} />
              {profile.ctaText || "Book Appointment"}
            </button>
            <button
              type="button"
              onClick={() => window.dispatchEvent(new Event("open-public-message-modal"))}
              className="inline-flex min-h-12 items-center gap-2 rounded-[var(--site-radius)] border border-slate-200 bg-white px-5 text-sm font-black text-slate-700"
            >
              <MessageCircle size={17} />
              Message
            </button>
            <Link
              to="/about"
              className="inline-flex min-h-12 items-center rounded-[var(--site-radius)] border border-slate-200 bg-white px-5 text-sm font-black text-slate-700"
            >
              View Profile
            </Link>
          </div>
        </div>

        <img
          src={image}
          alt={profile.doctorName || "Doctor"}
          className={[
            "h-72 w-full object-cover",
            classic ? "border border-slate-300" : "rounded-[var(--site-radius)]",
            centered ? "max-w-2xl" : "",
          ].join(" ")}
        />
      </div>
    </section>
  );
};

export default HeroSimpleVariant;
