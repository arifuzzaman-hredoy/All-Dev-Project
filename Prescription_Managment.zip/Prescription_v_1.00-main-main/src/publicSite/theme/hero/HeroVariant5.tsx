import HeroSimpleVariant from "./HeroSimpleVariant";

const HeroVariant5 = (props) => <HeroSimpleVariant {...props} variant="variant-5" />;

export default HeroVariant5;
