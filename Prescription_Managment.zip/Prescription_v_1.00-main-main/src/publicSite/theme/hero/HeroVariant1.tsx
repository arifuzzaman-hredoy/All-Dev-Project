import PublicHero from "../../components/PublicHero";

const HeroVariant1 = (props) => <PublicHero {...props} />;

export default HeroVariant1;
