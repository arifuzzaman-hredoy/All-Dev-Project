import { getThemeSettings } from "../../lib/themeSettings";
import HeroVariant1 from "./HeroVariant1";
import HeroVariant2 from "./HeroVariant2";
import HeroVariant3 from "./HeroVariant3";
import HeroVariant4 from "./HeroVariant4";
import HeroVariant5 from "./HeroVariant5";

const variants = {
  "variant-1": HeroVariant1,
  "variant-2": HeroVariant2,
  "variant-3": HeroVariant3,
  "variant-4": HeroVariant4,
  "variant-5": HeroVariant5,
};

const HeroRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.heroVariant] || HeroVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default HeroRenderer;
