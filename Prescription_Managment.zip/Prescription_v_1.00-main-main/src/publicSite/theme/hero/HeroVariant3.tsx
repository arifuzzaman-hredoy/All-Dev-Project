import HeroSimpleVariant from "./HeroSimpleVariant";

const HeroVariant3 = (props) => <HeroSimpleVariant {...props} variant="variant-3" />;

export default HeroVariant3;
