import { getThemeSettings } from "../../lib/themeSettings";
import GalleryVariant1 from "./GalleryVariant1";
import GalleryVariant2 from "./GalleryVariant2";
import GalleryVariant3 from "./GalleryVariant3";
import GalleryVariant4 from "./GalleryVariant4";
import GalleryVariant5 from "./GalleryVariant5";

const variants = {
  "variant-1": GalleryVariant1,
  "variant-2": GalleryVariant2,
  "variant-3": GalleryVariant3,
  "variant-4": GalleryVariant4,
  "variant-5": GalleryVariant5,
};

const GalleryRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.galleryVariant] || GalleryVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default GalleryRenderer;
