import GallerySimpleVariant from "./GallerySimpleVariant";

const GalleryVariant5 = (props) => <GallerySimpleVariant {...props} variant="variant-5" />;

export default GalleryVariant5;
