import GallerySimpleVariant from "./GallerySimpleVariant";

const GalleryVariant3 = (props) => <GallerySimpleVariant {...props} variant="variant-3" />;

export default GalleryVariant3;
