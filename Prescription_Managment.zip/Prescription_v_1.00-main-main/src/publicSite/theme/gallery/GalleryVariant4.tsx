import GallerySimpleVariant from "./GallerySimpleVariant";

const GalleryVariant4 = (props) => <GallerySimpleVariant {...props} variant="variant-4" />;

export default GalleryVariant4;
