import GallerySimpleVariant from "./GallerySimpleVariant";

const GalleryVariant1 = (props) => <GallerySimpleVariant {...props} variant="variant-1" />;

export default GalleryVariant1;
