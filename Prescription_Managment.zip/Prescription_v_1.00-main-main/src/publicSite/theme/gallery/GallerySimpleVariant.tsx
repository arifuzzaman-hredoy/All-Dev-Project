import PublicGalleryCard from "../../components/PublicGalleryCard";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const GallerySimpleVariant = ({ gallery = [], variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Gallery"
    title="Chamber & Care Moments"
    items={gallery}
    columns="two"
    emptyTitle="No gallery items"
    emptyMessage="Gallery updates will appear here."
    renderItem={(item) =>
      variant === "variant-1" ? (
        <PublicGalleryCard key={item.id} item={item} />
      ) : (
        <SimplePanel key={item.id} title={item.title} text={item.description} meta="Gallery" variant={variant}>
          {item.imageUrl ? <img src={item.imageUrl} alt={item.title} className="mt-3 h-40 w-full object-cover" /> : null}
        </SimplePanel>
      )
    }
  />
);

export default GallerySimpleVariant;
