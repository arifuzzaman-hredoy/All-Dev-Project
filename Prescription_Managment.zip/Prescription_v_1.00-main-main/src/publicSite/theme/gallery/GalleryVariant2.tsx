import GallerySimpleVariant from "./GallerySimpleVariant";

const GalleryVariant2 = (props) => <GallerySimpleVariant {...props} variant="variant-2" />;

export default GalleryVariant2;
