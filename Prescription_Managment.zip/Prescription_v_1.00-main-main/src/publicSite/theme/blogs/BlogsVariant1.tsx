import BlogsSimpleVariant from "./BlogsSimpleVariant";

const BlogsVariant1 = (props) => <BlogsSimpleVariant {...props} variant="variant-1" />;

export default BlogsVariant1;
