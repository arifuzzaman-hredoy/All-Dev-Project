import BlogsSimpleVariant from "./BlogsSimpleVariant";

const BlogsVariant2 = (props) => <BlogsSimpleVariant {...props} variant="variant-2" />;

export default BlogsVariant2;
