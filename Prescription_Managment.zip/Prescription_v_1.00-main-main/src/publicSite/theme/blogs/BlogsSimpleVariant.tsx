import PublicBlogCard from "../../components/PublicBlogCard";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const BlogsSimpleVariant = ({ blogs = [], variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="Blogs"
    title="Recent Health Notes"
    items={blogs}
    columns="two"
    emptyTitle="No published blogs"
    emptyMessage="Published articles will appear here."
    renderItem={(blog) =>
      variant === "variant-1" ? (
        <PublicBlogCard key={blog.id} blog={blog} />
      ) : (
        <SimplePanel key={blog.id} title={blog.title} text={blog.excerpt || blog.summary} meta={blog.category || "Health Note"} to={`/blogs/${blog.slug}`} variant={variant} />
      )
    }
  />
);

export default BlogsSimpleVariant;
