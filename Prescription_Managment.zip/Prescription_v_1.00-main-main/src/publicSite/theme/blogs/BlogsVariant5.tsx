import BlogsSimpleVariant from "./BlogsSimpleVariant";

const BlogsVariant5 = (props) => <BlogsSimpleVariant {...props} variant="variant-5" />;

export default BlogsVariant5;
