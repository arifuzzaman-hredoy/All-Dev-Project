import { getThemeSettings } from "../../lib/themeSettings";
import BlogsVariant1 from "./BlogsVariant1";
import BlogsVariant2 from "./BlogsVariant2";
import BlogsVariant3 from "./BlogsVariant3";
import BlogsVariant4 from "./BlogsVariant4";
import BlogsVariant5 from "./BlogsVariant5";

const variants = {
  "variant-1": BlogsVariant1,
  "variant-2": BlogsVariant2,
  "variant-3": BlogsVariant3,
  "variant-4": BlogsVariant4,
  "variant-5": BlogsVariant5,
};

const BlogsRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.blogsVariant] || BlogsVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default BlogsRenderer;
