import BlogsSimpleVariant from "./BlogsSimpleVariant";

const BlogsVariant3 = (props) => <BlogsSimpleVariant {...props} variant="variant-3" />;

export default BlogsVariant3;
