import BlogsSimpleVariant from "./BlogsSimpleVariant";

const BlogsVariant4 = (props) => <BlogsSimpleVariant {...props} variant="variant-4" />;

export default BlogsVariant4;
