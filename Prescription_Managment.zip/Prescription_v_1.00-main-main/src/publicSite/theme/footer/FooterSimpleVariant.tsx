import { Link } from "react-router-dom";

const styles = {
  "variant-2": "border border-[var(--site-primary)]/30 bg-white",
  "variant-3": "rounded-[var(--site-radius)] border border-slate-200 bg-white shadow-sm",
  "variant-4": "border-t border-slate-200 bg-transparent text-center",
  "variant-5": "border-y border-slate-300 bg-slate-50 font-mono",
};

const FooterSimpleVariant = ({ profile = {}, variant = "variant-2" }) => (
  <footer
    className={[
      "mx-auto mb-4 mt-8 grid w-[min(1180px,calc(100%-1rem))] gap-4 p-5 sm:w-[min(1180px,calc(100%-1.75rem))] md:grid-cols-[1fr_auto_auto] md:items-center",
      styles[variant] || styles["variant-2"],
      variant === "variant-4" ? "md:grid-cols-1" : "",
    ].join(" ")}
  >
    <div>
      <strong className="text-lg font-black text-[var(--site-primary)]">
        {profile.brandName || profile.siteName || "CareBridge"}
      </strong>
      <p className="mt-1 max-w-xl text-sm font-semibold leading-6 text-slate-600">
        {profile.footerText || profile.shortBio}
      </p>
    </div>
    <div className="grid gap-1 text-sm font-bold text-slate-600">
      <span>{profile.chamberName}</span>
      <span>{profile.phone}</span>
      <span>{profile.email}</span>
    </div>
    <Link
      className="inline-flex w-fit rounded-[var(--site-radius)] border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-700"
      to="/doctor/dashboard"
    >
      Doctor Panel
    </Link>
  </footer>
);

export default FooterSimpleVariant;
