import PublicFooter from "../../components/PublicFooter";

const FooterVariant1 = (props) => <PublicFooter {...props} />;

export default FooterVariant1;
