import FooterSimpleVariant from "./FooterSimpleVariant";

const FooterVariant3 = (props) => <FooterSimpleVariant {...props} variant="variant-3" />;

export default FooterVariant3;
