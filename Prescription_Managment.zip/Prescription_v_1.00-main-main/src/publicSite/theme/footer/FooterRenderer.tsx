import { getThemeSettings } from "../../lib/themeSettings";
import FooterVariant1 from "./FooterVariant1";
import FooterVariant2 from "./FooterVariant2";
import FooterVariant3 from "./FooterVariant3";
import FooterVariant4 from "./FooterVariant4";
import FooterVariant5 from "./FooterVariant5";

const variants = {
  "variant-1": FooterVariant1,
  "variant-2": FooterVariant2,
  "variant-3": FooterVariant3,
  "variant-4": FooterVariant4,
  "variant-5": FooterVariant5,
};

const FooterRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.footerVariant] || FooterVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default FooterRenderer;
