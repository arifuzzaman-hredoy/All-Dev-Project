import FooterSimpleVariant from "./FooterSimpleVariant";

const FooterVariant2 = (props) => <FooterSimpleVariant {...props} variant="variant-2" />;

export default FooterVariant2;
