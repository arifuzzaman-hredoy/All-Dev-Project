import FooterSimpleVariant from "./FooterSimpleVariant";

const FooterVariant5 = (props) => <FooterSimpleVariant {...props} variant="variant-5" />;

export default FooterVariant5;
