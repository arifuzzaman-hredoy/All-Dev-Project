import FooterSimpleVariant from "./FooterSimpleVariant";

const FooterVariant4 = (props) => <FooterSimpleVariant {...props} variant="variant-4" />;

export default FooterVariant4;
