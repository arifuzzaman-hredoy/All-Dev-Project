import AboutSimpleVariant from "./AboutSimpleVariant";

const AboutVariant3 = (props) => <AboutSimpleVariant {...props} variant="variant-3" />;

export default AboutVariant3;
