import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const AboutSimpleVariant = ({ profile = {}, variant = "variant-1" }) => (
  <ThemeSection
    variant={variant === "variant-1" ? "variant-3" : variant}
    eyebrow="About"
    title={profile.doctorName || "About Doctor"}
    description={profile.shortBio}
  >
    <SimplePanel
      title={profile.specialization || "Specialist Doctor"}
      text={profile.longBio || profile.shortBio}
      meta={profile.title || profile.chamberName}
      variant={variant}
    />
  </ThemeSection>
);

export default AboutSimpleVariant;
