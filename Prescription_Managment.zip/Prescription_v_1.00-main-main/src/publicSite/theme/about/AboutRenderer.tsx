import { getThemeSettings } from "../../lib/themeSettings";
import AboutVariant1 from "./AboutVariant1";
import AboutVariant2 from "./AboutVariant2";
import AboutVariant3 from "./AboutVariant3";
import AboutVariant4 from "./AboutVariant4";
import AboutVariant5 from "./AboutVariant5";

const variants = {
  "variant-1": AboutVariant1,
  "variant-2": AboutVariant2,
  "variant-3": AboutVariant3,
  "variant-4": AboutVariant4,
  "variant-5": AboutVariant5,
};

const AboutRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.aboutVariant] || AboutVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default AboutRenderer;
