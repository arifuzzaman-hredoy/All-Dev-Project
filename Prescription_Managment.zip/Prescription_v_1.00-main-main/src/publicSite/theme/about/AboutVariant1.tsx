import AboutSimpleVariant from "./AboutSimpleVariant";

const AboutVariant1 = (props) => <AboutSimpleVariant {...props} variant="variant-1" />;

export default AboutVariant1;
