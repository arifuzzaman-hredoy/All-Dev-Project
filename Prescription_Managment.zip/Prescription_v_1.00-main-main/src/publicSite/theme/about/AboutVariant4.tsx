import AboutSimpleVariant from "./AboutSimpleVariant";

const AboutVariant4 = (props) => <AboutSimpleVariant {...props} variant="variant-4" />;

export default AboutVariant4;
