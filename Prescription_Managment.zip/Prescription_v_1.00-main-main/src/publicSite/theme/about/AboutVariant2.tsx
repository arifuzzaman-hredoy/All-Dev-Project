import AboutSimpleVariant from "./AboutSimpleVariant";

const AboutVariant2 = (props) => <AboutSimpleVariant {...props} variant="variant-2" />;

export default AboutVariant2;
