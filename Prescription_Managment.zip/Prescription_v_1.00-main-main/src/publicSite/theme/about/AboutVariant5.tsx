import AboutSimpleVariant from "./AboutSimpleVariant";

const AboutVariant5 = (props) => <AboutSimpleVariant {...props} variant="variant-5" />;

export default AboutVariant5;
