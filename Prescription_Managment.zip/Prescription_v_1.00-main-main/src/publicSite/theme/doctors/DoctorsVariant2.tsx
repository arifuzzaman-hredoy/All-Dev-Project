import DoctorsSimpleVariant from "./DoctorsSimpleVariant";

const DoctorsVariant2 = (props) => <DoctorsSimpleVariant {...props} variant="variant-2" />;

export default DoctorsVariant2;
