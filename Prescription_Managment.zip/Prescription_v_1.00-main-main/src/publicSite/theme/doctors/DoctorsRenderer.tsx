import { getThemeSettings } from "../../lib/themeSettings";
import DoctorsVariant1 from "./DoctorsVariant1";
import DoctorsVariant2 from "./DoctorsVariant2";
import DoctorsVariant3 from "./DoctorsVariant3";
import DoctorsVariant4 from "./DoctorsVariant4";
import DoctorsVariant5 from "./DoctorsVariant5";

const variants = {
  "variant-1": DoctorsVariant1,
  "variant-2": DoctorsVariant2,
  "variant-3": DoctorsVariant3,
  "variant-4": DoctorsVariant4,
  "variant-5": DoctorsVariant5,
};

const DoctorsRenderer = ({ themeSettings, ...props }) => {
  const theme = themeSettings || getThemeSettings();
  const Component = variants[theme.doctorsVariant] || DoctorsVariant1;

  return <Component {...props} themeSettings={theme} />;
};

export default DoctorsRenderer;
