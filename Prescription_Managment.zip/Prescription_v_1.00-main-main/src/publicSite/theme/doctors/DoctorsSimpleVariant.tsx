import PublicDoctorCard from "../../components/PublicDoctorCard";
import ThemeSection, { SimplePanel } from "../shared/SectionVariantFactory";

const DoctorsSimpleVariant = ({ profile = {}, variant = "variant-1" }) => (
  <ThemeSection variant={variant === "variant-1" ? "variant-3" : variant} eyebrow="Doctor" title="Doctor Profile">
    {variant === "variant-1" ? (
      <PublicDoctorCard profile={profile} />
    ) : (
      <SimplePanel
        title={profile.doctorName || "Doctor Name"}
        text={profile.longBio || profile.shortBio}
        meta={profile.specialization || "Specialist"}
        variant={variant}
      >
        <p className="mt-3 text-sm font-bold text-slate-600">{profile.chamberName}</p>
      </SimplePanel>
    )}
  </ThemeSection>
);

export default DoctorsSimpleVariant;
