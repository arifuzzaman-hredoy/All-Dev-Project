import DoctorsSimpleVariant from "./DoctorsSimpleVariant";

const DoctorsVariant5 = (props) => <DoctorsSimpleVariant {...props} variant="variant-5" />;

export default DoctorsVariant5;
