import DoctorsSimpleVariant from "./DoctorsSimpleVariant";

const DoctorsVariant1 = (props) => <DoctorsSimpleVariant {...props} variant="variant-1" />;

export default DoctorsVariant1;
