import DoctorsSimpleVariant from "./DoctorsSimpleVariant";

const DoctorsVariant3 = (props) => <DoctorsSimpleVariant {...props} variant="variant-3" />;

export default DoctorsVariant3;
