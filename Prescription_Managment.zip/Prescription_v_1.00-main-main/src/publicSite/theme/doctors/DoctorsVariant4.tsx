import DoctorsSimpleVariant from "./DoctorsSimpleVariant";

const DoctorsVariant4 = (props) => <DoctorsSimpleVariant {...props} variant="variant-4" />;

export default DoctorsVariant4;
