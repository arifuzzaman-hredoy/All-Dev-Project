import { Link } from "react-router-dom";
import EmptyPublicState from "../../components/EmptyPublicState";
import PublicSectionHeader from "../../components/PublicSectionHeader";

const sectionWidth = "mx-auto w-[min(1180px,calc(100%-1rem))] sm:w-[min(1180px,calc(100%-1.75rem))]";

const variantStyles = {
  "variant-2": {
    section: "border border-[var(--site-primary)]/30 bg-white",
    header: "border-b border-slate-200 pb-4",
    grid: "grid gap-3 md:grid-cols-2 lg:grid-cols-3",
  },
  "variant-3": {
    section: "rounded-[var(--site-radius)] border border-slate-200 bg-white p-5 shadow-sm",
    header: "",
    grid: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
  },
  "variant-4": {
    section: "bg-transparent",
    header: "mx-auto max-w-2xl text-center",
    grid: "grid gap-5 md:grid-cols-2 lg:grid-cols-3",
  },
  "variant-5": {
    section: "border border-slate-300 bg-white font-mono",
    header: "border-b border-slate-300 bg-slate-50 p-3",
    grid: "grid divide-y divide-slate-200 md:grid-cols-2 md:divide-x md:divide-y-0 lg:grid-cols-3",
  },
};

const ThemeSection = ({
  variant = "variant-2",
  eyebrow,
  title,
  description,
  items = [],
  renderItem,
  emptyTitle = "No content",
  emptyMessage = "Content will appear here.",
  columns = "cards",
  actions,
  children,
}) => {
  const style = variantStyles[variant] || variantStyles["variant-2"];
  const gridClass =
    columns === "two"
      ? style.grid.replace("lg:grid-cols-3", "")
      : columns === "one"
        ? "grid gap-4"
        : style.grid;

  return (
    <section
      className={[
        sectionWidth,
        "py-[var(--site-section-spacing)]",
        style.section,
        variant === "variant-5" ? "p-0" : "",
      ].join(" ")}
    >
      <div className={style.header}>
        <PublicSectionHeader
          eyebrow={eyebrow}
          title={title}
          description={description}
        />
      </div>

      {children ? <div className="mt-5">{children}</div> : null}

      {items.length ? (
        <div className={["mt-5", gridClass].join(" ")}>
          {items.map((item) => renderItem(item, variant))}
        </div>
      ) : renderItem ? (
        <div className="mt-5">
          <EmptyPublicState title={emptyTitle} message={emptyMessage} />
        </div>
      ) : null}

      {actions ? <div className="mt-6 flex flex-wrap gap-3">{actions}</div> : null}
    </section>
  );
};

export const SimplePanel = ({ title, text, meta, to, children, variant }) => {
  const classic = variant === "variant-5";

  const content = (
    <article
      className={[
        classic
          ? "p-4"
          : "h-full rounded-[var(--site-radius)] border border-slate-200 bg-white p-5 shadow-sm",
      ].join(" ")}
    >
      {meta ? (
        <p className="text-xs font-black uppercase tracking-wider text-[var(--site-primary)]">
          {meta}
        </p>
      ) : null}
      <h3 className="mt-2 text-lg font-black text-slate-950">{title}</h3>
      {text ? (
        <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{text}</p>
      ) : null}
      {children}
    </article>
  );

  if (!to) return content;

  return (
    <Link to={to} className="block transition hover:-translate-y-0.5">
      {content}
    </Link>
  );
};

export default ThemeSection;
