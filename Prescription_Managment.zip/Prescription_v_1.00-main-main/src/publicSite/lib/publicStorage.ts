import defaults from "../data/publicDefaults";
import { fireAndForget, apiFetch } from "../../lib/apiClient";
import { notifyDoctorIdentityUpdated, normalizeDoctorIdentity } from "../../services/doctorIdentityApi";

export const STORAGE_KEYS = {
  profile: "carebridge_public_profile",
  services: "carebridge_public_services",
  blogs: "carebridge_public_blogs",
  qa: "carebridge_public_qa",
  gallery: "carebridge_public_gallery",
  appointments: "carebridge_public_appointments",
  messages: "carebridge_public_messages",
  prescriptions: "carebridge_public_prescriptions",
};

const canUseStorage = () => typeof window !== "undefined" && window.localStorage;

const read = (key, fallback) => {
  if (!canUseStorage()) return fallback;
  try {
    const stored = window.localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch {
    return fallback;
  }
};

const remoteContentTypes = {
  [STORAGE_KEYS.profile]: "profile",
  [STORAGE_KEYS.services]: "services",
  [STORAGE_KEYS.blogs]: "blogs",
  [STORAGE_KEYS.qa]: "qa",
  [STORAGE_KEYS.gallery]: "gallery",
  [STORAGE_KEYS.prescriptions]: "prescriptions",
};

const syncContentToApi = (key, data) => {
  const type = remoteContentTypes[key];
  if (type) fireAndForget(`/api/content/${type}`, { data }, "PUT");
};

const write = (key, data) => {
  if (!canUseStorage()) return data;
  try {
    window.localStorage.setItem(key, JSON.stringify(data));
    syncContentToApi(key, data);
    window.dispatchEvent(
      new CustomEvent("carebridge-storage-updated", { detail: { key } }),
    );
  } catch {
    // localStorage can be blocked; keep the UI usable.
  }
  return data;
};

const createId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`;

export const getPublicProfile = () => read(STORAGE_KEYS.profile, defaults.profile);
export const savePublicProfile = (data) => {
  const identity = normalizeDoctorIdentity({ ...defaults.profile, ...data });
  const saved = write(STORAGE_KEYS.profile, identity);
  notifyDoctorIdentityUpdated(identity);
  return saved;
};

export const getPublicServices = () => read(STORAGE_KEYS.services, defaults.services);
export const savePublicServices = (data) => write(STORAGE_KEYS.services, data);

export const getPublicBlogs = () => read(STORAGE_KEYS.blogs, defaults.blogs);
export const savePublicBlogs = (data) => write(STORAGE_KEYS.blogs, data);
export const getPublishedBlogs = () =>
  getPublicBlogs().filter((blog) => blog.status === "published");
export const getBlogBySlug = (slug) =>
  getPublicBlogs().find((blog) => blog.slug === slug && blog.status === "published");

export const getPublicQa = () => read(STORAGE_KEYS.qa, defaults.qa);
export const savePublicQa = (data) => write(STORAGE_KEYS.qa, data);
export const getAnsweredQa = () =>
  getPublicQa().filter((item) => item.status === "answered");
export const addPublicQuestion = (question) => {
  const item = {
    id: createId("qa"),
    patientName: question.patientName,
    phone: question.phone,
    question: question.question,
    answer: "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  savePublicQa([item, ...getPublicQa()]);
  fireAndForget("/api/questions", question);
  return item;
};

export const getPublicGallery = () => read(STORAGE_KEYS.gallery, defaults.gallery);
export const savePublicGallery = (data) => write(STORAGE_KEYS.gallery, data);

export const getPublicAppointments = () =>
  read(STORAGE_KEYS.appointments, defaults.appointments);
export const savePublicAppointments = (data) =>
  write(STORAGE_KEYS.appointments, data);
export const addPublicAppointment = (data) => {
  const item = {
    id: createId("apt"),
    ...data,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  savePublicAppointments([item, ...getPublicAppointments()]);
  fireAndForget("/api/appointments", data);
  return item;
};

export const submitPublicAppointment = async (data) => {
  const response = await apiFetch("/api/appointments", {
    method: "POST",
    body: JSON.stringify(data),
  });
  const item = response.item || {
    id: createId("apt"),
    ...data,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  savePublicAppointments([item, ...getPublicAppointments()]);
  return item;
};

export const getPublicMessages = () => read(STORAGE_KEYS.messages, defaults.messages);
export const savePublicMessages = (data) => write(STORAGE_KEYS.messages, data);
export const addPublicMessage = (data) => {
  const item = {
    id: createId("msg"),
    ...data,
    status: "new",
    createdAt: new Date().toISOString(),
  };
  savePublicMessages([item, ...getPublicMessages()]);
  fireAndForget("/api/messages", data);
  return item;
};

export const getPublicPrescriptions = () =>
  read(STORAGE_KEYS.prescriptions, defaults.prescriptions);
export const savePublicPrescriptions = (data) =>
  write(STORAGE_KEYS.prescriptions, data);
export const findPrescription = (query) => {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return null;
  return getPublicPrescriptions().find(
    (rx) =>
      rx.patientId?.toLowerCase() === normalized ||
      rx.phone?.replace(/\s/g, "").toLowerCase() === normalized.replace(/\s/g, ""),
  );
};


export const refreshPublicContentFromApi = async () => {
  const response = await apiFetch("/api/content");
  return response.content;
};

export const loadPublicContent = async (type, fallback) => {
  if (type === "profile") {
    const response = await apiFetch("/api/public/doctor-identity");
    const identity = normalizeDoctorIdentity(response.data ?? fallback);
    savePublicProfile(identity);
    notifyDoctorIdentityUpdated(identity);
    return identity;
  }
  const response = await apiFetch(`/api/content/${type}`);
  return response.data ?? fallback;
};

export const savePublicContent = async (type, data) => {
  if (type === "profile") {
    const response = await apiFetch("/api/admin/site-identity", {
      method: "PUT",
      body: JSON.stringify(data),
    });
    const identity = normalizeDoctorIdentity(response.data ?? data);
    savePublicProfile(identity);
    notifyDoctorIdentityUpdated(identity);
    return identity;
  }
  const response = await apiFetch(`/api/content/${type}`, {
    method: "PUT",
    body: JSON.stringify({ data }),
  });
  return response.data;
};

export const uploadPublicFile = async (file) => {
  if (!file) throw new Error("No file selected.");
  if (!file.type.startsWith("image/")) throw new Error("Only image files are allowed.");
  if (file.size > 2.5 * 1024 * 1024) throw new Error("Image must be under 2.5MB.");

  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read image file."));
    reader.readAsDataURL(file);
  });

  const response = await apiFetch("/api/admin/upload", {
    method: "POST",
    body: JSON.stringify({
      fileName: file.name,
      mimeType: file.type,
      dataUrl,
    }),
  });

  return response.file;
};
