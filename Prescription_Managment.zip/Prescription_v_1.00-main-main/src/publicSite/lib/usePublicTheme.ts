import { useEffect, useMemo, useState } from "react";
import {
  fetchThemeSettings,
  getThemeSettings,
  getThemeStyle,
} from "./themeSettings";

export const usePublicTheme = () => {
  const [themeSettings, setThemeSettings] = useState(getThemeSettings);

  useEffect(() => {
    const syncLocal = () => setThemeSettings(getThemeSettings());

    window.addEventListener("carebridge-theme-updated", syncLocal);
    fetchThemeSettings()
      .then(setThemeSettings)
      .catch(() => setThemeSettings(getThemeSettings()));

    return () => window.removeEventListener("carebridge-theme-updated", syncLocal);
  }, []);

  const themeStyle = useMemo(
    () => getThemeStyle(themeSettings),
    [themeSettings]
  );

  return { themeSettings, themeStyle };
};
