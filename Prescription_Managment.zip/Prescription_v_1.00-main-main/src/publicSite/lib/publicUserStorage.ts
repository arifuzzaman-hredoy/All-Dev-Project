import { fireAndForget } from "../../lib/apiClient";
export const PUBLIC_USERS_KEY = "public_registered_users";
export const PUBLIC_ACTIVE_USER_KEY = "public_active_user";
export const PUBLIC_REMEMBER_USER_KEY = "public_remember_user";
export const PUBLIC_PASSWORD_RESET_KEY = "public_password_reset_request";
export const PUBLIC_MESSAGES_KEY = "public_user_messages";
export const PUBLIC_POPUP_DISMISSED_KEY = "public_user_popup_dismissed";

const normalize = (value) => String(value || "").trim().toLowerCase();

const safeParse = (value, fallback) => {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
};

export const safeReadList = (key) => {
  if (typeof window === "undefined") return [];
  return safeParse(window.localStorage.getItem(key), []);
};

export const safeWriteList = (key, value) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
};

export const getPublicUsers = () => safeReadList(PUBLIC_USERS_KEY);

export const savePublicUsers = (users) => {
  safeWriteList(PUBLIC_USERS_KEY, users);
  window.dispatchEvent(new Event("public-users-updated"));
};

export const getActivePublicUser = () => {
  if (typeof window === "undefined") return null;
  return safeParse(window.localStorage.getItem(PUBLIC_ACTIVE_USER_KEY), null);
};

export const setActivePublicUser = (user) => {
  if (typeof window === "undefined") return;
  const publicUser = { ...user };
  delete publicUser.password;
  window.localStorage.setItem(PUBLIC_ACTIVE_USER_KEY, JSON.stringify(publicUser));
  window.dispatchEvent(new Event("public-users-updated"));
};

export const logoutPublicUser = () => {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(PUBLIC_ACTIVE_USER_KEY);
  window.dispatchEvent(new Event("public-users-updated"));
};

export const getRememberedPublicUser = () => {
  if (typeof window === "undefined") return "";
  return window.localStorage.getItem(PUBLIC_REMEMBER_USER_KEY) || "";
};

export const getPasswordStrength = (password) => {
  const value = String(password || "");

  if (value.length < 6) {
    return { label: "Weak", color: "red", score: 1 };
  }

  const hasLower = /[a-z]/.test(value);
  const hasUpper = /[A-Z]/.test(value);
  const hasNumber = /[0-9]/.test(value);
  const hasSpecial = /[^A-Za-z0-9]/.test(value);

  if (value.length >= 8 && hasLower && hasUpper && hasNumber && hasSpecial) {
    return { label: "Strong", color: "green", score: 3 };
  }

  if ((hasLower || hasUpper) && hasNumber) {
    return { label: "Medium", color: "yellow", score: 2 };
  }

  return { label: "Weak", color: "red", score: 1 };
};

export const registerPublicUser = (input) => {
  const users = getPublicUsers();
  const name = String(input.name || "").trim();
  const phone = String(input.phone || "").trim();
  const email = String(input.email || "").trim();
  const password = String(input.password || "");

  if (!name || !phone || !email || !password) {
    return {
      success: false,
      ok: false,
      message: "Name, phone, email and password are required.",
    };
  }

  if (password.length < 6) {
    return {
      success: false,
      ok: false,
      message: "Password must be at least 6 characters.",
    };
  }

  const exists = users.some(
    (user) =>
      normalize(user.phone) === normalize(phone) ||
      normalize(user.email) === normalize(email),
  );

  if (exists) {
    return {
      success: false,
      ok: false,
      message: "This phone or email is already registered.",
    };
  }

  const now = new Date().toISOString();
  const user = {
    id: Date.now(),
    name,
    phone,
    email,
    age: String(input.age || "").trim(),
    gender: input.gender || "Female",
    address: String(input.address || "").trim(),
    password,
    avatar: "",
    status: "Active",
    createdAt: now,
    updatedAt: now,
  };

  savePublicUsers([user, ...users]);
  fireAndForget("/api/public/register", { name, phone, email, password, age: user.age, gender: user.gender, address: user.address });
  setActivePublicUser(user);
  window.localStorage.setItem(PUBLIC_POPUP_DISMISSED_KEY, "true");

  if (input.rememberMe) {
    window.localStorage.setItem(PUBLIC_REMEMBER_USER_KEY, email || phone);
  }

  const publicUser = { ...user };
  delete publicUser.password;

  return { success: true, ok: true, user: publicUser };
};

export const loginPublicUser = (input, legacyPassword) => {
  const phoneOrEmail =
    typeof input === "object" ? input.phoneOrEmail || input.identifier : input;
  const password =
    typeof input === "object" ? input.password : legacyPassword;
  const rememberMe = typeof input === "object" ? input.rememberMe : false;
  const users = getPublicUsers();

  const user = users.find(
    (item) =>
      normalize(item.phone) === normalize(phoneOrEmail) ||
      normalize(item.email) === normalize(phoneOrEmail),
  );

  if (!user || user.password !== String(password || "")) {
    return {
      success: false,
      ok: false,
      message: "Invalid phone/email or password.",
    };
  }

  setActivePublicUser(user);
  fireAndForget("/api/public/login", { phoneOrEmail, password });

  if (rememberMe) {
    window.localStorage.setItem(PUBLIC_REMEMBER_USER_KEY, phoneOrEmail);
  } else {
    window.localStorage.removeItem(PUBLIC_REMEMBER_USER_KEY);
  }

  const publicUser = { ...user };
  delete publicUser.password;

  return { success: true, ok: true, user: publicUser };
};

export const startPasswordReset = (email) => {
  const users = getPublicUsers();
  const user = users.find((item) => normalize(item.email) === normalize(email));

  if (!user) {
    return { success: false, ok: false, message: "No account found with this email." };
  }

  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const request = {
    email: user.email,
    otp,
    expiresAt: Date.now() + 10 * 60 * 1000,
    verified: false,
  };

  window.localStorage.setItem(PUBLIC_PASSWORD_RESET_KEY, JSON.stringify(request));
  console.log("Demo OTP:", otp);
  window.alert(`Demo OTP: ${otp}`);
  return { success: true, ok: true, message: "OTP sent for demo.", otp };
};

export const verifyPasswordResetOtp = (otp) => {
  const request = safeParse(
    window.localStorage.getItem(PUBLIC_PASSWORD_RESET_KEY),
    null,
  );

  if (!request) {
    return { success: false, ok: false, message: "No reset request found." };
  }

  if (Date.now() > request.expiresAt) {
    return { success: false, ok: false, message: "OTP expired. Please resend." };
  }

  if (String(otp || "").trim() !== request.otp) {
    return { success: false, ok: false, message: "Invalid OTP." };
  }

  window.localStorage.setItem(
    PUBLIC_PASSWORD_RESET_KEY,
    JSON.stringify({ ...request, verified: true }),
  );

  return { success: true, ok: true };
};

export const resetPublicUserPassword = (newPassword) => {
  const request = safeParse(
    window.localStorage.getItem(PUBLIC_PASSWORD_RESET_KEY),
    null,
  );

  if (!request?.verified) {
    return { success: false, ok: false, message: "Verify OTP first." };
  }

  if (String(newPassword || "").length < 6) {
    return {
      success: false,
      ok: false,
      message: "Password must be at least 6 characters.",
    };
  }

  const users = getPublicUsers();
  const exists = users.some(
    (user) => normalize(user.email) === normalize(request.email),
  );

  if (!exists) {
    return { success: false, ok: false, message: "No account found." };
  }

  const nextUsers = users.map((user) =>
    normalize(user.email) === normalize(request.email)
      ? {
          ...user,
          password: newPassword,
          updatedAt: new Date().toISOString(),
        }
      : user,
  );

  savePublicUsers(nextUsers);
  window.localStorage.removeItem(PUBLIC_PASSWORD_RESET_KEY);
  return { success: true, ok: true, message: "Password reset successful." };
};

export const findPublicUserByEmail = (email) =>
  getPublicUsers().find((user) => normalize(user.email) === normalize(email));

export const savePublicUserMessage = (input) => {
  const activeUser = getActivePublicUser();
  if (!activeUser) return { ok: false, success: false, message: "Please login first." };

  const messages = safeReadList(PUBLIC_MESSAGES_KEY);
  const now = new Date().toISOString();
  const message = {
    id: Date.now(),
    userId: activeUser.id,
    userName: activeUser.name,
    phone: activeUser.phone,
    email: activeUser.email || "",
    subject: String(input.subject || "").trim(),
    category: input.category || "General",
    message: String(input.message || "").trim(),
    status: "Unread",
    createdAt: now,
    updatedAt: now,
  };

  safeWriteList(PUBLIC_MESSAGES_KEY, [message, ...messages]);
  fireAndForget("/api/messages", message);
  window.dispatchEvent(new Event("public-user-messages-updated"));
  return { ok: true, success: true, message };
};
