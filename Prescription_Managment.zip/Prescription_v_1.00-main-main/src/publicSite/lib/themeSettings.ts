import { apiFetch } from "../../lib/apiClient";

export const THEME_STORAGE_KEY = "carebridge_public_theme_settings";

export const defaultThemeSettings = {
  navbarVariant: "variant-1",
  heroVariant: "variant-1",
  aboutVariant: "variant-1",
  servicesVariant: "variant-1",
  doctorsVariant: "variant-1",
  appointmentVariant: "variant-1",
  blogsVariant: "variant-1",
  galleryVariant: "variant-1",
  qaVariant: "variant-1",
  contactVariant: "variant-1",
  footerVariant: "variant-1",
  primaryColor: "#00796b",
  secondaryColor: "#0891b2",
  accentColor: "#2563eb",
  backgroundColor: "#f8fafc",
  textColor: "#0f172a",
  buttonColor: "#0f766e",
  buttonTextColor: "#ffffff",
  borderRadius: "24px",
  sectionSpacing: "40px",
  fontStyle: "system",
};

export const themeVariantOptions = [
  { value: "variant-1", label: "Variant 1 - Default", description: "Current website design." },
  { value: "variant-2", label: "Variant 2 - Outline", description: "Simple outlined blocks." },
  { value: "variant-3", label: "Variant 3 - Boxed", description: "Compact boxed card style." },
  { value: "variant-4", label: "Variant 4 - Center Menu", description: "Minimal balanced layout." },
  { value: "variant-5", label: "Variant 5 - Classic Minimal", description: "Plain spreadsheet-like style." },
];

export const themeSections = [
  { key: "navbarVariant", label: "Navbar Design" },
  { key: "heroVariant", label: "Hero Design" },
  { key: "aboutVariant", label: "About Design" },
  { key: "servicesVariant", label: "Services Design" },
  { key: "doctorsVariant", label: "Doctors Design" },
  { key: "appointmentVariant", label: "Appointment Design" },
  { key: "blogsVariant", label: "Blogs Design" },
  { key: "galleryVariant", label: "Gallery Design" },
  { key: "qaVariant", label: "Q&A Design" },
  { key: "contactVariant", label: "Contact Design" },
  { key: "footerVariant", label: "Footer Design" },
];

const canUseStorage = () => typeof window !== "undefined" && window.localStorage;

export const getDefaultThemeSettings = () => ({ ...defaultThemeSettings });

export const normalizeThemeSettings = (settings = {}) => ({
  ...defaultThemeSettings,
  ...settings,
});

export const getThemeSettings = () => {
  if (!canUseStorage()) return getDefaultThemeSettings();

  try {
    const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
    return stored ? normalizeThemeSettings(JSON.parse(stored)) : getDefaultThemeSettings();
  } catch {
    return getDefaultThemeSettings();
  }
};

export const saveThemeSettingsLocal = (settings) => {
  const normalized = normalizeThemeSettings(settings);

  if (canUseStorage()) {
    window.localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(normalized));
    applyThemeVariables(normalized);
    window.dispatchEvent(new Event("carebridge-theme-updated"));
  }

  return normalized;
};

export const fetchThemeSettings = async () => {
  const response = await apiFetch("/api/cms/theme-settings");
  return saveThemeSettingsLocal(response.data || defaultThemeSettings);
};

export const updateThemeSettings = async (settings) => {
  const response = await apiFetch("/api/cms/theme-settings", {
    method: "PUT",
    body: JSON.stringify(normalizeThemeSettings(settings)),
  });

  return saveThemeSettingsLocal(response.data || settings);
};

export const resetThemeSettings = () => saveThemeSettingsLocal(getDefaultThemeSettings());

export const getThemeStyle = (settings = {}) => {
  const theme = normalizeThemeSettings(settings);

  return {
    "--site-primary": theme.primaryColor,
    "--site-secondary": theme.secondaryColor,
    "--site-accent": theme.accentColor,
    "--site-bg": theme.backgroundColor,
    "--site-text": theme.textColor,
    "--site-button": theme.buttonColor,
    "--site-button-text": theme.buttonTextColor,
    "--site-radius": theme.borderRadius,
    "--site-section-spacing": theme.sectionSpacing,
    backgroundColor: theme.backgroundColor,
    color: theme.textColor,
    fontFamily:
      theme.fontStyle === "serif"
        ? "Georgia, 'Times New Roman', serif"
        : theme.fontStyle === "mono"
          ? "'Courier New', monospace"
          : "inherit",
  };
};

export const applyThemeVariables = (settings = {}) => {
  if (typeof document === "undefined") return;

  const style = getThemeStyle(settings);
  const root = document.documentElement;

  Object.entries(style).forEach(([key, value]) => {
    if (key.startsWith("--")) root.style.setProperty(key, value);
  });
};
