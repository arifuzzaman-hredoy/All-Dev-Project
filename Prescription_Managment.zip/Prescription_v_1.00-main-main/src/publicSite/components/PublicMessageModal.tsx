import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarClock,
  CheckCircle2,
  Download,
  Edit3,
  Eye,
  File,
  FileImage,
  LockKeyhole,
  MoreVertical,
  Paperclip,
  Phone,
  Send,
  ShieldCheck,
  Trash2,
  UserRound,
  Video,
  X,
} from "lucide-react";
import {
  PUBLIC_MESSAGES_KEY,
  safeReadList,
  safeWriteList,
} from "../lib/publicUserStorage";

const emptyForm = {
  message: "",
};

const MAX_ATTACHMENT_SIZE = 2.5 * 1024 * 1024;

const getPatientId = (user) => {
  return (
    user?.patientId ||
    user?.patientID ||
    user?.serialNo ||
    user?.id ||
    "P-0000"
  );
};

const getInitialLetters = (name = "Patient") => {
  return String(name)
    .trim()
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0])
    .join("")
    .toUpperCase();
};

const cleanKey = (value) => {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

const getPhoneKey = (value) => {
  return String(value || "").replace(/\D/g, "");
};

const makeId = (prefix = "msg") => {
  if (typeof window !== "undefined" && window.crypto?.randomUUID) {
    return `${prefix}-${window.crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
};

const formatTime = (date = new Date()) => {
  return date.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatTimeFromValue = (value) => {
  if (!value) return formatTime(new Date());

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return formatTime(date);
};

const getSortTime = (message) => {
  const time = new Date(message?.createdAt || message?.updatedAt || 0).getTime();

  if (Number.isFinite(time) && time > 0) return time;

  const idStamp = String(message?.id || "").match(/(\d{10,})/);
  if (idStamp) return Number(idStamp[1]);

  return 0;
};

const getThreadId = (user, patientId) => {
  const phone = getPhoneKey(user?.phone);

  if (phone) return `public-${phone}`;

  return `public-${cleanKey(patientId || user?.name || user?.patientName)}`;
};

const getStorageKey = (patientId) => {
  return `public_patient_chat_${patientId}`;
};

const getHiddenKey = (patientId) => {
  return `public_patient_chat_hidden_${patientId}`;
};

const getLocalMessages = (patientId) => {
  try {
    const raw = localStorage.getItem(getStorageKey(patientId));
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const saveLocalMessages = (patientId, messages) => {
  localStorage.setItem(getStorageKey(patientId), JSON.stringify(messages));
};

const getHiddenIds = (patientId) => {
  try {
    const raw = localStorage.getItem(getHiddenKey(patientId));
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const saveHiddenIds = (patientId, ids) => {
  localStorage.setItem(getHiddenKey(patientId), JSON.stringify(ids));
};

const getMessageSender = (message) => {
  const sender = String(message?.sender || message?.from || "patient").toLowerCase();
  return sender === "doctor" ? "doctor" : "patient";
};

const getMessageText = (message) => {
  return message?.message || message?.text || message?.body || "";
};

const normalizeAttachment = (attachment) => {
  if (!attachment) return null;

  const type = attachment.type || "application/octet-stream";

  return {
    ...attachment,
    type,
    isImage: Boolean(
      attachment.isImage ||
        type.startsWith("image/") ||
        String(attachment.name || "").match(/\.(png|jpg|jpeg|webp|gif)$/i)
    ),
  };
};

const readPublicMessages = () => {
  return safeReadList(PUBLIC_MESSAGES_KEY);
};

const writePublicMessages = (nextMessages) => {
  safeWriteList(PUBLIC_MESSAGES_KEY, nextMessages);
  window.dispatchEvent(new Event("public-user-messages-updated"));
  window.dispatchEvent(new Event("public-doctor-reply-updated"));
};

const buildPublicMessage = ({ user, patientId, threadId, text, attachment }) => {
  const now = new Date().toISOString();
  const name = user?.name || user?.patientName || "Patient";

  return {
    id: makeId("public-message"),
    threadId,
    sender: "patient",
    from: "patient",
    userName: name,
    patientName: name,
    patientId,
    phone: user?.phone || "",
    category: "General",
    subject: "Patient message",
    message: text,
    status: "Unread",
    deliveryStatus: "sent",
    createdAt: now,
    updatedAt: now,
    attachment: attachment || null,
    deleted: false,
    edited: false,
  };
};

const normalizePublicMessages = (user, patientId, threadId) => {
  const allMessages = readPublicMessages();
  const hiddenIds = getHiddenIds(patientId);
  const phoneKey = getPhoneKey(user?.phone);

  const matchedMessages = allMessages.filter((message) => {
    const messageThreadId =
      message.threadId ||
      (message.phone ? `public-${getPhoneKey(message.phone)}` : "");

    const sameThread = messageThreadId && messageThreadId === threadId;
    const samePhone = phoneKey && getPhoneKey(message.phone) === phoneKey;
    const samePatientId =
      patientId && String(message.patientId || "") === String(patientId);

    return sameThread || samePhone || samePatientId;
  });

  if (!matchedMessages.length) {
    return [];
  }

  return matchedMessages
    .filter((message) => !hiddenIds.includes(message.id))
    .map((message) => {
      const sender = getMessageSender(message);

      return {
        id: `public-${message.id}`,
        rawId: message.id,
        source: "public",
        text: getMessageText(message),
        sender,
        time: formatTimeFromValue(message.createdAt || message.updatedAt),
        sortTime: getSortTime(message),
        attachment: normalizeAttachment(message.attachment),
        deleted: Boolean(message.deleted),
        edited: Boolean(message.edited),
        localOnly: false,
        status: message.deliveryStatus || message.replyStatus || message.status,
      };
    })
    .sort((a, b) => a.sortTime - b.sortTime);
};

const normalizeLegacyMessages = (user, patientId) => {
  const source = user?.messages || user?.conversation || user?.chat || [];

  const serverMessages = Array.isArray(source)
    ? source.map((item, index) => ({
        id: item.id || `server-${patientId}-${index}`,
        rawId: item.id || `server-${patientId}-${index}`,
        source: "legacy",
        text: item.text || item.message || "",
        sender: item.sender || item.from || "doctor",
        time: item.time || formatTimeFromValue(item.createdAt),
        sortTime: getSortTime(item) || index,
        attachment: normalizeAttachment(item.attachment),
        deleted: Boolean(item.deleted),
        edited: Boolean(item.edited),
        localOnly: false,
      }))
    : [];

  const localMessages = getLocalMessages(patientId).map((item, index) => ({
    ...item,
    source: item.source || "legacy-local",
    sortTime: item.sortTime || getSortTime(item) || index + 10000,
    attachment: normalizeAttachment(item.attachment),
  }));

  const map = new Map();

  serverMessages.forEach((message) => {
    map.set(message.id, message);
  });

  localMessages.forEach((message) => {
    map.set(message.id, message);
  });

  return Array.from(map.values())
    .filter((item) => !item.hiddenForMe)
    .sort((a, b) => (a.sortTime || 0) - (b.sortTime || 0));
};

const normalizeMessages = (user, patientId, threadId) => {
  const publicMessages = normalizePublicMessages(user, patientId, threadId);

  if (publicMessages.length) {
    return publicMessages;
  }

  return normalizeLegacyMessages(user, patientId);
};

const isPatientSender = (message) => {
  return getMessageSender(message) === "patient";
};

const downloadAttachment = (attachment) => {
  if (!attachment?.dataUrl) return;

  const link = document.createElement("a");
  link.href = attachment.dataUrl;
  link.download = attachment.name || "attachment";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const formatFileSize = (size = 0) => {
  if (!size) return "";
  if (size < 1024 * 1024) return `${Math.ceil(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
};

const PublicMessageModal = ({ open, user, onClose }) => {
  const [form, setForm] = useState(emptyForm);
  const [status, setStatus] = useState("");
  const [messages, setMessages] = useState([]);
  const [attachment, setAttachment] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [activeMenuId, setActiveMenuId] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);

  const localIdRef = useRef(0);
  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  const patientId = useMemo(() => getPatientId(user), [user]);
  const threadId = useMemo(() => getThreadId(user, patientId), [user, patientId]);

  const canCall = Boolean(user?.allowCall ?? user?.canCall ?? user?.phone);
  const canVideo = Boolean(user?.allowVideo ?? user?.canVideo ?? false);
  const canAccess = Boolean(
    user?.allowAccess ?? user?.canAccess ?? user?.accessGranted ?? true
  );

  const loadMessages = useCallback(() => {
    if (!user || !patientId || !threadId) return;

    setMessages(normalizeMessages(user, patientId, threadId));
  }, [patientId, threadId, user]);

  const persistLegacyMessages = (nextMessages) => {
    setMessages(nextMessages);
    saveLocalMessages(patientId, nextMessages);
  };

  useEffect(() => {
    if (!open || !user) return;

    const timeoutId = window.setTimeout(() => {
      setForm(emptyForm);
      setStatus("");
      setAttachment(null);
      setEditingId(null);
      setActiveMenuId(null);
      setPreviewImage(null);
      loadMessages();
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [loadMessages, open, user, patientId, threadId]);

  useEffect(() => {
    if (!open || !user) return;

    const syncMessages = () => {
      loadMessages();
    };

    window.addEventListener("storage", syncMessages);
    window.addEventListener("public-user-messages-updated", syncMessages);
    window.addEventListener("public-doctor-reply-updated", syncMessages);

    const intervalId = window.setInterval(syncMessages, 900);

    return () => {
      window.removeEventListener("storage", syncMessages);
      window.removeEventListener("public-user-messages-updated", syncMessages);
      window.removeEventListener("public-doctor-reply-updated", syncMessages);
      window.clearInterval(intervalId);
    };
  }, [loadMessages, open, user, patientId, threadId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  if (!open || !user) return null;

  const handleAttachment = (file) => {
    if (!file) return;

    setStatus("");

    if (file.size > MAX_ATTACHMENT_SIZE) {
      setStatus("Attachment too large. Use file under 2.5MB.");
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      setAttachment({
        id: `attach-${(localIdRef.current += 1)}`,
        name: file.name,
        type: file.type || "application/octet-stream",
        size: file.size,
        dataUrl: reader.result,
        isImage: file.type.startsWith("image/"),
      });

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    };

    reader.readAsDataURL(file);
  };

  const resetComposer = () => {
    setForm(emptyForm);
    setAttachment(null);
    setEditingId(null);
    setActiveMenuId(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const updatePublicMessage = (rawId, updater) => {
    const allMessages = readPublicMessages();

    const nextMessages = allMessages.map((message) =>
      message.id === rawId ? updater(message) : message
    );

    writePublicMessages(nextMessages);
    loadMessages();
  };

  const submit = (event) => {
    event.preventDefault();

    const text = form.message.trim();
    setStatus("");

    if (!text && !attachment) {
      setStatus("Message or attachment is required.");
      return;
    }

    if (editingId) {
      const target = messages.find((item) => item.id === editingId);

      if (target?.source === "public" && target.rawId) {
        updatePublicMessage(target.rawId, (message) => ({
          ...message,
          message: text,
          text,
          attachment: attachment || message.attachment || null,
          edited: true,
          updatedAt: new Date().toISOString(),
        }));
      } else {
        const nextMessages = messages.map((item) =>
          item.id === editingId
            ? {
                ...item,
                text,
                attachment: attachment || item.attachment || null,
                edited: true,
                time: formatTime(new Date()),
                sortTime: Date.now(),
              }
            : item
        );

        persistLegacyMessages(nextMessages);
      }

      resetComposer();
      setStatus("Message updated.");
      window.setTimeout(() => setStatus(""), 1200);
      return;
    }

    const newPublicMessage = buildPublicMessage({
      user,
      patientId,
      threadId,
      text,
      attachment,
    });

    writePublicMessages([...readPublicMessages(), newPublicMessage]);
    resetComposer();
    loadMessages();

    setStatus("Message sent.");
    window.setTimeout(() => setStatus(""), 1200);
  };

  const startEditMessage = (message) => {
    if (!isPatientSender(message) || message.deleted) return;

    setEditingId(message.id);
    setForm({ message: message.text || "" });
    setAttachment(message.attachment || null);
    setActiveMenuId(null);
  };

  const deleteForMe = (messageId) => {
    const target = messages.find((item) => item.id === messageId);

    if (target?.source === "public" && target.rawId) {
      const hiddenIds = getHiddenIds(patientId);

      if (!hiddenIds.includes(target.rawId)) {
        saveHiddenIds(patientId, [...hiddenIds, target.rawId]);
      }

      loadMessages();
    } else {
      const nextMessages = messages.map((item) =>
        item.id === messageId ? { ...item, hiddenForMe: true } : item
      );

      persistLegacyMessages(nextMessages.filter((item) => !item.hiddenForMe));
    }

    setActiveMenuId(null);

    if (editingId === messageId) {
      resetComposer();
    }
  };

  const deleteForEveryone = (messageId) => {
    const target = messages.find((item) => item.id === messageId);

    if (!target || !isPatientSender(target)) return;

    if (target?.source === "public" && target.rawId) {
      updatePublicMessage(target.rawId, (message) => ({
        ...message,
        message: "This message was deleted.",
        text: "This message was deleted.",
        attachment: null,
        deleted: true,
        edited: false,
        updatedAt: new Date().toISOString(),
      }));
    } else {
      const nextMessages = messages.map((item) =>
        item.id === messageId
          ? {
              ...item,
              text: "This message was deleted.",
              attachment: null,
              deleted: true,
              edited: false,
            }
          : item
      );

      persistLegacyMessages(nextMessages);
    }

    setActiveMenuId(null);

    if (editingId === messageId) {
      resetComposer();
    }
  };

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-sm">
      <div className="flex h-[min(760px,calc(100vh-36px))] w-full max-w-4xl flex-col overflow-hidden rounded-[28px] border border-cyan-100 bg-white shadow-2xl">
        <div className="flex items-center justify-between gap-4 border-b border-slate-100 bg-white px-5 py-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-2xl bg-gradient-to-br from-cyan-50 to-teal-100 text-sm font-black text-teal-800 ring-1 ring-cyan-100">
              {user.avatarUrl || user.profileImageUrl ? (
                <img
                  src={user.avatarUrl || user.profileImageUrl}
                  alt={user.name || "Patient"}
                  className="h-full w-full object-cover"
                />
              ) : (
                getInitialLetters(user.name || user.patientName || "Patient")
              )}
            </div>

            <div className="min-w-0">
              <h2 className="truncate text-lg font-black leading-5 text-slate-950">
                {user.name || user.patientName || "Patient"}
              </h2>

              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-black text-slate-500">
                <span>{user.phone || "No phone"}</span>
                <span className="text-slate-300">•</span>
                <span>Patient ID: {patientId}</span>
              </div>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            {canCall ? (
              <button
                type="button"
                className="grid h-10 w-10 place-items-center rounded-2xl bg-slate-100 text-slate-600 transition hover:-translate-y-0.5 hover:bg-cyan-50 hover:text-teal-700"
                title="Call access enabled"
              >
                <Phone size={18} />
              </button>
            ) : null}

            {canVideo ? (
              <button
                type="button"
                className="grid h-10 w-10 place-items-center rounded-2xl bg-slate-100 text-slate-600 transition hover:-translate-y-0.5 hover:bg-cyan-50 hover:text-teal-700"
                title="Video access enabled"
              >
                <Video size={18} />
              </button>
            ) : null}

            {canAccess ? (
              <div className="hidden h-10 items-center gap-1.5 rounded-2xl bg-emerald-50 px-3 text-xs font-black text-emerald-700 sm:inline-flex">
                <ShieldCheck size={15} />
                Access
              </div>
            ) : (
              <div className="hidden h-10 items-center gap-1.5 rounded-2xl bg-red-50 px-3 text-xs font-black text-red-700 sm:inline-flex">
                <LockKeyhole size={15} />
                Blocked
              </div>
            )}

            <button
              type="button"
              onClick={onClose}
              className="group ml-1 text-slate-400 transition hover:-translate-y-0.5 hover:text-red-600"
              aria-label="Close message popup"
            >
              <X
                size={24}
                strokeWidth={2.4}
                className="transition-transform duration-300 group-hover:rotate-90"
              />
            </button>
          </div>
        </div>

        <div className="flex min-h-0 flex-1 flex-col bg-slate-50/70">
          {status ? (
            <div className="mx-5 mt-4 flex items-center gap-2 rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3 text-xs font-black text-teal-700">
              <CheckCircle2 size={15} />
              {status}
            </div>
          ) : null}

          <div
            className="min-h-0 flex-1 overflow-y-auto px-5 py-4"
            onClick={() => setActiveMenuId(null)}
          >
            {messages.length ? (
              <div className="grid gap-3">
                {messages.map((item) => {
                  const isPatient = isPatientSender(item);

                  return (
                    <div
                      key={item.id}
                      className={[
                        "group flex items-start gap-2",
                        isPatient ? "justify-end" : "justify-start",
                      ].join(" ")}
                    >
                      {!isPatient ? (
                        <div className="relative order-1">
                          <button
                            type="button"
                            onClick={(event) => {
                              event.stopPropagation();
                              setActiveMenuId((prev) =>
                                prev === item.id ? null : item.id
                              );
                            }}
                            className="mt-1 grid h-8 w-8 place-items-center rounded-full text-slate-400 opacity-0 transition hover:bg-white hover:text-slate-700 group-hover:opacity-100"
                            title="Message options"
                          >
                            <MoreVertical size={17} />
                          </button>

                          {activeMenuId === item.id ? (
                            <MessageMenu
                              item={item}
                              isPatient={isPatient}
                              onEdit={() => startEditMessage(item)}
                              onDeleteMe={() => deleteForMe(item.id)}
                              onDeleteAll={() => deleteForEveryone(item.id)}
                              onViewImage={() => {
                                setPreviewImage(item.attachment);
                                setActiveMenuId(null);
                              }}
                              onDownload={() => {
                                downloadAttachment(item.attachment);
                                setActiveMenuId(null);
                              }}
                            />
                          ) : null}
                        </div>
                      ) : null}

                      <div
                        className={[
                          "order-2 max-w-[78%]",
                          isPatient ? "text-right" : "text-left",
                        ].join(" ")}
                      >
                        <div
                          className={[
                            "inline-block w-fit max-w-full rounded-2xl px-3 py-2 shadow-sm",
                            isPatient
                              ? "rounded-br-md bg-teal-700 text-white"
                              : "rounded-bl-md border border-slate-200 bg-white text-slate-800",
                            item.deleted ? "opacity-75" : "",
                          ].join(" ")}
                        >
                          {item.attachment ? (
                            <div className={item.text ? "mb-2" : ""}>
                              {item.attachment.isImage &&
                              item.attachment.dataUrl ? (
                                <button
                                  type="button"
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    setPreviewImage(item.attachment);
                                  }}
                                  className="block overflow-hidden rounded-xl"
                                  title="View image"
                                >
                                  <img
                                    src={item.attachment.dataUrl}
                                    alt={item.attachment.name || "Attachment"}
                                    className="max-h-60 max-w-[260px] rounded-xl object-cover"
                                  />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    downloadAttachment(item.attachment);
                                  }}
                                  className={[
                                    "flex max-w-[260px] items-center gap-2 rounded-xl px-3 py-2 text-xs font-black",
                                    isPatient
                                      ? "bg-white/15 text-white"
                                      : "bg-slate-100 text-slate-600",
                                  ].join(" ")}
                                  title="Download attachment"
                                >
                                  <File size={15} />
                                  <span className="truncate">
                                    {item.attachment.name || "Attachment"}
                                  </span>
                                </button>
                              )}
                            </div>
                          ) : null}

                          {item.text ? (
                            <p
                              className={[
                                "whitespace-pre-wrap break-words text-sm font-bold leading-6",
                                item.deleted ? "italic" : "",
                              ].join(" ")}
                            >
                              {item.text}
                            </p>
                          ) : null}

                          <p
                            className={[
                              "mt-1 text-[11px] font-black",
                              isPatient ? "text-white/65" : "text-slate-400",
                            ].join(" ")}
                          >
                            {item.time}
                            {item.edited ? " · edited" : ""}
                            {!isPatient && item.status === "seen" ? " · seen" : ""}
                          </p>
                        </div>
                      </div>

                      {isPatient ? (
                        <div className="relative order-3">
                          <button
                            type="button"
                            onClick={(event) => {
                              event.stopPropagation();
                              setActiveMenuId((prev) =>
                                prev === item.id ? null : item.id
                              );
                            }}
                            className="mt-1 grid h-8 w-8 place-items-center rounded-full text-slate-400 opacity-0 transition hover:bg-white hover:text-slate-700 group-hover:opacity-100"
                            title="Message options"
                          >
                            <MoreVertical size={17} />
                          </button>

                          {activeMenuId === item.id ? (
                            <MessageMenu
                              alignRight
                              item={item}
                              isPatient={isPatient}
                              onEdit={() => startEditMessage(item)}
                              onDeleteMe={() => deleteForMe(item.id)}
                              onDeleteAll={() => deleteForEveryone(item.id)}
                              onViewImage={() => {
                                setPreviewImage(item.attachment);
                                setActiveMenuId(null);
                              }}
                              onDownload={() => {
                                downloadAttachment(item.attachment);
                                setActiveMenuId(null);
                              }}
                            />
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  );
                })}

                <div ref={bottomRef} />
              </div>
            ) : (
              <div className="grid h-full place-items-center text-center">
                <div>
                  <div className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-white text-teal-700 shadow-sm ring-1 ring-slate-100">
                    <UserRound size={24} />
                  </div>

                  <h3 className="mt-4 text-lg font-black text-slate-950">
                    Start conversation
                  </h3>

                  <p className="mt-1 max-w-sm text-sm font-semibold leading-6 text-slate-500">
                    Public user message right side, doctor reply left side.
                  </p>
                </div>
              </div>
            )}
          </div>

          <form
            onSubmit={submit}
            className="border-t border-slate-100 bg-white px-5 py-4"
          >
            {editingId || attachment ? (
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3">
                <div className="min-w-0 flex items-center gap-3">
                  {attachment?.isImage && attachment?.dataUrl ? (
                    <img
                      src={attachment.dataUrl}
                      alt={attachment.name}
                      className="h-14 w-14 rounded-xl object-cover"
                    />
                  ) : attachment ? (
                    <div className="grid h-14 w-14 place-items-center rounded-xl bg-white text-teal-700">
                      <File size={22} />
                    </div>
                  ) : null}

                  <div className="min-w-0">
                    <p className="text-xs font-black text-teal-700">
                      {editingId ? "Editing message" : "Attachment selected"}
                    </p>

                    {attachment ? (
                      <p className="truncate text-xs font-bold text-slate-500">
                        {attachment.name} {formatFileSize(attachment.size)}
                      </p>
                    ) : null}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={resetComposer}
                  className="group text-slate-400 transition hover:text-red-600"
                >
                  <X
                    size={18}
                    className="transition-transform duration-300 group-hover:rotate-90"
                  />
                </button>
              </div>
            ) : null}

            <div className="flex items-end gap-2">
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={(event) =>
                  handleAttachment(event.target.files?.[0] || null)
                }
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-slate-100 text-slate-500 transition hover:bg-cyan-50 hover:text-teal-700"
                title="Attach file"
              >
                <Paperclip size={19} />
              </button>

              <div className="min-w-0 flex-1">
                <textarea
                  value={form.message}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      message: event.target.value,
                    }))
                  }
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      submit(event);
                    }
                  }}
                  placeholder="Write message..."
                  rows={1}
                  className="max-h-32 min-h-11 w-full resize-none rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold leading-5 text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100"
                />
              </div>

              <button
                type="submit"
                disabled={!form.message.trim() && !attachment}
                className="grid h-11 w-12 shrink-0 place-items-center rounded-2xl bg-teal-700 text-white transition hover:-translate-y-0.5 hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-300"
                title={editingId ? "Update message" : "Send message"}
              >
                <Send size={18} />
              </button>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] font-bold text-slate-400">
              <span className="inline-flex items-center gap-1">
                <CalendarClock size={13} />
                Live inbox
              </span>

              <span className="inline-flex items-center gap-1">
                <FileImage size={13} />
                Image preview + save ready
              </span>
            </div>
          </form>
        </div>
      </div>

      {previewImage ? (
        <div
          className="fixed inset-0 z-[120] grid place-items-center bg-slate-950/80 p-4"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="relative max-h-[92vh] max-w-5xl"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setPreviewImage(null)}
              className="group absolute -right-3 -top-3 z-10 grid h-10 w-10 place-items-center rounded-full bg-white text-slate-500 shadow-xl transition hover:text-red-600"
              title="Close image"
            >
              <X
                size={22}
                className="transition-transform duration-300 group-hover:rotate-90"
              />
            </button>

            <img
              src={previewImage.dataUrl}
              alt={previewImage.name || "Preview"}
              className="max-h-[90vh] max-w-full rounded-3xl object-contain shadow-2xl"
            />

            <button
              type="button"
              onClick={() => downloadAttachment(previewImage)}
              className="absolute bottom-4 right-4 inline-flex h-10 items-center gap-2 rounded-2xl bg-white px-4 text-xs font-black text-slate-800 shadow-xl transition hover:-translate-y-0.5"
            >
              <Download size={15} />
              Save Image
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
};

const MessageMenu = ({
  item,
  isPatient,
  alignRight = false,
  onEdit,
  onDeleteMe,
  onDeleteAll,
  onViewImage,
  onDownload,
}) => {
  const hasAttachment = Boolean(item.attachment);
  const hasImage = Boolean(item.attachment?.isImage && item.attachment?.dataUrl);

  return (
    <div
      className={[
        "absolute top-9 z-40 w-44 overflow-hidden rounded-2xl border border-slate-200 bg-white p-1 shadow-xl",
        alignRight ? "right-0" : "left-0",
      ].join(" ")}
      onClick={(event) => event.stopPropagation()}
    >
      {isPatient && !item.deleted ? (
        <button
          type="button"
          onClick={onEdit}
          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-black text-slate-700 transition hover:bg-slate-50"
        >
          <Edit3 size={14} />
          Edit message
        </button>
      ) : null}

      {hasImage ? (
        <button
          type="button"
          onClick={onViewImage}
          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-black text-slate-700 transition hover:bg-slate-50"
        >
          <Eye size={14} />
          View image
        </button>
      ) : null}

      {hasAttachment && item.attachment?.dataUrl ? (
        <button
          type="button"
          onClick={onDownload}
          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-black text-slate-700 transition hover:bg-slate-50"
        >
          <Download size={14} />
          {hasImage ? "Save image" : "Download file"}
        </button>
      ) : null}

      <button
        type="button"
        onClick={onDeleteMe}
        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-black text-slate-700 transition hover:bg-slate-50"
      >
        <Trash2 size={14} />
        Delete for me
      </button>

      {isPatient && !item.deleted ? (
        <button
          type="button"
          onClick={onDeleteAll}
          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-black text-red-700 transition hover:bg-red-50"
        >
          <Trash2 size={14} />
          Delete everyone
        </button>
      ) : null}
    </div>
  );
};

export default PublicMessageModal;
