import { useState } from "react";
import { addPublicMessage } from "../lib/publicStorage";

const initialForm = { name: "", phone: "", email: "", message: "" };

const ContactMessageForm = () => {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState("");

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));
  const labelClass = "grid gap-1.5 text-sm font-extrabold text-slate-600";
  const fieldClass =
    "w-full rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100";

  const submit = (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.message.trim()) {
      setStatus("Please add name, phone and message.");
      return;
    }
    addPublicMessage(form);
    setForm(initialForm);
    setStatus("Message sent. Doctor panel can read it from storage.");
  };

  return (
    <form
      className="grid gap-4 rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur"
      onSubmit={submit}
    >
      <h3 className="text-xl font-black tracking-tight text-slate-900">
        Send Message
      </h3>
      <label className={labelClass}>Name<input className={fieldClass} value={form.name} onChange={(e) => update("name", e.target.value)} /></label>
      <label className={labelClass}>Phone<input className={fieldClass} value={form.phone} onChange={(e) => update("phone", e.target.value)} /></label>
      <label className={labelClass}>Email<input className={fieldClass} value={form.email} onChange={(e) => update("email", e.target.value)} /></label>
      <label className={labelClass}>Message<textarea className={`${fieldClass} min-h-28 resize-y`} value={form.message} onChange={(e) => update("message", e.target.value)} /></label>
      {status ? <p className="text-sm font-extrabold text-teal-700">{status}</p> : null}
      <button
        type="submit"
        className="inline-flex min-h-11 items-center justify-center rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-cyan-300"
      >
        Send
      </button>
    </form>
  );
};

export default ContactMessageForm;
