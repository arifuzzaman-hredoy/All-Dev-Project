import { Link } from "react-router-dom";
import ProductCredit from "../../components/common/ProductCredit";

const PublicFooter = ({ profile }) => (
  <footer className="mx-auto mb-4 mt-8 w-[min(1180px,calc(100%-1rem))] rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur sm:w-[min(1180px,calc(100%-1.75rem))]">
    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
      <div className="max-w-xl">
        <strong className="text-lg font-black text-teal-800">{profile.brandName}</strong>
        <p className="mt-1 text-sm font-semibold leading-6 text-slate-600">
          {profile.shortBio}
        </p>
      </div>
      <div className="grid gap-1 text-sm font-bold text-slate-600">
        <span>{profile.chamberName}</span>
        <span>{profile.phone}</span>
        <span>{profile.email}</span>
      </div>
      <Link
        className="inline-flex w-fit rounded-full border border-teal-100 bg-white px-4 py-2 text-sm font-black text-teal-700 transition hover:bg-cyan-50 focus:outline-none focus:ring-2 focus:ring-cyan-300"
        to="/doctor/dashboard"
      >
        Doctor Panel
      </Link>
    </div>
    <div className="mt-4 border-t border-teal-100 pt-4 text-center">
      <ProductCredit />
    </div>
  </footer>
);

export default PublicFooter;
