import { useState } from "react";
import {
  Eye,
  EyeOff,
  HeartPulse,
  LockKeyhole,
  LogIn,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  UserPlus,
  UserRound,
  X,
} from "lucide-react";
import { Link } from "react-router-dom";
import {
  loginPublicUser,
  PUBLIC_POPUP_DISMISSED_KEY,
  registerPublicUser,
} from "../lib/publicUserStorage";

const emptyRegisterForm = {
  name: "",
  phone: "",
  age: "",
  gender: "Female",
  email: "",
  address: "",
  password: "",
};

const initialLoginForm = {
  phoneOrEmail: "",
  password: "",
  rememberMe: false,
};

const modalCss = `
  @keyframes patientModalIn {
    from { opacity: 0; transform: translateY(18px) scale(0.975); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes softFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: 0.55; transform: scale(1); }
    50% { opacity: 0.9; transform: scale(1.06); }
  }

  @keyframes slideFadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .patient-modal-shell {
    animation: patientModalIn 360ms cubic-bezier(.2,.8,.2,1) both;
  }

  .patient-float-icon {
    animation: softFloat 4s ease-in-out infinite;
  }

  .patient-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .patient-fade-up {
    animation: slideFadeIn 360ms ease both;
  }
`;

const FieldIcon = ({ icon: Icon }) => (
  <Icon
    size={16}
    strokeWidth={2.25}
    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 group-focus-within:-translate-y-[55%] group-focus-within:text-teal-700"
  />
);

const PasswordToggle = ({ visible, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition duration-300 hover:-translate-y-[55%] hover:text-teal-700"
    aria-label={visible ? "Hide password" : "Show password"}
  >
    {visible ? <EyeOff size={17} /> : <Eye size={17} />}
  </button>
);

const ModeTabs = ({ mode, onChange }) => {
  return (
    <div className="relative mb-5 rounded-[20px] border border-slate-200 bg-slate-100/80 p-1">
      <span
        className={[
          "absolute left-1 top-1 h-10 w-[calc(50%-4px)] rounded-2xl bg-white shadow-sm shadow-slate-900/10 transition-transform duration-500 ease-[cubic-bezier(.2,.9,.2,1)]",
          mode === "login" ? "translate-x-full" : "translate-x-0",
        ].join(" ")}
      />

      <div className="relative z-10 grid grid-cols-2 gap-1">
        <button
          type="button"
          onClick={() => onChange("register")}
          className={[
            "inline-flex h-10 items-center justify-center gap-2 rounded-2xl text-sm font-black transition duration-300",
            mode === "register"
              ? "text-teal-700"
              : "text-slate-500 hover:text-slate-900",
          ].join(" ")}
        >
          <UserPlus
            size={16}
            className="transition-transform duration-300 group-hover:-translate-y-0.5"
          />
          Register
        </button>

        <button
          type="button"
          onClick={() => onChange("login")}
          className={[
            "inline-flex h-10 items-center justify-center gap-2 rounded-2xl text-sm font-black transition duration-300",
            mode === "login"
              ? "text-teal-700"
              : "text-slate-500 hover:text-slate-900",
          ].join(" ")}
        >
          <LogIn
            size={16}
            className="transition-transform duration-300 group-hover:-translate-y-0.5"
          />
          Login
        </button>
      </div>
    </div>
  );
};

const PublicUserModal = ({ open, onClose, onSuccess }) => {
  const [mode, setMode] = useState("register");
  const [registerForm, setRegisterForm] = useState(emptyRegisterForm);
  const [loginForm, setLoginForm] = useState(initialLoginForm);
  const [error, setError] = useState("");
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  if (!open) return null;

  const close = () => {
    window.localStorage.setItem(PUBLIC_POPUP_DISMISSED_KEY, "true");
    setError("");
    onClose();
  };

  const switchMode = (nextMode) => {
    if (nextMode === mode) return;
    setMode(nextMode);
    setError("");
  };

  const submitRegister = (event) => {
    event.preventDefault();
    setError("");

    if (
      !registerForm.name.trim() ||
      !registerForm.phone.trim() ||
      !registerForm.email.trim() ||
      !registerForm.password
    ) {
      setError("Full name, phone, email and password are required.");
      return;
    }

    const result = registerPublicUser(registerForm);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setRegisterForm(emptyRegisterForm);
    onSuccess?.(result.user);
    onClose();
  };

  const submitLogin = (event) => {
    event.preventDefault();
    setError("");

    if (!loginForm.phoneOrEmail.trim() || !loginForm.password) {
      setError("Phone/email and password are required.");
      return;
    }

    const result = loginPublicUser({
      phoneOrEmail: loginForm.phoneOrEmail,
      password: loginForm.password,
      rememberMe: loginForm.rememberMe,
    });

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setLoginForm(initialLoginForm);
    onSuccess?.(result.user);
    onClose();
  };

  const inputClass =
    "h-11 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 focus:border-teal-500 focus:ring-4 focus:ring-teal-50";
  const iconInputClass = `${inputClass} pl-10`;
  const passwordInputClass = `${inputClass} pl-10 pr-10`;

  return (
    <>
      <style>{modalCss}</style>

      <div className="fixed inset-0 z-[100] grid place-items-center bg-slate-950/45 p-4 backdrop-blur-sm">
        <div className="patient-modal-shell relative grid max-h-[calc(100vh-32px)] w-full max-w-4xl overflow-hidden rounded-[34px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/20 md:grid-cols-[0.92fr_1.08fr]">
          <button
            type="button"
            onClick={close}
            className="group absolute right-4 top-4 z-20 text-slate-400 transition duration-300 hover:-translate-y-0.5 hover:text-red-600"
            aria-label="Close user popup"
          >
            <X
              size={24}
              strokeWidth={2.4}
              className="transition-transform duration-300 group-hover:rotate-90"
            />
          </button>

          <aside className="relative hidden overflow-hidden bg-gradient-to-br from-teal-900 via-teal-700 to-cyan-700 p-7 text-white md:grid">
            <span className="patient-glow absolute -left-20 top-12 h-44 w-44 rounded-full bg-white/15 blur-3xl" />
            <span className="patient-glow absolute -bottom-16 right-4 h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl" />

            <div className="relative z-10 flex h-full flex-col justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <Stethoscope
                    size={38}
                    strokeWidth={2.05}
                    className="patient-float-icon text-white"
                  />
                  <Sparkles
                    size={18}
                    className="text-cyan-100 transition-transform duration-500 hover:rotate-12"
                  />
                </div>

                <h2 className="mt-6 text-3xl font-black leading-tight">
                  Patient Profile
                </h2>

                <p className="mt-3 max-w-xs text-sm font-semibold leading-7 text-white/75">
                  Profile create korle appointment, message, report follow-up
                  faster manage kora jabe.
                </p>
              </div>

              <div className="grid gap-4">
                <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                  <div className="flex items-center gap-2">
                    <ShieldCheck
                      size={18}
                      className="transition-transform duration-300 hover:-translate-y-0.5"
                    />
                    <p className="text-sm font-black">Secure patient access</p>
                  </div>
                  <p className="mt-2 text-xs font-semibold leading-6 text-white/70">
                    Login korle saved information reuse hobe. Public appointment
                    and message form aro easy hobe.
                  </p>
                </div>

                <div className="rounded-3xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur">
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-white/60">
                    Current Mode
                  </p>
                  <p className="mt-1 text-xl font-black transition-all duration-300">
                    {mode === "register" ? "Create Profile" : "Patient Login"}
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs font-black text-white/65">
                  <HeartPulse size={16} />
                  Faster healthcare communication
                </div>
              </div>
            </div>
          </aside>

          <main className="max-h-[calc(100vh-32px)] overflow-y-auto p-5 sm:p-7">
            <div className="patient-fade-up mb-5 pr-9">
              <p className="text-[11px] font-black uppercase tracking-[0.22em] text-teal-700">
                Patient Portal
              </p>

              <h2 className="mt-1 text-2xl font-black tracking-tight text-slate-950 transition-all duration-300">
                {mode === "register"
                  ? "Create your patient profile"
                  : "Welcome back"}
              </h2>

              <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                {mode === "register"
                  ? "Save your details once, then use appointment and message faster."
                  : "Login with phone/email and continue your patient profile."}
              </p>
            </div>

            <ModeTabs mode={mode} onChange={switchMode} />

            <div className="min-h-[44px]">
              {error ? (
                <p className="mb-4 rounded-2xl border border-rose-100 bg-rose-50 px-4 py-3 text-xs font-black text-rose-700">
                  {error}
                </p>
              ) : null}
            </div>

            <div className="relative min-h-[430px] overflow-hidden">
              <div
                className={[
                  "absolute inset-0 transition-all duration-500 ease-[cubic-bezier(.2,.9,.2,1)]",
                  mode === "register"
                    ? "translate-x-0 scale-100 opacity-100"
                    : "-translate-x-8 scale-[0.98] opacity-0 pointer-events-none",
                ].join(" ")}
              >
                <form className="grid gap-3" onSubmit={submitRegister}>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <label className="group relative">
                      <FieldIcon icon={UserRound} />
                      <input
                        className={iconInputClass}
                        placeholder="Full name *"
                        value={registerForm.name}
                        onChange={(event) =>
                          setRegisterForm((prev) => ({
                            ...prev,
                            name: event.target.value,
                          }))
                        }
                      />
                    </label>

                    <label className="group relative">
                      <FieldIcon icon={Phone} />
                      <input
                        className={iconInputClass}
                        placeholder="Phone *"
                        value={registerForm.phone}
                        onChange={(event) =>
                          setRegisterForm((prev) => ({
                            ...prev,
                            phone: event.target.value,
                          }))
                        }
                      />
                    </label>

                    <input
                      className={inputClass}
                      type="number"
                      placeholder="Age"
                      value={registerForm.age}
                      onChange={(event) =>
                        setRegisterForm((prev) => ({
                          ...prev,
                          age: event.target.value,
                        }))
                      }
                    />

                    <select
                      className={inputClass}
                      value={registerForm.gender}
                      onChange={(event) =>
                        setRegisterForm((prev) => ({
                          ...prev,
                          gender: event.target.value,
                        }))
                      }
                    >
                      <option>Female</option>
                      <option>Male</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <label className="group relative">
                    <FieldIcon icon={Mail} />
                    <input
                      className={iconInputClass}
                      type="email"
                      placeholder="Email *"
                      value={registerForm.email}
                      onChange={(event) =>
                        setRegisterForm((prev) => ({
                          ...prev,
                          email: event.target.value,
                        }))
                      }
                    />
                  </label>

                  <label className="group relative">
                    <FieldIcon icon={MapPin} />
                    <input
                      className={iconInputClass}
                      placeholder="Address"
                      value={registerForm.address}
                      onChange={(event) =>
                        setRegisterForm((prev) => ({
                          ...prev,
                          address: event.target.value,
                        }))
                      }
                    />
                  </label>

                  <label className="group relative">
                    <FieldIcon icon={LockKeyhole} />
                    <input
                      className={passwordInputClass}
                      type={showRegisterPassword ? "text" : "password"}
                      placeholder="Password *"
                      value={registerForm.password}
                      onChange={(event) =>
                        setRegisterForm((prev) => ({
                          ...prev,
                          password: event.target.value,
                        }))
                      }
                    />
                    <PasswordToggle
                      visible={showRegisterPassword}
                      onClick={() => setShowRegisterPassword((prev) => !prev)}
                    />
                  </label>

                  <button
                    type="submit"
                    className="mt-1 inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                  >
                    <UserPlus size={17} />
                    Create profile
                  </button>

                  <p className="text-center text-xs font-bold text-slate-500">
                    Already have profile?{" "}
                    <button
                      type="button"
                      onClick={() => switchMode("login")}
                      className="font-black text-teal-700 transition hover:text-teal-800"
                    >
                      Login now
                    </button>
                  </p>
                </form>
              </div>

              <div
                className={[
                  "absolute inset-0 transition-all duration-500 ease-[cubic-bezier(.2,.9,.2,1)]",
                  mode === "login"
                    ? "translate-x-0 scale-100 opacity-100"
                    : "translate-x-8 scale-[0.98] opacity-0 pointer-events-none",
                ].join(" ")}
              >
                <form
                  className="flex min-h-[430px] flex-col justify-between gap-4"
                  onSubmit={submitLogin}
                >
                  <div className="grid gap-3">
                    <label className="group relative">
                      <FieldIcon icon={Mail} />
                      <input
                        className={iconInputClass}
                        placeholder="Phone or Email"
                        value={loginForm.phoneOrEmail}
                        onChange={(event) =>
                          setLoginForm((prev) => ({
                            ...prev,
                            phoneOrEmail: event.target.value,
                          }))
                        }
                      />
                    </label>

                    <label className="group relative">
                      <FieldIcon icon={LockKeyhole} />
                      <input
                        className={passwordInputClass}
                        type={showLoginPassword ? "text" : "password"}
                        placeholder="Password"
                        value={loginForm.password}
                        onChange={(event) =>
                          setLoginForm((prev) => ({
                            ...prev,
                            password: event.target.value,
                          }))
                        }
                      />
                      <PasswordToggle
                        visible={showLoginPassword}
                        onClick={() => setShowLoginPassword((prev) => !prev)}
                      />
                    </label>

                    <div className="flex items-center justify-between gap-3">
                      <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-slate-500">
                        <input
                          type="checkbox"
                          checked={loginForm.rememberMe}
                          onChange={(event) =>
                            setLoginForm((prev) => ({
                              ...prev,
                              rememberMe: event.target.checked,
                            }))
                          }
                          className="h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-500"
                        />
                        Remember me
                      </label>

                      <Link
                        to="/user/forgot-password"
                        className="text-xs font-black text-blue-600 transition hover:text-blue-700"
                        onClick={onClose}
                      >
                        Forgot password?
                      </Link>
                    </div>

                    <button
                      type="submit"
                      className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-teal-700 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800"
                    >
                      <LogIn size={17} />
                      Login
                    </button>
                  </div>

                  <div className="rounded-3xl border border-cyan-100 bg-cyan-50 p-4 transition duration-300 hover:-translate-y-0.5 hover:shadow-sm">
                    <p className="text-sm font-black text-slate-950">
                      New patient?
                    </p>
                    <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                      Create profile once and use faster appointment/message
                      access next time.
                    </p>

                    <button
                      type="button"
                      onClick={() => switchMode("register")}
                      className="mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-xs font-black text-teal-700 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-teal-50"
                    >
                      <UserPlus size={15} />
                      Create profile
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </main>
        </div>
      </div>
    </>
  );
};

export default PublicUserModal;