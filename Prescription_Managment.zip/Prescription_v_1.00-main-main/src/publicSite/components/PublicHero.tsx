import { createElement, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Award,
  BadgeCheck,
  Brain,
  CalendarDays,
  Clock,
  MapPin,
  MessageCircle,
  Navigation,
  Play,
  ShieldCheck,
  Star,
  Users,
} from "lucide-react";
import { Link } from "react-router-dom";

const fallbackHeroImage =
  "https://images.unsplash.com/photo-1582750433449-648ed127bb54?q=80&w=1100&auto=format&fit=crop";

const FacebookIcon = ({ className = "" }) => (
  <svg
    viewBox="0 0 24 24"
    aria-hidden="true"
    className={className}
    fill="currentColor"
  >
    <path d="M14.2 8.1V6.6c0-.7.5-.9.9-.9h2.2V2.1L14.3 2C11.1 2 9.4 3.9 9.4 6.2v1.9H6.8V12h2.6v10h4.1V12h3.1l.5-3.9h-3Z" />
  </svg>
);

const XIcon = ({ className = "" }) => (
  <svg
    viewBox="0 0 24 24"
    aria-hidden="true"
    className={className}
    fill="currentColor"
  >
    <path d="M18.2 2.4h3.1l-6.8 7.8 8 11.4h-6.3l-4.9-7-5.6 7H2.6l7.3-8.5L2.2 2.4h6.5l4.4 6.3 5.1-6.3Zm-1.1 17.2h1.7L7.8 4.3H6L17.1 19.6Z" />
  </svg>
);

const InstagramIcon = ({ className = "" }) => (
  <svg
    viewBox="0 0 24 24"
    aria-hidden="true"
    className={className}
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <rect x="3" y="3" width="18" height="18" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
  </svg>
);

const YoutubeIcon = ({ className = "" }) => (
  <svg
    viewBox="0 0 24 24"
    aria-hidden="true"
    className={className}
    fill="currentColor"
  >
    <path d="M21.6 7.1a3 3 0 0 0-2.1-2.1C17.6 4.5 12 4.5 12 4.5s-5.6 0-7.5.5a3 3 0 0 0-2.1 2.1A31 31 0 0 0 2 12a31 31 0 0 0 .4 4.9 3 3 0 0 0 2.1 2.1c1.9.5 7.5.5 7.5.5s5.6 0 7.5-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 22 12a31 31 0 0 0-.4-4.9ZM10 15.5v-7l6 3.5-6 3.5Z" />
  </svg>
);

const getSocialLinks = (profile = {}) => [
  { label: "Facebook", url: profile.facebookUrl || "#", Icon: FacebookIcon },
  { label: "X", url: profile.twitterUrl || "#", Icon: XIcon },
  { label: "Instagram", url: profile.instagramUrl || "#", Icon: InstagramIcon },
  { label: "YouTube", url: profile.youtubeUrl || "#", Icon: YoutubeIcon },
];

const getTitleLines = (title = "Get Appointment Easy and Fast") => {
  const cleanTitle = String(title).trim();

  if (cleanTitle.toLowerCase() === "get appointment easy and fast") {
    return ["Get", "Appointment", "Easy and", "Fast"];
  }

  const words = cleanTitle.split(" ").filter(Boolean);

  if (words.length <= 2) return [cleanTitle];

  if (words.length <= 4) {
    return [words.slice(0, 2).join(" "), words.slice(2).join(" ")];
  }

  return [
    words.slice(0, 2).join(" "),
    words.slice(2, 4).join(" "),
    words.slice(4).join(" "),
  ].filter(Boolean);
};

const useTypewriterCount = (text, speed = 54, delay = 350) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const resetId = window.setTimeout(() => setCount(0), 0);

    let intervalId;
    const timeoutId = window.setTimeout(() => {
      intervalId = window.setInterval(() => {
        setCount((current) => {
          if (current >= text.length) {
            window.clearInterval(intervalId);
            return current;
          }

          return current + 1;
        });
      }, speed);
    }, delay);

    return () => {
      window.clearTimeout(resetId);
      window.clearTimeout(timeoutId);
      window.clearInterval(intervalId);
    };
  }, [text, speed, delay]);

  return count;
};

const useInViewOnce = () => {
  const ref = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;

    if (!element || isVisible) return undefined;

    if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
      const frameId = window.requestAnimationFrame(() => setIsVisible(true));
      return () => window.cancelAnimationFrame(frameId);
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      {
        threshold: 0.35,
        rootMargin: "0px 0px -10% 0px",
      }
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, [isVisible]);

  return [ref, isVisible];
};

const parseStatValue = (value) => {
  const rawValue = String(value || "0");
  const match = rawValue.match(/^(\d+(?:\.\d+)?)(.*)$/);

  if (!match) {
    return {
      numeric: false,
      target: 0,
      suffix: rawValue,
      decimals: 0,
    };
  }

  const target = Number(match[1]);
  const suffix = match[2] || "";
  const decimals = match[1].includes(".") ? match[1].split(".")[1].length : 0;

  return {
    numeric: Number.isFinite(target),
    target,
    suffix,
    decimals,
  };
};

const CountUpNumber = ({ value, start = false }) => {
  const parsed = useMemo(() => parseStatValue(value), [value]);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!parsed.numeric) return undefined;

    if (!start) {
      const frameId = window.requestAnimationFrame(() => setCurrent(0));
      return () => window.cancelAnimationFrame(frameId);
    }

    let frameId;
    let startTime;
    const duration = 1450;

    const animate = (time) => {
      if (!startTime) startTime = time;

      const progress = Math.min((time - startTime) / duration, 1);
      const easedProgress = 1 - Math.pow(1 - progress, 3);

      setCurrent(parsed.target * easedProgress);

      if (progress < 1) {
        frameId = window.requestAnimationFrame(animate);
      }
    };

    frameId = window.requestAnimationFrame(animate);

    return () => window.cancelAnimationFrame(frameId);
  }, [parsed.numeric, parsed.target, start]);

  if (!parsed.numeric) return value;

  const formattedValue =
    parsed.decimals > 0
      ? current.toFixed(parsed.decimals)
      : Math.round(current).toString();

  return `${formattedValue}${parsed.suffix}`;
};

const PublicHero = ({ profile = {}, onAppointment }) => {
  const [statsRef, statsVisible] = useInViewOnce();

  const doctorName =
    profile.doctorName || "Professor Dr. Md. Tofael Hossain Bhuiyan";

  const specialization =
    profile.specialization ||
    "MS Neuro Surgery, Brain, Nerve, Spine & Stroke Specialist";

  const heroImageUrl =
    profile.heroImageUrl || profile.profileImageUrl || fallbackHeroImage;

  const heroTitle = profile.heroTitle || "Get Appointment Easy and Fast";
  const titleLines = getTitleLines(heroTitle);

  const fullTitleText = titleLines.join("\n");
  const titleLineMeta = titleLines.map((line, index) => {
    const lineStart = titleLines
      .slice(0, index)
      .reduce((total, item) => total + item.length + 1, 0);
    const lineEnd = lineStart + line.length;

    return {
      line,
      lineStart,
      lineEnd,
    };
  });

  const typedCount = useTypewriterCount(fullTitleText, 54, 350);
  const isTitleDone = typedCount >= fullTitleText.length;

  const lastTitleLine = titleLines[titleLines.length - 1] || "";
  const lastTitleWords = lastTitleLine.split(" ").filter(Boolean);
  const highlightWord =
    profile.highlightWord || lastTitleWords[lastTitleWords.length - 1] || "Fast";

  const handleImageError = (event) => {
    event.currentTarget.src = fallbackHeroImage;
  };

  const handleMessageClick = () => {
    window.dispatchEvent(new Event("open-public-message-modal"));
  };

  const stats = [
    {
      value: profile.totalPatients || "50k+",
      label: "Happy Patient",
      Icon: Users,
    },
    {
      value: profile.totalExperience || "15+",
      label: "Years Experience",
      Icon: Award,
    },
    {
      value: profile.successRate || "98%",
      label: "Patient Trust",
      Icon: Star,
    },
  ];

  const metaItems = [
    {
      Icon: MapPin,
      text: profile.chamberName || "Dhanmondi Branch, Room 302",
    },
    {
      Icon: Clock,
      text: profile.visitingTime || "09:00 AM - 01:00 PM",
    },
    {
      Icon: MessageCircle,
      text: profile.assistantName || "Assistant support available",
    },
  ];

  const chips = [
    {
      Icon: Brain,
      text: profile.chipOne || "Neuro specialist",
    },
    {
      Icon: ShieldCheck,
      text: profile.chipTwo || "Trusted care",
    },
    {
      Icon: BadgeCheck,
      text: profile.chipThree || "Evidence based",
    },
  ];

  return (
    <section className="relative mx-3 mt-6 max-w-[1180px] overflow-hidden rounded-[28px] border border-cyan-100/80 bg-white shadow-[0_30px_80px_rgba(15,69,82,0.12)] sm:mx-auto sm:w-[calc(100%_-_28px)] lg:rounded-[34px]">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white via-cyan-50/75 to-sky-50" />
      <div className="pointer-events-none absolute -left-28 -top-24 h-80 w-80 rounded-full bg-cyan-200/30 blur-3xl" />
      <div className="pointer-events-none absolute left-[58%] top-[18%] h-[440px] w-[440px] -translate-x-1/2 rounded-full bg-blue-100/70 blur-2xl" />
      <div className="pointer-events-none absolute -right-28 bottom-0 h-80 w-80 rounded-full bg-blue-200/25 blur-3xl" />

      <div className="relative z-10 grid gap-10 px-5 py-8 sm:px-8 sm:py-10 md:py-12 lg:min-h-[660px] lg:grid-cols-[minmax(0,500px)_minmax(420px,1fr)_38px] lg:items-center lg:gap-6 lg:px-12 lg:py-14">
        <div className="max-w-[500px]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-white/80 px-3.5 py-2 text-xs font-black text-teal-700 shadow-sm backdrop-blur">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </span>
            {profile.availabilityText || "Available for appointment"}
          </div>

          <span className="mb-5 inline-flex max-w-xl items-center gap-3 text-xs font-black uppercase leading-6 tracking-wider text-teal-700 sm:text-[13px]">
            <span className="h-0.5 w-7 shrink-0 rounded-full bg-teal-600" />
            {specialization}
          </span>

<h1 className="m-0 min-h-[245px] max-w-[520px] overflow-visible text-[2.65rem] font-black leading-[1.06] tracking-[-0.045em] sm:min-h-[330px] sm:text-[3.65rem] lg:min-h-[315px] lg:text-[4.45rem]">
  {titleLineMeta.map(({ line, lineStart, lineEnd }) => {
    const visibleLength = Math.max(
      0,
      Math.min(line.length, typedCount - lineStart)
    );

    const visibleLine = line.slice(0, visibleLength);

    const isCurrentLine =
      !isTitleDone && typedCount >= lineStart && typedCount <= lineEnd;

    const shouldHighlight =
      isTitleDone && visibleLine.includes(highlightWord);

    if (!shouldHighlight) {
      return (
        <span
          key={line}
          className="block min-h-[1.06em] bg-gradient-to-r from-slate-950 via-blue-950 to-teal-700 bg-clip-text pb-1 text-transparent"
        >
          {visibleLine || "\u00A0"}

          {isCurrentLine && (
            <span className="ml-1 inline-block h-[0.72em] w-[3px] translate-y-1 rounded-full bg-blue-600 align-baseline animate-pulse" />
          )}
        </span>
      );
    }

    const highlightIndex = visibleLine.indexOf(highlightWord);
    const beforeHighlight = visibleLine.slice(0, highlightIndex);
    const afterHighlight = visibleLine.slice(
      highlightIndex + highlightWord.length
    );

    return (
      <span
        key={line}
        className="block min-h-[1.06em] bg-gradient-to-r from-slate-950 via-blue-950 to-teal-700 bg-clip-text pb-2 text-transparent"
      >
        {beforeHighlight}

        <span className="relative inline-block bg-gradient-to-r from-blue-700 to-teal-600 bg-clip-text pb-1 text-transparent">
          {highlightWord}
          <span className="absolute bottom-0 left-0 h-[4px] w-full rounded-full bg-gradient-to-r from-blue-600 to-teal-500" />
        </span>

        {afterHighlight}
      </span>
    );
  })}
</h1>

          <p className="mt-6 max-w-md text-[15px] font-semibold leading-7 text-slate-600 sm:text-base">
            {profile.shortBio ||
              "Brain, nerve, spine and stroke care with calm clinical guidance. রোগীর কথা শুনে evidence-based treatment plan করা হয়।"}
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            {chips.map(({ Icon, text }) => (
              <span
                key={text}
                className="group inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-white/75 px-3.5 py-2 text-xs font-extrabold text-slate-600 shadow-sm backdrop-blur transition duration-300 hover:-translate-y-0.5 hover:border-blue-100 hover:bg-white hover:text-blue-600 hover:shadow-md"
              >
                {createElement(Icon, {
                  size: 14,
                  className:
                    "text-teal-600 transition duration-700 group-hover:rotate-[360deg] group-hover:text-blue-600",
                })}
                {text}
              </span>
            ))}
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
            <button
              type="button"
              className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 px-6 text-sm font-black text-white shadow-[0_18px_34px_rgba(20,102,242,0.26)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_24px_48px_rgba(20,102,242,0.34)] focus:outline-none focus:ring-2 focus:ring-blue-300"
              onClick={onAppointment}
            >
              <CalendarDays
                size={17}
                className="transition duration-700 group-hover:rotate-[360deg]"
              />
              {profile.ctaText || "Book Appointment"}
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>

            <Link
              className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl border border-cyan-100 bg-white/85 px-6 text-sm font-black text-slate-700 shadow-sm backdrop-blur transition duration-300 hover:-translate-y-1 hover:border-blue-100 hover:bg-white hover:text-blue-600 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-cyan-300"
              to="/about"
            >
              <Play
                size={17}
                className="transition duration-700 group-hover:rotate-[360deg] group-hover:text-blue-600"
              />
              View Profile
            </Link>
          </div>

          <div ref={statsRef} className="mt-8 grid gap-3 sm:grid-cols-3 lg:mt-11">
            {stats.map(({ value, label, Icon }) => (
              <div
                key={label}
                className="group rounded-3xl border border-white/90 bg-white/75 p-4 shadow-sm backdrop-blur transition duration-300 hover:-translate-y-1 hover:border-blue-100 hover:bg-white hover:shadow-xl"
              >
                {createElement(Icon, {
                  size: 20,
                  className:
                    "mb-3 text-blue-600 transition duration-700 group-hover:rotate-[360deg]",
                })}

                <strong className="block text-2xl font-black tracking-tight text-blue-600">
                  <CountUpNumber value={value} start={statsVisible} />
                </strong>

                <span className="mt-1 block text-xs font-bold text-slate-500">
                  {label}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative isolate flex min-h-[470px] items-center justify-center lg:min-h-[560px]">
          <div className="pointer-events-none absolute left-1/2 top-[38%] -z-10 aspect-square w-[min(470px,96%)] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-blue-100 via-white/85 to-cyan-50 shadow-inner" />

          <div className="w-full max-w-[520px]">
            <img
              src={heroImageUrl}
              alt={`${doctorName} appointment`}
              onError={handleImageError}
              className="mx-auto h-[290px] w-full rounded-[30px] object-cover object-center shadow-[0_28px_45px_rgba(32,73,92,0.16)] transition duration-700 hover:scale-[1.015] sm:h-[355px] lg:h-[410px]"
            />

            <div className="mt-4 w-full rounded-3xl border border-cyan-100 bg-white/90 p-4 shadow-[0_16px_34px_rgba(16,78,92,0.10)] backdrop-blur transition duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-xl">
  <div className="grid gap-4 sm:grid-cols-3">
    {metaItems.map(({ Icon, text }) => (
      <div
        key={text}
        className="group flex items-start gap-2 text-xs font-bold leading-5 text-slate-600"
      >
        {createElement(Icon, {
          size: 16,
          className:
            "mt-0.5 shrink-0 text-teal-600 transition duration-700 group-hover:rotate-[360deg] group-hover:text-blue-600",
        })}
        <span>{text}</span>
      </div>
    ))}
  </div>

  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
    <span className="text-xs font-black text-slate-500">
      Direction
    </span>

    <Link
      to="/contact"
      className="group inline-flex items-center gap-1 text-xs font-black text-blue-600 transition hover:gap-2"
    >
      Map
      <Navigation
        size={13}
        className="transition duration-700 group-hover:rotate-[360deg]"
      />
    </Link>
  </div>
</div>
          </div>
        </div>

        <aside
          className="hidden h-full min-h-[430px] items-center justify-center lg:flex"
          aria-label="Social links"
        >
          <div className="grid justify-items-center gap-5 before:mb-3 before:h-20 before:w-0.5 before:rounded-full before:bg-blue-600 before:content-['']">
            {getSocialLinks(profile).map(({ label, url, Icon }) => (
              <a
                key={label}
                className="group relative text-blue-600 transition duration-300 hover:-translate-y-1 hover:scale-110 hover:text-slate-950 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-4"
                href={url}
                target="_blank"
                rel="noreferrer"
                aria-label={`Open ${label}`}
              >
                {createElement(Icon, {
                  className:
                    "h-5 w-5 transition duration-700 group-hover:rotate-[360deg]",
                })}

                <span className="pointer-events-none absolute right-9 top-1/2 -translate-y-1/2 scale-95 rounded-full bg-slate-950 px-3 py-1.5 text-xs font-black text-white opacity-0 shadow-lg transition duration-200 group-hover:scale-100 group-hover:opacity-100">
                  {label}
                </span>
              </a>
            ))}

            <button
              type="button"
              className="group relative text-blue-600 transition duration-300 hover:-translate-y-1 hover:scale-110 hover:text-slate-950 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-4"
              onClick={handleMessageClick}
              aria-label="Open message"
            >
              <MessageCircle className="h-5 w-5 transition duration-700 group-hover:rotate-[360deg]" />

              <span className="pointer-events-none absolute right-9 top-1/2 -translate-y-1/2 scale-95 rounded-full bg-slate-950 px-3 py-1.5 text-xs font-black text-white opacity-0 shadow-lg transition duration-200 group-hover:scale-100 group-hover:opacity-100">
                Message
              </span>
            </button>
          </div>
        </aside>
      </div>
    </section>
  );
};

export default PublicHero;
