import { Stethoscope } from "lucide-react";

const PublicServiceCard = ({ service }) => (
  <article className="rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur">
    <Stethoscope size={22} className="text-teal-700" />
    <h3 className="mt-4 text-xl font-black tracking-tight text-slate-900">
      {service.title}
    </h3>
    <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
      {service.description}
    </p>
  </article>
);

export default PublicServiceCard;
