import {
  AlertCircle,
  CalendarClock,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  HeartPulse,
  MessageSquareText,
  Phone,
  TicketCheck,
  UserRound,
  Users,
  VenusAndMars,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { addPublicAppointment, submitPublicAppointment } from "../lib/publicStorage";
import { getActivePublicUser } from "../lib/publicUserStorage";

const APPOINTMENT_RULES_KEY = "doctor_appointment_rules";
const SERIAL_BOOKINGS_KEY = "public_appointment_serial_bookings";

const defaultAppointmentRules = {
  dailyCapacity: 12,
  blockedDates: [],
  dateLimits: {},
  dateSlots: {},
  weeklySlots: {
    5: [
      {
        label: "Friday Evening",
        start: "14:00",
        end: "23:59",
        intervalMinutes: 30,
        capacityPerSlot: 1,
      },
    ],
    6: [
      {
        label: "Saturday Morning",
        start: "08:00",
        end: "12:00",
        intervalMinutes: 20,
        capacityPerSlot: 1,
      },
    ],
  },
};

const initialForm = {
  patientName: "",
  phone: "",
  age: "",
  gender: "Female",
  problem: "",
  preferredDate: "",
  preferredTime: "",
  message: "",
};

const appointmentCss = `
  @keyframes modalIn {
    from { opacity: 0; transform: translateY(14px) scale(0.985); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes softPulse {
    0%, 100% { opacity: .42; transform: scale(1); }
    50% { opacity: .75; transform: scale(1.04); }
  }

  @keyframes slotPop {
    0% { transform: scale(.96); opacity: .65; }
    100% { transform: scale(1); opacity: 1; }
  }

  .appointment-modal-in {
    animation: modalIn 320ms cubic-bezier(.2,.8,.2,1) both;
  }

  .appointment-fade-up {
    animation: fadeUp 360ms ease both;
  }

  .appointment-glow {
    animation: softPulse 5s ease-in-out infinite;
  }

  .slot-pop {
    animation: slotPop 220ms ease both;
  }
`;

const RequiredMark = () => (
  <span className="ml-1 text-[10px] font-black text-red-500">*</span>
);

const pad = (value) => String(value).padStart(2, "0");

const formatDateInput = (date) => {
  const year = date.getFullYear();
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  return `${year}-${month}-${day}`;
};

const getTodayDate = () => formatDateInput(new Date());

const addDaysToDate = (dateString, days) => {
  const date = new Date(`${dateString}T00:00:00`);
  date.setDate(date.getDate() + days);
  return formatDateInput(date);
};

const formatDisplayDate = (dateString) => {
  if (!dateString) return "";

  const date = new Date(`${dateString}T00:00:00`);

  return date.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatMonthTitle = (date) => {
  return date.toLocaleDateString("en-GB", {
    month: "long",
    year: "numeric",
  });
};

const toMinutes = (time) => {
  const [hour, minute] = String(time || "00:00")
    .split(":")
    .map((item) => Number(item));

  return hour * 60 + minute;
};

const fromMinutes = (total) => {
  const hour = Math.floor(total / 60);
  const minute = total % 60;
  return `${pad(hour)}:${pad(minute)}`;
};

const formatTimeLabel = (time) => {
  const [hour, minute] = String(time).split(":").map(Number);
  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${pad(displayHour)}:${pad(minute)} ${suffix}`;
};

const readJson = (key, fallback) => {
  if (typeof window === "undefined") return fallback;

  try {
    const saved = window.localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
};

const readAppointmentRules = () => {
  const saved = readJson(APPOINTMENT_RULES_KEY, {});
  const dailyCapacity = Number(saved.dailyCapacity);

  return {
    dailyCapacity:
      Number.isFinite(dailyCapacity) && dailyCapacity > 0
        ? dailyCapacity
        : defaultAppointmentRules.dailyCapacity,
    blockedDates: Array.isArray(saved.blockedDates)
      ? saved.blockedDates
      : defaultAppointmentRules.blockedDates,
    dateLimits:
      saved.dateLimits && typeof saved.dateLimits === "object"
        ? saved.dateLimits
        : defaultAppointmentRules.dateLimits,
    dateSlots:
      saved.dateSlots && typeof saved.dateSlots === "object"
        ? saved.dateSlots
        : defaultAppointmentRules.dateSlots,
    weeklySlots:
      saved.weeklySlots && typeof saved.weeklySlots === "object"
        ? saved.weeklySlots
        : defaultAppointmentRules.weeklySlots,
  };
};

const readSerialBookings = () => {
  const saved = readJson(SERIAL_BOOKINGS_KEY, []);

  return Array.isArray(saved)
    ? saved.filter((item) => item && item.date && item.time && item.serialNo)
    : [];
};

const saveSerialBooking = (record) => {
  if (typeof window === "undefined") return;

  const bookings = readSerialBookings();
  window.localStorage.setItem(
    SERIAL_BOOKINGS_KEY,
    JSON.stringify([...bookings, record])
  );
};

const makeId = () => {
  if (
    typeof window !== "undefined" &&
    window.crypto &&
    window.crypto.randomUUID
  ) {
    return window.crypto.randomUUID();
  }

  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
};

const getDailyCapacityForDate = (date, rules) => {
  if (rules.blockedDates.includes(date)) return 0;

  const customCapacity = Number(rules.dateLimits?.[date]);

  if (Number.isFinite(customCapacity) && customCapacity >= 0) {
    return customCapacity;
  }

  return rules.dailyCapacity;
};

const getRawRangesForDate = (date, rules) => {
  if (rules.blockedDates.includes(date)) return [];

  if (Array.isArray(rules.dateSlots?.[date])) {
    return rules.dateSlots[date];
  }

  const dayIndex = new Date(`${date}T00:00:00`).getDay();
  return Array.isArray(rules.weeklySlots?.[dayIndex])
    ? rules.weeklySlots[dayIndex]
    : [];
};

const buildTimeSlots = (date, rules, bookings) => {
  const ranges = getRawRangesForDate(date, rules);
  const dayCapacity = getDailyCapacityForDate(date, rules);
  const dayBooked = bookings.filter((item) => item.date === date).length;
  const dayRemaining = Math.max(dayCapacity - dayBooked, 0);

  if (!ranges.length || dayCapacity <= 0 || dayRemaining <= 0) {
    return [];
  }

  return ranges.flatMap((range) => {
    const start = toMinutes(range.start);
    const end = toMinutes(range.end);
    const interval = Number(range.intervalMinutes) || 30;
    const capacityPerSlot = Math.max(Number(range.capacityPerSlot) || 1, 1);
    const slots = [];

    for (let minute = start; minute < end; minute += interval) {
      const time = fromMinutes(minute);
      const booked = bookings.filter(
        (item) => item.date === date && item.time === time
      ).length;

      const available = Math.max(
        Math.min(capacityPerSlot - booked, dayRemaining),
        0
      );

      slots.push({
        date,
        time,
        label: formatTimeLabel(time),
        rangeLabel: range.label || "Doctor Chamber",
        capacityPerSlot,
        booked,
        available,
        isFull: available <= 0,
      });
    }

    return slots;
  });
};

const getDayStatus = (date, rules, bookings) => {
  const capacity = getDailyCapacityForDate(date, rules);
  const booked = bookings.filter((item) => item.date === date).length;
  const available = Math.max(capacity - booked, 0);
  const slots = buildTimeSlots(date, rules, bookings);
  const availableSlots = slots.filter((slot) => slot.available > 0);

  return {
    date,
    capacity,
    booked,
    available,
    slots,
    availableSlots,
    isClosed: getRawRangesForDate(date, rules).length === 0 || capacity <= 0,
    isFull: capacity <= 0 || available <= 0 || availableSlots.length === 0,
  };
};

const findAvailableSlot = (startDate, rules, bookings) => {
  for (let day = 0; day <= 60; day += 1) {
    const date = addDaysToDate(startDate, day);
    const status = getDayStatus(date, rules, bookings);
    const slot = status.availableSlots[0];

    if (slot) {
      return {
        ...slot,
        dayCapacity: status.capacity,
        dayBooked: status.booked,
        dayAvailable: status.available,
        serialNo: status.booked + 1,
        moved: day > 0,
      };
    }
  }

  return null;
};

const getCalendarDays = (viewMonth) => {
  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const firstDate = new Date(year, month, 1);
  const startDate = new Date(firstDate);
  startDate.setDate(firstDate.getDate() - firstDate.getDay());

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(startDate);
    date.setDate(startDate.getDate() + index);

    return {
      value: formatDateInput(date),
      day: date.getDate(),
      isCurrentMonth: date.getMonth() === month,
    };
  });
};

const FieldIcon = ({ icon: Icon, top = "top-1/2" }) => (
  <Icon
    size={15}
    strokeWidth={2}
    className={`pointer-events-none absolute left-3.5 ${top} -translate-y-1/2 text-slate-400 transition duration-300 group-focus-within:text-teal-700`}
  />
);

const AppointmentModal = ({ open, onClose }) => {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState({ type: "", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const [bookingVersion, setBookingVersion] = useState(0);
  const [viewMonth, setViewMonth] = useState(
    () => new Date(`${getTodayDate()}T00:00:00`)
  );

  const selectedDate = form.preferredDate || getTodayDate();
  const today = getTodayDate();

  useEffect(() => {
    if (!open) return;

    setViewMonth(new Date(`${selectedDate}T00:00:00`));

    const activeUser = getActivePublicUser();
    if (!activeUser) return;

    const timeoutId = window.setTimeout(() => {
      setForm((prev) => ({
        ...prev,
        patientName: prev.patientName || activeUser.name || "",
        phone: prev.phone || activeUser.phone || "",
        age: prev.age || activeUser.age || "",
        gender: prev.gender || activeUser.gender || prev.gender,
      }));
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [open, selectedDate]);

  const availability = useMemo(() => {
    void bookingVersion;

    const rules = readAppointmentRules();
    const bookings = readSerialBookings();
    const requested = getDayStatus(selectedDate, rules, bookings);
    const nextSlot = findAvailableSlot(selectedDate, rules, bookings);

    return {
      rules,
      bookings,
      requested,
      nextSlot,
    };
  }, [selectedDate, bookingVersion]);

  const calendarDays = useMemo(() => getCalendarDays(viewMonth), [viewMonth]);

  if (!open) return null;

  const update = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
      ...(key === "preferredDate" ? { preferredTime: "" } : {}),
    }));

    if (status.message) setStatus({ type: "", message: "" });
  };

  const updatePhone = (value) => {
    const cleanPhone = value.replace(/\D/g, "").slice(0, 11);
    update("phone", cleanPhone);
  };

  const selectDate = (date) => {
    if (date < today) return;

    setViewMonth(new Date(`${date}T00:00:00`));
    update("preferredDate", date);
  };

  const moveMonth = (direction) => {
    setViewMonth((prev) => {
      const next = new Date(prev);
      next.setMonth(prev.getMonth() + direction);
      return next;
    });
  };

  const useNextAvailable = () => {
    if (!availability.nextSlot) return;

    update("preferredDate", availability.nextSlot.date);

    window.setTimeout(() => {
      update("preferredTime", availability.nextSlot.time);
    }, 0);

    setViewMonth(new Date(`${availability.nextSlot.date}T00:00:00`));
  };

  const submit = async (event) => {
    event.preventDefault();
    if (submitting) return;

    if (!form.patientName.trim() || !form.phone.trim() || !form.problem.trim()) {
      setStatus({
        type: "error",
        message: "Please add patient name, phone and problem.",
      });
      return;
    }

    if (form.phone.length !== 11) {
      setStatus({
        type: "error",
        message: "Phone number must be exactly 11 digits.",
      });
      return;
    }

    const selectedSlot = availability.requested.availableSlots.find(
      (slot) => slot.time === form.preferredTime
    );

    if (availability.requested.availableSlots.length > 0 && !selectedSlot) {
      setStatus({
        type: "error",
        message: "Please select an available time slot.",
      });
      return;
    }

    const slot = selectedSlot
      ? {
          ...selectedSlot,
          dayCapacity: availability.requested.capacity,
          dayBooked: availability.requested.booked,
          dayAvailable: availability.requested.available,
          serialNo: availability.requested.booked + 1,
          moved: false,
        }
      : availability.nextSlot;

    if (!slot) {
      setStatus({
        type: "error",
        message: "No serial available in the next 60 days.",
      });
      return;
    }

    const bookingRecord = {
      id: makeId(),
      date: slot.date,
      time: slot.time,
      serialNo: slot.serialNo,
      patientName: form.patientName,
      phone: form.phone,
      preferredDate: selectedDate,
      createdAt: new Date().toISOString(),
    };

    saveSerialBooking(bookingRecord);

    const payload = {
      ...form,
      preferredDate: selectedDate,
      preferredTime: slot.time,
      assignedDate: slot.date,
      assignedTime: slot.time,
      serialNo: slot.serialNo,
      serialCapacity: slot.dayCapacity,
      appointmentStatus: "Pending",
    };

    let savedAppointment;

    try {
      setSubmitting(true);
      savedAppointment = await submitPublicAppointment(payload);
    } catch {
      savedAppointment = addPublicAppointment(payload);
    } finally {
      setSubmitting(false);
    }

    setForm(initialForm);
    setBookingVersion((value) => value + 1);

    setStatus({
      type: "success",
      message: slot.moved
        ? `Tracking ID ${savedAppointment.appointmentCode || savedAppointment.id}. Selected date is full/closed. Serial #${pad(
            slot.serialNo
          )} assigned for ${formatDisplayDate(slot.date)} at ${slot.label}.`
        : `Tracking ID ${savedAppointment.appointmentCode || savedAppointment.id}. Appointment request submitted. Serial #${pad(
            slot.serialNo
          )} assigned for ${formatDisplayDate(slot.date)} at ${slot.label}.`,
    });
  };

  const closeFromBackdrop = (event) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  const fieldClass =
    "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 hover:border-cyan-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-50";

  const iconFieldClass = `${fieldClass} pl-9`;

  return (
    <>
      <style>{appointmentCss}</style>

      <div
        className="fixed inset-0 z-[90] grid place-items-center bg-slate-950/45 p-3 backdrop-blur-sm"
        role="dialog"
        aria-modal="true"
        onMouseDown={closeFromBackdrop}
      >
        <form
          className="appointment-modal-in relative grid max-h-[calc(100svh-1.5rem)] w-[min(980px,100%)] overflow-hidden rounded-[26px] border border-cyan-100 bg-white shadow-2xl shadow-slate-950/20 lg:grid-cols-[0.95fr_1.05fr]"
          onSubmit={submit}
          onMouseDown={(event) => event.stopPropagation()}
        >
          <button
            type="button"
            className="group absolute right-4 top-4 z-20 text-slate-400 transition duration-300 hover:-translate-y-0.5 hover:text-red-500 focus:outline-none"
            onClick={onClose}
            aria-label="Close appointment modal"
          >
            <X
              size={22}
              strokeWidth={2.2}
              className="transition duration-300 group-hover:rotate-90"
            />
          </button>

          <section className="relative max-h-[calc(100svh-1.5rem)] overflow-y-auto p-4 sm:p-5">
            <span className="appointment-glow pointer-events-none absolute -left-16 top-10 h-32 w-32 rounded-full bg-cyan-100 blur-3xl" />

            <div className="appointment-fade-up relative pr-8">
              <p className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-teal-700">
                <CalendarDays size={13} strokeWidth={2} />
                Appointment
              </p>

              <h2 className="mt-1.5 text-2xl font-black tracking-tight text-slate-950">
                Book Appointment
              </h2>

              <p className="mt-1.5 text-xs font-semibold leading-5 text-slate-500">
                Add patient details, choose date, then select a time slot.
              </p>
            </div>

            <div className="mt-4 grid gap-2.5">
              <label className="grid gap-1">
                <span className="text-[11px] font-black text-slate-700">
                  Patient name
                  <RequiredMark />
                </span>
                <div className="group relative">
                  <FieldIcon icon={UserRound} />
                  <input
                    className={iconFieldClass}
                    placeholder="Patient full name"
                    value={form.patientName}
                    onChange={(event) =>
                      update("patientName", event.target.value)
                    }
                  />
                </div>
              </label>

              <div className="grid gap-2.5 sm:grid-cols-2">
                <label className="grid gap-1">
                  <span className="text-[11px] font-black text-slate-700">
                    Mobile number
                    <RequiredMark />
                  </span>
                  <div className="group relative">
                    <FieldIcon icon={Phone} />
                    <input
                      className={iconFieldClass}
                      inputMode="numeric"
                      maxLength={11}
                      placeholder="017XXXXXXXX"
                      value={form.phone}
                      onChange={(event) => updatePhone(event.target.value)}
                    />
                  </div>
                </label>

                <label className="grid gap-1">
                  <span className="text-[11px] font-black text-slate-700">
                    Age
                  </span>
                  <div className="group relative">
                    <FieldIcon icon={HeartPulse} />
                    <input
                      className={iconFieldClass}
                      type="number"
                      placeholder="Age"
                      value={form.age}
                      onChange={(event) => update("age", event.target.value)}
                    />
                  </div>
                </label>
              </div>

              <label className="grid gap-1">
                <span className="text-[11px] font-black text-slate-700">
                  Gender
                </span>
                <div className="group relative">
                  <FieldIcon icon={VenusAndMars} />
                  <select
                    className={iconFieldClass}
                    value={form.gender}
                    onChange={(event) => update("gender", event.target.value)}
                  >
                    <option>Female</option>
                    <option>Male</option>
                    <option>Other</option>
                  </select>
                </div>
              </label>

              <label className="grid gap-1">
                <span className="text-[11px] font-black text-slate-700">
                  Problem
                  <RequiredMark />
                </span>
                <div className="group relative">
                  <FieldIcon icon={MessageSquareText} top="top-5" />
                  <textarea
                    className={`${iconFieldClass} min-h-20 resize-none py-2.5 leading-5`}
                    placeholder="Write patient problem..."
                    value={form.problem}
                    onChange={(event) => update("problem", event.target.value)}
                  />
                </div>
              </label>

              <label className="grid gap-1">
                <span className="text-[11px] font-black text-slate-700">
                  Message
                </span>
                <textarea
                  className={`${fieldClass} min-h-16 resize-none py-2.5 leading-5`}
                  placeholder="Additional message, if any..."
                  value={form.message}
                  onChange={(event) => update("message", event.target.value)}
                />
              </label>
            </div>

            {status.message ? (
              <div
                className={[
                  "mt-3 flex items-start gap-2 rounded-xl border px-3 py-2.5 text-xs font-extrabold leading-5",
                  status.type === "error"
                    ? "border-red-100 bg-red-50 text-red-700"
                    : "border-teal-100 bg-teal-50 text-teal-700",
                ].join(" ")}
              >
                {status.type === "error" ? (
                  <AlertCircle
                    size={15}
                    strokeWidth={2}
                    className="mt-0.5 shrink-0"
                  />
                ) : (
                  <CheckCircle2
                    size={15}
                    strokeWidth={2}
                    className="mt-0.5 shrink-0"
                  />
                )}
                <span>{status.message}</span>
              </div>
            ) : null}

            <button
              type="submit"
              disabled={submitting}
              className="mt-4 h-11 w-full rounded-xl bg-teal-700 px-5 text-sm font-black text-white shadow-lg shadow-teal-700/15 transition duration-300 hover:-translate-y-0.5 hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {submitting ? "Submitting..." : "Submit Appointment"}
            </button>
          </section>

          <section className="max-h-[calc(100svh-1.5rem)] overflow-y-auto border-t border-cyan-100 bg-slate-50/80 p-4 sm:p-5 lg:border-l lg:border-t-0">
            <div className="appointment-fade-up">
              <div className="flex items-start justify-between gap-3 pr-8">
                <div>
                  <p className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-teal-700">
                    <TicketCheck size={13} strokeWidth={2} />
                    Schedule
                  </p>

                  <h3 className="mt-1.5 text-xl font-black text-slate-950">
                    Date & Time
                  </h3>

                  <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                    Select date and choose available slot.
                  </p>
                </div>

                <span
                  className={[
                    "rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wide",
                    availability.requested.isFull
                      ? "bg-red-50 text-red-600"
                      : "bg-teal-50 text-teal-700",
                  ].join(" ")}
                >
                  {availability.requested.isClosed
                    ? "Closed"
                    : availability.requested.isFull
                    ? "Full"
                    : "Available"}
                </span>
              </div>

              <div className="mt-3 rounded-[20px] border border-cyan-100 bg-white p-3 shadow-sm">
                <div className="flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => moveMonth(-1)}
                    className="text-slate-400 transition hover:-translate-x-0.5 hover:text-teal-700"
                    aria-label="Previous month"
                  >
                    <ChevronLeft size={20} />
                  </button>

                  <h4 className="text-xs font-black text-slate-950">
                    {formatMonthTitle(viewMonth)}
                  </h4>

                  <button
                    type="button"
                    onClick={() => moveMonth(1)}
                    className="text-slate-400 transition hover:translate-x-0.5 hover:text-teal-700"
                    aria-label="Next month"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>

                <div className="mt-3 grid grid-cols-7 gap-1 text-center text-[9px] font-black uppercase text-slate-400">
                  {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => (
                    <span key={`${day}-${index}`}>{day}</span>
                  ))}
                </div>

                <div className="mt-1.5 grid grid-cols-7 gap-1">
                  {calendarDays.map((day) => {
                    const dayStatus = getDayStatus(
                      day.value,
                      availability.rules,
                      availability.bookings
                    );
                    const isPast = day.value < today;
                    const isSelected = day.value === selectedDate;
                    const isToday = day.value === today;

                    return (
                      <button
                        key={day.value}
                        type="button"
                        disabled={isPast}
                        onClick={() => selectDate(day.value)}
                        className={[
                          "slot-pop relative h-8 rounded-xl text-xs font-black transition duration-300",
                          !day.isCurrentMonth ? "opacity-35" : "",
                          isPast
                            ? "cursor-not-allowed text-slate-300"
                            : isSelected
                            ? "bg-teal-700 text-white shadow-md shadow-teal-700/15"
                            : dayStatus.isFull
                            ? "bg-red-50 text-red-500 hover:bg-red-100"
                            : "bg-slate-50 text-slate-700 hover:-translate-y-0.5 hover:bg-teal-50 hover:text-teal-700",
                        ].join(" ")}
                        title={
                          isPast
                            ? "Past date"
                            : dayStatus.isFull
                            ? "Full or closed"
                            : "Available"
                        }
                      >
                        {day.day}

                        {isToday ? (
                          <span
                            className={[
                              "absolute bottom-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full",
                              isSelected ? "bg-white" : "bg-teal-600",
                            ].join(" ")}
                          />
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2">
                <div className="rounded-2xl border border-cyan-100 bg-white p-3">
                  <Users size={15} className="text-blue-600" />
                  <p className="mt-1 text-[9px] font-black uppercase text-slate-400">
                    Limit
                  </p>
                  <p className="text-base font-black text-slate-950">
                    {availability.requested.capacity}
                  </p>
                </div>

                <div className="rounded-2xl border border-cyan-100 bg-white p-3">
                  <CalendarClock size={15} className="text-teal-600" />
                  <p className="mt-1 text-[9px] font-black uppercase text-slate-400">
                    Booked
                  </p>
                  <p className="text-base font-black text-slate-950">
                    {availability.requested.booked}
                  </p>
                </div>

                <div className="rounded-2xl border border-cyan-100 bg-white p-3">
                  <CheckCircle2 size={15} className="text-teal-600" />
                  <p className="mt-1 text-[9px] font-black uppercase text-slate-400">
                    Free
                  </p>
                  <p className="text-base font-black text-slate-950">
                    {availability.requested.available}
                  </p>
                </div>
              </div>

              <div className="mt-3 rounded-[20px] border border-cyan-100 bg-white p-3 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="text-xs font-black text-slate-950">
                      Time Slots
                    </h4>
                    <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                      {formatDisplayDate(selectedDate)}
                    </p>
                  </div>

                  <Clock size={16} className="text-teal-700" />
                </div>

                {availability.requested.slots.length ? (
                  <div className="mt-3 grid max-h-44 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
                    {availability.requested.slots.map((slot) => (
                      <button
                        key={slot.time}
                        type="button"
                        disabled={slot.isFull}
                        onClick={() => update("preferredTime", slot.time)}
                        className={[
                          "slot-pop rounded-xl border px-3 py-2 text-left transition duration-300 focus:outline-none",
                          form.preferredTime === slot.time
                            ? "border-teal-300 bg-teal-50 text-teal-800 shadow-sm"
                            : slot.isFull
                            ? "cursor-not-allowed border-slate-100 bg-slate-50 text-slate-300"
                            : "border-slate-200 bg-white text-slate-700 hover:-translate-y-0.5 hover:border-teal-200 hover:bg-teal-50",
                        ].join(" ")}
                      >
                        <span className="block text-xs font-black">
                          {slot.label}
                        </span>
                        <span className="mt-0.5 block text-[10px] font-bold">
                          {slot.isFull
                            ? "Full"
                            : `${slot.available} serial available`}
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="mt-3 rounded-xl border border-dashed border-cyan-200 bg-cyan-50/60 p-3">
                    <p className="text-xs font-black text-slate-800">
                      No slot available.
                    </p>

                    {availability.nextSlot ? (
                      <div className="mt-1.5">
                        <p className="text-xs font-semibold leading-5 text-slate-600">
                          Next:{" "}
                          <span className="font-black text-teal-700">
                            {formatDisplayDate(availability.nextSlot.date)}
                          </span>{" "}
                          at{" "}
                          <span className="font-black text-teal-700">
                            {availability.nextSlot.label}
                          </span>
                        </p>

                        <button
                          type="button"
                          onClick={useNextAvailable}
                          className="mt-2 h-9 rounded-xl bg-white px-3 text-[11px] font-black text-teal-700 shadow-sm transition hover:-translate-y-0.5 hover:bg-teal-50"
                        >
                          Use next available
                        </button>
                      </div>
                    ) : (
                      <p className="mt-1 text-xs font-semibold leading-5 text-red-600">
                        No serial available in the next 60 days.
                      </p>
                    )}
                  </div>
                )}

                <div className="mt-3 rounded-xl bg-slate-50 px-3 py-2">
                  <p className="text-[11px] font-bold leading-5 text-slate-500">
                    Selected:{" "}
                    <span className="font-black text-slate-900">
                      {formatDisplayDate(selectedDate)}
                    </span>
                    {form.preferredTime ? (
                      <>
                        {" "}
                        at{" "}
                        <span className="font-black text-teal-700">
                          {formatTimeLabel(form.preferredTime)}
                        </span>
                      </>
                    ) : (
                      <span className="font-black text-red-500">
                        {" "}
                        — choose time
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </div>
          </section>
        </form>
      </div>
    </>
  );
};

export default AppointmentModal;
