const PublicGalleryCard = ({ item }) => (
  <article className="overflow-hidden rounded-[1.5rem] border border-teal-100 bg-white/80 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur">
    <img className="h-72 w-full object-cover" src={item.imageUrl} alt={item.title} />
    <div className="p-4">
      <span className="text-xs font-black uppercase tracking-wide text-teal-700">
        {item.category}
      </span>
      <h3 className="mt-2 text-xl font-black tracking-tight text-slate-900">
        {item.title}
      </h3>
      <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
        {item.description}
      </p>
    </div>
  </article>
);

export default PublicGalleryCard;
