import { useState } from "react";
import { findPrescription } from "../lib/publicStorage";
import EmptyPublicState from "./EmptyPublicState";

const PrescriptionLookupForm = () => {
  const [query, setQuery] = useState("");
  const [searched, setSearched] = useState(false);
  const [prescription, setPrescription] = useState(null);

  const submit = (event) => {
    event.preventDefault();
    setPrescription(findPrescription(query));
    setSearched(true);
  };
  const fieldClass =
    "w-full rounded-2xl border border-teal-100 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-2 focus:ring-cyan-100";

  return (
    <section className="grid gap-4 md:grid-cols-2">
      <form
        className="grid gap-4 rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur"
        onSubmit={submit}
      >
        <h3 className="text-xl font-black tracking-tight text-slate-900">
          Prescription Lookup
        </h3>
        <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
          Patient ID or phone
          <input className={fieldClass} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="P-1003 or +880..." />
        </label>
        <button
          type="submit"
          className="inline-flex min-h-11 items-center justify-center rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-cyan-300"
        >
          Search
        </button>
      </form>

      {prescription ? (
        <article className="rounded-[1.5rem] border border-teal-100 bg-white/90 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)]">
          <span className="text-xs font-black uppercase tracking-wide text-teal-700">{prescription.date}</span>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-slate-900">{prescription.patientName}</h2>
          <p className="mt-3 text-sm font-semibold text-slate-600"><strong>Patient ID:</strong> {prescription.patientId}</p>
          <p className="mt-2 text-sm font-semibold text-slate-600"><strong>Diagnosis:</strong> {prescription.diagnosis}</p>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600"><strong>Advice:</strong> {prescription.advice}</p>
          <h3 className="mt-4 text-lg font-black text-slate-900">Medicines</h3>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm font-semibold text-slate-600">
            {prescription.medicines?.map((medicine) => (
              <li key={medicine}>{medicine}</li>
            ))}
          </ul>
          <button
            type="button"
            className="mt-5 inline-flex min-h-11 items-center justify-center rounded-full border border-teal-100 bg-white px-5 text-sm font-black text-teal-700 shadow-sm transition hover:bg-cyan-50 focus:outline-none focus:ring-2 focus:ring-cyan-300"
            onClick={() => window.print()}
          >
            Download / Print
          </button>
        </article>
      ) : searched ? (
        <EmptyPublicState title="No prescription found" message="Please check the patient ID or phone number and try again." />
      ) : null}
    </section>
  );
};

export default PrescriptionLookupForm;
