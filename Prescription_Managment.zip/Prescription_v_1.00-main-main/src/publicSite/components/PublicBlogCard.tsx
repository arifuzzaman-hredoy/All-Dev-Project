import { Link } from "react-router-dom";
import { formatDate } from "../lib/dateFormat";

const PublicBlogCard = ({ blog }) => (
  <article className="overflow-hidden rounded-[1.5rem] border border-teal-100 bg-white/80 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur">
    <img className="h-56 w-full object-cover" src={blog.coverImageUrl} alt={blog.title} />
    <div className="p-4">
      <span className="text-xs font-black uppercase tracking-wide text-teal-700">
        {blog.category} • {formatDate(blog.publishDate)}
      </span>
      <h3 className="mt-2 text-xl font-black tracking-tight text-slate-900">
        {blog.title}
      </h3>
      <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
        {blog.excerpt}
      </p>
      <Link
        className="mt-3 inline-flex text-sm font-black text-teal-700 transition hover:text-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-300"
        to={`/blogs/${blog.slug}`}
      >
        Read article
      </Link>
    </div>
  </article>
);

export default PublicBlogCard;
