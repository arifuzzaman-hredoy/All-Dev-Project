const EmptyPublicState = ({ title, message }) => (
  <div className="rounded-[1.5rem] border border-dashed border-teal-200 bg-white/60 p-8 text-center">
    <h3 className="text-xl font-black tracking-tight text-slate-900">{title}</h3>
    <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{message}</p>
  </div>
);

export default EmptyPublicState;
