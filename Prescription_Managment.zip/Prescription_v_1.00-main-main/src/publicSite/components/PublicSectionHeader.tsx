const PublicSectionHeader = ({ eyebrow, title, description }) => (
  <div className="mb-5 max-w-3xl">
    {eyebrow ? (
      <span className="text-xs font-black uppercase tracking-wider text-teal-700">
        {eyebrow}
      </span>
    ) : null}
    <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 md:text-5xl">
      {title}
    </h2>
    {description ? (
      <p className="mt-3 text-sm font-semibold leading-7 text-slate-600 md:text-base">
        {description}
      </p>
    ) : null}
  </div>
);

export default PublicSectionHeader;
