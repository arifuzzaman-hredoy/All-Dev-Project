import { Mail, Phone } from "lucide-react";

const PublicDoctorCard = ({ profile }) => (
  <article className="grid gap-5 rounded-[1.5rem] border border-teal-100 bg-white/80 p-4 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur md:grid-cols-[280px_1fr] md:items-center">
    <img
      className="aspect-square w-full rounded-[1.25rem] object-cover"
      src={profile.profileImageUrl}
      alt={profile.doctorName}
    />
    <div>
      <span className="text-sm font-black text-teal-700">{profile.title}</span>
      <h3 className="mt-2 text-2xl font-black tracking-tight text-slate-900">
        {profile.doctorName}
      </h3>
      <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">
        {profile.longBio}
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <a
          className="inline-flex items-center gap-2 rounded-full border border-teal-100 bg-white/80 px-3 py-2 text-sm font-bold text-slate-600 transition hover:text-teal-700 focus:outline-none focus:ring-2 focus:ring-cyan-300"
          href={`tel:${profile.phone}`}
        >
          <Phone size={15} /> {profile.phone}
        </a>
        <a
          className="inline-flex items-center gap-2 rounded-full border border-teal-100 bg-white/80 px-3 py-2 text-sm font-bold text-slate-600 transition hover:text-teal-700 focus:outline-none focus:ring-2 focus:ring-cyan-300"
          href={`mailto:${profile.email}`}
        >
          <Mail size={15} /> {profile.email}
        </a>
      </div>
    </div>
  </article>
);

export default PublicDoctorCard;
