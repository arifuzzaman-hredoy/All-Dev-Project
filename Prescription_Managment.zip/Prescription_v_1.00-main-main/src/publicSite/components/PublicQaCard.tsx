const PublicQaCard = ({ item }) => (
  <article className="rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)] backdrop-blur">
    <p className="text-base font-black leading-7 text-slate-900">{item.question}</p>
    <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">{item.answer}</p>
    <span className="mt-4 inline-flex rounded-full bg-cyan-50 px-3 py-1 text-xs font-black text-teal-700">
      Answered by doctor
    </span>
  </article>
);

export default PublicQaCard;
