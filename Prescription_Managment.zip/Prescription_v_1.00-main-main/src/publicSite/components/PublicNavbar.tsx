import {
  CalendarDays,
  ChevronDown,
  LogOut,
  Menu,
  MessageCircle,
  Stethoscope,
  UserRound,
  X,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import PublicMessageModal from "./PublicMessageModal";
import PublicUserModal from "./PublicUserModal";
import {
  getActivePublicUser,
  logoutPublicUser,
  PUBLIC_POPUP_DISMISSED_KEY,
} from "../lib/publicUserStorage";

const links = [
  { path: "/", label: "Home" },
  { path: "/about", label: "About" },
  { path: "/services", label: "Services" },
  { path: "/blogs", label: "Blogs" },
  { path: "/qa", label: "Q&A" },
  { path: "/gallery", label: "Gallery" },
  { path: "/contact", label: "Contact" },
  { path: "/patient-prescription", label: "Prescription" },
];

const getActivePath = (pathname) => {
  if (pathname === "/") return "/";

  const matched = links
    .filter((item) => item.path !== "/" && pathname.startsWith(item.path))
    .sort((a, b) => b.path.length - a.path.length);

  return matched[0]?.path || "/";
};

const getFirstName = (name) => {
  if (!name) return "User";
  return name.trim().split(" ")[0] || "User";
};

const getInitial = (name) => {
  const first = getFirstName(name);
  return first.charAt(0).toUpperCase();
};

const PublicNavbar = ({ profile = {}, onAppointment }) => {
  const [open, setOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [messageModalOpen, setMessageModalOpen] = useState(false);
  const [activeUser, setActiveUser] = useState(() => getActivePublicUser());
  const [indicator, setIndicator] = useState({
    left: 0,
    width: 0,
    opacity: 0,
  });

  const location = useLocation();
  const navigate = useNavigate();
  const navRef = useRef(null);
  const userMenuRef = useRef(null);
  const linkRefs = useRef({});

  const activePath = useMemo(
    () => getActivePath(location.pathname),
    [location.pathname],
  );

  const moveIndicator = useCallback((path) => {
    const navNode = navRef.current;
    const linkNode = linkRefs.current[path];

    if (!navNode || !linkNode) return;

    const navRect = navNode.getBoundingClientRect();
    const linkRect = linkNode.getBoundingClientRect();

    setIndicator({
      left: linkRect.left - navRect.left + 10,
      width: Math.max(linkRect.width - 20, 24),
      opacity: 1,
    });
  }, []);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      moveIndicator(activePath);
    });

    const handleResize = () => moveIndicator(activePath);
    window.addEventListener("resize", handleResize);

    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", handleResize);
    };
  }, [activePath, moveIndicator]);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        userMenuRef.current &&
        !userMenuRef.current.contains(event.target)
      ) {
        setUserMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setOpen(false);
      setUserMenuOpen(false);
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [location.pathname]);

  useEffect(() => {
    const syncUser = () => setActiveUser(getActivePublicUser());

    const openUserModal = () => {
      setUserMenuOpen(false);
      navigate("/user/login", { state: { from: "message" } });
    };

    const openMessageModal = () => {
      const user = getActivePublicUser();
      setActiveUser(user);

      if (user) {
        setUserMenuOpen(false);
        setMessageModalOpen(true);
        return;
      }

      setUserModalOpen(true);
    };

    syncUser();

    window.addEventListener("storage", syncUser);
    window.addEventListener("public-users-updated", syncUser);
    window.addEventListener("open-public-user-modal", openUserModal);
    window.addEventListener("open-public-message-modal", openMessageModal);

    return () => {
      window.removeEventListener("storage", syncUser);
      window.removeEventListener("public-users-updated", syncUser);
      window.removeEventListener("open-public-user-modal", openUserModal);
      window.removeEventListener("open-public-message-modal", openMessageModal);
    };
  }, [navigate]);

  useEffect(() => {
    const dismissed =
      window.localStorage.getItem(PUBLIC_POPUP_DISMISSED_KEY) === "true";

    if (!activeUser && !dismissed) {
      const timeoutId = window.setTimeout(() => setUserModalOpen(true), 700);
      return () => window.clearTimeout(timeoutId);
    }

    return undefined;
  }, [activeUser]);

  useEffect(() => {
    if (!activeUser) return;

    if (window.sessionStorage.getItem("open_public_message_after_login") === "true") {
      window.sessionStorage.removeItem("open_public_message_after_login");
      const timeoutId = window.setTimeout(() => setMessageModalOpen(true), 0);
      return () => window.clearTimeout(timeoutId);
    }

    return undefined;
  }, [activeUser, location.pathname]);

  const handleAppointmentClick = () => {
    setOpen(false);
    setUserMenuOpen(false);

    if (typeof onAppointment === "function") {
      onAppointment();
    }
  };

  const handleUserClick = () => {
    if (!activeUser) {
      setUserMenuOpen(false);
      navigate("/user/login");
      return;
    }

    setUserMenuOpen((value) => !value);
  };

  const handleMessageClick = () => {
    setUserMenuOpen(false);

    if (!activeUser) {
      navigate("/user/login", { state: { from: "message" } });
      return;
    }

    setMessageModalOpen(true);
  };

  const handleLogout = () => {
    logoutPublicUser();
    setActiveUser(null);
    setUserMenuOpen(false);
    setMessageModalOpen(false);

    window.dispatchEvent(new Event("public-users-updated"));
  };

  const handleNavClick = (event) => {
    event.currentTarget.blur();
    setOpen(false);
    setUserMenuOpen(false);
  };

  return (
    <header className="sticky top-3 z-50 mx-3 mt-3 max-w-[1220px] sm:mx-auto sm:w-[calc(100%_-_28px)]">
      <div className="relative overflow-visible rounded-[26px] border border-cyan-100/80 bg-white/90 shadow-[0_18px_48px_rgba(13,78,86,0.11)] backdrop-blur-2xl">
        <div className="pointer-events-none absolute inset-0 rounded-[26px] bg-gradient-to-r from-white via-cyan-50/40 to-white" />
        <div className="pointer-events-none absolute -left-14 -top-14 h-28 w-28 rounded-full bg-cyan-200/25 blur-2xl" />
        <div className="pointer-events-none absolute -right-14 bottom-0 h-28 w-28 rounded-full bg-blue-200/20 blur-2xl" />

        <div className="relative flex min-h-[68px] items-center justify-between gap-3 px-3 py-2 sm:px-4">
          <NavLink
            to="/"
            className="group flex min-w-0 shrink-0 items-center gap-2.5 text-teal-950 transition duration-300 hover:-translate-y-0.5 focus:outline-none lg:w-[245px]"
            onClick={handleNavClick}
          >
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl border border-cyan-100 bg-gradient-to-br from-cyan-50 to-white text-teal-700 shadow-sm transition duration-300 group-hover:text-blue-600">
              <Stethoscope
                size={19}
                strokeWidth={2.2}
                className="transition duration-300 group-hover:-rotate-6"
              />
            </span>

            <span className="grid min-w-0 gap-0.5">
              <strong className="truncate bg-gradient-to-r from-slate-950 to-teal-700 bg-clip-text text-base font-black tracking-tight text-transparent sm:text-lg">
                {profile.brandName || "CareBridge"}
              </strong>

              <small className="max-w-[145px] truncate text-[11px] font-bold text-slate-500 sm:max-w-[210px]">
                {profile.doctorName || "Doctor Profile"}
              </small>
            </span>
          </NavLink>

          <nav
            ref={navRef}
            className="relative hidden min-w-0 flex-1 items-center justify-center gap-0.5 px-1 lg:flex"
            onMouseLeave={() => moveIndicator(activePath)}
          >
            <span
              className="pointer-events-none absolute bottom-1.5 h-[3px] rounded-full bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500 shadow-[0_4px_14px_rgba(20,102,242,0.32)] transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]"
              style={{
                left: `${indicator.left}px`,
                width: `${indicator.width}px`,
                opacity: indicator.opacity,
              }}
            />

            {links.map(({ path, label }) => (
              <NavLink
                key={path}
                to={path}
                end={path === "/"}
                ref={(node) => {
                  if (node) linkRefs.current[path] = node;
                }}
                onMouseEnter={() => moveIndicator(path)}
                onClick={handleNavClick}
                className={({ isActive }) =>
                  [
                    "relative z-10 inline-flex h-10 items-center justify-center whitespace-nowrap px-2.5 text-[13px] font-black transition duration-300 ease-out hover:-translate-y-0.5 focus:outline-none xl:px-3",
                    isActive
                      ? "bg-gradient-to-r from-blue-700 via-cyan-600 to-teal-600 bg-clip-text text-transparent"
                      : "text-slate-600 hover:text-teal-700",
                  ].join(" ")
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex shrink-0 items-center justify-end gap-2 lg:w-[280px]">
            <div ref={userMenuRef} className="relative">
              <button
                type="button"
                className={[
                  "group inline-flex h-10 items-center justify-center gap-2 rounded-2xl border border-teal-100 bg-white/90 px-2.5 text-sm font-black text-teal-800 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-cyan-50 hover:text-blue-600 focus:outline-none",
                  activeUser ? "max-w-[165px]" : "w-10",
                ].join(" ")}
                onClick={handleUserClick}
                title={activeUser ? "User profile" : "User login"}
              >
                {activeUser ? (
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-teal-700 text-xs font-black text-white">
                    {getInitial(activeUser.name)}
                  </span>
                ) : (
                  <UserRound
                    size={18}
                    className="transition duration-300 group-hover:-rotate-6"
                  />
                )}

                {activeUser ? (
                  <>
                    <span className="hidden max-w-[76px] truncate text-xs font-black sm:inline">
                      {getFirstName(activeUser.name)}
                    </span>
                    <ChevronDown
                      size={14}
                      className={`hidden shrink-0 transition sm:block ${
                        userMenuOpen ? "rotate-180" : ""
                      }`}
                    />
                  </>
                ) : null}
              </button>

              {activeUser && userMenuOpen ? (
                <div className="absolute right-0 top-12 z-[70] w-60 overflow-hidden rounded-2xl border border-cyan-100 bg-white shadow-2xl">
                  <div className="border-b border-slate-100 px-4 py-3">
                    <p className="truncate text-sm font-black text-slate-900">
                      {activeUser.name}
                    </p>
                    <p className="mt-0.5 truncate text-xs font-bold text-slate-500">
                      {activeUser.phone}
                    </p>
                  </div>

                  <button
                    type="button"
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-xs font-black text-slate-700 transition hover:bg-cyan-50"
                    onClick={handleMessageClick}
                  >
                    <MessageCircle size={14} />
                    Message
                  </button>

                  <button
                    type="button"
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-xs font-black text-slate-700 transition hover:bg-cyan-50"
                    onClick={handleAppointmentClick}
                  >
                    <CalendarDays size={14} />
                    Appointment
                  </button>

                  <button
                    type="button"
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-xs font-black text-rose-700 transition hover:bg-rose-50"
                    onClick={handleLogout}
                  >
                    <LogOut size={14} />
                    Logout
                  </button>
                </div>
              ) : null}
            </div>

            <button
              type="button"
              className="group hidden h-10 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 via-cyan-600 to-blue-600 px-4 text-xs font-black text-white shadow-[0_12px_26px_rgba(7,107,116,0.22)] transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_16px_32px_rgba(7,107,116,0.28)] focus:outline-none lg:inline-flex"
              onClick={handleAppointmentClick}
            >
              <CalendarDays
                size={16}
                className="transition duration-300 group-hover:-rotate-6"
              />
              <span>{profile.ctaText || "Book"}</span>
            </button>

            <button
              type="button"
              className="group grid h-10 w-10 place-items-center rounded-2xl border border-teal-100 bg-white/90 text-teal-800 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:bg-cyan-50 hover:text-blue-600 focus:outline-none lg:hidden"
              onClick={() => setOpen((value) => !value)}
              aria-label="Toggle navigation"
              aria-expanded={open}
            >
              {open ? (
                <X
                  size={21}
                  className="transition duration-300 group-hover:rotate-90"
                />
              ) : (
                <Menu
                  size={21}
                  className="transition duration-300 group-hover:-rotate-6"
                />
              )}
            </button>
          </div>
        </div>
      </div>

      {open ? (
        <nav className="mt-2 grid gap-1 rounded-[24px] border border-teal-100 bg-white/95 p-3 shadow-[0_20px_45px_rgba(13,78,86,0.12)] backdrop-blur-xl lg:hidden">
          {links.map(({ path, label }) => (
            <NavLink
              key={path}
              to={path}
              end={path === "/"}
              onClick={handleNavClick}
              className={({ isActive }) =>
                [
                  "relative flex min-h-11 items-center px-4 text-sm font-extrabold transition duration-300 hover:-translate-y-0.5 focus:outline-none",
                  "after:absolute after:bottom-2 after:left-4 after:h-[3px] after:rounded-full after:bg-gradient-to-r after:from-blue-600 after:via-cyan-500 after:to-teal-500 after:shadow-[0_4px_12px_rgba(20,102,242,0.28)] after:transition-all after:duration-500",
                  isActive
                    ? "bg-gradient-to-r from-blue-700 via-cyan-600 to-teal-600 bg-clip-text text-transparent after:w-12"
                    : "text-slate-600 hover:text-teal-700 after:w-0 hover:after:w-10",
                ].join(" ")
              }
            >
              {label}
            </NavLink>
          ))}

          <button
            type="button"
            className="group mt-2 inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 via-cyan-600 to-blue-600 px-4 text-sm font-black text-white shadow-lg transition duration-300 hover:-translate-y-0.5 focus:outline-none"
            onClick={handleAppointmentClick}
          >
            <CalendarDays
              size={18}
              className="transition duration-300 group-hover:-rotate-6"
            />
            {profile.ctaText || "Book Appointment"}
          </button>
        </nav>
      ) : null}

      <PublicUserModal
        open={userModalOpen}
        onClose={() => setUserModalOpen(false)}
        onSuccess={(user) => {
          setActiveUser(user);
          setUserMenuOpen(false);
          setUserModalOpen(false);
          window.dispatchEvent(new Event("public-users-updated"));
        }}
      />

      <PublicMessageModal
        open={messageModalOpen}
        user={activeUser}
        onClose={() => setMessageModalOpen(false)}
      />
    </header>
  );
};

export default PublicNavbar;
