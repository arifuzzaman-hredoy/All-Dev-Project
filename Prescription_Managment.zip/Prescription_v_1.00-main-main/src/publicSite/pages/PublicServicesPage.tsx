import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowRight,
  BadgeCheck,
  Brain,
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  HeartPulse,
  Microscope,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import AppointmentModal from "../components/AppointmentModal";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import { getPublicProfile, getPublicServices } from "../lib/publicStorage";

const serviceIcons = [
  Brain,
  Activity,
  HeartPulse,
  Stethoscope,
  Microscope,
  ShieldCheck,
  ClipboardCheck,
  BadgeCheck,
];

const getServiceTitle = (service, index) =>
  service.title || service.name || `Service ${index + 1}`;

const getServiceDescription = (service) =>
  service.description ||
  service.shortDescription ||
  service.summary ||
  "Focused consultation and follow-up support with clear clinical guidance.";

const getServiceBullets = (service) => {
  const possible =
    service.features ||
    service.highlights ||
    service.points ||
    service.items ||
    service.bullets;

  if (Array.isArray(possible) && possible.length > 0) {
    return possible.slice(0, 3);
  }

  return [
    "Doctor-led assessment",
    "Clear treatment guidance",
    "Follow-up friendly support",
  ];
};

const PublicServicesPage = () => {
  const [profile] = useState(getPublicProfile);
  const [cmsServices, setCmsServices] = useState(getPublicServices);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const sync = () => setCmsServices(getPublicServices());
    window.addEventListener("carebridge-storage-updated", sync);
    return () => window.removeEventListener("carebridge-storage-updated", sync);
  }, []);

  const services = useMemo(
    () =>
      (cmsServices || []).map((service, index) => ({
        ...service,
        id: service.id || service.slug || getServiceTitle(service, index),
        title: getServiceTitle(service, index),
        description: getServiceDescription(service),
        bullets: getServiceBullets(service),
        Icon: serviceIcons[index % serviceIcons.length],
      })),
    [cmsServices]
  );

  return (
    <div className="min-h-svh overflow-hidden bg-gradient-to-b from-[#effafa] via-white to-[#f7fbff] text-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(13,148,136,0.12)_1px,transparent_0)] [background-size:24px_24px]" />
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[linear-gradient(to_right,rgba(14,165,233,0.045)_1px,transparent_1px),linear-gradient(to_bottom,rgba(14,165,233,0.045)_1px,transparent_1px)] [background-size:82px_82px]" />
      <div className="pointer-events-none fixed -left-40 -top-40 -z-10 h-[430px] w-[430px] rounded-full bg-cyan-200/35 blur-3xl" />
      <div className="pointer-events-none fixed -right-44 bottom-[-170px] -z-10 h-[460px] w-[460px] rounded-full bg-blue-200/30 blur-3xl" />

      <NavbarRenderer
        profile={profile}
        onAppointment={() => setModalOpen(true)}
      />

      <main className="mx-3 max-w-[1180px] py-8 sm:mx-auto sm:w-[calc(100%_-_28px)] lg:py-10">
        <section className="relative overflow-hidden rounded-[32px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-7 lg:p-9">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan-100/70 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-28 left-1/3 h-72 w-72 rounded-full bg-blue-100/60 blur-3xl" />

          <div className="relative grid gap-7 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50/85 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-teal-700">
                <Sparkles size={14} />
                Clinical Services
              </div>

              <h1 className="mt-5 max-w-3xl text-[2.35rem] font-black leading-[1.05] tracking-[-0.05em] text-slate-950 sm:text-[3.4rem] lg:text-[4.25rem]">
                Treatments &{" "}
                <span className="bg-gradient-to-r from-blue-700 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
                  Follow-up
                </span>
              </h1>

              <p className="mt-4 max-w-2xl text-[15px] font-semibold leading-8 text-slate-600 sm:text-base">
                Focused consultation for brain, nerve, spine and stroke concerns.
                Choose the service you need and book an appointment with clear
                chamber guidance.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:shadow-[0_22px_44px_rgba(20,102,242,0.30)] focus:outline-none"
            >
              <CalendarDays
                size={17}
                className="transition duration-300 group-hover:-rotate-6"
              />
              Book Appointment
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>
        </section>

        <section className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {services.map(({ id, title, description, bullets, Icon }, index) => (
            <article
              key={id}
              className="group relative overflow-hidden rounded-[30px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.07)] backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:rotate-[0.35deg] hover:bg-white hover:shadow-[0_22px_55px_rgba(11,86,90,0.12)]"
            >
              <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-cyan-100/70 blur-2xl transition duration-300 group-hover:bg-blue-100/80" />

              <div className="relative">
                <div className="flex items-start justify-between gap-4">
                  <Icon
                    size={28}
                    className="text-teal-600 transition duration-300 group-hover:-rotate-6 group-hover:text-blue-600"
                  />

                  <span className="rounded-full border border-cyan-100 bg-cyan-50/80 px-3 py-1.5 text-[11px] font-black uppercase tracking-wide text-teal-700">
                    0{index + 1}
                  </span>
                </div>

                <h2 className="mt-5 text-xl font-black leading-7 tracking-tight text-slate-950">
                  {title}
                </h2>

                <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">
                  {description}
                </p>

                <div className="mt-5 space-y-2.5">
                  {bullets.map((item) => (
                    <div
                      key={item}
                      className="flex items-start gap-2 text-sm font-bold leading-6 text-slate-600"
                    >
                      <CheckCircle2
                        size={16}
                        className="mt-1 shrink-0 text-teal-600"
                      />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setModalOpen(true)}
                  className="mt-6 inline-flex items-center gap-2 text-sm font-black text-blue-600 transition duration-300 hover:gap-3 hover:text-teal-700 focus:outline-none"
                >
                  Book this service
                  <ArrowRight size={16} />
                </button>
              </div>
            </article>
          ))}
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_0.8fr]">
          <div className="rounded-[32px] border border-cyan-100/80 bg-gradient-to-r from-white via-cyan-50/80 to-blue-50/80 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.07)] backdrop-blur-xl sm:p-7">
            <div className="flex items-center gap-2">
              <ShieldCheck size={20} className="text-teal-600" />
              <h2 className="text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">
                Patient-friendly service process
              </h2>
            </div>

            <p className="mt-3 max-w-2xl text-sm font-semibold leading-7 text-slate-600">
              Every service is designed to keep patients informed, organized and
              confident before and after the chamber visit.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[
                "Select service",
                "Book appointment",
                "Get follow-up guidance",
              ].map((step, index) => (
                <div
                  key={step}
                  className="group rounded-[24px] border border-white/80 bg-white/80 p-4 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:rotate-[0.35deg] hover:shadow-md"
                >
                  <span className="grid h-9 w-9 place-items-center rounded-2xl bg-cyan-50 text-sm font-black text-teal-700">
                    {index + 1}
                  </span>

                  <p className="mt-3 text-sm font-black text-slate-700">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[32px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.07)] backdrop-blur-xl sm:p-7">
            <div className="flex items-center gap-2">
              <HeartPulse size={20} className="text-blue-600" />
              <h2 className="text-2xl font-black tracking-tight text-slate-950">
                Need help choosing?
              </h2>
            </div>

            <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">
              রোগীর symptoms বা report অনুযায়ী কোন service লাগবে সেটা confirm
              করতে appointment request করুন।
            </p>

            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="group mt-5 inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:shadow-[0_22px_44px_rgba(20,102,242,0.30)] focus:outline-none"
            >
              <CalendarDays
                size={17}
                className="transition duration-300 group-hover:-rotate-6"
              />
              Ask for Appointment
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>
        </section>
      </main>

      <FooterRenderer profile={profile} />

      <AppointmentModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </div>
  );
};

export default PublicServicesPage;
