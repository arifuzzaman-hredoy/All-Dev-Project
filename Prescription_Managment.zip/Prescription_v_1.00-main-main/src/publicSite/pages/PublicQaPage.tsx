import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  HelpCircle,
  MessageCircleQuestion,
  Phone,
  Send,
  ShieldCheck,
  UserRound,
  X,
} from "lucide-react";
import AppointmentModal from "../components/AppointmentModal";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import {
  getPublicProfile,
  getPublicQa,
  loadPublicContent,
  savePublicContent,
  savePublicQa,
} from "../lib/publicStorage";

const PUBLIC_QA_REQUESTS_KEY = "public_qa_requests";
const QA_SEEN_ANSWERS_PREFIX = "public_qa_seen_answers_";

const demoQaItems = [
  {
    id: "demo-1",
    question: "মাথা ব্যথা বারবার হলে কি সবসময় serious problem?",
    answer:
      "না, বারবার মাথা ব্যথা মানেই serious problem না। Migraine, stress, sleep problem, eye problem বা sinus থেকেও হতে পারে। তবে vomiting, চোখে ঝাপসা দেখা, হাত-পা দুর্বল হওয়া বা কথা জড়িয়ে গেলে দ্রুত doctor দেখানো উচিত।",
  },
  {
    id: "demo-2",
    question: "Stroke-এর early sign কী কী?",
    answer:
      "মুখ বেঁকে যাওয়া, এক পাশের হাত-পা দুর্বল হওয়া, কথা জড়িয়ে যাওয়া, balance হারানো বা হঠাৎ চোখে কম দেখা stroke-এর warning sign হতে পারে। এমন হলে delay না করে emergency hospital যেতে হবে।",
  },
  {
    id: "demo-3",
    question: "ঘাড় বা কোমরের disc problem হলে কি surgery লাগবেই?",
    answer:
      "সব disc problem-এ surgery লাগে না। অনেক সময় medicine, physiotherapy, posture correction এবং lifestyle change দিয়ে ভালো হয়। তবে weakness, numbness বা urine/stool control problem থাকলে specialist review জরুরি।",
  },
  {
    id: "demo-4",
    question: "Report ছাড়া doctor দেখালে কি problem হবে?",
    answer:
      "Report থাকলে ভালো, কিন্তু report না থাকলেও doctor symptoms শুনে primary assessment করতে পারেন। পরে প্রয়োজন হলে test বা report advise করবেন।",
  },
];

const safeReadList = (key) => {
  if (typeof window === "undefined") return [];

  try {
    const saved = window.localStorage.getItem(key);
    const parsed = saved ? JSON.parse(saved) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const safeWriteList = (key, list) => {
  if (typeof window === "undefined") return;

  window.localStorage.setItem(key, JSON.stringify(list));
  window.dispatchEvent(new Event("public-qa-updated"));
  window.dispatchEvent(new Event("public-content-updated"));
};

const normalizeStatus = (status, answer = "") => {
  const value = String(status || "").toLowerCase();

  if (value === "answered") return "answered";
  if (value === "published") return "answered";
  if (value === "publish") return "answered";
  if (value === "hidden") return "hidden";
  if (answer?.trim()) return "answered";

  return "pending";
};

const getTimeValue = (item) => {
  const time = new Date(item?.updatedAt || item?.createdAt || 0).getTime();
  return Number.isFinite(time) ? time : 0;
};

const normalizeQaItem = (item, index = 0) => {
  const createdAt = item.createdAt || new Date().toISOString();
  const answer = item.answer || item.reply || item.doctorAnswer || "";

  return {
    id: item.id || `qa-${getTimeValue(item) || Date.now()}-${index}`,
    patientId: item.patientId || item.patientID || item.userId || "",
    patientName:
      item.patientName ||
      item.name ||
      item.userName ||
      item.fullName ||
      "Patient",
    phone: item.phone || item.mobile || item.phoneNumber || "",
    question: item.question || item.message || item.text || "",
    answer,
    status: normalizeStatus(item.status, answer),
    createdAt,
    updatedAt: item.updatedAt || createdAt,
  };
};

const mergeQaLists = (...lists) => {
  const map = new Map();

  lists
    .flat()
    .filter(Boolean)
    .forEach((item, index) => {
      const normalized = normalizeQaItem(item, index);
      const existing = map.get(normalized.id);

      if (!existing || getTimeValue(normalized) >= getTimeValue(existing)) {
        map.set(normalized.id, normalized);
      }
    });

  return Array.from(map.values()).sort(
    (a, b) => getTimeValue(b) - getTimeValue(a)
  );
};

const getCurrentPublicUser = () => {
  if (typeof window === "undefined") return null;

  const priorityKeys = [
    "public_user",
    "publicUser",
    "public_current_user",
    "public_logged_user",
    "publicLoggedUser",
    "logged_public_user",
    "active_public_user",
    "doctor_public_user",
    "carebridge_public_user",
    "currentUser",
    "authUser",
  ];

  for (const key of priorityKeys) {
    try {
      const saved = window.localStorage.getItem(key);
      if (!saved) continue;

      const parsed = JSON.parse(saved);
      const user = parsed?.user || parsed?.data || parsed;

      if (user && typeof user === "object" && (user.name || user.patientName || user.phone)) {
        return user;
      }
    } catch {
      // ignore
    }
  }

  try {
    for (let index = 0; index < window.localStorage.length; index += 1) {
      const key = window.localStorage.key(index);
      if (!key) continue;

      const keyText = key.toLowerCase();
      if (
        !keyText.includes("public") &&
        !keyText.includes("patient") &&
        !keyText.includes("user")
      ) {
        continue;
      }

      const saved = window.localStorage.getItem(key);
      const parsed = saved ? JSON.parse(saved) : null;
      const user = parsed?.user || parsed?.data || parsed;

      if (user && typeof user === "object" && (user.name || user.patientName || user.phone)) {
        return user;
      }
    }
  } catch {
    // ignore
  }

  return null;
};

const getUserName = (user) =>
  user?.name || user?.patientName || user?.fullName || "";

const getUserPhone = (user) =>
  user?.phone || user?.mobile || user?.phoneNumber || "";

const getUserPatientId = (user) =>
  user?.patientId || user?.patientID || user?.serialNo || user?.id || "";

const getUserKey = (user) => {
  return (
    getUserPatientId(user) ||
    getUserPhone(user) ||
    getUserName(user) ||
    "guest"
  );
};

const isMine = (item, user) => {
  if (!user) return false;

  const patientId = getUserPatientId(user);
  const phone = getUserPhone(user);
  const name = getUserName(user);

  if (patientId && item.patientId && item.patientId === patientId) return true;
  if (phone && item.phone && item.phone === phone) return true;
  if (name && item.patientName && item.patientName === name) return true;

  return false;
};

const formatDateTime = (value) => {
  if (!value) return "";

  return new Date(value).toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
};

const PublicQaPage = () => {
  const [profile] = useState(getPublicProfile);
  const [modalOpen, setModalOpen] = useState(false);
  const [appointmentOpen, setAppointmentOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(() => getCurrentPublicUser());
  const [qaItems, setQaItems] = useState(() =>
    mergeQaLists(getPublicQa(), safeReadList(PUBLIC_QA_REQUESTS_KEY))
  );
  const [toast, setToast] = useState("");
  const [status, setStatus] = useState("");
  const [form, setForm] = useState({
    patientName: getUserName(currentUser),
    phone: getUserPhone(currentUser),
    question: "",
  });

  const inputClass =
    "w-full rounded-2xl border border-cyan-100 bg-white px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100";

  const syncQa = () => {
    const user = getCurrentPublicUser();
    const next = mergeQaLists(getPublicQa(), safeReadList(PUBLIC_QA_REQUESTS_KEY));

    setCurrentUser(user);
    setQaItems(next);

    setForm((prev) => ({
      ...prev,
      patientName: prev.patientName || getUserName(user),
      phone: prev.phone || getUserPhone(user),
    }));
  };

  useEffect(() => {
    const syncTimeoutId = window.setTimeout(syncQa, 0);

    loadPublicContent("qa", getPublicQa())
      .then((data) => {
        const remote = Array.isArray(data) ? data : [];
        const next = mergeQaLists(
          remote,
          getPublicQa(),
          safeReadList(PUBLIC_QA_REQUESTS_KEY)
        );

        setQaItems(next);
        savePublicQa(next);
        safeWriteList(PUBLIC_QA_REQUESTS_KEY, next);
      })
      .catch(() => {
        // local fallback active
      });

    window.addEventListener("storage", syncQa);
    window.addEventListener("public-qa-updated", syncQa);
    window.addEventListener("public-content-updated", syncQa);

    return () => {
      window.removeEventListener("storage", syncQa);
      window.removeEventListener("public-qa-updated", syncQa);
      window.removeEventListener("public-content-updated", syncQa);
      window.clearTimeout(syncTimeoutId);
    };
  }, []);

  const submittedQuestions = useMemo(() => {
    return qaItems.filter((item) => isMine(item, currentUser));
  }, [qaItems, currentUser]);

  const answeredSubmittedQuestions = useMemo(() => {
    return submittedQuestions.filter(
      (item) => normalizeStatus(item.status, item.answer) === "answered" && item.answer
    );
  }, [submittedQuestions]);

  const publicAnsweredQuestions = useMemo(() => {
    const answered = qaItems
      .filter(
        (item) =>
          normalizeStatus(item.status, item.answer) === "answered" &&
          item.answer &&
          item.question
      )
      .map((item) => ({
        id: item.id,
        question: item.question,
        answer: item.answer,
      }));

    return [...answered, ...demoQaItems];
  }, [qaItems]);

  useEffect(() => {
    if (!currentUser || !answeredSubmittedQuestions.length) return;

    const userKey = getUserKey(currentUser);
    const seenKey = `${QA_SEEN_ANSWERS_PREFIX}${userKey}`;

    let seenIds = [];

    try {
      const saved = window.localStorage.getItem(seenKey);
      seenIds = saved ? JSON.parse(saved) : [];
      if (!Array.isArray(seenIds)) seenIds = [];
    } catch {
      seenIds = [];
    }

    const answeredIds = answeredSubmittedQuestions.map((item) => item.id);
    const newAnswered = answeredIds.filter((id) => !seenIds.includes(id));

    if (newAnswered.length) {
      const timeoutId = window.setTimeout(() => {
        setToast("Doctor answered your question.");
      }, 0);
      window.localStorage.setItem(seenKey, JSON.stringify(answeredIds));
      return () => window.clearTimeout(timeoutId);
    }

    return undefined;
  }, [answeredSubmittedQuestions, currentUser]);

  useEffect(() => {
    if (!toast) return;

    const timeoutId = window.setTimeout(() => setToast(""), 2400);
    return () => window.clearTimeout(timeoutId);
  }, [toast]);

  const openQuestionForm = () => {
    const user = getCurrentPublicUser();

    setCurrentUser(user);
    setForm({
      patientName: getUserName(user),
      phone: getUserPhone(user),
      question: "",
    });
    setStatus("");
    setModalOpen(true);
  };

  const closeQuestionForm = () => {
    if (form.question.trim()) {
      const confirmed = window.confirm("Question লেখা আছে. Close করতে চান?");
      if (!confirmed) return;
    }

    setModalOpen(false);
    setStatus("");
  };

  const submitQuestion = (event) => {
    event.preventDefault();

    const name = form.patientName.trim();
    const question = form.question.trim();
    const phone = form.phone.trim();

    if (!name || !question) {
      setStatus("Name and question required.");
      return;
    }

    const now = new Date().toISOString();

    const item = {
      id: `qa-${Date.now()}`,
      patientId: getUserPatientId(currentUser),
      patientName: name,
      phone,
      question,
      answer: "",
      status: "pending",
      createdAt: now,
      updatedAt: now,
    };

    const next = mergeQaLists([item], qaItems);

    setQaItems(next);
    savePublicQa(next);
    safeWriteList(PUBLIC_QA_REQUESTS_KEY, next);

    savePublicContent("qa", next).catch(() => {
      // remote optional
    });

    setModalOpen(false);
    setForm({
      patientName: getUserName(currentUser),
      phone: getUserPhone(currentUser),
      question: "",
    });
    setStatus("");
    setToast("Question submitted successfully.");
  };

  return (
    <div className="min-h-svh overflow-hidden bg-gradient-to-b from-[#effafa] via-white to-[#f7fbff] text-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(13,148,136,0.11)_1px,transparent_0)] [background-size:24px_24px]" />

      {toast ? (
        <div className="fixed right-5 top-5 z-[120] flex max-w-sm items-center gap-2 rounded-2xl border border-emerald-100 bg-white px-4 py-3 text-sm font-black text-emerald-700 shadow-2xl">
          <CheckCircle2 size={17} />
          {toast}
        </div>
      ) : null}

      <NavbarRenderer
        profile={profile}
        onAppointment={() => setAppointmentOpen(true)}
      />

      <main className="mx-3 min-h-[70svh] max-w-[1180px] py-8 sm:mx-auto sm:w-[calc(100%_-_28px)] lg:py-10">
        <section className="mb-6 rounded-[32px] border border-cyan-100/80 bg-white/88 p-6 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-teal-700">
              <MessageCircleQuestion size={14} />
              Q&amp;A
            </span>

            <span className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-blue-700">
              <ShieldCheck size={14} />
              Doctor Answered
            </span>
          </div>

          <div className="mt-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h1 className="text-[2.35rem] font-black leading-[1.05] tracking-[-0.05em] text-slate-950 sm:text-[3.4rem] lg:text-[4.15rem]">
                Ask the{" "}
                <span className="bg-gradient-to-r from-teal-700 to-blue-600 bg-clip-text text-transparent">
                  Doctor
                </span>
              </h1>

              <p className="mt-4 max-w-2xl text-[15px] font-semibold leading-8 text-slate-600 sm:text-base">
                Submit your question privately. Doctor answered questions will
                appear here after review.
              </p>
            </div>

            <button
              type="button"
              onClick={openQuestionForm}
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition hover:-translate-y-1"
            >
              <Send size={17} />
              Ask Question
            </button>
          </div>
        </section>

        {submittedQuestions.length ? (
          <section className="mb-6 rounded-[30px] border border-amber-100 bg-amber-50/55 p-4 shadow-sm sm:p-5">
            <h2 className="text-base font-black text-amber-800">
              Your submitted questions
            </h2>

            <div className="mt-3 grid gap-2">
              {submittedQuestions.map((item) => {
                const answered =
                  normalizeStatus(item.status, item.answer) === "answered" &&
                  item.answer;

                return (
                  <article
                    key={item.id}
                    className="rounded-2xl border border-amber-100 bg-white px-4 py-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="text-sm font-black text-slate-900">
                        {item.question}
                      </h3>

                      <span
                        className={`rounded-full px-2.5 py-1 text-[10px] font-black ${
                          answered
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-amber-50 text-amber-700"
                        }`}
                      >
                        {answered ? "Answered" : "Pending review"} •{" "}
                        {formatDateTime(item.updatedAt || item.createdAt)}
                      </span>
                    </div>

                    {answered ? (
                      <div className="mt-3 rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-3">
                        <p className="text-[11px] font-black uppercase tracking-wide text-emerald-700">
                          Doctor Answer
                        </p>
                        <p className="mt-1 text-sm font-semibold leading-7 text-slate-700">
                          {item.answer}
                        </p>
                      </div>
                    ) : null}
                  </article>
                );
              })}
            </div>
          </section>
        ) : null}

        <section className="rounded-[30px] border border-cyan-100/80 bg-white/90 p-5 shadow-[0_16px_42px_rgba(11,86,90,0.08)] backdrop-blur-xl">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-cyan-100 pb-4">
            <div>
              <h2 className="text-2xl font-black text-slate-950">
                Common Questions
              </h2>
              <p className="mt-1 text-sm font-semibold text-slate-500">
                List style: number → question → answer.
              </p>
            </div>

            <span className="rounded-full bg-teal-50 px-3 py-1 text-xs font-black text-teal-700">
              {publicAnsweredQuestions.length} answered
            </span>
          </div>

          <div className="grid gap-3">
            {publicAnsweredQuestions.map((item, index) => (
              <article
                key={item.id || item.question}
                className="group rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-md"
              >
                <div className="grid gap-4 md:grid-cols-[52px_1fr_32px_1.2fr] md:items-start">
                  <span className="grid h-11 w-11 place-items-center rounded-2xl bg-cyan-50 text-sm font-black text-teal-700">
                    {String(index + 1).padStart(2, "0")}
                  </span>

                  <div>
                    <span className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wide text-teal-700">
                      <HelpCircle size={13} />
                      Question
                    </span>
                    <h3 className="mt-2 text-base font-black leading-7 text-slate-950">
                      {item.question}
                    </h3>
                  </div>

                  <div className="hidden justify-center pt-8 text-blue-600 md:flex">
                    <ArrowRight
                      size={20}
                      className="transition group-hover:translate-x-1"
                    />
                  </div>

                  <div className="border-t border-cyan-100 pt-4 md:border-l md:border-t-0 md:pl-5 md:pt-0">
                    <span className="text-xs font-black uppercase tracking-wide text-blue-700">
                      Answer
                    </span>

                    <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
                      {item.answer}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>

      <FooterRenderer profile={profile} />

      <AppointmentModal
        open={appointmentOpen}
        onClose={() => setAppointmentOpen(false)}
      />

      {modalOpen ? (
        <div
          className="fixed inset-0 z-[100] grid place-items-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closeQuestionForm();
          }}
        >
          <form
            onSubmit={submitQuestion}
            onMouseDown={(event) => event.stopPropagation()}
            className="w-full max-w-lg rounded-[30px] border border-cyan-100 bg-white p-5 shadow-2xl"
          >
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.2em] text-cyan-600">
                  Ask Doctor
                </p>
                <h2 className="mt-1 text-2xl font-black text-slate-950">
                  Submit a Question
                </h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">
                  Login থাকলে name/phone auto fill হবে।
                </p>
              </div>

              <button
                type="button"
                onClick={closeQuestionForm}
                className="group grid h-10 w-10 place-items-center rounded-2xl text-slate-400 transition hover:-translate-y-0.5 hover:bg-red-50 hover:text-red-600"
              >
                <X
                  size={24}
                  className="transition-transform duration-300 group-hover:rotate-90"
                />
              </button>
            </div>

            <div className="grid gap-4">
              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Name
                <div className="relative">
                  <UserRound
                    size={17}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-teal-600"
                  />
                  <input
                    className={`${inputClass} pl-11`}
                    placeholder="Your name"
                    value={form.patientName}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        patientName: event.target.value,
                      }))
                    }
                  />
                </div>
              </label>

              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Phone
                <div className="relative">
                  <Phone
                    size={17}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-teal-600"
                  />
                  <input
                    className={`${inputClass} pl-11`}
                    placeholder="Phone number"
                    value={form.phone}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        phone: event.target.value,
                      }))
                    }
                  />
                </div>
              </label>

              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Question
                <textarea
                  className={`${inputClass} min-h-32 resize-y`}
                  placeholder="Write your question..."
                  value={form.question}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      question: event.target.value,
                    }))
                  }
                />
              </label>
            </div>

            {status ? (
              <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm font-extrabold text-red-700">
                {status}
              </p>
            ) : null}

            <button
              type="submit"
              className="mt-5 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-5 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition hover:-translate-y-1"
            >
              <Send size={17} />
              Submit Question
            </button>
          </form>
        </div>
      ) : null}
    </div>
  );
};

export default PublicQaPage;
