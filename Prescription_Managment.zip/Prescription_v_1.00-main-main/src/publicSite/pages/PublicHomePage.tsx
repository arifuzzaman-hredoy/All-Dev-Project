import { useEffect, useState } from "react";
import AppointmentModal from "../components/AppointmentModal";
import { getAnsweredQa, getPublicGallery, getPublicProfile, getPublicServices, getPublishedBlogs } from "../lib/publicStorage";
import { usePublicTheme } from "../lib/usePublicTheme";
import AppointmentRenderer from "../theme/appointment/AppointmentRenderer";
import BlogsRenderer from "../theme/blogs/BlogsRenderer";
import ContactRenderer from "../theme/contact/ContactRenderer";
import DoctorsRenderer from "../theme/doctors/DoctorsRenderer";
import FooterRenderer from "../theme/footer/FooterRenderer";
import GalleryRenderer from "../theme/gallery/GalleryRenderer";
import HeroRenderer from "../theme/hero/HeroRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import QaRenderer from "../theme/qa/QaRenderer";
import ServicesRenderer from "../theme/services/ServicesRenderer";

const PublicHomePage = () => {
  const [profile, setProfile] = useState(getPublicProfile);
  const [blogs, setBlogs] = useState(getPublishedBlogs);
  const [qa, setQa] = useState(getAnsweredQa);
  const [gallery, setGallery] = useState(getPublicGallery);
  const [services, setServices] = useState(getPublicServices);
  const [modalOpen, setModalOpen] = useState(false);
  const { themeSettings, themeStyle } = usePublicTheme();

  useEffect(() => {
    const sync = () => {
      setProfile(getPublicProfile());
      setBlogs(getPublishedBlogs());
      setQa(getAnsweredQa());
      setGallery(getPublicGallery());
      setServices(getPublicServices());
    };
    window.addEventListener("carebridge-storage-updated", sync);
    return () => window.removeEventListener("carebridge-storage-updated", sync);
  }, []);

  return (
    <div className="min-h-svh text-slate-900" style={themeStyle}>
      <NavbarRenderer
        profile={profile}
        themeSettings={themeSettings}
        onAppointment={() => setModalOpen(true)}
      />
      <main>
        <HeroRenderer
          profile={profile}
          themeSettings={themeSettings}
          onAppointment={() => setModalOpen(true)}
        />
        <DoctorsRenderer profile={profile} themeSettings={themeSettings} />
        <ServicesRenderer
          profile={profile}
          services={services}
          themeSettings={themeSettings}
        />
        <AppointmentRenderer
          profile={profile}
          themeSettings={themeSettings}
          onAppointment={() => setModalOpen(true)}
        />
        <BlogsRenderer blogs={blogs.slice(0, 2)} themeSettings={themeSettings} />
        <QaRenderer qa={qa.slice(0, 2)} themeSettings={themeSettings} />
        <GalleryRenderer gallery={gallery.slice(0, 2)} themeSettings={themeSettings} />
        <ContactRenderer
          profile={profile}
          themeSettings={themeSettings}
          onAppointment={() => setModalOpen(true)}
        />
      </main>
      <button type="button" className="fixed bottom-4 right-4 z-40 inline-flex rounded-full bg-teal-800 px-5 py-3 text-sm font-black text-white shadow-xl lg:hidden" onClick={() => setModalOpen(true)}>Appointment</button>
      <FooterRenderer profile={profile} themeSettings={themeSettings} />
      <AppointmentModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default PublicHomePage;
