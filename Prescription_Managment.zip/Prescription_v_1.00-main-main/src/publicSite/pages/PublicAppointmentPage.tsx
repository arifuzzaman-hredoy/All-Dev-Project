import { useState } from "react";
import AppointmentModal from "../components/AppointmentModal";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import PublicSectionHeader from "../components/PublicSectionHeader";
import { getPublicProfile } from "../lib/publicStorage";

const PublicAppointmentPage = () => {
  const [profile] = useState(getPublicProfile);
  const [modalOpen, setModalOpen] = useState(true);
  return (
    <div className="min-h-svh bg-gradient-to-b from-cyan-50 via-white to-white text-slate-900">
      <NavbarRenderer profile={profile} onAppointment={() => setModalOpen(true)} />
      <main className="mx-auto min-h-[70svh] w-[min(1180px,calc(100%-1rem))] py-12 sm:w-[min(1180px,calc(100%-1.75rem))]">
        <PublicSectionHeader eyebrow="Appointment" title="Request a chamber visit" description={`${profile.visitingDays}, ${profile.visitingTime}`} />
        <section className="rounded-[1.5rem] border border-teal-100 bg-white/80 p-6 shadow-[0_14px_36px_rgba(11,86,90,0.09)]">
          <h3 className="text-2xl font-black tracking-tight text-slate-900">{profile.chamberName}</h3>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{profile.chamberAddress}</p>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{profile.emergencyNotice}</p>
          <button type="button" className="mt-5 inline-flex min-h-11 items-center justify-center rounded-full bg-gradient-to-r from-teal-700 to-cyan-500 px-5 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-cyan-300" onClick={() => setModalOpen(true)}>{profile.ctaText}</button>
        </section>
      </main>
      <FooterRenderer profile={profile} />
      <AppointmentModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default PublicAppointmentPage;
