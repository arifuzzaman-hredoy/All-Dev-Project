import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import AppointmentModal from "../components/AppointmentModal";
import EmptyPublicState from "../components/EmptyPublicState";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import { formatDate } from "../lib/dateFormat";
import { getBlogBySlug, getPublicProfile } from "../lib/publicStorage";

const PublicBlogDetailsPage = () => {
  const { slug } = useParams();
  const [profile] = useState(getPublicProfile);
  const [modalOpen, setModalOpen] = useState(false);
  const blog = getBlogBySlug(slug);

  return (
    <div className="min-h-svh bg-gradient-to-b from-cyan-50 via-white to-white text-slate-900">
      <NavbarRenderer profile={profile} onAppointment={() => setModalOpen(true)} />
      <main className="mx-auto min-h-[70svh] w-[min(1180px,calc(100%-1rem))] py-12 sm:w-[min(1180px,calc(100%-1.75rem))]">
        {blog ? (
          <article className="mx-auto grid max-w-4xl gap-4">
            <img className="max-h-[430px] w-full rounded-[1.5rem] object-cover" src={blog.coverImageUrl} alt={blog.title} />
            <span className="text-xs font-black uppercase tracking-wide text-teal-700">{blog.category} • {formatDate(blog.publishDate)}</span>
            <h1 className="text-4xl font-black tracking-tight text-slate-900 md:text-5xl">{blog.title}</h1>
            <p className="text-base font-semibold leading-8 text-slate-600">{blog.content}</p>
            <Link className="inline-flex w-fit min-h-11 items-center justify-center rounded-full border border-teal-100 bg-white px-5 text-sm font-black text-teal-700 shadow-sm transition hover:bg-cyan-50 focus:outline-none focus:ring-2 focus:ring-cyan-300" to="/blogs">Back to blogs</Link>
          </article>
        ) : (
          <EmptyPublicState title="Blog not found" message="This article may be unpublished or removed." />
        )}
      </main>
      <FooterRenderer profile={profile} />
      <AppointmentModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default PublicBlogDetailsPage;
