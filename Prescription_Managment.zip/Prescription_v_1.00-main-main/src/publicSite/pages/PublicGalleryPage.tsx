import { useState } from "react";
import AppointmentModal from "../components/AppointmentModal";
import EmptyPublicState from "../components/EmptyPublicState";
import FooterRenderer from "../theme/footer/FooterRenderer";
import PublicGalleryCard from "../components/PublicGalleryCard";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import PublicSectionHeader from "../components/PublicSectionHeader";
import { getPublicGallery, getPublicProfile } from "../lib/publicStorage";

const PublicGalleryPage = () => {
  const [profile] = useState(getPublicProfile);
  const [gallery] = useState(getPublicGallery);
  const [modalOpen, setModalOpen] = useState(false);
  return (
    <div className="min-h-svh bg-gradient-to-b from-cyan-50 via-white to-white text-slate-900">
      <NavbarRenderer profile={profile} onAppointment={() => setModalOpen(true)} />
      <main className="mx-auto min-h-[70svh] w-[min(1180px,calc(100%-1rem))] py-12 sm:w-[min(1180px,calc(100%-1.75rem))]">
        <PublicSectionHeader eyebrow="Gallery" title="Chamber Gallery" description="Photos and media from the doctor brand." />
        {gallery.length ? (
          <div className="grid gap-4 md:grid-cols-2">{gallery.map((item) => <PublicGalleryCard key={item.id} item={item} />)}</div>
        ) : (
          <EmptyPublicState title="No gallery items" message="Gallery updates will appear here." />
        )}
      </main>
      <FooterRenderer profile={profile} />
      <AppointmentModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default PublicGalleryPage;
