import { useState } from "react";
import {
  ArrowRight,
  BookOpenCheck,
  CalendarDays,
  Newspaper,
  PenLine,
  Sparkles,
} from "lucide-react";
import AppointmentModal from "../components/AppointmentModal";
import EmptyPublicState from "../components/EmptyPublicState";
import PublicBlogCard from "../components/PublicBlogCard";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import { getPublicProfile, getPublishedBlogs } from "../lib/publicStorage";

const PublicBlogsPage = () => {
  const [profile] = useState(getPublicProfile);
  const [blogs] = useState(getPublishedBlogs);
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div className="min-h-svh overflow-hidden bg-gradient-to-b from-[#effafa] via-white to-[#f7fbff] text-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(13,148,136,0.11)_1px,transparent_0)] [background-size:24px_24px]" />
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[linear-gradient(to_right,rgba(14,165,233,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(14,165,233,0.04)_1px,transparent_1px)] [background-size:82px_82px]" />
      <div className="pointer-events-none fixed -left-40 -top-40 -z-10 h-[430px] w-[430px] rounded-full bg-cyan-200/35 blur-3xl" />
      <div className="pointer-events-none fixed -right-44 bottom-[-170px] -z-10 h-[460px] w-[460px] rounded-full bg-blue-200/30 blur-3xl" />

      <NavbarRenderer
        profile={profile}
        onAppointment={() => setModalOpen(true)}
      />

      <main className="mx-3 min-h-[70svh] max-w-[1180px] py-8 sm:mx-auto sm:w-[calc(100%_-_28px)] lg:py-10">
        <section className="relative overflow-hidden rounded-[32px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-7 lg:p-8">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan-100/70 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-28 left-1/3 h-72 w-72 rounded-full bg-blue-100/60 blur-3xl" />

          <div className="relative grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50/85 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-teal-700">
                  <Newspaper size={14} />
                  Blogs
                </span>

                <span className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50/80 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-blue-700">
                  <Sparkles size={14} />
                  Patient Notes
                </span>
              </div>

              <h1 className="mt-5 max-w-3xl text-[2.35rem] font-black leading-[1.05] tracking-[-0.05em] text-slate-950 sm:text-[3.4rem] lg:text-[4.15rem]">
                Health{" "}
                <span className="bg-gradient-to-r from-blue-700 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
                  Articles
                </span>
              </h1>

              <p className="mt-4 max-w-2xl text-[15px] font-semibold leading-8 text-slate-600 sm:text-base">
                Short, practical notes for patients and families. Read simple
                health guidance before or after your chamber visit.
              </p>

              <div className="mt-5 flex flex-wrap gap-3">
                <div className="inline-flex items-center gap-2 rounded-2xl border border-cyan-100 bg-white/85 px-4 py-3 text-sm font-black text-slate-700 shadow-sm backdrop-blur">
                  <BookOpenCheck size={17} className="text-teal-600" />
                  {blogs.length} Published Article{blogs.length === 1 ? "" : "s"}
                </div>

                <div className="inline-flex items-center gap-2 rounded-2xl border border-cyan-100 bg-white/85 px-4 py-3 text-sm font-black text-slate-700 shadow-sm backdrop-blur">
                  <PenLine size={17} className="text-blue-600" />
                  Practical Health Tips
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:shadow-[0_22px_44px_rgba(20,102,242,0.30)] focus:outline-none"
            >
              <CalendarDays
                size={17}
                className="transition duration-300 group-hover:-rotate-6"
              />
              Book Appointment
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>
        </section>

        <section className="mt-6">
          {blogs.length ? (
            <div className="grid gap-4 md:grid-cols-2">
              {blogs.map((blog) => (
                <div
                  key={blog.id}
                  className="transition duration-300 hover:-translate-y-1 hover:rotate-[0.25deg]"
                >
                  <PublicBlogCard blog={blog} />
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-[32px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.07)] backdrop-blur-xl sm:p-8">
              <EmptyPublicState
                title="No published blogs"
                message="Published articles will appear here."
              />
            </div>
          )}
        </section>
      </main>

      <FooterRenderer profile={profile} />

      <AppointmentModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </div>
  );
};

export default PublicBlogsPage; 