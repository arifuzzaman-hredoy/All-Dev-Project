import { useState } from "react";
import AppointmentModal from "../components/AppointmentModal";
import ContactMessageForm from "../components/ContactMessageForm";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import PublicSectionHeader from "../components/PublicSectionHeader";
import { getPublicProfile } from "../lib/publicStorage";

const PublicContactPage = () => {
  const [profile] = useState(getPublicProfile);
  const [modalOpen, setModalOpen] = useState(false);
  return (
    <div className="min-h-svh bg-gradient-to-b from-cyan-50 via-white to-white text-slate-900">
      <NavbarRenderer profile={profile} onAppointment={() => setModalOpen(true)} />
      <main className="mx-auto min-h-[70svh] w-[min(1180px,calc(100%-1rem))] py-12 sm:w-[min(1180px,calc(100%-1.75rem))]">
        <PublicSectionHeader eyebrow="Contact" title="Chamber & Message" description="For urgent symptoms, visit emergency care first." />
        <section className="grid gap-4 md:grid-cols-2">
          <article className="rounded-[1.5rem] border border-teal-100 bg-white/80 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.09)]">
            <h3 className="text-2xl font-black tracking-tight text-slate-900">{profile.chamberName}</h3>
            <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{profile.chamberAddress}</p>
            <p className="mt-2 text-sm font-semibold text-slate-600">{profile.phone}</p>
            <p className="mt-1 text-sm font-semibold text-slate-600">{profile.email}</p>
            <div className="mt-5 grid min-h-56 place-items-center rounded-[1.25rem] border border-dashed border-teal-200 bg-cyan-50 text-sm font-black text-slate-500">Map placeholder</div>
          </article>
          <ContactMessageForm />
        </section>
      </main>
      <FooterRenderer profile={profile} />
      <AppointmentModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default PublicContactPage;
