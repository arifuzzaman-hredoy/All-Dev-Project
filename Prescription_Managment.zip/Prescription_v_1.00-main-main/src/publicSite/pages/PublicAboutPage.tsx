import { useMemo, useState } from "react";
import {
  ArrowRight,
  Award,
  BadgeCheck,
  Brain,
  CalendarDays,
  CheckCircle2,
  Clock,
  FileText,
  GraduationCap,
  HeartPulse,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Stethoscope,
  Users,
} from "lucide-react";
import { Link } from "react-router-dom";
import AppointmentModal from "../components/AppointmentModal";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import { getPublicProfile } from "../lib/publicStorage";

const fallbackDoctorImage =
  "https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=900&auto=format&fit=crop";

const getValue = (value, fallback) => value || fallback;

const PublicAboutPage = () => {
  const [profile] = useState(getPublicProfile);
  const [modalOpen, setModalOpen] = useState(false);

  const doctorName = getValue(
    profile.doctorName,
    "Professor Dr. Md. Tofael Hossain Bhuiyan"
  );

  const doctorTitle = getValue(profile.title, "Consultant Neuro Surgeon");

  const specialization = getValue(
    profile.specialization,
    "Brain, Nerve, Spine & Stroke Specialist"
  );

  const doctorImage =
    profile.profileImageUrl || profile.heroImageUrl || fallbackDoctorImage;

  const shortBio = getValue(
    profile.shortBio,
    "Brain, nerve, spine and stroke care with calm clinical guidance. রোগীর কথা শুনে evidence-based treatment plan করা হয়।"
  );

  const stats = [
    {
      value: getValue(profile.totalPatients, "50k+"),
      label: "Happy Patient",
      Icon: Users,
    },
    {
      value: getValue(profile.totalExperience, "15+"),
      label: "Years Experience",
      Icon: Award,
    },
    {
      value: getValue(profile.successRate, "98%"),
      label: "Patient Trust",
      Icon: ShieldCheck,
    },
  ];

  const infoCards = useMemo(
    () => [
      {
        title: "Qualification",
        first: specialization,
        second: doctorTitle,
        Icon: GraduationCap,
      },
      {
        title: "Chamber",
        first: getValue(profile.chamberName, "Dhanmondi Branch, Room 302"),
        second: getValue(profile.chamberAddress, "Dhaka, Bangladesh"),
        Icon: MapPin,
      },
      {
        title: "Schedule",
        first: getValue(profile.visitingDays, "Saturday - Thursday"),
        second: getValue(profile.visitingTime, "09:00 AM - 01:00 PM"),
        Icon: Clock,
      },
    ],
    [
      doctorTitle,
      profile.chamberAddress,
      profile.chamberName,
      profile.visitingDays,
      profile.visitingTime,
      specialization,
    ]
  );

  const strengths = [
    {
      title: "Specialized Neuro Care",
      text: "Brain, nerve, spine and stroke related cases are handled with focused clinical judgement.",
      Icon: Brain,
    },
    {
      title: "Clear Patient Guidance",
      text: "Patients get practical explanation, next steps and follow-up direction without confusion.",
      Icon: MessageCircle,
    },
    {
      title: "Evidence Based Plan",
      text: "Treatment planning stays grounded in history, examination, reports and patient condition.",
      Icon: BadgeCheck,
    },
  ];

  const careSteps = [
    "Patient history and symptoms review",
    "Report and investigation assessment",
    "Diagnosis explanation in simple language",
    "Treatment plan and follow-up guidance",
  ];

  return (
    <div className="min-h-svh overflow-hidden bg-gradient-to-b from-[#effafa] via-white to-[#f7fcff] text-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(13,148,136,0.12)_1px,transparent_0)] [background-size:24px_24px]" />
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[linear-gradient(to_right,rgba(14,165,233,0.045)_1px,transparent_1px),linear-gradient(to_bottom,rgba(14,165,233,0.045)_1px,transparent_1px)] [background-size:82px_82px]" />
      <div className="pointer-events-none fixed -left-40 -top-40 -z-10 h-[430px] w-[430px] rounded-full bg-cyan-200/35 blur-3xl" />
      <div className="pointer-events-none fixed -right-44 bottom-[-170px] -z-10 h-[460px] w-[460px] rounded-full bg-blue-200/30 blur-3xl" />

      <NavbarRenderer
        profile={profile}
        onAppointment={() => setModalOpen(true)}
      />

      <main className="mx-3 max-w-[1180px] py-8 sm:mx-auto sm:w-[calc(100%_-_28px)] lg:py-10">
        <section className="grid gap-6 lg:grid-cols-[430px_minmax(0,1fr)] lg:items-start">
          <div className="space-y-4">
            <img
              src={doctorImage}
              alt={doctorName}
              onError={(event) => {
                event.currentTarget.src = fallbackDoctorImage;
              }}
              className="h-[360px] w-full rounded-[32px] object-cover object-center shadow-[0_24px_58px_rgba(15,69,82,0.15)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.35deg] sm:h-[460px] lg:h-[520px]"
            />

            <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
              {stats.map(({ value, label, Icon: StatIcon }) => (
                <article
                  key={label}
                  className="group rounded-[24px] border border-cyan-100/80 bg-white/82 p-4 shadow-[0_12px_30px_rgba(11,86,90,0.07)] backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:bg-white hover:shadow-lg"
                >
                  <StatIcon
                    size={18}
                    className="text-teal-600 transition duration-300 group-hover:-rotate-6 group-hover:text-blue-600"
                  />
                  <strong className="mt-3 block text-2xl font-black tracking-tight text-slate-950">
                    {value}
                  </strong>
                  <span className="mt-1 block text-xs font-bold text-slate-500">
                    {label}
                  </span>
                </article>
              ))}
            </div>
          </div>

          <section className="rounded-[32px] border border-cyan-100/80 bg-white/86 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-7 lg:p-8">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50/90 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-teal-700">
                <Stethoscope size={14} />
                Doctor Profile
              </span>

              <span className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50/80 px-3.5 py-2 text-xs font-black uppercase tracking-wide text-blue-700">
                <HeartPulse size={14} />
                Specialist Care
              </span>
            </div>

            <h1 className="mt-5 max-w-3xl text-[2.15rem] font-black leading-[1.06] tracking-[-0.045em] text-slate-950 sm:text-[3.05rem] lg:text-[3.7rem]">
              {doctorName}
            </h1>

            <p className="mt-3 max-w-3xl text-base font-black leading-7 text-teal-700">
              {doctorTitle}
            </p>

            <p className="mt-2 max-w-3xl text-sm font-bold leading-7 text-slate-500 sm:text-[15px]">
              {specialization}
            </p>

            <div className="my-6 h-px w-full bg-gradient-to-r from-transparent via-cyan-200 to-transparent" />

            <p className="max-w-3xl text-[15px] font-semibold leading-8 text-slate-600">
              {shortBio}
            </p>

            <div className="mt-6 grid gap-3 md:grid-cols-3">
              {infoCards.map(({ title, first, second, Icon: InfoIcon }) => (
                <article
                  key={title}
                  className="group rounded-[24px] border border-slate-100 bg-slate-50/75 p-4 transition duration-300 hover:-translate-y-0.5 hover:rotate-[0.35deg] hover:border-cyan-100 hover:bg-white hover:shadow-md"
                >
                  <InfoIcon
                    size={20}
                    className="text-teal-600 transition duration-300 group-hover:-rotate-6 group-hover:text-blue-600"
                  />

                  <h2 className="mt-3 text-sm font-black uppercase tracking-wide text-slate-950">
                    {title}
                  </h2>

                  <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
                    {first}
                  </p>

                  <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
                    {second}
                  </p>
                </article>
              ))}
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setModalOpen(true)}
                className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:shadow-[0_22px_44px_rgba(20,102,242,0.30)] focus:outline-none"
              >
                <CalendarDays
                  size={17}
                  className="transition duration-300 group-hover:-rotate-6"
                />
                Book Appointment
                <ArrowRight
                  size={17}
                  className="transition duration-300 group-hover:translate-x-1"
                />
              </button>

              <Link
                to="/contact"
                className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl border border-cyan-100 bg-white px-6 text-sm font-black text-slate-700 shadow-sm transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:border-blue-100 hover:text-blue-600 hover:shadow-md focus:outline-none"
              >
                <Phone
                  size={17}
                  className="transition duration-300 group-hover:-rotate-6"
                />
                Contact Chamber
              </Link>
            </div>
          </section>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
          <section className="rounded-[32px] border border-cyan-100/80 bg-white/84 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.07)] backdrop-blur-xl sm:p-7">
            <div className="flex items-center gap-2">
              <FileText size={18} className="text-teal-600" />
              <h2 className="text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">
                Consultation Flow
              </h2>
            </div>

            <p className="mt-3 max-w-2xl text-sm font-semibold leading-7 text-slate-600">
              Simple, clear and patient-friendly process from first discussion to
              follow-up plan.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {careSteps.map((step, index) => (
                <article
                  key={step}
                  className="group rounded-[24px] border border-slate-100 bg-slate-50/75 p-4 transition duration-300 hover:-translate-y-0.5 hover:rotate-[0.35deg] hover:border-cyan-100 hover:bg-white hover:shadow-md"
                >
                  <div className="flex items-start gap-3">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-white text-sm font-black text-teal-700 shadow-sm">
                      {index + 1}
                    </span>

                    <div>
                      <CheckCircle2
                        size={18}
                        className="text-teal-600 transition duration-300 group-hover:-rotate-6 group-hover:text-blue-600"
                      />
                      <p className="mt-2 text-sm font-bold leading-6 text-slate-600">
                        {step}
                      </p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="grid gap-3">
            {strengths.map(({ title, text, Icon: StrengthIcon }) => (
              <article
                key={title}
                className="group rounded-[28px] border border-cyan-100/80 bg-white/84 p-5 shadow-[0_14px_36px_rgba(11,86,90,0.06)] backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:bg-white hover:shadow-xl"
              >
                <div className="flex items-start gap-3">
                  <StrengthIcon
                    size={22}
                    className="mt-0.5 shrink-0 text-blue-600 transition duration-300 group-hover:-rotate-6 group-hover:text-teal-600"
                  />

                  <div>
                    <h3 className="text-base font-black text-slate-950">
                      {title}
                    </h3>
                    <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
                      {text}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </section>
        </section>

        <section className="mt-6 overflow-hidden rounded-[32px] border border-cyan-100/80 bg-gradient-to-r from-white via-cyan-50 to-blue-50 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.07)] sm:p-7">
          <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-white/80 px-3 py-2 text-xs font-black uppercase tracking-wide text-teal-700 shadow-sm">
                <CalendarDays size={14} />
                Appointment
              </div>

              <h2 className="mt-4 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">
                Need a specialist consultation?
              </h2>

              <p className="mt-2 max-w-2xl text-sm font-semibold leading-7 text-slate-600">
                Book an appointment and confirm chamber schedule before visiting.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="group inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.22)] transition duration-300 hover:-translate-y-1 hover:rotate-[0.45deg] hover:shadow-[0_22px_44px_rgba(20,102,242,0.30)] focus:outline-none"
            >
              <CalendarDays
                size={17}
                className="transition duration-300 group-hover:-rotate-6"
              />
              Book Appointment
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>
        </section>
      </main>

      <FooterRenderer profile={profile} />

      <AppointmentModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </div>
  );
};

export default PublicAboutPage;