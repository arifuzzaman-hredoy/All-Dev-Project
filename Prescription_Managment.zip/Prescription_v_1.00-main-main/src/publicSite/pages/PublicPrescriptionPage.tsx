import { useMemo, useState } from "react";
import {
  AlertCircle,
  ArrowRight,
  BadgeCheck,
  CalendarDays,
  CheckCircle2,
  Download,
  FileText,
  KeyRound,
  LockKeyhole,
  Phone,
  Printer,
  RefreshCcw,
  Search,
  ShieldCheck,
  Sparkles,
  UnlockKeyhole,
  UserRound,
} from "lucide-react";
import AppointmentModal from "../components/AppointmentModal";
import FooterRenderer from "../theme/footer/FooterRenderer";
import NavbarRenderer from "../theme/navbar/NavbarRenderer";
import { buildApiUrl } from "../../lib/apiClient";
import {
  sendPrescriptionOtp,
  verifyPrescriptionOtp,
} from "../../services/prescriptionApi";
import { useDoctorIdentity } from "../../hooks/useDoctorIdentity";

const LOCAL_DEMO_OTP = "123456";

const emptyForm = {
  lookup: "",
  phone: "",
  otp: "",
};

const inputClass =
  "w-full rounded-2xl border border-cyan-100 bg-white px-4 py-3 text-sm font-bold text-slate-800 outline-none transition duration-300 placeholder:text-slate-400 focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100";

const iconAnim =
  "transition duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6";

const getValue = (item, keys, fallback = "") => {
  const record = item || {};

  for (const key of keys) {
    const value = record[key];

    if (value !== undefined && value !== null && String(value).trim() !== "") {
      return String(value);
    }
  }

  return fallback;
};

const getPrescriptionId = (item) => {
  return getValue(item, ["id", "_id", "prescriptionId"], `rx-${Date.now()}`);
};

const getPatientName = (item) => {
  return getValue(item, ["patientName", "name", "patient", "fullName"], "Patient");
};

const getPatientId = (item) => {
  return getValue(
    item,
    ["patientId", "patientID", "serialNo", "registrationNo"],
    "-"
  );
};

const getPhone = (item) => {
  return getValue(item, ["phone", "mobile", "phoneNumber", "contact"], "-");
};

const getDate = (item) => {
  return getValue(
    item,
    ["prescriptionDate", "date", "createdAt", "uploadedAt"],
    "-"
  );
};

const getDoctorName = (item) => {
  return getValue(item, ["doctorName", "doctor", "createdBy"], "Not specified");
};

const getFileName = (item) => {
  return getValue(item, ["fileName", "filename", "originalName", "title"], "Prescription");
};

const getStatus = (item) => {
  return getValue(item, ["status", "uploadStatus"], "Uploaded");
};

const getDownloadPath = (item) => {
  return getValue(
    item,
    ["downloadUrl", "fileUrl", "url", "path", "prescriptionUrl"],
    ""
  );
};

const getDownloadHref = (item) => {
  const url = getDownloadPath(item);

  if (!url) return "";

  if (
    url.startsWith("http://") ||
    url.startsWith("https://") ||
    url.startsWith("data:") ||
    url.startsWith("blob:")
  ) {
    return url;
  }

  return buildApiUrl(url);
};

const formatDate = (value) => {
  if (!value || value === "-") return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const normalizePrescription = (item, index = 0) => {
  return {
    ...item,
    id: getPrescriptionId(item) || `local-rx-${index}-${Date.now()}`,
    patientName: getPatientName(item),
    patientId: getPatientId(item),
    phone: getPhone(item),
    prescriptionDate: getDate(item),
    doctorName: getDoctorName(item),
    fileName: getFileName(item),
    status: getStatus(item),
    downloadUrl: getDownloadPath(item),
  };
};

const looksLikePrescription = (item) => {
  if (!item || typeof item !== "object" || Array.isArray(item)) return false;

  const text = [
    item.patientName,
    item.patientId,
    item.phone,
    item.fileName,
    item.downloadUrl,
    item.prescriptionDate,
    item.prescriptionId,
  ]
    .join(" ")
    .toLowerCase();

  return (
    text.includes("prescription") ||
    Boolean(item.patientName && item.phone) ||
    Boolean(item.patientId && item.fileName) ||
    Boolean(item.downloadUrl || item.fileUrl || item.prescriptionUrl)
  );
};

const collectPrescriptionObjects = (value, list = [], depth = 0) => {
  if (depth > 4 || !value) return list;

  if (Array.isArray(value)) {
    value.forEach((entry) => collectPrescriptionObjects(entry, list, depth + 1));
    return list;
  }

  if (typeof value === "object") {
    if (looksLikePrescription(value)) {
      list.push(value);
      return list;
    }

    Object.values(value).forEach((entry) =>
      collectPrescriptionObjects(entry, list, depth + 1)
    );
  }

  return list;
};

const scanLocalPrescriptions = () => {
  if (typeof window === "undefined") return [];

  const results = [];

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);

    if (!key) continue;

    try {
      const raw = window.localStorage.getItem(key);
      const parsed = raw ? JSON.parse(raw) : null;
      collectPrescriptionObjects(parsed, results);
    } catch {
      // ignore non JSON localStorage data
    }
  }

  const map = new Map();

  results.map(normalizePrescription).forEach((item) => {
    const uniqueKey = [
      getPatientId(item),
      getPhone(item),
      getFileName(item),
      getDate(item),
    ].join("|");

    if (!map.has(uniqueKey)) {
      map.set(uniqueKey, item);
    }
  });

  return Array.from(map.values());
};

const matchesLookup = (item, lookup, phone) => {
  const keyword = String(lookup || "").trim().toLowerCase();
  const phoneText = String(phone || "").replace(/\s+/g, "");
  const itemPhone = getPhone(item).replace(/\s+/g, "");

  const searchable = [
    getPatientName(item),
    getPatientId(item),
    getFileName(item),
    getDoctorName(item),
    getStatus(item),
  ]
    .join(" ")
    .toLowerCase();

  const matchesKeyword = keyword ? searchable.includes(keyword) : true;
  const matchesPhone = phoneText ? itemPhone.includes(phoneText) : true;

  return matchesKeyword && matchesPhone;
};

const PublicPrescriptionPage = () => {
  const { identity: profile } = useDoctorIdentity();
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState(emptyForm);
  const [otpSent, setOtpSent] = useState(false);
  const [verified, setVerified] = useState(false);
  const [showPrescription, setShowPrescription] = useState(false);
  const [status, setStatus] = useState("");
  const [statusTone, setStatusTone] = useState("info");
  const [loading, setLoading] = useState(false);
  const [localMode, setLocalMode] = useState(false);
  const [localMatches, setLocalMatches] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);

  const lookupText = form.lookup.trim();
  const phoneText = form.phone.trim();

  const resultCount = prescriptions.length;

  const statusStyle = useMemo(() => {
    if (statusTone === "success") {
      return "border-emerald-100 bg-emerald-50 text-emerald-700";
    }

    if (statusTone === "error") {
      return "border-rose-100 bg-rose-50 text-rose-700";
    }

    return "border-cyan-100 bg-cyan-50 text-slate-700";
  }, [statusTone]);

  const updateField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));

    if (key === "lookup" || key === "phone") {
      setOtpSent(false);
      setVerified(false);
      setShowPrescription(false);
      setStatus("");
      setPrescriptions([]);
      setLocalMode(false);
      setLocalMatches([]);
    }
  };

  const showAlert = (message, tone = "info") => {
    setStatus(message);
    setStatusTone(tone);
  };

  const sendOtp = async (event) => {
    event?.preventDefault?.();

    if (!lookupText || !phoneText) {
      showAlert("Patient ID / Name এবং Phone number দিন।", "error");
      return;
    }

    setLoading(true);

    try {
      const response = await sendPrescriptionOtp({
        patientId: lookupText,
        patientName: lookupText,
        name: lookupText,
        phone: phoneText,
      });

      setOtpSent(true);
      setVerified(false);
      setShowPrescription(false);
      setPrescriptions([]);
      setLocalMode(false);

      showAlert(
        response.demoOtp
          ? `OTP sent successfully. Demo OTP: ${response.demoOtp}`
          : "OTP sent successfully. Please check phone.",
        "success"
      );
    } catch (error) {
      const localData = scanLocalPrescriptions().filter((item) =>
        matchesLookup(item, lookupText, phoneText)
      );

      if (localData.length) {
        setOtpSent(true);
        setVerified(false);
        setShowPrescription(false);
        setPrescriptions([]);
        setLocalMode(true);
        setLocalMatches(localData);

        showAlert(
          `Prescription found locally. Demo OTP: ${LOCAL_DEMO_OTP}`,
          "success"
        );
      } else {
        setOtpSent(false);
        setVerified(false);
        setShowPrescription(false);
        setPrescriptions([]);
        setLocalMode(false);
        setLocalMatches([]);

        showAlert(
          error.message || "Prescription পাওয়া যায়নি। Patient ID/Name অথবা Phone check করুন।",
          "error"
        );
      }
    } finally {
      setLoading(false);
    }
  };

  const verifyOtp = async (event) => {
    event?.preventDefault?.();

    if (!otpSent) {
      showAlert("আগে OTP send করুন।", "error");
      return;
    }

    if (!form.otp.trim()) {
      showAlert("OTP code দিন।", "error");
      return;
    }

    setLoading(true);

    try {
      if (localMode) {
        if (form.otp.trim() !== LOCAL_DEMO_OTP) {
          throw new Error("Invalid OTP.");
        }

        const normalized = localMatches.map(normalizePrescription);
        setPrescriptions(normalized);
        setVerified(true);
        setShowPrescription(false);

        showAlert(
          normalized.length
            ? `${normalized.length} prescription found. Access unlocked.`
            : "No prescription found for this patient.",
          normalized.length ? "success" : "error"
        );

        return;
      }

      const data = await verifyPrescriptionOtp({
        patientId: lookupText,
        patientName: lookupText,
        name: lookupText,
        phone: phoneText,
        otp: form.otp,
      });

      const normalized = (Array.isArray(data) ? data : []).map(
        normalizePrescription
      );

      const finalData = normalized.length
        ? normalized.filter((item) => matchesLookup(item, lookupText, phoneText))
        : normalized;

      setPrescriptions(finalData);
      setVerified(true);
      setShowPrescription(false);

      showAlert(
        finalData.length
          ? `${finalData.length} prescription found. Download option unlocked.`
          : "OTP verified, but no active prescription found.",
        finalData.length ? "success" : "error"
      );
    } catch (error) {
      setVerified(false);
      setShowPrescription(false);
      setPrescriptions([]);

      showAlert(error.message || "OTP verification failed.", "error");
    } finally {
      setLoading(false);
    }
  };

  const unlockPrescription = () => {
    setShowPrescription(true);

    if (resultCount) {
      showAlert("Prescription preview opened successfully.", "success");
    } else {
      showAlert("No prescription found for preview.", "error");
    }
  };

  const resetLookup = () => {
    setForm(emptyForm);
    setOtpSent(false);
    setVerified(false);
    setShowPrescription(false);
    setStatus("");
    setStatusTone("info");
    setLoading(false);
    setLocalMode(false);
    setLocalMatches([]);
    setPrescriptions([]);
  };

  const printPrescription = () => {
    window.print();
  };

  return (
    <div className="min-h-svh overflow-hidden bg-gradient-to-b from-[#effafa] via-white to-[#f7fbff] text-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(13,148,136,0.1)_1px,transparent_0)] [background-size:24px_24px]" />
      <div className="pointer-events-none fixed -left-40 -top-40 -z-10 h-[430px] w-[430px] rounded-full bg-cyan-200/30 blur-3xl" />
      <div className="pointer-events-none fixed -right-44 bottom-[-170px] -z-10 h-[460px] w-[460px] rounded-full bg-blue-200/25 blur-3xl" />

      <NavbarRenderer
        profile={profile}
        onAppointment={() => setModalOpen(true)}
      />

      <main className="mx-3 min-h-[70svh] max-w-[1180px] py-8 sm:mx-auto sm:w-[calc(100%_-_28px)] lg:py-10">
        <section className="overflow-hidden rounded-[32px] border border-cyan-100/80 bg-white/90 p-6 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-8">
          <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="group inline-flex items-center gap-2 text-xs font-black uppercase tracking-wide text-teal-700">
                  <FileText size={15} className={iconAnim} />
                  Prescription Lookup
                </span>

                <span className="group inline-flex items-center gap-2 text-xs font-black uppercase tracking-wide text-blue-700">
                  <ShieldCheck size={15} className={iconAnim} />
                  OTP Protected
                </span>
              </div>

              <h1 className="mt-5 text-[2.3rem] font-black leading-[1.05] tracking-[-0.05em] text-slate-950 sm:text-[3.3rem] lg:text-[4rem]">
                Find Your{" "}
                <span className="bg-gradient-to-r from-teal-700 to-blue-600 bg-clip-text text-transparent">
                  Prescription
                </span>
              </h1>

              <p className="mt-4 max-w-2xl text-[15px] font-semibold leading-8 text-slate-600">
                Patient ID, name বা phone দিয়ে prescription খুঁজুন। OTP verify
                করার পর preview, print এবং download option unlock হবে।
              </p>
            </div>

            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="group inline-flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.2)] transition duration-300 hover:-translate-y-1 hover:shadow-xl"
            >
              <CalendarDays size={17} className={iconAnim} />
              Book Appointment
              <ArrowRight
                size={17}
                className="transition duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[390px_minmax(0,1fr)] lg:items-start">
          <form
            onSubmit={otpSent ? verifyOtp : sendOtp}
            className="rounded-[30px] border border-cyan-100/80 bg-white/92 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl lg:sticky lg:top-28"
          >
            <div className="group flex items-start gap-3">
              <LockKeyhole size={24} className={`mt-1 text-teal-700 ${iconAnim}`} />
              <div>
                <h2 className="text-2xl font-black tracking-tight text-slate-950">
                  Secure Access
                </h2>
                <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
                  ID / Name + phone verify করুন।
                </p>
              </div>
            </div>

            <div className="mt-5 grid gap-4">
              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Patient ID / Name
                <div className="relative">
                  <UserRound
                    size={17}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-teal-700"
                  />
                  <input
                    className={`${inputClass} pl-11`}
                    placeholder="Example: P-1001 / Nafiul Azam"
                    value={form.lookup}
                    onChange={(event) => updateField("lookup", event.target.value)}
                  />
                </div>
              </label>

              <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                Phone Number
                <div className="relative">
                  <Phone
                    size={17}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-teal-700"
                  />
                  <input
                    className={`${inputClass} pl-11`}
                    placeholder="Example: 017XXXXXXXX"
                    value={form.phone}
                    onChange={(event) => updateField("phone", event.target.value)}
                  />
                </div>
              </label>

              {otpSent ? (
                <label className="grid gap-1.5 text-sm font-extrabold text-slate-600">
                  OTP Code
                  <div className="relative">
                    <KeyRound
                      size={17}
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-blue-700"
                    />
                    <input
                      className={`${inputClass} pl-11 tracking-[0.25em]`}
                      placeholder="123456"
                      value={form.otp}
                      maxLength={6}
                      onChange={(event) => updateField("otp", event.target.value)}
                    />
                  </div>
                </label>
              ) : null}
            </div>

            {status ? (
              <div
                className={`mt-4 flex items-start gap-2 rounded-2xl border px-4 py-3 text-sm font-extrabold leading-6 ${statusStyle}`}
              >
                {statusTone === "error" ? (
                  <AlertCircle size={17} className="mt-0.5 shrink-0" />
                ) : (
                  <CheckCircle2 size={17} className="mt-0.5 shrink-0" />
                )}
                <span>{status}</span>
              </div>
            ) : null}

            <button
              type="submit"
              disabled={loading}
              className="group mt-5 inline-flex min-h-[50px] w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.2)] transition duration-300 hover:-translate-y-1 hover:shadow-xl disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Search size={17} className={iconAnim} />
                  Please wait...
                </>
              ) : otpSent ? (
                <>
                  <BadgeCheck size={17} className={iconAnim} />
                  Verify OTP
                </>
              ) : (
                <>
                  <KeyRound size={17} className={iconAnim} />
                  Send OTP
                </>
              )}
            </button>

            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {otpSent && !verified ? (
                <button
                  type="button"
                  onClick={sendOtp}
                  disabled={loading}
                  className="group inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-cyan-100 bg-white px-4 text-sm font-black text-teal-700 transition hover:-translate-y-0.5 hover:bg-cyan-50 disabled:opacity-60"
                >
                  <RefreshCcw size={15} className={iconAnim} />
                  Resend
                </button>
              ) : null}

              <button
                type="button"
                onClick={resetLookup}
                className="group inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-600 transition hover:-translate-y-0.5 hover:bg-slate-50"
              >
                <RefreshCcw size={15} className={iconAnim} />
                Reset
              </button>
            </div>
          </form>

          <section className="rounded-[30px] border border-cyan-100/80 bg-white/90 p-5 shadow-[0_18px_50px_rgba(11,86,90,0.08)] backdrop-blur-xl sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-100 pb-4">
              <div>
                <h2 className="text-2xl font-black tracking-tight text-slate-950">
                  Prescription Preview
                </h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">
                  Verify হলে prescription preview এখানে আসবে।
                </p>
              </div>

              <span
                className={[
                  "group inline-flex items-center gap-2 text-xs font-black uppercase tracking-wide",
                  verified ? "text-teal-700" : "text-slate-500",
                ].join(" ")}
              >
                {verified ? (
                  <>
                    <CheckCircle2 size={15} className={iconAnim} />
                    Verified
                  </>
                ) : (
                  <>
                    <ShieldCheck size={15} className={iconAnim} />
                    Locked
                  </>
                )}
              </span>
            </div>

            {verified && !showPrescription ? (
              <div className="mt-5 grid min-h-[300px] place-items-center rounded-[28px] border border-teal-100 bg-gradient-to-r from-teal-50 to-blue-50 p-6 text-center">
                <div>
                  <div className="group inline-flex items-center gap-2 text-teal-700">
                    <UnlockKeyhole size={42} className={iconAnim} />
                    <Sparkles size={22} className={iconAnim} />
                  </div>

                  <h3 className="mt-4 text-2xl font-black text-slate-950">
                    Access Unlocked
                  </h3>

                  <p className="mx-auto mt-2 max-w-md text-sm font-semibold leading-7 text-slate-600">
                    {resultCount
                      ? `${resultCount} prescription found.`
                      : "OTP verified, but no active prescription found."}
                  </p>

                  <button
                    type="button"
                    onClick={unlockPrescription}
                    className="group mt-5 inline-flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-6 text-sm font-black text-white shadow-[0_16px_34px_rgba(20,102,242,0.2)] transition duration-300 hover:-translate-y-1 hover:shadow-xl"
                  >
                    <Download size={17} className={iconAnim} />
                    View Prescription
                    <ArrowRight
                      size={17}
                      className="transition duration-300 group-hover:translate-x-1"
                    />
                  </button>
                </div>
              </div>
            ) : null}

            {verified && showPrescription ? (
              <div className="mt-5">
                <div className="mb-5 rounded-3xl border border-teal-100 bg-gradient-to-r from-teal-50 to-blue-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="group flex items-start gap-3">
                      <Printer
                        size={20}
                        className={`mt-0.5 shrink-0 text-blue-700 ${iconAnim}`}
                      />
                      <div>
                        <h3 className="text-sm font-black text-slate-950">
                          Print / Download Ready
                        </h3>
                        <p className="mt-1 text-sm font-semibold leading-6 text-slate-600">
                          Browser print দিয়ে PDF save করা যাবে।
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={printPrescription}
                      className="group inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-sm font-black text-blue-700 shadow-sm transition hover:-translate-y-0.5 hover:text-teal-700 hover:shadow-md"
                    >
                      <Download size={16} className={iconAnim} />
                      Print / PDF
                    </button>
                  </div>
                </div>

                <div className="grid gap-4">
                  {prescriptions.length ? (
                    prescriptions.map((item) => {
                      const downloadHref = getDownloadHref(item);

                      return (
                        <article
                          key={getPrescriptionId(item)}
                          className="rounded-3xl border border-cyan-100 bg-white p-5 shadow-[0_14px_36px_rgba(11,86,90,0.07)]"
                        >
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div>
                              <p className="text-xs font-black uppercase tracking-wide text-teal-700">
                                {formatDate(getDate(item))}
                              </p>

                              <h3 className="mt-2 text-xl font-black text-slate-950">
                                {getFileName(item)}
                              </h3>

                              <p className="mt-1 text-sm font-semibold text-slate-500">
                                {getPatientName(item)} · {getPatientId(item)}
                              </p>
                            </div>

                            {downloadHref ? (
                              <a
                                href={downloadHref}
                                target="_blank"
                                rel="noreferrer"
                                className="group inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal-700 to-blue-600 px-4 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5"
                              >
                                <Download size={16} className={iconAnim} />
                                Download
                              </a>
                            ) : (
                              <span className="inline-flex min-h-11 items-center justify-center rounded-2xl bg-slate-100 px-4 text-sm font-black text-slate-500">
                                No file
                              </span>
                            )}
                          </div>

                          <div className="mt-4 grid gap-2 text-sm font-semibold text-slate-600 sm:grid-cols-2">
                            <p>
                              <strong>Phone:</strong> {getPhone(item)}
                            </p>
                            <p>
                              <strong>Doctor:</strong> {getDoctorName(item)}
                            </p>
                            <p>
                              <strong>Appointment:</strong>{" "}
                              {getValue(item, ["appointmentId"], "Not specified")}
                            </p>
                            <p>
                              <strong>Status:</strong> {getStatus(item)}
                            </p>
                          </div>

                          {item.notes ? (
                            <p className="mt-4 rounded-2xl bg-cyan-50/60 p-4 text-sm font-semibold leading-7 text-slate-600">
                              {item.notes}
                            </p>
                          ) : null}
                        </article>
                      );
                    })
                  ) : (
                    <EmptyResult
                      title="No prescription found"
                      message="OTP verified, but this patient has no active prescription."
                    />
                  )}
                </div>
              </div>
            ) : null}

            {!verified ? (
              <EmptyResult
                title="Verify OTP First"
                message="Patient prescription protected. ID/Name + phone দিয়ে OTP verify করুন।"
              />
            ) : null}
          </section>
        </section>
      </main>

      <FooterRenderer profile={profile} />

      <AppointmentModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </div>
  );
};

const EmptyResult = ({ title, message }) => {
  return (
    <div className="mt-5 grid min-h-[300px] place-items-center rounded-[28px] border border-dashed border-cyan-200 bg-cyan-50/45 p-6 text-center">
      <div>
        <div className="group inline-flex items-center justify-center text-teal-700">
          <Search size={42} className={iconAnim} />
        </div>

        <h3 className="mt-4 text-2xl font-black text-slate-950">{title}</h3>

        <p className="mx-auto mt-2 max-w-md text-sm font-semibold leading-7 text-slate-500">
          {message}
        </p>
      </div>
    </div>
  );
};

export default PublicPrescriptionPage;
