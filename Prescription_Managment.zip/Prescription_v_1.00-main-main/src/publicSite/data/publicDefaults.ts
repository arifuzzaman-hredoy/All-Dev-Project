export const defaultProfile = {
  brandName: "CareBridge",
  doctorName: "Professor Dr. Md. Tofael Hossain Bhuiyan",
  title: "Professor & Head of Neurosurgery",
  specialization: "MS Neuro Surgery, Brain, Nerve, Spine & Stroke Specialist",
  shortBio:
    "Brain, nerve, spine and stroke care with calm clinical guidance. রোগীর কথা শুনে evidence-based treatment plan করা হয়।",
  longBio:
    "Professor Dr. Md. Tofael Hossain Bhuiyan is a neurosurgery specialist focused on brain, nerve, spine and stroke related conditions. His practice combines careful diagnosis, clear patient education and practical follow-up planning for families.",
  profileImageUrl:
    "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=900&q=80",
  heroImageUrl:
    "https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?auto=format&fit=crop&w=1600&q=80",
  phone: "+880 1711-000000",
  email: "carebridge.doctor@example.com",
  chamberName: "Dhanmondi Branch, Room 302",
  chamberAddress: "House 12, Road 8, Dhanmondi, Dhaka",
  visitingDays: "Sunday - Thursday",
  visitingTime: "09:00 AM - 01:00 PM",
  emergencyNotice:
    "Emergency neuro symptoms such as sudden weakness, seizure or severe head injury should go to nearest emergency unit first.",
  ctaText: "Book Appointment",
  assistant: "Shafin",
  homepageIntro:
    "Personal doctor website for appointment, Q&A, health blogs and prescription lookup.",
  socialLinks: {
    facebook: "https://facebook.com",
    linkedin: "https://linkedin.com",
    youtube: "https://youtube.com",
  },
};

export const defaultServices = [
  {
    id: "service-1",
    title: "Brain & Spine Consultation",
    description:
      "Headache, back pain, nerve compression and spine-related symptoms reviewed with a structured plan.",
  },
  {
    id: "service-2",
    title: "Stroke Follow-up",
    description:
      "Post-stroke assessment, risk review and family guidance for recovery planning.",
  },
  {
    id: "service-3",
    title: "Neuro Trauma Guidance",
    description:
      "Clear next steps for head injury, seizure, weakness and urgent neurological warning signs.",
  },
  {
    id: "service-4",
    title: "Prescription Review",
    description:
      "Existing reports and prescriptions are reviewed for safer continuation and follow-up.",
  },
];

export const defaultBlogs = [
  {
    id: "blog-1",
    title: "When Headache Needs Urgent Care",
    slug: "when-headache-needs-urgent-care",
    category: "Neuro Care",
    excerpt:
      "Most headaches are manageable, but some warning signs need fast medical attention.",
    content:
      "Severe sudden headache, headache with weakness, repeated vomiting, seizure, fever with neck stiffness, or headache after head injury should be treated urgently. মাথাব্যথা দীর্ঘদিন থাকলে self-medication না করে consultation করুন।",
    coverImageUrl:
      "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=1200&q=80",
    publishDate: "2026-04-12",
    status: "published",
  },
  {
    id: "blog-2",
    title: "Back Pain and Nerve Symptoms",
    slug: "back-pain-and-nerve-symptoms",
    category: "Spine",
    excerpt:
      "Leg numbness, weakness or bladder change with back pain should not be ignored.",
    content:
      "Back pain becomes more concerning when it travels down the leg, causes numbness, weakness, walking difficulty or bladder-bowel symptoms. Early diagnosis helps prevent long-term nerve damage.",
    coverImageUrl:
      "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=80",
    publishDate: "2026-05-05",
    status: "published",
  },
];

export const defaultQa = [
  {
    id: "qa-1",
    patientName: "Nusrat",
    phone: "+880 1700-111222",
    question: "Migraine হলে কি নিয়মিত painkiller খাওয়া নিরাপদ?",
    answer:
      "Frequent painkiller use can cause rebound headache. Please track headache days and consult for preventive treatment if it is frequent.",
    status: "answered",
    createdAt: "2026-05-10T09:30:00.000Z",
  },
];

export const defaultGallery = [
  {
    id: "gallery-1",
    title: "Consultation Chamber",
    imageUrl:
      "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80",
    category: "Chamber",
    description: "Dhanmondi Branch, Room 302 consultation space.",
  },
  {
    id: "gallery-2",
    title: "Patient Education Session",
    imageUrl:
      "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?auto=format&fit=crop&w=1200&q=80",
    category: "Awareness",
    description: "Neuro care awareness and follow-up guidance.",
  },
];

export const defaultAppointments = [];
export const defaultMessages = [];

export const defaultPrescriptions = [
  {
    id: "rx-1",
    patientId: "P-1003",
    patientName: "Nabila Akter",
    phone: "+880 1711-100003",
    date: "2026-04-13",
    diagnosis: "Migraine with fever review",
    advice: "Follow up in 7 days with CBC report. পর্যাপ্ত পানি পান করুন।",
    medicines: ["Tab. Paracetamol 500mg - as advised", "Cap. Omeprazole 20mg"],
  },
];

export default {
  profile: defaultProfile,
  services: defaultServices,
  blogs: defaultBlogs,
  qa: defaultQa,
  gallery: defaultGallery,
  appointments: defaultAppointments,
  messages: defaultMessages,
  prescriptions: defaultPrescriptions,
};
