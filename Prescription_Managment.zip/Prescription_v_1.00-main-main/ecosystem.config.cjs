module.exports = {
  apps: [
    {
      name: "prescription-app",
      script: "server/index.ts",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: 3500,
      },
    },
  ],
};
