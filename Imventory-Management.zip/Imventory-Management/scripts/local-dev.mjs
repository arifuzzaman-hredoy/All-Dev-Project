import { spawn, spawnSync } from "node:child_process";
import net from "node:net";

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: "inherit", shell: false, ...options });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

function succeeds(command, args) {
  const result = spawnSync(command, args, { stdio: "ignore", shell: false });
  return result.status === 0;
}

function portOpen(port, host = "127.0.0.1") {
  return new Promise((resolve) => {
    const socket = net.createConnection({ port, host });
    const done = (value) => {
      socket.destroy();
      resolve(value);
    };
    socket.setTimeout(700);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false));
    socket.once("error", () => done(false));
  });
}

function startMariaDb() {
  if (!succeeds("docker", ["--version"])) {
    console.error("\nMariaDB is not reachable on 127.0.0.1:3307 and Docker is not installed.");
    console.error("Start MariaDB manually or install Docker, then run npm run dev again.\n");
    process.exit(1);
  }

  if (succeeds("docker", ["compose", "version"])) {
    console.log("Starting local MariaDB with Docker Compose v2...");
    run("docker", ["compose", "up", "-d", "db"]);
    return;
  }

  if (succeeds("docker-compose", ["--version"])) {
    console.log("Starting local MariaDB with docker-compose...");
    run("docker-compose", ["up", "-d", "db"]);
    return;
  }

  console.log("Docker Compose was not found. Starting MariaDB directly with Docker...");
  if (succeeds("docker", ["inspect", "ammazan-homeo-mariadb"])) {
    run("docker", ["start", "ammazan-homeo-mariadb"]);
    return;
  }

  run("docker", [
    "run",
    "-d",
    "--name",
    "ammazan-homeo-mariadb",
    "--restart",
    "unless-stopped",
    "-e",
    "MARIADB_DATABASE=ammazan_homeo",
    "-e",
    "MARIADB_USER=ammazan",
    "-e",
    "MARIADB_PASSWORD=ammazan_local_db_2026",
    "-e",
    "MARIADB_ROOT_PASSWORD=ammazan_root_local_2026",
    "-p",
    "3307:3306",
    "-v",
    "ammazan_mariadb_data:/var/lib/mysql",
    "mariadb:11.4",
  ]);
}

async function main() {
  if (!(await portOpen(3307))) {
    startMariaDb();

    let ready = false;
    for (let attempt = 0; attempt < 60; attempt += 1) {
      if (await portOpen(3307)) {
        ready = true;
        break;
      }
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    if (!ready) {
      console.error("MariaDB did not become ready on 127.0.0.1:3307.");
      console.error("Run: docker ps -a");
      process.exit(1);
    }
  }

  console.log("Preparing database...");
  run("npx", ["prisma", "generate"]);
  run("npx", ["prisma", "db", "push"]);
  run("npx", ["tsx", "prisma/seed.ts"]);
  run("npx", ["tsx", "scripts/backfill-stock.ts"]);

  console.log("\nStarting Ammazan Homeo Distributor at http://localhost:3000\n");
  const child = spawn("npx", ["next", "dev"], { stdio: "inherit", shell: false });
  child.on("exit", (code) => process.exit(code ?? 0));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
