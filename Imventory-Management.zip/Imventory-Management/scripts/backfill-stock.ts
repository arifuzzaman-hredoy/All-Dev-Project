import { Prisma, TransactionType } from "@prisma/client";
import { prisma } from "../lib/prisma";

const BACKFILL_KEY = "phase5.stock.backfill.v1";

function normalizeName(value: string) {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
}

async function main() {
  const done = await prisma.setting.findUnique({ where: { key: BACKFILL_KEY } });
  if (done) return;

  const items = await prisma.transactionItem.findMany({
    include: { transaction: { select: { type: true } }, product: true },
    orderBy: { createdAt: "asc" },
  });

  const groups = new Map<string, typeof items>();
  for (const item of items) {
    if (item.transaction.type !== TransactionType.PURCHASE && item.transaction.type !== TransactionType.SALE) continue;
    const unit = (item.unit || "UNIT").trim().toUpperCase();
    const key = `${normalizeName(item.productName)}::${unit}`;
    const current = groups.get(key) ?? [];
    current.push(item);
    groups.set(key, current);
  }

  for (const [key, group] of groups) {
    const [normalizedName, unit] = key.split("::");
    const first = group[0];
    if (!first) continue;

    const existingId = group.find((item) => item.productId)?.productId;
    let product = existingId ? await prisma.product.findUnique({ where: { id: existingId } }) : null;
    if (!product) {
      product = await prisma.product.create({
        data: { name: first.productName, normalizedName, unit, stockQuantity: new Prisma.Decimal(0) },
      });
    }

    let stock = new Prisma.Decimal(0);
    for (const item of group) {
      stock = item.transaction.type === TransactionType.PURCHASE
        ? stock.plus(item.quantity)
        : stock.minus(item.quantity);
    }
    if (stock.lt(0)) stock = new Prisma.Decimal(0);

    await prisma.$transaction([
      prisma.product.update({
        where: { id: product.id },
        data: { name: first.productName, normalizedName, unit, stockQuantity: stock },
      }),
      prisma.transactionItem.updateMany({
        where: { id: { in: group.map((item) => item.id) } },
        data: { productId: product.id, unit },
      }),
    ]);
  }

  await prisma.setting.upsert({
    where: { key: BACKFILL_KEY },
    create: { key: BACKFILL_KEY, value: new Date().toISOString() },
    update: { value: new Date().toISOString() },
  });
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (error) => {
    console.error("Phase 5 stock backfill failed", error);
    await prisma.$disconnect();
    process.exit(1);
  });
