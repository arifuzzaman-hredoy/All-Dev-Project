# Ammazan Homeo Production Deployment

Production:
- Domain: inventory.techteamlead.com
- VPS: 198.54.121.88
- App port: 127.0.0.1:4180
- Database: MariaDB at 127.0.0.1:3306
- Database name: ammazan_homeo
- Runtime user: ammazan
- CI deploy user: ammazan-deploy
- Runtime Node: /opt/ammazan-homeo/node
- Runtime env: /etc/ammazan-homeo/app.env
- Persistent uploads: /var/lib/ammazan-homeo/uploads
- Persistent cache: /var/lib/ammazan-homeo/cache
- Releases: /var/www/ammazan-homeo/releases
- Current release: /var/www/ammazan-homeo/current

Deployment policy:
- Build occurs in GitHub Actions.
- VPS does not perform Next.js compilation.
- Database migrations use `prisma migrate deploy`.
- MariaDB is never exposed publicly.
- Uploads survive releases.
- Deployment switches releases atomically.
- Failed health checks trigger rollback.
