import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD;

  if (!email || !password) {
    throw new Error("Production seed credentials are missing.");
  }

  const adminCount = await prisma.adminUser.count();

  if (adminCount === 0) {
    const passwordHash = await bcrypt.hash(password, 12);

    await prisma.adminUser.create({
      data: {
        email,
        passwordHash,
      },
    });

    console.log(`Initial production admin created: ${email}`);
  } else {
    console.log("Admin already exists; initial admin creation skipped.");
  }

  await prisma.setting.upsert({
    where: { key: "app_language" },
    update: {},
    create: {
      key: "app_language",
      value: "bn",
    },
  });
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
