import { TransactionType } from "@prisma/client";
import { prisma } from "@/lib/prisma";

export async function getBusinessTotals() {
  const [totalsByType, commission] = await Promise.all([
    prisma.transaction.groupBy({
      by: ["type"],
      _sum: { totalAmount: true, dueAmount: true },
    }),
    prisma.commission.aggregate({ _sum: { amount: true, dueAmount: true } }),
  ]);

  const totals = new Map(totalsByType.map((row) => [row.type, row._sum]));
  const purchase = totals.get(TransactionType.PURCHASE);
  const sale = totals.get(TransactionType.SALE);
  const payment = totals.get(TransactionType.PAYMENT);
  const receive = totals.get(TransactionType.RECEIVE);

  const purchaseTotal = Number(purchase?.totalAmount ?? 0);
  const saleTotal = Number(sale?.totalAmount ?? 0);
  const supplierDue = Math.max(0, Number(purchase?.dueAmount ?? 0) - Number(payment?.totalAmount ?? 0));
  const customerDue = Math.max(0, Number(sale?.dueAmount ?? 0) - Number(receive?.totalAmount ?? 0));

  return {
    purchaseTotal,
    saleTotal,
    supplierDue,
    customerDue,
    paymentTotal: Number(payment?.totalAmount ?? 0),
    receiveTotal: Number(receive?.totalAmount ?? 0),
    commissionTotal: Number(commission._sum.amount ?? 0),
    commissionDue: Number(commission._sum.dueAmount ?? 0),
  };
}

export async function getPartyBalances(partyId: string) {
  const totalsByType = await prisma.transaction.groupBy({
    by: ["type"],
    where: { partyId },
    _sum: { totalAmount: true, dueAmount: true },
  });

  const totals = new Map(totalsByType.map((row) => [row.type, row._sum]));
  const purchase = totals.get(TransactionType.PURCHASE);
  const sale = totals.get(TransactionType.SALE);
  const payment = totals.get(TransactionType.PAYMENT);
  const receive = totals.get(TransactionType.RECEIVE);

  return {
    totalPurchase: Number(purchase?.totalAmount ?? 0),
    totalSale: Number(sale?.totalAmount ?? 0),
    supplierDue: Math.max(0, Number(purchase?.dueAmount ?? 0) - Number(payment?.totalAmount ?? 0)),
    customerDue: Math.max(0, Number(sale?.dueAmount ?? 0) - Number(receive?.totalAmount ?? 0)),
    totalPaidLater: Number(payment?.totalAmount ?? 0),
    totalReceivedLater: Number(receive?.totalAmount ?? 0),
  };
}
