"use client";

import { ArrowLeft, ExternalLink, Pencil, ReceiptText, ShoppingBasket, ShoppingCart } from "lucide-react";
import Link from "next/link";
import { useLanguage } from "@/components/language-provider";

type Detail = {
  id: string;
  type: "PURCHASE" | "SALE" | "PAYMENT" | "RECEIVE";
  date: string;
  party: string;
  product: string;
  quantity: number;
  unit: string;
  total: number;
  unitPrice: number;
  paid: number;
  due: number;
  sellingPrice: number | null;
  commission: number;
  manufacture: string | null;
  expiry: string | null;
  alertDays: number | null;
  payments: Array<{ method: string; amount: number }>;
  attachments: Array<{ id: string; name: string }>;
};

const money = (value: number) => `৳${new Intl.NumberFormat("en-BD", { maximumFractionDigits: 2 }).format(value)}`;

export function TransactionDetailView({ detail }: { detail: Detail }) {
  const { t } = useLanguage();
  const isBuy = detail.type === "PURCHASE";
  const ToneIcon = isBuy ? ShoppingBasket : ShoppingCart;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <Link href="/dashboard" data-action="back" className="action-link pressable inline-flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-800 dark:text-indigo-300 dark:hover:text-indigo-200"><ArrowLeft size={17} className="action-icon" /> {t.backDashboard}</Link>
        <div className="flex flex-wrap items-center gap-3">
          <Link href={`/transactions/${detail.id}/edit`} data-action="edit" className="pressable inline-flex min-h-11 items-center gap-2 border-0 bg-transparent px-2 py-2 text-xs font-black text-sky-600 dark:text-sky-300"><Pencil size={16} /> {t.edit}</Link>
          <Link href={`/receipt/${detail.id}`} target="_blank" data-action="receipt" className="premium-button pressable inline-flex min-h-11 items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-700 via-violet-800 to-purple-950 px-4 py-2.5 text-xs font-black text-white"><ReceiptText size={16} /> {t.receipt}</Link>
        </div>
      </div>
      <div className="premium-surface motion-panel mt-5 overflow-hidden rounded-[1.75rem]">
        <div className={`px-5 py-4 text-white ${isBuy ? "bg-gradient-to-r from-rose-600 via-red-600 to-red-800" : "bg-gradient-to-r from-emerald-600 via-green-600 to-teal-800"}`}>
          <div className="flex items-center gap-2">
            <ToneIcon size={18} />
            <p className="text-xs font-black uppercase tracking-[0.16em] text-white/80">{isBuy ? t.buy : t.sell}</p>
          </div>
          <h1 className="mt-1 text-xl font-black">{t.details}</h1>
        </div>
        <div className="grid gap-px bg-slate-100 dark:bg-white/5 sm:grid-cols-2">
          <Info label={t.date} value={detail.date} />
          <Info label={t.party} value={detail.party} />
          <Info label={t.product} value={detail.product} />
          <Info label={t.quantity} value={`${detail.quantity} ${detail.unit}`} />
          {!isBuy ? <Info label={t.sellingUnitPrice} value={money(detail.unitPrice)} /> : null}
          <Info label={t.amount} value={money(detail.total)} />
          <Info label={t.paid} value={money(detail.paid)} />
          <Info label={t.due} value={money(detail.due)} />
          {isBuy && detail.sellingPrice !== null ? <Info label={t.sellingPrice} value={money(detail.sellingPrice)} /> : null}
          {isBuy ? <Info label={t.commission} value={money(detail.commission)} /> : null}
          {isBuy ? <Info label={t.manufacture} value={detail.manufacture || "—"} /> : null}
          {isBuy ? <Info label={t.expiry} value={detail.expiry || "—"} /> : null}
          {isBuy ? <Info label={t.alert} value={detail.alertDays === null ? "—" : `${detail.alertDays} ${t.days}`} /> : null}
        </div>
      </div>

      <section className="premium-surface motion-panel mt-4 rounded-[1.75rem] p-4 sm:p-5">
        <h2 className="font-black text-slate-950 dark:text-white">{t.paymentBreakdown}</h2>
        <div className="mt-3 grid gap-2 md:grid-cols-2">
          {detail.payments.length ? detail.payments.map((payment) => (
            <div key={`${payment.method}-${payment.amount}`} className="flex items-center justify-between rounded-2xl bg-gradient-to-r from-slate-50 to-indigo-50 px-4 py-3 text-sm dark:from-slate-900 dark:to-indigo-950/35">
              <span className="font-bold text-slate-500 dark:text-slate-400">{payment.method}</span><strong className="text-slate-950 dark:text-white">{money(payment.amount)}</strong>
            </div>
          )) : <div className="text-sm text-slate-400">—</div>}
        </div>
      </section>

      <section className="premium-surface motion-panel mt-4 rounded-[1.75rem] p-4 sm:p-5">
        <h2 className="font-black text-slate-950 dark:text-white">{t.attachment}</h2>
        {detail.attachments.length === 0 ? <p className="mt-3 text-sm text-slate-400">{t.noAttachment}</p> : (
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {detail.attachments.map((attachment) => (
              <a key={attachment.id} href={`/api/attachments/${attachment.id}`} target="_blank" rel="noreferrer" className="group overflow-hidden rounded-2xl border border-slate-200 transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/api/attachments/${attachment.id}`} alt={attachment.name} className="h-56 w-full bg-slate-50 object-contain dark:bg-slate-900" />
                <div className="flex items-center justify-between gap-2 border-t border-slate-100 px-3 py-2 text-xs font-bold text-slate-600 dark:border-white/10 dark:text-slate-300"><span className="truncate">{attachment.name}</span><ExternalLink size={14} className="transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></div>
              </a>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <div className="bg-white px-5 py-4 dark:bg-slate-950/80"><div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{label}</div><div className="mt-1 text-sm font-black text-slate-900 dark:text-white">{value}</div></div>;
}
