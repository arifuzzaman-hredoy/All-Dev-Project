"use client";

import Link from "next/link";
import {
  AlertTriangle,
  BadgeDollarSign,
  Boxes,
  ChevronDown,
  Eye,
  HandCoins,
  ImagePlus,
  Loader2,
  Pencil,
  CheckCircle2,
  ReceiptText,
  ShoppingBasket,
  ShoppingCart,
  Trash2,
  Wallet,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useLanguage } from "@/components/language-provider";
import { DashboardGreeting } from "@/components/dashboard-greeting";

export type DashboardRow = {
  id: string;
  date: string;
  product: string;
  party: string;
  quantity: number;
  unit: string;
  amount: number;
  paid: number;
  due: number;
  proofCount: number;
};

export type ExpiryRow = {
  id: string;
  product: string;
  party: string;
  expiry: string;
  daysRemaining: number;
};

export type StockRow = {
  id: string;
  product: string;
  quantity: number;
  unit: string;
};

export type DashboardMetrics = {
  totalBuy: number;
  totalSell: number;
  buyDue: number;
  sellDue: number;
  commission: number;
};

type DueTarget = { row: DashboardRow; tone: "buy" | "sell" };
type PaymentChannel = "CASH" | "BANKING";
type BankingMethod = "BKASH" | "ROCKET" | "NAGAD" | "BANK";

const moneyFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 2 });
const quantityFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 3 });
const money = (value: number) => `৳${moneyFormatter.format(value)}`;
const qty = (value: number) => quantityFormatter.format(value);

export function DashboardView({ metrics, buys, sells, expiry, stock }: { metrics: DashboardMetrics; buys: DashboardRow[]; sells: DashboardRow[]; expiry: ExpiryRow[]; stock: StockRow[] }) {
  const { t } = useLanguage();
  const router = useRouter();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [dueTarget, setDueTarget] = useState<DueTarget | null>(null);

  async function remove(id: string) {
    if (!window.confirm(t.deleteConfirm)) return;
    setDeletingId(id);
    try {
      const response = await fetch(`/api/transactions/${id}`, { method: "DELETE" });
      if (!response.ok) {
        const body = (await response.json()) as { message?: string };
        throw new Error(body.message || "Delete failed");
      }
      router.refresh();
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "Delete failed");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div className="liquid-dashboard">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div className="min-w-0">
          <DashboardGreeting />
          <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950 dark:text-white sm:text-3xl">{t.dashboard}</h1>
        </div>
      </div>

      <section className="grid grid-cols-1 gap-3 min-[390px]:grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
        <Metric label={t.totalBuy} value={metrics.totalBuy} icon={<ShoppingBasket size={23} />} motion="buy" gradient="from-rose-600 via-red-700 to-red-950" />
        <Metric label={t.totalSell} value={metrics.totalSell} icon={<ShoppingCart size={23} />} motion="sell" gradient="from-emerald-600 via-green-700 to-teal-950" />
        <Metric label={t.buyDue} value={metrics.buyDue} icon={<Wallet size={23} />} motion="wallet" gradient="from-amber-500 via-orange-700 to-red-950" />
        <Metric label={t.sellDue} value={metrics.sellDue} icon={<HandCoins size={23} />} motion="wallet" gradient="from-sky-600 via-blue-800 to-indigo-950" />
        <Metric label={t.commission} value={metrics.commission} icon={<BadgeDollarSign size={23} />} motion="dashboard" gradient="from-violet-600 via-purple-800 to-indigo-950" className="min-[390px]:col-span-2 md:col-span-1" />
      </section>

      <section className="premium-surface mt-5 overflow-hidden rounded-3xl">
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-3.5 dark:border-white/10">
          <div className="flex items-center gap-2.5">
            <Boxes size={19} className="text-indigo-600 dark:text-indigo-300" />
            <h2 className="text-sm font-black text-slate-900 dark:text-white">{t.stockBalance}</h2>
          </div>
          <span className="text-[10px] font-black uppercase tracking-[0.16em] text-indigo-500/70">{t.liveStock}</span>
        </div>
        {stock.length === 0 ? (
          <p className="px-4 py-8 text-center text-sm text-slate-400">{t.noStock}</p>
        ) : (
          <>
            <div className="grid gap-2 p-3 sm:hidden">
              {stock.map((row) => (
                <div key={row.id} className="stock-mobile-card flex items-center justify-between gap-3 rounded-2xl px-3 py-3">
                  <span className="min-w-0 truncate text-sm font-bold text-slate-900 dark:text-slate-100">{row.product}</span>
                  <span className="shrink-0 text-sm font-black text-indigo-700 dark:text-indigo-300">{qty(row.quantity)} {row.unit}</span>
                </div>
              ))}
            </div>
            <div className="hidden overflow-x-auto sm:block">
            <table className="w-full min-w-[460px] border-collapse text-left text-xs">
              <thead className="bg-gradient-to-r from-indigo-50 to-violet-50 text-indigo-700 dark:from-indigo-950/50 dark:to-violet-950/50 dark:text-indigo-200"><tr><Th>{t.product}</Th><Th>{t.remainingStock}</Th></tr></thead>
              <tbody>
                {stock.map((row) => (
                  <tr key={row.id} className="border-t border-slate-100 transition hover:bg-indigo-50/45 dark:border-white/5 dark:hover:bg-indigo-500/5">
                    <Td><span className="font-bold text-slate-900 dark:text-slate-100">{row.product}</span></Td>
                    <Td><span className="font-black text-indigo-700 dark:text-indigo-300">{qty(row.quantity)} {row.unit}</span></Td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </>
        )}
      </section>

      <section className="dashboard-expiry-glass mt-5 overflow-hidden rounded-3xl border border-amber-200/80 bg-gradient-to-br from-amber-50 via-orange-50/80 to-white p-4 shadow-soft dark:border-amber-500/15 dark:from-amber-950/30 dark:via-orange-950/15 dark:to-slate-950/80">
        <div className="flex items-center gap-2">
          <AlertTriangle size={18} className="text-amber-600 dark:text-amber-300" />
          <h2 className="font-black text-amber-950 dark:text-amber-100">{t.expiringSoon}</h2>
        </div>
        {expiry.length === 0 ? (
          <p className="mt-3 text-sm text-amber-800/70 dark:text-amber-200/60">{t.noExpiryAlerts}</p>
        ) : (
          <div className="mt-3 grid gap-2 md:grid-cols-2 xl:grid-cols-3">
            {expiry.map((item) => (
              <div key={item.id} className="rounded-2xl border border-white/70 bg-white/75 px-3 py-3 text-sm shadow-sm backdrop-blur dark:border-white/10 dark:bg-slate-950/55">
                <div className="font-black text-slate-900 dark:text-white">{item.product}</div>
                <div className="mt-1 truncate text-xs text-slate-500 dark:text-slate-400">{item.party}</div>
                <div className="mt-2 flex items-center justify-between gap-3 text-xs font-bold">
                  <span>{item.expiry}</span>
                  <span className={item.daysRemaining < 0 ? "text-red-600 dark:text-red-300" : "text-amber-700 dark:text-amber-300"}>{item.daysRemaining < 0 ? t.expired : `${item.daysRemaining} ${t.daysRemaining}`}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="mt-5 grid gap-4 2xl:grid-cols-2">
        <RecordTable title={t.buyRecords} rows={buys} empty={t.noBuyRecords} tone="buy" deletingId={deletingId} onDelete={remove} onDue={(row) => setDueTarget({ row, tone: "buy" })} labels={t} />
        <RecordTable title={t.sellRecords} rows={sells} empty={t.noSellRecords} tone="sell" deletingId={deletingId} onDelete={remove} onDue={(row) => setDueTarget({ row, tone: "sell" })} labels={t} />
      </section>

      {dueTarget ? <DuePaymentModal target={dueTarget} onClose={() => setDueTarget(null)} onSaved={() => router.refresh()} /> : null}
    </div>
  );
}

function Metric({ label, value, icon, gradient, motion, className = "" }: { label: string; value: number; icon: React.ReactNode; gradient: string; motion: "dashboard" | "buy" | "sell" | "wallet"; className?: string }) {
  return (
    <div className={`metric-card premium-metric rounded-[1.65rem] bg-gradient-to-br ${gradient} p-4 text-white shadow-xl shadow-slate-900/10 sm:p-5 ${className}`} data-motion={motion}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[1.15rem] font-black tracking-tight min-[420px]:text-xl sm:text-2xl">{money(value)}</div>
          <div className="mt-1 text-xs font-bold text-white/72">{label}</div>
        </div>
        <div className="metric-icon semantic-action-icon text-white/85" data-motion={motion}>{icon}</div>
      </div>
    </div>
  );
}

function RecordTable({ title, rows, empty, tone, deletingId, onDelete, onDue, labels }: {
  title: string;
  rows: DashboardRow[];
  empty: string;
  tone: "buy" | "sell";
  deletingId: string | null;
  onDelete: (id: string) => void;
  onDue: (row: DashboardRow) => void;
  labels: ReturnType<typeof useLanguage>["t"];
}) {
  const header = tone === "buy"
    ? "bg-gradient-to-r from-rose-600 via-red-700 to-red-950 text-white"
    : "bg-gradient-to-r from-emerald-600 via-green-700 to-teal-950 text-white";
  const ToneIcon = tone === "buy" ? ShoppingBasket : ShoppingCart;
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    setCollapsed(window.localStorage.getItem(`ahd-record-panel-${tone}-collapsed`) === "true");
  }, [tone]);

  function togglePanel() {
    setCollapsed((current) => {
      const next = !current;
      window.localStorage.setItem(`ahd-record-panel-${tone}-collapsed`, String(next));
      return next;
    });
  }

  return (
    <div className="premium-surface record-panel overflow-visible rounded-[1.75rem]" data-collapsed={collapsed ? "true" : "false"}>
      <div className={`record-panel-header px-4 py-3.5 sm:px-5 ${header}`}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <span className="semantic-action-icon" data-motion={tone}><ToneIcon size={19} className="semantic-icon-svg" /></span>
            <h2 className="truncate text-sm font-black sm:text-base">{title}</h2>
            <span className="record-count-chip" aria-label={`${rows.length} records`}>{rows.length}</span>
          </div>
          <button
            type="button"
            onClick={togglePanel}
            className="premium-tooltip record-collapse-toggle pressable relative inline-flex items-center justify-center border-0 bg-transparent p-1 text-white/80 transition hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            data-tooltip={collapsed ? labels.expand : labels.collapse}
            aria-label={collapsed ? labels.expand : labels.collapse}
            aria-expanded={!collapsed}
          >
            <ChevronDown size={21} strokeWidth={2.3} className={`record-collapse-chevron transition-transform duration-300 ${collapsed ? "-rotate-90" : "rotate-0"}`} />
          </button>
        </div>
      </div>
      <div className={`record-panel-body ${collapsed ? "record-panel-body-collapsed" : "record-panel-body-expanded"}`}>
      {rows.length === 0 ? <div className="px-4 py-12 text-center text-sm text-slate-400">{empty}</div> : (
        <>
          <div className="grid gap-2.5 p-3 md:hidden">
            {rows.map((row) => (
              <article key={row.id} className={`record-mobile-card rounded-2xl p-3.5 ${tone === "buy" ? "record-buy" : "record-sell"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-black text-slate-950 dark:text-white">{row.product}</div>
                    <div className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">{row.party}</div>
                  </div>
                  <span className="shrink-0 text-[10px] font-bold text-slate-400">{row.date}</span>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                  <MiniStat label={labels.quantity} value={`${qty(row.quantity)} ${row.unit}`} />
                  <MiniStat label={labels.amount} value={money(row.amount)} />
                  <MiniStat label={labels.due} value={money(row.due)} warning={row.due > 0} />
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-slate-200/70 pt-3 dark:border-white/10">
                  {row.due > 0 ? (
                    <button type="button" onClick={() => onDue(row)} data-action="wallet" className={`action-link pressable inline-flex items-center gap-1.5 border-0 bg-transparent text-xs font-black ${tone === "buy" ? "text-red-600 dark:text-red-300" : "text-emerald-600 dark:text-emerald-300"}`}>
                      <Wallet size={15} className="action-icon" /> {tone === "buy" ? labels.payDue : labels.receiveDue}
                    </button>
                  ) : null}
                  <Link href={`/transactions/${row.id}/edit`} data-action="edit" className="action-link pressable inline-flex items-center gap-1 text-xs font-bold text-sky-600 dark:text-sky-300"><Pencil size={15} className="action-icon" /> {labels.edit}</Link>
                  <Link href={`/transactions/${row.id}`} data-action="view" className="action-link pressable inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-300"><Eye size={15} className="action-icon" /> {labels.view}</Link>
                  <button disabled={deletingId === row.id} onClick={() => onDelete(row.id)} data-action="delete" className="action-link pressable inline-flex items-center gap-1 border-0 bg-transparent text-xs font-bold text-red-600 disabled:opacity-50 dark:text-red-300"><Trash2 size={15} className="action-icon" /> {deletingId === row.id ? "..." : labels.delete}</button>
                </div>
              </article>
            ))}
          </div>

          <div className="hidden md:block">
            <div className="record-sheet">
              <table className="record-excel-table w-full table-fixed" data-tone={tone}>
                <colgroup>
                  <col className="record-col-date" />
                  <col className="record-col-product" />
                  <col className="record-col-party" />
                  <col className="record-col-quantity" />
                  <col className="record-col-amount" />
                  <col className="record-col-due" />
                  <col className="record-col-actions" />
                </colgroup>
                <thead>
                  <tr>
                    <th className="text-center">{labels.date}</th>
                    <th>{labels.product}</th>
                    <th>{labels.party}</th>
                    <th className="text-center">{labels.quantity}</th>
                    <th className="text-right">{labels.amount}</th>
                    <th className="text-right">{labels.due}</th>
                    <th className="text-center">{labels.action}</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.id}>
                      <td className="record-cell-date text-center tabular-nums">{row.date}</td>
                      <td className="record-cell-product" title={row.product}>
                        <span className="block truncate font-black text-slate-900 dark:text-white">{row.product}</span>
                      </td>
                      <td className="record-cell-party" title={row.party}>
                        <span className="block truncate">{row.party}</span>
                      </td>
                      <td className="record-cell-quantity text-center tabular-nums">
                        <span className="font-bold text-slate-800 dark:text-slate-100">{qty(row.quantity)}</span>
                        <span className="ml-1 text-[0.72rem] font-black uppercase tracking-wide text-slate-400">{row.unit}</span>
                      </td>
                      <td className="record-cell-money text-right font-bold tabular-nums text-slate-900 dark:text-slate-100">{money(row.amount)}</td>
                      <td className="record-cell-money text-right tabular-nums">
                        <span className={row.due > 0 ? "font-black text-amber-600 dark:text-amber-300" : "font-bold text-slate-400"}>{money(row.due)}</span>
                      </td>
                      <td className="record-cell-actions">
                        <div className="record-action-icons">
                          {row.due > 0 ? (
                            <FloatingTooltip label={tone === "buy" ? labels.payDue : labels.receiveDue}>
                              <button
                                type="button"
                                onClick={() => onDue(row)}
                                data-action="wallet"
                                className={`action-link pressable record-action-icon border-0 bg-transparent ${tone === "buy" ? "text-red-600 hover:text-red-700 dark:text-red-300" : "text-emerald-600 hover:text-emerald-700 dark:text-emerald-300"}`}
                                aria-label={tone === "buy" ? labels.payDue : labels.receiveDue}
                              >
                                <Wallet size={18} className="action-icon" />
                              </button>
                            </FloatingTooltip>
                          ) : (
                            <span className="record-action-placeholder" aria-hidden="true" />
                          )}
                          <FloatingTooltip label={labels.edit}>
                            <Link href={`/transactions/${row.id}/edit`} data-action="edit" className="action-link pressable record-action-icon text-sky-600 hover:text-sky-800 dark:text-sky-300 dark:hover:text-sky-200" aria-label={labels.edit}>
                              <Pencil size={18} className="action-icon" />
                            </Link>
                          </FloatingTooltip>
                          <FloatingTooltip label={labels.view}>
                            <Link href={`/transactions/${row.id}`} data-action="view" className="action-link pressable record-action-icon text-indigo-600 hover:text-indigo-800 dark:text-indigo-300 dark:hover:text-indigo-200" aria-label={labels.view}>
                              <Eye size={18} className="action-icon" />
                            </Link>
                          </FloatingTooltip>
                          <FloatingTooltip label={labels.delete}>
                            <button disabled={deletingId === row.id} onClick={() => onDelete(row.id)} data-action="delete" className="action-link pressable record-action-icon border-0 bg-transparent text-red-600 hover:text-red-700 disabled:opacity-50 dark:text-red-300" aria-label={labels.delete}>
                              {deletingId === row.id ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} className="action-icon" />}
                            </button>
                          </FloatingTooltip>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
      </div>
    </div>
  );
}

function FloatingTooltip({ label, children }: { label: string; children: React.ReactNode }) {
  const anchorRef = useRef<HTMLSpanElement>(null);
  const [position, setPosition] = useState<{ left: number; top: number; below: boolean } | null>(null);

  function updatePosition() {
    const anchor = anchorRef.current;
    if (!anchor) return;
    const rect = anchor.getBoundingClientRect();
    const below = rect.top < 72;
    setPosition({
      left: rect.left + rect.width / 2,
      top: below ? rect.bottom + 10 : rect.top - 10,
      below,
    });
  }

  function show() {
    updatePosition();
  }

  function hide() {
    setPosition(null);
  }

  const tooltipVisible = position !== null;

  useEffect(() => {
    if (!tooltipVisible) return;
    const sync = () => {
      const anchor = anchorRef.current;
      if (!anchor) return;
      const rect = anchor.getBoundingClientRect();
      const below = rect.top < 72;
      setPosition({ left: rect.left + rect.width / 2, top: below ? rect.bottom + 10 : rect.top - 10, below });
    };
    window.addEventListener("scroll", sync, true);
    window.addEventListener("resize", sync);
    return () => {
      window.removeEventListener("scroll", sync, true);
      window.removeEventListener("resize", sync);
    };
  }, [tooltipVisible]);

  return (
    <span ref={anchorRef} className="record-tooltip-anchor" onMouseEnter={show} onMouseLeave={hide} onFocusCapture={show} onBlurCapture={hide}>
      {children}
      {position ? createPortal(
        <span
          className={`floating-action-tooltip ${position.below ? "floating-action-tooltip-below" : ""}`}
          style={{ left: position.left, top: position.top }}
          role="tooltip"
        >
          {label}
        </span>,
        document.body,
      ) : null}
    </span>
  );
}

function MiniStat({ label, value, warning = false }: { label: string; value: string; warning?: boolean }) {
  return (
    <div className="min-w-0">
      <div className="truncate text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</div>
      <div className={`mt-1 truncate font-black ${warning ? "text-amber-600 dark:text-amber-300" : "text-slate-900 dark:text-white"}`}>{value}</div>
    </div>
  );
}

function DuePaymentModal({ target, onClose, onSaved }: { target: DueTarget; onClose: () => void; onSaved: () => void }) {
  const { t } = useLanguage();
  const [remainingDue, setRemainingDue] = useState(target.row.due);
  const [amount, setAmount] = useState(String(target.row.due));
  const [paymentChannel, setPaymentChannel] = useState<PaymentChannel>("CASH");
  const [bankingMethod, setBankingMethod] = useState<BankingMethod>("BKASH");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const numericAmount = Number(amount) || 0;
  const invalidAmount = remainingDue <= 0 || numericAmount <= 0 || numericAmount > remainingDue;

  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previousOverflow; };
  }, []);

  function chooseFile(nextFile: File | null) {
    if (preview) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(nextFile ? URL.createObjectURL(nextFile) : null);
    if (inputRef.current && !nextFile) inputRef.current.value = "";
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading || invalidAmount) return;
    setLoading(true);
    setSaved(false);
    setError("");
    try {
      const form = new FormData();
      form.set("amount", String(numericAmount));
      form.set("paymentChannel", paymentChannel);
      if (paymentChannel === "BANKING") form.set("bankingMethod", bankingMethod);
      if (file) form.set("attachment", file);

      const response = await fetch(`/api/transactions/${target.row.id}/due`, { method: "POST", body: form });
      const body = (await response.json()) as { message?: string; data?: { paid: number; due: number } };
      if (!response.ok) throw new Error(body.message || t.duePaymentFailed);

      const nextDue = body.data?.due ?? Math.max(remainingDue - numericAmount, 0);
      setRemainingDue(nextDue);
      setAmount(nextDue > 0 ? String(nextDue) : "");
      chooseFile(null);
      setSaved(true);
      onSaved();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : t.duePaymentFailed);
    } finally {
      setLoading(false);
    }
  }

  const toneClass = target.tone === "buy" ? "text-red-600 dark:text-red-300" : "text-emerald-600 dark:text-emerald-300";
  const saveGradient = target.tone === "buy" ? "from-rose-600 via-red-600 to-red-800" : "from-emerald-600 via-green-600 to-teal-800";

  if (typeof document === "undefined") return null;

  return createPortal(
    <div className="fixed inset-0 z-[2147482000] flex items-center justify-center overflow-y-auto bg-slate-950/60 p-3 backdrop-blur-md sm:p-5" role="dialog" aria-modal="true">
      <form onSubmit={submit} className="phase27-modal-card max-h-[calc(100dvh-1.5rem)] w-full max-w-lg overflow-y-auto rounded-[2rem] border border-white/10 bg-white p-4 shadow-[0_35px_100px_rgba(2,6,23,.35)] dark:bg-slate-950 sm:rounded-[2rem] sm:p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className={`text-xs font-black uppercase tracking-[0.16em] ${toneClass}`}>{target.tone === "buy" ? t.buy : t.sell}</p>
            <h2 className="mt-1 text-xl font-black text-slate-950 dark:text-white">{target.tone === "buy" ? t.payDue : t.receiveDue}</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{target.row.party} · {target.row.product}</p>
          </div>
          <button type="button" onClick={onClose} className="pressable border-0 bg-transparent p-1 text-slate-400 hover:text-red-600" aria-label={t.close}><X size={21} className="action-icon" /></button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 rounded-2xl bg-gradient-to-r from-slate-50 to-indigo-50 p-4 dark:from-slate-900 dark:to-indigo-950/50">
          <div><div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{t.currentDue}</div><div className="mt-1 text-xl font-black text-amber-600 dark:text-amber-300">{money(remainingDue)}</div></div>
          <div className="text-right"><div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{t.oldProofs}</div><div className="mt-1 text-xl font-black text-slate-900 dark:text-white">{target.row.proofCount}</div></div>
        </div>

        {saved ? (
          <div className="mt-4 flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-950/30 dark:text-emerald-300">
            <CheckCircle2 size={18} /> {t.paymentSaved}
          </div>
        ) : null}

        <div className="mt-5 space-y-4">
          <label className="block"><span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{target.tone === "buy" ? t.payAmount : t.receiveAmount}</span><input value={amount} onChange={(event) => { setAmount(event.target.value); setSaved(false); }} disabled={remainingDue <= 0} type="number" min="0.01" max={remainingDue} step="0.01" inputMode="decimal" className="input font-bold disabled:opacity-60" required={remainingDue > 0} /></label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block"><span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{t.paymentMethod}</span><select value={paymentChannel} onChange={(event) => setPaymentChannel(event.target.value as PaymentChannel)} disabled={remainingDue <= 0} className="input disabled:opacity-60"><option value="CASH">{t.cash}</option><option value="BANKING">{t.banking}</option></select></label>
            {paymentChannel === "BANKING" ? <label className="block"><span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{t.bankingMethod}</span><select value={bankingMethod} onChange={(event) => setBankingMethod(event.target.value as BankingMethod)} disabled={remainingDue <= 0} className="input disabled:opacity-60"><option value="BKASH">{t.bkash}</option><option value="ROCKET">{t.rocket}</option><option value="NAGAD">{t.nagad}</option><option value="BANK">{t.bank}</option></select></label> : null}
          </div>

          <div>
            <div className="flex items-center justify-between gap-2"><span className="text-xs font-bold text-slate-500 dark:text-slate-400">{t.newProofOptional}</span><span className="text-[11px] text-slate-400">{t.oldProofKept}</span></div>
            <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => chooseFile(event.target.files?.[0] ?? null)} />
            {!preview ? <button disabled={remainingDue <= 0} type="button" onClick={() => inputRef.current?.click()} className="pressable mt-2 flex w-full items-center justify-center gap-2 border-x-0 border-y border-dashed border-slate-300 bg-transparent py-5 text-sm font-bold text-slate-600 hover:text-indigo-700 disabled:opacity-50 dark:border-white/15 dark:text-slate-300 dark:hover:text-indigo-300"><ImagePlus size={19} className="action-icon" /> {t.chooseImage}</button> : (
              <div className="mt-2">
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-slate-900">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={preview} alt={t.preview} className="max-h-52 w-full object-contain" /></div>
                <div className="mt-2 flex justify-between"><button type="button" onClick={() => inputRef.current?.click()} className="pressable border-0 bg-transparent text-xs font-bold text-indigo-600 hover:text-indigo-800 dark:text-indigo-300">{t.replace}</button><button type="button" onClick={() => chooseFile(null)} className="pressable inline-flex items-center gap-1 border-0 bg-transparent text-xs font-bold text-red-600 dark:text-red-300"><X size={14} className="action-icon" /> {t.remove}</button></div>
              </div>
            )}
          </div>

          {invalidAmount && numericAmount > remainingDue ? <p className="text-xs font-bold text-red-600 dark:text-red-300">{t.amountExceedsDue}</p> : null}
          {error ? <div className="rounded-xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 dark:bg-red-950/40 dark:text-red-300">{error}</div> : null}
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
          <Link href={`/receipt/${target.row.id}`} target="_blank" className="pressable inline-flex items-center gap-2 border-0 bg-transparent px-2 py-2 text-sm font-black text-violet-600 hover:text-violet-800 dark:text-violet-300" aria-label={t.openReceipt}>
            <ReceiptText size={17} className="action-icon" /> {t.openReceipt}
          </Link>
          <button type="button" onClick={onClose} className="pressable border-0 bg-transparent px-2 py-2 text-sm font-bold text-slate-500 hover:text-slate-950 dark:text-slate-400 dark:hover:text-white">{t.close}</button>
          {remainingDue > 0 ? (
            <button disabled={loading || invalidAmount} type="submit" className={`premium-button pressable inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r ${saveGradient} px-5 py-3 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-50`}>
              {loading ? <Loader2 size={17} className="animate-spin" /> : <Wallet size={17} className="action-icon" />}
              {loading ? t.saving : target.tone === "buy" ? t.savePayment : t.saveReceive}
            </button>
          ) : null}
        </div>
      </form>
    </div>,
    document.body,
  );
}

function Th({ children }: { children: React.ReactNode }) { return <th className="px-3 py-2.5 font-black">{children}</th>; }
function Td({ children }: { children: React.ReactNode }) { return <td className="px-3 py-3 text-slate-600 dark:text-slate-300">{children}</td>; }
