"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { useLanguage } from "@/components/language-provider";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();
  const isDark = theme === "dark";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? t.dayMode : t.nightMode}
      title={isDark ? t.dayMode : t.nightMode}
      className="theme-icon-button pressable"
    >
      {isDark ? <Sun size={19} strokeWidth={2.1} className="theme-icon" /> : <Moon size={19} strokeWidth={2.1} className="theme-icon" />}
    </button>
  );
}
