"use client";

import { useLanguage } from "@/components/language-provider";

export function LoginIntro() {
  const { t } = useLanguage();
  return (
    <div className="mb-7 sm:mb-8">
      <div className="inline-flex bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-xs font-black tracking-[0.2em] text-transparent">AHD</div>
      <h1 className="mt-4 text-2xl font-black tracking-tight text-slate-950 dark:text-white sm:mt-5 sm:text-[1.7rem]">{t.loginTitle}</h1>
      <p className="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">{t.loginSubtitle}</p>
    </div>
  );
}
