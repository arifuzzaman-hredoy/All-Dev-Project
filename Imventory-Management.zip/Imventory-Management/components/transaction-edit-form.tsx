"use client";

import { ArrowLeft, ExternalLink, ImagePlus, Loader2, PackageCheck, Paperclip, Save, ShoppingBasket, ShoppingCart, X } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useMemo, useRef, useState } from "react";
import { useLanguage } from "@/components/language-provider";
import { displayDateToIso, formatDateTyping, isoToDisplayDate } from "@/lib/date-format";
import type { StockProduct } from "@/components/buy-sell-form";

type Mode = "buy" | "sell";

export type EditTransactionData = {
  id: string;
  mode: Mode;
  partyName: string;
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  totalAmount: number;
  purchaseUnitPrice: number;
  sellingUnitPrice: number;
  sellingPrice: number;
  commissionAmount: number;
  date: string;
  manufacturingDate: string;
  expiryDate: string;
  expiryAlertDays: number;
  paidAmount: number;
  attachments: Array<{ id: string; name: string }>;
};

const moneyFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 2 });
const quantityFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 3 });
const money = (value: number) => `৳${moneyFormatter.format(value)}`;
const quantityLabel = (value: number) => quantityFormatter.format(value);

function positive(value: string) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

export function TransactionEditForm({ initial, stockProducts }: { initial: EditTransactionData; stockProducts: StockProduct[] }) {
  const { t } = useLanguage();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const isBuy = initial.mode === "buy";

  const [partyName, setPartyName] = useState(initial.partyName);
  const [productName, setProductName] = useState(initial.productName);
  const [selectedProductId, setSelectedProductId] = useState(initial.productId);
  const [quantity, setQuantity] = useState(String(initial.quantity));
  const [unit, setUnit] = useState(initial.unit || "UNIT");
  const [purchaseUnitPrice, setPurchaseUnitPrice] = useState(String(initial.purchaseUnitPrice || 0));
  const [sellingUnitPrice, setSellingUnitPrice] = useState(String(initial.sellingUnitPrice || 0));
  const [sellingPrice, setSellingPrice] = useState(String(initial.sellingPrice || 0));
  const [commissionAmount, setCommissionAmount] = useState(String(initial.commissionAmount || 0));
  const [date, setDate] = useState(isoToDisplayDate(initial.date));
  const [manufacturingDate, setManufacturingDate] = useState(isoToDisplayDate(initial.manufacturingDate));
  const [expiryDate, setExpiryDate] = useState(isoToDisplayDate(initial.expiryDate));
  const [expiryAlertDays, setExpiryAlertDays] = useState(String(initial.expiryAlertDays ?? 30));
  const [removedAttachmentIds, setRemovedAttachmentIds] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const quantityNumber = positive(quantity);
  const selectedProduct = stockProducts.find((product) => product.id === selectedProductId) ?? null;
  const purchaseUnitPriceNumber = positive(purchaseUnitPrice);
  const sellUnitPriceNumber = positive(sellingUnitPrice);
  const totalNumber = isBuy
    ? Math.round(quantityNumber * purchaseUnitPriceNumber * 100) / 100
    : Math.round(quantityNumber * sellUnitPriceNumber * 100) / 100;
  const resultingDue = Math.max(totalNumber - initial.paidAmount, 0);
  const exceedsStock = !isBuy && selectedProduct ? quantityNumber > selectedProduct.stockQuantity : false;
  const activeAttachments = initial.attachments.filter((item) => !removedAttachmentIds.includes(item.id));

  const remainingAfterSale = useMemo(() => {
    if (!selectedProduct) return 0;
    return Math.max(selectedProduct.stockQuantity - quantityNumber, 0);
  }, [selectedProduct, quantityNumber]);

  function chooseFile(nextFile: File | null) {
    if (preview) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(nextFile ? URL.createObjectURL(nextFile) : null);
    if (inputRef.current && !nextFile) inputRef.current.value = "";
  }

  function toggleAttachment(id: string) {
    setRemovedAttachmentIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setError("");

    if (!partyName.trim()) return setError(`${t.party} is required.`);
    if (quantityNumber <= 0) return setError(t.quantityMustBePositive);
    if (!isBuy && !selectedProduct) return setError(t.selectProductFromStock);
    if (exceedsStock) return setError(t.notEnoughStock);
    if (totalNumber <= 0) return setError(`${t.amount} must be greater than zero.`);
    if (totalNumber < initial.paidAmount) return setError(t.totalCannotBeBelowPaid);
    if (file && file.size > 5 * 1024 * 1024) return setError("Attachment must be 5 MB or smaller.");

    const dateIso = displayDateToIso(date);
    const manufacturingDateIso = manufacturingDate ? displayDateToIso(manufacturingDate) : "";
    const expiryDateIso = expiryDate ? displayDateToIso(expiryDate) : "";
    if (!dateIso || (manufacturingDate && !manufacturingDateIso) || (expiryDate && !expiryDateIso)) {
      return setError("তারিখ DD/MM/YYYY ফরম্যাটে দিন। / Use DD/MM/YYYY date format.");
    }

    setLoading(true);
    try {
      const form = new FormData();
      form.set("partyName", partyName);
      form.set("quantity", quantity);
      form.set("date", dateIso);
      form.set("totalAmount", String(totalNumber));

      if (isBuy) {
        form.set("productName", productName);
        form.set("unit", unit);
        form.set("purchaseUnitPrice", purchaseUnitPrice);
        form.set("sellingPrice", sellingPrice);
        form.set("commissionAmount", commissionAmount);
        form.set("manufacturingDate", manufacturingDateIso || "");
        form.set("expiryDate", expiryDateIso || "");
        form.set("expiryAlertDays", expiryAlertDays);
      } else {
        form.set("productId", selectedProductId);
        form.set("sellingUnitPrice", sellingUnitPrice);
      }

      removedAttachmentIds.forEach((id) => form.append("removeAttachmentIds", id));
      if (file) form.set("attachment", file);

      const response = await fetch(`/api/transactions/${initial.id}`, { method: "PUT", body: form });
      const body = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(body.message || t.updateFailed);

      router.push("/dashboard");
      router.refresh();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : t.updateFailed);
    } finally {
      setLoading(false);
    }
  }

  const toneText = isBuy ? "text-rose-600 dark:text-rose-300" : "text-emerald-600 dark:text-emerald-300";
  const saveGradient = isBuy ? "from-rose-600 via-red-700 to-red-950" : "from-emerald-600 via-green-700 to-teal-950";
  const ToneIcon = isBuy ? ShoppingBasket : ShoppingCart;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-5 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <p className={`text-xs font-black uppercase tracking-[0.18em] ${toneText}`}>{isBuy ? t.buy : t.sell}</p>
          <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-950 dark:text-white sm:text-3xl">{t.editRecord}</h1>
        </div>
        <Link href="/dashboard" className="action-link pressable inline-flex items-center gap-2 text-sm font-bold text-indigo-600 dark:text-indigo-300">
          <ArrowLeft size={17} /> {t.backDashboard}
        </Link>
      </div>

      <form onSubmit={submit} className="liquid-form grid gap-4 2xl:grid-cols-[1.35fr_0.65fr]" data-mode={initial.mode}>
        <div className="space-y-4">
          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
            <div className="grid gap-4 md:grid-cols-2">
              {isBuy ? (
                <Field label={t.productName} className="md:col-span-2">
                  <input value={productName} onChange={(event) => setProductName(event.target.value)} required maxLength={160} className="input" />
                </Field>
              ) : (
                <Field label={t.productName} className="md:col-span-2">
                  <select value={selectedProductId} onChange={(event) => setSelectedProductId(event.target.value)} required className="input">
                    <option value="">{t.selectProductFromStock}</option>
                    {stockProducts.map((product) => (
                      <option key={product.id} value={product.id}>{product.name} — {quantityLabel(product.stockQuantity)} {product.unit}</option>
                    ))}
                  </select>
                </Field>
              )}

              <Field label={isBuy ? t.companyPartyName : t.sellToParty} className="md:col-span-2">
                <input value={partyName} onChange={(event) => setPartyName(event.target.value)} required maxLength={160} className="input" />
              </Field>

              <Field label={t.quantityLabel}>
                <input value={quantity} onChange={(event) => setQuantity(event.target.value)} required type="number" min="0.001" step="0.001" max={!isBuy && selectedProduct ? selectedProduct.stockQuantity : undefined} className="input" />
              </Field>

              {isBuy ? (
                <Field label={t.unit}>
                  <select value={unit} onChange={(event) => setUnit(event.target.value)} className="input">
                    <option value="BOX">{t.box}</option>
                    <option value="UNIT">{t.piece}</option>
                  </select>
                </Field>
              ) : (
                <Field label={t.unit}>
                  <div className="input flex items-center bg-slate-50 font-bold text-slate-700 dark:bg-slate-900 dark:text-slate-200">{selectedProduct?.unit ?? initial.unit}</div>
                </Field>
              )}

              {!isBuy && selectedProduct ? (
                <div className="liquid-inline md:col-span-2 grid grid-cols-1 gap-3 rounded-2xl p-3 min-[420px]:grid-cols-2">
                  <div><div className="text-[11px] font-bold uppercase tracking-wide text-emerald-700/60">{t.availableStock}</div><div className="mt-1 text-lg font-black text-emerald-700">{quantityLabel(selectedProduct.stockQuantity)} {selectedProduct.unit}</div></div>
                  <div className="text-left min-[420px]:text-right"><div className="text-[11px] font-bold uppercase tracking-wide text-emerald-700/60">{t.afterSaleStock}</div><div className={`mt-1 text-lg font-black ${exceedsStock ? "text-red-600" : "text-emerald-700"}`}>{quantityLabel(remainingAfterSale)} {selectedProduct.unit}</div></div>
                </div>
              ) : null}

              {isBuy ? (
                <>
                  <Field label={t.purchaseUnitPrice}>
                    <input value={purchaseUnitPrice} onChange={(event) => setPurchaseUnitPrice(event.target.value)} required type="number" min="0.01" step="0.01" inputMode="decimal" className="input font-bold" />
                  </Field>
                  <Field label={t.totalPurchaseAmountAuto}>
                    <div className="input flex items-center justify-between bg-rose-50 font-black text-rose-700 dark:bg-rose-950/30 dark:text-rose-300"><span>{money(totalNumber)}</span><span className="text-[10px] font-bold uppercase tracking-wide opacity-60">{t.automatic}</span></div>
                    <p className="mt-1.5 text-[11px] font-semibold text-slate-400">{t.quantityTimesPurchasePrice}</p>
                  </Field>
                </>
              ) : (
                <>
                  <Field label={t.sellingUnitPrice}>
                    <input value={sellingUnitPrice} onChange={(event) => setSellingUnitPrice(event.target.value)} required type="number" min="0.01" step="0.01" inputMode="decimal" className="input font-bold" />
                  </Field>
                  <Field label={t.totalSellingAmountAuto}>
                    <div className="input flex items-center justify-between bg-emerald-50 font-black text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300"><span>{money(totalNumber)}</span><span className="text-[10px] font-bold uppercase tracking-wide opacity-60">{t.automatic}</span></div>
                  </Field>
                </>
              )}

              {isBuy ? (
                <>
                  <Field label={t.sellingPrice}>
                    <input value={sellingPrice} onChange={(event) => setSellingPrice(event.target.value)} type="number" min="0" step="0.01" inputMode="decimal" className="input" />
                  </Field>
                  <Field label={t.commissionOptional}>
                    <input value={commissionAmount} onChange={(event) => setCommissionAmount(event.target.value)} type="number" min="0" step="0.01" inputMode="decimal" className="input" />
                  </Field>
                </>
              ) : null}

              <Field label={t.date} className="md:col-span-2">
                <input value={date} onChange={(event) => setDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" required maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" />
              </Field>
            </div>
          </section>

          {isBuy ? (
            <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
              <div className="grid gap-4 md:grid-cols-3">
                <Field label={t.manufactureDate}><input value={manufacturingDate} onChange={(event) => setManufacturingDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" /></Field>
                <Field label={t.expiryDate}><input value={expiryDate} onChange={(event) => setExpiryDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" /></Field>
                <Field label={t.alertBeforeExpiry}>
                  <div className="relative"><input value={expiryAlertDays} onChange={(event) => setExpiryAlertDays(event.target.value)} type="number" min="0" max="3650" className="input pr-14" /><span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">{t.days}</span></div>
                </Field>
              </div>
            </section>
          ) : null}

          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
            <div className="mb-4 flex items-center gap-2"><PackageCheck size={18} className="text-indigo-500" /><h2 className="font-black">{t.payment}</h2></div>
            <p className="text-sm leading-6 text-slate-500 dark:text-slate-400">{t.paymentHistoryProtected}</p>
            <div className="liquid-inline mt-4 grid grid-cols-2 gap-3 rounded-2xl p-3">
              <div><div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{t.paid}</div><div className="mt-1 text-lg font-black text-slate-900 dark:text-white">{money(initial.paidAmount)}</div></div>
              <div className="text-right"><div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{isBuy ? t.due : t.amountToReceive}</div><div className={`mt-1 text-lg font-black ${resultingDue > 0 ? "text-amber-600 dark:text-amber-300" : "text-slate-900 dark:text-white"}`}>{money(resultingDue)}</div></div>
            </div>
          </section>
        </div>

        <div className="space-y-4">
          <section className={`premium-total-card liquid-total-card relative overflow-hidden rounded-[1.65rem] p-5 text-white shadow-xl bg-gradient-to-br ${saveGradient}`}>
            <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/10" />
            <div className="flex items-center gap-2 text-white/80"><ToneIcon size={18} /><span className="text-sm font-bold">{t.editRecord}</span></div>
            <div className="mt-5 flex items-center justify-between text-sm text-white/75"><span>{t.totalAmount}</span><span className="font-bold text-white">{money(totalNumber)}</span></div>
            <div className="my-4 h-px bg-white/20" />
            <div className="flex items-center justify-between text-sm text-white/75"><span>{t.paid}</span><span className="font-bold text-white">{money(initial.paidAmount)}</span></div>
            <div className="mt-4 flex items-end justify-between gap-3"><span className="text-sm text-white/80">{t.due}</span><strong className="text-3xl tracking-tight">{money(resultingDue)}</strong></div>
          </section>

          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5">
            <div className="flex items-center gap-2"><Paperclip size={18} className="text-slate-400" /><h2 className="font-black">{t.existingProofs}</h2></div>
            {initial.attachments.length === 0 ? <p className="mt-3 text-sm text-slate-400">{t.noAttachment}</p> : (
              <div className="mt-3 space-y-2">
                {initial.attachments.map((attachment) => {
                  const removed = removedAttachmentIds.includes(attachment.id);
                  return (
                    <div key={attachment.id} className={`flex items-center justify-between gap-3 rounded-xl border px-3 py-2.5 ${removed ? "border-red-300/50 bg-red-50/70 opacity-60 dark:bg-red-950/20" : "border-slate-200/70 bg-white/50 dark:border-white/10 dark:bg-slate-900/40"}`}>
                      <a href={`/api/attachments/${attachment.id}`} target="_blank" rel="noreferrer" className="min-w-0 inline-flex items-center gap-2 text-sm font-bold text-indigo-600 dark:text-indigo-300"><ExternalLink size={14} /><span className="truncate">{attachment.name}</span></a>
                      <button type="button" onClick={() => toggleAttachment(attachment.id)} className={`pressable shrink-0 border-0 bg-transparent text-xs font-black ${removed ? "text-emerald-600" : "text-red-600"}`}>{removed ? t.cancel : t.remove}</button>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-5 border-t border-slate-200/70 pt-4 dark:border-white/10">
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">{t.newProofOptionalEdit}</p>
              <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => chooseFile(event.target.files?.[0] ?? null)} />
              {!preview ? (
                <button type="button" onClick={() => inputRef.current?.click()} className="liquid-upload-zone pressable mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed px-4 py-7 text-sm font-bold text-indigo-700 dark:text-indigo-300"><ImagePlus size={19} /> {t.chooseImage}</button>
              ) : (
                <div className="mt-3">
                  <div className="liquid-preview-frame overflow-hidden rounded-2xl border">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={preview} alt={t.preview} className="max-h-64 w-full object-contain" /></div>
                  <div className="mt-2 flex justify-between"><button type="button" onClick={() => inputRef.current?.click()} className="pressable border-0 bg-transparent text-xs font-bold text-indigo-600">{t.replace}</button><button type="button" onClick={() => chooseFile(null)} className="pressable inline-flex items-center gap-1 border-0 bg-transparent text-xs font-bold text-red-600"><X size={14} /> {t.remove}</button></div>
                </div>
              )}
            </div>
          </section>

          {error ? <div className="rounded-2xl border border-red-200/70 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 dark:border-red-500/20 dark:bg-red-950/35 dark:text-red-300">{error}</div> : null}

          <button disabled={loading || exceedsStock || totalNumber < initial.paidAmount} type="submit" className={`premium-button pressable flex min-h-12 w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r ${saveGradient} px-5 py-3.5 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-60`}>
            {loading ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
            {loading ? t.updating : t.saveChanges}
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className}`}><span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{label}</span>{children}</label>;
}
