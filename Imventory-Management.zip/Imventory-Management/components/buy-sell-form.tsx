"use client";

import { ImagePlus, Loader2, PackageCheck, Paperclip, ShoppingBasket, ShoppingCart, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useMemo, useRef, useState } from "react";
import { useLanguage } from "@/components/language-provider";
import { displayDateToIso, formatDateTyping, todayDisplayDate } from "@/lib/date-format";

type Mode = "buy" | "sell";
type PaymentChannel = "CASH" | "BANKING";
type BankingMethod = "BKASH" | "ROCKET" | "NAGAD" | "BANK";

export type StockProduct = {
  id: string;
  name: string;
  unit: string;
  stockQuantity: number;
};

function numberValue(value: string) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

const moneyFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 2 });
const quantityFormatter = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 3 });

function money(value: number) {
  return `৳${moneyFormatter.format(value)}`;
}

function quantityLabel(value: number) {
  return quantityFormatter.format(value);
}


export function BuySellForm({ mode, stockProducts }: { mode: Mode; stockProducts: StockProduct[] }) {
  const router = useRouter();
  const { t } = useLanguage();
  const inputRef = useRef<HTMLInputElement>(null);
  const [purchaseUnitPrice, setPurchaseUnitPrice] = useState("");
  const [sellingUnitPrice, setSellingUnitPrice] = useState("");
  const [paidAmount, setPaidAmount] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [selectedProductId, setSelectedProductId] = useState("");
  const [paymentChannel, setPaymentChannel] = useState<PaymentChannel>("CASH");
  const [bankingMethod, setBankingMethod] = useState<BankingMethod>("BKASH");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [transactionDate, setTransactionDate] = useState(todayDisplayDate());
  const [manufacturingDate, setManufacturingDate] = useState("");
  const [expiryDate, setExpiryDate] = useState("");

  const isBuy = mode === "buy";
  const quantityNumber = numberValue(quantity);
  const purchaseUnitPriceNumber = numberValue(purchaseUnitPrice);
  const sellingUnitPriceNumber = numberValue(sellingUnitPrice);
  const calculatedBuyTotal = Math.round(quantityNumber * purchaseUnitPriceNumber * 100) / 100;
  const calculatedSellTotal = Math.round(quantityNumber * sellingUnitPriceNumber * 100) / 100;
  const totalNumber = isBuy ? calculatedBuyTotal : calculatedSellTotal;
  const paid = useMemo(() => numberValue(paidAmount), [paidAmount]);
  const due = Math.max(totalNumber - paid, 0);
  const selectedProduct = stockProducts.find((product) => product.id === selectedProductId) ?? null;
  const remainingAfterSale = selectedProduct ? Math.max(selectedProduct.stockQuantity - quantityNumber, 0) : 0;
  const exceedsStock = !isBuy && selectedProduct ? quantityNumber > selectedProduct.stockQuantity : false;

  function chooseFile(nextFile: File | null) {
    if (preview) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(nextFile ? URL.createObjectURL(nextFile) : null);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setError("");

    if (!isBuy && !selectedProduct) {
      setError(t.selectProductFromStock);
      return;
    }
    if (quantityNumber <= 0) {
      setError(t.quantityMustBePositive);
      return;
    }
    if (exceedsStock) {
      setError(t.notEnoughStock);
      return;
    }
    if (totalNumber <= 0) {
      setError(isBuy ? `${t.purchaseAmount} must be greater than zero.` : `${t.sellingAmount} must be greater than zero.`);
      return;
    }
    if (paid > totalNumber) {
      setError(t.paidCannotExceedTotal);
      return;
    }
    if (file && file.size > 5 * 1024 * 1024) {
      setError("Attachment must be 5 MB or smaller.");
      return;
    }

    const transactionDateIso = displayDateToIso(transactionDate);
    const manufacturingDateIso = manufacturingDate ? displayDateToIso(manufacturingDate) : "";
    const expiryDateIso = expiryDate ? displayDateToIso(expiryDate) : "";
    if (!transactionDateIso || (manufacturingDate && !manufacturingDateIso) || (expiryDate && !expiryDateIso)) {
      setError("তারিখ DD/MM/YYYY ফরম্যাটে দিন। / Use DD/MM/YYYY date format.");
      return;
    }

    setLoading(true);
    try {
      const form = new FormData(event.currentTarget);
      form.set("date", transactionDateIso);
      form.set("manufacturingDate", manufacturingDateIso || "");
      form.set("expiryDate", expiryDateIso || "");
      form.set("type", isBuy ? "PURCHASE" : "SALE");
      form.set("totalAmount", String(totalNumber));
      form.set("quantity", quantity);
      if (isBuy) form.set("purchaseUnitPrice", purchaseUnitPrice);
      else form.set("sellingUnitPrice", sellingUnitPrice);
      form.set("paidAmount", paidAmount);
      form.set("paymentChannel", paymentChannel);
      form.set("bankingMethod", paymentChannel === "BANKING" ? bankingMethod : "");
      if (!isBuy) form.set("productId", selectedProductId);
      if (file) form.set("attachment", file);

      const response = await fetch("/api/transactions", { method: "POST", body: form });
      const body = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(body.message || t.saveFailed);
      router.push("/dashboard");
      router.refresh();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : t.saveFailed);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-5">
        <p className={`text-xs font-black uppercase tracking-[0.18em] ${isBuy ? "text-rose-600 dark:text-rose-300" : "text-emerald-600 dark:text-emerald-300"}`}>{isBuy ? t.buy : t.sell}</p>
        <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-950 dark:text-white sm:text-3xl">{isBuy ? t.newBuy : t.newSell}</h1>
      </div>

      <form onSubmit={submit} className="liquid-form grid gap-4 2xl:grid-cols-[1.35fr_0.65fr]" data-mode={mode}>
        <div className="space-y-4">
          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
            <div className="grid gap-4 md:grid-cols-2">
              {isBuy ? (
                <Field label={t.productName} className="md:col-span-2">
                  <input name="productName" required maxLength={160} className="input" placeholder={t.productName} />
                </Field>
              ) : (
                <Field label={t.productName} className="md:col-span-2">
                  <select
                    name="productId"
                    required
                    value={selectedProductId}
                    onChange={(event) => setSelectedProductId(event.target.value)}
                    className="input"
                  >
                    <option value="">{t.selectProductFromStock}</option>
                    {stockProducts.map((product) => (
                      <option key={product.id} value={product.id}>
                        {product.name} — {quantityLabel(product.stockQuantity)} {product.unit}
                      </option>
                    ))}
                  </select>
                  {stockProducts.length === 0 ? <p className="mt-2 text-xs font-semibold text-amber-600">{t.noStockProducts}</p> : null}
                </Field>
              )}

              <Field label={isBuy ? t.companyPartyName : t.sellToParty} className="md:col-span-2">
                <input name="partyName" required maxLength={160} className="input" placeholder={isBuy ? t.companyPartyName : t.sellToParty} />
              </Field>

              <Field label={t.quantityLabel}>
                <input
                  name="quantity"
                  required
                  type="number"
                  min="0.001"
                  step="0.001"
                  max={!isBuy && selectedProduct ? selectedProduct.stockQuantity : undefined}
                  value={quantity}
                  onChange={(event) => setQuantity(event.target.value)}
                  className="input"
                />
              </Field>

              {isBuy ? (
                <Field label={t.unit}>
                  <select name="unit" defaultValue="BOX" className="input">
                    <option value="BOX">{t.box}</option>
                    <option value="UNIT">{t.piece}</option>
                  </select>
                </Field>
              ) : (
                <Field label={t.unit}>
                  <div className="input flex items-center bg-slate-50 font-bold text-slate-700 dark:bg-slate-900 dark:text-slate-200">
                    {selectedProduct?.unit ?? "—"}
                  </div>
                </Field>
              )}

              {!isBuy && selectedProduct ? (
                <div className="liquid-inline md:col-span-2 grid grid-cols-1 gap-3 rounded-2xl min-[420px]:grid-cols-2 p-3">
                  <div>
                    <div className="text-[11px] font-bold uppercase tracking-wide text-emerald-700/60">{t.availableStock}</div>
                    <div className="mt-1 text-lg font-black text-emerald-700">{quantityLabel(selectedProduct.stockQuantity)} {selectedProduct.unit}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[11px] font-bold uppercase tracking-wide text-emerald-700/60">{t.afterSaleStock}</div>
                    <div className={`mt-1 text-lg font-black ${exceedsStock ? "text-red-600 dark:text-red-300" : "text-slate-900 dark:text-white"}`}>
                      {quantityLabel(remainingAfterSale)} {selectedProduct.unit}
                    </div>
                  </div>
                </div>
              ) : null}

              {isBuy ? (
                <>
                  <Field label={t.purchaseUnitPrice}>
                    <input
                      value={purchaseUnitPrice}
                      onChange={(event) => setPurchaseUnitPrice(event.target.value)}
                      required
                      type="number"
                      min="0.01"
                      step="0.01"
                      inputMode="decimal"
                      className="input font-bold"
                      placeholder="0.00"
                    />
                  </Field>
                  <Field label={t.totalPurchaseAmountAuto}>
                    <div className="input flex items-center justify-between bg-rose-50 font-black text-rose-700 dark:bg-rose-950/30 dark:text-rose-300">
                      <span>{money(totalNumber)}</span>
                      <span className="text-[10px] font-bold uppercase tracking-wide opacity-60">{t.automatic}</span>
                    </div>
                    <p className="mt-1.5 text-[11px] font-semibold text-slate-400">{t.quantityTimesPurchasePrice}</p>
                  </Field>
                </>
              ) : (
                <>
                  <Field label={t.sellingUnitPrice}>
                    <input
                      value={sellingUnitPrice}
                      onChange={(event) => setSellingUnitPrice(event.target.value)}
                      required
                      type="number"
                      min="0.01"
                      step="0.01"
                      inputMode="decimal"
                      className="input font-bold"
                      placeholder="0.00"
                    />
                  </Field>
                  <Field label={t.totalSellingAmountAuto}>
                    <div className="input flex items-center justify-between bg-emerald-50 font-black text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300">
                      <span>{money(totalNumber)}</span>
                      <span className="text-[10px] font-bold uppercase tracking-wide opacity-60">{t.automatic}</span>
                    </div>
                    <p className="mt-1.5 text-[11px] font-semibold text-slate-400">{t.quantityTimesPrice}</p>
                  </Field>
                </>
              )}

              {isBuy ? (
                <Field label={t.sellingPrice}>
                  <input name="sellingPrice" type="number" min="0" step="0.01" inputMode="decimal" className="input" placeholder="0.00" />
                </Field>
              ) : null}

              {isBuy ? (
                <Field label={t.commissionOptional} className="md:col-span-2">
                  <input name="commissionAmount" type="number" min="0" step="0.01" inputMode="decimal" className="input" placeholder="0.00" />
                </Field>
              ) : null}

              <Field label={t.date} className="md:col-span-2">
                <input value={transactionDate} onChange={(event) => setTransactionDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" required maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" />
              </Field>
            </div>
          </section>

          {isBuy ? (
            <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
              <div className="grid gap-4 md:grid-cols-3">
                <Field label={t.manufactureDate}>
                  <input value={manufacturingDate} onChange={(event) => setManufacturingDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" />
                </Field>
                <Field label={t.expiryDate}>
                  <input value={expiryDate} onChange={(event) => setExpiryDate(formatDateTyping(event.target.value))} type="text" inputMode="numeric" autoComplete="off" maxLength={10} pattern="\d{2}/\d{2}/\d{4}" placeholder="DD/MM/YYYY" className="input tabular-nums" />
                </Field>
                <Field label={t.alertBeforeExpiry}>
                  <div className="relative">
                    <input name="expiryAlertDays" type="number" min="0" max="3650" defaultValue="30" className="input pr-14" />
                    <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">{t.days}</span>
                  </div>
                </Field>
              </div>
            </section>
          ) : null}

          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5 md:p-6">
            <div className="mb-4">
              <h2 className="font-black">{t.payment}</h2>
              <p className="mt-1 text-xs leading-5 text-slate-400">{t.paymentDueHint}</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label={t.paymentMethod}>
                <select value={paymentChannel} onChange={(event) => setPaymentChannel(event.target.value as PaymentChannel)} className="input">
                  <option value="CASH">{t.cash}</option>
                  <option value="BANKING">{t.banking}</option>
                </select>
              </Field>

              {paymentChannel === "BANKING" ? (
                <Field label={t.bankingMethod}>
                  <select value={bankingMethod} onChange={(event) => setBankingMethod(event.target.value as BankingMethod)} className="input">
                    <option value="BKASH">{t.bkash}</option>
                    <option value="ROCKET">{t.rocket}</option>
                    <option value="NAGAD">{t.nagad}</option>
                    <option value="BANK">{t.bank}</option>
                  </select>
                </Field>
              ) : <div className="hidden md:block" />}

              <Field label={isBuy ? t.paidAmount : t.customerPaidNow} className="md:col-span-2">
                <input
                  value={paidAmount}
                  onChange={(event) => setPaidAmount(event.target.value)}
                  type="number"
                  min="0"
                  step="0.01"
                  inputMode="decimal"
                  className="input font-bold"
                  placeholder="0.00"
                />
              </Field>
            </div>

            <div className="liquid-inline mt-4 grid grid-cols-2 gap-3 rounded-2xl p-3">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{isBuy ? t.paidNow : t.receivedNow}</div>
                <div className="mt-1 text-lg font-black text-slate-900 dark:text-white">{money(paid)}</div>
              </div>
              <div className="text-right">
                <div className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{isBuy ? t.due : t.amountToReceive}</div>
                <div className={`mt-1 text-lg font-black ${due > 0 ? "text-amber-600 dark:text-amber-300" : "text-slate-900 dark:text-white"}`}>{money(due)}</div>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-4">
          {!isBuy && selectedProduct ? (
            <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] border-emerald-200/80 p-4 dark:border-emerald-500/15 sm:p-5">
              <div className="flex items-center gap-2 text-emerald-700">
                <PackageCheck size={18} />
                <h2 className="font-black">{t.stockBalance}</h2>
              </div>
              <div className="mt-4 flex items-end justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-slate-400">{t.currentStock}</div>
                  <div className="mt-1 text-2xl font-black text-slate-950 dark:text-white">{quantityLabel(selectedProduct.stockQuantity)} {selectedProduct.unit}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-400">{t.afterSaleStock}</div>
                  <div className={`mt-1 text-2xl font-black ${exceedsStock ? "text-red-600" : "text-emerald-600"}`}>{quantityLabel(remainingAfterSale)} {selectedProduct.unit}</div>
                </div>
              </div>
              {exceedsStock ? <p className="mt-3 text-xs font-bold text-red-600">{t.notEnoughStock}</p> : null}
            </section>
          ) : null}

          <section className={`premium-total-card liquid-total-card relative overflow-hidden rounded-[1.65rem] p-5 text-white shadow-xl ${isBuy ? "bg-gradient-to-br from-rose-600 via-red-700 to-red-950 shadow-red-950/15" : "bg-gradient-to-br from-emerald-600 via-green-700 to-teal-950 shadow-emerald-950/15"}`}>
            <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/10" />
            <div className="flex items-center justify-between text-sm text-white/75">
              <span>{t.totalAmount}</span>
              <span className="font-bold text-white">{money(totalNumber)}</span>
            </div>
            <div className="my-4 h-px bg-white/20" />
            <div className="flex items-center justify-between text-sm text-white/75">
              <span>{isBuy ? t.paidNow : t.customerPaidNow}</span>
              <span className="font-bold text-white">{money(paid)}</span>
            </div>
            <div className="mt-4 flex items-end justify-between gap-3">
              <span className="text-sm text-white/80">{isBuy ? t.due : t.amountToReceive}</span>
              <strong className="text-3xl tracking-tight">{money(due)}</strong>
            </div>
          </section>

          <section className="premium-surface liquid-form-surface motion-panel rounded-[1.65rem] p-4 sm:p-5">
            <div className="flex items-center gap-2">
              <Paperclip size={18} className="text-slate-400" />
              <h2 className="font-black">{t.proofAttachment}</h2>
            </div>
            <p className="mt-1 text-xs text-slate-400">{t.attachmentHint}</p>
            <input
              ref={inputRef}
              name="attachmentInput"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(event) => chooseFile(event.target.files?.[0] ?? null)}
            />
            {!preview ? (
              <button type="button" onClick={() => inputRef.current?.click()} className="liquid-upload-zone pressable mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed px-4 py-8 text-sm font-bold text-indigo-700 transition dark:text-indigo-300">
                <ImagePlus size={20} className="action-icon" /> {t.chooseImage}
              </button>
            ) : (
              <div className="mt-4">
                <div className="liquid-preview-frame overflow-hidden rounded-2xl border">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={preview} alt={t.preview} className="max-h-72 w-full object-contain" />
                </div>
                <div className="mt-3 flex items-center justify-between gap-3">
                  <button type="button" onClick={() => inputRef.current?.click()} className="pressable border-0 bg-transparent text-sm font-bold text-indigo-600 hover:text-indigo-800 dark:text-indigo-300">{t.replace}</button>
                  <button type="button" onClick={() => chooseFile(null)} className="pressable inline-flex items-center gap-1 border-0 bg-transparent text-sm font-bold text-red-600 hover:text-red-700 dark:text-red-300"><X size={16} /> {t.remove}</button>
                </div>
              </div>
            )}
          </section>

          {error ? <div className="rounded-2xl border border-red-200/70 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 dark:border-red-500/20 dark:bg-red-950/35 dark:text-red-300">{error}</div> : null}

          <button
            disabled={loading || (!isBuy && (!selectedProduct || exceedsStock || stockProducts.length === 0))}
            type="submit"
            className={`premium-button pressable flex min-h-12 w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r px-5 py-3.5 text-sm font-black text-white transition disabled:cursor-not-allowed disabled:opacity-60 ${isBuy ? "from-rose-600 via-red-700 to-red-950" : "from-emerald-600 via-green-700 to-teal-950"}`}
          >
            {loading ? <Loader2 size={18} className="animate-spin" /> : (
              <span className="semantic-action-icon" data-motion={isBuy ? "buy" : "sell"}>
                {isBuy ? <ShoppingBasket size={19} className="semantic-icon-svg" /> : <ShoppingCart size={19} className="semantic-icon-svg" />}
              </span>
            )}
            {loading ? t.saving : isBuy ? t.saveBuy : t.saveSell}
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{label}</span>
      {children}
    </label>
  );
}
