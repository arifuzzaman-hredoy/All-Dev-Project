"use client";

import { LogOut } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useLanguage } from "@/components/language-provider";

export function LogoutButton() {
  const router = useRouter();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);

  async function logout() {
    if (loading) return;
    setLoading(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.replace("/login");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      type="button"
      onClick={logout}
      disabled={loading}
      className="logout-button pressable inline-flex items-center gap-2 px-1.5 py-2 text-sm font-bold text-slate-500 transition disabled:opacity-50 dark:text-slate-400"
    >
      <LogOut size={17} strokeWidth={2.1} className="logout-icon" />
      <span className="hidden sm:inline">{t.logout}</span>
    </button>
  );
}
