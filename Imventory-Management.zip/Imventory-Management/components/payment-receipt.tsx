"use client";

import Link from "next/link";
import { ArrowLeft, Printer } from "lucide-react";
import { LanguageSwitch } from "@/components/language-switch";
import { useLanguage } from "@/components/language-provider";

type PaymentMethod = "CASH" | "BKASH" | "ROCKET" | "NAGAD" | "BANK";

type ReceiptData = {
  id: string;
  receiptNo: string;
  type: "PURCHASE" | "SALE";
  date: string;
  party: string;
  product: string;
  quantity: number;
  unit: string;
  total: number;
  unitPrice: number;
  paid: number;
  due: number;
  note: string | null;
  payments: Array<{ id: string; method: PaymentMethod; amount: number; date: string }>;
};

export function PaymentReceipt({ receipt }: { receipt: ReceiptData }) {
  const { language, t } = useLanguage();
  const locale = language === "bn" ? "bn-BD" : "en-BD";
  const isBuy = receipt.type === "PURCHASE";
  const isPaid = receipt.due <= 0;

  const money = (value: number) =>
    `৳${new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(value)}`;
  const quantity = new Intl.NumberFormat(locale, { maximumFractionDigits: 3 }).format(receipt.quantity);
  const date = (value: string) =>
    new Intl.DateTimeFormat(locale, { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value));

  const methodLabel = (method: PaymentMethod) => {
    if (method === "CASH") return t.cash;
    if (method === "BKASH") return t.bkash;
    if (method === "ROCKET") return t.rocket;
    if (method === "NAGAD") return t.nagad;
    return t.bank;
  };

  return (
    <div className="receipt-page-wrap min-h-screen bg-neutral-100 px-3 py-5 sm:px-6 sm:py-8">
      <div className="receipt-toolbar mx-auto mb-4 flex w-full max-w-[210mm] flex-col items-stretch justify-between gap-3 sm:flex-row sm:items-center">
        <Link
          href={`/transactions/${receipt.id}`}
          className="pressable inline-flex items-center gap-2 text-sm font-bold text-neutral-700 hover:text-black"
        >
          <ArrowLeft size={17} /> {t.backToRecord}
        </Link>
        <div className="flex items-center gap-3">
          <LanguageSwitch />
          <button
            type="button"
            onClick={() => window.print()}
            className="pressable inline-flex items-center gap-2 rounded-lg bg-black px-4 py-2.5 text-sm font-bold text-white hover:bg-neutral-800"
          >
            <Printer size={17} /> {t.printReceipt}
          </button>
        </div>
      </div>

      <article className="receipt-paper mx-auto w-full max-w-[210mm] bg-white text-black shadow-lg">
        <div className="receipt-content px-[14mm] py-[12mm] sm:px-[16mm]">
          <header className="flex items-start justify-between gap-8 border-b-2 border-black pb-5">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-neutral-600">{t.appName}</p>
              <h1 className="mt-1 text-2xl font-black tracking-tight">{t.paymentReceipt}</h1>
            </div>
            <div className="shrink-0 text-right text-xs leading-5">
              <p><span className="font-bold">{t.receiptNo}:</span> {receipt.receiptNo}</p>
              <p><span className="font-bold">{t.date}:</span> {date(receipt.date)}</p>
            </div>
          </header>

          <section className="grid grid-cols-2 border-b border-black py-4 text-sm">
            <div className="pr-4">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-neutral-500">
                {isBuy ? t.supplierParty : t.customerParty}
              </p>
              <p className="mt-1 font-bold">{receipt.party}</p>
            </div>
            <div className="border-l border-black pl-4 text-right">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-neutral-500">{t.transactionType}</p>
              <p className="mt-1 font-bold">{isBuy ? t.buy : t.sell}</p>
            </div>
          </section>

          <section className="mt-5">
            <table className="receipt-table w-full border-collapse text-left text-xs">
              <thead>
                <tr>
                  <th>{t.product}</th>
                  <th className="text-center">{t.quantity}</th>
                  <th className="text-center">{t.unit}</th>
                  <th className="text-right">{t.unitPrice}</th>
                  <th className="text-right">{t.totalAmount}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="font-bold">{receipt.product}</td>
                  <td className="text-center">{quantity}</td>
                  <td className="text-center">{receipt.unit || "—"}</td>
                  <td className="text-right">{money(receipt.unitPrice)}</td>
                  <td className="text-right font-bold">{money(receipt.total)}</td>
                </tr>
              </tbody>
            </table>
          </section>

          <section className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-[1fr_245px]">
            <div>
              <div className="mb-2 flex items-center justify-between gap-4">
                <h2 className="text-sm font-bold">{t.paymentHistory}</h2>
                <span className="text-[11px] font-bold uppercase tracking-wide">
                  {isPaid ? t.paidInFull : t.dueRemaining}
                </span>
              </div>
              <table className="receipt-table w-full border-collapse text-left text-[11px]">
                <thead>
                  <tr>
                    <th>{t.date}</th>
                    <th>{t.method}</th>
                    <th className="text-right">{t.amount}</th>
                  </tr>
                </thead>
                <tbody>
                  {receipt.payments.length > 0 ? (
                    receipt.payments.map((payment) => (
                      <tr key={payment.id}>
                        <td>{date(payment.date)}</td>
                        <td>{methodLabel(payment.method)}</td>
                        <td className="text-right font-bold">{money(payment.amount)}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="py-4 text-center text-neutral-500">{t.noPaymentRecorded}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="receipt-summary self-start border-2 border-black p-4">
              <Summary label={t.totalAmount} value={money(receipt.total)} />
              <Summary label={isBuy ? t.paidToParty : t.receivedFromParty} value={money(receipt.paid)} />
              <div className="my-3 border-t border-black" />
              <Summary label={t.outstandingDue} value={money(receipt.due)} strong />
            </div>
          </section>

          {receipt.note ? (
            <section className="mt-5 border border-black p-3">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-neutral-500">{t.note}</p>
              <p className="mt-1 whitespace-pre-wrap text-xs leading-5">{receipt.note}</p>
            </section>
          ) : null}

          <footer className="mt-14">
            <div className="grid grid-cols-2 gap-14">
              <Signature label={t.authorizedSignature} />
              <Signature label={t.partySignature} />
            </div>
            <div className="mt-10 flex items-end justify-between gap-6 border-t border-neutral-400 pt-3 text-[9px] leading-4 text-neutral-500">
              <p>{t.systemGeneratedReceipt}</p>
              <p className="shrink-0 font-bold text-black">{receipt.receiptNo}</p>
            </div>
          </footer>
        </div>
      </article>
    </div>
  );
}

function Summary({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 py-1.5 text-xs">
      <span className={strong ? "font-bold" : "font-medium"}>{label}</span>
      <span className={strong ? "text-base font-black" : "font-bold"}>{value}</span>
    </div>
  );
}

function Signature({ label }: { label: string }) {
  return (
    <div className="pt-10 text-center">
      <div className="border-t border-black pt-2 text-[11px] font-bold">{label}</div>
    </div>
  );
}
