"use client";

import { Languages } from "lucide-react";
import { useLanguage } from "@/components/language-provider";

export function LanguageSwitch() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="language-switch" aria-label={t.language} title={t.language}>
      <Languages size={16} strokeWidth={2.15} className="language-icon" />
      <button type="button" onClick={() => setLanguage("bn")} className={`language-option pressable ${language === "bn" ? "is-active" : ""}`}>বাংলা</button>
      <span className="language-divider" />
      <button type="button" onClick={() => setLanguage("en")} className={`language-option pressable ${language === "en" ? "is-active" : ""}`}>EN</button>
    </div>
  );
}
