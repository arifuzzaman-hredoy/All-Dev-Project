"use client";

import { Eye, EyeOff, Loader2, LockKeyhole, Mail } from "lucide-react";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { useLanguage } from "@/components/language-provider";

export function LoginForm() {
  const router = useRouter();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setLoading(true);
    setError("");

    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const body = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(body.message || t.loginFailed);
      router.replace("/dashboard");
      router.refresh();
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : t.loginFailed);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <label className="block">
        <span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{t.email}</span>
        <div className="premium-input-wrap flex items-center gap-3 px-4 py-3.5">
          <Mail size={18} className="text-indigo-500" />
          <input name="email" type="email" required autoComplete="email" placeholder="you@example.com" className="w-full bg-transparent text-sm text-slate-950 outline-none placeholder:text-slate-300 dark:text-white dark:placeholder:text-slate-600" />
        </div>
      </label>
      <label className="block">
        <span className="mb-2 block text-xs font-bold text-slate-500 dark:text-slate-400">{t.password}</span>
        <div className="premium-input-wrap flex items-center gap-3 px-4 py-3.5">
          <LockKeyhole size={18} className="shrink-0 text-violet-500" />
          <input name="password" type={showPassword ? "text" : "password"} required autoComplete="current-password" placeholder="••••••••••••" className="min-w-0 flex-1 bg-transparent text-sm text-slate-950 outline-none placeholder:text-slate-300 dark:text-white dark:placeholder:text-slate-600" />
          <button
            type="button"
            onClick={() => setShowPassword((value) => !value)}
            aria-label={showPassword ? t.hidePassword : t.showPassword}
            title={showPassword ? t.hidePassword : t.showPassword}
            className="icon-only pressable shrink-0 text-slate-400 hover:text-violet-600 dark:hover:text-violet-300"
          >
            {showPassword ? <EyeOff size={19} className="action-icon" /> : <Eye size={19} className="action-icon" />}
          </button>
        </div>
      </label>
      {error ? <div className="rounded-xl border border-red-200/70 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 dark:border-red-500/20 dark:bg-red-950/40 dark:text-red-300">{error}</div> : null}
      <button type="submit" disabled={loading} className="premium-button premium-login-button pressable flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-black text-white disabled:opacity-60">
        {loading ? <Loader2 size={18} className="animate-spin" /> : null}
        {loading ? t.signingIn : t.signIn}
      </button>
    </form>
  );
}
