"use client";

import { SunMedium } from "lucide-react";
import { useEffect, useState } from "react";
import { useLanguage } from "@/components/language-provider";

export function DashboardGreeting() {
  const { t } = useLanguage();
  const [currentHour, setCurrentHour] = useState<number | null>(null);

  useEffect(() => {
    const syncHour = () => setCurrentHour(new Date().getHours());
    syncHour();
    const timer = window.setInterval(syncHour, 60_000);
    return () => window.clearInterval(timer);
  }, []);

  const greeting = currentHour === null
    ? t.greetingMorning
    : currentHour < 5
      ? t.greetingNight
      : currentHour < 12
        ? t.greetingMorning
        : currentHour < 15
          ? t.greetingNoon
          : currentHour < 18
            ? t.greetingAfternoon
            : currentHour < 22
              ? t.greetingEvening
              : t.greetingNight;

  return (
    <div className="dashboard-greeting inline-flex max-w-full items-center gap-2">
      <SunMedium size={17} strokeWidth={2.2} className="greeting-icon shrink-0" />
      <span className="truncate">{greeting}</span>
      <span className="hidden text-slate-300 dark:text-slate-600 sm:inline">•</span>
      <span className="hidden truncate sm:inline">{t.appName}</span>
    </div>
  );
}
