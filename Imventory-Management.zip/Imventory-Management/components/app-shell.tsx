"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, PanelLeftClose, PanelLeftOpen, Pill, ShoppingBasket, ShoppingCart } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { LanguageSwitch } from "@/components/language-switch";
import { LogoutButton } from "@/components/logout-button";
import { ThemeToggle } from "@/components/theme-toggle";
import { useLanguage } from "@/components/language-provider";

const navItems = [
  { href: "/dashboard", key: "dashboard", icon: LayoutDashboard, tone: "dashboard" },
  { href: "/buy", key: "buy", icon: ShoppingBasket, tone: "buy" },
  { href: "/sell", key: "sell", icon: ShoppingCart, tone: "sell" },
] as const;

function navClass(active: boolean, tone: (typeof navItems)[number]["tone"]) {
  if (!active) return "text-slate-300 hover:text-white";
  if (tone === "buy") return "bg-gradient-to-r from-rose-600 via-red-700 to-red-950 text-white shadow-[0_16px_34px_rgba(127,29,29,.28)]";
  if (tone === "sell") return "bg-gradient-to-r from-emerald-600 via-green-700 to-teal-950 text-white shadow-[0_16px_34px_rgba(6,78,59,.28)]";
  return "bg-gradient-to-r from-indigo-600 via-violet-700 to-purple-950 text-white shadow-[0_16px_34px_rgba(49,46,129,.30)]";
}

function NavSymbol({ tone, children }: { tone: "dashboard" | "buy" | "sell"; children: React.ReactNode }) {
  return <span className="semantic-nav-icon" data-motion={tone}>{children}</span>;
}

function HeaderFloatingTooltip({ label, children }: { label: string; children: React.ReactNode }) {
  const anchorRef = useRef<HTMLSpanElement>(null);
  const [position, setPosition] = useState<{ left: number; top: number } | null>(null);

  function show() {
    const anchor = anchorRef.current;
    if (!anchor) return;
    const rect = anchor.getBoundingClientRect();
    setPosition({ left: rect.left + rect.width / 2, top: rect.bottom + 10 });
  }

  return (
    <span ref={anchorRef} className="inline-flex" onMouseEnter={show} onMouseLeave={() => setPosition(null)} onFocusCapture={show} onBlurCapture={() => setPosition(null)}>
      {children}
      {position && typeof document !== "undefined" ? createPortal(
        <span className="floating-action-tooltip floating-action-tooltip-below" style={{ left: position.left, top: position.top }} role="tooltip">{label}</span>,
        document.body,
      ) : null}
    </span>
  );
}

export function AppShell({ children, email }: { children: React.ReactNode; email: string }) {
  const pathname = usePathname();
  const { t } = useLanguage();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    setSidebarCollapsed(window.localStorage.getItem("ahd-sidebar-collapsed") === "true");
  }, []);

  function toggleSidebar() {
    setSidebarCollapsed((current) => {
      const next = !current;
      window.localStorage.setItem("ahd-sidebar-collapsed", String(next));
      return next;
    });
  }

  return (
    <div className="app-background min-h-screen text-slate-950 transition-colors duration-300 dark:text-slate-100">
      <aside
        className={`deep-sidebar fixed inset-y-0 left-0 z-30 hidden overflow-visible border-r border-white/10 text-white transition-[width] duration-300 ease-[cubic-bezier(.22,1,.36,1)] xl:flex xl:flex-col ${sidebarCollapsed ? "w-[5.5rem]" : "w-[17rem]"}`}
        data-collapsed={sidebarCollapsed ? "true" : "false"}
      >
        <div className="pointer-events-none absolute -left-24 top-14 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-fuchsia-500/15 blur-3xl" />
        <div className="sidebar-brand-row relative border-b border-white/10">
          <div className="sidebar-brand min-w-0">
            <span className="sidebar-brand-mark" aria-hidden="true"><Pill size={25} strokeWidth={2.15} /></span>
            <div className="sidebar-brand-copy min-w-0" aria-hidden={sidebarCollapsed}>
              <div className="sidebar-brand-name bg-gradient-to-r from-white via-indigo-100 to-violet-200 bg-clip-text font-black tracking-tight text-transparent">{t.appName}</div>
              <div className="sidebar-brand-email truncate text-[11px] font-semibold text-indigo-200/55">{email}</div>
            </div>
          </div>
        </div>
        <nav className="sidebar-nav relative flex-1">
          {navItems.map((item) => {
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                data-active={active ? "true" : "false"}
                data-tone={item.tone}
                data-tooltip={sidebarCollapsed ? t[item.key] : undefined}
                className={`nav-link premium-tooltip pressable relative text-sm font-black ${navClass(active, item.tone)}`}
              >
                <NavSymbol tone={item.tone}><Icon size={21} strokeWidth={2.2} className="nav-icon" /></NavSymbol>
                <span className="sidebar-nav-label overflow-hidden whitespace-nowrap">{t[item.key]}</span>
              </Link>
            );
          })}
        </nav>
        <div className="sidebar-footer relative border-t border-white/10 text-center text-[10px] font-semibold uppercase tracking-[0.2em] text-indigo-200/40">
          {sidebarCollapsed ? "P27" : "AHD · Phase 27"}
        </div>
      </aside>

      <div className={`transition-[padding] duration-300 ease-[cubic-bezier(.22,1,.36,1)] ${sidebarCollapsed ? "xl:pl-[5.5rem]" : "xl:pl-[17rem]"}`}>
        <header className="sticky top-0 z-20 border-b border-slate-200/60 bg-white/78 shadow-sm shadow-slate-900/[0.03] backdrop-blur-2xl transition-colors dark:border-white/10 dark:bg-slate-950/76">
          <div className="mx-auto flex min-h-16 max-w-[1700px] items-center justify-between gap-2 px-3 py-2 sm:px-5 lg:px-7 xl:px-8">
            <div className="flex min-w-0 items-center gap-2.5 sm:gap-3">
              <HeaderFloatingTooltip label={sidebarCollapsed ? t.expandSidebar : t.collapseSidebar}>
                <button
                  type="button"
                  onClick={toggleSidebar}
                  className="desktop-header-sidebar-toggle sidebar-toggle pressable relative hidden shrink-0 items-center justify-center border-0 bg-transparent p-1.5 text-slate-500 transition hover:text-violet-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/40 dark:text-slate-300 dark:hover:text-violet-200 xl:inline-flex"
                  aria-label={sidebarCollapsed ? t.expandSidebar : t.collapseSidebar}
                  aria-expanded={!sidebarCollapsed}
                >
                  {sidebarCollapsed ? <PanelLeftOpen size={23} strokeWidth={2.15} /> : <PanelLeftClose size={23} strokeWidth={2.15} />}
                </button>
              </HeaderFloatingTooltip>
              <div className="min-w-0 xl:hidden">
                <div className="truncate bg-gradient-to-r from-indigo-700 via-violet-700 to-fuchsia-700 bg-clip-text text-[13px] font-black text-transparent sm:text-sm">{t.appName}</div>
              </div>
            </div>
            <div className="ml-auto flex shrink-0 items-center gap-1.5 sm:gap-2.5"><LanguageSwitch /><ThemeToggle /><LogoutButton /></div>
          </div>
        </header>
        <main className="mx-auto max-w-[1700px] px-3 pb-28 pt-4 sm:px-5 sm:pt-5 lg:px-7 xl:px-8 xl:pb-10">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/12 bg-slate-950/94 px-2 pb-[max(env(safe-area-inset-bottom),0.45rem)] pt-1.5 shadow-[0_-18px_45px_rgba(15,23,42,.22)] backdrop-blur-2xl xl:hidden">
        <div className="mx-auto grid max-w-lg grid-cols-3 gap-1">
          {navItems.map((item) => {
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            const Icon = item.icon;
            const activeColor = item.tone === "buy" ? "text-rose-400" : item.tone === "sell" ? "text-emerald-400" : "text-violet-300";
            return (
              <Link
                key={item.href}
                href={item.href}
                data-active={active ? "true" : "false"}
                data-tone={item.tone}
                className={`nav-link pressable flex min-h-[58px] flex-col items-center justify-center gap-1 rounded-2xl px-1 text-[10px] font-black sm:text-[11px] ${active ? activeColor : "text-slate-500"}`}
              >
                <NavSymbol tone={item.tone}><Icon size={22} strokeWidth={2.2} className="nav-icon" /></NavSymbol>
                <span className="max-w-full truncate">{t[item.key]}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
