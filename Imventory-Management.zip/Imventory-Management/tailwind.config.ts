import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      boxShadow: {
        soft: "0 20px 55px rgba(15, 23, 42, 0.08)",
        premium: "0 24px 60px rgba(30, 41, 59, 0.16)",
      },
    },
  },
  plugins: [],
};

export default config;
