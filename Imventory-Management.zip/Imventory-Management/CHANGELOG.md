# Phase 28

- Date format only: changed visible numeric dates to `DD/MM/YYYY`.
- Internal database/API date format remains unchanged.
- No Buy/Sell/Stock/Due/Receipt behavior changes.

# Changelog

## Phase 23 — Main Project Consolidation + Build Hotfix

- Switched delivery workflow to one authoritative `Asad` project folder.
- Future updates can be applied from `changes/` instead of creating a new full project folder for every phase.
- Removed historical `PHASE*.md` files from the clean project payload.
- Fixed the confirmed TypeScript error in `app/api/transactions/[id]/due/route.ts` by explicitly typing `method` as `PaymentMethod`.
- Updated stale package/dev-server phase metadata.
- Excluded real `.env` credentials from the replacement package. The apply script preserves the existing `Asad/.env` and `Asad/uploads` data.

### Known verification requirement

Run `npm install` and `npm run build` after applying. Phase 23 fixes the confirmed build blocker, but any subsequent build error must still be reported and fixed rather than assumed away.

## Phase 25 — Record Editing + Due Receipt + Table/Tooltip Polish
- Added Pencil/Edit action to dashboard Buy/Sell rows and record details.
- Added `/transactions/[id]/edit` with stock-safe server-side PUT updates.
- Purchase edits adjust inventory deltas; sale edits restore old stock before validating the new sale.
- Existing payments remain intact; due is recalculated from edited total minus already-paid amount.
- Existing proof files can be marked for removal and a new proof can be uploaded.
- Due popup now returns updated paid/due values, stays open after save, and exposes the updated A4 receipt.
- Replaced clipped table pseudo-tooltips with document-level floating tooltips.
- Refined dashboard table column widths and text alignment for five actions.

## Phase 26 — Transaction Edit Build Hotfix
- Fixed `string | null` product ID typing in `app/api/transactions/[id]/route.ts`.
- Captured `oldProductId` after an explicit null guard before the Prisma transaction callback.
- Replaced callback references to `oldItem.productId` with the narrowed non-null `oldProductId`.
- This is a build-only correctness hotfix; business behavior is intentionally unchanged.


## Phase 27 — Purchase Calculator + Viewport Due Modal + Tooltip/Receipt Flow
- Added purchase unit-price calculation so quantity × purchase unit/box price produces total purchase automatically.
- Recalculation is enforced on the server for both create and edit requests.
- Kept the existing Sell quantity × unit selling-price calculator unchanged.
- Moved the due-payment modal to a `document.body` portal and locked background scrolling while it is open.
- Replaced the header collapse control's clipped pseudo-tooltip with a document-level floating tooltip.
- Removed the direct dashboard receipt action; View/details remains the primary receipt entry point.
- Kept the previously requested receipt action inside the due-payment popup.
- Reduced dashboard action columns from five to four and rebalanced table widths.
