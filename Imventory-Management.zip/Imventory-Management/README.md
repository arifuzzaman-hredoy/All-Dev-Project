# Ammazan Homeo Distributor

Single-main-project version of the Bengali-first Buy/Sell ledger with stock balance, due settlement, attachment history, black-and-white A4 receipts, responsive liquid-glass UI, and MariaDB persistence.

## Main project workflow

The authoritative working folder is always:

```text
~/Downloads/MD Asad/Project/Asad
```

New update ZIPs are placed in:

```text
~/Downloads/MD Asad/Project/changes
```

Historical full-project phase folders are no longer required for the normal update workflow.

## Run

```bash
npm install
npm run build
npm run dev
```

Open `http://localhost:3000` (or the next free port chosen by Next.js).

## DBeaver

- Host: `127.0.0.1`
- Port: `3307`
- Database: `ammazan_homeo`
- User: `ammazan`
- Password: use your local `.env`

## Security

- Do not commit or share the real `.env`.
- `.env.example` is safe to keep in source control.
- Rotate production credentials and `SESSION_SECRET` before deployment.
