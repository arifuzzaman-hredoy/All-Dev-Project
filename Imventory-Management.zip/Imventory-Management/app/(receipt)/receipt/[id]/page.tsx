import { notFound } from "next/navigation";
import { PaymentReceipt } from "@/components/payment-receipt";
import { prisma } from "@/lib/prisma";

function receiptNumber(id: string, date: Date) {
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  return `AHD-${stamp}-${id.slice(-6).toUpperCase()}`;
}

export default async function ReceiptPage({ params }: { params: { id: string } }) {
  const record = await prisma.transaction.findUnique({
    where: { id: params.id },
    include: {
      party: { select: { name: true } },
      items: { take: 1 },
      payments: { orderBy: { createdAt: "asc" } },
    },
  });

  if (!record || (record.type !== "PURCHASE" && record.type !== "SALE")) notFound();
  const item = record.items[0];

  return (
    <PaymentReceipt
      receipt={{
        id: record.id,
        receiptNo: receiptNumber(record.id, record.date),
        type: record.type,
        date: record.date.toISOString(),
        party: record.party?.name ?? "—",
        product: item?.productName ?? "—",
        quantity: Number(item?.quantity ?? 0),
        unit: item?.unit ?? "",
        total: Number(record.totalAmount),
        unitPrice: Number(item?.unitPrice ?? 0),
        paid: Number(record.paidAmount),
        due: Number(record.dueAmount),
        note: record.note ?? null,
        payments: record.payments.map((payment) => ({
          id: payment.id,
          method: payment.method,
          amount: Number(payment.amount),
          date: payment.createdAt.toISOString(),
        })),
      }}
    />
  );
}
