import { LanguageProvider } from "@/components/language-provider";
import { requireAdmin } from "@/lib/auth";

export default async function ReceiptLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return <LanguageProvider>{children}</LanguageProvider>;
}
