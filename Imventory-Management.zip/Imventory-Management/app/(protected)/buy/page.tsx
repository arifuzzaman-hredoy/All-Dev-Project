import { BuySellForm } from "@/components/buy-sell-form";

export default function BuyPage() {
  return <BuySellForm mode="buy" stockProducts={[]} />;
}
