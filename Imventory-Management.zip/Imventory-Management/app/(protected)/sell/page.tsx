import { BuySellForm } from "@/components/buy-sell-form";
import { prisma } from "@/lib/prisma";

export default async function SellPage() {
  const products = await prisma.product.findMany({
    where: { stockQuantity: { gt: 0 }, normalizedName: { not: "" } },
    orderBy: { name: "asc" },
    take: 500,
    select: { id: true, name: true, unit: true, stockQuantity: true },
  });

  return (
    <BuySellForm
      mode="sell"
      stockProducts={products.map((product) => ({
        id: product.id,
        name: product.name,
        unit: product.unit,
        stockQuantity: Number(product.stockQuantity),
      }))}
    />
  );
}
