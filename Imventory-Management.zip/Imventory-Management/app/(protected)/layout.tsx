import { AppShell } from "@/components/app-shell";
import { LanguageProvider } from "@/components/language-provider";
import { requireAdmin } from "@/lib/auth";

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdmin();
  return (
    <LanguageProvider>
      <AppShell email={session.email}>{children}</AppShell>
    </LanguageProvider>
  );
}
