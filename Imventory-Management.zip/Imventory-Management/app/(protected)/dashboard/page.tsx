import { TransactionType } from "@prisma/client";
import { DashboardView } from "@/components/dashboard-view";
import { getBusinessTotals } from "@/lib/accounting";
import { prisma } from "@/lib/prisma";

const dateFormatter = new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" });

function toDateLabel(date: Date) {
  return dateFormatter.format(date);
}

function startOfDay(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

export default async function DashboardPage() {
  const now = startOfDay(new Date());
  const [totals, buys, sells, expiryItems, stockProducts] = await Promise.all([
    getBusinessTotals(),
    prisma.transaction.findMany({
      where: { type: TransactionType.PURCHASE },
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      take: 100,
      select: {
        id: true, date: true, totalAmount: true, paidAmount: true, dueAmount: true,
        party: { select: { name: true } },
        items: { take: 1, select: { productName: true, quantity: true, unit: true } },
        _count: { select: { attachments: true } },
      },
    }),
    prisma.transaction.findMany({
      where: { type: TransactionType.SALE },
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      take: 100,
      select: {
        id: true, date: true, totalAmount: true, paidAmount: true, dueAmount: true,
        party: { select: { name: true } },
        items: { take: 1, select: { productName: true, quantity: true, unit: true } },
        _count: { select: { attachments: true } },
      },
    }),
    prisma.transactionItem.findMany({
      where: {
        expiryDate: { not: null },
        transaction: { type: TransactionType.PURCHASE },
        product: { stockQuantity: { gt: 0 } },
      },
      include: { transaction: { include: { party: { select: { name: true } } } } },
      orderBy: { expiryDate: "asc" },
      take: 100,
    }),
    prisma.product.findMany({
      where: { stockQuantity: { gt: 0 }, normalizedName: { not: "" } },
      orderBy: { name: "asc" },
      take: 100,
      select: { id: true, name: true, unit: true, stockQuantity: true },
    }),
  ]);

  const mapRow = (row: (typeof buys)[number]) => {
    const item = row.items[0];
    return {
      id: row.id,
      date: toDateLabel(row.date),
      product: item?.productName ?? "—",
      party: row.party?.name ?? "—",
      quantity: Number(item?.quantity ?? 0),
      unit: item?.unit ?? "",
      amount: Number(row.totalAmount),
      paid: Number(row.paidAmount),
      due: Number(row.dueAmount),
      proofCount: row._count.attachments,
    };
  };

  const expiry = expiryItems
    .map((item) => {
      if (!item.expiryDate) return null;
      const expiryDate = startOfDay(item.expiryDate);
      const daysRemaining = Math.ceil((expiryDate.getTime() - now.getTime()) / 86_400_000);
      const alertDays = item.expiryAlertDays ?? 30;
      if (daysRemaining > alertDays) return null;
      return {
        id: item.id,
        product: item.productName,
        party: item.transaction.party?.name ?? "—",
        expiry: toDateLabel(item.expiryDate),
        daysRemaining,
      };
    })
    .filter((item): item is NonNullable<typeof item> => Boolean(item))
    .slice(0, 12);

  return (
    <DashboardView
      metrics={{
        totalBuy: totals.purchaseTotal,
        totalSell: totals.saleTotal,
        buyDue: totals.supplierDue,
        sellDue: totals.customerDue,
        commission: totals.commissionTotal,
      }}
      buys={buys.map(mapRow)}
      sells={sells.map(mapRow)}
      expiry={expiry}
      stock={stockProducts.map((product) => ({
        id: product.id,
        product: product.name,
        quantity: Number(product.stockQuantity),
        unit: product.unit,
      }))}
    />
  );
}
