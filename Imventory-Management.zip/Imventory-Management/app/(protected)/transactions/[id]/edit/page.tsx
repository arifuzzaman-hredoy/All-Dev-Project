import { notFound } from "next/navigation";
import { TransactionType } from "@prisma/client";
import { TransactionEditForm } from "@/components/transaction-edit-form";
import { prisma } from "@/lib/prisma";

function inputDate(value: Date | null | undefined) {
  if (!value) return "";
  const local = new Date(value.getTime() - value.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

export default async function TransactionEditPage({ params }: { params: { id: string } }) {
  const record = await prisma.transaction.findUnique({
    where: { id: params.id },
    include: {
      party: true,
      items: { take: 1 },
      commission: true,
      attachments: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!record || (record.type !== TransactionType.PURCHASE && record.type !== TransactionType.SALE)) notFound();

  const item = record.items[0];
  if (!item?.productId) notFound();
  const isSale = record.type === TransactionType.SALE;
  const oldQuantity = Number(item.quantity);

  const products = isSale ? await prisma.product.findMany({
    where: { OR: [{ stockQuantity: { gt: 0 } }, { id: item.productId }] },
    orderBy: { name: "asc" },
    take: 500,
    select: { id: true, name: true, unit: true, stockQuantity: true },
  }) : [];

  return (
    <TransactionEditForm
      initial={{
        id: record.id,
        mode: isSale ? "sell" : "buy",
        partyName: record.party?.name ?? "",
        productId: item.productId,
        productName: item.productName,
        quantity: oldQuantity,
        unit: item.unit ?? "UNIT",
        totalAmount: Number(record.totalAmount),
        purchaseUnitPrice: isSale ? 0 : Number(item.unitPrice),
        sellingUnitPrice: isSale ? Number(item.unitPrice) : 0,
        sellingPrice: item.sellingPrice === null ? 0 : Number(item.sellingPrice),
        commissionAmount: Number(record.commission?.amount ?? 0),
        date: inputDate(record.date),
        manufacturingDate: inputDate(item.manufacturingDate),
        expiryDate: inputDate(item.expiryDate),
        expiryAlertDays: item.expiryAlertDays ?? 30,
        paidAmount: Number(record.paidAmount),
        attachments: record.attachments.map((attachment) => ({ id: attachment.id, name: attachment.fileName })),
      }}
      stockProducts={products.map((product) => ({
        id: product.id,
        name: product.name,
        unit: product.unit,
        stockQuantity: Number(product.stockQuantity) + (product.id === item.productId ? oldQuantity : 0),
      }))}
    />
  );
}
