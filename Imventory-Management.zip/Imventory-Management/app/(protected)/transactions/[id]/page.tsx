import { notFound } from "next/navigation";
import { TransactionDetailView } from "@/components/transaction-detail-view";
import { prisma } from "@/lib/prisma";

function dateLabel(value: Date | null | undefined) {
  if (!value) return null;
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }).format(value);
}

export default async function TransactionDetailPage({ params }: { params: { id: string } }) {
  const record = await prisma.transaction.findUnique({
    where: { id: params.id },
    include: { party: true, items: { take: 1 }, payments: { orderBy: { createdAt: "asc" } }, commission: true, attachments: { orderBy: { createdAt: "asc" } } },
  });
  if (!record) notFound();
  const item = record.items[0];

  return (
    <TransactionDetailView
      detail={{
        id: record.id,
        type: record.type,
        date: dateLabel(record.date) || "—",
        party: record.party?.name ?? "—",
        product: item?.productName ?? "—",
        quantity: Number(item?.quantity ?? 0),
        unit: item?.unit ?? "",
        total: Number(record.totalAmount),
        unitPrice: Number(item?.unitPrice ?? 0),
        paid: Number(record.paidAmount),
        due: Number(record.dueAmount),
        sellingPrice: item?.sellingPrice === null || item?.sellingPrice === undefined ? null : Number(item.sellingPrice),
        commission: Number(record.commission?.amount ?? 0),
        manufacture: dateLabel(item?.manufacturingDate),
        expiry: dateLabel(item?.expiryDate),
        alertDays: item?.expiryAlertDays ?? null,
        payments: record.payments.map((payment) => ({ method: payment.method, amount: Number(payment.amount) })),
        attachments: record.attachments.map((attachment) => ({ id: attachment.id, name: attachment.fileName })),
      }}
    />
  );
}
