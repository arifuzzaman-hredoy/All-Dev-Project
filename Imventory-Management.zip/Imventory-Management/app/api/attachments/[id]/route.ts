import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { readSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const session = await readSession();
  if (!session) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });

  const attachment = await prisma.attachment.findUnique({ where: { id: params.id } });
  if (!attachment) return NextResponse.json({ message: "Attachment not found." }, { status: 404 });

  const uploadDir = path.resolve(process.cwd(), "uploads");
  const absolutePath = path.resolve(uploadDir, attachment.filePath);
  if (!absolutePath.startsWith(`${uploadDir}${path.sep}`)) return NextResponse.json({ message: "Invalid attachment path." }, { status: 400 });

  try {
    const buffer = await readFile(absolutePath);
    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": attachment.mimeType || "application/octet-stream",
        "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(attachment.fileName)}`,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return NextResponse.json({ message: "Attachment file is missing." }, { status: 404 });
  }
}
