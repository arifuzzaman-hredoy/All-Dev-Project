import { PartyType, PaymentMethod, Prisma, TransactionType } from "@prisma/client";
import { randomUUID } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { readSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const MAX_ATTACHMENT_SIZE = 5 * 1024 * 1024;
const imageTypes: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
};

class StockError extends Error {}

function text(form: FormData, key: string, max = 160) {
  const value = form.get(key);
  return typeof value === "string" ? value.trim().replace(/\s+/g, " ").slice(0, max) : "";
}

function normalizedProductName(value: string) {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
}

function number(form: FormData, key: string, optional = false) {
  const raw = text(form, key, 40);
  if (!raw && optional) return 0;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

function positiveNumber(form: FormData, key: string) {
  const value = number(form, key);
  return value !== null && value > 0 ? value : null;
}

function dateValue(form: FormData, key: string, required = false) {
  const raw = text(form, key, 10);
  if (!raw) return required ? null : undefined;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const parsed = new Date(`${raw}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function cents(value: number) {
  return Math.round(value * 100);
}

function decimalFromCents(value: number) {
  return new Prisma.Decimal(value).div(100);
}

function mergedPartyType(current: PartyType, next: PartyType) {
  if (current === next || current === PartyType.BOTH) return current;
  return PartyType.BOTH;
}

export async function POST(request: Request) {
  const session = await readSession();
  if (!session) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });

  let savedFilePath: string | null = null;

  try {
    const form = await request.formData();
    const typeRaw = text(form, "type", 16);
    const type = typeRaw === "PURCHASE" ? TransactionType.PURCHASE : typeRaw === "SALE" ? TransactionType.SALE : null;
    if (!type) return NextResponse.json({ message: "Only Buy and Sell records are supported." }, { status: 400 });

    const partyName = text(form, "partyName");
    const quantity = positiveNumber(form, "quantity");
    let total = positiveNumber(form, "totalAmount");
    const purchaseUnitPrice = number(form, "purchaseUnitPrice", true);
    const sellingPrice = number(form, "sellingPrice", true);
    const saleUnitPrice = number(form, "sellingUnitPrice", true);
    const commissionAmount = number(form, "commissionAmount", true);
    const transactionDate = dateValue(form, "date", true);
    const manufacturingDate = dateValue(form, "manufacturingDate");
    const expiryDate = dateValue(form, "expiryDate");
    const alertDaysRaw = number(form, "expiryAlertDays", true);

    if (!partyName) return NextResponse.json({ message: "Party name is required." }, { status: 400 });
    if (quantity === null) return NextResponse.json({ message: "Quantity must be greater than zero." }, { status: 400 });
    if (type === TransactionType.PURCHASE) {
      if (purchaseUnitPrice === null || purchaseUnitPrice <= 0) {
        return NextResponse.json({ message: "Purchase price per unit or box must be greater than zero." }, { status: 400 });
      }
      total = Math.round(quantity * purchaseUnitPrice * 100) / 100;
    } else {
      if (saleUnitPrice === null || saleUnitPrice <= 0) {
        return NextResponse.json({ message: "Selling price per unit or box must be greater than zero." }, { status: 400 });
      }
      total = Math.round(quantity * saleUnitPrice * 100) / 100;
    }
    if (total === null || total <= 0) return NextResponse.json({ message: "Amount must be greater than zero." }, { status: 400 });
    if (!transactionDate) return NextResponse.json({ message: "Invalid transaction date." }, { status: 400 });
    if (manufacturingDate === null || expiryDate === null) return NextResponse.json({ message: "Invalid manufacture or expiry date." }, { status: 400 });
    if (manufacturingDate && expiryDate && expiryDate < manufacturingDate) return NextResponse.json({ message: "Expiry date cannot be before manufacture date." }, { status: 400 });
    if (alertDaysRaw === null || alertDaysRaw > 3650) return NextResponse.json({ message: "Expiry alert days must be between 0 and 3650." }, { status: 400 });

    const paymentChannel = text(form, "paymentChannel", 16);
    const paidAmount = number(form, "paidAmount", true);
    if (paymentChannel !== "CASH" && paymentChannel !== "BANKING") {
      return NextResponse.json({ message: "Select Cash or Banking as the payment method." }, { status: 400 });
    }
    if (paidAmount === null) return NextResponse.json({ message: "Invalid paid amount." }, { status: 400 });

    let selectedMethod: PaymentMethod = PaymentMethod.CASH;
    if (paymentChannel === "BANKING") {
      const bankingMethod = text(form, "bankingMethod", 16);
      const bankingMethods: Record<string, PaymentMethod> = {
        BKASH: PaymentMethod.BKASH,
        ROCKET: PaymentMethod.ROCKET,
        NAGAD: PaymentMethod.NAGAD,
        BANK: PaymentMethod.BANK,
      };
      const resolvedMethod = bankingMethods[bankingMethod];
      if (!resolvedMethod) return NextResponse.json({ message: "Select bKash, Rocket, Nagad or Bank." }, { status: 400 });
      selectedMethod = resolvedMethod;
    }

    const totalCents = cents(total);
    const paidCents = cents(paidAmount ?? 0);
    if (paidCents > totalCents) return NextResponse.json({ message: "Paid amount cannot be greater than total amount." }, { status: 400 });
    const payments = paidCents > 0 ? [{ method: selectedMethod, amount: paidAmount ?? 0 }] : [];

    let purchaseProductName = "";
    let purchaseUnit = "UNIT";
    let saleProductId = "";

    if (type === TransactionType.PURCHASE) {
      purchaseProductName = text(form, "productName");
      purchaseUnit = text(form, "unit", 24).toUpperCase() || "UNIT";
      if (!purchaseProductName) return NextResponse.json({ message: "Product name is required." }, { status: 400 });
      if (purchaseUnit !== "BOX" && purchaseUnit !== "UNIT") return NextResponse.json({ message: "Unit must be Box or Unit." }, { status: 400 });
    } else {
      saleProductId = text(form, "productId", 64);
      if (!saleProductId) return NextResponse.json({ message: "Select a product from available stock." }, { status: 400 });
    }

    const attachmentValue = form.get("attachment");
    let attachment: { filePath: string; fileName: string; mimeType: string } | null = null;
    if (attachmentValue instanceof File && attachmentValue.size > 0) {
      const extension = imageTypes[attachmentValue.type];
      if (!extension) return NextResponse.json({ message: "Attachment must be PNG, JPG or WebP." }, { status: 400 });
      if (attachmentValue.size > MAX_ATTACHMENT_SIZE) return NextResponse.json({ message: "Attachment must be 5 MB or smaller." }, { status: 400 });

      const uploadDir = path.join(process.cwd(), "uploads");
      await mkdir(uploadDir, { recursive: true });
      const generatedName = `${randomUUID()}${extension}`;
      const absolutePath = path.join(uploadDir, generatedName);
      await writeFile(absolutePath, Buffer.from(await attachmentValue.arrayBuffer()));
      savedFilePath = absolutePath;
      attachment = { filePath: generatedName, fileName: attachmentValue.name.slice(0, 255), mimeType: attachmentValue.type };
    }

    const partyType = type === TransactionType.PURCHASE ? PartyType.SUPPLIER : PartyType.CUSTOMER;
    const result = await prisma.$transaction(async (tx) => {
      let party = await tx.party.findFirst({ where: { name: partyName } });
      if (!party) {
        party = await tx.party.create({ data: { name: partyName, type: partyType } });
      } else if (party.type !== partyType && party.type !== PartyType.BOTH) {
        party = await tx.party.update({ where: { id: party.id }, data: { type: mergedPartyType(party.type, partyType) } });
      }

      let product;
      let productName;
      let unit;

      if (type === TransactionType.PURCHASE) {
        const normalizedName = normalizedProductName(purchaseProductName);
        product = await tx.product.findFirst({ where: { normalizedName, unit: purchaseUnit } });
        if (!product) {
          product = await tx.product.create({
            data: {
              name: purchaseProductName,
              normalizedName,
              unit: purchaseUnit,
              stockQuantity: new Prisma.Decimal(0),
            },
          });
        }
        product = await tx.product.update({
          where: { id: product.id },
          data: { name: purchaseProductName, stockQuantity: { increment: new Prisma.Decimal(quantity) } },
        });
        productName = product.name;
        unit = product.unit;
      } else {
        product = await tx.product.findUnique({ where: { id: saleProductId } });
        if (!product) throw new StockError("Selected product was not found.");

        const updated = await tx.product.updateMany({
          where: { id: product.id, stockQuantity: { gte: new Prisma.Decimal(quantity) } },
          data: { stockQuantity: { decrement: new Prisma.Decimal(quantity) } },
        });
        if (updated.count !== 1) {
          throw new StockError(`Only ${Number(product.stockQuantity)} ${product.unit} available. Reduce the sell quantity.`);
        }
        productName = product.name;
        unit = product.unit;
      }

      const unitPrice = type === TransactionType.PURCHASE ? (purchaseUnitPrice as number) : (saleUnitPrice as number);
      return tx.transaction.create({
        data: {
          partyId: party.id,
          type,
          totalAmount: decimalFromCents(totalCents),
          paidAmount: decimalFromCents(paidCents),
          dueAmount: decimalFromCents(Math.max(totalCents - paidCents, 0)),
          date: transactionDate,
          items: {
            create: {
              productId: product.id,
              productName,
              quantity: new Prisma.Decimal(quantity),
              unit,
              unitPrice: new Prisma.Decimal(unitPrice),
              sellingPrice: type === TransactionType.PURCHASE && sellingPrice && sellingPrice > 0 ? new Prisma.Decimal(sellingPrice) : null,
              lineTotal: decimalFromCents(totalCents),
              manufacturingDate: type === TransactionType.PURCHASE ? manufacturingDate : undefined,
              expiryDate: type === TransactionType.PURCHASE ? expiryDate : undefined,
              expiryAlertDays: type === TransactionType.PURCHASE && expiryDate ? Math.round(alertDaysRaw ?? 30) : null,
            },
          },
          payments: {
            create: payments.map((payment) => ({ method: payment.method, amount: new Prisma.Decimal(payment.amount) })),
          },
          ...(type === TransactionType.PURCHASE && commissionAmount && commissionAmount > 0
            ? { commission: { create: { amount: new Prisma.Decimal(commissionAmount), receivedAmount: new Prisma.Decimal(0), dueAmount: new Prisma.Decimal(0) } } }
            : {}),
          ...(attachment ? { attachments: { create: attachment } } : {}),
        },
      });
    });

    return NextResponse.json({ success: true, data: { id: result.id } }, { status: 201 });
  } catch (error) {
    if (savedFilePath) await unlink(savedFilePath).catch(() => undefined);
    if (error instanceof StockError) return NextResponse.json({ message: error.message }, { status: 409 });
    console.error("Transaction creation failed", error);
    return NextResponse.json({ message: "Unable to save the record right now." }, { status: 500 });
  }
}
