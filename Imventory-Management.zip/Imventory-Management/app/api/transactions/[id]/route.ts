import { PartyType, Prisma, TransactionType } from "@prisma/client";
import { randomUUID } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { readSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const MAX_ATTACHMENT_SIZE = 5 * 1024 * 1024;
const imageTypes: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
};

class StockDeleteError extends Error {}
class StockEditError extends Error {}

function text(form: FormData, key: string, max = 160) {
  const value = form.get(key);
  return typeof value === "string" ? value.trim().replace(/\s+/g, " ").slice(0, max) : "";
}

function normalizedProductName(value: string) {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
}

function number(form: FormData, key: string, optional = false) {
  const raw = text(form, key, 40);
  if (!raw && optional) return 0;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

function positiveNumber(form: FormData, key: string) {
  const value = number(form, key);
  return value !== null && value > 0 ? value : null;
}

function dateValue(form: FormData, key: string, required = false) {
  const raw = text(form, key, 10);
  if (!raw) return required ? null : undefined;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const parsed = new Date(`${raw}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function cents(value: number) {
  return Math.round(value * 100);
}

function decimalFromCents(value: number) {
  return new Prisma.Decimal(value).div(100);
}

function mergedPartyType(current: PartyType, next: PartyType) {
  if (current === next || current === PartyType.BOTH) return current;
  return PartyType.BOTH;
}

async function safeUnlink(filePath: string) {
  const uploadDir = path.resolve(process.cwd(), "uploads");
  const absolutePath = path.resolve(uploadDir, filePath);
  if (absolutePath.startsWith(`${uploadDir}${path.sep}`)) {
    await unlink(absolutePath).catch(() => undefined);
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  const session = await readSession();
  if (!session) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });

  let savedFilePath: string | null = null;

  try {
    const existing = await prisma.transaction.findUnique({
      where: { id: params.id },
      include: {
        party: true,
        items: { take: 1 },
        commission: true,
        attachments: true,
      },
    });
    if (!existing) return NextResponse.json({ message: "Record not found." }, { status: 404 });
    if (existing.type !== TransactionType.PURCHASE && existing.type !== TransactionType.SALE) {
      return NextResponse.json({ message: "Only Buy and Sell records can be edited." }, { status: 400 });
    }

    const oldItem = existing.items[0];
    if (!oldItem) return NextResponse.json({ message: "This record has no transaction item." }, { status: 409 });
    const oldProductId = oldItem.productId;
    if (!oldProductId) return NextResponse.json({ message: "This record has no linked product." }, { status: 409 });

    const form = await request.formData();
    const isBuy = existing.type === TransactionType.PURCHASE;
    const partyName = text(form, "partyName");
    const quantity = positiveNumber(form, "quantity");
    let total = positiveNumber(form, "totalAmount");
    const purchaseUnitPrice = number(form, "purchaseUnitPrice", true);
    const sellingPrice = number(form, "sellingPrice", true);
    const sellingUnitPrice = number(form, "sellingUnitPrice", true);
    const commissionAmount = number(form, "commissionAmount", true);
    const transactionDate = dateValue(form, "date", true);
    const manufacturingDate = dateValue(form, "manufacturingDate");
    const expiryDate = dateValue(form, "expiryDate");
    const alertDaysRaw = number(form, "expiryAlertDays", true);

    if (!partyName) return NextResponse.json({ message: "Party name is required." }, { status: 400 });
    if (quantity === null) return NextResponse.json({ message: "Quantity must be greater than zero." }, { status: 400 });
    if (!transactionDate) return NextResponse.json({ message: "Invalid transaction date." }, { status: 400 });

    if (isBuy) {
      if (purchaseUnitPrice === null || purchaseUnitPrice <= 0) {
        return NextResponse.json({ message: "Purchase price per unit or box must be greater than zero." }, { status: 400 });
      }
      total = Math.round(quantity * purchaseUnitPrice * 100) / 100;
    } else {
      if (sellingUnitPrice === null || sellingUnitPrice <= 0) {
        return NextResponse.json({ message: "Selling price per unit or box must be greater than zero." }, { status: 400 });
      }
      total = Math.round(quantity * sellingUnitPrice * 100) / 100;
    }
    if (total === null || total <= 0) return NextResponse.json({ message: "Amount must be greater than zero." }, { status: 400 });
    if (manufacturingDate === null || expiryDate === null) return NextResponse.json({ message: "Invalid manufacture or expiry date." }, { status: 400 });
    if (manufacturingDate && expiryDate && expiryDate < manufacturingDate) {
      return NextResponse.json({ message: "Expiry date cannot be before manufacture date." }, { status: 400 });
    }
    if (alertDaysRaw === null || alertDaysRaw > 3650) {
      return NextResponse.json({ message: "Expiry alert days must be between 0 and 3650." }, { status: 400 });
    }

    const totalCents = cents(total);
    const alreadyPaidCents = cents(Number(existing.paidAmount));
    if (totalCents < alreadyPaidCents) {
      return NextResponse.json({ message: "Total amount cannot be lower than money already paid or received." }, { status: 400 });
    }

    let targetProductId = oldProductId;
    let targetProductName = oldItem.productName;
    let targetUnit = oldItem.unit || "UNIT";

    if (isBuy) {
      targetProductName = text(form, "productName");
      targetUnit = text(form, "unit", 24).toUpperCase() || "UNIT";
      if (!targetProductName) return NextResponse.json({ message: "Product name is required." }, { status: 400 });
      if (targetUnit !== "BOX" && targetUnit !== "UNIT") return NextResponse.json({ message: "Unit must be Box or Unit." }, { status: 400 });
    } else {
      targetProductId = text(form, "productId", 64);
      if (!targetProductId) return NextResponse.json({ message: "Select a product from available stock." }, { status: 400 });
    }

    const attachmentValue = form.get("attachment");
    let attachment: { filePath: string; fileName: string; mimeType: string } | null = null;
    if (attachmentValue instanceof File && attachmentValue.size > 0) {
      const extension = imageTypes[attachmentValue.type];
      if (!extension) return NextResponse.json({ message: "Attachment must be PNG, JPG or WebP." }, { status: 400 });
      if (attachmentValue.size > MAX_ATTACHMENT_SIZE) return NextResponse.json({ message: "Attachment must be 5 MB or smaller." }, { status: 400 });

      const uploadDir = path.join(process.cwd(), "uploads");
      await mkdir(uploadDir, { recursive: true });
      const generatedName = `${randomUUID()}${extension}`;
      const absolutePath = path.join(uploadDir, generatedName);
      await writeFile(absolutePath, Buffer.from(await attachmentValue.arrayBuffer()));
      savedFilePath = absolutePath;
      attachment = { filePath: generatedName, fileName: attachmentValue.name.slice(0, 255), mimeType: attachmentValue.type };
    }

    const removableIds = form.getAll("removeAttachmentIds").filter((value): value is string => typeof value === "string");
    const removableAttachments = existing.attachments.filter((item) => removableIds.includes(item.id));
    const partyType = isBuy ? PartyType.SUPPLIER : PartyType.CUSTOMER;

    await prisma.$transaction(async (tx) => {
      let party = await tx.party.findFirst({ where: { name: partyName } });
      if (!party) {
        party = await tx.party.create({ data: { name: partyName, type: partyType } });
      } else if (party.type !== partyType && party.type !== PartyType.BOTH) {
        party = await tx.party.update({ where: { id: party.id }, data: { type: mergedPartyType(party.type, partyType) } });
      }

      const oldQuantity = new Prisma.Decimal(oldItem.quantity);
      const newQuantity = new Prisma.Decimal(quantity);
      let targetProduct;

      if (isBuy) {
        const normalizedName = normalizedProductName(targetProductName);
        targetProduct = await tx.product.findFirst({ where: { normalizedName, unit: targetUnit } });
        if (!targetProduct) {
          targetProduct = await tx.product.create({
            data: { name: targetProductName, normalizedName, unit: targetUnit, stockQuantity: new Prisma.Decimal(0) },
          });
        }

        if (targetProduct.id === oldProductId) {
          const difference = newQuantity.minus(oldQuantity);
          if (difference.gt(0)) {
            await tx.product.update({ where: { id: targetProduct.id }, data: { name: targetProductName, stockQuantity: { increment: difference } } });
          } else if (difference.lt(0)) {
            const reduction = difference.abs();
            const updated = await tx.product.updateMany({
              where: { id: targetProduct.id, stockQuantity: { gte: reduction } },
              data: { name: targetProductName, stockQuantity: { decrement: reduction } },
            });
            if (updated.count !== 1) throw new StockEditError("Quantity cannot be reduced because some of this stock has already been sold.");
          } else if (targetProduct.name !== targetProductName) {
            await tx.product.update({ where: { id: targetProduct.id }, data: { name: targetProductName } });
          }
        } else {
          const removed = await tx.product.updateMany({
            where: { id: oldProductId, stockQuantity: { gte: oldQuantity } },
            data: { stockQuantity: { decrement: oldQuantity } },
          });
          if (removed.count !== 1) throw new StockEditError("Product cannot be changed because some of this purchased stock has already been sold.");
          await tx.product.update({
            where: { id: targetProduct.id },
            data: { name: targetProductName, stockQuantity: { increment: newQuantity } },
          });
        }
      } else {
        await tx.product.update({ where: { id: oldProductId }, data: { stockQuantity: { increment: oldQuantity } } });
        targetProduct = await tx.product.findUnique({ where: { id: targetProductId } });
        if (!targetProduct) throw new StockEditError("Selected product was not found.");
        const reduced = await tx.product.updateMany({
          where: { id: targetProduct.id, stockQuantity: { gte: newQuantity } },
          data: { stockQuantity: { decrement: newQuantity } },
        });
        if (reduced.count !== 1) {
          throw new StockEditError(`Only ${Number(targetProduct.stockQuantity)} ${targetProduct.unit} available. Reduce the sell quantity.`);
        }
        targetProductName = targetProduct.name;
        targetUnit = targetProduct.unit;
      }

      const unitPrice = isBuy ? (purchaseUnitPrice as number) : (sellingUnitPrice as number);

      await tx.transaction.update({
        where: { id: existing.id },
        data: {
          partyId: party.id,
          totalAmount: decimalFromCents(totalCents),
          dueAmount: decimalFromCents(totalCents - alreadyPaidCents),
          date: transactionDate,
        },
      });

      await tx.transactionItem.update({
        where: { id: oldItem.id },
        data: {
          productId: targetProduct.id,
          productName: targetProductName,
          quantity: newQuantity,
          unit: targetUnit,
          unitPrice: new Prisma.Decimal(unitPrice),
          lineTotal: decimalFromCents(totalCents),
          sellingPrice: isBuy && sellingPrice && sellingPrice > 0 ? new Prisma.Decimal(sellingPrice) : null,
          manufacturingDate: isBuy ? manufacturingDate : null,
          expiryDate: isBuy ? expiryDate : null,
          expiryAlertDays: isBuy && expiryDate ? Math.round(alertDaysRaw ?? 30) : null,
        },
      });

      if (isBuy && commissionAmount && commissionAmount > 0) {
        await tx.commission.upsert({
          where: { transactionId: existing.id },
          create: { transactionId: existing.id, amount: new Prisma.Decimal(commissionAmount), receivedAmount: new Prisma.Decimal(0), dueAmount: new Prisma.Decimal(0) },
          update: { amount: new Prisma.Decimal(commissionAmount) },
        });
      } else if (existing.commission) {
        await tx.commission.delete({ where: { transactionId: existing.id } });
      }

      if (removableAttachments.length) {
        await tx.attachment.deleteMany({ where: { id: { in: removableAttachments.map((item) => item.id) }, transactionId: existing.id } });
      }
      if (attachment) {
        await tx.attachment.create({ data: { transactionId: existing.id, ...attachment } });
      }
    });

    await Promise.all(removableAttachments.map((item) => safeUnlink(item.filePath)));
    return NextResponse.json({ success: true, data: { id: existing.id } });
  } catch (error) {
    if (savedFilePath) await unlink(savedFilePath).catch(() => undefined);
    if (error instanceof StockEditError) return NextResponse.json({ message: error.message }, { status: 409 });
    console.error("Transaction edit failed", error);
    return NextResponse.json({ message: "Unable to update this record right now." }, { status: 500 });
  }
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const session = await readSession();
  if (!session) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });

  const record = await prisma.transaction.findUnique({
    where: { id: params.id },
    include: { attachments: true, items: true },
  });
  if (!record) return NextResponse.json({ message: "Record not found." }, { status: 404 });

  try {
    await prisma.$transaction(async (tx) => {
      for (const item of record.items) {
        if (!item.productId) continue;
        const quantity = new Prisma.Decimal(item.quantity);

        if (record.type === TransactionType.PURCHASE) {
          const updated = await tx.product.updateMany({
            where: { id: item.productId, stockQuantity: { gte: quantity } },
            data: { stockQuantity: { decrement: quantity } },
          });
          if (updated.count !== 1) {
            throw new StockDeleteError("This Buy record cannot be deleted because some of this stock has already been sold.");
          }
        } else if (record.type === TransactionType.SALE) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stockQuantity: { increment: quantity } },
          });
        }
      }

      await tx.transaction.delete({ where: { id: params.id } });
    });
  } catch (error) {
    if (error instanceof StockDeleteError) return NextResponse.json({ message: error.message }, { status: 409 });
    console.error("Transaction delete failed", error);
    return NextResponse.json({ message: "Unable to delete this record right now." }, { status: 500 });
  }

  await Promise.all(record.attachments.map((attachment) => safeUnlink(attachment.filePath)));
  return NextResponse.json({ success: true });
}
