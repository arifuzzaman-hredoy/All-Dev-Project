import { PaymentMethod, Prisma, TransactionType } from "@prisma/client";
import { randomUUID } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { readSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const MAX_ATTACHMENT_SIZE = 5 * 1024 * 1024;
const imageTypes: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
};

class DuePaymentError extends Error {}

function text(form: FormData, key: string, max = 160) {
  const value = form.get(key);
  return typeof value === "string" ? value.trim().replace(/\s+/g, " ").slice(0, max) : "";
}

function moneyNumber(form: FormData, key: string) {
  const raw = text(form, key, 40);
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function cents(value: number) {
  return Math.round(value * 100);
}

function decimalFromCents(value: number) {
  return new Prisma.Decimal(value).div(100);
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  const session = await readSession();
  if (!session) return NextResponse.json({ message: "Unauthorized." }, { status: 401 });

  let savedFilePath: string | null = null;

  try {
    const form = await request.formData();
    const amount = moneyNumber(form, "amount");
    if (amount === null) return NextResponse.json({ message: "Amount must be greater than zero." }, { status: 400 });

    const paymentChannel = text(form, "paymentChannel", 16);
    if (paymentChannel !== "CASH" && paymentChannel !== "BANKING") {
      return NextResponse.json({ message: "Select Cash or Banking." }, { status: 400 });
    }

    let method: PaymentMethod = PaymentMethod.CASH;
    if (paymentChannel === "BANKING") {
      const bankingMethod = text(form, "bankingMethod", 16);
      const methods: Record<string, PaymentMethod> = {
        BKASH: PaymentMethod.BKASH,
        ROCKET: PaymentMethod.ROCKET,
        NAGAD: PaymentMethod.NAGAD,
        BANK: PaymentMethod.BANK,
      };
      const resolved = methods[bankingMethod];
      if (!resolved) return NextResponse.json({ message: "Select bKash, Rocket, Nagad or Bank." }, { status: 400 });
      method = resolved;
    }

    const record = await prisma.transaction.findUnique({
      where: { id: params.id },
      select: { id: true, type: true, dueAmount: true },
    });
    if (!record) return NextResponse.json({ message: "Record not found." }, { status: 404 });
    if (record.type !== TransactionType.PURCHASE && record.type !== TransactionType.SALE) {
      return NextResponse.json({ message: "Due payment is only available for Buy and Sell records." }, { status: 400 });
    }

    const amountCents = cents(amount);
    const dueCents = cents(Number(record.dueAmount));
    if (amountCents > dueCents) {
      return NextResponse.json({ message: "Amount cannot be greater than the current due." }, { status: 400 });
    }

    const attachmentValue = form.get("attachment");
    let attachment: { filePath: string; fileName: string; mimeType: string } | null = null;
    if (attachmentValue instanceof File && attachmentValue.size > 0) {
      const extension = imageTypes[attachmentValue.type];
      if (!extension) return NextResponse.json({ message: "Attachment must be PNG, JPG or WebP." }, { status: 400 });
      if (attachmentValue.size > MAX_ATTACHMENT_SIZE) return NextResponse.json({ message: "Attachment must be 5 MB or smaller." }, { status: 400 });

      const uploadDir = path.join(process.cwd(), "uploads");
      await mkdir(uploadDir, { recursive: true });
      const generatedName = `${randomUUID()}${extension}`;
      const absolutePath = path.join(uploadDir, generatedName);
      await writeFile(absolutePath, Buffer.from(await attachmentValue.arrayBuffer()));
      savedFilePath = absolutePath;
      attachment = {
        filePath: generatedName,
        fileName: attachmentValue.name.slice(0, 255),
        mimeType: attachmentValue.type,
      };
    }

    const decimalAmount = decimalFromCents(amountCents);
    const updatedRecord = await prisma.$transaction(async (tx) => {
      const updated = await tx.transaction.updateMany({
        where: {
          id: record.id,
          type: record.type,
          dueAmount: { gte: decimalAmount },
        },
        data: {
          paidAmount: { increment: decimalAmount },
          dueAmount: { decrement: decimalAmount },
        },
      });

      if (updated.count !== 1) {
        throw new DuePaymentError("Due changed before this payment was saved. Refresh and try again.");
      }

      await tx.payment.create({
        data: {
          transactionId: record.id,
          method,
          amount: decimalAmount,
        },
      });

      if (attachment) {
        await tx.attachment.create({
          data: {
            transactionId: record.id,
            ...attachment,
          },
        });
      }

      return tx.transaction.findUnique({
        where: { id: record.id },
        select: { paidAmount: true, dueAmount: true },
      });
    });

    return NextResponse.json({
      success: true,
      data: {
        paid: Number(updatedRecord?.paidAmount ?? 0),
        due: Number(updatedRecord?.dueAmount ?? 0),
      },
    });
  } catch (error) {
    if (savedFilePath) await unlink(savedFilePath).catch(() => undefined);
    if (error instanceof DuePaymentError) return NextResponse.json({ message: error.message }, { status: 409 });
    console.error("Due payment failed", error);
    return NextResponse.json({ message: "Unable to save the due payment right now." }, { status: 500 });
  }
}
