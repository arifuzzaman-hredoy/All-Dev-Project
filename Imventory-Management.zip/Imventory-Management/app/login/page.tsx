import { redirect } from "next/navigation";
import { LoginForm } from "@/components/login-form";
import { LoginThemeToggle } from "@/components/login-theme-toggle";
import { LanguageProvider } from "@/components/language-provider";
import { LanguageSwitch } from "@/components/language-switch";
import { LoginIntro } from "@/components/login-intro";
import { readSession } from "@/lib/auth";

export default async function LoginPage() {
  const session = await readSession();
  if (session) redirect("/dashboard");

  return (
    <LanguageProvider>
      <main className="login-stage relative grid min-h-[100dvh] place-items-center overflow-hidden px-3 py-8 sm:px-5 sm:py-10">
        <div className="absolute right-4 top-4 z-20 flex items-center gap-2 sm:right-6 sm:top-6"><LanguageSwitch /><LoginThemeToggle /></div>
        <div className="pointer-events-none absolute left-[4%] top-[8%] h-64 w-64 rounded-full bg-indigo-500/25 blur-3xl sm:h-80 sm:w-80" />
        <div className="pointer-events-none absolute bottom-[5%] right-[3%] h-72 w-72 rounded-full bg-fuchsia-500/18 blur-3xl sm:h-96 sm:w-96" />
        <section className="login-card relative w-full max-w-md overflow-hidden rounded-[1.8rem] p-5 sm:rounded-[2rem] sm:p-8">
          <div className="pointer-events-none absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-violet-400/90 to-transparent" />
          <LoginIntro />
          <LoginForm />
        </section>
      </main>
    </LanguageProvider>
  );
}
