variable "vps_host" {
  description = "Existing production VPS IPv4 address."
  type        = string
  default     = "198.54.121.88"
}

variable "domain" {
  description = "Production hostname."
  type        = string
  default     = "inventory.techteamlead.com"
}

variable "app_port" {
  description = "Loopback application port."
  type        = number
  default     = 4180

  validation {
    condition     = var.app_port >= 1024 && var.app_port <= 65535
    error_message = "app_port must be between 1024 and 65535."
  }
}

variable "database_host" {
  description = "MariaDB listener."
  type        = string
  default     = "127.0.0.1"
}

variable "database_port" {
  type    = number
  default = 3306
}

variable "app_root" {
  type    = string
  default = "/var/www/ammazan-homeo"
}
