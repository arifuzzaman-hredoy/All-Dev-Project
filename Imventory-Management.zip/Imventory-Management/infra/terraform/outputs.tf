output "production_target" {
  value = {
    host     = var.vps_host
    domain   = var.domain
    app_port = var.app_port
    app_root = var.app_root
  }
}
