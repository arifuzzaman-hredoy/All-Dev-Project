resource "terraform_data" "production_contract" {
  input = {
    vps_host      = var.vps_host
    domain        = var.domain
    app_port      = var.app_port
    database_host = var.database_host
    database_port = var.database_port
    app_root      = var.app_root
  }

  lifecycle {
    precondition {
      condition     = var.database_host == "127.0.0.1"
      error_message = "MariaDB must remain loopback-only."
    }

    precondition {
      condition     = var.app_port != var.database_port
      error_message = "Application and database ports must differ."
    }
  }
}
