import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import dotenv from "dotenv";
dotenv.config();

const prisma = new PrismaClient({
  adapter: new PrismaPg({
    connectionString: process.env.DATABASE_URL,
  }),
});

async function main() {
  const categories = [
    "tupi",
    "dates",
    "jacket",
    "watch",
    "electronic-computers",
    "headphone",
    "smartwatch",
    "bluetooth",
    "t-shirts",
    "mouse",
    "gaming",
  ];

  // Ensure categories exist
  for (const slug of categories) {
    await prisma.category.upsert({
      where: { slug },
      update: {},
      create: {
        slug,
        name: slug.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
      },
    });
  }

  // Seed 10 products per category
  let count = 1;
  for (const slug of categories) {
    const category = await prisma.category.findUnique({ where: { slug } });
    if (!category) continue;
    for (let i = 1; i <= 10; i++) {
      await prisma.product.upsert({
        where: { slug: `${slug}-product-${i}` },
        update: {},
        create: {
          slug: `${slug}-product-${i}`,
          name: `${category.name} Product ${i}`,
          price: 1000 + count * 10,
          offerPrice: i % 2 === 0 ? 900 + count * 10 : null,
          sku: `SKU-${slug.toUpperCase()}-${i}`,
          stock: 10 + i,
          isActive: true,
          isFeatured: i === 1,
          categoryId: category.id,
          images: {
            create: [
              {
                url:
                  "https://placehold.co/300x225?text=" +
                  encodeURIComponent(`${category.name}+${i}`),
                alt: `${category.name} Product ${i}`,
                sortOrder: 0,
              },
            ],
          },
        },
      });
      count++;
    }
  }

  console.log("Seeded 100+ products!");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
