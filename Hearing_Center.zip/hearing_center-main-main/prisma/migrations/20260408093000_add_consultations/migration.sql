-- CreateTable
CREATE TABLE "Consultation" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "email" TEXT,
    "hearingAidUsage" TEXT,
    "hearingTestDone" TEXT,
    "tinnitus" TEXT,
    "crowdDifficulty" TEXT,
    "dailyLifeImpact" TEXT,
    "age" TEXT,
    "district" TEXT,
    "budget" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Consultation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Consultation_createdAt_idx" ON "Consultation"("createdAt");

-- CreateIndex
CREATE INDEX "Consultation_phone_idx" ON "Consultation"("phone");

-- CreateIndex
CREATE INDEX "Consultation_name_idx" ON "Consultation"("name");
