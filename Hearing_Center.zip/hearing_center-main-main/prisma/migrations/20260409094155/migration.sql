-- AlterTable
ALTER TABLE "StoreSettings" ALTER COLUMN "storeName" SET DEFAULT 'Rangpur Hearing Center';
