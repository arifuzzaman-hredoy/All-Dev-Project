ALTER TABLE "Product"
ADD COLUMN "brand" TEXT NOT NULL DEFAULT 'Phonak',
ADD COLUMN "modelCode" TEXT,
ADD COLUMN "deviceStyle" TEXT,
ADD COLUMN "hearingLossRange" TEXT,
ADD COLUMN "batteryType" TEXT,
ADD COLUMN "connectivity" TEXT,
ADD COLUMN "isRechargeable" BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE "ProductContent"
ADD COLUMN "fittingRange" TEXT,
ADD COLUMN "careGuide" TEXT,
ADD COLUMN "keyFeatures" JSONB,
ADD COLUMN "specifications" JSONB;
