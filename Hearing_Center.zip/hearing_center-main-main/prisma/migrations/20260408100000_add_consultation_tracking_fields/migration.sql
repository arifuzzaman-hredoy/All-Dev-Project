-- CreateEnum
CREATE TYPE "ConsultationStatus" AS ENUM (
    'PENDING',
    'CONTACTED',
    'CONFIRMED',
    'FOLLOW_UP',
    'NO_ANSWER',
    'CLOSED',
    'CANCELLED'
);

-- AlterTable
ALTER TABLE "Consultation"
ADD COLUMN "status" "ConsultationStatus" NOT NULL DEFAULT 'PENDING',
ADD COLUMN "adminNote" TEXT,
ADD COLUMN "followUpDate" TIMESTAMP(3),
ADD COLUMN "contactedAt" TIMESTAMP(3),
ADD COLUMN "closedAt" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX "Consultation_status_idx" ON "Consultation"("status");
