ALTER TABLE "Product"
ADD COLUMN "compatibilityGroupKey" TEXT,
ADD COLUMN "compatibilityGroupLabel" TEXT,
ADD COLUMN "accessorySortOrder" INTEGER NOT NULL DEFAULT 0;

CREATE INDEX "Product_compatibilityGroupKey_idx"
ON "Product"("compatibilityGroupKey");

CREATE INDEX "Product_compatibilityGroupKey_isActive_idx"
ON "Product"("compatibilityGroupKey", "isActive");

CREATE INDEX "Product_compatibilityGroupKey_accessorySortOrder_idx"
ON "Product"("compatibilityGroupKey", "accessorySortOrder");
