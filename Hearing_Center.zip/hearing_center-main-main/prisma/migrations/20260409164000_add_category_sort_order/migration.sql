ALTER TABLE "Category"
ADD COLUMN "sortOrder" INTEGER NOT NULL DEFAULT 0;

CREATE INDEX "Category_parentId_sortOrder_idx" ON "Category"("parentId", "sortOrder");
