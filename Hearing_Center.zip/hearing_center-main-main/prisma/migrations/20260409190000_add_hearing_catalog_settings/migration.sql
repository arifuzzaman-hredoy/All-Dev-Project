ALTER TABLE "StoreSettings"
ADD COLUMN "deviceStyleOptions" JSONB,
ADD COLUMN "hearingLossOptions" JSONB,
ADD COLUMN "batteryTypeOptions" JSONB,
ADD COLUMN "connectivityOptions" JSONB;
