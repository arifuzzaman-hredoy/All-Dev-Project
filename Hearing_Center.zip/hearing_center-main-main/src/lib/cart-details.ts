import { prisma } from "@/lib/prisma";
import type { CartItem } from "@/lib/cart.types";

export type CartDetailsItem = {
  qty: number;
  variantId: string | null;
  variantLabel: string | null;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
  };
};

export async function buildCartDetails(
  items: CartItem[],
): Promise<CartDetailsItem[]> {
  const ids = [...new Set(items.map((i) => i.productId))];

  if (ids.length === 0) {
    return [];
  }

  const products = await prisma.product.findMany({
    where: { id: { in: ids }, isActive: true },
    include: {
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  const map = new Map(products.map((p) => [p.id, p] as const));

  return items
    .map((item): CartDetailsItem | null => {
      const product = map.get(item.productId);
      if (!product) return null;

      const variant =
        item.variantId && product.variants.length
          ? (product.variants.find((entry) => entry.id === item.variantId) ??
            null)
          : null;

      const priceDiff = variant?.priceDiff ?? 0;
      const effectiveImages = variant?.images?.length
        ? variant.images
        : product.images;

      return {
        qty: item.qty,
        variantId: variant?.id ?? null,
        variantLabel: variant ? `${variant.type}: ${variant.value}` : null,
        product: {
          id: product.id,
          name: product.name,
          slug: product.slug,
          price: product.price + priceDiff,
          offerPrice:
            product.offerPrice !== null ? product.offerPrice + priceDiff : null,
          stock: variant ? variant.stock : product.stock,
          images: (effectiveImages ?? [])
            .map((image) => ({ url: image.url }))
            .filter(
              (image) =>
                typeof image.url === "string" && image.url.trim().length > 0,
            ),
        },
      };
    })
    .filter((item): item is CartDetailsItem => item !== null);
}
