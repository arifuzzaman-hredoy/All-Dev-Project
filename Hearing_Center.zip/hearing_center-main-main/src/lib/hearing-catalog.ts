export const DEVICE_STYLE_OPTIONS = [
  "BTE",
  "RIC",
  "RITE",
  "ITE",
  "ITC",
  "CIC",
  "IIC",
  "Pediatric",
] as const;

export const HEARING_LOSS_OPTIONS = [
  "Mild",
  "Moderate",
  "Moderately Severe",
  "Severe",
  "Profound",
] as const;

export const BATTERY_TYPE_OPTIONS = [
  "Rechargeable",
  "Size 10",
  "Size 13",
  "Size 312",
  "Size 675",
] as const;

export const CONNECTIVITY_OPTIONS = [
  "Bluetooth",
  "Roger Compatible",
  "Telecoil",
  "App Control",
  "Basic",
] as const;

export type HearingCatalogSettings = {
  deviceStyleOptions: string[];
  hearingLossOptions: string[];
  batteryTypeOptions: string[];
  connectivityOptions: string[];
};

export type ProductSpecification = {
  label: string;
  value: string;
};

export const DEFAULT_HEARING_CATALOG_SETTINGS: HearingCatalogSettings = {
  deviceStyleOptions: [...DEVICE_STYLE_OPTIONS],
  hearingLossOptions: [...HEARING_LOSS_OPTIONS],
  batteryTypeOptions: [...BATTERY_TYPE_OPTIONS],
  connectivityOptions: [...CONNECTIVITY_OPTIONS],
};

function normalizeOptionList(input: unknown, fallback: readonly string[]): string[] {
  if (!Array.isArray(input)) return [...fallback];

  const items = input
    .map((item) => (typeof item === "string" ? item.trim() : ""))
    .filter(Boolean);

  return items.length ? Array.from(new Set(items)) : [...fallback];
}

export function normalizeHearingCatalogSettings(
  input: Partial<HearingCatalogSettings> | null | undefined,
): HearingCatalogSettings {
  return {
    deviceStyleOptions: normalizeOptionList(
      input?.deviceStyleOptions,
      DEVICE_STYLE_OPTIONS,
    ),
    hearingLossOptions: normalizeOptionList(
      input?.hearingLossOptions,
      HEARING_LOSS_OPTIONS,
    ),
    batteryTypeOptions: normalizeOptionList(
      input?.batteryTypeOptions,
      BATTERY_TYPE_OPTIONS,
    ),
    connectivityOptions: normalizeOptionList(
      input?.connectivityOptions,
      CONNECTIVITY_OPTIONS,
    ),
  };
}

export function parseLineList(input: string): string[] {
  return input
    .split(/\r?\n/)
    .map((item) => item.trim())
    .filter(Boolean);
}

export function serializeLineList(items: string[] | null | undefined): string {
  return Array.isArray(items) ? items.filter(Boolean).join("\n") : "";
}

export function parseSpecifications(input: string): ProductSpecification[] {
  return input
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split(":");
      if (parts.length < 2) return null;

      const label = parts.shift()?.trim() ?? "";
      const value = parts.join(":").trim();

      if (!label || !value) return null;

      return { label, value };
    })
    .filter((item): item is ProductSpecification => item !== null);
}

export function serializeSpecifications(
  items: ProductSpecification[] | null | undefined,
): string {
  return Array.isArray(items)
    ? items
        .filter((item) => item.label && item.value)
        .map((item) => `${item.label}: ${item.value}`)
        .join("\n")
    : "";
}
