import { z } from "zod";
import { isValidBdDistrict } from "@/lib/bd-districts";

export const checkoutSchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        variantId: z.string().min(1).optional(),
        qty: z.coerce.number().int().min(1).max(20),
      }),
    )
    .min(1),

  couponCode: z.string().trim().max(50).optional(),
  paymentMethod: z.enum(["COD", "ONLINE"]),

  name: z.string().trim().min(2).max(120),
  email: z.string().email().optional(),
  phone: z.string().trim().min(8).max(20),

  addressLine1: z.string().trim().min(3).max(255),
  addressLine2: z.string().trim().max(255).optional(),

  city: z
    .string()
    .trim()
    .min(2)
    .max(100)
    .refine((value) => isValidBdDistrict(value), {
      message: "Please select a valid district",
    }),

  area: z.string().trim().max(100).optional(),
  note: z.string().trim().max(500).optional(),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
