import { cookies } from "next/headers";
import type { Cart, CartItem } from "./cart.types";

const CART_COOKIE = "rhc_cart_v1";

function toInt(v: unknown, fallback = 1): number {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(1, Math.floor(n));
}

function toVariantId(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const value = v.trim();
  return value.length ? value : null;
}

export function normalizeCart(input: unknown): Cart {
  try {
    const o =
      typeof input === "string"
        ? (JSON.parse(input) as { items?: unknown })
        : (input as { items?: unknown });

    if (!Array.isArray(o.items)) return { items: [] };

    const items: CartItem[] = o.items
      .map(
        (x) => x as { productId?: unknown; qty?: unknown; variantId?: unknown },
      )
      .filter(
        (x) => typeof x.productId === "string" && x.productId.trim().length > 0,
      )
      .map((x) => ({
        productId: (x.productId as string).trim(),
        qty: toInt(x.qty, 1),
        variantId: toVariantId(x.variantId),
      }));

    return { items };
  } catch {
    return { items: [] };
  }
}

export async function getCartServer(): Promise<Cart> {
  const jar = await cookies();
  const c = jar.get(CART_COOKIE)?.value;
  if (!c) return { items: [] };
  return normalizeCart(c);
}

export async function setCartServer(cart: Cart): Promise<void> {
  const jar = await cookies();
  jar.set(CART_COOKIE, JSON.stringify(cart), {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function clearCartServer(): Promise<void> {
  const jar = await cookies();
  jar.delete(CART_COOKIE);
}
