import { cache } from "react";
import { prisma } from "@/lib/prisma";

export const getBestSellingProductIds = cache(async (): Promise<Set<string>> => {
  const [activeProducts, soldGroups] = await Promise.all([
    prisma.product.findMany({
      where: { isActive: true },
      select: { id: true, createdAt: true },
    }),
    prisma.orderItem.groupBy({
      by: ["productId"],
      _sum: { qty: true },
    }),
  ]);

  if (!activeProducts.length) {
    return new Set<string>();
  }

  const soldQtyMap = new Map(
    soldGroups.map((item) => [item.productId, item._sum.qty ?? 0] as const),
  );

  const rankedProducts = activeProducts
    .map((product) => ({
      id: product.id,
      soldQty: soldQtyMap.get(product.id) ?? 0,
      createdAt: product.createdAt.getTime(),
    }))
    .sort(
      (a, b) => b.soldQty - a.soldQty || b.createdAt - a.createdAt,
    );

  const topCount = Math.max(1, Math.ceil(activeProducts.length * 0.1));

  return new Set(rankedProducts.slice(0, topCount).map((product) => product.id));
});
