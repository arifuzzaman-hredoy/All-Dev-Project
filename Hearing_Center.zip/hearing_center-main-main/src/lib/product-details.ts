import { prisma } from "@/lib/prisma";

export type RelatedProductCard = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  brand: string;
  accessorySortOrder: number;
  images: { url: string }[];
};

export async function getProductBySlugWithRelatedProducts(slug: string) {
  const currentProduct = await prisma.product.findFirst({
    where: { slug, isActive: true },
    include: {
      content: true,
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
      category: {
        include: {
          parent: true,
        },
      },
    },
  });

  if (!currentProduct) {
    return {
      currentProduct: null,
      relatedProducts: [] as RelatedProductCard[],
      fallbackProducts: [] as RelatedProductCard[],
    };
  }

  const relatedProducts = currentProduct.compatibilityGroupKey
    ? await prisma.product.findMany({
        where: {
          isActive: true,
          compatibilityGroupKey: currentProduct.compatibilityGroupKey,
          id: { not: currentProduct.id },
        },
        select: {
          id: true,
          name: true,
          slug: true,
          price: true,
          offerPrice: true,
          stock: true,
          brand: true,
          accessorySortOrder: true,
          images: {
            orderBy: { sortOrder: "asc" },
            take: 1,
            select: { url: true },
          },
        },
        orderBy: [
          { accessorySortOrder: "asc" },
          { createdAt: "desc" },
        ],
        take: 8,
      })
    : [];

  const fallbackProducts =
    relatedProducts.length === 0
      ? await prisma.product.findMany({
          where: {
            isActive: true,
            categoryId: currentProduct.categoryId,
            id: { not: currentProduct.id },
          },
          select: {
            id: true,
            name: true,
            slug: true,
            price: true,
            offerPrice: true,
            stock: true,
            brand: true,
            accessorySortOrder: true,
            images: {
              orderBy: { sortOrder: "asc" },
              take: 1,
              select: { url: true },
            },
          },
          orderBy: { createdAt: "desc" },
          take: 8,
        })
      : [];

  return {
    currentProduct,
    relatedProducts,
    fallbackProducts,
  };
}
