import { isDhakaDistrict } from "@/lib/bd-districts";

export type StorePricingSettings = {
  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
};

export type TotalsInput = {
  subtotal: number;
  discount: number;
  district: string;
  settings: StorePricingSettings;
};

export type TotalsOutput = {
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
};

function clampInt(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.floor(n));
}

function getShippingCharge(params: {
  subtotal: number;
  discount: number;
  district: string;
  settings: StorePricingSettings;
}): number {
  const subtotal = clampInt(params.subtotal);
  const discount = clampInt(params.discount);
  const discounted = Math.max(0, subtotal - discount);

  const freeOver = clampInt(params.settings.shippingFreeOver);
  if (freeOver > 0 && discounted >= freeOver) {
    return 0;
  }

  return isDhakaDistrict(params.district)
    ? clampInt(params.settings.shippingInsideDhaka)
    : clampInt(params.settings.shippingOutsideDhaka);
}

export function calcTotals(input: TotalsInput): TotalsOutput {
  const subtotal = clampInt(input.subtotal);
  const discount = clampInt(input.discount);
  const discounted = Math.max(0, subtotal - discount);

  const taxRate = clampInt(input.settings.taxRate);
  const shipping = getShippingCharge({
    subtotal,
    discount,
    district: input.district,
    settings: input.settings,
  });

  const tax = clampInt((discounted * taxRate) / 100);
  const total = Math.max(0, discounted + shipping + tax);

  return { subtotal, discount, shipping, tax, total };
}
