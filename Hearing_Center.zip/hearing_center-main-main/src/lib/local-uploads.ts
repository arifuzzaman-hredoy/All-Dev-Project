import crypto from "crypto";
import fs from "fs/promises";
import path from "path";

const ALLOWED_MIME_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
]);

const MAX_SIZE_IN_BYTES = 25 * 1024 * 1024; // 25MB
const STATIC_PUBLIC_DIR = path.resolve("public");
const DEFAULT_UPLOADS_DIR = path.join(STATIC_PUBLIC_DIR, "uploads");

type UploadImageOptions = {
  preserveOriginal?: boolean;
};

function getUploadsDir(): string {
  const configured = process.env.UPLOADS_DIR?.trim();
  if (!configured) return DEFAULT_UPLOADS_DIR;

  if (path.isAbsolute(configured)) {
    return configured;
  }

  return path.join(STATIC_PUBLIC_DIR, configured);
}

export function validateImageFile(file: File): void {
  if (!ALLOWED_MIME_TYPES.has(file.type)) {
    throw new Error("Only PNG, JPG, JPEG, and WEBP images are allowed.");
  }

  if (file.size > MAX_SIZE_IN_BYTES) {
    throw new Error("Image size must be 25MB or less.");
  }
}

function getLocalUploadFolder(folder: string): string {
  const folderName = folder.split("/").filter(Boolean).at(-1) ?? "products";
  return folderName.replace(/[^a-z0-9_-]/gi, "") || "products";
}

function getExtensionFromMimeType(mimeType: string): string {
  if (mimeType === "image/png") return "png";
  if (mimeType === "image/webp") return "webp";
  return "jpg";
}

export async function uploadImageToLocalUploads(
  file: File,
  folder: string,
  _options: UploadImageOptions = {},
): Promise<string> {
  validateImageFile(file);

  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);
  const outputBuffer = buffer;

  const uploadFolder = getLocalUploadFolder(folder);
  const extension = getExtensionFromMimeType(file.type);
  const filename = `${crypto.randomUUID()}.${extension}`;
  const uploadDir = path.join(getUploadsDir(), uploadFolder);

  await fs.mkdir(uploadDir, { recursive: true });
  await fs.writeFile(path.join(uploadDir, filename), outputBuffer);

  return `/uploads/${uploadFolder}/${filename}`;
}

export async function deleteLocalUploadByUrl(url: string): Promise<void> {
  if (!url.startsWith("/uploads/")) return;

  try {
    const uploadsDir = getUploadsDir();
    const relativePath = url.replace(/^\/uploads\//, "");
    const filePath = path.normalize(path.join(uploadsDir, relativePath));

    if (!filePath.startsWith(uploadsDir + path.sep)) return;

    await fs.unlink(filePath);
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      error.code === "ENOENT"
    ) {
      return;
    }

    console.error("Failed to delete local upload:", { url, error });
  }
}

export async function deleteLocalUploadsByUrls(urls: string[]): Promise<void> {
  const uniqueUrls = Array.from(
    new Set(urls.map((x) => x.trim()).filter(Boolean)),
  );

  await Promise.all(uniqueUrls.map((url) => deleteLocalUploadByUrl(url)));
}
