import { OrderStatus } from "@prisma/client";

type OrderForSteadfast = {
  id: string;
  createdAt: Date;
  name: string;
  email: string | null;
  phone: string;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  total: number;
  items: Array<{
    sku: string;
    qty: number;
  }>;
};

type SteadfastCreatePayload = {
  CusRef: string;
  UserName: string;
  Email?: string;
  OrderDate: string;
  ReceiverName: string;
  ReceiverAddress: {
    Address1: string;
    Address2?: string;
    Suburb: string;
    State: string;
    Postcode: string;
    Country: string;
  };
  Phone?: string;
  Value?: number;
  Depot?: string;
  SrvCode?: string;
  ColCode?: string;
  Weight?: number | null;
  Items: Array<{
    ProductCode: string;
    Quantity: number;
  }>;
};

type SteadfastEnvelope<T> = {
  Message?: string;
  ResponseMessage?: {
    Success?: boolean;
    TokenChanged?: boolean;
    ErrorMessage?: string;
    NewToken?: string;
  };
  TotalQueryRows?: number;
} & T;

type SteadfastStatusResponse = {
  Success?: boolean;
  ErrorMessage?: string;
  CustomerRef?: string | null;
  ConsRef?: string | null;
  TripStatus?: string | null;
  OrderFound?: boolean;
  JobNo?: string | null;
  Url?: string | null;
  DispatchDate?: string | null;
  PODdate?: string | null;
};

function env(name: string, fallback = ""): string {
  return process.env[name]?.trim() || fallback;
}

export function isSteadfastEnabled(): boolean {
  return env("STEADFAST_ENABLED", "false") === "true";
}

function getBaseUrl(): string {
  return env("STEADFAST_BASE_URL", "https://middleware.podapp.com.au");
}

function getApiKey(): string {
  return env("STEADFAST_API_KEY");
}

function getOrderEndpoint(): string {
  return env("STEADFAST_ORDER_ENDPOINT", "/passthrough/customerorder");
}

function getStatusEndpoint(): string {
  return env("STEADFAST_STATUS_ENDPOINT", "/passthrough/customerorderstatus");
}

function buildReceiverAddress(order: OrderForSteadfast) {
  const line2 = [order.addressLine2, order.area].filter(Boolean).join(", ");
  return {
    Address1: order.addressLine1,
    Address2: line2 || undefined,
    Suburb: order.city,
    State: order.city, // Bangladesh-specific mapping can be refined later
    Postcode: "0000", // placeholder if not collected
    Country: "BANGLADESH",
  };
}

export function buildSteadfastCreatePayload(
  order: OrderForSteadfast
): SteadfastCreatePayload {
  return {
    CusRef: order.id,
    UserName: "RANGPUR_HEARING_CENTER",
    Email: order.email ?? undefined,
    OrderDate: order.createdAt.toISOString(),
    ReceiverName: order.name,
    ReceiverAddress: buildReceiverAddress(order),
    Phone: order.phone,
    Value: order.total,
    Depot: "DHAKA",
    SrvCode: "REGULAR",
    ColCode: "PICKUP",
    Weight: null,
    Items: order.items.map((item) => ({
      ProductCode: item.sku,
      Quantity: item.qty,
    })),
  };
}

async function steadfastFetch<T>(
  path: string,
  body: unknown
): Promise<T> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("STEADFAST_API_KEY is missing");
  }

  const res = await fetch(`${getBaseUrl()}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Steadfast-Api-Key": apiKey,
    },
    body: JSON.stringify(body),
    cache: "no-store",
  });

  const json: unknown = await res.json().catch(() => null);

  if (!res.ok) {
    const obj = json as { Message?: unknown; ErrorMessage?: unknown };
    const msg =
      (typeof obj?.Message === "string" && obj.Message) ||
      (typeof obj?.ErrorMessage === "string" && obj.ErrorMessage) ||
      `Steadfast request failed with ${res.status}`;
    throw new Error(msg);
  }

  return (json ?? {}) as T;
}

export async function createSteadfastOrder(order: OrderForSteadfast) {
  const payload = buildSteadfastCreatePayload(order);
  const response = await steadfastFetch<SteadfastEnvelope<Record<string, unknown>>>(
    getOrderEndpoint(),
    payload
  );

  const ok = response?.ResponseMessage?.Success === true;
  const errorMessage = response?.ResponseMessage?.ErrorMessage || "";

  return {
    ok,
    payload,
    response,
    errorMessage,
  };
}

export async function fetchSteadfastOrderStatus(customerRef: string) {
  const response = await steadfastFetch<SteadfastStatusResponse>(
    getStatusEndpoint(),
    { CustomerRef: customerRef }
  );

  return response;
}

export function mapSteadfastTripStatusToOrderStatus(
  tripStatus: string | null | undefined
): OrderStatus | null {
  const s = (tripStatus || "").trim().toLowerCase();

  if (!s) return null;
  if (["booked", "allocated", "picked", "pickup", "in transit"].includes(s)) {
    return "PROCESSING";
  }
  if (["dispatched", "on route", "out for delivery"].includes(s)) {
    return "SHIPPED";
  }
  if (["ended", "delivered", "completed"].includes(s)) {
    return "DELIVERED";
  }
  if (["cancelled", "canceled", "returned"].includes(s)) {
    return "CANCELLED";
  }

  return null;
}