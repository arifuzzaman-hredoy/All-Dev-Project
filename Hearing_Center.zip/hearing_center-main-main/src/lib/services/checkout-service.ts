import { prisma } from "@/lib/prisma";
import { CouponType, PaymentMethod, PaymentStatus } from "@prisma/client";
import type { CheckoutInput } from "@/lib/validations/checkout";
import { generateIdempotencyKey } from "@/lib/payments/sslcommerz/helpers";
import { AppError } from "../app-error";
import { isDhakaDistrict } from "@/lib/bd-districts";

type PreparedOrderItem = {
  productId: string;
  variantId?: string;
  productName: string;
  sku: string;
  unitPrice: number;
  qty: number;
  lineTotal: number;
};

type PreparedCheckout = {
  items: PreparedOrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  couponCode?: string;
};

function calculateDiscount(params: {
  subtotal: number;
  coupon: {
    type: CouponType;
    value: number;
    minSubtotal: number;
    maxDiscount: number | null;
    startsAt: Date | null;
    endsAt: Date | null;
    usageLimit: number | null;
    usedCount: number;
    isActive: boolean;
  };
}) {
  const { subtotal, coupon } = params;
  const now = new Date();

  if (!coupon.isActive) {
    throw new AppError("Coupon inactive", { statusCode: 422 });
  }

  if (coupon.startsAt && coupon.startsAt > now) {
    throw new AppError("Coupon not active yet", { statusCode: 422 });
  }

  if (coupon.endsAt && coupon.endsAt < now) {
    throw new AppError("Coupon expired", { statusCode: 422 });
  }

  if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
    throw new AppError("Coupon usage limit exceeded", { statusCode: 409 });
  }

  if (subtotal < coupon.minSubtotal) {
    throw new AppError(`Minimum subtotal is ${coupon.minSubtotal}`, {
      statusCode: 422,
    });
  }

  let discount = 0;

  if (coupon.type === "PERCENT") {
    discount = Math.floor((subtotal * coupon.value) / 100);
    if (coupon.maxDiscount !== null) {
      discount = Math.min(discount, coupon.maxDiscount);
    }
  } else {
    discount = coupon.value;
  }

  return Math.max(0, Math.min(discount, subtotal));
}

function getShippingCharge(params: {
  subtotal: number;
  discount: number;
  district: string;
  settings: {
    shippingInsideDhaka: number;
    shippingOutsideDhaka: number;
    shippingFreeOver: number;
  };
}) {
  const discounted = Math.max(0, params.subtotal - params.discount);

  if (
    params.settings.shippingFreeOver > 0 &&
    discounted >= params.settings.shippingFreeOver
  ) {
    return 0;
  }

  return isDhakaDistrict(params.district)
    ? params.settings.shippingInsideDhaka
    : params.settings.shippingOutsideDhaka;
}

export async function prepareCheckout(
  body: CheckoutInput,
): Promise<PreparedCheckout> {
  const productIds = [...new Set(body.items.map((i) => i.productId))];
  const variantIds = [
    ...new Set(body.items.map((i) => i.variantId).filter(Boolean)),
  ] as string[];

  const [products, variants, settings, coupon] = await Promise.all([
    prisma.product.findMany({
      where: {
        id: { in: productIds },
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        sku: true,
        price: true,
        offerPrice: true,
        stock: true,
        isActive: true,
      },
    }),
    prisma.productVariant.findMany({
      where: { id: { in: variantIds } },
      select: {
        id: true,
        productId: true,
        value: true,
        type: true,
        priceDiff: true,
        stock: true,
      },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        taxRate: true,
        shippingInsideDhaka: true,
        shippingOutsideDhaka: true,
        shippingFreeOver: true,
        codEnabled: true,
        onlineEnabled: true,
      },
    }),
    body.couponCode
      ? prisma.coupon.findUnique({
          where: { code: body.couponCode },
          select: {
            id: true,
            code: true,
            type: true,
            value: true,
            minSubtotal: true,
            maxDiscount: true,
            startsAt: true,
            endsAt: true,
            usageLimit: true,
            usedCount: true,
            isActive: true,
          },
        })
      : Promise.resolve(null),
  ]);

  if (!settings) {
    throw new AppError("Store settings not found", {
      statusCode: 500,
      expose: false,
    });
  }

  if (body.paymentMethod === "COD" && !settings.codEnabled) {
    throw new AppError("Cash on delivery is disabled", { statusCode: 422 });
  }

  if (body.paymentMethod === "ONLINE" && !settings.onlineEnabled) {
    throw new AppError("Online payment is disabled", { statusCode: 422 });
  }

  const productMap = new Map(products.map((p) => [p.id, p]));
  const variantMap = new Map(variants.map((v) => [v.id, v]));

  const preparedItems: PreparedOrderItem[] = [];

  for (const item of body.items) {
    const product = productMap.get(item.productId);

    if (!product) {
      throw new AppError("Product not found or inactive", { statusCode: 404 });
    }

    const variant = item.variantId ? variantMap.get(item.variantId) : null;

    if (item.variantId && !variant) {
      throw new AppError("Selected product variant not found", {
        statusCode: 404,
      });
    }

    if (variant && variant.productId !== product.id) {
      throw new AppError("Variant does not belong to the product", {
        statusCode: 422,
      });
    }

    const availableStock = variant ? variant.stock : product.stock;

    if (availableStock < item.qty) {
      throw new AppError(`${product.name} stock is insufficient`, {
        statusCode: 409,
      });
    }

    const basePrice = product.offerPrice ?? product.price;
    const unitPrice = basePrice + (variant?.priceDiff ?? 0);
    const lineTotal = unitPrice * item.qty;

    preparedItems.push({
      productId: product.id,
      variantId: variant?.id,
      productName: product.name,
      sku: product.sku,
      unitPrice,
      qty: item.qty,
      lineTotal,
    });
  }

  const subtotal = preparedItems.reduce((sum, item) => sum + item.lineTotal, 0);

  let discount = 0;
  if (body.couponCode) {
    if (!coupon) {
      throw new AppError("Coupon not found", { statusCode: 404 });
    }

    discount = calculateDiscount({
      subtotal,
      coupon,
    });
  }

  const shipping = getShippingCharge({
    subtotal,
    discount,
    district: body.city,
    settings: {
      shippingInsideDhaka: settings.shippingInsideDhaka,
      shippingOutsideDhaka: settings.shippingOutsideDhaka,
      shippingFreeOver: settings.shippingFreeOver,
    },
  });

  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = Math.floor((taxableAmount * settings.taxRate) / 100);
  const total = taxableAmount + shipping + tax;

  return {
    items: preparedItems,
    subtotal,
    discount,
    shipping,
    tax,
    total,
    couponCode: body.couponCode,
  };
}

export async function createCodOrder(params: {
  userId?: string | null;
  body: CheckoutInput;
  prepared: PreparedCheckout;
  idempotencyKey?: string;
}) {
  return prisma.$transaction(async (tx) => {
    if (params.idempotencyKey) {
      const existing = await tx.order.findUnique({
        where: { idempotencyKey: params.idempotencyKey },
        select: { id: true, total: true, paymentStatus: true, status: true },
      });

      if (existing) return existing;
    }

    for (const item of params.prepared.items) {
      if (item.variantId) {
        const updated = await tx.productVariant.updateMany({
          where: {
            id: item.variantId,
            productId: item.productId,
            stock: { gte: item.qty },
          },
          data: {
            stock: { decrement: item.qty },
          },
        });

        if (updated.count === 0) {
          throw new AppError(`Stock unavailable for ${item.productName}`, {
            statusCode: 409,
          });
        }
      } else {
        const updated = await tx.product.updateMany({
          where: {
            id: item.productId,
            stock: { gte: item.qty },
            isActive: true,
          },
          data: {
            stock: { decrement: item.qty },
          },
        });

        if (updated.count === 0) {
          throw new AppError(`Stock unavailable for ${item.productName}`, {
            statusCode: 409,
          });
        }
      }
    }

    if (params.prepared.couponCode) {
      const coupon = await tx.coupon.findUnique({
        where: { code: params.prepared.couponCode },
        select: {
          id: true,
          usageLimit: true,
          usedCount: true,
          isActive: true,
        },
      });

      if (!coupon || !coupon.isActive) {
        throw new AppError("Coupon is no longer valid", { statusCode: 409 });
      }

      if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
        throw new AppError("Coupon usage limit exceeded", { statusCode: 409 });
      }

      await tx.coupon.update({
        where: { id: coupon.id },
        data: {
          usedCount: { increment: 1 },
        },
      });
    }

    const order = await tx.order.create({
      data: {
        userId: params.userId ?? null,
        idempotencyKey: params.idempotencyKey ?? generateIdempotencyKey(),
        name: params.body.name,
        email: params.body.email,
        phone: params.body.phone,
        addressLine1: params.body.addressLine1,
        addressLine2: params.body.addressLine2,
        city: params.body.city,
        area: params.body.area,
        note: params.body.note,
        couponCode: params.prepared.couponCode,
        subtotal: params.prepared.subtotal,
        discount: params.prepared.discount,
        shipping: params.prepared.shipping,
        tax: params.prepared.tax,
        total: params.prepared.total,
        paymentMethod: PaymentMethod.COD,
        paymentStatus: PaymentStatus.UNPAID,
        stockDeducted: true,
        items: {
          create: params.prepared.items.map((item) => ({
            productId: item.productId,
            variantId: item.variantId,
            productName: item.productName,
            sku: item.sku,
            unitPrice: item.unitPrice,
            qty: item.qty,
            lineTotal: item.lineTotal,
          })),
        },
      },
      select: {
        id: true,
        total: true,
        paymentMethod: true,
        paymentStatus: true,
        status: true,
        createdAt: true,
      },
    });

    return order;
  });
}

export async function createOnlinePendingOrder(params: {
  userId?: string | null;
  body: CheckoutInput;
  prepared: PreparedCheckout;
  idempotencyKey?: string;
}) {
  if (params.idempotencyKey) {
    const existing = await prisma.order.findUnique({
      where: { idempotencyKey: params.idempotencyKey },
      select: {
        id: true,
        total: true,
        paymentMethod: true,
        paymentStatus: true,
        status: true,
        sslczSessionKey: true,
      },
    });

    if (existing) return existing;
  }

  const order = await prisma.order.create({
    data: {
      userId: params.userId ?? null,
      idempotencyKey: params.idempotencyKey ?? generateIdempotencyKey(),
      name: params.body.name,
      email: params.body.email,
      phone: params.body.phone,
      addressLine1: params.body.addressLine1,
      addressLine2: params.body.addressLine2,
      city: params.body.city,
      area: params.body.area,
      note: params.body.note,
      couponCode: params.prepared.couponCode,
      subtotal: params.prepared.subtotal,
      discount: params.prepared.discount,
      shipping: params.prepared.shipping,
      tax: params.prepared.tax,
      total: params.prepared.total,
      paymentMethod: PaymentMethod.ONLINE,
      paymentStatus: PaymentStatus.UNPAID,
      stockDeducted: false,
      paymentGateway: "SSLCOMMERZ",
      items: {
        create: params.prepared.items.map((item) => ({
          productId: item.productId,
          variantId: item.variantId,
          productName: item.productName,
          sku: item.sku,
          unitPrice: item.unitPrice,
          qty: item.qty,
          lineTotal: item.lineTotal,
        })),
      },
    },
    select: {
      id: true,
      total: true,
      paymentMethod: true,
      paymentStatus: true,
      status: true,
      createdAt: true,
    },
  });

  return order;
}
