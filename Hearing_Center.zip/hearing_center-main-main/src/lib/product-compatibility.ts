import { slugify } from "@/lib/slug";

export function normalizeCompatibilityGroupKey(
  input: string | null | undefined,
): string | null {
  if (typeof input !== "string") return null;

  const normalized = slugify(input);
  return normalized || null;
}

export function normalizeCompatibilityGroupLabel(
  input: string | null | undefined,
): string | null {
  if (typeof input !== "string") return null;

  const trimmed = input.trim();
  return trimmed || null;
}

export function normalizeAccessorySortOrder(input: unknown): number {
  if (typeof input === "number" && Number.isFinite(input)) {
    return Math.max(0, Math.trunc(input));
  }

  const parsed = Number(input);
  if (!Number.isFinite(parsed)) return 0;

  return Math.max(0, Math.trunc(parsed));
}
