import { getServerSession } from "next-auth";
import type { Cart, CartItem } from "@/lib/cart.types";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  clearCartServer,
  getCartServer,
  normalizeCart,
  setCartServer,
} from "@/lib/cart.server";

function isSameLine(
  item: CartItem,
  productId: string,
  variantId: string | null,
): boolean {
  return item.productId === productId && (item.variantId ?? null) === variantId;
}

export function mergeCarts(...carts: Cart[]): Cart {
  const merged: Cart = { items: [] };

  for (const cart of carts) {
    for (const item of cart.items) {
      const variantId = item.variantId ?? null;
      const existing = merged.items.find((entry) =>
        isSameLine(entry, item.productId, variantId),
      );

      if (existing) {
        existing.qty += item.qty;
      } else {
        merged.items.push({
          productId: item.productId,
          qty: item.qty,
          variantId,
        });
      }
    }
  }

  return merged;
}

async function getSessionUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);
  return typeof session?.user?.id === "string" ? session.user.id : null;
}

export async function getStoredUserCart(userId: string): Promise<Cart> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { cartJson: true },
  });

  return normalizeCart(user?.cartJson ?? null);
}

export async function setStoredUserCart(
  userId: string,
  cart: Cart,
): Promise<void> {
  await prisma.user.update({
    where: { id: userId },
    data: { cartJson: cart },
  });
}

export async function resolveCurrentCart(): Promise<{
  cart: Cart;
  userId: string | null;
}> {
  const userId = await getSessionUserId();

  if (!userId) {
    return { cart: await getCartServer(), userId: null };
  }

  const [storedCart, cookieCart] = await Promise.all([
    getStoredUserCart(userId),
    getCartServer(),
  ]);

  const mergedCart = mergeCarts(storedCart, cookieCart);

  if (JSON.stringify(mergedCart) !== JSON.stringify(storedCart)) {
    await setStoredUserCart(userId, mergedCart);
  }

  if (cookieCart.items.length > 0) {
    await clearCartServer();
  }

  return { cart: mergedCart, userId };
}

export async function persistCurrentCart(
  cart: Cart,
  userId: string | null,
): Promise<void> {
  if (userId) {
    await Promise.all([setStoredUserCart(userId, cart), clearCartServer()]);
    return;
  }

  await setCartServer(cart);
}
