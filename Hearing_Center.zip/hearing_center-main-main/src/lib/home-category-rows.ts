import { prisma } from "@/lib/prisma";

export type HomeCategoryRow = {
  id: string;
  name: string;
  slug: string;
  imageUrl: string | null;
};

export async function getHomeCategoryRows(): Promise<HomeCategoryRow[]> {
  return prisma.category.findMany({
    where: {
      isActive: true,
      parentId: null,
      products: {
        some: {
          isActive: true,
        },
      },
    },
    orderBy: [{ name: "asc" }],
    take: 6,
    select: {
      id: true,
      name: true,
      slug: true,
      imageUrl: true,
    },
  });
}
