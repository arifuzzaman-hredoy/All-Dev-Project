import { prisma } from "@/lib/prisma";

function WhatsAppIcon() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className="h-6 w-6 fill-current"
    >
      <path d="M19.05 4.94A9.94 9.94 0 0 0 12.03 2C6.55 2 2.09 6.46 2.09 11.94c0 1.75.46 3.46 1.33 4.97L2 22l5.24-1.37a9.9 9.9 0 0 0 4.77 1.22h.01c5.48 0 9.94-4.46 9.94-9.94a9.9 9.9 0 0 0-2.91-6.97Zm-7.02 15.23h-.01a8.26 8.26 0 0 1-4.21-1.15l-.3-.18-3.11.81.83-3.03-.2-.31a8.25 8.25 0 0 1-1.27-4.38c0-4.57 3.71-8.28 8.28-8.28a8.2 8.2 0 0 1 5.85 2.43 8.2 8.2 0 0 1 2.42 5.85c0 4.57-3.71 8.28-8.28 8.28Zm4.54-6.2c-.25-.13-1.47-.72-1.7-.8-.23-.08-.39-.13-.56.12-.16.25-.64.8-.78.96-.14.17-.28.19-.53.07-.25-.13-1.04-.38-1.98-1.21-.73-.65-1.22-1.45-1.36-1.7-.14-.25-.01-.38.11-.5.11-.11.25-.28.37-.42.12-.14.16-.24.25-.4.08-.17.04-.31-.02-.44-.06-.13-.56-1.35-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1 0 1.24.9 2.43 1.02 2.6.12.17 1.77 2.7 4.28 3.79.6.26 1.07.42 1.44.54.61.2 1.17.17 1.61.1.49-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.14-1.18-.06-.1-.23-.17-.48-.29Z" />
    </svg>
  );
}

export default async function FloatingWhatsAppButton() {
  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: { whatsappUrl: true },
  });

  const whatsappUrl = settings?.whatsappUrl?.trim() ?? "";

  if (!whatsappUrl) {
    return null;
  }

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="group fixed bottom-20 right-4 z-50 md:bottom-6 md:right-6"
    >
      <span className="pointer-events-none absolute inset-0 animate-whatsapp-ping rounded-full bg-[#25d366]/30" />
      <span className="pointer-events-none absolute inset-0 rounded-full bg-[#25d366]/20 blur-xl transition-opacity duration-300 group-hover:opacity-80" />
      <span className="relative flex h-14 w-14 animate-whatsapp-float items-center justify-center rounded-full bg-[#25d366] text-white shadow-[0_18px_45px_-18px_rgba(37,211,102,0.85)] transition-transform duration-300 group-hover:scale-110 group-hover:bg-[#1ebe5b]">
        <WhatsAppIcon />
      </span>
    </a>
  );
}
