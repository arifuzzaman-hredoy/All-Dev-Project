"use client";

import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export type PageHeroAction = {
    href: string;
    label: string;
    variant?: "primary" | "secondary";
};

export type PageHeroStat = {
    label: string;
    value: string;
};

type Breadcrumb = {
    label: string;
    href?: string;
};

type PageHeroProps = {
    eyebrow?: string;
    title: string;
    description: string;
    breadcrumbs?: Breadcrumb[];
    actions?: PageHeroAction[];
    stats?: PageHeroStat[];
    className?: string;
    contentClassName?: string;
    align?: "left" | "center";
    children?: ReactNode;
};

export default function PageHero({
    eyebrow = "Rangpur Hearing Center",
    title,
    description,
    breadcrumbs = [],
    actions = [],
    stats = [],
    className,
    contentClassName,
    align = "left",
    children,
}: PageHeroProps) {
    const centered = align === "center";

    return (
        <section
            className={cn(
                "relative overflow-hidden rounded-[24px] border border-[#ece7de] bg-white shadow-[0_18px_45px_-38px_rgba(15,23,42,0.24)]",
                className,
            )}
        >
            <div
                className={cn(
                    "relative px-6 py-10 sm:px-8 sm:py-12",
                    centered && "text-center",
                    contentClassName,
                )}
            >
                {breadcrumbs.length ? (
                    <div
                        className={cn(
                            "mb-4 flex flex-wrap items-center gap-2 text-xs text-[#64748b]",
                            centered && "justify-center",
                        )}
                    >
                        {breadcrumbs.map((crumb, index) => {
                            const isLast = index === breadcrumbs.length - 1;

                            return (
                                <div
                                    key={`${crumb.label}-${index}`}
                                    className="flex items-center gap-2"
                                >
                                    {crumb.href && !isLast ? (
                                        <Link
                                            href={crumb.href}
                                            className="transition hover:text-[#d88a26]"
                                        >
                                            {crumb.label}
                                        </Link>
                                    ) : (
                                        <span className="font-medium text-[#475569]">
                                            {crumb.label}
                                        </span>
                                    )}

                                    {!isLast ? <ChevronRight className="h-3 w-3" /> : null}
                                </div>
                            );
                        })}
                    </div>
                ) : null}

                <div className={cn("mt-4 max-w-3xl", centered && "mx-auto")}>
                    <h1 className="text-3xl font-semibold tracking-tight text-[#334155] sm:text-4xl lg:text-5xl">
                        {title}
                    </h1>
                    <p className="mt-4 text-sm leading-7 text-[#475569] sm:text-base">
                        {description}
                    </p>

                    {actions.length ? (
                        <div
                            className={cn(
                                "mt-6 flex flex-wrap gap-3",
                                centered && "justify-center",
                            )}
                        >
                            {actions.map((action) => {
                                const isSecondary = action.variant === "secondary";

                                return (
                                    <Link
                                        key={`${action.href}-${action.label}`}
                                        href={action.href}
                                        className={cn(
                                            "group inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-medium transition",
                                            isSecondary
                                                ? "rounded-[14px] border border-[#efbf7e] bg-white text-[#d88a26] hover:bg-[#fff8ee]"
                                                : "rounded-[14px] bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.6)] hover:bg-[#ef3f32]",
                                        )}
                                    >
                                        <span>{action.label}</span>
                                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                                    </Link>
                                );
                            })}
                        </div>
                    ) : null}
                </div>

                {stats.length ? (
                    <div className="mt-8 grid gap-3 grid-cols-2 xl:grid-cols-4">
                        {stats.map((stat) => (
                            <div
                                key={stat.label}
                                className="rounded-[18px] border border-[#ece7de] bg-white p-4 text-left shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]"
                            >
                                <div className="text-2xl font-bold text-[#e28a20]">
                                    {stat.value}
                                </div>
                                <div className="mt-1 text-sm text-[#64748b]">{stat.label}</div>
                            </div>
                        ))}
                    </div>
                ) : null}

                {children}
            </div>
        </section>
    );
}
