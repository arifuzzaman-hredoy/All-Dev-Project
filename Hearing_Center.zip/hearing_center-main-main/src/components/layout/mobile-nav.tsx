"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Heart, Home, ShoppingBag, User2, LayoutDashboard, type LucideIcon } from "lucide-react";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import { useSession } from "next-auth/react";

type NavItemProps = {
  href: string;
  label: string;
  icon: LucideIcon;
  badgeCount?: number;
};

type CartItem = { productId: string; qty: number };
type Cart = { items: CartItem[] };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parseCart(input: unknown): Cart {
  if (!input || typeof input !== "object") return { items: [] };

  const o = input as Record<string, unknown>;
  const cartObj = (o.cart as Record<string, unknown> | undefined) ?? {};
  const raw = Array.isArray(cartObj.items) ? cartObj.items : [];

  const items: CartItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      qty: Math.max(1, Math.floor(safeNumber(x.qty, 1))),
    }))
    .filter((item) => item.productId);

  return { items };
}

function NavItem({ href, label, icon: Icon, badgeCount }: NavItemProps) {
  const pathname = usePathname();
  const active = pathname === href;

  return (
    <Link
      href={href}
      className={cn(
        "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs font-medium transition",
        active ? "text-[#d88a26]" : "text-[#64748b]"
      )}
    >
      <span className="relative inline-flex">
        <Icon className="h-5 w-5" />
        {typeof badgeCount === "number" && badgeCount > 0 ? (
          <span className="absolute -right-2 -top-2 inline-flex min-w-4 items-center justify-center rounded-full bg-[#ff4a3d] px-1 text-[10px] font-semibold leading-4 text-white shadow-[0_10px_20px_-12px_rgba(255,74,61,0.75)]">
            {badgeCount > 99 ? "99+" : badgeCount}
          </span>
        ) : null}
      </span>
      {label}
    </Link>
  );
}

export function MobileNav() {
  const { data } = useSession();
  const [cart, setCart] = useState<Cart>({ items: [] });
  const isAdmin = data?.user?.role === "ADMIN" || data?.user?.role === "STAFF";

  const cartCount = useMemo(
    () => cart.items.reduce((sum, item) => sum + item.qty, 0),
    [cart.items],
  );

  const loadCart = useCallback(async (): Promise<void> => {
    try {
      const response = await fetch("/api/cart", { cache: "no-store" });
      if (!response.ok) {
        setCart({ items: [] });
        return;
      }

      const json: unknown = await response.json().catch(() => null);
      setCart(parseCart(json));
    } catch {
      setCart({ items: [] });
    }
  }, []);

  useEffect(() => {
    queueMicrotask(() => {
      void loadCart();
    });

    const handler = () => {
      void loadCart();
    };

    window.addEventListener("rhc_cart_updated", handler);

    return () => {
      window.removeEventListener("rhc_cart_updated", handler);
    };
  }, [loadCart]);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-[#ece7de] bg-[rgba(255,255,255,0.92)] backdrop-blur md:hidden">
      <div className="mx-auto flex max-w-6xl px-2">
        <NavItem href="/" label="Home" icon={Home} />
        {isAdmin ? (
          <Link
            href="/admin"
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs font-medium text-[#64748b] transition hover:bg-[#fff4e8] hover:text-[#d88a26]"
            )}
          >
            <LayoutDashboard className="h-5 w-5" />
            Admin
          </Link>
        ) : null}
        <NavItem href="/wishlist" label="Wishlist" icon={Heart} />
        <NavItem
          href="/cart"
          label="Cart"
          icon={ShoppingBag}
          badgeCount={cartCount}
        />
        <NavItem href="/login" label="Account" icon={User2} />
      </div>
    </div>
  );
}
