"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Heart,
  User2,
  LayoutDashboard,
  Menu,
  X,
  Package2,
  ShoppingBag,
  Info,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { useSession, signOut } from "next-auth/react";
import CartBadge from "../shop/cart-badge";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import HeaderSearch from "../search/header-search";

const navItems = [
  { name: "Products", href: "/products", icon: Package2 },
  { name: "Orders", href: "/orders", icon: ShoppingBag },
  { name: "About Us", href: "/about-us", icon: Info },
];

type Branding = {
  storeName: string;
  logoUrl: string;
};

export function Header() {
  const pathname = usePathname();
  const { data, status } = useSession();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isFixedHeader, setIsFixedHeader] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement | null>(null);
  const mobileMenuButtonRef = useRef<HTMLButtonElement | null>(null);
  const [branding, setBranding] = useState<Branding>({
    storeName: "Rangpur Hearing Aids Center",
    logoUrl: "",
  }); 

  const isAdmin = data?.user?.role === "ADMIN" || data?.user?.role === "STAFF";
  const isLoggedIn = status === "authenticated";

  useEffect(() => {
    const handleScroll = () => {
      setIsFixedHeader(window.scrollY >= 200);
      setMobileMenuOpen(false);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (!mobileMenuOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (!target) return;

      if (mobileMenuRef.current?.contains(target)) return;
      if (mobileMenuButtonRef.current?.contains(target)) return;

      setMobileMenuOpen(false);
    };

    window.addEventListener("pointerdown", handlePointerDown);

    return () => {
      window.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [mobileMenuOpen]);

  useEffect(() => {
    let alive = true;

    const loadBranding = async () => {
      try {
        const res = await fetch("/api/store/settings/public", {
          cache: "no-store",
        });
        const json = await res.json().catch(() => null);

        if (!alive || !res.ok) return;

        setBranding({
          storeName:
            typeof json?.storeName === "string" && json.storeName.trim()
              ? json.storeName
              : "Rangpur Hearing Center",
          logoUrl:
            typeof json?.logoUrl === "string" && json.logoUrl.trim()
              ? json.logoUrl
              : "",
        });
      } catch {
        // Keep the bundled logo if settings cannot be loaded.
      }
    };

    void loadBranding();

    return () => {
      alive = false;
    };
  }, []);

  return (
    <header
      className={cn(
        "z-120 w-full overflow-visible border-[#ece7de] bg-[#f8f5f0]/95 backdrop-blur-md transition-all duration-300",
        isFixedHeader
          ? "fixed inset-x-0 top-0 border shadow-[0_20px_50px_-30px_rgba(15,23,42,0.28)]"
          : "relative rounded-b-[24px] border-x-0 border-t-0 border-b shadow-[0_18px_40px_-30px_rgba(15,23,42,0.2)]",
      )}
    >
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex min-h-12 sm:min-h-18 items-center gap-3">
          <Link href="/" className="flex shrink-0 items-center gap-3 group">
            {branding.logoUrl ? (
              <div className="relative h-18 w-18 shrink-0 transition-transform group-hover:scale-105 sm:h-18 sm:w-24">
                <Image
                  src={branding.logoUrl}
                  alt={`${branding.storeName} logo`}
                  fill
                  sizes="96px"
                  className="object-contain"
                  priority
                />
              </div>
            ) : null}
          </Link>

          <div className="flex-1 ">
            <HeaderSearch />
          </div>

          <nav className="ml-auto hidden items-center gap-1 md:flex">
            {navItems.map((item) => {
              const active =
                pathname === item.href || pathname.startsWith(item.href + "/");
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-[14px] px-4 py-2 text-sm font-semibold transition-all duration-150",
                    active
                      ? "bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)]"
                      : "text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.name}
                </Link>
              );
            })}

            {isAdmin ? (
              <Link
                href="/admin"
                className={cn(
                  "ml-1 inline-flex items-center gap-2 rounded-[14px] px-3 py-2 text-sm font-semibold transition-all duration-150",
                  pathname.startsWith("/admin")
                    ? "bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)]"
                    : "text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]",
                )}
              >
                <LayoutDashboard className="h-4 w-4" />
                Admin
              </Link>
            ) : null}

            <Link
              className="rounded-[14px] p-2 text-[#475569] transition-colors hover:bg-[#fff4e8] hover:text-[#d88a26]"
              href="/wishlist"
              aria-label="Wishlist"
            >
              <Heart className="h-5 w-5" />
            </Link>

            <CartBadge />

            {isLoggedIn ? (
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="rounded-[14px] px-3 py-2 text-sm font-semibold text-[#475569] transition-all hover:bg-[#fff4e8] hover:text-[#d88a26]"
                aria-label="Logout"
              >
                Logout
              </button>
            ) : (
              <Link
                className="rounded-[14px] p-2 text-[#475569] transition-colors hover:bg-[#fff4e8] hover:text-[#d88a26]"
                href="/login"
                aria-label="Login"
              >
                <User2 className="h-5 w-5" />
              </Link>
            )}
          </nav>

          <div className="ml-auto flex items-center gap-1 md:hidden">



            <button
              ref={mobileMenuButtonRef}
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="relative z-9999 rounded-[14px] p-2 text-[#d88a26] transition-colors hover:bg-[#fff4e8]"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* <div className="hidden pb-3 md:block lg:hidden">
          <HeaderSearch />
        </div>

        <div className="pb-3 md:hidden">
          <HeaderSearch />
        </div> */}
      </div>

      {mobileMenuOpen && (
        <div
          ref={mobileMenuRef}
          className="relative z-9998 animate-fade-in rounded-b-[24px] border-t border-[#ece7de] bg-white/95 shadow-[0_18px_40px_-30px_rgba(15,23,42,0.22)] md:hidden"
        >
          <div className="mx-auto max-w-6xl px-4 py-4">
            <nav className="flex flex-col gap-2">
              {navItems.map((item) => {
                const active =
                  pathname === item.href ||
                  pathname.startsWith(item.href + "/");
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-[16px] px-4 py-3 text-base font-semibold transition-all duration-150",
                      active
                        ? "bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)]"
                        : "text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]",
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    {item.name}
                  </Link>
                );
              })}

              {isAdmin ? (
                <Link
                  href="/admin"
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    "mt-1 flex items-center gap-3 rounded-[16px] px-4 py-3 text-base font-semibold transition-all duration-150",
                    pathname.startsWith("/admin")
                      ? "bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)]"
                      : "text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]",
                  )}
                >
                  <LayoutDashboard className="h-5 w-5" />
                  Admin
                </Link>
              ) : null}

              <div className="mt-2 grid grid-cols-2 gap-2">
                <Link
                  href="/wishlist"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-[16px] border border-[#ece7de] px-4 py-3 text-base font-semibold text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]"
                >
                  <Heart className="h-5 w-5" />
                  Wishlist
                </Link>

                {isLoggedIn ? (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      signOut({ callbackUrl: "/" });
                    }}
                    className="flex items-center justify-center gap-2 rounded-[16px] border border-[#ece7de] px-4 py-3 text-base font-semibold text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]"
                  >
                    Logout
                  </button>
                ) : (
                  <Link
                    href="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-center gap-2 rounded-[16px] border border-[#ece7de] px-4 py-3 text-base font-semibold text-[#475569] hover:bg-[#fff4e8] hover:text-[#d88a26]"
                  >
                    <User2 className="h-5 w-5" />
                    Login
                  </Link>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
