import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function SiteFooter() {
  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: {
      storeName: true,
      facebookUrl: true,
      instagramUrl: true,
      youtubeUrl: true,
      tiktokUrl: true,
      whatsappUrl: true,
    },
  });

  const socialLinks = [
    { label: "Facebook", href: settings?.facebookUrl || "" },
    { label: "Instagram", href: settings?.instagramUrl || "" },
    { label: "YouTube", href: settings?.youtubeUrl || "" },
    { label: "TikTok", href: settings?.tiktokUrl || "" },
    { label: "WhatsApp", href: settings?.whatsappUrl || "" },
  ].filter((item) => item.href.trim());

  return (
    <footer className="border-t border-black/10 bg-black/2">
      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="grid gap-6 md:grid-cols-3">
          <div>
            <div className="text-lg font-semibold">
              {settings?.storeName || "Rangpur Hearing Center"}
            </div>
            <div className="mt-2 text-sm text-black/60">
              Trusted online shopping experience with fast delivery and quality
              products.
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold">Quick Links</div>
            <div className="mt-3 grid gap-2 text-sm text-black/70">
              <Link href="/products" className="hover:underline">
                Products
              </Link>
              <Link href="/cart" className="hover:underline">
                Cart
              </Link>
              <Link href="/wishlist" className="hover:underline">
                Wishlist
              </Link>
              <Link href="/orders" className="hover:underline">
                Orders
              </Link>
              <Link href="/about-us" className="hover:underline">
                About Us
              </Link>
              <Link href="/privacy-policy" className="hover:underline">
                Privacy Policy
              </Link>
              <Link href="/terms-conditions" className="hover:underline">
                Terms & Conditions
              </Link>
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold">Follow Us</div>
            <div className="mt-3 flex flex-wrap gap-2">
              {socialLinks.length ? (
                socialLinks.map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-black/10 px-4 py-2 text-sm hover:bg-black hover:text-white"
                  >
                    {item.label}
                  </a>
                ))
              ) : (
                <div className="text-sm text-black/50">
                  No social links added yet.
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-black/10 pt-4 text-sm text-black/50">
          © {new Date().getFullYear()}{" "}
          {settings?.storeName || "Rangpur Hearing Center"}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
