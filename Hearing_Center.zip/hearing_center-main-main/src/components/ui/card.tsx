import { cn } from "@/lib/cn";

export function Card({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-[18px] border border-[#ece7de] bg-white " +
          "shadow-[0_18px_45px_-38px_rgba(15,23,42,0.28)]",
        className
      )}
      {...props}
    />
  );
}
