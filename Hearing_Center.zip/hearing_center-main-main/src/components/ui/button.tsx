"use client";

import * as React from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

export function Button({
  className,
  variant = "primary",
  size = "md",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-[14px] font-semibold transition " +
    "focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-60 disabled:pointer-events-none cursor-pointer";

  const variants: Record<Variant, string> = {
    primary:
      "bg-[#ff4a3d] text-white hover:bg-[#ef3f32] focus-visible:ring-[#ff4a3d] " +
      "shadow-[0_14px_28px_-18px_rgba(255,74,61,0.6)]",
    secondary:
      "border border-[#efbf7e] bg-white text-[#d88a26] hover:bg-[#fff8ee] focus-visible:ring-[#e28a20]",
    ghost:
      "bg-transparent text-[#334155] hover:bg-[#f8f5f0] focus-visible:ring-[#e28a20]",
    danger:
      "bg-[#b91c1c] text-white hover:bg-[#991b1b] focus-visible:ring-[#b91c1c]",
  };

  const sizes: Record<Size, string> = {
    sm: "h-9 px-4 text-sm",
    md: "h-11 px-5 text-sm",
    lg: "h-12 px-6 text-base",
  };

  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    />
  );
}
