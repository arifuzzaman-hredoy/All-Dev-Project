"use client";

import { type FormEvent, useEffect, useState } from "react";
import { X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type ConsultationFormField =
  | "name"
  | "phone"
  | "email"
  | "hearingAidUsage"
  | "hearingTestDone"
  | "tinnitus"
  | "crowdDifficulty"
  | "dailyLifeImpact"
  | "age"
  | "district"
  | "budget";

type ConsultationDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const initialConsultationForm = {
  name: "",
  phone: "",
  email: "",
  hearingAidUsage: "",
  hearingTestDone: "",
  tinnitus: "",
  crowdDifficulty: "",
  dailyLifeImpact: "",
  age: "",
  district: "",
  budget: "",
};

export default function ConsultationDialog({
  open,
  onOpenChange,
}: ConsultationDialogProps) {
  const [isSubmittingConsultation, setIsSubmittingConsultation] = useState(false);
  const [consultationForm, setConsultationForm] = useState(
    initialConsultationForm,
  );
  const { toast } = useToast();

  useEffect(() => {
    if (!open) return;

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onOpenChange(false);
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleEscape);

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleEscape);
    };
  }, [onOpenChange, open]);

  const updateConsultationField = (
    field: ConsultationFormField,
    value: string,
  ) => {
    setConsultationForm((current) => ({
      ...current,
      [field]: value,
    }));
  };

  const handleConsultationSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!consultationForm.name.trim() || !consultationForm.phone.trim()) {
      toast({
        title: "Name and phone are required",
        description: "Please fill in your contact details to request a consultation.",
        variant: "error",
      });
      return;
    }

    setIsSubmittingConsultation(true);

    try {
      const res = await fetch("/api/consultations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(consultationForm),
      });

      const json = (await res.json().catch(() => null)) as
        | { error?: string }
        | null;

      if (!res.ok) {
        toast({
          title: "Consultation request failed",
          description: json?.error || "Please try again in a moment.",
          variant: "error",
        });
        return;
      }

      toast({
        title: "Consultation request received",
        description: "We will contact you shortly with expert guidance.",
        variant: "success",
      });

      setConsultationForm(initialConsultationForm);
      onOpenChange(false);
    } catch {
      toast({
        title: "Consultation request failed",
        description: "Network সমস্যা হয়েছে। আবার চেষ্টা করুন।",
        variant: "error",
      });
    } finally {
      setIsSubmittingConsultation(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100000]">
      <button
        type="button"
        onClick={() => onOpenChange(false)}
        className="absolute inset-0 bg-[#111827]/60"
        aria-label="Close consultation form"
      />

      <div className="absolute inset-0 flex items-center justify-center p-3 sm:p-4">
        <div className="relative flex max-h-[92vh] w-full max-w-xl flex-col overflow-hidden rounded-[28px] border border-[#f8bbd0] bg-white shadow-[0_30px_90px_-48px_rgba(190,24,93,0.35)] sm:max-h-[90vh]">
          <div className="flex items-center justify-between border-b border-[#fce7f3] px-5 py-4 sm:px-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#b3124f]">
                Consultation Form
              </p>
              <h3 className="mt-1 text-xl font-bold text-[#111827]">
                আপনার তথ্য দিন
              </h3>
            </div>

            <button
              type="button"
              onClick={() => onOpenChange(false)}
              className="rounded-full border border-[#f8bbd0] p-2 text-[#b3124f] transition hover:bg-[#fff1f5]"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <form
            onSubmit={handleConsultationSubmit}
            className="flex-1 space-y-4 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনার নাম
                </label>
                <Input
                  value={consultationForm.name}
                  onChange={(event) =>
                    updateConsultationField("name", event.target.value)
                  }
                  placeholder="আপনার নাম লিখুন"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  মোবাইল নম্বর
                </label>
                <Input
                  value={consultationForm.phone}
                  onChange={(event) =>
                    updateConsultationField("phone", event.target.value)
                  }
                  placeholder="আপনার মোবাইল নম্বর লিখুন"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#374151]">
                ইমেইল
              </label>
              <Input
                type="email"
                value={consultationForm.email}
                onChange={(event) =>
                  updateConsultationField("email", event.target.value)
                }
                placeholder="আপনার ইমেইল লিখুন"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনি কি শ্রবণযন্ত্র ব্যবহার করেন?
                </label>
                <select
                  value={consultationForm.hearingAidUsage}
                  onChange={(event) =>
                    updateConsultationField("hearingAidUsage", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="yes">হ্যাঁ</option>
                  <option value="no">না</option>
                  <option value="previously-used">আগে ব্যবহার করেছি</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনার কি হিয়ারিং টেস্ট করা আছে ?
                </label>
                <select
                  value={consultationForm.hearingTestDone}
                  onChange={(event) =>
                    updateConsultationField("hearingTestDone", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="yes">হ্যাঁ</option>
                  <option value="no">না</option>
                </select>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনার কি টিনিটাস (কানে শোঁ শোঁ শব্দ) আছে ?
                </label>
                <select
                  value={consultationForm.tinnitus}
                  onChange={(event) =>
                    updateConsultationField("tinnitus", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="yes">হ্যাঁ</option>
                  <option value="no">না</option>
                  <option value="sometimes">মাঝে মাঝে</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনি কি জনাকীর্ণ জায়গায় (ভিড়ের মধ্যে) কানে শুনতে সমস্যা বোধ করেন ?
                </label>
                <select
                  value={consultationForm.crowdDifficulty}
                  onChange={(event) =>
                    updateConsultationField("crowdDifficulty", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="yes">হ্যাঁ</option>
                  <option value="no">না</option>
                  <option value="sometimes">কখনও কখনও</option>
                </select>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনার কানে শোনার সমস্যা আপনার দৈনন্দিন জীবনে কতখানি সমস্যা করছে?
                </label>
                <select
                  value={consultationForm.dailyLifeImpact}
                  onChange={(event) =>
                    updateConsultationField("dailyLifeImpact", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="mild">অল্প</option>
                  <option value="moderate">মাঝারি</option>
                  <option value="severe">অনেক বেশি</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনার বয়স কত ?
                </label>
                <Input
                  value={consultationForm.age}
                  onChange={(event) =>
                    updateConsultationField("age", event.target.value)
                  }
                  placeholder="আপনার বয়স লিখুন"
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  আপনি কোন জেলায় থাকেন?
                </label>
                <Input
                  value={consultationForm.district}
                  onChange={(event) =>
                    updateConsultationField("district", event.target.value)
                  }
                  placeholder="আপনার জেলার নাম লিখুন"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">
                  কানে শোনার সমস্যা সমাধানের জন্য আপনার বাজেট কেমন ?
                </label>
                <select
                  value={consultationForm.budget}
                  onChange={(event) =>
                    updateConsultationField("budget", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none transition focus:border-black/30 focus:ring-2 focus:ring-black/10"
                >
                  <option value="">একটি অপশন বাছাই করুন</option>
                  <option value="under-30k">৩০,০০০ টাকার নিচে</option>
                  <option value="30k-60k">৩০,০০০ - ৬০,০০০ টাকা</option>
                  <option value="60k-120k">৬০,০০০ - ১,২০,০০০ টাকা</option>
                  <option value="above-120k">১,২০,০০০ টাকার বেশি</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#374151]">
                আপনার নির্বাচিত তথ্যের সারাংশ
              </label>
              <textarea
                value={[
                  consultationForm.hearingAidUsage &&
                    `শ্রবণযন্ত্র ব্যবহার: ${consultationForm.hearingAidUsage}`,
                  consultationForm.hearingTestDone &&
                    `হিয়ারিং টেস্ট: ${consultationForm.hearingTestDone}`,
                  consultationForm.tinnitus &&
                    `টিনিটাস: ${consultationForm.tinnitus}`,
                  consultationForm.crowdDifficulty &&
                    `ভিড়ে শুনতে সমস্যা: ${consultationForm.crowdDifficulty}`,
                  consultationForm.dailyLifeImpact &&
                    `দৈনন্দিন জীবনে প্রভাব: ${consultationForm.dailyLifeImpact}`,
                ]
                  .filter(Boolean)
                  .join("\n")}
                rows={4}
                readOnly
                placeholder="আপনার নির্বাচিত তথ্য এখানে দেখা যাবে"
                className="w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none transition placeholder:text-black/40 focus:border-black/30 focus:ring-2 focus:ring-black/10"
              />
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => onOpenChange(false)}
                disabled={isSubmittingConsultation}
                className="inline-flex items-center justify-center rounded-xl border border-[#f8bbd0] bg-white px-5 py-3 text-sm font-semibold text-[#b3124f] transition hover:bg-[#fff1f5]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmittingConsultation}
                className="inline-flex items-center justify-center rounded-xl bg-[#b3122f] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#991127]"
              >
                {isSubmittingConsultation ? "Submitting..." : "Submit Request"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
