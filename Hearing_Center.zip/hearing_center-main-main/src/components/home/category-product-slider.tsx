"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useRef, useState } from "react";

type Props = {
  children: React.ReactNode;
  className?: string;
};

export default function CategoryProductSlider({
  children,
  className = "",
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  const pointerDownRef = useRef(false);
  const isDraggingRef = useRef(false);
  const dragAxisRef = useRef<"horizontal" | "vertical" | null>(null);
  const startXRef = useRef(0);
  const startYRef = useRef(0);
  const startScrollLeftRef = useRef(0);
  const dragDistanceRef = useRef(0);
  const preventClickRef = useRef(false);
  const activePointerIdRef = useRef<number | null>(null);

  const [isHydrated, setIsHydrated] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  useEffect(() => {
    queueMicrotask(() => {
      setIsHydrated(true);
    });
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const DRAG_THRESHOLD = 6;
    const AXIS_LOCK_THRESHOLD = 8;

    const updateScrollState = () => {
      const maxScrollLeft = el.scrollWidth - el.clientWidth;
      setCanScrollLeft(el.scrollLeft > 4);
      setCanScrollRight(maxScrollLeft - el.scrollLeft > 4);
    };

    const startInteraction = (clientX: number, clientY: number) => {
      pointerDownRef.current = true;
      dragAxisRef.current = null;
      isDraggingRef.current = false;
      preventClickRef.current = false;
      dragDistanceRef.current = 0;

      startXRef.current = clientX;
      startYRef.current = clientY;
      startScrollLeftRef.current = el.scrollLeft;
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;

      activePointerIdRef.current = e.pointerId;
      startInteraction(e.clientX, e.clientY);
    };

    const onPointerMove = (e: PointerEvent) => {
      if (
        activePointerIdRef.current !== null &&
        e.pointerId !== activePointerIdRef.current
      ) {
        return;
      }

      if (!pointerDownRef.current) return;

      const dx = e.clientX - startXRef.current;
      const dy = e.clientY - startYRef.current;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);

      if (!dragAxisRef.current) {
        if (absX < AXIS_LOCK_THRESHOLD && absY < AXIS_LOCK_THRESHOLD) return;

        dragAxisRef.current = absX > absY ? "horizontal" : "vertical";

        if (dragAxisRef.current === "vertical") {
          return;
        }

        isDraggingRef.current = true;
        setIsDragging(true);
      }

      if (dragAxisRef.current !== "horizontal") return;

      dragDistanceRef.current = Math.max(dragDistanceRef.current, absX);

      if (dragDistanceRef.current > DRAG_THRESHOLD) {
        preventClickRef.current = true;
      }

      e.preventDefault();
      el.scrollLeft = startScrollLeftRef.current - dx;
    };

    const endInteraction = () => {
      pointerDownRef.current = false;
      dragAxisRef.current = null;
      isDraggingRef.current = false;
      activePointerIdRef.current = null;
      setIsDragging(false);

      window.setTimeout(() => {
        preventClickRef.current = false;
      }, 220);
    };

    const onPointerUp = (e: PointerEvent) => {
      if (
        activePointerIdRef.current !== null &&
        e.pointerId !== activePointerIdRef.current
      ) {
        return;
      }
      endInteraction();
    };

    const onPointerCancel = (e: PointerEvent) => {
      if (
        activePointerIdRef.current !== null &&
        e.pointerId !== activePointerIdRef.current
      ) {
        return;
      }
      endInteraction();
    };

    const preventDrag = (e: DragEvent) => {
      e.preventDefault();
    };

    const captureClick = (e: MouseEvent) => {
      if (preventClickRef.current) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    updateScrollState();

    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("scroll", updateScrollState, { passive: true });
    window.addEventListener("pointermove", onPointerMove, { passive: false });
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerCancel);
    window.addEventListener("resize", updateScrollState);

    el.addEventListener("dragstart", preventDrag);
    el.addEventListener("click", captureClick, true);

    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("scroll", updateScrollState);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerCancel);
      window.removeEventListener("resize", updateScrollState);

      el.removeEventListener("dragstart", preventDrag);
      el.removeEventListener("click", captureClick, true);
    };
  }, []);

  const scrollByAmount = (direction: "left" | "right") => {
    const el = containerRef.current;
    if (!el) return;

    const amount = Math.max(el.clientWidth * 0.72, 220);
    el.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  return (
    <div className="relative">
      <button
        type="button"
        aria-label="Scroll left"
        onClick={() => scrollByAmount("left")}
        disabled={isHydrated ? !canScrollLeft : undefined}
        className={`absolute inset-y-0 left-0 z-10 my-auto flex h-10 w-10 items-center justify-center rounded-full border border-[#eadfce] bg-[#fff8ee]/95 text-[#8b5a2b] transition-all sm:h-11 sm:w-11 ${
          isHydrated && canScrollLeft
            ? "translate-x-0 opacity-100 hover:border-[#efbf7e] hover:bg-[#fff8ee]"
            : "pointer-events-none -translate-x-1 opacity-0"
        }`}
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <button
        type="button"
        aria-label="Scroll right"
        onClick={() => scrollByAmount("right")}
        disabled={isHydrated ? !canScrollRight : undefined}
        className={`absolute inset-y-0 right-0 z-10 my-auto flex h-10 w-10 items-center justify-center rounded-full border border-[#eadfce] bg-[#fff8ee]/95 text-[#8b5a2b] transition-all sm:h-11 sm:w-11 ${
          isHydrated && canScrollRight
            ? "translate-x-0 opacity-100 hover:border-[#efbf7e] hover:bg-[#fff8ee]"
            : "pointer-events-none translate-x-1 opacity-0"
        }`}
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      <div
        ref={containerRef}
        className={`flex gap-1 overflow-x-auto scrollbar-hide pb-2 select-none touch-pan-y ${
          isDragging ? "cursor-grabbing" : "cursor-grab"
        } ${className}`}
        style={{ WebkitOverflowScrolling: "touch" }}
      >
        {children}
      </div>
    </div>
  );
}
