import { ShoppingCart } from "lucide-react";
import HomeProductCard from "@/components/products/home-product-card";

type Product = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  shortDescription?: string | null;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured?: boolean;
  category?: { name: string; parent?: { name: string } | null } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  isBestSelling?: boolean;
};

export default function FeaturedProducts({
  products,
}: {
  products: Product[];
}) {
  if (!products?.length) {
    return (
      <div className="rounded-[18px] border border-[#ece7de] bg-white p-16 text-center">
        <ShoppingCart className="mx-auto mb-4 h-16 w-16 text-[#d9d0c5]" />
        <p className="text-lg font-medium text-[#334155]">
          No featured products yet.
        </p>
        <p className="mt-2 text-sm text-[#64748b]">
          Admin &gt; Products &gt; mark items as Featured
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-5 lg:gap-6">
      {products.map((product) => (
        <HomeProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
