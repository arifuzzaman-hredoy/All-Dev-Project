import { prisma } from "@/lib/prisma";
import CategoryGrid from "@/components/home/category-grid";

export default async function ShopByCategory() {
  const categories = await prisma.category.findMany({
    where: {
      isActive: true,
      parentId: null,
    },
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      slug: true,
      imageUrl: true,
      _count: {
        select: {
          products: true,
        },
      },
    },
  });

  if (!categories.length) return null;

  return (
    <section>
      <CategoryGrid
        categories={categories.map((category) => ({
          id: category.id,
          name: category.name,
          slug: category.slug,
          imageUrl: category.imageUrl,
          productCount: category._count.products,
        }))}
      />
    </section>
  );
}
