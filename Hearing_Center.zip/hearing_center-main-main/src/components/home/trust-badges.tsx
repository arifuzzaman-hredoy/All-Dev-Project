import { Shield, Truck, Star, Headphones } from "lucide-react";

export default function TrustBadges() {
  const items = [
    {
      title: "Clinical Guidance",
      desc: "Support before you choose the right device.",
      icon: Truck,
    },
    {
      title: "Trusted Fitting",
      desc: "Device setup and after-sales assistance.",
      icon: Shield,
    },
    {
      title: "Verified Products",
      desc: "Authentic hearing devices and accessories.",
      icon: Star,
    },
    {
      title: "Ongoing Support",
      desc: "Guidance for care, usage, and replacement needs.",
      icon: Headphones,
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.title}
            className="group relative flex flex-col items-center gap-3 overflow-hidden rounded-[6px] border border-[#ece7de] bg-white px-4 py-5 text-center transition-all hover:-translate-y-1 hover:shadow-[0_18px_45px_-36px_rgba(15,23,42,0.18)]"
          >
            <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-[#f6f2ec] text-[#d88a26]">
              <Icon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="relative text-sm font-semibold uppercase tracking-[0.12em] text-[#334155]">
                {item.title}
              </h3>
              <p className="relative mt-2 text-xs leading-6 text-[#64748b] sm:block">
                {item.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
