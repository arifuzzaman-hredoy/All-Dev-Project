import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { prisma } from "@/lib/prisma";
import HomeProductCard from "@/components/products/home-product-card";
import CategoryProductSlider from "./category-product-slider";
import { getBestSellingProductIds } from "@/lib/best-selling";

interface Props {
  slug: string;
  title: string;
  colorClass?: string;
}

export default async function CategoryProductRow({
  slug,
  title,
  colorClass = "",
}: Props) {
  const category = await prisma.category.findUnique({
    where: { slug },
    select: {
      id: true,
      name: true,
    },
  });

  if (!category) return null;

  const products = await prisma.product.findMany({
    where: {
      isActive: true,
      categoryId: category.id,
    },
    orderBy: [{ updatedAt: "desc" }],
    take: 16,
    include: {
      images: {
        orderBy: { sortOrder: "asc" },
        take: 1,
      },
      category: {
        select: {
          id: true,
          name: true,
          slug: true,
          parent: { select: { id: true, name: true, slug: true } },
        },
      },
    },
  });

  if (!products.length) return null;

  const productIds = products.map((product) => product.id);

  const [ratings, bestSellingIds] = await Promise.all([
    prisma.review.groupBy({
      by: ["productId"],
      where: { productId: { in: productIds } },
      _avg: { rating: true },
      _count: { rating: true },
    }),
    getBestSellingProductIds(),
  ]);

  const ratingMap = new Map(
    ratings.map((item) => [
      item.productId,
      {
        ratingAvg:
          typeof item._avg.rating === "number"
            ? Math.round(item._avg.rating * 10) / 10
            : 0,
        ratingCount:
          typeof item._count.rating === "number" ? item._count.rating : 0,
      },
    ]),
  );

  return (
    <section className="mx-auto max-w-7xl px-4 pt-9 lg:px-6 ">
      <div className="mb-4 flex items-end justify-between gap-4 border-b border-[#ece7de] pb-3">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#8b5a2b]">
            Shop Collection
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-[#334155] md:text-3xl">
            {title}
          </h2>
        </div>

        <Link
          href={`/products?cat=${slug}`}
          className={`group shrink-0 flex items-center gap-2 rounded-[14px] px-5 py-2.5 text-sm font-semibold ring-1 transition-all ${
            colorClass
              ? colorClass
              : "bg-[#fff8ee] text-[#d88a26] ring-[#efbf7e] hover:bg-[#fff1df] hover:text-[#b96f10]"
          }`}
        >
          <span>View all</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>

      <CategoryProductSlider>
        {products.map((product) => {
          const rating = ratingMap.get(product.id);

          return (
            <div key={product.id} className="w-52 shrink-0 sm:w-56 lg:w-60">
              <HomeProductCard
                product={{
                  id: product.id,
                  name: product.name,
                  slug: product.slug,
                  description: product.description,
                  shortDescription: null,
                  price: product.price,
                  offerPrice: product.offerPrice,
                  stock: product.stock,
                  isFeatured: product.isFeatured,
                  category: product.category,
                  images: product.images,
                  ratingAvg: rating?.ratingAvg ?? 0,
                  ratingCount: rating?.ratingCount ?? 0,
                  isBestSelling: bestSellingIds.has(product.id),
                }}
              />
            </div>
          );
        })}
      </CategoryProductSlider>
    </section>
  );
}
