import {
  ShieldCheck,
  PackageCheck,
  Sparkles,
  ArrowRight,
  SearchCheck,
} from "lucide-react";

const HelpSection = () => {
  return (
    <div className="flex items-center justify-center py-6 sm:py-8 md:py-12">
      <div className="relative w-full max-w-7xl overflow-hidden rounded-[8px] border border-[#ece7de] bg-white">
        <div className="relative z-10 grid grid-cols-1 gap-8 p-6 sm:p-8 md:grid-cols-[1.35fr_0.65fr] md:gap-10 md:p-10 lg:p-12">
          <div className="flex flex-col justify-center">
            <div className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-[#ece7de] bg-[#f8f5f0] px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.18em] text-[#8b5a2b]">
              <Sparkles size={14} className="text-[#d88a26]" />
              Consultation & Care
            </div>

            <h2 className="max-w-3xl text-2xl font-semibold leading-tight text-[#334155] sm:text-3xl md:text-[2rem] lg:text-[2.3rem]">
              Hear better with the right product,
              <span className="block text-[#64748b]">
                chosen with clarity and support
              </span>
            </h2>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-[#64748b] sm:text-[15px]">
              From hearing aid selection to daily care, we make the process
              easier with curated products, practical guidance, and a calmer
              shopping experience.
            </p>

            <div className="mt-8 grid max-w-2xl grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="group rounded-[6px] border border-[#ece7de] bg-[#fbf9f5] p-4 transition duration-300 hover:bg-[#f6f2ec]">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-[#f1efeb] text-[#d88a26]">
                  <ShieldCheck size={22} />
                </div>
                <h3 className="text-base font-semibold text-[#334155]">
                  Verified Hearing Products
                </h3>
                <p className="mt-1 text-sm text-[#64748b]">
                  Reliable devices and accessories selected for everyday use.
                </p>
              </div>

              <div className="group rounded-[6px] border border-[#ece7de] bg-[#fbf9f5] p-4 transition duration-300 hover:bg-[#f6f2ec]">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-[#f1efeb] text-[#d88a26]">
                  <PackageCheck size={22} />
                </div>
                <h3 className="text-base font-semibold text-[#334155]">
                  Smooth Ordering & Follow-up
                </h3>
                <p className="mt-1 text-sm text-[#64748b]">
                  Guidance from checkout to care support after purchase.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col justify-center gap-5 md:items-end">
            <ShineButton
              text="Explore Collection"
              icon={<ArrowRight size={18} />}
              glow="accent"
            />

            <ShineButton
              text="Track My Order"
              icon={<SearchCheck size={18} />}
              glow="soft"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const ShineButton = ({ text, icon, glow = "accent" }) => {
  const glowStyles =
    glow === "soft"
      ? "border-[#efbf7e] bg-white text-[#d88a26] hover:bg-[#fff8ee]"
      : "border-[#ff4a3d] bg-[#ff4a3d] text-white hover:bg-[#ef3f32] hover:border-[#ef3f32]";

  return (
    <button
      className={`group relative inline-flex min-w-[220px] items-center justify-center gap-2 overflow-hidden rounded-[14px] border px-6 py-4 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${glowStyles}`}
    >
      <span className="relative z-10">{text}</span>
      <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
        {icon}
      </span>
    </button>
  );
};

export default HelpSection;
