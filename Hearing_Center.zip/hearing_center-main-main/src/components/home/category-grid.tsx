"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import ConsultationDialog from "@/components/home/consultation-dialog";
import CategoryProductSlider from "@/components/home/category-product-slider";

type Category = {
  id: string;
  name: string;
  slug: string;
  imageUrl?: string | null;
  productCount: number;
};

function CategoryCard({ category }: { category: Category }) {
  return (
    <Link
      href={`/products?cat=${encodeURIComponent(category.slug)}`}
      className="group flex w-full flex-col items-center gap-3 text-center"
    >
      <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[6px] border border-[#ece7de] bg-[#f6f2ec] shadow-sm transition-transform duration-300 group-hover:-translate-y-1">
        {category.imageUrl ? (
          <Image
            src={category.imageUrl}
            alt={category.name}
            fill
            className="object-contain p-2"
            sizes="(max-width: 640px) 148px, (max-width: 1024px) 170px, 180px"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white text-3xl font-semibold text-[#d88a26]">
            {category.name.charAt(0).toUpperCase()}
          </div>
        )}
      </div>

      <h3 className="max-w-[180px] text-[11px] font-semibold uppercase tracking-[0.18em] leading-snug text-[#334155] transition-colors duration-300 group-hover:text-[#d88a26]">
        {category.name}
      </h3>
      <p className="text-xs text-[#64748b]">
        {category.productCount} products
      </p>
    </Link>
  );
}

export default function CategoryGrid({
  categories,
}: {
  categories: Category[];
}) {
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);

  if (!categories?.length) return null;

  return (
    <>
      <section className="border-y border-[#ece7de] bg-white px-4 py-8 sm:px-6 lg:px-10">
        <div className="mx-auto max-w-6xl">
          <p className="text-center text-[11px] font-semibold uppercase tracking-[0.24em] text-[#8b5a2b] sm:text-xs">
            Shop By Category
          </p>
          
          <h2 className="mt-3 text-center text-2xl font-semibold tracking-tight text-[#334155] sm:text-3xl">
            Hearing Collections
          </h2>

          <div className="mx-auto mt-8 max-w-6xl">
            <CategoryProductSlider className="-mx-1 gap-4 px-1 pb-3 touch-pan-x snap-x snap-mandatory overscroll-x-contain [scrollbar-width:none] [-ms-overflow-style:none]">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className="min-w-[148px] flex-none snap-start sm:min-w-[170px] lg:min-w-[180px]"
                >
                  <CategoryCard category={category} />
                </div>
              ))}
            </CategoryProductSlider>
          </div>

          <div className="mt-8 text-center">
            <button
              type="button"
              onClick={() => setIsConsultationOpen(true)}
              className="inline-flex items-center justify-center rounded-[14px] border border-[#efbf7e] bg-white px-6 py-3 text-sm font-semibold text-[#d88a26] transition-colors duration-300 hover:bg-[#fff8ee]"
            >
              Need Help Choosing?
            </button>
          </div>
        </div>
      </section>

      <ConsultationDialog
        open={isConsultationOpen}
        onOpenChange={setIsConsultationOpen}
      />
    </>
  );
}
