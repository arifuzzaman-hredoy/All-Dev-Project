"use client";

import { useEffect, useMemo, useState } from "react";
import Image, { type StaticImageData } from "next/image";
import Link from "next/link";
import {
  BadgeCheck,
  ChevronLeft,
  ChevronRight,
  Headphones,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import heroBannerImg from "@/assets/banner/bannerblack.jpg";
import heroSideBannerImg1 from "@/assets/banner/bannerblack2.png";
import heroSideBannerImg2 from "@/assets/banner/iamgeblack3.png";
import ConsultationDialog from "@/components/home/consultation-dialog";

type HomeBanner = {
  slot: string | null;
  title: string | null;
  imageUrl: string;
  linkUrl: string | null;
};

type HeroSectionProps = {
  settings: unknown;
  banners?: HomeBanner[];
};

type HeroBannerView = {
  href: string;
  image: string | StaticImageData;
  alt: string;
};

const fallbackBanners: HeroBannerView[] = [
  {
    href: "/products",
    image: heroBannerImg,
    alt: "Featured banner",
  },
  {
    href: "/products",
    image: heroSideBannerImg1,
    alt: "Promotional banner",
  },
  {
    href: "/products?featured=1",
    image: heroSideBannerImg2,
    alt: "Featured promotional banner",
  },
];

const ribbonItems = [
  "Consultation-first guidance",
  "Rechargeable hearing solutions",
  "Warranty Support",
  "Trusted by hearing patients",
];

function getBannerView(
  banner: Pick<HomeBanner, "imageUrl" | "linkUrl" | "title">,
): HeroBannerView {
  return {
    href: banner.linkUrl || "/products",
    image: banner.imageUrl,
    alt: banner.title || "Promotional banner",
  };
}

export default function HeroSection({
  settings,
  banners = [],
}: HeroSectionProps) {
  void settings;

  const [activeSlide, setActiveSlide] = useState(0);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);

  const heroSlides = useMemo(
    () =>
      banners.length
        ? banners
            .filter((banner) => banner.imageUrl)
            .map((banner) => getBannerView(banner))
        : fallbackBanners,
    [banners],
  );

  useEffect(() => {
    if (heroSlides.length <= 1) return;

    const interval = window.setInterval(() => {
      setActiveSlide((current) => (current + 1) % heroSlides.length);
    }, 5000);

    return () => window.clearInterval(interval);
  }, [heroSlides.length]);

  const safeActiveSlide = heroSlides.length
    ? Math.min(activeSlide, heroSlides.length - 1)
    : 0;
  const active = heroSlides[safeActiveSlide];

  return (
    <section className="relative pt-4 sm:pt-6 lg:pt-8">
      <div className="mx-auto max-w-[1440px] px-3 sm:px-4 lg:px-6">
        <div className="overflow-hidden rounded-[24px] border border-[#e9e2d7] bg-[#f7f2e8] p-2.5 sm:p-4 lg:rounded-[34px] lg:p-5">
          <div className="grid gap-3 lg:grid-cols-[minmax(0,1.02fr)_minmax(0,0.98fr)] lg:items-stretch">
            <div className="order-2 rounded-[22px] px-4 py-5 sm:px-6 sm:py-7 lg:order-1 lg:px-8 lg:py-8 xl:px-10 xl:py-10">
              <div className="flex flex-wrap items-center gap-2.5 text-[#1f3a2d] sm:gap-3">
                <div className="flex items-center gap-2 text-sm font-semibold sm:text-[15px]">
                  <span className="text-[#00b67a]">*</span>
                  <span>RHC</span>
                </div>
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <span
                      key={index}
                      className="inline-flex h-5 w-5 items-center justify-center bg-[#00b67a] text-[10px] text-white sm:h-6 sm:w-6 sm:text-xs lg:h-7 lg:w-7 lg:text-sm"
                    >
                      *
                    </span>
                  ))}
                </div>
                <div className="text-sm font-medium text-[#334155] sm:text-base">
                  4.9/5
                </div>
                <div className="text-sm text-[#475569] sm:text-base">
                  18K+ reviews
                </div>
              </div>

              <p className="mt-4 text-sm font-semibold text-[#334155] sm:mt-5 sm:text-base">
                Trusted hearing care support with product guidance that puts
                real-life comfort first.
              </p>

              <h1 className="mt-4 max-w-[18ch] text-[36px] font-light leading-[0.95] tracking-[-0.05em] text-[#183528] sm:text-[30px] md:text-[32px] lg:text-[34px] xl:text-[36px]">
                Better hearing built for everyday life
              </h1>

              <p className="mt-3 max-w-xl text-sm leading-7 text-[#4f5f58] sm:text-base sm:leading-8 lg:text-[17px]">
                Personalized hearing aid guidance, rechargeable devices, and
                care support designed around comfort, clarity, and confidence.
              </p>

              <div className="mt-5 space-y-3 text-[#24382f]">
                <div className="flex items-start gap-3 text-sm font-medium leading-6 sm:text-base lg:text-[17px]">
                  <BadgeCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#183528]" />
                  <span>Loss-friendly hearing plans built around your needs</span>
                </div>
                <div className="flex items-start gap-3 text-sm font-medium leading-6 sm:text-base lg:text-[17px]">
                  <Stethoscope className="mt-0.5 h-5 w-5 shrink-0 text-[#183528]" />
                  <span>Rechargeable and discreet options for daily life</span>
                </div>
                <div className="flex items-start gap-3 text-sm font-medium leading-6 sm:text-base lg:text-[17px]">
                  <Headphones className="mt-0.5 h-5 w-5 shrink-0 text-[#183528]" />
                  <span>Access to clinicians and after-sales care support</span>
                </div>
              </div>

              <div className="mt-7 flex flex-col gap-3 sm:mt-8 sm:flex-row">
                <button
                  type="button"
                  onClick={() => setIsConsultationOpen(true)}
                  className="inline-flex min-h-[54px] items-center justify-center rounded-full bg-[#183528] px-4 text-base font-semibold text-white shadow-[0_18px_45px_-24px_rgba(24,53,40,0.45)] transition hover:bg-[#12291f] sm:min-h-[60px] sm:px-6 sm:text-lg"
                >
                  Book A Consultation?
                </button>
                <Link
                  href={active.href}
                  className="inline-flex min-h-[54px] items-center justify-center rounded-full border border-[#183528] bg-white/80 px-4 text-base font-semibold text-[#183528] transition hover:bg-white sm:min-h-[60px] sm:px-6 sm:text-lg"
                >
                  Explore products
                </Link>
              </div>
            </div>

            <div className="order-1 hidden lg:order-2 lg:block">
              <div className="relative h-full min-h-[420px] overflow-hidden rounded-[22px] bg-[#d9c0a0]">
                {heroSlides.map((slide, index) => (
                  <Link
                    key={`${slide.alt}-${index}`}
                    href={slide.href}
                    className={`absolute inset-0 transition-all duration-700 ${
                      index === safeActiveSlide
                        ? "pointer-events-auto opacity-100"
                        : "pointer-events-none opacity-0"
                    }`}
                    aria-hidden={index !== safeActiveSlide}
                    tabIndex={index === safeActiveSlide ? 0 : -1}
                  >
                    <Image
                      src={slide.image}
                      alt={slide.alt}
                      fill
                      className="object-cover"
                      priority={index === 0}
                      sizes="(max-width: 1023px) 100vw, 48vw"
                    />
                  </Link>
                ))}

                <div className="absolute right-3 top-3 flex h-16 w-16 items-center justify-center rounded-full bg-[rgba(251,247,240,0.92)] text-center text-[#183528] shadow-sm sm:right-4 sm:top-4 sm:h-20 sm:w-20 lg:right-5 lg:top-5 lg:h-24 lg:w-24">
                  <div>
                    <div className="text-[9px] uppercase tracking-[0.22em] sm:text-[10px] lg:text-[11px] lg:tracking-[0.28em]">
                      Promise
                    </div>
                    <div className="mt-0.5 text-lg font-semibold sm:text-xl lg:mt-1 lg:text-2xl">
                      RHC
                    </div>
                  </div>
                </div>

                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[rgba(24,53,40,0.48)] via-[rgba(24,53,40,0.18)] to-transparent px-5 pb-5 pt-16">
                  <div className="flex items-center justify-center gap-2">
                    {heroSlides.map((slide, index) => (
                      <button
                        key={`${slide.alt}-dot-${index}`}
                        type="button"
                        onClick={() => setActiveSlide(index)}
                        className={`h-2.5 rounded-full transition-all ${
                          index === safeActiveSlide
                            ? "w-9 bg-white"
                            : "w-2.5 bg-white/55 hover:bg-white/80"
                        }`}
                        aria-label={`Go to hero slide ${index + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 flex flex-col gap-3 rounded-[20px] bg-white px-4 py-3 text-[#20372b] shadow-[0_12px_30px_-24px_rgba(15,23,42,0.22)] sm:px-5 lg:flex-row lg:items-center lg:justify-between">
            

            <div className="grid flex-1 gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4 lg:gap-4 lg:text-sm xl:text-base">
              {ribbonItems.map((item, index) => (
                <div
                  key={item}
                  className={`flex items-center gap-2.5 ${
                    index < ribbonItems.length - 1
                      ? "lg:border-r lg:border-[#e7dfd5] lg:pr-6"
                      : ""
                  }`}
                >
                  <ShieldCheck className="h-4 w-4 shrink-0 text-[#183528] lg:h-5 lg:w-5" />
                  <span className="font-medium leading-6 text-[#334155]">
                    {item}
                  </span>
                </div>
              ))}
            </div>

            <div className="hidden items-center justify-end gap-2 lg:flex">
              <button
                type="button"
                onClick={() =>
                  setActiveSlide((current) =>
                    current <= 0 ? heroSlides.length - 1 : current - 1,
                  )
                }
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#d8d0c3] bg-[#fbf7f0] text-[#183528] transition hover:bg-white sm:h-11 sm:w-11"
                aria-label="Previous hero slide"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() =>
                  setActiveSlide(
                    (current) => (current + 1) % heroSlides.length,
                  )
                }
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#d8d0c3] bg-[#fbf7f0] text-[#183528] transition hover:bg-white sm:h-11 sm:w-11"
                aria-label="Next hero slide"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <ConsultationDialog
        open={isConsultationOpen}
        onOpenChange={setIsConsultationOpen}
      />
    </section>
  );
}
