"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import HomeProductCard from "@/components/products/home-product-card";
import { useRouter, useSearchParams } from "next/navigation";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Star,
  Package,
  Filter,
  Grid3x3,
  List,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  buildCategoryTree,
  type CategoryTreeItem,
  type CategoryTreeNode,
} from "@/lib/category-tree";
import {
  DEFAULT_HEARING_CATALOG_SETTINGS,
  normalizeHearingCatalogSettings,
  type HearingCatalogSettings,
} from "@/lib/hearing-catalog";

type Category = CategoryTreeItem;

type Product = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  shortDescription?: string | null;
  brand?: string | null;
  modelCode?: string | null;
  deviceStyle?: string | null;
  hearingLossRange?: string | null;
  batteryType?: string | null;
  connectivity?: string | null;
  isRechargeable?: boolean;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured?: boolean;
  isBestSelling?: boolean;
  category?: {
    id: string;
    name: string;
    slug?: string;
    parent?: { id: string; name: string; slug: string } | null;
  } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
};

type ProductsApiResponse = {
  items: Product[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeNullableNumber(v: unknown): number | null {
  if (v === null) return null;
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function safeArray<T>(v: unknown, map: (x: unknown) => T): T[] {
  return Array.isArray(v) ? v.map(map) : [];
}

function parseProduct(input: unknown): Product | null {
  const o = input as Record<string, unknown>;
  const id = safeString(o.id);
  const name = safeString(o.name);
  const slug = safeString(o.slug);

  if (!id || !name || !slug) return null;

  const categoryObj = o.category as Record<string, unknown> | null | undefined;
  const category =
    categoryObj && typeof categoryObj === "object"
      ? {
          id: safeString(categoryObj.id),
          name: safeString(categoryObj.name),
          slug: safeString(categoryObj.slug),
          parent:
            categoryObj.parent && typeof categoryObj.parent === "object"
              ? {
                  id: safeString(
                    (categoryObj.parent as Record<string, unknown>).id,
                  ),
                  name: safeString(
                    (categoryObj.parent as Record<string, unknown>).name,
                  ),
                  slug: safeString(
                    (categoryObj.parent as Record<string, unknown>).slug,
                  ),
                }
              : null,
        }
      : null;

  const images = safeArray(o.images, (img) => {
    const io = img as Record<string, unknown>;
    return { url: safeString(io.url) };
  }).filter((x) => !!x.url);

  return {
    id,
    name,
    slug,
    description: safeString(o.description) || null,
    shortDescription: safeString(o.shortDescription) || null,
    brand: safeString(o.brand) || null,
    modelCode: safeString(o.modelCode) || null,
    deviceStyle: safeString(o.deviceStyle) || null,
    hearingLossRange: safeString(o.hearingLossRange) || null,
    batteryType: safeString(o.batteryType) || null,
    connectivity: safeString(o.connectivity) || null,
    isRechargeable: !!o.isRechargeable,
    price: safeNumber(o.price, 0),
    offerPrice: safeNullableNumber(o.offerPrice),
    stock: safeNumber(o.stock, 0),
    isFeatured: !!o.isFeatured,
    isBestSelling: !!o.isBestSelling,
    category: category?.name ? category : null,
    images,
    ratingAvg: safeNumber(o.ratingAvg, 0),
    ratingCount: safeNumber(o.ratingCount, 0),
  };
}

function parseProductsResponse(input: unknown): ProductsApiResponse {
  const o = input as Record<string, unknown>;

  const items = safeArray(o.items, (x) => parseProduct(x)).filter(
    (p): p is Product => p !== null,
  );

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 12)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

export default function ProductsBrowser({
  categories,
}: {
  categories: Category[];
}) {
  const router = useRouter();
  const sp = useSearchParams();

  const [loading, setLoading] = React.useState(false);
  const [data, setData] = React.useState<ProductsApiResponse | null>(null);
  const [mobileFiltersOpen, setMobileFiltersOpen] = React.useState(false);
  const [catalogOptions, setCatalogOptions] =
    React.useState<HearingCatalogSettings>(DEFAULT_HEARING_CATALOG_SETTINGS);
  const [viewMode, setViewMode] = React.useState<"grid" | "list">("grid");
  const [expandedParents, setExpandedParents] = React.useState<
    Record<string, boolean>
  >({});
  const [min, setMin] = React.useState(sp.get("min") || "");
  const [max, setMax] = React.useState(sp.get("max") || "");

  const q = sp.get("q") || "";
  const sort = sp.get("sort") || "newest";
  const cat = sp.get("cat") || "";
  const featured = sp.get("featured") || "";
  const inStock = sp.get("inStock") || "";
  const style = sp.get("style") || "";
  const loss = sp.get("loss") || "";
  const rechargeable = sp.get("rechargeable") || "";
  const takeFromUrl = Number(sp.get("take") || "12") || 12;
  const pageFromUrl = Number(sp.get("page") || "1") || 1;

  const tree: CategoryTreeNode[] = React.useMemo(
    () => buildCategoryTree(categories),
    [categories],
  );

  React.useEffect(() => {
    setMin(sp.get("min") || "");
    setMax(sp.get("max") || "");
  }, [sp]);

  React.useEffect(() => {
    const loadCatalogOptions = async () => {
      try {
        const res = await fetch("/api/store/hearing-catalog", {
          cache: "no-store",
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) return;
        setCatalogOptions(normalizeHearingCatalogSettings(json?.settings));
      } catch {
        // Keep default options if settings have not been configured yet.
      }
    };

    void loadCatalogOptions();
  }, []);

  React.useEffect(() => {
    const next: Record<string, boolean> = {};
    tree.forEach((parent) => {
      next[parent.id] =
        parent.slug === cat ||
        parent.children.some((child) => child.slug === cat);
    });
    setExpandedParents((prev) => ({ ...prev, ...next }));
  }, [tree, cat]);

  const queryString = sp.toString();

  const fetchData = React.useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(`/api/products?${queryString}`, {
        cache: "no-store",
      });
      const j: unknown = await r.json();
      setData(parseProductsResponse(j));
    } catch {
      setData({
        items: [],
        total: 0,
        page: 1,
        take: 12,
        pages: 1,
      });
    } finally {
      setLoading(false);
    }
  }, [queryString]);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const setParam = React.useCallback(
    (key: string, value: string): void => {
      const params = new URLSearchParams(sp.toString());

      if (value.trim()) params.set(key, value.trim());
      else params.delete(key);

      if (key !== "page") params.set("page", "1");

      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const setManyParams = React.useCallback(
    (updates: Record<string, string>) => {
      const params = new URLSearchParams(sp.toString());

      for (const [key, value] of Object.entries(updates)) {
        if (value.trim()) params.set(key, value.trim());
        else params.delete(key);
      }

      params.set("page", "1");
      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const goPage = React.useCallback(
    (p: number): void => {
      const params = new URLSearchParams(sp.toString());
      params.set("page", String(p));
      router.push(`/products?${params.toString()}`);
    },
    [router, sp],
  );

  const clearAll = React.useCallback((): void => {
    router.push("/products");
  }, [router]);

  const activeFiltersCount = React.useMemo(() => {
    let count = 0;
    if (q) count++;
    if (min || max) count++;
    if (cat) count++;
    if (sort !== "newest") count++;
    if (featured === "1") count++;
    if (inStock === "1") count++;
    if (style) count++;
    if (loss) count++;
    if (rechargeable === "1") count++;
    if (takeFromUrl !== 12) count++;
    return count;
  }, [q, min, max, cat, sort, featured, inStock, style, loss, rechargeable, takeFromUrl]);

  const activeCatName = React.useMemo(() => {
    if (!cat) return "All Categories";
    const found = categories.find((c) => c.slug === cat);
    if (!found) return "Category";

    if (!found.parentId) return found.name;

    const parent = categories.find((c) => c.id === found.parentId);
    return parent ? `${parent.name} → ${found.name}` : found.name;
  }, [cat, categories]);

  const pages = data?.pages ?? 1;
  const currentPage = clamp(data?.page ?? pageFromUrl, 1, pages);

  const pageButtons = React.useMemo(() => {
    const last = pages;
    const p = currentPage;

    const set = new Set<number>();
    set.add(1);
    set.add(last);

    for (let i = p - 1; i <= p + 1; i++) {
      if (i >= 1 && i <= last) set.add(i);
    }

    const arr = Array.from(set).sort((a, b) => a - b);

    const out: number[] = [];
    for (let i = 0; i < arr.length; i++) {
      out.push(arr[i]);
      if (i < arr.length - 1 && arr[i + 1] - arr[i] > 1) out.push(0);
    }

    return out;
  }, [pages, currentPage]);

  const toggleParent = (id: string) => {
    setExpandedParents((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const renderCategoryTree = (mobile = false) => (
    <div className="space-y-2">
      <button
        onClick={() => {
          setParam("cat", "");
          if (mobile) setMobileFiltersOpen(false);
        }}
        className={`w-full rounded-xl px-4 py-2.5 text-left transition-all ${
          !cat
            ? "bg-[#d88a26] text-white"
            : "bg-[#fff8ee] text-slate-700 hover:bg-[#fff1df]"
        }`}
      >
        <span className="text-sm font-medium">All Categories</span>
      </button>

      {tree.map((parent) => {
        const isParentActive = cat === parent.slug;
        const hasChildren = parent.children.length > 0;
        const isOpen = expandedParents[parent.id];

        return (
          <div
            key={parent.id}
            className="rounded-2xl border border-[#ece7de] bg-white/90"
          >
            <div className="flex gap-2 p-2">
              <button
                onClick={() => {
                  setParam("cat", parent.slug);
                  if (mobile) setMobileFiltersOpen(false);
                }}
                className={`flex-1 rounded-xl px-4 py-2.5 text-left transition-all ${
                  isParentActive
                    ? "bg-[#d88a26] text-white"
                    : "bg-[#fff8ee] text-slate-700 hover:bg-[#fff1df]"
                }`}
              >
                <span className="text-sm font-medium">{parent.name}</span>
              </button>

              {hasChildren ? (
                <button
                  type="button"
                  onClick={() => toggleParent(parent.id)}
                  className="rounded-xl bg-[#f8f5f0] px-3 text-slate-700 hover:bg-[#f1ebe2]"
                >
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </button>
              ) : null}
            </div>

            {hasChildren && isOpen ? (
              <div className="space-y-2 px-2 pb-2">
                {parent.children.map((child) => {
                  const isChildActive = cat === child.slug;

                  return (
                    <button
                      key={child.id}
                      onClick={() => {
                        setParam("cat", child.slug);
                        if (mobile) setMobileFiltersOpen(false);
                      }}
                      className={`w-full rounded-xl px-4 py-2.5 text-left text-sm transition-all ${
                        isChildActive
                          ? "bg-[#d88a26] text-white"
                          : "bg-white text-slate-700 hover:bg-[#fff8ee]"
                      }`}
                    >
                      ↳ {child.name}
                    </button>
                  );
                })}
              </div>
            ) : null}
          </div>
        );
      })}
    </div>
  );

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#fbf9f5] via-white to-white">
      <section className="sticky top-0 z-30 border-b border-[#ece7de] bg-white/90 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-4 lg:px-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Link
                  href="/"
                  className="transition-colors hover:text-[#d88a26]"
                >
                  Home
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span className="font-medium text-slate-900">Products</span>
              </div>
              <h1 className="mt-1 text-2xl font-bold text-slate-900 md:text-3xl">
                Browse Products
              </h1>
              <p className="mt-1 max-w-2xl text-sm text-slate-600">
                Explore hearing solutions in a calmer warm-neutral catalog with
                clearer filtering and browsing controls.
              </p>
            </div>

            <div className="flex items-center gap-2 md:hidden">
              <Button
                variant="secondary"
                onClick={() => setMobileFiltersOpen(true)}
                className="flex-1 rounded-full border-[#ece7de] bg-white text-[#334155]"
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
                {activeFiltersCount > 0 ? (
                  <span className="ml-2 rounded-full bg-[#d88a26] px-2 py-0.5 text-xs text-white">
                    {activeFiltersCount}
                  </span>
                ) : null}
              </Button>

              <Button
                variant="secondary"
                onClick={() =>
                  setViewMode(viewMode === "grid" ? "list" : "grid")
                }
                className="rounded-full border-[#ece7de] bg-white text-[#334155]"
              >
                {viewMode === "grid" ? (
                  <List className="h-4 w-4" />
                ) : (
                  <Grid3x3 className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
        {activeFiltersCount > 0 ? (
          <div className="mb-6 flex flex-wrap items-center gap-2">
            <span className="text-sm text-slate-500">Active filters:</span>

            {q ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Search: {q}</span>
                <button onClick={() => setParam("q", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {cat ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Category: {activeCatName}</span>
                <button onClick={() => setParam("cat", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {featured === "1" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Featured</span>
                <button onClick={() => setParam("featured", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {inStock === "1" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>In stock</span>
                <button onClick={() => setParam("inStock", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {style ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Style: {style}</span>
                <button onClick={() => setParam("style", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {loss ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Loss: {loss}</span>
                <button onClick={() => setParam("loss", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {rechargeable === "1" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Rechargeable</span>
                <button onClick={() => setParam("rechargeable", "")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {min || max ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>
                  Price: {min || "0"} - {max || "∞"}
                </span>
                <button onClick={() => setManyParams({ min: "", max: "" })}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            {sort !== "newest" ? (
              <div className="inline-flex items-center gap-1 rounded-full bg-[#fff8ee] px-3 py-1.5 text-sm text-[#d88a26] ring-1 ring-[#efbf7e]">
                <span>Sort: {sort.replace("_", " ")}</span>
                <button onClick={() => setParam("sort", "newest")}>
                  <X className="ml-1 h-3.5 w-3.5" />
                </button>
              </div>
            ) : null}

            <Button
              variant="ghost"
              onClick={clearAll}
              className="text-sm text-[#d88a26] hover:text-[#b96f10]"
            >
              Clear all
            </Button>
          </div>
        ) : null}

        <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
          <div className="hidden lg:block">
            <aside className="sticky top-24 space-y-7 rounded-[2rem] bg-gradient-to-b from-[#fbf9f5] via-white to-[#f8f5f0] p-2 ring-1 ring-[#ece7de]">
              <div className="flex items-center justify-between px-4 pt-4 pb-2">
                <h2 className="flex items-center gap-2 text-xl font-bold text-slate-900">
                  <Filter className="h-5 w-5 text-[#d88a26]" /> Filters
                </h2>
                {activeFiltersCount > 0 ? (
                  <button
                    onClick={clearAll}
                    className="text-xs font-medium text-slate-500 transition-colors hover:text-[#d88a26]"
                  >
                    Clear all
                  </button>
                ) : null}
              </div>

              <div className="rounded-2xl bg-white/95 p-6 ring-1 ring-[#ece7de]">
                <h3 className="mb-4 flex items-center gap-2 font-semibold text-slate-900">
                  <Grid3x3 className="h-4 w-4 text-[#d88a26]" /> Categories
                </h3>
                {renderCategoryTree(false)}
              </div>

              <div className="rounded-2xl bg-white/95 p-6 ring-1 ring-[#ece7de]">
                <h3 className="mb-4 flex items-center gap-2 font-semibold text-slate-900">
                  <Package className="h-4 w-4 text-[#d88a26]" /> Price Range
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">
                        Min (৳)
                      </label>
                      <Input
                        value={min}
                        onChange={(e) => setMin(e.target.value)}
                        type="number"
                        placeholder="0"
                        className="rounded-xl border-[#ece7de] focus:border-[#d88a26] focus:ring-[#efbf7e]/30"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">
                        Max (৳)
                      </label>
                      <Input
                        value={max}
                        onChange={(e) => setMax(e.target.value)}
                        type="number"
                        placeholder="∞"
                        className="rounded-xl border-[#ece7de] focus:border-[#d88a26] focus:ring-[#efbf7e]/30"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={() => setManyParams({ min, max })}
                    className="w-full rounded-xl bg-[#d88a26] text-white hover:bg-[#b96f10]"
                  >
                    Apply Price
                  </Button>
                </div>
              </div>

              <div className="rounded-2xl bg-white/95 p-6 ring-1 ring-[#ece7de]">
                <h3 className="mb-4 flex items-center gap-2 font-semibold text-slate-900">
                  <Star className="h-4 w-4 text-[#d88a26]" /> More Filters
                </h3>
                <div className="space-y-2">
                  <select
                    value={style}
                    onChange={(e) => setParam("style", e.target.value)}
                    className="h-11 w-full rounded-xl border border-[#ece7de] bg-white px-4 text-sm outline-none"
                  >
                    <option value="">All styles</option>
                    {catalogOptions.deviceStyleOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>

                  <select
                    value={loss}
                    onChange={(e) => setParam("loss", e.target.value)}
                    className="h-11 w-full rounded-xl border border-[#ece7de] bg-white px-4 text-sm outline-none"
                  >
                    <option value="">All hearing-loss ranges</option>
                    {catalogOptions.hearingLossOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={() =>
                      setParam("rechargeable", rechargeable === "1" ? "" : "1")
                    }
                    className={`w-full rounded-xl border border-transparent px-4 py-2.5 text-left transition-all focus:border-[#efbf7e] focus:ring-2 focus:ring-[#fff1df] ${
                      rechargeable === "1"
                        ? "bg-[#d88a26] text-white"
                        : "bg-[#fff8ee] text-slate-700 hover:border-[#efbf7e] hover:bg-[#fff1df]"
                    }`}
                  >
                    Rechargeable Only
                  </button>

                  <button
                    onClick={() =>
                      setParam("featured", featured === "1" ? "" : "1")
                    }
                    className={`w-full rounded-xl border border-transparent px-4 py-2.5 text-left transition-all focus:border-[#efbf7e] focus:ring-2 focus:ring-[#fff1df] ${
                      featured === "1"
                        ? "bg-[#d88a26] text-white"
                        : "bg-[#fff8ee] text-slate-700 hover:border-[#efbf7e] hover:bg-[#fff1df]"
                    }`}
                  >
                    Featured Products
                  </button>

                  <button
                    onClick={() =>
                      setParam("inStock", inStock === "1" ? "" : "1")
                    }
                    className={`w-full rounded-xl border border-transparent px-4 py-2.5 text-left transition-all focus:border-[#efbf7e] focus:ring-2 focus:ring-[#fff1df] ${
                      inStock === "1"
                        ? "bg-[#d88a26] text-white"
                        : "bg-[#fff8ee] text-slate-700 hover:border-[#efbf7e] hover:bg-[#fff1df]"
                    }`}
                  >
                    In Stock Only
                  </button>
                </div>
              </div>

              <div className="rounded-2xl bg-white/95 p-6 ring-1 ring-[#ece7de]">
                <h3 className="mb-4 flex items-center gap-2 font-semibold text-slate-900">
                  <List className="h-4 w-4 text-[#d88a26]" /> Sort By
                </h3>
                <div className="space-y-2">
                  {[
                    { value: "newest", label: "Newest First" },
                    { value: "best_selling", label: "Best Selling" },
                    { value: "price_asc", label: "Price: Low to High" },
                    { value: "price_desc", label: "Price: High to Low" },
                  ].map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setParam("sort", option.value)}
                      className={`w-full rounded-xl border border-transparent px-4 py-2.5 text-left transition-all focus:border-[#efbf7e] focus:ring-2 focus:ring-[#fff1df] ${
                        sort === option.value
                          ? "bg-[#d88a26] text-white"
                          : "bg-[#fff8ee] text-slate-700 hover:border-[#efbf7e] hover:bg-[#fff1df]"
                      }`}
                    >
                      <span className="text-sm font-medium">
                        {option.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </aside>
          </div>

          <div className="space-y-6">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm text-gray-500">
                  Showing{" "}
                  <span className="font-medium text-gray-900">
                    {data?.items?.length || 0}
                  </span>{" "}
                  of{" "}
                  <span className="font-medium text-gray-900">
                    {data?.total || 0}
                  </span>{" "}
                  products
                </p>
              </div>

              <div className="hidden items-center gap-3 md:flex">
                <div className="flex items-center rounded-xl border border-gray-200 p-1">
                  <button
                    onClick={() => setViewMode("grid")}
                    className={`rounded-lg p-2 transition-all ${
                      viewMode === "grid"
                        ? "bg-[#d88a26] text-white"
                        : "text-gray-400 hover:text-[#d88a26]"
                    }`}
                  >
                    <Grid3x3 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setViewMode("list")}
                    className={`rounded-lg p-2 transition-all ${
                      viewMode === "list"
                        ? "bg-[#d88a26] text-white"
                        : "text-gray-400 hover:text-[#d88a26]"
                    }`}
                  >
                    <List className="h-4 w-4" />
                  </button>
                </div>

                <select
                  value={takeFromUrl}
                  onChange={(e) => setParam("take", e.target.value)}
                  className="rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm focus:border-gray-400 focus:outline-none"
                >
                  <option value="12">12 / page</option>
                  <option value="18">18 / page</option>
                  <option value="24">24 / page</option>
                  <option value="36">36 / page</option>
                  <option value="48">48 / page</option>
                </select>

                <select
                  value={sort}
                  onChange={(e) => setParam("sort", e.target.value)}
                  className="rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm focus:border-gray-400 focus:outline-none"
                >
                  <option value="newest">Newest</option>
                  <option value="best_selling">Best Selling</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                </select>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-square rounded-2xl bg-[#f1efeb]" />
                    <div className="mt-4 space-y-3">
                      <div className="h-4 w-3/4 rounded bg-[#ece7de]" />
                      <div className="h-4 w-1/2 rounded bg-[#ece7de]" />
                      <div className="h-4 w-1/4 rounded bg-[#ece7de]" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div
                className={
                  viewMode === "grid"
                    ? "grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4"
                    : "space-y-4"
                }
              >
                {(data?.items ?? []).map((product) =>
                  viewMode === "grid" ? (
                    <HomeProductCard key={product.id} product={product} />
                  ) : (
                    <ProductCard
                      key={product.id}
                      product={product}
                      viewMode={viewMode}
                    />
                  ),
                )}
              </div>
            )}

            {!loading && (!data?.items || data.items.length === 0) ? (
              <div className="rounded-2xl bg-white p-16 text-center ring-1 ring-[#ece7de]">
                <Package className="mx-auto mb-4 h-16 w-16 text-[#efbf7e]" />
                <h3 className="text-lg font-medium text-slate-900">
                  No products found
                </h3>
                <p className="mt-2 text-sm text-slate-500">
                  Try adjusting your filters or search term
                </p>
                <Button
                  onClick={clearAll}
                  className="mt-6 rounded-xl bg-[#d88a26] text-white hover:bg-[#b96f10]"
                >
                  Clear all filters
                </Button>
              </div>
            ) : null}

            {!loading && data?.pages && data.pages > 1 ? (
              <div className="flex flex-col items-center justify-between gap-4 pt-8 md:flex-row">
                <div className="text-sm text-slate-500">
                  Page {currentPage} of {pages}
                </div>

                <div className="flex items-center justify-center gap-2">
                  <Button
                    variant="secondary"
                    onClick={() => goPage(currentPage - 1)}
                    disabled={currentPage <= 1}
                    className="rounded-xl border-[#ece7de] bg-white text-[#334155]"
                  >
                    <ChevronLeft className="mr-1 h-4 w-4" />
                    Previous
                  </Button>

                  <div className="flex items-center gap-1">
                    {pageButtons.map((p, idx) =>
                      p === 0 ? (
                        <span
                          key={`gap-${idx}`}
                          className="px-3 py-2 text-slate-400"
                        >
                          …
                        </span>
                      ) : (
                        <button
                          key={p}
                          onClick={() => goPage(p)}
                          className={`min-w-10 rounded-xl px-4 py-2 text-sm font-medium transition-all ${
                            p === currentPage
                              ? "bg-[#d88a26] text-white"
                              : "bg-[#fff8ee] text-slate-700 hover:bg-[#fff1df]"
                          }`}
                        >
                          {p}
                        </button>
                      ),
                    )}
                  </div>

                  <Button
                    variant="secondary"
                    onClick={() => goPage(currentPage + 1)}
                    disabled={currentPage >= pages}
                    className="rounded-xl border-[#ece7de] bg-white text-[#334155]"
                  >
                    Next
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {mobileFiltersOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-[#334155]/28"
            onClick={() => setMobileFiltersOpen(false)}
          />
          <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-white ring-1 ring-[#ece7de]">
            <div className="flex h-full flex-col">
              <div className="flex items-center justify-between border-b border-[#ece7de] p-4">
                <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
                <button
                  onClick={() => setMobileFiltersOpen(false)}
                  className="rounded-lg p-2 hover:bg-[#fff8ee]"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="flex-1 space-y-6 overflow-y-auto p-4">
                <div>
                  <h3 className="mb-3 font-medium text-gray-900">Categories</h3>
                  {renderCategoryTree(true)}
                </div>

                <div>
                  <h3 className="mb-3 font-medium text-gray-900">
                    Price Range
                  </h3>
                  <div className="space-y-3">
                    <Input
                      value={min}
                      onChange={(e) => setMin(e.target.value)}
                      placeholder="Min price"
                      className="rounded-xl border-[#ece7de] bg-white"
                    />
                    <Input
                      value={max}
                      onChange={(e) => setMax(e.target.value)}
                      placeholder="Max price"
                      className="rounded-xl border-[#ece7de] bg-white"
                    />
                    <Button
                      onClick={() => {
                        setManyParams({ min, max });
                        setMobileFiltersOpen(false);
                      }}
                      className="w-full rounded-xl bg-[#d88a26] text-white hover:bg-[#b96f10]"
                    >
                      Apply
                    </Button>
                  </div>
                </div>

                <div>
                  <h3 className="mb-3 font-medium text-gray-900">
                    More Filters
                  </h3>
                  <div className="space-y-2">
                    <select
                      value={style}
                      onChange={(e) => setParam("style", e.target.value)}
                      className="w-full rounded-xl border border-[#ece7de] bg-white p-3"
                    >
                      <option value="">All styles</option>
                      {catalogOptions.deviceStyleOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>

                    <select
                      value={loss}
                      onChange={(e) => setParam("loss", e.target.value)}
                      className="w-full rounded-xl border border-[#ece7de] bg-white p-3"
                    >
                      <option value="">All hearing-loss ranges</option>
                      {catalogOptions.hearingLossOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>

                    <button
                      onClick={() =>
                        setParam("rechargeable", rechargeable === "1" ? "" : "1")
                      }
                      className={`w-full rounded-xl px-4 py-3 text-left ${
                        rechargeable === "1"
                          ? "bg-[#d88a26] text-white"
                          : "bg-[#fff8ee] text-slate-700"
                      }`}
                    >
                      Rechargeable Only
                    </button>

                    <button
                      onClick={() =>
                        setParam("featured", featured === "1" ? "" : "1")
                      }
                      className={`w-full rounded-xl px-4 py-3 text-left ${
                        featured === "1"
                          ? "bg-[#d88a26] text-white"
                          : "bg-[#fff8ee] text-slate-700"
                      }`}
                    >
                      Featured Products
                    </button>

                    <button
                      onClick={() =>
                        setParam("inStock", inStock === "1" ? "" : "1")
                      }
                      className={`w-full rounded-xl px-4 py-3 text-left ${
                        inStock === "1"
                          ? "bg-[#d88a26] text-white"
                          : "bg-[#fff8ee] text-slate-700"
                      }`}
                    >
                      In Stock Only
                    </button>
                  </div>
                </div>

                <div>
                  <h3 className="mb-3 font-medium text-gray-900">Sort By</h3>
                  <select
                    value={sort}
                    onChange={(e) => setParam("sort", e.target.value)}
                    className="w-full rounded-xl border border-[#ece7de] bg-white p-3"
                  >
                    <option value="newest">Newest</option>
                    <option value="best_selling">Best Selling</option>
                    <option value="price_asc">Price: Low to High</option>
                    <option value="price_desc">Price: High to Low</option>
                  </select>
                </div>

                <div>
                  <h3 className="mb-3 font-medium text-gray-900">
                    Show Per Page
                  </h3>
                  <select
                    value={takeFromUrl}
                    onChange={(e) => setParam("take", e.target.value)}
                    className="w-full rounded-xl border border-[#ece7de] bg-white p-3"
                  >
                    <option value="12">12 / page</option>
                    <option value="18">18 / page</option>
                    <option value="24">24 / page</option>
                    <option value="36">36 / page</option>
                    <option value="48">48 / page</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-[#ece7de] p-4">
                <Button
                  onClick={() => {
                    clearAll();
                    setMobileFiltersOpen(false);
                  }}
                  variant="secondary"
                  className="w-full rounded-xl border-[#ece7de] bg-white text-[#334155]"
                >
                  Clear all filters
                </Button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}

function ProductCard({
  product,
  viewMode,
}: {
  product: Product;
  viewMode: "grid" | "list";
}) {
  const img = product.images?.[0]?.url;
  const finalPrice = product.offerPrice ?? product.price;
  const discount =
    product.offerPrice && product.price > 0
      ? Math.round(((product.price - product.offerPrice) / product.price) * 100)
      : null;

  const categoryLabel = product.category?.parent
    ? `${product.category.parent.name} → ${product.category.name}`
    : product.category?.name || "Uncategorized";

  if (viewMode === "list") {
    return (
      <Link
        href={`/products/${product.slug}`}
        className="group relative flex gap-5 rounded-[24px] border border-[#ece7de] bg-white p-4 transition-all hover:-translate-y-0.5"
      >
        <div className="relative h-32 w-32 shrink-0 overflow-hidden rounded-2xl bg-[#f1efeb]">
          {img ? (
            <Image
              src={img}
              alt={product.name}
              fill
              className="object-contain p-2 transition-transform duration-300 group-hover:scale-[1.02]"
              sizes="128px"
            />
          ) : null}
        </div>

        <div className="min-w-0 flex-1">
          <div className="inline-flex rounded-full bg-[#fff8ee] px-2.5 py-1 text-[11px] font-medium text-[#d88a26]">
            {categoryLabel}
          </div>
          <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
            {product.deviceStyle ? (
              <span className="rounded-full bg-[#eef4ff] px-2.5 py-1 text-[#1f4fa1]">
                {product.deviceStyle}
              </span>
            ) : null}
            {product.hearingLossRange ? (
              <span className="rounded-full bg-[#fff7e8] px-2.5 py-1 text-[#8a5a15]">
                {product.hearingLossRange}
              </span>
            ) : null}
            {product.isRechargeable ? (
              <span className="rounded-full bg-[#eef9f1] px-2.5 py-1 text-[#196b39]">
                Rechargeable
              </span>
            ) : null}
          </div>
          <h3 className="mt-1 line-clamp-2 text-lg font-semibold text-slate-900">
            {product.name}
          </h3>

          <div className="mt-3 flex items-center gap-2">
            <span className="text-lg font-bold text-slate-900">
              ৳{finalPrice}
            </span>
            {product.offerPrice ? (
              <span className="text-sm text-slate-400 line-through">
                ৳{product.price}
              </span>
            ) : null}
            {discount ? (
              <span className="rounded-full bg-[#fff8ee] px-2.5 py-1 text-xs font-medium text-[#d88a26]">
                -{discount}%
              </span>
            ) : null}
          </div>

          <div
            className={`mt-3 inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
              product.stock > 0
                ? "bg-emerald-100 text-emerald-700"
                : "bg-rose-100 text-rose-600"
            }`}
          >
            {product.stock > 0 ? `In Stock (${product.stock})` : "Out of Stock"}
          </div>
        </div>

      </Link>
    );
  }

  return <HomeProductCard product={product} />;
}
