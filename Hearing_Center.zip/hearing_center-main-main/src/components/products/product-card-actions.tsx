"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, ShoppingCart } from "lucide-react";
import { useToast } from "@/components/ui/toast";

type ProductCardActionsProps = {
  productId: string;
  productName: string;
  productSlug: string;
  stock: number;
  compact?: boolean;
  hideDetails?: boolean;
  mode?: "default" | "outline-only";
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number }>;
  };
};

type ErrorResponse = { error?: string };

function isCartResponse(v: unknown): v is CartResponse {
  const o = v as Record<string, unknown>;
  const cart = o.cart as Record<string, unknown> | undefined;
  return !!cart && Array.isArray((cart as { items?: unknown }).items);
}

export default function ProductCardActions({
  productId,
  productName,
  productSlug,
  stock,
  compact = false,
  hideDetails = false,
  mode = "default",
}: ProductCardActionsProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const onAddToCart = async (
    event: React.MouseEvent<HTMLButtonElement>,
  ): Promise<void> => {
    event.preventDefault();
    event.stopPropagation();

    if (stock <= 0 || loading) return;

    setLoading(true);
    try {
      const res = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "add", productId, qty: 1 }),
      });

      const json: unknown = await res.json().catch(() => null);

      if (!res.ok) {
        const message =
          (json as ErrorResponse | null)?.error || "Failed to add to cart";
        throw new Error(message);
      }

      if (isCartResponse(json)) {
        window.dispatchEvent(new Event("rhc_cart_updated"));
      }

      toast({
        variant: "success",
        title: "Added to cart",
        description: `${productName} has been added to your cart.`,
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error ? error.message : "Failed to add to cart",
      });
    } finally {
      setLoading(false);
    }
  };

  const onViewDetails = (
    event: React.MouseEvent<HTMLButtonElement>,
  ): void => {
    event.preventDefault();
    event.stopPropagation();
    router.push(`/products/${productSlug}`);
  };

  return (
    <div
      className={`grid gap-2 ${
        compact || hideDetails ? "grid-cols-1" : "grid-cols-[1fr_auto]"
      }`}
    >
      <button
        type="button"
        onClick={(event) => void onAddToCart(event)}
        disabled={stock <= 0 || loading}
        className={
          mode === "outline-only"
            ? "inline-flex min-h-10 items-center justify-center gap-2 rounded-[14px] border border-[#efbf7e] bg-white px-4 py-2.5 text-sm font-semibold text-[#d88a26] transition hover:bg-[#fff8ee] disabled:cursor-not-allowed disabled:border-slate-200 disabled:text-slate-400 disabled:opacity-70"
            : "inline-flex min-h-10 items-center justify-center gap-2 rounded-2xl bg-[#b3122f] px-2 py-2 text-xs font-semibold text-white shadow-[0_14px_28px_-18px_rgba(179,18,47,0.65)] transition hover:bg-[#991127] disabled:cursor-not-allowed disabled:opacity-60"
        }
      >
        <ShoppingCart className="h-4 w-4" />
        {stock <= 0 ? "Out of Stock" : loading ? "Adding..." : "Add to Cart"}
      </button>

      {hideDetails ? null : (
        <button
          type="button"
          onClick={onViewDetails}
          className="inline-flex min-h-10 items-center justify-center gap-2 rounded-2xl border border-[#f3c7d7] bg-[#fff8fb] px-3.5 py-2.5 text-xs font-semibold text-[#b3124f] transition hover:bg-[#fff1f5]"
        >
          <Eye className="h-4 w-4" />
          {compact ? "Details" : "View Details"}
        </button>
      )}
    </div>
  );
}
