import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  ShoppingCart,
  Eye,
  Star,
  ArrowDownRight,
  Flame,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getBestSellingProductIds } from "@/lib/best-selling";

type ProductCard = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured: boolean;
  isBestSelling?: boolean;
  images: { url: string }[];
  category: {
    id: string;
    name: string;
    slug: string;
    parent: {
      id: string;
      name: string;
      slug: string;
    } | null;
  } | null;
};

type Props = {
  title?: string;
  excludeProductIds?: string[];
  categoryIds?: string[];
  fallbackToFeatured?: boolean;
  limit?: number;
};

export default async function RecommendedProducts({
  title = "Recommended Products",
  excludeProductIds = [],
  categoryIds = [],
  fallbackToFeatured = true,
  limit = 8,
}: Props) {
  const bestSellingIds = await getBestSellingProductIds();
  const uniqueExcludeIds = Array.from(
    new Set(excludeProductIds.filter(Boolean)),
  );
  const uniqueCategoryIds = Array.from(new Set(categoryIds.filter(Boolean)));

  let items: ProductCard[] = [];

  if (uniqueCategoryIds.length > 0) {
    items = await prisma.product.findMany({
      where: {
        isActive: true,
        id: { notIn: uniqueExcludeIds },
        categoryId: { in: uniqueCategoryIds },
      },
      orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
      take: limit,
      include: {
        images: {
          orderBy: { sortOrder: "asc" },
          take: 1,
          select: { url: true },
        },
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
            parent: {
              select: {
                id: true,
                name: true,
                slug: true,
              },
            },
          },
        },
      },
    });

    items = items.map((item) => ({
      ...item,
      isBestSelling: bestSellingIds.has(item.id),
    }));
  }

  if (items.length < limit && fallbackToFeatured) {
    const more = await prisma.product.findMany({
      where: {
        isActive: true,
        isFeatured: true,
        id: { notIn: [...uniqueExcludeIds, ...items.map((p) => p.id)] },
      },
      orderBy: [{ createdAt: "desc" }],
      take: limit - items.length,
      include: {
        images: {
          orderBy: { sortOrder: "asc" },
          take: 1,
          select: { url: true },
        },
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
            parent: {
              select: {
                id: true,
                name: true,
                slug: true,
              },
            },
          },
        },
      },
    });

    items = [
      ...items,
      ...more.map((item) => ({
        ...item,
        isBestSelling: bestSellingIds.has(item.id),
      })),
    ];
  }

  if (!items.length) return null;

  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between gap-4">
        <div className="min-w-0">
          <div className="text-xl font-semibold text-slate-900">{title}</div>
        </div>

        <Link
          href="/products"
          className="group shrink-0 flex items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] ring-1 ring-[#f8bbd0] transition-all hover:bg-[#ffe4ec] hover:text-[#8e1042]"
        >
          <span>View all</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {items.map((product) => {
          const image = product.images[0]?.url;
          const finalPrice = product.offerPrice ?? product.price;
          const badge = product.isFeatured && product.isBestSelling
            ? {
                label: "Recommended",
                className: "bg-[#ff4a3d] text-white",
              }
            : product.isFeatured
              ? {
                  label: "Featured",
                  className: "bg-[#cdd94b] text-[#4d5600]",
                }
              : product.isBestSelling
                ? {
                    label: "Best Selling",
                    className: "bg-[#ff4a3d] text-white",
                  }
                : null;
          const discount =
            product.offerPrice && product.price > product.offerPrice
              ? Math.round(
                  ((product.price - product.offerPrice) / product.price) * 100,
                )
              : null;

          return (
            <Link
              key={product.id}
              href={`/products/${product.slug}`}
              draggable={false}
              className="group relative block overflow-hidden rounded-sm bg-white shadow-sm ring-1 ring-black/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="pointer-events-none absolute inset-x-4 top-0 h-10 rounded-b-2xl bg-rose-200/30 blur-xl" />

              {badge ? (
                <div
                  className={`absolute right-2 top-2 z-20 inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[9px] font-semibold shadow-md ${badge.className}`}
                >
                  <Flame className="h-3 w-3" />
                  {badge.label}
                </div>
              ) : null}

              {discount ? (
                <div className="absolute left-2 top-2 z-20 rounded-full bg-rose-600 px-2 py-0.5 text-[9px] font-semibold text-white shadow-md">
                  -{discount}%
                </div>
              ) : null}

              <div className="absolute left-2 top-9 z-20 flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[9px] font-semibold text-slate-700 shadow backdrop-blur">
                <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                4.9
              </div>

              <div className="relative aspect-square overflow-hidden bg-rose-50">
                {image ? (
                  <Image
                    src={image}
                    alt={product.name}
                    fill
                    draggable={false}
                    className="pointer-events-none object-contain p-3 transition-transform duration-500 group-hover:scale-[1.02]"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <ShoppingCart className="h-8 w-8 text-rose-300" />
                  </div>
                )}

                <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <div className="rounded-full bg-white p-2 shadow-lg">
                    <Eye className="h-4 w-4 text-rose-600" />
                  </div>
                </div>
              </div>

              <div className="p-2">
                <div className="mx-auto text-center">
                  <span
                    className={`mx-auto inline-flex rounded-full px-1.5 py-0.5 text-[8px] font-semibold ${
                      product.stock > 0
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-rose-100 text-rose-600"
                    }`}
                  >
                    {product.stock > 0 ? "In Stock" : "Out"}
                  </span>

                  <h3 className="mt-1 line-clamp-2 text-xs font-semibold text-slate-800 transition-colors group-hover:text-rose-600">
                    {product.name}
                  </h3>

                  <div className="mt-1 flex items-center justify-center gap-1">
                    <span className="text-base font-bold text-slate-900">
                      ৳{finalPrice}
                    </span>

                    {product.offerPrice ? (
                      <span className="text-xs text-slate-400 line-through">
                        ৳{product.price}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="mt-1 flex justify-center">
                  <ArrowDownRight className="h-4 w-4 shrink-0 text-rose-500 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
