import Image from "next/image";
import Link from "next/link";
import { Flame, ShoppingCart } from "lucide-react";
import ProductCardActions from "@/components/products/product-card-actions";

export type ProductCardProduct = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  shortDescription?: string | null;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured?: boolean;
  category?: { name: string; parent?: { name: string } | null } | null;
  images?: { url: string }[];
  ratingAvg?: number;
  ratingCount?: number;
  isBestSelling?: boolean;
};

type HomeProductCardProps = {
  product: ProductCardProduct;
};

export default function HomeProductCard({
  product,
}: HomeProductCardProps) {
  const img = product.images?.[0]?.url;
  const finalPrice = product.offerPrice ?? product.price;
  const hasOffer =
    typeof product.offerPrice === "number" && product.offerPrice < product.price;
  const savedAmount = hasOffer ? product.price - finalPrice : 0;
  const badge = product.isFeatured && product.isBestSelling
    ? {
        label: "Recommended",
        className: "bg-[#ff4a3d] text-white",
      }
    : product.isFeatured
      ? {
          label: "Featured",
          className: "bg-[#cdd94b] text-[#4d5600]",
        }
      : product.isBestSelling
        ? {
            label: "Best Selling",
            className: "bg-[#ff4a3d] text-white",
          }
        : null;

  return (
    <div className="group relative flex h-full flex-col rounded-[18px] border border-[#ece7de] bg-white shadow-[0_18px_45px_-38px_rgba(15,23,42,0.28)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_60px_-42px_rgba(15,23,42,0.32)]">
      <Link href={`/products/${product.slug}`} className="flex flex-1 flex-col">
        <div className="relative overflow-hidden bg-[#f1efeb]">
          {badge ? (
            <div
              className={`absolute right-0 top-0 z-10 inline-flex items-center gap-1 rounded-bl-[14px] rounded-tr-[14px] px-3 py-2 text-[11px] font-semibold shadow-sm ${badge.className}`}
            >
              <Flame className="h-3.5 w-3.5" />
              <span>{badge.label}</span>
            </div>
          ) : null}

          <div className="relative aspect-[4/5]">
            {img ? (
              <div className="relative h-full overflow-hidden bg-[#f1efeb]">
                <Image
                  src={img}
                  alt={product.name}
                  fill
                  className="object-contain p-3 transition-transform duration-500 group-hover:scale-[1.02]"
                />
              </div>
            ) : (
              <div className="flex h-full items-center justify-center bg-[#f1efeb]">
                <ShoppingCart className="h-10 w-10 text-[#d1cbc1]" />
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-1 flex-col px-2 pb-1 pt-1">
          <h3 className="line-clamp-2  text-[18px] font-semibold leading-6 text-[#334155]">
            {product.name}
          </h3>

          <div className="flex items-end gap-2">
            <span className="text-[14px] font-bold leading-none text-[#e28a20]">
              Tk {finalPrice}
            </span>
            {hasOffer ? (
              <span className="text-[12px] text-[#9ca3af] line-through">
                Tk {product.price}
              </span>
            ) : null}
          </div>

          {hasOffer ? (
            <div className="mt-3 min-h-7">
              <span className="inline-flex rounded-[8px] bg-[#cdd94b] px-2 py-1 text-[10px] font-semibold text-[#4d5600]">
                Save Tk {savedAmount}
              </span>
            </div>
          ) : null}
        </div>
      </Link>

      <div className="px-1 pb-2 pt-2">
        <ProductCardActions
          productId={product.id}
          productName={product.name}
          productSlug={product.slug}
          stock={product.stock}
          compact
          hideDetails
          mode="outline-only"
        />
      </div>
    </div>
  );
}
