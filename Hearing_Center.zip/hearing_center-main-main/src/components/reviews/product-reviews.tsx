"use client";

import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "../ui/toast";

type SortKey = "latest" | "highest_rated";

type ReviewItem = {
  id: string;
  rating: number;
  comment: string | null;
  createdAt: string;
  helpfulCount: number;
  user: { name: string | null };
  verified: boolean;
};

type ReviewsApiResponse = {
  reviews: ReviewItem[];
  average: number;
};

type VoteApiResponse = { voted: boolean };
type ToggleWishlistErr = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeBool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

function parseReviewsResponse(input: unknown): ReviewsApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.reviews) ? o.reviews : [];
  const reviews: ReviewItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const userObj =
        (x.user as Record<string, unknown> | null | undefined) ?? null;
      return {
        id: safeString(x.id),
        rating: safeNumber(x.rating, 0),
        comment: typeof x.comment === "string" ? x.comment : null,
        createdAt: safeString(x.createdAt),
        helpfulCount: safeNumber(x.helpfulCount, 0),
        user: {
          name: userObj
            ? typeof userObj.name === "string"
              ? userObj.name
              : null
            : null,
        },
        verified: safeBool(x.verified, false),
      };
    })
    .filter((r) => r.id && r.rating >= 1 && r.rating <= 5);

  return {
    reviews,
    average: safeNumber(o.average, 0),
  };
}

function parseVoteResponse(input: unknown): VoteApiResponse | null {
  const o = input as Record<string, unknown>;
  if (typeof o.voted === "boolean") return { voted: o.voted };
  return null;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function Stars({ value }: { value: number }) {
  const v = Math.round(value * 10) / 10;
  const full = Math.floor(v);
  const half = v - full >= 0.5;

  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => {
        const idx = i + 1;
        const filled = idx <= full;
        const isHalf = !filled && half && idx === full + 1;

        return (
          <span
            key={idx}
            className={`text-base ${filled || isHalf ? "text-black" : "text-black/20"}`}
          >
            {filled ? "★" : isHalf ? "★" : "☆"}
          </span>
        );
      })}
      <span className="ml-2 text-sm text-black/60">{v.toFixed(1)}</span>
    </div>
  );
}

export default function ProductReviews({ productId }: { productId: string }) {
  const { status } = useSession();

  const [sort, setSort] = useState<SortKey>("latest");
  const [loading, setLoading] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const [data, setData] = useState<ReviewsApiResponse>({
    reviews: [],
    average: 0,
  });

  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>("");

  const { toast } = useToast();

  const fetchReviews = async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(
        `/api/reviews?productId=${encodeURIComponent(productId)}&sort=${sort}`,
        {
          cache: "no-store",
        },
      );
      const j: unknown = await r.json().catch(() => null);
      setData(parseReviewsResponse(j));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchReviews();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId, sort]);

  const breakdown = useMemo(() => {
    const counts = [0, 0, 0, 0, 0]; // 1..5
    data.reviews.forEach((r) => {
      if (r.rating >= 1 && r.rating <= 5) counts[r.rating - 1] += 1;
    });
    const total = data.reviews.length || 1;
    return counts.map((c) => ({
      count: c,
      pct: Math.round((c / total) * 100),
    }));
  }, [data.reviews]);

  const submitReview = async (): Promise<void> => {
    if (status !== "authenticated") {
      window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
      return;
    }
    if (rating < 1 || rating > 5)
      return toast({
        variant: "error",
        title: "Failed",
        description: "Rating must be 1-5",
      });
    if (!productId) return;

    setSubmitting(true);
    try {
      const r = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId,
          rating,
          comment: comment.trim() ? comment.trim() : null,
        }),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        const msg = (j as ToggleWishlistErr | null)?.error || "Failed";
        throw new Error(msg);
      }

      setComment("");
      setRating(5);
      await fetchReviews();
    } catch (e) {
      toast({
        variant: "error",
        title: "Failed",
        description: e instanceof Error ? e.message : "Failed"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const voteHelpful = async (reviewId: string): Promise<void> => {
    if (status !== "authenticated") {
      window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
      return;
    }

    // optimistic update
    setData((prev) => ({
      ...prev,
      reviews: prev.reviews.map((r) =>
        r.id === reviewId ? { ...r, helpfulCount: r.helpfulCount + 1 } : r,
      ),
    }));

    try {
      const r = await fetch("/api/reviews/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewId }),
      });
      const j: unknown = await r.json().catch(() => null);

      if (!r.ok)
        throw new Error(
          (j as ToggleWishlistErr | null)?.error || "Vote failed",
        );

      const parsed = parseVoteResponse(j);
      if (parsed && parsed.voted === false) {
        setData((prev) => ({
          ...prev,
          reviews: prev.reviews.map((x) =>
            x.id === reviewId
              ? { ...x, helpfulCount: Math.max(0, x.helpfulCount - 2) }
              : x,
          ),
        }));
      }
    } catch {
      setData((prev) => ({
        ...prev,
        reviews: prev.reviews.map((x) =>
          x.id === reviewId
            ? { ...x, helpfulCount: Math.max(0, x.helpfulCount - 1) }
            : x,
        ),
      }));
    }
  };

  return (
    <div className="mt-10 grid gap-4 md:w-2/3">
      <div className="px-5 flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-xl font-semibold">Reviews</div>
          <div className="text-sm text-black/60">
            {data.reviews.length} reviews
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-sm text-black/60">Sort:</div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="rounded-2xl border border-black/10 bg-white px-3 py-2 text-sm"
          >
            <option value="latest">Latest</option>
            <option value="highest_rated">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Summary */}
      <Card className="rounded-3xl p-4">
        <div className="grid gap-4 md:grid-cols-[240px_1fr]">
          <div>
            <div className="text-sm font-semibold">Average rating</div>
            <div className="mt-2 flex items-center gap-3">
              <div className="text-4xl font-semibold">
                {(Math.round(data.average * 10) / 10).toFixed(1)}
              </div>
              <Stars value={data.average} />
            </div>
            <div className="mt-2 text-xs text-black/60">
              Based on {data.reviews.length} reviews
            </div>
          </div>

          <div className="grid gap-2">
            {[5, 4, 3, 2, 1].map((star) => {
              const idx = star - 1;
              const row = breakdown[idx];
              return (
                <div key={star} className="flex items-center gap-3">
                  <div className="w-12 text-xs text-black/60">{star}★</div>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-black/10">
                    <div
                      className="h-full bg-black"
                      style={{ width: `${row.pct}%` }}
                    />
                  </div>
                  <div className="w-10 text-right text-xs text-black/60">
                    {row.count}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      {/* Write review */}
      <Card className="rounded-3xl p-4">
        <div className="text-sm font-semibold">Write a review</div>
        <div className=" mt-3 grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-xs font-semibold text-black/60">Rating</div>
            <div className="mt-2 flex gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  className={`rounded-2xl px-3 py-2 text-sm ${
                    rating === n
                      ? "bg-black text-white"
                      : "bg-black/5 hover:bg-black/10"
                  }`}
                >
                  {n}★
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold text-black/60">
              Comment (optional)
            </div>
            <Input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Share your experience…"
              className="mt-2"
            />
            <div className="mt-3">
              <Button onClick={() => void submitReview()} disabled={submitting}>
                {submitting
                  ? "Submitting…"
                  : status === "authenticated"
                    ? "Submit Review"
                    : "Login to Review"}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* List */}
      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm font-semibold">All reviews</div>
          <div className="text-xs text-black/60">
            {loading ? "Loading…" : ""}
          </div>
        </div>

        <div className="grid gap-3">
          {data.reviews.map((r) => (
            <div
              key={r.id}
              className="rounded-3xl border border-black/10 bg-white p-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-semibold">
                      {r.user.name ?? "Anonymous"}
                    </div>
                    {r.verified ? (
                      <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                        Verified Purchase
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-1 flex items-center gap-2 text-sm">
                    <div className="text-black">
                      {Array.from({ length: r.rating }).map((_, i) => (
                        <span key={i}>★</span>
                      ))}
                    </div>
                    <div className="text-black/40">
                      {formatDate(r.createdAt)}
                    </div>
                  </div>

                  {r.comment ? (
                    <div className="mt-2 text-sm text-black/80">
                      {r.comment}
                    </div>
                  ) : null}
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="secondary"
                    onClick={() => void voteHelpful(r.id)}
                  >
                    Helpful ({r.helpfulCount})
                  </Button>
                </div>
              </div>
            </div>
          ))}

          {data.reviews.length === 0 && !loading ? (
            <div className="rounded-3xl bg-black/5 p-6 text-sm text-black/60">
              No reviews yet. Be the first to review this product.
            </div>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
