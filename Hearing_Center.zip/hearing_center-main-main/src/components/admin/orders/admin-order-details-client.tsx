"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type OrderStatus =
  | "PENDING"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

type PaymentStatus = "UNPAID" | "PAID" | "FAILED" | "REFUNDED";

type PaymentMethod = "COD" | "ONLINE";

type OrderDetails = {
  id: string;
  createdAt: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  name: string;
  phone: string;
  email: string | null;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  couponCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  courierName: string | null;
  trackingId: string | null;
  items: Array<{
    id: string;
    productName: string;
    sku: string;
    unitPrice: number;
    qty: number;
    lineTotal: number;
  }>;
};

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export default function AdminOrderDetailsClient() {
  const params = useParams();
  const id = safeString(params?.id);

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<OrderDetails | null>(null);

  const [status, setStatus] = useState<OrderStatus>("PENDING");
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>("UNPAID");
  const [courierName, setCourierName] = useState<string>("");
  const [trackingId, setTrackingId] = useState<string>("");

  const { toast } = useToast();

  const load = async (): Promise<void> => {
    if (!id) return;

    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}`, { cache: "no-store" });
      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setData(null);
        return;
      }

      const o =
        j && typeof j === "object" ? (j as Record<string, unknown>) : {};

      const itemsRaw = Array.isArray(o.items) ? o.items : [];
      const items = itemsRaw
        .map((x) => x as Record<string, unknown>)
        .map((x) => ({
          id: safeString(x.id),
          productName: safeString(x.productName),
          sku: safeString(x.sku),
          unitPrice: safeNumber(x.unitPrice, 0),
          qty: safeNumber(x.qty, 0),
          lineTotal: safeNumber(x.lineTotal, 0),
        }))
        .filter((x) => x.id);

      const parsed: OrderDetails = {
        id: safeString(o.id),
        createdAt: safeString(o.createdAt),
        status: safeString(o.status) as OrderStatus,
        paymentStatus: safeString(o.paymentStatus) as PaymentStatus,
        paymentMethod: safeString(o.paymentMethod) as PaymentMethod,
        name: safeString(o.name),
        phone: safeString(o.phone),
        email: typeof o.email === "string" ? o.email : null,
        addressLine1: safeString(o.addressLine1),
        addressLine2:
          typeof o.addressLine2 === "string" ? o.addressLine2 : null,
        city: safeString(o.city),
        area: typeof o.area === "string" ? o.area : null,
        note: typeof o.note === "string" ? o.note : null,
        couponCode: typeof o.couponCode === "string" ? o.couponCode : null,
        subtotal: safeNumber(o.subtotal, 0),
        discount: safeNumber(o.discount, 0),
        shipping: safeNumber(o.shipping, 0),
        tax: safeNumber(o.tax, 0),
        total: safeNumber(o.total, 0),
        courierName: typeof o.courierName === "string" ? o.courierName : null,
        trackingId: typeof o.trackingId === "string" ? o.trackingId : null,
        items,
      };

      if (!parsed.id) {
        setData(null);
        return;
      }

      setData(parsed);
      setStatus(parsed.status);
      setPaymentStatus(parsed.paymentStatus);
      setCourierName(parsed.courierName ?? "");
      setTrackingId(parsed.trackingId ?? "");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const save = async (): Promise<void> => {
    if (!id) return;

    setLoading(true);
    try {
      await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          paymentStatus,
          courierName: courierName.trim() ? courierName.trim() : null,
          trackingId: trackingId.trim() ? trackingId.trim() : null,
        }),
      });

      await load();
    } finally {
      setLoading(false);
    }
  };

  const bookSteadfast = async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}/steadfast/book`, {
        method: "POST",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        toast({
          variant: "error",
          title: "Booking Failed",
          description:
            (j as { error?: string } | null)?.error ||
            "Steadfast booking failed",
        });
        return;
      }
      await load();
      toast({
        variant: "success",
        title: "Booked in Steadfast ✅",
      });
    } finally {
      setLoading(false);
    }
  };

  const syncSteadfastStatus = async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/orders/${id}/steadfast/status`, {
        method: "POST",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description:
            (j as { error?: string } | null)?.error || "Status sync failed",
        });
        return;
      }
      await load();
      toast({
        variant: "success",
        title: "Successful",
        description: "Steadfast status synced ✅",
      });
    } finally {
      setLoading(false);
    }
  };

  const canRefund =
    data?.paymentStatus === "PAID" && data?.paymentMethod !== "COD";

  if (!id) return null;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
        <div>
          <div className="text-2xl font-semibold">Order #{id}</div>
          <div className="text-sm text-black/60">
            {data?.createdAt ? new Date(data.createdAt).toLocaleString() : ""}
          </div>
        </div>

        <div className="flex gap-2">
          <Link
            href="/admin/orders"
            className="text-sm text-black/70 underline"
          >
            Back
          </Link>
          <Link
            href={`/admin/orders/${id}/invoice`}
            className="text-sm text-black/70 underline"
          >
            Invoice
          </Link>
        </div>
      </div>

      {!data ? (
        <Card className="rounded-3xl p-6">
          {loading ? "Loading…" : "Not found"}
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-[1fr_360px]">
          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Customer</div>

            <div className="mt-3 text-sm text-black/70">
              <div className="font-semibold">{data.name}</div>
              <div>{data.phone}</div>
              {data.email ? <div>{data.email}</div> : null}

              <div className="mt-2">
                {data.addressLine1}
                {data.addressLine2 ? `, ${data.addressLine2}` : ""}
                {`, ${data.city}`}
                {data.area ? `, ${data.area}` : ""}
              </div>

              {data.note ? (
                <div className="mt-2 text-xs text-black/60">
                  Note: {data.note}
                </div>
              ) : null}

              {data.couponCode ? (
                <div className="mt-2 text-xs text-black/60">
                  Coupon: {data.couponCode}
                </div>
              ) : null}
            </div>

            <div className="mt-5 border-t border-black/10 pt-4">
              <div className="text-sm font-semibold">Items</div>

              <div className="mt-2 space-y-2">
                {data.items.map((it) => (
                  <div
                    key={it.id}
                    className="flex items-center justify-between text-sm"
                  >
                    <div className="min-w-0">
                      <div className="line-clamp-1 font-semibold">
                        {it.productName}
                      </div>
                      <div className="text-xs text-black/60">
                        SKU: {it.sku} • ৳ {it.unitPrice} × {it.qty}
                      </div>
                    </div>

                    <div className="font-semibold">৳ {it.lineTotal}</div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Update</div>

            <div className="mt-3 space-y-3">
              <div>
                <div className="text-xs font-semibold text-black/60">
                  Status
                </div>
                <select
                  className="mt-1 h-10 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as OrderStatus)}
                >
                  <option value="PENDING">PENDING</option>
                  <option value="PROCESSING">PROCESSING</option>
                  <option value="SHIPPED">SHIPPED</option>
                  <option value="DELIVERED">DELIVERED</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>

              <div>
                <div className="text-xs font-semibold text-black/60">
                  Payment
                </div>
                <select
                  className="mt-1 h-10 w-full rounded-2xl border border-black/10 bg-white px-3 text-sm"
                  value={paymentStatus}
                  onChange={(e) =>
                    setPaymentStatus(e.target.value as PaymentStatus)
                  }
                >
                  <option value="UNPAID">UNPAID</option>
                  <option value="PAID">PAID</option>
                  <option value="FAILED">FAILED</option>
                  <option value="REFUNDED">REFUNDED</option>
                </select>
              </div>

              <div>
                <div className="text-xs font-semibold text-black/60">
                  Courier
                </div>
                <Input
                  value={courierName}
                  onChange={(e) => setCourierName(e.target.value)}
                  placeholder="Pathao / RedX / Steadfast"
                />
              </div>

              <div>
                <div className="text-xs font-semibold text-black/60">
                  Tracking ID
                </div>
                <Input
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  placeholder="Tracking ID"
                />
              </div>

              <div className="pt-1 flex flex-col gap-2">
                <Button
                  className="w-full"
                  onClick={() => void save()}
                  disabled={loading}
                >
                  {loading ? "Saving…" : "Save changes"}
                </Button>

                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => void bookSteadfast()}
                  disabled={loading}
                >
                  Book in Steadfast
                </Button>

                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => void syncSteadfastStatus()}
                  disabled={loading}
                >
                  Sync Steadfast Status
                </Button>
              </div>

              <Button
                variant="secondary"
                className="w-full"
                onClick={async () => {
                  if (!id) return;
                  setLoading(true);
                  try {
                    await fetch(`/api/admin/orders/${id}/refund`, {
                      method: "POST",
                    });
                    await load();
                  } finally {
                    setLoading(false);
                  }
                }}
                disabled={!canRefund || loading}
              >
                {data.paymentStatus === "REFUNDED"
                  ? "Already Refunded"
                  : "Mark as REFUNDED"}
              </Button>

              <div className="mt-2 grid gap-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-black/60">Subtotal</span>
                  <span>৳ {data.subtotal}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-black/60">Discount</span>
                  <span>৳ {data.discount}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-black/60">Shipping</span>
                  <span>৳ {data.shipping}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-black/60">Tax</span>
                  <span>৳ {data.tax}</span>
                </div>

                <div className="mt-1 flex justify-between border-t border-black/10 pt-3">
                  <span className="font-semibold">Total</span>
                  <span className="font-semibold">৳ {data.total}</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
