"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AdminPagination from "@/components/admin/admin-pagination";
import AdminPageSize from "@/components/admin/admin-page-size";

type OrderStatus =
  | "PENDING"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

type PaymentStatus = "UNPAID" | "PAID" | "FAILED" | "REFUNDED";

type AdminOrderListItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  itemsCount: number;
  couponCode: string | null;
  courierName: string | null;
  trackingId: string | null;
};

type ApiResponse = {
  items: AdminOrderListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parseResponse(input: unknown): ApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const items: AdminOrderListItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      createdAt: safeString(x.createdAt),
      name: safeString(x.name),
      phone: safeString(x.phone),
      total: safeNumber(x.total, 0),
      status: safeString(x.status) as OrderStatus,
      paymentStatus: safeString(x.paymentStatus) as PaymentStatus,
      itemsCount: safeNumber(x.itemsCount, 0),
      couponCode: typeof x.couponCode === "string" ? x.couponCode : null,
      courierName: typeof x.courierName === "string" ? x.courierName : null,
      trackingId: typeof x.trackingId === "string" ? x.trackingId : null,
    }))
    .filter((x) => x.id);

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 20)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

export default function AdminOrdersPage() {
  const router = useRouter();
  const sp = useSearchParams();

  const [loading, setLoading] = React.useState(false);
  const [data, setData] = React.useState<ApiResponse>({
    items: [],
    total: 0,
    page: 1,
    take: 20,
    pages: 1,
  });

  const [q, setQ] = React.useState(sp.get("q") || "");

  const take = Number(sp.get("take") || "20") || 20;
  const status = sp.get("status") || "";
  const payment = sp.get("payment") || "";

  const setParam = React.useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(sp.toString());

      if (value.trim()) params.set(key, value.trim());
      else params.delete(key);

      if (key !== "page") params.set("page", "1");

      router.push(`/admin/orders?${params.toString()}`);
    },
    [router, sp],
  );

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/orders?${sp.toString()}`, {
        cache: "no-store",
      });
      const json: unknown = await res.json().catch(() => null);
      setData(parseResponse(json));
    } finally {
      setLoading(false);
    }
  }, [sp]);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6 flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-semibold text-[#334155]">
            Admin Orders
          </div>
          <div className="text-sm text-[#64748b]">{data.total} orders</div>
        </div>
      </div>

      <Card className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-4 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)]">
        <div className="grid gap-3 md:grid-cols-5">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search: id / name / phone / tracking"
            className="border-[#ece7de] bg-white text-[#334155] placeholder:text-[#94a3b8] focus:border-[#efbf7e]"
          />

          <select
            className="h-10 rounded-2xl border border-[#ece7de] bg-white px-3 text-sm text-[#334155] outline-none transition focus:border-[#efbf7e]"
            value={status}
            onChange={(e) => setParam("status", e.target.value)}
          >
            <option value="">All status</option>
            <option value="PENDING">PENDING</option>
            <option value="PROCESSING">PROCESSING</option>
            <option value="SHIPPED">SHIPPED</option>
            <option value="DELIVERED">DELIVERED</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>

          <select
            className="h-10 rounded-2xl border border-[#ece7de] bg-white px-3 text-sm text-[#334155] outline-none transition focus:border-[#efbf7e]"
            value={payment}
            onChange={(e) => setParam("payment", e.target.value)}
          >
            <option value="">All payment</option>
            <option value="UNPAID">UNPAID</option>
            <option value="PAID">PAID</option>
            <option value="FAILED">FAILED</option>
            <option value="REFUNDED">REFUNDED</option>
          </select>

          <div className="flex gap-2">
            <Button
              variant="secondary"
              onClick={() => setParam("q", q)}
              disabled={loading}
              className="border-[#efbf7e] bg-[#fff4e8] text-[#d88a26] hover:bg-[#fff1df] hover:text-[#b96f10]"
            >
              Search
            </Button>

            <Button
              variant="secondary"
              onClick={() => {
                setQ("");
                router.push("/admin/orders");
              }}
              disabled={loading}
              className="border-[#ece7de] bg-[#f8f5f0] text-[#64748b] hover:bg-[#f1efeb] hover:text-[#334155]"
            >
              Clear
            </Button>
          </div>

          <div className="flex justify-start md:justify-end">
            <AdminPageSize
              value={take}
              onChange={(value) => setParam("take", String(value))}
            />
          </div>
        </div>
      </Card>

      <div className="mt-4 grid gap-3">
        {data.items.map((o) => (
          <Link key={o.id} href={`/admin/orders/${o.id}`}>
            <Card className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-4 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)] transition-all hover:-translate-y-0.5 hover:border-[#efbf7e] hover:bg-[#fffdfa] hover:shadow-[0_24px_55px_-36px_rgba(226,138,32,0.22)]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-semibold text-[#334155]">
                    #{o.id}
                  </div>
                  <div className="text-xs text-[#64748b]">
                    {new Date(o.createdAt).toLocaleString()} • {o.itemsCount}{" "}
                    items
                  </div>
                  <div className="text-xs text-[#64748b]">
                    {o.name} • {o.phone}
                  </div>
                  <div className="text-xs text-[#64748b]">
                    {o.couponCode ? `Coupon: ${o.couponCode}` : "No coupon"}
                    {" • "}
                    {o.courierName ? `Courier: ${o.courierName}` : "No courier"}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-semibold text-[#ff4a3d]">
                    ৳ {o.total}
                  </div>
                  <div className="text-xs text-[#64748b]">
                    {o.status} • {o.paymentStatus}
                  </div>
                  <div className="text-xs text-[#64748b]">
                    {o.trackingId ? `Tracking: ${o.trackingId}` : "No tracking"}
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}

        {!loading && data.items.length === 0 ? (
          <Card className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 text-sm text-[#64748b] shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)]">
            No orders found.
          </Card>
        ) : null}
      </div>

      <AdminPagination
        page={data.page}
        pages={data.pages}
        onPageChange={(nextPage) => setParam("page", String(nextPage))}
      />
    </div>
  );
}
