"use client";

export default function InvoicePrintButton() {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="rounded-xl border border-black/10 px-4 py-2 text-sm hover:bg-black/5"
    >
      Print
    </button>
  );
}