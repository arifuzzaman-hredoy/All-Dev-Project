"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Role = "ADMIN" | "STAFF" | "USER";

type UserItem = {
  id: string;
  name: string | null;
  email: string;
  role: Role;
  blocked: boolean;
  createdAt: string;
  ordersCount: number;
  cartCount: number;
};

type ApiResponse = {
  items: UserItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

type ErrorResponse = { error: string };

type UserCartItem = {
  qty: number;
  variantId: string | null;
  variantLabel: string | null;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
  };
};

type UserCartResponse = {
  items: UserCartItem[];
  totalQty: number;
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}
function parse(input: unknown): ApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];
  const items: UserItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      name: typeof x.name === "string" ? x.name : null,
      email: safeString(x.email),
      role: safeString(x.role) as Role,
      blocked: Boolean(x.blocked),
      createdAt: safeString(x.createdAt),
      ordersCount: safeNumber(x.ordersCount, 0),
      cartCount: safeNumber(x.cartCount, 0),
    }))
    .filter((x) => x.id && x.email);

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 20)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export default function AdminUsersClient() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");
  const [openCartUserId, setOpenCartUserId] = useState<string | null>(null);
  const [cartLoadingFor, setCartLoadingFor] = useState<string | null>(null);
  const [cartErr, setCartErr] = useState("");
  const [cartByUser, setCartByUser] = useState<Record<string, UserCartResponse>>(
    {},
  );

  const [q, setQ] = useState("");
  const [role, setRole] = useState<string>("");
  const [minCart, setMinCart] = useState("");
  const [maxCart, setMaxCart] = useState("");
  const [page, setPage] = useState(1);

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set("q", q.trim());
    if (role) p.set("role", role);
    if (minCart.trim()) p.set("minCart", minCart.trim());
    if (maxCart.trim()) p.set("maxCart", maxCart.trim());
    p.set("page", String(page));
    p.set("take", "20");
    return p.toString();
  }, [q, role, minCart, maxCart, page]);

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    setErr("");
    try {
      const r = await fetch(`/api/admin/users?${qs}`, { cache: "no-store" });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed");
        setData(null);
        return;
      }
      setData(parse(j));
    } finally {
      setLoading(false);
    }
  }, [qs]);

  useEffect(() => {
    void load();
  }, [load]);

  const pages = data?.pages ?? 1;
  const currentPage = clamp(data?.page ?? page, 1, pages);

  const patchUser = async (
    id: string,
    body: { blocked?: boolean; role?: Role },
  ): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(`/api/admin/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!r.ok) {
        const j: unknown = await r.json().catch(() => null);
        setErr((j as { error?: string } | null)?.error || "Update failed");
        return;
      }
      await load();
    } finally {
      setLoading(false);
    }
  };

  const toggleCart = async (userId: string): Promise<void> => {
    if (openCartUserId === userId) {
      setOpenCartUserId(null);
      return;
    }

    setOpenCartUserId(userId);
    setCartErr("");

    if (cartByUser[userId]) {
      return;
    }

    setCartLoadingFor(userId);

    try {
      const r = await fetch(`/api/admin/users/${userId}/cart`, {
        cache: "no-store",
      });
      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setCartErr((j as ErrorResponse | null)?.error || "Failed to load cart");
        return;
      }

      const payload = j as UserCartResponse;
      setCartByUser((current) => ({
        ...current,
        [userId]: {
          items: Array.isArray(payload.items) ? payload.items : [],
          totalQty: safeNumber(payload.totalQty, 0),
        },
      }));
    } finally {
      setCartLoadingFor(null);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
        <div>
          <div className="text-2xl font-semibold">User Management</div>
          <div className="text-sm text-black/60">{data?.total ?? 0} users</div>
        </div>

        <div className="flex gap-2">
          <Link href="/admin/dashboard">
            <Button variant="secondary">Dashboard</Button>
          </Link>
          <Button
            variant="secondary"
            onClick={() => void load()}
            disabled={loading}
          >
            {loading ? "Loading…" : "Refresh"}
          </Button>
        </div>
      </div>

      {err ? (
        <Card className="rounded-3xl p-5 text-sm text-red-600">{err}</Card>
      ) : null}

      <Card className="rounded-3xl p-4">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          <Input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Search name/email"
          />
          <select
            className="h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
            value={role}
            onChange={(e) => {
              setRole(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All roles</option>
            <option value="USER">USER</option>
            <option value="STAFF">STAFF</option>
            <option value="ADMIN">ADMIN</option>
          </select>

          <Input
            type="number"
            min="0"
            value={minCart}
            onChange={(e) => {
              setMinCart(e.target.value);
              setPage(1);
            }}
            placeholder="Min cart items"
          />

          <Input
            type="number"
            min="0"
            value={maxCart}
            onChange={(e) => {
              setMaxCart(e.target.value);
              setPage(1);
            }}
            placeholder="Max cart items"
          />

          <div className="flex items-center text-sm text-black/60">
            Tip: Only ADMIN can edit users.
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-black/55">
          <span className="rounded-full bg-[#f5efe6] px-3 py-1">
            Example: `1` to `10`
          </span>
          <span className="rounded-full bg-[#f5efe6] px-3 py-1">
            Example: `1` to `9`
          </span>
          <span className="rounded-full bg-[#f5efe6] px-3 py-1">
            Leave max empty for open-ended results
          </span>
        </div>
      </Card>

      <div className="mt-4 grid gap-3">
        {(data?.items ?? []).map((u) => (
          <Card key={u.id} className="rounded-3xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-semibold">
                  {u.name ?? "—"}{" "}
                  {u.blocked ? (
                    <span className="ml-2 rounded-full bg-red-50 px-2 py-1 text-xs font-semibold text-red-700">
                      BLOCKED
                    </span>
                  ) : (
                    <span className="ml-2 rounded-full bg-green-50 px-2 py-1 text-xs font-semibold text-green-700">
                      ACTIVE
                    </span>
                  )}
                </div>
                <div className="text-xs text-black/60">{u.email}</div>
                <div className="text-xs text-black/60">
                  Role: <span className="font-semibold">{u.role}</span> •
                  Orders: {u.ordersCount} • Cart items: {u.cartCount}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  variant="secondary"
                  onClick={() => void toggleCart(u.id)}
                  disabled={loading || cartLoadingFor === u.id}
                >
                  {cartLoadingFor === u.id
                    ? "Loading cart..."
                    : openCartUserId === u.id
                      ? "Hide cart"
                      : "View cart"}
                </Button>

                <select
                  className="h-10 rounded-2xl border border-black/10 bg-white px-3 text-sm"
                  value={u.role}
                  onChange={(e) =>
                    void patchUser(u.id, { role: e.target.value as Role })
                  }
                  disabled={loading}
                >
                  <option value="USER">USER</option>
                  <option value="STAFF">STAFF</option>
                  <option value="ADMIN">ADMIN</option>
                </select>

                <Button
                  variant="secondary"
                  onClick={() => void patchUser(u.id, { blocked: !u.blocked })}
                  disabled={loading}
                >
                  {u.blocked ? "Unblock" : "Block"}
                </Button>
              </div>
            </div>

            {openCartUserId === u.id ? (
              <div className="mt-4 rounded-2xl border border-black/10 bg-[#faf8f5] p-4">
                <div className="mb-3 text-sm font-semibold text-black/70">
                  User cart
                </div>

                {cartErr ? (
                  <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
                    {cartErr}
                  </div>
                ) : null}

                {(cartByUser[u.id]?.items ?? []).length ? (
                  <div className="grid gap-3">
                    {(cartByUser[u.id]?.items ?? []).map((item) => (
                      <div
                        key={`${item.product.id}-${item.variantId ?? "base"}`}
                        className="flex flex-wrap items-center gap-3 rounded-2xl border border-black/8 bg-white p-3"
                      >
                        <div className="relative h-16 w-16 overflow-hidden rounded-xl bg-[#f3efe8]">
                          {item.product.images[0]?.url ? (
                            <Image
                              src={item.product.images[0].url}
                              alt={item.product.name}
                              fill
                              sizes="64px"
                              className="object-cover"
                            />
                          ) : null}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-semibold text-black">
                            {item.product.name}
                          </div>
                          <div className="text-xs text-black/60">
                            Qty: {item.qty}
                            {item.variantLabel ? ` • ${item.variantLabel}` : ""}
                            {" • "}Stock: {item.product.stock}
                          </div>
                          <div className="text-xs text-black/60">
                            Price: Tk{" "}
                            {(item.product.offerPrice ?? item.product.price).toLocaleString()}
                          </div>
                        </div>

                        <Link
                          href={`/products/${item.product.slug}`}
                          className="text-xs font-semibold text-[#d88a26] hover:underline"
                        >
                          Open product
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : cartLoadingFor === u.id ? null : (
                  <div className="text-sm text-black/60">
                    This user has no saved cart items right now.
                  </div>
                )}
              </div>
            ) : null}
          </Card>
        ))}

        {!loading && (data?.items?.length ?? 0) === 0 ? (
          <Card className="rounded-3xl p-6 text-sm text-black/60">
            No users found.
          </Card>
        ) : null}
      </div>

      <div className="mt-5 flex items-center justify-between">
        <Button
          variant="secondary"
          disabled={currentPage <= 1 || loading}
          onClick={() => setPage((p) => Math.max(1, p - 1))}
        >
          Prev
        </Button>
        <div className="text-sm text-black/60">
          Page {currentPage} of {pages}
        </div>
        <Button
          variant="secondary"
          disabled={currentPage >= pages || loading}
          onClick={() => setPage((p) => p + 1)}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
