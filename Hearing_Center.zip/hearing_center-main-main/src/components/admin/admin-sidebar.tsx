"use client";

import * as Dialog from "@radix-ui/react-dialog";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  BarChart3,
  Menu,
  LayoutDashboard,
  Megaphone,
  Package2,
  PanelLeft,
  Settings2,
  ShoppingBag,
  X,
  Ticket,
  Users,
  MessagesSquare,
  Ear,
} from "lucide-react";
import { cn } from "@/lib/cn";

const navItems = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/categories", label: "Categories", icon: PanelLeft },
  { href: "/admin/products", label: "Products", icon: Package2 },
  { href: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { href: "/admin/consultations", label: "Consultations", icon: MessagesSquare },
  { href: "/admin/hearing-catalog", label: "Hearing Catalog", icon: Ear },
  { href: "/admin/reports", label: "Reports", icon: BarChart3 },
  { href: "/admin/users", label: "Users", icon: Users },
  { href: "/admin/settings", label: "Settings", icon: Settings2 },
  { href: "/admin/banners", label: "Banners", icon: Megaphone },
  { href: "/admin/coupons", label: "Coupons", icon: Ticket },
];

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <nav className="mt-4 flex flex-col gap-1.5">
      {navItems.map((item) => {
        const active =
          pathname === item.href || pathname.startsWith(item.href + "/");
        const Icon = item.icon;

        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "group flex items-center gap-3 rounded-2xl border px-3 py-2.5 text-sm font-medium transition-all duration-150",
              active
                ? "border-[#efbf7e] bg-[#ff4a3d] text-white shadow-[0_14px_30px_-18px_rgba(255,74,61,0.75)]"
                : "border-transparent bg-transparent text-[#475569] hover:border-[#efe2cf] hover:bg-[#fff4e8] hover:text-[#d88a26]",
            )}
          >
            <span
              className={cn(
                "grid h-9 w-9 place-items-center rounded-xl transition-all duration-150",
                active
                  ? "bg-white/15 text-white"
                  : "bg-[#fff4e8] text-[#d88a26] group-hover:bg-white group-hover:text-[#b96f10]",
              )}
            >
              <Icon className="h-4 w-4" />
            </span>
            <span className="flex-1">{item.label}</span>
            {active ? (
              <span
                className="h-2 w-2 rounded-full bg-white"
                aria-hidden="true"
              />
            ) : null}
          </Link>
        );
      })}
    </nav>
  );
}

export default function AdminSidebar() {
  return (
    <div className="h-full rounded-[28px] border border-[#ece7de] bg-[linear-gradient(180deg,rgba(255,255,255,0.96)_0%,rgba(248,245,240,0.98)_100%)] p-4 shadow-[0_24px_80px_-48px_rgba(226,138,32,0.35)] backdrop-blur-xl">
      <div className="flex items-center gap-3 border-b border-[#ece7de] pb-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#ff4a3d] text-white shadow-[0_14px_30px_-18px_rgba(255,74,61,0.75)]">
          <PanelLeft className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-semibold text-[#334155]">Admin panel</p>
          <p className="text-xs text-[#64748b]">Manage catalog and orders</p>
        </div>
      </div>
      <SidebarNav />
    </div>
  );
}

export function AdminSidebarMobileToggle() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <Dialog.Root key={pathname} open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button
          type="button"
          className="inline-flex h-11 items-center gap-2 rounded-2xl border border-[#ece7de] bg-white/90 px-4 text-sm font-medium text-[#334155] shadow-[0_16px_40px_-24px_rgba(226,138,32,0.28)] backdrop-blur transition-colors hover:bg-[#fff4e8] hover:text-[#d88a26] lg:hidden"
          aria-label="Open admin sidebar"
        >
          <Menu className="h-4 w-4" />
          Menu
        </button>
      </Dialog.Trigger>

      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-[2px]" />
        <Dialog.Content className="fixed bottom-4 left-0 top-16 z-50 w-[min(20rem,85vw)] border-r border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#f8f5f0_100%)] p-4 shadow-[24px_0_80px_-40px_rgba(15,23,42,0.5)] outline-none">
          <div className="flex items-center justify-between border-b border-[#ece7de] pb-3">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-2xl bg-[#ff4a3d] text-white shadow-[0_14px_30px_-18px_rgba(255,74,61,0.75)]">
                <PanelLeft className="h-4 w-4" />
              </div>
              <div>
                <Dialog.Title className="text-sm font-semibold text-[#334155]">
                  Admin menu
                </Dialog.Title>
                <Dialog.Description className="text-xs text-[#64748b]">
                  Navigate admin sections
                </Dialog.Description>
              </div>
            </div>

            <Dialog.Close asChild>
              <button
                type="button"
                className="grid h-10 w-10 place-items-center rounded-2xl border border-[#ece7de] text-[#64748b] transition-colors hover:bg-[#fff4e8] hover:text-[#d88a26]"
                aria-label="Close admin sidebar"
              >
                <X className="h-4 w-4" />
              </button>
            </Dialog.Close>
          </div>

          <div className="mt-4 max-h-[calc(100dvh-12rem)] overflow-y-auto pb-4 pr-1">
            <SidebarNav onNavigate={() => setOpen(false)} />
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
