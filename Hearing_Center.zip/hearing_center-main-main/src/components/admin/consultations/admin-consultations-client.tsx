"use client";

import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AdminPagination from "@/components/admin/admin-pagination";
import AdminPageSize from "@/components/admin/admin-page-size";

const CONSULTATION_STATUSES = [
  "PENDING",
  "CONTACTED",
  "CONFIRMED",
  "FOLLOW_UP",
  "NO_ANSWER",
  "CLOSED",
  "CANCELLED",
] as const;

type ConsultationStatus = (typeof CONSULTATION_STATUSES)[number];

type ConsultationItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  email: string | null;
  status: ConsultationStatus;
  adminNote: string | null;
  followUpDate: string | null;
  contactedAt: string | null;
  closedAt: string | null;
  hearingAidUsage: string | null;
  hearingTestDone: string | null;
  tinnitus: string | null;
  crowdDifficulty: string | null;
  dailyLifeImpact: string | null;
  age: string | null;
  district: string | null;
  budget: string | null;
};

type ApiResponse = {
  items: ConsultationItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function toNullableString(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v : null;
}

function parseResponse(input: unknown): ApiResponse {
  const o =
    input && typeof input === "object"
      ? (input as Record<string, unknown>)
      : {};
  const raw = Array.isArray(o.items) ? o.items : [];

  const items: ConsultationItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      createdAt: safeString(x.createdAt),
      name: safeString(x.name),
      phone: safeString(x.phone),
      email: toNullableString(x.email),
      status: safeString(x.status, "PENDING") as ConsultationStatus,
      adminNote: toNullableString(x.adminNote),
      followUpDate: toNullableString(x.followUpDate),
      contactedAt: toNullableString(x.contactedAt),
      closedAt: toNullableString(x.closedAt),
      hearingAidUsage: toNullableString(x.hearingAidUsage),
      hearingTestDone: toNullableString(x.hearingTestDone),
      tinnitus: toNullableString(x.tinnitus),
      crowdDifficulty: toNullableString(x.crowdDifficulty),
      dailyLifeImpact: toNullableString(x.dailyLifeImpact),
      age: toNullableString(x.age),
      district: toNullableString(x.district),
      budget: toNullableString(x.budget),
    }))
    .filter((x) => x.id);

  return {
    items,
    total: safeNumber(o.total, items.length),
    page: Math.max(1, safeNumber(o.page, 1)),
    take: Math.max(1, safeNumber(o.take, 20)),
    pages: Math.max(1, safeNumber(o.pages, 1)),
  };
}

function renderValue(label: string, value: string | null) {
  return `${label}: ${value || "—"}`;
}

function getStatusClass(status: ConsultationStatus) {
  switch (status) {
    case "CONFIRMED":
      return "bg-[#eef7e8] text-[#4d5600]";
    case "CONTACTED":
      return "bg-[#eef6ff] text-[#245b8f]";
    case "FOLLOW_UP":
      return "bg-[#fff4e8] text-[#d88a26]";
    case "NO_ANSWER":
      return "bg-[#fff0e6] text-[#c97316]";
    case "CLOSED":
      return "bg-[#f1efeb] text-[#64748b]";
    case "CANCELLED":
      return "bg-[#ffe8e6] text-[#c73a2c]";
    default:
      return "bg-[#fff7e8] text-[#8b5a15]";
  }
}

export default function AdminConsultationsClient() {
  const router = useRouter();
  const sp = useSearchParams();

  const [loading, setLoading] = React.useState(false);
  const [data, setData] = React.useState<ApiResponse>({
    items: [],
    total: 0,
    page: 1,
    take: 20,
    pages: 1,
  });

  const [q, setQ] = React.useState(sp.get("q") || "");
  const [savingId, setSavingId] = React.useState<string | null>(null);
  const [drafts, setDrafts] = React.useState<
    Record<string, { status: ConsultationStatus; adminNote: string; followUpDate: string }>
  >({});

  const take = Number(sp.get("take") || "20") || 20;
  const status = sp.get("status") || "";

  const setParam = React.useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(sp.toString());

      if (value.trim()) params.set(key, value.trim());
      else params.delete(key);

      if (key !== "page") params.set("page", "1");

      router.push(`/admin/consultations?${params.toString()}`);
    },
    [router, sp],
  );

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/consultations?${sp.toString()}`, {
        cache: "no-store",
      });
      const json: unknown = await res.json().catch(() => null);
      const parsed = res.ok ? parseResponse(json) : parseResponse(null);
      setData(parsed);
      setDrafts((current) => {
        const next = { ...current };
        for (const item of parsed.items) {
          next[item.id] ??= {
            status: item.status,
            adminNote: item.adminNote || "",
            followUpDate: item.followUpDate
              ? item.followUpDate.slice(0, 10)
              : "",
          };
        }
        return next;
      });
    } finally {
      setLoading(false);
    }
  }, [sp]);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const updateDraft = (
    id: string,
    field: "status" | "adminNote" | "followUpDate",
    value: string,
  ) => {
    setDrafts((current) => ({
      ...current,
      [id]: {
        status: current[id]?.status ?? "PENDING",
        adminNote: current[id]?.adminNote ?? "",
        followUpDate: current[id]?.followUpDate ?? "",
        [field]: value,
      },
    }));
  };

  const saveConsultation = async (id: string) => {
    const draft = drafts[id];
    if (!draft) return;

    setSavingId(id);
    try {
      await fetch(`/api/admin/consultations/${encodeURIComponent(id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: draft.status,
          adminNote: draft.adminNote,
          followUpDate: draft.followUpDate || null,
        }),
      });
      await fetchData();
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6 flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-semibold text-[#334155]">
            Consultations
          </div>
          <div className="text-sm text-[#64748b]">{data.total} requests</div>
        </div>
      </div>

      <Card className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-4 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)]">
        <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_220px_auto_auto]">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search: name / phone / email / district"
            className="border-[#ece7de] bg-white text-[#334155] placeholder:text-[#94a3b8] focus:border-[#efbf7e]"
          />

          <select
            className="h-10 rounded-2xl border border-[#ece7de] bg-white px-3 text-sm text-[#334155] outline-none transition focus:border-[#efbf7e]"
            value={status}
            onChange={(e) => setParam("status", e.target.value)}
          >
            <option value="">All status</option>
            {CONSULTATION_STATUSES.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>

          <div className="flex gap-2">
            <Button
              variant="secondary"
              onClick={() => setParam("q", q)}
              disabled={loading}
              className="border-[#efbf7e] bg-[#fff4e8] text-[#d88a26] hover:bg-[#fff1df] hover:text-[#b96f10]"
            >
              Search
            </Button>

            <Button
              variant="secondary"
              onClick={() => {
                setQ("");
                router.push("/admin/consultations");
              }}
              disabled={loading}
              className="border-[#ece7de] bg-[#f8f5f0] text-[#64748b] hover:bg-[#f1efeb] hover:text-[#334155]"
            >
              Clear
            </Button>
          </div>

          <div className="flex justify-start md:justify-end">
            <AdminPageSize
              value={take}
              onChange={(value) => setParam("take", String(value))}
            />
          </div>
        </div>
      </Card>

      <div className="mt-4 grid gap-3">
        {data.items.map((item) => (
          <Card
            key={item.id}
            className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-4 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)] transition-all hover:-translate-y-0.5 hover:border-[#efbf7e] hover:shadow-[0_24px_55px_-36px_rgba(226,138,32,0.22)]"
          >
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div className="space-y-1 text-sm text-[#64748b]">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="text-base font-semibold text-[#334155]">
                    {item.name}
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-semibold ${getStatusClass(item.status)}`}
                  >
                    {item.status}
                  </span>
                </div>
                <div>
                  {item.phone}
                  {item.email ? ` • ${item.email}` : ""}
                </div>
                <div>{new Date(item.createdAt).toLocaleString()}</div>
                <div>{renderValue("বয়স", item.age)}</div>
                <div>{renderValue("জেলা", item.district)}</div>
                <div>{renderValue("বাজেট", item.budget)}</div>
                <div>
                  {renderValue(
                    "Follow up",
                    item.followUpDate
                      ? new Date(item.followUpDate).toLocaleDateString()
                      : null,
                  )}
                </div>
                <div>
                  {renderValue(
                    "Contacted at",
                    item.contactedAt
                      ? new Date(item.contactedAt).toLocaleString()
                      : null,
                  )}
                </div>
              </div>

              <div className="grid gap-1 text-sm text-[#64748b] lg:min-w-[420px]">
                <div>{renderValue("শ্রবণযন্ত্র ব্যবহার", item.hearingAidUsage)}</div>
                <div>{renderValue("হিয়ারিং টেস্ট", item.hearingTestDone)}</div>
                <div>{renderValue("টিনিটাস", item.tinnitus)}</div>
                <div>{renderValue("ভিড়ে শুনতে সমস্যা", item.crowdDifficulty)}</div>
                <div>{renderValue("দৈনন্দিন জীবনে প্রভাব", item.dailyLifeImpact)}</div>
              </div>
            </div>

            <div className="mt-4 grid gap-3 border-t border-[#ece7de] pt-4 md:grid-cols-[180px_180px_minmax(0,1fr)_auto]">
              <select
                className="h-10 rounded-2xl border border-[#ece7de] bg-white px-3 text-sm text-[#334155] outline-none transition focus:border-[#efbf7e]"
                value={drafts[item.id]?.status ?? item.status}
                onChange={(e) =>
                  updateDraft(
                    item.id,
                    "status",
                    e.target.value as ConsultationStatus,
                  )
                }
              >
                {CONSULTATION_STATUSES.map((statusItem) => (
                  <option key={statusItem} value={statusItem}>
                    {statusItem}
                  </option>
                ))}
              </select>

              <Input
                type="date"
                value={drafts[item.id]?.followUpDate ?? ""}
                onChange={(e) =>
                  updateDraft(item.id, "followUpDate", e.target.value)
                }
                className="border-[#ece7de] bg-white text-[#334155] focus:border-[#efbf7e]"
              />

              <textarea
                value={drafts[item.id]?.adminNote ?? item.adminNote ?? ""}
                onChange={(e) =>
                  updateDraft(item.id, "adminNote", e.target.value)
                }
                rows={2}
                placeholder="Add admin note"
                className="w-full rounded-2xl border border-[#ece7de] bg-white px-4 py-3 text-sm text-[#334155] outline-none transition placeholder:text-[#94a3b8] focus:border-[#efbf7e] focus:ring-2 focus:ring-[#f7d9ad]"
              />

              <Button
                variant="secondary"
                onClick={() => void saveConsultation(item.id)}
                disabled={savingId === item.id}
                className="border-[#efbf7e] bg-[#fff4e8] text-[#d88a26] hover:bg-[#fff1df] hover:text-[#b96f10]"
              >
                {savingId === item.id ? "Saving..." : "Update"}
              </Button>
            </div>
          </Card>
        ))}

        {!loading && data.items.length === 0 ? (
          <Card className="rounded-3xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 text-sm text-[#64748b] shadow-[0_18px_45px_-32px_rgba(15,23,42,0.12)]">
            No consultation requests found.
          </Card>
        ) : null}
      </div>

      <AdminPagination
        page={data.page}
        pages={data.pages}
        onPageChange={(nextPage) => setParam("page", String(nextPage))}
      />
    </div>
  );
}
