"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Area,
  ComposedChart,
  Legend,
} from "recharts";
import {
  TrendingUp,
  Download,
  Package,
  DollarSign,
  ShoppingBag,
  ArrowUpRight,
  BarChart3,
  LineChart as LineChartIcon,
  DownloadCloud,
  Eye,
  EyeOff,
  Clock,
  Star,
  Zap,
  Award,
  type LucideIcon,
} from "lucide-react";

type MonthPoint = { month: string; revenue: number; orders: number };
type BestSellingItem = {
  productId: string;
  name: string;
  slug: string;
  qty: number;
  revenue: number;
};
type DayPoint = { day: string; revenue: number; orders: number };

type ApiResponse = {
  ok: true;
  last30Days: { orders: number; revenue: number; productSales: number };
  thisMonth: { orders: number; revenue: number };
  monthly: MonthPoint[];
  bestSelling30: BestSellingItem[];
};

type ErrorResponse = { error: string };
type TooltipPayloadItem = {
  color?: string;
  name?: string;
  value?: number | string;
};

type CustomTooltipProps = {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
};

type StatCardProps = {
  title: string;
  value: string;
  icon: LucideIcon;
  subtitle?: string;
  color?: "blue" | "green" | "purple";
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parse(input: unknown): ApiResponse | null {
  const o = input as Record<string, unknown>;
  if (o.ok !== true) return null;

  const monthlyRaw = Array.isArray(o.monthly) ? o.monthly : [];
  const monthly: MonthPoint[] = monthlyRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      month: safeString(x.month),
      revenue: safeNumber(x.revenue, 0),
      orders: safeNumber(x.orders, 0),
    }))
    .filter((x) => x.month);

  const bestRaw = Array.isArray(o.bestSelling30) ? o.bestSelling30 : [];
  const bestSelling30: BestSellingItem[] = bestRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      name: safeString(x.name),
      slug: safeString(x.slug),
      qty: safeNumber(x.qty, 0),
      revenue: safeNumber(x.revenue, 0),
    }))
    .filter((x) => x.slug);

  const last30 = (o.last30Days as Record<string, unknown>) ?? {};
  const thisM = (o.thisMonth as Record<string, unknown>) ?? {};

  return {
    ok: true,
    last30Days: {
      orders: safeNumber(last30.orders, 0),
      revenue: safeNumber(last30.revenue, 0),
      productSales: safeNumber(last30.productSales, 0),
    },
    thisMonth: {
      orders: safeNumber(thisM.orders, 0),
      revenue: safeNumber(thisM.revenue, 0),
    },
    monthly,
    bestSelling30,
  };
}

// Custom tooltip component
const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-2xl border border-[#ece7de] bg-[rgba(255,253,250,0.96)] p-4 shadow-xl backdrop-blur-md">
        <p className="mb-2 text-sm font-semibold text-[#334155]">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-[#64748b]">{entry.name}:</span>
            <span className="font-semibold text-[#334155]">
              {entry.name === "revenue" ? `৳ ${entry.value?.toLocaleString()}` : entry.value}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

// Stat Card Component
const StatCard = ({
  title,
  value,
  icon: Icon,
  subtitle,
  color = "blue",
}: StatCardProps) => {
  const palette =
    color === "green"
      ? {
          iconWrap: "bg-[#eef7e8]",
          icon: "text-[#4d5600]",
          glow: "bg-[radial-gradient(circle,rgba(205,217,75,0.24)_0%,transparent_70%)]",
        }
      : color === "purple"
        ? {
            iconWrap: "bg-[#fff4e8]",
            icon: "text-[#d88a26]",
            glow: "bg-[radial-gradient(circle,rgba(226,138,32,0.18)_0%,transparent_70%)]",
          }
        : {
            iconWrap: "bg-[#ffe8e6]",
            icon: "text-[#ff4a3d]",
            glow: "bg-[radial-gradient(circle,rgba(255,74,61,0.18)_0%,transparent_70%)]",
          };

  return (
    <Card className="group relative overflow-hidden rounded-2xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] shadow-[0_18px_45px_-32px_rgba(15,23,42,0.18)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_55px_-36px_rgba(226,138,32,0.28)]">
      <div className={`absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-70 ${palette.glow}`} />
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`rounded-xl p-3 ${palette.iconWrap}`}>
            <Icon className={`h-5 w-5 ${palette.icon}`} />
          </div>
        </div>
        <p className="mb-1 text-sm text-[#64748b]">{title}</p>
        <p className="mb-2 text-2xl font-bold text-[#334155]">{value}</p>
        {subtitle && <p className="text-xs text-[#94a3b8]">{subtitle}</p>}
      </div>
    </Card>
  );
};

export default function AdminReportsClient() {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");
  const [daily, setDaily] = useState<DayPoint[]>([]);
  const [csvFrom, setCsvFrom] = useState<string>("");
  const [csvTo, setCsvTo] = useState<string>("");
  const [csvStatus, setCsvStatus] = useState<string>("");
  const [timeRange, setTimeRange] = useState<"7" | "14" | "30">("14");
  const [showChartType, setShowChartType] = useState<"line" | "bar">("line");
  const [showValues, setShowValues] = useState(true);

  const load = useCallback(async (): Promise<void> => {
    setErr("");
    try {
      const r = await fetch("/api/admin/reports/overview", {
        cache: "no-store",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed to load reports");
        setData(null);
        return;
      }
      const parsed = parse(j);
      if (!parsed) {
        setErr("Invalid response");
        setData(null);
        return;
      }
      setData(parsed);

      const dr = await fetch(`/api/admin/reports/daily?days=${timeRange}`, {
        cache: "no-store",
      });
      const dj: unknown = await dr.json().catch(() => null);
      const dobj = dj as Record<string, unknown>;
      if (dr.ok && dobj.ok === true && Array.isArray(dobj.days)) {
        const arr = dobj.days
          .map((x) => x as Record<string, unknown>)
          .map((x) => ({
            day: safeString(x.day),
            revenue: safeNumber(x.revenue, 0),
            orders: safeNumber(x.orders, 0),
          }))
          .filter((x) => x.day);
        setDaily(arr);
      } else {
        setDaily([]);
      }
    } catch {
      setErr("Failed to load reports");
      setData(null);
      setDaily([]);
    }
  }, [timeRange]);

  useEffect(() => {
    queueMicrotask(() => {
      void load();
    });
  }, [load]);

  const formatCurrency = (value: number) => {
    return `৳ ${value.toLocaleString()}`;
  };

  // Use last 30 days directly; `thisMonth` overlaps with it and must not be added.
  const totalRevenue = useMemo(() => {
    return data?.last30Days.revenue || 0;
  }, [data]);

  const totalOrders = useMemo(() => {
    return data?.last30Days.orders || 0;
  }, [data]);

  const totalProductSales = useMemo(() => {
    return data?.last30Days.productSales || 0;
  }, [data]);

  return (
    <div className="min-h-screen bg-transparent">
      <div className="mx-auto max-w-7xl px-4 py-4">
        {err ? (
          <Card className="mb-6 rounded-2xl border border-red-200 bg-red-50/90 p-6 backdrop-blur-sm">
            <p className="text-red-600">{err}</p>
          </Card>
        ) : null}

        {/* Summary Cards */}
        <div className="mb-8 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Revenue"
            value={formatCurrency(totalRevenue)}
            icon={DollarSign}
            subtitle="Last 30 days"
            color="green"
          />
          <StatCard
            title="Total Orders"
            value={totalOrders.toString()}
            icon={ShoppingBag}
            subtitle="Last 30 days"
            color="blue"
          />
          <StatCard
            title="Total Product Sales"
            value={totalProductSales.toString()}
            icon={Package}
            subtitle="Units sold in last 30 days"
            color="purple"
          />
          <StatCard
            title="Avg. Order Value"
            value={formatCurrency(totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0)}
            icon={Package}
            subtitle="Last 30 days"
            color="blue"
          />
        </div>

        {/* Charts Section */}
        <div className="grid gap-6 lg:grid-cols-3 mb-8">
          {/* Daily Revenue Chart - Takes 2 columns */}
          <Card className="min-w-0 rounded-2xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.18)] transition-all hover:shadow-[0_24px_55px_-36px_rgba(226,138,32,0.24)] lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="text-lg font-semibold text-[#334155]">Revenue Overview</h3>
                <p className="text-sm text-[#64748b]">Daily performance with order volume</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex rounded-xl bg-[#f5efe6] p-1">
                  <button
                    onClick={() => setShowChartType("line")}
                    className={`p-2 rounded-lg transition-all ${
                      showChartType === "line"
                        ? "bg-white text-[#334155] shadow-sm"
                        : "text-[#64748b]"
                    }`}
                  >
                    <LineChartIcon className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowChartType("bar")}
                    className={`p-2 rounded-lg transition-all ${
                      showChartType === "bar"
                        ? "bg-white text-[#334155] shadow-sm"
                        : "text-[#64748b]"
                    }`}
                  >
                    <BarChart3 className="w-4 h-4" />
                  </button>
                </div>
                <button
                  onClick={() => setShowValues(!showValues)}
                  className="rounded-xl bg-[#f5efe6] p-2 text-[#64748b] transition-colors hover:bg-[#efe2cf] hover:text-[#334155]"
                >
                  {showValues ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <div className="flex gap-2">
                  {(["7", "14", "30"] as const).map((range) => (
                    <button
                      key={range}
                      onClick={() => setTimeRange(range)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                        timeRange === range
                          ? "bg-[#ff4a3d] text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)]"
                          : "bg-[#f5efe6] text-[#64748b] hover:bg-[#efe2cf] hover:text-[#334155]"
                      }`}
                    >
                      {range}d
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="h-80 min-w-0 min-h-[20rem]">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                {showChartType === "line" ? (
                  <ComposedChart data={daily}>
                    <defs>
                      <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="ordersGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="day" 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      axisLine={{ stroke: '#ece7de' }}
                    />
                    <YAxis 
                      yAxisId="revenue"
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      axisLine={{ stroke: '#ece7de' }}
                      tickFormatter={(value) => `৳${value/1000}k`}
                    />
                    <YAxis 
                      yAxisId="orders"
                      orientation="right"
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      axisLine={{ stroke: '#ece7de' }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Area
                      yAxisId="revenue"
                      type="monotone"
                      dataKey="revenue"
                      name="Revenue"
                      stroke="#ff4a3d"
                      strokeWidth={2}
                      fill="url(#revenueGradient)"
                    />
                    <Area
                      yAxisId="orders"
                      type="monotone"
                      dataKey="orders"
                      name="Orders"
                      stroke="#d88a26"
                      strokeWidth={2}
                      fill="url(#ordersGradient)"
                    />
                  </ComposedChart>
                ) : (
                  <BarChart data={daily}>
                    <defs>
                      <linearGradient id="barRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#ff4a3d" stopOpacity={1}/>
                        <stop offset="100%" stopColor="#ef3f32" stopOpacity={1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#64748b' }} />
                    <YAxis tick={{ fontSize: 12, fill: '#64748b' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="revenue" fill="url(#barRevenue)" radius={[8, 8, 0, 0]} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Monthly Revenue - Pie Chart */}
          <Card className="min-w-0 rounded-2xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.18)] transition-all hover:shadow-[0_24px_55px_-36px_rgba(226,138,32,0.24)]">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-[#334155]">Monthly Distribution</h3>
              <p className="text-sm text-[#64748b]">Revenue by month</p>
            </div>
            <div className="h-64 min-w-0 min-h-[16rem]">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <PieChart>
                  <Pie
                    data={data?.monthly ?? []}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="revenue"
                  >
                    {(data?.monthly ?? []).map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={[ '#ff4a3d', '#d88a26', '#cdd94b', '#334155', '#8b5a2b', '#efbf7e' ][index % 6]} 
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {(data?.monthly ?? []).slice(0, 4).map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full`} style={{ backgroundColor: ['#ff4a3d', '#d88a26', '#cdd94b', '#334155'][idx] }} />
                  <span className="text-xs text-[#64748b]">{item.month}</span>
                  <span className="ml-auto text-xs font-semibold text-[#334155]">{formatCurrency(item.revenue)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Bottom Section */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Best Selling Products */}
          <Card className="rounded-2xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.18)] lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-[#334155]">Best Selling Products</h3>
                <p className="text-sm text-[#64748b]">Top performers by quantity sold</p>
              </div>
              <Link href="/admin/orders" className="flex items-center text-sm font-medium text-[#d88a26] hover:text-[#b96f10]">
                View All
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            <div className="space-y-3">
              {(data?.bestSelling30 ?? []).map((item, idx) => (
                <Link
                  key={item.productId}
                  href={`/products/${item.slug}`}
                  className="block group"
                >
                  <div className="rounded-xl bg-[#fcfaf7] p-4 transition-all group-hover:bg-[linear-gradient(90deg,#fcfaf7_0%,#fff4e8_100%)]">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold
                        ${idx === 0 ? 'bg-[linear-gradient(135deg,#ff4a3d_0%,#ef3f32_100%)] text-white' : 
                          idx === 1 ? 'bg-[linear-gradient(135deg,#d88a26_0%,#b96f10_100%)] text-white' : 
                          idx === 2 ? 'bg-[linear-gradient(135deg,#cdd94b_0%,#a8b837_100%)] text-[#334155]' : 
                          'bg-[#f1efeb] text-[#64748b]'}`}>
                        {idx === 0 ? <Zap className="w-5 h-5" /> : 
                         idx === 1 ? <Award className="w-5 h-5" /> : 
                         idx === 2 ? <Star className="w-5 h-5" /> : `#${idx + 1}`}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="truncate font-semibold text-[#334155]">{item.name}</p>
                          <p className="text-sm font-semibold text-[#ff4a3d]">{formatCurrency(item.revenue)}</p>
                        </div>
                        <div className="flex items-center gap-4 mt-1">
                          <p className="text-xs text-[#64748b]">Quantity: {item.qty}</p>
                          <p className="text-xs text-[#64748b]">Avg: {formatCurrency(Math.round(item.revenue / item.qty))}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
              {(data?.bestSelling30 ?? []).length === 0 && (
                <div className="py-12 text-center text-[#64748b]">No sales data available</div>
              )}
            </div>
          </Card>

          {/* Export and Filters */}
          <Card className="rounded-2xl border border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#ffffff_100%)] p-6 shadow-[0_18px_45px_-32px_rgba(15,23,42,0.18)]">
            <div className="flex items-center gap-3 mb-6">
              <div className="rounded-xl bg-[linear-gradient(135deg,#ff4a3d_0%,#ef3f32_100%)] p-2">
                <DownloadCloud className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-[#334155]">Export Data</h3>
                <p className="text-sm text-[#64748b]">Download orders as CSV</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-xs font-medium text-[#64748b]">Date Range</label>
                <div className="grid gap-3">
                  <input
                    value={csvFrom}
                    onChange={(e) => setCsvFrom(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-[#ece7de] bg-white px-4 transition-colors focus:border-[#efbf7e] focus:ring-0"
                    placeholder="From"
                  />
                  <input
                    value={csvTo}
                    onChange={(e) => setCsvTo(e.target.value)}
                    type="date"
                    className="h-11 w-full rounded-xl border border-[#ece7de] bg-white px-4 transition-colors focus:border-[#efbf7e] focus:ring-0"
                    placeholder="To"
                  />
                </div>
              </div>
              
              <div>
                <label className="mb-2 block text-xs font-medium text-[#64748b]">Order Status</label>
                <select
                  value={csvStatus}
                  onChange={(e) => setCsvStatus(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-[#ece7de] bg-white px-4 transition-colors focus:border-[#efbf7e] focus:ring-0"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%2364748b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E")`,
                    backgroundPosition: 'right 1rem center',
                    backgroundRepeat: 'no-repeat',
                    backgroundSize: '1.5em 1.5em',
                    paddingRight: '2.5rem'
                  }}
                >
                  <option value="">All Statuses</option>
                  <option value="PENDING">Pending</option>
                  <option value="PROCESSING">Processing</option>
                  <option value="SHIPPED">Shipped</option>
                  <option value="DELIVERED">Delivered</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>

              <div className="pt-4">
                <Button
                  onClick={() => {
                    const p = new URLSearchParams();
                    if (csvFrom) p.set("from", csvFrom);
                    if (csvTo) p.set("to", csvTo);
                    if (csvStatus) p.set("status", csvStatus);
                    window.open(`/api/admin/reports/orders-csv?${p.toString()}`, "_blank");
                  }}
                  className="h-12 w-full rounded-xl bg-[linear-gradient(90deg,#ff4a3d_0%,#ef3f32_100%)] text-white shadow-[0_18px_36px_-24px_rgba(255,74,61,0.65)] transition-all hover:opacity-95 hover:shadow-[0_22px_42px_-24px_rgba(255,74,61,0.72)]"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="mt-6 border-t border-[#ece7de] pt-6">
              <h4 className="mb-3 text-sm font-semibold text-[#334155]">Quick Stats</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#d88a26]" />
                    <span className="text-sm text-[#64748b]">Avg. Processing</span>
                  </div>
                  <span className="text-sm font-semibold text-[#334155]">2.4 hours</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-[#d88a26]" />
                    <span className="text-sm text-[#64748b]">Pending Orders</span>
                  </div>
                  <span className="text-sm font-semibold text-[#334155]">8</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-[#d88a26]" />
                    <span className="text-sm text-[#64748b]">Growth Rate</span>
                  </div>
                  <span className="text-sm font-semibold text-[#4d5600]">+12.5%</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
