"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  ComposedChart,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Download,
  RefreshCw,
  Calendar,
  Package,
  DollarSign,
  ShoppingBag,
  ArrowUpRight,
} from "lucide-react";

type MonthPoint = { month: string; revenue: number; orders: number };
type BestSellingItem = {
  productId: string;
  name: string;
  slug: string;
  qty: number;
  revenue: number;
};
type DayPoint = { day: string; revenue: number; orders: number };

type ApiResponse = {
  ok: true;
  last30Days: { orders: number; revenue: number };
  thisMonth: { orders: number; revenue: number };
  monthly: MonthPoint[];
  bestSelling30: BestSellingItem[];
};

type ErrorResponse = { error: string };

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parse(input: unknown): ApiResponse | null {
  const o = input as Record<string, unknown>;
  if (o.ok !== true) return null;

  const monthlyRaw = Array.isArray(o.monthly) ? o.monthly : [];
  const monthly: MonthPoint[] = monthlyRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      month: safeString(x.month),
      revenue: safeNumber(x.revenue, 0),
      orders: safeNumber(x.orders, 0),
    }))
    .filter((x) => x.month);

  const bestRaw = Array.isArray(o.bestSelling30) ? o.bestSelling30 : [];
  const bestSelling30: BestSellingItem[] = bestRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      name: safeString(x.name),
      slug: safeString(x.slug),
      qty: safeNumber(x.qty, 0),
      revenue: safeNumber(x.revenue, 0),
    }))
    .filter((x) => x.slug);

  const last30 = (o.last30Days as Record<string, unknown>) ?? {};
  const thisM = (o.thisMonth as Record<string, unknown>) ?? {};

  return {
    ok: true,
    last30Days: {
      orders: safeNumber(last30.orders, 0),
      revenue: safeNumber(last30.revenue, 0),
    },
    thisMonth: {
      orders: safeNumber(thisM.orders, 0),
      revenue: safeNumber(thisM.revenue, 0),
    },
    monthly,
    bestSelling30,
  };
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 rounded-xl shadow-lg border border-gray-100">
        <p className="text-sm font-semibold text-gray-900 mb-1">{label}</p>
        <p className="text-xs text-gray-600">
          Revenue:{" "}
          <span className="font-semibold text-green-600">
            ৳ {payload[0].value.toLocaleString()}
          </span>
        </p>
        {payload[1] && (
          <p className="text-xs text-gray-600">
            Orders:{" "}
            <span className="font-semibold text-blue-600">
              {payload[1].value}
            </span>
          </p>
        )}
      </div>
    );
  }
  return null;
};

export default function AdminReportsClient() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ApiResponse | null>(null);
  const [err, setErr] = useState("");
  const [daily, setDaily] = useState<DayPoint[]>([]);
  const [csvFrom, setCsvFrom] = useState<string>("");
  const [csvTo, setCsvTo] = useState<string>("");
  const [csvStatus, setCsvStatus] = useState<string>("");
  const [timeRange, setTimeRange] = useState<"7" | "14" | "30">("14");

  const load = async (): Promise<void> => {
    setLoading(true);
    setErr("");
    try {
      const r = await fetch("/api/admin/reports/overview", {
        cache: "no-store",
      });
      const j: unknown = await r.json().catch(() => null);
      if (!r.ok) {
        setErr((j as ErrorResponse | null)?.error || "Failed to load reports");
        setData(null);
        return;
      }
      const parsed = parse(j);
      if (!parsed) {
        setErr("Invalid response");
        setData(null);
        return;
      }
      setData(parsed);

      const dr = await fetch(`/api/admin/reports/daily?days=${timeRange}`, {
        cache: "no-store",
      });
      const dj: unknown = await dr.json().catch(() => null);
      const dobj = dj as Record<string, unknown>;
      if (dr.ok && dobj.ok === true && Array.isArray(dobj.days)) {
        const arr = dobj.days
          .map((x) => x as Record<string, unknown>)
          .map((x) => ({
            day: safeString(x.day),
            revenue: safeNumber(x.revenue, 0),
            orders: safeNumber(x.orders, 0),
          }))
          .filter((x) => x.day);
        setDaily(arr);
      } else {
        setDaily([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [timeRange]);

  // Calculate trends
  const revenueTrend = useMemo(() => {
    if (daily.length < 2) return 0;
    const lastTwo = daily.slice(-2);
    const change =
      (((lastTwo[1]?.revenue || 0) - (lastTwo[0]?.revenue || 0)) /
        (lastTwo[0]?.revenue || 1)) *
      100;
    return change.toFixed(1);
  }, [daily]);

//     const arr = data?.monthly ?? [];
//     return arr.reduce((m, x) => Math.max(m, x.revenue), 0);
//   }, [data]);

  // Format currency
  const formatCurrency = (value: number) => {
    return `৳ ${value.toLocaleString()}`;
  };

  return (
    <div className="min-h-screen bg-linear-to-br from-gray-50 to-gray-100">
      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Header Section */}
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-linear-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
              Sales Analytics
            </h1>
            <p className="text-gray-500 mt-1">
              Track your business performance in real-time
            </p>
          </div>

          <div className="flex gap-3">
            <Link href="/admin/dashboard">
              <Button
                variant="secondary"
                className="rounded-xl border-gray-200 hover:bg-gray-50"
              >
                <ShoppingBag className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Button
              onClick={() => void load()}
              disabled={loading}
              className="rounded-xl bg-linear-to-r from-gray-900 to-gray-700 text-white hover:from-gray-800 hover:to-gray-600"
            >
              <RefreshCw
                className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`}
              />
              {loading ? "Refreshing..." : "Refresh Data"}
            </Button>
          </div>
        </div>

        {err ? (
          <Card className="mb-6 p-6 bg-red-50 border-red-200 rounded-2xl">
            <p className="text-red-600">{err}</p>
          </Card>
        ) : null}

        {/* KPI Cards */}
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-blue-50 rounded-xl">
                <Package className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                This Month
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-1">Orders</p>
            <p className="text-2xl font-bold text-gray-900">
              {data?.thisMonth.orders ?? 0}
            </p>
            <div className="mt-2 flex items-center text-xs text-gray-500">
              <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
              <span>
                +{((data?.thisMonth.orders || 0) / 10).toFixed(0)}% from last
                month
              </span>
            </div>
          </Card>

          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-green-50 rounded-xl">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                This Month
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-1">Revenue</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(data?.thisMonth.revenue ?? 0)}
            </p>
            <div className="mt-2 flex items-center text-xs text-gray-500">
              <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
              <span>
                +{((data?.thisMonth.revenue || 0) / 15).toFixed(0)}% from last
                month
              </span>
            </div>
          </Card>

          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-purple-50 rounded-xl">
                <ShoppingBag className="w-5 h-5 text-purple-600" />
              </div>
              <span className="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-1 rounded-full">
                Last 30 Days
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-1">Orders</p>
            <p className="text-2xl font-bold text-gray-900">
              {data?.last30Days.orders ?? 0}
            </p>
            <div className="mt-2 flex items-center text-xs text-gray-500">
              <Calendar className="w-3 h-3 text-gray-400 mr-1" />
              <span>Rolling 30-day total</span>
            </div>
          </Card>

          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-orange-50 rounded-xl">
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
              <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded-full">
                Last 30 Days
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-1">Revenue</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(data?.last30Days.revenue ?? 0)}
            </p>
            <div className="mt-2 flex items-center text-xs">
              {Number(revenueTrend) >= 0 ? (
                <div className="flex items-center text-green-500">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  <span>+{revenueTrend}% from yesterday</span>
                </div>
              ) : (
                <div className="flex items-center text-red-500">
                  <TrendingDown className="w-3 h-3 mr-1" />
                  <span>{revenueTrend}% from yesterday</span>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid gap-6 lg:grid-cols-2 mb-8">
          {/* Daily Revenue Line Chart */}
          <Card className="min-w-0 p-6 rounded-2xl border-0 bg-white shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Daily Revenue
                </h3>
                <p className="text-sm text-gray-500">
                  Last {timeRange} days performance
                </p>
              </div>
              <div className="flex gap-2">
                {(["7", "14", "30"] as const).map((range) => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
                      timeRange === range
                        ? "bg-gray-900 text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {range}d
                  </button>
                ))}
              </div>
            </div>
            <div className="h-80 min-w-0 min-h-[20rem]">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <ComposedChart data={daily}>
                  <defs>
                    <linearGradient
                      id="colorRevenue"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis
                    dataKey="day"
                    tick={{ fontSize: 12, fill: "#6b7280" }}
                    axisLine={{ stroke: "#e5e7eb" }}
                  />
                  <YAxis
                    yAxisId="left"
                    tick={{ fontSize: 12, fill: "#6b7280" }}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickFormatter={(value) => `৳${value / 1000}k`}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    tick={{ fontSize: 12, fill: "#6b7280" }}
                    axisLine={{ stroke: "#e5e7eb" }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="revenue"
                    stroke="#10b981"
                    strokeWidth={2}
                    fill="url(#colorRevenue)"
                  />
                  <Bar
                    yAxisId="right"
                    dataKey="orders"
                    fill="#6366f1"
                    opacity={0.3}
                    barSize={20}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Monthly Revenue Bar Chart */}
          <Card className="min-w-0 p-6 rounded-2xl border-0 bg-white shadow-lg">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900">
                Monthly Revenue
              </h3>
              <p className="text-sm text-gray-500">Last 6 months comparison</p>
            </div>
            <div className="h-80 min-w-0 min-h-[20rem]">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <BarChart data={data?.monthly ?? []}>
                  <defs>
                    <linearGradient
                      id="barGradient"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={1} />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity={1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 12, fill: "#6b7280" }}
                    axisLine={{ stroke: "#e5e7eb" }}
                  />
                  <YAxis
                    tick={{ fontSize: 12, fill: "#6b7280" }}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickFormatter={(value) => `৳${value / 1000}k`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar
                    dataKey="revenue"
                    fill="url(#barGradient)"
                    radius={[8, 8, 0, 0]}
                    barSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        {/* Bottom Section */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Best Selling Products */}
          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Best Selling Products
                </h3>
                <p className="text-sm text-gray-500">
                  Top performers in last 30 days
                </p>
              </div>
              <Link
                href="/admin/orders"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center"
              >
                View All
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            <div className="space-y-3">
              {(data?.bestSelling30 ?? []).map((item, idx) => (
                <Link
                  key={item.productId}
                  href={`/products/${item.slug}`}
                  className="block p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold
                        ${
                          idx === 0
                            ? "bg-yellow-100 text-yellow-700"
                            : idx === 1
                              ? "bg-gray-200 text-gray-700"
                              : idx === 2
                                ? "bg-orange-100 text-orange-700"
                                : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        #{idx + 1}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{item.name}</p>
                        <p className="text-sm text-gray-500">
                          Qty: {item.qty} • Revenue:{" "}
                          {formatCurrency(item.revenue)}
                        </p>
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">View →</div>
                  </div>
                </Link>
              ))}
              {(data?.bestSelling30 ?? []).length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No sales data available
                </div>
              )}
            </div>
          </Card>

          {/* CSV Export */}
          <Card className="p-6 rounded-2xl border-0 bg-white shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Export Orders
                </h3>
                <p className="text-sm text-gray-500">
                  Download order data as CSV (max 5000 rows)
                </p>
              </div>
              <div className="p-2 bg-gray-100 rounded-xl">
                <Download className="w-5 h-5 text-gray-600" />
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    From Date
                  </label>
                  <input
                    value={csvFrom}
                    onChange={(e) => setCsvFrom(e.target.value)}
                    type="date"
                    className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-gray-400 focus:ring-0 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    To Date
                  </label>
                  <input
                    value={csvTo}
                    onChange={(e) => setCsvTo(e.target.value)}
                    type="date"
                    className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-gray-400 focus:ring-0 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Order Status
                </label>
                <select
                  value={csvStatus}
                  onChange={(e) => setCsvStatus(e.target.value)}
                  className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-gray-400 focus:ring-0 transition-colors"
                >
                  <option value="">All Statuses</option>
                  <option value="PENDING">Pending</option>
                  <option value="PROCESSING">Processing</option>
                  <option value="SHIPPED">Shipped</option>
                  <option value="DELIVERED">Delivered</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>

              <Button
                onClick={() => {
                  const p = new URLSearchParams();
                  if (csvFrom) p.set("from", csvFrom);
                  if (csvTo) p.set("to", csvTo);
                  if (csvStatus) p.set("status", csvStatus);
                  window.open(
                    `/api/admin/reports/orders-csv?${p.toString()}`,
                    "_blank",
                  );
                }}
                className="w-full h-11 bg-linear-to-r from-gray-900 to-gray-700 text-white rounded-xl hover:from-gray-800 hover:to-gray-600 transition-all"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CSV Report
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
