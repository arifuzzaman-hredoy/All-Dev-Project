"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  loadAppliedCoupon,
  clearAppliedCoupon,
  saveAppliedCoupon,
} from "@/lib/coupon-client";
import { useToast } from "../ui/toast";
import { BD_DISTRICTS, isDhakaDistrict } from "@/lib/bd-districts";
import ReturnRefundPolicyModal from "./return-refund-policy-modal";

type CartDetailsItem = {
  qty: number;
  variantId?: string | null;
  variantLabel?: string | null;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
  };
};

type CartDetailsResponse = { items: CartDetailsItem[] };

type ValidateOk = {
  ok?: true;
  success?: true;
  code?: string;
  discount?: number;
};

type PublicStoreSettings = {
  ok: true;
  storeName: string;
  currency: string;
  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  codEnabled: boolean;
  onlineEnabled: boolean;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;
  returnRefundPolicy: string;
};

type PaymentMethod = "COD" | "ONLINE";

const COD_CHECKOUT_ENDPOINT = "/api/orders";
const ONLINE_CHECKOUT_ENDPOINT = "/api/payments/sslcommerz/initiate";

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parseDetails(input: unknown): CartDetailsResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const items: CartDetailsItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const p = (x.product as Record<string, unknown> | undefined) ?? {};
      const qty = Math.max(1, Math.floor(safeNumber(x.qty, 1)));

      return {
        qty,
        variantId:
          typeof x.variantId === "string"
            ? x.variantId
            : x.variantId === null
              ? null
              : undefined,
        variantLabel:
          typeof x.variantLabel === "string"
            ? x.variantLabel
            : x.variantLabel === null
              ? null
              : undefined,
        product: {
          id: safeString(p.id),
          name: safeString(p.name),
          slug: safeString(p.slug),
          price: safeNumber(p.price, 0),
          offerPrice:
            p.offerPrice === null
              ? null
              : typeof p.offerPrice === "number"
                ? p.offerPrice
                : null,
          stock: safeNumber(p.stock, 0),
          images: Array.isArray(p.images)
            ? (p.images as Array<{ url: string }>)
            : [],
        },
      };
    })
    .filter((i) => i.product.id && i.product.slug);

  return { items };
}

function parseSettings(input: unknown): PublicStoreSettings {
  const data = (input as Record<string, unknown> | null) ?? {};

  return {
    ok: true,
    storeName: safeString(data.storeName, "Rangpur Hearing Center"),
    currency: safeString(data.currency, "BDT"),
    taxRate: Math.max(0, safeNumber(data.taxRate, 0)),
    shippingInsideDhaka: Math.max(0, safeNumber(data.shippingInsideDhaka, 0)),
    shippingOutsideDhaka: Math.max(0, safeNumber(data.shippingOutsideDhaka, 0)),
    shippingFreeOver: Math.max(0, safeNumber(data.shippingFreeOver, 0)),
    codEnabled: typeof data.codEnabled === "boolean" ? data.codEnabled : true,
    onlineEnabled:
      typeof data.onlineEnabled === "boolean" ? data.onlineEnabled : false,
    lowStockThreshold: Math.max(0, safeNumber(data.lowStockThreshold, 5)),
    facebookUrl: safeString(data.facebookUrl, ""),
    instagramUrl: safeString(data.instagramUrl, ""),
    youtubeUrl: safeString(data.youtubeUrl, ""),
    tiktokUrl: safeString(data.tiktokUrl, ""),
    whatsappUrl: safeString(data.whatsappUrl, ""),
    returnRefundPolicy: safeString(data.returnRefundPolicy, ""),
  };
}

function calcTotals(input: {
  subtotal: number;
  discount: number;
  district: string;
  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
}) {
  const subtotal = Math.max(0, Math.floor(input.subtotal));
  const discount = Math.max(0, Math.min(subtotal, Math.floor(input.discount)));

  const discounted = Math.max(0, subtotal - discount);

  const shipping =
    input.shippingFreeOver > 0 && discounted >= input.shippingFreeOver
      ? 0
      : isDhakaDistrict(input.district)
        ? Math.max(0, Math.floor(input.shippingInsideDhaka))
        : Math.max(0, Math.floor(input.shippingOutsideDhaka));

  const tax = Math.max(
    0,
    Math.floor((discounted * Math.max(0, input.taxRate)) / 100),
  );

  const total = Math.max(0, discounted + shipping + tax);

  return {
    subtotal,
    discount,
    shipping,
    tax,
    total,
  };
}

function getErrorMessage(
  input: unknown,
  fallback = "Something went wrong",
): string {
  const o = input as Record<string, unknown> | null;

  if (!o) return fallback;

  if (typeof o.error === "string" && o.error.trim()) return o.error;
  if (typeof o.message === "string" && o.message.trim()) return o.message;

  return fallback;
}

function getOrderIdFromResponse(input: unknown): string | null {
  const o = input as Record<string, unknown> | null;
  if (!o) return null;

  if (typeof o.orderId === "string") return o.orderId;

  const data =
    typeof o.data === "object" && o.data !== null
      ? (o.data as Record<string, unknown>)
      : null;

  if (data && typeof data.orderId === "string") return data.orderId;
  if (data && typeof data.id === "string") return data.id;

  const order =
    data && typeof data.order === "object" && data.order !== null
      ? (data.order as Record<string, unknown>)
      : null;

  if (order && typeof order.id === "string") return order.id;

  return null;
}

function getGatewayUrlFromResponse(input: unknown): string | null {
  const o = input as Record<string, unknown> | null;
  if (!o) return null;

  if (typeof o.gatewayUrl === "string") return o.gatewayUrl;

  const data =
    typeof o.data === "object" && o.data !== null
      ? (o.data as Record<string, unknown>)
      : null;

  if (data && typeof data.gatewayUrl === "string") return data.gatewayUrl;
  if (data && typeof data.GatewayPageURL === "string")
    return data.GatewayPageURL;

  return null;
}

export default function CheckoutClient() {
  const [loading, setLoading] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);

  const [details, setDetails] = useState<CartDetailsResponse>({ items: [] });
  const [settings, setSettings] = useState<PublicStoreSettings>({
    ok: true,
    storeName: "Rangpur Hearing Center",
    currency: "BDT",
    taxRate: 0,
    shippingInsideDhaka: 0,
    shippingOutsideDhaka: 0,
    shippingFreeOver: 0,
    codEnabled: true,
    onlineEnabled: false,
    lowStockThreshold: 5,
    facebookUrl: "",
    instagramUrl: "",
    youtubeUrl: "",
    tiktokUrl: "",
    whatsappUrl: "",
    returnRefundPolicy: "",
  });

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("COD");

  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [couponMsg, setCouponMsg] = useState("");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [line1, setLine1] = useState("");
  const [line2, setLine2] = useState("");
  const [city, setCity] = useState("Dhaka");
  const [area, setArea] = useState("");
  const [note, setNote] = useState("");

  const { toast } = useToast();

  const subtotal = useMemo(() => {
    return details.items.reduce((sum, row) => {
      const unit = row.product.offerPrice ?? row.product.price;
      return sum + unit * row.qty;
    }, 0);
  }, [details.items]);

  const totals = useMemo(() => {
    return calcTotals({
      subtotal,
      discount,
      district: city,
      taxRate: settings.taxRate,
      shippingInsideDhaka: settings.shippingInsideDhaka,
      shippingOutsideDhaka: settings.shippingOutsideDhaka,
      shippingFreeOver: settings.shippingFreeOver,
    });
  }, [subtotal, discount, city, settings]);

  const shippingLabel = useMemo(() => {
    return isDhakaDistrict(city)
      ? "Shipping (Dhaka)"
      : "Shipping (Outside Dhaka)";
  }, [city]);

  const load = async (): Promise<void> => {
    setLoading(true);
    try {
      const [cartRes, settingsRes] = await Promise.all([
        fetch("/api/cart/details", { cache: "no-store" }),
        fetch("/api/store/settings/public", { cache: "no-store" }),
      ]);

      const cartJson: unknown = await cartRes.json().catch(() => null);
      const settingsJson: unknown = await settingsRes.json().catch(() => null);

      setDetails(parseDetails(cartJson));
      setSettings(parseSettings(settingsJson));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  useEffect(() => {
    const saved = loadAppliedCoupon();
    if (saved?.code) {
      setCouponCode(saved.code);
    }
  }, []);

  useEffect(() => {
    if (settings.codEnabled) {
      setPaymentMethod("COD");
      return;
    }

    if (settings.onlineEnabled) {
      setPaymentMethod("ONLINE");
    }
  }, [settings.codEnabled, settings.onlineEnabled]);

  useEffect(() => {
    const saved = loadAppliedCoupon();
    if (!saved?.code) return;
    if (subtotal <= 0) return;

    const revalidateSavedCoupon = async () => {
      const r = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: saved.code, subtotal }),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setDiscount(0);
        setCouponMsg(getErrorMessage(j, "Invalid coupon"));
        clearAppliedCoupon();
        return;
      }

      const disc = (j as { discount?: unknown })?.discount;
      const d = typeof disc === "number" ? disc : Number(disc);
      const dd = Number.isFinite(d) ? Math.max(0, Math.floor(d)) : 0;

      setDiscount(dd);
      setCouponMsg("Coupon applied ✅");
      saveAppliedCoupon({ code: saved.code, discount: dd });
    };

    void revalidateSavedCoupon();
  }, [subtotal]);

  const applyCoupon = async (): Promise<void> => {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    setCouponMsg("");

    const r = await fetch("/api/coupons/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, subtotal }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      setDiscount(0);
      setCouponMsg(getErrorMessage(j, "Invalid coupon"));
      clearAppliedCoupon();
      return;
    }

    const ok = j as ValidateOk;
    const dd = Math.max(0, Math.floor(safeNumber(ok.discount, 0)));

    setDiscount(dd);
    setCouponMsg("Coupon applied ✅");
    saveAppliedCoupon({ code, discount: dd });
  };

  const buildCheckoutPayload = () => {
    return {
      items: details.items.map((row) => ({
        productId: row.product.id,
        variantId: row.variantId || undefined,
        qty: row.qty,
      })),
      couponCode: couponCode.trim()
        ? couponCode.trim().toUpperCase()
        : undefined,
      paymentMethod,
      name: name.trim(),
      email: email.trim() ? email.trim() : undefined,
      phone: phone.trim(),
      addressLine1: line1.trim(),
      addressLine2: line2.trim() ? line2.trim() : undefined,
      city,
      area: area.trim() ? area.trim() : undefined,
      note: note.trim() ? note.trim() : undefined,
    };
  };

  const clearClientCartState = async (): Promise<void> => {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "clear" }),
    });

    clearAppliedCoupon();
    window.dispatchEvent(new Event("rhc_cart_updated"));
  };

  const placeOrder = async (): Promise<void> => {
    if (details.items.length === 0) return;

    if (!name.trim() || !phone.trim() || !line1.trim() || !city.trim()) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Name, phone, address line 1 and district are required",
      });
      return;
    }

    if (paymentMethod === "COD" && !settings.codEnabled) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Cash on Delivery is currently disabled.",
      });
      return;
    }

    if (paymentMethod === "ONLINE" && !settings.onlineEnabled) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Online payment is currently disabled.",
      });
      return;
    }

    const payload = buildCheckoutPayload();

    setPlacing(true);
    try {
      if (paymentMethod === "COD") {
        const r = await fetch(COD_CHECKOUT_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const j: unknown = await r.json().catch(() => null);

        if (!r.ok) {
          toast({
            variant: "error",
            title: "Failed",
            description: getErrorMessage(j, "Order failed"),
          });
          return;
        }

        const orderId = getOrderIdFromResponse(j);
        if (!orderId) {
          toast({
            variant: "info",
            title: "No ID",
            description: "Order created but order ID was not returned",
          });
          return;
        }

        await clearClientCartState();
        window.location.href = `/orders/${orderId}`;
        return;
      }

      const r = await fetch(ONLINE_CHECKOUT_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description: getErrorMessage(j, "Payment initiation failed"),
        });
        return;
      }

      const gatewayUrl = getGatewayUrlFromResponse(j);
      if (!gatewayUrl) {
        toast({
          variant: "error",
          title: "Failed",
          description: "Payment gateway URL not found",
        });
        return;
      }

      window.location.href = gatewayUrl;
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6 flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-semibold">Checkout</div>
          <div className="text-sm text-black/60">
            {settings.codEnabled && settings.onlineEnabled
              ? "Cash on Delivery + Online Payment available"
              : settings.codEnabled
                ? "Cash on Delivery available"
                : settings.onlineEnabled
                  ? "Online Payment available"
                  : "No payment method is currently available"}
          </div>
        </div>

        <Link href="/cart" className="text-sm text-black/70 underline">
          Back to cart
        </Link>
      </div>

      {loading ? (
        <Card className="rounded-3xl p-6">Loading…</Card>
      ) : details.items.length === 0 ? (
        <Card className="rounded-3xl p-8">
          <div className="text-base font-semibold">Cart is empty</div>
          <div className="mt-3">
            <Link href="/products">
              <Button>Browse products</Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-[1fr_380px]">
          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Delivery details</div>

            <div className="mt-4 grid gap-3">
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Full name *"
              />

              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email (optional)"
                type="email"
              />

              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Phone *"
              />

              <Input
                value={line1}
                onChange={(e) => setLine1(e.target.value)}
                placeholder="Address line 1 *"
              />

              <Input
                value={line2}
                onChange={(e) => setLine2(e.target.value)}
                placeholder="Address line 2"
              />

              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <div className="mb-1 text-sm text-black/60">District *</div>
                  <select
                    className="h-11 w-full rounded-2xl border border-black/10 bg-white px-4 text-sm outline-none"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                  >
                    {BD_DISTRICTS.map((district) => (
                      <option key={district} value={district}>
                        {district}
                      </option>
                    ))}
                  </select>
                </div>

                <Input
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  placeholder="Area / Upazila"
                />
              </div>

              <Input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Note (optional)"
              />

              <div className="rounded-2xl border border-black/10 bg-black/5 px-4 py-3 text-sm text-black/70">
                Selected district: <b>{city}</b>
                <br />
                Applied shipping:{" "}
                <b>
                  ৳{" "}
                  {isDhakaDistrict(city)
                    ? settings.shippingInsideDhaka
                    : settings.shippingOutsideDhaka}
                </b>
                {settings.shippingFreeOver > 0 ? (
                  <>
                    <br />
                    Free shipping over: <b>৳ {settings.shippingFreeOver}</b>
                  </>
                ) : null}
              </div>
            </div>

            <div className="mt-6 border-t border-black/10 pt-4">
              <div className="text-sm font-semibold">Payment method</div>

              <div className="mt-3 grid gap-2">
                <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-black/10 p-3">
                  <input
                    type="radio"
                    name="payment-method"
                    value="COD"
                    checked={paymentMethod === "COD"}
                    onChange={() => setPaymentMethod("COD")}
                    disabled={!settings.codEnabled}
                  />
                  <div>
                    <div className="text-sm font-medium">Cash on Delivery</div>
                    <div className="text-xs text-black/60">
                      {settings.codEnabled
                        ? "Pay when your order is delivered"
                        : "Currently unavailable"}
                    </div>
                  </div>
                </label>

                <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-black/10 p-3">
                  <input
                    type="radio"
                    name="payment-method"
                    value="ONLINE"
                    checked={paymentMethod === "ONLINE"}
                    onChange={() => setPaymentMethod("ONLINE")}
                    disabled={!settings.onlineEnabled}
                  />
                  <div>
                    <div className="text-sm font-medium">
                      Online Payment (SSLCommerz)
                    </div>
                    <div className="text-xs text-black/60">
                      {settings.onlineEnabled
                        ? "Pay securely via SSLCommerz"
                        : "Currently unavailable"}
                    </div>
                  </div>
                </label>
              </div>

              <div className="mt-2 text-xs text-black/60">
                চূড়ান্ত total server-side calculate হবে।
              </div>
            </div>

            <div className="mt-6 border-t border-black/10 pt-4">
              <div className="text-sm font-semibold">Items</div>
              <div className="mt-2 space-y-2">
                {details.items.map((row) => {
                  const unit = row.product.offerPrice ?? row.product.price;
                  return (
                    <div
                      key={`${row.product.id}-${row.variantId ?? "base"}`}
                      className="flex items-center justify-between text-sm"
                    >
                      <div className="min-w-0">
                        <div className="line-clamp-1 font-semibold">
                          {row.product.name}
                        </div>
                        {row.variantLabel ? (
                          <div className="text-xs text-black/60">
                            Variant: {row.variantLabel}
                          </div>
                        ) : null}
                        <div className="text-xs text-black/60">
                          ৳ {unit} × {row.qty}
                        </div>
                      </div>
                      <div className="font-semibold">৳ {unit * row.qty}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>

          <Card className="rounded-3xl p-4">
            <div className="text-sm font-semibold">Order summary</div>

            <div className="mt-4">
              <div className="text-sm font-semibold">Coupon</div>
              <div className="mt-2 flex gap-2">
                <Input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder="Enter coupon"
                />
                <Button
                  variant="secondary"
                  onClick={() => void applyCoupon()}
                  disabled={subtotal <= 0}
                >
                  Apply
                </Button>
              </div>
              {couponMsg ? (
                <div className="mt-2 text-xs text-black/60">{couponMsg}</div>
              ) : null}
            </div>

            <div className="mt-4 grid gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-black/60">Subtotal</span>
                <span>৳ {totals.subtotal}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-black/60">Discount</span>
                <span>৳ {totals.discount}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-black/60">{shippingLabel}</span>
                <span>৳ {totals.shipping}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-black/60">Tax</span>
                <span>৳ {totals.tax}</span>
              </div>

              <div className="mt-2 flex justify-between border-t border-black/10 pt-3">
                <span className="font-semibold">Total</span>
                <span className="font-semibold">৳ {totals.total}</span>
              </div>
            </div>

            <div className="mt-3 text-xs text-black/60">
              Dhaka shipping: ৳ {settings.shippingInsideDhaka}
              <br />
              Outside Dhaka shipping: ৳ {settings.shippingOutsideDhaka}
              {settings.shippingFreeOver > 0 ? (
                <>
                  <br />
                  Free shipping over ৳ {settings.shippingFreeOver}
                </>
              ) : null}
            </div>

            <div className="mt-4">
              <Button
                className="w-full"
                onClick={() => void placeOrder()}
                disabled={
                  placing ||
                  (!settings.codEnabled && !settings.onlineEnabled) ||
                  (paymentMethod === "COD" && !settings.codEnabled) ||
                  (paymentMethod === "ONLINE" && !settings.onlineEnabled)
                }
              >
                {placing
                  ? paymentMethod === "ONLINE"
                    ? "Redirecting to payment..."
                    : "Placing order..."
                  : paymentMethod === "ONLINE"
                    ? "Pay Online with SSLCommerz"
                    : "Place Order (COD)"}
              </Button>

              <div className="mt-2 text-xs text-black/60">
                By placing the order, you agree to our policies.{" "}
                <button
                  type="button"
                  onClick={() => setPolicyOpen(true)}
                  className="underline hover:text-black"
                >
                  Return and Refund Policy
                </button>
              </div>
            </div>
          </Card>
        </div>
      )}
      <ReturnRefundPolicyModal
        open={policyOpen}
        onClose={() => setPolicyOpen(false)}
        content={settings.returnRefundPolicy}
      />
    </div>
  );
}
