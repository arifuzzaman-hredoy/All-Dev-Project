"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { saveAppliedCoupon, clearAppliedCoupon } from "@/lib/coupon-client";
import PageHero from "@/components/layout/page-hero";

type CartItem = {
  productId: string;
  qty: number;
  variantId?: string | null;
};

type Cart = { items: CartItem[] };
type CartApiResponse = { cart: Cart };

type ProductRow = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  images: { url: string }[];
};

type CartDetailsRow = {
  qty: number;
  variantId: string | null;
  variantLabel: string | null;
  product: ProductRow;
};

type CartDetailsResponse = {
  items: CartDetailsRow[];
};

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function formatCurrency(amount: number): string {
  return `৳ ${Math.max(0, Math.round(amount))}`;
}

function parseCartApi(input: unknown): CartApiResponse {
  const o = input as Record<string, unknown>;
  const c = (o.cart as Record<string, unknown> | undefined) ?? {};
  const itemsRaw = Array.isArray(c.items) ? c.items : [];

  const items: CartItem[] = itemsRaw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      productId: safeString(x.productId),
      qty: Math.max(1, Math.floor(safeNumber(x.qty, 1))),
      variantId:
        typeof x.variantId === "string"
          ? x.variantId
          : x.variantId === null
            ? null
            : null,
    }))
    .filter((x) => x.productId);

  return { cart: { items } };
}

function parseCartDetails(input: unknown): CartDetailsResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const items = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const p = (x.product as Record<string, unknown> | undefined) ?? {};
      const imagesRaw = Array.isArray(p.images) ? p.images : [];
      const images = imagesRaw
        .map((img) => img as Record<string, unknown>)
        .map((img) => ({ url: safeString(img.url) }))
        .filter((img) => img.url);

      const product: ProductRow = {
        id: safeString(p.id),
        name: safeString(p.name),
        slug: safeString(p.slug),
        price: safeNumber(p.price, 0),
        offerPrice:
          p.offerPrice === null
            ? null
            : typeof p.offerPrice === "number"
              ? p.offerPrice
              : null,
        stock: safeNumber(p.stock, 0),
        images,
      };

      return {
        qty: Math.max(1, Math.floor(safeNumber(x.qty, 1))),
        variantId:
          typeof x.variantId === "string"
            ? x.variantId
            : x.variantId === null
              ? null
              : null,
        variantLabel:
          typeof x.variantLabel === "string"
            ? x.variantLabel
            : x.variantLabel === null
              ? null
              : null,
        product,
      };
    })
    .filter((x) => x.product.id && x.product.slug);

  return { items };
}

export default function CartClient() {
  const [loading, setLoading] = useState<boolean>(false);
  const [cart, setCart] = useState<Cart>({ items: [] });
  const [details, setDetails] = useState<CartDetailsResponse>({ items: [] });
  const [couponCode, setCouponCode] = useState<string>("");
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [couponLoading, setCouponLoading] = useState<boolean>(false);
  const [couponMsg, setCouponMsg] = useState<string>("");

  const load = async () => {
    setLoading(true);
    try {
      const r1 = await fetch("/api/cart", { cache: "no-store" });
      const j1: unknown = await r1.json().catch(() => null);
      const c = parseCartApi(j1).cart;
      setCart(c);

      const r2 = await fetch("/api/cart/details", { cache: "no-store" });
      const j2: unknown = await r2.json().catch(() => null);
      setDetails(parseCartDetails(j2));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const subtotal = useMemo(() => {
    return details.items.reduce((sum, row) => {
      const unit = row.product.offerPrice ?? row.product.price;
      return sum + unit * row.qty;
    }, 0);
  }, [details.items]);

  const total = useMemo(
    () => Math.max(0, subtotal - couponDiscount),
    [subtotal, couponDiscount],
  );

  const totalItems = useMemo(
    () => details.items.reduce((sum, row) => sum + row.qty, 0),
    [details.items],
  );

  const setQty = async (
    productId: string,
    variantId: string | null,
    qty: number,
  ) => {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "set", productId, variantId, qty }),
    });
    await load();
  };

  const remove = async (productId: string, variantId: string | null) => {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "remove", productId, variantId }),
    });
    await load();
  };

  const clear = async () => {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "clear" }),
    });

    clearAppliedCoupon();
    setCouponCode("");
    setCouponDiscount(0);
    setCouponMsg("");
    await load();
  };

  const applyCoupon = async (): Promise<void> => {
    const code = couponCode.trim();
    if (!code) return;

    setCouponLoading(true);
    setCouponMsg("");

    try {
      const r = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, subtotal }),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        const msg = (j as { error?: unknown })?.error;
        setCouponDiscount(0);
        setCouponMsg(typeof msg === "string" ? msg : "Invalid coupon");
        return;
      }

      const disc = (j as { discount?: unknown })?.discount;
      const d = typeof disc === "number" ? disc : Number(disc);

      setCouponDiscount(Number.isFinite(d) ? Math.max(0, Math.floor(d)) : 0);
      setCouponMsg("Coupon applied ✅");

      saveAppliedCoupon({
        code: code.toUpperCase(),
        discount: Math.max(0, Math.floor(d)),
      });
    } finally {
      setCouponLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <PageHero
        eyebrow="Cart"
        title="Cart"
        description="Review items, apply coupons, and continue to checkout."
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Cart" },
        ]}
        actions={[
          { href: "/products", label: "Continue shopping" },
          { href: "/checkout", label: "Pay Now", variant: "secondary" },
        ]}
        stats={[
          { label: "Unique items", value: String(cart.items.length) },
          { label: "Total quantity", value: String(totalItems) },
          { label: "Subtotal", value: formatCurrency(subtotal) },
          { label: "Discount", value: formatCurrency(couponDiscount) },
        ]}
      />


      {loading ? (
        <Card className="border border-[#ece7de] bg-gradient-to-br from-[#fbf7f0] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(148,112,67,0.18)]">
          <div className="space-y-3">
            <div className="h-5 w-32 animate-pulse rounded-full bg-[#efe6d6]" />
            <div className="h-20 animate-pulse rounded-3xl bg-white/80" />
            <div className="h-20 animate-pulse rounded-3xl bg-white/80" />
            <div className="text-sm text-slate-600">Loading your cart…</div>
          </div>
        </Card>
      ) : details.items.length === 0 ? (
        <Card className="rounded-[2rem] border border-[#ece7de] bg-gradient-to-br from-[#fbf7f0] via-white to-white p-8 shadow-[0_18px_60px_-44px_rgba(148,112,67,0.18)]">
          <div className="mx-auto max-w-xl text-center">
            <div className="inline-flex rounded-full border border-[#efbf7e] bg-[#fff8ee] px-4 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-[#d88a26]">
              Cart Empty
            </div>
            <div className="mt-4 text-2xl font-semibold text-slate-900">
              Your cart is waiting for something nice.
            </div>
            <div className="mt-2 text-sm leading-6 text-slate-600">
              Add products to compare prices, adjust quantity, and continue to
              checkout whenever you are ready.
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link href="/products">
                <Button>
                  Browse Products
                </Button>
              </Link>
              <Link href="/">
                <Button
                  variant="secondary"
                  className="bg-white"
                >
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </Card>
      ) : (
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-4">
            <Card className="rounded-[2rem] border border-[#ece7de] bg-gradient-to-br from-[#fbf7f0] via-white to-white p-4 shadow-[0_18px_60px_-44px_rgba(148,112,67,0.16)]">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="text-base font-semibold text-slate-900">
                    Cart Items
                  </div>
                  <div className="text-sm text-slate-600">
                    Review each product before moving to payment.
                  </div>
                </div>
              </div>

              <div className="grid gap-3">
              {details.items.map(
                ({ product, qty, variantId, variantLabel }) => {
                  const img = product.images[0]?.url;
                  const unit = product.offerPrice ?? product.price;
                  const lineTotal = unit * qty;
                  const isLowStock =
                    product.stock > 0 && qty >= Math.max(1, product.stock - 2);

                  return (
                    <div
                      key={`${product.id}-${variantId ?? "base"}`}
                      className="rounded-3xl border border-[#ece7de] bg-white/90 p-4 transition hover:bg-[#fffdfa]"
                    >
                      <div className="flex flex-col gap-4 md:flex-row">
                        <div className="relative h-24 w-24 overflow-hidden rounded-2xl bg-[#f8f5f0]">
                          {img ? (
                            <Image
                              src={img}
                              alt={product.name}
                              fill
                              className="object-contain p-2"
                              sizes="96px"
                            />
                          ) : (
                            <div className="flex h-full items-center justify-center text-xs text-slate-400">
                              No image
                            </div>
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                            <div className="min-w-0">
                              <Link
                                href={`/products/${product.slug}`}
                                className="line-clamp-2 text-base font-semibold text-slate-900"
                              >
                                {product.name}
                              </Link>

                              <div className="mt-2 flex flex-wrap gap-2 text-xs font-medium">
                                {variantLabel ? (
                                  <span className="rounded-full border border-[#efbf7e] bg-[#fff8ee] px-3 py-1 text-[#d88a26]">
                                    Variant: {variantLabel}
                                  </span>
                                ) : null}
                                <span className="rounded-full border border-black/10 bg-black/5 px-3 py-1 text-slate-600">
                                  Unit price: {formatCurrency(unit)}
                                </span>
                                <span className="rounded-full border border-black/10 bg-black/5 px-3 py-1 text-slate-600">
                                  Stock: {product.stock}
                                </span>
                              </div>

                              {isLowStock ? (
                                <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                                  This item is running low in stock. Checkout soon
                                  if you want to keep this quantity.
                                </div>
                              ) : null}
                            </div>

                            <div className="rounded-2xl border border-[#ece7de] bg-[#fbf7f0] px-4 py-3 text-left lg:min-w-[140px] lg:text-right">
                              <div className="text-xs uppercase tracking-[0.18em] text-slate-500">
                                Line total
                              </div>
                              <div className="mt-1 text-lg font-semibold text-slate-900">
                                {formatCurrency(lineTotal)}
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 flex flex-col gap-3 border-t border-[#ece7de] pt-4 sm:flex-row sm:items-end sm:justify-between">
                            <div>
                              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
                                Quantity
                              </div>
                              <div className="mt-2 flex items-center gap-2">
                                <Button
                                  variant="secondary"
                                  onClick={() =>
                                    void setQty(
                                      product.id,
                                      variantId,
                                      Math.max(1, qty - 1),
                                    )
                                  }
                                  className="h-11 w-11 border-[#efbf7e] bg-[#fff8ee] p-0 text-lg text-[#d88a26] hover:bg-[#fff1df]"
                                >
                                  -
                                </Button>

                                <Input
                                  className="h-11 w-20 border-[#ece7de] bg-white text-center text-base"
                                  type="number"
                                  min={1}
                                  max={Math.max(1, product.stock)}
                                  value={qty}
                                  onChange={(e) =>
                                    void setQty(
                                      product.id,
                                      variantId,
                                      Math.max(1, Number(e.target.value)),
                                    )
                                  }
                                />

                                <Button
                                  variant="secondary"
                                  onClick={() =>
                                    void setQty(product.id, variantId, qty + 1)
                                  }
                                  className="h-11 w-11 border-[#efbf7e] bg-[#fff8ee] p-0 text-lg text-[#d88a26] hover:bg-[#fff1df]"
                                >
                                  +
                                </Button>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              <Link href={`/products/${product.slug}`}>
                                <Button
                                  variant="secondary"
                                  className="bg-white"
                                >
                                  View Product
                                </Button>
                              </Link>

                              <Button
                                variant="secondary"
                                onClick={() => void remove(product.id, variantId)}
                                className="border-[#efbf7e] bg-[#fff8ee] text-[#d88a26] hover:bg-[#fff1df]"
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                },
              )}
              </div>
            </Card>
          </div>

          <div className="space-y-4 xl:sticky xl:top-6 xl:self-start">
            <Card className="rounded-[2rem] border border-[#ece7de] bg-gradient-to-br from-[#fbf7f0] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(148,112,67,0.18)]">
              <div className="text-lg font-semibold text-slate-900">
                Order Summary
              </div>
              <div className="mt-1 text-sm text-slate-600">
                A quick overview before payment.
              </div>

              <div className="mt-5 grid gap-3 text-sm text-slate-700">
                <div className="flex items-center justify-between rounded-2xl border border-[#ece7de] bg-white/80 px-4 py-3">
                  <span className="text-slate-600">Subtotal</span>
                  <span className="font-semibold">{formatCurrency(subtotal)}</span>
                </div>

                <div className="flex items-center justify-between rounded-2xl border border-[#ece7de] bg-white/80 px-4 py-3">
                  <span className="text-slate-600">Discount</span>
                  <span className="font-semibold">{formatCurrency(couponDiscount)}</span>
                </div>

                <div className="rounded-2xl bg-[#ff4a3d] px-4 py-4 text-white shadow-[0_12px_34px_-16px_rgba(255,74,61,0.55)]">
                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Estimated total</span>
                    <span className="text-lg font-semibold">
                      {formatCurrency(total)}
                    </span>
                  </div>
                  <div className="mt-1 text-xs text-white/80">
                    Shipping and any payment fees will be confirmed at checkout.
                  </div>
                </div>
              </div>

              <div className="mt-5">
                <div className="text-sm font-semibold text-slate-900">
                  Coupon Code
                </div>
                <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                  <Input
                    className="border-[#ece7de] bg-white"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Enter coupon code"
                  />
                  <Button
                    variant="secondary"
                    onClick={() => void applyCoupon()}
                    disabled={couponLoading || subtotal <= 0}
                    className="bg-white"
                  >
                    {couponLoading ? "Applying…" : "Apply"}
                  </Button>
                </div>

                {couponMsg ? (
                  <div className="mt-2 text-xs text-slate-600">{couponMsg}</div>
                ) : null}
              </div>

              <div className="mt-5 rounded-2xl border border-[#ece7de] bg-white/80 p-4">
                <div className="text-sm font-semibold text-slate-900">
                  Before you place the order
                </div>
                <div className="mt-3 grid gap-2 text-sm text-slate-600">
                  <div>Review quantity and variant details.</div>
                  <div>Apply a coupon if you have one.</div>
                  <div>Proceed to checkout to confirm address and payment.</div>
                </div>
              </div>

              <div className="mt-5 space-y-3">
                <Link href="/checkout">
                  <Button
                    className="w-full"
                    disabled={details.items.length === 0}
                  >
                    Pay Now
                  </Button>
                </Link>
                <Link href="/products">
                  <Button
                    variant="secondary"
                    className="w-full bg-white"
                  >
                    Add More Products
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
