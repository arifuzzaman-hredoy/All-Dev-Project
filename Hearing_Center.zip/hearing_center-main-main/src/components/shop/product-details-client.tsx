"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { Flame, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

type ProductImage = {
  id: string;
  url: string;
};

type ProductVariant = {
  id: string;
  type: string;
  value: string;
  priceDiff: number;
  stock: number;
  images: ProductImage[];
};

type RelatedProduct = {
  id: string;
  name: string;
  slug: string;
  price: number;
  offerPrice: number | null;
  stock: number;
  brand: string;
  accessorySortOrder: number;
  images: { url: string }[];
};

type Props = {
  product: {
    id: string;
    name: string;
    brand: string;
    modelCode: string | null;
    deviceStyle: string | null;
    hearingLossRange: string | null;
    batteryType: string | null;
    connectivity: string | null;
    isRechargeable: boolean;
    sku: string;
    description: string | null;
    shortDescription: string | null;
    longDescription: string | null;
    warranty: string | null;
    fittingRange: string | null;
    careGuide: string | null;
    keyFeatures: string[];
    specifications: Array<{ label: string; value: string }>;
    price: number;
    offerPrice: number | null;
    stock: number;
    isFeatured: boolean;
    isBestSelling?: boolean;
    categoryName: string | null;
    images: ProductImage[];
    variants: ProductVariant[];
  };
  relatedProducts?: RelatedProduct[];
  fallbackProducts?: RelatedProduct[];
  compatibilityGroupLabel?: string | null;
};

type CartResponse = {
  cart: {
    items: Array<{ productId: string; qty: number; variantId?: string | null }>;
  };
};

type ErrorResponse = { error: string };

function formatMoney(value: number): string {
  return `Tk ${new Intl.NumberFormat("en-BD").format(value)}`;
}

function isCartResponse(v: unknown): v is CartResponse {
  const o = v as Record<string, unknown>;
  const cart = o.cart as Record<string, unknown> | undefined;
  return !!cart && Array.isArray((cart as { items?: unknown }).items);
}

function overviewRows(product: Props["product"]) {
  return [
    { label: "Brand", value: product.brand },
    { label: "Model", value: product.modelCode },
    { label: "Style", value: product.deviceStyle },
    { label: "Category", value: product.categoryName },
    { label: "Hearing Loss Range", value: product.hearingLossRange },
    { label: "Battery", value: product.batteryType },
    { label: "Rechargeable", value: product.isRechargeable ? "Yes" : "No" },
    { label: "Connectivity", value: product.connectivity },
    { label: "Fitting Range", value: product.fittingRange },
    { label: "Warranty", value: product.warranty },
  ].filter(
    (item): item is { label: string; value: string } =>
      typeof item.value === "string" && item.value.trim().length > 0,
  );
}

function CompactAccessoryCard({ product }: { product: RelatedProduct }) {
  const finalPrice = product.offerPrice ?? product.price;
  const img = product.images[0]?.url;

  return (
    <Link
      href={`/products/${product.slug}`}
      className="group flex items-center gap-3 rounded-[16px] border border-[#ece7de] bg-white p-3 transition hover:-translate-y-0.5 hover:border-[#efbf7e] hover:shadow-[0_16px_36px_-28px_rgba(15,23,42,0.28)]"
    >
      <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-[14px] bg-[#f1efeb]">
        {img ? (
          <Image src={img} alt={product.name} fill className="object-contain p-2" sizes="64px" />
        ) : null}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[11px] font-medium uppercase tracking-[0.14em] text-[#8b5a2b]">
          {product.brand}
        </p>
        <h3 className="mt-1 line-clamp-2 text-sm font-semibold leading-5 text-[#334155]">
          {product.name}
        </h3>
        <p className="mt-1 text-sm font-bold text-[#e28a20]">Tk {finalPrice}</p>
      </div>
    </Link>
  );
}

const ZOOM_LENS_SIZE = 150;
const ZOOM_SCALE = 3;
const ZOOM_PANEL_WIDTH = 420;
const ZOOM_PANEL_HEIGHT = 420;

function getContainedImageRect(
  containerWidth: number,
  containerHeight: number,
  imageWidth: number,
  imageHeight: number,
) {
  if (
    containerWidth <= 0 ||
    containerHeight <= 0 ||
    imageWidth <= 0 ||
    imageHeight <= 0
  ) {
    return null;
  }

  const scale = Math.min(containerWidth / imageWidth, containerHeight / imageHeight);
  const width = imageWidth * scale;
  const height = imageHeight * scale;

  return {
    left: (containerWidth - width) / 2,
    top: (containerHeight - height) / 2,
    width,
    height,
  };
}

export default function ProductDetailsClient({
  product,
  relatedProducts = [],
  fallbackProducts = [],
  compatibilityGroupLabel = null,
}: Props) {
  const { toast } = useToast();

  const [qty, setQty] = useState(1);
  const [variantId, setVariantId] = useState<string | null>(
    product.variants[0]?.id ?? null,
  );
  const [loading, setLoading] = useState(false);

  const selectedVariant = useMemo(
    () => product.variants.find((v) => v.id === variantId) ?? null,
    [product.variants, variantId],
  );

  const basePrice = product.offerPrice ?? product.price;
  const unitPrice = basePrice + (selectedVariant?.priceDiff ?? 0);
  const compareAtPrice = product.price + (selectedVariant?.priceDiff ?? 0);
  const savedAmount =
    product.offerPrice && product.offerPrice < product.price
      ? compareAtPrice - unitPrice
      : 0;
  const currentStock = selectedVariant ? selectedVariant.stock : product.stock;
  const currentImages = selectedVariant?.images?.length
    ? selectedVariant.images
    : product.images;
  const badge = product.isFeatured && product.isBestSelling
    ? {
        label: "Recommended",
        className: "bg-[#ff4a3d] text-white",
      }
    : product.isFeatured
      ? {
          label: "Featured",
          className: "bg-[#cdd94b] text-[#4d5600]",
        }
      : product.isBestSelling
        ? {
            label: "Best Selling",
            className: "bg-[#ffe8e6] text-[#c73a2c]",
          }
        : null;

  const [activeImage, setActiveImage] = useState<string>(
    currentImages[0]?.url ?? product.images[0]?.url ?? "",
  );
  const [zoomState, setZoomState] = useState<{
    x: number;
    y: number;
    width: number;
    height: number;
    imageLeft: number;
    imageTop: number;
    imageWidth: number;
    imageHeight: number;
  } | null>(null);
  const [imageNaturalSize, setImageNaturalSize] = useState<{
    width: number;
    height: number;
  } | null>(null);
  const [mobileImagePreviewOpen, setMobileImagePreviewOpen] = useState(false);
  const zoomAreaRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (currentImages[0]?.url) {
      setActiveImage(currentImages[0].url);
    } else if (product.images[0]?.url) {
      setActiveImage(product.images[0].url);
    } else {
      setActiveImage("");
    }
  }, [currentImages, product.images]);

  useEffect(() => {
    setZoomState(null);
    setImageNaturalSize(null);
    setMobileImagePreviewOpen(false);
  }, [activeImage]);

  useEffect(() => {
    if (!activeImage || typeof window === "undefined") return;

    const probe = new window.Image();
    probe.src = activeImage;

    const setSize = () => {
      if (!probe.naturalWidth || !probe.naturalHeight) return;
      setImageNaturalSize({
        width: probe.naturalWidth,
        height: probe.naturalHeight,
      });
    };

    if (probe.complete) {
      setSize();
      return;
    }

    probe.onload = setSize;

    return () => {
      probe.onload = null;
    };
  }, [activeImage]);

  const canBuy = currentStock > 0;
  const detailsRows = useMemo(() => overviewRows(product), [product]);

  const dec = () => setQty((q) => Math.max(1, q - 1));
  const inc = () =>
    setQty((q) => Math.min(Math.max(1, currentStock || 1), q + 1));

  const addToCartApi = async (): Promise<void> => {
    const r = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "add",
        productId: product.id,
        variantId,
        qty,
      }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      const msg = (j as ErrorResponse | null)?.error || "Failed to add to cart";
      throw new Error(msg);
    }

    if (!isCartResponse(j)) return;
  };

  const onAdd = async (): Promise<void> => {
    if (!canBuy || loading) return;

    setLoading(true);
    try {
      await addToCartApi();
      window.dispatchEvent(new Event("rhc_cart_updated"));
      toast({
        variant: "success",
        title: "Added to cart",
        description: selectedVariant
          ? `${product.name} - ${selectedVariant.type}: ${selectedVariant.value} added successfully.`
          : `${product.name} added successfully.`,
      });
    } catch (e) {
      toast({
        variant: "error",
        title: "Failed",
        description: e instanceof Error ? e.message : "Failed to add to cart",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleZoomMove = (clientX: number, clientY: number) => {
    const area = zoomAreaRef.current;
    if (!area || !imageNaturalSize) return;

    const rect = area.getBoundingClientRect();
    const imageRect = getContainedImageRect(
      rect.width,
      rect.height,
      imageNaturalSize.width,
      imageNaturalSize.height,
    );
    if (!imageRect) return;

    const localX = clientX - rect.left;
    const localY = clientY - rect.top;

    if (
      localX < imageRect.left ||
      localX > imageRect.left + imageRect.width ||
      localY < imageRect.top ||
      localY > imageRect.top + imageRect.height
    ) {
      setZoomState(null);
      return;
    }

    const x = Math.max(
      imageRect.left,
      Math.min(localX, imageRect.left + imageRect.width),
    );
    const y = Math.max(
      imageRect.top,
      Math.min(localY, imageRect.top + imageRect.height),
    );

    setZoomState({
      x,
      y,
      width: rect.width,
      height: rect.height,
      imageLeft: imageRect.left,
      imageTop: imageRect.top,
      imageWidth: imageRect.width,
      imageHeight: imageRect.height,
    });
  };

  const clearZoom = () => {
    setZoomState(null);
  };

  const lensLeft = zoomState
    ? Math.min(
        Math.max(zoomState.x - ZOOM_LENS_SIZE / 2, zoomState.imageLeft),
        Math.max(zoomState.imageLeft + zoomState.imageWidth - ZOOM_LENS_SIZE, zoomState.imageLeft),
      )
    : 0;
  const lensTop = zoomState
    ? Math.min(
        Math.max(zoomState.y - ZOOM_LENS_SIZE / 2, zoomState.imageTop),
        Math.max(zoomState.imageTop + zoomState.imageHeight - ZOOM_LENS_SIZE, zoomState.imageTop),
      )
    : 0;
  const backgroundPosition = zoomState
    ? {
        backgroundPositionX: `${
          ((zoomState.x - zoomState.imageLeft) / zoomState.imageWidth) * 100
        }%`,
        backgroundPositionY: `${
          ((zoomState.y - zoomState.imageTop) / zoomState.imageHeight) * 100
        }%`,
        backgroundSize: `${zoomState.imageWidth * ZOOM_SCALE}px ${zoomState.imageHeight * ZOOM_SCALE}px`,
      }
    : undefined;

  return (
    <div className="grid gap-0 lg:grid-cols-12">
      <div className="space-y-6 lg:col-span-12 ">
        <div className="grid gap-6 xl:grid-cols-[1fr_0.9fr_1fr]">
          <Card className="overflow-hidden rounded-[18px] border border-[#ece7de] bg-white p-4 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.28)]">
            <div className="space-y-3">
              <div className="relative flex h-[420px] items-center justify-center overflow-hidden rounded-[16px] bg-[#f1efeb] sm:h-[520px] lg:h-[560px]">
                {badge ? (
                  <div
                    className={`absolute right-0 top-0 z-10 inline-flex items-center gap-1 rounded-bl-[14px] rounded-tr-[14px] px-3 py-2 text-[11px] font-semibold shadow-sm ${badge.className}`}
                  >
                    <Flame className="h-3.5 w-3.5" />
                    <span>{badge.label}</span>
                  </div>
                ) : null}
                {activeImage ? (
                  <div className="absolute inset-0 p-4">
                    <div
                      ref={zoomAreaRef}
                      className="relative flex h-full w-full items-center justify-center cursor-crosshair"
                      onPointerMove={(e) => {
                        if (e.pointerType === "mouse") {
                          handleZoomMove(e.clientX, e.clientY);
                        }
                      }}
                      onMouseEnter={(e) =>
                        handleZoomMove(e.clientX, e.clientY)
                      }
                      onMouseMove={(e) => handleZoomMove(e.clientX, e.clientY)}
                      onMouseLeave={clearZoom}
                      onClick={() => {
                        if (window.innerWidth < 768) {
                          setMobileImagePreviewOpen(true);
                        }
                      }}
                    >
                      <Image
                        src={activeImage}
                        alt={product.name}
                        width={imageNaturalSize?.width ?? 1600}
                        height={imageNaturalSize?.height ?? 1600}
                        priority
                        loading="eager"
                        className="h-auto max-h-full w-auto max-w-full object-contain object-center"
                        sizes="(max-width: 640px) 92vw, (max-width: 1280px) 56vw, 720px"
                        onLoad={(e) => {
                          const target = e.currentTarget;
                          setImageNaturalSize({
                            width: target.naturalWidth,
                            height: target.naturalHeight,
                          });
                        }}
                      />

                      {zoomState ? (
                        <div
                          className="pointer-events-none absolute overflow-hidden rounded-2xl border border-white/80 bg-white/10 shadow-[0_18px_40px_-24px_rgba(15,23,42,0.45)] ring-1 ring-black/10 backdrop-blur-[1px]"
                          style={{
                            left: `${lensLeft}px`,
                            top: `${lensTop}px`,
                            width: `${ZOOM_LENS_SIZE}px`,
                            height: `${ZOOM_LENS_SIZE}px`,
                          }}
                        >
                          <div className="absolute inset-0 border border-white/50" />
                        </div>
                      ) : null}

                      <div className="absolute bottom-3 right-3 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-semibold text-[#334155] shadow-sm ring-1 ring-black/5 md:hidden">
                        Tap to preview
                      </div>
                    </div>
                  </div>
                ) : (
                  <span className="text-sm text-[#94a3b8]">No image</span>
                )}
              </div>

              {currentImages.length > 1 ? (
                <div className="grid grid-cols-5 gap-2">
                  {currentImages.slice(0, 10).map((img, index) => (
                    <button
                      key={`${img.id}-${index}`}
                      type="button"
                      onClick={() => setActiveImage(img.url)}
                      className={`relative aspect-square overflow-hidden rounded-[14px] border bg-[#f1efeb] ${
                        activeImage === img.url
                          ? "border-[#e28a20] ring-2 ring-[#f2c996]"
                          : "border-[#e7dfd5]"
                      }`}
                    >
                      <Image
                        src={img.url}
                        alt={`${product.name} thumbnail ${index + 1}`}
                        fill
                        className="object-contain p-1.5"
                        sizes="120px"
                      />
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          </Card>

          {zoomState ? (
            <div className="pointer-events-none fixed left-1/2 top-1/2 z-[90] hidden -translate-x-1/2 -translate-y-1/2 md:block">
              <div className="overflow-hidden rounded-[28px] border border-[#eadfce] bg-white p-3 shadow-[0_35px_90px_-35px_rgba(15,23,42,0.38)]">
                <div className="mb-2 flex items-center justify-between gap-4 px-1">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8b5a2b]">
                    Zoom Preview
                  </p>
                  <p className="text-[11px] text-[#64748b]">
                    {Math.round(ZOOM_SCALE * 100)}%
                  </p>
                </div>
                <div
                  className="overflow-hidden rounded-[20px] border border-[#efe7dc] bg-[#f1efeb] bg-no-repeat"
                  style={{
                    width: `${ZOOM_PANEL_WIDTH}px`,
                    height: `${ZOOM_PANEL_HEIGHT}px`,
                    backgroundImage: `url(${activeImage})`,
                    ...backgroundPosition,
                  }}
                />
              </div>
            </div>
          ) : null}

          {mobileImagePreviewOpen && activeImage ? (
            <div className="fixed inset-0 z-[95] flex items-center justify-center bg-black/70 p-4 md:hidden">
              <div className="relative w-full max-w-md overflow-hidden rounded-[24px] border border-[#eadfce] bg-[#f1efeb] p-3 shadow-[0_35px_90px_-35px_rgba(15,23,42,0.38)]">
                <div className="mb-2 flex items-center justify-between gap-4 px-1">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8b5a2b]">
                    Image Preview
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setMobileImagePreviewOpen(false);
                    }}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-[#eadfce] text-[#334155]"
                    aria-label="Close image preview"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="relative aspect-[4/5] min-h-[360px] w-full overflow-hidden rounded-[18px] bg-[#f1efeb]">
                  <Image
                    src={activeImage}
                    alt={`${product.name} full preview`}
                    width={imageNaturalSize?.width ?? 1600}
                    height={imageNaturalSize?.height ?? 1600}
                    className="h-full w-full object-contain object-center"
                    sizes="(max-width: 768px) 92vw, 420px"
                  />
                </div>
              </div>
            </div>
          ) : null}

          {relatedProducts.length || fallbackProducts.length ? (
            <Card className="rounded-[18px] border border-[#ece7de] bg-white p-4 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.28)]">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8b5a2b]">
                  {relatedProducts.length ? "Compatibility Group" : "Same Category"}
                </p>
                <h2 className="mt-2 text-xl font-bold text-[#334155]">
                  {relatedProducts.length
                    ? "Compatible Accessories"
                    : "Related Accessories"}
                </h2>
                <p className="mt-2 text-sm text-[#64748b]">
                  {relatedProducts.length
                    ? compatibilityGroupLabel ||
                      "Products that share the same compatibility group as this item."
                    : "Similar active products from the same category."}
                </p>
              </div>

              <div className="mt-4 space-y-3">
                {(relatedProducts.length ? relatedProducts : fallbackProducts).map(
                  (item) => (
                    <CompactAccessoryCard key={item.id} product={item} />
                  ),
                )}
              </div>
            </Card>
          ) : null}

          <Card className="space-y-5 rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.28)]">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.16em] text-[#8b5a2b]">
                  {product.brand}
                  {product.categoryName ? ` / ${product.categoryName}` : ""}
                </p>
                <h1 className="text-2xl font-bold tracking-tight text-[#334155]">
                  {product.name}
                </h1>
                {product.shortDescription ? (
                  <p className="mt-2 text-sm leading-7 text-[#475569]">
                    {product.shortDescription}
                  </p>
                ) : null}
              </div>

              {badge ? (
                <span
                  className={`rounded-[8px] px-2.5 py-1 text-xs font-semibold ${badge.className}`}
                >
                  {badge.label}
                </span>
              ) : null}
            </div>

            <div>
              <p className="text-3xl font-bold text-[#e28a20]">
                {formatMoney(unitPrice)}
              </p>
              <div className="mt-1 flex flex-wrap items-center gap-3">
                {product.offerPrice ? (
                  <p className="text-sm text-[#9ca3af] line-through">
                    {formatMoney(compareAtPrice)}
                  </p>
                ) : null}
                {savedAmount > 0 ? (
                  <span className="inline-flex rounded-[8px] bg-[#cdd94b] px-2.5 py-1 text-xs font-semibold text-[#4d5600]">
                    Save {formatMoney(savedAmount)}
                  </span>
                ) : null}
              </div>
            </div>

            <div className="grid gap-2 sm:grid-cols-2">
              <div className="rounded-[14px] border border-[#f3dfbd] bg-[#fff7e8] p-3">
                <div className="text-xs font-medium text-[#8a5a15]">
                  Battery Type
                </div>
                <div className="mt-1 text-sm font-semibold text-[#334155]">
                  {product.batteryType || "Not added"}
                </div>
              </div>

              <div className="rounded-[14px] border border-[#d9e5fb] bg-[#f6f9ff] p-3">
                <div className="text-xs font-medium text-[#3c5d97]">
                  Rechargeable
                </div>
                <div className="mt-1 text-sm font-semibold text-[#334155]">
                  {product.isRechargeable ? "Rechargeable" : "Non Rechargeable"}
                </div>
              </div>
            </div>

            {product.variants.length ? (
              <div className="space-y-2">
                <p className="text-sm font-medium text-[#334155]">Variant</p>
                <select
                  className="h-11 w-full rounded-[14px] border border-[#e7dfd5] bg-white px-3 text-sm text-[#334155] outline-none transition focus:border-[#efbf7e]"
                  value={variantId ?? ""}
                  onChange={(e) => {
                    setVariantId(e.target.value);
                    setQty(1);
                  }}
                >
                  {product.variants.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.type}: {v.value}
                      {v.priceDiff ? ` (+${formatMoney(v.priceDiff)})` : ""}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}

            <div className="space-y-2">
              <p className="text-sm font-medium text-[#334155]">Quantity</p>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={dec}
                  className="h-9 w-9 rounded-[12px] border border-[#e7dfd5] bg-white text-[#334155] hover:bg-[#f8f5f0] disabled:opacity-50"
                  disabled={!canBuy || loading || qty <= 1}
                >
                  -
                </button>
                <span className="min-w-[2ch] text-center font-semibold text-[#334155]">
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={inc}
                  className="h-9 w-9 rounded-[12px] border border-[#e7dfd5] bg-white text-[#334155] hover:bg-[#f8f5f0] disabled:opacity-50"
                  disabled={
                    !canBuy || loading || qty >= Math.max(1, currentStock || 1)
                  }
                >
                  +
                </button>
              </div>
            </div>

            <Button
              className="w-full rounded-[14px] border border-[#efbf7e] bg-white text-[#d88a26] shadow-none hover:bg-[#fff8ee]"
              onClick={() => void onAdd()}
              disabled={!canBuy || loading}
            >
              {!canBuy ? "Out of Stock" : loading ? "Adding..." : "Add to Cart"}
            </Button>

            <div className="rounded-[14px] bg-[#f8f5f0] px-4 py-3 text-sm text-[#64748b]">
              SKU: {product.sku}
              {selectedVariant
                ? ` / Variant: ${selectedVariant.type} ${selectedVariant.value}`
                : ""}
              {canBuy ? ` / Stock: ${currentStock}` : " / Out of stock"}
            </div>
          </Card>
        </div>

        {product.shortDescription ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">
              Short Description
            </h2>
            <p className="mt-3 text-sm leading-7 text-[#475569]">
              {product.shortDescription}
            </p>
          </Card>
        ) : null}

        {product.longDescription ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">
              Long Description
            </h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-7 text-[#475569]">
              {product.longDescription}
            </p>
          </Card>
        ) : null}

        {detailsRows.length ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">
              Product Details
            </h2>
            <div className="mt-4 overflow-hidden rounded-[16px] border border-[#e7dfd5]">
              {detailsRows.map((item) => (
                <div
                  key={`${item.label}-${item.value}`}
                  className="grid gap-2 border-b border-[#efe8de] bg-white px-4 py-3 text-sm last:border-b-0 odd:bg-[#fffdfa] sm:grid-cols-[220px_1fr]"
                >
                  <div className="font-medium text-[#334155]">{item.label}</div>
                  <div className="text-[#475569]">{item.value}</div>
                </div>
              ))}
            </div>
          </Card>
        ) : null}

        {product.specifications.length ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">Specification</h2>
            <div className="mt-4 overflow-hidden rounded-[16px] border border-[#e7dfd5]">
              {product.specifications.map((item) => (
                <div
                  key={`${item.label}-${item.value}`}
                  className="grid gap-2 border-b border-[#efe8de] bg-white px-4 py-3 text-sm last:border-b-0 odd:bg-[#fffdfa] sm:grid-cols-[220px_1fr]"
                >
                  <div className="font-medium text-[#334155]">{item.label}</div>
                  <div className="text-[#475569]">{item.value}</div>
                </div>
              ))}
            </div>
          </Card>
        ) : null}

        {product.keyFeatures.length ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">Key Features</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {product.keyFeatures.map((item) => (
                <div
                  key={item}
                  className="rounded-[14px] border border-[#e7dfd5] bg-[#f8f5f0] px-4 py-3 text-sm text-[#475569]"
                >
                  {item}
                </div>
              ))}
            </div>
          </Card>
        ) : null}

        {product.careGuide ? (
          <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
            <h2 className="text-lg font-semibold text-[#334155]">Care Guide</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-7 text-[#475569]">
              {product.careGuide}
            </p>
          </Card>
        ) : null}
      </div>

      <div className="space-y-4 lg:col-span-12">
        <Card className="rounded-[18px] border border-[#ece7de] bg-white p-5 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.16)]">
          <div className="grid gap-4 lg:grid-cols-3">
            <div>
              <h2 className="text-lg font-semibold text-[#334155]">
                Delivery & Support
              </h2>
              <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-[#475569]">
                <li>Nationwide courier delivery available</li>
                <li>Phone consultation before choosing a device</li>
                <li>Fitting and after-sales support guidance</li>
                <li>Secure checkout for hearing devices and accessories</li>
              </ul>
            </div>

            {product.warranty ? (
              <div>
                <h2 className="text-lg font-semibold text-[#334155]">
                  Warranty
                </h2>
                <p className="mt-4 text-sm leading-7 text-[#475569]">
                  {product.warranty}
                </p>
              </div>
            ) : (
              <div />
            )}

            <div>
              <h2 className="text-lg font-semibold text-[#334155]">
                Battery & Power
              </h2>
              <div className="mt-4 space-y-3">
                <div className="rounded-[14px] border border-[#f3dfbd] bg-[#fff7e8] p-4">
                  <div className="text-xs font-medium text-[#8a5a15]">
                    Battery Type
                  </div>
                  <div className="mt-1 text-sm font-semibold text-[#334155]">
                    {product.batteryType || "Not added"}
                  </div>
                </div>
                <div className="rounded-[14px] border border-[#d9e5fb] bg-[#f6f9ff] p-4">
                  <div className="text-xs font-medium text-[#3c5d97]">
                    Rechargeable Status
                  </div>
                  <div className="mt-1 text-sm font-semibold text-[#334155]">
                    {product.isRechargeable ? "Rechargeable" : "Non Rechargeable"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
