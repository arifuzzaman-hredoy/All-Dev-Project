"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/toast";
import {
  normalizeHearingCatalogSettings,
  serializeLineList,
  type HearingCatalogSettings,
} from "@/lib/hearing-catalog";

type HearingCatalogForm = {
  deviceStyleOptions: string;
  hearingLossOptions: string;
  batteryTypeOptions: string;
  connectivityOptions: string;
};

function toFormState(settings: HearingCatalogSettings): HearingCatalogForm {
  return {
    deviceStyleOptions: serializeLineList(settings.deviceStyleOptions),
    hearingLossOptions: serializeLineList(settings.hearingLossOptions),
    batteryTypeOptions: serializeLineList(settings.batteryTypeOptions),
    connectivityOptions: serializeLineList(settings.connectivityOptions),
  };
}

export default function AdminHearingCatalogPage() {
  const { toast } = useToast();
  const [form, setForm] = useState<HearingCatalogForm | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/hearing-catalog", {
          cache: "no-store",
        });
        const json = await res.json().catch(() => null);

        if (!res.ok) {
          throw new Error(json?.message || "Could not load hearing catalog settings");
        }

        setForm(toFormState(normalizeHearingCatalogSettings(json?.settings)));
      } catch (error) {
        toast({
          variant: "error",
          title: "Failed",
          description:
            error instanceof Error
              ? error.message
              : "Could not load hearing catalog settings",
        });
        setForm(toFormState(normalizeHearingCatalogSettings(null)));
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [toast]);

  const save = async () => {
    if (!form) return;

    setSaving(true);
    try {
      const res = await fetch("/api/admin/hearing-catalog", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const json = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(json?.message || "Could not save hearing catalog settings");
      }

      setForm(toFormState(normalizeHearingCatalogSettings(json?.settings)));
      toast({
        variant: "success",
        title: "Saved",
        description: "Hearing catalog options updated successfully.",
      });
    } catch (error) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          error instanceof Error
            ? error.message
            : "Could not save hearing catalog settings",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading || !form) {
    return (
      <div className="grid gap-4">
        <div className="text-lg font-semibold">Hearing Catalog</div>
        <Card className="rounded-3xl p-6 text-sm text-black/60">
          Loading hearing catalog settings...
        </Card>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      <div>
        <div className="text-lg font-semibold">Hearing Catalog</div>
        <p className="mt-1 text-sm text-black/60">
          One option per line. These values will appear in the admin product form
          and public product filters.
        </p>
      </div>

      <Card className="rounded-3xl p-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium text-black/70">
              Device Style Options
            </label>
            <textarea
              value={form.deviceStyleOptions}
              onChange={(e) =>
                setForm({ ...form, deviceStyleOptions: e.target.value })
              }
              rows={10}
              className="min-h-52 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
              placeholder={"BTE\nRIC\nRITE"}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-black/70">
              Hearing Loss Options
            </label>
            <textarea
              value={form.hearingLossOptions}
              onChange={(e) =>
                setForm({ ...form, hearingLossOptions: e.target.value })
              }
              rows={10}
              className="min-h-52 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
              placeholder={"Mild\nModerate\nSevere"}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-black/70">
              Battery Type Options
            </label>
            <textarea
              value={form.batteryTypeOptions}
              onChange={(e) =>
                setForm({ ...form, batteryTypeOptions: e.target.value })
              }
              rows={10}
              className="min-h-52 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
              placeholder={"Rechargeable\nSize 10\nSize 13"}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-black/70">
              Connectivity Options
            </label>
            <textarea
              value={form.connectivityOptions}
              onChange={(e) =>
                setForm({ ...form, connectivityOptions: e.target.value })
              }
              rows={10}
              className="min-h-52 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
              placeholder={"Bluetooth\nTelecoil\nApp Control"}
            />
          </div>
        </div>

        <div className="mt-4 flex justify-end">
          <Button onClick={() => void save()} disabled={saving}>
            {saving ? "Saving..." : "Save Catalog Options"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
