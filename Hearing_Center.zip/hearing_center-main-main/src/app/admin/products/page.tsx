"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  ImagePlus,
  Pencil,
  Plus,
  RotateCcw,
  Save,
  Trash2,
  X,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { getCategoryDisplayPath } from "@/lib/category-tree";
import {
  DEFAULT_HEARING_CATALOG_SETTINGS,
  normalizeHearingCatalogSettings,
  parseLineList,
  parseSpecifications,
  serializeLineList,
  serializeSpecifications,
  type HearingCatalogSettings,
  type ProductSpecification,
} from "@/lib/hearing-catalog";
import {
  normalizeAccessorySortOrder,
  normalizeCompatibilityGroupKey,
} from "@/lib/product-compatibility";

function Modal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  React.useEffect(() => {
    if (!open) return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };

    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-130">
      <button
        type="button"
        aria-label="Close modal"
        onClick={onClose}
        className="absolute inset-0 bg-black/50"
      />
      <div className="absolute inset-0 flex items-start justify-center overflow-y-auto px-4 pt-20 pb-8 sm:px-6 sm:pt-24 sm:pb-10">
        <div className="w-full max-w-6xl">
          <div className="flex max-h-[calc(100dvh-7rem)] flex-col overflow-hidden rounded-3xl border border-black/10 bg-white shadow-xl">
            <div className="flex items-center justify-between gap-3 border-b border-black/10 px-5 py-4">
              <div className="text-sm font-semibold">{title}</div>
              <Button
                variant="secondary"
                onClick={onClose}
                className={neutralButtonClass}
              >
                <X className="h-4 w-4" />
                Close
              </Button>
            </div>

            <div className="flex-1 overflow-auto p-5">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

type Category = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  isActive: boolean;
  parent?: { id: string; name: string; slug: string } | null;
};

type VariantForm = {
  id?: string;
  type: string;
  value: string;
  priceDiff: number;
  stock: number;
  images: string[];
};

type Product = {
  id: string;
  name: string;
  sku: string;
  brand: string;
  modelCode?: string | null;
  deviceStyle?: string | null;
  hearingLossRange?: string | null;
  batteryType?: string | null;
  connectivity?: string | null;
  isRechargeable?: boolean;
  compatibilityGroupKey?: string | null;
  compatibilityGroupLabel?: string | null;
  accessorySortOrder?: number;
  description?: string | null;
  content?: {
    shortDescription?: string | null;
    longDescription?: string | null;
    warranty?: string | null;
    fittingRange?: string | null;
    careGuide?: string | null;
    keyFeatures?: string[] | null;
    specifications?: ProductSpecification[] | null;
  } | null;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured: boolean;
  isActive: boolean;
  categoryId: string;
  category: {
    id: string;
    name: string;
    slug: string;
    parent?: { id: string; name: string; slug: string } | null;
  } | null;
  images: { url: string }[];
  variants: Array<{
    id: string;
    type: string;
    value: string;
    priceDiff: number;
    stock: number;
    images: { url: string }[];
  }>;
  analytics?: {
    totalSoldQty: number;
    totalOrderCount: number;
    totalRevenue: number;
    activeCartQty: number;
    activeCartUsers: number;
  };
};

type UploadResponse = { url?: string; error?: string };

const ACCEPTED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

const MAX_IMAGE_SIZE = 25 * 1024 * 1024;

function formatMoney(amount: number | null | undefined): string {
  return `৳${Number(amount || 0)}`;
}

function validateImageFile(file: File): string | null {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    return "Only PNG, JPG, JPEG, and WEBP images are allowed.";
  }

  if (file.size > MAX_IMAGE_SIZE) {
    return "Each image must be 25MB or less.";
  }

  return null;
}

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);

  const res = await fetch("/api/upload/product-image", {
    method: "POST",
    body: fd,
  });

  const data: UploadResponse = await res.json().catch(() => ({}));

  if (!res.ok) throw new Error(data.error || "Upload failed");
  if (!data.url) throw new Error("Upload failed: missing image URL");

  return data.url;
}

const emptyVariantForm: VariantForm = {
  type: "Color",
  value: "",
  priceDiff: 0,
  stock: 0,
  images: [],
};

const VARIANT_EDITOR_ID = "variant-editor";

const actionButtonClass =
  "bg-blue-600 text-white hover:bg-blue-700 focus-visible:ring-blue-600";
const editButtonClass =
  "border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100 focus-visible:ring-amber-500";
const uploadButtonClass =
  "border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 focus-visible:ring-emerald-500";
const neutralButtonClass =
  "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 focus-visible:ring-slate-500";

function AdminProductsClient() {
  const LOW_STOCK_LIMIT = 5;

  const sp = useSearchParams();
  const filter = (sp.get("filter") || "").trim();

  const [categories, setCategories] = React.useState<Category[]>([]);
  const [items, setItems] = React.useState<Product[]>([]);
  const [loadingList, setLoadingList] = React.useState(false);

  const [listQuery, setListQuery] = React.useState("");

  const [showForm, setShowForm] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);

  const [name, setName] = React.useState("");
  const [brand, setBrand] = React.useState("Phonak");
  const [modelCode, setModelCode] = React.useState("");
  const [deviceStyle, setDeviceStyle] = React.useState("");
  const [hearingLossRange, setHearingLossRange] = React.useState("");
  const [batteryType, setBatteryType] = React.useState("");
  const [connectivity, setConnectivity] = React.useState("");
  const [isRechargeable, setIsRechargeable] = React.useState(false);
  const [compatibilityGroupKey, setCompatibilityGroupKey] = React.useState("");
  const [compatibilityGroupLabel, setCompatibilityGroupLabel] = React.useState("");
  const [accessorySortOrder, setAccessorySortOrder] = React.useState<number>(0);
  const [shortDescription, setShortDescription] = React.useState("");
  const [longDescription, setLongDescription] = React.useState("");
  const [warranty, setWarranty] = React.useState("");
  const [fittingRange, setFittingRange] = React.useState("");
  const [careGuide, setCareGuide] = React.useState("");
  const [keyFeaturesText, setKeyFeaturesText] = React.useState("");
  const [specificationsText, setSpecificationsText] = React.useState("");
  const [price, setPrice] = React.useState<number>(0);
  const [offerPrice, setOfferPrice] = React.useState<number>(0);
  const [stock, setStock] = React.useState<number>(0);
  const [categoryId, setCategoryId] = React.useState("");

  const [isFeatured, setIsFeatured] = React.useState(false);
  const [isActive, setIsActive] = React.useState(true);

  const [images, setImages] = React.useState<string[]>([]);
  const [uploading, setUploading] = React.useState(false);
  const [catalogOptions, setCatalogOptions] =
    React.useState<HearingCatalogSettings>(DEFAULT_HEARING_CATALOG_SETTINGS);
  const [saving, setSaving] = React.useState(false);
  const [formError, setFormError] = React.useState<string | null>(null);

  const [variants, setVariants] = React.useState<VariantForm[]>([]);
  const [variantDraft, setVariantDraft] =
    React.useState<VariantForm>(emptyVariantForm);
  const [variantEditIndex, setVariantEditIndex] = React.useState<number | null>(
    null,
  );
  const [variantUploading, setVariantUploading] = React.useState(false);

  const productFileRef = React.useRef<HTMLInputElement | null>(null);
  const variantFileRef = React.useRef<HTMLInputElement | null>(null);

  const { toast } = useToast();

  React.useEffect(() => {
    const loadCatalogOptions = async () => {
      try {
        const res = await fetch("/api/admin/hearing-catalog", {
          cache: "no-store",
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) return;
        setCatalogOptions(normalizeHearingCatalogSettings(json?.settings));
      } catch {
        // Keep built-in defaults if the settings are not available yet.
      }
    };

    void loadCatalogOptions();
  }, []);

  const mainCategories = React.useMemo(
    () => categories.filter((c) => !c.parentId && c.isActive),
    [categories],
  );
  const compatibilityGroupKeyOptions = React.useMemo(
    () =>
      Array.from(
        new Set(
          items
            .map((item) => item.compatibilityGroupKey?.trim())
            .filter((value): value is string => !!value),
        ),
      ).sort(),
    [items],
  );

  const load = React.useCallback(async () => {
    setLoadingList(true);

    try {
      const [cRes, pRes] = await Promise.all([
        fetch("/api/admin/categories", { cache: "no-store" }),
        fetch("/api/admin/products", { cache: "no-store" }),
      ]);

      const cRaw: unknown = await cRes.json().catch(() => []);
      const pRaw: unknown = await pRes.json().catch(() => []);

      setCategories(Array.isArray(cRaw) ? (cRaw as Category[]) : []);
      setItems(Array.isArray(pRaw) ? (pRaw as Product[]) : []);
    } catch {
      setCategories([]);
      setItems([]);
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not load products or categories.",
      });
    } finally {
      setLoadingList(false);
    }
  }, [toast]);

  React.useEffect(() => {
    void load();
  }, [load]);

  React.useEffect(() => {
    if (!categoryId && categories.length) {
      const firstActive = categories.find((c) => c.isActive);
      if (firstActive) setCategoryId(firstActive.id);
    }
  }, [categories, categoryId]);

  function resetForm() {
    setEditingId(null);
    setName("");
    setBrand("Phonak");
    setModelCode("");
    setDeviceStyle("");
    setHearingLossRange("");
    setBatteryType("");
    setConnectivity("");
    setIsRechargeable(false);
    setCompatibilityGroupKey("");
    setCompatibilityGroupLabel("");
    setAccessorySortOrder(0);
    setShortDescription("");
    setLongDescription("");
    setWarranty("");
    setFittingRange("");
    setCareGuide("");
    setKeyFeaturesText("");
    setSpecificationsText("");
    setPrice(0);
    setOfferPrice(0);
    setStock(0);
    setCategoryId(categories.find((c) => c.isActive)?.id || "");
    setIsFeatured(false);
    setIsActive(true);
    setImages([]);
    setVariants([]);
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    setFormError(null);

    if (productFileRef.current) productFileRef.current.value = "";
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function openCreate() {
    resetForm();
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditingId(null);
    setFormError(null);
    setVariantEditIndex(null);
    setVariantDraft(emptyVariantForm);

    if (productFileRef.current) productFileRef.current.value = "";
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function startEdit(product: Product) {
    setEditingId(product.id);
    setName(product.name);
    setBrand(product.brand ?? "Phonak");
    setModelCode(product.modelCode ?? "");
    setDeviceStyle(product.deviceStyle ?? "");
    setHearingLossRange(product.hearingLossRange ?? "");
    setBatteryType(product.batteryType ?? "");
    setConnectivity(product.connectivity ?? "");
    setIsRechargeable(!!product.isRechargeable);
    setCompatibilityGroupKey(product.compatibilityGroupKey ?? "");
    setCompatibilityGroupLabel(product.compatibilityGroupLabel ?? "");
    setAccessorySortOrder(product.accessorySortOrder ?? 0);
    setShortDescription(product.content?.shortDescription ?? "");
    setLongDescription(product.content?.longDescription ?? product.description ?? "");
    setWarranty(product.content?.warranty ?? "");
    setFittingRange(product.content?.fittingRange ?? "");
    setCareGuide(product.content?.careGuide ?? "");
    setKeyFeaturesText(serializeLineList(product.content?.keyFeatures ?? []));
    setSpecificationsText(
      serializeSpecifications(product.content?.specifications ?? []),
    );
    setPrice(product.price);
    setOfferPrice(product.offerPrice ?? 0);
    setStock(product.stock);
    setCategoryId(product.categoryId);
    setIsFeatured(product.isFeatured);
    setIsActive(product.isActive);
    setImages(product.images.map((img) => img.url));
    setVariants(
      product.variants.map((v) => ({
        id: v.id,
        type: v.type,
        value: v.value,
        priceDiff: v.priceDiff,
        stock: v.stock,
        images: v.images.map((img) => img.url),
      })),
    );
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    setFormError(null);
    setShowForm(true);
  }

  function moveImage(
    source: "product" | "variant",
    index: number,
    direction: "left" | "right",
  ) {
    const updater = (prev: string[]) => {
      const next = [...prev];
      const target = direction === "left" ? index - 1 : index + 1;

      if (target < 0 || target >= next.length) return prev;

      [next[index], next[target]] = [next[target], next[index]];
      return next;
    };

    if (source === "product") {
      setImages(updater);
    } else {
      setVariantDraft((prev) => ({
        ...prev,
        images: updater(prev.images),
      }));
    }
  }

  function removeProductImage(url: string) {
    setImages((prev) => prev.filter((x) => x !== url));
  }

  function removeVariantImage(url: string) {
    setVariantDraft((prev) => ({
      ...prev,
      images: prev.images.filter((x) => x !== url),
    }));
  }

  async function onPickProductFiles(files: FileList | null) {
    if (!files?.length) return;

    setFormError(null);
    setUploading(true);

    try {
      const list = Array.from(files);
      const validationErrors = list
        .map((file) => validateImageFile(file))
        .filter(Boolean) as string[];

      if (validationErrors.length) {
        throw new Error(validationErrors[0]);
      }

      const uploaded: string[] = [];

      for (const file of list) {
        const url = await uploadFile(file);
        uploaded.push(url);
      }

      setImages((prev) => [...prev, ...uploaded]);

      toast({
        title: "Uploaded",
        description: `${uploaded.length} shared product image uploaded successfully.`,
      });
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
      if (productFileRef.current) productFileRef.current.value = "";
    }
  }

  async function onPickVariantFiles(files: FileList | null) {
    if (!files?.length) return;

    setFormError(null);
    setVariantUploading(true);

    try {
      const list = Array.from(files);
      const validationErrors = list
        .map((file) => validateImageFile(file))
        .filter(Boolean) as string[];

      if (validationErrors.length) {
        throw new Error(validationErrors[0]);
      }

      const uploaded: string[] = [];

      for (const file of list) {
        const url = await uploadFile(file);
        uploaded.push(url);
      }

      setVariantDraft((prev) => ({
        ...prev,
        images: [...prev.images, ...uploaded],
      }));

      toast({
        title: "Uploaded",
        description: `${uploaded.length} variant image uploaded successfully.`,
      });
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setVariantUploading(false);
      if (variantFileRef.current) variantFileRef.current.value = "";
    }
  }

  function resetVariantDraft() {
    setVariantDraft(emptyVariantForm);
    setVariantEditIndex(null);
    if (variantFileRef.current) variantFileRef.current.value = "";
  }

  function saveVariantDraft() {
    setFormError(null);

    const value = variantDraft.value.trim();
    const type = variantDraft.type.trim();

    if (!type || !value) {
      setFormError("Variant type and value are required.");
      return;
    }

    if (variantDraft.stock < 0) {
      setFormError("Variant stock cannot be negative.");
      return;
    }

    const duplicate = variants.some((v, idx) => {
      if (variantEditIndex !== null && idx === variantEditIndex) return false;

      return (
        v.type.trim().toLowerCase() === type.toLowerCase() &&
        v.value.trim().toLowerCase() === value.toLowerCase()
      );
    });

    if (duplicate) {
      setFormError("This variant already exists.");
      return;
    }

    const payload: VariantForm = {
      id: variantDraft.id,
      type,
      value,
      priceDiff: Number(variantDraft.priceDiff) || 0,
      stock: Number(variantDraft.stock) || 0,
      images: variantDraft.images,
    };

    if (variantEditIndex !== null) {
      setVariants((prev) =>
        prev.map((item, idx) => (idx === variantEditIndex ? payload : item)),
      );
    } else {
      setVariants((prev) => [...prev, payload]);
    }

    resetVariantDraft();
  }

  function editVariant(index: number) {
    setVariantEditIndex(index);
    setVariantDraft(variants[index]);

    document.getElementById(VARIANT_EDITOR_ID)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }

  function removeVariant(index: number) {
    setVariants((prev) => prev.filter((_, i) => i !== index));

    if (variantEditIndex === index) {
      resetVariantDraft();
    }
  }

  async function save() {
    setFormError(null);

    if (!name.trim()) {
      setFormError("Product name is required.");
      return;
    }

    if (!categoryId) {
      setFormError("Category is required.");
      return;
    }

    if (price <= 0) {
      setFormError("Price must be greater than 0.");
      return;
    }

    if (stock < 0) {
      setFormError("Stock cannot be negative.");
      return;
    }

    if (offerPrice < 0) {
      setFormError("Offer price cannot be negative.");
      return;
    }

    if (offerPrice > 0 && offerPrice >= price) {
      setFormError("Offer price should be less than regular price.");
      return;
    }

    if (images.length === 0) {
      setFormError("At least one shared product image is required.");
      return;
    }

    const body = {
      name: name.trim(),
      description: longDescription.trim() ? longDescription.trim() : null,
      brand: brand.trim() || "Phonak",
      modelCode: modelCode.trim() ? modelCode.trim() : null,
      deviceStyle: deviceStyle || null,
      hearingLossRange: hearingLossRange || null,
      batteryType: batteryType || null,
      connectivity: connectivity || null,
      isRechargeable,
      compatibilityGroupKey: normalizeCompatibilityGroupKey(
        compatibilityGroupKey,
      ),
      compatibilityGroupLabel: compatibilityGroupLabel.trim()
        ? compatibilityGroupLabel.trim()
        : null,
      accessorySortOrder: normalizeAccessorySortOrder(accessorySortOrder),
      shortDescription: shortDescription.trim()
        ? shortDescription.trim()
        : null,
      longDescription: longDescription.trim() ? longDescription.trim() : null,
      warranty: warranty.trim() ? warranty.trim() : null,
      fittingRange: fittingRange.trim() ? fittingRange.trim() : null,
      careGuide: careGuide.trim() ? careGuide.trim() : null,
      keyFeatures: parseLineList(keyFeaturesText),
      specifications: parseSpecifications(specificationsText),
      price: Number(price),
      offerPrice: offerPrice > 0 ? Number(offerPrice) : null,
      stock: Number(stock),
      categoryId,
      isFeatured,
      isActive,
      images,
      variants,
    };

    const url = editingId
      ? `/api/admin/products/${editingId}`
      : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";

    setSaving(true);

    try {
      const res = await fetch(url, {
        method,
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

      const d: unknown = await res.json().catch(() => ({}));

      if (!res.ok) {
        const msg =
          (d as { error?: string })?.error || "Save failed. Please try again.";
        setFormError(msg);
        return;
      }

      toast({
        title: editingId ? "Updated" : "Created",
        description: editingId
          ? "Product updated successfully."
          : "Product created successfully.",
      });

      closeForm();
      await load();
    } catch {
      setFormError("Save failed. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    const ok = window.confirm("Delete this product?");
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Delete failed",
        });
        return;
      }

      toast({
        title: "Deleted",
        description: "Product deleted successfully.",
      });

      if (editingId === id) closeForm();
      await load();
    } catch {
      toast({
        variant: "error",
        title: "Delete failed",
      });
    }
  }

  const filteredItems = React.useMemo(() => {
    const q = listQuery.trim().toLowerCase();

    const isLowStock = (p: Product) => {
      if (p.stock <= LOW_STOCK_LIMIT) return true;
      if (Array.isArray(p.variants) && p.variants.length) {
        return p.variants.some((v) => v.stock <= LOW_STOCK_LIMIT);
      }
      return false;
    };

    let out = items;

    if (filter === "low_stock") {
      out = out.filter(isLowStock);
    }

    if (q) {
      out = out.filter((p) => {
        const nameHit = p.name.toLowerCase().includes(q);
        const skuHit = p.sku.toLowerCase().includes(q);
        const catHit = [p.category?.parent?.name, p.category?.name]
          .filter(Boolean)
          .join(" → ")
          .toLowerCase()
          .includes(q);

        return nameHit || skuHit || catHit;
      });
    }

    return out;
  }, [items, listQuery, filter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Products</h1>
          <p className="mt-1 text-sm text-black/70">
            Browse, filter and manage products.
          </p>
        </div>

        <Button onClick={openCreate} className={actionButtonClass}>
          <Plus className="h-4 w-4" />
          Add Product
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">
              {filter === "low_stock" ? "Low Stock Products" : "All Products"}
            </div>
            <div className="mt-1 text-xs text-black/60">
              Showing {filteredItems.length} of {items.length}
              {filter === "low_stock"
                ? ` • Stock ≤ ${LOW_STOCK_LIMIT} (product OR variants)`
                : null}
              {loadingList ? " • Loading..." : null}
            </div>
          </div>

        </div>

        <div className="mt-4 flex items-center gap-2 overflow-x-auto">
          <Input
            className="min-w-0 flex-1"
            value={listQuery}
            onChange={(e) => setListQuery(e.target.value)}
            placeholder="Search by name / SKU / category"
          />

          <Link
            href="/admin/products"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              filter === "low_stock"
                ? "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                : "bg-blue-600 text-white hover:bg-blue-700"
            }`}
          >
            All
          </Link>

          <Link
            href="/admin/products?filter=low_stock"
            className={`inline-flex h-10 shrink-0 items-center justify-center rounded-2xl px-4 text-sm transition ${
              filter === "low_stock"
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            Low Stock
          </Link>
        </div>

        <div className="mt-3 space-y-2">
          {filteredItems.map((p) => {
            const isLow =
              p.stock <= LOW_STOCK_LIMIT ||
              (p.variants?.some((v) => v.stock <= LOW_STOCK_LIMIT) ?? false);

            const categoryLabel = p.category
              ? [p.category.parent?.name, p.category.name]
                  .filter(Boolean)
                  .join(" → ")
              : "Uncategorized";

            return (
              <div
                key={p.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-black/10 bg-white/60 px-3 py-3"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <div className="relative h-14 w-14 overflow-hidden rounded-xl bg-black/5">
                    {p.images?.[0]?.url ? (
                      <Image
                        src={p.images[0].url}
                        alt={p.name}
                        fill
                        className="object-cover"
                        sizes="56px"
                      />
                    ) : null}
                  </div>

                  <div className="text-sm">
                    <div className="flex flex-wrap items-center gap-2 font-medium">
                      {p.name}
                      {!p.isActive ? (
                        <span className="text-xs text-red-600">(Inactive)</span>
                      ) : null}
                      {p.isFeatured ? (
                        <span className="text-xs text-black/60">
                          (Featured)
                        </span>
                      ) : null}
                    </div>

                    <div className="text-xs text-black/60">
                      {categoryLabel} • SKU: {p.sku} • Price:{" "}
                      {formatMoney(p.price)} • Stock: {p.stock}
                      {p.offerPrice ? (
                        <> • Offer: {formatMoney(p.offerPrice)}</>
                      ) : null}
                    </div>

                    <div className="mt-1 flex flex-wrap gap-2 text-[11px] text-black/70">
                      <span className="rounded-full bg-[#eef6ff] px-2.5 py-1 text-[#245b8f]">
                        Sold: {p.analytics?.totalSoldQty ?? 0}
                      </span>
                      <span className="rounded-full bg-[#f5efe6] px-2.5 py-1 text-[#8b5a2b]">
                        Orders: {p.analytics?.totalOrderCount ?? 0}
                      </span>
                      <span className="rounded-full bg-[#eef7e8] px-2.5 py-1 text-[#3f6b20]">
                        In carts: {p.analytics?.activeCartQty ?? 0}
                      </span>
                      <span className="rounded-full bg-[#fff4e8] px-2.5 py-1 text-[#d88a26]">
                        Cart users: {p.analytics?.activeCartUsers ?? 0}
                      </span>
                      <span className="rounded-full bg-[#f3f1fb] px-2.5 py-1 text-[#5b4b96]">
                        Revenue: {formatMoney(p.analytics?.totalRevenue ?? 0)}
                      </span>
                    </div>

                    {isLow ? (
                      <div className="mt-1 text-xs text-red-600">
                        Low stock (≤ {LOW_STOCK_LIMIT})
                        {p.variants?.some((v) => v.stock <= LOW_STOCK_LIMIT)
                          ? " • includes variant stock"
                          : ""}
                      </div>
                    ) : null}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => startEdit(p)}
                    className={editButtonClass}
                  >
                    <Pencil className="h-4 w-4" />
                    Edit Product
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => void remove(p.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete
                  </Button>
                </div>
              </div>
            );
          })}

          {!filteredItems.length ? (
            <div className="text-sm text-black/60">
              {filter === "low_stock"
                ? "No low stock products."
                : "No products yet."}
            </div>
          ) : null}
        </div>
      </Card>

      <Modal
        open={showForm}
        title={editingId ? "Edit Product" : "Add Product"}
        onClose={closeForm}
      >
        <div className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Product Name *
              </label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Digital Hearing Aid"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Category *
              </label>
              <select
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
              >
                {mainCategories.map((parent) => {
                  const children = categories.filter(
                    (c) => c.parentId === parent.id && c.isActive,
                  );

                  return (
                    <optgroup key={parent.id} label={parent.name}>
                      <option value={parent.id}>{parent.name}</option>
                      {children.map((child) => (
                        <option key={child.id} value={child.id}>
                          {parent.name} → {child.name}
                        </option>
                      ))}
                    </optgroup>
                  );
                })}
              </select>

              {categoryId ? (
                <div className="text-xs text-black/50">
                  Selected: {getCategoryDisplayPath(categoryId, categories)}
                </div>
              ) : null}
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Short Description
              </label>
              <Input
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
                placeholder="Brief summary for product card and details"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">Brand</label>
              <Input
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="Phonak"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Model Code
              </label>
              <Input
                value={modelCode}
                onChange={(e) => setModelCode(e.target.value)}
                placeholder="e.g. Audeo L90-R"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Compatibility Group Key
              </label>
              <Input
                list="compatibility-group-key-options"
                value={compatibilityGroupKey}
                onChange={(e) => setCompatibilityGroupKey(e.target.value)}
                onBlur={(e) =>
                  setCompatibilityGroupKey(
                    normalizeCompatibilityGroupKey(e.target.value) ?? "",
                  )
                }
                placeholder="e.g. phonak-audeo-l70"
              />
              <datalist id="compatibility-group-key-options">
                {compatibilityGroupKeyOptions.map((option) => (
                  <option key={option} value={option} />
                ))}
              </datalist>
              <p className="text-[11px] text-black/50">
                Use the same slug-style key on multiple products to group
                compatible accessories together.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Compatibility Group Label
              </label>
              <Input
                value={compatibilityGroupLabel}
                onChange={(e) => setCompatibilityGroupLabel(e.target.value)}
                placeholder="e.g. Phonak Audeo L70 Accessories"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Accessory Sort Order
              </label>
              <Input
                type="number"
                min={0}
                value={accessorySortOrder}
                onChange={(e) =>
                  setAccessorySortOrder(Number(e.target.value) || 0)
                }
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Device Style
              </label>
              <select
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                value={deviceStyle}
                onChange={(e) => setDeviceStyle(e.target.value)}
              >
                <option value="">Select style</option>
                {catalogOptions.deviceStyleOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Hearing Loss Range
              </label>
              <select
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                value={hearingLossRange}
                onChange={(e) => setHearingLossRange(e.target.value)}
              >
                <option value="">Select range</option>
                {catalogOptions.hearingLossOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Battery Type
              </label>
              <select
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                value={batteryType}
                onChange={(e) => setBatteryType(e.target.value)}
              >
                <option value="">Select battery type</option>
                {catalogOptions.batteryTypeOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Connectivity
              </label>
              <select
                className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                value={connectivity}
                onChange={(e) => setConnectivity(e.target.value)}
              >
                <option value="">Select connectivity</option>
                {catalogOptions.connectivityOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Long Description
              </label>
              <textarea
                value={longDescription}
                onChange={(e) => setLongDescription(e.target.value)}
                className="min-h-28 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
                placeholder="Write details about the product..."
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Warranty
              </label>
              <Input
                value={warranty}
                onChange={(e) => setWarranty(e.target.value)}
                placeholder="e.g. 1 Year Service Warranty"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Fitting Range
              </label>
              <Input
                value={fittingRange}
                onChange={(e) => setFittingRange(e.target.value)}
                placeholder="e.g. Mild to Severe hearing loss"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Key Features
              </label>
              <textarea
                value={keyFeaturesText}
                onChange={(e) => setKeyFeaturesText(e.target.value)}
                className="min-h-28 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
                placeholder={"One feature per line\nBluetooth streaming\nNoise reduction\nRechargeable"}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Specifications
              </label>
              <textarea
                value={specificationsText}
                onChange={(e) => setSpecificationsText(e.target.value)}
                className="min-h-28 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
                placeholder={"One per line using Label: Value\nStyle: RIC\nChannels: 16\nBattery: Rechargeable"}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-medium text-black/70">
                Care Guide
              </label>
              <textarea
                value={careGuide}
                onChange={(e) => setCareGuide(e.target.value)}
                className="min-h-24 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-sm outline-none"
                placeholder="Cleaning, storage, moisture care and daily handling notes"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Price (BDT) *
              </label>
              <Input
                type="number"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Offer Price
              </label>
              <Input
                type="number"
                value={offerPrice}
                onChange={(e) => setOfferPrice(Number(e.target.value))}
              />
              <div className="text-[11px] text-black/50">
                Set 0 to disable offer price.
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-black/70">
                Stock *
              </label>
              <Input
                type="number"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
              />
              {stock <= LOW_STOCK_LIMIT ? (
                <div className="text-xs text-red-600">
                  Low stock (≤ {LOW_STOCK_LIMIT})
                </div>
              ) : (
                <div className="text-xs text-black/50">
                  Stock looks healthy.
                </div>
              )}
            </div>

            <div className="flex items-center gap-6 md:col-span-3">
              <label className="flex items-center gap-2 text-sm text-black/70">
                <input
                  type="checkbox"
                  checked={isRechargeable}
                  onChange={(e) => setIsRechargeable(e.target.checked)}
                />
                Rechargeable
              </label>

              <label className="flex items-center gap-2 text-sm text-black/70">
                <input
                  type="checkbox"
                  checked={isFeatured}
                  onChange={(e) => setIsFeatured(e.target.checked)}
                />
                Featured
              </label>

              <label className="flex items-center gap-2 text-sm text-black/70">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                />
                Active
              </label>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">
                  Shared Product Images *
                </div>
                <div className="text-xs text-black/60">
                  এগুলো সব variant-এর fallback/shared image হিসেবে কাজ করবে।
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={productFileRef}
                  type="file"
                  multiple
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  className="hidden"
                  onChange={(e) => void onPickProductFiles(e.target.files)}
                  disabled={uploading || saving}
                />
                <Button
                  variant="secondary"
                  onClick={() => productFileRef.current?.click()}
                  disabled={uploading || saving}
                  className={uploadButtonClass}
                >
                  <ImagePlus className="h-4 w-4" />
                  {uploading ? "Uploading..." : "Upload Shared Images"}
                </Button>
              </div>
            </div>

            {images.length ? (
              <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
                {images.map((url, index) => (
                  <div
                    key={`${url}-${index}`}
                    className="space-y-2 rounded-2xl border border-black/10 bg-white/60 p-3"
                  >
                    <div className="relative aspect-square overflow-hidden rounded-xl bg-black/5">
                      <Image
                        src={url}
                        alt={`Product image ${index + 1}`}
                        fill
                        className="object-cover"
                        sizes="220px"
                      />
                    </div>

                    <div className="truncate text-[10px] text-black/60">
                      {url}
                    </div>

                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => moveImage("product", index, "left")}
                        disabled={index === 0}
                        className={neutralButtonClass}
                      >
                        <ArrowLeft className="h-4 w-4" />

                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => moveImage("product", index, "right")}
                        disabled={index === images.length - 1}
                        className={neutralButtonClass}
                      >
                        <ArrowRight className="h-4 w-4" />
                    
                      </Button>
                      <Button
                        type="button"
                        variant="danger"
                        size="sm"
                        onClick={() => removeProductImage(url)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-black/60">
                No shared product images uploaded yet.
              </div>
            )}
          </div>

          <div
            id={VARIANT_EDITOR_ID}
            className="scroll-mt-4 space-y-4 rounded-3xl border border-black/10 p-4"
          >
            <div>
              <div className="text-sm font-semibold">Variant Editor</div>
              <div className="text-xs text-black/60">
                Variant image না দিলে shared product images use হবে।
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-4">
              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Type</div>
                <select
                  className="h-11 w-full rounded-2xl border border-black/10 bg-white/70 px-4 text-sm outline-none"
                  value={variantDraft.type}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      type: e.target.value,
                    }))
                  }
                >
                  <option value="Color">Color</option>
                  <option value="Size">Size</option>
                  <option value="Model">Model</option>
                  <option value="Measurement">Measurement</option>
                </select>
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Value</div>
                <Input
                  value={variantDraft.value}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      value: e.target.value,
                    }))
                  }
                  placeholder="e.g. Red / XL / M-01 / 2 ml / 500 ml / 1 kg"
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">
                  Additional Price (BDT)
                </div>
                <Input
                  type="number"
                  value={variantDraft.priceDiff}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      priceDiff: Number(e.target.value),
                    }))
                  }
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-medium text-black/70">Stock</div>
                <Input
                  type="number"
                  value={variantDraft.stock}
                  onChange={(e) =>
                    setVariantDraft((prev) => ({
                      ...prev,
                      stock: Number(e.target.value),
                    }))
                  }
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <div className="text-sm font-medium">Variant Images</div>
                  <div className="text-xs text-black/60">
                    Optional. Empty থাকলে shared product images use হবে।
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    ref={variantFileRef}
                    type="file"
                    multiple
                    accept="image/png,image/jpeg,image/jpg,image/webp"
                    className="hidden"
                    onChange={(e) => void onPickVariantFiles(e.target.files)}
                    disabled={variantUploading || saving}
                  />
                  <Button
                    variant="secondary"
                    onClick={() => variantFileRef.current?.click()}
                    disabled={variantUploading || saving}
                    className={uploadButtonClass}
                  >
                    <ImagePlus className="h-4 w-4" />
                    {variantUploading
                      ? "Uploading..."
                      : "Upload Variant Images"}
                  </Button>
                </div>
              </div>

              {variantDraft.images.length ? (
                <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
                  {variantDraft.images.map((url, index) => (
                    <div
                      key={`${url}-${index}`}
                      className="space-y-2 rounded-2xl border border-black/10 bg-white/60 p-3"
                    >
                      <div className="relative aspect-square overflow-hidden rounded-xl bg-black/5">
                        <Image
                          src={url}
                          alt={`Variant image ${index + 1}`}
                          fill
                          className="object-cover"
                          sizes="220px"
                        />
                      </div>

                      <div className="truncate text-[10px] text-black/60">
                        {url}
                      </div>

                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="secondary"
                          size="sm"
                          onClick={() => moveImage("variant", index, "left")}
                          disabled={index === 0}
                          className={neutralButtonClass}
                        >
                          <ArrowLeft className="h-4 w-4" />
                          Move Left
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          size="sm"
                          onClick={() => moveImage("variant", index, "right")}
                          disabled={index === variantDraft.images.length - 1}
                          className={neutralButtonClass}
                        >
                          <ArrowRight className="h-4 w-4" />
                          Move Right
                        </Button>
                        <Button
                          type="button"
                          variant="danger"
                          size="sm"
                          onClick={() => removeVariantImage(url)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-black/60">
                  No variant-specific images. Shared product images will be
                  used.
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                onClick={saveVariantDraft}
                className={actionButtonClass}
              >
                <Save className="h-4 w-4" />
                {variantEditIndex !== null ? "Update Variant" : "Add Variant"}
              </Button>

              {variantEditIndex !== null ? (
                <Button
                  variant="secondary"
                  onClick={resetVariantDraft}
                  className={neutralButtonClass}
                >
                  <RotateCcw className="h-4 w-4" />
                  Cancel Variant Edit
                </Button>
              ) : null}
            </div>

            {variants.length ? (
              <div className="grid gap-3">
                {variants.map((variant, index) => (
                  <div
                    key={`${variant.id ?? "new"}-${variant.type}-${variant.value}-${index}`}
                    className="rounded-2xl border border-black/10 p-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold">
                          {variant.type}: {variant.value}
                        </div>
                        <div className="text-xs text-black/60">
                          Price diff: ৳ {variant.priceDiff} • Stock:{" "}
                          {variant.stock}
                        </div>
                        <div className="mt-1 text-xs text-black/60">
                          {variant.images.length
                            ? `Own images: ${variant.images.length}`
                            : "Uses shared product images"}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => editVariant(index)}
                          className={editButtonClass}
                        >
                          <Pencil className="h-4 w-4" />
                          Edit
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={() => removeVariant(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Remove
                        </Button>
                      </div>
                    </div>

                    {variant.images.length ? (
                      <div className="mt-3 grid gap-2 sm:grid-cols-4">
                        {variant.images.map((img, idx) => (
                          <div
                            key={`${img}-${idx}`}
                            className="relative aspect-square overflow-hidden rounded-xl bg-black/5"
                          >
                            <Image
                              src={img}
                              alt={`${variant.value}-${idx}`}
                              fill
                              className="object-cover"
                              sizes="160px"
                            />
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-black/60">
                No variants added yet.
              </div>
            )}
          </div>

          {formError ? (
            <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {formError}
            </div>
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-xs text-black/60">
              Fill the form and press {editingId ? "Update" : "Create"}.
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                onClick={closeForm}
                disabled={saving}
                className={neutralButtonClass}
              >
                <X className="h-4 w-4" />
                Cancel
              </Button>
              <Button
                onClick={() => void save()}
                disabled={saving || uploading || variantUploading}
                className={actionButtonClass}
              >
                <Save className="h-4 w-4" />
                {saving ? "Saving..." : editingId ? "Update" : "Create"}
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default function AdminProductsPage() {
  return (
    <React.Suspense
      fallback={
        <div className="rounded-3xl border border-black/10 bg-white p-6 text-sm text-black/60">
          Loading products...
        </div>
      }
    >
      <AdminProductsClient />
    </React.Suspense>
  );
}
