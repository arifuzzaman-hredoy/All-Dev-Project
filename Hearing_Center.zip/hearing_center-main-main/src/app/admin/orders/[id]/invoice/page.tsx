import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import InvoicePrintButton from "@/components/admin/orders/invoice-print-button";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export default async function AdminInvoicePage({
  params,
}: {
  params: Promise<{ id?: string }> | { id?: string };
}) {
  const p = params instanceof Promise ? await params : params;
  const id = p?.id;

  if (!isNonEmptyString(id)) return notFound();

  const order = await prisma.order.findUnique({
    where: { id },
    include: { items: true },
  });

  if (!order) return notFound();

  return (
    <div className="mx-auto w-4xl print:w-5xl p-6 print:p-0">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>

      <div className="no-print mb-4 flex items-center justify-between">
        <div className="text-lg font-semibold">Invoice</div>

        <div className="flex gap-2">
          <Link
            href={`/admin/orders/${order.id}`}
            className="rounded-xl border border-black/10 px-4 py-2 text-sm hover:bg-black/5"
          >
            Back
          </Link>
          <InvoicePrintButton />
        </div>
      </div>

      <div className="rounded-2xl border border-black/10 p-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xl font-bold">Rangpur Hearing Center</div>
            <div className="text-sm text-black/60">siamsbay.com</div>
          </div>

          <div className="text-right text-sm">
            <div className="font-semibold">Order #{order.id}</div>
            <div className="text-black/60">{order.createdAt.toLocaleString()}</div>
          </div>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <div className="text-sm">
            <div className="text-xs font-semibold text-black/60">Bill to</div>
            <div className="mt-1 font-semibold">{order.name}</div>
            <div>{order.phone}</div>

            <div className="mt-1 text-black/70">
              {order.addressLine1}
              {order.addressLine2 ? `, ${order.addressLine2}` : ""}
              {`, ${order.city}`}
              {order.area ? `, ${order.area}` : ""}
            </div>
          </div>

          <div className="text-sm">
            <div className="text-xs font-semibold text-black/60">Shipping</div>

            <div className="mt-1 text-black/70">
              Courier: {order.courierName ?? "—"}
              <br />
              Tracking: {order.trackingId ?? "—"}
            </div>

            <div className="mt-2 text-xs text-black/60">
              Payment: {order.paymentMethod} • {order.paymentStatus}
            </div>
          </div>
        </div>

        <div className="mt-6 overflow-hidden rounded-xl border border-black/10">
          <table className="w-full text-sm">
            <thead className="bg-black/5">
              <tr>
                <th className="px-3 py-2 text-left">Item</th>
                <th className="px-3 py-2 text-right">Unit</th>
                <th className="px-3 py-2 text-right">Qty</th>
                <th className="px-3 py-2 text-right">Total</th>
              </tr>
            </thead>

            <tbody>
              {order.items.map((it) => (
                <tr key={it.id} className="border-t border-black/10">
                  <td className="px-3 py-2">
                    <div className="font-semibold">{it.productName}</div>
                    <div className="text-xs text-black/60">SKU: {it.sku}</div>
                  </td>
                  <td className="px-3 py-2 text-right">৳ {it.unitPrice}</td>
                  <td className="px-3 py-2 text-right">{it.qty}</td>
                  <td className="px-3 py-2 text-right font-semibold">
                    ৳ {it.lineTotal}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-5 grid gap-2 text-sm md:ml-auto md:w-72">
          <div className="flex justify-between">
            <span className="text-black/60">Subtotal</span>
            <span>৳ {order.subtotal}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-black/60">Discount</span>
            <span>৳ {order.discount}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-black/60">Shipping</span>
            <span>৳ {order.shipping}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-black/60">Tax</span>
            <span>৳ {order.tax}</span>
          </div>

          <div className="mt-2 flex justify-between border-t border-black/10 pt-3">
            <span className="font-semibold">Total</span>
            <span className="font-semibold">৳ {order.total}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
