"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

type Banner = {
  id: string;
  slot: string | null;
  imageUrl: string;
  isActive: boolean;
};

type BannersResponse = {
  banners: Banner[];
};

type UploadResponse = {
  url?: string;
  error?: string;
};

const ACCEPTED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

const MAX_IMAGE_SIZE = 25 * 1024 * 1024;

function safeString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function parseBannersResponse(input: unknown): BannersResponse {
  const obj = input as { banners?: unknown };
  const raw = Array.isArray(obj?.banners) ? obj.banners : [];

  const banners: Banner[] = raw
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      slot: typeof item.slot === "string" ? item.slot : null,
      imageUrl: safeString(item.imageUrl),
      isActive: item.isActive === true,
    }))
    .filter((banner) => banner.id && banner.imageUrl);

  return { banners };
}

function validateBannerImageFile(file: File): string | null {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    return "Only PNG, JPG, JPEG, and WEBP images are allowed.";
  }

  if (file.size > MAX_IMAGE_SIZE) {
    return "Image must be 25MB or less.";
  }

  return null;
}

async function uploadBannerImage(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);

  const response = await fetch("/api/upload/banner-image", {
    method: "POST",
    body: fd,
  });

  const data: UploadResponse = await response
    .json()
    .catch(() => ({}) as UploadResponse);

  if (!response.ok) {
    throw new Error(data.error || "Upload failed");
  }

  if (!data.url) {
    throw new Error("Upload failed: missing image URL");
  }

  return data.url;
}

export default function AdminBannersPage() {
  const [items, setItems] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(false);
  const [savingBannerId, setSavingBannerId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const fileRef = useRef<HTMLInputElement | null>(null);
  const { toast } = useToast();

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/banners", { cache: "no-store" });
      const json: unknown = await response.json();
      const parsed = parseBannersResponse(json);
      setItems(parsed.banners);
    } catch {
      setItems([]);
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not load banner images.",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void load();
  }, [load]);

  const createBanner = useCallback(
    async (imageUrl: string): Promise<void> => {
      setIsUploading(true);
      setFormError(null);

      try {
        const response = await fetch("/api/admin/banners", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageUrl,
            title: "Homepage banner",
            isActive: true,
            sortOrder: items.length,
          }),
        });

        const json = await response
          .json()
          .catch(() => ({}) as { message?: string });

        if (!response.ok) {
          throw new Error(json?.message || "Save failed");
        }

        toast({
          title: "Uploaded",
          description: "Banner added to the homepage slideshow.",
        });

        await load();
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Banner save failed";
        setFormError(message);
        toast({
          variant: "error",
          title: "Save failed",
          description: message,
        });
      } finally {
        setIsUploading(false);
      }
    },
    [items.length, load, toast],
  );

  const removeBanner = useCallback(
    async (banner: Banner): Promise<void> => {
      const ok = confirm("Remove this banner?");
      if (!ok) return;

      setSavingBannerId(banner.id);
      setFormError(null);

      try {
        const response = await fetch(
          `/api/admin/banners?id=${encodeURIComponent(banner.id)}`,
          { method: "DELETE" },
        );

        const json = await response
          .json()
          .catch(() => ({}) as { message?: string });

        if (!response.ok) {
          throw new Error(json?.message || "Delete failed");
        }

        toast({
          title: "Removed",
          description: "Banner removed successfully.",
        });

        await load();
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Banner delete failed";
        setFormError(message);
        toast({
          variant: "error",
          title: "Delete failed",
          description: message,
        });
      } finally {
        setSavingBannerId(null);
      }
    },
    [load, toast],
  );

  const toggleBannerActive = useCallback(
    async (banner: Banner): Promise<void> => {
      setSavingBannerId(banner.id);
      setFormError(null);

      try {
        const response = await fetch("/api/admin/banners", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: banner.id,
            isActive: !banner.isActive,
          }),
        });

        const json = await response
          .json()
          .catch(() => ({}) as { message?: string });

        if (!response.ok) {
          throw new Error(json?.message || "Update failed");
        }

        toast({
          title: "Updated",
          description: `Banner is now ${
            banner.isActive ? "inactive" : "active"
          }.`,
        });

        await load();
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Banner update failed";
        setFormError(message);
        toast({
          variant: "error",
          title: "Update failed",
          description: message,
        });
      } finally {
        setSavingBannerId(null);
      }
    },
    [load, toast],
  );

  const onPickFile = async (file: File): Promise<void> => {
    const error = validateBannerImageFile(file);
    if (error) {
      setFormError(error);
      return;
    }

    setFormError(null);

    try {
      const imageUrl = await uploadBannerImage(file);
      await createBanner(imageUrl);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Upload failed";
      setFormError(message);
      toast({
        variant: "error",
        title: "Upload failed",
        description: message,
      });
      setIsUploading(false);
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="grid gap-5">
      <input
        ref={fileRef}
        type="file"
        accept="image/png,image/jpeg,image/jpg,image/webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void onPickFile(file);
        }}
      />

      <Card className="rounded-[28px] border-[#ece7de] bg-[linear-gradient(180deg,#fffdfa_0%,#f8f4ee_100%)] p-6 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.14)]">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <div className="inline-flex rounded-full border border-[#ece7de] bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-[#8b5a2b]">
              Homepage Banner Images
            </div>
            <h1 className="mt-3 text-2xl font-semibold tracking-tight text-[#334155] md:text-3xl">
              Hero Slideshow
            </h1>
            <p className="mt-2 text-sm leading-7 text-[#64748b]">
              Upload as many banners as you want. Every active banner will be
              included in the homepage slideshow automatically.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => fileRef.current?.click()}
              disabled={isUploading || !!savingBannerId}
            >
              {isUploading ? "Uploading..." : "Add Banner"}
            </Button>
            <Button
              variant="secondary"
              onClick={() => void load()}
              disabled={loading || isUploading || !!savingBannerId}
            >
              {loading ? "Refreshing..." : "Refresh"}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="rounded-[28px] border-[#ece7de] bg-white p-6 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.14)]">
        <div className="mb-5">
          <div className="text-lg font-semibold text-[#334155]">
            Uploaded Banners
          </div>
          <div className="mt-1 text-sm text-[#64748b]">
            Active banners appear in the homepage slideshow in order.
          </div>
        </div>

        {items.length ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {items.map((banner, index) => {
              const busy = savingBannerId === banner.id;

              return (
                <div
                  key={banner.id}
                  className="rounded-[24px] border border-[#ece7de] bg-[#fcfaf7] p-5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-base font-semibold text-[#334155]">
                        Banner {index + 1}
                      </div>
                      <div className="mt-1 text-sm text-[#64748b]">
                        Homepage slideshow image
                      </div>
                    </div>

                    <span
                      className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${
                        banner.isActive
                          ? "bg-[#eef7e8] text-[#3f6b20]"
                          : "bg-[#f1ebe2] text-[#8b5a2b]"
                      }`}
                    >
                      {banner.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>

                  <div className="mt-5 overflow-hidden rounded-[18px] border border-[#ece7de] bg-[#f4efe8]">
                    <div className="relative aspect-[4/3]">
                      <Image
                        src={banner.imageUrl}
                        alt={`Banner ${index + 1}`}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 100vw, 360px"
                      />
                    </div>
                  </div>

                  <div className="mt-4 grid gap-2">
                    <Button
                      variant="secondary"
                      onClick={() => void toggleBannerActive(banner)}
                      disabled={busy}
                      className="w-full"
                    >
                      {busy
                        ? "Saving..."
                        : banner.isActive
                          ? "Set Inactive"
                          : "Set Active"}
                    </Button>

                    <Button
                      variant="secondary"
                      onClick={() => void removeBanner(banner)}
                      disabled={busy}
                      className="w-full"
                    >
                      Remove Banner
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="rounded-[24px] border border-dashed border-[#d8d0c3] bg-[#fcfaf7] px-6 py-12 text-center text-sm text-[#64748b]">
            No banners uploaded yet. Add your first image to start the
            homepage slideshow.
          </div>
        )}

        {formError ? (
          <div className="mt-5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {formError}
          </div>
        ) : null}
      </Card>
    </div>
  );
}
