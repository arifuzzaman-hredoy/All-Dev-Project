import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import AdminSidebar, {
  AdminSidebarMobileToggle,
} from "@/components/admin/admin-sidebar";

type Role = "ADMIN" | "STAFF" | "USER";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role as Role | undefined;

  if (!session) redirect("/login?next=/admin");
  if (role !== "ADMIN" && role !== "STAFF") redirect("/");

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(226,138,32,0.14),transparent_34%),radial-gradient(circle_at_top_right,rgba(205,217,75,0.12),transparent_28%),linear-gradient(180deg,#fffdfa_0%,#f8f5f0_100%)]">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-4 px-4 py-4 lg:flex-row lg:items-start">
        <aside className="print:hidden hidden lg:block lg:sticky lg:top-4 lg:h-[calc(100vh-2rem)] lg:w-72 lg:flex-none">
          <AdminSidebar />
        </aside>
        <section className="min-w-0 flex-1">
          <div className="mb-4 flex items-center justify-between lg:hidden">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#d88a26]">
                Admin
              </p>
              <h1 className="text-lg font-semibold text-[#334155]">
                Dashboard
              </h1>
            </div>
            <AdminSidebarMobileToggle />
          </div>
          {children}
        </section>
      </div>
    </div>
  );
}
