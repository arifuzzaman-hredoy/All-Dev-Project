"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

type CouponType = "PERCENT" | "FIXED";

type Coupon = {
  id: string;
  code: string;
  type: CouponType;
  value: number;
  minSubtotal: number;
  maxDiscount: number | null;
  startsAt: string | null;
  endsAt: string | null;
  usageLimit: number | null;
  usedCount: number;
  isActive: boolean;
  createdAt: string;
};

type CouponsResponse = { coupons: Coupon[] };

type CouponFormState = {
  id?: string;
  code: string;
  type: CouponType;
  value: number;
  minSubtotal: number;
  maxDiscount: number | "";
  startsAt: string; // yyyy-mm-dd
  endsAt: string; // yyyy-mm-dd
  usageLimit: number | "";
  isActive: boolean;
};

type CouponPayload = {
  code: string;
  type: CouponType;
  value: number;
  minSubtotal: number;
  maxDiscount: number | null;
  startsAt: string | null;
  endsAt: string | null;
  usageLimit: number | null;
  isActive: boolean;
};

const emptyForm: CouponFormState = {
  code: "",
  type: "PERCENT",
  value: 10,
  minSubtotal: 0,
  maxDiscount: "",
  startsAt: "",
  endsAt: "",
  usageLimit: "",
  isActive: true,
};

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function toBool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

function toNum(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function isCouponType(v: unknown): v is CouponType {
  return v === "PERCENT" || v === "FIXED";
}

function toDateInputValue(v: string | null): string {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function parseCouponsResponse(input: unknown): CouponsResponse {
  const obj = input as { coupons?: unknown };
  const raw = Array.isArray(obj?.coupons) ? obj.coupons : [];

  const coupons: Coupon[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => ({
      id: safeString(x.id),
      code: safeString(x.code).toUpperCase(),
      type: isCouponType(x.type) ? x.type : "PERCENT",
      value: toNum(x.value, 0),
      minSubtotal: toNum(x.minSubtotal, 0),
      maxDiscount: typeof x.maxDiscount === "number" && Number.isFinite(x.maxDiscount) ? x.maxDiscount : null,
      startsAt: typeof x.startsAt === "string" ? x.startsAt : null,
      endsAt: typeof x.endsAt === "string" ? x.endsAt : null,
      usageLimit: typeof x.usageLimit === "number" && Number.isFinite(x.usageLimit) ? x.usageLimit : null,
      usedCount: toNum(x.usedCount, 0),
      isActive: toBool(x.isActive, false),
      createdAt: safeString(x.createdAt),
    }))
    .filter((c) => c.id && c.code);

  return { coupons };
}

export default function AdminCouponsPage() {
  const [items, setItems] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  const [showForm, setShowForm] = useState<boolean>(false);
  const [form, setForm] = useState<CouponFormState>(emptyForm);
  const [query, setQuery] = useState<string>("");

  const {toast} = useToast()

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((c) => c.code.toLowerCase().includes(q));
  }, [items, query]);

  const load = async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch("/api/admin/coupons", { cache: "no-store" });
      const j: unknown = await r.json();
      const parsed = parseCouponsResponse(j);
      setItems(parsed.coupons);
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => void load(), []);

  const startAdd = (): void => {
    setForm(emptyForm);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const startEdit = (c: Coupon): void => {
    setForm({
      id: c.id,
      code: c.code,
      type: c.type,
      value: c.value,
      minSubtotal: c.minSubtotal ?? 0,
      maxDiscount: c.maxDiscount ?? "",
      startsAt: toDateInputValue(c.startsAt),
      endsAt: toDateInputValue(c.endsAt),
      usageLimit: c.usageLimit ?? "",
      isActive: !!c.isActive,
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const closeForm = (): void => {
    setShowForm(false);
    setForm(emptyForm);
  };

  const validate = (): string | null => {
    const code = form.code.trim().toUpperCase();

    if (!code) return "Coupon code is required";
    if (code.length < 3) return "Coupon code too short";

    if (!Number.isFinite(form.value) || form.value <= 0) return "Value must be greater than 0";
    if (form.type === "PERCENT" && form.value > 100) return "Percent cannot exceed 100";

    if (!Number.isFinite(form.minSubtotal) || form.minSubtotal < 0) return "Min subtotal cannot be negative";

    if (form.maxDiscount !== "") {
      const n = Number(form.maxDiscount);
      if (!Number.isFinite(n) || n < 0) return "Max discount cannot be negative";
    }

    if (form.usageLimit !== "") {
      const n = Number(form.usageLimit);
      if (!Number.isFinite(n) || n < 1) return "Usage limit must be 1 or more";
    }

    if (form.startsAt && form.endsAt) {
      const s = new Date(form.startsAt);
      const e = new Date(form.endsAt);
      if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) return "Invalid date";
      if (s > e) return "Start date must be before end date";
    }

    return null;
  };

  const buildPayload = (): CouponPayload => {
    return {
      code: form.code.trim().toUpperCase(),
      type: form.type,
      value: Number(form.value),
      minSubtotal: Number(form.minSubtotal || 0),
      maxDiscount: form.maxDiscount === "" ? null : Number(form.maxDiscount),
      startsAt: form.startsAt ? new Date(form.startsAt).toISOString() : null,
      endsAt: form.endsAt ? new Date(form.endsAt).toISOString() : null,
      usageLimit: form.usageLimit === "" ? null : Number(form.usageLimit),
      isActive: !!form.isActive,
    };
  };

  const save = async (): Promise<void> => {
    const err = validate();
    if (err) {
      ;toast({
        variant: "error",
        title: "Failed",
        description: err
      })
      return;
    }

    setSaving(true);
    try {
      const payload = buildPayload();

      if (!form.id) {
        await fetch("/api/admin/coupons", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await fetch("/api/admin/coupons", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: form.id, ...payload }),
        });
      }

      await load();
      closeForm();
    } catch {
      toast({
        variant: "error",
        title: "Save failed",
      })
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string): Promise<void> => {
    const ok = confirm("Delete this coupon?");
    if (!ok) return;

    setSaving(true);
    try {
      await fetch(`/api/admin/coupons?id=${encodeURIComponent(id)}`, { method: "DELETE" });
      await load();
      if (form.id === id) closeForm();
    } catch {
      toast({
        variant: "error",
        title: "Delete failed",
      })
    } finally {
      setSaving(false);
    }
  };

  const quickToggle = async (c: Coupon): Promise<void> => {
    setSaving(true);
    try {
      await fetch("/api/admin/coupons", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: c.id, isActive: !c.isActive }),
      });
      await load();
    } catch {
      toast({
        variant: "error",
        title: "Toggle failed",
      })
    } finally {
      setSaving(false);
    }
  };

  const statusLabel = (c: Coupon): "Inactive" | "Scheduled" | "Expired" | "Active" => {
    const now = new Date();
    const s = c.startsAt ? new Date(c.startsAt) : null;
    const e = c.endsAt ? new Date(c.endsAt) : null;

    if (!c.isActive) return "Inactive";
    if (s && now < s) return "Scheduled";
    if (e && now > e) return "Expired";
    return "Active";
  };

  return (
    <div className="grid gap-4">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-lg font-semibold">Coupons</div>
          <div className="text-sm text-black/60">Add Coupon এ ক্লিক করলে নতুন coupon add হবে।</div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Input
            placeholder="Search coupons…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full md:w-64"
          />
          <Button variant="secondary" onClick={() => void load()} disabled={loading || saving}>
            Refresh
          </Button>
          <Button onClick={startAdd} disabled={saving}>
            Add Coupon
          </Button>
        </div>
      </div>

      {showForm ? (
        <Card className="rounded-3xl p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">{form.id ? "Edit Coupon" : "New Coupon"}</div>
              <div className="text-xs text-black/60">Code automatically uppercase হবে।</div>
            </div>
            <div className="flex gap-2">
              {form.id ? (
                <Button variant="danger" onClick={() => void remove(form.id!)} disabled={saving}>
                  Delete
                </Button>
              ) : null}
              <Button variant="secondary" onClick={closeForm} disabled={saving}>
                Close
              </Button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <div>
              <div className="text-sm text-black/60">Code *</div>
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. RHC10" />
            </div>

            <div>
              <div className="text-sm text-black/60">Type</div>
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value as CouponType })}
                className="w-full rounded-2xl border border-black/10 bg-white px-3 py-2 text-sm"
              >
                <option value="PERCENT">Percent (%)</option>
                <option value="FIXED">Fixed (৳)</option>
              </select>
            </div>

            <div>
              <div className="text-sm text-black/60">Value *</div>
              <Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: Number(e.target.value) })} />
            </div>

            <div>
              <div className="text-sm text-black/60">Min Subtotal (৳)</div>
              <Input type="number" value={form.minSubtotal} onChange={(e) => setForm({ ...form, minSubtotal: Number(e.target.value) })} />
            </div>

            <div>
              <div className="text-sm text-black/60">Max Discount (optional)</div>
              <Input
                type="number"
                value={form.maxDiscount}
                onChange={(e) => setForm({ ...form, maxDiscount: e.target.value === "" ? "" : Number(e.target.value) })}
                placeholder="e.g. 500"
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Usage Limit (optional)</div>
              <Input
                type="number"
                value={form.usageLimit}
                onChange={(e) => setForm({ ...form, usageLimit: e.target.value === "" ? "" : Number(e.target.value) })}
                placeholder="e.g. 100"
              />
            </div>

            <div>
              <div className="text-sm text-black/60">Starts At (optional)</div>
              <Input type="date" value={form.startsAt} onChange={(e) => setForm({ ...form, startsAt: e.target.value })} />
            </div>

            <div>
              <div className="text-sm text-black/60">Ends At (optional)</div>
              <Input type="date" value={form.endsAt} onChange={(e) => setForm({ ...form, endsAt: e.target.value })} />
            </div>

            <div className="flex items-end gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} />
                Active
              </label>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={() => void save()} disabled={saving}>
              {saving ? "Saving…" : form.id ? "Update Coupon" : "Create Coupon"}
            </Button>
          </div>
        </Card>
      ) : null}

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm font-semibold">All Coupons</div>
          <div className="text-xs text-black/60">{loading ? "Loading…" : `${filtered.length} items`}</div>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((c) => (
            <div key={c.id} className="rounded-3xl border border-black/10 bg-white p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="truncate text-base font-semibold">{c.code}</div>
                    <span className="rounded-full bg-black/5 px-3 py-1 text-xs text-black/70">{statusLabel(c)}</span>
                  </div>

                  <div className="mt-2 text-sm text-black/70">
                    {c.type === "PERCENT" ? `${c.value}% off` : `৳ ${c.value} off`}
                    {c.minSubtotal ? <span className="text-black/50"> • Min ৳{c.minSubtotal}</span> : null}
                    {c.maxDiscount != null ? <span className="text-black/50"> • Max ৳{c.maxDiscount}`</span> : null}
                  </div>

                  <div className="mt-1 text-xs text-black/60">
                    Used: {c.usedCount}
                    {c.usageLimit != null ? ` / ${c.usageLimit}` : ""} •{" "}
                    {c.startsAt ? `Start: ${toDateInputValue(c.startsAt)}` : "Start: —"} •{" "}
                    {c.endsAt ? `End: ${toDateInputValue(c.endsAt)}` : "End: —"}
                  </div>
                </div>

                <div className="flex shrink-0 flex-col gap-2">
                  <Button variant="secondary" onClick={() => void quickToggle(c)} disabled={saving}>
                    Toggle
                  </Button>
                  <Button variant="secondary" onClick={() => startEdit(c)} disabled={saving}>
                    Edit
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {!filtered.length && !loading ? (
          <div className="mt-6 rounded-3xl bg-black/5 p-6 text-sm text-black/60">
            No coupons found. Click <b>Add Coupon</b> to create your first coupon.
          </div>
        ) : null}
      </Card>
    </div>
  );
}