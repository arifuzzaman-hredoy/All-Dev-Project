"use client";

import * as React from "react";
import Image from "next/image";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { buildCategoryTree, getCategoryDisplayPath } from "@/lib/category-tree";

type Category = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  isActive: boolean;
  imageUrl?: string | null;
  parent?: {
    id: string;
    name: string;
    slug: string;
  } | null;
  children?: Array<{
    id: string;
    name: string;
    slug: string;
    parentId: string | null;
    isActive: boolean;
    imageUrl?: string | null;
  }>;
  _count?: {
    products: number;
    children: number;
  };
};

type CategoryTreeNode = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  isActive: boolean;
  imageUrl?: string | null;
  parent?: {
    id: string;
    name: string;
    slug: string;
  } | null;
  _count?: {
    products: number;
    children: number;
  };
  children: CategoryTreeNode[];
};

type FormState = {
  id?: string;
  name: string;
  parentId: string;
  isActive: boolean;
  imageUrl: string;
};

type UploadResponse = { url?: string; error?: string };

const emptyForm: FormState = {
  name: "",
  parentId: "",
  isActive: true,
  imageUrl: "",
};

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);

  const res = await fetch("/api/upload/category-image", {
    method: "POST",
    body: fd,
  });

  const data: UploadResponse = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Upload failed");
  if (!data.url) throw new Error("Upload failed");

  return data.url;
}

function Modal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  React.useEffect(() => {
    if (!open) return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };

    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[200]">
      <button
        type="button"
        aria-label="Close modal"
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/45 backdrop-blur-[2px]"
      />
      <div className="absolute inset-0 flex items-start justify-center overflow-y-auto p-4 pt-24 sm:p-6 sm:pt-28">
        <div className="w-full max-w-3xl">
          <div className="overflow-hidden rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white shadow-[0_20px_70px_-40px_rgba(216,27,96,0.3)]">
            <div className="flex items-center justify-between gap-3 border-b border-[#f8bbd0]/70 px-5 py-4">
              <div className="text-sm font-semibold">{title}</div>
              <Button variant="secondary" onClick={onClose}>
                Close
              </Button>
            </div>

            <div className="max-h-[80vh] overflow-auto p-5">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminCategoriesPage() {
  const [items, setItems] = React.useState<Category[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [uploading, setUploading] = React.useState(false);
  const [query, setQuery] = React.useState("");

  const [showForm, setShowForm] = React.useState(false);
  const [form, setForm] = React.useState<FormState>(emptyForm);
  const [formError, setFormError] = React.useState<string | null>(null);

  const fileRef = React.useRef<HTMLInputElement | null>(null);
  const { toast } = useToast();

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/categories", { cache: "no-store" });
      const data: unknown = await res.json().catch(() => []);
      setItems(Array.isArray(data) ? (data as Category[]) : []);
    } catch {
      setItems([]);
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not load categories.",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  React.useEffect(() => {
    void load();
  }, [load]);

  const rootCategories = React.useMemo(
    () => items.filter((item) => !item.parentId),
    [items],
  );

  const tree = React.useMemo(() => {
    return buildCategoryTree(
      items.map((item) => ({
        id: item.id,
        name: item.name,
        slug: item.slug,
        parentId: item.parentId,
        isActive: item.isActive,
        imageUrl: item.imageUrl ?? null,
      })),
    );
  }, [items]);

  const mergedTree: CategoryTreeNode[] = React.useMemo(() => {
    const map = new Map(items.map((item) => [item.id, item]));

    const merge = (
      node: ReturnType<typeof buildCategoryTree>[number],
    ): CategoryTreeNode => {
      const full = map.get(node.id);

      return {
        id: node.id,
        name: node.name,
        slug: node.slug,
        parentId: node.parentId,
        isActive: node.isActive ?? true,
        imageUrl: full?.imageUrl ?? null,
        parent: full?.parent ?? null,
        _count: full?._count,
        children: node.children.map(merge),
      };
    };

    return tree.map(merge);
  }, [tree, items]);

  const filteredTree = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return mergedTree;

    const filterNode = (node: CategoryTreeNode): CategoryTreeNode | null => {
      const selfMatch =
        node.name.toLowerCase().includes(q) ||
        node.slug.toLowerCase().includes(q);

      const matchedChildren = node.children
        .map(filterNode)
        .filter((x): x is CategoryTreeNode => x !== null);

      if (selfMatch || matchedChildren.length > 0) {
        return {
          ...node,
          children: matchedChildren,
        };
      }

      return null;
    };

    return mergedTree
      .map(filterNode)
      .filter((x): x is CategoryTreeNode => x !== null);
  }, [mergedTree, query]);

  function openCreate(parentId = "") {
    setForm({
      id: undefined,
      name: "",
      parentId,
      isActive: true,
      imageUrl: "",
    });
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(category: Category) {
    setForm({
      id: category.id,
      name: category.name,
      parentId: category.parentId || "",
      isActive: category.isActive,
      imageUrl: category.imageUrl || "",
    });
    setFormError(null);
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setForm(emptyForm);
    setFormError(null);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function onPickImage(file: File | null) {
    if (!file) return;

    setFormError(null);
    setUploading(true);

    try {
      const url = await uploadFile(file);
      setForm((prev) => ({ ...prev, imageUrl: url }));
      toast({
        title: "Uploaded",
        description: "Category image uploaded successfully.",
      });
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function save() {
    setFormError(null);

    if (!form.name.trim()) {
      setFormError("Category name is required.");
      return;
    }

    setSaving(true);

    try {
      const isEdit = !!form.id;
      const res = await fetch(
        isEdit ? `/api/admin/categories/${form.id}` : "/api/admin/categories",
        {
          method: isEdit ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: form.name.trim(),
            parentId: form.parentId || null,
            isActive: form.isActive,
            imageUrl: form.imageUrl || null,
          }),
        },
      );

      const data = await res.json().catch(() => ({}) as { error?: string });

      if (!res.ok) {
        setFormError(data?.error || "Save failed");
        return;
      }

      toast({
        title: isEdit ? "Updated" : "Created",
        description: isEdit
          ? "Category updated successfully."
          : "Category created successfully.",
      });

      closeForm();
      await load();
    } catch {
      setFormError("Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    const ok = window.confirm("Delete this category?");
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/categories/${id}`, {
        method: "DELETE",
      });

      const data = await res.json().catch(() => ({}) as { error?: string });

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Delete failed",
          description: data?.error || "Could not delete category.",
        });
        return;
      }

      toast({
        title: "Deleted",
        description: "Category deleted successfully.",
      });

      await load();
    } catch {
      toast({
        variant: "error",
        title: "Delete failed",
      });
    }
  }

  async function quickToggle(category: Category) {
    try {
      const res = await fetch(`/api/admin/categories/${category.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          isActive: !category.isActive,
        }),
      });

      const data = await res.json().catch(() => ({}) as { error?: string });

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Update failed",
          description: data?.error || "Could not update category.",
        });
        return;
      }

      await load();
    } catch {
      toast({
        variant: "error",
        title: "Update failed",
      });
    }
  }

  const renderNode = (node: CategoryTreeNode, depth = 0) => {
    const full = items.find((x) => x.id === node.id);
    const path = getCategoryDisplayPath(node.id, items);

    return (
      <div key={node.id} className="space-y-2">
        <div
          className="rounded-3xl border border-[#f8bbd0] bg-white/90 p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]"
          style={{ marginLeft: depth ? depth * 20 : 0 }}
        >
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex min-w-0 items-start gap-3">
              <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl bg-[#fff1f5] ring-1 ring-[#f8bbd0]/60">
                {node.imageUrl ? (
                  <Image
                    src={node.imageUrl}
                    alt={node.name}
                    fill
                    className="object-cover"
                    sizes="64px"
                  />
                ) : null}
              </div>

              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="text-sm font-semibold">{node.name}</div>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                      node.isActive
                        ? "bg-emerald-50 text-emerald-700"
                        : "bg-rose-50 text-rose-700"
                    }`}
                  >
                    {node.isActive ? "Active" : "Inactive"}
                  </span>
                  {!node.parentId ? (
                    <span className="rounded-full bg-[#fff1f5] px-2 py-0.5 text-[11px] text-[#ad1457] ring-1 ring-[#f8bbd0]/60">
                      Main Category
                    </span>
                  ) : (
                    <span className="rounded-full bg-[#fff7fb] px-2 py-0.5 text-[11px] text-[#c2185b] ring-1 ring-[#f8bbd0]/50">
                      Subcategory
                    </span>
                  )}
                </div>

                <div className="mt-1 text-xs text-slate-500">Path: {path}</div>
                <div className="mt-1 text-xs text-slate-500">
                  Slug: {node.slug}
                </div>
                <div className="mt-1 text-xs text-slate-500">
                  Products: {full?._count?.products ?? 0} • Subcategories:{" "}
                  {full?._count?.children ?? node.children.length}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {!node.parentId ? (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => openCreate(node.id)}
                >
                  Add Subcategory
                </Button>
              ) : null}

              <Button
                variant="secondary"
                size="sm"
                onClick={() =>
                  quickToggle({
                    id: node.id,
                    name: node.name,
                    slug: node.slug,
                    parentId: node.parentId,
                    isActive: node.isActive,
                    imageUrl: node.imageUrl,
                  })
                }
              >
                {node.isActive ? "Deactivate" : "Activate"}
              </Button>

              <Button
                variant="secondary"
                size="sm"
                onClick={() =>
                  openEdit({
                    id: node.id,
                    name: node.name,
                    slug: node.slug,
                    parentId: node.parentId,
                    isActive: node.isActive,
                    imageUrl: node.imageUrl,
                  })
                }
              >
                Edit
              </Button>

              <Button
                variant="danger"
                size="sm"
                onClick={() => void remove(node.id)}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>

        {node.children.length ? (
          <div className="space-y-2">
            {node.children.map((child: CategoryTreeNode) =>
              renderNode(child, depth + 1),
            )}
          </div>
        ) : null}
      </div>
    );
  };

  return (
    <div className="space-y-4 rounded-4xl bg-[radial-gradient(900px_circle_at_0%_0%,rgba(248,187,208,0.28),transparent_35%),radial-gradient(700px_circle_at_100%_0%,rgba(255,241,245,0.8),transparent_28%)] p-4 md:p-6">
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-4xl border border-[#f8bbd0] bg-white/90 p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
        <div className="max-w-2xl">
          <div className="inline-flex rounded-full bg-[#fff1f5] px-3 py-1 text-xs font-medium text-[#ad1457] ring-1 ring-[#f8bbd0]/60">
            Catalog structure
          </div>
          <div className="mt-3 text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
            Categories
          </div>
          <div className="mt-2 text-sm text-slate-600">
            Manage main categories and subcategories in a nested structure.
          </div>
        </div>

        <Button
          onClick={() => openCreate()}
          className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
        >
          Add Main Category
        </Button>
      </div>

      <Card className="rounded-4xl border-[#f8bbd0] bg-white/90 p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.16)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search category by name or slug"
            className="w-full border-[#f8bbd0] bg-white/80 md:w-80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
          />

          <div className="rounded-full bg-[#fff1f5] px-3 py-1 text-xs text-[#ad1457] ring-1 ring-[#f8bbd0]/60">
            {loading ? "Loading..." : `${items.length} categories`}
          </div>
        </div>
      </Card>

      <Card className="rounded-4xl border-[#f8bbd0] bg-white/90 p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.16)]">
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm font-semibold text-slate-900">
            Category Tree
          </div>
          <div className="text-xs text-slate-500">
            {rootCategories.length} main categories
          </div>
        </div>

        <div className="space-y-3">
          {filteredTree.map((node) => renderNode(node))}

          {!filteredTree.length && !loading ? (
            <div className="rounded-3xl bg-[#fff1f5] p-6 text-sm text-slate-600 ring-1 ring-[#f8bbd0]/60">
              No categories found.
            </div>
          ) : null}
        </div>
      </Card>

      <Modal
        open={showForm}
        title={form.id ? "Edit Category" : "Add Category"}
        onClose={closeForm}
      >
        <div className="space-y-4">
          <div>
            <div className="mb-1 text-sm text-slate-600">Category Name *</div>
            <Input
              value={form.name}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="e.g. Hearing Aid"
              className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
            />
          </div>

          <div>
            <div className="mb-1 text-sm text-slate-600">Parent Category</div>
            <select
              className="h-11 w-full rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 text-sm outline-none focus:border-[#d81b60]"
              value={form.parentId}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, parentId: e.target.value }))
              }
            >
              <option value="">No parent (Main Category)</option>
              {rootCategories
                .filter((cat) => cat.id !== form.id)
                .map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
            </select>
          </div>

          <div className="space-y-3">
            <div className="text-sm text-slate-600">Category Image</div>

            <div className="flex flex-wrap items-center gap-3">
              <input
                ref={fileRef}
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                className="hidden"
                onChange={(e) => void onPickImage(e.target.files?.[0] || null)}
              />

              <Button
                type="button"
                variant="secondary"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? "Uploading..." : "Upload Image"}
              </Button>

              {form.imageUrl ? (
                <Button
                  type="button"
                  variant="danger"
                  onClick={() => setForm((prev) => ({ ...prev, imageUrl: "" }))}
                >
                  Remove Image
                </Button>
              ) : null}
            </div>

            {form.imageUrl ? (
              <div className="relative h-32 w-32 overflow-hidden rounded-2xl border border-[#f8bbd0]/70 bg-[#fff1f5]">
                <Image
                  src={form.imageUrl}
                  alt="Category preview"
                  fill
                  className="object-cover"
                  sizes="128px"
                />
              </div>
            ) : (
              <div className="text-xs text-slate-500">
                No image uploaded yet.
              </div>
            )}
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.isActive}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, isActive: e.target.checked }))
                }
              />
              Active
            </label>
          </div>

          {formError ? (
            <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
              {formError}
            </div>
          ) : null}

          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={closeForm} disabled={saving}>
              Cancel
            </Button>
            <Button onClick={() => void save()} disabled={saving || uploading}>
              {saving ? "Saving..." : form.id ? "Update" : "Create"}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
