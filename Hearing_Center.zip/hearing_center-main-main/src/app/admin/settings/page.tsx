"use client";

import Image from "next/image";
import { type ChangeEvent, useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

type FaqItem = {
  question: string;
  answer: string;
};

type Settings = {
  storeName: string;
  logoUrl: string;
  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  codEnabled: boolean;
  onlineEnabled: boolean;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;

  returnRefundPolicy: string;
  privacyPolicy: string;
  termsConditions: string;

  aboutUs: string;
  aboutFaqs: FaqItem[];
};

function normalizeFaqs(input: unknown): FaqItem[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => {
      const o = item as Record<string, unknown>;
      return {
        question: typeof o.question === "string" ? o.question : "",
        answer: typeof o.answer === "string" ? o.answer : "",
      };
    })
    .filter((x) => x.question || x.answer);
}

function normalizeSettings(
  input: Partial<Settings> | null | undefined,
): Settings {
  return {
    storeName: input?.storeName ?? "Rangpur Hearing Center",
    logoUrl: input?.logoUrl ?? "",
    taxRate: Number(input?.taxRate ?? 0),
    shippingInsideDhaka: Number(input?.shippingInsideDhaka ?? 0),
    shippingOutsideDhaka: Number(input?.shippingOutsideDhaka ?? 0),
    shippingFreeOver: Number(input?.shippingFreeOver ?? 0),
    codEnabled: Boolean(input?.codEnabled ?? true),
    onlineEnabled: Boolean(input?.onlineEnabled ?? false),
    lowStockThreshold: Number(input?.lowStockThreshold ?? 5),

    facebookUrl: input?.facebookUrl ?? "",
    instagramUrl: input?.instagramUrl ?? "",
    youtubeUrl: input?.youtubeUrl ?? "",
    tiktokUrl: input?.tiktokUrl ?? "",
    whatsappUrl: input?.whatsappUrl ?? "",

    returnRefundPolicy: input?.returnRefundPolicy ?? "",
    privacyPolicy: input?.privacyPolicy ?? "",
    termsConditions: input?.termsConditions ?? "",

    aboutUs: input?.aboutUs ?? "",
    aboutFaqs: normalizeFaqs(input?.aboutFaqs),
  };
}

export default function AdminSettingsPage() {
  const [s, setS] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [logoUploading, setLogoUploading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const load = async () => {
      setLoading(true);

      try {
        const res = await fetch("/api/admin/settings", {
          cache: "no-store",
        });

        const json = await res.json().catch(() => null);

        if (!res.ok) {
          toast({
            variant: "error",
            title: "Failed",
            description: "Could not load settings",
          });
          setS(normalizeSettings(null));
          return;
        }

        setS(normalizeSettings(json?.settings));
      } catch {
        toast({
          variant: "error",
          title: "Failed",
          description: "Could not load settings",
        });
        setS(normalizeSettings(null));
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [toast]);

  const save = async () => {
    if (!s) return;

    setSaving(true);

    try {
      const payload = {
        ...s,
        taxRate: Number(s.taxRate || 0),
        shippingInsideDhaka: Number(s.shippingInsideDhaka || 0),
        shippingOutsideDhaka: Number(s.shippingOutsideDhaka || 0),
        shippingFreeOver: Number(s.shippingFreeOver || 0),
        lowStockThreshold: Number(s.lowStockThreshold || 0),
        aboutFaqs: s.aboutFaqs.filter((item) => item.question || item.answer),
      };

      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const json = await res.json().catch(() => null);

      if (!res.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description: json?.message || "Could not save settings",
        });
        return;
      }

      setS(normalizeSettings(json?.settings));

      toast({
        variant: "success",
        title: "Saved",
        description: "Settings saved successfully",
      });
    } catch {
      toast({
        variant: "error",
        title: "Failed",
        description: "Could not save settings",
      });
    } finally {
      setSaving(false);
    }
  };

  const uploadLogo = async (event: ChangeEvent<HTMLInputElement>) => {
    if (!s) return;

    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    setLogoUploading(true);

    try {
      const form = new FormData();
      form.append("file", file);

      const res = await fetch("/api/upload/logo-image", {
        method: "POST",
        body: form,
      });

      const json = await res.json().catch(() => null);

      if (!res.ok || typeof json?.url !== "string") {
        toast({
          variant: "error",
          title: "Upload failed",
          description: json?.error || "Could not upload logo",
        });
        return;
      }

      setS((current) => (current ? { ...current, logoUrl: json.url } : current));

      toast({
        variant: "success",
        title: "Logo uploaded",
        description: "Logo published successfully.",
      });
    } catch {
      toast({
        variant: "error",
        title: "Upload failed",
        description: "Could not upload logo",
      });
    } finally {
      setLogoUploading(false);
    }
  };

  const updateFaq = (
    index: number,
    key: "question" | "answer",
    value: string,
  ) => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: s.aboutFaqs.map((item, i) =>
        i === index ? { ...item, [key]: value } : item,
      ),
    });
  };

  const addFaq = () => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: [...s.aboutFaqs, { question: "", answer: "" }],
    });
  };

  const removeFaq = (index: number) => {
    if (!s) return;
    setS({
      ...s,
      aboutFaqs: s.aboutFaqs.filter((_, i) => i !== index),
    });
  };

  if (loading || !s) {
    return (
      <div className="grid gap-4">
        <div className="text-lg font-semibold">Store Settings</div>
        <Card className="rounded-3xl p-6 text-sm text-black/60">
          Loading settings...
        </Card>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      <div className="text-lg font-semibold">Store Settings</div>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">General Settings</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm text-black/60">Store Name</div>
            <Input
              value={s.storeName ?? ""}
              onChange={(e) => setS({ ...s, storeName: e.target.value })}
            />
          </div>

          <div className="md:row-span-2">
            <div className="text-sm text-black/60">Store Logo</div>
            <div className="mt-2 flex flex-wrap items-center gap-4 rounded-2xl border border-black/10 bg-white/60 p-3">
              <div className="relative grid h-16 w-16 place-items-center overflow-hidden rounded-2xl bg-pink-50">
                <Image
                  src={s.logoUrl || "/logo.png"}
                  alt={s.storeName || "Store logo"}
                  fill
                  sizes="64px"
                  className="object-contain p-2"
                />
              </div>

              <div className="min-w-0 flex-1">
                <Input
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  onChange={uploadLogo}
                  disabled={logoUploading}
                />
                <div className="mt-2 text-xs text-black/50">
                  PNG, JPG, JPEG or WEBP. Upload first, then save settings.
                </div>
              </div>

              {s.logoUrl ? (
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() =>
                    setS((current) =>
                      current ? { ...current, logoUrl: "" } : current,
                    )
                  }
                  disabled={logoUploading}
                >
                  Use Default
                </Button>
              ) : null}
            </div>
          </div>

          <div>
            <div className="text-sm text-black/60">Tax Rate (%)</div>
            <Input
              type="number"
              value={s.taxRate}
              onChange={(e) => setS({ ...s, taxRate: Number(e.target.value) })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">
              Shipping Charge (Dhaka) ৳
            </div>
            <Input
              type="number"
              value={s.shippingInsideDhaka}
              onChange={(e) =>
                setS({ ...s, shippingInsideDhaka: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">
              Shipping Charge (Outside Dhaka) ৳
            </div>
            <Input
              type="number"
              value={s.shippingOutsideDhaka}
              onChange={(e) =>
                setS({ ...s, shippingOutsideDhaka: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Free Shipping Over (৳)</div>
            <Input
              type="number"
              value={s.shippingFreeOver}
              onChange={(e) =>
                setS({ ...s, shippingFreeOver: Number(e.target.value) })
              }
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Low Stock Threshold</div>
            <Input
              type="number"
              value={s.lowStockThreshold}
              onChange={(e) =>
                setS({ ...s, lowStockThreshold: Number(e.target.value) })
              }
            />
          </div>

          <div className="flex items-end gap-4 md:col-span-2">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={s.codEnabled}
                onChange={(e) => setS({ ...s, codEnabled: e.target.checked })}
              />
              COD Enabled
            </label>

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={s.onlineEnabled}
                onChange={(e) =>
                  setS({ ...s, onlineEnabled: e.target.checked })
                }
              />
              Online Enabled
            </label>
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Social Media Links</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm text-black/60">Facebook URL</div>
            <Input
              value={s.facebookUrl ?? ""}
              onChange={(e) => setS({ ...s, facebookUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">Instagram URL</div>
            <Input
              value={s.instagramUrl ?? ""}
              onChange={(e) => setS({ ...s, instagramUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">YouTube URL</div>
            <Input
              value={s.youtubeUrl ?? ""}
              onChange={(e) => setS({ ...s, youtubeUrl: e.target.value })}
            />
          </div>

          <div>
            <div className="text-sm text-black/60">TikTok URL</div>
            <Input
              value={s.tiktokUrl ?? ""}
              onChange={(e) => setS({ ...s, tiktokUrl: e.target.value })}
            />
          </div>

          <div className="md:col-span-2">
            <div className="text-sm text-black/60">WhatsApp URL</div>
            <Input
              value={s.whatsappUrl ?? ""}
              onChange={(e) => setS({ ...s, whatsappUrl: e.target.value })}
            />
          </div>
        </div>
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">
          Return and Refund Policy
        </div>
        <textarea
          value={s.returnRefundPolicy ?? ""}
          onChange={(e) => setS({ ...s, returnRefundPolicy: e.target.value })}
          className="min-h-55 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm outline-none"
        />
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Privacy Policy</div>
        <textarea
          value={s.privacyPolicy ?? ""}
          onChange={(e) => setS({ ...s, privacyPolicy: e.target.value })}
          className="min-h-55 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm outline-none"
        />
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">Terms & Conditions</div>
        <textarea
          value={s.termsConditions ?? ""}
          onChange={(e) => setS({ ...s, termsConditions: e.target.value })}
          className="min-h-55 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm outline-none"
        />
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 text-sm font-semibold">About Us Content</div>
        <textarea
          value={s.aboutUs ?? ""}
          onChange={(e) => setS({ ...s, aboutUs: e.target.value })}
          className="min-h-65 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm outline-none"
          placeholder="Write your About Us content here..."
        />
      </Card>

      <Card className="rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm font-semibold">About Us FAQ</div>
          <Button type="button" variant="secondary" onClick={addFaq}>
            Add FAQ
          </Button>
        </div>

        <div className="space-y-4">
          {s.aboutFaqs.length ? (
            s.aboutFaqs.map((faq, index) => (
              <div
                key={index}
                className="rounded-2xl border border-black/10 bg-white p-4"
              >
                <div className="grid gap-3">
                  <div>
                    <div className="mb-1 text-sm text-black/60">Question</div>
                    <Input
                      value={faq.question ?? ""}
                      onChange={(e) =>
                        updateFaq(index, "question", e.target.value)
                      }
                    />
                  </div>

                  <div>
                    <div className="mb-1 text-sm text-black/60">Answer</div>
                    <textarea
                      value={faq.answer ?? ""}
                      onChange={(e) =>
                        updateFaq(index, "answer", e.target.value)
                      }
                      className="min-h-30 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-sm outline-none"
                    />
                  </div>

                  <div>
                    <Button
                      type="button"
                      variant="danger"
                      onClick={() => removeFaq(index)}
                    >
                      Remove FAQ
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-sm text-black/50">No FAQ added yet.</div>
          )}
        </div>
      </Card>

      <div>
        <Button onClick={save} disabled={saving}>
          {saving ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
}
