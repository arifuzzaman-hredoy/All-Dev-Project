import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";

export default async function ContactPage() {
  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: {
      storeName: true,
      facebookUrl: true,
      instagramUrl: true,
      youtubeUrl: true,
      tiktokUrl: true,
      whatsappUrl: true,
    },
  });

  const socialLinks = [
    { label: "Facebook", href: settings?.facebookUrl || "" },
    { label: "Instagram", href: settings?.instagramUrl || "" },
    { label: "YouTube", href: settings?.youtubeUrl || "" },
    { label: "TikTok", href: settings?.tiktokUrl || "" },
    { label: "WhatsApp", href: settings?.whatsappUrl || "" },
  ].filter((item) => item.href.trim());

  return (
    <div className="space-y-12 pb-10">
      <section className="rounded-3xl border border-black/10 bg-white/80 px-6 py-12 text-center shadow-sm sm:px-10 sm:py-16">
        <span className="inline-flex rounded-full border border-black/10 bg-black/5 px-4 py-1 text-xs font-medium uppercase tracking-wide text-black/70">
          Contact Us
        </span>

        <h1 className="mt-4 text-3xl font-bold tracking-tight text-black sm:text-4xl">
          We’re here to help with hearing care
        </h1>

        <p className="mx-auto mt-5 max-w-2xl text-sm leading-7 text-black/70 sm:text-base">
          Reach out to {settings?.storeName || "Rangpur Hearing Center"} for
          hearing-aid guidance, accessory questions, consultation support, and
          order help.
        </p>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Card className="rounded-3xl p-6">
          <div className="text-lg font-semibold">Order Support</div>
          <div className="mt-2 text-sm leading-7 text-black/65">
            Need help with an order, tracking, delivery, or checkout? Visit
            your orders page or contact us through our active channels.
          </div>
          <Link
            href="/orders"
            className="mt-5 inline-flex rounded-2xl bg-black px-4 py-2 text-sm font-medium text-white"
          >
            View Orders
          </Link>
        </Card>

        <Card className="rounded-3xl p-6">
          <div className="text-lg font-semibold">Product Help</div>
          <div className="mt-2 text-sm leading-7 text-black/65">
            Explore our hearing catalog and get help choosing the right style,
            hearing-loss range, rechargeable option, or accessory support
            device.
          </div>
          <Link
            href="/products"
            className="mt-5 inline-flex rounded-2xl bg-black px-4 py-2 text-sm font-medium text-white"
          >
            Browse Products
          </Link>
        </Card>

        <Card className="rounded-3xl p-6">
          <div className="text-lg font-semibold">Stay Connected</div>
          <div className="mt-2 text-sm leading-7 text-black/65">
            Follow us on social media for clinic updates, product highlights,
            hearing-care information, and quick communication.
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            {socialLinks.length ? (
              socialLinks.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-black/10 px-4 py-2 text-sm hover:bg-black hover:text-white"
                >
                  {item.label}
                </a>
              ))
            ) : (
              <div className="text-sm text-black/50">
                No contact links added yet.
              </div>
            )}
          </div>
        </Card>
      </section>

      <section className="rounded-3xl border border-black/10 bg-black px-6 py-10 text-center text-white shadow-sm sm:px-10">
        <p className="text-sm font-semibold uppercase tracking-wide text-white/60">
          Need Assistance?
        </p>
        <h2 className="mt-3 text-2xl font-bold tracking-tight sm:text-3xl">
          We’re always happy to guide you
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-white/75 sm:text-base">
          Check your orders, browse hearing solutions, or connect with us for
          consultation and after-sales support.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/orders"
            className="rounded-2xl bg-white px-5 py-3 text-sm font-medium text-black transition hover:opacity-90"
          >
            Track Orders
          </Link>
          <Link
            href="/products"
            className="rounded-2xl border border-white/20 bg-transparent px-5 py-3 text-sm font-medium text-white transition hover:bg-white/10"
          >
            Browse Hearing Devices
          </Link>
        </div>
      </section>
    </div>
  );
}
