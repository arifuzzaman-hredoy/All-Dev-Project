// app/page.tsx
import Link from "next/link";
import { headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import TrustBadges from "@/components/home/trust-badges";
import FeaturedProducts from "@/components/home/featured-products";
import CategoryProductRow from "@/components/home/category-product-row";
import { ArrowRight } from "lucide-react";
import ShopByCategory from "@/components/home/shop-by-category";
import HeroSection from "@/components/home/hero-section";
import HelpSection from "@/components/home/HelpSection";
import type { HomeCategoryRow } from "@/lib/home-category-rows";
import { getBestSellingProductIds } from "@/lib/best-selling";

export const dynamic = "force-dynamic";
// export const revalidate = 60;

const categoryColorClasses: Record<string, string> = {
  headphone:
    "bg-[#fff8ee] text-[#d88a26] ring-[#efbf7e] hover:bg-[#fff1df] hover:text-[#b96f10]",
  smartwatch:
    "bg-[#f8f5f0] text-[#475569] ring-[#e3dbd1] hover:bg-[#f1ebe2] hover:text-[#334155]",
  bluetooth:
    "bg-[#fff5f1] text-[#ff4a3d] ring-[#ffd0c9] hover:bg-[#ffebe7] hover:text-[#ef3f32]",
  "t-shirts":
    "bg-[#fff8ee] text-[#d88a26] ring-[#efbf7e] hover:bg-[#fff1df] hover:text-[#b96f10]",
  mouse:
    "bg-[#f8f5f0] text-[#475569] ring-[#e3dbd1] hover:bg-[#f1ebe2] hover:text-[#334155]",
  gaming:
    "bg-[#eef5d8] text-[#4d5600] ring-[#d8e69b] hover:bg-[#e6f0c4] hover:text-[#434d00]",
};

function getCategoryColorClass(slug: string) {
  return (
    categoryColorClasses[slug] ??
    "bg-[#fff8ee] text-[#d88a26] ring-[#efbf7e] hover:bg-[#fff1df] hover:text-[#b96f10]"
  );
}

async function getRequestOrigin() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (!host) return null;

  const protocol =
    h.get("x-forwarded-proto") ??
    (host.startsWith("localhost") || host.startsWith("127.0.0.1")
      ? "http"
      : "https");
  return `${protocol}://${host}`;
}

export default async function HomePage() {
  const origin = await getRequestOrigin();

  const [settings, featured, homeBanners, bestSellingIds] = await Promise.all([
    prisma.storeSettings.upsert({
      where: { id: "default" },
      update: {},
      create: { id: "default" },
    }),
    prisma.product.findMany({
      where: { isFeatured: true, isActive: true },
      orderBy: [{ updatedAt: "desc" }],
      take: 8,
      include: {
        images: { orderBy: { sortOrder: "asc" }, take: 1 },
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
            parent: { select: { id: true, name: true, slug: true } },
          },
        },
      },
    }),
    prisma.banner.findMany({
      where: {
        isActive: true,
      },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
    }),
    getBestSellingProductIds(),
  ]);

  const categoryRowsResponse = origin
    ? await fetch(`${origin}/api/home/category-rows`, {
        cache: "no-store",
      })
    : null;

  const categoryRows = categoryRowsResponse?.ok
    ? ((await categoryRowsResponse.json()) as HomeCategoryRow[])
    : [];

  const featuredIds = featured.map((product) => product.id);

  const [featuredRatings] = await Promise.all([
    featuredIds.length
      ? prisma.review.groupBy({
          by: ["productId"],
          where: { productId: { in: featuredIds } },
          _avg: { rating: true },
          _count: { rating: true },
        })
      : Promise.resolve([]),
  ]);

  const featuredRatingMap = new Map(
    featuredRatings.map((item) => [
      item.productId,
      {
        ratingAvg:
          typeof item._avg.rating === "number"
            ? Math.round(item._avg.rating * 10) / 10
            : 0,
        ratingCount:
          typeof item._count.rating === "number" ? item._count.rating : 0,
      },
    ]),
  );

  const featuredProducts = featured.map((product) => {
    const rating = featuredRatingMap.get(product.id);

    return {
      ...product,
      shortDescription: null,
      ratingAvg: rating?.ratingAvg ?? 0,
      ratingCount: rating?.ratingCount ?? 0,
      isBestSelling: bestSellingIds.has(product.id),
    };
  });

  return (
    <main className="min-h-screen overflow-hidden">
      <HeroSection settings={settings} banners={homeBanners} />

      <section className="mx-auto max-w-7xl px-4 pt-6 lg:px-6">
        <ShopByCategory />
      </section>

      <section className="mx-auto max-w-7xl px-4 pt-9 lg:px-6">
        <div className="mb-5 border-b border-[#ece7de] pb-3">
          <p className="text-center text-[11px] font-semibold uppercase tracking-[0.22em] text-[#8b5a2b]">
            Trending Products
          </p>
        </div>

        <div className="mb-5 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold text-[#334155] md:text-3xl">
              Hearing Solutions & Featured Devices
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-[#64748b]">
              Compare hearing aids, rechargeable models, and essential
              accessories from our curated catalog.
            </p>
          </div>

          <Link
            href="/products?featured=1"
            className="group flex items-center gap-2 rounded-[14px] border border-[#efbf7e] bg-white px-5 py-2.5 text-sm font-semibold text-[#d88a26] transition-all hover:bg-[#fff8ee]"
          >
            <span>View all</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        <FeaturedProducts products={featuredProducts} />
      </section>

     

      {categoryRows.map((item) => (
        <CategoryProductRow
          key={item.slug}
          slug={item.slug}
          title={item.name}
          colorClass={getCategoryColorClass(item.slug)}
        />
      ))}

      <section className="mx-auto max-w-7xl px-4 pt-9 lg:px-6">
        <div className="mb-6 border-b border-[#ece7de] pb-4 text-left">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#8b5a2b]">
            Why Choose Us
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-[#334155] md:text-3xl">
            Why Patients Choose Us
          </h2>
        </div>
        <TrustBadges />
      </section>

      <HelpSection />
    </main>
  );
}
