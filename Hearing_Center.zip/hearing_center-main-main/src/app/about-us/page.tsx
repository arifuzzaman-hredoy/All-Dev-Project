import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import PageHero from "@/components/layout/page-hero";

type FaqItem = {
  question: string;
  answer: string;
};

function normalizeFaqs(input: unknown): FaqItem[] {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => {
      const o = item as Record<string, unknown>;
      return {
        question: typeof o.question === "string" ? o.question : "",
        answer: typeof o.answer === "string" ? o.answer : "",
      };
    })
    .filter((x) => x.question && x.answer);
}

export default async function AboutPage() {
  const [settings, productCount, orderCount, deliveredCount, categoryCount] =
    await Promise.all([
      prisma.storeSettings.findUnique({
        where: { id: "default" },
        select: {
          storeName: true,
          aboutUs: true,
          aboutFaqs: true,
        },
      }),
      prisma.product.count({
        where: { isActive: true },
      }),
      prisma.order.count(),
      prisma.order.count({
        where: { status: "DELIVERED" },
      }),
      prisma.category.count({
        where: { isActive: true },
      }),
    ]);

  const faqs = normalizeFaqs(settings?.aboutFaqs);

  const stats = [
    { label: "Products", value: String(productCount) },
    { label: "Orders", value: String(orderCount) },
    { label: "Delivered Orders", value: String(deliveredCount) },
    { label: "Categories", value: String(categoryCount) },
  ];

  return (
    <div className="space-y-12 pb-10">
      <PageHero
        eyebrow="About Us"
        title="A hearing-care focused catalog built around guidance, trust, and the right fit."
        description={
          settings?.aboutUs?.trim() ||
          `${settings?.storeName || "Rangpur Hearing Center"} helps people explore hearing aids, accessories, and consultation support with clear product information, patient-friendly guidance, and dependable after-sales service.`
        }
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "About Us" },
        ]}
        actions={[
          { href: "/products", label: "Explore products" },
          { href: "/contact", label: "Contact us", variant: "secondary" },
        ]}
        stats={stats}
        align="center"
      />

      <section className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.25)] sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
            Our Story
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            We focus on trust, convenience, and better online service
          </h2>
          <p className="mt-4 text-sm leading-7 text-slate-700 sm:text-base">
            We believe hearing care should start with understanding, not
            pressure. That is why we focus on clear hearing-aid information,
            hearing-loss guidance, and product selection that matches real-life
            needs.
          </p>
          <p className="mt-4 text-sm leading-7 text-slate-700 sm:text-base">
            From consultation and product comparison to delivery and everyday
            maintenance, our goal is to make better hearing easier and more
            trustworthy for families across Bangladesh.
          </p>
        </Card>

        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-[#ffe4ec] to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)] sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
            Why Customers Choose Us
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            A hearing-focused platform with dependable product and support guidance
          </h2>

          <div className="mt-6 space-y-3">
            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Trusted Products</div>
              <div className="mt-1 text-sm text-slate-700">
                Carefully selected hearing aids and accessories with a strong
                focus on reliability and suitability.
              </div>
            </div>

            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Smooth Experience</div>
              <div className="mt-1 text-sm text-slate-700">
                Easy browsing, comparison-friendly product data, and
                consultation-first buying support.
              </div>
            </div>

            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Responsive Support</div>
              <div className="mt-1 text-sm text-slate-700">
                We aim to help with hearing-aid selection, fitting questions,
                care guidance, and order support.
              </div>
            </div>
          </div>
        </Card>
      </section>

      <section>
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
            FAQ
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="mx-auto mt-8 max-w-3xl space-y-3">
          {faqs.length ? (
            faqs.map((faq, index) => (
              <details
                key={`${faq.question}-${index}`}
                className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-5 shadow-[0_12px_34px_-24px_rgba(216,27,96,0.22)]"
              >
                <summary className="cursor-pointer list-none text-sm font-semibold text-slate-900">
                  {faq.question}
                </summary>
                <div className="mt-3 text-sm leading-7 text-slate-700">
                  {faq.answer}
                </div>
              </details>
            ))
          ) : (
            <Card className="rounded-3xl border border-[#f8bbd0] bg-white/80 p-6 text-sm text-slate-600">
              No FAQ added yet.
            </Card>
          )}
        </div>
      </section>

      <section className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-[#ffe4ec] to-white px-6 py-10 text-center shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)] sm:px-10 sm:py-14">
        <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
          Let’s Get Started
        </p>
        <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
          Discover hearing solutions matched to lifestyle, hearing range, and comfort
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-slate-700 sm:text-base">
          Browse our catalog of hearing devices and accessories, then reach out
          for guidance if you need help choosing the right solution.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/products"
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#d81b60] px-5 py-3 text-sm font-medium text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] transition hover:bg-[#c2185b]"
          >
            Shop Now
          </Link>
          <Link
            href="/orders"
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-[#f8bbd0] bg-white/75 px-5 py-3 text-sm font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
          >
            View Orders
          </Link>
        </div>
      </section>
    </div>
  );
}
