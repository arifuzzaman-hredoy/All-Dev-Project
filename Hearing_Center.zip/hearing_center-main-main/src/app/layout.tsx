import "./globals.css";
import "./scrollbar-hide.css";
import type { Metadata } from "next";
import favIcon from "@/assets/favicon.ico";
import { Providers } from "@/app/providers";
import { Header } from "@/components/layout/header";
import { MobileNav } from "@/components/layout/mobile-nav";
import SiteFooter from "@/components/layout/site-footer";
import FloatingWhatsAppButton from "@/components/layout/floating-whatsapp-button";


export const metadata: Metadata = {
  metadataBase: new URL("https://hearing.techteamlead.com"),
  title: {
    default: "Rangpur Hearing Center",
    template: "%s | Rangpur Hearing Center",
  },
  description:
    "Phonak hearing aids, hearing accessories, consultation support, and hearing-care solutions from Rangpur Hearing Center.",
  keywords:
    "hearing aids, Phonak Bangladesh, hearing consultation, hearing loss solutions, hearing accessories, Bangladesh, Rangpur Hearing Center",
  icons: {
    icon: [{ url: favIcon.src, type: "image/png" }],
    shortcut: [{ url: favIcon.src, type: "image/png" }],
    apple: [{ url: favIcon.src, type: "image/png" }],
  },
  openGraph: {
    title: "Rangpur Hearing Center",
    description:
      "Trusted Phonak hearing aids, accessories, and consultation-first hearing support from Rangpur Hearing Center.",
    url: "https://hearing.techteamlead.com",
    siteName: "Rangpur Hearing Center",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Rangpur Hearing Center",
    description:
      "Trusted hearing aids, accessories, and consultation support for better hearing.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-(--rhc-bg) text-(--rhc-text)">
        <Providers>
          <div className="min-h-screen overflow-x-hidden">
            <div className="print:hidden">
              <Header />
            </div>
            <main className="mx-auto max-w-7xl pb-24 md:pb-24">{children}</main>
            <SiteFooter />
            <FloatingWhatsAppButton />
            <MobileNav />
          </div>
        </Providers>
      </body>
    </html>
  );
}

