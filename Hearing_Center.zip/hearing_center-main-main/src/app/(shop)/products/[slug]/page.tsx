import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";
import { ChevronRight } from "lucide-react";
import ProductReviews from "@/components/reviews/product-reviews";
import ProductDetailsClient from "@/components/shop/product-details-client";
import RecommendedProducts from "@/components/products/recommended-products";
import { getProductBySlugWithRelatedProducts } from "@/lib/product-details";
import { getBestSellingProductIds } from "@/lib/best-selling";

function getProductContent(
  product: unknown,
): {
  shortDescription?: string | null;
  longDescription?: string | null;
  warranty?: string | null;
  fittingRange?: string | null;
  careGuide?: string | null;
  keyFeatures?: string[] | null;
  specifications?: Array<{ label: string; value: string }> | null;
} | null {
  if (!product || typeof product !== "object" || !("content" in product)) {
    return null;
  }

  const content = (product as { content?: unknown }).content;
  if (!content || typeof content !== "object") return null;

  return content as {
    shortDescription?: string | null;
    longDescription?: string | null;
    warranty?: string | null;
    fittingRange?: string | null;
    careGuide?: string | null;
    keyFeatures?: string[] | null;
    specifications?: Array<{ label: string; value: string }> | null;
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug?: string }> | { slug?: string };
}): Promise<Metadata> {
  const p = params instanceof Promise ? await params : params;
  const slug = p?.slug;

  if (!slug) {
    return {
      title: "Product",
      description: "Product details",
    };
  }

  const product = await prisma.product.findUnique({
    where: { slug },
    include: {
      content: true,
      images: { orderBy: { sortOrder: "asc" }, take: 1 },
      category: true,
    },
  }).catch(async (error: unknown) => {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return prisma.product.findUnique({
        where: { slug },
        include: {
          images: { orderBy: { sortOrder: "asc" }, take: 1 },
          category: true,
        },
      });
    }
    throw error;
  });

  if (!product) {
    return {
      title: "Product not found",
    };
  }

  const content = getProductContent(product);

  const image = product.images?.[0]?.url || "/placeholder.png";

  return {
    title: product.name,
    description:
      content?.shortDescription?.slice(0, 160) ||
      content?.longDescription?.slice(0, 160) ||
      product.description?.slice(0, 160) ||
      `${product.name} from Rangpur Hearing Center`,
    openGraph: {
      title: product.name,
      description:
        content?.shortDescription?.slice(0, 160) ||
        content?.longDescription?.slice(0, 160) ||
        product.description?.slice(0, 160) ||
        `${product.name} from Rangpur Hearing Center`,
      images: [image],
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: product.name,
      description:
        content?.shortDescription?.slice(0, 160) ||
        content?.longDescription?.slice(0, 160) ||
        product.description?.slice(0, 160) ||
        `${product.name} from Rangpur Hearing Center`,
      images: [image],
    },
  };
}

export default async function ProductDetailsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  if (!slug) return notFound();

  const {
    currentProduct: p,
    relatedProducts,
    fallbackProducts,
  } = await getProductBySlugWithRelatedProducts(slug);
  const bestSellingIds = await getBestSellingProductIds();

  if (!p) return notFound();

  const content = getProductContent(p);

  return (
    <>
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Product",
            name: p.name,
            description:
              content?.shortDescription ||
              content?.longDescription ||
              p.description ||
              p.name,
            sku: p.sku,
            image: p.images?.map((img) => img.url) || [],
            brand: {
              "@type": "Brand",
              name: "Rangpur Hearing Center",
            },
            offers: {
              "@type": "Offer",
              priceCurrency: "BDT",
              price: p.offerPrice ?? p.price,
              availability:
                p.stock > 0
                  ? "https://schema.org/InStock"
                  : "https://schema.org/OutOfStock",
            },
          }),
        }}
      />

      <div className="mx-auto max-w-6xl space-y-6 px-4 py-10">
        <section className="rounded-[24px] border border-[#ece7de] bg-white px-5 py-6 shadow-[0_18px_45px_-38px_rgba(15,23,42,0.24)] sm:px-7">
          <div className="flex flex-wrap items-center gap-2 text-sm text-black/55">
            <Link href="/" className="transition hover:text-black">
              Home
            </Link>
            <ChevronRight className="h-4 w-4" />
            <Link href="/products" className="transition hover:text-black">
              Products
            </Link>
            {p.category?.parent ? (
              <>
                <ChevronRight className="h-4 w-4" />
                <span>{p.category.parent.name}</span>
              </>
            ) : null}
            {p.category?.name ? (
              <>
                <ChevronRight className="h-4 w-4" />
                <span>{p.category.name}</span>
              </>
            ) : null}
          </div>

          <div className="mt-4 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8b5a2b]">
                {p.brand}
                {p.deviceStyle ? ` | ${p.deviceStyle}` : ""}
                {p.hearingLossRange ? ` | ${p.hearingLossRange}` : ""}
              </div>
              <h1 className="mt-2 text-3xl font-bold leading-tight text-[#334155] sm:text-4xl">
                {p.name}
              </h1>
              <p className="mt-3 text-sm leading-7 text-[#475569] sm:text-base">
                {content?.shortDescription ||
                  content?.longDescription ||
                  p.description ||
                  "Explore the full product details, technical snapshot, and support information below."}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <a
                href="#reviews"
                className="inline-flex items-center justify-center rounded-[14px] border border-[#efbf7e] bg-white px-4 py-2.5 text-sm font-semibold text-[#d88a26] transition hover:bg-[#fff8ee]"
              >
                Jump to Reviews
              </a>
              <Link
                href="/products"
                className="inline-flex items-center justify-center rounded-[14px] bg-[#ff4a3d] px-4 py-2.5 text-sm font-semibold text-white shadow-[0_14px_28px_-18px_rgba(255,74,61,0.55)] transition hover:bg-[#ef3f32]"
              >
                Back to Catalog
              </Link>
            </div>
          </div>
        </section>

        <ProductDetailsClient
          product={{
            id: p.id,
            name: p.name,
            brand: p.brand,
            modelCode: p.modelCode,
            deviceStyle: p.deviceStyle,
            hearingLossRange: p.hearingLossRange,
            batteryType: p.batteryType,
            connectivity: p.connectivity,
            isRechargeable: p.isRechargeable,
            sku: p.sku,
            description: p.description ?? null,
            shortDescription: content?.shortDescription ?? null,
            longDescription: content?.longDescription ?? p.description ?? null,
            warranty: content?.warranty ?? null,
            fittingRange: content?.fittingRange ?? null,
            careGuide: content?.careGuide ?? null,
            keyFeatures: Array.isArray(content?.keyFeatures)
              ? content.keyFeatures.filter(
                  (item): item is string => typeof item === "string" && !!item,
                )
              : [],
            specifications: Array.isArray(content?.specifications)
              ? content.specifications.filter(
                  (
                    item,
                  ): item is { label: string; value: string } =>
                    !!item &&
                    typeof item === "object" &&
                    "label" in item &&
                    "value" in item,
                )
              : [],
            price: p.price,
            offerPrice: p.offerPrice ?? null,
            stock: p.stock,
            isFeatured: p.isFeatured,
            isBestSelling: bestSellingIds.has(p.id),
            categoryName: p.category?.name ?? null,
            images: p.images.map((img) => ({
              id: img.id,
              url: img.url,
            })),
            variants: p.variants.map((v) => ({
              id: v.id,
              type: v.type,
              value: v.value,
              priceDiff: v.priceDiff,
              stock: v.stock,
              images: v.images.map((img) => ({
                id: img.id,
                url: img.url,
              })),
            })),
          }}
          relatedProducts={relatedProducts}
          fallbackProducts={fallbackProducts}
          compatibilityGroupLabel={p.compatibilityGroupLabel ?? null}
        />

        <RecommendedProducts
          title="Related Products"
          excludeProductIds={[p.id]}
          categoryIds={[
            p.categoryId,
            ...(p.category?.parent?.id ? [p.category.parent.id] : []),
          ]}
          fallbackToFeatured
          limit={8}
        />

        <div id="reviews">
          <ProductReviews productId={p.id} />
        </div>
      </div>
    </>
  );
}
