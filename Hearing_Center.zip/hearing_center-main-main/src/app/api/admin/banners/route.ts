import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { deleteLocalUploadByUrl } from "@/lib/local-uploads";

function isValidAbsoluteUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function normalizeBannerImageUrl(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;

  const imageUrl = value.trim();
  if (!imageUrl) return undefined;

  return imageUrl.startsWith("/uploads/") || isValidAbsoluteUrl(imageUrl)
    ? imageUrl
    : undefined;
}

function normalizeBannerSlot(value: unknown): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  if (typeof value !== "string") return undefined;

  return value.trim().toLowerCase() || null;
}

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok)
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const banners = await prisma.banner.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({ banners });
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok)
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const slot = normalizeBannerSlot(body.slot);
  const imageUrl = normalizeBannerImageUrl(body.imageUrl);

  if (body.slot !== undefined && slot === undefined) {
    return NextResponse.json({ message: "Invalid banner slot" }, { status: 400 });
  }

  if (!imageUrl) {
    return NextResponse.json(
      { message: "Banner image URL is invalid" },
      { status: 400 },
    );
  }

  const banner = await prisma.banner.create({
    data: {
      slot,
      title: body.title ?? null,
      imageUrl,
      linkUrl: body.linkUrl ?? null,
      sortOrder: body.sortOrder ?? 0,
      isActive: body.isActive ?? true,
    },
  });

  return NextResponse.json({ banner });
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok)
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const slot = normalizeBannerSlot(body.slot);
  const imageUrl = normalizeBannerImageUrl(body.imageUrl);

  if (!body?.id) {
    return NextResponse.json({ message: "Missing id" }, { status: 400 });
  }

  if (body.slot !== undefined && slot === undefined) {
    return NextResponse.json({ message: "Invalid banner slot" }, { status: 400 });
  }

  if (body.imageUrl !== undefined && !imageUrl) {
    return NextResponse.json(
      { message: "Banner image URL is invalid" },
      { status: 400 },
    );
  }

  const existing = await prisma.banner.findUnique({
    where: { id: body.id },
  });

  if (!existing) {
    return NextResponse.json({ message: "Banner not found" }, { status: 404 });
  }

  const nextImageUrl = imageUrl ?? existing.imageUrl;

  const banner = await prisma.banner.update({
    where: { id: body.id },
    data: {
      title: body.title ?? undefined,
      slot,
      imageUrl,
      linkUrl: body.linkUrl ?? undefined,
      sortOrder:
        typeof body.sortOrder === "number" ? body.sortOrder : undefined,
      isActive: typeof body.isActive === "boolean" ? body.isActive : undefined,
    },
  });

  if (existing.imageUrl !== nextImageUrl) {
    await deleteLocalUploadByUrl(existing.imageUrl);
  }

  return NextResponse.json({ banner });
}

export async function DELETE(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok)
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ message: "Missing id" }, { status: 400 });
  }

  const existing = await prisma.banner.findUnique({
    where: { id },
  });

  if (!existing) {
    return NextResponse.json({ message: "Banner not found" }, { status: 404 });
  }

  await prisma.banner.delete({ where: { id } });
  await deleteLocalUploadByUrl(existing.imageUrl);

  return NextResponse.json({ ok: true });
}
