import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const settings = await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {},
    create: { id: "default" },
  });

  return NextResponse.json({ settings });
}

export async function PUT(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();

  const settings = await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {
      storeName:
        typeof body.storeName === "string" ? body.storeName : undefined,
      logoUrl: typeof body.logoUrl === "string" ? body.logoUrl : undefined,
      taxRate: typeof body.taxRate === "number" ? body.taxRate : undefined,
      shippingInsideDhaka:
        typeof body.shippingInsideDhaka === "number"
          ? body.shippingInsideDhaka
          : undefined,
      shippingOutsideDhaka:
        typeof body.shippingOutsideDhaka === "number"
          ? body.shippingOutsideDhaka
          : undefined,
      shippingFreeOver:
        typeof body.shippingFreeOver === "number"
          ? body.shippingFreeOver
          : undefined,
      codEnabled:
        typeof body.codEnabled === "boolean" ? body.codEnabled : undefined,
      onlineEnabled:
        typeof body.onlineEnabled === "boolean"
          ? body.onlineEnabled
          : undefined,
      lowStockThreshold:
        typeof body.lowStockThreshold === "number"
          ? body.lowStockThreshold
          : undefined,

      facebookUrl:
        typeof body.facebookUrl === "string" ? body.facebookUrl : undefined,
      instagramUrl:
        typeof body.instagramUrl === "string" ? body.instagramUrl : undefined,
      youtubeUrl:
        typeof body.youtubeUrl === "string" ? body.youtubeUrl : undefined,
      tiktokUrl:
        typeof body.tiktokUrl === "string" ? body.tiktokUrl : undefined,
      whatsappUrl:
        typeof body.whatsappUrl === "string" ? body.whatsappUrl : undefined,

      returnRefundPolicy:
        typeof body.returnRefundPolicy === "string"
          ? body.returnRefundPolicy
          : undefined,
      aboutUs: typeof body.aboutUs === "string" ? body.aboutUs : undefined,
      aboutFaqs: Array.isArray(body.aboutFaqs) ? body.aboutFaqs : undefined,

      privacyPolicy:
        typeof body.privacyPolicy === "string" ? body.privacyPolicy : undefined,
      termsConditions:
        typeof body.termsConditions === "string"
          ? body.termsConditions
          : undefined,
    },
    create: {
      id: "default",
      storeName:
        typeof body.storeName === "string"
          ? body.storeName
          : "Rangpur Hearing Center",
      logoUrl: typeof body.logoUrl === "string" ? body.logoUrl : "",
      taxRate: typeof body.taxRate === "number" ? body.taxRate : 0,
      shippingInsideDhaka:
        typeof body.shippingInsideDhaka === "number"
          ? body.shippingInsideDhaka
          : 0,
      shippingOutsideDhaka:
        typeof body.shippingOutsideDhaka === "number"
          ? body.shippingOutsideDhaka
          : 0,
      shippingFreeOver:
        typeof body.shippingFreeOver === "number" ? body.shippingFreeOver : 0,
      codEnabled: typeof body.codEnabled === "boolean" ? body.codEnabled : true,
      onlineEnabled:
        typeof body.onlineEnabled === "boolean" ? body.onlineEnabled : false,
      lowStockThreshold:
        typeof body.lowStockThreshold === "number" ? body.lowStockThreshold : 5,

      facebookUrl: typeof body.facebookUrl === "string" ? body.facebookUrl : "",
      instagramUrl:
        typeof body.instagramUrl === "string" ? body.instagramUrl : "",
      youtubeUrl: typeof body.youtubeUrl === "string" ? body.youtubeUrl : "",
      tiktokUrl: typeof body.tiktokUrl === "string" ? body.tiktokUrl : "",
      whatsappUrl: typeof body.whatsappUrl === "string" ? body.whatsappUrl : "",

      returnRefundPolicy:
        typeof body.returnRefundPolicy === "string"
          ? body.returnRefundPolicy
          : "",
      aboutUs: typeof body.aboutUs === "string" ? body.aboutUs : "",
      aboutFaqs: Array.isArray(body.aboutFaqs) ? body.aboutFaqs : [],

      privacyPolicy:
        typeof body.privacyPolicy === "string" ? body.privacyPolicy : "",
      termsConditions:
        typeof body.termsConditions === "string" ? body.termsConditions : "",
    },
  });

  return NextResponse.json({ settings });
}
