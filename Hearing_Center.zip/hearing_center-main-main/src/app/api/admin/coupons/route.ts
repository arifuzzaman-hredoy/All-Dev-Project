import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ coupons });
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const b = await req.json();
  const coupon = await prisma.coupon.create({
    data: {
      code: String(b.code).toUpperCase().trim(),
      type: b.type,
      value: b.value,
      minSubtotal: b.minSubtotal ?? 0,
      maxDiscount: b.maxDiscount ?? null,
      startsAt: b.startsAt ? new Date(b.startsAt) : null,
      endsAt: b.endsAt ? new Date(b.endsAt) : null,
      usageLimit: b.usageLimit ?? null,
      isActive: b.isActive ?? true,
    },
  });
  return NextResponse.json({ coupon });
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const b = await req.json();
  const coupon = await prisma.coupon.update({
    where: { id: b.id },
    data: {
      code: b.code ? String(b.code).toUpperCase().trim() : undefined,
      type: b.type ?? undefined,
      value: typeof b.value === "number" ? b.value : undefined,
      minSubtotal: typeof b.minSubtotal === "number" ? b.minSubtotal : undefined,
      maxDiscount: b.maxDiscount ?? undefined,
      startsAt: b.startsAt ? new Date(b.startsAt) : undefined,
      endsAt: b.endsAt ? new Date(b.endsAt) : undefined,
      usageLimit: b.usageLimit ?? undefined,
      isActive: typeof b.isActive === "boolean" ? b.isActive : undefined,
    },
  });
  return NextResponse.json({ coupon });
}

export async function DELETE(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ message: "Missing id" }, { status: 400 });

  await prisma.coupon.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}