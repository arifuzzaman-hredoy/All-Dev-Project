import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import {
  normalizeHearingCatalogSettings,
  parseLineList,
} from "@/lib/hearing-catalog";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  try {
    const settings = await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: {},
      create: { id: "default" },
    });

    return NextResponse.json({
      settings: normalizeHearingCatalogSettings({
        deviceStyleOptions: settings.deviceStyleOptions as string[] | undefined,
        hearingLossOptions: settings.hearingLossOptions as string[] | undefined,
        batteryTypeOptions: settings.batteryTypeOptions as string[] | undefined,
        connectivityOptions: settings.connectivityOptions as string[] | undefined,
      }),
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          message:
            "Hearing catalog settings fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }
    throw error;
  }
}

export async function PUT(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const settings = normalizeHearingCatalogSettings({
    deviceStyleOptions: parseLineList(
      typeof body?.deviceStyleOptions === "string" ? body.deviceStyleOptions : "",
    ),
    hearingLossOptions: parseLineList(
      typeof body?.hearingLossOptions === "string" ? body.hearingLossOptions : "",
    ),
    batteryTypeOptions: parseLineList(
      typeof body?.batteryTypeOptions === "string" ? body.batteryTypeOptions : "",
    ),
    connectivityOptions: parseLineList(
      typeof body?.connectivityOptions === "string" ? body.connectivityOptions : "",
    ),
  });

  try {
    const updated = await prisma.storeSettings.upsert({
      where: { id: "default" },
      update: {
        deviceStyleOptions: settings.deviceStyleOptions,
        hearingLossOptions: settings.hearingLossOptions,
        batteryTypeOptions: settings.batteryTypeOptions,
        connectivityOptions: settings.connectivityOptions,
      },
      create: {
        id: "default",
        deviceStyleOptions: settings.deviceStyleOptions,
        hearingLossOptions: settings.hearingLossOptions,
        batteryTypeOptions: settings.batteryTypeOptions,
        connectivityOptions: settings.connectivityOptions,
      },
    });

    return NextResponse.json({
      settings: normalizeHearingCatalogSettings({
        deviceStyleOptions: updated.deviceStyleOptions as string[] | undefined,
        hearingLossOptions: updated.hearingLossOptions as string[] | undefined,
        batteryTypeOptions: updated.batteryTypeOptions as string[] | undefined,
        connectivityOptions: updated.connectivityOptions as string[] | undefined,
      }),
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          message:
            "Hearing catalog settings fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }
    throw error;
  }
}
