import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getPagination, makePaginatedResponse } from "@/lib/pagination";

type ErrorResponse = { error: string };
type ConsultationStatus =
  | "PENDING"
  | "CONTACTED"
  | "CONFIRMED"
  | "FOLLOW_UP"
  | "NO_ANSWER"
  | "CLOSED"
  | "CANCELLED";

const CONSULTATION_STATUSES: ConsultationStatus[] = [
  "PENDING",
  "CONTACTED",
  "CONFIRMED",
  "FOLLOW_UP",
  "NO_ANSWER",
  "CLOSED",
  "CANCELLED",
];

type ConsultationListItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  email: string | null;
  status: ConsultationStatus;
  adminNote: string | null;
  followUpDate: string | null;
  contactedAt: string | null;
  closedAt: string | null;
  hearingAidUsage: string | null;
  hearingTestDone: string | null;
  tinnitus: string | null;
  crowdDifficulty: string | null;
  dailyLifeImpact: string | null;
  age: string | null;
  district: string | null;
  budget: string | null;
};

type Response = {
  items: ConsultationListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

async function requireAdmin(): Promise<
  { ok: true } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;

  if (role !== "ADMIN" && role !== "STAFF") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();
  const status = (searchParams.get("status") || "").trim();

  const { page, take, skip } = getPagination({
    page: searchParams.get("page"),
    take: searchParams.get("take"),
    defaultTake: 20,
    minTake: 10,
    maxTake: 50,
  });

  const and: Prisma.ConsultationWhereInput[] = [];

  if (q) {
    and.push({
      OR: [
        { name: { contains: q, mode: "insensitive" } },
        { phone: { contains: q, mode: "insensitive" } },
        { email: { contains: q, mode: "insensitive" } },
        { district: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (
    status &&
    CONSULTATION_STATUSES.includes(status as ConsultationStatus)
  ) {
    and.push({ status: status as never });
  }

  const where: Prisma.ConsultationWhereInput = and.length ? { AND: and } : {};

  try {
    const [consultations, total] = await Promise.all([
      (prisma.consultation.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip,
        take,
      }) as unknown as Promise<
        Array<{
          id: string;
          createdAt: Date;
          name: string;
          phone: string;
          email: string | null;
          status: ConsultationStatus;
          adminNote: string | null;
          followUpDate: Date | null;
          contactedAt: Date | null;
          closedAt: Date | null;
          hearingAidUsage: string | null;
          hearingTestDone: string | null;
          tinnitus: string | null;
          crowdDifficulty: string | null;
          dailyLifeImpact: string | null;
          age: string | null;
          district: string | null;
          budget: string | null;
        }>
      >),
      prisma.consultation.count({ where }),
    ]);

    const items: ConsultationListItem[] = consultations.map((item) => ({
      id: item.id,
      createdAt: item.createdAt.toISOString(),
      name: item.name,
      phone: item.phone,
      email: item.email,
      status: item.status,
      adminNote: item.adminNote,
      followUpDate: item.followUpDate ? item.followUpDate.toISOString() : null,
      contactedAt: item.contactedAt ? item.contactedAt.toISOString() : null,
      closedAt: item.closedAt ? item.closedAt.toISOString() : null,
      hearingAidUsage: item.hearingAidUsage,
      hearingTestDone: item.hearingTestDone,
      tinnitus: item.tinnitus,
      crowdDifficulty: item.crowdDifficulty,
      dailyLifeImpact: item.dailyLifeImpact,
      age: item.age,
      district: item.district,
      budget: item.budget,
    }));

    return NextResponse.json(
      makePaginatedResponse({
        items,
        total,
        page,
        take,
      }),
    );
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;

    // Backward-compatible fallback until the new migration is applied.
    if (prismaError?.code === "P2022") {
      const [consultations, total] = await Promise.all([
        prisma.consultation.findMany({
          where,
          orderBy: { createdAt: "desc" },
          skip,
          take,
          select: {
            id: true,
            createdAt: true,
            name: true,
            phone: true,
            email: true,
            hearingAidUsage: true,
            hearingTestDone: true,
            tinnitus: true,
            crowdDifficulty: true,
            dailyLifeImpact: true,
            age: true,
            district: true,
            budget: true,
          },
        }),
        prisma.consultation.count({ where }),
      ]);

      const items: ConsultationListItem[] = consultations.map((item) => ({
        id: item.id,
        createdAt: item.createdAt.toISOString(),
        name: item.name,
        phone: item.phone,
        email: item.email,
        status: "PENDING",
        adminNote: null,
        followUpDate: null,
        contactedAt: null,
        closedAt: null,
        hearingAidUsage: item.hearingAidUsage,
        hearingTestDone: item.hearingTestDone,
        tinnitus: item.tinnitus,
        crowdDifficulty: item.crowdDifficulty,
        dailyLifeImpact: item.dailyLifeImpact,
        age: item.age,
        district: item.district,
        budget: item.budget,
      }));

      return NextResponse.json(
        makePaginatedResponse({
          items,
          total,
          page,
          take,
        }),
      );
    }

    return NextResponse.json(
      { error: "Could not load consultation requests." },
      { status: 500 },
    );
  }
}
