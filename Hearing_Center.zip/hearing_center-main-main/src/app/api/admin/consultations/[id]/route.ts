import { NextRequest, NextResponse } from "next/server";
import { Role } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type ErrorResponse = { error: string };
type AuthUser = { id: string; role: Role; email: string };
type ConsultationStatus =
  | "PENDING"
  | "CONTACTED"
  | "CONFIRMED"
  | "FOLLOW_UP"
  | "NO_ANSWER"
  | "CLOSED"
  | "CANCELLED";

const CONSULTATION_STATUSES: ConsultationStatus[] = [
  "PENDING",
  "CONTACTED",
  "CONFIRMED",
  "FOLLOW_UP",
  "NO_ANSWER",
  "CLOSED",
  "CANCELLED",
];

async function requireAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "STAFF")) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

type PatchBody = {
  status?: ConsultationStatus;
  adminNote?: string | null;
  followUpDate?: string | null;
};

export async function PATCH(
  req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as PatchBody;
  const data: {
    status?: ConsultationStatus;
    adminNote?: string | null;
    followUpDate?: Date | null;
    contactedAt?: Date | null;
    closedAt?: Date | null;
  } = {};

  if (body.status && CONSULTATION_STATUSES.includes(body.status)) {
    data.status = body.status;

    if (
      body.status === "CONTACTED" ||
      body.status === "CONFIRMED" ||
      body.status === "FOLLOW_UP"
    ) {
      data.contactedAt = new Date();
    }

    if (
      body.status === "CLOSED" ||
      body.status === "CANCELLED"
    ) {
      data.closedAt = new Date();
    }
  }

  if (body.adminNote === null) data.adminNote = null;
  else if (typeof body.adminNote === "string") {
    data.adminNote = body.adminNote.trim() || null;
  }

  if (body.followUpDate === null || body.followUpDate === "") {
    data.followUpDate = null;
  } else if (typeof body.followUpDate === "string") {
    const date = new Date(body.followUpDate);
    if (!Number.isNaN(date.getTime())) {
      data.followUpDate = date;
    }
  }

  try {
    await prisma.consultation.update({
      where: { id },
      data,
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;

    if (prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          error:
            "Consultation tracking fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }

    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
