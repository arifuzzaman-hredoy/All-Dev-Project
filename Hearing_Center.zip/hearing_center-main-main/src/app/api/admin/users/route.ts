import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Role, Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { normalizeCart } from "@/lib/cart.server";

type ErrorResponse = { error: string };

type UserItem = {
  id: string;
  name: string | null;
  email: string;
  role: Role;
  blocked: boolean;
  createdAt: string;
  ordersCount: number;
  cartCount: number;
};

type Response = {
  items: UserItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function num(v: string | null, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

type AuthUser = { id: string; role: Role; email: string };

async function requireStaffOrAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  if (user.role !== "ADMIN" && user.role !== "STAFF") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireStaffOrAdminDb();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") || "").trim();
  const role = (searchParams.get("role") || "").trim();
  const minCart = Math.max(0, num(searchParams.get("minCart"), 0));
  const rawMaxCart = searchParams.get("maxCart");
  const parsedMaxCart = num(rawMaxCart, 0);
  const maxCart =
    rawMaxCart === null || rawMaxCart.trim() === ""
      ? null
      : Math.max(minCart, parsedMaxCart);

  const page = Math.max(1, num(searchParams.get("page"), 1));
  const take = clamp(num(searchParams.get("take"), 20), 10, 50);

  const and: Prisma.UserWhereInput[] = [];

  if (q) {
    and.push({
      OR: [
        { email: { contains: q, mode: "insensitive" } },
        { name: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (role && Object.values(Role).includes(role as Role)) {
    and.push({ role: role as Role });
  }

  const where: Prisma.UserWhereInput = and.length ? { AND: and } : {};

  const users = await prisma.user.findMany({
    where,
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      blocked: true,
      cartJson: true,
      createdAt: true,
      _count: { select: { orders: true } },
    },
  });

  const filteredUsers = users
    .map((u) => {
      const cartCount = normalizeCart(u.cartJson).items.reduce(
        (sum, item) => sum + item.qty,
        0,
      );

      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        blocked: u.blocked,
        createdAt: u.createdAt.toISOString(),
        ordersCount: u._count.orders,
        cartCount,
      };
    })
    .filter((u) => {
      if (u.cartCount < minCart) return false;
      if (maxCart !== null && u.cartCount > maxCart) return false;
      return true;
    });

  const total = filteredUsers.length;
  const pages = Math.max(1, Math.ceil(total / take));
  const safePage = Math.min(page, pages);
  const skip = (safePage - 1) * take;
  const pagedUsers = filteredUsers.slice(skip, skip + take);

  return NextResponse.json({
    items: pagedUsers,
    total,
    page: safePage,
    take,
    pages,
  });
}
