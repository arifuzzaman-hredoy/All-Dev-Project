import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { Role } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { normalizeCart } from "@/lib/cart.server";
import { buildCartDetails } from "@/lib/cart-details";

type ErrorResponse = { error: string };

type AuthUser = { id: string; role: Role; email: string };

type CartResponse = {
  items: Awaited<ReturnType<typeof buildCartDetails>>;
  totalQty: number;
};

async function requireStaffOrAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "STAFF")) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

export async function GET(
  _req: Request,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<CartResponse | ErrorResponse>> {
  const gate = await requireStaffOrAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = typeof p?.id === "string" ? p.id : "";

  if (!id.trim()) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const user = await prisma.user.findUnique({
    where: { id },
    select: { cartJson: true },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const cart = normalizeCart(user.cartJson);
  const items = await buildCartDetails(cart.items);
  const totalQty = cart.items.reduce((sum, item) => sum + item.qty, 0);

  return NextResponse.json({ items, totalQty });
}
