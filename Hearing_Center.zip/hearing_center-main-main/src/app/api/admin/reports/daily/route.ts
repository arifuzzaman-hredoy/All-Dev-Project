import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { OrderStatus, PaymentStatus } from "@prisma/client";

type ErrorResponse = { error: string };

type DayPoint = {
  day: string; // YYYY-MM-DD
  revenue: number;
  orders: number;
};

type Response = {
  ok: true;
  days: DayPoint[];
};

async function requireAdmin(): Promise<{ ok: true } | { ok: false; res: NextResponse<ErrorResponse> }> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;
  if (role !== "ADMIN" && role !== "STAFF") {
    return { ok: false, res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { ok: true };
}

function isoDayUTC(d: Date): string {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Dhaka day start in UTC (UTC+6)
function dhakaStartUTC(dateUTC: Date): Date {
  const offsetMs = 6 * 60 * 60 * 1000;
  const dhakaNow = new Date(dateUTC.getTime() + offsetMs);
  const startDhaka = new Date(Date.UTC(dhakaNow.getUTCFullYear(), dhakaNow.getUTCMonth(), dhakaNow.getUTCDate()));
  return new Date(startDhaka.getTime() - offsetMs);
}

export async function GET(req: NextRequest): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);
  const daysParam = Number(searchParams.get("days") || "14");
  const days = Number.isFinite(daysParam) ? Math.max(7, Math.min(60, Math.floor(daysParam))) : 14;

  const now = new Date();
  const end = dhakaStartUTC(now); // start of today (Dhaka), so chart covers previous full days
  const start = new Date(end.getTime() - days * 24 * 60 * 60 * 1000);

  // fetch all orders in one range then bucket them (simple + stable)
  const orders = await prisma.order.findMany({
    where: {
      createdAt: { gte: start, lt: end },
      status: { not: OrderStatus.CANCELLED },
      paymentStatus: PaymentStatus.PAID,
    },
    select: { createdAt: true, total: true },
  });

  // init buckets
  const map = new Map<string, { revenue: number; orders: number }>();
  for (let i = 0; i < days; i++) {
    const d = new Date(start.getTime() + i * 24 * 60 * 60 * 1000);
    map.set(isoDayUTC(dhakaStartUTC(d)), { revenue: 0, orders: 0 });
  }

  // bucket by Dhaka date
  const offsetMs = 6 * 60 * 60 * 1000;
  for (const o of orders) {
    const dhaka = new Date(o.createdAt.getTime() + offsetMs);
    const key = isoDayUTC(new Date(Date.UTC(dhaka.getUTCFullYear(), dhaka.getUTCMonth(), dhaka.getUTCDate())));
    const curr = map.get(key);
    if (curr) {
      curr.revenue += o.total;
      curr.orders += 1;
    }
  }

  const out: DayPoint[] = Array.from(map.entries())
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([day, v]) => ({ day, revenue: v.revenue, orders: v.orders }));

  return NextResponse.json({ ok: true, days: out });
}