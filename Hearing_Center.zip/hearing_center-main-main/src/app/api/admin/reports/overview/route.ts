import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { OrderStatus, PaymentStatus } from "@prisma/client";

type ErrorResponse = { error: string };

type MonthPoint = { month: string; revenue: number; orders: number };
type BestSellingItem = { productId: string; name: string; slug: string; qty: number; revenue: number };

type Response = {
  ok: true;

  last30Days: { orders: number; revenue: number; productSales: number };
  thisMonth: { orders: number; revenue: number };

  monthly: MonthPoint[]; // last 6 months
  bestSelling30: BestSellingItem[]; // top 10 last 30 days
};

async function requireAdmin(): Promise<{ ok: true } | { ok: false; res: NextResponse<ErrorResponse> }> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;
  if (role !== "ADMIN" && role !== "STAFF") {
    return { ok: false, res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { ok: true };
}

function startOfMonthUTC(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}
function addMonthsUTC(d: Date, months: number): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + months, 1));
}
function ymLabel(d: Date): string {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export async function GET(): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const now = new Date();
  const last30Start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const thisMonthStart = startOfMonthUTC(now);
  const nextMonthStart = addMonthsUTC(thisMonthStart, 1);

  // monthly last 6 months points (including current month)
  const monthStarts: Date[] = [];
  for (let i = 5; i >= 0; i--) {
    monthStarts.push(addMonthsUTC(thisMonthStart, -i));
  }

  const statusFilter = { not: OrderStatus.CANCELLED };

  const [agg30, aggThisMonth, productSales30] = await Promise.all([
    prisma.order.aggregate({
      where: {
        createdAt: { gte: last30Start },
        status: statusFilter,
        paymentStatus: PaymentStatus.PAID,
      },
      _count: { id: true },
      _sum: { total: true },
    }),
    prisma.order.aggregate({
      where: {
        createdAt: { gte: thisMonthStart, lt: nextMonthStart },
        status: statusFilter,
        paymentStatus: PaymentStatus.PAID,
      },
      _count: { id: true },
      _sum: { total: true },
    }),
    prisma.orderItem.aggregate({
      where: {
        order: {
          createdAt: { gte: last30Start },
          status: statusFilter,
          paymentStatus: PaymentStatus.PAID,
        },
      },
      _sum: { qty: true },
    }),
  ]);

  // monthly series: compute each month range separately (simple & reliable)
  const monthly: MonthPoint[] = [];
  for (let i = 0; i < monthStarts.length; i++) {
    const start = monthStarts[i];
    const end = addMonthsUTC(start, 1);

    const a = await prisma.order.aggregate({
      where: {
        createdAt: { gte: start, lt: end },
        status: statusFilter,
        paymentStatus: PaymentStatus.PAID,
      },
      _count: { id: true },
      _sum: { total: true },
    });

    monthly.push({
      month: ymLabel(start),
      revenue: a._sum.total ?? 0,
      orders: a._count.id ?? 0,
    });
  }

  // best selling (last 30 days) based on OrderItem qty and lineTotal
  const grouped = await prisma.orderItem.groupBy({
    by: ["productId"],
    where: {
      order: {
        createdAt: { gte: last30Start },
        status: statusFilter,
        paymentStatus: PaymentStatus.PAID,
      },
    },
    _sum: { qty: true, lineTotal: true },
    orderBy: { _sum: { qty: "desc" } },
    take: 10,
  });

  const ids = grouped.map((g) => g.productId);
  const products = ids.length
    ? await prisma.product.findMany({
        where: { id: { in: ids } },
        select: { id: true, name: true, slug: true },
      })
    : [];

  const pMap = new Map(products.map((p) => [p.id, p] as const));

  const bestSelling30: BestSellingItem[] = grouped
    .map((g) => {
      const p = pMap.get(g.productId);
      return {
        productId: g.productId,
        name: p?.name ?? "Unknown",
        slug: p?.slug ?? "",
        qty: g._sum.qty ?? 0,
        revenue: g._sum.lineTotal ?? 0,
      };
    })
    .filter((x) => x.slug);

  return NextResponse.json({
    ok: true,
    last30Days: {
      orders: agg30._count.id ?? 0,
      revenue: agg30._sum.total ?? 0,
      productSales: productSales30._sum.qty ?? 0,
    },
    thisMonth: { orders: aggThisMonth._count.id ?? 0, revenue: aggThisMonth._sum.total ?? 0 },
    monthly,
    bestSelling30,
  });
}
