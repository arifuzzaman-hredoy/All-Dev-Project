import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { OrderStatus, PaymentStatus, Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getPagination, makePaginatedResponse } from "@/lib/pagination";

type ErrorResponse = { error: string };

type AdminOrderListItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  itemsCount: number;
  couponCode: string | null;
  courierName: string | null;
  trackingId: string | null;
};

type Response = {
  items: AdminOrderListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

async function requireAdmin(): Promise<
  { ok: true } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;

  if (role !== "ADMIN" && role !== "STAFF") {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true };
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<Response | ErrorResponse>> {
  const gate = await requireAdmin();
  if (!gate.ok) return gate.res;

  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") || "").trim();
  const status = (searchParams.get("status") || "").trim();
  const payment = (searchParams.get("payment") || "").trim();

  const { page, take, skip } = getPagination({
    page: searchParams.get("page"),
    take: searchParams.get("take"),
    defaultTake: 20,
    minTake: 10,
    maxTake: 50,
  });

  const and: Prisma.OrderWhereInput[] = [];

  if (q) {
    and.push({
      OR: [
        { id: { contains: q, mode: "insensitive" } },
        { name: { contains: q, mode: "insensitive" } },
        { phone: { contains: q, mode: "insensitive" } },
        { trackingId: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (status && Object.values(OrderStatus).includes(status as OrderStatus)) {
    and.push({ status: status as OrderStatus });
  }

  if (
    payment &&
    Object.values(PaymentStatus).includes(payment as PaymentStatus)
  ) {
    and.push({ paymentStatus: payment as PaymentStatus });
  }

  const where: Prisma.OrderWhereInput = and.length ? { AND: and } : {};

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take,
      select: {
        id: true,
        createdAt: true,
        name: true,
        phone: true,
        total: true,
        status: true,
        paymentStatus: true,
        couponCode: true,
        courierName: true,
        trackingId: true,
        _count: {
          select: {
            items: true,
          },
        },
      },
    }),
    prisma.order.count({ where }),
  ]);

  const items: AdminOrderListItem[] = orders.map((o) => ({
    id: o.id,
    createdAt: o.createdAt.toISOString(),
    name: o.name,
    phone: o.phone,
    total: o.total,
    status: o.status,
    paymentStatus: o.paymentStatus,
    itemsCount: o._count.items,
    couponCode: o.couponCode ?? null,
    courierName: o.courierName ?? null,
    trackingId: o.trackingId ?? null,
  }));

  return NextResponse.json(
    makePaginatedResponse({
      items,
      total,
      page,
      take,
    }),
  );
}
