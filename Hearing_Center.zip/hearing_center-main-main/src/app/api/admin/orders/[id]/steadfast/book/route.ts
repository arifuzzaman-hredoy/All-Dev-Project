import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import {
  createSteadfastOrder,
  isSteadfastEnabled,
} from "@/lib/couriers/steadfast";

// type ErrorResponse = { error: string };

async function requireAdminOrStaff() {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false as const,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { role: true },
  });

  if (!user || (user.role !== Role.ADMIN && user.role !== Role.STAFF)) {
    return {
      ok: false as const,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true as const };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export async function POST(
  _req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
) {
  const gate = await requireAdminOrStaff();
  if (!gate.ok) return gate.res;

  if (!isSteadfastEnabled()) {
    return NextResponse.json(
      { error: "Steadfast integration is disabled" },
      { status: 400 },
    );
  }

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid order id" }, { status: 400 });
  }

  const order = await prisma.order.findUnique({
    where: { id },
    include: { items: true },
  });

  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  const result = await createSteadfastOrder({
    id: order.id,
    createdAt: order.createdAt,
    name: order.name,
    email: order.email,
    phone: order.phone,
    addressLine1: order.addressLine1,
    addressLine2: order.addressLine2,
    city: order.city,
    area: order.area,
    total: order.total,
    items: order.items.map((it) => ({
      sku: it.sku,
      qty: it.qty,
    })),
  });

  if (!result.ok) {
    return NextResponse.json(
      { error: result.errorMessage || "Steadfast booking failed" },
      { status: 400 },
    );
  }

  await prisma.order.update({
    where: { id: order.id },
    data: {
      courierName: "Steadfast",
      status: order.status === "PENDING" ? "PROCESSING" : order.status,
    },
  });

  return NextResponse.json({
    ok: true,
    message: "Booked in Steadfast",
    response: result.response,
  });
}
