import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  OrderStatus,
  PaymentStatus,
  PaymentMethod,
  Role,
} from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

type ErrorResponse = { error: string };

type OrderDetailsResponse = {
  id: string;
  createdAt: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  name: string;
  phone: string;
  email: string | null;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  area: string | null;
  note: string | null;
  couponCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  courierName: string | null;
  trackingId: string | null;
  items: Array<{
    id: string;
    productName: string;
    sku: string;
    unitPrice: number;
    qty: number;
    lineTotal: number;
  }>;
};

type AuthUser = { id: string; role: Role; email: string };

async function requireAdminDb(): Promise<
  { ok: true; user: AuthUser } | { ok: false; res: NextResponse<ErrorResponse> }
> {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email;

  if (!email) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "STAFF")) {
    return {
      ok: false,
      res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  return { ok: true, user };
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export async function GET(
  _req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<OrderDetailsResponse | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const order = await prisma.order.findUnique({
    where: { id },
    include: { items: true },
  });

  if (!order) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({
    id: order.id,
    createdAt: order.createdAt.toISOString(),
    status: order.status,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod,
    name: order.name,
    phone: order.phone,
    email: order.email ?? null,
    addressLine1: order.addressLine1,
    addressLine2: order.addressLine2 ?? null,
    city: order.city,
    area: order.area ?? null,
    note: order.note ?? null,
    couponCode: order.couponCode ?? null,
    subtotal: order.subtotal,
    discount: order.discount,
    shipping: order.shipping,
    tax: order.tax ?? 0,
    total: order.total,
    courierName: order.courierName ?? null,
    trackingId: order.trackingId ?? null,
    items: order.items.map((it) => ({
      id: it.id,
      productName: it.productName,
      sku: it.sku,
      unitPrice: it.unitPrice,
      qty: it.qty,
      lineTotal: it.lineTotal,
    })),
  });
}

type PatchBody = {
  status?: OrderStatus;
  paymentStatus?: PaymentStatus;
  courierName?: string | null;
  trackingId?: string | null;
};

export async function PATCH(
  req: NextRequest,
  ctx: { params: Promise<{ id?: string }> | { id?: string } },
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const gate = await requireAdminDb();
  if (!gate.ok) return gate.res;

  const p = ctx.params instanceof Promise ? await ctx.params : ctx.params;
  const id = p?.id;

  if (!isNonEmptyString(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as PatchBody;

  const data: PatchBody = {};

  if (body.status && Object.values(OrderStatus).includes(body.status)) {
    data.status = body.status;
  }

  if (
    body.paymentStatus &&
    Object.values(PaymentStatus).includes(body.paymentStatus)
  ) {
    data.paymentStatus = body.paymentStatus;
  }

  if (body.courierName === null) data.courierName = null;
  else if (typeof body.courierName === "string") {
    data.courierName = body.courierName.trim() || null;
  }

  if (body.trackingId === null) data.trackingId = null;
  else if (typeof body.trackingId === "string") {
    data.trackingId = body.trackingId.trim() || null;
  }

  await prisma.order.update({
    where: { id },
    data,
  });

  return NextResponse.json({ ok: true });
}
