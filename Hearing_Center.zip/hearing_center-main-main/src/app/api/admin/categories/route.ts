import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";

const createSchema = z.object({
  name: z.string().min(2),
  parentId: z.string().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
});

const reorderSchema = z.object({
  items: z
    .array(
      z.object({
        id: z.string().min(1),
        parentId: z.string().nullable(),
        sortOrder: z.number().int().nonnegative(),
      }),
    )
    .min(1),
});

export async function GET() {
  const items = await prisma.category.findMany({
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
      children: {
        select: {
          id: true,
          name: true,
          slug: true,
          parentId: true,
          isActive: true,
          imageUrl: true,
          sortOrder: true,
        },
        orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      },
      _count: {
        select: {
          products: true,
          children: true,
        },
      },
    },
    orderBy: [{ parentId: "asc" }, { sortOrder: "asc" }, { name: "asc" }],
  });

  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const g = await requireAdmin(req);
  if (!g.ok)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success)
    return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const { name, parentId, imageUrl } = parsed.data;

  if (parentId) {
    const parent = await prisma.category.findUnique({
      where: { id: parentId },
      select: { id: true },
    });

    if (!parent) {
      return NextResponse.json(
        { error: "Parent category not found" },
        { status: 404 },
      );
    }
  }

  const sibling = await prisma.category.findFirst({
    where: { parentId: parentId || null },
    orderBy: [{ sortOrder: "desc" }],
    select: { sortOrder: true },
  });

  const slugBase = slugify(name);
  let slug = slugBase;
  let i = 1;

  while (await prisma.category.findUnique({ where: { slug } })) {
    slug = `${slugBase}-${i++}`;
  }

  const created = await prisma.category.create({
    data: {
      name,
      slug,
      parentId: parentId || null,
      imageUrl: imageUrl || null,
      sortOrder: (sibling?.sortOrder ?? -1) + 1,
    },
    include: {
      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
    },
  });

  return NextResponse.json(created, { status: 201 });
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = reorderSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const { items } = parsed.data;

  await prisma.$transaction(
    items.map((item) =>
      prisma.category.update({
        where: { id: item.id },
        data: {
          parentId: item.parentId,
          sortOrder: item.sortOrder,
        },
      }),
    ),
  );

  return NextResponse.json({ ok: true });
}
