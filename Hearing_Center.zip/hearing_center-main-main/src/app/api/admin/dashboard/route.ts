import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin-guard";
import { OrderStatus, PaymentStatus } from "@prisma/client";

export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const settings = await prisma.storeSettings.upsert({
    where: { id: "default" },
    update: {},
    create: { id: "default" },
  });

  const [totalUsers, totalOrders, paidAgg] = await Promise.all([
    prisma.user.count(),
    prisma.order.count(),
    prisma.order.aggregate({
      _sum: { total: true },
      where: {
        paymentStatus: PaymentStatus.PAID,
        status: { not: OrderStatus.CANCELLED },
      },
    }),
  ]);

  const bestSelling = await prisma.orderItem.groupBy({
    by: ["productId"],
    where: {
      order: {
        paymentStatus: PaymentStatus.PAID,
        status: { not: OrderStatus.CANCELLED },
      },
    },
    _sum: { qty: true },
    orderBy: { _sum: { qty: "desc" } },
    take: 5,
  });

  const productIds = bestSelling.map((b) => b.productId);
  const products = await prisma.product.findMany({
    where: { id: { in: productIds } },
    select: { id: true, name: true, slug: true, stock: true },
  });

  const bestSellingResolved = bestSelling.map((b) => ({
    product: products.find((p) => p.id === b.productId),
    qty: b._sum.qty ?? 0,
  }));

  const lowStock = await prisma.product.findMany({
    where: { stock: { lte: settings.lowStockThreshold } },
    orderBy: { stock: "asc" },
    take: 10,
    select: { id: true, name: true, slug: true, stock: true, sku: true },
  });

  return NextResponse.json({
    cards: {
      totalSales: paidAgg._sum.total ?? 0,
      totalOrders,
      totalUsers,
    },
    bestSelling: bestSellingResolved,
    lowStock,
    settings: { lowStockThreshold: settings.lowStockThreshold },
  });
}