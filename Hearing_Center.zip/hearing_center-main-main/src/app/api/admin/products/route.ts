import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify, makeSku } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";
import {
  normalizeAccessorySortOrder,
  normalizeCompatibilityGroupKey,
  normalizeCompatibilityGroupLabel,
} from "@/lib/product-compatibility";
import { normalizeCart } from "@/lib/cart.server";

type ProductAnalytics = {
  totalSoldQty: number;
  totalOrderCount: number;
  totalRevenue: number;
  activeCartQty: number;
  activeCartUsers: number;
};

async function getProductAnalytics(): Promise<Map<string, ProductAnalytics>> {
  const [orderItems, users] = await Promise.all([
    prisma.orderItem.groupBy({
      by: ["productId"],
      _sum: {
        qty: true,
        lineTotal: true,
      },
      _count: {
        _all: true,
      },
    }),
    prisma.user
      .findMany({
        select: {
          id: true,
          cartJson: true,
        },
      })
      .catch(() => [] as Array<{ id: string; cartJson: unknown }>),
  ]);

  const analytics = new Map<string, ProductAnalytics>();

  for (const item of orderItems) {
    analytics.set(item.productId, {
      totalSoldQty: item._sum.qty ?? 0,
      totalOrderCount: item._count._all ?? 0,
      totalRevenue: item._sum.lineTotal ?? 0,
      activeCartQty: 0,
      activeCartUsers: 0,
    });
  }

  for (const user of users) {
    const cart = normalizeCart(user.cartJson);
    const perProductQty = new Map<string, number>();

    for (const cartItem of cart.items) {
      perProductQty.set(
        cartItem.productId,
        (perProductQty.get(cartItem.productId) ?? 0) + cartItem.qty,
      );
    }

    for (const [productId, qty] of perProductQty.entries()) {
      const existing = analytics.get(productId) ?? {
        totalSoldQty: 0,
        totalOrderCount: 0,
        totalRevenue: 0,
        activeCartQty: 0,
        activeCartUsers: 0,
      };

      existing.activeCartQty += qty;
      existing.activeCartUsers += 1;
      analytics.set(productId, existing);
    }
  }

  return analytics;
}

const variantSchema = z.object({
  id: z.string().optional(),
  type: z.string().min(1),
  value: z.string().min(1),
  priceDiff: z.number().int().default(0),
  stock: z.number().int().min(0).default(0),
  images: z.array(z.string().min(1)).default([]),
});

const specificationSchema = z.object({
  label: z.string().min(1),
  value: z.string().min(1),
});

const createSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional().nullable(),
  brand: z.string().min(1).default("Phonak"),
  modelCode: z.string().optional().nullable(),
  deviceStyle: z.string().optional().nullable(),
  hearingLossRange: z.string().optional().nullable(),
  batteryType: z.string().optional().nullable(),
  connectivity: z.string().optional().nullable(),
  isRechargeable: z.boolean().optional(),
  compatibilityGroupKey: z.string().optional().nullable(),
  compatibilityGroupLabel: z.string().optional().nullable(),
  accessorySortOrder: z.number().int().optional(),
  shortDescription: z.string().optional().nullable(),
  longDescription: z.string().optional().nullable(),
  warranty: z.string().optional().nullable(),
  fittingRange: z.string().optional().nullable(),
  careGuide: z.string().optional().nullable(),
  keyFeatures: z.array(z.string().min(1)).default([]),
  specifications: z.array(specificationSchema).default([]),
  price: z.number().int().min(0),
  offerPrice: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0).default(0),
  categoryId: z.string().min(1),
  isFeatured: z.boolean().optional(),
  isActive: z.boolean().optional(),
  images: z.array(z.string().min(1)).default([]),
  variants: z.array(variantSchema).default([]),
});

export async function GET() {
  try {
    const [items, analytics] = await Promise.all([
      prisma.product.findMany({
        include: {
          content: true,
          category: {
            include: {
              parent: {
                select: {
                  id: true,
                  name: true,
                  slug: true,
                },
              },
            },
          },
          images: { orderBy: { sortOrder: "asc" } },
          variants: {
            include: {
              images: { orderBy: { sortOrder: "asc" } },
            },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      getProductAnalytics(),
    ]);

    return NextResponse.json(
      items.map((item) => ({
        ...item,
        analytics: analytics.get(item.id) ?? {
          totalSoldQty: 0,
          totalOrderCount: 0,
          totalRevenue: 0,
          activeCartQty: 0,
          activeCartUsers: 0,
        },
      })),
    );
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;

    if (
      prismaError?.code === "P2021" ||
      prismaError?.code === "P2022"
    ) {
      const items = await prisma.product.findMany({
        include: {
          category: {
            include: {
              parent: {
                select: {
                  id: true,
                  name: true,
                  slug: true,
                },
              },
            },
          },
          images: { orderBy: { sortOrder: "asc" } },
          variants: {
            include: {
              images: { orderBy: { sortOrder: "asc" } },
            },
          },
        },
        orderBy: { createdAt: "desc" },
      });

      return NextResponse.json(
        items.map((item) => ({
          ...item,
          analytics: {
            totalSoldQty: 0,
            totalOrderCount: 0,
            totalRevenue: 0,
            activeCartQty: 0,
            activeCartUsers: 0,
          },
        })),
      );
    }

    throw error;
  }
}

export async function POST(req: NextRequest) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid" }, { status: 400 });
  }

  const data = parsed.data;
  const compatibilityGroupKey = normalizeCompatibilityGroupKey(
    data.compatibilityGroupKey,
  );
  const compatibilityGroupLabel = normalizeCompatibilityGroupLabel(
    data.compatibilityGroupLabel,
  );
  const accessorySortOrder = normalizeAccessorySortOrder(
    data.accessorySortOrder,
  );

  const slugBase = slugify(data.name);
  let slug = slugBase;
  let i = 1;

  while (await prisma.product.findUnique({ where: { slug } })) {
    slug = `${slugBase}-${i++}`;
  }

  let sku = makeSku("RHC");
  while (await prisma.product.findUnique({ where: { sku } })) {
    sku = makeSku("RHC");
  }

  try {
    const created = await prisma.product.create({
      data: {
        name: data.name,
        slug,
        description: data.longDescription ?? data.description ?? null,
        brand: data.brand,
        modelCode: data.modelCode ?? null,
        deviceStyle: data.deviceStyle ?? null,
        hearingLossRange: data.hearingLossRange ?? null,
        batteryType: data.batteryType ?? null,
        connectivity: data.connectivity ?? null,
        isRechargeable: data.isRechargeable ?? false,
        compatibilityGroupKey,
        compatibilityGroupLabel,
        accessorySortOrder,
        price: data.price,
        offerPrice: data.offerPrice ?? null,
        stock: data.stock,
        sku,
        categoryId: data.categoryId,
        isFeatured: data.isFeatured ?? false,
        isActive: data.isActive ?? true,
        content:
          data.shortDescription ||
          data.longDescription ||
          data.warranty ||
          data.fittingRange ||
          data.careGuide ||
          data.keyFeatures.length ||
          data.specifications.length
            ? {
                create: {
                  shortDescription: data.shortDescription ?? null,
                  longDescription:
                    data.longDescription ?? data.description ?? null,
                  warranty: data.warranty ?? null,
                  fittingRange: data.fittingRange ?? null,
                  careGuide: data.careGuide ?? null,
                  keyFeatures: data.keyFeatures,
                  specifications: data.specifications,
                },
              }
            : undefined,

        images: data.images.length
          ? {
              create: data.images.map((url, idx) => ({
                url,
                sortOrder: idx,
              })),
            }
          : undefined,

        variants: data.variants.length
          ? {
              create: data.variants.map((v) => ({
                type: v.type,
                value: v.value,
                priceDiff: v.priceDiff,
                stock: v.stock,
                images: v.images.length
                  ? {
                      create: v.images.map((url, idx) => ({
                        url,
                        sortOrder: idx,
                      })),
                    }
                  : undefined,
              })),
            }
          : undefined,
      },
      include: {
        category: {
          include: {
            parent: {
              select: {
                id: true,
                name: true,
                slug: true,
              },
            },
          },
        },
        images: { orderBy: { sortOrder: "asc" } },
        variants: {
          include: {
            images: { orderBy: { sortOrder: "asc" } },
          },
        },
      },
    });

    return NextResponse.json(created, { status: 201 });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;

    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          error:
            "Product content fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }

    throw error;
  }
}
