import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin-guard";
import { deleteLocalUploadsByUrls } from "@/lib/local-uploads";
import {
  normalizeAccessorySortOrder,
  normalizeCompatibilityGroupKey,
  normalizeCompatibilityGroupLabel,
} from "@/lib/product-compatibility";

type Ctx = { params: Promise<{ id: string }> };

const variantSchema = z.object({
  id: z.string().optional(),
  type: z.string().min(1),
  value: z.string().min(1),
  priceDiff: z.number().int().default(0),
  stock: z.number().int().min(0).default(0),
  images: z.array(z.string().min(1)).default([]),
});

const specificationSchema = z.object({
  label: z.string().min(1),
  value: z.string().min(1),
});

const updateSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional().nullable(),
  brand: z.string().min(1).default("Phonak"),
  modelCode: z.string().optional().nullable(),
  deviceStyle: z.string().optional().nullable(),
  hearingLossRange: z.string().optional().nullable(),
  batteryType: z.string().optional().nullable(),
  connectivity: z.string().optional().nullable(),
  isRechargeable: z.boolean().optional(),
  compatibilityGroupKey: z.string().optional().nullable(),
  compatibilityGroupLabel: z.string().optional().nullable(),
  accessorySortOrder: z.number().int().optional(),
  shortDescription: z.string().optional().nullable(),
  longDescription: z.string().optional().nullable(),
  warranty: z.string().optional().nullable(),
  fittingRange: z.string().optional().nullable(),
  careGuide: z.string().optional().nullable(),
  keyFeatures: z.array(z.string().min(1)).default([]),
  specifications: z.array(specificationSchema).default([]),
  price: z.number().int().min(0),
  offerPrice: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0),
  categoryId: z.string().min(1),
  isFeatured: z.boolean().optional(),
  isActive: z.boolean().optional(),
  images: z.array(z.string().min(1)).default([]),
  variants: z.array(variantSchema).default([]),
});

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  const body = await req.json();
  const parsed = updateSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid" }, { status: 400 });
  }

  const data = parsed.data;
  const compatibilityGroupKey = normalizeCompatibilityGroupKey(
    data.compatibilityGroupKey,
  );
  const compatibilityGroupLabel = normalizeCompatibilityGroupLabel(
    data.compatibilityGroupLabel,
  );
  const accessorySortOrder = normalizeAccessorySortOrder(
    data.accessorySortOrder,
  );

  let existingProduct;
  try {
    existingProduct = await prisma.product.findUnique({
      where: { id },
      include: {
        content: true,
        images: { orderBy: { sortOrder: "asc" } },
        variants: {
          include: {
            images: { orderBy: { sortOrder: "asc" } },
          },
        },
      },
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          error:
            "Product content fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }
    throw error;
  }

  if (!existingProduct) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const slugBase = slugify(data.name);
  let slug = slugBase;
  let i = 1;

  while (true) {
    const existing = await prisma.product.findUnique({ where: { slug } });
    if (!existing || existing.id === id) break;
    slug = `${slugBase}-${i++}`;
  }

  const oldProductImageUrls = existingProduct.images.map((img) => img.url);
  const nextProductImageUrls = data.images;
  const removedProductImageUrls = oldProductImageUrls.filter(
    (url) => !nextProductImageUrls.includes(url),
  );

  const existingVariantMap = new Map(
    existingProduct.variants.map((v) => [v.id, v] as const),
  );

  const incomingVariantIds = new Set(
    data.variants.map((v) => v.id).filter(Boolean) as string[],
  );

  const removedVariants = existingProduct.variants.filter(
    (v) => !incomingVariantIds.has(v.id),
  );

  const removedVariantImageUrls = removedVariants.flatMap((v) =>
    v.images.map((img) => img.url),
  );

  const changedExistingVariantRemovedUrls: string[] = [];

  for (const variant of data.variants) {
    if (!variant.id) continue;

    const existing = existingVariantMap.get(variant.id);
    if (!existing) continue;

    const oldUrls = existing.images.map((img) => img.url);
    const nextUrls = variant.images;
    const removedUrls = oldUrls.filter((url) => !nextUrls.includes(url));

    changedExistingVariantRemovedUrls.push(...removedUrls);
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.product.update({
      where: { id },
      data: {
        name: data.name,
        slug,
        description: data.longDescription ?? data.description ?? null,
        brand: data.brand,
        modelCode: data.modelCode ?? null,
        deviceStyle: data.deviceStyle ?? null,
        hearingLossRange: data.hearingLossRange ?? null,
        batteryType: data.batteryType ?? null,
        connectivity: data.connectivity ?? null,
        isRechargeable: data.isRechargeable ?? false,
        compatibilityGroupKey,
        compatibilityGroupLabel,
        accessorySortOrder,
        price: data.price,
        offerPrice: data.offerPrice ?? null,
        stock: data.stock,
        categoryId: data.categoryId,
        isFeatured: data.isFeatured ?? false,
        isActive: data.isActive ?? true,
        content: {
          upsert: {
            create: {
              shortDescription: data.shortDescription ?? null,
              longDescription: data.longDescription ?? data.description ?? null,
              warranty: data.warranty ?? null,
              fittingRange: data.fittingRange ?? null,
              careGuide: data.careGuide ?? null,
              keyFeatures: data.keyFeatures,
              specifications: data.specifications,
            },
            update: {
              shortDescription: data.shortDescription ?? null,
              longDescription: data.longDescription ?? data.description ?? null,
              warranty: data.warranty ?? null,
              fittingRange: data.fittingRange ?? null,
              careGuide: data.careGuide ?? null,
              keyFeatures: data.keyFeatures,
              specifications: data.specifications,
            },
          },
        },
        images: {
          deleteMany: {},
          create: data.images.map((url, idx) => ({
            url,
            sortOrder: idx,
          })),
        },
      },
      });

      if (removedVariants.length) {
        await tx.productVariant.deleteMany({
          where: {
            id: {
              in: removedVariants.map((v) => v.id),
            },
          },
        });
      }

      for (const variant of data.variants) {
        if (variant.id && existingVariantMap.has(variant.id)) {
          await tx.productVariant.update({
            where: { id: variant.id },
            data: {
              type: variant.type,
              value: variant.value,
              priceDiff: variant.priceDiff,
              stock: variant.stock,
              images: {
                deleteMany: {},
                create: variant.images.map((url, idx) => ({
                  url,
                  sortOrder: idx,
                })),
              },
            },
          });
        } else {
          await tx.productVariant.create({
            data: {
              productId: id,
              type: variant.type,
              value: variant.value,
              priceDiff: variant.priceDiff,
              stock: variant.stock,
              images: {
                create: variant.images.map((url, idx) => ({
                  url,
                  sortOrder: idx,
                })),
              },
            },
          });
        }
      }
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json(
        {
          error:
            "Product content fields are not in the database yet. Run the latest migration first.",
        },
        { status: 409 },
      );
    }
    throw error;
  }

  const updated = await prisma.product.findUnique({
    where: { id },
    include: {
      category: true,
      images: { orderBy: { sortOrder: "asc" } },
      variants: {
        include: {
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  const allRemovedUrls = [
    ...removedProductImageUrls,
    ...removedVariantImageUrls,
    ...changedExistingVariantRemovedUrls,
  ];

  if (allRemovedUrls.length) {
    await deleteLocalUploadsByUrls(allRemovedUrls);
  }

  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: Ctx) {
  const g = await requireAdmin(req);
  if (!g.ok) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  try {
    const exists = await prisma.product.findUnique({
      where: { id },
      include: {
        images: true,
        variants: {
          include: {
            images: true,
          },
        },
      },
    });

    if (!exists) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    await prisma.product.delete({ where: { id } });

    const sharedUrls = exists.images.map((img) => img.url);
    const variantUrls = exists.variants.flatMap((v) =>
      v.images.map((img) => img.url),
    );

    const allUrls = [...sharedUrls, ...variantUrls];

    if (allUrls.length) {
      await deleteLocalUploadsByUrls(allUrls);
    }

    return NextResponse.json({ ok: true });
  } catch (err: unknown) {
    const e = err as { code?: string; message?: string };

    if (e.code === "P2003") {
      return NextResponse.json(
        { error: "Cannot delete: product is linked with other data." },
        { status: 409 },
      );
    }

    return NextResponse.json(
      { error: "Delete failed", detail: e.message ?? "Unknown" },
      { status: 500 },
    );
  }
}
