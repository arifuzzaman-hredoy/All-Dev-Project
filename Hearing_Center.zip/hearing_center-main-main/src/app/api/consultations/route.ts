import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const consultationSchema = z.object({
  name: z.string().trim().min(1).max(120),
  phone: z.string().trim().min(5).max(30),
  email: z.union([z.literal(""), z.string().trim().email().max(160)]).optional(),
  hearingAidUsage: z.string().trim().max(80).optional(),
  hearingTestDone: z.string().trim().max(80).optional(),
  tinnitus: z.string().trim().max(80).optional(),
  crowdDifficulty: z.string().trim().max(80).optional(),
  dailyLifeImpact: z.string().trim().max(80).optional(),
  age: z.string().trim().max(40).optional(),
  district: z.string().trim().max(120).optional(),
  budget: z.string().trim().max(80).optional(),
});

type ConsultationPayload = z.infer<typeof consultationSchema>;

function toNullable(value: string | undefined): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

export async function POST(req: NextRequest) {
  try {
    const json = (await req.json().catch(() => null)) as ConsultationPayload | null;
    const parsed = consultationSchema.safeParse(json);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please provide valid consultation details." },
        { status: 400 },
      );
    }

    const data = parsed.data;

    const consultation = await prisma.consultation.create({
      data: {
        name: data.name.trim(),
        phone: data.phone.trim(),
        email: toNullable(data.email),
        hearingAidUsage: toNullable(data.hearingAidUsage),
        hearingTestDone: toNullable(data.hearingTestDone),
        tinnitus: toNullable(data.tinnitus),
        crowdDifficulty: toNullable(data.crowdDifficulty),
        dailyLifeImpact: toNullable(data.dailyLifeImpact),
        age: toNullable(data.age),
        district: toNullable(data.district),
        budget: toNullable(data.budget),
      },
      select: {
        id: true,
      },
    });

    return NextResponse.json({ ok: true, id: consultation.id }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Could not save consultation request." },
      { status: 500 },
    );
  }
}
