import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { CouponType } from "@prisma/client";

type ErrorResponse = { error: string };
type OkResponse = {
  ok: true;
  code: string;
  type: "PERCENT" | "FIXED";
  value: number;
  discount: number;
};

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}
function toInt(v: unknown, fallback = 0): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? Math.floor(n) : fallback;
}

export async function POST(
  req: NextRequest
): Promise<NextResponse<OkResponse | ErrorResponse>> {
  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = bodyUnknown as { code?: unknown; subtotal?: unknown };

  const code = isNonEmptyString(body?.code) ? body.code.trim().toUpperCase() : "";
  const subtotal = Math.max(0, toInt(body?.subtotal, 0));

  if (!code) return NextResponse.json({ error: "Coupon code required" }, { status: 400 });
  if (subtotal <= 0) return NextResponse.json({ error: "Subtotal required" }, { status: 400 });

  const c = await prisma.coupon.findUnique({ where: { code } });
  if (!c || !c.isActive) return NextResponse.json({ error: "Invalid coupon" }, { status: 400 });

  const now = new Date();
  if (c.startsAt && now < c.startsAt) return NextResponse.json({ error: "Coupon not started yet" }, { status: 400 });
  if (c.endsAt && now > c.endsAt) return NextResponse.json({ error: "Coupon expired" }, { status: 400 });

  if (subtotal < c.minSubtotal) {
    return NextResponse.json({ error: `Minimum subtotal is ৳${c.minSubtotal}` }, { status: 400 });
  }

  if (typeof c.usageLimit === "number" && c.usageLimit > 0 && c.usedCount >= c.usageLimit) {
    return NextResponse.json({ error: "Coupon usage limit reached" }, { status: 400 });
  }

  let discount = 0;
  if (c.type === CouponType.PERCENT) {
    discount = Math.floor((subtotal * c.value) / 100);
    if (typeof c.maxDiscount === "number" && c.maxDiscount > 0) {
      discount = Math.min(discount, c.maxDiscount);
    }
  } else {
    discount = c.value;
  }

  discount = Math.max(0, Math.min(discount, subtotal));

  return NextResponse.json({
    ok: true,
    code,
    type: c.type,
    value: c.value,
    discount,
  });
}