import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const { code, subtotal } = await req.json();
  if (!code) return NextResponse.json({ message: "Missing code" }, { status: 400 });

  const coupon = await prisma.coupon.findUnique({ where: { code: String(code).toUpperCase().trim() } });
  if (!coupon || !coupon.isActive) return NextResponse.json({ ok: false, message: "Invalid coupon" });

  const now = new Date();
  if (coupon.startsAt && now < coupon.startsAt) return NextResponse.json({ ok: false, message: "Coupon not started" });
  if (coupon.endsAt && now > coupon.endsAt) return NextResponse.json({ ok: false, message: "Coupon expired" });
  if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) return NextResponse.json({ ok: false, message: "Coupon limit reached" });

  const sub = Number(subtotal ?? 0);
  if (sub < coupon.minSubtotal) return NextResponse.json({ ok: false, message: `Minimum subtotal ৳${coupon.minSubtotal}` });

  let discount = 0;
  if (coupon.type === "PERCENT") discount = Math.floor((sub * coupon.value) / 100);
  if (coupon.type === "FIXED") discount = coupon.value;

  if (coupon.maxDiscount != null) discount = Math.min(discount, coupon.maxDiscount);
  discount = Math.max(0, Math.min(discount, sub));

  return NextResponse.json({ ok: true, discount, couponCode: coupon.code });
}