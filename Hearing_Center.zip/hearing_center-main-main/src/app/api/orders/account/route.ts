import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type ErrorResponse = {
  error: string;
};

type OrderItem = {
  id: string;
  createdAt: string;
  total: number;
  status: string;
  paymentStatus: string;
};

type SuccessResponse = {
  items: OrderItem[];
};

export async function GET(): Promise<
  NextResponse<SuccessResponse | ErrorResponse>
> {
  const session = await getServerSession(authOptions);

  const userId = typeof session?.user?.id === "string" ? session.user.id : null;

  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const orders = await prisma.order.findMany({
    where: {
      userId,
    },
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      createdAt: true,
      total: true,
      status: true,
      paymentStatus: true,
    },
  });

  return NextResponse.json({
    items: orders.map((order) => ({
      id: order.id,
      createdAt: order.createdAt.toISOString(),
      total: order.total,
      status: order.status,
      paymentStatus: order.paymentStatus,
    })),
  });
}
