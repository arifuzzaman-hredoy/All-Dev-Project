import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { checkoutSchema } from "@/lib/validations/checkout";
import {
  createCodOrder,
  prepareCheckout,
} from "@/lib/services/checkout-service";
import { AppError } from "@/lib/app-error";
import { formatZodError } from "@/lib/validation-error";

type ErrorResponse = {
  error: string;
};

type SuccessResponse = {
  ok: true;
  orderId: string;
};

export async function POST(
  req: NextRequest,
): Promise<NextResponse<SuccessResponse | ErrorResponse>> {
  try {
    const bodyUnknown: unknown = await req.json().catch(() => null);

    const parsed = checkoutSchema.safeParse(bodyUnknown);
    if (!parsed.success) {
      return NextResponse.json(
        { error: formatZodError(parsed.error) },
        { status: 400 },
      );
    }

    const session = await getServerSession(authOptions);
    const userId =
      typeof session?.user?.id === "string" ? session.user.id : null;

    const body = parsed.data;

    if (body.paymentMethod !== "COD") {
      return NextResponse.json(
        { error: "Invalid payment method for this route" },
        { status: 400 },
      );
    }

    const prepared = await prepareCheckout(body);

    const order = await createCodOrder({
      userId,
      body,
      prepared,
    });

    return NextResponse.json({
      ok: true,
      orderId: order.id,
    });
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }

    console.error("COD checkout failed:", error);
    return NextResponse.json({ error: "Checkout failed" }, { status: 500 });
  }
}
