import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type TrackOrderItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  status: string;
  paymentStatus: string;
  courierName: string | null;
  trackingId: string | null;
  itemsCount: number;
};

type SuccessResponse = {
  ok: true;
  mode: "id" | "phone";
  items: TrackOrderItem[];
};

type ErrorResponse = {
  ok: false;
  error: string;
};

function normalize(value: string): string {
  return value.trim();
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<SuccessResponse | ErrorResponse>> {
  const { searchParams } = new URL(req.url);

  const orderId = normalize(searchParams.get("orderId") || "");
  const phone = normalize(searchParams.get("phone") || "");

  if (!orderId && !phone) {
    return NextResponse.json(
      { ok: false, error: "Order ID or phone number is required" },
      { status: 400 },
    );
  }

  if (orderId) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      select: {
        id: true,
        createdAt: true,
        name: true,
        phone: true,
        total: true,
        status: true,
        paymentStatus: true,
        courierName: true,
        trackingId: true,
        _count: {
          select: {
            items: true,
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json(
        { ok: false, error: "No order found with this ID" },
        { status: 404 },
      );
    }

    return NextResponse.json({
      ok: true,
      mode: "id",
      items: [
        {
          id: order.id,
          createdAt: order.createdAt.toISOString(),
          name: order.name,
          phone: order.phone,
          total: order.total,
          status: order.status,
          paymentStatus: order.paymentStatus,
          courierName: order.courierName ?? null,
          trackingId: order.trackingId ?? null,
          itemsCount: order._count.items,
        },
      ],
    });
  }

  const orders = await prisma.order.findMany({
    where: {
      phone: {
        equals: phone,
      },
    },
    orderBy: {
      createdAt: "desc",
    },
    take: 20,
    select: {
      id: true,
      createdAt: true,
      name: true,
      phone: true,
      total: true,
      status: true,
      paymentStatus: true,
      courierName: true,
      trackingId: true,
      _count: {
        select: {
          items: true,
        },
      },
    },
  });

  if (!orders.length) {
    return NextResponse.json(
      { ok: false, error: "No orders found with this phone number" },
      { status: 404 },
    );
  }

  return NextResponse.json({
    ok: true,
    mode: "phone",
    items: orders.map((order) => ({
      id: order.id,
      createdAt: order.createdAt.toISOString(),
      name: order.name,
      phone: order.phone,
      total: order.total,
      status: order.status,
      paymentStatus: order.paymentStatus,
      courierName: order.courierName ?? null,
      trackingId: order.trackingId ?? null,
      itemsCount: order._count.items,
    })),
  });
}
