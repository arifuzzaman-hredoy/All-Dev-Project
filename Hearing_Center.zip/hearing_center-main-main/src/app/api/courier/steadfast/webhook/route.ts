import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { mapSteadfastTripStatusToOrderStatus } from "@/lib/couriers/steadfast";
import { env } from "@/lib/env"

type WebhookBody = {
  OrderFound?: boolean;
  ConsignmentReference?: string | null;
  JobNumber?: string | null;
  TripStatus?: string | null;
  FullURL?: string | null;
  CustomerRef?: string | null;
  ConsRef?: string | null;
};

function getCustomerRef(body: WebhookBody): string | null {
  if (typeof body.CustomerRef === "string" && body.CustomerRef.trim()) {
    return body.CustomerRef.trim();
  }
  return null;
}

export async function POST(req: NextRequest) {
  const secret = env.STEADFAST_WEBHOOK_SECRET?.trim();

  if (secret) {
    const incoming = req.headers.get("x-steadfast-webhook-secret");
    if (incoming !== secret) {
      return NextResponse.json(
        { error: "Unauthorized webhook" },
        { status: 401 },
      );
    }
  }

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = (bodyUnknown ?? {}) as WebhookBody;

  const customerRef = getCustomerRef(body);
  if (!customerRef) {
    return NextResponse.json({ error: "CustomerRef missing" }, { status: 400 });
  }

  const nextStatus = mapSteadfastTripStatusToOrderStatus(body.TripStatus);

  await prisma.order.updateMany({
    where: { id: customerRef },
    data: {
      courierName: "Steadfast",
      trackingId:
        (typeof body.ConsignmentReference === "string" &&
          body.ConsignmentReference) ||
        (typeof body.ConsRef === "string" && body.ConsRef) ||
        null,
      ...(nextStatus ? { status: nextStatus } : {}),
    },
  });

  return NextResponse.json({ ok: true });
}
