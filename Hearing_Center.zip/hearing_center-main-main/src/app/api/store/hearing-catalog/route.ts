import { NextResponse } from "next/server";
import { normalizeHearingCatalogSettings } from "@/lib/hearing-catalog";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const settings = await prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        deviceStyleOptions: true,
        hearingLossOptions: true,
        batteryTypeOptions: true,
        connectivityOptions: true,
      },
    });

    return NextResponse.json({
      settings: normalizeHearingCatalogSettings({
        deviceStyleOptions: settings?.deviceStyleOptions as string[] | undefined,
        hearingLossOptions: settings?.hearingLossOptions as string[] | undefined,
        batteryTypeOptions: settings?.batteryTypeOptions as string[] | undefined,
        connectivityOptions: settings?.connectivityOptions as string[] | undefined,
      }),
    });
  } catch (error: unknown) {
    const prismaError = error as { code?: string } | null;
    if (prismaError?.code === "P2021" || prismaError?.code === "P2022") {
      return NextResponse.json({
        settings: normalizeHearingCatalogSettings(null),
      });
    }
    throw error;
  }
}
