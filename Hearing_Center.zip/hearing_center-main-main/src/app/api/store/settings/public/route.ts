import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

type Response = {
  ok: true;
  storeName: string;
  logoUrl: string;
  currency: string;

  taxRate: number;
  shippingInsideDhaka: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;

  codEnabled: boolean;
  onlineEnabled: boolean;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;

  returnRefundPolicy: string;
  aboutUs: string;
  privacyPolicy: string;
  termsConditions: string;
};

export async function GET(): Promise<NextResponse<Response>> {
  const s = await prisma.storeSettings.findUnique({
    where: { id: "default" },
  });

  return NextResponse.json({
    ok: true,
    storeName: s?.storeName ?? "Rangpur Hearing Center",
    logoUrl: s?.logoUrl ?? "",
    currency: s?.currency ?? "BDT",

    taxRate: s?.taxRate ?? 0,
    shippingInsideDhaka: s?.shippingInsideDhaka ?? 0,
    shippingOutsideDhaka: s?.shippingOutsideDhaka ?? 0,
    shippingFreeOver: s?.shippingFreeOver ?? 0,

    codEnabled: s?.codEnabled ?? true,
    onlineEnabled: s?.onlineEnabled ?? false,
    lowStockThreshold: s?.lowStockThreshold ?? 5,

    facebookUrl: s?.facebookUrl ?? "",
    instagramUrl: s?.instagramUrl ?? "",
    youtubeUrl: s?.youtubeUrl ?? "",
    tiktokUrl: s?.tiktokUrl ?? "",
    whatsappUrl: s?.whatsappUrl ?? "",

    returnRefundPolicy: s?.returnRefundPolicy ?? "",
    aboutUs: s?.aboutUs ?? "",
    privacyPolicy: s?.privacyPolicy ?? "",
    termsConditions: s?.termsConditions ?? "",
  });
}
