import { NextRequest, NextResponse } from "next/server";
import type { Cart, CartItem } from "@/lib/cart.types";
import { persistCurrentCart, resolveCurrentCart } from "@/lib/cart-store";

type ErrorResponse = { error: string };
type CartResponse = { cart: Cart };

type Body =
  | {
      action: "add";
      productId: string;
      qty?: number;
      variantId?: string | null;
    }
  | { action: "set"; productId: string; qty: number; variantId?: string | null }
  | { action: "remove"; productId: string; variantId?: string | null }
  | { action: "clear" };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function toQty(v: unknown, fallback = 1): number {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(1, Math.floor(n));
}

function extractProductId(body: Partial<Body>): string {
  if ("productId" in body && typeof body.productId === "string") {
    return body.productId.trim();
  }
  return "";
}

function extractVariantId(body: Partial<Body>): string | null {
  if (!("variantId" in body)) return null;
  if (typeof body.variantId !== "string") return null;

  const value = body.variantId.trim();
  return value.length ? value : null;
}

function isSameLine(
  item: CartItem,
  productId: string,
  variantId: string | null,
): boolean {
  return item.productId === productId && (item.variantId ?? null) === variantId;
}

export async function GET(): Promise<NextResponse<CartResponse>> {
  const { cart } = await resolveCurrentCart();
  return NextResponse.json({ cart });
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<CartResponse | ErrorResponse>> {
  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = bodyUnknown as Partial<Body>;

  if (!body || typeof body.action !== "string") {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const { cart, userId } = await resolveCurrentCart();

  if (body.action === "clear") {
    await persistCurrentCart({ items: [] }, userId);
    return NextResponse.json({ cart: { items: [] } });
  }

  const productId = extractProductId(body);
  if (!isNonEmptyString(productId)) {
    return NextResponse.json({ error: "productId required" }, { status: 400 });
  }

  const variantId = extractVariantId(body);

  if (body.action === "add") {
    const qty = toQty((body as { qty?: unknown }).qty, 1);
    const existing = cart.items.find((i) =>
      isSameLine(i, productId, variantId),
    );

    if (existing) {
      existing.qty += qty;
    } else {
      cart.items.push({ productId, qty, variantId });
    }

    await persistCurrentCart(cart, userId);
    return NextResponse.json({ cart });
  }

  if (body.action === "set") {
    const qty = toQty((body as { qty?: unknown }).qty, 1);
    const existing = cart.items.find((i) =>
      isSameLine(i, productId, variantId),
    );

    if (existing) {
      existing.qty = qty;
    } else {
      cart.items.push({ productId, qty, variantId });
    }

    await persistCurrentCart(cart, userId);
    return NextResponse.json({ cart });
  }

  if (body.action === "remove") {
    const next: Cart = {
      items: cart.items.filter((i) => !isSameLine(i, productId, variantId)),
    };

    await persistCurrentCart(next, userId);
    return NextResponse.json({ cart: next });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
