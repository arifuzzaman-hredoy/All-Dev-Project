import { NextResponse } from "next/server";
import { buildCartDetails, type CartDetailsItem } from "@/lib/cart-details";
import { resolveCurrentCart } from "@/lib/cart-store";

type CartDetailsResponse = {
  items: CartDetailsItem[];
};

export async function GET(): Promise<NextResponse<CartDetailsResponse>> {
  const { cart } = await resolveCurrentCart();
  const items = await buildCartDetails(cart.items);

  return NextResponse.json({ items });
}
