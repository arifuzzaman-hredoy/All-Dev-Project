import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type WishlistListItem = {
  id: string;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
    category: { name: string; slug: string } | null;
  };
  createdAt: string;
};

type WishlistListResponse = { items: WishlistListItem[] };

type ToggleBody = { productId: string };
type ToggleResponse = { inWishlist: boolean };

type ErrorResponse = { error: string };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

async function requireUser() {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  const email = session?.user?.email;

  if (!userId || !isNonEmptyString(userId) || !isNonEmptyString(email)) {
    return { ok: false as const };
  }

  const user = await prisma.user.findFirst({
    where: {
      OR: [{ id: userId }, { email }],
    },
    select: { id: true, blocked: true },
  });

  if (!user || user.blocked) {
    return { ok: false as const };
  }

  return { ok: true as const, userId: user.id };
}

export async function GET(): Promise<NextResponse<WishlistListResponse | ErrorResponse>> {
  const auth = await requireUser();
  if (!auth.ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const rows = await prisma.wishlistItem.findMany({
    where: { userId: auth.userId },
    orderBy: { createdAt: "desc" },
    include: {
      product: {
        include: {
          images: { orderBy: { sortOrder: "asc" }, take: 1 },
          category: true,
        },
      },
    },
  });

  const items: WishlistListItem[] = rows
    .filter((r) => r.product)
    .map((r) => ({
      id: r.id,
      product: {
        id: r.product.id,
        name: r.product.name,
        slug: r.product.slug,
        price: r.product.price,
        offerPrice: r.product.offerPrice ?? null,
        stock: r.product.stock,
        images: (r.product.images ?? []).map((img) => ({ url: img.url })).filter((x) => !!x.url),
        category: r.product.category ? { name: r.product.category.name, slug: r.product.category.slug } : null,
      },
      createdAt: r.createdAt.toISOString(),
    }));

  return NextResponse.json({ items });
}

export async function POST(req: NextRequest): Promise<NextResponse<ToggleResponse | ErrorResponse>> {
  const auth = await requireUser();
  if (!auth.ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = bodyUnknown as Partial<ToggleBody>;

  if (!isNonEmptyString(body?.productId)) {
    return NextResponse.json({ error: "productId is required" }, { status: 400 });
  }

  const productId = body.productId.trim();

  const existing = await prisma.wishlistItem.findFirst({
    where: { userId: auth.userId, productId },
    select: { id: true },
  });

  if (existing) {
    await prisma.wishlistItem.delete({ where: { id: existing.id } });
    return NextResponse.json({ inWishlist: false });
  }

  await prisma.wishlistItem.create({
    data: { userId: auth.userId, productId },
  });

  return NextResponse.json({ inWishlist: true }, { status: 201 });
}

export async function DELETE(req: NextRequest): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const auth = await requireUser();
  if (!auth.ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const productId = searchParams.get("productId");

  if (!isNonEmptyString(productId)) {
    return NextResponse.json({ error: "productId is required" }, { status: 400 });
  }

  await prisma.wishlistItem.deleteMany({
    where: { userId: auth.userId, productId: productId.trim() },
  });

  return NextResponse.json({ ok: true });
}
