import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type ResponseOk = { productIds: string[] };
type ResponseErr = { error: string };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

export async function GET(): Promise<NextResponse<ResponseOk | ResponseErr>> {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  const email = session?.user?.email;

  if (!isNonEmptyString(userId) || !isNonEmptyString(email)) {
    return NextResponse.json({ productIds: [] });
  }

  const user = await prisma.user.findFirst({
    where: {
      OR: [{ id: userId }, { email }],
    },
    select: { id: true, blocked: true },
  });

  if (!user || user.blocked) {
    return NextResponse.json({ productIds: [] });
  }

  const rows = await prisma.wishlistItem.findMany({
    where: { userId: user.id },
    select: { productId: true },
  });

  return NextResponse.json({ productIds: rows.map((r) => r.productId) });
}
