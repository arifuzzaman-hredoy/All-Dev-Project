import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { checkoutSchema } from "@/lib/validations/checkout";
import {
  createOnlinePendingOrder,
  prepareCheckout,
} from "@/lib/services/checkout-service";
import { AppError } from "@/lib/app-error";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { formatZodError } from "@/lib/validation-error";

type ErrorResponse = {
  error: string;
};

type SuccessResponse = {
  ok: true;
  gatewayUrl: string;
  orderId: string;
};

function getBaseUrl(req: NextRequest): string {
  const origin = req.headers.get("origin");
  if (origin) return origin;
  return env.NEXT_PUBLIC_BASE_URL;
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<SuccessResponse | ErrorResponse>> {
  try {
    const bodyUnknown: unknown = await req.json().catch(() => null);

    const parsed = checkoutSchema.safeParse(bodyUnknown);
    if (!parsed.success) {
      return NextResponse.json(
        { error: formatZodError(parsed.error) },
        { status: 400 },
      );
    }

    const body = parsed.data;

    if (body.paymentMethod !== "ONLINE") {
      return NextResponse.json(
        { error: "Invalid payment method for this route" },
        { status: 400 },
      );
    }

    const session = await getServerSession(authOptions);
    const userId =
      typeof session?.user?.id === "string" ? session.user.id : null;

    const prepared = await prepareCheckout(body);

    const order = await createOnlinePendingOrder({
      userId,
      body,
      prepared,
    });

    const baseUrl = getBaseUrl(req);

    const payload = {
      store_id: env.SSLCOMMERZ_STORE_ID,
      store_passwd: env.SSLCOMMERZ_STORE_PASS,
      total_amount: prepared.total,
      currency: "BDT",
      tran_id: order.id,
      success_url: `${baseUrl}/api/payments/sslcommerz/callback/success`,
      fail_url: `${baseUrl}/api/payments/sslcommerz/callback/fail`,
      cancel_url: `${baseUrl}/api/payments/sslcommerz/callback/cancel`,
      ipn_url: `${baseUrl}/api/payments/sslcommerz/ipn`,
      shipping_method: "Courier",
      product_name: `Order ${order.id}`,
      product_category: "General",
      product_profile: "general",
      cus_name: body.name,
      cus_email: body.email || "guest@example.com",
      cus_add1: body.addressLine1,
      cus_add2: body.addressLine2 || "",
      cus_city: body.city,
      cus_state: body.area || body.city,
      cus_postcode: "1200",
      cus_country: "Bangladesh",
      cus_phone: body.phone,
      cus_fax: body.phone,

      ship_name: body.name,
      ship_add1: body.addressLine1,
      ship_add2: body.addressLine2 || "",
      ship_city: body.city,
      ship_state: body.area || body.city,
      ship_postcode: "1200",
      ship_country: "Bangladesh",

      value_a: order.id,
      value_b: userId || "",
      value_c: body.city,
      value_d: "guest-checkout",
    };

    const sslBase = env.SSLCOMMERZ_IS_LIVE
      ? "https://securepay.sslcommerz.com"
      : "https://sandbox.sslcommerz.com";

    const response = await fetch(`${sslBase}/gwprocess/v4/api.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams(
        Object.entries(payload).map(([key, value]) => [key, String(value)]),
      ).toString(),
    });

    const json = (await response.json().catch(() => null)) as {
      GatewayPageURL?: string;
      sessionkey?: string;
      failedreason?: string;
    } | null;

    const gatewayUrl = json?.GatewayPageURL;

    if (!response.ok || !gatewayUrl) {
      console.error("SSLCommerz initiate failed:", json);
      return NextResponse.json(
        { error: json?.failedreason || "Payment initiation failed" },
        { status: 500 },
      );
    }

    if (json?.sessionkey) {
      await prisma.order.update({
        where: { id: order.id },
        data: {
          sslczSessionKey: json.sessionkey,
        },
      });
    }

    return NextResponse.json({
      ok: true,
      gatewayUrl,
      orderId: order.id,
    });
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }

    console.error("SSLCommerz checkout failed:", error);
    return NextResponse.json(
      { error: "Payment initiation failed" },
      { status: 500 },
    );
  }
}
