import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

type ErrorResponse = { error: string };

type ReviewListItem = {
  id: string;
  rating: number;
  comment: string | null;
  createdAt: string;
  helpfulCount: number;
  user: { name: string | null };
  verified: boolean;
};

type ReviewListResponse = {
  reviews: ReviewListItem[];
  average: number;
};

type CreateBody = {
  productId: string;
  rating: number;
  comment?: string | null;
};

type SortKey = "latest" | "highest_rated";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function isValidRating(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v) && v >= 1 && v <= 5;
}

function parseSort(v: string | null): SortKey {
  if (v === "highest_rated") return "highest_rated";
  return "latest";
}

async function requireUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);

  const userId = session?.user?.id;
  if (!userId || !isNonEmptyString(userId)) return null;

  return userId;
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<ReviewListResponse | ErrorResponse>> {
  const { searchParams } = new URL(req.url);

  const productId = searchParams.get("productId");
  const sort = parseSort(searchParams.get("sort"));

  if (!isNonEmptyString(productId)) {
    return NextResponse.json({ error: "productId required" }, { status: 400 });
  }

  const orderBy: Prisma.ReviewOrderByWithRelationInput =
    sort === "highest_rated"
      ? { rating: Prisma.SortOrder.desc }
      : { createdAt: Prisma.SortOrder.desc };

  const reviews = await prisma.review.findMany({
    where: { productId: productId.trim() },
    orderBy,
    select: {
      id: true,
      rating: true,
      comment: true,
      createdAt: true,
      userId: true,
      productId: true,
      isVerifiedPurchase: true,
    },
  });

  const average =
    reviews.length > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
      : 0;

  const voteCounts = await prisma.reviewVote.groupBy({
    by: ["reviewId"],
    _count: { reviewId: true },
    where: { reviewId: { in: reviews.map((r) => r.id) } },
  });

  const voteMap = new Map<string, number>();
  voteCounts.forEach((v) => voteMap.set(v.reviewId, v._count.reviewId));

  const userIds = Array.from(new Set(reviews.map((r) => r.userId)));
  const users = await prisma.user.findMany({
    where: { id: { in: userIds } },
    select: { id: true, name: true },
  });

  const userMap = new Map<string, string | null>();
  users.forEach((u) => userMap.set(u.id, u.name ?? null));

  const formatted: ReviewListItem[] = reviews.map((r) => ({
    id: r.id,
    rating: r.rating,
    comment: r.comment,
    createdAt: r.createdAt.toISOString(),
    helpfulCount: voteMap.get(r.id) ?? 0,
    user: { name: userMap.get(r.userId) ?? null },
    verified: !!r.isVerifiedPurchase,
  }));

  return NextResponse.json({ reviews: formatted, average });
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const userId = await requireUserId();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const bodyUnknown: unknown = await req.json().catch(() => null);
  const body = bodyUnknown as Partial<CreateBody>;

  if (!isNonEmptyString(body?.productId)) {
    return NextResponse.json({ error: "productId required" }, { status: 400 });
  }
  if (!isValidRating(body?.rating)) {
    return NextResponse.json({ error: "rating must be 1-5" }, { status: 400 });
  }

  const productId = body.productId.trim();
  const rating = body.rating;
  const comment = typeof body.comment === "string" ? body.comment.trim() : null;

  const existing = await prisma.review.findFirst({
    where: { userId, productId },
    select: { id: true },
  });

  if (existing) {
    return NextResponse.json({ error: "Already reviewed" }, { status: 400 });
  }

  const delivered = await prisma.orderItem.findFirst({
    where: {
      productId,
      order: {
        userId,
        status: "DELIVERED",
      },
    },
    select: { id: true },
  });

  await prisma.review.create({
    data: {
      productId,
      userId,
      rating,
      comment,
      isVerifiedPurchase: !!delivered,
    },
  });

  return NextResponse.json({ ok: true }, { status: 201 });
}
