import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { getDescendantCategoryIds } from "@/lib/category-tree";
import { getBestSellingProductIds } from "@/lib/best-selling";

type ProductListItem = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  brand: string;
  modelCode: string | null;
  deviceStyle: string | null;
  hearingLossRange: string | null;
  batteryType: string | null;
  connectivity: string | null;
  isRechargeable: boolean;
  price: number;
  offerPrice: number | null;
  stock: number;
  isFeatured: boolean;
  isBestSelling: boolean;
  category: {
    id: string;
    name: string;
    slug: string;
    parent: { id: string; name: string; slug: string } | null;
  } | null;
  images: { url: string }[];
  ratingAvg: number;
  ratingCount: number;
};

type ProductsApiResponse = {
  items: ProductListItem[];
  total: number;
  page: number;
  take: number;
  pages: number;
};

function toNumber(v: string | null, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function getEffectivePriceWhere(
  min: number,
  max: number,
): Prisma.ProductWhereInput {
  const gte = min > 0 ? min : undefined;
  const lte = max > 0 ? max : undefined;

  return {
    OR: [
      {
        AND: [{ offerPrice: { not: null } }, { offerPrice: { gte, lte } }],
      },
      {
        AND: [{ offerPrice: null }, { price: { gte, lte } }],
      },
    ],
  };
}

async function attachRatings(
  products: Array<{
    id: string;
    name: string;
    slug: string;
    description: string | null;
    brand: string;
    modelCode: string | null;
    deviceStyle: string | null;
    hearingLossRange: string | null;
    batteryType: string | null;
    connectivity: string | null;
    isRechargeable: boolean;
    price: number;
    offerPrice: number | null;
    stock: number;
    isFeatured: boolean;
    isBestSelling: boolean;
    images: { url: string }[];
    category: {
      id: string;
      name: string;
      slug: string;
      parent: { id: string; name: string; slug: string } | null;
    } | null;
  }>,
): Promise<ProductListItem[]> {
  if (products.length === 0) return [];

  const ids = products.map((p) => p.id);

  const grouped = await prisma.review.groupBy({
    by: ["productId"],
    where: { productId: { in: ids } },
    _avg: { rating: true },
    _count: { rating: true },
  });

  const ratingMap = new Map<string, { avg: number; count: number }>();
  for (const g of grouped) {
    ratingMap.set(g.productId, {
      avg: typeof g._avg.rating === "number" ? g._avg.rating : 0,
      count: typeof g._count.rating === "number" ? g._count.rating : 0,
    });
  }

  return products.map((p) => {
    const rating = ratingMap.get(p.id) ?? { avg: 0, count: 0 };

    return {
      ...p,
      ratingAvg: Math.round(rating.avg * 10) / 10,
      ratingCount: rating.count,
    };
  });
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<ProductsApiResponse>> {
  const bestSellingIds = await getBestSellingProductIds();
  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") || "").trim();
  const cat = (searchParams.get("cat") || "").trim();
  const sort = (searchParams.get("sort") || "newest").trim();
  const featured = (searchParams.get("featured") || "") === "1";
  const inStock = (searchParams.get("inStock") || "") === "1";
  const style = (searchParams.get("style") || "").trim();
  const loss = (searchParams.get("loss") || "").trim();
  const rechargeable = (searchParams.get("rechargeable") || "") === "1";

  const page = Math.max(1, toNumber(searchParams.get("page"), 1));
  const take = clamp(toNumber(searchParams.get("take"), 12), 6, 48);
  const skip = (page - 1) * take;

  const min = Math.max(0, toNumber(searchParams.get("min"), 0));
  const max = Math.max(0, toNumber(searchParams.get("max"), 0));

  const and: Prisma.ProductWhereInput[] = [{ isActive: true }];

  if (q) {
    and.push({
      OR: [
        { name: { contains: q, mode: "insensitive" } },
        { description: { contains: q, mode: "insensitive" } },
        { sku: { contains: q, mode: "insensitive" } },
        { brand: { contains: q, mode: "insensitive" } },
        { modelCode: { contains: q, mode: "insensitive" } },
      ],
    });
  }

  if (featured) {
    and.push({ isFeatured: true });
  }

  if (style) {
    and.push({ deviceStyle: style });
  }

  if (loss) {
    and.push({ hearingLossRange: loss });
  }

  if (rechargeable) {
    and.push({ isRechargeable: true });
  }

  if (inStock) {
    and.push({
      OR: [
        { stock: { gt: 0 } },
        {
          variants: {
            some: {
              stock: { gt: 0 },
            },
          },
        },
      ],
    });
  }

  if (cat) {
    const allCategories = await prisma.category.findMany({
      where: { isActive: true },
      select: {
        id: true,
        slug: true,
        parentId: true,
      },
    });

    const matched = allCategories.find((c) => c.slug === cat);

    if (matched) {
      const categoryIds = getDescendantCategoryIds(matched.id, allCategories);
      and.push({
        categoryId: {
          in: categoryIds,
        },
      });
    } else {
      and.push({
        categoryId: "__not_found__",
      });
    }
  }

  if (min > 0 || max > 0) {
    and.push(getEffectivePriceWhere(min, max));
  }

  const where: Prisma.ProductWhereInput = {
    AND: and,
  };

  const include = {
    images: {
      orderBy: { sortOrder: "asc" as const },
      take: 1,
      select: {
        url: true,
      },
    },
    category: {
      select: {
        id: true,
        name: true,
        slug: true,
        parent: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
      },
    },
  };

  const transformProducts = (
    items: Array<{
      id: string;
      name: string;
      slug: string;
      description: string | null;
      brand: string;
      modelCode: string | null;
      deviceStyle: string | null;
      hearingLossRange: string | null;
      batteryType: string | null;
      connectivity: string | null;
      isRechargeable: boolean;
      price: number;
      offerPrice: number | null;
      stock: number;
      isFeatured: boolean;
      images: { url: string }[];
      category: {
        id: string;
        name: string;
        slug: string;
        parent: { id: string; name: string; slug: string } | null;
      } | null;
    }>,
  ) =>
    items.map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      description: p.description,
      brand: p.brand,
      modelCode: p.modelCode,
      deviceStyle: p.deviceStyle,
      hearingLossRange: p.hearingLossRange,
      batteryType: p.batteryType,
      connectivity: p.connectivity,
      isRechargeable: p.isRechargeable,
      shortDescription: null,
      price: p.price,
      offerPrice: p.offerPrice,
      stock: p.stock,
      isFeatured: p.isFeatured,
      isBestSelling: bestSellingIds.has(p.id),
      images: p.images.map((img) => ({ url: img.url })),
      category: p.category
        ? {
            id: p.category.id,
            name: p.category.name,
            slug: p.category.slug,
            parent: p.category.parent
              ? {
                  id: p.category.parent.id,
                  name: p.category.parent.name,
                  slug: p.category.parent.slug,
                }
              : null,
          }
        : null,
    }));

  if (sort === "best_selling") {
    const ranked = await prisma.orderItem.groupBy({
      by: ["productId"],
      _sum: { qty: true },
      orderBy: { _sum: { qty: "desc" } },
      take: 1000,
    });

    const rankedIds = ranked.map((r) => r.productId);

    if (rankedIds.length === 0) {
      const [items, total] = await Promise.all([
        prisma.product.findMany({
          where,
          orderBy: { createdAt: "desc" },
          skip,
          take,
          include,
        }),
        prisma.product.count({ where }),
      ]);

      const normalized = transformProducts(items);
      const withRatings = await attachRatings(normalized);

      return NextResponse.json({
        items: withRatings,
        total,
        page,
        take,
        pages: Math.max(1, Math.ceil(total / take)),
      });
    }

    const filteredProducts = await prisma.product.findMany({
      where: {
        ...where,
        id: { in: rankedIds },
      },
      include,
    });

    const rankMap = new Map<string, number>();
    rankedIds.forEach((id, idx) => rankMap.set(id, idx));

    filteredProducts.sort((a, b) => {
      return (
        (rankMap.get(a.id) ?? Number.MAX_SAFE_INTEGER) -
        (rankMap.get(b.id) ?? Number.MAX_SAFE_INTEGER)
      );
    });

    const total = filteredProducts.length;
    const pages = Math.max(1, Math.ceil(total / take));
    const sliced = filteredProducts.slice(skip, skip + take);

    const normalized = transformProducts(sliced);
    const withRatings = await attachRatings(normalized);

    return NextResponse.json({
      items: withRatings,
      total,
      page,
      take,
      pages,
    });
  }

  const orderBy =
    sort === "price_asc"
      ? [
          { offerPrice: "asc" as const },
          { price: "asc" as const },
          { createdAt: "desc" as const },
        ]
      : sort === "price_desc"
        ? [
            { offerPrice: "desc" as const },
            { price: "desc" as const },
            { createdAt: "desc" as const },
          ]
        : [{ createdAt: "desc" as const }];

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      skip,
      take,
      include,
    }),
    prisma.product.count({ where }),
  ]);

  const normalized = transformProducts(items);
  const withRatings = await attachRatings(normalized);

  return NextResponse.json({
    items: withRatings,
    total,
    page,
    take,
    pages: Math.max(1, Math.ceil(total / take)),
  });
}
