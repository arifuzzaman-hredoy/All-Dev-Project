import RecommendedProducts from "@/components/products/recommended-products";
import { Card } from "@/components/ui/card";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHero from "@/components/layout/page-hero";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function getStatusBadgeClass(status: string): string {
  switch (status) {
    case "DELIVERED":
      return "bg-green-50 text-green-700 border-green-200";
    case "SHIPPED":
      return "bg-blue-50 text-blue-700 border-blue-200";
    case "PROCESSING":
      return "bg-yellow-50 text-yellow-700 border-yellow-200";
    case "CANCELLED":
      return "bg-red-50 text-red-700 border-red-200";
    default:
      return "bg-black/5 text-black/70 border-black/10";
  }
}

function getPaymentBadgeClass(status: string): string {
  switch (status) {
    case "PAID":
      return "bg-green-50 text-green-700 border-green-200";
    case "FAILED":
    case "REFUNDED":
      return "bg-red-50 text-red-700 border-red-200";
    default:
      return "bg-black/5 text-black/70 border-black/10";
  }
}

function formatDate(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  return date.toLocaleString();
}

export default async function OrderDetailsPage({
  params,
}: {
  params: Promise<{ id?: string }> | { id?: string };
}) {
  const p = params instanceof Promise ? await params : params;
  const id = p?.id;

  if (!isNonEmptyString(id)) return notFound();

  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      items: {
        include: {
          product: {
            select: {
              id: true,
              categoryId: true,
              category: {
                select: {
                  id: true,
                  parent: {
                    select: {
                      id: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  if (!order) return notFound();

  const recommendedCategoryIds = Array.from(
    new Set(
      order.items.flatMap((item) => {
        const ids: string[] = [];

        if (item.product?.categoryId) ids.push(item.product.categoryId);
        if (item.product?.category?.parent?.id) {
          ids.push(item.product.category.parent.id);
        }

        return ids;
      }),
    ),
  );

  const orderedProductIds = Array.from(
    new Set(
      order.items
        .map((item) => item.product?.id)
        .filter((value): value is string => Boolean(value)),
    ),
  );

  const hasCourierInfo = Boolean(order.courierName || order.trackingId);

  return (
    <div className="space-y-8 pb-10">
      <PageHero
        eyebrow="Order Details"
        title={`Order ${order.id}`}
        description={`Placed on ${formatDate(order.createdAt)}. Review the summary, items, and delivery details in the same polished storefront style.`}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Orders", href: "/orders" },
          { label: "Order Details" },
        ]}
        actions={[
          { href: "/orders", label: "Back to orders" },
          { href: "/products", label: "Browse products", variant: "secondary" },
        ]}
        stats={[
          { label: "Order total", value: `৳ ${order.total}` },
          { label: "Items", value: String(order.items.length) },
          { label: "Status", value: String(order.status) },
          { label: "Payment", value: String(order.paymentStatus) },
        ]}
      />

      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Order Summary
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Subtotal</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.subtotal}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Discount</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.discount}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Shipping</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.shipping}
                </div>
              </div>

              <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
                <div className="text-xs text-slate-500">Tax</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ৳ {order.tax}
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-2xl border border-[#f8bbd0] bg-[#d81b60] p-4 text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)]">
              <div className="flex items-center justify-between">
                <span className="text-sm text-white/80">Grand Total</span>
                <span className="text-2xl font-bold">৳ {order.total}</span>
              </div>
            </div>
          </Card>

          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Ordered Items
            </div>

            <div className="mt-4 space-y-3">
              {order.items.map((it, index) => (
                <div
                  key={it.id}
                  className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-xs text-slate-400">
                        Item #{index + 1}
                      </div>
                      <div className="mt-1 line-clamp-2 text-sm font-semibold text-slate-900">
                        {it.productName}
                      </div>

                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                        <span>Unit Price: ৳ {it.unitPrice}</span>
                        <span>Qty: {it.qty}</span>
                        {it.sku ? <span>SKU: {it.sku}</span> : null}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs text-slate-500">Line Total</div>
                      <div className="text-base font-bold text-slate-900">
                        ৳ {it.lineTotal}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <RecommendedProducts
            title="You May Also Like"
            excludeProductIds={orderedProductIds}
            categoryIds={recommendedCategoryIds}
            fallbackToFeatured
            limit={8}
          />
        </div>

        <div className="space-y-4">
          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Delivery Information
            </div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Customer Name</div>
                <div className="font-semibold text-slate-900">{order.name}</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Phone Number</div>
                <div className="font-medium text-slate-900">{order.phone}</div>
              </div>

              {order.email ? (
                <div>
                  <div className="text-xs text-slate-500">Email</div>
                  <div className="font-medium text-slate-900">{order.email}</div>
                </div>
              ) : null}

              <div>
                <div className="text-xs text-slate-500">Address</div>
                <div className="font-medium leading-6 text-slate-700">
                  {order.addressLine1}
                  {order.addressLine2 ? `, ${order.addressLine2}` : ""}
                  {`, ${order.city}`}
                  {order.area ? `, ${order.area}` : ""}
                </div>
              </div>

              {order.note ? (
                <div>
                  <div className="text-xs text-slate-500">Customer Note</div>
                  <div className="rounded-2xl border border-[#f8bbd0] bg-[#fff1f5] p-3 text-slate-700">
                    {order.note}
                  </div>
                </div>
              ) : null}
            </div>
          </Card>

          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Courier Details
            </div>

            <div className="mt-4 space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Courier Service</div>
                <div className="font-medium text-slate-900">
                  {order.courierName || "Not assigned yet"}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Tracking ID</div>
                <div className="font-medium text-slate-900">
                  {order.trackingId || "Tracking not available yet"}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Shipping Status</div>
                <div className="font-medium text-slate-900">
                  {order.status === "SHIPPED"
                    ? "Your order has been shipped"
                    : order.status === "DELIVERED"
                      ? "Your order has been delivered"
                      : order.status === "PROCESSING"
                        ? "Your order is being prepared"
                        : order.status === "CANCELLED"
                          ? "This order was cancelled"
                          : "Waiting for courier processing"}
                </div>
              </div>

              {!hasCourierInfo ? (
                <div className="rounded-2xl border border-yellow-200 bg-yellow-50 p-3 text-xs text-yellow-800">
                  Courier details will appear here once the order is processed
                  and assigned.
                </div>
              ) : null}
            </div>
          </Card>

          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Quick Actions
            </div>

            <div className="mt-4 flex flex-col gap-3">
              <Link
                href="/orders"
                className="inline-flex h-11 items-center justify-center rounded-2xl border border-[#f8bbd0] bg-white/80 px-4 text-sm font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
              >
                My Orders
              </Link>

              <Link
                href="/products"
                className="inline-flex h-11 items-center justify-center rounded-2xl bg-[#d81b60] px-4 text-sm font-medium text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] transition hover:bg-[#c2185b]"
              >
                Continue Shopping
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
