"use client";

import * as React from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PageHero from "@/components/layout/page-hero";

type OrderItem = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  total: number;
  status: string;
  paymentStatus: string;
  courierName: string | null;
  trackingId: string | null;
  itemsCount: number;
};

type TrackResponse =
  | {
    ok: true;
    mode: "id" | "phone";
    items: OrderItem[];
  }
  | {
    ok: false;
    error: string;
  };

type MyOrdersResponse = {
  items: Array<{
    id: string;
    createdAt: string;
    total: number;
    status: string;
    paymentStatus: string;
  }>;
};

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function parseTrackResponse(input: unknown): TrackResponse {
  const o = input as Record<string, unknown>;

  if (o.ok === false) {
    return {
      ok: false,
      error: safeString(o.error, "Something went wrong"),
    };
  }

  const raw = Array.isArray(o.items) ? o.items : [];

  return {
    ok: true,
    mode: (safeString(o.mode) === "phone" ? "phone" : "id") as "id" | "phone",
    items: raw
      .map((x) => x as Record<string, unknown>)
      .map((x) => ({
        id: safeString(x.id),
        createdAt: safeString(x.createdAt),
        name: safeString(x.name),
        phone: safeString(x.phone),
        total: safeNumber(x.total, 0),
        status: safeString(x.status),
        paymentStatus: safeString(x.paymentStatus),
        courierName: typeof x.courierName === "string" ? x.courierName : null,
        trackingId: typeof x.trackingId === "string" ? x.trackingId : null,
        itemsCount: safeNumber(x.itemsCount, 0),
      }))
      .filter((x) => x.id),
  };
}

function parseMyOrdersResponse(input: unknown): MyOrdersResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  return {
    items: raw
      .map((x) => x as Record<string, unknown>)
      .map((x) => ({
        id: safeString(x.id),
        createdAt: safeString(x.createdAt),
        total: safeNumber(x.total, 0),
        status: safeString(x.status),
        paymentStatus: safeString(x.paymentStatus),
      }))
      .filter((x) => x.id),
  };
}

function OrderStatusBadge({ value }: { value: string }) {
  const cls =
    value === "DELIVERED"
      ? "bg-green-50 text-green-700"
      : value === "CANCELLED"
        ? "bg-red-50 text-red-700"
        : value === "SHIPPED"
          ? "bg-blue-50 text-blue-700"
          : value === "PROCESSING"
            ? "bg-yellow-50 text-yellow-700"
            : "bg-black/5 text-black/70";

  return (
    <span className={`rounded-full px-2 py-1 text-[11px] font-medium ${cls}`}>
      {value}
    </span>
  );
}

function PaymentStatusBadge({ value }: { value: string }) {
  const cls =
    value === "PAID"
      ? "bg-green-50 text-green-700"
      : value === "FAILED" || value === "REFUNDED"
        ? "bg-red-50 text-red-700"
        : "bg-black/5 text-black/70";

  return (
    <span className={`rounded-full px-2 py-1 text-[11px] font-medium ${cls}`}>
      {value}
    </span>
  );
}

export default function OrdersPage() {
  const { status } = useSession();

  const [orderId, setOrderId] = React.useState("");
  const [phone, setPhone] = React.useState("");

  const [loadingTrack, setLoadingTrack] = React.useState(false);
  const [trackResult, setTrackResult] = React.useState<TrackResponse | null>(
    null,
  );

  const [loadingMine, setLoadingMine] = React.useState(false);
  const [myOrders, setMyOrders] = React.useState<MyOrdersResponse>({
    items: [],
  });

  React.useEffect(() => {
    if (status !== "authenticated") return;

    const loadMyOrders = async () => {
      setLoadingMine(true);
      try {
        const res = await fetch("/api/orders/account", { cache: "no-store" });
        const json: unknown = await res.json().catch(() => null);
        setMyOrders(parseMyOrdersResponse(json));
      } finally {
        setLoadingMine(false);
      }
    };

    void loadMyOrders();
  }, [status]);

  const searchById = async () => {
    const value = orderId.trim();
    if (!value) return;

    setLoadingTrack(true);
    setTrackResult(null);

    try {
      const res = await fetch(
        `/api/orders/track?orderId=${encodeURIComponent(value)}`,
        { cache: "no-store" },
      );
      const json: unknown = await res.json().catch(() => null);
      setTrackResult(parseTrackResponse(json));
    } finally {
      setLoadingTrack(false);
    }
  };

  const searchByPhone = async () => {
    const value = phone.trim();
    if (!value) return;

    setLoadingTrack(true);
    setTrackResult(null);

    try {
      const res = await fetch(
        `/api/orders/track?phone=${encodeURIComponent(value)}`,
        { cache: "no-store" },
      );
      const json: unknown = await res.json().catch(() => null);
      setTrackResult(parseTrackResponse(json));
    } finally {
      setLoadingTrack(false);
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <PageHero
        eyebrow="Orders & Tracking"
        title="Find your order."
        description="Track by order ID or phone number"
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Orders & Tracking" },
        ]}
        actions={[
          { href: "/products", label: "Browse products" },
          { href: "/cart", label: "Open cart", variant: "secondary" },
        ]}
        stats={[
          { label: "Search options", value: "2" },
          { label: "Account orders", value: "Live" },
          { label: "Tracking mode", value: "Fast" },
          { label: "Details page", value: "Ready" },
        ]}
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-white to-white p-5 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)]">
          <div className="text-sm font-semibold text-[#ad1457]">
            Track by Order ID
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Write your order ID to track a single order
          </div>

          <div className="mt-3 flex gap-2">
            <Input
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="Enter order ID"
            />
            <Button
              onClick={() => void searchById()}
              disabled={loadingTrack}
              className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
            >
              Search
            </Button>
          </div>

          <div className="mt-6 text-sm font-semibold text-[#ad1457]">
            Track by Phone
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Write your phone number to track recent orders with that phone
            number. This is useful if you don&apos;t remember your order ID.
          </div>

          <div className="mt-3 flex gap-2">
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Enter phone number"
            />
            <Button
              onClick={() => void searchByPhone()}
              disabled={loadingTrack}
              className="bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
            >
              Search
            </Button>
          </div>

          <div className="mt-6 rounded-2xl border border-[#f8bbd0] bg-white/80 p-4 text-xs text-slate-600 shadow-[0_12px_34px_-24px_rgba(216,27,96,0.18)]">
            Tip: Search with order ID for better results.
          </div>
        </Card>

        <div className="space-y-4">
          {status === "authenticated" ? (
            <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    My Orders
                  </div>
                  <div className="text-xs text-slate-600">
                    Logged-in account orders
                  </div>
                </div>
              </div>

              <div className="mt-3 space-y-2">
                {loadingMine ? (
                  <div className="text-sm text-slate-600">
                    Loading your orders...
                  </div>
                ) : myOrders.items.length ? (
                  myOrders.items.map((order) => (
                    <Link key={order.id} href={`/orders/${order.id}`}>
                      <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4 transition hover:bg-[#fff1f5]">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div>
                            <div className="text-sm font-semibold text-slate-900">
                              #{order.id}
                            </div>
                            <div className="text-xs text-slate-600">
                              {new Date(order.createdAt).toLocaleString()}
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="text-sm font-semibold text-slate-900">
                              ৳ {order.total}
                            </div>
                            <div className="mt-1 flex flex-wrap justify-end gap-1">
                              <OrderStatusBadge value={order.status} />
                              <PaymentStatusBadge value={order.paymentStatus} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-sm text-slate-600">
                    No account orders found.
                  </div>
                )}
              </div>
            </Card>
          ) : null}

          <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-white to-white p-4 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
            <div className="text-sm font-semibold text-slate-900">
              Tracking Result
            </div>

            <div className="mt-3 space-y-2">
              {loadingTrack ? (
                <div className="text-sm text-slate-600">
                  Searching orders...
                </div>
              ) : trackResult?.ok === false ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {trackResult.error}
                </div>
              ) : trackResult?.ok === true && trackResult.items.length ? (
                trackResult.items.map((order) => (
                  <Link key={order.id} href={`/orders/${order.id}`}>
                    <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4 transition hover:bg-[#fff1f5]">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold text-slate-900">
                            #{order.id}
                          </div>
                          <div className="text-xs text-slate-600">
                            {new Date(order.createdAt).toLocaleString()} •{" "}
                            {order.itemsCount} items
                          </div>
                          <div className="text-xs text-black/60">
                            {order.name} • {order.phone}
                          </div>
                          <div className="text-xs text-black/60">
                            {order.courierName
                              ? `Courier: ${order.courierName}`
                              : "No courier"}
                            {" • "}
                            {order.trackingId
                              ? `Tracking: ${order.trackingId}`
                              : "No tracking"}
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-sm font-semibold">
                            ৳ {order.total}
                          </div>
                          <div className="mt-1 flex flex-wrap justify-end gap-1">
                            <OrderStatusBadge value={order.status} />
                            <PaymentStatusBadge value={order.paymentStatus} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="text-sm text-black/60">
                  Search by Order ID or phone number to track orders.
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
