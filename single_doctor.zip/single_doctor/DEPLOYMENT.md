# Single Doctor production deployment

- Repository: `git@github.com:techtemlead-lab/single_doctor.git`
- Branch: `main`
- Domain: `singledoc.techteamlead.com`
- Project directory: `/var/www/single-doctor`
- App binding: `127.0.0.1:5010`
- Container: `singledoc-app`

This deployment creates a new application and does not modify the existing `prescription.techteamlead.com` application.

## First deployment

```bash
cd /var/www/single-doctor
chmod +x vps-install.sh scripts/*.sh
./scripts/deploy.sh
curl -sS http://127.0.0.1:5010/api/health
sudo ./scripts/setup-nginx.sh
```

After the DNS A record points to the VPS:

```bash
sudo certbot --nginx -d singledoc.techteamlead.com --redirect
```

## Update from GitHub

```bash
cd /var/www/single-doctor
./scripts/update-from-github.sh
```

## Persistent paths

- Data: `/var/www/single-doctor/data/clinic-store.json`
- Uploads: `/var/www/single-doctor/uploads/`
- Environment: `/var/www/single-doctor/.env.production`
