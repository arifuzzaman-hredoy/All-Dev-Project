#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${PROJECT_DIR:-/var/www/single-doctor}"
BRANCH="${BRANCH:-main}"

cd "$PROJECT_DIR"

[[ -d .git ]] || { echo "$PROJECT_DIR is not a Git repository." >&2; exit 1; }
[[ -z "$(git status --porcelain)" ]] || {
  echo "Working tree has uncommitted changes. Refusing to overwrite them." >&2
  git status --short
  exit 1
}

git fetch origin "$BRANCH"
git checkout "$BRANCH"
git pull --ff-only origin "$BRANCH"
exec "$PROJECT_DIR/scripts/deploy.sh"
