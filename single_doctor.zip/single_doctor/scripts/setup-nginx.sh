#!/usr/bin/env bash
set -Eeuo pipefail

DOMAIN="${DOMAIN:-singledoc.techteamlead.com}"
HOST_PORT="${HOST_PORT:-5010}"
SITE_NAME="${SITE_NAME:-singledoc}"
AVAILABLE_FILE="/etc/nginx/sites-available/$SITE_NAME"
ENABLED_FILE="/etc/nginx/sites-enabled/$SITE_NAME"
CERT_DIR="/etc/letsencrypt/live/$DOMAIN"

[[ "${EUID}" -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 1; }

curl --fail --silent --max-time 5 "http://127.0.0.1:${HOST_PORT}/api/health" >/dev/null || {
  echo "Application is not healthy on port $HOST_PORT." >&2
  exit 1
}

if [[ -f "$CERT_DIR/fullchain.pem" && -f "$CERT_DIR/privkey.pem" ]]; then
  cat > "$AVAILABLE_FILE" <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN;

    ssl_certificate $CERT_DIR/fullchain.pem;
    ssl_certificate_key $CERT_DIR/privkey.pem;

    client_max_body_size 25m;

    location / {
        proxy_pass http://127.0.0.1:$HOST_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 120s;
    }
}
NGINX
else
  cat > "$AVAILABLE_FILE" <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    client_max_body_size 25m;

    location / {
        proxy_pass http://127.0.0.1:$HOST_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 120s;
    }
}
NGINX
fi

ln -sfn "$AVAILABLE_FILE" "$ENABLED_FILE"
nginx -t
systemctl reload nginx

echo "Nginx configured for http://$DOMAIN"

if [[ ! -f "$CERT_DIR/fullchain.pem" ]]; then
  cat <<NEXT
SSL certificate is not installed yet. After the DNS A record points to this VPS, run:

sudo certbot --nginx -d $DOMAIN --redirect
NEXT
else
  echo "SSL certificate already exists: https://$DOMAIN"
fi
