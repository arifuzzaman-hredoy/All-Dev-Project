#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${PROJECT_DIR:-/var/www/single-doctor}"
DOMAIN="${DOMAIN:-singledoc.techteamlead.com}"
HOST_PORT="${HOST_PORT:-5010}"
COMPOSE_FILE="$PROJECT_DIR/compose.production.yml"
ENV_FILE="$PROJECT_DIR/.env.production"
CREDENTIAL_FILE="$PROJECT_DIR/.initial-admin-credentials"
CONTAINER_NAME="singledoc-app"

cd "$PROJECT_DIR"

command -v docker >/dev/null 2>&1 || { echo "Docker is not installed." >&2; exit 1; }
docker compose version >/dev/null
command -v openssl >/dev/null 2>&1 || { echo "OpenSSL is not installed." >&2; exit 1; }

if ss -ltnH | awk '{print $4}' | grep -Eq "(^|:)${HOST_PORT}$"; then
  existing_container="$(docker ps --filter "name=^/${CONTAINER_NAME}$" --format '{{.Names}}' || true)"
  if [[ "$existing_container" != "$CONTAINER_NAME" ]]; then
    echo "Port $HOST_PORT is already occupied by another process." >&2
    exit 1
  fi
fi

mkdir -p data uploads
chown -R 1001:1001 data uploads
chmod 750 data uploads

if [[ ! -f "$ENV_FILE" ]]; then
  umask 077
  auth_secret="$(openssl rand -hex 48)"
  admin_password="$(openssl rand -base64 24 | tr -d '\n' | tr '/+' '_-')"

  cat > "$ENV_FILE" <<ENV
AUTH_SECRET=$auth_secret
CLINIC_DATA_PATH=/app/.clinic-data/clinic-store.json
NEXT_PUBLIC_SITE_URL=https://$DOMAIN
INITIAL_ADMIN_NAME=Dr. Kawsar Ahmed
INITIAL_ADMIN_EMAIL=doctor@example.com
INITIAL_ADMIN_PASSWORD=$admin_password
ENV

  cat > "$CREDENTIAL_FILE" <<CREDS
Admin URL: https://$DOMAIN/admin
Email: doctor@example.com
Password: $admin_password
CREDS
  chmod 600 "$ENV_FILE" "$CREDENTIAL_FILE"
  echo "Created $ENV_FILE and one-time credential file."
else
  chmod 600 "$ENV_FILE"
fi

required_vars=(AUTH_SECRET CLINIC_DATA_PATH NEXT_PUBLIC_SITE_URL INITIAL_ADMIN_NAME INITIAL_ADMIN_EMAIL INITIAL_ADMIN_PASSWORD)
for variable in "${required_vars[@]}"; do
  if ! grep -Eq "^${variable}=.+" "$ENV_FILE"; then
    echo "Missing or empty $variable in $ENV_FILE" >&2
    exit 1
  fi
done

echo "Building production image..."
docker compose -f "$COMPOSE_FILE" build --pull app

echo "Starting application on 127.0.0.1:$HOST_PORT..."
docker compose -f "$COMPOSE_FILE" up -d --remove-orphans

for attempt in $(seq 1 40); do
  if curl --fail --silent --max-time 3 "http://127.0.0.1:${HOST_PORT}/api/health" >/dev/null; then
    echo "Application health check passed."
    docker compose -f "$COMPOSE_FILE" ps
    echo "Local URL: http://127.0.0.1:$HOST_PORT"
    echo "Credentials: $CREDENTIAL_FILE"
    exit 0
  fi
  sleep 3
done

echo "Application did not become healthy." >&2
docker compose -f "$COMPOSE_FILE" ps >&2
docker compose -f "$COMPOSE_FILE" logs --tail=200 app >&2
exit 1
