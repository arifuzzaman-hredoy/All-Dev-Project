#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${PROJECT_DIR:-/var/www/single-doctor}"
DOMAIN="${DOMAIN:-singledoc.techteamlead.com}"
HOST_PORT="${HOST_PORT:-5010}"

cd "$PROJECT_DIR"
docker compose -f compose.production.yml ps
echo
docker compose -f compose.production.yml logs --tail=80 app
echo
curl --max-time 10 -sS -w '\nLocal HTTP %{http_code}\n' "http://127.0.0.1:${HOST_PORT}/api/health" || true
curl --max-time 15 -sS -o /dev/null -w "Domain HTTP %{http_code}\n" "https://${DOMAIN}/api/health" || true
