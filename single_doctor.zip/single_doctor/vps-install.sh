#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${TARGET_DIR:-/var/www/single-doctor}"

if [[ "$SOURCE_DIR" == "$TARGET_DIR" ]]; then
  exec "$TARGET_DIR/scripts/deploy.sh"
fi

mkdir -p "$TARGET_DIR"
cp -a "$SOURCE_DIR"/. "$TARGET_DIR"/
chmod +x "$TARGET_DIR"/scripts/*.sh "$TARGET_DIR/vps-install.sh"
exec "$TARGET_DIR/scripts/deploy.sh"
