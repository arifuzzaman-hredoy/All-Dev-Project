"use client";

import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  ClipboardCheck,
  HeartPulse,
  Leaf,
  LucideIcon,
  Microscope,
  ShieldCheck,
  Stethoscope,
  Syringe,
} from "lucide-react";

import { serviceItems } from "../../data/site";
import { SectionLabel } from "../shared/SectionLabel";

const serviceIcons = {
  Activity,
  ClipboardCheck,
  HeartPulse,
  Leaf,
  Microscope,
  ShieldCheck,
  Stethoscope,
  Syringe,
};

type ServiceIconName = keyof typeof serviceIcons;

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[6%] top-[18%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[8%] top-[15%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[14%] bottom-[12%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[16%] bottom-[10%] h-16 w-16 rotate-[-8deg]",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.12,
    },
  },
};

const fadeUpVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 26,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.62,
      ease: "easeOut",
    },
  },
};

export function Services() {
  const reduceMotion = useReducedMotion();

  return (
    <section
      id="services"
      className="relative isolate overflow-hidden bg-[#F5F7F8] py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.105)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.105)_1px,transparent_1px)] bg-[size:48px_48px]" />
        <div className="absolute left-[-10%] top-[-18%] h-[420px] w-[420px] bg-[#D7E0E4]/70 blur-3xl" />
        <div className="absolute bottom-[-20%] right-[-8%] h-[520px] w-[520px] bg-[#7FBAC6]/24 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(46,126,149,0.08),transparent_28%),linear-gradient(180deg,rgba(245,247,248,0.78),rgba(245,247,248,0.96))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.055] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -12 : 12, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 24 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.35 }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mx-auto max-w-3xl text-center"
        >
          <SectionLabel>Services</SectionLabel>

          <h2 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl">
            <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
              Care that feels personal, clear, and preventive.
            </span>
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-[#1B3A44]/68">
            Focused medical support for everyday health, lifestyle improvement,
            chronic disease prevention, and long-term patient guidance.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: false, amount: 0.18 }}
          className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4"
        >
          {serviceItems.map((item, index) => {
            const Icon =
              serviceIcons[item.icon as ServiceIconName] ?? Stethoscope;

            return (
              <motion.article
                key={item.title}
                variants={fadeUpVariants}
                whileHover={
                  reduceMotion
                    ? undefined
                    : {
                        y: -7,
                        boxShadow: "0 28px 80px rgba(27,58,68,0.12)",
                      }
                }
                transition={{ duration: 0.28, ease: "easeOut" }}
                className="group relative overflow-hidden border border-white/85 bg-white/78 p-6 shadow-[0_18px_50px_rgba(27,58,68,0.055)] backdrop-blur transition-colors duration-300 hover:border-[#7FBAC6]/80"
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#7FBAC6] to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <div className="absolute -right-12 -top-12 h-28 w-28 bg-[#7FBAC6]/18 blur-2xl transition-opacity duration-300 group-hover:opacity-100" />

                <div className="relative">
                  <div className="flex items-center justify-between gap-4">
                    <motion.div
                      whileHover={
                        reduceMotion
                          ? undefined
                          : {
                              rotate: 8,
                              scale: 1.08,
                            }
                      }
                      transition={{ duration: 0.22, ease: "easeOut" }}
                      className="text-[#2E7E95]"
                    >
                      <Icon className="h-8 w-8 stroke-[1.55]" />
                    </motion.div>

                    <span className="text-xs font-extrabold text-[#1B3A44]/22">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>

                  <h3 className="mt-6 text-lg font-extrabold tracking-[-0.02em] text-[#1B3A44]">
                    {item.title}
                  </h3>

                  <p className="mt-3 text-sm leading-7 text-[#1B3A44]/68">
                    {item.body}
                  </p>
                </div>
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}