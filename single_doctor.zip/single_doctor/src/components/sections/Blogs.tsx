"use client";

import Link from "next/link";
import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  ArrowRight,
  BookOpenText,
  HeartPulse,
  LucideIcon,
  Newspaper,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";

import { blogItems } from "../../data/site";
import { usePublicSite } from "../PublicSiteProvider";
import { SectionLabel } from "../shared/SectionLabel";

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[7%] top-[16%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[8%] top-[20%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[15%] bottom-[12%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[15%] bottom-[10%] h-16 w-16 rotate-[-8deg]",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.09,
      delayChildren: 0.1,
    },
  },
};

const cardVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 28,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.62,
      ease: "easeOut",
    },
  },
};

export function Blogs() {
  const reduceMotion = useReducedMotion();
  const { blogs } = usePublicSite();
  const visibleBlogs = blogs.length ? blogs : blogItems.map((item, index) => ({ ...item, id: `fallback-blog-${index}`, image: undefined, published: true, createdAt: "", updatedAt: "" }));

  return (
    <section
      id="blogs"
      className="relative isolate overflow-hidden bg-white py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.075)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.075)_1px,transparent_1px)] bg-[size:48px_48px]" />
        <div className="absolute left-[-10%] top-[-18%] h-[440px] w-[440px] bg-[#D7E0E4]/60 blur-3xl" />
        <div className="absolute bottom-[-22%] right-[-8%] h-[520px] w-[520px] bg-[#7FBAC6]/20 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_8%,rgba(46,126,149,0.08),transparent_30%),linear-gradient(180deg,rgba(255,255,255,0.74),rgba(255,255,255,0.98))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.052] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -12 : 12, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 24 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.35 }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mx-auto max-w-3xl text-center"
        >
          <SectionLabel>Health Advice</SectionLabel>

          <h2 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl">
            <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
              Public health education in simple language.
            </span>
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-[#1B3A44]/68">
            Practical health guidance for lifestyle, prevention, blood pressure,
            diabetes, and everyday patient awareness.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: false, amount: 0.16 }}
          className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3"
        >
          {visibleBlogs.map((blog, index) => {
            const isFeatured = index === 0;

            return (
              <motion.article
                key={blog.id || blog.title}
                variants={cardVariants}
                whileHover={
                  reduceMotion
                    ? undefined
                    : {
                        y: -7,
                        boxShadow: "0 30px 90px rgba(27,58,68,0.12)",
                      }
                }
                transition={{ duration: 0.28, ease: "easeOut" }}
                className={`group relative overflow-hidden border border-[#D7E0E4]/80 bg-[#F5F7F8]/88 p-6 shadow-[0_18px_50px_rgba(27,58,68,0.055)] backdrop-blur transition-colors duration-300 hover:border-[#7FBAC6]/90 ${
                  isFeatured ? "md:col-span-2 lg:col-span-1 lg:row-span-2" : ""
                }`}
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#2E7E95] to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <div className="absolute -right-14 -top-14 h-32 w-32 bg-[#7FBAC6]/20 blur-2xl transition-opacity duration-300 group-hover:opacity-100" />
                <div className="absolute bottom-0 left-0 h-24 w-24 bg-[#D7E0E4]/50 blur-2xl" />

                <div className="relative flex min-h-full flex-col">
                  <div className="flex items-center justify-between gap-4">
                    <motion.div
                      whileHover={
                        reduceMotion
                          ? undefined
                          : {
                              rotate: 8,
                              scale: 1.08,
                            }
                      }
                      transition={{ duration: 0.22, ease: "easeOut" }}
                      className="text-[#2E7E95]"
                    >
                      {isFeatured ? (
                        <BookOpenText className="h-8 w-8 stroke-[1.55]" />
                      ) : (
                        <Newspaper className="h-7 w-7 stroke-[1.55]" />
                      )}
                    </motion.div>

                    <span className="border border-white/80 bg-white/76 px-3 py-1 text-xs font-extrabold text-[#2E7E95] shadow-[0_10px_30px_rgba(27,58,68,0.05)]">
                      {blog.category}
                    </span>
                  </div>

                  {isFeatured && (
                    <div className="mt-8 flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.18em] text-[#d99b45]">
                      <Sparkles className="h-4 w-4" />
                      Featured Advice
                    </div>
                  )}

                  <h3
                    className={`mt-6 font-extrabold leading-tight tracking-[-0.03em] text-[#1B3A44] ${
                      isFeatured ? "text-2xl sm:text-3xl" : "text-xl"
                    }`}
                  >
                    {blog.title}
                  </h3>

                  <p
                    className={`mt-4 text-sm leading-7 text-[#1B3A44]/68 ${
                      isFeatured ? "sm:text-base sm:leading-8" : ""
                    }`}
                  >
                    {blog.body}
                  </p>

                  <Link
                    href={`/blogs/${blog.slug}`}
                    className="mt-7 inline-flex w-fit items-center gap-2 text-sm font-extrabold text-[#2E7E95]"
                  >
                    <span className="relative">
                      Read more
                      <span className="absolute -bottom-1 left-0 h-px w-0 bg-[#2E7E95] transition-all duration-300 group-hover:w-full" />
                    </span>
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </div>
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}