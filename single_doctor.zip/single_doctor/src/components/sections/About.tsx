"use client";

import Image from "next/image";
import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  Award,
  CheckCircle2,
  HeartPulse,
  LucideIcon,
  Microscope,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  UserRound,
} from "lucide-react";

import { focusItems } from "../../data/site";
import { SectionLabel } from "../shared/SectionLabel";

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[6%] top-[14%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[8%] top-[18%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[18%] bottom-[13%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: Microscope,
    className: "right-[18%] bottom-[12%] h-16 w-16 rotate-[-8deg]",
  },
];

const containerAnimation: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.08,
    },
  },
};

const fadeUpAnimation: Variants = {
  hidden: {
    opacity: 0,
    y: 24,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.62,
      ease: "easeOut",
    },
  },
};

export function About() {
  const reduceMotion = useReducedMotion();

  return (
    <section
      id="about"
      className="relative isolate overflow-hidden bg-white py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.075)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.075)_1px,transparent_1px)] bg-[size:46px_46px]" />
        <div className="absolute left-[-12%] top-[10%] h-[420px] w-[420px] bg-[#D7E0E4]/60 blur-3xl" />
        <div className="absolute bottom-[-20%] right-[-8%] h-[500px] w-[500px] bg-[#7FBAC6]/22 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_20%,rgba(46,126,149,0.08),transparent_30%),linear-gradient(180deg,rgba(255,255,255,0.7),rgba(255,255,255,0.96))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.055] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -12 : 12, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto grid max-w-7xl gap-14 px-4 sm:px-6 lg:grid-cols-[0.86fr_1.14fr] lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, x: -34 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, x: 0 }}
          viewport={{ once: false, amount: 0.35 }}
          transition={{ duration: 0.72, ease: "easeOut" }}
          className="relative"
        >
          <motion.span
            initial={reduceMotion ? false : { scaleY: 0 }}
            whileInView={reduceMotion ? undefined : { scaleY: 1 }}
            viewport={{ once: false, amount: 0.45 }}
            transition={{ duration: 0.75, ease: "easeOut" }}
            className="absolute -left-5 top-8 z-10 h-44 w-px origin-top bg-gradient-to-b from-transparent via-[#2E7E95] to-transparent"
          />

          <motion.span
            initial={reduceMotion ? false : { scaleX: 0 }}
            whileInView={reduceMotion ? undefined : { scaleX: 1 }}
            viewport={{ once: false, amount: 0.45 }}
            transition={{ duration: 0.75, delay: 0.16, ease: "easeOut" }}
            className="absolute -left-5 top-8 z-10 h-px w-32 origin-left bg-gradient-to-r from-[#2E7E95] via-[#7FBAC6] to-transparent"
          />

          <motion.span
            initial={reduceMotion ? false : { scaleX: 0 }}
            whileInView={reduceMotion ? undefined : { scaleX: 1 }}
            viewport={{ once: false, amount: 0.45 }}
            transition={{ duration: 0.75, delay: 0.24, ease: "easeOut" }}
            className="absolute -right-4 bottom-8 z-10 h-px w-36 origin-right bg-gradient-to-l from-[#2E7E95] via-[#7FBAC6] to-transparent"
          />

          <motion.span
            initial={reduceMotion ? false : { scaleY: 0 }}
            whileInView={reduceMotion ? undefined : { scaleY: 1 }}
            viewport={{ once: false, amount: 0.45 }}
            transition={{ duration: 0.75, delay: 0.32, ease: "easeOut" }}
            className="absolute -right-4 bottom-8 z-10 h-32 w-px origin-bottom bg-gradient-to-t from-[#2E7E95] via-[#7FBAC6] to-transparent"
          />

          <div className="absolute -inset-4 bg-[#7FBAC6]/16 blur-3xl" />

          <motion.div
            whileHover={reduceMotion ? undefined : { y: -6 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
            className="group relative overflow-hidden rounded-2xl border border-[#D7E0E4]/80 bg-[#F5F7F8] p-3 shadow-[0_30px_95px_rgba(27,58,68,0.12)]"
          >
            <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.85),transparent_36%,rgba(127,186,198,0.2))]" />

            <motion.div
              initial={reduceMotion ? false : { opacity: 0, scale: 0.98 }}
              whileInView={reduceMotion ? undefined : { opacity: 1, scale: 1 }}
              viewport={{ once: false, amount: 0.35 }}
              transition={{ duration: 0.55, ease: "easeOut" }}
              className="relative overflow-hidden rounded-xl"
            >
              <Image
                src="/kawsharsirabout.png"
                alt="Dr. Kawsar Ahmed professional portrait"
                width={760}
                height={860}
                sizes="(max-width: 1024px) 100vw, 42vw"
                className="aspect-[4/5] w-full object-cover object-center"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-[#1B3A44]/24 via-transparent to-transparent" />

              <motion.div
                aria-hidden="true"
                animate={
                  reduceMotion
                    ? undefined
                    : {
                        x: ["-140%", "140%"],
                      }
                }
                transition={{
                  duration: 3.4,
                  repeat: Infinity,
                  repeatDelay: 3.2,
                  ease: "easeInOut",
                }}
                className="absolute inset-y-0 w-1/3 rotate-12 bg-gradient-to-r from-transparent via-white/24 to-transparent"
              />
            </motion.div>

            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: 18 }}
              whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: false, amount: 0.55 }}
              transition={{ duration: 0.55, delay: 0.25, ease: "easeOut" }}
              className="absolute bottom-6 left-6 right-6 border border-white/70 bg-white/90 p-4 shadow-[0_18px_45px_rgba(27,58,68,0.13)] backdrop-blur-md"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-[#2E7E95]" />
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#d99b45]">
                  Doctor Profile
                </p>
              </div>
              <p className="mt-1 text-sm font-extrabold text-[#1B3A44]">
                General & Lifestyle Physician
              </p>
            </motion.div>

            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: 12 }}
              whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: false, amount: 0.55 }}
              transition={{ duration: 0.55, delay: 0.42, ease: "easeOut" }}
              className="absolute right-6 top-6 flex items-center gap-2 border border-white/70 bg-white/86 px-3 py-2 text-xs font-extrabold text-[#1B3A44] shadow-[0_14px_35px_rgba(27,58,68,0.12)] backdrop-blur"
            >
              <Award className="h-4 w-4 text-[#2E7E95]" />
              Senior Medical Officer
            </motion.div>
          </motion.div>
        </motion.div>

        <motion.div
          variants={containerAnimation}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: false, amount: 0.28 }}
        >
          <motion.div variants={fadeUpAnimation}>
            <SectionLabel>About Doctor</SectionLabel>
          </motion.div>

          <motion.h2
            variants={fadeUpAnimation}
            className="mt-3 max-w-3xl text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl"
          >
            <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
              Trusted personal care with a public-health perspective.
            </span>
          </motion.h2>

          <motion.p
            variants={fadeUpAnimation}
            className="mt-6 max-w-3xl text-base leading-8 text-[#1B3A44]/72 sm:text-lg"
          >
            Dr. Kawsar Ahmed is a General & Lifestyle Physician serving at
            Hypertension & Research Centre, Rangpur. His practice combines
            general medicine, cardiovascular prevention, diabetes care, lifestyle
            counseling, research-minded public health, and clear patient
            education.
          </motion.p>

          <motion.div
            variants={fadeUpAnimation}
            className="relative mt-6 overflow-hidden border border-[#D7E0E4]/85 bg-[#F5F7F8]/90 p-5 shadow-[0_18px_50px_rgba(27,58,68,0.055)] backdrop-blur"
          >
            <ShieldCheck className="absolute right-5 top-5 h-14 w-14 text-[#2E7E95]/10" />
            <p className="font-bangla relative text-base leading-8 text-[#1B3A44]/80">
              জেনারেল এন্ড লাইফস্টাইল ফিজিশিয়ান ডা. কাওছার আহমেদ, এমবিবিএস
              (রংপুর মেডিকেল কলেজ), এমপিএইচ, সিসিএইচ, সিসিডি, সিএমইউ, সিনিয়র
              মেডিকেল অফিসার, হাইপারটেনশন এন্ড রিসার্চ সেন্টার, রংপুর।
            </p>
          </motion.div>

          <motion.div
            variants={fadeUpAnimation}
            className="mt-7 grid gap-3 sm:grid-cols-3"
          >
            {[
              { icon: UserRound, text: "Personal Care" },
              { icon: HeartPulse, text: "Lifestyle Medicine" },
              { icon: Activity, text: "Preventive Health" },
            ].map(({ icon: Icon, text }) => (
              <motion.div
                key={text}
                whileHover={reduceMotion ? undefined : { y: -4 }}
                className="border border-[#D7E0E4]/75 bg-white/74 px-4 py-4 text-sm font-extrabold shadow-[0_16px_45px_rgba(27,58,68,0.06)] backdrop-blur"
              >
                <Icon className="mb-3 h-5 w-5 text-[#2E7E95]" />
                {text}
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            variants={fadeUpAnimation}
            className="mt-8 grid gap-4 sm:grid-cols-2"
          >
            {focusItems.map((item, index) => (
              <motion.div
                key={item}
                initial={reduceMotion ? false : { opacity: 0, y: 18 }}
                whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
                viewport={{ once: false, amount: 0.55 }}
                transition={{
                  duration: 0.48,
                  delay: reduceMotion ? 0 : index * 0.055,
                  ease: "easeOut",
                }}
                whileHover={reduceMotion ? undefined : { y: -3 }}
                className="group flex items-start gap-3 border-t border-[#D7E0E4] bg-white/58 px-1 pt-4 text-sm font-bold"
              >
                <motion.span
                  whileHover={
                    reduceMotion
                      ? undefined
                      : {
                          rotate: 10,
                          scale: 1.08,
                        }
                  }
                  transition={{ duration: 0.22, ease: "easeOut" }}
                >
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#2E7E95]" />
                </motion.span>
                <span className="leading-6 text-[#1B3A44]">{item}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
