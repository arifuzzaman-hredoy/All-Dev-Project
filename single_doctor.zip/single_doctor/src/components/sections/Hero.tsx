"use client";

import Image from "next/image";
import { motion, useReducedMotion, type Variants } from "framer-motion";
import {
  ArrowRight,
  CalendarCheck,
  CheckCircle2,
  HeartPulse,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import { usePublicSite } from "../PublicSiteProvider";


const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.11,
      delayChildren: 0.12,
    },
  },
};

const textVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 26,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.72,
      ease: "easeOut",
    },
  },
};

export function Hero() {
  const reduceMotion = useReducedMotion();
  const { profile, cms } = usePublicSite();
  const trustItems = [profile.designation, profile.chamberName, profile.visitingHours].filter(Boolean);

  return (
    <section
      id="home"
      className="relative isolate min-h-[92vh] overflow-hidden bg-[#F5F7F8] pt-36 text-[#1B3A44] sm:pt-32"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.12)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.12)_1px,transparent_1px)] bg-[size:48px_48px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_18%,rgba(127,186,198,0.22),transparent_32%),radial-gradient(circle_at_82%_25%,rgba(46,126,149,0.16),transparent_34%),radial-gradient(circle_at_55%_88%,rgba(215,224,228,0.75),transparent_34%)]" />
        <div className="absolute left-0 top-0 h-full w-full bg-[linear-gradient(90deg,rgba(245,247,248,0.94),rgba(245,247,248,0.78),rgba(245,247,248,0.94))]" />

        <motion.div
          animate={
            reduceMotion
              ? undefined
              : {
                  y: [0, -14, 0],
                  rotate: [-10, -4, -10],
                }
          }
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute left-[7%] top-[22%] text-[#2E7E95]/[0.055]"
        >
          <HeartPulse className="h-16 w-16 stroke-[1.35]" />
        </motion.div>

        <motion.div
          animate={
            reduceMotion
              ? undefined
              : {
                  y: [0, 12, 0],
                  rotate: [8, 2, 8],
                }
          }
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
          className="absolute right-[10%] top-[18%] text-[#2E7E95]/[0.06]"
        >
          <Stethoscope className="h-20 w-20 stroke-[1.35]" />
        </motion.div>

        <motion.div
          animate={
            reduceMotion
              ? undefined
              : {
                  y: [0, -10, 0],
                  rotate: [-6, 4, -6],
                }
          }
          transition={{ duration: 7.5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-[16%] right-[18%] text-[#2E7E95]/[0.055]"
        >
          <ShieldCheck className="h-16 w-16 stroke-[1.35]" />
        </motion.div>
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-12 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:px-8 lg:py-20">
        <motion.div
          variants={containerVariants}
          initial={reduceMotion ? false : "hidden"}
          animate={reduceMotion ? undefined : "visible"}
        >
          <motion.span
            variants={textVariants}
            className="inline-flex items-center gap-2 border border-[#7FBAC6]/70 bg-white/75 px-4 py-2 text-sm font-bold text-[#2E7E95] shadow-[0_16px_45px_rgba(27,58,68,0.06)] backdrop-blur"
          >
            <Stethoscope className="h-4 w-4" />
            {profile.designation}
          </motion.span>

          <motion.h1
            variants={textVariants}
            className="mt-7 max-w-3xl text-5xl font-extrabold leading-[1.04] tracking-[-0.055em] sm:text-6xl lg:text-7xl"
          >
            <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
              {cms.heroTitle || profile.doctorName}
            </span>
          </motion.h1>

          <motion.p
            variants={textVariants}
            className="mt-4 text-lg font-extrabold tracking-[-0.02em] sm:text-xl"
          >
            <span className="bg-gradient-to-r from-[#2E7E95] via-[#7FBAC6] to-[#1B3A44] bg-clip-text text-transparent">
              {profile.qualification}
            </span>
          </motion.p>

          <motion.p
            variants={textVariants}
            className="mt-6 max-w-2xl text-base leading-8 text-[#1B3A44]/72 sm:text-lg"
          >
            {cms.heroSubtitle}
          </motion.p>

          <motion.div
            variants={textVariants}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <motion.a
              href="#appointment"
              whileHover={reduceMotion ? undefined : { y: -3 }}
              whileTap={reduceMotion ? undefined : { scale: 0.98 }}
              className="group relative inline-flex items-center justify-center gap-2 overflow-hidden bg-[#2E7E95] px-6 py-3 text-sm font-bold text-white shadow-[0_18px_45px_rgba(46,126,149,0.24)] transition hover:bg-[#1B3A44]"
            >
              <span className="absolute inset-0 translate-x-[-120%] bg-gradient-to-r from-transparent via-white/25 to-transparent transition duration-700 group-hover:translate-x-[120%]" />
              <CalendarCheck className="relative h-4 w-4" />
              <span className="relative">Book Appointment</span>
            </motion.a>

            <motion.a
              href="#about"
              whileHover={reduceMotion ? undefined : { y: -3 }}
              whileTap={reduceMotion ? undefined : { scale: 0.98 }}
              className="inline-flex items-center justify-center gap-2 border border-[#7FBAC6] bg-white/75 px-6 py-3 text-sm font-bold text-[#1B3A44] shadow-[0_18px_45px_rgba(27,58,68,0.06)] backdrop-blur transition hover:border-[#2E7E95] hover:bg-white"
            >
              View Profile
              <ArrowRight className="h-4 w-4" />
            </motion.a>
          </motion.div>

          <motion.div
            variants={textVariants}
            className="mt-9 grid gap-3 sm:grid-cols-3"
          >
            {trustItems.map((item, index) => (
              <motion.div
                key={item}
                initial={reduceMotion ? false : { opacity: 0, y: 18 }}
                animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
                transition={{
                  duration: 0.5,
                  delay: 0.55 + index * 0.08,
                  ease: "easeOut",
                }}
                whileHover={reduceMotion ? undefined : { y: -4 }}
                className="border border-white/80 bg-white/72 px-4 py-4 text-sm font-bold leading-6 shadow-[0_18px_50px_rgba(27,58,68,0.07)] backdrop-blur"
              >
                <CheckCircle2 className="mb-2 h-5 w-5 text-[#2E7E95]" />
                {item}
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          initial={reduceMotion ? false : { opacity: 0, scale: 0.96, x: 24 }}
          animate={reduceMotion ? undefined : { opacity: 1, scale: 1, x: 0 }}
          transition={{ duration: 0.75, delay: 0.18, ease: "easeOut" }}
          className="relative"
        >
          <div className="absolute -inset-5 bg-[#7FBAC6]/20 blur-3xl" />
          <div className="absolute -right-5 -top-5 h-28 w-28 border border-[#7FBAC6]/55" />
          <div className="absolute -bottom-5 -left-5 h-28 w-28 border border-[#2E7E95]/35" />

          <div className="relative border border-white bg-gradient-to-br from-white via-[#D7E0E4] to-[#7FBAC6] p-3 shadow-[0_30px_90px_rgba(27,58,68,0.14)]">
            <Image
              src={profile.profileImage || "/kawshersirhero.png"}
              alt={`${profile.doctorName} profile`}
              width={900}
              height={1100}
              priority
              className="aspect-[4/5] w-full object-cover object-center"
            />

            <div className="absolute bottom-7 left-7 border border-white/70 bg-white/88 px-5 py-4 shadow-[0_18px_45px_rgba(27,58,68,0.13)] backdrop-blur-md">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#d99b45]">
                Focus
              </p>
              <p className="mt-1 font-extrabold text-[#1B3A44]">
                Preventive Medicine
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
