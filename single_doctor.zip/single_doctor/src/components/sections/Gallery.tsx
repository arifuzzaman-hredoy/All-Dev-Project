"use client";

import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  Camera,
  HeartPulse,
  Images,
  LucideIcon,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";

import { galleryItems } from "../../data/site";
import { usePublicSite } from "../PublicSiteProvider";
import { SectionLabel } from "../shared/SectionLabel";

type GalleryItem = { title: string; type: string; body: string; image: string };

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[6%] top-[16%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[8%] top-[15%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[15%] bottom-[12%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[16%] bottom-[10%] h-16 w-16 rotate-[-8deg]",
  },
];

const fadeUpVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 26,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.62,
      ease: "easeOut",
    },
  },
};

function GalleryCard({ item }: { item: GalleryItem }) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.article
      whileHover={reduceMotion ? undefined : { y: -6 }}
      transition={{ duration: 0.28, ease: "easeOut" }}
      className="group relative h-56 w-72 shrink-0 overflow-hidden rounded-[14px] border border-white/80 bg-[#D7E0E4] shadow-[0_18px_55px_rgba(27,58,68,0.08)] sm:h-64 sm:w-96"
    >
      <div
        className="absolute inset-0 bg-cover bg-center transition duration-700 group-hover:scale-105"
        style={{ backgroundImage: `url(${item.image})` }}
      />

      <div className="absolute inset-0 bg-gradient-to-t from-[#1B3A44]/78 via-[#1B3A44]/20 to-transparent transition duration-500 group-hover:from-[#1B3A44]/84" />

      <div className="absolute left-5 top-5 flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.16em] text-white/82">
        <Camera className="h-4 w-4 text-[#7FBAC6]" />
        {item.type}
      </div>

      <div className="absolute inset-x-0 bottom-0 p-5 text-white">
        <h3 className="text-xl font-extrabold tracking-[-0.03em]">
          {item.title}
        </h3>

        <p className="mt-2 text-sm leading-6 text-white/78">{item.body}</p>
      </div>

      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#7FBAC6] to-transparent opacity-0 transition duration-300 group-hover:opacity-100" />
    </motion.article>
  );
}

export function Gallery() {
  const reduceMotion = useReducedMotion();
  const { gallery } = usePublicSite();
  const visibleGallery = gallery.length ? gallery : galleryItems;

  const firstRow = [...visibleGallery, ...visibleGallery];
  const secondRow = [
    ...visibleGallery.slice().reverse(),
    ...visibleGallery.slice().reverse(),
  ];

  return (
    <section
      id="gallery"
      className="relative isolate overflow-hidden bg-[#F5F7F8] py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.105)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.105)_1px,transparent_1px)] bg-[size:48px_48px]" />
        <div className="absolute left-[-10%] top-[-18%] h-[440px] w-[440px] bg-[#D7E0E4]/70 blur-3xl" />
        <div className="absolute bottom-[-22%] right-[-8%] h-[520px] w-[520px] bg-[#7FBAC6]/24 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_48%_12%,rgba(46,126,149,0.09),transparent_30%),linear-gradient(180deg,rgba(245,247,248,0.82),rgba(245,247,248,0.98))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.052] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -12 : 12, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={fadeUpVariants}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: false, amount: 0.35 }}
          className="max-w-3xl"
        >
          <SectionLabel>Gallery</SectionLabel>

          <div className="mt-3 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <h2 className="max-w-3xl text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl">
              <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
                Professional moments from care, education, and prevention.
              </span>
            </h2>

            <div className="flex items-center gap-2 text-sm font-extrabold text-[#2E7E95]">
              <Images className="h-5 w-5" />
              Doctor Portfolio
              <Sparkles className="h-4 w-4 text-[#d99b45]" />
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={reduceMotion ? false : { opacity: 0, y: 30 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.18 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="relative mt-14 grid gap-5 overflow-hidden"
      >
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#F5F7F8] to-transparent sm:w-40" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#F5F7F8] to-transparent sm:w-40" />

        <div className="gallery-marquee-row">
          <div className="gallery-marquee-track gallery-marquee-forward">
            {firstRow.map((item, index) => (
              <GalleryCard key={`${item.title}-forward-${index}`} item={item} />
            ))}
          </div>
        </div>

        <div className="gallery-marquee-row">
          <div className="gallery-marquee-track gallery-marquee-reverse">
            {secondRow.map((item, index) => (
              <GalleryCard key={`${item.title}-reverse-${index}`} item={item} />
            ))}
          </div>
        </div>
      </motion.div>

      <style jsx global>{`
        .gallery-marquee-row {
          width: 100%;
          overflow: hidden;
        }

        .gallery-marquee-track {
          display: flex;
          width: max-content;
          gap: 1.25rem;
          padding-inline: 1rem;
          will-change: transform;
        }

        .gallery-marquee-forward {
          animation: gallery-forward 44s linear infinite;
        }

        .gallery-marquee-reverse {
          animation: gallery-reverse 48s linear infinite;
        }

        .gallery-marquee-row:hover .gallery-marquee-track {
          animation-play-state: paused;
        }

        @keyframes gallery-forward {
          from {
            transform: translate3d(-50%, 0, 0);
          }
          to {
            transform: translate3d(0, 0, 0);
          }
        }

        @keyframes gallery-reverse {
          from {
            transform: translate3d(0, 0, 0);
          }
          to {
            transform: translate3d(-50%, 0, 0);
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .gallery-marquee-forward,
          .gallery-marquee-reverse {
            animation: none;
          }
        }
      `}</style>
    </section>
  );
}