"use client";

import { FormEvent, useState } from "react";
import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  CalendarCheck,
  Clock3,
  HeartPulse,
  Hospital,
  LucideIcon,
  MessageSquareText,
  Phone,
  ShieldCheck,
  Stethoscope,
  UserRound,
} from "lucide-react";

import { SectionLabel } from "../shared/SectionLabel";
import { usePublicSite } from "../PublicSiteProvider";

const appointmentFields = [
  {
    label: "Patient Name",
    name: "patientName",
    type: "text",
    icon: UserRound,
    placeholder: "Enter patient name",
  },
  {
    label: "Phone Number",
    name: "phone",
    type: "tel",
    icon: Phone,
    placeholder: "+8801XXXXXXXXX",
  },
  {
    label: "Age",
    name: "age",
    type: "number",
    icon: Activity,
    placeholder: "Patient age",
  },
  {
    label: "Preferred Date",
    name: "preferredDate",
    type: "date",
    icon: CalendarCheck,
    placeholder: "",
  },
] as const;

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[7%] top-[16%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[8%] top-[18%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[16%] bottom-[12%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[16%] bottom-[10%] h-16 w-16 rotate-[-8deg]",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.09,
      delayChildren: 0.1,
    },
  },
};

const fadeUpVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 26,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.62,
      ease: "easeOut",
    },
  },
};

export function Appointment() {
  const reduceMotion = useReducedMotion();
  const { profile, cms } = usePublicSite();
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  async function submitAppointment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(false);
    setError("");
    const form = event.currentTarget;
    const formData = new FormData(form);

    const response = await fetch("/api/public/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(formData.entries())),
    });

    const result = (await response.json()) as { ok?: boolean; error?: string };
    if (!response.ok || !result.ok) {
      setError(result.error || "Appointment submit failed.");
      return;
    }

    setSubmitted(true);
    form.reset();

    window.setTimeout(() => {
      setSubmitted(false);
    }, 5000);
  }

  return (
    <section
      id="appointment"
      className="relative isolate overflow-hidden bg-[#F5F7F8] py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.105)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.105)_1px,transparent_1px)] bg-[size:48px_48px]" />
        <div className="absolute left-[-12%] top-[-16%] h-[480px] w-[480px] bg-[#D7E0E4]/75 blur-3xl" />
        <div className="absolute bottom-[-24%] right-[-10%] h-[560px] w-[560px] bg-[#7FBAC6]/24 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_35%_16%,rgba(46,126,149,0.09),transparent_30%),linear-gradient(180deg,rgba(245,247,248,0.8),rgba(245,247,248,0.98))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.052] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -12 : 12, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:px-8">
        <motion.div
          variants={containerVariants}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: false, amount: 0.3 }}
        >
          <motion.div variants={fadeUpVariants}>
            <SectionLabel>Appointment</SectionLabel>
          </motion.div>

          <motion.h2
            variants={fadeUpVariants}
            className="mt-3 max-w-xl text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl"
          >
            <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
              Take the first step toward better health.
            </span>
          </motion.h2>

          <motion.p
            variants={fadeUpVariants}
            className="mt-6 max-w-xl text-base leading-8 text-[#1B3A44]/70"
          >
            Share the basics and the chamber team can use the information for
            appointment communication.
          </motion.p>

          <motion.div
            variants={fadeUpVariants}
            whileHover={reduceMotion ? undefined : { y: -5 }}
            className="relative mt-8 overflow-hidden border border-[#2E7E95]/25 bg-[#1B3A44] p-6 text-white shadow-[0_28px_90px_rgba(27,58,68,0.18)]"
          >
            <div className="absolute -right-12 -top-12 h-32 w-32 bg-[#7FBAC6]/20 blur-2xl" />
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#7FBAC6] to-transparent" />

            <Hospital className="relative h-8 w-8 text-[#7FBAC6]" />

            <p className="relative mt-5 text-lg font-extrabold">
              {profile.chamberName}
            </p>

            <div className="relative mt-5 grid gap-4 sm:grid-cols-2">
              <div className="flex items-start gap-3">
                <Clock3 className="mt-1 h-5 w-5 shrink-0 text-[#7FBAC6]" />
                <p className="text-sm leading-7 text-white/72">
                  {cms.appointmentNote}
                </p>
              </div>

              <div className="flex items-start gap-3">
                <ShieldCheck className="mt-1 h-5 w-5 shrink-0 text-[#7FBAC6]" />
                <p className="text-sm leading-7 text-white/72">
                  For emergency conditions, contact the nearest hospital
                  immediately.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>

        <motion.form
          onSubmit={submitAppointment}
          initial={reduceMotion ? false : { opacity: 0, x: 34 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, x: 0 }}
          viewport={{ once: false, amount: 0.25 }}
          transition={{ duration: 0.72, ease: "easeOut" }}
          className="relative overflow-hidden border border-white/85 bg-white/78 p-5 shadow-[0_30px_95px_rgba(27,58,68,0.1)] backdrop-blur sm:p-6"
        >
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#2E7E95] to-transparent" />
          <div className="absolute -right-16 -top-16 h-40 w-40 bg-[#7FBAC6]/18 blur-3xl" />
          <div className="absolute -bottom-16 -left-16 h-40 w-40 bg-[#D7E0E4]/70 blur-3xl" />

          <div className="relative grid gap-4 sm:grid-cols-2">
            {appointmentFields.map(({ label, name, type, icon: Icon, placeholder }) => (
              <label key={name} className="grid gap-2 text-sm font-extrabold">
                <span className="flex items-center gap-2">
                  <Icon className="h-4 w-4 text-[#2E7E95]" />
                  {label}
                </span>

                <input
                  required
                  name={name}
                  type={type}
                  placeholder={placeholder}
                  className="border border-[#D7E0E4] bg-white px-4 py-3 text-sm font-semibold text-[#1B3A44] outline-none transition placeholder:text-[#1B3A44]/35 focus:border-[#2E7E95] focus:shadow-[0_0_0_3px_rgba(46,126,149,0.12)]"
                />
              </label>
            ))}

            <label className="grid gap-2 text-sm font-extrabold">
              <span className="flex items-center gap-2">
                <UserRound className="h-4 w-4 text-[#2E7E95]" />
                Gender
              </span>

              <select
                required
                name="gender"
                defaultValue=""
                className="border border-[#D7E0E4] bg-white px-4 py-3 text-sm font-semibold text-[#1B3A44] outline-none transition focus:border-[#2E7E95] focus:shadow-[0_0_0_3px_rgba(46,126,149,0.12)]"
              >
                <option value="" disabled>
                  Select gender
                </option>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="prefer-not-to-say">Prefer not to say</option>
              </select>
            </label>

            <label className="grid gap-2 text-sm font-extrabold">
              <span className="flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-[#2E7E95]" />
                Consultation Type
              </span>

              <select
                required
                name="consultationType"
                defaultValue="general"
                className="border border-[#D7E0E4] bg-white px-4 py-3 text-sm font-semibold text-[#1B3A44] outline-none transition focus:border-[#2E7E95] focus:shadow-[0_0_0_3px_rgba(46,126,149,0.12)]"
              >
                <option value="general">General consultation</option>
                <option value="lifestyle">Lifestyle consultation</option>
                <option value="hypertension">Hypertension follow-up</option>
                <option value="diabetes">Diabetes follow-up</option>
              </select>
            </label>

            <label className="grid gap-2 text-sm font-extrabold sm:col-span-2">
              <span className="flex items-center gap-2">
                <MessageSquareText className="h-4 w-4 text-[#2E7E95]" />
                Message / Problem Summary
              </span>

              <textarea
                name="message"
                rows={5}
                placeholder="Write short problem summary"
                className="resize-none border border-[#D7E0E4] bg-white px-4 py-3 text-sm font-semibold text-[#1B3A44] outline-none transition placeholder:text-[#1B3A44]/35 focus:border-[#2E7E95] focus:shadow-[0_0_0_3px_rgba(46,126,149,0.12)]"
              />
            </label>
          </div>

          <motion.button
            type="submit"
            whileHover={reduceMotion ? undefined : { y: -3 }}
            whileTap={reduceMotion ? undefined : { scale: 0.98 }}
            className="group relative mt-6 inline-flex w-full items-center justify-center gap-2 overflow-hidden bg-[#2E7E95] px-6 py-3 text-sm font-extrabold text-white shadow-[0_18px_45px_rgba(46,126,149,0.24)] transition hover:bg-[#1B3A44] sm:w-auto"
          >
            <span className="absolute inset-0 translate-x-[-120%] bg-gradient-to-r from-transparent via-white/25 to-transparent transition duration-700 group-hover:translate-x-[120%]" />
            <span className="relative">Submit Appointment Request</span>
            <CalendarCheck className="relative h-4 w-4" />
          </motion.button>

          <p className="relative mt-4 text-sm leading-6 text-[#1B3A44]/65">
            Your information will only be used for appointment communication.
          </p>

          {error && (
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative mt-4 border border-red-200 bg-red-50 px-4 py-3 text-sm font-extrabold text-red-700"
            >
              {error}
            </motion.p>
          )}

          {submitted && (
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative mt-4 border border-[#7FBAC6]/70 bg-[#D7E0E4]/70 px-4 py-3 text-sm font-extrabold text-[#1B3A44]"
            >
              Appointment request saved. Chamber team will review it from the doctor panel.
            </motion.p>
          )}
        </motion.form>
      </div>
    </section>
  );
}