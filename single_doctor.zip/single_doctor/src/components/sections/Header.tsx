"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  HeartPulse,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  X,
} from "lucide-react";
import { navItems } from "../../data/site";
import { usePublicSite } from "../PublicSiteProvider";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { profile, cms } = usePublicSite();

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="bg-[#1B3A44] text-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-5 gap-y-2 px-4 py-2 text-xs sm:justify-between">
          <span className="flex items-center gap-2">
            <Phone className="h-3.5 w-3.5" /> {profile.phone}
          </span>
          <span className="flex items-center gap-2">
            <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
          </span>
          <span className="hidden items-center gap-2 sm:flex">
            <Mail className="h-3.5 w-3.5" /> {profile.email}
          </span>
          <span className="flex items-center gap-2">
            <MapPin className="h-3.5 w-3.5" /> {cms.chamberAddress}
          </span>
          <a
            href="/account"
            className="rounded-full bg-white/15 px-3 py-1 font-semibold text-white ring-1 ring-white/20 transition hover:bg-white hover:text-[#1B3A44]"
          >
            Patient Account
          </a>
          <a
            href="#appointment"
            className="rounded-full bg-white px-3 py-1 font-semibold text-[#1B3A44] transition hover:bg-[#D7E0E4]"
          >
            Book Appointment
          </a>
        </div>
      </div>

      <nav className="border-b border-white/50 bg-white/76 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
          <a href="#home" className="flex items-center gap-3">
            <HeartPulse className="h-8 w-8 text-[#2E7E95]" strokeWidth={1.7} />
            <span>
              <span className="block text-base font-extrabold leading-tight">
                {profile.doctorName}
              </span>
              <span className="block text-xs font-semibold text-[#2E7E95]">
                {profile.designation}
              </span>
            </span>
          </a>

          <div className="hidden items-center gap-7 lg:flex">
            {navItems.map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className={`nav-underline text-sm font-semibold text-[#1B3A44]/78 transition hover:text-[#1B3A44] ${
                  item === "Home" ? "is-active" : ""
                }`}
              >
                {item}
              </a>
            ))}
          </div>

          <button
            type="button"
            aria-label="Toggle navigation"
            onClick={() => setIsMenuOpen((value) => !value)}
            className="group grid h-10 w-10 place-items-center rounded-full border border-[#D7E0E4] bg-white text-[#1B3A44] transition hover:border-[#7FBAC6] lg:hidden"
          >
            <AnimatePresence mode="wait" initial={false}>
              {isMenuOpen ? (
                <motion.span
                  key="close"
                  initial={{ rotate: -45, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 45, opacity: 0 }}
                >
                  <X className="h-5 w-5" />
                </motion.span>
              ) : (
                <motion.span
                  key="menu"
                  initial={{ rotate: 45, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -45, opacity: 0 }}
                >
                  <Menu className="h-5 w-5" />
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="border-t border-[#D7E0E4] bg-white px-4 py-5 lg:hidden"
            >
              <div className="mx-auto grid max-w-7xl gap-4">
                {navItems.map((item) => (
                  <a
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    onClick={() => setIsMenuOpen(false)}
                    className="nav-underline w-fit text-sm font-semibold"
                  >
                    {item}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}
