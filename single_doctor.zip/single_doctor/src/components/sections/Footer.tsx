"use client";

import Link from "next/link";
import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  ArrowUpRight,
  HeartPulse,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Stethoscope,
  LucideIcon,
} from "lucide-react";

import { navItems, serviceItems } from "../../data/site";
import { usePublicSite } from "../PublicSiteProvider";

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[5%] top-[18%] h-16 w-16 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[7%] top-[16%] h-20 w-20 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[42%] bottom-[14%] h-14 w-14 rotate-[8deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[18%] bottom-[12%] h-16 w-16 rotate-[-8deg]",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.08,
    },
  },
};

const fadeUpVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 22,
    filter: "blur(8px)",
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: {
      duration: 0.58,
      ease: "easeOut",
    },
  },
};

function getSectionHref(item: string) {
  return `/#${item.toLowerCase().trim().replace(/\s+/g, "-")}`;
}

export function Footer() {
  const reduceMotion = useReducedMotion();
  const { profile, cms } = usePublicSite();

  return (
    <footer className="relative isolate overflow-hidden bg-[#123039] px-4 py-14 text-white sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.075)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.075)_1px,transparent_1px)] bg-[size:46px_46px]" />
        <div className="absolute left-[-12%] top-[-30%] h-[420px] w-[420px] bg-[#2E7E95]/24 blur-3xl" />
        <div className="absolute bottom-[-34%] right-[-10%] h-[520px] w-[520px] bg-[#7FBAC6]/14 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(127,186,198,0.12),transparent_32%),linear-gradient(180deg,rgba(18,48,57,0.94),rgba(18,48,57,1))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#7FBAC6]/[0.065] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -10 : 10, 0],
                    rotate: [0, index % 2 === 0 ? 5 : -5, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.35]" />
          </motion.div>
        ))}
      </div>

      <motion.div
        variants={containerVariants}
        initial={reduceMotion ? false : "hidden"}
        whileInView={reduceMotion ? undefined : "visible"}
        viewport={{ once: false, amount: 0.18 }}
        className="relative mx-auto grid max-w-7xl gap-10 md:grid-cols-[1.25fr_0.75fr_0.9fr_0.9fr]"
      >
        <motion.div variants={fadeUpVariants}>
          <Link
            href="/#home"
            className="group inline-flex items-center gap-2 text-2xl font-extrabold tracking-[-0.03em]"
          >
            <HeartPulse className="h-6 w-6 text-[#7FBAC6] transition duration-300 group-hover:rotate-6" />
            {profile.doctorName}
          </Link>

          <p className="mt-4 max-w-sm text-sm leading-7 text-white/68">
            {cms.heroSubtitle}
          </p>

          <p className="font-bangla mt-4 max-w-sm text-sm leading-7 text-white/62">
            {profile.doctorName} | {profile.designation}
          </p>

          <div className="mt-6 flex flex-wrap gap-3 text-xs font-extrabold uppercase tracking-[0.14em] text-[#7FBAC6]">
            <span>MBBS</span>
            <span>MPH</span>
            <span>CCH</span>
            <span>CCD</span>
            <span>CMU</span>
          </div>
        </motion.div>

        <motion.div variants={fadeUpVariants}>
          <p className="font-extrabold text-white">Quick Links</p>

          <div className="mt-5 grid gap-3 text-sm text-white/68">
            {navItems.map((item) => (
              <Link
                key={item}
                href={getSectionHref(item)}
                className="group inline-flex w-fit items-center gap-2 transition hover:text-white"
              >
                <span className="h-px w-0 bg-[#7FBAC6] transition-all duration-300 group-hover:w-5" />
                {item}
              </Link>
            ))}
          </div>
        </motion.div>

        <motion.div variants={fadeUpVariants}>
          <p className="font-extrabold text-white">Services</p>

          <div className="mt-5 grid gap-3 text-sm text-white/68">
            {serviceItems.slice(0, 5).map((item) => (
              <Link
                key={item.title}
                href="/#services"
                className="group inline-flex w-fit items-center gap-2 transition hover:text-white"
              >
                <span className="h-px w-0 bg-[#7FBAC6] transition-all duration-300 group-hover:w-5" />
                {item.title}
              </Link>
            ))}
          </div>
        </motion.div>

        <motion.div variants={fadeUpVariants}>
          <p className="font-extrabold text-white">Contact</p>

          <div className="mt-5 grid gap-4 text-sm text-white/68">
            <a
              href="tel:+8801XXXXXXXXX"
              className="group flex gap-3 transition hover:text-white"
            >
              <Phone className="h-4 w-4 shrink-0 text-[#7FBAC6] transition duration-300 group-hover:rotate-6" />
              {profile.phone}
            </a>

            <a
              href={`https://wa.me/${profile.phone.replace(/\D/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="group flex gap-3 transition hover:text-white"
            >
              <MessageCircle className="h-4 w-4 shrink-0 text-[#7FBAC6] transition duration-300 group-hover:rotate-6" />
              WhatsApp
            </a>

            <a
              href={`mailto:${profile.email}`}
              className="group flex gap-3 transition hover:text-white"
            >
              <Mail className="h-4 w-4 shrink-0 text-[#7FBAC6] transition duration-300 group-hover:rotate-6" />
              {profile.email}
            </a>

            <span className="flex gap-3">
              <MapPin className="h-4 w-4 shrink-0 text-[#7FBAC6]" />
              {cms.chamberAddress}
            </span>
          </div>
        </motion.div>
      </motion.div>

      <motion.div
        initial={reduceMotion ? false : { opacity: 0, y: 18 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.4 }}
        transition={{ duration: 0.58, ease: "easeOut" }}
        className="relative mx-auto mt-12 flex max-w-7xl flex-col justify-between gap-4 border-t border-white/10 pt-6 text-sm text-white/56 md:flex-row"
      >
        <p>Copyright © 2026 {profile.doctorName}. All rights reserved.</p>

        <a
          href="https://techteamlead.com"
          target="_blank"
          rel="noreferrer"
          className="group inline-flex w-fit items-center gap-2 font-bold text-white/68 transition hover:text-[#7FBAC6]"
        >
          Developed by TechTeam
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </a>
      </motion.div>
    </footer>
  );
}