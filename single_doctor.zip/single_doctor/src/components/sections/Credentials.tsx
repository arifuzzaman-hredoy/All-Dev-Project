"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  Activity,
  GraduationCap,
  HeartPulse,
  Hospital,
  LucideIcon,
  Microscope,
  ScanSearch,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";

import { timelineItems } from "../../data/site";
import { SectionLabel } from "../shared/SectionLabel";

const timelineIcons: LucideIcon[] = [
  GraduationCap,
  Microscope,
  HeartPulse,
  Activity,
  ScanSearch,
  Hospital,
];

const backgroundIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[8%] top-[18%] h-16 w-16 rotate-[-12deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[10%] top-[14%] h-20 w-20 rotate-[14deg]",
  },
  {
    Icon: Activity,
    className: "left-[14%] bottom-[18%] h-14 w-14 rotate-[10deg]",
  },
  {
    Icon: ShieldCheck,
    className: "right-[16%] bottom-[12%] h-16 w-16 rotate-[-10deg]",
  },
];

export function Credentials() {
  const reduceMotion = useReducedMotion();

  return (
    <section
      id="expertise"
      className="relative overflow-hidden bg-white py-24 text-[#1B3A44]"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.09)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.09)_1px,transparent_1px)] bg-[size:44px_44px]" />
        <div className="absolute left-[-10%] top-[-20%] h-[420px] w-[420px] rounded-full bg-[#7FBAC6]/20 blur-3xl" />
        <div className="absolute bottom-[-18%] right-[-8%] h-[460px] w-[460px] rounded-full bg-[#2E7E95]/12 blur-3xl" />

        {backgroundIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#2E7E95]/[0.055] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, -10, 0],
                    rotate: [0, index % 2 === 0 ? 4 : -4, 0],
                  }
            }
            transition={{
              duration: 7 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.4]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto grid max-w-7xl gap-14 px-4 sm:px-6 lg:grid-cols-[0.82fr_1.18fr] lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 28 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.35 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="lg:sticky lg:top-32 lg:self-start"
        >
          <SectionLabel>Credentials</SectionLabel>

          <h2 className="mt-3 max-w-xl text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl lg:text-5xl">
            Qualifications and clinical experience.
          </h2>

          <p className="mt-6 max-w-xl text-base leading-8 text-[#1B3A44]/70">
            A focused professional path across medicine, public health, chronic
            disease care, endocrine care, and ultrasonography support.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            {["Clinical Focus", "Public Health", "Preventive Care"].map(
              (item) => (
                <motion.span
                  key={item}
                  whileHover={
                    reduceMotion
                      ? undefined
                      : {
                          y: -3,
                          borderColor: "rgba(46,126,149,0.45)",
                        }
                  }
                  className="rounded-xl border border-[#D7E0E4] bg-white/80 px-4 py-2 text-sm font-bold text-[#1B3A44]/75 shadow-[0_14px_40px_rgba(27,58,68,0.06)] backdrop-blur"
                >
                  {item}
                </motion.span>
              ),
            )}
          </div>
        </motion.div>

        <div className="relative">
          <div className="absolute bottom-4 left-4 top-4 w-px overflow-hidden bg-[#D7E0E4]">
            <motion.div
              className="absolute left-0 top-0 h-32 w-px bg-gradient-to-b from-transparent via-[#2E7E95] to-transparent"
              animate={
                reduceMotion
                  ? undefined
                  : {
                      y: ["-30%", "650%"],
                    }
              }
              transition={{
                duration: 4.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </div>

          <div className="grid gap-6">
            {timelineItems.map((item, index) => {
              const Icon = timelineIcons[index] ?? ShieldCheck;

              return (
                <motion.div
                  key={item.title}
                  initial={reduceMotion ? false : { opacity: 0, x: 34 }}
                  whileInView={reduceMotion ? undefined : { opacity: 1, x: 0 }}
                  viewport={{ once: false, amount: 0.55 }}
                  transition={{
                    duration: 0.58,
                    delay: reduceMotion ? 0 : index * 0.055,
                    ease: "easeOut",
                  }}
                  className="group relative pl-12"
                >
                  <motion.span
                    initial={reduceMotion ? false : { scale: 0.72 }}
                    whileInView={reduceMotion ? undefined : { scale: 1 }}
                    viewport={{ once: false, amount: 0.7 }}
                    transition={{
                      duration: 0.45,
                      delay: reduceMotion ? 0 : index * 0.06,
                      ease: "easeOut",
                    }}
                    className="absolute left-[0.42rem] top-6 z-10 flex h-5 w-5 items-center justify-center rounded-full border-[5px] border-white bg-[#2E7E95] shadow-[0_0_0_7px_rgba(127,186,198,0.16)]"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  </motion.span>

                  <motion.div
                    whileHover={
                      reduceMotion
                        ? undefined
                        : {
                            y: -5,
                            boxShadow: "0 28px 80px rgba(27,58,68,0.12)",
                          }
                    }
                    whileInView={
                      reduceMotion
                        ? undefined
                        : {
                            boxShadow: [
                              "0 16px 45px rgba(27,58,68,0.06)",
                              "0 22px 75px rgba(46,126,149,0.18)",
                              "0 16px 45px rgba(27,58,68,0.06)",
                            ],
                          }
                    }
                    viewport={{ once: false, amount: 0.68 }}
                    transition={{ duration: 0.7, ease: "easeOut" }}
                    className="relative overflow-hidden rounded-2xl border border-[#D7E0E4]/80 bg-[#F5F7F8] p-5 transition-colors duration-300 group-hover:border-[#7FBAC6]"
                  >
                    <div className="absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-[#7FBAC6] via-[#2E7E95] to-[#1B3A44] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                    <div className="absolute right-[-48px] top-[-48px] h-28 w-28 rounded-full bg-[#7FBAC6]/20 blur-2xl transition-opacity duration-300 group-hover:opacity-100" />

                    <div className="relative flex items-start gap-4">
                      <motion.div
                        whileHover={
                          reduceMotion
                            ? undefined
                            : {
                                rotate: 8,
                                scale: 1.08,
                              }
                        }
                        transition={{ duration: 0.25, ease: "easeOut" }}
                        className="mt-1 text-[#2E7E95]"
                      >
                        <Icon className="h-7 w-7 stroke-[1.7]" />
                      </motion.div>

                      <div>
                        <p className="text-lg font-extrabold tracking-[-0.02em]">
                          {item.title}
                        </p>
                        <p className="mt-1 text-sm font-semibold leading-6 text-[#1B3A44]/62">
                          {item.body}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}