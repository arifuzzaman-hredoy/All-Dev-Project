"use client";

import { FormEvent, useState } from "react";
import { motion, useReducedMotion, Variants } from "framer-motion";
import {
  Activity,
  ArrowRight,
  CalendarCheck,
  Clock,
  HeartPulse,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Stethoscope,
  LucideIcon,
} from "lucide-react";

import { contactItems } from "../../data/site";
import { SectionLabel } from "../shared/SectionLabel";
import { usePublicSite } from "../PublicSiteProvider";

const contactIcons = {
  Clock,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
};

type ContactIconName = keyof typeof contactIcons;

const floatingIcons: Array<{
  Icon: LucideIcon;
  className: string;
}> = [
  {
    Icon: HeartPulse,
    className: "left-[5%] top-[18%] h-14 w-14 rotate-[-10deg]",
  },
  {
    Icon: Stethoscope,
    className: "right-[7%] top-[16%] h-16 w-16 rotate-[10deg]",
  },
  {
    Icon: Activity,
    className: "left-[44%] bottom-[12%] h-12 w-12 rotate-[8deg]",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.055,
      delayChildren: 0.04,
    },
  },
};

const fadeUpVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 14,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.42,
      ease: "easeOut",
    },
  },
};

export function Contact() {
  const reduceMotion = useReducedMotion();
  const { profile, cms } = usePublicSite();
  const [messageStatus, setMessageStatus] = useState("");
  const [messageError, setMessageError] = useState("");

  async function submitMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessageStatus("");
    setMessageError("");
    const form = event.currentTarget;
    const response = await fetch("/api/public/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(new FormData(form).entries())),
    });
    const result = (await response.json()) as { ok?: boolean; error?: string };
    if (!response.ok || !result.ok) {
      setMessageError(result.error || "Message failed.");
      return;
    }
    form.reset();
    setMessageStatus("Message sent. Doctor panel এ দেখা যাবে।");
  }

  return (
    <section
      id="contact"
      className="relative isolate overflow-hidden bg-[#1B3A44] py-14 text-white sm:py-16"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.055)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.055)_1px,transparent_1px)] bg-[size:44px_44px]" />
        <div className="absolute left-[-10%] top-[-20%] h-80 w-80 bg-[#2E7E95]/18 blur-3xl" />
        <div className="absolute bottom-[-24%] right-[-10%] h-96 w-96 bg-[#7FBAC6]/10 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_36%_10%,rgba(127,186,198,0.12),transparent_28%),linear-gradient(180deg,rgba(27,58,68,0.96),rgba(27,58,68,1))]" />

        {floatingIcons.map(({ Icon, className }, index) => (
          <motion.div
            key={index}
            className={`absolute text-[#7FBAC6]/[0.055] ${className}`}
            animate={
              reduceMotion
                ? undefined
                : {
                    y: [0, index % 2 === 0 ? -6 : 6, 0],
                  }
            }
            transition={{
              duration: 6 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="h-full w-full stroke-[1.25]" />
          </motion.div>
        ))}
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-7 px-4 sm:px-6 lg:grid-cols-[1fr_0.58fr] lg:px-8">
        <motion.div
          variants={containerVariants}
          initial={reduceMotion ? false : "hidden"}
          whileInView={reduceMotion ? undefined : "visible"}
          viewport={{ once: true, amount: 0.28 }}
        >
          <motion.div variants={fadeUpVariants}>
            <SectionLabel>Contact</SectionLabel>
          </motion.div>

          <motion.h2
            variants={fadeUpVariants}
            className="mt-2 max-w-2xl text-2xl font-extrabold leading-tight tracking-[-0.035em] sm:text-3xl lg:text-4xl"
          >
            <span className="bg-gradient-to-r from-white via-[#D7E0E4] to-[#7FBAC6] bg-clip-text text-transparent">
              Visit, call, or message for appointment details.
            </span>
          </motion.h2>

          <motion.p
            variants={fadeUpVariants}
            className="mt-3 max-w-xl text-sm leading-7 text-white/68"
          >
            Confirm chamber time, appointment availability, and basic visit
            information before coming.
          </motion.p>

          <motion.div
            variants={fadeUpVariants}
            className="mt-6 grid gap-4 sm:grid-cols-2"
          >
            {contactItems.map((item) => {
              const Icon = contactIcons[item.icon as ContactIconName] ?? Phone;

              return (
                <motion.div
                  key={item.title}
                  whileHover={reduceMotion ? undefined : { y: -2 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  className="group border-t border-white/10 pt-4"
                >
                  <div className="flex gap-3">
                    <Icon className="mt-1 h-4 w-4 shrink-0 text-[#7FBAC6] transition-transform duration-200 group-hover:rotate-6" />

                    <div>
                      <p className="text-sm font-extrabold text-white">
                        {item.title}
                      </p>
                      <p className="mt-1 text-sm leading-6 text-white/64">
                        {item.body}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>

        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 18 }}
          whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.48, ease: "easeOut" }}
          className="relative w-full max-w-sm justify-self-start overflow-hidden rounded-[16px] border border-white/10 bg-white/[0.075] p-4 shadow-[0_22px_70px_rgba(0,0,0,0.16)] backdrop-blur lg:justify-self-end"
        >
          <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.055)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.055)_1px,transparent_1px)] bg-[size:30px_30px]" />
          <div className="absolute -right-16 -top-16 h-36 w-36 bg-[#7FBAC6]/14 blur-3xl" />
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#7FBAC6] to-transparent" />

          <div className="relative">
            <div className="inline-flex items-center gap-2 text-[#7FBAC6]">
              <MapPin className="h-6 w-6 stroke-[1.6]" />
              <span className="text-xs font-extrabold uppercase tracking-[0.16em]">
                Chamber
              </span>
            </div>

            <h3 className="mt-4 text-xl font-extrabold tracking-[-0.03em]">
              {profile.chamberName}
            </h3>

            <p className="mt-1 text-sm font-semibold leading-6 text-white/66">
              {cms.chamberAddress}
            </p>

            <div className="mt-5 grid gap-2.5">
              <div className="flex items-start gap-2.5 text-sm text-white/70">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-[#7FBAC6]" />
                <span>{profile.visitingHours}</span>
              </div>

              <div className="flex items-start gap-2.5 text-sm text-white/70">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#7FBAC6]" />
                <span>Emergency হলে nearest hospital এ যান।</span>
              </div>
            </div>

            <motion.a
              href="#appointment"
              whileHover={reduceMotion ? undefined : { y: -2 }}
              whileTap={reduceMotion ? undefined : { scale: 0.985 }}
              className="group relative mt-5 inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-[10px] bg-[#7FBAC6] px-4 py-2.5 text-sm font-extrabold text-[#1B3A44] transition hover:bg-white"
            >
              <span className="absolute inset-0 translate-x-[-120%] bg-gradient-to-r from-transparent via-white/40 to-transparent transition duration-500 group-hover:translate-x-[120%]" />
              <CalendarCheck className="relative h-4 w-4" />
              <span className="relative">Book Appointment</span>
              <ArrowRight className="relative h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </motion.a>

            <form onSubmit={submitMessage} className="mt-5 grid gap-2">
              <input name="name" required placeholder="Your name" className="rounded-[10px] border border-white/10 bg-white/10 px-3 py-2 text-sm outline-none placeholder:text-white/42 focus:border-[#7FBAC6]" />
              <input name="phone" placeholder="Phone" className="rounded-[10px] border border-white/10 bg-white/10 px-3 py-2 text-sm outline-none placeholder:text-white/42 focus:border-[#7FBAC6]" />
              <textarea name="message" required rows={3} placeholder="Message" className="resize-none rounded-[10px] border border-white/10 bg-white/10 px-3 py-2 text-sm outline-none placeholder:text-white/42 focus:border-[#7FBAC6]" />
              <button type="submit" className="rounded-[10px] bg-white px-3 py-2 text-sm font-extrabold text-[#1B3A44]">Send message</button>
              {messageStatus && <p className="text-xs font-bold text-[#9ff2da]">{messageStatus}</p>}
              {messageError && <p className="text-xs font-bold text-red-200">{messageError}</p>}
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}