"use client";

import { FormEvent, useState } from "react";
import { Eye, EyeOff, HeartPulse, Lock, Mail } from "lucide-react";

export function LoginPage({ mode }: { mode: "admin" | "role" }) {
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError("");
    const formData = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: formData.get("email"),
        password: formData.get("password"),
      }),
    });
    const result = (await response.json()) as { ok?: boolean; error?: string };
    setIsLoading(false);
    if (!response.ok || !result.ok) {
      setError(result.error || "Login failed.");
      return;
    }
    window.location.href = "/doctor/dashboard";
  }

  return (
    <main className="grid min-h-screen place-items-center bg-[#eef7f8] px-4 text-[#102a33]">
      <form onSubmit={submit} className="w-full max-w-md rounded-[28px] border border-white bg-white/90 p-7 shadow-[0_30px_100px_rgba(15,70,80,0.12)] backdrop-blur">
        <div className="mb-7 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e3fbf8] text-[#007c75]">
            <HeartPulse className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#007c75]">
              {mode === "admin" ? "Doctor Admin" : "Role Login"}
            </p>
            <h1 className="text-2xl font-black tracking-[-0.04em]">CareBridge Panel</h1>
          </div>
        </div>

        <label className="grid gap-2 text-sm font-bold">
          Email / Gmail
          <span className="flex items-center gap-2 rounded-2xl border border-[#dbe8ec] bg-white px-4 py-3 focus-within:border-[#007c75]">
            <Mail className="h-4 w-4 text-[#007c75]" />
            <input name="email" type="email" required placeholder="doctor@example.com" className="w-full bg-transparent outline-none" />
          </span>
        </label>

        <label className="mt-4 grid gap-2 text-sm font-bold">
          Password
          <span className="flex items-center gap-2 rounded-2xl border border-[#dbe8ec] bg-white px-4 py-3 focus-within:border-[#007c75]">
            <Lock className="h-4 w-4 text-[#007c75]" />
            <input name="password" type={showPassword ? "text" : "password"} required placeholder="Admin@12345" className="w-full bg-transparent outline-none" />
            <button type="button" onClick={() => setShowPassword((value) => !value)} className="text-[#007c75]" aria-label="Toggle password visibility">
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </span>
        </label>

        {error && <p className="mt-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-bold text-red-700">{error}</p>}

        <button type="submit" disabled={isLoading} className="mt-6 w-full rounded-2xl bg-[#102033] px-5 py-3 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60">
          {isLoading ? "Checking..." : "Login"}
        </button>

        <div className="mt-5 rounded-2xl bg-[#f4fafb] p-4 text-xs leading-6 text-[#516675]">
          Default first run: <b>doctor@example.com</b> / <b>Admin@12345</b>. Change this after first login.
        </div>
      </form>
    </main>
  );
}
