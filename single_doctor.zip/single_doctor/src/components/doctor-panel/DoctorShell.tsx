"use client";

import Link from "next/link";
import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import {
  Activity,
  Bell,
  BookOpen,
  CalendarDays,
  ChevronRight,
  ClipboardList,
  FileText,
  GalleryHorizontal,
  KeyRound,
  LayoutDashboard,
  LogOut,
  MessageCircle,
  PencilLine,
  Plus,
  RefreshCw,
  Settings,
  ShieldCheck,
  Stethoscope,
  UploadCloud,
  UserCog,
  UserRound,
  Users,
  Wallet,
} from "lucide-react";
import type {
  Appointment,
  AppointmentStatus,
  BlogPost,
  CmsContent,
  DoctorProfile,
  GalleryItem,
  PatientMessage,
  QaItem,
  Permission,
  Prescription,
  UploadedPrescription,
  SafePatient,
  SafeStaffUser,
  StaffRole,
} from "@/lib/clinic-types";
import { allPermissions, roleDefaultPermissions } from "@/lib/clinic-types";
import { PrescriptionTemplateRenderer, prescriptionTemplateOptions, type PrescriptionTemplateId } from "./PrescriptionTemplateRenderer";

type DashboardData = {
  stats?: {
    todayAppointments: number;
    waitingPatients: number;
    completedToday: number;
    followUpDue: number;
    patients: number;
    messages: number;
  };
  weekly?: { date: string; count: number }[];
  latestAppointments?: Appointment[];
  latestMessages?: PatientMessage[];
  dueFollowUps?: Prescription[];
  profile?: DoctorProfile;
  cms?: CmsContent;
};

type StoreState = {
  dashboard: DashboardData;
  appointments: Appointment[];
  patients: SafePatient[];
  staff: SafeStaffUser[];
  messages: PatientMessage[];
  prescriptions: Prescription[];
  uploadedPrescriptions: UploadedPrescription[];
  blogs: BlogPost[];
  gallery: GalleryItem[];
  qa: QaItem[];
  profile?: DoctorProfile;
  cms?: CmsContent;
};

type ApiResponse<T> = T & { ok?: boolean; error?: string };

const sidebarItems: Array<{
  section: string;
  label: string;
  icon: ReactNode;
  permission: Permission;
}> = [
  { section: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" />, permission: "dashboard:read" },
  { section: "appointments", label: "Appointments", icon: <CalendarDays className="h-4 w-4" />, permission: "appointments:read" },
  { section: "patients", label: "Patients", icon: <Users className="h-4 w-4" />, permission: "patients:read" },
  { section: "users", label: "Users", icon: <UserCog className="h-4 w-4" />, permission: "users:read" },
  { section: "patient-record", label: "Patient Record", icon: <ClipboardList className="h-4 w-4" />, permission: "patients:read" },
  { section: "prescription", label: "Prescription", icon: <FileText className="h-4 w-4" />, permission: "prescriptions:read" },
  { section: "upload-prescription", label: "Upload Prescription", icon: <UploadCloud className="h-4 w-4" />, permission: "prescriptions:write" },
  { section: "follow-up", label: "Follow Up", icon: <Bell className="h-4 w-4" />, permission: "prescriptions:read" },
  { section: "messages", label: "Messages", icon: <MessageCircle className="h-4 w-4" />, permission: "messages:read" },
  { section: "profile", label: "Profile", icon: <UserRound className="h-4 w-4" />, permission: "profile:write" },
  { section: "website-cms", label: "Website CMS", icon: <BookOpen className="h-4 w-4" />, permission: "cms:write" },
  { section: "blogs", label: "Blogs", icon: <PencilLine className="h-4 w-4" />, permission: "cms:write" },
  { section: "qa", label: "Q&A", icon: <MessageCircle className="h-4 w-4" />, permission: "cms:write" },
  { section: "gallery", label: "Gallery", icon: <GalleryHorizontal className="h-4 w-4" />, permission: "cms:write" },
  { section: "access-control", label: "Access Control", icon: <ShieldCheck className="h-4 w-4" />, permission: "roles:write" },
  { section: "accounts", label: "Accounts", icon: <Wallet className="h-4 w-4" />, permission: "accounts:read" },
  { section: "reports", label: "Reports", icon: <Activity className="h-4 w-4" />, permission: "reports:read" },
  { section: "settings", label: "Settings", icon: <Settings className="h-4 w-4" />, permission: "settings:write" },
];

const sectionTitles: Record<string, string> = {
  dashboard: "Continue patient care",
  appointments: "Appointment queue",
  patients: "Patients",
  users: "Users",
  "patient-record": "Patient records",
  prescription: "Prescription workspace",
  "upload-prescription": "Upload Prescription",
  "follow-up": "Follow-up due",
  messages: "Messages",
  profile: "Doctor profile",
  "website-cms": "Website CMS",
  blogs: "Blogs",
  qa: "Q&A",
  gallery: "Gallery",
  "access-control": "Access Control",
  accounts: "Accounts",
  reports: "Reports",
  settings: "Settings",
};

const blankState: StoreState = {
  dashboard: {},
  appointments: [],
  patients: [],
  staff: [],
  messages: [],
  prescriptions: [],
  uploadedPrescriptions: [],
  blogs: [],
  gallery: [],
  qa: [],
};

function statusClass(status: AppointmentStatus) {
  const map: Record<AppointmentStatus, string> = {
    pending: "bg-amber-50 text-amber-700",
    confirmed: "bg-blue-50 text-blue-700",
    in_progress: "bg-indigo-50 text-indigo-700",
    completed: "bg-emerald-50 text-emerald-700",
    cancelled: "bg-red-50 text-red-700",
  };
  return map[status];
}

function displayDate(date?: string) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(date));
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

async function api<T>(url: string, init?: RequestInit) {
  const response = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  const result = (await response.json()) as ApiResponse<T>;
  if (!response.ok || result.ok === false) throw new Error(result.error || "Request failed.");
  return result;
}

function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-[22px] border border-[#deebee] bg-white p-5 shadow-[0_16px_50px_rgba(15,50,60,0.05)] ${className}`}>{children}</div>;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="grid gap-2 text-sm font-black text-[#203847]">
      {label}
      {children}
    </label>
  );
}

function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`rounded-2xl border border-[#dce8ec] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#008d86] ${props.className || ""}`} />;
}

function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`rounded-2xl border border-[#dce8ec] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#008d86] ${props.className || ""}`} />;
}

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`rounded-2xl border border-[#dce8ec] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#008d86] ${props.className || ""}`} />;
}

function PrimaryButton({ children, className = "", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...props} className={`inline-flex items-center justify-center gap-2 rounded-2xl bg-[#101d31] px-4 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 ${className}`}>
      {children}
    </button>
  );
}

function SecondaryButton({ children, className = "", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...props} className={`inline-flex items-center justify-center gap-2 rounded-2xl border border-[#dce8ec] bg-white px-4 py-3 text-sm font-black text-[#203847] transition hover:bg-[#f3fbfb] disabled:cursor-not-allowed disabled:opacity-60 ${className}`}>
      {children}
    </button>
  );
}

export function DoctorShell({ initialSection, initialStaff }: { initialSection: string; initialStaff: SafeStaffUser }) {
  const [data, setData] = useState<StoreState>(blankState);
  const [staff] = useState(initialStaff);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const activeSection = initialSection || "dashboard";
  const visibleSidebarItems = useMemo(
    () => sidebarItems.filter((item) => staff.permissions.includes(item.permission)),
    [staff.permissions],
  );

  const has = (permission: Permission) => staff.permissions.includes(permission);

  async function load() {
    setIsLoading(true);
    setError("");
    try {
      const updates: Partial<StoreState> = {};
      const dashboard = await api<DashboardData>("/api/admin/dashboard");
      updates.dashboard = dashboard;
      updates.profile = dashboard.profile;
      updates.cms = dashboard.cms;

      if (["appointments", "dashboard", "accounts", "reports"].includes(activeSection)) {
        const appointments = await api<{ appointments: Appointment[]; patients: SafePatient[] }>("/api/admin/appointments");
        updates.appointments = appointments.appointments;
        updates.patients = appointments.patients;
      }
      if (["patients", "patient-record", "prescription", "upload-prescription", "accounts", "reports"].includes(activeSection)) {
        const patients = await api<{ patients: SafePatient[]; prescriptions: Prescription[]; appointments: Appointment[] }>("/api/admin/patients");
        updates.patients = patients.patients;
        updates.prescriptions = patients.prescriptions;
        updates.appointments = patients.appointments;
      }
      if (["users", "access-control"].includes(activeSection)) {
        const users = await api<{ staff: SafeStaffUser[]; patients: SafePatient[] }>("/api/admin/users");
        updates.staff = users.staff;
        updates.patients = users.patients;
      }
      if (["messages"].includes(activeSection)) {
        const messages = await api<{ messages: PatientMessage[] }>("/api/admin/messages");
        updates.messages = messages.messages;
      }
      if (["prescription", "upload-prescription", "follow-up"].includes(activeSection)) {
        const prescriptions = await api<{ prescriptions: Prescription[]; patients: SafePatient[]; profile: DoctorProfile }>("/api/admin/prescriptions");
        const uploads = await api<{ uploadedPrescriptions: UploadedPrescription[]; patients: SafePatient[] }>("/api/admin/upload-prescriptions");
        updates.prescriptions = prescriptions.prescriptions;
        updates.uploadedPrescriptions = uploads.uploadedPrescriptions;
        updates.patients = prescriptions.patients;
        updates.profile = prescriptions.profile;
      }
      if (["profile"].includes(activeSection)) {
        const profile = await api<{ profile: DoctorProfile }>("/api/admin/profile");
        updates.profile = profile.profile;
      }
      if (["website-cms", "blogs", "qa", "gallery"].includes(activeSection)) {
        const cms = await api<{ cms: CmsContent; profile: DoctorProfile }>("/api/admin/cms");
        const content = await api<{ blogs: BlogPost[]; gallery: GalleryItem[]; qa: QaItem[]; uploadedPrescriptions: UploadedPrescription[] }>("/api/admin/content");
        updates.cms = cms.cms;
        updates.profile = cms.profile;
        updates.blogs = content.blogs;
        updates.gallery = content.gallery;
        updates.qa = content.qa;
        updates.uploadedPrescriptions = content.uploadedPrescriptions;
      }
      setData((current) => ({ ...current, ...updates }));
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Failed to load data.");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    const firstRun = window.setTimeout(() => {
      void load();
    }, 0);
    const timer = window.setInterval(() => {
      if (["dashboard", "appointments", "messages"].includes(activeSection)) void load();
    }, 12000);
    return () => {
      window.clearTimeout(firstRun);
      window.clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeSection]);

  async function submitForm(event: FormEvent<HTMLFormElement>, url: string, method: "POST" | "PATCH" = "POST") {
    event.preventDefault();
    setError("");
    setMessage("");
    try {
      const form = event.currentTarget;
      const formData = new FormData(form);
      await api(url, {
        method,
        body: JSON.stringify(Object.fromEntries(formData.entries())),
      });
      form.reset();
      setMessage("Saved successfully.");
      await load();
    } catch (formError) {
      setError(formError instanceof Error ? formError.message : "Save failed.");
    }
  }

  async function submitJson(url: string, payload: Record<string, unknown>, method: "POST" | "PATCH" = "PATCH") {
    setError("");
    setMessage("");
    try {
      await api(url, { method, body: JSON.stringify(payload) });
      setMessage("Updated successfully.");
      await load();
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Update failed.");
    }
  }


  async function uploadFile(file: File) {
    const formData = new FormData();
    formData.append("file", file);
    const response = await fetch("/api/admin/uploads", { method: "POST", body: formData });
    const result = (await response.json()) as ApiResponse<{ fileUrl: string; fileName: string; mimeType: string; sizeBytes: number }>;
    if (!response.ok || result.ok === false) throw new Error(result.error || "Upload failed.");
    return result;
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/admin";
  }

  const profile = data.profile || data.dashboard.profile;
  const cms = data.cms || data.dashboard.cms;

  return (
    <main className="min-h-screen bg-[#f4f8fa] text-[#132c3a]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[270px] border-r border-[#e1eef1] bg-white/95 p-5 shadow-[12px_0_50px_rgba(30,80,90,0.06)] backdrop-blur lg:block">
        <div className="flex items-center gap-3 border-b border-[#e3eef1] pb-5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e5fbf8] text-[#008d86]"><Stethoscope className="h-6 w-6" /></div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#008d86]">Doctor Panel</p>
            <h2 className="text-lg font-black tracking-[-0.04em]">CareBridge</h2>
            <p className="text-xs font-bold text-[#7d8d99]">Clinical workspace</p>
          </div>
        </div>

        <nav className="mt-5 grid max-h-[calc(100vh-260px)] gap-1 overflow-y-auto pr-1">
          {visibleSidebarItems.map((item) => (
            <Link
              href={`/doctor/${item.section}`}
              key={item.section}
              className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-black transition ${activeSection === item.section ? "bg-[#e9fbf8] text-[#007c75]" : "text-[#607384] hover:bg-[#f2f8f9] hover:text-[#132c3a]"}`}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="absolute inset-x-5 bottom-5 grid gap-3">
          <Link href="/" target="_blank" className="flex items-center justify-between rounded-2xl border border-[#bfecea] bg-[#f2fffd] px-4 py-3 text-sm font-black text-[#007c75]">
            View Public Site <ChevronRight className="h-4 w-4" />
          </Link>
          <div className="rounded-2xl bg-[#eef9ff] p-4 text-xs leading-6 text-[#607384]">
            Logged in as <b>{staff.name}</b><br />{staff.role}
          </div>
        </div>
      </aside>

      <section className="lg:pl-[270px]">
        <header className="sticky top-0 z-20 border-b border-[#e1eef1] bg-white/90 px-4 py-4 backdrop-blur lg:px-8">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">
                Doctor <ChevronRight className="h-3 w-3" /> {sectionTitles[activeSection] || "Panel"}
              </p>
              <h1 className="mt-1 text-3xl font-black tracking-[-0.05em]">{sectionTitles[activeSection] || "Doctor Panel"}</h1>
            </div>
            <div className="flex items-center gap-2">
              <SecondaryButton onClick={load} disabled={isLoading}><RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} /> Refresh</SecondaryButton>
              {has("prescriptions:write") && <Link href="/doctor/prescription" className="rounded-2xl bg-[#101d31] px-4 py-3 text-sm font-black text-white">New prescription</Link>}
              <SecondaryButton onClick={logout}><LogOut className="h-4 w-4" /> Logout</SecondaryButton>
            </div>
          </div>
          {(message || error) && (
            <div className={`mt-4 rounded-2xl px-4 py-3 text-sm font-black ${error ? "border border-red-200 bg-red-50 text-red-700" : "border border-emerald-200 bg-emerald-50 text-emerald-700"}`}>
              {error || message}
            </div>
          )}
        </header>

        <div className="mx-auto max-w-[1480px] px-4 py-6 lg:px-8">
          {activeSection === "dashboard" && <DashboardView data={data} />}
          {activeSection === "appointments" && <AppointmentsView appointments={data.appointments} onSubmitForm={submitForm} onStatus={submitJson} canWrite={has("appointments:write")} />}
          {activeSection === "patients" && <PatientsView patients={data.patients} prescriptions={data.prescriptions} onSubmitForm={submitForm} canWrite={has("patients:write")} />}
          {activeSection === "users" && <UsersView staff={data.staff} patients={data.patients} onSubmitForm={submitForm} onSubmitJson={submitJson} showPassword={showPassword} setShowPassword={setShowPassword} canWrite={has("users:write")} />}
          {activeSection === "patient-record" && <PatientRecordView patients={data.patients} prescriptions={data.prescriptions} appointments={data.appointments} />}
          {activeSection === "prescription" && <PrescriptionView patients={data.patients} prescriptions={data.prescriptions} profile={profile} onSubmitForm={submitForm} canWrite={has("prescriptions:write")} />}
          {activeSection === "upload-prescription" && <UploadPrescriptionView patients={data.patients} uploads={data.uploadedPrescriptions} onSubmitJson={submitJson} uploadFile={uploadFile} />}
          {activeSection === "follow-up" && <FollowUpView prescriptions={data.prescriptions} />}
          {activeSection === "messages" && <MessagesView messages={data.messages} onSubmitJson={submitJson} canWrite={has("messages:write")} />}
          {activeSection === "profile" && <ProfileView profile={profile} onSubmitForm={submitForm} />}
          {activeSection === "website-cms" && <CmsView cms={cms} onSubmitForm={submitForm} />}
          {activeSection === "blogs" && <BlogCmsView blogs={data.blogs} onSubmitJson={submitJson} uploadFile={uploadFile} />}
          {activeSection === "qa" && <QaCmsView qa={data.qa} onSubmitJson={submitJson} />}
          {activeSection === "gallery" && <GalleryCmsView gallery={data.gallery} onSubmitJson={submitJson} uploadFile={uploadFile} />}
          {activeSection === "access-control" && <AccessControlView staff={data.staff} onSubmitJson={submitJson} />}
          {activeSection === "accounts" && <AccountsView appointments={data.appointments} prescriptions={data.prescriptions} />}
          {activeSection === "reports" && <ReportsView patients={data.patients} appointments={data.appointments} prescriptions={data.prescriptions} />}
          {activeSection === "settings" && <SettingsView />}
        </div>
      </section>
    </main>
  );
}

function DashboardView({ data }: { data: StoreState }) {
  const stats = data.dashboard.stats;
  const cards = [
    ["Today appointments", stats?.todayAppointments ?? 0, "Live queue"],
    ["Waiting patients", stats?.waitingPatients ?? 0, "New"],
    ["Completed visits", stats?.completedToday ?? 0, "Today"],
    ["Follow-up due", stats?.followUpDue ?? 0, "This week"],
  ];
  return (
    <div className="grid gap-5">
      <div className="grid gap-4 md:grid-cols-4">
        {cards.map(([label, value, hint]) => (
          <Card key={label as string}>
            <p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">{label}</p>
            <div className="mt-2 flex items-end gap-2"><span className="text-3xl font-black">{String(value).padStart(2, "0")}</span><span className="pb-1 text-sm font-bold text-[#7d8d99]">{hint}</span></div>
          </Card>
        ))}
      </div>
      <div className="grid gap-5 xl:grid-cols-[1fr_390px]">
        <Card>
          <div className="flex items-center justify-between"><p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">Analytics</p><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700">Realtime</span></div>
          <h2 className="mt-2 text-lg font-black">Weekly patient visits</h2>
          <div className="mt-6 flex h-48 items-end gap-4">
            {(data.dashboard.weekly || []).map((day) => (
              <div key={day.date} className="flex flex-1 flex-col items-center gap-2">
                <div className="w-full rounded-t-2xl bg-[#2b6df6]" style={{ height: `${Math.max(12, day.count * 26)}px` }} />
                <span className="text-xs font-bold text-[#7d8d99]">{new Date(day.date).toLocaleDateString("en", { weekday: "short" })}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">Clinical Desk</p>
          <h2 className="mt-2 text-lg font-black">Patient queue, reports and prescriptions</h2>
          <div className="mt-5 grid gap-3 text-sm font-bold text-[#607384]">
            <p>Avg. {Math.max(1, Math.round(((data.dashboard.weekly || []).reduce((sum, day) => sum + day.count, 0)) / 7))} patients/day</p>
            <p>Chamber: {data.profile?.visitingHours || data.dashboard.profile?.visitingHours || "Not set"}</p>
            <p>Unread messages: {stats?.messages ?? 0}</p>
          </div>
        </Card>
      </div>
      <Card>
        <div className="flex items-center justify-between"><h2 className="text-lg font-black">Today&apos;s appointments</h2><Link href="/doctor/appointments" className="text-sm font-black text-[#007c75]">View all</Link></div>
        <AppointmentTable appointments={data.dashboard.latestAppointments || []} />
      </Card>
    </div>
  );
}

function AppointmentTable({ appointments, onStatus, canWrite = false }: { appointments: Appointment[]; onStatus?: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; canWrite?: boolean }) {
  if (!appointments.length) return <EmptyState label="No appointments yet." />;
  return (
    <div className="mt-4 overflow-x-auto">
      <table className="w-full min-w-[760px] text-left text-sm">
        <thead className="text-xs uppercase tracking-[0.12em] text-[#7d8d99]"><tr><th className="p-3">Patient</th><th className="p-3">Phone</th><th className="p-3">Date</th><th className="p-3">Type</th><th className="p-3">Status</th><th className="p-3">Action</th></tr></thead>
        <tbody>
          {appointments.map((item) => (
            <tr key={item.id} className="border-t border-[#edf3f5]">
              <td className="p-3"><b>{item.patientName}</b><p className="text-xs text-[#7d8d99]">{item.message || "No summary"}</p></td>
              <td className="p-3 font-bold">{item.phone}</td>
              <td className="p-3 font-bold">{displayDate(item.preferredDate)}</td>
              <td className="p-3">{item.consultationType}</td>
              <td className="p-3"><span className={`rounded-full px-3 py-1 text-xs font-black ${statusClass(item.status)}`}>{item.status}</span></td>
              <td className="p-3">
                <div className="flex flex-wrap gap-2">
                  {canWrite && onStatus && ["confirmed", "in_progress", "completed"].map((status) => (
                    <button key={status} onClick={() => void onStatus("/api/admin/appointments", { id: item.id, status }, "PATCH")} className="rounded-xl border border-[#dce8ec] px-3 py-1 text-xs font-black hover:bg-[#f3fbfb]">{status}</button>
                  ))}
                  <Link href={`/doctor/prescription?patientId=${item.patientId || ""}&appointmentId=${item.id}`} className="rounded-xl bg-[#101d31] px-3 py-1 text-xs font-black text-white">Rx</Link>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AppointmentsView({ appointments, onSubmitForm, onStatus, canWrite }: { appointments: Appointment[]; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void>; onStatus: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; canWrite: boolean }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[390px_1fr]">
      {canWrite && (
        <Card>
          <h2 className="text-lg font-black">Add appointment</h2>
          <form className="mt-5 grid gap-4" onSubmit={(event) => onSubmitForm(event, "/api/admin/appointments")}> 
            <Field label="Patient name"><Input name="patientName" required /></Field>
            <Field label="Phone"><Input name="phone" required /></Field>
            <div className="grid grid-cols-2 gap-3"><Field label="Age"><Input name="age" /></Field><Field label="Date"><Input name="preferredDate" type="date" defaultValue={today()} required /></Field></div>
            <Field label="Type"><Select name="consultationType" defaultValue="general"><option value="general">General</option><option value="follow-up">Follow-up</option><option value="diabetes">Diabetes</option><option value="pressure">Pressure</option></Select></Field>
            <Field label="Summary"><TextArea name="message" rows={3} /></Field>
            <PrimaryButton><Plus className="h-4 w-4" /> Save appointment</PrimaryButton>
          </form>
        </Card>
      )}
      <Card className={canWrite ? "" : "xl:col-span-2"}>
        <div className="flex items-center justify-between"><h2 className="text-lg font-black">All appointments</h2><span className="text-sm font-bold text-[#7d8d99]">{appointments.length} total</span></div>
        <AppointmentTable appointments={appointments} onStatus={onStatus} canWrite={canWrite} />
      </Card>
    </div>
  );
}

function PatientsView({ patients, prescriptions, onSubmitForm, canWrite }: { patients: SafePatient[]; prescriptions: Prescription[]; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void>; canWrite: boolean }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[390px_1fr]">
      {canWrite && <Card>
        <h2 className="text-lg font-black">Create patient</h2>
        <form className="mt-5 grid gap-4" onSubmit={(event) => onSubmitForm(event, "/api/admin/patients")}> 
          <Field label="Name"><Input name="name" required /></Field>
          <Field label="Phone"><Input name="phone" required /></Field>
          <Field label="Email"><Input name="email" type="email" /></Field>
          <div className="grid grid-cols-2 gap-3"><Field label="Age"><Input name="age" /></Field><Field label="Gender"><Select name="gender"><option value="male">Male</option><option value="female">Female</option><option value="prefer-not-to-say">Prefer not</option></Select></Field></div>
          <Field label="Address"><Input name="address" /></Field>
          <Field label="Optional login password"><Input name="password" type="password" minLength={6} /></Field>
          <PrimaryButton><Plus className="h-4 w-4" /> Save patient</PrimaryButton>
        </form>
      </Card>}
      <Card className={canWrite ? "" : "xl:col-span-2"}>
        <h2 className="text-lg font-black">Patient list</h2>
        <PatientTable patients={patients} prescriptions={prescriptions} />
      </Card>
    </div>
  );
}

function PatientTable({ patients, prescriptions }: { patients: SafePatient[]; prescriptions: Prescription[] }) {
  if (!patients.length) return <EmptyState label="No patients yet. Public appointment form will create patient records automatically." />;
  return (
    <div className="mt-4 overflow-x-auto">
      <table className="w-full min-w-[760px] text-left text-sm"><thead className="text-xs uppercase tracking-[0.12em] text-[#7d8d99]"><tr><th className="p-3">Patient</th><th className="p-3">Code</th><th className="p-3">Phone</th><th className="p-3">Age/Gender</th><th className="p-3">Rx</th><th className="p-3">Action</th></tr></thead>
        <tbody>{patients.map((patient) => <tr key={patient.id} className="border-t border-[#edf3f5]"><td className="p-3"><b>{patient.name}</b><p className="text-xs text-[#7d8d99]">{patient.email || "No email"}</p></td><td className="p-3 font-bold">{patient.patientCode}</td><td className="p-3 font-bold">{patient.phone}</td><td className="p-3">{patient.age || "—"} / {patient.gender || "—"}</td><td className="p-3">{prescriptions.filter((rx) => rx.patientId === patient.id).length}</td><td className="p-3"><Link href={`/doctor/prescription?patientId=${patient.id}`} className="rounded-xl bg-[#101d31] px-3 py-2 text-xs font-black text-white">Open Rx</Link></td></tr>)}</tbody></table>
    </div>
  );
}

function UsersView({ staff, patients, onSubmitForm, onSubmitJson, showPassword, setShowPassword, canWrite }: { staff: SafeStaffUser[]; patients: SafePatient[]; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void>; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; showPassword: boolean; setShowPassword: (value: boolean) => void; canWrite: boolean }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[420px_1fr]">
      {canWrite && <Card>
        <h2 className="text-lg font-black">Create staff / role user</h2>
        <form className="mt-5 grid gap-4" onSubmit={(event) => onSubmitForm(event, "/api/admin/users")}> 
          <Field label="Name"><Input name="name" required /></Field>
          <Field label="Gmail / Email"><Input name="email" type="email" required /></Field>
          <Field label="Password"><div className="flex gap-2"><Input name="password" type={showPassword ? "text" : "password"} minLength={8} required className="flex-1" /><SecondaryButton type="button" onClick={() => setShowPassword(!showPassword)}><KeyRound className="h-4 w-4" /></SecondaryButton></div></Field>
          <Field label="Role"><Select name="role" defaultValue="ASSISTANT"><option value="ASSISTANT">Assistant</option><option value="RECEPTIONIST">Receptionist</option><option value="CMS_MANAGER">CMS Manager</option><option value="DOCTOR">Doctor</option><option value="SUPER_ADMIN">Super Admin</option></Select></Field>
          <PrimaryButton><Plus className="h-4 w-4" /> Create login</PrimaryButton>
        </form>
      </Card>}
      <div className="grid gap-5">
        <Card><h2 className="text-lg font-black">Staff users</h2><div className="mt-4 grid gap-3">{staff.map((item) => <div key={item.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><b>{item.name}</b><p className="text-sm text-[#607384]">{item.email} · {item.role}</p><p className="mt-1 text-xs font-bold text-[#7d8d99]">Password is stored as hash. Use reset password instead of showing original password.</p></div><div className="flex flex-wrap gap-2"><button onClick={() => onSubmitJson("/api/admin/users", { id: item.id, status: item.status === "active" ? "disabled" : "active" })} className="rounded-xl border px-3 py-2 text-xs font-black">{item.status === "active" ? "Disable" : "Enable"}</button><button onClick={() => onSubmitJson("/api/admin/users", { id: item.id, canLogin: !item.canLogin })} className="rounded-xl border px-3 py-2 text-xs font-black">{item.canLogin ? "Block login" : "Allow login"}</button></div></div></div>)}</div></Card>
        <Card><h2 className="text-lg font-black">Patient accounts</h2><PatientTable patients={patients} prescriptions={[]} /></Card>
      </div>
    </div>
  );
}

function PatientRecordView({ patients, prescriptions, appointments }: { patients: SafePatient[]; prescriptions: Prescription[]; appointments: Appointment[] }) {
  return <div className="grid gap-5">{patients.map((patient) => <Card key={patient.id}><div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"><div><h2 className="text-xl font-black">{patient.name}</h2><p className="text-sm font-bold text-[#607384]">{patient.patientCode} · {patient.phone}</p></div><Link href={`/doctor/prescription?patientId=${patient.id}`} className="rounded-2xl bg-[#101d31] px-4 py-3 text-sm font-black text-white">Write prescription</Link></div><div className="mt-4 grid gap-3 md:grid-cols-3"><p className="rounded-2xl bg-[#f4fafb] p-4 text-sm"><b>{appointments.filter((item) => item.patientId === patient.id).length}</b><br />Appointments</p><p className="rounded-2xl bg-[#f4fafb] p-4 text-sm"><b>{prescriptions.filter((item) => item.patientId === patient.id).length}</b><br />Prescriptions</p><p className="rounded-2xl bg-[#f4fafb] p-4 text-sm"><b>{patient.lastVisitAt ? displayDate(patient.lastVisitAt) : "—"}</b><br />Last visit</p></div></Card>)}</div>;
}

function PrescriptionView({ patients, prescriptions, profile, onSubmitForm, canWrite }: { patients: SafePatient[]; prescriptions: Prescription[]; profile?: DoctorProfile; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void>; canWrite: boolean }) {
  const [selectedPatientId, setSelectedPatientId] = useState(() => {
    if (typeof window === "undefined") return "";
    return new URLSearchParams(window.location.search).get("patientId") || "";
  });
  const [selectedTemplateId, setSelectedTemplateId] = useState<PrescriptionTemplateId>(profile?.defaultPrescriptionTemplateId || "yellow-classic");

  const selectedPatient = patients.find((patient) => patient.id === selectedPatientId) || patients[0];
  const selectedPrescription = selectedPatient ? prescriptions.find((item) => item.patientId === selectedPatient.id) || prescriptions[0] : prescriptions[0];


  return (
    <div className="grid gap-5 2xl:grid-cols-[480px_1fr]">
      {canWrite && <Card>
        <h2 className="text-lg font-black">Write prescription</h2>
        <form className="mt-5 grid gap-4" onSubmit={(event) => onSubmitForm(event, "/api/admin/prescriptions")}> 
          <Field label="Patient"><Select name="patientId" value={selectedPatientId || selectedPatient?.id || ""} onChange={(event) => { const nextPatientId = event.target.value; setSelectedPatientId(nextPatientId); const nextPrescription = prescriptions.find((item) => item.patientId === nextPatientId); setSelectedTemplateId(nextPrescription?.templateId || profile?.defaultPrescriptionTemplateId || "yellow-classic"); }} required>{patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.name} · {patient.phone}</option>)}</Select></Field>
          <Field label="Prescription template"><Select name="templateId" value={selectedTemplateId} onChange={(event) => setSelectedTemplateId(event.target.value as PrescriptionTemplateId)}>{prescriptionTemplateOptions.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</Select><p className="text-xs font-bold text-[#7d8d99]">Doctor চাইলে prescription লেখার সময় template select করতে পারবে। Saved prescription history-তেও template save হবে।</p></Field>
          <Field label="Diagnosis"><Input name="diagnosis" required /></Field>
          <Field label="Vitals"><Input name="vitals" placeholder="BP 120/80, Pulse 78" /></Field>
          <Field label="Medicines"><TextArea name="medicines" rows={5} required placeholder="1. Medicine name - dose - duration" /></Field>
          <Field label="Tests"><TextArea name="tests" rows={3} /></Field>
          <Field label="Advice"><TextArea name="advice" rows={3} /></Field>
          <Field label="Follow-up date"><Input name="followUpDate" type="date" /></Field>
          <PrimaryButton><FileText className="h-4 w-4" /> Save prescription</PrimaryButton>
        </form>
      </Card>}
      <div className="grid gap-5">
        <Card>
          <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div><h2 className="text-lg font-black">Selected template preview</h2><p className="text-sm font-bold text-[#607384]">{prescriptionTemplateOptions.find((item) => item.id === selectedTemplateId)?.hint}</p></div>
            <span className="rounded-full bg-[#eef9ff] px-3 py-1 text-xs font-black text-[#007c75]">{prescriptionTemplateOptions.find((item) => item.id === selectedTemplateId)?.label}</span>
          </div>
          <PrescriptionTemplateRenderer templateId={selectedTemplateId} profile={profile} patient={selectedPatient} prescription={selectedPrescription} />
        </Card>
        <Card><h2 className="text-lg font-black">Prescription history</h2><PrescriptionHistory prescriptions={prescriptions} /></Card>
      </div>
    </div>
  );
}

function PrescriptionHistory({ prescriptions }: { prescriptions: Prescription[] }) {
  if (!prescriptions.length) return <EmptyState label="No prescriptions yet." />;
  return <div className="mt-4 grid gap-3">{prescriptions.map((rx) => <div key={rx.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between"><div><b>{rx.patientName}</b><p className="text-sm text-[#607384]">{displayDate(rx.createdAt)} · {rx.printCode}</p></div><span className="rounded-full bg-[#eef9ff] px-3 py-1 text-xs font-black text-[#007c75]">Follow-up {rx.followUpDate ? displayDate(rx.followUpDate) : "not set"}</span></div><p className="mt-3 whitespace-pre-line text-sm leading-6 text-[#334b57]">{rx.medicines}</p></div>)}</div>;
}

function UploadPrescriptionView({ patients, uploads, onSubmitJson, uploadFile }: { patients: SafePatient[]; uploads: UploadedPrescription[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; uploadFile: (file: File) => Promise<{ fileUrl: string; fileName: string; mimeType: string; sizeBytes: number }> }) {
  const [isUploading, setIsUploading] = useState(false);

  async function handleUpload(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsUploading(true);
    try {
      const form = event.currentTarget;
      const formData = new FormData(form);
      const file = formData.get("file");
      if (!(file instanceof File) || file.size === 0) throw new Error("Prescription file is required.");
      const uploaded = await uploadFile(file);
      await onSubmitJson("/api/admin/upload-prescriptions", {
        patientId: String(formData.get("patientId") || ""),
        patientName: String(formData.get("patientName") || ""),
        phone: String(formData.get("phone") || ""),
        notes: String(formData.get("notes") || ""),
        ...uploaded,
      }, "POST");
      form.reset();
    } finally {
      setIsUploading(false);
    }
  }

  return (
    <div className="grid gap-5 xl:grid-cols-[440px_1fr]">
      <Card>
        <h2 className="text-lg font-black">Upload scanned prescription</h2>
        <p className="mt-2 text-sm leading-7 text-[#607384]">JPG, PNG, WEBP or PDF. Max 5MB. File saves to public/uploads/clinic and record saves in the real data store.</p>
        <form className="mt-5 grid gap-4" onSubmit={handleUpload}>
          <Field label="Existing patient"><Select name="patientId" defaultValue=""><option value="">Manual patient name</option>{patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.name} · {patient.phone}</option>)}</Select></Field>
          <Field label="Manual patient name"><Input name="patientName" placeholder="Needed if no patient selected" /></Field>
          <Field label="Phone"><Input name="phone" /></Field>
          <Field label="Prescription file"><Input name="file" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required /></Field>
          <Field label="Notes"><TextArea name="notes" rows={3} /></Field>
          <PrimaryButton disabled={isUploading}><UploadCloud className="h-4 w-4" /> {isUploading ? "Uploading..." : "Upload prescription"}</PrimaryButton>
        </form>
      </Card>
      <Card>
        <h2 className="text-lg font-black">Uploaded prescriptions</h2>
        {!uploads.length ? <EmptyState label="No uploaded prescriptions yet." /> : <div className="mt-4 grid gap-3">{uploads.map((item) => <div key={item.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><b>{item.patientName}</b><p className="text-sm text-[#607384]">{item.fileName} · {(item.sizeBytes / 1024).toFixed(1)} KB · {displayDate(item.createdAt)}</p>{item.notes && <p className="mt-2 text-sm leading-6 text-[#607384]">{item.notes}</p>}</div><a href={item.fileUrl} target="_blank" className="rounded-xl border px-3 py-2 text-xs font-black" rel="noreferrer">Open file</a></div></div>)}</div>}
      </Card>
    </div>
  );
}

function FollowUpView({ prescriptions }: { prescriptions: Prescription[] }) {
  const due = prescriptions.filter((rx) => rx.followUpDate && new Date(rx.followUpDate) >= new Date(new Date().toISOString().slice(0, 10))).sort((a, b) => String(a.followUpDate).localeCompare(String(b.followUpDate)));
  if (!due.length) return <Card><EmptyState label="No upcoming follow-ups." /></Card>;
  return <div className="grid gap-4">{due.map((rx) => <Card key={rx.id}><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><h2 className="text-lg font-black">{rx.patientName}</h2><p className="text-sm font-bold text-[#607384]">Due: {displayDate(rx.followUpDate)} · {rx.phone}</p></div><Link href={`/doctor/prescription?patientId=${rx.patientId}`} className="rounded-2xl bg-[#101d31] px-4 py-3 text-sm font-black text-white">Open Rx</Link></div></Card>)}</div>;
}

function MessagesView({ messages, onSubmitJson, canWrite }: { messages: PatientMessage[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; canWrite: boolean }) {
  if (!messages.length) return <Card><EmptyState label="No messages yet." /></Card>;
  return <div className="grid gap-4">{messages.map((msg) => <Card key={msg.id}><div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between"><div><h2 className="text-lg font-black">{msg.name}</h2><p className="text-sm font-bold text-[#607384]">{msg.phone || "No phone"} · {msg.email || "No email"}</p><p className="mt-3 leading-7">{msg.message}</p>{msg.reply && <p className="mt-3 rounded-2xl bg-[#f2fbfb] p-4 text-sm"><b>Reply:</b> {msg.reply}</p>}</div><span className="rounded-full bg-[#eef9ff] px-3 py-1 text-xs font-black text-[#007c75]">{msg.status}</span></div>{canWrite && <form className="mt-4 flex gap-2" onSubmit={(event) => { event.preventDefault(); const formData = new FormData(event.currentTarget); void onSubmitJson("/api/admin/messages", { id: msg.id, reply: formData.get("reply") }, "PATCH"); event.currentTarget.reset(); }}><Input name="reply" placeholder="Write reply" className="flex-1" /><PrimaryButton>Reply</PrimaryButton></form>}</Card>)}</div>;
}

function ProfileView({ profile, onSubmitForm }: { profile?: DoctorProfile; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void> }) {
  if (!profile) return <Card><EmptyState label="Profile loading..." /></Card>;
  return <Card><h2 className="text-lg font-black">Profile controls prescription header</h2><form className="mt-5 grid gap-4 md:grid-cols-2" onSubmit={(event) => onSubmitForm(event, "/api/admin/profile", "PATCH")}><Field label="Hospital name"><Input name="hospitalName" defaultValue={profile.hospitalName} /></Field><Field label="Hospital slogan"><Input name="hospitalSlogan" defaultValue={profile.hospitalSlogan} /></Field><Field label="Doctor name"><Input name="doctorName" defaultValue={profile.doctorName} /></Field><Field label="Qualification"><Input name="qualification" defaultValue={profile.qualification} /></Field><Field label="Designation"><Input name="designation" defaultValue={profile.designation} /></Field><Field label="Default prescription template"><Select name="defaultPrescriptionTemplateId" defaultValue={profile.defaultPrescriptionTemplateId || "yellow-classic"}>{prescriptionTemplateOptions.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</Select></Field><Field label="Chamber"><Input name="chamberName" defaultValue={profile.chamberName} /></Field><Field label="Visiting hours"><Input name="visitingHours" defaultValue={profile.visitingHours} /></Field><Field label="Phone"><Input name="phone" defaultValue={profile.phone} /></Field><Field label="Email"><Input name="email" defaultValue={profile.email} /></Field><Field label="Profile image URL"><Input name="profileImage" defaultValue={profile.profileImage} /></Field><Field label="Address line 1"><Input name="addressLine1" defaultValue={profile.addressLine1} /></Field><Field label="Address line 2"><Input name="addressLine2" defaultValue={profile.addressLine2} /></Field><Field label="Prescription footer"><Input name="prescriptionFooter" defaultValue={profile.prescriptionFooter} /></Field><div className="md:col-span-2"><PrimaryButton>Save profile</PrimaryButton></div></form></Card>;
}

function CmsView({ cms, onSubmitForm }: { cms?: CmsContent; onSubmitForm: (event: FormEvent<HTMLFormElement>, url: string, method?: "POST" | "PATCH") => Promise<void> }) {
  if (!cms) return <Card><EmptyState label="CMS loading..." /></Card>;
  return <Card><h2 className="text-lg font-black">Website CMS</h2><p className="mt-2 text-sm text-[#607384]">These fields control the live public site core content.</p><form className="mt-5 grid gap-4" onSubmit={(event) => onSubmitForm(event, "/api/admin/cms", "PATCH")}><Field label="Hero title"><Input name="heroTitle" defaultValue={cms.heroTitle} /></Field><Field label="Hero subtitle"><TextArea name="heroSubtitle" defaultValue={cms.heroSubtitle} rows={4} /></Field><Field label="Appointment note"><TextArea name="appointmentNote" defaultValue={cms.appointmentNote} rows={3} /></Field><Field label="About text"><TextArea name="aboutText" defaultValue={cms.aboutText} rows={4} /></Field><div className="grid gap-4 md:grid-cols-3"><Field label="Contact phone"><Input name="contactPhone" defaultValue={cms.contactPhone} /></Field><Field label="Contact email"><Input name="contactEmail" defaultValue={cms.contactEmail} /></Field><Field label="Chamber address"><Input name="chamberAddress" defaultValue={cms.chamberAddress} /></Field></div><PrimaryButton>Publish CMS</PrimaryButton></form></Card>;
}

function BlogCmsView({ blogs, onSubmitJson, uploadFile }: { blogs: BlogPost[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; uploadFile: (file: File) => Promise<{ fileUrl: string }> }) {
  const [isUploading, setIsUploading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsUploading(true);
    try {
      const form = event.currentTarget;
      const formData = new FormData(form);
      const file = formData.get("imageFile");
      let image = String(formData.get("image") || "");
      if (file instanceof File && file.size > 0) image = (await uploadFile(file)).fileUrl;
      await onSubmitJson("/api/admin/content", {
        collection: "blogs",
        title: String(formData.get("title") || ""),
        slug: String(formData.get("slug") || ""),
        category: String(formData.get("category") || ""),
        body: String(formData.get("body") || ""),
        content: String(formData.get("content") || ""),
        image,
        published: true,
      }, "POST");
      form.reset();
    } finally {
      setIsUploading(false);
    }
  }
  return <div className="grid gap-5 xl:grid-cols-[430px_1fr]"><Card><h2 className="text-lg font-black">Create blog</h2><form className="mt-5 grid gap-4" onSubmit={submit}><Field label="Title"><Input name="title" required /></Field><Field label="Slug"><Input name="slug" placeholder="auto if empty" /></Field><Field label="Category"><Input name="category" defaultValue="Health Advice" /></Field><Field label="Summary"><TextArea name="body" rows={3} required /></Field><Field label="Full content"><TextArea name="content" rows={6} placeholder="Paragraph gap diye alada koro" /></Field><Field label="Image URL"><Input name="image" placeholder="/uploads/clinic/image.webp" /></Field><Field label="Or upload image"><Input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp" /></Field><PrimaryButton disabled={isUploading}>{isUploading ? "Publishing..." : "Publish blog"}</PrimaryButton></form></Card><Card><h2 className="text-lg font-black">Blog list</h2><div className="mt-4 grid gap-3">{blogs.map((blog) => <div key={blog.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><b>{blog.title}</b><p className="text-sm text-[#607384]">/{blog.slug} · {blog.category}</p></div><div className="flex gap-2"><a href={`/blogs/${blog.slug}`} target="_blank" rel="noreferrer" className="rounded-xl border px-3 py-2 text-xs font-black">Open</a><button className="rounded-xl border px-3 py-2 text-xs font-black" onClick={() => onSubmitJson("/api/admin/content", { collection: "blogs", id: blog.id, published: !blog.published })}>{blog.published ? "Hide" : "Show"}</button></div></div></div>)}</div></Card></div>;
}

function QaCmsView({ qa, onSubmitJson }: { qa: QaItem[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void> }) {
  return <div className="grid gap-5 xl:grid-cols-[430px_1fr]"><Card><h2 className="text-lg font-black">Create Q&A</h2><form className="mt-5 grid gap-4" onSubmit={(event) => { event.preventDefault(); const formData = new FormData(event.currentTarget); void onSubmitJson("/api/admin/content", { collection: "qa", question: formData.get("question"), answer: formData.get("answer"), published: true }, "POST"); event.currentTarget.reset(); }}><Field label="Question"><Input name="question" required /></Field><Field label="Answer"><TextArea name="answer" rows={5} required /></Field><PrimaryButton>Publish Q&A</PrimaryButton></form></Card><Card><h2 className="text-lg font-black">Q&A list</h2><div className="mt-4 grid gap-3">{qa.map((item) => <div key={item.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between"><div><b>{item.question}</b><p className="mt-2 text-sm leading-6 text-[#607384]">{item.answer}</p></div><button className="rounded-xl border px-3 py-2 text-xs font-black" onClick={() => onSubmitJson("/api/admin/content", { collection: "qa", id: item.id, published: !item.published })}>{item.published ? "Hide" : "Show"}</button></div></div>)}</div></Card></div>;
}

function GalleryCmsView({ gallery, onSubmitJson, uploadFile }: { gallery: GalleryItem[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void>; uploadFile: (file: File) => Promise<{ fileUrl: string }> }) {
  const [isUploading, setIsUploading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsUploading(true);
    try {
      const form = event.currentTarget;
      const formData = new FormData(form);
      const file = formData.get("imageFile");
      let image = String(formData.get("image") || "");
      if (file instanceof File && file.size > 0) image = (await uploadFile(file)).fileUrl;
      await onSubmitJson("/api/admin/content", {
        collection: "gallery",
        title: String(formData.get("title") || ""),
        type: String(formData.get("type") || ""),
        body: String(formData.get("body") || ""),
        image,
        published: true,
      }, "POST");
      form.reset();
    } finally {
      setIsUploading(false);
    }
  }
  return <div className="grid gap-5 xl:grid-cols-[430px_1fr]"><Card><h2 className="text-lg font-black">Add gallery photo</h2><form className="mt-5 grid gap-4" onSubmit={submit}><Field label="Title"><Input name="title" required /></Field><Field label="Type"><Input name="type" defaultValue="Clinic" /></Field><Field label="Caption"><TextArea name="body" rows={3} /></Field><Field label="Image URL"><Input name="image" placeholder="/uploads/clinic/photo.webp" /></Field><Field label="Or upload image"><Input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp" /></Field><PrimaryButton disabled={isUploading}>{isUploading ? "Uploading..." : "Add photo"}</PrimaryButton></form></Card><Card><h2 className="text-lg font-black">Gallery list</h2><div className="mt-4 grid gap-3 md:grid-cols-2">{gallery.map((item) => <div key={item.id} className="rounded-2xl border border-[#edf3f5] p-4"><div className="h-36 rounded-2xl bg-cover bg-center" style={{ backgroundImage: `url(${item.image})` }} /><div className="mt-3 flex items-start justify-between gap-3"><div><b>{item.title}</b><p className="text-sm text-[#607384]">{item.type}</p></div><button className="rounded-xl border px-3 py-2 text-xs font-black" onClick={() => onSubmitJson("/api/admin/content", { collection: "gallery", id: item.id, published: !item.published })}>{item.published ? "Hide" : "Show"}</button></div></div>)}</div></Card></div>;
}

function AccessControlView({ staff, onSubmitJson }: { staff: SafeStaffUser[]; onSubmitJson: (url: string, payload: Record<string, unknown>, method?: "POST" | "PATCH") => Promise<void> }) {
  return <div className="grid gap-5">{staff.map((item) => <Card key={item.id}><div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between"><div><h2 className="text-lg font-black">{item.name}</h2><p className="text-sm font-bold text-[#607384]">{item.email} · {item.role}</p></div><Select defaultValue={item.role} onChange={(event) => onSubmitJson("/api/admin/users", { id: item.id, role: event.target.value as StaffRole, permissions: roleDefaultPermissions[event.target.value as StaffRole] })}><option value="ASSISTANT">Assistant</option><option value="RECEPTIONIST">Receptionist</option><option value="CMS_MANAGER">CMS Manager</option><option value="DOCTOR">Doctor</option><option value="SUPER_ADMIN">Super Admin</option></Select></div><div className="mt-5 grid gap-2 md:grid-cols-3 lg:grid-cols-4">{allPermissions.map((permission) => <label key={permission} className="flex items-center gap-2 rounded-2xl border border-[#edf3f5] p-3 text-xs font-black"><input type="checkbox" defaultChecked={item.permissions.includes(permission)} onChange={(event) => { const next = event.target.checked ? [...item.permissions, permission] : item.permissions.filter((existing) => existing !== permission); void onSubmitJson("/api/admin/users", { id: item.id, permissions: next }); }} />{permission}</label>)}</div></Card>)}</div>;
}

function AccountsView({ appointments, prescriptions }: { appointments: Appointment[]; prescriptions: Prescription[] }) {
  const completed = appointments.filter((item) => item.status === "completed").length;
  return <div className="grid gap-5 md:grid-cols-3"><Card><p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">Visits</p><h2 className="mt-2 text-3xl font-black">{completed}</h2></Card><Card><p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">Prescriptions</p><h2 className="mt-2 text-3xl font-black">{prescriptions.length}</h2></Card><Card><p className="text-xs font-black uppercase tracking-[0.16em] text-[#007c75]">Billing</p><p className="mt-2 text-sm leading-7 text-[#607384]">Income/expense ledger needs a real accounting model in the next phase.</p></Card></div>;
}

function ReportsView({ patients, appointments, prescriptions }: { patients: SafePatient[]; appointments: Appointment[]; prescriptions: Prescription[] }) {
  return <div className="grid gap-5 md:grid-cols-3"><Card><h2 className="text-3xl font-black">{patients.length}</h2><p className="font-bold text-[#607384]">Patients</p></Card><Card><h2 className="text-3xl font-black">{appointments.length}</h2><p className="font-bold text-[#607384]">Appointments</p></Card><Card><h2 className="text-3xl font-black">{prescriptions.length}</h2><p className="font-bold text-[#607384]">Prescriptions</p></Card></div>;
}

function SettingsView() {
  return <Card><h2 className="text-lg font-black">Production settings</h2><div className="mt-4 grid gap-3 text-sm leading-7 text-[#607384]"><p>Set <b>AUTH_SECRET</b> in production.</p><p>Set <b>CLINIC_DATA_PATH</b> to a persistent server volume.</p><p>Use PostgreSQL/Prisma before multi-tenant SaaS launch. JSON storage is okay for this local full-stack phase only.</p></div></Card>;
}

function EmptyState({ label }: { label: string }) {
  return <div className="mt-4 rounded-2xl border border-dashed border-[#bed9de] bg-[#f8fcfd] p-8 text-center text-sm font-black text-[#7d8d99]">{label}</div>;
}
