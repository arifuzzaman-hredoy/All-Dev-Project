"use client";

import type { DoctorProfile, Prescription, PrescriptionTemplateId, SafePatient } from "@/lib/clinic-types";
export type { PrescriptionTemplateId } from "@/lib/clinic-types";

export const prescriptionTemplateOptions: Array<{ id: PrescriptionTemplateId; label: string; hint: string }> = [
  { id: "yellow-classic", label: "Yellow Classic Rx", hint: "Full yellow A4 prescription pad" },
  { id: "blue-diagnostic", label: "Premium Blue Lab Pad", hint: "Premium blue/white diagnostic layout like the selected reference" },
];

function displayDate(date?: string) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(date));
}

function escapeHtml(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;")
    .replace(/\n/g, "<br />");
}

type PrescriptionTemplateRendererProps = {
  templateId: PrescriptionTemplateId;
  profile?: DoctorProfile;
  patient?: SafePatient;
  prescription?: Prescription;
};

type TemplateData = {
  hospitalName: string;
  hospitalSlogan: string;
  doctorName: string;
  qualification: string;
  designation: string;
  footer: string;
  patientName: string;
  patientAge: string;
  patientGender: string;
  patientPhone: string;
  diagnosis: string;
  vitals: string;
  medicines: string;
  tests: string;
  advice: string;
  followUp: string;
  date: string;
};

export function PrescriptionTemplateRenderer({ templateId, profile, patient, prescription }: PrescriptionTemplateRendererProps) {
  const data: TemplateData = {
    hospitalName: profile?.hospitalName || "CareBridge Diagnostic",
    hospitalSlogan: profile?.hospitalSlogan || "Clinical workspace",
    doctorName: profile?.doctorName || "Dr. Doctor Name",
    qualification: profile?.qualification || "MBBS, MPH, CCH, CCD, CMU",
    designation: profile?.designation || "General & Lifestyle Physician",
    footer: profile?.prescriptionFooter || "Address Line 1 | Address Line 2 | Phone +8801672132837 | companyname@email.com",
    patientName: patient?.name || prescription?.patientName || "________________",
    patientAge: patient?.age || prescription?.age || "___",
    patientGender: patient?.gender || prescription?.gender || "___",
    patientPhone: patient?.phone || prescription?.phone || "____________",
    diagnosis: prescription?.diagnosis || "Write diagnosis here",
    vitals: prescription?.vitals || "",
    medicines: prescription?.medicines || "1. Medicine name - dose - duration",
    tests: prescription?.tests || "As needed",
    advice: prescription?.advice || "Diet, rest, follow instructions",
    followUp: prescription?.followUpDate ? displayDate(prescription.followUpDate) : "__________",
    date: displayDate(prescription?.createdAt || new Date().toISOString()),
  };

  const print = () => {
    const printWindow = window.open("", "_blank", "width=900,height=1200");
    if (!printWindow) {
      window.print();
      return;
    }

    printWindow.document.write(templateId === "blue-diagnostic" ? bluePrintHtml(data) : yellowPrintHtml(data));
    printWindow.document.close();
    printWindow.focus();

    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 300);
  };

  return (
    <div>
      {templateId === "blue-diagnostic" ? <BlueDiagnosticPreview data={data} /> : <YellowClassicPreview data={data} />}
      <div className="mt-4 flex justify-end print:hidden">
        <button type="button" onClick={print} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-[#dce8ec] bg-white px-4 py-3 text-sm font-black text-[#203847] transition hover:bg-[#f3fbfb]">
          Print selected template
        </button>
      </div>
    </div>
  );
}

function MedicalMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 72" aria-hidden="true" className={className}>
      <path d="M60 61C31 42 15 28 15 15c0-8 6-13 14-13 7 0 12 4 16 11C49 6 54 2 61 2c8 0 14 6 14 14 0 12-10 23-15 30" fill="none" stroke="currentColor" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8 43h23l8-16 12 34 11-45 10 27h40" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function YellowClassicPreview({ data }: { data: TemplateData }) {
  return (
    <div className="mx-auto flex aspect-[210/297] w-full max-w-[820px] flex-col overflow-hidden bg-[#fff4a5] p-[6.7%] text-[#142126] shadow-[0_30px_100px_rgba(120,100,30,0.16)]">
      <div className="grid grid-cols-[1fr_90px_1fr] items-start gap-6 border-b-[5px] border-[#142126] pb-5">
        <div><h2 className="text-2xl font-black uppercase leading-none tracking-[-0.04em]">{data.hospitalName}</h2><p className="mt-1 text-xs font-extrabold uppercase leading-tight">{data.hospitalSlogan}</p></div>
        <div className="pt-4 text-center text-4xl font-black leading-none">♡</div>
        <div className="text-right"><h3 className="text-xl font-black uppercase leading-none tracking-[-0.04em]">{data.doctorName}</h3><p className="mt-1 text-xs font-extrabold uppercase leading-tight">{data.qualification}</p></div>
      </div>
      <div className="grid grid-cols-[1.6fr_80px_100px_1fr] gap-3 border-b border-[#142126]/60 py-3 text-[11px] font-extrabold leading-tight">
        <p className="truncate">Name: <span className="font-black">{data.patientName}</span></p><p>Age: <span>{data.patientAge}</span></p><p>Gender: <span>{data.patientGender}</span></p><p className="truncate">Phone: <span>{data.patientPhone}</span></p>
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-[90px_1fr] gap-6 py-6">
        <div className="border-r-2 border-[#142126]/75 pr-5"><p className="text-4xl font-black leading-none">Rx</p></div>
        <div className="space-y-5 whitespace-pre-line text-sm leading-7"><p><b>Diagnosis:</b><br />{data.diagnosis}</p><p><b>Medicines:</b><br />{data.medicines}</p><p><b>Tests:</b><br />{data.tests}</p><p><b>Advice:</b><br />{data.advice}</p><p><b>Follow-up:</b><br />{data.followUp}</p></div>
      </div>
      <div className="grid grid-cols-[80px_1fr] items-end border-t-[5px] border-[#142126] pt-3 text-xs font-extrabold leading-tight"><span>⌁</span><span className="text-right">{data.footer}</span></div>
    </div>
  );
}

function BlueDiagnosticPreview({ data }: { data: TemplateData }) {
  return (
    <div className="mx-auto flex aspect-[210/297] w-full max-w-[820px] flex-col overflow-hidden bg-white text-[#15313d] shadow-[0_30px_110px_rgba(10,77,108,0.20)] ring-1 ring-[#0a7b9a]/25">
      <div className="grid min-h-[104px] grid-cols-[1fr_150px_1fr] items-center gap-4 border-b-[5px] border-[#087892] px-8 py-5">
        <div className="leading-tight">
          <h2 className="text-[17px] font-black uppercase tracking-[-0.02em] text-[#0d2731]">{data.doctorName}</h2>
          <p className="mt-1 text-[11px] font-extrabold text-[#15313d]">{data.qualification}</p>
          <p className="text-[10px] font-bold text-[#50616b]">{data.designation}</p>
        </div>
        <div className="grid place-items-center text-[#0b86a5]">
          <MedicalMark className="h-[72px] w-[120px]" />
        </div>
        <div className="text-right leading-tight">
          <h2 className="text-[19px] font-black uppercase tracking-[-0.02em] text-[#0b7997]">{data.hospitalName}</h2>
          <p className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#15313d]">{data.hospitalSlogan}</p>
          <p className="mt-1 text-[10px] font-bold text-[#50616b]">Phone: {data.patientPhone}</p>
        </div>
      </div>

      <div className="grid grid-cols-[1.45fr_86px_92px_1fr] border-b border-[#087892] px-8 py-2.5 text-[11px] font-extrabold leading-tight">
        <p className="truncate">Name: <b>{data.patientName}</b></p>
        <p>Age: <b>{data.patientAge}</b></p>
        <p>Sex: <b>{data.patientGender}</b></p>
        <p className="text-right">Date: <b>{data.date}</b></p>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-[118px_1fr] border-b border-[#087892]">
        <div className="grid grid-rows-[1fr_1.08fr_1.03fr] border-r border-[#087892] text-[12px] font-black text-[#15313d]">
          <div className="p-5">C/C</div>
          <div className="border-y border-[#087892] p-5">O/E</div>
          <div className="p-5">Investigation.</div>
        </div>
        <div className="relative overflow-hidden px-9 py-8">
          <div className="pointer-events-none absolute inset-0 grid place-items-center text-[#88a2d2]/35">
            <MedicalMark className="h-[135px] w-[220px]" />
          </div>
          <div className="relative z-10 grid grid-cols-[52px_1fr] gap-6">
            <p className="m-0 text-[29px] font-black leading-none text-[#102d38]">Rx</p>
            <div className="space-y-4 whitespace-pre-line text-[13px] leading-6">
              <p><b>Diagnosis:</b> {data.diagnosis}</p>
              <p><b>Medicines:</b><br />{data.medicines}</p>
              <p><b>Tests:</b><br />{data.tests}</p>
              <p><b>Advice:</b><br />{data.advice}</p>
              <p><b>Follow-up:</b> {data.followUp}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="relative min-h-[58px] overflow-hidden bg-[#087892] px-8 py-5 text-[10px] font-extrabold text-white">
        <span className="relative z-10">{data.footer}</span>
        <span className="absolute bottom-0 left-[48%] h-[66px] w-[36px] -skew-x-[27deg] bg-white" />
        <span className="absolute bottom-0 left-[55%] h-[66px] w-[15px] -skew-x-[27deg] bg-white" />
      </div>
    </div>
  );
}

function yellowPrintHtml(data: TemplateData) {
  return `<!doctype html><html><head><meta charset="utf-8" /><title>Prescription</title><style>${basePrintCss("#fff4a5", "#142126")}
.sheet{padding:14mm 14mm 10mm}.y-head{display:grid;grid-template-columns:1fr 26mm 1fr;gap:8mm;border-bottom:1.2mm solid #142126;padding-bottom:6mm}.title{margin:0;font-size:18pt;line-height:1;font-weight:900;text-transform:uppercase;letter-spacing:-.8pt}.sub{margin:1.5mm 0 0;font-size:7.8pt;line-height:1.2;font-weight:800;text-transform:uppercase}.right{text-align:right}.heart{text-align:center;font-size:25pt;line-height:1;font-weight:900;padding-top:3mm}.patient{display:grid;grid-template-columns:1.6fr 20mm 25mm 1fr;gap:4mm;border-bottom:.35mm solid rgba(20,33,38,.62);padding:4mm 0;font-size:8.4pt;line-height:1.35;font-weight:800;white-space:nowrap}.body{flex:1;display:grid;grid-template-columns:24mm 1fr;gap:7mm;padding:8mm 0 7mm}.rxcol{border-right:.55mm solid rgba(20,33,38,.78);padding-right:5mm}.rxmark{margin:0;font-size:27pt;line-height:1;font-weight:900}.content{font-size:10.4pt;line-height:1.58;word-break:break-word}.section{margin:0 0 5.2mm}.label{display:block;margin-bottom:1mm;font-weight:900}.footer{display:grid;grid-template-columns:20mm 1fr;align-items:end;border-top:1.2mm solid #142126;padding-top:3mm;font-size:8pt;line-height:1.25;font-weight:800}.fr{text-align:right}</style></head><body><main class="sheet"><header class="y-head"><section><h1 class="title">${escapeHtml(data.hospitalName)}</h1><p class="sub">${escapeHtml(data.hospitalSlogan)}</p></section><section class="heart">♡</section><section class="right"><h2 class="title">${escapeHtml(data.doctorName)}</h2><p class="sub">${escapeHtml(data.qualification)}</p></section></header><section class="patient"><div>Name: <b>${escapeHtml(data.patientName)}</b></div><div>Age: <b>${escapeHtml(data.patientAge)}</b></div><div>Gender: <b>${escapeHtml(data.patientGender)}</b></div><div>Phone: <b>${escapeHtml(data.patientPhone)}</b></div></section><section class="body"><aside class="rxcol"><p class="rxmark">Rx</p></aside><article class="content"><p class="section"><span class="label">Diagnosis:</span>${escapeHtml(data.diagnosis)}</p><p class="section"><span class="label">Medicines:</span>${escapeHtml(data.medicines)}</p><p class="section"><span class="label">Tests:</span>${escapeHtml(data.tests)}</p><p class="section"><span class="label">Advice:</span>${escapeHtml(data.advice)}</p><p class="section"><span class="label">Follow-up:</span>${escapeHtml(data.followUp)}</p></article></section><footer class="footer"><div>⌁</div><div class="fr">${escapeHtml(data.footer)}</div></footer></main></body></html>`;
}

function bluePrintHtml(data: TemplateData) {
  const logo = `<svg viewBox="0 0 120 72" aria-hidden="true"><path d="M60 61C31 42 15 28 15 15c0-8 6-13 14-13 7 0 12 4 16 11C49 6 54 2 61 2c8 0 14 6 14 14 0 12-10 23-15 30" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 43h23l8-16 12 34 11-45 10 27h40" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  return `<!doctype html><html><head><meta charset="utf-8" /><title>Prescription</title><style>${basePrintCss("#ffffff", "#15313d")}
.sheet{padding:0;background:#fff}.head{height:35mm;display:grid;grid-template-columns:1fr 42mm 1fr;align-items:center;gap:5mm;border-bottom:1.55mm solid #087892;padding:6mm 11mm 4.8mm}.doctor-title,.brand-title{margin:0;font-size:12pt;line-height:1.02;font-weight:900;text-transform:uppercase;letter-spacing:-.2pt}.brand-title{font-size:14pt;color:#0b7997;text-align:right}.small{font-size:7.2pt;line-height:1.25;font-weight:800;color:#435763}.right{text-align:right}.logo{display:grid;place-items:center;color:#0b86a5}.logo svg{width:34mm;height:21mm}.patient{display:grid;grid-template-columns:1.45fr 20mm 23mm 1fr;gap:4mm;border-bottom:.4mm solid #087892;padding:3.2mm 11mm;font-size:7.8pt;line-height:1.25;font-weight:800;white-space:nowrap}.body{flex:1;display:grid;grid-template-columns:32mm 1fr;border-bottom:.4mm solid #087892;min-height:0}.left{display:grid;grid-template-rows:1fr 1.08fr 1.03fr;border-right:.4mm solid #087892;font-size:9.2pt;font-weight:900}.left div{padding:7mm 6mm}.left div+div{border-top:.4mm solid #087892}.main{position:relative;padding:8mm 10mm;overflow:hidden}.water{position:absolute;inset:0;display:grid;place-items:center;color:rgba(111,139,196,.29)}.water svg{width:58mm;height:35mm}.copy{position:relative;z-index:1;display:grid;grid-template-columns:14mm 1fr;gap:7mm}.rx{margin:0;font-size:21pt;line-height:1;font-weight:900;color:#102d38}.content{font-size:9.7pt;line-height:1.55;word-break:break-word}.section{margin:0 0 4.6mm}.footer{position:relative;height:15.5mm;background:#087892;color:#fff;padding:4.5mm 11mm;font-size:7.4pt;line-height:1.25;font-weight:800;overflow:hidden}.slash1,.slash2{position:absolute;bottom:-1mm;background:#fff;transform:skewX(-28deg)}.slash1{left:48%;width:13mm;height:20mm}.slash2{left:57%;width:6mm;height:20mm}</style></head><body><main class="sheet"><header class="head"><section><h1 class="doctor-title">${escapeHtml(data.doctorName)}</h1><div class="small">${escapeHtml(data.qualification)}<br/>${escapeHtml(data.designation)}</div></section><section class="logo">${logo}</section><section class="right"><h2 class="brand-title">${escapeHtml(data.hospitalName)}</h2><div class="small">${escapeHtml(data.hospitalSlogan)}<br/>Phone: ${escapeHtml(data.patientPhone)}</div></section></header><section class="patient"><div>Name: <b>${escapeHtml(data.patientName)}</b></div><div>Age: <b>${escapeHtml(data.patientAge)}</b></div><div>Sex: <b>${escapeHtml(data.patientGender)}</b></div><div class="right">Date: <b>${escapeHtml(data.date)}</b></div></section><section class="body"><aside class="left"><div>C/C</div><div>O/E</div><div>Investigation.</div></aside><article class="main"><div class="water">${logo}</div><div class="copy"><p class="rx">Rx</p><div class="content"><p class="section"><b>Diagnosis:</b> ${escapeHtml(data.diagnosis)}</p><p class="section"><b>Medicines:</b><br/>${escapeHtml(data.medicines)}</p><p class="section"><b>Tests:</b><br/>${escapeHtml(data.tests)}</p><p class="section"><b>Advice:</b><br/>${escapeHtml(data.advice)}</p><p class="section"><b>Follow-up:</b> ${escapeHtml(data.followUp)}</p></div></div></article></section><footer class="footer"><span>${escapeHtml(data.footer)}</span><span class="slash1"></span><span class="slash2"></span></footer></main></body></html>`;
}

function basePrintCss(background: string, color: string) {
  return `@page{size:A4 portrait;margin:0}*{box-sizing:border-box}html,body{width:210mm;height:297mm;margin:0;padding:0;background:${background};color:${color};font-family:Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.sheet{width:210mm;height:297mm;display:flex;flex-direction:column;overflow:hidden;background:${background}}@media print{html,body{width:210mm;height:297mm;background:${background}!important}.sheet{background:${background}!important;page-break-after:avoid;break-after:avoid}}`;
}
