"use client";

import { createContext, useContext } from "react";
import type { BlogPost, CmsContent, DoctorProfile, GalleryItem, QaItem } from "@/lib/clinic-types";

type PublicSiteContextValue = {
  profile: DoctorProfile;
  cms: CmsContent;
  blogs: BlogPost[];
  gallery: GalleryItem[];
  qa: QaItem[];
};

const fallback: PublicSiteContextValue = {
  profile: {
    hospitalName: "CareBridge",
    hospitalSlogan: "Clinical workspace",
    doctorName: "Dr. Kawsar Ahmed",
    qualification: "MBBS, MPH, CCH, CCD, CMU",
    designation: "General & Lifestyle Physician",
    chamberName: "Hypertension & Research Centre, Rangpur",
    visitingHours: "5:00 PM - 9:00 PM",
    phone: "+8801672132837",
    email: "contact@drkawsarahmed.com",
    addressLine1: "Rangpur, Bangladesh",
    addressLine2: "Call before visit to confirm schedule",
    prescriptionFooter: "Address Line 1 | Address Line 2 | Phone +8801672132837 | companyname@email.com",
    profileImage: "/dr-kawsar-hero.png",
    defaultPrescriptionTemplateId: "yellow-classic",
  },
  cms: {
    heroTitle: "Dr. Kawsar Ahmed",
    heroSubtitle:
      "Compassionate care focused on lifestyle medicine, hypertension, diabetes, cardiovascular risk, public health, and preventive healthcare.",
    appointmentNote: "Preferred appointment date will be confirmed by the chamber team.",
    aboutText:
      "General and lifestyle-focused clinical care with practical prevention guidance for patients and families.",
    contactPhone: "+8801672132837",
    contactEmail: "contact@drkawsarahmed.com",
    chamberAddress: "Rangpur, Bangladesh",
    updatedAt: new Date(0).toISOString(),
  },
  blogs: [],
  gallery: [],
  qa: [],
};

const PublicSiteContext = createContext<PublicSiteContextValue>(fallback);

export function PublicSiteProvider({ children, content }: { children: React.ReactNode; content?: PublicSiteContextValue }) {
  return <PublicSiteContext.Provider value={content || fallback}>{children}</PublicSiteContext.Provider>;
}

export function usePublicSite() {
  return useContext(PublicSiteContext);
}
