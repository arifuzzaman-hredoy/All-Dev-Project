import {
  Activity,
  HeartPulse,
  Pill,
  Plus,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";

export function MedicalPatternIcons() {
  const icons = [
    HeartPulse,
    Stethoscope,
    Plus,
    Pill,
    Activity,
    ShieldCheck,
    HeartPulse,
    Plus,
  ];

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-35">
      {icons.map((Icon, index) => (
        <Icon
          key={index}
          className="absolute h-8 w-8 text-[#2E7E95]"
          style={{
            left: `${8 + ((index * 17) % 84)}%`,
            top: `${12 + ((index * 23) % 76)}%`,
            opacity: index % 2 ? 0.12 : 0.18,
            transform: `rotate(${index * 16}deg)`,
          }}
          strokeWidth={1.4}
        />
      ))}
    </div>
  );
}
