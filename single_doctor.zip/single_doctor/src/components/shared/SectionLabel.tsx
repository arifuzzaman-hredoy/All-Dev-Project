export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-3 text-sm font-bold uppercase tracking-[0.18em] text-[#d99b45]">
      {children}
    </p>
  );
}
