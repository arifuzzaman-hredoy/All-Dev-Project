import { About } from "./sections/About";
import { Appointment } from "./sections/Appointment";
import { Blogs } from "./sections/Blogs";
import { Contact } from "./sections/Contact";
import { Credentials } from "./sections/Credentials";
import { Footer } from "./sections/Footer";
import { Gallery } from "./sections/Gallery";
import { Header } from "./sections/Header";
import { Hero } from "./sections/Hero";
import { Services } from "./sections/Services";
import { PublicSiteProvider } from "./PublicSiteProvider";
import type { BlogPost, CmsContent, DoctorProfile, GalleryItem, QaItem } from "@/lib/clinic-types";

export function DoctorHome({ content }: { content?: { profile: DoctorProfile; cms: CmsContent; blogs: BlogPost[]; gallery: GalleryItem[]; qa: QaItem[] } }) {
  return (
    <PublicSiteProvider content={content}>
    <main className="min-h-screen overflow-hidden text-[#1B3A44]">
      <Header />
      <Hero />
      <About />
      <Services />
      <Credentials />
      <Blogs />
      <Appointment />
      <Contact />
      <Gallery />
      <Footer />
    </main>
    </PublicSiteProvider>
  );
}
