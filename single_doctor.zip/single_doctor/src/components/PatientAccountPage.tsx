"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { Eye, EyeOff, HeartPulse, UserRound } from "lucide-react";

export function PatientAccountPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("");
    setError("");
    const form = event.currentTarget;
    const response = await fetch("/api/public/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(new FormData(form).entries())),
    });
    const result = (await response.json()) as { ok?: boolean; error?: string; patient?: { patientCode?: string } };
    if (!response.ok || !result.ok) {
      setError(result.error || "Account creation failed.");
      return;
    }
    form.reset();
    setStatus(`Account created. Patient code: ${result.patient?.patientCode || "saved"}`);
  }

  return (
    <main className="grid min-h-screen place-items-center bg-[#eef7f8] px-4 py-10 text-[#102a33]">
      <div className="w-full max-w-3xl rounded-[28px] border border-white bg-white/92 p-7 shadow-[0_30px_100px_rgba(15,70,80,0.12)]">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e3fbf8] text-[#007c75]"><HeartPulse className="h-6 w-6" /></div>
            <div><p className="text-xs font-black uppercase tracking-[0.18em] text-[#007c75]">Patient Account</p><h1 className="text-2xl font-black tracking-[-0.04em]">Create patient account</h1></div>
          </div>
          <Link href="/" className="rounded-2xl border border-[#dbe8ec] px-4 py-2 text-sm font-black">Home</Link>
        </div>

        <form onSubmit={submit} className="mt-7 grid gap-4 md:grid-cols-2">
          <label className="grid gap-2 text-sm font-black">Patient name<input name="name" required className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]" /></label>
          <label className="grid gap-2 text-sm font-black">Phone<input name="phone" required className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]" /></label>
          <label className="grid gap-2 text-sm font-black">Email<input name="email" type="email" className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]" /></label>
          <label className="grid gap-2 text-sm font-black">Age<input name="age" className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]" /></label>
          <label className="grid gap-2 text-sm font-black">Gender<select name="gender" defaultValue="prefer-not-to-say" className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]"><option value="male">Male</option><option value="female">Female</option><option value="prefer-not-to-say">Prefer not to say</option></select></label>
          <label className="grid gap-2 text-sm font-black">Password<span className="flex rounded-2xl border border-[#dbe8ec] px-4 py-3 focus-within:border-[#007c75]"><input name="password" type={showPassword ? "text" : "password"} minLength={6} required className="w-full outline-none" /><button type="button" onClick={() => setShowPassword((value) => !value)} className="text-[#007c75]">{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></span></label>
          <label className="grid gap-2 text-sm font-black md:col-span-2">Address<input name="address" className="rounded-2xl border border-[#dbe8ec] px-4 py-3 outline-none focus:border-[#007c75]" /></label>
          <button className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#101d31] px-5 py-3 text-sm font-black text-white md:col-span-2"><UserRound className="h-4 w-4" /> Create account</button>
        </form>

        {status && <p className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-black text-emerald-700">{status}</p>}
        {error && <p className="mt-5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-700">{error}</p>}
      </div>
    </main>
  );
}
