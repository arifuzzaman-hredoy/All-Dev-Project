export type AppointmentStatus = "pending" | "confirmed" | "in_progress" | "completed" | "cancelled";
export type MessageStatus = "new" | "seen" | "replied";
export type StaffRole = "SUPER_ADMIN" | "DOCTOR" | "ASSISTANT" | "CMS_MANAGER" | "RECEPTIONIST";
export type Gender = "male" | "female" | "other" | "prefer-not-to-say";
export type PrescriptionTemplateId = "yellow-classic" | "blue-diagnostic";

export type Permission =
  | "dashboard:read"
  | "appointments:read"
  | "appointments:write"
  | "patients:read"
  | "patients:write"
  | "users:read"
  | "users:write"
  | "prescriptions:read"
  | "prescriptions:write"
  | "messages:read"
  | "messages:write"
  | "profile:write"
  | "cms:write"
  | "roles:write"
  | "accounts:read"
  | "reports:read"
  | "settings:write";

export type StaffUser = {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: StaffRole;
  permissions: Permission[];
  canLogin: boolean;
  status: "active" | "disabled";
  createdAt: string;
  updatedAt: string;
};

export type Patient = {
  id: string;
  patientCode: string;
  name: string;
  email?: string;
  phone: string;
  passwordHash?: string;
  age?: string;
  gender?: Gender;
  address?: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
  lastVisitAt?: string;
};

export type Appointment = {
  id: string;
  patientId?: string;
  patientName: string;
  phone: string;
  age?: string;
  gender?: Gender;
  preferredDate: string;
  consultationType: string;
  message?: string;
  status: AppointmentStatus;
  source: "public" | "doctor_panel";
  createdAt: string;
  updatedAt: string;
};

export type PatientMessage = {
  id: string;
  patientId?: string;
  name: string;
  phone?: string;
  email?: string;
  message: string;
  reply?: string;
  status: MessageStatus;
  createdAt: string;
  updatedAt: string;
};

export type Prescription = {
  id: string;
  patientId: string;
  appointmentId?: string;
  patientName: string;
  age?: string;
  gender?: Gender;
  phone?: string;
  diagnosis: string;
  vitals?: string;
  medicines: string;
  tests?: string;
  advice?: string;
  followUpDate?: string;
  notes?: string;
  createdByStaffId: string;
  printCode: string;
  templateId: PrescriptionTemplateId;
  createdAt: string;
  updatedAt: string;
};

export type UploadedPrescription = {
  id: string;
  patientId?: string;
  patientName: string;
  phone?: string;
  fileUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  notes?: string;
  createdByStaffId: string;
  createdAt: string;
  updatedAt: string;
};

export type DoctorProfile = {
  hospitalName: string;
  hospitalSlogan: string;
  doctorName: string;
  qualification: string;
  designation: string;
  chamberName: string;
  visitingHours: string;
  phone: string;
  email: string;
  addressLine1: string;
  addressLine2: string;
  prescriptionFooter: string;
  profileImage: string;
  defaultPrescriptionTemplateId: PrescriptionTemplateId;
};

export type CmsContent = {
  heroTitle: string;
  heroSubtitle: string;
  appointmentNote: string;
  aboutText: string;
  contactPhone: string;
  contactEmail: string;
  chamberAddress: string;
  updatedAt: string;
};

export type BlogPost = {
  id: string;
  title: string;
  slug: string;
  category: string;
  body: string;
  content: string[];
  image?: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
};

export type GalleryItem = {
  id: string;
  title: string;
  type: string;
  body: string;
  image: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
};

export type QaItem = {
  id: string;
  question: string;
  answer: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ClinicStore = {
  version: number;
  staff: StaffUser[];
  patients: Patient[];
  appointments: Appointment[];
  messages: PatientMessage[];
  prescriptions: Prescription[];
  uploadedPrescriptions: UploadedPrescription[];
  profile: DoctorProfile;
  cms: CmsContent;
  blogs: BlogPost[];
  gallery: GalleryItem[];
  qa: QaItem[];
};

export type SafeStaffUser = Omit<StaffUser, "passwordHash"> & { passwordStored: false };
export type SafePatient = Omit<Patient, "passwordHash"> & { passwordStored: boolean };

export const allPermissions: Permission[] = [
  "dashboard:read",
  "appointments:read",
  "appointments:write",
  "patients:read",
  "patients:write",
  "users:read",
  "users:write",
  "prescriptions:read",
  "prescriptions:write",
  "messages:read",
  "messages:write",
  "profile:write",
  "cms:write",
  "roles:write",
  "accounts:read",
  "reports:read",
  "settings:write",
];

export const roleDefaultPermissions: Record<StaffRole, Permission[]> = {
  SUPER_ADMIN: allPermissions,
  DOCTOR: allPermissions.filter((permission) => permission !== "settings:write"),
  ASSISTANT: [
    "dashboard:read",
    "appointments:read",
    "appointments:write",
    "patients:read",
    "patients:write",
    "messages:read",
    "messages:write",
  ],
  CMS_MANAGER: ["dashboard:read", "cms:write", "profile:write"],
  RECEPTIONIST: [
    "dashboard:read",
    "appointments:read",
    "appointments:write",
    "patients:read",
    "patients:write",
    "messages:read",
  ],
};
