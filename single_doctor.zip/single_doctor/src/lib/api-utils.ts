import { NextResponse } from "next/server";

export async function readJsonBody<T extends Record<string, unknown>>(request: Request): Promise<T> {
  try {
    return (await request.json()) as T;
  } catch {
    return {} as T;
  }
}

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ ok: true, ...data }, init);
}

export function badRequest(message: string) {
  return NextResponse.json({ ok: false, error: message }, { status: 400 });
}

export function serverError(error: unknown) {
  const message = error instanceof Error ? error.message : "Unexpected server error";
  return NextResponse.json({ ok: false, error: message }, { status: 500 });
}

export function textValue(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

export function optionalText(value: unknown) {
  const text = textValue(value);
  return text || undefined;
}
