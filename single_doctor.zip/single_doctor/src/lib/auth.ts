import "server-only";

import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { readStore, verifyPassword } from "./clinic-store";
import type { Permission, SafeStaffUser, StaffUser } from "./clinic-types";
import { sanitizeStaff } from "./clinic-store";

const sessionCookieName = "clinic_admin_session";
const sessionMaxAgeSeconds = 60 * 60 * 12;

type SessionPayload = {
  staffId: string;
  exp: number;
};

function secret() {
  return process.env.AUTH_SECRET || process.env.ADMIN_SESSION_SECRET || "change-this-secret-before-production";
}

function base64Url(input: string | Buffer) {
  return Buffer.from(input).toString("base64url");
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

function createToken(payload: SessionPayload) {
  const encoded = base64Url(JSON.stringify(payload));
  return `${encoded}.${sign(encoded)}`;
}

function readToken(token: string): SessionPayload | null {
  const [encoded, signature] = token.split(".");
  if (!encoded || !signature) return null;
  const expected = sign(encoded);
  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (signatureBuffer.length !== expectedBuffer.length) return null;
  if (!timingSafeEqual(signatureBuffer, expectedBuffer)) return null;

  try {
    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as SessionPayload;
    if (!payload.staffId || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function authenticateStaff(email: string, password: string): Promise<StaffUser | null> {
  const store = await readStore();
  const staff = store.staff.find((item) => item.email.toLowerCase() === email.trim().toLowerCase());
  if (!staff || !staff.canLogin || staff.status !== "active") return null;
  return verifyPassword(password, staff.passwordHash) ? staff : null;
}

export async function createSessionResponse(staff: StaffUser) {
  const response = NextResponse.json({ ok: true, staff: sanitizeStaff(staff) });
  response.cookies.set({
    name: sessionCookieName,
    value: createToken({ staffId: staff.id, exp: Date.now() + sessionMaxAgeSeconds * 1000 }),
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: sessionMaxAgeSeconds,
  });
  return response;
}

export function clearSessionResponse() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set({
    name: sessionCookieName,
    value: "",
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
  return response;
}

export async function getCurrentStaff(): Promise<StaffUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(sessionCookieName)?.value;
  if (!token) return null;
  const session = readToken(token);
  if (!session) return null;
  const store = await readStore();
  const staff = store.staff.find((item) => item.id === session.staffId);
  if (!staff || !staff.canLogin || staff.status !== "active") return null;
  return staff;
}

export async function getSafeCurrentStaff(): Promise<SafeStaffUser | null> {
  const staff = await getCurrentStaff();
  return staff ? sanitizeStaff(staff) : null;
}

export async function requireStaff(permission?: Permission) {
  const staff = await getCurrentStaff();
  if (!staff) {
    return { staff: null, response: NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 }) };
  }
  if (permission && !staff.permissions.includes(permission)) {
    return { staff: null, response: NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 }) };
  }
  return { staff, response: null };
}

export async function canAccessDoctorSection(section: string) {
  const staff = await getCurrentStaff();
  if (!staff) return { allowed: false, staff: null, redirectTo: "/admin" };
  const sectionPermission: Record<string, Permission | undefined> = {
    dashboard: "dashboard:read",
    appointments: "appointments:read",
    patients: "patients:read",
    users: "users:read",
    "patient-record": "patients:read",
    prescription: "prescriptions:read",
    "upload-prescription": "prescriptions:write",
    "follow-up": "prescriptions:read",
    messages: "messages:read",
    profile: "profile:write",
    "website-cms": "cms:write",
    blogs: "cms:write",
    qa: "cms:write",
    gallery: "cms:write",
    "access-control": "roles:write",
    accounts: "accounts:read",
    reports: "reports:read",
    settings: "settings:write",
  };
  const needed = sectionPermission[section] || "dashboard:read";
  return { allowed: staff.permissions.includes(needed), staff, redirectTo: "/doctor/dashboard" };
}
