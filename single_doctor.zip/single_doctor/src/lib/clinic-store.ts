import "server-only";

import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import {
  allPermissions,
  roleDefaultPermissions,
  type Appointment,
  type ClinicStore,
  type CmsContent,
  type DoctorProfile,
  type Patient,
  type PatientMessage,
  type Permission,
  type Prescription,
  type PrescriptionTemplateId,
  type BlogPost,
  type GalleryItem,
  type QaItem,
  type UploadedPrescription,
  type SafePatient,
  type SafeStaffUser,
  type StaffRole,
  type StaffUser,
} from "./clinic-types";
import { blogItems, galleryItems } from "@/data/site";

const dataPath = process.env.CLINIC_DATA_PATH
  ? path.resolve(process.env.CLINIC_DATA_PATH)
  : path.join(process.cwd(), ".clinic-data", "clinic-store.json");

const defaultProfile: DoctorProfile = {
  hospitalName: "CareBridge",
  hospitalSlogan: "Clinical workspace",
  doctorName: "Dr. Kawsar Ahmed",
  qualification: "MBBS, MPH, CCH, CCD, CMU",
  designation: "General & Lifestyle Physician",
  chamberName: "Hypertension & Research Centre, Rangpur",
  visitingHours: "5:00 PM - 9:00 PM",
  phone: "+8801672132837",
  email: "contact@drkawsarahmed.com",
  addressLine1: "Rangpur, Bangladesh",
  addressLine2: "Call before visit to confirm schedule",
  prescriptionFooter: "Address Line 1 | Address Line 2 | Phone +8801672132837 | companyname@email.com",
  profileImage: "/dr-kawsar-hero.png",
  defaultPrescriptionTemplateId: "yellow-classic",
};

const defaultCms: CmsContent = {
  heroTitle: "Dr. Kawsar Ahmed",
  heroSubtitle:
    "Compassionate care focused on lifestyle medicine, hypertension, diabetes, cardiovascular risk, public health, and preventive healthcare.",
  appointmentNote: "Preferred appointment date will be confirmed by the chamber team.",
  aboutText:
    "General and lifestyle-focused clinical care with practical prevention guidance for patients and families.",
  contactPhone: "+8801672132837",
  contactEmail: "contact@drkawsarahmed.com",
  chamberAddress: "Rangpur, Bangladesh",
  updatedAt: new Date(0).toISOString(),
};


function toSlug(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function defaultBlogs(createdAt: string): BlogPost[] {
  return blogItems.map((blog, index) => ({
    id: `blog_seed_${index + 1}`,
    title: blog.title,
    slug: blog.slug,
    category: blog.category,
    body: blog.body,
    content: blog.content || [blog.body],
    published: true,
    createdAt,
    updatedAt: createdAt,
  }));
}

function defaultGallery(createdAt: string): GalleryItem[] {
  return galleryItems.map((item, index) => ({
    id: `gal_seed_${index + 1}`,
    title: item.title,
    type: item.type,
    body: item.body,
    image: item.image,
    published: true,
    createdAt,
    updatedAt: createdAt,
  }));
}

function defaultQa(createdAt: string): QaItem[] {
  return [
    {
      id: "qa_seed_1",
      question: "How do I book an appointment?",
      answer: "Use the appointment form on the public website. The chamber team will confirm the preferred date and consultation type.",
      published: true,
      createdAt,
      updatedAt: createdAt,
    },
    {
      id: "qa_seed_2",
      question: "Can I send a health question before visiting?",
      answer: "Yes, send a message from the contact section. For emergency symptoms, visit the nearest emergency service instead of waiting for an online reply.",
      published: true,
      createdAt,
      updatedAt: createdAt,
    },
  ];
}

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, passwordHash: string) {
  const [salt, hash] = passwordHash.split(":");
  if (!salt || !hash) return false;
  const hashBuffer = Buffer.from(hash, "hex");
  const candidate = scryptSync(password, salt, 64);
  return hashBuffer.length === candidate.length && timingSafeEqual(hashBuffer, candidate);
}

export function newId(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}_${randomBytes(5).toString("hex")}`;
}

function now() {
  return new Date().toISOString();
}

function normalizePrescriptionTemplateId(value?: string): PrescriptionTemplateId {
  return value === "blue-diagnostic" ? "blue-diagnostic" : "yellow-classic";
}

function initialAdminValue(name: string, fallback: string) {
  const value = process.env[name]?.trim();
  if (value) return value;
  if (process.env.NODE_ENV === "production") {
    throw new Error(`${name} is required when creating the production data store.`);
  }
  return fallback;
}

function createSeedStore(): ClinicStore {
  const createdAt = now();
  const initialAdminName = initialAdminValue("INITIAL_ADMIN_NAME", "Dr. Kawsar Ahmed");
  const initialAdminEmail = initialAdminValue("INITIAL_ADMIN_EMAIL", "doctor@example.com").toLowerCase();
  const initialAdminPassword = initialAdminValue("INITIAL_ADMIN_PASSWORD", "Admin@12345");

  return {
    version: 1,
    staff: [
      {
        id: "staff_admin",
        name: initialAdminName,
        email: initialAdminEmail,
        passwordHash: hashPassword(initialAdminPassword),
        role: "SUPER_ADMIN",
        permissions: allPermissions,
        canLogin: true,
        status: "active",
        createdAt,
        updatedAt: createdAt,
      },
    ],
    patients: [],
    appointments: [],
    messages: [],
    prescriptions: [],
    uploadedPrescriptions: [],
    profile: defaultProfile,
    cms: { ...defaultCms, updatedAt: createdAt },
    blogs: defaultBlogs(createdAt),
    gallery: defaultGallery(createdAt),
    qa: defaultQa(createdAt),
  };
}

async function ensureStoreFile() {
  const dir = path.dirname(dataPath);
  if (!existsSync(dataPath)) {
    await mkdir(dir, { recursive: true });
    await writeFile(dataPath, JSON.stringify(createSeedStore(), null, 2), "utf8");
  }
}

export async function readStore(): Promise<ClinicStore> {
  await ensureStoreFile();
  const raw = await readFile(dataPath, "utf8");
  const parsed = JSON.parse(raw) as ClinicStore;
  return {
    version: parsed.version || 1,
    staff: Array.isArray(parsed.staff) ? parsed.staff : [],
    patients: Array.isArray(parsed.patients) ? parsed.patients : [],
    appointments: Array.isArray(parsed.appointments) ? parsed.appointments : [],
    messages: Array.isArray(parsed.messages) ? parsed.messages : [],
    prescriptions: Array.isArray(parsed.prescriptions)
      ? parsed.prescriptions.map((item) => ({ ...item, templateId: normalizePrescriptionTemplateId(item.templateId) }))
      : [],
    uploadedPrescriptions: Array.isArray(parsed.uploadedPrescriptions) ? parsed.uploadedPrescriptions : [],
    profile: { ...defaultProfile, ...(parsed.profile || {}), defaultPrescriptionTemplateId: normalizePrescriptionTemplateId(parsed.profile?.defaultPrescriptionTemplateId) },
    cms: { ...defaultCms, ...(parsed.cms || {}) },
    blogs: Array.isArray(parsed.blogs) ? parsed.blogs : defaultBlogs(new Date(0).toISOString()),
    gallery: Array.isArray(parsed.gallery) ? parsed.gallery : defaultGallery(new Date(0).toISOString()),
    qa: Array.isArray(parsed.qa) ? parsed.qa : defaultQa(new Date(0).toISOString()),
  };
}

export async function writeStore(store: ClinicStore) {
  await mkdir(path.dirname(dataPath), { recursive: true });
  const tempPath = `${dataPath}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tempPath, JSON.stringify(store, null, 2), "utf8");
  await rename(tempPath, dataPath);
}

export async function mutateStore<T>(mutator: (store: ClinicStore) => T | Promise<T>) {
  const store = await readStore();
  const result = await mutator(store);
  await writeStore(store);
  return result;
}

export function sanitizeStaff(staff: StaffUser): SafeStaffUser {
  return {
    id: staff.id,
    name: staff.name,
    email: staff.email,
    role: staff.role,
    permissions: staff.permissions,
    canLogin: staff.canLogin,
    status: staff.status,
    createdAt: staff.createdAt,
    updatedAt: staff.updatedAt,
    passwordStored: false,
  };
}

export function sanitizePatient(patient: Patient): SafePatient {
  const { passwordHash, ...safe } = patient;
  return { ...safe, passwordStored: Boolean(passwordHash) };
}

export function sanitizePatients(patients: Patient[]) {
  return patients.map(sanitizePatient);
}

export function sanitizeStaffList(staff: StaffUser[]) {
  return staff.map(sanitizeStaff);
}

export function normalizePhone(phone: string) {
  return phone.replace(/\s+/g, "").trim();
}

export function findPatientByIdentity(store: ClinicStore, phone?: string, email?: string) {
  const cleanPhone = phone ? normalizePhone(phone) : "";
  const cleanEmail = email?.trim().toLowerCase();
  return store.patients.find((patient) => {
    return Boolean(
      (cleanPhone && normalizePhone(patient.phone) === cleanPhone) ||
        (cleanEmail && patient.email?.toLowerCase() === cleanEmail),
    );
  });
}

export function createPatientCode(existingCount: number) {
  const stamp = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  return `Demo-${stamp}${String(existingCount + 1).padStart(4, "0")}`;
}

export function createPatientFromPayload(payload: {
  name: string;
  email?: string;
  phone: string;
  password?: string;
  age?: string;
  gender?: Patient["gender"];
  address?: string;
}, existingCount: number): Patient {
  const createdAt = now();
  return {
    id: newId("pat"),
    patientCode: createPatientCode(existingCount),
    name: payload.name.trim(),
    email: payload.email?.trim().toLowerCase() || undefined,
    phone: normalizePhone(payload.phone),
    passwordHash: payload.password ? hashPassword(payload.password) : undefined,
    age: payload.age?.trim() || undefined,
    gender: payload.gender,
    address: payload.address?.trim() || undefined,
    status: "active",
    createdAt,
    updatedAt: createdAt,
  };
}

export function applyRolePermissions(role: StaffRole, permissions?: Permission[]) {
  const allowed = roleDefaultPermissions[role] || [];
  if (!permissions) return allowed;
  return permissions.filter((permission) => allPermissions.includes(permission));
}

export function createAppointment(payload: {
  patientId?: string;
  patientName: string;
  phone: string;
  age?: string;
  gender?: Appointment["gender"];
  preferredDate: string;
  consultationType: string;
  message?: string;
  source: Appointment["source"];
}): Appointment {
  const createdAt = now();
  return {
    id: newId("apt"),
    patientId: payload.patientId,
    patientName: payload.patientName.trim(),
    phone: normalizePhone(payload.phone),
    age: payload.age?.trim() || undefined,
    gender: payload.gender,
    preferredDate: payload.preferredDate,
    consultationType: payload.consultationType.trim() || "general",
    message: payload.message?.trim() || undefined,
    status: "pending",
    source: payload.source,
    createdAt,
    updatedAt: createdAt,
  };
}

export function createMessage(payload: {
  patientId?: string;
  name: string;
  phone?: string;
  email?: string;
  message: string;
}): PatientMessage {
  const createdAt = now();
  return {
    id: newId("msg"),
    patientId: payload.patientId,
    name: payload.name.trim(),
    phone: payload.phone ? normalizePhone(payload.phone) : undefined,
    email: payload.email?.trim().toLowerCase() || undefined,
    message: payload.message.trim(),
    status: "new",
    createdAt,
    updatedAt: createdAt,
  };
}

export function createPrescription(payload: {
  patient: Patient;
  appointmentId?: string;
  diagnosis: string;
  vitals?: string;
  medicines: string;
  tests?: string;
  advice?: string;
  followUpDate?: string;
  notes?: string;
  templateId?: string;
  createdByStaffId: string;
}): Prescription {
  const createdAt = now();
  return {
    id: newId("rx"),
    patientId: payload.patient.id,
    appointmentId: payload.appointmentId,
    patientName: payload.patient.name,
    age: payload.patient.age,
    gender: payload.patient.gender,
    phone: payload.patient.phone,
    diagnosis: payload.diagnosis.trim(),
    vitals: payload.vitals?.trim() || undefined,
    medicines: payload.medicines.trim(),
    tests: payload.tests?.trim() || undefined,
    advice: payload.advice?.trim() || undefined,
    followUpDate: payload.followUpDate || undefined,
    notes: payload.notes?.trim() || undefined,
    createdByStaffId: payload.createdByStaffId,
    printCode: `RX-${Date.now().toString(36).toUpperCase()}`,
    templateId: normalizePrescriptionTemplateId(payload.templateId),
    createdAt,
    updatedAt: createdAt,
  };
}


export function createBlogPost(payload: {
  title: string;
  slug?: string;
  category: string;
  body: string;
  content?: string;
  image?: string;
  published?: boolean;
}): BlogPost {
  const createdAt = now();
  const title = payload.title.trim();
  return {
    id: newId("blog"),
    title,
    slug: toSlug(payload.slug || title) || newId("post"),
    category: payload.category.trim() || "Health Advice",
    body: payload.body.trim(),
    content: (payload.content || payload.body)
      .split(/\n{2,}/)
      .map((part) => part.trim())
      .filter(Boolean),
    image: payload.image?.trim() || undefined,
    published: payload.published ?? true,
    createdAt,
    updatedAt: createdAt,
  };
}

export function createGalleryItem(payload: {
  title: string;
  type: string;
  body: string;
  image: string;
  published?: boolean;
}): GalleryItem {
  const createdAt = now();
  return {
    id: newId("gal"),
    title: payload.title.trim(),
    type: payload.type.trim() || "Clinic",
    body: payload.body.trim(),
    image: payload.image.trim(),
    published: payload.published ?? true,
    createdAt,
    updatedAt: createdAt,
  };
}

export function createQaItem(payload: {
  question: string;
  answer: string;
  published?: boolean;
}): QaItem {
  const createdAt = now();
  return {
    id: newId("qa"),
    question: payload.question.trim(),
    answer: payload.answer.trim(),
    published: payload.published ?? true,
    createdAt,
    updatedAt: createdAt,
  };
}

export function createUploadedPrescription(payload: {
  patientId?: string;
  patientName: string;
  phone?: string;
  fileUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  notes?: string;
  createdByStaffId: string;
}): UploadedPrescription {
  const createdAt = now();
  return {
    id: newId("uprx"),
    patientId: payload.patientId,
    patientName: payload.patientName.trim(),
    phone: payload.phone ? normalizePhone(payload.phone) : undefined,
    fileUrl: payload.fileUrl,
    fileName: payload.fileName,
    mimeType: payload.mimeType,
    sizeBytes: payload.sizeBytes,
    notes: payload.notes?.trim() || undefined,
    createdByStaffId: payload.createdByStaffId,
    createdAt,
    updatedAt: createdAt,
  };
}

export function todayDate() {
  return new Date().toISOString().slice(0, 10);
}

export function isSameDate(dateString?: string, compareDate = todayDate()) {
  if (!dateString) return false;
  return dateString.slice(0, 10) === compareDate;
}

export function toPublicContent(store: ClinicStore) {
  return {
    profile: store.profile,
    cms: store.cms,
    blogs: store.blogs.filter((item) => item.published),
    gallery: store.gallery.filter((item) => item.published),
    qa: store.qa.filter((item) => item.published),
  };
}
