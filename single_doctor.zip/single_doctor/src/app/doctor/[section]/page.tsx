import { redirect } from "next/navigation";
import { DoctorShell } from "@/components/doctor-panel/DoctorShell";
import { canAccessDoctorSection } from "@/lib/auth";
import { sanitizeStaff } from "@/lib/clinic-store";

export const dynamic = "force-dynamic";

export default async function DoctorSectionPage({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params;
  const access = await canAccessDoctorSection(section);
  if (!access.staff) redirect("/admin");
  if (!access.allowed) redirect(access.redirectTo);
  return <DoctorShell initialSection={section} initialStaff={sanitizeStaff(access.staff)} />;
}
