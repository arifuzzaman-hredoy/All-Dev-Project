import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  BookOpenText,
  CalendarCheck,
  HeartPulse,
  ShieldAlert,
  Sparkles,
  Stethoscope,
} from "lucide-react";

import { readStore } from "@/lib/clinic-store";

export const dynamic = "force-dynamic";

type BlogDetailPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export async function generateMetadata({ params }: BlogDetailPageProps) {
  const { slug } = await params;
  const store = await readStore();
  const blog = store.blogs.find((item) => item.slug === slug && item.published);

  return {
    title: blog
      ? `${blog.title} | ${store.profile.doctorName}`
      : `Health Advice | ${store.profile.doctorName}`,
    description: blog?.body ?? "Health advice by doctor.",
  };
}

export default async function BlogDetailPage({ params }: BlogDetailPageProps) {
  const { slug } = await params;
  const store = await readStore();
  const blog = store.blogs.find((item) => item.slug === slug && item.published);

  if (!blog) {
    notFound();
  }

  const paragraphs = blog.content && blog.content.length > 0 ? blog.content : [blog.body];

  return (
    <main className="min-h-screen overflow-hidden bg-[#F5F7F8] text-[#1B3A44]">
      <section className="relative isolate overflow-hidden border-b border-[#D7E0E4] px-4 py-12 sm:px-6 lg:px-8">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.105)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.105)_1px,transparent_1px)] bg-[size:46px_46px]" />
          <div className="absolute left-[-10%] top-[-35%] h-[420px] w-[420px] rounded-full bg-[#7FBAC6]/25 blur-3xl" />
          <div className="absolute bottom-[-35%] right-[-10%] h-[520px] w-[520px] rounded-full bg-[#D7E0E4]/80 blur-3xl" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_18%,rgba(46,126,149,0.1),transparent_30%),linear-gradient(180deg,rgba(245,247,248,0.88),rgba(245,247,248,0.98))]" />
          <HeartPulse className="absolute left-[8%] top-[26%] h-16 w-16 rotate-[-12deg] text-[#2E7E95]/[0.06]" />
          <Stethoscope className="absolute right-[10%] top-[20%] h-20 w-20 rotate-[10deg] text-[#2E7E95]/[0.06]" />
        </div>

        <div className="relative mx-auto max-w-5xl">
          <Link href="/#blogs" className="group inline-flex items-center gap-2 text-sm font-extrabold text-[#2E7E95]">
            <ArrowLeft className="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-1" />
            Back to Blogs
          </Link>

          <div className="mt-10 max-w-4xl">
            <div className="inline-flex items-center gap-2 border border-[#7FBAC6]/50 bg-white/76 px-4 py-2 text-xs font-extrabold uppercase tracking-[0.18em] text-[#2E7E95] shadow-[0_16px_45px_rgba(27,58,68,0.06)] backdrop-blur">
              <BookOpenText className="h-4 w-4" />
              {blog.category}
            </div>

            <h1 className="mt-6 text-4xl font-extrabold leading-[1.08] tracking-[-0.05em] sm:text-5xl lg:text-6xl">
              <span className="bg-gradient-to-r from-[#1B3A44] via-[#2E7E95] to-[#1B3A44] bg-clip-text text-transparent">
                {blog.title}
              </span>
            </h1>

            <p className="mt-6 max-w-3xl text-base leading-8 text-[#1B3A44]/72 sm:text-lg">
              {blog.body}
            </p>
          </div>
        </div>
      </section>

      <section className="relative px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-5xl gap-6">
          <div className="relative overflow-hidden border border-[#D7E0E4]/85 bg-white/82 p-5 shadow-[0_18px_55px_rgba(27,58,68,0.06)] backdrop-blur">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#2E7E95] to-transparent" />
            <div className="flex gap-4">
              <ShieldAlert className="mt-1 h-5 w-5 shrink-0 text-[#2E7E95]" />
              <p className="text-sm leading-7 text-[#1B3A44]/72">
                This article is for general health education only and does not replace a medical consultation. For personal diagnosis, treatment, or emergency symptoms, please consult a qualified doctor or the nearest emergency service.
              </p>
            </div>
          </div>

          <article className="relative overflow-hidden border border-white/85 bg-white p-6 shadow-[0_24px_80px_rgba(27,58,68,0.075)] sm:p-8 lg:p-10">
            <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-[#7FBAC6]/16 blur-3xl" />
            <div className="absolute bottom-[-90px] left-[-90px] h-60 w-60 rounded-full bg-[#D7E0E4]/75 blur-3xl" />
            <div className="relative mb-8 flex items-center gap-3 border-b border-[#D7E0E4] pb-5">
              <Sparkles className="h-5 w-5 text-[#d99b45]" />
              <p className="text-sm font-extrabold uppercase tracking-[0.16em] text-[#2E7E95]">Health Education</p>
            </div>
            <div className="relative grid gap-6 text-base leading-8 text-[#1B3A44]/76 sm:text-lg sm:leading-9">
              {paragraphs.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </div>
          </article>

          <div className="relative overflow-hidden bg-[#1B3A44] p-6 text-white shadow-[0_24px_80px_rgba(27,58,68,0.16)] sm:p-7">
            <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(127,186,198,0.07)_1px,transparent_1px),linear-gradient(to_bottom,rgba(127,186,198,0.07)_1px,transparent_1px)] bg-[size:34px_34px]" />
            <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-[#7FBAC6]/16 blur-3xl" />
            <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xl font-extrabold tracking-[-0.03em]">Need a personal review?</p>
                <p className="mt-2 text-sm leading-6 text-white/70">Share your concern through the appointment form.</p>
              </div>
              <Link href="/#appointment" className="group inline-flex items-center justify-center gap-2 bg-white px-5 py-3 text-sm font-extrabold text-[#1B3A44] transition hover:bg-[#7FBAC6]">
                Book Appointment
                <CalendarCheck className="h-4 w-4" />
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
