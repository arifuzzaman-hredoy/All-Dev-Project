import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Dr. Kawsar Ahmed | General & Lifestyle Physician",
  description:
    "Personal brand website for Dr. Kawsar Ahmed, General & Lifestyle Physician in Rangpur.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full scroll-smooth antialiased">
      <body className="min-h-full">{children}</body>
    </html>
  );
}
