import Link from "next/link";
import { ArrowLeft, MessageCircleQuestion } from "lucide-react";
import { readStore } from "@/lib/clinic-store";

export const dynamic = "force-dynamic";
export const metadata = { title: "Q&A | CareBridge", description: "Common patient questions and answers." };

export default async function QaPage() {
  const store = await readStore();
  const qa = store.qa.filter((item) => item.published).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return <main className="min-h-screen bg-[#F5F7F8] px-4 py-10 text-[#1B3A44] sm:px-6 lg:px-8"><section className="mx-auto max-w-4xl"><Link href="/#qa" className="inline-flex items-center gap-2 text-sm font-extrabold text-[#2E7E95]"><ArrowLeft className="h-4 w-4" />Back to home</Link><div className="mt-8 rounded-[2rem] border border-[#D7E0E4] bg-white p-6 shadow-[0_24px_80px_rgba(27,58,68,0.07)] sm:p-8"><p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-[#2E7E95]"><MessageCircleQuestion className="h-4 w-4" />Q&A</p><h1 className="mt-3 text-4xl font-black tracking-[-0.05em]">Patient questions</h1><p className="mt-3 text-sm leading-7 text-[#607384]">CMS থেকে publish করা Q&A গুলো এখানে live দেখাবে।</p></div><div className="mt-8 grid gap-4">{qa.map((item) => <article key={item.id} className="rounded-[1.5rem] border border-[#D7E0E4] bg-white p-5 shadow-sm"><h2 className="text-lg font-black tracking-[-0.03em]">{item.question}</h2><p className="mt-3 text-sm leading-7 text-[#607384]">{item.answer}</p></article>)}</div>{!qa.length && <div className="mt-8 rounded-[1.5rem] border border-dashed border-[#D7E0E4] bg-white p-8 text-center text-sm font-bold text-[#607384]">No published Q&A yet.</div>}</section></main>;
}
