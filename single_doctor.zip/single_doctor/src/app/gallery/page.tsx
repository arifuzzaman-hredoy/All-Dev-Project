import Link from "next/link";
import { ArrowLeft, GalleryHorizontal } from "lucide-react";
import { readStore } from "@/lib/clinic-store";

export const dynamic = "force-dynamic";
export const metadata = { title: "Gallery | CareBridge", description: "Clinic and doctor gallery." };

export default async function GalleryPage() {
  const store = await readStore();
  const gallery = store.gallery.filter((item) => item.published).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return <main className="min-h-screen bg-[#F5F7F8] px-4 py-10 text-[#1B3A44] sm:px-6 lg:px-8"><section className="mx-auto max-w-7xl"><Link href="/#gallery" className="inline-flex items-center gap-2 text-sm font-extrabold text-[#2E7E95]"><ArrowLeft className="h-4 w-4" />Back to home</Link><div className="mt-8 rounded-[2rem] border border-[#D7E0E4] bg-white p-6 shadow-[0_24px_80px_rgba(27,58,68,0.07)] sm:p-8"><p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-[#2E7E95]"><GalleryHorizontal className="h-4 w-4" />Gallery</p><h1 className="mt-3 text-4xl font-black tracking-[-0.05em]">Clinic gallery</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-[#607384]">CMS থেকে publish করা gallery image গুলো এখানে live দেখাবে।</p></div><div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">{gallery.map((item) => <article key={item.id} className="overflow-hidden rounded-[1.5rem] border border-[#D7E0E4] bg-white shadow-sm"><div className="h-64 bg-cover bg-center" style={{ backgroundImage: `url(${item.image})` }} /><div className="p-5"><p className="text-xs font-black uppercase tracking-[0.14em] text-[#2E7E95]">{item.type}</p><h2 className="mt-2 text-xl font-black tracking-[-0.03em]">{item.title}</h2><p className="mt-2 text-sm leading-7 text-[#607384]">{item.body}</p></div></article>)}</div>{!gallery.length && <div className="mt-8 rounded-[1.5rem] border border-dashed border-[#D7E0E4] bg-white p-8 text-center text-sm font-bold text-[#607384]">No published gallery photos yet.</div>}</section></main>;
}
