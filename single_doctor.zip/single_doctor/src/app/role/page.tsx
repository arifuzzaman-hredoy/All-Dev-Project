import { LoginPage } from "@/components/doctor-panel/LoginPage";

export default function RoleLoginPage() {
  return <LoginPage mode="role" />;
}
