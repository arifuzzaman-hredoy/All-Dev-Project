import { PatientAccountPage } from "@/components/PatientAccountPage";

export default function AccountPage() {
  return <PatientAccountPage />;
}
