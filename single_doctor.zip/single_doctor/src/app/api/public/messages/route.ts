import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createMessage, findPatientByIdentity, mutateStore } from "@/lib/clinic-store";

export const runtime = "nodejs";

type MessageBody = {
  name?: string;
  phone?: string;
  email?: string;
  message?: string;
};

export async function POST(request: Request) {
  try {
    const body = await readJsonBody<MessageBody>(request);
    const name = textValue(body.name);
    const message = textValue(body.message);
    if (!name || !message) return badRequest("Name and message are required.");

    const created = await mutateStore((store) => {
      const patient = findPatientByIdentity(store, body.phone, body.email);
      const msg = createMessage({
        patientId: patient?.id,
        name,
        phone: body.phone,
        email: body.email,
        message,
      });
      store.messages.unshift(msg);
      return msg;
    });

    return ok({ message: created }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}
