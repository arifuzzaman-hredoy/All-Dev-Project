import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createPatientFromPayload, findPatientByIdentity, mutateStore, sanitizePatient } from "@/lib/clinic-store";
import type { Gender } from "@/lib/clinic-types";

export const runtime = "nodejs";

type RegisterBody = {
  name?: string;
  email?: string;
  phone?: string;
  password?: string;
  age?: string;
  gender?: Gender;
  address?: string;
};

export async function POST(request: Request) {
  try {
    const body = await readJsonBody<RegisterBody>(request);
    const name = textValue(body.name);
    const phone = textValue(body.phone);
    const password = body.password || "";
    if (!name || !phone || password.length < 6) {
      return badRequest("Name, phone and a minimum 6 character password are required.");
    }

    const patient = await mutateStore((store) => {
      const existing = findPatientByIdentity(store, phone, body.email);
      if (existing) throw new Error("A patient account already exists with this phone or email.");
      const created = createPatientFromPayload(
        {
          name,
          phone,
          email: body.email,
          password,
          age: body.age,
          gender: body.gender,
          address: body.address,
        },
        store.patients.length,
      );
      store.patients.unshift(created);
      return created;
    });

    return ok({ patient: sanitizePatient(patient) }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message.includes("already exists")) return badRequest(error.message);
    return serverError(error);
  }
}
