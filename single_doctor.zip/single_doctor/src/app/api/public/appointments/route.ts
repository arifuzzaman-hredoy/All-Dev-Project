import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createAppointment, createPatientFromPayload, findPatientByIdentity, mutateStore } from "@/lib/clinic-store";
import type { Gender } from "@/lib/clinic-types";

export const runtime = "nodejs";

type AppointmentBody = {
  patientName?: string;
  name?: string;
  phone?: string;
  age?: string;
  gender?: Gender;
  preferredDate?: string;
  consultationType?: string;
  message?: string;
};

export async function POST(request: Request) {
  try {
    const body = await readJsonBody<AppointmentBody>(request);
    const patientName = textValue(body.patientName || body.name);
    const phone = textValue(body.phone);
    const preferredDate = textValue(body.preferredDate);
    if (!patientName || !phone || !preferredDate) {
      return badRequest("Patient name, phone and preferred date are required.");
    }

    const appointment = await mutateStore((store) => {
      let patient = findPatientByIdentity(store, phone);
      if (!patient) {
        patient = createPatientFromPayload(
          {
            name: patientName,
            phone,
            age: body.age,
            gender: body.gender,
          },
          store.patients.length,
        );
        store.patients.unshift(patient);
      }
      const created = createAppointment({
        patientId: patient.id,
        patientName,
        phone,
        age: body.age,
        gender: body.gender,
        preferredDate,
        consultationType: body.consultationType || "general",
        message: body.message,
        source: "public",
      });
      store.appointments.unshift(created);
      return created;
    });

    return ok({ appointment }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}
