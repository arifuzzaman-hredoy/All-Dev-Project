import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createPatientFromPayload, findPatientByIdentity, mutateStore, readStore, sanitizePatients } from "@/lib/clinic-store";
import type { Gender } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  name?: string;
  email?: string;
  phone?: string;
  password?: string;
  age?: string;
  gender?: Gender;
  address?: string;
};

export async function GET() {
  const auth = await requireStaff("patients:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ patients: sanitizePatients(store.patients), prescriptions: store.prescriptions, appointments: store.appointments });
}

export async function POST(request: Request) {
  const auth = await requireStaff("patients:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const name = textValue(body.name);
    const phone = textValue(body.phone);
    if (!name || !phone) return badRequest("Name and phone are required.");

    const patient = await mutateStore((store) => {
      const existing = findPatientByIdentity(store, phone, body.email);
      if (existing) throw new Error("Patient already exists.");
      const created = createPatientFromPayload(
        { name, phone, email: body.email, password: body.password, age: body.age, gender: body.gender, address: body.address },
        store.patients.length,
      );
      store.patients.unshift(created);
      return created;
    });

    return ok({ patient: sanitizePatients([patient])[0] }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message.includes("exists")) return badRequest(error.message);
    return serverError(error);
  }
}
