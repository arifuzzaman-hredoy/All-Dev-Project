import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { applyRolePermissions, hashPassword, mutateStore, readStore, sanitizePatients, sanitizeStaffList, newId } from "@/lib/clinic-store";
import type { Permission, StaffRole, StaffUser } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  id?: string;
  name?: string;
  email?: string;
  password?: string;
  role?: StaffRole;
  permissions?: Permission[];
  canLogin?: boolean;
  status?: "active" | "disabled";
};

export async function GET() {
  const auth = await requireStaff("users:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ staff: sanitizeStaffList(store.staff), patients: sanitizePatients(store.patients) });
}

export async function POST(request: Request) {
  const auth = await requireStaff("users:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const name = textValue(body.name);
    const email = textValue(body.email).toLowerCase();
    const password = body.password || "";
    const role = body.role || "ASSISTANT";
    if (!name || !email || password.length < 8) return badRequest("Name, email and 8+ character password are required.");

    const staff = await mutateStore((store) => {
      if (store.staff.some((item) => item.email.toLowerCase() === email)) throw new Error("Staff email already exists.");
      const createdAt = new Date().toISOString();
      const item: StaffUser = {
        id: newId("staff"),
        name,
        email,
        passwordHash: hashPassword(password),
        role,
        permissions: applyRolePermissions(role, body.permissions),
        canLogin: body.canLogin ?? true,
        status: body.status || "active",
        createdAt,
        updatedAt: createdAt,
      };
      store.staff.unshift(item);
      return item;
    });
    return ok({ staff: sanitizeStaffList([staff])[0] }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message.includes("exists")) return badRequest(error.message);
    return serverError(error);
  }
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("users:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const id = textValue(body.id);
    if (!id) return badRequest("Staff id is required.");
    const staff = await mutateStore((store) => {
      const item = store.staff.find((entry) => entry.id === id);
      if (!item) throw new Error("Staff not found.");
      if (body.name !== undefined) item.name = textValue(body.name);
      if (body.role) item.role = body.role;
      if (body.permissions) item.permissions = applyRolePermissions(item.role, body.permissions);
      if (body.canLogin !== undefined) item.canLogin = body.canLogin;
      if (body.status) item.status = body.status;
      if (body.password && body.password.length >= 8) item.passwordHash = hashPassword(body.password);
      item.updatedAt = new Date().toISOString();
      return item;
    });
    return ok({ staff: sanitizeStaffList([staff])[0] });
  } catch (error) {
    return serverError(error);
  }
}
