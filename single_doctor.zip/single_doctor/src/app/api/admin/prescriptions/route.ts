import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createPrescription, mutateStore, readStore, sanitizePatients } from "@/lib/clinic-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  patientId?: string;
  appointmentId?: string;
  diagnosis?: string;
  vitals?: string;
  medicines?: string;
  tests?: string;
  advice?: string;
  followUpDate?: string;
  notes?: string;
  templateId?: string;
};

export async function GET(request: Request) {
  const auth = await requireStaff("prescriptions:read");
  if (auth.response) return auth.response;
  const url = new URL(request.url);
  const patientId = url.searchParams.get("patientId");
  const store = await readStore();
  const prescriptions = patientId ? store.prescriptions.filter((item) => item.patientId === patientId) : store.prescriptions;
  return ok({ prescriptions, patients: sanitizePatients(store.patients), profile: store.profile });
}

export async function POST(request: Request) {
  const auth = await requireStaff("prescriptions:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const patientId = textValue(body.patientId);
    const diagnosis = textValue(body.diagnosis);
    const medicines = textValue(body.medicines);
    if (!patientId || !diagnosis || !medicines) return badRequest("Patient, diagnosis and medicines are required.");

    const prescription = await mutateStore((store) => {
      const patient = store.patients.find((item) => item.id === patientId);
      if (!patient) throw new Error("Patient not found.");
      const created = createPrescription({
        patient,
        appointmentId: body.appointmentId,
        diagnosis,
        vitals: body.vitals,
        medicines,
        tests: body.tests,
        advice: body.advice,
        followUpDate: body.followUpDate,
        notes: body.notes,
        templateId: body.templateId,
        createdByStaffId: auth.staff.id,
      });
      store.prescriptions.unshift(created);
      patient.lastVisitAt = created.createdAt;
      patient.updatedAt = created.createdAt;
      if (body.appointmentId) {
        const appointment = store.appointments.find((item) => item.id === body.appointmentId);
        if (appointment) {
          appointment.status = "completed";
          appointment.updatedAt = created.createdAt;
        }
      }
      return created;
    });

    return ok({ prescription }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}
