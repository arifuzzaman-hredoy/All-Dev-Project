import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { requireStaff } from "@/lib/auth";
import { badRequest, ok, serverError } from "@/lib/api-utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const maxUploadBytes = 5 * 1024 * 1024;
const allowedTypes: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf",
};

export async function POST(request: Request) {
  const auth = await requireStaff();
  if (auth.response) return auth.response;
  if (!auth.staff.permissions.includes("cms:write") && !auth.staff.permissions.includes("prescriptions:write")) {
    return badRequest("Upload permission is required.");
  }

  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return badRequest("Upload file is required.");
    if (file.size <= 0) return badRequest("Uploaded file is empty.");
    if (file.size > maxUploadBytes) return badRequest("Upload file must be 5MB or smaller.");

    const extension = allowedTypes[file.type];
    if (!extension) return badRequest("Only JPG, PNG, WEBP and PDF files are allowed.");

    const uploadDir = path.join(process.cwd(), "public", "uploads", "clinic");
    await mkdir(uploadDir, { recursive: true });
    const safeName = `${Date.now()}-${randomBytes(6).toString("hex")}.${extension}`;
    const diskPath = path.join(uploadDir, safeName);
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(diskPath, buffer);

    return ok({
      fileUrl: `/uploads/clinic/${safeName}`,
      fileName: file.name,
      mimeType: file.type,
      sizeBytes: file.size,
    }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}
