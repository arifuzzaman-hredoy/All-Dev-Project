import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { mutateStore, readStore } from "@/lib/clinic-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  id?: string;
  reply?: string;
  status?: "new" | "seen" | "replied";
};

export async function GET() {
  const auth = await requireStaff("messages:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ messages: store.messages });
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("messages:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const id = textValue(body.id);
    if (!id) return badRequest("Message id is required.");
    const message = await mutateStore((store) => {
      const item = store.messages.find((entry) => entry.id === id);
      if (!item) throw new Error("Message not found.");
      if (body.reply !== undefined) item.reply = textValue(body.reply);
      if (body.status) item.status = body.status;
      if (body.reply) item.status = "replied";
      item.updatedAt = new Date().toISOString();
      return item;
    });
    return ok({ message });
  } catch (error) {
    return serverError(error);
  }
}
