import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createAppointment, createPatientFromPayload, findPatientByIdentity, mutateStore, readStore, sanitizePatients } from "@/lib/clinic-store";
import type { AppointmentStatus, Gender } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  id?: string;
  patientName?: string;
  phone?: string;
  age?: string;
  gender?: Gender;
  preferredDate?: string;
  consultationType?: string;
  message?: string;
  status?: AppointmentStatus;
};

export async function GET() {
  const auth = await requireStaff("appointments:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ appointments: store.appointments, patients: sanitizePatients(store.patients) });
}

export async function POST(request: Request) {
  const auth = await requireStaff("appointments:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const patientName = textValue(body.patientName);
    const phone = textValue(body.phone);
    const preferredDate = textValue(body.preferredDate);
    if (!patientName || !phone || !preferredDate) return badRequest("Patient name, phone and date are required.");

    const appointment = await mutateStore((store) => {
      let patient = findPatientByIdentity(store, phone);
      if (!patient) {
        patient = createPatientFromPayload(
          { name: patientName, phone, age: body.age, gender: body.gender },
          store.patients.length,
        );
        store.patients.unshift(patient);
      }
      const created = createAppointment({
        patientId: patient.id,
        patientName,
        phone,
        age: body.age,
        gender: body.gender,
        preferredDate,
        consultationType: body.consultationType || "general",
        message: body.message,
        source: "doctor_panel",
      });
      store.appointments.unshift(created);
      return created;
    });

    return ok({ appointment }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("appointments:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Body>(request);
    const id = textValue(body.id);
    if (!id) return badRequest("Appointment id is required.");
    const appointment = await mutateStore((store) => {
      const item = store.appointments.find((entry) => entry.id === id);
      if (!item) throw new Error("Appointment not found.");
      if (body.status) item.status = body.status;
      if (body.preferredDate) item.preferredDate = body.preferredDate;
      if (body.message !== undefined) item.message = body.message;
      item.updatedAt = new Date().toISOString();
      return item;
    });
    return ok({ appointment });
  } catch (error) {
    return serverError(error);
  }
}
