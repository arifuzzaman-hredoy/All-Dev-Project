import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createUploadedPrescription, mutateStore, readStore, sanitizePatients } from "@/lib/clinic-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type UploadPrescriptionBody = {
  patientId?: string;
  patientName?: string;
  phone?: string;
  fileUrl?: string;
  fileName?: string;
  mimeType?: string;
  sizeBytes?: number;
  notes?: string;
};

export async function GET() {
  const auth = await requireStaff("prescriptions:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ uploadedPrescriptions: store.uploadedPrescriptions, patients: sanitizePatients(store.patients) });
}

export async function POST(request: Request) {
  const auth = await requireStaff("prescriptions:write");
  if (auth.response) return auth.response;

  try {
    const body = await readJsonBody<UploadPrescriptionBody>(request);
    const fileUrl = textValue(body.fileUrl);
    const fileName = textValue(body.fileName);
    const mimeType = textValue(body.mimeType);
    if (!fileUrl || !fileName || !mimeType || !body.sizeBytes) return badRequest("Uploaded file information is required.");

    const created = await mutateStore((store) => {
      const patient = body.patientId ? store.patients.find((item) => item.id === body.patientId) : undefined;
      const patientName = patient?.name || textValue(body.patientName);
      if (!patientName) throw new Error("Patient name is required.");
      const upload = createUploadedPrescription({
        patientId: patient?.id,
        patientName,
        phone: patient?.phone || body.phone,
        fileUrl,
        fileName,
        mimeType,
        sizeBytes: body.sizeBytes || 0,
        notes: body.notes,
        createdByStaffId: auth.staff.id,
      });
      store.uploadedPrescriptions.unshift(upload);
      if (patient) {
        patient.lastVisitAt = upload.createdAt;
        patient.updatedAt = upload.createdAt;
      }
      return upload;
    });

    return ok({ uploadedPrescription: created }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}
