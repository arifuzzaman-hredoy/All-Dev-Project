import { requireStaff } from "@/lib/auth";
import { badRequest, ok, readJsonBody, serverError, textValue } from "@/lib/api-utils";
import { createBlogPost, createGalleryItem, createQaItem, mutateStore, readStore } from "@/lib/clinic-store";
import type { BlogPost, GalleryItem, QaItem } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Collection = "blogs" | "gallery" | "qa";

type ContentBody = Partial<BlogPost & GalleryItem & QaItem> & {
  collection?: Collection;
  id?: string;
  published?: boolean | string;
};

function normalizePublished(value: unknown) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value === "true" || value === "on";
  return true;
}

function getCollection(body: ContentBody): Collection | null {
  return body.collection === "blogs" || body.collection === "gallery" || body.collection === "qa" ? body.collection : null;
}

export async function GET() {
  const auth = await requireStaff("cms:write");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ blogs: store.blogs, gallery: store.gallery, qa: store.qa, uploadedPrescriptions: store.uploadedPrescriptions });
}

export async function POST(request: Request) {
  const auth = await requireStaff("cms:write");
  if (auth.response) return auth.response;

  try {
    const body = await readJsonBody<ContentBody>(request);
    const collection = getCollection(body);
    if (!collection) return badRequest("Valid collection is required.");

    const created = await mutateStore((store) => {
      if (collection === "blogs") {
        const title = textValue(body.title);
        const category = textValue(body.category);
        const postBody = textValue(body.body);
        if (!title || !postBody) throw new Error("Blog title and summary are required.");
        const post = createBlogPost({
          title,
          slug: textValue(body.slug),
          category,
          body: postBody,
          content: textValue(body.content),
          image: textValue(body.image),
          published: normalizePublished(body.published),
        });
        if (store.blogs.some((item) => item.slug === post.slug)) throw new Error("Blog slug already exists.");
        store.blogs.unshift(post);
        return post;
      }

      if (collection === "gallery") {
        const title = textValue(body.title);
        const image = textValue(body.image);
        if (!title || !image) throw new Error("Gallery title and image are required.");
        const item = createGalleryItem({
          title,
          type: textValue(body.type),
          body: textValue(body.body),
          image,
          published: normalizePublished(body.published),
        });
        store.gallery.unshift(item);
        return item;
      }

      const question = textValue(body.question);
      const answer = textValue(body.answer);
      if (!question || !answer) throw new Error("Question and answer are required.");
      const item = createQaItem({ question, answer, published: normalizePublished(body.published) });
      store.qa.unshift(item);
      return item;
    });

    return ok({ item: created }, { status: 201 });
  } catch (error) {
    return serverError(error);
  }
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("cms:write");
  if (auth.response) return auth.response;

  try {
    const body = await readJsonBody<ContentBody>(request);
    const collection = getCollection(body);
    const id = textValue(body.id);
    if (!collection || !id) return badRequest("Collection and id are required.");

    const updated = await mutateStore((store) => {
      const list = store[collection] as Array<BlogPost | GalleryItem | QaItem>;
      const item = list.find((entry) => entry.id === id);
      if (!item) throw new Error("Content item not found.");

      if ("title" in item && body.title !== undefined) item.title = textValue(body.title);
      if ("slug" in item && body.slug !== undefined) {
        const slug = textValue(body.slug)
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "");
        if (!slug) throw new Error("Slug cannot be empty.");
        if (store.blogs.some((entry) => entry.id !== id && entry.slug === slug)) throw new Error("Blog slug already exists.");
        item.slug = slug;
      }
      if ("category" in item && body.category !== undefined) item.category = textValue(body.category);
      if ("type" in item && body.type !== undefined) item.type = textValue(body.type);
      if ("body" in item && body.body !== undefined) item.body = textValue(body.body);
      if ("image" in item && body.image !== undefined) item.image = textValue(body.image);
      if ("question" in item && body.question !== undefined) item.question = textValue(body.question);
      if ("answer" in item && body.answer !== undefined) item.answer = textValue(body.answer);
      if ("content" in item && body.content !== undefined) {
        item.content = textValue(body.content)
          .split(/\n{2,}/)
          .map((part) => part.trim())
          .filter(Boolean);
      }
      if (body.published !== undefined) item.published = normalizePublished(body.published);
      item.updatedAt = new Date().toISOString();
      return item;
    });

    return ok({ item: updated });
  } catch (error) {
    return serverError(error);
  }
}

export async function DELETE(request: Request) {
  const auth = await requireStaff("cms:write");
  if (auth.response) return auth.response;

  try {
    const body = await readJsonBody<ContentBody>(request);
    const collection = getCollection(body);
    const id = textValue(body.id);
    if (!collection || !id) return badRequest("Collection and id are required.");

    await mutateStore((store) => {
      const list = store[collection] as Array<BlogPost | GalleryItem | QaItem>;
      const index = list.findIndex((entry) => entry.id === id);
      if (index === -1) throw new Error("Content item not found.");
      list.splice(index, 1);
    });

    return ok({ deleted: true });
  } catch (error) {
    return serverError(error);
  }
}
