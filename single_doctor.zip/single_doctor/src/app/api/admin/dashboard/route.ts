import { requireStaff } from "@/lib/auth";
import { isSameDate, readStore, todayDate } from "@/lib/clinic-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireStaff("dashboard:read");
  if (auth.response) return auth.response;

  const store = await readStore();
  const today = todayDate();
  const todayAppointments = store.appointments.filter((item) => item.preferredDate === today);
  const completedToday = store.appointments.filter((item) => item.status === "completed" && isSameDate(item.updatedAt, today));
  const nextSeven = new Date();
  nextSeven.setDate(nextSeven.getDate() + 7);
  const dueFollowUps = store.prescriptions.filter((item) => {
    if (!item.followUpDate) return false;
    const date = new Date(item.followUpDate);
    return date >= new Date(today) && date <= nextSeven;
  });

  const weekly = Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - index));
    const key = date.toISOString().slice(0, 10);
    return {
      date: key,
      count: store.appointments.filter((item) => item.preferredDate === key).length,
    };
  });

  return Response.json({
    ok: true,
    stats: {
      todayAppointments: todayAppointments.length,
      waitingPatients: store.appointments.filter((item) => item.status === "pending").length,
      completedToday: completedToday.length,
      followUpDue: dueFollowUps.length,
      patients: store.patients.length,
      messages: store.messages.filter((item) => item.status === "new").length,
    },
    weekly,
    latestAppointments: store.appointments.slice(0, 8),
    latestMessages: store.messages.slice(0, 5),
    dueFollowUps,
    profile: store.profile,
    cms: store.cms,
  });
}
