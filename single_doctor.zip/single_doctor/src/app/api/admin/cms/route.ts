import { requireStaff } from "@/lib/auth";
import { ok, readJsonBody, serverError } from "@/lib/api-utils";
import { mutateStore, readStore } from "@/lib/clinic-store";
import type { CmsContent } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireStaff("dashboard:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ cms: store.cms, profile: store.profile });
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("cms:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Partial<CmsContent>>(request);
    const cms = await mutateStore((store) => {
      store.cms = { ...store.cms, ...body, updatedAt: new Date().toISOString() };
      return store.cms;
    });
    return ok({ cms });
  } catch (error) {
    return serverError(error);
  }
}
