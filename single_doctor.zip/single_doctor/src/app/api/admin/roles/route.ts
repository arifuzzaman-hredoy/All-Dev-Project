import { requireStaff } from "@/lib/auth";
import { ok } from "@/lib/api-utils";
import { allPermissions, roleDefaultPermissions } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireStaff("roles:write");
  if (auth.response) return auth.response;
  return ok({ allPermissions, roleDefaultPermissions });
}
