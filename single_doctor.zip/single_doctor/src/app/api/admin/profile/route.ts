import { requireStaff } from "@/lib/auth";
import { ok, readJsonBody, serverError } from "@/lib/api-utils";
import { mutateStore, readStore } from "@/lib/clinic-store";
import type { DoctorProfile } from "@/lib/clinic-types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireStaff("dashboard:read");
  if (auth.response) return auth.response;
  const store = await readStore();
  return ok({ profile: store.profile });
}

export async function PATCH(request: Request) {
  const auth = await requireStaff("profile:write");
  if (auth.response) return auth.response;
  try {
    const body = await readJsonBody<Partial<DoctorProfile>>(request);
    const profile = await mutateStore((store) => {
      store.profile = { ...store.profile, ...body };
      return store.profile;
    });
    return ok({ profile });
  } catch (error) {
    return serverError(error);
  }
}
