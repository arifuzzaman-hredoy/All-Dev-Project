import { authenticateStaff, createSessionResponse } from "@/lib/auth";
import { badRequest, readJsonBody } from "@/lib/api-utils";

export const runtime = "nodejs";

type LoginBody = {
  email?: string;
  password?: string;
};

export async function POST(request: Request) {
  const body = await readJsonBody<LoginBody>(request);
  const email = body.email?.trim().toLowerCase() || "";
  const password = body.password || "";
  if (!email || !password) return badRequest("Email and password are required.");

  const staff = await authenticateStaff(email, password);
  if (!staff) return Response.json({ ok: false, error: "Invalid email or password." }, { status: 401 });
  return createSessionResponse(staff);
}
