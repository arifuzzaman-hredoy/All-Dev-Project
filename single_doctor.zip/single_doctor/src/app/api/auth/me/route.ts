import { getSafeCurrentStaff } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const staff = await getSafeCurrentStaff();
  if (!staff) return Response.json({ ok: false, staff: null }, { status: 401 });
  return Response.json({ ok: true, staff });
}
