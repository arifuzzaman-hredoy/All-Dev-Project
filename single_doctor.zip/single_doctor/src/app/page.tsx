import { DoctorHome } from "../components/DoctorHome";
import { readStore, toPublicContent } from "@/lib/clinic-store";

export const dynamic = "force-dynamic";

export default async function Home() {
  const store = await readStore();
  return <DoctorHome content={toPublicContent(store)} />;
}
