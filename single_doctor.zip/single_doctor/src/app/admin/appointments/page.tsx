import { redirect } from "next/navigation";

export default function AdminAppointmentsRedirectPage() {
  redirect("/doctor/appointments");
}
