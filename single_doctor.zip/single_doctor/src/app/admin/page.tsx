import { LoginPage } from "@/components/doctor-panel/LoginPage";

export default function AdminLoginPage() {
  return <LoginPage mode="admin" />;
}
