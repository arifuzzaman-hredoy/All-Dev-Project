import { redirect } from "next/navigation";

export default function AdminPrescriptionRedirectPage() {
  redirect("/doctor/prescription");
}
