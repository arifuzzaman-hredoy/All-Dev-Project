export const navItems = [
  "Home",
  "About",
  "Services",
  "Expertise",
  "Gallery",
  "Blogs",
  "Appointment",
  "Contact",
];

export const focusItems = [
  "Hypertension care",
  "Diabetes & endocrine care",
  "Lifestyle medicine",
  "Cardiovascular disease prevention",
  "Public health and research",
  "Ultrasonography support",
];

export const serviceItems = [
  {
    title: "Lifestyle Consultation",
    icon: "Leaf",
    body: "Practical guidance for diet, movement, sleep, stress, and sustainable daily routines.",
  },
  {
    title: "Hypertension Management",
    icon: "HeartPulse",
    body: "Risk-aware blood pressure care with follow-up planning and prevention counseling.",
  },
  {
    title: "Diabetes & Hormone Care",
    icon: "Syringe",
    body: "Support for glucose control, endocrine concerns, and habit-centered monitoring.",
  },
  {
    title: "Cardiovascular Risk Assessment",
    icon: "Activity",
    body: "Focused evaluation of heart-health risks and lifestyle factors that influence outcomes.",
  },
  {
    title: "General Medicine",
    icon: "Stethoscope",
    body: "Primary care for common health concerns with clear explanations and next steps.",
  },
  {
    title: "Public Health & Preventive Care",
    icon: "ShieldCheck",
    body: "Health education, screening awareness, and prevention-oriented medical advice.",
  },
  {
    title: "Ultrasonography Guidance",
    icon: "Microscope",
    body: "Clinically grounded support for ultrasound-related evaluation and interpretation.",
  },
  {
    title: "Follow-up Consultation",
    icon: "ClipboardCheck",
    body: "Continuity care that keeps treatment plans understandable, measured, and realistic.",
  },
];

export const timelineItems = [
  { title: "MBBS", body: "Rangpur Medical College" },
  { title: "MPH", body: "Public Health & Research" },
  { title: "CCH", body: "Hypertension & Cardiovascular Diseases" },
  { title: "CCD", body: "Diabetes & Endocrinology" },
  { title: "CMU", body: "Ultrasonography" },
  {
    title: "Senior Medical Officer",
    body: "Hypertension & Research Centre, Rangpur",
  },
];

export const galleryItems = [
  {
    title: "Doctor profile",
    type: "Profile",
    tone: "from-[#2E7E95] to-[#7FBAC6]",
    body: "A calm professional portrait for the doctor profile.",
    image: "/kawshersirhero.png",
  },
  {
    title: "Clinic environment",
    type: "Clinic",
    tone: "from-[#1B3A44] to-[#2E7E95]",
    body: "A clean setting for thoughtful consultation.",
    image: "/kawsharsirabout.png",
  },
  {
    title: "Awareness program",
    type: "Awareness",
    tone: "from-[#7FBAC6] to-[#D99B45]",
    body: "Community-centered prevention and awareness work.",
    image: "/kawsharsirmore.png",
  },
  {
    title: "Patient education",
    type: "Education",
    tone: "from-[#2E7E95] to-[#D7E0E4]",
    body: "Clear education for long-term health decisions.",
    image: "/kawsarsir1.jpeg",
  },
  {
    title: "Professional moments",
    type: "Profile",
    tone: "from-[#1B3A44] to-[#D7E0E4]",
    body: "Professional moments from clinical practice.",
    image: "/kawsharsirabout.png",
  },
  {
    title: "Research health camp",
    type: "Awareness",
    tone: "from-[#D99B45] to-[#2E7E95]",
    body: "Research-minded service beyond the chamber.",
    image: "/kawsharsirmore.png",
  },
];

export const galleryFilters = ["All", "Profile", "Clinic", "Awareness", "Education"];

export const blogItems = [
  {
    title: "Understanding High Blood Pressure",
    slug: "understanding-high-blood-pressure",
    category: "Hypertension",
    body: "How routine monitoring, medication adherence, and daily habits work together.",
    content: [
      "High blood pressure often develops quietly, so regular measurement is an important part of prevention. A single high reading does not always mean a diagnosis, but repeated elevated readings deserve a clinical review.",
      "Daily habits matter. Reducing excess salt, walking regularly, improving sleep, managing stress, and taking prescribed medicine consistently can all support healthier blood pressure control.",
      "Patients should bring previous prescriptions, recent blood pressure readings, and any lab reports to a consultation. This helps the doctor understand patterns instead of making decisions from one number only.",
    ],
  },
  {
    title: "Lifestyle Changes for Better Heart Health",
    slug: "lifestyle-changes-for-better-heart-health",
    category: "Lifestyle",
    body: "Small choices around food, movement, sleep, and stress can lower long-term risk.",
    content: [
      "Heart health is shaped by small choices repeated over time. Balanced meals, regular walking, tobacco avoidance, weight control, and adequate sleep can reduce cardiovascular risk.",
      "Lifestyle change should be practical. A plan that fits a patient's family routine, budget, and work schedule is more likely to continue than a strict plan that lasts only a few days.",
      "People with chest pain, shortness of breath, fainting, or severe weakness should seek urgent medical care immediately instead of waiting for a routine appointment.",
    ],
  },
  {
    title: "Diabetes Control: Daily Habits That Matter",
    slug: "diabetes-control-daily-habits",
    category: "Diabetes",
    body: "A simple look at glucose-friendly routines and when to seek medical review.",
    content: [
      "Diabetes care works best when medicine, food habits, activity, and monitoring are connected. Skipping follow-up can make it harder to notice patterns early.",
      "A daily routine may include consistent meal timing, portion awareness, regular walking, glucose checks when advised, and taking medicines exactly as prescribed.",
      "Bring glucose records and current medicines to follow-up visits. This helps adjust care safely and avoids guesswork.",
    ],
  },
  {
    title: "When Should You See a Doctor?",
    slug: "when-should-you-see-a-doctor",
    category: "General Medicine",
    body: "Symptoms and patterns that deserve a timely, calm clinical conversation.",
    content: [
      "Some symptoms are mild and short-lived, but repeated fever, unexplained weight loss, persistent pain, breathing difficulty, dizziness, or worsening weakness should be discussed with a doctor.",
      "A consultation is not only for severe illness. It can help patients understand symptoms, avoid unnecessary medicine use, and decide when tests are needed.",
      "Emergency symptoms such as severe chest pain, stroke-like weakness, severe breathing difficulty, or loss of consciousness need immediate hospital care.",
    ],
  },
  {
    title: "Preventive Health Checkup Guide",
    slug: "preventive-health-checkup-guide",
    category: "Prevention",
    body: "What routine checkups can reveal before health issues become harder to manage.",
    content: [
      "Preventive checkups help identify risk factors such as high blood pressure, high blood sugar, cholesterol problems, and early lifestyle-related concerns.",
      "The right checkup depends on age, family history, symptoms, current medicines, and previous reports. More tests are not always better; relevant tests are better.",
      "After receiving reports, patients should review results with a physician so numbers can be interpreted in context.",
    ],
  },
];

export const contactItems = [
  {
    icon: "MapPin",
    title: "Chamber / Workplace",
    body: "Hypertension & Research Centre, Rangpur",
  },
  { icon: "Phone", title: "Phone", body: "+8801672132837 " },
  { icon: "MessageCircle", title: "WhatsApp", body: "+8801672132837 " },
  { icon: "Mail", title: "Email", body: "contact@drkawsarahmed.com" },
  { icon: "Clock", title: "Visiting Hours", body: "To be updated" },
];
