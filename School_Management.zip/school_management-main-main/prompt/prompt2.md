You are working on an existing School Management System project.

The project structure is already created.
Do NOT modify the folder structure.

Only implement logic and code inside existing files.

Tech stack:

Next.js 16+
TypeScript
Prisma 6
PostgreSQL
Zod
JWT
bcryptjs

Architecture:

API Route
→ Validation
→ Service
→ Repository
→ Prisma
→ Database

Never query the database directly inside API routes.

1. Prisma Client

File:

src/lib/prisma.ts

Create a Prisma singleton client.

Example logic:

import { PrismaClient } from "@prisma/client"

export const prisma = new PrismaClient()

Ensure it works correctly in Next.js environment.

2. Authentication Logic

File:

src/lib/auth.ts

Implement:

hashPassword
comparePassword
generateToken
verifyToken

Use:

bcryptjs
jsonwebtoken

JWT payload:

{
 id,
 role
}

Token expiration:

7 days
3. Role Permissions

File:

src/lib/permissions.ts

Create helper functions:

hasRole(userRole, allowedRoles)
requireRole(request, roles)

Example:

ADMIN can create teachers
TEACHER can manage attendance
STUDENT can view results
4. API Response Helper

File:

src/utils/api-response.ts

Create helper functions:

success(data)
error(message)

Format:

{
 success: true,
 data
}

Error:

{
 success: false,
 message
}
5. Error Handler

File:

src/utils/error-handler.ts

Create centralized error handling.

Return proper HTTP status codes.

6. Pagination Utility

File:

src/utils/pagination.ts

Create function:

getPagination(page, limit)

Return:

skip
take
7. Zod Validation

Inside

src/validations

Create schemas.

Example:

Student:

createStudentSchema
updateStudentSchema

Fields:

name
email
rollNumber
classId
gender

Validate API input.

8. Repository Layer

Repositories contain database logic only.

Example file:

src/repositories/student.repository.ts

Functions:

findAll
findById
create
update
delete

Use Prisma queries.

Example:

prisma.student.findMany()
9. Service Layer

Services contain business logic.

Example:

src/services/student.service.ts

Functions:

getAllStudents
getStudentById
createStudent
updateStudent
deleteStudent

Services must call repositories.

Never call Prisma directly here.

10. Auth API

File:

src/app/api/v1/auth/login/route.ts

Logic:

1 verify email
2 compare password
3 generate JWT
4 return token

Response:

{
 success: true,
 token,
 user
}
11. Students API

File:

src/app/api/v1/students/route.ts

Implement:

GET
POST

Use:

student.service
student.schema
12. Student By ID API

File:

src/app/api/v1/students/[id]/route.ts

Implement:

GET
PATCH
DELETE
13. Teachers API

Implement:

GET
POST
PATCH
DELETE

Files:

teachers/route.ts
teachers/[id]/route.ts
14. Attendance Logic

Teacher can mark attendance.

File:

attendance/route.ts

POST attendance.

Fields:

studentId
classId
date
status

Status enum:

PRESENT
ABSENT
LATE
15. Results Logic

Teacher enters marks.

File:

results/route.ts

Constraint:

unique(studentId, examId, subjectId)
16. Fees System

Implement payment recording.

Files:

fees/categories
fees/payments

Features:

create fee category
record payment
check dues
17. Notices

Admin creates notices.

File:

notices/route.ts

Students and teachers can view notices.

18. Admissions

Public endpoint:

POST /api/v1/admissions

Admin actions:

approve
reject
19. Middleware

File:

src/middleware.ts

Responsibilities:

verify JWT
check role
protect routes

Protect:

/admin
/teacher
/student
20. Code Rules

Follow these rules strictly.

Use:

TypeScript types
Zod validation
Service layer
Repository layer

Never:

Direct Prisma query in API route

Always:

API → validation → service → repository
Final Objective

Implement the logic so the system fully supports:

Admin Panel
Teacher Panel
Student Panel
REST API
Flutter Mobile App

The system must be:

modular
scalable
production ready
Important Copilot Instruction

Do NOT create new folders.

Use only the existing project structure.

Implement logic inside the existing files.