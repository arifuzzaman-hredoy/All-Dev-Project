Next.js 16+

Prisma 6

PostgreSQL

API-first architecture

Web + Flutter mobile compatible

MASTER PROMPT
Build Production School Management System

You are a senior full-stack engineer.

Your task is to build a production-grade School Management System (ERP).

The system must follow:

Clean architecture

API-first design

Scalable folder structure

Role based access control

This backend will serve:

Next.js Web Admin Panel
Teacher Panel
Student Panel
Flutter Mobile App
1. Tech Stack

Use the following technologies:

Framework

Next.js 16+
App Router
TypeScript

Backend

Next.js API Routes
Prisma ORM (v6)
PostgreSQL

Validation

Zod

Authentication

JWT
bcryptjs

UI

TailwindCSS
shadcn/ui

Architecture

API First
Service Layer
Repository Layer
Validation Layer
Clean Architecture
2. Project Folder Structure

Follow this structure strictly.

src
│
├ app
│
│ ├ login
│ │ └ page.tsx
│
│ ├ unauthorized
│ │ └ page.tsx
│
│ ├ (panels)
│ │
│ │ ├ student
│ │ │
│ │ │ ├ dashboard
│ │ │ ├ profile
│ │ │ ├ attendance
│ │ │ ├ results
│ │ │ ├ timetable
│ │ │ ├ fees
│ │ │ └ notices
│ │
│ │ ├ teacher
│ │ │
│ │ │ ├ dashboard
│ │ │ ├ profile
│ │ │ ├ attendance
│ │ │ ├ students
│ │ │ ├ results
│ │ │ ├ timetable
│ │ │ └ notices
│ │
│ │ └ admin
│ │
│ │   ├ dashboard
│ │   ├ students
│ │   ├ teachers
│ │   ├ parents
│ │   ├ classes
│ │   ├ subjects
│ │   ├ teacher-subjects
│ │   ├ attendance
│ │   ├ exams
│ │   ├ results
│ │   ├ fees
│ │   ├ timetable
│ │   ├ notices
│ │   └ admissions
│
│ └ api
│   └ v1
│
│     ├ auth
│     ├ users
│     ├ students
│     ├ teachers
│     ├ parents
│     ├ classes
│     ├ subjects
│     ├ teacher-subjects
│     ├ attendance
│     ├ exams
│     ├ results
│     ├ fees
│     ├ timetable
│     ├ notices
│     └ admissions
│
├ components
│ ├ ui
│ ├ forms
│ ├ tables
│ ├ modals
│ └ layouts
│
├ constants
│ ├ roles.ts
│ ├ api.ts
│ └ errors.ts
│
├ lib
│ ├ prisma.ts
│ ├ auth.ts
│ └ permissions.ts
│
├ services
├ repositories
├ validations
├ utils
├ types
│
└ middleware.ts
3. Database Design (Prisma)

Use PostgreSQL.

Schema must include these models.

Core Identity

User
Teacher
Student
Parent

Academic Structure

Class
Subject
TeacherSubject

Attendance

Attendance

Exams

Exam
Result

Fees

FeeCategory
Payment

Schedule

Timetable

Communication

Notice

Admissions

AdmissionApplication
4. Enums
Role
Gender
AttendanceStatus
PaymentStatus
AdmissionStatus

Role values

SUPER_ADMIN
ADMIN
ACCOUNTANT
ACADEMIC_ADMIN
ADMISSION_ADMIN
TEACHER
STUDENT
PARENT
5. Database Rules

Authentication

User handles authentication
Teacher / Student / Parent extend User

Constraints

Student rollNumber must be unique per class

Result constraint

@@unique([studentId, examId, subjectId])
6. API Design

Prefix all APIs

/api/v1

Follow REST conventions.

Examples:

Students

GET    /api/v1/students
POST   /api/v1/students
GET    /api/v1/students/:id
PATCH  /api/v1/students/:id
DELETE /api/v1/students/:id

Teachers

GET    /api/v1/teachers
POST   /api/v1/teachers
GET    /api/v1/teachers/:id
PATCH  /api/v1/teachers/:id
DELETE /api/v1/teachers/:id

Classes

GET /api/v1/classes
POST /api/v1/classes

Attendance

POST /api/v1/attendance
GET  /api/v1/attendance/class/:classId

Results

POST /api/v1/results
GET  /api/v1/results/student/:studentId

Fees

GET /api/v1/fees/categories
POST /api/v1/fees/payments

Notices

GET /api/v1/notices
POST /api/v1/notices

Admissions

POST /api/v1/admissions
PATCH /api/v1/admissions/:id/approve
PATCH /api/v1/admissions/:id/reject
7. Architecture Pattern

Follow this request flow.

Request
 ↓
API Route
 ↓
Validation (Zod)
 ↓
Service Layer
 ↓
Repository Layer
 ↓
Prisma ORM
 ↓
Database
8. Repository Layer

Repositories contain database queries.

Example

student.repository.ts
teacher.repository.ts
class.repository.ts
attendance.repository.ts
result.repository.ts
payment.repository.ts

Example function

findAll
findById
create
update
delete
9. Service Layer

Services contain business logic.

Example

student.service.ts
teacher.service.ts
attendance.service.ts
exam.service.ts
result.service.ts
payment.service.ts

Services call repositories.

10. Validation Layer

Use Zod.

Example

student.schema.ts
teacher.schema.ts
attendance.schema.ts
result.schema.ts

Example

createStudentSchema
updateStudentSchema
11. Authentication System

Use JWT.

Login flow

User login
 → verify password
 → generate JWT
 → return token

Store role inside token.

Example payload

{
 id,
 role
}
12. Authorization

Use role based access control.

Example

ADMIN can create teachers
TEACHER can manage attendance
STUDENT can view results

Create permission helper

lib/permissions.ts
13. Middleware

Use middleware for:

JWT verification
Role checking

Example

src/middleware.ts

Protect routes

/admin/*
/teacher/*
/student/*
14. Constants

Create centralized constants.

roles.ts

export const ROLES

api.ts

export const API endpoints

errors.ts

export const error messages
15. Utilities
api-response.ts
error-handler.ts
pagination.ts
date.ts

Standard response format

{
 success: true,
 data
}

Error

{
 success: false,
 message
}
16. Panels

Student Panel

Dashboard
Profile
Attendance
Results
Timetable
Fees
Notices

Teacher Panel

Dashboard
Students
Attendance
Results
Timetable
Notices

Admin Panel

Dashboard
Students
Teachers
Parents
Classes
Subjects
Teacher Subjects
Attendance
Exams
Results
Fees
Timetable
Notices
Admissions
17. Development Order

Build system in this order.

1

Auth

2

Users

3

Classes

4

Students

5

Teachers

6

Subjects

7

Attendance

8

Exams

9

Results

10

Fees

11

Timetable

12

Notices

13

Admissions
18. Code Quality Rules

Use:

TypeScript types
Zod validation
Service layer
Repository layer

Never:

Query database directly inside API route
Final Goal

Build a complete scalable School Management System backend and panel that can power:

Web Admin Panel
Teacher Portal
Student Portal
Flutter Mobile App

The system must be modular, scalable, and production ready.