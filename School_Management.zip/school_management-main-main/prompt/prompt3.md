You are working on a School Management System (ERP).

The project is already scaffolded and the folder structure is fixed.
Do NOT change the folder structure.

Your job is to implement logic inside existing files only.

TECH STACK

Use:

Next.js 16+
TypeScript
Prisma ORM v6
PostgreSQL
Zod validation
JWT authentication
bcryptjs password hashing
TailwindCSS
shadcn/ui

Architecture pattern:

API Route
↓
Validation (Zod)
↓
Service Layer
↓
Repository Layer
↓
Prisma ORM
↓
Database

Never query Prisma directly in API routes.

PROJECT STRUCTURE
src
│
├ app
│
│ ├ login
│ │ └ page.tsx
│
│ ├ unauthorized
│ │ └ page.tsx
│
│ ├ (panels)
│ │
│ │ ├ student
│ │ ├ teacher
│ │ └ admin
│
│ └ api
│   └ v1
│
├ components
├ constants
├ lib
├ services
├ repositories
├ validations
├ utils
├ types
│
└ middleware.ts
DATABASE

Prisma models include:

User
Teacher
Student
Parent
Class
Subject
TeacherSubject
Attendance
Exam
Result
FeeCategory
Payment
Timetable
Notice
AdmissionApplication

Enums:

Role
Gender
AttendanceStatus
PaymentStatus
AdmissionStatus
AUTHENTICATION

Authentication uses JWT.

Login flow:

User submits email + password
↓
Password verified using bcrypt
↓
JWT token generated
↓
Token returned

JWT payload:

{
 id,
 role
}

Token expiration: 7 days

Auth logic is inside:

src/lib/auth.ts
ROLE BASED ACCESS CONTROL

Roles:

SUPER_ADMIN
ADMIN
ACCOUNTANT
ACADEMIC_ADMIN
ADMISSION_ADMIN
TEACHER
STUDENT
PARENT

Permission logic inside:

src/lib/permissions.ts

Example rules:

ADMIN can create teachers
TEACHER can mark attendance
STUDENT can view results
PARENT can view student data
MIDDLEWARE

File:

src/middleware.ts

Responsibilities:

Verify JWT
Attach user info to request
Protect routes
Check roles

Protected routes:

/admin/*
/teacher/*
/student/*
CONSTANTS

Located in:

src/constants

Files:

roles.ts
api.ts
errors.ts

Purpose:

centralized roles
API paths
error messages
UTILS

Located in:

src/utils

Files:

api-response.ts
error-handler.ts
pagination.ts

Purpose:

standard response
central error handling
pagination logic
TYPES

Located in:

src/types

Purpose:

TypeScript interfaces
API request types
response types
DTOs

Example:

CreateStudentInput
UpdateStudentInput
StudentResponse
VALIDATION LAYER

Located in:

src/validations

Uses Zod.

Example:

student.schema.ts
teacher.schema.ts
attendance.schema.ts
result.schema.ts

Example schemas:

createStudentSchema
updateStudentSchema

Validation happens before service logic.

REPOSITORY LAYER

Located in:

src/repositories

Repositories contain only database queries.

Example files:

student.repository.ts
teacher.repository.ts
parent.repository.ts
class.repository.ts
subject.repository.ts
teacherSubject.repository.ts
attendance.repository.ts
exam.repository.ts
result.repository.ts
payment.repository.ts
feeCategory.repository.ts
timetable.repository.ts
notice.repository.ts
admission.repository.ts

Example repository functions:

findAll()
findById(id)
create(data)
update(id,data)
delete(id)

Repositories must use:

prisma.<model>

Example:

prisma.student.findMany()

Repositories must not contain business logic.

SERVICE LAYER

Located in:

src/services

Services contain business logic.

Example files:

student.service.ts
teacher.service.ts
attendance.service.ts
exam.service.ts
result.service.ts
payment.service.ts

Services call repository functions.

Example flow:

API route
→ validation
→ service
→ repository
→ database

Service responsibilities:

business rules
error handling
calling repositories
data transformations
API ROUTES

Located in:

src/app/api/v1

Example structure:

students
students/[id]

teachers
teachers/[id]

attendance
results
fees
notices
admissions

Example routes:

Students

GET    /api/v1/students
POST   /api/v1/students
GET    /api/v1/students/:id
PATCH  /api/v1/students/:id
DELETE /api/v1/students/:id

Attendance

POST /api/v1/attendance
GET  /api/v1/attendance/class/:classId
GET  /api/v1/attendance/student/:studentId

Results

POST /api/v1/results
GET  /api/v1/results/student/:studentId
GET  /api/v1/results/exam/:examId

Admissions

POST /api/v1/admissions
PATCH /api/v1/admissions/:id/approve
PATCH /api/v1/admissions/:id/reject
API RESPONSE FORMAT

Success:

{
 success: true,
 data
}

Error:

{
 success: false,
 message
}

Use helper:

utils/api-response.ts
PANELS

Student panel

dashboard
profile
attendance
results
timetable
fees
notices

Teacher panel

dashboard
students
attendance
results
timetable
notices

Admin panel

dashboard
students
teachers
parents
classes
subjects
teacher-subjects
attendance
exams
results
fees
timetable
notices
admissions
DEVELOPMENT RULES

Always follow:

API → validation → service → repository

Never:

Direct Prisma query inside API route

Use:

TypeScript types
Zod validation
Clean architecture
Modular code
FINAL OBJECTIVE

Build a complete scalable School Management System that powers:

Admin Panel
Teacher Panel
Student Panel
REST API
Flutter Mobile App

The system must be:

modular
scalable
maintainable
production-ready