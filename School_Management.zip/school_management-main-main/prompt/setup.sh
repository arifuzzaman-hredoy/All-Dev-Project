#!/bin/bash

create_dir () {
  if [ ! -d "$1" ]; then
    mkdir -p "$1"
    echo "Created dir: $1"
  fi
}

create_file () {
  if [ ! -f "$1" ]; then
    mkdir -p "$(dirname "$1")"
    touch "$1"
    echo "Created file: $1"
  fi
}

# prisma
create_dir prisma
create_file prisma/schema.prisma
create_file prisma/seed.ts

# public assets
create_dir public/images
create_dir public/icons

# core folders
create_dir src/components
create_dir src/components/ui
create_dir src/components/forms
create_dir src/components/tables
create_dir src/components/modals
create_dir src/components/layouts

create_dir src/lib
create_dir src/services
create_dir src/repositories
create_dir src/validations
create_dir src/utils
create_dir src/types

# lib files
create_file src/lib/prisma.ts
create_file src/lib/auth.ts
create_file src/lib/permissions.ts

# utils
create_file src/utils/api-response.ts
create_file src/utils/error-handler.ts
create_file src/utils/pagination.ts

# services
create_file src/services/auth.service.ts
create_file src/services/student.service.ts
create_file src/services/teacher.service.ts
create_file src/services/parent.service.ts
create_file src/services/class.service.ts
create_file src/services/subject.service.ts
create_file src/services/teacherSubject.service.ts
create_file src/services/attendance.service.ts
create_file src/services/exam.service.ts
create_file src/services/result.service.ts
create_file src/services/payment.service.ts
create_file src/services/feeCategory.service.ts
create_file src/services/timetable.service.ts
create_file src/services/notice.service.ts
create_file src/services/admission.service.ts

# repositories
create_file src/repositories/student.repository.ts
create_file src/repositories/teacher.repository.ts
create_file src/repositories/parent.repository.ts
create_file src/repositories/class.repository.ts
create_file src/repositories/subject.repository.ts
create_file src/repositories/teacherSubject.repository.ts
create_file src/repositories/attendance.repository.ts
create_file src/repositories/exam.repository.ts
create_file src/repositories/result.repository.ts
create_file src/repositories/payment.repository.ts
create_file src/repositories/feeCategory.repository.ts
create_file src/repositories/timetable.repository.ts
create_file src/repositories/notice.repository.ts
create_file src/repositories/admission.repository.ts

# validations
create_file src/validations/auth.schema.ts
create_file src/validations/student.schema.ts
create_file src/validations/teacher.schema.ts
create_file src/validations/parent.schema.ts
create_file src/validations/class.schema.ts
create_file src/validations/subject.schema.ts
create_file src/validations/attendance.schema.ts
create_file src/validations/exam.schema.ts
create_file src/validations/result.schema.ts
create_file src/validations/payment.schema.ts
create_file src/validations/admission.schema.ts

# types
create_file src/types/auth.types.ts
create_file src/types/student.types.ts
create_file src/types/teacher.types.ts
create_file src/types/api.types.ts

# middleware
create_file src/middleware.ts

# api base
create_dir src/app/api/v1

# auth
create_file src/app/api/v1/auth/login/route.ts
create_file src/app/api/v1/auth/logout/route.ts
create_file src/app/api/v1/auth/refresh/route.ts
create_file src/app/api/v1/auth/me/route.ts

# users
create_file src/app/api/v1/users/route.ts
create_file src/app/api/v1/users/[id]/route.ts

# students
create_file src/app/api/v1/students/route.ts
create_file src/app/api/v1/students/[id]/route.ts

# teachers
create_file src/app/api/v1/teachers/route.ts
create_file src/app/api/v1/teachers/[id]/route.ts

# parents
create_file src/app/api/v1/parents/route.ts
create_file src/app/api/v1/parents/[id]/route.ts

# classes
create_file src/app/api/v1/classes/route.ts
create_file src/app/api/v1/classes/[id]/route.ts

# subjects
create_file src/app/api/v1/subjects/route.ts
create_file src/app/api/v1/subjects/[id]/route.ts

# teacher-subjects
create_file src/app/api/v1/teacher-subjects/route.ts
create_file src/app/api/v1/teacher-subjects/[id]/route.ts

# attendance
create_file src/app/api/v1/attendance/route.ts
create_file src/app/api/v1/attendance/class/[classId]/route.ts
create_file src/app/api/v1/attendance/student/[studentId]/route.ts

# exams
create_file src/app/api/v1/exams/route.ts
create_file src/app/api/v1/exams/[id]/route.ts

# results
create_file src/app/api/v1/results/route.ts
create_file src/app/api/v1/results/student/[studentId]/route.ts
create_file src/app/api/v1/results/exam/[examId]/route.ts

# fees
create_file src/app/api/v1/fees/categories/route.ts
create_file src/app/api/v1/fees/categories/[id]/route.ts
create_file src/app/api/v1/fees/payments/route.ts
create_file src/app/api/v1/fees/payments/[id]/route.ts

# timetable
create_file src/app/api/v1/timetable/route.ts
create_file src/app/api/v1/timetable/[id]/route.ts

# notices
create_file src/app/api/v1/notices/route.ts
create_file src/app/api/v1/notices/[id]/route.ts

# admissions
create_file src/app/api/v1/admissions/route.ts
create_file src/app/api/v1/admissions/[id]/route.ts

echo "ERP backend structure ready."