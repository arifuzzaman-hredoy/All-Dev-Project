import { Role } from "@prisma/client";
import { comparePassword, hashPassword } from "@/lib/auth";
import { buildFeeLedger } from "@/lib/fee-history";
import { getPaymentDueAmount } from "@/lib/fee-utils";
import { buildAttendanceSummary } from "@/lib/attendance-summary";
import { prisma } from "@/lib/prisma";
import { resolveTotalMarksFromExamSubjects } from "@/lib/result-marks";
import { findUserByEmail } from "@/repositories/user.repository";
import { buildVisibleNoticeWhere } from "@/repositories/notice.repository";
import { getExamTypeLabel } from "@/constants/exam-types";
import { listVisibleParentExams } from "@/services/exam.service";
import { syncExpiredNotices } from "@/services/notice.service";
import { fetchUserTheme } from "@/services/theme.service";
import { recordAuditEvent } from "@/services/audit.service";
import { HttpError } from "@/utils/error-handler";

async function requireGuardianContext(userId: string) {
  const guardian = await prisma.guardian.findFirst({
    where: {
      userId,
      isDeleted: false,
    },
    select: {
      id: true,
      phone: true,
      address: true,
      name: true,
      email: true,
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          password: true,
        },
      },
      students: {
        where: { isDeleted: false, user: { isDeleted: false } },
        select: {
          id: true,
          rollNumber: true,
          phone: true,
          gender: true,
          user: {
            select: {
              name: true,
              email: true,
            },
          },
          class: {
            select: {
              id: true,
              name: true,
            },
          },
          group: {
            select: {
              name: true,
            },
          },
          section: {
            select: {
              name: true,
            },
          },
        },
      },
    },
  });

  if (!guardian || !guardian.user || guardian.user.role !== Role.PARENT) {
    throw new HttpError("Guardian account not found", 404);
  }

  return guardian;
}

function assertLinkedStudent(
  guardian: Awaited<ReturnType<typeof requireGuardianContext>>,
  studentId?: string | null,
) {
  if (!studentId) {
    return guardian.students[0]?.id ?? null;
  }

  if (!guardian.students.some((student) => student.id === studentId)) {
    throw new HttpError("You are not allowed to access this student", 403);
  }

  return studentId;
}

function buildChildrenSummary(
  guardian: Awaited<ReturnType<typeof requireGuardianContext>>,
) {
  return guardian.students.map((student) => ({
    id: student.id,
    name: student.user.name,
    email: student.user.email,
    className: student.class.name,
    classId: student.class.id,
    groupName: student.group?.name ?? "General",
    sectionName: student.section?.name ?? "Default",
    rollNumber: student.rollNumber,
    phone: student.phone,
    gender: student.gender,
  }));
}

type GuardianResultWithMarkConfig = {
  subjectId: string;
  student: { class: { id: string } };
  exam: {
    name: string;
    date: Date;
    subjects: Parameters<typeof resolveTotalMarksFromExamSubjects>[0];
  };
};

function withGuardianResultTotalMarks<T extends GuardianResultWithMarkConfig>(
  result: T,
) {
  const { exam, ...resultWithoutExam } = result;

  return {
    ...resultWithoutExam,
    totalMarks: resolveTotalMarksFromExamSubjects(
      exam.subjects,
      result.student.class.id,
      result.subjectId,
    ),
    exam: {
      name: exam.name,
      date: exam.date,
    },
  };
}

export async function getGuardianDashboard(userId: string) {
  await syncExpiredNotices();
  const guardian = await requireGuardianContext(userId);
  const studentIds = guardian.students.map((student) => student.id);
  const classIds = guardian.students.map((student) => student.class.id);

  const [attendance, results, payments, notices, exams] = await Promise.all([
    prisma.attendance.findMany({
      where: { studentId: { in: studentIds } },
      select: {
        studentId: true,
        status: true,
      },
    }),
    prisma.result.findMany({
      where: { studentId: { in: studentIds } },
      orderBy: { createdAt: "desc" },
      take: 8,
      select: {
        id: true,
        subjectId: true,
        marks: true,
        grade: true,
        student: {
          select: {
            id: true,
            user: { select: { name: true } },
            class: { select: { id: true } },
          },
        },
        subject: { select: { name: true } },
        exam: {
          select: {
            name: true,
            date: true,
            subjects: {
              select: {
                classId: true,
                subjectId: true,
                fullMarks: true,
                components: { select: { fullMarks: true } },
              },
            },
          },
        },
      },
    }),
    prisma.payment.findMany({
      where: { studentId: { in: studentIds } },
      select: {
        studentId: true,
        amountPaid: true,
        feeCategory: { select: { id: true, amount: true } },
        student: {
          select: {
            id: true,
            class: {
              select: {
                monthlyFeeSetting: {
                  select: {
                    monthlyFee: true,
                    isActive: true,
                  },
                },
              },
            },
          },
        },
      },
    }),
    prisma.notice.findMany({
      where: {
        ...buildVisibleNoticeWhere(),
        OR: [
          { audience: "ALL" },
          { audience: "STUDENTS" },
          {
            classId: { in: guardian.students.map((student) => student.class.id) },
          },
        ],
      },
      orderBy: { createdAt: "desc" },
      take: 6,
      select: {
        id: true,
        title: true,
        content: true,
        createdAt: true,
        class: { select: { name: true } },
      },
    }),
    listVisibleParentExams(classIds),
  ]);

  return {
    guardian: {
      name: guardian.user!.name ?? guardian.name,
      email: guardian.user!.email ?? guardian.email,
      phone: guardian.phone,
      address: guardian.address,
    },
    children: buildChildrenSummary(guardian),
    stats: {
      totalChildren: guardian.students.length,
      attendanceRate:
        attendance.length > 0
          ? Math.round(
              (attendance.filter((item) => item.status === "PRESENT").length /
                attendance.length) *
                100,
            )
          : 0,
      totalDue: payments.reduce(
        (sum, item) =>
          sum +
          getPaymentDueAmount(
            item.student.class.monthlyFeeSetting?.isActive === false
              ? 0
              : item.student.class.monthlyFeeSetting?.monthlyFee,
            item.feeCategory.amount,
            item.amountPaid,
          ),
        0,
      ),
      recentResults: results.length,
    },
    recentResults: results.map(withGuardianResultTotalMarks),
    notices,
    upcomingExams: exams
      .filter((exam) => exam.status !== "ARCHIVED")
      .slice(0, 8)
      .map((exam) => ({
        id: exam.id,
        name: exam.name,
        code: exam.code,
        date: exam.date,
        status: exam.status,
        className: exam.class.name,
        examType: getExamTypeLabel(exam.examType),
      })),
  };
}

export async function getGuardianProfile(userId: string) {
  const guardian = await requireGuardianContext(userId);
  const theme = await fetchUserTheme(userId);

  return {
    profile: {
      id: guardian.id,
      name: guardian.user!.name ?? guardian.name,
      email: guardian.user!.email ?? guardian.email,
      phone: guardian.phone,
      address: guardian.address,
    },
    children: buildChildrenSummary(guardian),
    theme,
  };
}

export async function listGuardianChildren(userId: string) {
  const guardian = await requireGuardianContext(userId);
  return {
    children: buildChildrenSummary(guardian),
  };
}

export async function getGuardianChildDetail(userId: string, studentId: string) {
  const guardian = await requireGuardianContext(userId);
  const selectedStudentId = assertLinkedStudent(guardian, studentId);

  const [student, attendance, results, payments, timetable] = await Promise.all(
    [
      prisma.student.findUnique({
        where: { id: selectedStudentId! },
        select: {
          id: true,
          rollNumber: true,
          phone: true,
          gender: true,
          user: { select: { name: true, email: true } },
          class: {
            select: {
              id: true,
              name: true,
              monthlyFeeSetting: {
                select: {
                  monthlyFee: true,
                  isActive: true,
                },
              },
            },
          },
          group: { select: { name: true } },
          section: { select: { name: true } },
        },
      }),
      prisma.attendance.findMany({
        where: { studentId: selectedStudentId! },
        orderBy: { date: "desc" },
        take: 30,
        select: {
          id: true,
          date: true,
          status: true,
          subject: { select: { name: true } },
        },
      }),
      prisma.result.findMany({
        where: { studentId: selectedStudentId! },
        orderBy: [{ exam: { date: "desc" } }, { createdAt: "desc" }],
        take: 12,
        select: {
          id: true,
          subjectId: true,
          marks: true,
          grade: true,
          subject: { select: { name: true } },
          student: { select: { class: { select: { id: true } } } },
          exam: {
            select: {
              name: true,
              date: true,
              subjects: {
                select: {
                  classId: true,
                  subjectId: true,
                  fullMarks: true,
                  components: { select: { fullMarks: true } },
                },
              },
            },
          },
        },
      }),
      prisma.payment.findMany({
        where: { studentId: selectedStudentId! },
        orderBy: [{ year: "desc" }, { month: "desc" }],
        take: 12,
        select: {
          id: true,
          amountPaid: true,
          status: true,
          paymentMethod: true,
          transactionId: true,
          month: true,
          year: true,
          dueDate: true,
          createdAt: true,
          feeCategory: { select: { id: true, name: true, amount: true } },
          student: {
            select: {
              id: true,
              user: { select: { name: true } },
              class: {
                select: {
                  name: true,
                  monthlyFeeSetting: {
                    select: {
                      monthlyFee: true,
                      isActive: true,
                    },
                  },
                },
              },
            },
          },
        },
      }),
      prisma.timetable.findMany({
        where: {
          classId: guardian.students.find(
            (item) => item.id === selectedStudentId,
          )!.class.id,
        },
        orderBy: [{ day: "asc" }, { startTime: "asc" }],
        select: {
          id: true,
          day: true,
          startTime: true,
          endTime: true,
          subject: { select: { name: true } },
          teacher: { select: { user: { select: { name: true } } } },
        },
      }),
    ],
  );

  if (!student) {
    throw new HttpError("Student not found", 404);
  }

  const attendanceRate =
    attendance.length > 0
      ? Math.round(
          (attendance.filter((item) => item.status === "PRESENT").length /
            attendance.length) *
            100,
        )
      : 0;

  return {
    child: {
      id: student.id,
      name: student.user.name,
      email: student.user.email,
      className: student.class.name,
      groupName: student.group?.name ?? "General",
      sectionName: student.section?.name ?? "Default",
      rollNumber: student.rollNumber,
      phone: student.phone,
      gender: student.gender,
      attendanceRate,
    },
    attendance,
    results: results.map(withGuardianResultTotalMarks),
    ...buildFeeLedger(payments),
    timetable,
  };
}

export async function listGuardianAttendance(
  userId: string,
  studentId?: string | null,
) {
  const guardian = await requireGuardianContext(userId);
  const selectedStudentId = assertLinkedStudent(guardian, studentId);

  const records = await prisma.attendance.findMany({
    where: selectedStudentId
      ? { studentId: selectedStudentId }
      : { studentId: { in: guardian.students.map((item) => item.id) } },
    orderBy: [{ date: "desc" }, { period: "asc" }],
    select: {
      id: true,
      date: true,
      status: true,
      period: true,
      student: {
        select: {
          id: true,
          user: { select: { name: true } },
          rollNumber: true,
          class: { select: { name: true } },
        },
      },
      subject: { select: { name: true } },
    },
  });

  return {
    children: buildChildrenSummary(guardian),
    selectedStudentId,
    records,
    summary: buildAttendanceSummary(records),
  };
}

export async function listGuardianResults(
  userId: string,
  studentId?: string | null,
) {
  const guardian = await requireGuardianContext(userId);
  const selectedStudentId = assertLinkedStudent(guardian, studentId);

  const results = await prisma.result.findMany({
    where: selectedStudentId
      ? { studentId: selectedStudentId }
      : { studentId: { in: guardian.students.map((item) => item.id) } },
    orderBy: [{ exam: { date: "desc" } }, { createdAt: "desc" }],
    select: {
      id: true,
      subjectId: true,
      marks: true,
      grade: true,
      student: {
        select: {
          id: true,
          user: { select: { name: true } },
          class: {
            select: {
              id: true,
              name: true,
              monthlyFeeSetting: {
                select: {
                  monthlyFee: true,
                  isActive: true,
                },
              },
            },
          },
        },
      },
      subject: { select: { name: true } },
      exam: {
        select: {
          name: true,
          date: true,
          subjects: {
            select: {
              classId: true,
              subjectId: true,
              fullMarks: true,
              components: { select: { fullMarks: true } },
            },
          },
        },
      },
    },
  });

  return {
    children: buildChildrenSummary(guardian),
    selectedStudentId,
    results: results.map(withGuardianResultTotalMarks),
  };
}

export async function listGuardianFees(
  userId: string,
  studentId?: string | null,
) {
  const guardian = await requireGuardianContext(userId);
  const selectedStudentId = assertLinkedStudent(guardian, studentId);

  const payments = await prisma.payment.findMany({
    where: selectedStudentId
      ? { studentId: selectedStudentId }
      : { studentId: { in: guardian.students.map((item) => item.id) } },
    orderBy: [{ year: "desc" }, { month: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      amountPaid: true,
      status: true,
      paymentMethod: true,
      transactionId: true,
      month: true,
      year: true,
      dueDate: true,
      createdAt: true,
      student: {
        select: {
          id: true,
          user: { select: { name: true } },
          class: {
            select: {
              name: true,
              monthlyFeeSetting: {
                select: {
                  monthlyFee: true,
                  isActive: true,
                },
              },
            },
          },
        },
      },
      feeCategory: { select: { id: true, name: true, amount: true } },
    },
  });

  return {
    children: buildChildrenSummary(guardian),
    selectedStudentId,
    ...buildFeeLedger(payments),
  };
}

export async function listGuardianNotices(
  userId: string,
  studentId?: string | null,
) {
  await syncExpiredNotices();
  const guardian = await requireGuardianContext(userId);
  const selectedStudentId = assertLinkedStudent(guardian, studentId);
  const targetClassIds = selectedStudentId
    ? guardian.students
        .filter((student) => student.id === selectedStudentId)
        .map((student) => student.class.id)
    : guardian.students.map((student) => student.class.id);

  const notices = await prisma.notice.findMany({
    where: {
      ...buildVisibleNoticeWhere(),
      OR: [
        { audience: "ALL" },
        { audience: "STUDENTS" },
        { classId: { in: targetClassIds } },
      ],
    },
    orderBy: { createdAt: "desc" },
    take: 20,
    select: {
      id: true,
      title: true,
      content: true,
      audience: true,
      createdAt: true,
      class: { select: { name: true } },
    },
  });

  return {
    children: buildChildrenSummary(guardian),
    selectedStudentId,
    notices,
  };
}

export async function updateGuardianProfile(
  userId: string,
  payload: {
    name: string;
    email: string;
    phone?: string | null;
    address?: string | null;
  },
) {
  const guardian = await requireGuardianContext(userId);
  const normalizedEmail = payload.email.trim().toLowerCase();
  const otherUser = await findUserByEmail(normalizedEmail);

  if (otherUser && otherUser.id !== guardian.user!.id) {
    throw new HttpError("Email already exists", 409);
  }

  const result = await prisma.$transaction(async (tx) => {
    const user = await tx.user.update({
      where: { id: guardian.user!.id },
      data: {
        name: payload.name.trim(),
        email: normalizedEmail,
      },
      select: {
        id: true,
        name: true,
        email: true,
      },
    });

    const guardianRecord = await tx.guardian.update({
      where: { id: guardian.id },
      data: {
        name: payload.name.trim(),
        email: normalizedEmail,
        phone: payload.phone?.trim() || null,
        address: payload.address?.trim() || null,
      },
      select: {
        id: true,
        phone: true,
        address: true,
      },
    });

    return { user, guardian: guardianRecord };
  });

  await recordAuditEvent({
    actorId: userId,
    action: "guardian.profile.updated",
    entityType: "Guardian",
    entityId: guardian.id,
    metadata: {
      email: result.user.email,
      phone: result.guardian.phone,
    },
  });

  return result;
}

export async function updateGuardianPassword(
  userId: string,
  payload: {
    currentPassword: string;
    newPassword: string;
  },
) {
  const guardian = await requireGuardianContext(userId);
  const valid = await comparePassword(
    payload.currentPassword,
    guardian.user!.password,
  );

  if (!valid) {
    throw new HttpError("Current password is incorrect", 400);
  }

  await prisma.user.update({
    where: { id: guardian.user!.id },
    data: {
      password: await hashPassword(payload.newPassword),
    },
  });

  await recordAuditEvent({
    actorId: userId,
    action: "guardian.password.updated",
    entityType: "Guardian",
    entityId: guardian.id,
  });

  return { message: "Password updated successfully" };
}
