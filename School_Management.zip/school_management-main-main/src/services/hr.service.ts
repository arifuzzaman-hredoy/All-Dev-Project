import type { LeaveStatus, Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import {
  createDepartment,
  createDesignation,
  createTeacherLeaveRequest,
  findDepartmentById,
  findDesignationById,
  findTeacherLeaveRequestById,
  listDepartments,
  listDesignations,
  listTeacherLeaveRequests,
  updateDepartment,
  updateDesignation,
  updateTeacherLeaveRequest,
} from "@/repositories/hr.repository";
import { HttpError } from "@/utils/error-handler";

const LEAVE_STATUS = {
  PENDING: "PENDING",
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
  CANCELLED: "CANCELLED",
} as const satisfies Record<string, LeaveStatus>;

export async function listDepartmentsForAdmin(search?: string) {
  const departments = await listDepartments(search);
  return { departments };
}

export async function createDepartmentForAdmin(payload: {
  name: string;
  isActive?: boolean;
}) {
  return createDepartment({
    name: payload.name.trim(),
    isActive: payload.isActive ?? true,
  });
}

export async function updateDepartmentForAdmin(
  id: string,
  payload: { name?: string; isActive?: boolean },
) {
  const existing = await findDepartmentById(id);
  if (!existing) throw new HttpError("Department not found", 404);
  return updateDepartment(id, {
    ...(payload.name ? { name: payload.name.trim() } : {}),
    ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
  });
}

export async function listDesignationsForAdmin(search?: string) {
  const designations = await listDesignations(search);
  return { designations };
}

export async function createDesignationForAdmin(payload: {
  name: string;
  isActive?: boolean;
}) {
  return createDesignation({
    name: payload.name.trim(),
    isActive: payload.isActive ?? true,
  });
}

export async function updateDesignationForAdmin(
  id: string,
  payload: { name?: string; isActive?: boolean },
) {
  const existing = await findDesignationById(id);
  if (!existing) throw new HttpError("Designation not found", 404);
  return updateDesignation(id, {
    ...(payload.name ? { name: payload.name.trim() } : {}),
    ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
  });
}

function normalizeLeaveDate(value: string, boundary: "start" | "end") {
  const trimmed = value.trim();
  if (!trimmed) {
    throw new HttpError("Invalid leave date", 400);
  }

  const [datePart] = trimmed.split("T");
  const [year, month, day] = datePart.split("-").map((part) => Number(part));
  if (!year || !month || !day) {
    throw new HttpError("Invalid leave date", 400);
  }

  const date = new Date(year, month - 1, day);
  date.setHours(boundary === "start" ? 0 : 23, boundary === "start" ? 0 : 59, boundary === "start" ? 0 : 59, boundary === "start" ? 0 : 999);
  if (Number.isNaN(date.getTime())) {
    throw new HttpError("Invalid leave date", 400);
  }
  return date;
}

export async function listTeacherLeavesForAdmin(filters: {
  status?: LeaveStatus;
  teacherId?: string;
} = {}) {
  const leaves = await listTeacherLeaveRequests(filters);
  return { leaves };
}

export async function createTeacherLeaveForAdmin(payload: {
  teacherId: string;
  startDate: string;
  endDate: string;
  reason?: string;
}) {
  const teacher = await prisma.teacher.findUnique({
    where: { id: payload.teacherId },
    select: { id: true, isDeleted: true, user: { select: { isDeleted: true } } },
  });
  if (!teacher || teacher.isDeleted || teacher.user.isDeleted) {
    throw new HttpError("Teacher not found", 404);
  }

  const startDate = normalizeLeaveDate(payload.startDate, "start");
  const endDate = normalizeLeaveDate(payload.endDate, "end");
  if (endDate < startDate) {
    throw new HttpError("End date must be on or after start date", 400);
  }

  const overlaps = await prisma.teacherLeaveRequest.count({
    where: {
      teacherId: payload.teacherId,
      status: { in: [LEAVE_STATUS.PENDING, LEAVE_STATUS.APPROVED] },
      AND: [{ startDate: { lte: endDate } }, { endDate: { gte: startDate } }],
    },
  });
  if (overlaps > 0) {
    throw new HttpError("Leave request overlaps with an existing leave", 409);
  }

  return createTeacherLeaveRequest({
    teacher: { connect: { id: payload.teacherId } },
    startDate,
    endDate,
    reason: payload.reason?.trim() || null,
    status: LEAVE_STATUS.PENDING,
  });
}

export async function decideTeacherLeaveForAdmin(payload: {
  leaveId: string;
  status: "APPROVED" | "REJECTED" | "CANCELLED";
  actorId: string;
  metadata?: Prisma.InputJsonValue;
}) {
  const leave = await findTeacherLeaveRequestById(payload.leaveId);
  if (!leave) throw new HttpError("Leave request not found", 404);

  if (leave.status === LEAVE_STATUS.CANCELLED) {
    return leave;
  }

  if (payload.status === LEAVE_STATUS.CANCELLED) {
    if (leave.status !== LEAVE_STATUS.PENDING) {
      throw new HttpError("Only pending leaves can be cancelled", 409);
    }
  }

  return updateTeacherLeaveRequest(payload.leaveId, {
    status: payload.status,
    decidedAt: new Date(),
    decidedBy: { connect: { id: payload.actorId } },
  });
}
