import { listClasses } from "@/repositories/class.repository";
import {
  createTeacherSubject,
  deleteTeacherSubjectRecord,
  findTeacherSubjectById,
  listTeacherSubjects,
  updateTeacherSubjectRecord,
} from "@/repositories/teacherSubject.repository";
import { listTeachers } from "@/repositories/teacher.repository";
import { listSubjects } from "@/repositories/subject.repository";
import { prisma } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";

async function assertTeacherSubjectAssignment(payload: {
  teacherId: string;
  subjectId: string;
  classId: string;
}) {
  const [teacher, subject] = await Promise.all([
    prisma.teacher.findUnique({
      where: { id: payload.teacherId },
      select: { id: true, isDeleted: true, user: { select: { isDeleted: true } } },
    }),
    prisma.subject.findUnique({
      where: { id: payload.subjectId },
      select: { id: true, classId: true },
    }),
  ]);

  if (!teacher || teacher.isDeleted || teacher.user.isDeleted) {
    throw new HttpError("Teacher not found", 404);
  }

  if (!subject) {
    throw new HttpError("Subject not found", 404);
  }

  if (subject.classId !== payload.classId) {
    throw new HttpError("Selected subject does not belong to the selected class", 400);
  }
}

export async function listTeacherSubjectsForAdmin(filters: {
  teacherId?: string;
  classId?: string;
  subjectId?: string;
}) {
  const [assignments, teachers, classes, subjects] = await Promise.all([
    listTeacherSubjects(filters),
    listTeachers({}),
    listClasses(),
    listSubjects({}),
  ]);

  return {
    assignments,
    teachers: teachers.map((teacher) => ({
      id: teacher.id,
      name: teacher.user.name,
    })),
    classes,
    subjects: subjects.map((subject) => ({
      id: subject.id,
      name: subject.name,
      classId: subject.class.id,
      className: subject.class.name,
    })),
    stats: {
      total: assignments.length,
    },
  };
}

export async function createTeacherSubjectForAdmin(payload: {
  teacherId: string;
  subjectId: string;
  classId: string;
}) {
  await assertTeacherSubjectAssignment(payload);

  return createTeacherSubject({
    teacher: { connect: { id: payload.teacherId } },
    subject: { connect: { id: payload.subjectId } },
    class: { connect: { id: payload.classId } },
  });
}

export async function updateTeacherSubjectForAdmin(
  id: string,
  payload: {
    teacherId?: string;
    subjectId?: string;
    classId?: string;
  }
) {
  const existing = await findTeacherSubjectById(id);
  if (!existing) {
    throw new HttpError("Teacher subject mapping not found", 404);
  }

  await assertTeacherSubjectAssignment({
    teacherId: payload.teacherId ?? existing.teacherId,
    subjectId: payload.subjectId ?? existing.subjectId,
    classId: payload.classId ?? existing.classId,
  });

  return updateTeacherSubjectRecord(id, {
    ...(payload.teacherId
      ? { teacher: { connect: { id: payload.teacherId } } }
      : {}),
    ...(payload.subjectId
      ? { subject: { connect: { id: payload.subjectId } } }
      : {}),
    ...(payload.classId ? { class: { connect: { id: payload.classId } } } : {}),
  });
}

export async function deleteTeacherSubjectForAdmin(id: string) {
  const existing = await findTeacherSubjectById(id);
  if (!existing) {
    throw new HttpError("Teacher subject mapping not found", 404);
  }

  return deleteTeacherSubjectRecord(id);
}
