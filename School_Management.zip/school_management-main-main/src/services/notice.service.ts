import { findClassById, listClasses } from "@/repositories/class.repository";
import {
  createNotice,
  deleteNoticeRecord,
  findNoticeById,
  listNotices,
  updateNoticeRecord,
} from "@/repositories/notice.repository";
import { prisma } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";

function parseNoticeDate(value: string, boundary: "start" | "end") {
  const trimmed = value.trim();
  if (!trimmed) {
    throw new HttpError("Invalid notice date", 400);
  }

  const [datePart] = value.trim().split("T");
  const [year, month, day] = datePart.split("-").map((part) => Number(part));

  if (
    Number.isNaN(year) ||
    Number.isNaN(month) ||
    Number.isNaN(day) ||
    !year ||
    !month ||
    !day
  ) {
    throw new HttpError("Invalid notice date", 400);
  }

  const date = new Date(year, month - 1, day);
  date.setHours(
    boundary === "start" ? 0 : 23,
    boundary === "start" ? 0 : 59,
    boundary === "start" ? 0 : 59,
    boundary === "start" ? 0 : 999,
  );

  if (Number.isNaN(date.getTime())) {
    throw new HttpError("Invalid notice date", 400);
  }

  return date;
}

function formatNoticeDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function normalizeNoticeWindow(payload: {
  startsAt?: string | null | undefined;
  endsAt?: string | null | undefined;
}) {
  const startsAt =
    payload.startsAt !== undefined && payload.startsAt !== null && payload.startsAt.trim()
      ? parseNoticeDate(payload.startsAt, "start")
      : null;
  const endsAt =
    payload.endsAt !== undefined && payload.endsAt !== null && payload.endsAt.trim()
      ? parseNoticeDate(payload.endsAt, "end")
      : null;

  if (startsAt && endsAt && endsAt < startsAt) {
    throw new HttpError("End date must be on or after start date", 400);
  }

  return {
    startsAt,
    endsAt,
    isActive: endsAt ? endsAt >= new Date() : true,
  };
}

export async function syncExpiredNotices() {
  await prisma.notice.updateMany({
    where: {
      isActive: true,
      endsAt: {
        lt: new Date(),
      },
    },
    data: {
      isActive: false,
    },
  });
}

export async function listNoticesForAdmin(filters: {
  search?: string;
  audience?: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS";
  classId?: string;
}) {
  await syncExpiredNotices();
  const [notices, classes] = await Promise.all([
    listNotices(filters),
    listClasses(),
  ]);

  return {
    notices,
    classes,
    stats: {
      total: notices.length,
      classSpecific: notices.filter((item) => Boolean(item.classId)).length,
    },
  };
}

export async function createNoticeForAdmin(payload: {
  title: string;
  content?: string;
  audience: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS";
  startsAt?: string;
  endsAt?: string;
  classId?: string | null;
}) {
  if (payload.classId) {
    const classRecord = await findClassById(payload.classId);
    if (!classRecord) {
      throw new HttpError("Selected class does not exist", 404);
    }
  }

  return createNotice({
    title: payload.title.trim(),
    content: payload.content?.trim() ?? "",
    audience: payload.audience,
    ...normalizeNoticeWindow({
      startsAt: payload.startsAt,
      endsAt: payload.endsAt,
    }),
    status: "DRAFT",
    isActive: false,
    ...(payload.classId
      ? {
          class: {
            connect: { id: payload.classId },
          },
        }
      : {}),
  });
}

export async function updateNoticeForAdmin(
  id: string,
  payload: {
    title?: string;
    content?: string;
    audience?: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS";
    startsAt?: string | null;
    endsAt?: string | null;
    classId?: string | null;
  }
) {
  const existing = await findNoticeById(id);
  if (!existing) {
    throw new HttpError("Notice not found", 404);
  }

  if (payload.classId) {
    const classRecord = await findClassById(payload.classId);
    if (!classRecord) {
      throw new HttpError("Selected class does not exist", 404);
    }
  }

  const nextWindow = normalizeNoticeWindow({
    startsAt:
      payload.startsAt !== undefined
        ? payload.startsAt
        : existing.startsAt
          ? formatNoticeDateInput(existing.startsAt)
          : null,
    endsAt:
      payload.endsAt !== undefined
        ? payload.endsAt
        : existing.endsAt
          ? formatNoticeDateInput(existing.endsAt)
          : null,
  });

  return updateNoticeRecord(id, {
    ...(payload.title ? { title: payload.title.trim() } : {}),
    ...(payload.content !== undefined ? { content: payload.content.trim() } : {}),
    ...(payload.audience ? { audience: payload.audience } : {}),
    ...nextWindow,
    ...(payload.classId === null
      ? { class: { disconnect: true } }
      : payload.classId
        ? { class: { connect: { id: payload.classId } } }
        : {}),
  });
}

export async function publishNoticeForAdmin(id: string) {
  const existing = await findNoticeById(id);
  if (!existing) {
    throw new HttpError("Notice not found", 404);
  }

  if (!existing.content.trim()) {
    throw new HttpError("Notice content is required before publishing", 400);
  }

  return updateNoticeRecord(id, {
    status: "PUBLISHED",
    publishedAt: new Date(),
    isActive: true,
  });
}

export async function deleteNoticeForAdmin(id: string) {
  const existing = await findNoticeById(id);
  if (!existing) {
    throw new HttpError("Notice not found", 404);
  }

  return deleteNoticeRecord(id);
}
