import { Role } from "@prisma/client";
import {
  comparePassword,
  generateToken,
  hashPassword,
  type TokenPayload,
} from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";
import { createUser, findUserByEmail, findUserByEmailWithBranch } from "@/repositories/user.repository";
import { assertBranchIsActive } from "@/services/branch.service";
import { ADMIN_ROLES } from "@/constants/roles";

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
  branchId?: string | null;
  branch?: {
    id: string;
    name: string;
    slug: string;
    school?: { id: string; name: string; slug: string } | null;
  } | null;
};

export type AuthResult = {
  token: string | null;
  user: AuthUser | null;
  message?: string;
};

/**
 * Validates an email/password pair and returns a token plus public profile info.
 */
export async function loginUser(credentials: {
  email: string;
  password: string;
  branchId?: string;
  loginScope?: "portal" | "staff";
}) {
  const normalizedEmail = credentials.email.trim().toLowerCase();
  const user = await findUserByEmailWithBranch(normalizedEmail);

  if (!user) {
    throw new HttpError("Invalid credentials", 401);
  }

  const isPasswordValid = await comparePassword(
    credentials.password,
    user.password,
  );
  if (!isPasswordValid) {
    throw new HttpError("Invalid credentials", 401);
  }

  const isStaffRole = ADMIN_ROLES.includes(user.role);
  if (credentials.loginScope === "portal" && isStaffRole) {
    throw new HttpError("Staff accounts must sign in from /staff/login", 403);
  }
  if (credentials.loginScope === "staff" && !isStaffRole) {
    throw new HttpError("Teacher, student, and guardian accounts must use /login", 403);
  }

  if (user.role === Role.STUDENT) {
    const admission = await prisma.admissionApplication.findFirst({
      where: { email: normalizedEmail },
      orderBy: { updatedAt: "desc" },
      select: {
        status: true,
      },
    });

    if (admission && admission.status !== "ACCEPTED") {
      throw new HttpError("Your application is still pending review", 403);
    }
  }

  const selectedBranchId = credentials.branchId?.trim() || undefined;
  let selectedBranch:
    | {
        id: string;
        name: string;
        slug: string;
        school: { id: string; name: string; slug: string };
      }
    | null = null;

  if (user.role === Role.SUPER_ADMIN) {
    if (!selectedBranchId) {
      throw new HttpError("Please select a school branch to continue", 400);
    }
    selectedBranch = await assertBranchIsActive(selectedBranchId);
  } else if (isStaffRole) {
    if (!selectedBranchId) {
      throw new HttpError("Please select your branch to sign in", 400);
    }
    selectedBranch = await assertBranchIsActive(selectedBranchId);
    if (!user.branchId) {
      throw new HttpError("Your account is not assigned to any branch", 403);
    }
    if (user.branchId !== selectedBranchId) {
      throw new HttpError("You are not allowed to sign in to this branch", 403);
    }
  }

  const tokenBranchId = user.role === Role.SUPER_ADMIN ? (selectedBranchId ?? null) : (user.branchId ?? null);

  const payload: TokenPayload = { id: user.id, role: user.role, branchId: tokenBranchId };
  const token = generateToken(payload);

  return {
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      branchId: tokenBranchId,
      branch:
        selectedBranch ??
        (user.branch
          ? { id: user.branch.id, name: user.branch.name, slug: user.branch.slug }
          : null),
    },
  };
}

export type RegisterPayload = {
  name: string;
  email: string;
  password: string;
  role: Role;
};

export async function registerUser(payload: RegisterPayload) {
  return prisma.$transaction(async (tx) => {
    const normalizedEmail = payload.email.trim().toLowerCase();

    const existingUser = await findUserByEmail(normalizedEmail, tx);
    if (existingUser) {
      throw new HttpError("Email already exists", 409);
    }

    const hashedPassword = await hashPassword(payload.password);

    if (payload.role !== Role.USER) {
      throw new HttpError("Only general user registration is supported here", 400);
    }

    const user = await createUser(
      {
        name: payload.name,
        email: normalizedEmail,
        password: hashedPassword,
        role: payload.role,
      },
      tx,
    );

    const tokenPayload: TokenPayload = { id: user.id, role: user.role };
    const token = generateToken(tokenPayload);

    return {
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    };
  });
}
