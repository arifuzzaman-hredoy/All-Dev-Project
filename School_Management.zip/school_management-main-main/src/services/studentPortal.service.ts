import { Role, WeekDay } from "@prisma/client";
import { getExamTypeLabel } from "@/constants/exam-types";
import { buildFeeLedger } from "@/lib/fee-history";
import { getClassMonthlyFee } from "@/lib/fee-utils";
import { buildAttendanceSummary } from "@/lib/attendance-summary";
import { prisma } from "@/lib/prisma";
import { resolveTotalMarksFromExamSubjects } from "@/lib/result-marks";
import { buildVisibleNoticeWhere } from "@/repositories/notice.repository";
import { listVisibleStudentExams } from "@/services/exam.service";
import { syncExpiredNotices } from "@/services/notice.service";
import { HttpError } from "@/utils/error-handler";

const weekDays: WeekDay[] = [
  WeekDay.MONDAY,
  WeekDay.TUESDAY,
  WeekDay.WEDNESDAY,
  WeekDay.THURSDAY,
  WeekDay.FRIDAY,
  WeekDay.SATURDAY,
];

async function requireStudentPortalContext(userId: string) {
  const student = await prisma.student.findUnique({
    where: { userId },
    select: {
      id: true,
      rollNumber: true,
      phone: true,
      gender: true,
      classId: true,
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
        },
      },
      class: {
        select: {
          id: true,
          name: true,
          monthlyFeeSetting: {
            select: {
              monthlyFee: true,
              isActive: true,
            },
          },
        },
      },
      group: {
        select: {
          name: true,
        },
      },
      section: {
        select: {
          name: true,
        },
      },
      fatherName: true,
      fatherPhone: true,
      motherName: true,
      motherPhone: true,
      parent: {
        select: {
          id: true,
          phone: true,
          address: true,
          user: {
            select: {
              name: true,
              email: true,
            },
          },
        },
      },
      guardian: {
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          address: true,
          relation: true,
        },
      },
    },
  });

  if (!student || student.user.role !== Role.STUDENT) {
    throw new HttpError("Student account not found", 404);
  }

  const admission = await prisma.admissionApplication.findFirst({
    where: { email: student.user.email },
    orderBy: { updatedAt: "desc" },
    select: {
      status: true,
    },
  });

  if (admission && admission.status !== "ACCEPTED") {
    throw new HttpError("Your application is still pending review", 403);
  }

  return student;
}

function getCurrentMonthlyFee(
  monthlyFeeSetting:
    | {
        monthlyFee: number | null;
        isActive?: boolean;
      }
    | null
    | undefined,
) {
  if (monthlyFeeSetting?.isActive === false) {
    return 0;
  }

  return getClassMonthlyFee(monthlyFeeSetting?.monthlyFee);
}

type StudentResultWithMarkConfig = {
  subjectId: string;
  marks: number;
  exam: {
    id?: string;
    name: string;
    date: Date;
    subjects: Parameters<typeof resolveTotalMarksFromExamSubjects>[0];
  };
};

function withStudentResultTotalMarks<T extends StudentResultWithMarkConfig>(
  result: T,
  classId: string,
) {
  const { exam, ...resultWithoutExam } = result;

  return {
    ...resultWithoutExam,
    totalMarks: resolveTotalMarksFromExamSubjects(
      exam.subjects,
      classId,
      result.subjectId,
    ),
    exam: {
      ...(exam.id ? { id: exam.id } : {}),
      name: exam.name,
      date: exam.date,
    },
  };
}

export async function getStudentDashboard(userId: string) {
  const student = await requireStudentPortalContext(userId);
  const [attendance, results, payments, notices, exams] = await Promise.all([
    prisma.attendance.findMany({
      where: { studentId: student.id },
      select: { status: true },
    }),
    prisma.result.findMany({
      where: { studentId: student.id },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        subjectId: true,
        marks: true,
        grade: true,
        subject: { select: { name: true } },
        exam: {
          select: {
            name: true,
            date: true,
            subjects: {
              select: {
                classId: true,
                subjectId: true,
                fullMarks: true,
                components: { select: { fullMarks: true } },
              },
            },
          },
        },
      },
    }),
    prisma.payment.findMany({
      where: {
        studentId: student.id,
        feeCategory: {
          isActive: true,
        },
      },
      select: {
        id: true,
        amountPaid: true,
        status: true,
        paymentMethod: true,
        transactionId: true,
        month: true,
        year: true,
        dueDate: true,
        createdAt: true,
        feeCategory: {
          select: {
            id: true,
            name: true,
            amount: true,
          },
        },
        student: {
          select: {
            id: true,
            user: {
              select: {
                name: true,
              },
            },
            class: {
              select: {
                name: true,
                monthlyFeeSetting: {
                  select: {
                    monthlyFee: true,
                    isActive: true,
                  },
                },
              },
            },
          },
        },
      },
    }),
    prisma.notice.findMany({
      where: {
        ...buildVisibleNoticeWhere(),
        OR: [
          { audience: "ALL" },
          { audience: "STUDENTS" },
          { classId: student.classId },
        ],
      },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        title: true,
        content: true,
        createdAt: true,
      },
    }),
    listVisibleStudentExams(student.id),
  ]);

  const attendanceRate =
    attendance.length > 0
      ? Math.round(
          (attendance.filter((item) => item.status === "PRESENT").length /
            attendance.length) *
            100,
        )
      : 0;

  const feeLedger = buildFeeLedger(payments);
  const currentMonthlyFee = getCurrentMonthlyFee(
    student.class.monthlyFeeSetting,
  );
  const hasMonthlyFeeSnapshots = feeLedger.history.some(
    (item) => item.monthlyFeeBase > 0,
  );
  const latestDueAmount = feeLedger.history[0]?.dueAmount ?? 0;
  const feesDue = hasMonthlyFeeSnapshots
    ? latestDueAmount
    : latestDueAmount + currentMonthlyFee;

  return {
    student: {
      name: student.user.name,
      className: student.class.name,
      roll: student.rollNumber,
      attendanceRate,
      feesDue,
    },
    recentResults: results.map((result) =>
      withStudentResultTotalMarks(result, student.classId),
    ),
    notices,
    upcomingExams: exams
      .filter((exam) => exam.status !== "ARCHIVED")
      .slice(0, 6)
      .map((exam) => ({
        id: exam.id,
        name: exam.name,
        code: exam.code,
        date: exam.date,
        status: exam.status,
        className: exam.class.name,
        examType: getExamTypeLabel(exam.examType),
      })),
  };
}

export async function getStudentProfile(userId: string) {
  const student = await requireStudentPortalContext(userId);

  return {
    id: student.id,
    name: student.user.name,
    email: student.user.email,
    phone: student.phone,
    gender: student.gender,
    className: student.class.name,
    groupName: student.group?.name ?? null,
    sectionName: student.section?.name ?? null,
    rollNumber: student.rollNumber,
    guardian: student.guardian
      ? {
          name: student.guardian.name,
          email: student.guardian.email,
          phone: student.guardian.phone,
          address: student.guardian.address,
          relation: student.guardian.relation,
        }
      : null,
    father: student.fatherName
      ? {
          name: student.fatherName,
          phone: student.fatherPhone,
        }
      : null,
    mother: student.motherName
      ? {
          name: student.motherName,
          phone: student.motherPhone,
        }
      : null,
  };
}

export async function listStudentResults(userId: string) {
  const student = await requireStudentPortalContext(userId);
  const results = await prisma.result.findMany({
    where: { studentId: student.id },
    orderBy: [{ exam: { date: "desc" } }, { subject: { name: "asc" } }],
    select: {
      id: true,
      subjectId: true,
      marks: true,
      grade: true,
      exam: {
        select: {
          id: true,
          name: true,
          date: true,
          subjects: {
            select: {
              classId: true,
              subjectId: true,
              fullMarks: true,
              components: { select: { fullMarks: true } },
            },
          },
        },
      },
      subject: {
        select: {
          name: true,
        },
      },
    },
  });

  return results.map((result) =>
    withStudentResultTotalMarks(result, student.classId),
  );
}

export async function listStudentAttendance(userId: string) {
  const student = await requireStudentPortalContext(userId);
  const records = await prisma.attendance.findMany({
    where: { studentId: student.id },
    orderBy: [{ date: "desc" }, { period: "asc" }],
    select: {
      id: true,
      date: true,
      status: true,
      period: true,
      subject: {
        select: {
          name: true,
        },
      },
    },
  });

  return {
    records,
    summary: buildAttendanceSummary(records),
  };
}

export async function listStudentPayments(userId: string) {
  const student = await requireStudentPortalContext(userId);
  const payments = await prisma.payment.findMany({
    where: {
      studentId: student.id,
      feeCategory: {
        isActive: true,
      },
    },
    orderBy: [{ year: "desc" }, { month: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      amountPaid: true,
      status: true,
      paymentMethod: true,
      transactionId: true,
      month: true,
      year: true,
      dueDate: true,
      createdAt: true,
      feeCategory: {
        select: {
          id: true,
          name: true,
          amount: true,
        },
      },
      student: {
        select: {
          id: true,
          user: {
            select: {
              name: true,
            },
          },
          class: {
            select: {
              name: true,
              monthlyFeeSetting: {
                select: {
                  monthlyFee: true,
                  isActive: true,
                },
              },
            },
          },
        },
      },
    },
  });

  return {
    ...buildFeeLedger(payments),
    currentMonthlyFee: getCurrentMonthlyFee(student.class.monthlyFeeSetting),
  };
}

export async function listStudentNotices(userId: string) {
  await syncExpiredNotices();
  const student = await requireStudentPortalContext(userId);
  return prisma.notice.findMany({
    where: {
      ...buildVisibleNoticeWhere(),
      OR: [
        { audience: "ALL" },
        { audience: "STUDENTS" },
        { classId: student.classId },
      ],
    },
    orderBy: { createdAt: "desc" },
    take: 20,
    select: {
      id: true,
      title: true,
      content: true,
      audience: true,
      createdAt: true,
      class: { select: { name: true } },
    },
  });
}

export async function listStudentTimetable(userId: string) {
  await syncExpiredNotices();
  const student = await requireStudentPortalContext(userId);
  const timetable = await prisma.timetable.findMany({
    where: { classId: student.classId },
    orderBy: [{ day: "asc" }, { startTime: "asc" }],
    select: {
      id: true,
      day: true,
      startTime: true,
      endTime: true,
      subject: {
        select: {
          id: true,
          name: true,
        },
      },
      teacher: {
        select: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
    },
  });

  return weekDays.map((day) => ({
    day,
    sessions: timetable
      .filter((item) => item.day === day)
      .map((item) => ({
        id: item.id,
        startTime: item.startTime,
        endTime: item.endTime,
        subject: item.subject,
        teacher: item.teacher,
      })),
  }));
}
