import {
  ExamLifecycleStatus,
  type ExamTypeCategory,
  Prisma,
} from "@prisma/client";
import { EXAM_TYPE_OPTIONS } from "@/constants/exam-types";
import { findClassById, listClasses } from "@/repositories/class.repository";
import {
  createExamRecord,
  deleteExamRecord,
  findExamById,
  listExams,
  updateExamRecord,
  type ExamDetailRecord,
  type ExamRecord,
} from "@/repositories/exam.repository";
import {
  listSubjects,
  findSubjectById,
} from "@/repositories/subject.repository";
import { prisma } from "@/lib/prisma";
import { getScopedBranchId } from "@/lib/request-context";
import { HttpError } from "@/utils/error-handler";
import { recordAuditEvent } from "@/services/audit.service";

const LOCKED_STATUSES: ExamLifecycleStatus[] = [
  ExamLifecycleStatus.RESULT_PUBLISHED,
  ExamLifecycleStatus.ARCHIVED,
];

type ExamWorkspaceFilters = {
  search?: string;
  classId?: string;
  status?: ExamLifecycleStatus;
  academicYear?: string;
  examTypeId?: ExamTypeCategory;
  includeArchived?: boolean;
};

function trimText(value?: string | null) {
  const trimmed = value?.trim();
  return trimmed ? trimmed : undefined;
}

function toDateOrNull(value?: string | null) {
  const trimmed = trimText(value);
  if (!trimmed) return null;
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new HttpError("Invalid date value", 400);
  }
  return parsed;
}

function uniqueIds(ids: string[]) {
  return Array.from(new Set(ids.map((item) => item.trim()).filter(Boolean)));
}

function buildSnapshot(exam: ExamDetailRecord | ExamRecord) {
  return {
    id: exam.id,
    name: exam.name,
    code: exam.code,
    date: exam.date,
    description: exam.description,
    academicYear: exam.academicYear,
    status: exam.status,
    visibility: {
      students: exam.visibleToStudents,
      parents: exam.visibleToParents,
      teachers: exam.visibleToTeachers,
    },
    generateResult: exam.generateResult,
    includeInFinalReport: exam.includeInFinalReport,
    includeInTranscript: exam.includeInTranscript,
    includeInMeritList: exam.includeInMeritList,
    lockAfterPublish: exam.lockAfterPublish,
    publishStartsAt: exam.publishStartsAt,
    publishEndsAt: exam.publishEndsAt,
    resultPublishAt: exam.resultPublishAt,
    isAllClasses: exam.isAllClasses,
    class: exam.class,
    examType: exam.examType,
    counts: exam._count,
    assignedClasses: "assignedClasses" in exam ? exam.assignedClasses : [],
    subjects: "subjects" in exam ? exam.subjects : [],
    teacherAssignments:
      "teacherAssignments" in exam ? exam.teacherAssignments : [],
  };
}

async function ensureClassesExist(classIds: string[]) {
  const classes = await prisma.class.findMany({
    where: { id: { in: classIds } },
    select: { id: true, name: true },
  });

  if (classes.length !== classIds.length) {
    throw new HttpError("One or more selected classes do not exist", 404);
  }

  return classes;
}

async function ensureSubjectsExist(subjectId: string) {
  const subject = await findSubjectById(subjectId);
  if (!subject) {
    throw new HttpError("Selected subject does not exist", 404);
  }
  return subject;
}

async function ensureTeacherExists(teacherId: string) {
  const teacher = await prisma.teacher.findUnique({
    where: { id: teacherId },
    select: {
      id: true,
      user: { select: { name: true } },
    },
  });

  if (!teacher) {
    throw new HttpError("Selected teacher does not exist", 404);
  }

  return teacher;
}

function assertExamCanBeEdited(exam: ExamDetailRecord) {
  if (LOCKED_STATUSES.includes(exam.status)) {
    throw new HttpError("This exam is locked after result publication", 400);
  }
}

function assertExamCanBeDeleted(exam: ExamDetailRecord) {
  if (
    exam.status !== ExamLifecycleStatus.DRAFT &&
    exam.status !== ExamLifecycleStatus.ASSIGNED
  ) {
    throw new HttpError("Published exams can only be archived", 400);
  }
}

async function recordExamHistory(
  examId: string,
  actorId: string | null | undefined,
  action: string,
  snapshot: Prisma.InputJsonValue,
  metadata?: Prisma.InputJsonValue | null,
) {
  try {
    await prisma.examHistory.create({
      data: {
        examId,
        actorId: actorId ?? null,
        action,
        snapshot,
        metadata: metadata === null ? Prisma.DbNull : (metadata ?? undefined),
      },
    });
  } catch (error) {
    console.error("Failed to record exam history", error);
  }
}

function normalizeSelectedClassIds(payload: {
  classId: string;
  classIds?: string[];
  isAllClasses?: boolean;
  availableClassIds: string[];
}) {
  const selected = payload.isAllClasses
    ? payload.availableClassIds
    : uniqueIds([payload.classId, ...(payload.classIds ?? [])]);

  if (!selected.length) {
    throw new HttpError("At least one class must be assigned", 400);
  }

  if (!selected.includes(payload.classId)) {
    selected.unshift(payload.classId);
  }

  return uniqueIds(selected);
}

async function validateAssignmentCoverage(examId: string, classId: string) {
  const assigned = await prisma.examClassAssignment.findFirst({
    where: {
      examId,
      classId,
    },
  });

  if (!assigned) {
    const exam = await findExamById(examId);
    if (!exam?.isAllClasses && exam?.classId !== classId) {
      throw new HttpError("Selected class is not assigned to this exam", 400);
    }
  }
}

async function validateSubjectMatchesClass(classId: string, subjectId: string) {
  const subject = await ensureSubjectsExist(subjectId);
  if (subject.classId !== classId) {
    throw new HttpError(
      "Selected subject does not belong to the chosen class",
      400,
    );
  }
}

async function validateComponentTotals(
  examSubjectId: string,
  client: Pick<typeof prisma, "examSubject"> = prisma,
) {
  const examSubject = await client.examSubject.findUnique({
    where: { id: examSubjectId },
    select: {
      id: true,
      fullMarks: true,
      components: {
        select: {
          fullMarks: true,
        },
      },
    },
  });

  if (!examSubject?.fullMarks) return;

  const componentMarks = examSubject.components
    .map((component) => component.fullMarks)
    .filter((value): value is number => typeof value === "number");

  if (
    componentMarks.length !== examSubject.components.length ||
    componentMarks.length === 0
  ) {
    return;
  }

  const total = componentMarks.reduce((sum, value) => sum + value, 0);
  if (Math.abs(total - examSubject.fullMarks) > 0.001) {
    throw new HttpError(
      "Component marks must add up to the subject full marks",
      400,
    );
  }
}

export async function listExamWorkspace(filters: ExamWorkspaceFilters = {}) {
  const [exams, classes, subjects, teachers] = await Promise.all([
    listExams(filters),
    listClasses(),
    listSubjects({}),
    prisma.teacher.findMany({
      where: {
        isDeleted: false,
        user: { isDeleted: false },
      },
      orderBy: { user: { name: "asc" } },
      select: {
        id: true,
        user: { select: { name: true } },
      },
    }),
  ]);

  return {
    exams,
    classes,
    subjects,
    teachers: teachers.map((teacher) => ({
      id: teacher.id,
      name: teacher.user.name,
    })),
    examTypes: EXAM_TYPE_OPTIONS.map((item) => ({
      id: item.value,
      name: item.label,
      code: item.value,
    })),
    stats: {
      total: exams.length,
      upcoming: exams.filter((item) => new Date(item.date) >= new Date())
        .length,
      published: exams.filter(
        (item) => item.status === ExamLifecycleStatus.PUBLISHED,
      ).length,
      resultPublished: exams.filter(
        (item) => item.status === ExamLifecycleStatus.RESULT_PUBLISHED,
      ).length,
      archived: exams.filter(
        (item) => item.status === ExamLifecycleStatus.ARCHIVED,
      ).length,
    },
  };
}

export async function getExamDetailForAdmin(id: string) {
  const exam = await findExamById(id);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  return { exam };
}

export async function createExamForAdmin(payload: {
  name: string;
  code: string;
  date: string;
  description?: string;
  academicYear: string;
  classIds?: string[];
  isAllClasses?: boolean;
  examTypeId?: ExamTypeCategory | null;
  status?: ExamLifecycleStatus;
  visibleToStudents?: boolean;
  visibleToParents?: boolean;
  visibleToTeachers?: boolean;
  generateResult?: boolean;
  includeInFinalReport?: boolean;
  includeInTranscript?: boolean;
  includeInMeritList?: boolean;
  lockAfterPublish?: boolean;
  publishStartsAt?: string | null;
  publishEndsAt?: string | null;
  resultPublishAt?: string | null;
}) {
  const branchId = getScopedBranchId();
  const name = trimText(payload.name);
  const code = trimText(payload.code)?.toUpperCase();
  const academicYear = trimText(payload.academicYear);
  if (!name) throw new HttpError("Exam name is required", 400);
  if (!code) throw new HttpError("Exam code is required", 400);
  if (!academicYear) throw new HttpError("Academic year is required", 400);

  const examDate = toDateOrNull(payload.date);
  if (!examDate) throw new HttpError("Exam date is required", 400);

  const selectedClassIds = uniqueIds(payload.classIds ?? []);
  if (!selectedClassIds.length) {
    throw new HttpError("At least one class must be selected", 400);
  }

  const primaryClassId = selectedClassIds[0];
  if (!primaryClassId) {
    throw new HttpError("At least one class must be selected", 400);
  }

  const primaryClass = await findClassById(primaryClassId);
  if (!primaryClass) {
    throw new HttpError("Selected class does not exist", 404);
  }

  const availableClasses = await listClasses();
  const availableClassIds = availableClasses.map((item) => item.id);
  const assignedClassIds = payload.isAllClasses
    ? availableClassIds
    : selectedClassIds;

  await ensureClassesExist(assignedClassIds);

  const duplicateCode = await prisma.exam.findFirst({ where: { code } });
  if (duplicateCode) {
    throw new HttpError("Duplicate exam code is not allowed", 409);
  }

  const duplicateName = await prisma.exam.findFirst({
    where: {
      name,
      academicYear,
      classId: primaryClassId,
    },
  });
  if (duplicateName) {
    throw new HttpError(
      "An exam with the same name and class already exists for this academic year",
      409,
    );
  }

  const exam = await createExamRecord({
    name,
    code,
    date: examDate,
    description: trimText(payload.description),
    academicYear,
    status: payload.status ?? ExamLifecycleStatus.DRAFT,
    visibleToStudents: payload.visibleToStudents ?? false,
    visibleToParents: payload.visibleToParents ?? false,
    visibleToTeachers: payload.visibleToTeachers ?? true,
    generateResult: payload.generateResult ?? true,
    includeInFinalReport: payload.includeInFinalReport ?? false,
    includeInTranscript: payload.includeInTranscript ?? false,
    includeInMeritList: payload.includeInMeritList ?? false,
    lockAfterPublish: payload.lockAfterPublish ?? true,
    publishStartsAt: toDateOrNull(payload.publishStartsAt),
    publishEndsAt: toDateOrNull(payload.publishEndsAt),
    resultPublishAt: toDateOrNull(payload.resultPublishAt),
    isAllClasses: payload.isAllClasses ?? false,
    class: { connect: { id: primaryClassId } },
    examType:
      payload.examTypeId ?? EXAM_TYPE_OPTIONS[0]?.value ?? "MONTHLY_EXAM",
    assignedClasses: {
      create: assignedClassIds.map((classId) => ({
        ...(branchId ? { branchId } : {}),
        class: { connect: { id: classId } },
      })),
    },
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.created",
    entityType: "Exam",
    entityId: exam.id,
    metadata: {
      classIds: assignedClassIds,
      isAllClasses: payload.isAllClasses ?? false,
    },
  });

  await recordExamHistory(exam.id, null, "created", buildSnapshot(exam), {
    classIds: assignedClassIds,
  });

  return exam;
}

export async function updateExamForAdmin(
  id: string,
  payload: {
    name?: string;
    code?: string;
    date?: string;
    description?: string;
    academicYear?: string;
    classIds?: string[];
    isAllClasses?: boolean;
    examTypeId?: ExamTypeCategory | null;
    status?: ExamLifecycleStatus;
    visibleToStudents?: boolean;
    visibleToParents?: boolean;
    visibleToTeachers?: boolean;
    generateResult?: boolean;
    includeInFinalReport?: boolean;
    includeInTranscript?: boolean;
    includeInMeritList?: boolean;
    lockAfterPublish?: boolean;
    publishStartsAt?: string | null;
    publishEndsAt?: string | null;
    resultPublishAt?: string | null;
  },
) {
  const branchId = getScopedBranchId();
  const existing = await findExamById(id);
  if (!existing) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(existing);

  const nextName = payload.name ? trimText(payload.name) : undefined;
  const nextCode = payload.code
    ? trimText(payload.code)?.toUpperCase()
    : undefined;
  const nextAcademicYear = payload.academicYear
    ? trimText(payload.academicYear)
    : undefined;
  const nextDate = payload.date ? toDateOrNull(payload.date) : undefined;
  const nextDescription = payload.description
    ? trimText(payload.description)
    : undefined;
  const nextIsAllClasses = payload.isAllClasses ?? existing.isAllClasses;

  if (nextCode) {
    const duplicateCode = await prisma.exam.findFirst({
      where: {
        code: nextCode,
        id: { not: id },
      },
    });
    if (duplicateCode) {
      throw new HttpError("Duplicate exam code is not allowed", 409);
    }
  }

  if (nextName || nextAcademicYear || payload.classIds) {
    const duplicateName = await prisma.exam.findFirst({
      where: {
        id: { not: id },
        name: nextName ?? existing.name,
        academicYear: nextAcademicYear ?? existing.academicYear,
        classId: existing.classId,
      },
    });
    if (duplicateName) {
      throw new HttpError(
        "An exam with the same name and class already exists for this academic year",
        409,
      );
    }
  }

  let selectedClassIds = existing.assignedClasses.map((item) => item.class.id);
  if (payload.classIds || payload.isAllClasses !== undefined) {
    const availableClasses = await listClasses();
    const availableClassIds = availableClasses.map((item) => item.id);
    selectedClassIds = normalizeSelectedClassIds({
      classId: selectedClassIds[0] ?? existing.classId,
      classIds: payload.classIds ?? selectedClassIds,
      isAllClasses: nextIsAllClasses,
      availableClassIds,
    });
    await ensureClassesExist(selectedClassIds);
  }

  const nextStatus =
    payload.status ??
    (payload.classIds || payload.isAllClasses !== undefined
      ? existing.status === ExamLifecycleStatus.DRAFT
        ? ExamLifecycleStatus.ASSIGNED
        : existing.status
      : existing.status);

  const updated = await updateExamRecord(id, {
    ...(nextName ? { name: nextName } : {}),
    ...(nextCode ? { code: nextCode } : {}),
    ...(nextDate ? { date: nextDate } : {}),
    ...(nextDescription !== undefined ? { description: nextDescription } : {}),
    ...(nextAcademicYear ? { academicYear: nextAcademicYear } : {}),
    ...(payload.examTypeId !== undefined && payload.examTypeId !== null
      ? { examType: payload.examTypeId }
      : {}),
    ...(payload.status
      ? { status: nextStatus }
      : payload.classIds || payload.isAllClasses !== undefined
        ? { status: nextStatus }
        : {}),
    ...(payload.visibleToStudents !== undefined
      ? { visibleToStudents: payload.visibleToStudents }
      : {}),
    ...(payload.visibleToParents !== undefined
      ? { visibleToParents: payload.visibleToParents }
      : {}),
    ...(payload.visibleToTeachers !== undefined
      ? { visibleToTeachers: payload.visibleToTeachers }
      : {}),
    ...(payload.generateResult !== undefined
      ? { generateResult: payload.generateResult }
      : {}),
    ...(payload.includeInFinalReport !== undefined
      ? { includeInFinalReport: payload.includeInFinalReport }
      : {}),
    ...(payload.includeInTranscript !== undefined
      ? { includeInTranscript: payload.includeInTranscript }
      : {}),
    ...(payload.includeInMeritList !== undefined
      ? { includeInMeritList: payload.includeInMeritList }
      : {}),
    ...(payload.lockAfterPublish !== undefined
      ? { lockAfterPublish: payload.lockAfterPublish }
      : {}),
    ...(payload.publishStartsAt !== undefined
      ? { publishStartsAt: toDateOrNull(payload.publishStartsAt) }
      : {}),
    ...(payload.publishEndsAt !== undefined
      ? { publishEndsAt: toDateOrNull(payload.publishEndsAt) }
      : {}),
    ...(payload.resultPublishAt !== undefined
      ? { resultPublishAt: toDateOrNull(payload.resultPublishAt) }
      : {}),
    ...(payload.classIds || payload.isAllClasses !== undefined
      ? {
          isAllClasses: nextIsAllClasses,
          class: { connect: { id: selectedClassIds[0] ?? existing.classId } },
          assignedClasses: {
            deleteMany: {},
            create: selectedClassIds.map((classId) => ({
              ...(branchId ? { branchId } : {}),
              class: { connect: { id: classId } },
            })),
          },
        }
      : {}),
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.updated",
    entityType: "Exam",
    entityId: updated.id,
    metadata: {
      classIds: selectedClassIds,
      status: nextStatus,
    },
  });

  await recordExamHistory(updated.id, null, "updated", buildSnapshot(updated), {
    classIds: selectedClassIds,
  });

  return updated;
}

export async function archiveExamForAdmin(id: string) {
  const existing = await findExamById(id);
  if (!existing) {
    throw new HttpError("Exam not found", 404);
  }

  if (
    existing.status === ExamLifecycleStatus.RESULT_PUBLISHED ||
    existing.status === ExamLifecycleStatus.ARCHIVED
  ) {
    return existing;
  }

  const updated = await updateExamRecord(id, {
    status: ExamLifecycleStatus.ARCHIVED,
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.archived",
    entityType: "Exam",
    entityId: updated.id,
  });

  await recordExamHistory(updated.id, null, "archived", buildSnapshot(updated));

  return updated;
}

export async function deleteExamForAdmin(id: string) {
  const existing = await findExamById(id);
  if (!existing) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeDeleted(existing);

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.deleted",
    entityType: "Exam",
    entityId: existing.id,
  });

  return deleteExamRecord(id);
}

export async function upsertExamSubjectForAdmin(
  examId: string,
  payload: {
    classId: string;
    subjectId: string;
    displayOrder?: number;
    isMandatory?: boolean;
    fullMarks?: number | null;
    passMarks?: number | null;
  },
) {
  const branchId = getScopedBranchId();
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);
  await validateAssignmentCoverage(examId, payload.classId);
  await validateSubjectMatchesClass(payload.classId, payload.subjectId);

  const saved = await prisma.$transaction(async (transaction) => {
    const record = await transaction.examSubject.upsert({
      where: {
        examId_classId_subjectId: {
          examId,
          classId: payload.classId,
          subjectId: payload.subjectId,
        },
      },
      update: {
        displayOrder: payload.displayOrder ?? 0,
        isMandatory: payload.isMandatory ?? true,
        fullMarks: payload.fullMarks ?? null,
        passMarks: payload.passMarks ?? null,
      },
      create: {
        ...(branchId ? { branchId } : {}),
        exam: { connect: { id: examId } },
        class: { connect: { id: payload.classId } },
        subject: { connect: { id: payload.subjectId } },
        displayOrder: payload.displayOrder ?? 0,
        isMandatory: payload.isMandatory ?? true,
        fullMarks: payload.fullMarks ?? null,
        passMarks: payload.passMarks ?? null,
      },
    });

    if (
      record.passMarks !== null &&
      record.fullMarks !== null &&
      record.passMarks > record.fullMarks
    ) {
      throw new HttpError("Pass marks cannot exceed full marks", 400);
    }

    await validateComponentTotals(record.id, transaction);

    return transaction.examSubject.findUnique({
      where: { id: record.id },
      select: {
        id: true,
        displayOrder: true,
        isMandatory: true,
        fullMarks: true,
        passMarks: true,
        class: { select: { id: true, name: true } },
        subject: { select: { id: true, name: true } },
        components: {
          orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }],
          select: {
            id: true,
            name: true,
            displayOrder: true,
            fullMarks: true,
            isMandatory: true,
          },
        },
      },
    });
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.subject.upserted",
    entityType: "ExamSubject",
    entityId: saved?.id ?? null,
    metadata: {
      examId,
      classId: payload.classId,
      subjectId: payload.subjectId,
    },
  });

  if (saved) {
    await recordExamHistory(
      examId,
      null,
      "subject-upserted",
      buildSnapshot(exam),
      {
        subjectId: payload.subjectId,
        classId: payload.classId,
      },
    );
  }

  return saved;
}

export async function deleteExamSubjectForAdmin(
  examId: string,
  payload: { classId: string; subjectId: string },
) {
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);
  await validateAssignmentCoverage(examId, payload.classId);

  const deleted = await prisma.examSubject.delete({
    where: {
      examId_classId_subjectId: {
        examId,
        classId: payload.classId,
        subjectId: payload.subjectId,
      },
    },
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.subject.deleted",
    entityType: "ExamSubject",
    entityId: deleted.id,
    metadata: {
      examId,
      classId: payload.classId,
      subjectId: payload.subjectId,
    },
  });

  await recordExamHistory(
    examId,
    null,
    "subject-deleted",
    buildSnapshot(exam),
    {
      subjectId: payload.subjectId,
      classId: payload.classId,
    },
  );

  return deleted;
}

export async function upsertExamComponentForAdmin(
  examId: string,
  payload: {
    examSubjectId: string;
    componentId?: string;
    name: string;
    displayOrder?: number;
    fullMarks?: number | null;
    isMandatory?: boolean;
  },
) {
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);

  const examSubject = await prisma.examSubject.findUnique({
    where: { id: payload.examSubjectId },
    select: {
      id: true,
      examId: true,
      classId: true,
      fullMarks: true,
    },
  });

  if (!examSubject || examSubject.examId !== examId) {
    throw new HttpError(
      "Selected exam subject does not belong to this exam",
      400,
    );
  }

  const saved = await prisma.$transaction(async (transaction) => {
    const record = payload.componentId
      ? await transaction.examComponent.update({
          where: { id: payload.componentId },
          data: {
            name: payload.name.trim(),
            displayOrder: payload.displayOrder ?? 0,
            fullMarks: payload.fullMarks ?? null,
            isMandatory: payload.isMandatory ?? true,
          },
        })
      : await transaction.examComponent.create({
          data: {
            examSubject: { connect: { id: payload.examSubjectId } },
            name: payload.name.trim(),
            displayOrder: payload.displayOrder ?? 0,
            fullMarks: payload.fullMarks ?? null,
            isMandatory: payload.isMandatory ?? true,
          },
        });

    const subjectTotals = await transaction.examComponent.findMany({
      where: { examSubjectId: payload.examSubjectId },
      select: { fullMarks: true },
    });
    const componentMarks = subjectTotals
      .map((component) => component.fullMarks)
      .filter((value): value is number => typeof value === "number");

    if (
      examSubject.fullMarks !== null &&
      componentMarks.length > 0 &&
      componentMarks.length === subjectTotals.length
    ) {
      const total = componentMarks.reduce((sum, value) => sum + value, 0);
      if (Math.abs(total - examSubject.fullMarks) > 0.001) {
        throw new HttpError(
          "Component marks must add up to the subject full marks",
          400,
        );
      }
    }

    return record;
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.component.upserted",
    entityType: "ExamComponent",
    entityId: saved.id,
    metadata: { examId, examSubjectId: payload.examSubjectId },
  });

  await recordExamHistory(
    examId,
    null,
    "component-upserted",
    buildSnapshot(exam),
    {
      examSubjectId: payload.examSubjectId,
    },
  );

  return saved;
}

export async function deleteExamComponentForAdmin(
  examId: string,
  componentId: string,
) {
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);

  const deleted = await prisma.examComponent.delete({
    where: { id: componentId },
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.component.deleted",
    entityType: "ExamComponent",
    entityId: deleted.id,
    metadata: { examId },
  });

  await recordExamHistory(
    examId,
    null,
    "component-deleted",
    buildSnapshot(exam),
    {
      componentId,
    },
  );

  return deleted;
}

export async function syncExamClassAssignmentsForAdmin(
  examId: string,
  payload: {
    classIds: string[];
    isAllClasses?: boolean;
  },
) {
  const branchId = getScopedBranchId();
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);

  const availableClasses = await listClasses();
  const availableClassIds = availableClasses.map((item) => item.id);
  const selectedClassIds = normalizeSelectedClassIds({
    classId: exam.classId,
    classIds: payload.classIds,
    isAllClasses: payload.isAllClasses,
    availableClassIds,
  });
  await ensureClassesExist(selectedClassIds);

  const updated = await updateExamRecord(examId, {
    isAllClasses: payload.isAllClasses ?? false,
    assignedClasses: {
      deleteMany: {},
      create: selectedClassIds.map((classId) => ({
        ...(branchId ? { branchId } : {}),
        class: { connect: { id: classId } },
      })),
    },
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.classes.updated",
    entityType: "Exam",
    entityId: updated.id,
    metadata: {
      classIds: selectedClassIds,
      isAllClasses: payload.isAllClasses ?? false,
    },
  });

  await recordExamHistory(
    examId,
    null,
    "classes-updated",
    buildSnapshot(updated),
    {
      classIds: selectedClassIds,
    },
  );

  return updated;
}

export async function upsertExamTeacherAssignmentForAdmin(
  examId: string,
  payload: {
    teacherId: string;
    classId: string;
    subjectId?: string | null;
    canEdit?: boolean;
  },
) {
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);
  await validateAssignmentCoverage(examId, payload.classId);

  const teacher = await ensureTeacherExists(payload.teacherId);
  void teacher;

  if (payload.subjectId) {
    await validateSubjectMatchesClass(payload.classId, payload.subjectId);
  }

  const assignmentSelect = {
    id: true,
    canEdit: true,
    teacher: { select: { id: true, user: { select: { name: true } } } },
    class: { select: { id: true, name: true } },
    subject: { select: { id: true, name: true } },
  } as const;

  const saved = payload.subjectId
    ? await prisma.examTeacherAssignment.upsert({
        where: {
          examId_teacherId_classId_subjectId: {
            examId,
            teacherId: payload.teacherId,
            classId: payload.classId,
            subjectId: payload.subjectId,
          },
        },
        update: {
          canEdit: payload.canEdit ?? false,
        },
        create: {
          exam: { connect: { id: examId } },
          teacher: { connect: { id: payload.teacherId } },
          class: { connect: { id: payload.classId } },
          subject: { connect: { id: payload.subjectId } },
          canEdit: payload.canEdit ?? false,
        },
        select: assignmentSelect,
      })
    : await prisma.examTeacherAssignment
        .findFirst({
          where: {
            examId,
            teacherId: payload.teacherId,
            classId: payload.classId,
            subjectId: null,
          },
        })
        .then(async (existingAssignment) => {
          if (existingAssignment) {
            return prisma.examTeacherAssignment.update({
              where: { id: existingAssignment.id },
              data: { canEdit: payload.canEdit ?? false },
              select: assignmentSelect,
            });
          }

          return prisma.examTeacherAssignment.create({
            data: {
              exam: { connect: { id: examId } },
              teacher: { connect: { id: payload.teacherId } },
              class: { connect: { id: payload.classId } },
              canEdit: payload.canEdit ?? false,
            },
            select: assignmentSelect,
          });
        });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.teacher-assignment.upserted",
    entityType: "ExamTeacherAssignment",
    entityId: saved.id,
    metadata: {
      examId,
      teacherId: payload.teacherId,
      classId: payload.classId,
      subjectId: payload.subjectId,
    },
  });

  await recordExamHistory(
    examId,
    null,
    "teacher-assignment-upserted",
    buildSnapshot(exam),
    {
      teacherId: payload.teacherId,
      classId: payload.classId,
      subjectId: payload.subjectId,
    },
  );

  return saved;
}

export async function deleteExamTeacherAssignmentForAdmin(
  examId: string,
  assignmentId: string,
) {
  const exam = await findExamById(examId);
  if (!exam) {
    throw new HttpError("Exam not found", 404);
  }

  assertExamCanBeEdited(exam);

  const deleted = await prisma.examTeacherAssignment.delete({
    where: { id: assignmentId },
  });

  await recordAuditEvent({
    actorId: null,
    action: "admin.exam.teacher-assignment.deleted",
    entityType: "ExamTeacherAssignment",
    entityId: deleted.id,
    metadata: { examId },
  });

  await recordExamHistory(
    examId,
    null,
    "teacher-assignment-deleted",
    buildSnapshot(exam),
    {
      assignmentId,
    },
  );

  return deleted;
}

export async function listVisibleStudentExams(studentId: string) {
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    select: {
      id: true,
      classId: true,
    },
  });

  if (!student) {
    throw new HttpError("Student not found", 404);
  }

  return listExams({ classId: student.classId, includeArchived: false }).then(
    (exams) =>
      exams.filter(
        (exam) =>
          exam.visibleToStudents && exam.status !== ExamLifecycleStatus.DRAFT,
      ),
  );
}

export async function listVisibleParentExams(classIds: string[]) {
  if (!classIds.length) return [];

  return prisma.exam.findMany({
    where: {
      status: { not: ExamLifecycleStatus.ARCHIVED },
      visibleToParents: true,
      OR: [
        { classId: { in: classIds } },
        { assignedClasses: { some: { classId: { in: classIds } } } },
      ],
      NOT: { status: ExamLifecycleStatus.DRAFT },
    },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      name: true,
      code: true,
      date: true,
      description: true,
      academicYear: true,
      status: true,
      visibleToStudents: true,
      visibleToParents: true,
      visibleToTeachers: true,
      isAllClasses: true,
      classId: true,
      class: { select: { id: true, name: true } },
      examType: true,
      _count: {
        select: {
          results: true,
          assignedClasses: true,
          subjects: true,
          teacherAssignments: true,
          history: true,
        },
      },
    },
  });
}

export async function listVisibleTeacherExams(
  teacherId: string,
  classIds: string[],
) {
  if (!classIds.length) return [];

  const teacherAssignments = await prisma.examTeacherAssignment.findMany({
    where: { teacherId },
    select: { examId: true },
  });
  const assignedExamIds = teacherAssignments.map((item) => item.examId);

  return prisma.exam.findMany({
    where: {
      status: { not: ExamLifecycleStatus.ARCHIVED },
      visibleToTeachers: true,
      NOT: { status: ExamLifecycleStatus.DRAFT },
      OR: [
        { classId: { in: classIds } },
        { assignedClasses: { some: { classId: { in: classIds } } } },
        { id: { in: assignedExamIds } },
      ],
    },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      name: true,
      code: true,
      date: true,
      description: true,
      academicYear: true,
      status: true,
      visibleToStudents: true,
      visibleToParents: true,
      visibleToTeachers: true,
      isAllClasses: true,
      classId: true,
      class: { select: { id: true, name: true } },
      examType: true,
      _count: {
        select: {
          results: true,
          assignedClasses: true,
          subjects: true,
          teacherAssignments: true,
          history: true,
        },
      },
    },
  });
}
