import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { listClasses } from "@/repositories/class.repository";
import {
  clearCurrentSession,
  createSession,
  findCurrentSession,
  findSessionById,
  listSessions,
  updateSessionRecord,
} from "@/repositories/session.repository";
import { HttpError } from "@/utils/error-handler";

function toDateOrNull(value?: string | null) {
  if (value === undefined) return undefined;
  if (value === null) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return null;
  }
  return date;
}

export async function listAcademicSessionsForAdmin(filters: {
  search?: string;
  includeInactive?: boolean;
} = {}) {
  const [sessions, current, classes] = await Promise.all([
    listSessions(filters),
    findCurrentSession(),
    listClasses(),
  ]);

  return {
    sessions,
    current,
    classes,
  };
}

export async function createAcademicSessionForAdmin(payload: {
  name: string;
  startsAt?: string;
  endsAt?: string;
  isActive?: boolean;
  makeCurrent?: boolean;
}) {
  const startsAt = payload.startsAt ? toDateOrNull(payload.startsAt) : undefined;
  const endsAt = payload.endsAt ? toDateOrNull(payload.endsAt) : undefined;

  if (payload.startsAt && !startsAt) {
    throw new HttpError("Invalid startsAt date", 400);
  }
  if (payload.endsAt && !endsAt) {
    throw new HttpError("Invalid endsAt date", 400);
  }
  if (startsAt && endsAt && endsAt < startsAt) {
    throw new HttpError("endsAt must be after startsAt", 400);
  }

  return prisma.$transaction(async (tx) => {
    if (payload.makeCurrent) {
      await clearCurrentSession(tx);
    }

    return createSession(
      {
        name: payload.name.trim(),
        startsAt: startsAt ?? null,
        endsAt: endsAt ?? null,
        isActive: payload.isActive ?? true,
        isCurrent: Boolean(payload.makeCurrent),
      },
      tx,
    );
  });
}

export async function setCurrentAcademicSessionForAdmin(
  sessionId: string,
  client: PrismaClientLike = prisma,
) {
  const session = await findSessionById(sessionId, client);
  if (!session) {
    throw new HttpError("Session not found", 404);
  }
  if (!session.isActive) {
    throw new HttpError("Cannot set an inactive session as current", 400);
  }

  return prisma.$transaction(async (tx) => {
    await clearCurrentSession(tx);
    return updateSessionRecord(sessionId, { isCurrent: true }, tx);
  });
}

export async function getCurrentAcademicSession() {
  return findCurrentSession();
}

type SessionMigrationMapping = {
  fromClassId: string;
  toClassId: string;
};

type LegacyClassParts = { base: string; suffix: string | null };

function parseLegacyCombinedClassName(name: string): LegacyClassParts {
  const trimmed = name.trim();
  const match = /^(\d+)\s*([A-Za-z])$/.exec(trimmed);
  if (!match) {
    return { base: trimmed, suffix: null };
  }
  return { base: match[1], suffix: match[2].toUpperCase() };
}

export function buildNextClassMappings(
  classes: Array<{ id: string; name: string; sortOrder: number }>,
) {
  const eligible = [...classes]
    .filter((row) => row.name.trim().toLowerCase() !== "unassigned")
    .map((row) => {
      const parts = parseLegacyCombinedClassName(row.name);
      return { ...row, base: parts.base, suffix: parts.suffix };
    });

  const byBase = new Map<
    string,
    { base: string; sortOrder: number; entries: typeof eligible }
  >();

  for (const row of eligible) {
    const group = byBase.get(row.base);
    if (!group) {
      byBase.set(row.base, {
        base: row.base,
        sortOrder: row.sortOrder,
        entries: [row],
      });
      continue;
    }
    group.sortOrder = Math.min(group.sortOrder, row.sortOrder);
    group.entries.push(row);
  }

  const baseGroups = Array.from(byBase.values()).sort(
    (a, b) => (a.sortOrder - b.sortOrder) || a.base.localeCompare(b.base),
  );

  const mappings: SessionMigrationMapping[] = [];
  for (let index = 0; index < baseGroups.length - 1; index += 1) {
    const fromGroup = baseGroups[index];
    const toGroup = baseGroups[index + 1];

    const toEntries = [...toGroup.entries].sort((a, b) => {
      const suffixA = a.suffix ?? "";
      const suffixB = b.suffix ?? "";
      return suffixA.localeCompare(suffixB) || a.name.localeCompare(b.name);
    });
    const defaultTo = toEntries[0];
    const toBySuffix = new Map<string, (typeof eligible)[number]>();
    for (const entry of toEntries) {
      if (entry.suffix && !toBySuffix.has(entry.suffix)) {
        toBySuffix.set(entry.suffix, entry);
      }
    }

    for (const fromEntry of fromGroup.entries) {
      const target =
        (fromEntry.suffix ? toBySuffix.get(fromEntry.suffix) : undefined) ??
        defaultTo;
      if (target) {
        mappings.push({ fromClassId: fromEntry.id, toClassId: target.id });
      }
    }
  }

  return mappings;
}

function dedupeMappings(mappings: SessionMigrationMapping[]) {
  const map = new Map<string, string>();
  for (const mapping of mappings) {
    map.set(mapping.fromClassId, mapping.toClassId);
  }
  return Array.from(map.entries()).map(([fromClassId, toClassId]) => ({
    fromClassId,
    toClassId,
  }));
}

async function assertSessionsExist(fromId: string, toId: string) {
  const [from, to] = await Promise.all([findSessionById(fromId), findSessionById(toId)]);
  if (!from) throw new HttpError("From session not found", 404);
  if (!to) throw new HttpError("To session not found", 404);
  return { from, to };
}

async function assertClassesExist(mappings: SessionMigrationMapping[]) {
  const classIds = Array.from(
    new Set(mappings.flatMap((m) => [m.fromClassId, m.toClassId])),
  );
  const classes = await prisma.class.findMany({
    where: { id: { in: classIds } },
    select: { id: true },
  });
  if (classes.length !== classIds.length) {
    throw new HttpError("One or more classes not found", 404);
  }
}

async function resetRollNumbersForClass(
  classId: string,
  sessionId: string,
  tx: PrismaClientLike,
) {
  const students = await tx.student.findMany({
    where: {
      isDeleted: false,
      user: { isDeleted: false },
      classId,
      sessionId,
    },
    orderBy: [{ rollNumber: "asc" }, { createdAt: "asc" }],
    select: { id: true },
  });

  for (let index = 0; index < students.length; index += 1) {
    await tx.student.update({
      where: { id: students[index].id },
      data: { rollNumber: index + 1 },
    });
  }

  return students.length;
}

export async function migrateStudentsToSessionForAdmin(payload: {
  fromSessionId: string;
  toSessionId: string;
  classMappings: SessionMigrationMapping[];
  resetRollNumbers?: boolean;
  clearGroupSection?: boolean;
}) {
  if (payload.fromSessionId === payload.toSessionId) {
    throw new HttpError("From and To session must be different", 400);
  }

  const mappings = dedupeMappings(payload.classMappings);
  if (mappings.length === 0) {
    throw new HttpError("At least one class mapping is required", 400);
  }

  await assertSessionsExist(payload.fromSessionId, payload.toSessionId);
  await assertClassesExist(mappings);

  const mappingToClassByFrom = new Map(
    mappings.map((mapping) => [mapping.fromClassId, mapping.toClassId]),
  );

  const fromStudents = await prisma.student.findMany({
    where: {
      isDeleted: false,
      user: { isDeleted: false },
      sessionId: payload.fromSessionId,
    },
    select: {
      id: true,
      classId: true,
    },
  });

  const toUpdate = fromStudents.filter((student) =>
    mappingToClassByFrom.has(student.classId),
  );

  const result = await prisma.$transaction(async (tx) => {
    for (const student of toUpdate) {
      const nextClassId = mappingToClassByFrom.get(student.classId)!;
      await tx.student.update({
        where: { id: student.id },
        data: {
          sessionId: payload.toSessionId,
          classId: nextClassId,
          ...(payload.clearGroupSection ? { groupId: null, sectionId: null } : {}),
          ...(payload.resetRollNumbers ? { rollNumber: null } : {}),
        },
      });
    }

    let rollResets = 0;
    if (payload.resetRollNumbers !== false) {
      const affectedToClasses = Array.from(
        new Set(toUpdate.map((student) => mappingToClassByFrom.get(student.classId)!)),
      );
      for (const classId of affectedToClasses) {
        rollResets += await resetRollNumbersForClass(
          classId,
          payload.toSessionId,
          tx,
        );
      }
    }

    return { updated: toUpdate.length, rollResets };
  });

  return {
    fromSessionId: payload.fromSessionId,
    toSessionId: payload.toSessionId,
    totalInFromSession: fromStudents.length,
    updated: result.updated,
    skipped: fromStudents.length - toUpdate.length,
    rollResets: result.rollResets,
  };
}

export async function migrateStudentsToNextClassByOrderForAdmin(payload: {
  fromSessionId: string;
  toSessionId: string;
  resetRollNumbers?: boolean;
  clearGroupSection?: boolean;
}) {
  const classes = await prisma.class.findMany({
    select: { id: true, name: true, sortOrder: true },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });
  const mappings = buildNextClassMappings(classes);
  if (mappings.length === 0) {
    throw new HttpError("Not enough classes are configured for promotion", 400);
  }

  return migrateStudentsToSessionForAdmin({
    fromSessionId: payload.fromSessionId,
    toSessionId: payload.toSessionId,
    classMappings: mappings,
    resetRollNumbers: payload.resetRollNumbers,
    clearGroupSection: payload.clearGroupSection,
  });
}
