import { Role } from "@prisma/client";
import { hashPassword, type TokenPayload } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { listClasses } from "@/repositories/class.repository";
import { listSubjects } from "@/repositories/subject.repository";
import {
  countTeachers,
  createTeacher,
  findTeacherById,
  listTeachers,
  updateTeacherRecord,
} from "@/repositories/teacher.repository";
import { createUser, findUserByEmail } from "@/repositories/user.repository";
import { HttpError } from "@/utils/error-handler";

export type TeacherListFilters = {
  search?: string;
  includeDeleted?: boolean;
  branchId?: string | null;
};

export type CreateTeacherInput = {
  name: string;
  email: string;
  password: string;
  phone?: string;
  address?: string;
  salary?: number;
  classIds?: string[];
  subjectAssignments?: Array<{
    classId: string;
    subjectId: string;
  }>;
  branchId?: string | null;
};

export type UpdateTeacherInput = {
  name?: string;
  email?: string;
  password?: string;
  phone?: string | null;
  address?: string | null;
  salary?: number | null;
  classIds?: string[];
  subjectAssignments?: Array<{
    classId: string;
    subjectId: string;
  }>;
  branchId?: string | null;
};

function isSuperAdminContext(context?: Pick<TokenPayload, "role"> | null) {
  return context?.role === Role.SUPER_ADMIN;
}

async function assertClassesExist(classIds: string[]) {
  if (classIds.length === 0) return;

  const classes = await prisma.class.findMany({
    where: {
      id: { in: classIds },
    },
    select: { id: true },
  });

  if (classes.length !== classIds.length) {
    throw new HttpError("One or more selected classes do not exist", 404);
  }
}

async function assertSubjectAssignmentsExist(
  assignments: Array<{ classId: string; subjectId: string }>
) {
  if (assignments.length === 0) return;

  const uniquePairs = Array.from(
    new Map(assignments.map((item) => [`${item.classId}:${item.subjectId}`, item])).values()
  );
  const subjectIds = Array.from(new Set(uniquePairs.map((item) => item.subjectId)));
  const subjects = await prisma.subject.findMany({
    where: {
      id: { in: subjectIds },
    },
    select: {
      id: true,
      classId: true,
    },
  });

  if (subjects.length !== subjectIds.length) {
    throw new HttpError("One or more selected subjects do not exist", 404);
  }

  const subjectMap = new Map(subjects.map((subject) => [subject.id, subject]));

  for (const assignment of uniquePairs) {
    const subject = subjectMap.get(assignment.subjectId);
    if (!subject || subject.classId !== assignment.classId) {
      throw new HttpError("One or more subject assignments do not belong to the selected class", 400);
    }
  }
}

function resolveManagedClassIds(payload: {
  classIds?: string[];
  subjectAssignments?: Array<{ classId: string; subjectId: string }>;
}) {
  return Array.from(
    new Set([
      ...(payload.classIds ?? []),
      ...((payload.subjectAssignments ?? []).map((item) => item.classId)),
    ])
  );
}

export async function listTeachersForAdmin(filters: TeacherListFilters) {
  const [teachers, total, classes, subjects] = await Promise.all([
    listTeachers(filters),
    countTeachers(Boolean(filters.includeDeleted), filters.branchId),
    listClasses(),
    listSubjects({}),
  ]);

  return {
    teachers,
    classes,
    subjects: subjects.map((subject) => ({
      id: subject.id,
      name: subject.name,
      classId: subject.class.id,
      className: subject.class.name,
    })),
    stats: {
      total,
      active: teachers.filter((teacher) => !teacher.isDeleted).length,
      deleted: teachers.filter((teacher) => teacher.isDeleted).length,
    },
  };
}

export async function createTeacherForAdmin(payload: CreateTeacherInput) {
  const normalizedEmail = payload.email.trim().toLowerCase();
  const branchId = payload.branchId?.trim() || undefined;
  const existingUser = await findUserByEmail(normalizedEmail);

  if (existingUser) {
    throw new HttpError("Email already exists", 409);
  }

  const managedClassIds = resolveManagedClassIds(payload);
  const uniqueSubjectAssignments = Array.from(
    new Map((payload.subjectAssignments ?? []).map((item) => [`${item.classId}:${item.subjectId}`, item])).values()
  );

  await Promise.all([
    assertClassesExist(managedClassIds),
    assertSubjectAssignmentsExist(uniqueSubjectAssignments),
  ]);

  return prisma.$transaction(async (tx) => {
    const password = await hashPassword(payload.password);
    const user = await createUser(
      {
        name: payload.name.trim(),
        email: normalizedEmail,
        password,
        role: "TEACHER",
        ...(branchId
          ? { branch: { connect: { id: branchId } } }
          : {}),
      },
      tx
    );

    return createTeacher(
      {
        user: {
          connect: { id: user.id },
        },
        phone: payload.phone?.trim() || null,
        address: payload.address?.trim() || null,
        salary: payload.salary ?? null,
        ...(managedClassIds.length
          ? {
              managedClasses: {
                create: managedClassIds.map((classId) => ({
                  ...(branchId ? { branchId } : {}),
                  class: {
                    connect: { id: classId },
                  },
                })),
              },
            }
          : {}),
        ...(uniqueSubjectAssignments.length
          ? {
              subjects: {
                create: uniqueSubjectAssignments.map((item) => ({
                  ...(branchId ? { branchId } : {}),
                  class: {
                    connect: { id: item.classId },
                  },
                  subject: {
                    connect: { id: item.subjectId },
                  },
                })),
              },
            }
          : {}),
      },
      tx
    );
  });
}

export async function updateTeacherForAdmin(
  teacherId: string,
  payload: UpdateTeacherInput,
  context?: Pick<TokenPayload, "role" | "branchId">,
) {
  const existing = await findTeacherById(teacherId);

  if (
    !existing ||
    (!isSuperAdminContext(context) &&
      context?.branchId &&
      existing.user.branchId !== context.branchId)
  ) {
    throw new HttpError("Teacher not found", 404);
  }

  const nextSubjectAssignments =
    payload.subjectAssignments ??
    (payload.classIds
      ? existing.subjects
          .filter((item) => payload.classIds?.includes(item.classId))
          .map((item) => ({
            classId: item.classId,
            subjectId: item.subjectId,
          }))
      : undefined);
  const managedClassIds = resolveManagedClassIds({
    classIds: payload.classIds,
    subjectAssignments: nextSubjectAssignments,
  });
  const uniqueSubjectAssignments = Array.from(
    new Map((nextSubjectAssignments ?? []).map((item) => [`${item.classId}:${item.subjectId}`, item])).values()
  );
  const assignmentBranchId =
    (isSuperAdminContext(context) && payload.branchId !== undefined
      ? payload.branchId
      : existing?.user.branchId ?? context?.branchId) || undefined;

  if (payload.classIds || nextSubjectAssignments) {
    await Promise.all([
      assertClassesExist(managedClassIds),
      assertSubjectAssignmentsExist(uniqueSubjectAssignments),
    ]);
  }

  return prisma.$transaction(async (tx) => {
    const normalizedEmail = payload.email?.trim().toLowerCase();

    if (normalizedEmail) {
      const otherUser = await findUserByEmail(normalizedEmail, tx);
      if (otherUser && otherUser.id !== existing.user.id) {
        throw new HttpError("Email already exists", 409);
      }
    }

    await tx.user.update({
      where: { id: existing.user.id },
      data: {
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(normalizedEmail ? { email: normalizedEmail } : {}),
        ...(payload.password
          ? { password: await hashPassword(payload.password) }
          : {}),
        ...(payload.branchId !== undefined && isSuperAdminContext(context)
          ? payload.branchId
            ? { branch: { connect: { id: payload.branchId } } }
            : { branch: { disconnect: true } }
          : {}),
      },
    });

    return updateTeacherRecord(
      existing.id,
      {
        ...(payload.phone !== undefined ? { phone: payload.phone?.trim() || null } : {}),
        ...(payload.address !== undefined
          ? { address: payload.address?.trim() || null }
          : {}),
        ...(payload.salary !== undefined ? { salary: payload.salary } : {}),
        ...(payload.classIds || payload.subjectAssignments
          ? {
              managedClasses: {
                deleteMany: {},
                create: managedClassIds.map((classId) => ({
                  ...(assignmentBranchId ? { branchId: assignmentBranchId } : {}),
                  class: {
                    connect: { id: classId },
                  },
                })),
              },
            }
          : {}),
        ...(nextSubjectAssignments
          ? {
              subjects: {
                deleteMany: {},
                create: uniqueSubjectAssignments.map((item) => ({
                  ...(assignmentBranchId ? { branchId: assignmentBranchId } : {}),
                  class: {
                    connect: { id: item.classId },
                  },
                  subject: {
                    connect: { id: item.subjectId },
                  },
                })),
              },
            }
          : {}),
      },
      tx
    );
  });
}

export async function deactivateTeacherForAdmin(
  teacherId: string,
  context?: Pick<TokenPayload, "role" | "branchId">,
) {
  const existing = await findTeacherById(teacherId);

  if (
    !existing ||
    (!isSuperAdminContext(context) &&
      context?.branchId &&
      existing.user.branchId !== context.branchId)
  ) {
    throw new HttpError("Teacher not found", 404);
  }

  return prisma.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: existing.user.id },
      data: { isDeleted: true },
    });

    return updateTeacherRecord(existing.id, { isDeleted: true }, tx);
  });
}
