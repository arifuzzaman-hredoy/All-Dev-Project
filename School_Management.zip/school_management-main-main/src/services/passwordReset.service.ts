import { randomUUID } from "crypto";
import { hashPassword } from "@/lib/auth";
import { HttpError } from "@/utils/error-handler";
import { createPasswordResetToken, findValidPasswordResetToken, invalidatePasswordResetTokens, PASSWORD_RESET_EXPIRATION_MINUTES, markPasswordResetTokenUsed } from "@/repositories/passwordReset.repository";
import { findUserByEmail, updateUserPassword } from "@/repositories/user.repository";
import { sendPasswordResetEmail } from "@/utils/email";

const appOrigin = (process.env.NEXT_PUBLIC_APP_URL ?? process.env.APP_URL ?? process.env.NEXTAUTH_URL ?? "http://localhost:3000").replace(/\/+$/, "");
const RESET_PATH = "/reset-password";

const MESSAGE = "If an account exists for that email address, you will receive instructions shortly.";

export async function requestPasswordReset(email: string) {
  const normalizedEmail = email.trim().toLowerCase();
  const user = await findUserByEmail(normalizedEmail);
  if (!user) {
    return { message: MESSAGE };
  }

  await invalidatePasswordResetTokens(user.id);

  const token = randomUUID();
  const expiresAt = new Date(Date.now() + PASSWORD_RESET_EXPIRATION_MINUTES * 60 * 1000);
  await createPasswordResetToken({ userId: user.id, token, expiresAt });

  const link = `${appOrigin}${RESET_PATH}?token=${token}`;
  await sendPasswordResetEmail({
    to: user.email,
    name: user.name,
    link
  });

  const result: { message: string; debugToken?: string } = { message: MESSAGE };
  if (process.env.NODE_ENV !== "production") {
    result.debugToken = token;
  }

  return result;
}

export async function resetPassword(token: string, password: string) {
  const record = await findValidPasswordResetToken(token);
  if (!record) {
    throw new HttpError("Invalid or expired reset token", 400);
  }

  const hashedPassword = await hashPassword(password);
  await updateUserPassword(record.userId, hashedPassword);
  await markPasswordResetTokenUsed(record.id);

  return { message: "Password reset successfully" };
}
