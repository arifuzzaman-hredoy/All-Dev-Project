import { prisma } from "@/lib/prisma";
import {
  createManagedGroup,
  deleteManagedGroup,
  findClassById,
  findGroupById,
  findGroupByName,
  findManagedClassById,
  listManagedGroupsForClass,
  updateManagedGroup,
} from "@/repositories/class.repository";
import { HttpError } from "@/utils/error-handler";

const DEFAULT_GROUP_NAME = "General";

function isDefaultGroupName(name: string) {
  return name.trim().toLowerCase() === DEFAULT_GROUP_NAME.toLowerCase();
}

function assertGroupLimitWithinClass(params: {
  classLimit: number | null | undefined;
  groupLimit: number | null | undefined;
}) {
  if (
    params.classLimit !== null &&
    params.classLimit !== undefined &&
    params.groupLimit !== null &&
    params.groupLimit !== undefined &&
    params.groupLimit > params.classLimit
  ) {
    throw new HttpError(
      `Group student limit cannot be more than the class limit (${params.classLimit})`,
      400,
    );
  }
}

async function assertTotalGroupLimitWithinClass(params: {
  classId: string;
  classLimit: number | null | undefined;
  nextGroupLimit: number | null | undefined;
  excludeGroupId?: string;
}) {
  if (params.classLimit === null || params.classLimit === undefined) return;

  if (params.nextGroupLimit === null || params.nextGroupLimit === undefined) {
    throw new HttpError(
      `Group student limit is required because this class has a limit (${params.classLimit})`,
      400,
    );
  }

  const groups = await prisma.group.findMany({
    where: {
      classId: params.classId,
      ...(params.excludeGroupId ? { id: { not: params.excludeGroupId } } : {}),
    },
    select: { studentLimit: true },
  });
  const usedLimit = groups.reduce(
    (sum, group) => sum + (group.studentLimit ?? 0),
    0,
  );
  const nextTotal = usedLimit + params.nextGroupLimit;

  if (nextTotal > params.classLimit) {
    const remaining = Math.max(params.classLimit - usedLimit, 0);
    throw new HttpError(
      `Only ${remaining} group seats are available for this class limit (${params.classLimit})`,
      400,
    );
  }
}

export async function listGroupsForClassForAdmin(payload: {
  classId: string;
  search?: string;
}) {
  const classRecord = await findManagedClassById(payload.classId);
  if (!classRecord) {
    throw new HttpError("Class not found", 404);
  }

  const groups = await listManagedGroupsForClass(payload.classId, payload.search);
  return {
    class: classRecord,
    groups,
    stats: {
      total: groups.length,
      totalStudents: groups.reduce((sum, row) => sum + row._count.students, 0),
      totalSections: groups.reduce((sum, row) => sum + row._count.sections, 0),
    },
  };
}

export async function createGroupForClassForAdmin(payload: {
  classId: string;
  name: string;
  studentLimit?: number | null;
}) {
  const classRecord = await findClassById(payload.classId);
  if (!classRecord) {
    throw new HttpError("Class not found", 404);
  }

  const normalized = payload.name.trim();
  const existing = await findGroupByName(payload.classId, normalized);
  if (existing) {
    throw new HttpError("Group already exists", 409);
  }
  assertGroupLimitWithinClass({
    classLimit: classRecord.studentLimit,
    groupLimit: payload.studentLimit,
  });
  await assertTotalGroupLimitWithinClass({
    classId: payload.classId,
    classLimit: classRecord.studentLimit,
    nextGroupLimit: payload.studentLimit,
  });

  return createManagedGroup({
    classId: payload.classId,
    name: normalized,
    studentLimit: payload.studentLimit ?? null,
  });
}

export async function updateGroupForClassForAdmin(payload: {
  classId: string;
  groupId: string;
  name?: string;
  studentLimit?: number | null;
}) {
  const group = await findGroupById(payload.groupId);
  if (!group || group.classId !== payload.classId) {
    throw new HttpError("Group not found", 404);
  }
  const classRecord = await findClassById(payload.classId);
  if (!classRecord) {
    throw new HttpError("Class not found", 404);
  }

  const normalized = payload.name?.trim();
  if (
    normalized &&
    isDefaultGroupName(group.name) &&
    !isDefaultGroupName(normalized)
  ) {
    throw new HttpError("Default group cannot be renamed", 409);
  }

  if (normalized) {
    const existing = await findGroupByName(payload.classId, normalized);
    if (existing && existing.id !== payload.groupId) {
      throw new HttpError("Group already exists", 409);
    }
  }
  assertGroupLimitWithinClass({
    classLimit: classRecord.studentLimit,
    groupLimit: payload.studentLimit,
  });
  if (payload.studentLimit !== undefined) {
    await assertTotalGroupLimitWithinClass({
      classId: payload.classId,
      classLimit: classRecord.studentLimit,
      nextGroupLimit: payload.studentLimit,
      excludeGroupId: payload.groupId,
    });
  }

  return updateManagedGroup(payload.groupId, {
    ...(normalized ? { name: normalized } : {}),
    ...(payload.studentLimit !== undefined
      ? { studentLimit: payload.studentLimit }
      : {}),
  });
}

export async function deleteGroupForClassForAdmin(payload: {
  classId: string;
  groupId: string;
}) {
  const group = await prisma.group.findUnique({
    where: { id: payload.groupId },
    select: {
      id: true,
      name: true,
      classId: true,
      _count: { select: { students: true, sections: true } },
    },
  });
  if (!group || group.classId !== payload.classId) {
    throw new HttpError("Group not found", 404);
  }

  if (isDefaultGroupName(group.name)) {
    throw new HttpError("Default group cannot be deleted", 409);
  }

  if (group._count.students > 0) {
    throw new HttpError(
      "Move students out of this group before deleting it",
      409,
    );
  }

  return deleteManagedGroup(payload.groupId);
}
