import { NotificationChannel, PaymentStatus } from "@prisma/client";
import { getPaymentDueAmount } from "@/lib/fee-utils";
import { prisma } from "@/lib/prisma";
import { recordAuditEvent } from "@/services/audit.service";
import { listSystemSettingsForAdmin } from "@/services/systemSetting.service";
import {
  enqueueNotification,
  findNotificationTemplateByKey,
  listNotificationQueue,
  listNotificationTemplates,
  updateNotificationQueueStatus,
  upsertNotificationTemplate,
} from "@/repositories/notification.repository";
import { sendAppEmail } from "@/utils/email";

const DEFAULT_TEMPLATES = [
  {
    key: "fee_due_reminder",
    channel: NotificationChannel.EMAIL,
    subject: "Fee reminder for {{studentName}}",
    body: "<p>Hello {{guardianName}},</p><p>{{studentName}} has an outstanding {{feeCategory}} balance of ৳{{amountDue}}.</p><p>Please clear the dues at your earliest convenience.</p>",
    description: "Sent to guardians when fee balances remain due.",
  },
  {
    key: "attendance_alert",
    channel: NotificationChannel.EMAIL,
    subject: "Attendance alert for {{studentName}}",
    body: "<p>Hello {{guardianName}},</p><p>{{studentName}} currently has an attendance rate of {{attendancePercentage}}%.</p><p>Please review the attendance pattern with the school.</p>",
    description: "Sent to guardians when attendance falls below the threshold.",
  },
] as const;

function interpolate(
  template: string,
  values: Record<string, string | number | null | undefined>,
) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, token: string) =>
    String(values[token] ?? ""),
  );
}

async function ensureNotificationTemplates() {
  await Promise.all(
    DEFAULT_TEMPLATES.map((template) =>
      upsertNotificationTemplate({
        ...template,
        isActive: true,
      }),
    ),
  );
}

export async function getReminderPreview() {
  await ensureNotificationTemplates();
  const [lowAttendanceStudents, duePayments, settings] = await Promise.all([
    prisma.student.findMany({
      where: { isDeleted: false },
      select: {
        id: true,
        user: { select: { name: true } },
        guardian: { select: { email: true, name: true } },
        parent: { select: { user: { select: { email: true, name: true } } } },
        attendances: { select: { status: true } },
      },
    }),
    prisma.payment.findMany({
      where: { status: { in: [PaymentStatus.DUE, PaymentStatus.PARTIAL] } },
      select: {
        id: true,
        amountPaid: true,
        status: true,
        student: {
          select: {
            id: true,
            user: { select: { name: true } },
            guardian: { select: { email: true, name: true } },
            parent: {
              select: { user: { select: { email: true, name: true } } },
            },
            class: {
              select: {
                name: true,
                monthlyFeeSetting: {
                  select: {
                    monthlyFee: true,
                    isActive: true,
                  },
                },
              },
            },
          },
        },
        feeCategory: { select: { name: true, amount: true } },
      },
    }),
    listSystemSettingsForAdmin(),
  ]);

  const attendanceTargets = lowAttendanceStudents
    .map((student) => {
      const total = student.attendances.length;
      const present = student.attendances.filter(
        (item) => item.status === "PRESENT",
      ).length;
      const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
      const guardianEmail = student.guardian?.email ?? student.parent?.user.email ?? null;
      const guardianName = student.guardian?.name ?? student.parent?.user.name ?? null;
      return {
        studentId: student.id,
        studentName: student.user.name,
        percentage,
        guardianEmail,
        guardianName,
        parentEmail: guardianEmail,
        parentName: guardianName,
      };
    })
    .filter((item) => item.percentage < 75);

  const feeTargets = duePayments.map((payment) => ({
    paymentId: payment.id,
    studentId: payment.student.id,
    studentName: payment.student.user.name,
    feeCategory: payment.feeCategory.name,
    amountDue: getPaymentDueAmount(
      payment.student.class.monthlyFeeSetting?.isActive === false
        ? 0
        : payment.student.class.monthlyFeeSetting?.monthlyFee,
      payment.feeCategory.amount,
      payment.amountPaid,
    ),
    status: payment.status,
    guardianEmail: payment.student.guardian?.email ?? payment.student.parent?.user.email ?? null,
    guardianName: payment.student.guardian?.name ?? payment.student.parent?.user.name ?? null,
    parentEmail: payment.student.guardian?.email ?? payment.student.parent?.user.email ?? null,
    parentName: payment.student.guardian?.name ?? payment.student.parent?.user.name ?? null,
  }));

  const reminderSettings = settings.find(
    (item) => item.key === "notification_preferences",
  );

  const [templates, queue] = await Promise.all([
    listNotificationTemplates(),
    listNotificationQueue({ limit: 10 }),
  ]);

  return {
    settings: reminderSettings?.value ?? {
      enableFeeReminders: true,
      enableAttendanceReminders: true,
      reminderChannel: "email",
    },
    templates,
    queue,
    feeTargets,
    attendanceTargets,
  };
}

export async function dispatchReminders(
  actorId: string,
  payload: {
    type: "fees" | "attendance" | "all";
  },
) {
  const preview = await getReminderPreview();
  const feeTemplate = await findNotificationTemplateByKey("fee_due_reminder");
  const attendanceTemplate =
    await findNotificationTemplateByKey("attendance_alert");

  const feeTargets =
    payload.type === "attendance"
      ? []
      : preview.feeTargets.filter((item) => item.guardianEmail ?? item.parentEmail);
  const attendanceTargets =
    payload.type === "fees"
      ? []
      : preview.attendanceTargets.filter((item) => item.guardianEmail ?? item.parentEmail);

  const feeQueueItems = await Promise.all(
    feeTargets.map(async (item) => {
      const subject = interpolate(
        feeTemplate?.subject ?? "Fee reminder for {{studentName}}",
        item,
      );
      const html = interpolate(
        feeTemplate?.body ??
          "<p>Hello {{guardianName}},</p><p>{{studentName}} has a due balance of ৳{{amountDue}}.</p>",
        item,
      );
      return enqueueNotification({
        templateId: feeTemplate?.id,
        channel: NotificationChannel.EMAIL,
        recipientName: item.guardianName ?? item.parentName,
        recipientEmail: (item.guardianEmail ?? item.parentEmail)!,
        subject,
        body: html,
        metadata: item,
      });
    }),
  );

  const attendanceQueueItems = await Promise.all(
    attendanceTargets.map(async (item) => {
      const templateValues = {
        ...item,
        attendancePercentage: item.percentage,
      };
      const subject = interpolate(
        attendanceTemplate?.subject ?? "Attendance alert for {{studentName}}",
        templateValues,
      );
      const html = interpolate(
        attendanceTemplate?.body ??
          "<p>Hello {{guardianName}},</p><p>{{studentName}} currently has attendance {{attendancePercentage}}%.</p>",
        templateValues,
      );
      return enqueueNotification({
        templateId: attendanceTemplate?.id,
        channel: NotificationChannel.EMAIL,
        recipientName: item.guardianName ?? item.parentName,
        recipientEmail: (item.guardianEmail ?? item.parentEmail)!,
        subject,
        body: html,
        metadata: templateValues,
      });
    }),
  );

  const queueItems = [...feeQueueItems, ...attendanceQueueItems];

  await Promise.all(
    queueItems.map(async (item) => {
      try {
        await updateNotificationQueueStatus(item.id, { status: "PROCESSING" });
        await sendAppEmail({
          to: item.recipientEmail,
          subject: item.subject,
          html: item.body,
          text: item.body.replace(/<[^>]+>/g, " "),
          name: item.recipientName ?? undefined,
        });
        await updateNotificationQueueStatus(item.id, {
          status: "SENT",
          sentAt: new Date(),
        });
      } catch (error) {
        await updateNotificationQueueStatus(item.id, {
          status: "FAILED",
          errorMessage:
            error instanceof Error ? error.message : "Unknown delivery error",
        });
      }
    }),
  );

  const dispatched = {
    fees: feeQueueItems.length,
    attendance: attendanceQueueItems.length,
  };

  await recordAuditEvent({
    actorId,
    action: "notifications.reminders.dispatched",
    entityType: "NotificationWorkflow",
    metadata: {
      type: payload.type,
      dispatched,
    },
  });

  return {
    message: "Reminder dispatch processed",
    dispatched,
  };
}
