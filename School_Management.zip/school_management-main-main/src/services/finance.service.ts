import { FinanceEntryType } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import {
  createFinanceCategory,
  findFinanceCategoryById,
  listFinanceCategories,
  updateFinanceCategoryRecord,
} from "@/repositories/financeCategory.repository";
import {
  createFinanceEntry,
  findFinanceEntryById,
  listFinanceEntries,
  updateFinanceEntryRecord,
} from "@/repositories/financeEntry.repository";
import { HttpError } from "@/utils/error-handler";

function toDate(value?: string | null) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return null;
  }
  return date;
}

function monthRangeUtc(month: number, year: number) {
  const from = new Date(Date.UTC(year, month - 1, 1, 0, 0, 0, 0));
  const to = new Date(Date.UTC(year, month, 0, 23, 59, 59, 999));
  return { from, to };
}

export async function listFinanceCategoriesForAdmin(filters: {
  type?: FinanceEntryType;
  search?: string;
} = {}) {
  const categories = await listFinanceCategories(filters);

  return {
    categories,
    stats: {
      total: categories.length,
      active: categories.filter((category) => category.isActive).length,
      inactive: categories.filter((category) => !category.isActive).length,
    },
  };
}

export async function createFinanceCategoryForAdmin(payload: {
  name: string;
  type: FinanceEntryType;
  isActive?: boolean;
}) {
  return createFinanceCategory({
    name: payload.name.trim(),
    type: payload.type,
    isActive: payload.isActive ?? true,
  });
}

export async function updateFinanceCategoryForAdmin(
  id: string,
  payload: { name?: string; isActive?: boolean },
) {
  const existing = await findFinanceCategoryById(id);
  if (!existing) {
    throw new HttpError("Finance category not found", 404);
  }

  return updateFinanceCategoryRecord(id, {
    ...(payload.name ? { name: payload.name.trim() } : {}),
    ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
  });
}

export async function listFinanceEntriesForAdmin(filters: {
  type?: FinanceEntryType;
  categoryId?: string;
  studentId?: string;
  search?: string;
  from?: string;
  to?: string;
  includeDeleted?: boolean;
} = {}) {
  const from = toDate(filters.from);
  const to = toDate(filters.to);
  if (filters.from && !from) {
    throw new HttpError("Invalid from date", 400);
  }
  if (filters.to && !to) {
    throw new HttpError("Invalid to date", 400);
  }

  const entries = await listFinanceEntries({
    type: filters.type,
    categoryId: filters.categoryId,
    studentId: filters.studentId,
    search: filters.search,
    from: from ?? undefined,
    to: to ?? undefined,
    includeDeleted: filters.includeDeleted,
  });

  const income = entries
    .filter((entry) => entry.type === FinanceEntryType.INCOME && !entry.isDeleted)
    .reduce((sum, entry) => sum + entry.amount, 0);
  const expense = entries
    .filter((entry) => entry.type === FinanceEntryType.EXPENSE && !entry.isDeleted)
    .reduce((sum, entry) => sum + entry.amount, 0);

  return {
    entries,
    stats: {
      total: entries.length,
      income,
      expense,
      net: income - expense,
    },
  };
}

export async function createFinanceEntryForAdmin(
  actorId: string,
  payload: {
    type: FinanceEntryType;
    categoryId: string;
    amount: number;
    occurredAt: string;
    description?: string;
    studentId?: string;
  },
  client: PrismaClientLike = prisma,
) {
  const occurredAt = toDate(payload.occurredAt);
  if (!occurredAt) {
    throw new HttpError("Invalid occurredAt date", 400);
  }

  const category = await client.financeCategory.findUnique({
    where: { id: payload.categoryId },
    select: { id: true, type: true, isActive: true },
  });
  if (!category) {
    throw new HttpError("Finance category not found", 404);
  }
  if (!category.isActive) {
    throw new HttpError("Finance category is inactive", 400);
  }
  if (category.type !== payload.type) {
    throw new HttpError("Category type does not match entry type", 400);
  }

  if (payload.studentId) {
    const student = await client.student.findUnique({
      where: { id: payload.studentId },
      select: { id: true },
    });
    if (!student) {
      throw new HttpError("Student not found", 404);
    }
  }

  return createFinanceEntry(
    {
      type: payload.type,
      amount: payload.amount,
      occurredAt,
      description: payload.description?.trim() || null,
      category: {
        connect: { id: payload.categoryId },
      },
      ...(payload.studentId
        ? { student: { connect: { id: payload.studentId } } }
        : {}),
      createdBy: {
        connect: { id: actorId },
      },
    },
    client,
  );
}

export async function updateFinanceEntryForAdmin(
  id: string,
  payload: {
    categoryId?: string;
    amount?: number;
    occurredAt?: string;
    description?: string | null;
    studentId?: string | null;
    isDeleted?: boolean;
  },
  client: PrismaClientLike = prisma,
) {
  const existing = await findFinanceEntryById(id, client);
  if (!existing) {
    throw new HttpError("Finance entry not found", 404);
  }

  const occurredAt =
    payload.occurredAt !== undefined ? toDate(payload.occurredAt) : null;
  if (payload.occurredAt !== undefined && !occurredAt) {
    throw new HttpError("Invalid occurredAt date", 400);
  }

  const nextCategoryId = payload.categoryId ?? existing.category.id;
  if (payload.categoryId) {
    const category = await client.financeCategory.findUnique({
      where: { id: nextCategoryId },
      select: { id: true, type: true, isActive: true },
    });
    if (!category) {
      throw new HttpError("Finance category not found", 404);
    }
    if (!category.isActive) {
      throw new HttpError("Finance category is inactive", 400);
    }
    if (category.type !== existing.type) {
      throw new HttpError("Category type does not match entry type", 400);
    }
  }

  if (payload.studentId !== undefined) {
    if (payload.studentId) {
      const student = await client.student.findUnique({
        where: { id: payload.studentId },
        select: { id: true },
      });
      if (!student) {
        throw new HttpError("Student not found", 404);
      }
    }
  }

  return updateFinanceEntryRecord(
    id,
    {
      ...(payload.amount !== undefined ? { amount: payload.amount } : {}),
      ...(occurredAt ? { occurredAt } : {}),
      ...(payload.description !== undefined
        ? { description: payload.description?.trim() || null }
        : {}),
      ...(payload.studentId !== undefined
        ? payload.studentId
          ? { student: { connect: { id: payload.studentId } } }
          : { student: { disconnect: true } }
        : {}),
      ...(payload.categoryId
        ? { category: { connect: { id: payload.categoryId } } }
        : {}),
      ...(payload.isDeleted !== undefined ? { isDeleted: payload.isDeleted } : {}),
    },
    client,
  );
}

export async function softDeleteFinanceEntryForAdmin(
  id: string,
  client: PrismaClientLike = prisma,
) {
  const existing = await findFinanceEntryById(id, client);
  if (!existing) {
    throw new HttpError("Finance entry not found", 404);
  }

  if (existing.isDeleted) {
    return existing;
  }

  return updateFinanceEntryRecord(id, { isDeleted: true }, client);
}

export async function getMonthlyFinanceReport(
  payload: { month: number; year: number },
  client: PrismaClientLike = prisma,
) {
  const { from, to } = monthRangeUtc(payload.month, payload.year);

  const [feeIncomeAgg, incomeAgg, expenseAgg, grouped] = await Promise.all([
    client.payment.aggregate({
      where: {
        month: payload.month,
        year: payload.year,
      },
      _sum: {
        amountPaid: true,
      },
    }),
    client.financeEntry.aggregate({
      where: {
        type: FinanceEntryType.INCOME,
        isDeleted: false,
        occurredAt: { gte: from, lte: to },
      },
      _sum: { amount: true },
    }),
    client.financeEntry.aggregate({
      where: {
        type: FinanceEntryType.EXPENSE,
        isDeleted: false,
        occurredAt: { gte: from, lte: to },
      },
      _sum: { amount: true },
    }),
    Promise.all([
      client.financeEntry.groupBy({
        by: ["categoryId"],
        where: {
          type: FinanceEntryType.INCOME,
          isDeleted: false,
          occurredAt: { gte: from, lte: to },
        },
        _sum: { amount: true },
      }),
      client.financeEntry.groupBy({
        by: ["categoryId"],
        where: {
          type: FinanceEntryType.EXPENSE,
          isDeleted: false,
          occurredAt: { gte: from, lte: to },
        },
        _sum: { amount: true },
      }),
    ]),
  ]);

  const feeIncome = feeIncomeAgg._sum.amountPaid ?? 0;
  const otherIncome = incomeAgg._sum.amount ?? 0;
  const expense = expenseAgg._sum.amount ?? 0;

  const [incomeByCategoryRaw, expenseByCategoryRaw] = grouped;
  const categoryIds = Array.from(
    new Set([
      ...incomeByCategoryRaw.map((row) => row.categoryId),
      ...expenseByCategoryRaw.map((row) => row.categoryId),
    ]),
  );

  const categories = categoryIds.length
    ? await client.financeCategory.findMany({
        where: { id: { in: categoryIds } },
        select: { id: true, name: true, type: true },
      })
    : [];
  const categoryNameById = new Map(categories.map((cat) => [cat.id, cat.name]));

  const incomeByCategory = incomeByCategoryRaw
    .map((row) => ({
      categoryId: row.categoryId,
      categoryName: categoryNameById.get(row.categoryId) ?? "Unknown",
      amount: row._sum.amount ?? 0,
    }))
    .sort((a, b) => b.amount - a.amount);

  const expenseByCategory = expenseByCategoryRaw
    .map((row) => ({
      categoryId: row.categoryId,
      categoryName: categoryNameById.get(row.categoryId) ?? "Unknown",
      amount: row._sum.amount ?? 0,
    }))
    .sort((a, b) => b.amount - a.amount);

  const totalIncome = feeIncome + otherIncome;

  return {
    month: payload.month,
    year: payload.year,
    totals: {
      feeIncome,
      otherIncome,
      income: totalIncome,
      expense,
      net: totalIncome - expense,
    },
    breakdown: {
      incomeByCategory,
      expenseByCategory,
    },
  };
}
