import { randomBytes } from "node:crypto";
import { Gender, StudentPlacementStatus } from "@prisma/client";
import { hashPassword } from "@/lib/auth";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { getScopedBranchId } from "@/lib/request-context";
import {
  ensureDefaultClass,
  ensureDefaultGroup,
  ensureDefaultSection,
  findClassById,
  findGroupById,
  findSectionById,
} from "@/repositories/class.repository";
import {
  countStudents,
  countStudentsByFilters,
  createStudent,
  findStudentById,
  getNextRollNumber,
  listStudents,
  updateStudentRecord,
} from "@/repositories/student.repository";
import {
  createGuardian,
  findGuardianByContact,
} from "@/repositories/guardian.repository";
import { createUser, findUserByEmail } from "@/repositories/user.repository";
import { syncFeeCategoryAssignmentsForStudent } from "@/services/feeCategory.service";
import { sendAppEmail } from "@/utils/email";
import { HttpError } from "@/utils/error-handler";

export type StudentListFilters = {
  search?: string;
  classId?: string;
  includeDeleted?: boolean;
  page?: number;
  pageSize?: number;
};

export type CreateStudentInput = {
  name: string;
  email: string;
  password?: string;
  phone?: string;
  gender: Gender;
  classId?: string;
  groupId?: string;
  sectionId?: string;
  guardianName: string;
  guardianEmail?: string;
  guardianPhone?: string;
  guardianAddress?: string;
  guardianRelation?: string;
  fatherName?: string;
  fatherPhone?: string;
  motherName?: string;
  motherPhone?: string;
  nidNumber: string;
  nidImage: string;
  profileImage: string;
  fatherNidNumber: string;
  fatherNidImage: string;
  motherNidNumber: string;
  motherNidImage: string;
  rollNumber?: number;
};

function getLoginUrl() {
  return (
    process.env.APP_URL ??
    process.env.NEXT_PUBLIC_APP_URL ??
    "http://localhost:3000"
  );
}

function generateSecurePassword() {
  // Min 12, URL-safe.
  return randomBytes(9).toString("base64url");
}

function buildStudentCredentialsEmail(params: {
  name: string;
  email: string;
  password: string;
}) {
  const loginUrl = `${getLoginUrl().replace(/\/$/, "")}/login`;

  return {
    subject: "Your student account is ready",
    html: `<p>Hi ${params.name},</p>
      <p>Your student account has been created by the school administration.</p>
      <p><strong>Login URL:</strong> <a href="${loginUrl}">${loginUrl}</a><br />
      <strong>Email:</strong> ${params.email}<br />
      <strong>Password:</strong> ${params.password}</p>
      <p>Please sign in with this password and change it after your first login.</p>
      <p>Regards,<br/>School Administration</p>`,
    text: `Hi ${params.name},\n\nYour student account has been created by the school administration.\n\nLogin URL: ${loginUrl}\nEmail: ${params.email}\nPassword: ${params.password}\n\nPlease sign in with this password and change it after your first login.\n\nRegards,\nSchool Administration`,
  };
}

export type UpdateStudentInput = {
  name?: string;
  email?: string;
  password?: string;
  phone?: string | null;
  gender?: Gender;
  classId?: string;
  groupId?: string | null;
  sectionId?: string | null;
  guardianName?: string;
  guardianEmail?: string | null;
  guardianPhone?: string | null;
  guardianAddress?: string | null;
  guardianRelation?: string | null;
  fatherName?: string | null;
  fatherPhone?: string | null;
  motherName?: string | null;
  motherPhone?: string | null;
  rollNumber?: number | null;
};

type CurrentSessionLookup = {
  academicSession?: {
    findFirst?: (args: {
      where: { isCurrent: boolean; isActive: boolean };
      select: { id: boolean };
    }) => Promise<{ id: string } | null>;
  };
};

async function resolveGuardian(
  payload: {
    guardianName: string;
    guardianEmail?: string | null;
    guardianPhone?: string | null;
    guardianAddress?: string | null;
    guardianRelation?: string | null;
  },
  client: PrismaClientLike = prisma,
) {
  const normalizedEmail = payload.guardianEmail?.trim().toLowerCase() || null;
  const normalizedPhone = payload.guardianPhone?.trim() || null;

  const existingGuardian = await findGuardianByContact(
    {
      email: normalizedEmail,
      phone: normalizedPhone,
    },
    client,
  );

  if (existingGuardian) {
    return existingGuardian;
  }

  return createGuardian(
    {
      name: payload.guardianName.trim(),
      email: normalizedEmail,
      phone: normalizedPhone,
      address: payload.guardianAddress?.trim() || null,
      relation: payload.guardianRelation?.trim() || null,
    },
    client,
  );
}

async function resolvePlacement(
  classId?: string,
  groupId?: string | null,
  sectionId?: string | null,
  client: PrismaClientLike = prisma,
) {
  const resolvedClass = classId
    ? await findClassById(classId, client)
    : await ensureDefaultClass(client);

  if (!resolvedClass) {
    throw new HttpError("Unable to assign class", 400);
  }

  let resolvedGroup = null;
  let resolvedSection = null;

  if (sectionId) {
    resolvedSection = await findSectionById(sectionId, client);
    if (!resolvedSection) {
      throw new HttpError("Invalid section selected", 400);
    }
    resolvedGroup = resolvedSection.group;
  }

  if (groupId) {
    const group = await findGroupById(groupId, client);
    if (!group) {
      throw new HttpError("Invalid group selected", 400);
    }
    if (group.classId !== resolvedClass.id) {
      throw new HttpError("Group does not belong to the selected class", 400);
    }
    resolvedGroup = group;
  }

  if (!resolvedGroup) {
    resolvedGroup = await ensureDefaultGroup(resolvedClass.id, client);
  }

  if (resolvedSection && resolvedSection.groupId !== resolvedGroup.id) {
    throw new HttpError("Section does not belong to the selected group", 400);
  }

  if (!resolvedSection) {
    resolvedSection = await ensureDefaultSection(resolvedGroup.id, client);
  }

  return {
    class: resolvedClass,
    group: resolvedGroup,
    section: resolvedSection,
  };
}

async function resolvePlacementStatus(
  placement: Awaited<ReturnType<typeof resolvePlacement>>,
  client: PrismaClientLike,
) {
  const [classActiveStudents, groupActiveStudents] = await Promise.all([
    client.student.count({
      where: {
        classId: placement.class.id,
        isDeleted: false,
        placementStatus: StudentPlacementStatus.ACTIVE,
      },
    }),
    placement.group
      ? client.student.count({
          where: {
            groupId: placement.group.id,
            isDeleted: false,
            placementStatus: StudentPlacementStatus.ACTIVE,
          },
        })
      : Promise.resolve(0),
  ]);

  const classFull =
    placement.class.studentLimit !== null &&
    placement.class.studentLimit !== undefined &&
    classActiveStudents >= placement.class.studentLimit;
  const groupFull =
    placement.group?.studentLimit !== null &&
    placement.group?.studentLimit !== undefined &&
    groupActiveStudents >= placement.group.studentLimit;

  return classFull || groupFull
    ? StudentPlacementStatus.WAITING_LIST
    : StudentPlacementStatus.ACTIVE;
}

async function listClassPlacementOptions(client: PrismaClientLike = prisma) {
  const classes = await client.class.findMany({
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      sortOrder: true,
      studentLimit: true,
      groups: {
        orderBy: [{ name: "asc" }],
        select: {
          id: true,
          name: true,
          studentLimit: true,
          _count: {
            select: {
              students: {
                where: {
                  isDeleted: false,
                  placementStatus: StudentPlacementStatus.ACTIVE,
                },
              },
            },
          },
        },
      },
      _count: {
        select: {
          students: {
            where: {
              isDeleted: false,
              placementStatus: StudentPlacementStatus.ACTIVE,
            },
          },
        },
      },
    },
  });

  return classes.map((item) => ({
    id: item.id,
    name: item.name,
    sortOrder: item.sortOrder,
    studentLimit: item.studentLimit,
    activeStudentCount: item._count.students,
    groups: item.groups.map((group) => ({
      id: group.id,
      name: group.name,
      studentLimit: group.studentLimit,
      activeStudentCount: group._count.students,
    })),
  }));
}

export async function listStudentsForAdmin(filters: StudentListFilters) {
  const page = filters.page ?? 1;
  const pageSize = filters.pageSize ?? 20;
  const skip = (page - 1) * pageSize;

  const [students, classes, filteredTotal, total, active, waitingList] = await Promise.all([
    listStudents({ ...filters, skip, take: pageSize }),
    listClassPlacementOptions(),
    countStudentsByFilters(filters),
    countStudents(true),
    countStudents(false),
    prisma.student.count({
      where: {
        isDeleted: false,
        placementStatus: StudentPlacementStatus.WAITING_LIST,
      },
    }),
  ]);

  return {
    students,
    classes,
    stats: {
      total,
      active,
      waitingList,
      deleted: Math.max(0, total - active),
    },
    pagination: {
      page,
      pageSize,
      total: filteredTotal,
      totalPages: Math.max(1, Math.ceil(filteredTotal / pageSize)),
    },
  };
}

export async function createStudentForAdmin(payload: CreateStudentInput) {
  const normalizedEmail = payload.email.trim().toLowerCase();
  const branchId = getScopedBranchId();
  const existingUser = await findUserByEmail(normalizedEmail);

  if (existingUser) {
    throw new HttpError("Email already exists", 409);
  }

  const plainPassword = payload.password?.trim() || generateSecurePassword();

  const student = await prisma.$transaction(async (tx) => {
    const placement = await resolvePlacement(
      payload.classId,
      payload.groupId,
      payload.sectionId,
      tx,
    );
    const placementStatus = await resolvePlacementStatus(placement, tx);

    const currentSession =
      await (tx as unknown as CurrentSessionLookup).academicSession?.findFirst?.({
        where: { isCurrent: true, isActive: true },
        select: { id: true },
      }) ?? null;

    const password = await hashPassword(plainPassword);
    const guardian = await resolveGuardian(payload, tx);
    const user = await createUser(
      {
        name: payload.name.trim(),
        email: normalizedEmail,
        password,
        role: "STUDENT",
        ...(branchId ? { branch: { connect: { id: branchId } } } : {}),
      },
      tx,
    );

    const rollNumber =
      placementStatus === StudentPlacementStatus.ACTIVE
        ? (payload.rollNumber ?? (await getNextRollNumber(placement.class.id, tx)))
        : null;

    const student = await createStudent(
      {
        user: {
          connect: { id: user.id },
        },
        gender: payload.gender,
        placementStatus,
        phone: payload.phone?.trim() || null,
        details: {
          nidNumber: payload.nidNumber.trim(),
          nidImage: payload.nidImage,
          profileImage: payload.profileImage,
          fatherNidNumber: payload.fatherNidNumber.trim(),
          fatherNidImage: payload.fatherNidImage,
          motherNidNumber: payload.motherNidNumber.trim(),
          motherNidImage: payload.motherNidImage,
        },
        fatherName: payload.fatherName?.trim() || null,
        fatherPhone: payload.fatherPhone?.trim() || null,
        motherName: payload.motherName?.trim() || null,
        motherPhone: payload.motherPhone?.trim() || null,
        rollNumber,
        ...(currentSession?.id
          ? { session: { connect: { id: currentSession.id } } }
          : {}),
        class: {
          connect: { id: placement.class.id },
        },
        group: placement.group
          ? { connect: { id: placement.group.id } }
          : undefined,
        section: placement.section
          ? { connect: { id: placement.section.id } }
          : undefined,
        guardian: {
          connect: { id: guardian.id },
        },
      },
      tx,
    );

    await syncFeeCategoryAssignmentsForStudent(
      student.id,
      placement.class.id,
      tx,
    );

    return student;
  });

  let credentialEmailSent = true;
  try {
    const emailPayload = buildStudentCredentialsEmail({
      name: student.user.name,
      email: student.user.email,
      password: plainPassword,
    });
    await sendAppEmail({
      to: student.user.email,
      subject: emailPayload.subject,
      html: emailPayload.html,
      text: emailPayload.text,
      name: student.user.name,
    });
  } catch (error) {
    credentialEmailSent = false;
    console.error("Failed to send student credential email", error);
  }

  return {
    student,
    credentialEmail: {
      to: student.user.email,
      sent: credentialEmailSent,
    },
  };
}

export async function updateStudentForAdmin(
  studentId: string,
  payload: UpdateStudentInput,
) {
  const existing = await findStudentById(studentId);

  if (!existing) {
    throw new HttpError("Student not found", 404);
  }

  const passwordForEmail = payload.password ?? null;
  const recipientEmail =
    payload.email?.trim().toLowerCase() || existing.user.email;

  const student = await prisma.$transaction(async (tx) => {
    const normalizedEmail = payload.email?.trim().toLowerCase();

    if (normalizedEmail) {
      const otherUser = await findUserByEmail(normalizedEmail, tx);
      if (otherUser && otherUser.id !== existing.user.id) {
        throw new HttpError("Email already exists", 409);
      }
    }

    const classId = payload.classId ?? existing.classId;
    const classChanged = classId !== existing.classId;
    const groupId =
      payload.groupId !== undefined
        ? payload.groupId
        : classChanged
          ? undefined
          : (existing.groupId ?? undefined);
    const sectionId =
      payload.sectionId !== undefined
        ? payload.sectionId
        : classChanged
          ? undefined
          : (existing.sectionId ?? undefined);
    const placement = await resolvePlacement(classId, groupId, sectionId, tx);
    const guardianPayloadProvided =
      payload.guardianName !== undefined ||
      payload.guardianEmail !== undefined ||
      payload.guardianPhone !== undefined ||
      payload.guardianAddress !== undefined ||
      payload.guardianRelation !== undefined;
    const guardian = guardianPayloadProvided
      ? await resolveGuardian(
          {
            guardianName:
              payload.guardianName?.trim() ||
              existing.guardian?.name ||
              (() => {
                throw new HttpError("Guardian name is required", 400);
              })(),
            guardianEmail:
              payload.guardianEmail ?? existing.guardian?.email ?? null,
            guardianPhone:
              payload.guardianPhone ?? existing.guardian?.phone ?? null,
            guardianAddress:
              payload.guardianAddress ?? existing.guardian?.address ?? null,
            guardianRelation:
              payload.guardianRelation ?? existing.guardian?.relation ?? null,
          },
          tx,
        )
      : null;

    await tx.user.update({
      where: { id: existing.user.id },
      data: {
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(normalizedEmail ? { email: normalizedEmail } : {}),
        ...(payload.password
          ? { password: await hashPassword(payload.password) }
          : {}),
      },
    });

    const student = await updateStudentRecord(
      existing.id,
      {
        ...(payload.phone !== undefined
          ? { phone: payload.phone?.trim() || null }
          : {}),
        ...(payload.gender ? { gender: payload.gender } : {}),
        ...(payload.fatherName !== undefined
          ? { fatherName: payload.fatherName?.trim() || null }
          : {}),
        ...(payload.fatherPhone !== undefined
          ? { fatherPhone: payload.fatherPhone?.trim() || null }
          : {}),
        ...(payload.motherName !== undefined
          ? { motherName: payload.motherName?.trim() || null }
          : {}),
        ...(payload.motherPhone !== undefined
          ? { motherPhone: payload.motherPhone?.trim() || null }
          : {}),
        ...(guardian ? { guardian: { connect: { id: guardian.id } } } : {}),
        ...(payload.rollNumber !== undefined
          ? { rollNumber: payload.rollNumber }
          : {}),
        class: {
          connect: { id: placement.class.id },
        },
        group: placement.group
          ? { connect: { id: placement.group.id } }
          : { disconnect: true },
        section: placement.section
          ? { connect: { id: placement.section.id } }
          : { disconnect: true },
      },
      tx,
    );

    await syncFeeCategoryAssignmentsForStudent(
      student.id,
      placement.class.id,
      tx,
    );

    return student;
  });

  if (passwordForEmail) {
    const subject = "Your student password has been updated";
    const html = `<p>Hello ${student.user.name},</p>
      <p>Your student account password has been updated by the school administration.</p>
      <p><strong>New password:</strong> ${passwordForEmail}</p>
      <p>Please sign in with this password and change it after your first login.</p>
      <p>Regards,<br/>School Administration</p>`;
    const text = `Hello ${student.user.name},\n\nYour student account password has been updated by the school administration.\n\nNew password: ${passwordForEmail}\n\nPlease sign in with this password and change it after your first login.\n\nRegards,\nSchool Administration`;

    await sendAppEmail({
      to: recipientEmail,
      subject,
      html,
      text,
      name: student.user.name,
    });
  }

  return student;
}

export async function deactivateStudentForAdmin(studentId: string) {
  const existing = await findStudentById(studentId);

  if (!existing) {
    throw new HttpError("Student not found", 404);
  }

  return prisma.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: existing.user.id },
      data: { isDeleted: true },
    });

    return updateStudentRecord(existing.id, { isDeleted: true }, tx);
  });
}
