import { Role } from "@prisma/client";
import { hashPassword } from "@/lib/auth";
import {
  countActiveUsersByRole,
  createUser,
  findManagedUserById,
  findUserByEmail,
  listManagedUsers,
  updateManagedUser,
  type ManagedUserRecord,
} from "@/repositories/user.repository";
import { HttpError } from "@/utils/error-handler";

const MANAGED_USER_ROLES = [
  Role.USER,
  Role.SUPER_ADMIN,
  Role.ADMIN,
  Role.ACCOUNTANT,
  Role.ACADEMIC_ADMIN,
  Role.ADMISSION_ADMIN,
  Role.TEACHER,
  Role.STUDENT,
] as const;

type ManagedUserRole = (typeof MANAGED_USER_ROLES)[number];

type UserListFilters = {
  search?: string;
  role?: ManagedUserRole;
  includeDeleted?: boolean;
};

export type CreateManagedUserInput = {
  name: string;
  email: string;
  password: string;
  role: ManagedUserRole;
  branchId?: string;
};

export type UpdateManagedUserInput = {
  name?: string;
  email?: string;
  password?: string;
  role?: ManagedUserRole;
  branchId?: string;
};

function getManageableRoles(actorRole: Role): ManagedUserRole[] {
  if (actorRole === Role.SUPER_ADMIN) {
    return [...MANAGED_USER_ROLES];
  }

  if (actorRole === Role.ADMIN) {
    return [
      Role.USER,
      Role.ADMIN,
      Role.ACCOUNTANT,
      Role.ACADEMIC_ADMIN,
      Role.ADMISSION_ADMIN,
      Role.TEACHER,
      Role.STUDENT,
    ];
  }

  return [];
}

function assertRoleIsManageable(actorRole: Role, targetRole: Role) {
  const manageableRoles = getManageableRoles(actorRole);

  if (!manageableRoles.includes(targetRole as ManagedUserRole)) {
    throw new HttpError("You are not allowed to manage this role", 403);
  }
}

async function assertSuperAdminSafety(
  currentRole: Role,
  nextRole?: Role,
  deleting = false,
) {
  if (currentRole !== Role.SUPER_ADMIN) {
    return;
  }

  if (!deleting && nextRole === Role.SUPER_ADMIN) {
    return;
  }

  const totalSuperAdmins = await countActiveUsersByRole(Role.SUPER_ADMIN);
  if (totalSuperAdmins <= 1) {
    throw new HttpError("At least one active super admin must remain", 400);
  }
}

function buildRoleCounts(users: ManagedUserRecord[]) {
  return MANAGED_USER_ROLES.reduce(
    (acc, role) => {
      acc[role] = users.filter(
        (user) => user.role === role && !user.isDeleted,
      ).length;
      return acc;
    },
    {} as Record<ManagedUserRole, number>,
  );
}

function roleRequiresBranch(role: ManagedUserRole) {
  return (
    role === Role.ADMIN ||
    role === Role.ACCOUNTANT ||
    role === Role.ACADEMIC_ADMIN ||
    role === Role.ADMISSION_ADMIN ||
    role === Role.TEACHER
  );
}

export async function listAdminUsers(
  actorRole: Role,
  actorBranchId: string | null | undefined,
  filters: UserListFilters,
) {
  const roles = getManageableRoles(actorRole);
  if (roles.length === 0) {
    throw new HttpError("You are not allowed to view user management", 403);
  }

  if (filters.role) {
    assertRoleIsManageable(actorRole, filters.role);
  }

  const users = await listManagedUsers({
    roles,
    search: filters.search,
    role: filters.role,
    includeDeleted: filters.includeDeleted,
    branchId: actorBranchId,
  });

  const activeUsers = users.filter((user) => !user.isDeleted);

  return {
    users,
    stats: {
      total: users.length,
      active: activeUsers.length,
      deleted: users.length - activeUsers.length,
      roleCounts: buildRoleCounts(users),
    },
    allowedRoles: roles,
  };
}

export async function createAdminUser(
  actorRole: Role,
  actorBranchId: string | null | undefined,
  payload: CreateManagedUserInput,
) {
  assertRoleIsManageable(actorRole, payload.role);

  const normalizedEmail = payload.email.trim().toLowerCase();
  const existingUser = await findUserByEmail(normalizedEmail);
  if (existingUser) {
    throw new HttpError("Email already exists", 409);
  }

  const nextBranchId = payload.branchId?.trim() || undefined;
  if (roleRequiresBranch(payload.role)) {
    if (!nextBranchId) {
      throw new HttpError("branchId is required for this role", 400);
    }
    if (actorRole !== Role.SUPER_ADMIN) {
      if (!actorBranchId) {
        throw new HttpError("Your account is not assigned to any branch", 403);
      }
      if (nextBranchId !== actorBranchId) {
        throw new HttpError("You can only create users in your own branch", 403);
      }
    }
  }

  const password = await hashPassword(payload.password);

  return createUser({
    name: payload.name.trim(),
    email: normalizedEmail,
    password,
    role: payload.role,
    ...(nextBranchId ? { branch: { connect: { id: nextBranchId } } } : {}),
  });
}

export async function updateAdminUser(
  actorId: string,
  actorRole: Role,
  actorBranchId: string | null | undefined,
  userId: string,
  payload: UpdateManagedUserInput,
) {
  const targetUser = await findManagedUserById(userId);
  if (!targetUser) {
    throw new HttpError("User not found", 404);
  }

  if (actorRole !== Role.SUPER_ADMIN) {
    if (!actorBranchId) {
      throw new HttpError("Your account is not assigned to any branch", 403);
    }
    if (targetUser.branchId !== actorBranchId) {
      throw new HttpError("User not found", 404);
    }
  }

  assertRoleIsManageable(actorRole, targetUser.role);

  if (payload.role) {
    assertRoleIsManageable(actorRole, payload.role);
  }

  if (
    targetUser.id === actorId &&
    payload.role &&
    payload.role !== targetUser.role
  ) {
    throw new HttpError("You cannot change your own administrative role", 400);
  }

  if (payload.role && payload.role !== targetUser.role) {
    await assertSuperAdminSafety(targetUser.role, payload.role);
  }

  const normalizedEmail = payload.email?.trim().toLowerCase();
  if (normalizedEmail) {
    const existingUser = await findUserByEmail(normalizedEmail);
    if (existingUser && existingUser.id !== targetUser.id) {
      throw new HttpError("Email already exists", 409);
    }
  }

  const nextData: Record<string, unknown> = {};

  if (payload.name) {
    nextData.name = payload.name.trim();
  }

  if (normalizedEmail) {
    nextData.email = normalizedEmail;
  }

  if (payload.role) {
    nextData.role = payload.role;
  }

  if (payload.password) {
    nextData.password = await hashPassword(payload.password);
  }

  const nextBranchId = payload.branchId?.trim();
  const effectiveRole = (payload.role ?? targetUser.role) as ManagedUserRole;
  if (nextBranchId !== undefined) {
    if (roleRequiresBranch(effectiveRole)) {
      if (!nextBranchId) {
        throw new HttpError("branchId is required for this role", 400);
      }
      if (actorRole !== Role.SUPER_ADMIN) {
        if (!actorBranchId) throw new HttpError("Your account is not assigned to any branch", 403);
        if (nextBranchId !== actorBranchId) {
          throw new HttpError("You can only assign your own branch", 403);
        }
      }
      nextData.branch = { connect: { id: nextBranchId } };
    } else {
      nextData.branch = { disconnect: true };
    }
  } else if (payload.role && roleRequiresBranch(effectiveRole) && !targetUser.branchId) {
    // role changed to a branch-scoped role but no branch set
    throw new HttpError("branchId is required for this role", 400);
  }

  return updateManagedUser(targetUser.id, nextData);
}

export async function deactivateAdminUser(
  actorId: string,
  actorRole: Role,
  actorBranchId: string | null | undefined,
  userId: string,
) {
  const targetUser = await findManagedUserById(userId);
  if (!targetUser) {
    throw new HttpError("User not found", 404);
  }

  if (actorRole !== Role.SUPER_ADMIN) {
    if (!actorBranchId) {
      throw new HttpError("Your account is not assigned to any branch", 403);
    }
    if (targetUser.branchId !== actorBranchId) {
      throw new HttpError("User not found", 404);
    }
  }

  assertRoleIsManageable(actorRole, targetUser.role);

  if (targetUser.id === actorId) {
    throw new HttpError("You cannot deactivate your own account", 400);
  }

  if (targetUser.isDeleted) {
    return targetUser;
  }

  await assertSuperAdminSafety(targetUser.role, undefined, true);

  return updateManagedUser(targetUser.id, { isDeleted: true });
}
