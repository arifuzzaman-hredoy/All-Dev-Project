import type { Prisma } from "@prisma/client";
import {
  findSystemSettingByKey,
  listSystemSettings,
  upsertSystemSetting,
} from "@/repositories/systemSetting.repository";
import { recordAuditEvent } from "@/services/audit.service";

export const DEFAULT_SYSTEM_SETTINGS = {
  school_profile: {
    schoolName: "School ERP Academy",
    timezone: "Asia/Dhaka",
    contactEmail: "admin@school-erp.local",
    contactPhone: "+8801700000000",
  },
  attendance_policy: {
    lateAfterMinutes: 15,
    minimumAttendancePercentage: 75,
    autoNotifyParents: true,
  },
  feature_flags: {
    enableGuardianPortal: true,
    enableOnlineAdmissions: true,
    enableTeacherSelfService: true,
  },
  notification_preferences: {
    enableFeeReminders: true,
    enableAttendanceReminders: true,
    reminderChannel: "email",
  },
  notice_template: {
    header: "",
    footer: "",
    signature: "",
  },
} as const;

function normalizeFeatureFlags(value: Prisma.JsonValue) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return null;
  }

  const featureFlags = value as Record<string, Prisma.JsonValue>;

  if (!("enableParentPortal" in featureFlags) || "enableGuardianPortal" in featureFlags) {
    return null;
  }

  const { enableParentPortal, ...rest } = featureFlags;

  return {
    ...rest,
    enableGuardianPortal: enableParentPortal,
  } as Prisma.InputJsonValue;
}

async function ensureDefaults() {
  await Promise.all(
    Object.entries(DEFAULT_SYSTEM_SETTINGS).map(async ([key, value]) => {
      const existing = await findSystemSettingByKey(key);
      if (!existing) {
        await upsertSystemSetting({ key, value });
      }
    })
  );

  const featureFlagsSetting = await findSystemSettingByKey("feature_flags");
  const normalizedFeatureFlags = featureFlagsSetting
    ? normalizeFeatureFlags(featureFlagsSetting.value)
    : null;

  if (normalizedFeatureFlags) {
    await upsertSystemSetting({
      key: "feature_flags",
      value: normalizedFeatureFlags,
      updatedById: featureFlagsSetting?.updatedById,
    });
  }
}

export async function listSystemSettingsForAdmin(search?: string) {
  await ensureDefaults();
  return listSystemSettings({ search });
}

export async function updateSystemSettingForAdmin(payload: {
  key: string;
  value: Prisma.InputJsonValue;
  actorId: string;
}) {
  const setting = await upsertSystemSetting(payload);

  await recordAuditEvent({
    actorId: payload.actorId,
    action: "system_setting.updated",
    entityType: "SystemSetting",
    entityId: setting.id,
    metadata: {
      key: payload.key,
      value: payload.value,
    },
  });

  return setting;
}
