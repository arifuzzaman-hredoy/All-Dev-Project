import { findClassById, listClasses } from "@/repositories/class.repository";
import {
  listClassMonthlyFees,
  upsertClassMonthlyFee,
} from "@/repositories/classMonthlyFee.repository";
import { HttpError } from "@/utils/error-handler";

export async function listClassMonthlyFeesForAdmin() {
  const [classes, configuredFees] = await Promise.all([
    listClasses(),
    listClassMonthlyFees(),
  ]);
  const monthlyFeeMap = new Map(
    configuredFees.map((item) => [item.classId, item]),
  );

  return {
    classes: classes.map((item) => ({
      id: item.id,
      name: item.name,
      monthlyFee: monthlyFeeMap.get(item.id)?.monthlyFee ?? null,
      isActive: monthlyFeeMap.get(item.id)?.isActive ?? false,
    })),
    stats: {
      total: classes.length,
      configured: configuredFees.filter(
        (item) => item.monthlyFee !== null && item.isActive,
      ).length,
      totalMonthlyFee: configuredFees.reduce(
        (sum, item) => sum + (item.isActive ? (item.monthlyFee ?? 0) : 0),
        0,
      ),
    },
  };
}

export async function setClassMonthlyFeeForAdmin(payload: {
  classId: string;
  monthlyFee: number | null;
  isActive?: boolean;
}) {
  const classRecord = await findClassById(payload.classId);

  if (!classRecord) {
    throw new HttpError("Class not found", 404);
  }

  return upsertClassMonthlyFee(
    classRecord.id,
    payload.monthlyFee,
    payload.isActive ?? payload.monthlyFee !== null,
  );
}
