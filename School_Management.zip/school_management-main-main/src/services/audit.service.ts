import type { Prisma } from "@prisma/client";
import {
  countAuditLogs,
  createAuditLog,
  listAuditActors,
  listAuditLogs,
} from "@/repositories/auditLog.repository";

export async function recordAuditEvent(payload: {
  actorId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  metadata?: Prisma.InputJsonValue;
  branchId?: string | null;
}) {
  try {
    return await createAuditLog(payload);
  } catch (error) {
    console.error("Failed to record audit event", error);
    return null;
  }
}

export async function listAuditEvents(
  options: {
    search?: string;
    action?: string;
    entityType?: string;
    actorId?: string;
    limit?: number;
    skip?: number;
  } = {},
) {
  const [logs, total, actors] = await Promise.all([
    listAuditLogs(options),
    countAuditLogs(options),
    listAuditActors(),
  ]);

  return {
    logs,
    total,
    actors,
  };
}
