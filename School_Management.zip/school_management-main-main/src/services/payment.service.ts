import { PaymentStatus } from "@prisma/client";
import { buildFeeLedger } from "@/lib/fee-history";
import { getClassMonthlyFee, getPaymentTotalAmount } from "@/lib/fee-utils";
import {
  findFeeCategoryById,
  listFeeCategories,
} from "@/repositories/feeCategory.repository";
import {
  createPayment,
  deletePaymentRecord,
  findPaymentById,
  findPaymentByStudentCategoryPeriod,
  listPayments,
  updatePaymentRecord,
} from "@/repositories/payment.repository";
import {
  findStudentById,
  listStudents,
} from "@/repositories/student.repository";
import { HttpError } from "@/utils/error-handler";

function formatBillingDedupeKey(month: number, year: number) {
  return `${year}-${String(month).padStart(2, "0")}`;
}

function resolvePaymentStatus(totalAmount: number, amountPaid: number) {
  if (amountPaid <= 0) {
    return PaymentStatus.DUE;
  }

  if (amountPaid >= totalAmount) {
    return PaymentStatus.PAID;
  }

  return PaymentStatus.PARTIAL;
}

function getMonthlySnapshot(
  monthlyFeeSetting:
    | { monthlyFee: number | null; isActive?: boolean | null }
    | null
    | undefined,
) {
  return monthlyFeeSetting?.isActive === false
    ? null
    : (monthlyFeeSetting?.monthlyFee ?? null);
}

function assertNotOverpaid(totalAmount: number, amountPaid: number) {
  if (amountPaid > totalAmount) {
    throw new HttpError(
      `Payment amount cannot exceed the expected total (${totalAmount})`,
      400,
    );
  }
}

export async function listPaymentsForAdmin(filters: {
  search?: string;
  status?: PaymentStatus;
  studentId?: string;
  feeCategoryId?: string;
}) {
  const [payments, students, feeCategories] = await Promise.all([
    listPayments({
      ...filters,
      status: filters.status,
    }),
    listStudents({}),
    listFeeCategories(),
  ]);

  const ledger = buildFeeLedger(payments);

  return {
    payments: ledger.payments,
    history: ledger.history,
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      className: student.class.name,
    })),
    feeCategories: feeCategories.filter((category) => category.isActive),
    stats: {
      total: ledger.history.length,
      collectedAmount: ledger.history.reduce(
        (sum, item) => sum + item.amountPaid,
        0,
      ),
      expectedAmount: ledger.history.reduce(
        (sum, item) => sum + item.totalExpected,
        0,
      ),
      dueAmount: ledger.history.reduce((sum, item) => sum + item.dueAmount, 0),
      dueCount: ledger.history.filter((item) => item.dueAmount > 0).length,
    },
  };
}

export async function createPaymentForAdmin(payload: {
  studentId: string;
  feeCategoryId: string;
  amountPaid: number;
  status: PaymentStatus;
  paymentMethod?: string;
  transactionId?: string;
  month?: number;
  year?: number;
  dueDate?: string;
}) {
  const student = await findStudentById(payload.studentId);
  if (!student) {
    throw new HttpError("Student not found", 404);
  }

  if (payload.month === undefined || payload.year === undefined) {
    throw new HttpError("Billing month and year are required", 400);
  }

  const feeCategory = await findFeeCategoryById(payload.feeCategoryId);
  if (!feeCategory) {
    throw new HttpError("Fee category not found", 404);
  }

  const existingPayment = await findPaymentByStudentCategoryPeriod(
    payload.studentId,
    payload.feeCategoryId,
    payload.month,
    payload.year,
  );

  if (existingPayment) {
    const monthlyFeeBase = getClassMonthlyFee(
      existingPayment.monthlyFeeSnapshot ??
        getMonthlySnapshot(existingPayment.student.class.monthlyFeeSetting),
    );
    const categoryFee =
      existingPayment.feeAmountSnapshot ?? existingPayment.feeCategory.amount;
    const totalAmount = getPaymentTotalAmount(monthlyFeeBase, categoryFee);
    const nextAmountPaid = existingPayment.amountPaid + payload.amountPaid;

    if (existingPayment.amountPaid >= totalAmount) {
      throw new HttpError(
        "This fee category is already settled for this student in the selected billing period",
        409,
      );
    }

    assertNotOverpaid(totalAmount, nextAmountPaid);

    return updatePaymentRecord(existingPayment.id, {
      amountPaid: nextAmountPaid,
      status: resolvePaymentStatus(totalAmount, nextAmountPaid),
      ...(payload.paymentMethod !== undefined
        ? { paymentMethod: payload.paymentMethod.trim() || null }
        : {}),
      ...(payload.transactionId !== undefined
        ? { transactionId: payload.transactionId.trim() || null }
        : {}),
      ...(payload.dueDate !== undefined
        ? { dueDate: payload.dueDate ? new Date(payload.dueDate) : null }
        : {}),
    });
  }

  if (!feeCategory.isActive) {
    throw new HttpError("Fee category is inactive", 400);
  }

  const targetClassIds = feeCategory.targetClasses.map((item) => item.classId);
  if (targetClassIds.length > 0 && !targetClassIds.includes(student.classId)) {
    throw new HttpError(
      "Fee category is not assigned to this student's class",
      400,
    );
  }

  const monthlyFeeSnapshot = getMonthlySnapshot(
    student.class.monthlyFeeSetting,
  );
  const totalAmount = getPaymentTotalAmount(
    monthlyFeeSnapshot,
    feeCategory.amount,
  );
  assertNotOverpaid(totalAmount, payload.amountPaid);

  return createPayment({
    amountPaid: payload.amountPaid,
    status: resolvePaymentStatus(totalAmount, payload.amountPaid),
    paymentMethod: payload.paymentMethod?.trim() || null,
    transactionId: payload.transactionId?.trim() || null,
    monthlyFeeSnapshot,
    feeAmountSnapshot: feeCategory.amount,
    dedupeKey: formatBillingDedupeKey(payload.month, payload.year),
    month: payload.month,
    year: payload.year,
    dueDate: payload.dueDate ? new Date(payload.dueDate) : null,
    student: {
      connect: { id: payload.studentId },
    },
    feeCategory: {
      connect: { id: payload.feeCategoryId },
    },
  });
}

export async function updatePaymentForAdmin(
  id: string,
  payload: {
    amountPaid?: number;
    status?: PaymentStatus;
    paymentMethod?: string | null;
    transactionId?: string | null;
    month?: number | null;
    year?: number | null;
    dueDate?: string | null;
  },
) {
  const existing = await findPaymentById(id);
  if (!existing) {
    throw new HttpError("Payment not found", 404);
  }

  const nextMonth = payload.month !== undefined ? payload.month : existing.month;
  const nextYear = payload.year !== undefined ? payload.year : existing.year;

  if ((nextMonth === null) !== (nextYear === null)) {
    throw new HttpError("Billing month and year must be set together", 400);
  }

  return updatePaymentRecord(id, {
    ...(payload.amountPaid !== undefined
      ? { amountPaid: payload.amountPaid }
      : {}),
    ...(payload.status ? { status: payload.status } : {}),
    ...(payload.paymentMethod !== undefined
      ? { paymentMethod: payload.paymentMethod?.trim() || null }
      : {}),
    ...(payload.transactionId !== undefined
      ? { transactionId: payload.transactionId?.trim() || null }
      : {}),
    ...(payload.month !== undefined ? { month: payload.month } : {}),
    ...(payload.year !== undefined ? { year: payload.year } : {}),
    ...(nextMonth !== existing.month || nextYear !== existing.year
      ? {
          dedupeKey:
            nextMonth !== null && nextYear !== null
              ? formatBillingDedupeKey(nextMonth, nextYear)
              : null,
        }
      : {}),
    ...(payload.dueDate !== undefined
      ? { dueDate: payload.dueDate ? new Date(payload.dueDate) : null }
      : {}),
  });
}

export async function deletePaymentForAdmin(id: string) {
  const existing = await findPaymentById(id);
  if (!existing) {
    throw new HttpError("Payment not found", 404);
  }

  return deletePaymentRecord(id);
}
