import { PaymentStatus } from "@prisma/client";
import { comparePassword } from "@/lib/auth";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import {
  createFeeCategory,
  deleteFeeCategoryRecord,
  findFeeCategoryById,
  listFeeCategories,
  updateFeeCategoryRecord,
} from "@/repositories/feeCategory.repository";
import { listClasses } from "@/repositories/class.repository";
import { HttpError } from "@/utils/error-handler";

function normalizeClassIds(classIds?: string[]) {
  return Array.from(
    new Set((classIds ?? []).map((value) => value.trim()).filter(Boolean)),
  );
}

async function assertClassesExist(
  classIds: string[],
  client: PrismaClientLike,
) {
  if (classIds.length === 0) {
    return [];
  }

  const classes = await client.class.findMany({
    where: { id: { in: classIds } },
    select: { id: true },
  });

  if (classes.length !== classIds.length) {
    throw new HttpError("One or more classes not found", 404);
  }

  return classes;
}

async function replaceFeeCategoryClasses(
  client: PrismaClientLike,
  feeCategoryId: string,
  classIds: string[],
) {
  await client.feeCategoryClass.deleteMany({
    where: { feeCategoryId },
  });

  if (classIds.length === 0) {
    return;
  }

  await client.feeCategoryClass.createMany({
    data: classIds.map((classId) => ({
      feeCategoryId,
      classId,
    })),
    skipDuplicates: true,
  });
}

async function assignFeeCategoryToClassStudents(
  client: PrismaClientLike,
  feeCategoryId: string,
  classIds: string[],
  feeAmount: number,
) {
  if (classIds.length === 0) {
    return 0;
  }

  const students = await client.student.findMany({
    where: {
      isDeleted: false,
      classId: { in: classIds },
    },
    select: {
      id: true,
      class: {
        select: {
          monthlyFeeSetting: {
            select: {
              monthlyFee: true,
              isActive: true,
            },
          },
        },
      },
    },
  });

  if (students.length === 0) {
    return 0;
  }

  const dedupeKey = `secondary:${feeCategoryId}`;
  const result = await client.payment.createMany({
    data: students.map((student) => ({
      studentId: student.id,
      feeCategoryId,
      amountPaid: 0,
      status: PaymentStatus.DUE,
      monthlyFeeSnapshot:
        student.class.monthlyFeeSetting?.isActive === false
          ? null
          : (student.class.monthlyFeeSetting?.monthlyFee ?? null),
      feeAmountSnapshot: feeAmount,
      dedupeKey,
      month: null,
      year: null,
      dueDate: null,
      paymentMethod: null,
      transactionId: null,
    })),
    skipDuplicates: true,
  });

  return result.count;
}

export async function syncFeeCategoryAssignmentsForStudent(
  studentId: string,
  classId: string,
  client: PrismaClientLike = prisma,
) {
  const student = await client.student.findUnique({
    where: { id: studentId },
    select: {
      class: {
        select: {
          monthlyFeeSetting: {
            select: {
              monthlyFee: true,
              isActive: true,
            },
          },
        },
      },
    },
  });

  const feeCategories = await client.feeCategory.findMany({
    where: {
      isActive: true,
      targetClasses: {
        some: {
          classId,
        },
      },
    },
    select: {
      id: true,
      amount: true,
    },
  });

  if (feeCategories.length === 0) {
    return 0;
  }

  const result = await client.payment.createMany({
    data: feeCategories.map((feeCategory) => ({
      studentId,
      feeCategoryId: feeCategory.id,
      amountPaid: 0,
      status: PaymentStatus.DUE,
      monthlyFeeSnapshot:
        student?.class.monthlyFeeSetting?.isActive === false
          ? null
          : (student?.class.monthlyFeeSetting?.monthlyFee ?? null),
      feeAmountSnapshot: feeCategory.amount,
      dedupeKey: `secondary:${feeCategory.id}`,
      month: null,
      year: null,
      dueDate: null,
      paymentMethod: null,
      transactionId: null,
    })),
    skipDuplicates: true,
  });

  return result.count;
}

export async function listFeeCategoriesForAdmin(search?: string) {
  const [categories, classes] = await Promise.all([
    listFeeCategories(search),
    listClasses(),
  ]);

  return {
    categories,
    classes,
    stats: {
      total: categories.length,
      configuredAmount: categories.reduce((sum, item) => sum + item.amount, 0),
    },
  };
}

export async function createFeeCategoryForAdmin(payload: {
  name: string;
  amount: number;
  classIds?: string[];
}) {
  const classIds = normalizeClassIds(payload.classIds);

  return prisma.$transaction(async (tx) => {
    await assertClassesExist(classIds, tx);

    const category = await createFeeCategory(
      {
        name: payload.name.trim(),
        amount: payload.amount,
        isActive: true,
      },
      tx,
    );

    await replaceFeeCategoryClasses(tx, category.id, classIds);
    const assignedCount = await assignFeeCategoryToClassStudents(
      tx,
      category.id,
      classIds,
      payload.amount,
    );

    const refreshed = await findFeeCategoryById(category.id, tx);
    if (!refreshed) {
      throw new HttpError("Fee category not found", 404);
    }

    return {
      ...refreshed,
      assignedCount,
    };
  });
}

export async function updateFeeCategoryForAdmin(
  id: string,
  payload: {
    name?: string;
    amount?: number;
    classIds?: string[];
    isActive?: boolean;
  },
) {
  const existing = await findFeeCategoryById(id);
  if (!existing) {
    throw new HttpError("Fee category not found", 404);
  }

  const classIds =
    payload.classIds !== undefined ? normalizeClassIds(payload.classIds) : null;

  return prisma.$transaction(async (tx) => {
    if (classIds) {
      await assertClassesExist(classIds, tx);
    }

    await updateFeeCategoryRecord(
      id,
      {
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(payload.amount !== undefined ? { amount: payload.amount } : {}),
        ...(payload.isActive !== undefined
          ? { isActive: payload.isActive }
          : {}),
      },
      tx,
    );

    if (classIds) {
      await replaceFeeCategoryClasses(tx, id, classIds);
      await assignFeeCategoryToClassStudents(
        tx,
        id,
        classIds,
        payload.amount ?? existing.amount,
      );
    }

    const refreshed = await findFeeCategoryById(id, tx);
    if (!refreshed) {
      throw new HttpError("Fee category not found", 404);
    }

    return refreshed;
  });
}

export async function deleteFeeCategoryForAdmin(
  id: string,
  payload: {
    actorId?: string;
    permanent?: boolean;
    force?: boolean;
    currentPassword?: string;
  } = {},
) {
  const existing = await findFeeCategoryById(id);
  if (!existing) {
    throw new HttpError("Fee category not found", 404);
  }

  if (payload.force) {
    if (!payload.actorId) {
      throw new HttpError("Authentication required", 401);
    }

    if (!payload.currentPassword) {
      throw new HttpError("Admin password is required for force delete", 400);
    }

    const currentPassword = payload.currentPassword;

    return prisma.$transaction(async (tx) => {
      const actor = await tx.user.findUnique({
        where: { id: payload.actorId },
        select: { password: true },
      });

      if (!actor) {
        throw new HttpError("Admin account not found", 404);
      }

      const passwordIsValid = await comparePassword(
        currentPassword,
        actor.password,
      );

      if (!passwordIsValid) {
        throw new HttpError("Admin password is incorrect", 401);
      }

      await tx.payment.deleteMany({
        where: { feeCategoryId: id },
      });

      return deleteFeeCategoryRecord(id, tx);
    });
  }

  if (payload.permanent) {
    if (existing._count.payments > 0) {
      throw new HttpError(
        "Use force delete to remove linked payment records before permanently deleting this fee category",
        409,
      );
    }

    return deleteFeeCategoryRecord(id);
  }

  return updateFeeCategoryRecord(id, {
    isActive: false,
  });
}
