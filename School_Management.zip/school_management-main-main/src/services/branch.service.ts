import { prisma } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";
import { createBranch, findBranchById, listBranches, updateBranch } from "@/repositories/branch.repository";
import { createSchool, findSchoolById, listSchools } from "@/repositories/school.repository";

export async function listBranchesPublic() {
  const branches = await listBranches({ includeInactive: false });
  return {
    branches: branches.map((branch) => ({
      id: branch.id,
      name: branch.name,
      slug: branch.slug,
      school: {
        id: branch.school.id,
        name: branch.school.name,
        slug: branch.school.slug,
      },
    })),
  };
}

export async function listBranchesForSuperAdmin(includeInactive = false) {
  const branches = await listBranches({ includeInactive });
  return { branches };
}

export async function createBranchForSuperAdmin(payload: {
  schoolId?: string;
  name: string;
  slug: string;
  isActive?: boolean;
}) {
  let schoolId = payload.schoolId;
  if (!schoolId) {
    const schools = await listSchools({ includeInactive: true });
    if (schools.length === 0) {
      const created = await createSchool({
        name: "Default School",
        slug: "default-school",
        isActive: true,
      });
      schoolId = created.id;
    } else {
      schoolId = schools[0].id;
    }
  }

  const school = await findSchoolById(schoolId);
  if (!school) throw new HttpError("School not found", 404);

  return createBranch({
    school: { connect: { id: school.id } },
    name: payload.name.trim(),
    slug: payload.slug.trim(),
    isActive: payload.isActive ?? true,
  });
}

export async function updateBranchForSuperAdmin(payload: {
  branchId: string;
  name?: string;
  slug?: string;
  isActive?: boolean;
}) {
  const branch = await findBranchById(payload.branchId);
  if (!branch) {
    throw new HttpError("Branch not found", 404);
  }

  return updateBranch(payload.branchId, {
    ...(payload.name ? { name: payload.name.trim() } : {}),
    ...(payload.slug ? { slug: payload.slug.trim() } : {}),
    ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
  });
}

export async function assertBranchIsActive(branchId: string) {
  const branch = await prisma.branch.findUnique({
    where: { id: branchId },
    select: {
      id: true,
      name: true,
      slug: true,
      isActive: true,
      school: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
    },
  });
  if (!branch) throw new HttpError("Branch not found", 404);
  if (!branch.isActive) throw new HttpError("Branch is inactive", 403);
  return branch;
}
