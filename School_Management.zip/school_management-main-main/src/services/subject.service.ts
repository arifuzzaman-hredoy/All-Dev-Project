import { findClassById, listClasses } from "@/repositories/class.repository";
import {
  createSubject,
  deleteSubjectRecord,
  findSubjectById,
  listSubjects,
  updateSubjectRecord,
} from "@/repositories/subject.repository";
import { HttpError } from "@/utils/error-handler";

export async function listSubjectsForAdmin(filters: {
  search?: string;
  classId?: string;
}) {
  const [subjects, classes] = await Promise.all([
    listSubjects(filters),
    listClasses(),
  ]);

  return {
    subjects,
    classes,
    stats: {
      total: subjects.length,
      linkedTeachers: subjects.reduce((sum, item) => sum + item._count.teachers, 0),
    },
  };
}

export async function createSubjectForAdmin(payload: {
  name: string;
  classId: string;
}) {
  const classRecord = await findClassById(payload.classId);
  if (!classRecord) {
    throw new HttpError("Selected class does not exist", 404);
  }

  return createSubject({
    name: payload.name.trim(),
    class: {
      connect: { id: payload.classId },
    },
  });
}

export async function updateSubjectForAdmin(
  id: string,
  payload: { name?: string; classId?: string }
) {
  const existing = await findSubjectById(id);
  if (!existing) {
    throw new HttpError("Subject not found", 404);
  }

  if (payload.classId) {
    const classRecord = await findClassById(payload.classId);
    if (!classRecord) {
      throw new HttpError("Selected class does not exist", 404);
    }
  }

  return updateSubjectRecord(id, {
    ...(payload.name ? { name: payload.name.trim() } : {}),
    ...(payload.classId
      ? {
          class: {
            connect: { id: payload.classId },
          },
        }
      : {}),
  });
}

export async function deleteSubjectForAdmin(id: string) {
  const existing = await findSubjectById(id);
  if (!existing) {
    throw new HttpError("Subject not found", 404);
  }

  return deleteSubjectRecord(id);
}
