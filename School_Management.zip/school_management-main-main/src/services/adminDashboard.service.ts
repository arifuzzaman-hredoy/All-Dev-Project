import { PaymentStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { buildVisibleNoticeWhere } from "@/repositories/notice.repository";
import { syncExpiredNotices } from "@/services/notice.service";

function getMonthLabel(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    year: "2-digit",
  }).format(date);
}

function getDayLabel(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
  }).format(date);
}

function startOfMonth(date: Date, offsetMonths = 0) {
  return new Date(date.getFullYear(), date.getMonth() + offsetMonths, 1);
}

function startOfDay(date: Date, offsetDays = 0) {
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate() + offsetDays,
  );
}

export async function getAdminDashboard() {
  const today = new Date();
  await syncExpiredNotices();
  const startOfToday = startOfDay(today);
  const endOfToday = startOfDay(today, 1);
  const upcomingWindow = startOfDay(today, 30);
  const admissionsWindowStart = startOfMonth(today, -5);
  const attendanceWindowStart = startOfDay(today, -13);
  const admissionsMonths = Array.from({ length: 6 }, (_, index) => {
    const monthDate = startOfMonth(today, index - 5);
    return {
      key: `${monthDate.getFullYear()}-${String(monthDate.getMonth() + 1).padStart(2, "0")}`,
      label: getMonthLabel(monthDate),
      total: 0,
      pending: 0,
      approved: 0,
      incomplete: 0,
      rejected: 0,
    };
  });
  const attendanceDays = Array.from({ length: 14 }, (_, index) => {
    const day = startOfDay(today, index - 13);
    return {
      key: day.toISOString().slice(0, 10),
      label: getDayLabel(day),
      present: 0,
      absent: 0,
      late: 0,
      total: 0,
      rate: 0,
    };
  });

  const [
    activeStudents,
    activeTeachers,
    totalParents,
    payments,
    todayAttendance,
    pendingAdmissions,
    liveNotices,
    totalClasses,
    totalSubjects,
    upcomingExams,
    recentNotices,
    recentAdmissions,
    teacherActivity,
    monthlyAdmissions,
    recentAttendance,
  ] = await Promise.all([
    prisma.student.count({
      where: {
        isDeleted: false,
        user: { isDeleted: false },
      },
    }),
    prisma.teacher.count({
      where: {
        isDeleted: false,
        user: { isDeleted: false },
      },
    }),
    prisma.parent.count({
      where: {
        user: { isDeleted: false },
      },
    }),
    prisma.payment.findMany({
      select: {
        id: true,
        amountPaid: true,
        status: true,
        createdAt: true,
        student: {
          select: {
            user: { select: { name: true } },
          },
        },
        feeCategory: {
          select: {
            name: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
    prisma.attendance.findMany({
      where: {
        date: {
          gte: startOfToday,
          lt: endOfToday,
        },
      },
      select: {
        status: true,
      },
    }),
    prisma.admissionApplication.count({
      where: {
        status: "PENDING",
      },
    }),
    prisma.notice.count({ where: buildVisibleNoticeWhere() }),
    prisma.class.count(),
    prisma.subject.count(),
    prisma.exam.count({
      where: {
        date: {
          gte: startOfToday,
          lte: upcomingWindow,
        },
        status: {
          not: "ARCHIVED",
        },
      },
    }),
    prisma.notice.findMany({
      where: buildVisibleNoticeWhere(),
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        title: true,
        content: true,
        audience: true,
        createdAt: true,
      },
    }),
    prisma.admissionApplication.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        name: true,
        status: true,
        createdAt: true,
      },
    }),
    prisma.teacher.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        createdAt: true,
        user: {
          select: {
            name: true,
          },
        },
        phone: true,
        salary: true,
      },
    }),
    prisma.admissionApplication.findMany({
      where: {
        createdAt: {
          gte: admissionsWindowStart,
        },
      },
      select: {
        createdAt: true,
        status: true,
      },
    }),
    prisma.attendance.findMany({
      where: {
        date: {
          gte: attendanceWindowStart,
          lt: endOfToday,
        },
      },
      select: {
        date: true,
        status: true,
      },
    }),
  ]);

  const totalCollected = payments.reduce(
    (sum, payment) => sum + payment.amountPaid,
    0,
  );
  const attendanceRate =
    todayAttendance.length > 0
      ? Math.round(
          (todayAttendance.filter((entry) => entry.status === "PRESENT")
            .length /
            todayAttendance.length) *
            100,
        )
      : 0;
  const duePayments = payments.filter(
    (payment) => payment.status !== PaymentStatus.PAID,
  ).length;

  for (const admission of monthlyAdmissions) {
    const key = `${admission.createdAt.getFullYear()}-${String(admission.createdAt.getMonth() + 1).padStart(2, "0")}`;
    const bucket = admissionsMonths.find((item) => item.key === key);
    if (!bucket) continue;

    bucket.total += 1;
    if (admission.status === "PENDING") bucket.pending += 1;
    if (admission.status === "ACCEPTED") bucket.approved += 1;
    if (admission.status === "REJECTED") bucket.rejected += 1;
  }

  for (const entry of recentAttendance) {
    const key = entry.date.toISOString().slice(0, 10);
    const bucket = attendanceDays.find((item) => item.key === key);
    if (!bucket) continue;

    bucket.total += 1;
    if (entry.status === "PRESENT") bucket.present += 1;
    if (entry.status === "ABSENT") bucket.absent += 1;
    if (entry.status === "LATE") bucket.late += 1;
  }

  attendanceDays.forEach((bucket) => {
    bucket.rate =
      bucket.total > 0 ? Math.round((bucket.present / bucket.total) * 100) : 0;
  });

  return {
    hero: {
      activeStudents,
      totalCollected,
      attendanceRate,
      pendingAdmissions,
    },
    focus: {
      liveNotices,
      activeTeachers,
      totalParents,
      totalClasses,
      totalSubjects,
      upcomingExams,
      duePayments,
    },
    pulse: {
      recentNotices: recentNotices.map((notice) => ({
        id: notice.id,
        title: notice.title,
        detail: notice.content,
        tag: notice.audience,
        createdAt: notice.createdAt,
      })),
      recentAdmissions: recentAdmissions.map((item) => ({
        id: item.id,
        title: item.name,
        detail: `Admission status: ${item.status}`,
        tag: "Admission",
        createdAt: item.createdAt,
      })),
      recentPayments: payments.slice(0, 5).map((payment) => ({
        id: payment.id,
        title: payment.student.user.name,
        detail: `${payment.feeCategory.name} · ${payment.status} · ৳${payment.amountPaid}`,
        tag: "Finance",
        createdAt: payment.createdAt,
      })),
    },
    insights: {
      monthlyAdmissions: admissionsMonths.map((item) => ({
        month: item.label,
        total: item.total,
        pending: item.pending,
        approved: item.approved,
        incomplete: item.incomplete,
        rejected: item.rejected,
      })),
      attendanceTrends: attendanceDays.map((item) => ({
        day: item.label,
        present: item.present,
        absent: item.absent,
        late: item.late,
        rate: item.rate,
      })),
      teacherActivity: teacherActivity.map((teacher) => ({
        id: teacher.id,
        name: teacher.user.name,
        createdAt: teacher.createdAt,
        phone: teacher.phone,
        salary: teacher.salary,
      })),
      systemPerformance: {
        attendanceRate,
        duePayments,
        upcomingExams,
        liveNotices,
      },
    },
  };
}
