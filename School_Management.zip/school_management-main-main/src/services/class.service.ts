import { Gender } from "@prisma/client";
import {
  createManagedClass,
  deleteManagedClass,
  findClassByName,
  findManagedClassById,
  listManagedClasses,
  updateManagedClass,
} from "@/repositories/class.repository";
import { prisma } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";

type GenderCounts = Record<Gender, number>;
type ClassGroupSummary = {
  id: string | null;
  name: string;
  totals: GenderCounts;
  totalStudents: number;
};

function looksLikeLegacyCombinedClass(name: string) {
  const normalized = name.trim();
  return /^(\d+)\s*[A-Za-z]$/.test(normalized);
}

function emptyGenderCounts(): GenderCounts {
  return {
    [Gender.MALE]: 0,
    [Gender.FEMALE]: 0,
    [Gender.OTHER]: 0,
  };
}

function totalGenderCounts(counts: GenderCounts) {
  return Object.values(counts).reduce((sum, value) => sum + value, 0);
}

export async function listClassesForAdmin(search?: string) {
  const classes = await listManagedClasses(search);
  const classIds = classes.map((item) => item.id);

  const [studentRows, groups] =
    classIds.length > 0
      ? await Promise.all([
          prisma.student.groupBy({
            by: ["classId", "groupId", "gender"],
            where: {
              classId: { in: classIds },
              isDeleted: false,
              user: { isDeleted: false },
            },
            _count: { _all: true },
          }),
          prisma.group.findMany({
            where: { classId: { in: classIds } },
            select: { id: true, name: true, classId: true },
            orderBy: [{ name: "asc" }],
          }),
        ])
      : [[], []];

  const classGenderCounts = new Map<string, GenderCounts>();
  const groupGenderCounts = new Map<string, GenderCounts>();
  const unassignedGroupCounts = new Map<string, GenderCounts>();

  for (const row of studentRows) {
    const classCounts = classGenderCounts.get(row.classId) ?? emptyGenderCounts();
    classCounts[row.gender] += row._count._all;
    classGenderCounts.set(row.classId, classCounts);

    if (row.groupId) {
      const groupCounts = groupGenderCounts.get(row.groupId) ?? emptyGenderCounts();
      groupCounts[row.gender] += row._count._all;
      groupGenderCounts.set(row.groupId, groupCounts);
    } else {
      const groupCounts =
        unassignedGroupCounts.get(row.classId) ?? emptyGenderCounts();
      groupCounts[row.gender] += row._count._all;
      unassignedGroupCounts.set(row.classId, groupCounts);
    }
  }

  const groupsByClassId = new Map<string, typeof groups>();
  for (const group of groups) {
    const current = groupsByClassId.get(group.classId) ?? [];
    current.push(group);
    groupsByClassId.set(group.classId, current);
  }

  const classesWithSummaries = classes.map((item) => {
    const studentSummary = classGenderCounts.get(item.id) ?? emptyGenderCounts();
    const groupSummaries: ClassGroupSummary[] = (
      groupsByClassId.get(item.id) ?? []
    ).map((group) => {
      const totals = groupGenderCounts.get(group.id) ?? emptyGenderCounts();
      return {
        id: group.id,
        name: group.name,
        totals,
        totalStudents: totalGenderCounts(totals),
      };
    });

    const unassignedTotals = unassignedGroupCounts.get(item.id);
    if (unassignedTotals && totalGenderCounts(unassignedTotals) > 0) {
      groupSummaries.push({
        id: null,
        name: "No group assigned",
        totals: unassignedTotals,
        totalStudents: totalGenderCounts(unassignedTotals),
      });
    }

    return {
      ...item,
      studentSummary,
      totalStudents: totalGenderCounts(studentSummary),
      groupSummaries,
    };
  });

  return {
    classes: classesWithSummaries,
    stats: {
      total: classesWithSummaries.length,
      totalStudents: classesWithSummaries.reduce(
        (sum, item) => sum + item.totalStudents,
        0,
      ),
      totalBoys: classesWithSummaries.reduce(
        (sum, item) => sum + item.studentSummary.MALE,
        0,
      ),
      totalGirls: classesWithSummaries.reduce(
        (sum, item) => sum + item.studentSummary.FEMALE,
        0,
      ),
      totalOther: classesWithSummaries.reduce(
        (sum, item) => sum + item.studentSummary.OTHER,
        0,
      ),
      totalGroups: classesWithSummaries.reduce((sum, item) => sum + item._count.groups, 0),
      totalSubjects: classesWithSummaries.reduce(
        (sum, item) => sum + item._count.subjects,
        0,
      ),
    },
  };
}

export async function createClassForAdmin(payload: {
  name: string;
  studentLimit?: number | null;
}) {
  const name = payload.name;
  const normalized = name.trim();
  if (looksLikeLegacyCombinedClass(normalized)) {
    throw new HttpError(
      "Create the class first (e.g. 1) and then create groups (e.g. A/B) under it",
      400,
    );
  }
  const existing = await findClassByName(normalized);
  if (existing) {
    throw new HttpError("Class already exists", 409);
  }

  const max = await prisma.class.aggregate({
    where: {
      NOT: {
        name: { equals: "Unassigned", mode: "insensitive" },
      },
    },
    _max: { sortOrder: true },
  });

  const sortOrder = (max._max.sortOrder ?? 0) + 1;
  return createManagedClass({
    name: normalized,
    sortOrder,
    studentLimit: payload.studentLimit ?? null,
  });
}

export async function updateClassForAdmin(
  id: string,
  payload: { name?: string; studentLimit?: number | null },
) {
  const normalized = payload.name?.trim();
  if (normalized) {
    if (looksLikeLegacyCombinedClass(normalized)) {
      throw new HttpError(
        "Use Groups (A/B/etc) instead of combining them into the class name",
        400,
      );
    }
    const existing = await findClassByName(normalized);
    if (existing && existing.id !== id) {
      throw new HttpError("Class already exists", 409);
    }
  }

  return updateManagedClass(id, {
    ...(normalized ? { name: normalized } : {}),
    ...(payload.studentLimit !== undefined
      ? { studentLimit: payload.studentLimit }
      : {}),
  });
}

export async function deleteClassForAdmin(id: string) {
  const classRecord = await findManagedClassById(id);

  if (!classRecord) {
    throw new HttpError("Class not found", 404);
  }

  if (classRecord.name.trim().toLowerCase() === "unassigned") {
    throw new HttpError("The default Unassigned class cannot be deleted", 409);
  }

  if (
    classRecord._count.students > 0 ||
    classRecord._count.groups > 0 ||
    classRecord._count.subjects > 0
  ) {
    throw new HttpError(
      "Move students, groups, and subjects out of this class before deleting it",
      409,
    );
  }

  return deleteManagedClass(id);
}

export async function reorderClassesForAdmin(orderedClassIds: string[]) {
  const uniqueIds = Array.from(
    new Set(orderedClassIds.map((id) => id.trim()).filter(Boolean)),
  );
  if (uniqueIds.length === 0) {
    throw new HttpError("At least one class is required", 400);
  }

  const classes = await prisma.class.findMany({
    where: {
      NOT: {
        name: { equals: "Unassigned", mode: "insensitive" },
      },
    },
    select: { id: true, name: true },
  });
  const knownIds = new Set(classes.map((row) => row.id));
  const unknownIds = uniqueIds.filter((id) => !knownIds.has(id));
  if (unknownIds.length > 0) {
    throw new HttpError("One or more classes not found or cannot be reordered", 404);
  }

  if (classes.length !== uniqueIds.length) {
    throw new HttpError(
      "Submit the full class order before saving. Clear search filters and try again.",
      400,
    );
  }

  await prisma.$transaction(async (tx) => {
    for (let index = 0; index < uniqueIds.length; index += 1) {
      await tx.class.update({
        where: { id: uniqueIds[index] },
        data: { sortOrder: index + 1 },
      });
    }
  });

  return listClassesForAdmin();
}
