import { hashPassword } from "@/lib/auth";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { getScopedBranchId } from "@/lib/request-context";
import {
  createGuardian,
  findGuardianById,
  listGuardiansPaged,
  countGuardiansBySearch,
  updateGuardianRecord,
} from "@/repositories/guardian.repository";
import { findStudentById } from "@/repositories/student.repository";
import { createUser, findUserByEmail } from "@/repositories/user.repository";
import { HttpError } from "@/utils/error-handler";

async function assertLinkableStudents(
  studentIds: string[],
  currentGuardianId?: string,
) {
  await Promise.all(
    studentIds.map(async (studentId) => {
      const student = await findStudentById(studentId);
      if (!student || student.isDeleted || student.user.isDeleted) {
        throw new HttpError("One or more selected students do not exist", 404);
      }

      if (student.guardianId && student.guardianId !== currentGuardianId) {
        throw new HttpError(
          `${student.user.name} is already linked to another guardian`,
          409,
        );
      }
    }),
  );
}

async function assertLinkableStudentsInTransaction(
  studentIds: string[],
  client: PrismaClientLike,
  currentGuardianId?: string,
) {
  if (!studentIds.length) return;

  const students = await client.student.findMany({
    where: { id: { in: studentIds } },
    select: {
      id: true,
      guardianId: true,
      isDeleted: true,
      user: {
        select: {
          isDeleted: true,
          name: true,
        },
      },
    },
  });

  const foundIds = new Set(students.map((student) => student.id));
  const missing = studentIds.find((id) => !foundIds.has(id));
  if (missing) {
    throw new HttpError("One or more selected students do not exist", 404);
  }

  for (const student of students) {
    if (student.isDeleted || student.user.isDeleted) {
      throw new HttpError("One or more selected students do not exist", 404);
    }

    if (student.guardianId && student.guardianId !== currentGuardianId) {
      throw new HttpError(
        `${student.user.name} is already linked to another guardian`,
        409,
      );
    }
  }
}

export async function listGuardiansForAdmin(options: {
  search?: string;
  unlinkedStudentsOnly?: boolean;
  page?: number;
  pageSize?: number;
} = {}) {
  const page = options.page ?? 1;
  const pageSize = options.pageSize ?? 20;
  const skip = (page - 1) * pageSize;

  const [guardians, students, filteredTotal, totalGuardians, linkedStudents] =
    await Promise.all([
      listGuardiansPaged({ search: options.search, skip, take: pageSize }),
    prisma.student.findMany({
      where: {
        isDeleted: false,
        user: { isDeleted: false },
        ...(options.unlinkedStudentsOnly ? { guardianId: null } : {}),
      },
      orderBy: [{ class: { name: "asc" } }, { user: { name: "asc" } }],
      select: {
        id: true,
        guardianId: true,
        user: {
          select: {
            name: true,
          },
        },
        class: {
          select: {
            name: true,
          },
        },
        guardian: {
          select: {
            user: {
              select: {
                name: true,
              },
            },
            name: true,
          },
        },
      },
    }),
    countGuardiansBySearch(options.search),
    prisma.guardian.count({
      where: { isDeleted: false, userId: { not: null } },
    }),
    prisma.student.count({
      where: {
        isDeleted: false,
        user: { isDeleted: false },
        guardianId: { not: null },
      },
    }),
  ]);

  return {
    guardians,
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      className: student.class.name,
      guardianId: student.guardianId,
      guardianName:
        student.guardian?.user?.name ?? student.guardian?.name ?? null,
    })),
    stats: {
      total: totalGuardians,
      linkedStudents,
    },
    pagination: {
      page,
      pageSize,
      total: filteredTotal,
      totalPages: Math.max(1, Math.ceil(filteredTotal / pageSize)),
    },
  };
}

export async function createGuardianForAdmin(payload: {
  name: string;
  email: string;
  password: string;
  phone?: string;
  address?: string;
  studentIds?: string[];
}) {
  const normalizedEmail = payload.email.trim().toLowerCase();
  const branchId = getScopedBranchId();
  const existingUser = await findUserByEmail(normalizedEmail);
  if (existingUser) {
    throw new HttpError("Email already exists", 409);
  }

  if (payload.studentIds?.length) {
    await assertLinkableStudents(payload.studentIds);
  }

  return prisma.$transaction(async (tx) => {
    const user = await createUser(
      {
        name: payload.name.trim(),
        email: normalizedEmail,
        password: await hashPassword(payload.password),
        role: "PARENT",
        ...(branchId ? { branch: { connect: { id: branchId } } } : {}),
      },
      tx,
    );

    const guardian = await createGuardian(
      {
        user: {
          connect: { id: user.id },
        },
        name: payload.name.trim(),
        email: normalizedEmail,
        phone: payload.phone?.trim() || null,
        address: payload.address?.trim() || null,
      },
      tx,
    );

    const studentIds = payload.studentIds ?? [];
    if (studentIds.length) {
      await assertLinkableStudentsInTransaction(studentIds, tx);
      const updated = await tx.student.updateMany({
        where: {
          id: { in: studentIds },
          guardianId: null,
        },
        data: {
          guardianId: guardian.id,
        },
      });

      if (updated.count !== studentIds.length) {
        throw new HttpError(
          "One or more selected students are already linked to another guardian",
          409,
        );
      }
    }

    const refreshed = await findGuardianById(guardian.id, tx);
    if (!refreshed) {
      throw new HttpError("Guardian not found", 500);
    }
    return refreshed;
  });
}

export async function updateGuardianForAdmin(
  id: string,
  payload: {
    name?: string;
    email?: string;
    password?: string;
    phone?: string | null;
    address?: string | null;
    studentIds?: string[];
  },
) {
  const existing = await findGuardianById(id);
  if (!existing || !existing.user) {
    throw new HttpError("Guardian not found", 404);
  }

  if (payload.studentIds) {
    await assertLinkableStudents(payload.studentIds, existing.id);
  }

  return prisma.$transaction(async (tx) => {
    const normalizedEmail = payload.email?.trim().toLowerCase();
    if (normalizedEmail) {
      const otherUser = await findUserByEmail(normalizedEmail, tx);
      if (otherUser && otherUser.id !== existing.user!.id) {
        throw new HttpError("Email already exists", 409);
      }
    }

    await tx.user.update({
      where: { id: existing.user!.id },
      data: {
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(normalizedEmail ? { email: normalizedEmail } : {}),
        ...(payload.password
          ? { password: await hashPassword(payload.password) }
          : {}),
      },
    });

    if (payload.studentIds) {
      const nextStudentIds = payload.studentIds;
      await assertLinkableStudentsInTransaction(
        nextStudentIds,
        tx,
        existing.id,
      );

      await tx.student.updateMany({
        where: {
          guardianId: existing.id,
          ...(nextStudentIds.length ? { id: { notIn: nextStudentIds } } : {}),
        },
        data: {
          guardianId: null,
        },
      });

      if (nextStudentIds.length) {
        const updated = await tx.student.updateMany({
          where: {
            id: { in: nextStudentIds },
            OR: [{ guardianId: null }, { guardianId: existing.id }],
          },
          data: {
            guardianId: existing.id,
          },
        });

        if (updated.count !== nextStudentIds.length) {
          throw new HttpError(
            "One or more selected students are already linked to another guardian",
            409,
          );
        }
      }
    }

    return updateGuardianRecord(
      id,
      {
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(normalizedEmail ? { email: normalizedEmail } : {}),
        ...(payload.phone !== undefined ? { phone: payload.phone?.trim() || null } : {}),
        ...(payload.address !== undefined
          ? { address: payload.address?.trim() || null }
          : {}),
      },
      tx,
    );
  });
}

export async function deactivateGuardianForAdmin(id: string) {
  const existing = await findGuardianById(id);
  if (!existing || !existing.user) {
    throw new HttpError("Guardian not found", 404);
  }

  await prisma.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: existing.user!.id },
      data: { isDeleted: true },
    });

    await tx.guardian.update({
      where: { id: existing.id },
      data: { isDeleted: true },
    });
  });

  return findGuardianById(id);
}

export async function transferStudentToGuardianForAdmin(payload: {
  studentId: string;
  currentGuardianId: string;
  targetGuardianId: string;
}) {
  if (payload.currentGuardianId === payload.targetGuardianId) {
    throw new HttpError(
      "Target guardian must be different from current guardian",
      400,
    );
  }

  const [student, currentGuardian, targetGuardian] = await Promise.all([
    findStudentById(payload.studentId),
    findGuardianById(payload.currentGuardianId),
    findGuardianById(payload.targetGuardianId),
  ]);

  if (!student || student.isDeleted || student.user.isDeleted) {
    throw new HttpError("Student not found", 404);
  }

  if (!currentGuardian || !currentGuardian.user || currentGuardian.user.isDeleted) {
    throw new HttpError("Current guardian not found", 404);
  }

  if (!targetGuardian || !targetGuardian.user || targetGuardian.user.isDeleted) {
    throw new HttpError("Target guardian not found", 404);
  }

  if (student.guardianId !== currentGuardian.id) {
    throw new HttpError(
      "This student is no longer linked to the selected guardian",
      409,
    );
  }

  const updatedStudent = await prisma.student.update({
    where: { id: student.id },
    data: {
      guardian: {
        connect: { id: targetGuardian.id },
      },
    },
    select: {
      id: true,
      user: {
        select: {
          name: true,
        },
      },
      guardianId: true,
    },
  });

  return {
    student: updatedStudent,
    fromGuardian: {
      id: currentGuardian.id,
      name: currentGuardian.user.name,
    },
    toGuardian: {
      id: targetGuardian.id,
      name: targetGuardian.user.name,
    },
  };
}
