import { PaymentStatus } from "@prisma/client";
import { buildFeeLedger } from "@/lib/fee-history";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";

function formatDedupeKey(month: number, year: number) {
  return `${year}-${String(month).padStart(2, "0")}`;
}

function buildDueDate(month: number, year: number) {
  // Last day of the month at 23:59:59 UTC
  return new Date(Date.UTC(year, month, 0, 23, 59, 59, 0));
}

export async function generateDuesForPeriod(
  payload: { month: number; year: number; classId?: string },
  client: PrismaClientLike = prisma,
) {
  if (payload.month < 1 || payload.month > 12) {
    throw new HttpError("Invalid month", 400);
  }

  if (payload.year < 2000 || payload.year > 2100) {
    throw new HttpError("Invalid year", 400);
  }

  const dedupeKey = formatDedupeKey(payload.month, payload.year);
  const dueDate = buildDueDate(payload.month, payload.year);

  const students = await client.student.findMany({
    where: {
      isDeleted: false,
      user: { isDeleted: false },
      ...(payload.classId ? { classId: payload.classId } : {}),
    },
    select: {
      id: true,
      classId: true,
      class: {
        select: {
          monthlyFeeSetting: {
            select: {
              monthlyFee: true,
              isActive: true,
            },
          },
        },
      },
    },
  });

  if (students.length === 0) {
    return { expected: 0, created: 0, skipped: 0 };
  }

  const classIds = Array.from(new Set(students.map((student) => student.classId)));
  const feeAssignments = await client.feeCategoryClass.findMany({
    where: {
      classId: { in: classIds },
      feeCategory: { isActive: true },
    },
    select: {
      classId: true,
      feeCategoryId: true,
      feeCategory: {
        select: {
          amount: true,
        },
      },
    },
  });

  const assignmentsByClass = new Map<
    string,
    Array<{
      feeCategoryId: string;
      amount: number;
    }>
  >();

  for (const assignment of feeAssignments) {
    const current = assignmentsByClass.get(assignment.classId) ?? [];
    current.push({
      feeCategoryId: assignment.feeCategoryId,
      amount: assignment.feeCategory.amount,
    });
    assignmentsByClass.set(assignment.classId, current);
  }

  const rows: Array<{
    studentId: string;
    feeCategoryId: string;
    amountPaid: number;
    status: PaymentStatus;
    monthlyFeeSnapshot: number | null;
    feeAmountSnapshot: number | null;
    dedupeKey: string;
    month: number;
    year: number;
    dueDate: Date;
  }> = [];

  for (const student of students) {
    const assignments = assignmentsByClass.get(student.classId) ?? [];
    if (assignments.length === 0) {
      continue;
    }

    const monthlyFeeSetting = student.class.monthlyFeeSetting;
    const monthlyFeeSnapshot =
      monthlyFeeSetting?.isActive === false
        ? null
        : (monthlyFeeSetting?.monthlyFee ?? null);

    for (const assignment of assignments) {
      rows.push({
        studentId: student.id,
        feeCategoryId: assignment.feeCategoryId,
        amountPaid: 0,
        status: PaymentStatus.DUE,
        monthlyFeeSnapshot,
        feeAmountSnapshot: assignment.amount,
        dedupeKey,
        month: payload.month,
        year: payload.year,
        dueDate,
      });
    }
  }

  if (rows.length === 0) {
    return { expected: 0, created: 0, skipped: 0 };
  }

  const result = await client.payment.createMany({
    data: rows,
    skipDuplicates: true,
  });

  return {
    expected: rows.length,
    created: result.count,
    skipped: rows.length - result.count,
  };
}

export async function getDueListReport(
  payload: {
    month: number;
    year: number;
    classId?: string;
    search?: string;
  },
  client: PrismaClientLike = prisma,
) {
  if (payload.month < 1 || payload.month > 12) {
    throw new HttpError("Invalid month", 400);
  }

  if (payload.year < 2000 || payload.year > 2100) {
    throw new HttpError("Invalid year", 400);
  }

  const search = payload.search?.trim();

  const payments = await client.payment.findMany({
    where: {
      month: payload.month,
      year: payload.year,
      feeCategory: { isActive: true },
      student: {
        isDeleted: false,
        user: { isDeleted: false },
        ...(payload.classId ? { classId: payload.classId } : {}),
        ...(search
          ? {
              OR: [
                { user: { name: { contains: search, mode: "insensitive" } } },
                { user: { email: { contains: search, mode: "insensitive" } } },
              ],
            }
          : {}),
      },
    },
    orderBy: [{ createdAt: "desc" }],
    select: {
      id: true,
      amountPaid: true,
      status: true,
      paymentMethod: true,
      transactionId: true,
      month: true,
      year: true,
      dueDate: true,
      createdAt: true,
      monthlyFeeSnapshot: true,
      feeAmountSnapshot: true,
      feeCategory: {
        select: {
          id: true,
          name: true,
          amount: true,
        },
      },
      student: {
        select: {
          id: true,
          user: { select: { name: true } },
          class: {
            select: {
              name: true,
              monthlyFeeSetting: {
                select: { monthlyFee: true, isActive: true },
              },
            },
          },
        },
      },
    },
  });

  const ledger = buildFeeLedger(payments);

  const dues = ledger.history
    .filter((entry) => entry.month === payload.month && entry.year === payload.year)
    .filter((entry) => entry.dueAmount > 0)
    .map((entry) => ({
      studentId: entry.studentId,
      studentName: entry.studentName,
      className: entry.className,
      month: entry.month,
      year: entry.year,
      label: entry.label,
      totalExpected: entry.totalExpected,
      amountPaid: entry.amountPaid,
      dueAmount: entry.dueAmount,
      monthlyFeeBase: entry.monthlyFeeBase,
      extraCategoryFees: entry.extraCategoryFees,
    }))
    .sort((a, b) => b.dueAmount - a.dueAmount || a.studentName.localeCompare(b.studentName));

  return {
    month: payload.month,
    year: payload.year,
    classId: payload.classId ?? null,
    items: dues,
    stats: {
      count: dues.length,
      totalDue: dues.reduce((sum, item) => sum + item.dueAmount, 0),
      totalExpected: dues.reduce((sum, item) => sum + item.totalExpected, 0),
      totalPaid: dues.reduce((sum, item) => sum + item.amountPaid, 0),
    },
  };
}

