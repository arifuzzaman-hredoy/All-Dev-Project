import { WeekDay } from "@prisma/client";
import { listClasses } from "@/repositories/class.repository";
import {
  createTimetable,
  deleteTimetableRecord,
  findTimetableById,
  listTimetables,
  updateTimetableRecord,
} from "@/repositories/timetable.repository";
import { listTeachers } from "@/repositories/teacher.repository";
import { listSubjects } from "@/repositories/subject.repository";
import { HttpError } from "@/utils/error-handler";

export async function listTimetablesForAdmin(filters: {
  classId?: string;
  teacherId?: string;
  day?: WeekDay;
}) {
  const [entries, teachers, classes, subjects] = await Promise.all([
    listTimetables(filters),
    listTeachers({}),
    listClasses(),
    listSubjects({}),
  ]);

  return {
    entries,
    teachers: teachers.map((teacher) => ({
      id: teacher.id,
      name: teacher.user.name,
    })),
    classes,
    subjects: subjects.map((subject) => ({
      id: subject.id,
      name: subject.name,
      classId: subject.class.id,
      className: subject.class.name,
    })),
    stats: {
      total: entries.length,
    },
  };
}

export async function createTimetableForAdmin(payload: {
  classId: string;
  subjectId: string;
  teacherId: string;
  day: WeekDay;
  startTime: string;
  endTime: string;
}) {
  return createTimetable({
    class: { connect: { id: payload.classId } },
    subject: { connect: { id: payload.subjectId } },
    teacher: { connect: { id: payload.teacherId } },
    day: payload.day,
    startTime: payload.startTime,
    endTime: payload.endTime,
  });
}

export async function updateTimetableForAdmin(
  id: string,
  payload: {
    classId?: string;
    subjectId?: string;
    teacherId?: string;
    day?: WeekDay;
    startTime?: string;
    endTime?: string;
  }
) {
  const existing = await findTimetableById(id);
  if (!existing) {
    throw new HttpError("Timetable entry not found", 404);
  }

  return updateTimetableRecord(id, {
    ...(payload.classId ? { class: { connect: { id: payload.classId } } } : {}),
    ...(payload.subjectId
      ? { subject: { connect: { id: payload.subjectId } } }
      : {}),
    ...(payload.teacherId
      ? { teacher: { connect: { id: payload.teacherId } } }
      : {}),
    ...(payload.day ? { day: payload.day } : {}),
    ...(payload.startTime ? { startTime: payload.startTime } : {}),
    ...(payload.endTime ? { endTime: payload.endTime } : {}),
  });
}

export async function deleteTimetableForAdmin(id: string) {
  const existing = await findTimetableById(id);
  if (!existing) {
    throw new HttpError("Timetable entry not found", 404);
  }

  return deleteTimetableRecord(id);
}
