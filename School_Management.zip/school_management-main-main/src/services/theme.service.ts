import type { ThemeColors } from "@/types/api.types"
import { findSystemSettingByKey, upsertSystemSetting } from "@/repositories/systemSetting.repository"
import { recordAuditEvent } from "@/services/audit.service"

const defaultTheme: ThemeColors = {
  background: "#f8fafc",
  foreground: "#0f172a",
  primary: "#6366f1",
  secondary: "#a855f7",
  accent: "#facc15",
  destructive: "#dc2626",
  muted: "#e2e8f0",
  border: "#cbd5f5",
  input: "#e5e7eb",
  ring: "#a855f7",
  card: "#ffffff",
  popover: "#ffffff",
  sidebar: "#ffffff",
  "sidebar-foreground": "#0f172a",
  "sidebar-border": "#e5e7eb",
}
const GLOBAL_THEME_KEY = "theme:global"
const userThemeKey = (userId: string) => `theme:user:${userId}`

export async function fetchGlobalTheme() {
  const setting = await findSystemSettingByKey(GLOBAL_THEME_KEY)
  return (setting?.value as ThemeColors | undefined) ?? defaultTheme
}

export async function updateGlobalTheme(payload: ThemeColors, actorId?: string) {
  const setting = await upsertSystemSetting({
    key: GLOBAL_THEME_KEY,
    value: payload,
    updatedById: actorId ?? null,
  })

  if (actorId) {
    await recordAuditEvent({
      actorId,
      action: "theme.global.updated",
      entityType: "SystemSetting",
      entityId: setting.id,
      metadata: payload,
    })
  }

  return payload
}

export async function fetchUserTheme(userId: string) {
  const [globalTheme, userTheme] = await Promise.all([
    fetchGlobalTheme(),
    findSystemSettingByKey(userThemeKey(userId)),
  ])

  return {
    ...globalTheme,
    ...((userTheme?.value as ThemeColors | undefined) ?? {}),
  }
}

export async function updateUserTheme(
  userId: string,
  payload: Partial<ThemeColors>,
  actorId?: string
) {
  const globalTheme = await fetchGlobalTheme()
  const merged = { ...globalTheme, ...payload }
  const setting = await upsertSystemSetting({
    key: userThemeKey(userId),
    value: payload,
    updatedById: actorId ?? userId,
  })

  await recordAuditEvent({
    actorId: actorId ?? userId,
    action: "theme.user.updated",
    entityType: "SystemSetting",
    entityId: setting.id,
    metadata: {
      userId,
      updates: payload,
    },
  })

  return merged
}
