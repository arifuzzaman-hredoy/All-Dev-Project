import { findExamById, listExams } from "@/repositories/exam.repository";
import {
  createResult,
  deleteResultRecord,
  findResultById,
  listResults,
  updateResultRecord,
} from "@/repositories/result.repository";
import { findStudentById, listStudents } from "@/repositories/student.repository";
import { findSubjectById, listSubjects } from "@/repositories/subject.repository";
import {
  deriveGradeFromMarks,
  resolveTotalMarksFromExamSubjects,
} from "@/lib/result-marks";
import { HttpError } from "@/utils/error-handler";

function withResultTotalMarks(result: Awaited<ReturnType<typeof listResults>>[number]) {
  const totalMarks = resolveTotalMarksFromExamSubjects(
    result.exam.subjects,
    result.student.class.id,
    result.subjectId,
  );

  return {
    ...result,
    exam: {
      id: result.exam.id,
      name: result.exam.name,
      date: result.exam.date,
    },
    totalMarks,
  };
}

function assertMarksWithinTotal(marks: number, totalMarks: number) {
  if (marks > totalMarks) {
    throw new HttpError(`Marks cannot be greater than total marks (${totalMarks})`, 400);
  }
}

export async function listResultsForAdmin(filters: {
  search?: string;
  examId?: string;
  studentId?: string;
  classId?: string;
  subjectId?: string;
}) {
  const [results, students, exams, subjects] = await Promise.all([
    listResults(filters),
    listStudents({}),
    listExams({}),
    listSubjects({}),
  ]);
  const enrichedResults = results.map(withResultTotalMarks);

  return {
    results: enrichedResults,
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      className: student.class.name,
    })),
    exams: exams.map((exam) => ({
      id: exam.id,
      name: exam.name,
      className: exam.class.name,
    })),
    subjects: subjects.map((subject) => ({
      id: subject.id,
      name: subject.name,
      className: subject.class.name,
    })),
    stats: {
      total: results.length,
      averageMarks:
        results.length > 0
          ? Number(
              (
                results.reduce((sum, item) => sum + item.marks, 0) / results.length
              ).toFixed(2)
            )
          : 0,
    },
  };
}

export async function createResultForAdmin(payload: {
  studentId: string;
  examId: string;
  subjectId: string;
  marks: number;
  grade?: string;
}) {
  const [student, exam, subject] = await Promise.all([
    findStudentById(payload.studentId),
    findExamById(payload.examId),
    findSubjectById(payload.subjectId),
  ]);

  if (!student) throw new HttpError("Student not found", 404);
  if (!exam) throw new HttpError("Exam not found", 404);
  if (!subject) throw new HttpError("Subject not found", 404);

  const totalMarks = resolveTotalMarksFromExamSubjects(
    exam.subjects,
    student.classId,
    payload.subjectId,
  );
  assertMarksWithinTotal(payload.marks, totalMarks);

  return createResult({
    marks: payload.marks,
    grade: payload.grade?.trim() || deriveGradeFromMarks(payload.marks, totalMarks),
    student: {
      connect: { id: payload.studentId },
    },
    exam: {
      connect: { id: payload.examId },
    },
    subject: {
      connect: { id: payload.subjectId },
    },
  });
}

export async function updateResultForAdmin(
  id: string,
  payload: { marks?: number; grade?: string | null }
) {
  const existing = await findResultById(id);
  if (!existing) {
    throw new HttpError("Result not found", 404);
  }

  const nextMarks = payload.marks ?? existing.marks;
  const totalMarks = resolveTotalMarksFromExamSubjects(
    existing.exam.subjects,
    existing.student.class.id,
    existing.subjectId,
  );
  assertMarksWithinTotal(nextMarks, totalMarks);

  return updateResultRecord(id, {
    ...(payload.marks !== undefined ? { marks: payload.marks } : {}),
    ...(payload.grade !== undefined
      ? { grade: payload.grade?.trim() || deriveGradeFromMarks(nextMarks, totalMarks) }
      : {}),
  });
}

export async function deleteResultForAdmin(id: string) {
  const existing = await findResultById(id);
  if (!existing) {
    throw new HttpError("Result not found", 404);
  }

  return deleteResultRecord(id);
}
