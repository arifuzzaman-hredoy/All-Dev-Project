import type { Prisma } from "@prisma/client";
import {
  findSystemSettingByKey,
  upsertSystemSetting,
} from "@/repositories/systemSetting.repository";
import { noticeTemplateSchema } from "@/validations/notice-template.schema";

export const NOTICE_TEMPLATE_KEY = "notice_template";

export type NoticeTemplate = {
  header: string;
  footer: string;
  signature: string;
};

export async function getNoticeTemplateForAdmin() {
  const setting = await findSystemSettingByKey(NOTICE_TEMPLATE_KEY);
  const parsed = noticeTemplateSchema.safeParse(setting?.value ?? {});
  const template = parsed.success ? parsed.data : noticeTemplateSchema.parse({});
  return { template };
}

export async function updateNoticeTemplateForAdmin(payload: {
  template: NoticeTemplate;
  actorId: string;
}) {
  const template = noticeTemplateSchema.parse(payload.template);
  const value: Prisma.InputJsonValue = template;
  const setting = await upsertSystemSetting({
    key: NOTICE_TEMPLATE_KEY,
    value,
    updatedById: payload.actorId,
  });
  return { setting, template };
}

