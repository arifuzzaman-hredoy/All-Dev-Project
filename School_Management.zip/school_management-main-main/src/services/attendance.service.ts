import { listClasses } from "@/repositories/class.repository";
import { listAttendance, upsertAttendance } from "@/repositories/attendance.repository";
import { listStudents } from "@/repositories/student.repository";
import { listSubjects } from "@/repositories/subject.repository";
import { prisma } from "@/lib/prisma";
import { buildAttendanceSummary } from "@/lib/attendance-summary";
import { HttpError } from "@/utils/error-handler";

export async function listAttendanceForAdmin(filters: {
  classId?: string;
  studentId?: string;
  subjectId?: string;
  status?: "PRESENT" | "ABSENT" | "LATE";
  date?: string;
  search?: string;
}) {
  const date = filters.date ? new Date(filters.date) : undefined;

  const [records, classes, students, subjects] = await Promise.all([
    listAttendance({
      ...filters,
      date,
    }),
    listClasses(),
    listStudents({}),
    listSubjects({}),
  ]);

  return {
    records,
    classes,
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      classId: student.classId,
      className: student.class.name,
    })),
    subjects: subjects.map((subject) => ({
      id: subject.id,
      name: subject.name,
      classId: subject.classId,
      className: subject.class.name,
    })),
    stats: buildAttendanceSummary(records),
  };
}

export async function upsertAttendanceBatch(payload: {
  date: string;
  subjectId: string;
  classId: string;
  period?: number;
  markedBy?: string | null;
  entries: Array<{
    studentId: string;
    status: "PRESENT" | "ABSENT" | "LATE";
    remarks?: string;
  }>;
}) {
  const date = new Date(payload.date);
  const studentIds = Array.from(
    new Set(payload.entries.map((entry) => entry.studentId)),
  );

  if (studentIds.length !== payload.entries.length) {
    throw new HttpError("Duplicate student attendance entries are not allowed", 400);
  }

  const [classRecord, subject, students] = await Promise.all([
    prisma.class.findUnique({
      where: { id: payload.classId },
      select: { id: true },
    }),
    prisma.subject.findUnique({
      where: { id: payload.subjectId },
      select: { id: true, classId: true },
    }),
    prisma.student.findMany({
      where: {
        id: { in: studentIds },
        classId: payload.classId,
        isDeleted: false,
      },
      select: { id: true },
    }),
  ]);

  if (!classRecord) {
    throw new HttpError("Selected class was not found", 404);
  }

  if (!subject || subject.classId !== payload.classId) {
    throw new HttpError("Selected subject does not belong to the selected class", 400);
  }

  if (students.length !== studentIds.length) {
    throw new HttpError(
      "One or more students do not belong to the selected class",
      400,
    );
  }

  const records = await Promise.all(
    payload.entries.map((entry) =>
      upsertAttendance({
        studentId: entry.studentId,
        subjectId: payload.subjectId,
        classId: payload.classId,
        date,
        period: payload.period ?? 1,
        status: entry.status,
        markedBy: payload.markedBy ?? null,
        remarks: entry.remarks?.trim() || null,
      })
    )
  );

  return {
    records,
    summary: buildAttendanceSummary(records),
  };
}
