import { Role } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { HttpError } from "@/utils/error-handler";

export const TRASH_ENTITY_TYPES = [
  "User",
  "Student",
  "Teacher",
  "Guardian",
] as const;

export type TrashEntityType = (typeof TRASH_ENTITY_TYPES)[number];

export type TrashItem = {
  entityType: TrashEntityType;
  entityId: string;
  label: string;
  secondary?: string | null;
  deletedAt: Date | null;
  deletedBy: { id: string; name: string; email: string } | null;
};

const TRASH_ACTIONS: Record<TrashEntityType, string> = {
  User: "admin.user.deactivated",
  Student: "admin.student.deactivated",
  Teacher: "admin.teacher.deactivated",
  Guardian: "admin.guardian.deactivated",
};

function assertTrashPermission(actorRole: Role) {
  if (actorRole !== Role.SUPER_ADMIN) {
    throw new HttpError("Insufficient permissions", 403);
  }
}

async function loadDeletionEvents(
  entityType: TrashEntityType,
  entityIds: string[],
  client: PrismaClientLike = prisma,
) {
  if (entityIds.length === 0) {
    return new Map<
      string,
      { deletedAt: Date; deletedBy: TrashItem["deletedBy"] }
    >();
  }

  const logs = await client.auditLog.findMany({
    where: {
      action: TRASH_ACTIONS[entityType],
      entityType,
      entityId: { in: entityIds },
    },
    orderBy: { createdAt: "desc" },
    take: entityIds.length * 2,
    select: {
      entityId: true,
      createdAt: true,
      actor: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });

  const byEntityId = new Map<
    string,
    { deletedAt: Date; deletedBy: TrashItem["deletedBy"] }
  >();

  for (const log of logs) {
    if (!log.entityId || byEntityId.has(log.entityId)) {
      continue;
    }

    byEntityId.set(log.entityId, {
      deletedAt: log.createdAt,
      deletedBy: log.actor
        ? { id: log.actor.id, name: log.actor.name, email: log.actor.email }
        : null,
    });
  }

  return byEntityId;
}

function normalizeSearch(search?: string) {
  const trimmed = search?.trim();
  return trimmed ? trimmed : undefined;
}

export async function listTrashItems(
  actorRole: Role,
  options: {
    search?: string;
    entityType?: TrashEntityType;
    limit?: number;
    page?: number;
  } = {},
  client: PrismaClientLike = prisma,
) {
  assertTrashPermission(actorRole);

  const search = normalizeSearch(options.search);
  const requestedTypes = options.entityType
    ? [options.entityType]
    : [...TRASH_ENTITY_TYPES];

  const take = Math.min(options.limit ?? 50, 200);
  const skip = options.page ? (Math.max(options.page, 1) - 1) * take : 0;

  const items: TrashItem[] = [];

  for (const entityType of requestedTypes) {
    if (entityType === "User") {
      const users = await client.user.findMany({
        where: {
          isDeleted: true,
          ...(search
            ? {
                OR: [
                  { name: { contains: search, mode: "insensitive" } },
                  { email: { contains: search, mode: "insensitive" } },
                ],
              }
            : {}),
        },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
        },
        orderBy: { updatedAt: "desc" },
        take,
        skip,
      });

      const deletionEvents = await loadDeletionEvents(
        "User",
        users.map((u) => u.id),
        client,
      );

      items.push(
        ...users.map((user) => {
          const deletion = deletionEvents.get(user.id) ?? null;
          return {
            entityType: "User" as const,
            entityId: user.id,
            label: user.name,
            secondary: user.email,
            deletedAt: deletion?.deletedAt ?? null,
            deletedBy: deletion?.deletedBy ?? null,
          };
        }),
      );
    }

    if (entityType === "Student") {
      const students = await client.student.findMany({
        where: {
          OR: [{ isDeleted: true }, { user: { isDeleted: true } }],
          ...(search
            ? {
                OR: [
                  { user: { name: { contains: search, mode: "insensitive" } } },
                  {
                    user: { email: { contains: search, mode: "insensitive" } },
                  },
                  { phone: { contains: search } },
                  { class: { name: { contains: search, mode: "insensitive" } } },
                ],
              }
            : {}),
        },
        select: {
          id: true,
          rollNumber: true,
          user: { select: { name: true, email: true } },
          class: { select: { name: true } },
        },
        orderBy: { createdAt: "desc" },
        take,
        skip,
      });

      const deletionEvents = await loadDeletionEvents(
        "Student",
        students.map((s) => s.id),
        client,
      );

      items.push(
        ...students.map((student) => {
          const deletion = deletionEvents.get(student.id) ?? null;
          const roll = student.rollNumber ? `Roll ${student.rollNumber}` : null;
          return {
            entityType: "Student" as const,
            entityId: student.id,
            label: student.user.name,
            secondary: [student.class.name, roll].filter(Boolean).join(" · "),
            deletedAt: deletion?.deletedAt ?? null,
            deletedBy: deletion?.deletedBy ?? null,
          };
        }),
      );
    }

    if (entityType === "Teacher") {
      const teachers = await client.teacher.findMany({
        where: {
          OR: [{ isDeleted: true }, { user: { isDeleted: true } }],
          ...(search
            ? {
                OR: [
                  { user: { name: { contains: search, mode: "insensitive" } } },
                  {
                    user: { email: { contains: search, mode: "insensitive" } },
                  },
                  { phone: { contains: search } },
                ],
              }
            : {}),
        },
        select: {
          id: true,
          phone: true,
          user: { select: { name: true, email: true } },
        },
        orderBy: { createdAt: "desc" },
        take,
        skip,
      });

      const deletionEvents = await loadDeletionEvents(
        "Teacher",
        teachers.map((t) => t.id),
        client,
      );

      items.push(
        ...teachers.map((teacher) => {
          const deletion = deletionEvents.get(teacher.id) ?? null;
          return {
            entityType: "Teacher" as const,
            entityId: teacher.id,
            label: teacher.user.name,
            secondary: teacher.user.email,
            deletedAt: deletion?.deletedAt ?? null,
            deletedBy: deletion?.deletedBy ?? null,
          };
        }),
      );
    }

    if (entityType === "Guardian") {
      const guardians = await client.guardian.findMany({
        where: {
          OR: [{ isDeleted: true }, { user: { isDeleted: true } }],
          ...(search
            ? {
                OR: [
                  { name: { contains: search, mode: "insensitive" } },
                  { email: { contains: search, mode: "insensitive" } },
                  { phone: { contains: search } },
                  { user: { name: { contains: search, mode: "insensitive" } } },
                  {
                    user: { email: { contains: search, mode: "insensitive" } },
                  },
                ],
              }
            : {}),
        },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          user: { select: { name: true, email: true } },
        },
        orderBy: { updatedAt: "desc" },
        take,
        skip,
      });

      const deletionEvents = await loadDeletionEvents(
        "Guardian",
        guardians.map((g) => g.id),
        client,
      );

      items.push(
        ...guardians.map((guardian) => {
          const deletion = deletionEvents.get(guardian.id) ?? null;
          return {
            entityType: "Guardian" as const,
            entityId: guardian.id,
            label: guardian.user?.name ?? guardian.name,
            secondary: guardian.user?.email ?? guardian.email ?? null,
            deletedAt: deletion?.deletedAt ?? null,
            deletedBy: deletion?.deletedBy ?? null,
          };
        }),
      );
    }
  }

  items.sort((a, b) => {
    const aTime = a.deletedAt?.getTime() ?? 0;
    const bTime = b.deletedAt?.getTime() ?? 0;
    return bTime - aTime;
  });

  return { items };
}

async function runInTransaction<T>(
  client: PrismaClientLike,
  fn: (tx: PrismaClientLike) => Promise<T>,
) {
  const maybeTransaction = (client as unknown as { $transaction?: unknown })
    .$transaction;

  if (typeof maybeTransaction === "function") {
    return (client as unknown as { $transaction: typeof prisma.$transaction })
      .$transaction(fn as never);
  }

  return fn(client);
}

export async function restoreTrashItem(
  actorRole: Role,
  payload: { entityType: TrashEntityType; entityId: string },
  client: PrismaClientLike = prisma,
) {
  assertTrashPermission(actorRole);

  const { entityType, entityId } = payload;

  if (entityType === "User") {
    const existing = await client.user.findUnique({
      where: { id: entityId },
      select: { id: true, isDeleted: true },
    });
    if (!existing) {
      throw new HttpError("User not found", 404);
    }

    if (!existing.isDeleted) {
      return { entityType, entityId };
    }

    await client.user.update({
      where: { id: entityId },
      data: { isDeleted: false },
    });
    return { entityType, entityId };
  }

  if (entityType === "Student") {
    return runInTransaction(client, async (tx) => {
      const student = await tx.student.findUnique({
        where: { id: entityId },
        select: { id: true, userId: true },
      });
      if (!student) {
        throw new HttpError("Student not found", 404);
      }

      await tx.user.update({
        where: { id: student.userId },
        data: { isDeleted: false },
      });

      await tx.student.update({
        where: { id: student.id },
        data: { isDeleted: false },
      });

      return { entityType, entityId };
    });
  }

  if (entityType === "Teacher") {
    return runInTransaction(client, async (tx) => {
      const teacher = await tx.teacher.findUnique({
        where: { id: entityId },
        select: { id: true, userId: true },
      });
      if (!teacher) {
        throw new HttpError("Teacher not found", 404);
      }

      await tx.user.update({
        where: { id: teacher.userId },
        data: { isDeleted: false },
      });

      await tx.teacher.update({
        where: { id: teacher.id },
        data: { isDeleted: false },
      });

      return { entityType, entityId };
    });
  }

  if (entityType === "Guardian") {
    return runInTransaction(client, async (tx) => {
      const guardian = await tx.guardian.findUnique({
        where: { id: entityId },
        select: { id: true, userId: true },
      });
      if (!guardian || !guardian.userId) {
        throw new HttpError("Guardian not found", 404);
      }

      await tx.user.update({
        where: { id: guardian.userId },
        data: { isDeleted: false },
      });

      await tx.guardian.update({
        where: { id: guardian.id },
        data: { isDeleted: false },
      });

      return { entityType, entityId };
    });
  }

  throw new HttpError("Unsupported entity type", 400);
}
