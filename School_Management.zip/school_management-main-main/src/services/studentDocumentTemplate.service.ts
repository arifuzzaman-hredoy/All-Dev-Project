import type { Prisma } from "@prisma/client";
import {
  DEFAULT_STUDENT_DOCUMENT_TEMPLATE,
  STUDENT_DOCUMENT_TEMPLATE_KEY,
  normalizeStudentDocumentTemplate,
  type StudentDocumentTemplateConfig,
} from "@/lib/student-document-template";
import {
  findSystemSettingByKey,
  upsertSystemSetting,
} from "@/repositories/systemSetting.repository";
import { recordAuditEvent } from "@/services/audit.service";

export async function fetchStudentDocumentTemplate() {
  const setting = await findSystemSettingByKey(STUDENT_DOCUMENT_TEMPLATE_KEY);

  if (!setting) {
    const created = await upsertSystemSetting({
      key: STUDENT_DOCUMENT_TEMPLATE_KEY,
      value: DEFAULT_STUDENT_DOCUMENT_TEMPLATE,
    });

    return normalizeStudentDocumentTemplate(created.value);
  }

  return normalizeStudentDocumentTemplate(setting.value);
}

export async function updateStudentDocumentTemplateForAdmin(payload: {
  template: StudentDocumentTemplateConfig;
  actorId: string;
}) {
  const setting = await upsertSystemSetting({
    key: STUDENT_DOCUMENT_TEMPLATE_KEY,
    value: payload.template as Prisma.InputJsonValue,
    updatedById: payload.actorId,
  });

  await recordAuditEvent({
    actorId: payload.actorId,
    action: "student_document_template.updated",
    entityType: "SystemSetting",
    entityId: setting.id,
    metadata: payload.template,
  });

  return normalizeStudentDocumentTemplate(setting.value);
}
