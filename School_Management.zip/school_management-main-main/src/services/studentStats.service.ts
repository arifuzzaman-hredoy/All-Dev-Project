import { Gender } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

type GenderCounts = Record<Gender, number>;

function emptyCounts(): GenderCounts {
  return {
    [Gender.MALE]: 0,
    [Gender.FEMALE]: 0,
    [Gender.OTHER]: 0,
  };
}

function applyGroupCounts(
  counts: GenderCounts,
  rows: Array<{ gender: Gender; _count: { _all: number } }>,
) {
  const next = { ...counts };
  for (const row of rows) {
    next[row.gender] = row._count._all;
  }
  return next;
}

export async function getStudentGenderCounts(
  filters: { classId?: string } = {},
  client: PrismaClientLike = prisma,
) {
  const baseWhere = {
    isDeleted: false,
    user: { isDeleted: false },
    ...(filters.classId ? { classId: filters.classId } : {}),
  } as const;

  const totalsRows = await client.student.groupBy({
    by: ["gender"],
    where: baseWhere,
    _count: { _all: true },
  });

  const totals = applyGroupCounts(emptyCounts(), totalsRows);

  if (filters.classId) {
    return {
      classId: filters.classId,
      totals,
      totalStudents: Object.values(totals).reduce((sum, value) => sum + value, 0),
      byClass: [],
    };
  }

  const byClassRows = await client.student.groupBy({
    by: ["classId", "gender"],
    where: baseWhere,
    _count: { _all: true },
  });

  const classIds = Array.from(new Set(byClassRows.map((row) => row.classId)));
  const classes = await client.class.findMany({
    where: { id: { in: classIds } },
    select: { id: true, name: true },
  });
  const classNameById = new Map(classes.map((row) => [row.id, row.name]));

  const countsByClassId = new Map<string, GenderCounts>();
  for (const row of byClassRows) {
    const current = countsByClassId.get(row.classId) ?? emptyCounts();
    current[row.gender] = row._count._all;
    countsByClassId.set(row.classId, current);
  }

  const byClass = Array.from(countsByClassId.entries())
    .map(([classId, counts]) => ({
      classId,
      className: classNameById.get(classId) ?? "Unknown",
      totals: counts,
      totalStudents: Object.values(counts).reduce((sum, value) => sum + value, 0),
    }))
    .sort((a, b) => a.className.localeCompare(b.className));

  return {
    classId: null,
    totals,
    totalStudents: Object.values(totals).reduce((sum, value) => sum + value, 0),
    byClass,
  };
}

