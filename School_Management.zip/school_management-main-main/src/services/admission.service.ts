import { randomBytes } from "node:crypto";
import { AdmissionStatus, Gender, Role, type Prisma } from "@prisma/client";
import { hashPassword } from "@/lib/auth";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import {
  createAdmission,
  findAdmissionByEmail,
  findAdmissionById,
  listAdmissions,
  updateAdmissionRecord,
} from "@/repositories/admission.repository";
import {
  ensureDefaultGroup,
  ensureDefaultSection,
  findClassByName,
} from "@/repositories/class.repository";
import { createStudent } from "@/repositories/student.repository";
import {
  createGuardian,
  findGuardianByContact,
  findGuardianByUserId,
  updateGuardianRecord,
} from "@/repositories/guardian.repository";
import { createUser, findUserByEmail } from "@/repositories/user.repository";
import { syncFeeCategoryAssignmentsForStudent } from "@/services/feeCategory.service";
import { sendAppEmail } from "@/utils/email";
import { HttpError } from "@/utils/error-handler";
import type { AdmissionDetailsInput } from "@/validations/admission.schema";

export type AdmissionReviewStatus = "PENDING" | "APPROVED" | "REJECTED";

export type AdmissionListFilters = {
  search?: string;
  status?: AdmissionReviewStatus;
};

type CurrentSessionLookup = {
  academicSession?: {
    findFirst?: (args: {
      where: { isCurrent: boolean; isActive: boolean };
      select: { id: boolean };
    }) => Promise<{ id: string } | null>;
  };
};

export type CreateAdmissionInput = {
  branchId: string;
  classId: string;
  name: string;
  email: string;
  phone?: string;
  className: string;
  message?: string;
  gender?: "MALE" | "FEMALE" | "OTHER";
  fatherName?: string;
  fatherPhone?: string;
  motherName?: string;
  motherPhone?: string;
  guardianName?: string;
  guardianEmail?: string;
  guardianRelation?: string;
  guardianPhone?: string;
  guardianAddress?: string;
  nidNumber?: string;
  nidImage?: string;
  profileImage?: string;
  fatherNidNumber?: string;
  fatherNidImage?: string;
  motherNidNumber?: string;
  motherNidImage?: string;
};

export type UpdateAdmissionInput = {
  name?: string;
  email?: string;
  phone?: string | null;
  className?: string;
  message?: string | null;
  details?: AdmissionDetailsInput | null;
  status: AdmissionReviewStatus;
  convertedToStudentId?: string | null;
};

function toDatabaseAdmissionStatus(
  status: AdmissionReviewStatus,
): AdmissionStatus {
  return status === "APPROVED" ? "ACCEPTED" : status;
}

function toReviewAdmissionStatus(
  status: AdmissionStatus,
): AdmissionReviewStatus {
  return status === "ACCEPTED" ? "APPROVED" : (status as AdmissionReviewStatus);
}

function generateSecurePassword() {
  return randomBytes(9).toString("base64url");
}

function getLoginUrl() {
  return (
    process.env.APP_URL ??
    process.env.NEXT_PUBLIC_APP_URL ??
    "http://localhost:3000"
  );
}

function getAdmissionDuplicateMessage() {
  return "Student email is already in use.";
}

function buildStudentCredentialsEmail(params: {
  name: string;
  email: string;
  password: string;
}) {
  const loginUrl = `${getLoginUrl().replace(/\/$/, "")}/login`;

  return {
    subject: "Your student account is ready",
    html: `<p>Hi ${params.name},</p>
      <p>Your admission application has been approved and your student account has been created.</p>
      <p><strong>Login URL:</strong> <a href="${loginUrl}">${loginUrl}</a><br />
      <strong>Email:</strong> ${params.email}<br />
      <strong>Password:</strong> ${params.password}</p>
      <p>You can now sign in and change your password after your first login.</p>
      <p>Regards,<br/>School Administration</p>`,
    text: `Hi ${params.name},\n\nYour admission application has been approved and your student account has been created.\n\nLogin URL: ${loginUrl}\nEmail: ${params.email}\nPassword: ${params.password}\n\nYou can now sign in and change your password after your first login.\n\nRegards,\nSchool Administration`,
  };
}

function buildGuardianCredentialsEmail(params: {
  name: string;
  email: string;
  password: string;
}) {
  const loginUrl = `${getLoginUrl().replace(/\/$/, "")}/login`;

  return {
    subject: "Your guardian account is ready",
    html: `<p>Hi ${params.name},</p>
      <p>A guardian account has been created for the approved admission application.</p>
      <p><strong>Login URL:</strong> <a href="${loginUrl}">${loginUrl}</a><br />
      <strong>Email:</strong> ${params.email}<br />
      <strong>Password:</strong> ${params.password}</p>
      <p>Please sign in and change your password after your first login.</p>
      <p>Regards,<br/>School Administration</p>`,
    text: `Hi ${params.name},\n\nA guardian account has been created for the approved admission application.\n\nLogin URL: ${loginUrl}\nEmail: ${params.email}\nPassword: ${params.password}\n\nPlease sign in and change your password after your first login.\n\nRegards,\nSchool Administration`,
  };
}

function buildExistingGuardianLinkedEmail(params: {
  name: string;
  email: string;
}) {
  const loginUrl = `${getLoginUrl().replace(/\/$/, "")}/login`;

  return {
    subject: "Your guardian account has been linked",
    html: `<p>Hi ${params.name},</p>
      <p>Your existing guardian account has been linked to the approved admission application.</p>
      <p><strong>Login URL:</strong> <a href="${loginUrl}">${loginUrl}</a><br />
      <strong>Email:</strong> ${params.email}</p>
      <p>Please continue using your existing password to sign in.</p>
      <p>Regards,<br/>School Administration</p>`,
    text: `Hi ${params.name},\n\nYour existing guardian account has been linked to the approved admission application.\n\nLogin URL: ${loginUrl}\nEmail: ${params.email}\n\nPlease continue using your existing password to sign in.\n\nRegards,\nSchool Administration`,
  };
}

async function resolveGuardianAccount(
  guardianInput: {
    name: string;
    email: string;
    phone: string;
    address: string | null;
    relation: string | null;
  },
  client: PrismaClientLike = prisma,
) {
  const normalizedGuardianEmail = guardianInput.email.trim().toLowerCase();
  const normalizedGuardianPhone = guardianInput.phone.trim();

  const existingUser = await findUserByEmail(normalizedGuardianEmail, client);
  if (existingUser && existingUser.role !== Role.PARENT) {
    throw new HttpError(
      "Guardian email is already used by another user account.",
      409,
    );
  }

  const guardianByEmailUser = existingUser
    ? await findGuardianByUserId(existingUser.id, client)
    : null;
  const guardianByContact = await findGuardianByContact(
    {
      email: normalizedGuardianEmail,
      phone: normalizedGuardianPhone,
    },
    client,
  );

  if (
    guardianByEmailUser &&
    guardianByContact &&
    guardianByEmailUser.id !== guardianByContact.id
  ) {
    throw new HttpError(
      "Guardian email and phone match different guardian accounts.",
      409,
    );
  }

  const existingGuardian = guardianByEmailUser ?? guardianByContact;

  if (
    existingGuardian?.user &&
    existingGuardian.user.email.toLowerCase() !== normalizedGuardianEmail
  ) {
    throw new HttpError(
      "Guardian account email does not match the provided guardian email.",
      409,
    );
  }

  if (existingGuardian?.userId && existingGuardian.user) {
    return {
      guardian: existingGuardian,
      password: null,
      isNew: false,
    };
  }

  const plainPassword = existingUser ? null : generateSecurePassword();
  const user =
    existingUser ??
    (await createUser(
      {
        name: guardianInput.name,
        email: normalizedGuardianEmail,
        password: await hashPassword(plainPassword!),
        role: Role.PARENT,
      },
      client,
    ));

  const guardian = existingGuardian
    ? await updateGuardianRecord(
        existingGuardian.id,
        {
          user: {
            connect: { id: user.id },
          },
          name: guardianInput.name,
          email: normalizedGuardianEmail,
          phone: normalizedGuardianPhone,
          address: guardianInput.address,
          relation: guardianInput.relation,
        },
        client,
      )
    : await createGuardian(
        {
          user: {
            connect: { id: user.id },
          },
          name: guardianInput.name,
          email: normalizedGuardianEmail,
          phone: normalizedGuardianPhone,
          address: guardianInput.address,
          relation: guardianInput.relation,
        },
        client,
      );

  return {
    guardian,
    password: plainPassword,
    isNew: !existingUser,
  };
}

async function createStudentAccountForApprovedAdmission(
  admission: {
    name: string;
    email: string;
    phone: string | null;
    className: string;
    details: AdmissionDetailsInput | null;
  },
  client: PrismaClientLike = prisma,
) {
  const normalizedEmail = admission.email.trim().toLowerCase();
  const existingUser = await findUserByEmail(normalizedEmail, client);

  if (existingUser) {
    throw new HttpError(getAdmissionDuplicateMessage(), 409);
  }

  const resolvedClass = await findClassByName(admission.className, client);

  if (!resolvedClass) {
    throw new HttpError(
      "Unable to resolve class for the approved admission",
      400,
    );
  }

  const details = admission.details;
  const plainPassword = generateSecurePassword();
  const hashedPassword = await hashPassword(plainPassword);

  const user = await createUser(
    {
      name: admission.name,
      email: normalizedEmail,
      password: hashedPassword,
      role: Role.STUDENT,
    },
    client,
  );

  const group = await ensureDefaultGroup(resolvedClass.id, client);
  const section = await ensureDefaultSection(group.id, client);

  const guardianInput =
    details?.guardianName?.trim() &&
    details?.guardianEmail?.trim() &&
    details?.guardianPhone?.trim()
      ? {
          name: details.guardianName.trim(),
          email: details.guardianEmail.trim().toLowerCase(),
          phone: details.guardianPhone.trim(),
          address: details.guardianAddress?.trim() || null,
          relation: details.guardianRelation?.trim() || null,
        }
      : null;

  if (!guardianInput) {
    throw new HttpError(
      "Guardian name, email, and phone are required to create the student account",
      400,
    );
  }

  const guardianAccount = await resolveGuardianAccount(
    {
      name: guardianInput.name,
      email: guardianInput.email,
      phone: guardianInput.phone,
      address: guardianInput.address,
      relation: guardianInput.relation,
    },
    client,
  );

  const guardian = guardianAccount.guardian;

  const currentSession =
    await (client as unknown as CurrentSessionLookup).academicSession?.findFirst?.({
      where: { isCurrent: true, isActive: true },
      select: { id: true },
    }) ?? null;

  const student = await createStudent(
    {
      user: {
        connect: { id: user.id },
      },
      gender: details?.gender ?? Gender.OTHER,
      phone: admission.phone,
      details: details ?? undefined,
      fatherName: details?.fatherName?.trim() || null,
      fatherPhone: details?.fatherPhone?.trim() || null,
      motherName: details?.motherName?.trim() || null,
      motherPhone: details?.motherPhone?.trim() || null,
      ...(currentSession?.id
        ? { session: { connect: { id: currentSession.id } } }
        : {}),
      class: {
        connect: { id: resolvedClass.id },
      },
      group: {
        connect: { id: group.id },
      },
      section: {
        connect: { id: section.id },
      },
      guardian: { connect: { id: guardian.id } },
    },
    client,
  );

  await syncFeeCategoryAssignmentsForStudent(
    student.id,
    resolvedClass.id,
    client,
  );

  return {
    user,
    student,
    studentPassword: plainPassword,
    guardianAccount: {
      email: guardian.user?.email ?? guardian.email ?? guardianInput.email,
      name: guardian.user?.name ?? guardian.name,
      password: guardianAccount.password,
      isNew: guardianAccount.isNew,
    },
  };
}

function mergeAdmissionDetails(
  existingDetails: unknown,
  nextDetails?: AdmissionDetailsInput | null,
) {
  if (nextDetails === undefined) {
    return existingDetails ?? undefined;
  }

  const currentDetails =
    existingDetails &&
    typeof existingDetails === "object" &&
    !Array.isArray(existingDetails)
      ? (existingDetails as AdmissionDetailsInput)
      : {};

  return {
    ...currentDetails,
    ...nextDetails,
  };
}

async function sendAdmissionStatusEmail(params: {
  status: AdmissionReviewStatus;
  name: string;
  email: string;
  className: string;
}) {
  if (params.status === "APPROVED") {
    const subject = "Admission application approved";
    const html = `<p>Hi ${params.name},</p>
      <p>Your admission application for <strong>${params.className}</strong> has been approved.</p>
      <p>You can now sign in using the student credentials already shared with you.</p>
      <p>Regards,<br/>School Administration</p>`;
    const text = `Hi ${params.name},\n\nYour admission application for ${params.className} has been approved.\n\nYou can now sign in using the student credentials already shared with you.\n\nRegards,\nSchool Administration`;

    await sendAppEmail({
      to: params.email,
      subject,
      html,
      text,
      name: params.name,
    });
    return;
  }

  if (params.status === "REJECTED") {
    const subject = "Admission application update";
    const html = `<p>Hi ${params.name},</p>
      <p>Your admission application for <strong>${params.className}</strong> was not approved at this time.</p>
      <p>If you need more information, please contact the school office.</p>
      <p>Regards,<br/>School Administration</p>`;
    const text = `Hi ${params.name},\n\nYour admission application for ${params.className} was not approved at this time. Please contact the school office if you need more information.\n\nRegards,\nSchool Administration`;

    await sendAppEmail({
      to: params.email,
      subject,
      html,
      text,
      name: params.name,
    });
  }
}

export async function submitAdmissionApplication(
  payload: CreateAdmissionInput,
) {
  const normalizedEmail = payload.email.trim().toLowerCase();

  const admission = await prisma.$transaction(async (tx) => {
    const selectedClass = await tx.class.findFirst({
      where: {
        id: payload.classId,
        branchId: payload.branchId,
      },
      select: {
        id: true,
        name: true,
      },
    });
    if (!selectedClass) {
      throw new HttpError("Selected class is not available for this branch", 400);
    }

    const existingAdmission = await findAdmissionByEmail(normalizedEmail, tx);

    if (existingAdmission && existingAdmission.status !== "REJECTED") {
      throw new HttpError(
        "An admission application already exists for this email.",
        409,
      );
    }

    const createdAdmission = await createAdmission(
      {
        name: payload.name.trim(),
        email: normalizedEmail,
        phone: payload.phone?.trim() || null,
        className: selectedClass.name,
        message: payload.message?.trim() || null,
        branchId: payload.branchId,
        details: {
          gender: payload.gender ?? null,
          fatherName: payload.fatherName?.trim() || null,
          fatherPhone: payload.fatherPhone?.trim() || null,
          motherName: payload.motherName?.trim() || null,
          motherPhone: payload.motherPhone?.trim() || null,
          guardianName: payload.guardianName?.trim() || null,
          guardianEmail: payload.guardianEmail?.trim().toLowerCase() || null,
          guardianRelation: payload.guardianRelation?.trim() || null,
          guardianPhone: payload.guardianPhone?.trim() || null,
          guardianAddress: payload.guardianAddress?.trim() || null,
          nidNumber: payload.nidNumber?.trim() || null,
          nidImage: payload.nidImage?.trim() || null,
          profileImage: payload.profileImage?.trim() || null,
          fatherNidNumber: payload.fatherNidNumber?.trim() || null,
          fatherNidImage: payload.fatherNidImage?.trim() || null,
          motherNidNumber: payload.motherNidNumber?.trim() || null,
          motherNidImage: payload.motherNidImage?.trim() || null,
        },
      },
      tx,
    );

    return createdAdmission;
  });

  return admission;
}

export async function listAdmissionsForAdmin(filters: AdmissionListFilters) {
  const admissions = await listAdmissions({
    search: filters.search,
    status: filters.status
      ? toDatabaseAdmissionStatus(filters.status)
      : undefined,
  });

  const mappedAdmissions = admissions.map((admission) => ({
    ...admission,
    status: toReviewAdmissionStatus(admission.status),
  }));

  return {
    admissions: mappedAdmissions,
    stats: {
      total: mappedAdmissions.length,
      pending: mappedAdmissions.filter((item) => item.status === "PENDING")
        .length,
      approved: mappedAdmissions.filter((item) => item.status === "APPROVED")
        .length,
      rejected: mappedAdmissions.filter((item) => item.status === "REJECTED")
        .length,
    },
  };
}

export async function updateAdmissionForAdmin(
  admissionId: string,
  payload: UpdateAdmissionInput,
) {
  const existing = await findAdmissionById(admissionId);

  if (!existing) {
    throw new HttpError("Admission application not found", 404);
  }

  const nextStatus = toDatabaseAdmissionStatus(payload.status);
  let shouldSendApprovalEmail = false;
  const nextName = payload.name?.trim() || existing.name;
  const nextEmail = payload.email?.trim().toLowerCase() || existing.email;
  const nextPhone =
    payload.phone !== undefined
      ? payload.phone?.trim() || null
      : existing.phone;
  const nextClassName = payload.className?.trim() || existing.className;
  const nextMessage =
    payload.message !== undefined
      ? payload.message?.trim() || null
      : existing.message;
  const nextDetails = mergeAdmissionDetails(existing.details, payload.details);
  let studentEmailRecipient: string | null = null;
  let studentEmailName: string | null = null;
  let studentEmailPassword: string | null = null;
  let guardianEmailRecipient: string | null = null;
  let guardianEmailName: string | null = null;
  let guardianEmailPassword: string | null = null;
  let guardianIsNew = false;

  const normalizedEmail = nextEmail;

  const otherAdmission = await findAdmissionByEmail(normalizedEmail);

  if (otherAdmission && otherAdmission.id !== existing.id) {
    throw new HttpError(
      "An admission application already exists for this email.",
      409,
    );
  }

  const updated = await prisma.$transaction(async (tx) => {
    let convertedToStudentId =
      payload.convertedToStudentId ?? existing.convertedToStudentId ?? null;

    if (nextStatus === "ACCEPTED" && !existing.convertedToStudentId) {
      const studentEmailInUse = await findUserByEmail(normalizedEmail, tx);

      if (studentEmailInUse) {
        throw new HttpError(getAdmissionDuplicateMessage(), 409);
      }

      const createdAccount = await createStudentAccountForApprovedAdmission(
        {
          name: nextName,
          email: nextEmail,
          phone: nextPhone,
          className: nextClassName,
          details: nextDetails ?? null,
        },
        tx,
      );

      convertedToStudentId = createdAccount.student.id;
      shouldSendApprovalEmail = existing.status !== "ACCEPTED";
      studentEmailRecipient = createdAccount.user.email;
      studentEmailName = createdAccount.user.name;
      studentEmailPassword = createdAccount.studentPassword;
      guardianEmailRecipient = createdAccount.guardianAccount.email;
      guardianEmailName = createdAccount.guardianAccount.name;
      guardianEmailPassword = createdAccount.guardianAccount.password;
      guardianIsNew = createdAccount.guardianAccount.isNew;
    }

    const updatedRecord = await updateAdmissionRecord(
      existing.id,
      {
        ...(payload.name ? { name: nextName } : {}),
        ...(payload.email ? { email: nextEmail } : {}),
        ...(payload.phone !== undefined ? { phone: nextPhone } : {}),
        ...(payload.className ? { className: nextClassName } : {}),
        ...(payload.message !== undefined ? { message: nextMessage } : {}),
        ...(payload.details !== undefined
          ? {
              details: nextDetails as Prisma.JsonObject | Prisma.InputJsonValue,
            }
          : {}),
        status: nextStatus,
        convertedToStudentId,
      },
      tx,
    );

    return updatedRecord;
  });

  try {
    if (updated.status === "ACCEPTED" && shouldSendApprovalEmail) {
      if (studentEmailRecipient && studentEmailName && studentEmailPassword) {
        const studentCredentialsEmail = buildStudentCredentialsEmail({
          name: studentEmailName,
          email: studentEmailRecipient,
          password: studentEmailPassword,
        });

        await sendAppEmail({
          to: studentEmailRecipient,
          subject: studentCredentialsEmail.subject,
          html: studentCredentialsEmail.html,
          text: studentCredentialsEmail.text,
          name: studentEmailName,
        });
      }

      if (guardianEmailRecipient && guardianEmailName) {
        const guardianEmail = guardianIsNew && guardianEmailPassword
          ? buildGuardianCredentialsEmail({
              name: guardianEmailName,
              email: guardianEmailRecipient,
              password: guardianEmailPassword,
            })
          : buildExistingGuardianLinkedEmail({
              name: guardianEmailName,
              email: guardianEmailRecipient,
            });

        await sendAppEmail({
          to: guardianEmailRecipient,
          subject: guardianEmail.subject,
          html: guardianEmail.html,
          text: guardianEmail.text,
          name: guardianEmailName,
        });
      }

      await sendAdmissionStatusEmail({
        status: "APPROVED",
        name: updated.name,
        email: updated.email,
        className: updated.className,
      });
    }

    if (updated.status === "REJECTED" && existing.status !== "REJECTED") {
      await sendAdmissionStatusEmail({
        status: "REJECTED",
        name: updated.name,
        email: updated.email,
        className: updated.className,
      });
    }
  } catch (err) {
    console.error("Failed to send admission status email", err);
  }

  return {
    ...updated,
    status: toReviewAdmissionStatus(updated.status),
  };
}

export async function deleteAdmissionForAdmin(admissionId: string) {
  const existing = await findAdmissionById(admissionId);

  if (!existing) {
    throw new HttpError("Admission application not found", 404);
  }

  if (existing.convertedToStudentId) {
    throw new HttpError(
      "Approved admission cannot be deleted after student creation",
      400,
    );
  }

  return prisma.admissionApplication.delete({
    where: { id: admissionId },
    select: {
      id: true,
    },
  });
}
