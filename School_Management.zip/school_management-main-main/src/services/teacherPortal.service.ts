import { Role, WeekDay } from "@prisma/client";
import { getExamTypeLabel } from "@/constants/exam-types";
import { comparePassword, hashPassword } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  deriveGradeFromMarks,
  resolveTotalMarksFromExamSubjects,
} from "@/lib/result-marks";
import { findUserByEmail } from "@/repositories/user.repository";
import { buildVisibleNoticeWhere } from "@/repositories/notice.repository";
import { listVisibleTeacherExams } from "@/services/exam.service";
import { syncExpiredNotices } from "@/services/notice.service";
import { fetchUserTheme } from "@/services/theme.service";
import { recordAuditEvent } from "@/services/audit.service";
import { HttpError } from "@/utils/error-handler";

function getWeekDay(date = new Date()) {
  const day = date.getDay();
  switch (day) {
    case 1:
      return WeekDay.MONDAY;
    case 2:
      return WeekDay.TUESDAY;
    case 3:
      return WeekDay.WEDNESDAY;
    case 4:
      return WeekDay.THURSDAY;
    case 5:
      return WeekDay.FRIDAY;
    case 6:
      return WeekDay.SATURDAY;
    default:
      return null;
  }
}

async function requireTeacherPortalContext(userId: string) {
  const teacher = await prisma.teacher.findUnique({
    where: { userId },
    select: {
      id: true,
      phone: true,
      address: true,
      isDeleted: true,
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          isDeleted: true,
        },
      },
      subjects: {
        select: {
          id: true,
          classId: true,
          subjectId: true,
          class: {
            select: {
              id: true,
              name: true,
            },
          },
          subject: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      },
      managedClasses: {
        select: {
          classId: true,
          class: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      },
    },
  });

  if (
    !teacher ||
    teacher.isDeleted ||
    teacher.user.isDeleted ||
    teacher.user.role !== Role.TEACHER
  ) {
    throw new HttpError("Teacher account not found", 404);
  }

  return teacher;
}

function deriveGrade(marks: number, totalMarks?: number) {
  return deriveGradeFromMarks(marks, totalMarks);
}

function uniqueValues<T>(values: T[]) {
  return Array.from(new Set(values));
}

function assertUniqueStudentEntries(entries: Array<{ studentId: string }>) {
  const studentIds = entries.map((entry) => entry.studentId);
  if (new Set(studentIds).size !== studentIds.length) {
    throw new HttpError("Duplicate student entries are not allowed", 400);
  }
}

function isSubjectAllowedForClass(
  assignments: Array<{ classId: string; subjectId: string }>,
  classId?: string | null,
  subjectId?: string | null,
) {
  if (!classId || !subjectId) return true;
  return assignments.some(
    (item) => item.classId === classId && item.subjectId === subjectId,
  );
}

function getTeacherManagedClassIds(
  teacher: Awaited<ReturnType<typeof requireTeacherPortalContext>>,
) {
  const explicitClassIds = teacher.managedClasses.map((item) => item.classId);
  if (explicitClassIds.length > 0) {
    return uniqueValues(explicitClassIds);
  }

  return uniqueValues(teacher.subjects.map((item) => item.classId));
}

function getTeacherManagedClasses(
  teacher: Awaited<ReturnType<typeof requireTeacherPortalContext>>,
) {
  if (teacher.managedClasses.length > 0) {
    return teacher.managedClasses.map((item) => ({
      id: item.class.id,
      name: item.class.name,
    }));
  }

  return uniqueValues(
    teacher.subjects.map((item) =>
      JSON.stringify({ id: item.class.id, name: item.class.name }),
    ),
  ).map((item) => JSON.parse(item) as { id: string; name: string });
}

function assertMarksWithinTotal(marks: number, totalMarks: number) {
  if (marks > totalMarks) {
    throw new HttpError(`Marks cannot be greater than total marks (${totalMarks})`, 400);
  }
}

export async function getTeacherDashboard(userId: string) {
  await syncExpiredNotices();
  const teacher = await requireTeacherPortalContext(userId);
  const classIds = getTeacherManagedClassIds(teacher);
  const subjectIds = Array.from(
    new Set(teacher.subjects.map((item) => item.subjectId)),
  );
  const today = getWeekDay();

  const [students, timetable, notices, recentResults, recentAttendance, exams] =
    await Promise.all([
      prisma.student.findMany({
        where: {
          classId: { in: classIds.length ? classIds : [""] },
          isDeleted: false,
        },
        select: {
          id: true,
        },
      }),
      prisma.timetable.findMany({
        where: {
          teacherId: teacher.id,
          ...(today ? { day: today } : {}),
        },
        orderBy: { startTime: "asc" },
        select: {
          id: true,
          day: true,
          startTime: true,
          endTime: true,
          class: { select: { name: true } },
          subject: { select: { name: true } },
        },
      }),
      prisma.notice.findMany({
        where: {
          ...buildVisibleNoticeWhere(),
          OR: [
            { audience: "ALL" },
            { audience: "TEACHERS" },
            ...(classIds.length ? [{ classId: { in: classIds } }] : []),
          ],
        },
        orderBy: { createdAt: "desc" },
        take: 5,
        select: {
          id: true,
          title: true,
          content: true,
          createdAt: true,
          audience: true,
          class: { select: { name: true } },
        },
      }),
      prisma.result.findMany({
        where: {
          subjectId: { in: subjectIds.length ? subjectIds : [""] },
          student: { classId: { in: classIds.length ? classIds : [""] } },
        },
        orderBy: { createdAt: "desc" },
        take: 10,
        select: { id: true },
      }),
      prisma.attendance.findMany({
        where: {
          subjectId: { in: subjectIds.length ? subjectIds : [""] },
          classId: { in: classIds.length ? classIds : [""] },
        },
        orderBy: { date: "desc" },
        take: 20,
        select: { id: true, status: true },
      }),
      listVisibleTeacherExams(teacher.id, classIds),
    ]);

  return {
    teacher: {
      id: teacher.id,
      name: teacher.user.name,
      email: teacher.user.email,
      phone: teacher.phone,
      address: teacher.address,
      managedClasses: teacher.managedClasses.map((item) => ({
        id: item.class.id,
        name: item.class.name,
      })),
      assignedSubjects: teacher.subjects.map((item) => ({
        id: item.id,
        className: item.class.name,
        subjectName: item.subject.name,
      })),
    },
    stats: {
      totalStudents: students.length,
      todaysClasses: timetable.length,
      trackedResults: recentResults.length,
      attendanceMarked: recentAttendance.length,
      assignedExams: exams.length,
    },
    todaySchedule: timetable,
    notices,
    assignedExams: exams
      .filter((exam) => exam.status !== "ARCHIVED")
      .slice(0, 8)
      .map((exam) => ({
        id: exam.id,
        name: exam.name,
        code: exam.code,
        date: exam.date,
        status: exam.status,
        className: exam.class.name,
        examType: getExamTypeLabel(exam.examType),
      })),
  };
}

export async function listTeacherStudents(userId: string, search?: string) {
  const teacher = await requireTeacherPortalContext(userId);
  const classIds = getTeacherManagedClassIds(teacher);
  const students = await prisma.student.findMany({
    where: {
      classId: { in: classIds.length ? classIds : [""] },
      isDeleted: false,
      ...(search?.trim()
        ? {
            OR: [
              {
                user: {
                  name: { contains: search.trim(), mode: "insensitive" },
                },
              },
              {
                user: {
                  email: { contains: search.trim(), mode: "insensitive" },
                },
              },
            ],
          }
        : {}),
    },
    orderBy: [{ class: { name: "asc" } }, { rollNumber: "asc" }],
    select: {
      id: true,
      rollNumber: true,
      phone: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
      class: {
        select: {
          name: true,
        },
      },
      group: {
        select: {
          name: true,
        },
      },
      parent: {
        select: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
      guardian: {
        select: {
          name: true,
          email: true,
          phone: true,
          relation: true,
        },
      },
      attendances: {
        select: {
          status: true,
        },
      },
    },
  });

  return students.map((student) => {
    const totalAttendance = student.attendances.length;
    const presentAttendance = student.attendances.filter(
      (item) => item.status === "PRESENT",
    ).length;

    return {
      id: student.id,
      name: student.user.name,
      email: student.user.email,
      className: student.class.name,
      group: student.group?.name ?? "General",
      roll: student.rollNumber ?? 0,
      parent:
        student.guardian?.name ??
        student.parent?.user.name ??
        "No guardian linked",
      phone: student.phone,
      attendance:
        totalAttendance > 0
          ? Math.round((presentAttendance / totalAttendance) * 100)
          : 0,
    };
  });
}

export async function listTeacherStudentDirectory(
  userId: string,
  filters?: {
    classId?: string;
    search?: string;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  const classIds = getTeacherManagedClassIds(teacher);

  if (filters?.classId && !classIds.includes(filters.classId)) {
    throw new HttpError("You are not assigned to this class", 403);
  }

  const availableClasses = uniqueValues(
    teacher.subjects
      .filter((item) => classIds.includes(item.classId))
      .map((item) => ({
        id: item.class.id,
        name: item.class.name,
      }))
      .map((item) => JSON.stringify(item)),
  ).map((item) => JSON.parse(item) as { id: string; name: string });

  const selectedClassId = filters?.classId ?? availableClasses[0]?.id ?? null;

  const students = await prisma.student.findMany({
    where: {
      isDeleted: false,
      ...(selectedClassId
        ? { classId: selectedClassId }
        : { classId: { in: classIds.length ? classIds : [""] } }),
      ...(filters?.search?.trim()
        ? {
            OR: [
              {
                user: {
                  name: {
                    contains: filters.search.trim(),
                    mode: "insensitive",
                  },
                },
              },
              {
                user: {
                  email: {
                    contains: filters.search.trim(),
                    mode: "insensitive",
                  },
                },
              },
            ],
          }
        : {}),
    },
    orderBy: [{ rollNumber: "asc" }, { user: { name: "asc" } }],
    select: {
      id: true,
      rollNumber: true,
      phone: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      group: {
        select: {
          name: true,
        },
      },
      section: {
        select: {
          name: true,
        },
      },
      parent: {
        select: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
      guardian: {
        select: {
          name: true,
        },
      },
      attendances: {
        select: {
          status: true,
        },
      },
    },
  });

  return {
    classes: availableClasses,
    selectedClassId,
    students: students.map((student) => {
      const totalAttendance = student.attendances.length;
      const presentAttendance = student.attendances.filter(
        (item) => item.status === "PRESENT",
      ).length;

      return {
        id: student.id,
        name: student.user.name,
        email: student.user.email,
        classId: student.class.id,
        className: student.class.name,
        group: student.group?.name ?? "General",
        section: student.section?.name ?? "Default",
        roll: student.rollNumber ?? 0,
        parent:
          student.guardian?.name ??
          student.parent?.user.name ??
          "No guardian linked",
        phone: student.phone,
        attendance:
          totalAttendance > 0
            ? Math.round((presentAttendance / totalAttendance) * 100)
            : 0,
      };
    }),
  };
}

export async function getTeacherStudentProfile(
  userId: string,
  studentId: string,
) {
  const teacher = await requireTeacherPortalContext(userId);
  const classIds = getTeacherManagedClassIds(teacher);

  const student = await prisma.student.findUnique({
    where: { id: studentId },
    select: {
      id: true,
      rollNumber: true,
      phone: true,
      isDeleted: true,
      user: {
        select: {
          name: true,
          email: true,
          isDeleted: true,
        },
      },
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      group: {
        select: {
          name: true,
        },
      },
      section: {
        select: {
          name: true,
        },
      },
      parent: {
        select: {
          user: {
            select: {
              name: true,
              email: true,
            },
          },
        },
      },
      guardian: {
        select: {
          name: true,
          email: true,
          phone: true,
          relation: true,
        },
      },
      attendances: {
        orderBy: [{ date: "desc" }],
        take: 12,
        select: {
          id: true,
          date: true,
          status: true,
          subject: {
            select: {
              name: true,
            },
          },
        },
      },
      results: {
        orderBy: [{ exam: { date: "desc" } }, { createdAt: "desc" }],
        take: 8,
        select: {
          id: true,
          marks: true,
          grade: true,
          subject: {
            select: {
              name: true,
            },
          },
          exam: {
            select: {
              name: true,
              date: true,
            },
          },
        },
      },
    },
  });

  if (
    !student ||
    student.isDeleted ||
    student.user.isDeleted ||
    !classIds.includes(student.class.id)
  ) {
    throw new HttpError("Student not found", 404);
  }

  const totalAttendance = student.attendances.length;
  const attendanceTotals = {
    present: student.attendances.filter((item) => item.status === "PRESENT")
      .length,
    absent: student.attendances.filter((item) => item.status === "ABSENT")
      .length,
    late: student.attendances.filter((item) => item.status === "LATE").length,
  };

  return {
    student: {
      id: student.id,
      name: student.user.name,
      email: student.user.email,
      phone: student.phone,
      roll: student.rollNumber ?? 0,
      classId: student.class.id,
      className: student.class.name,
      group: student.group?.name ?? "General",
      section: student.section?.name ?? "Default",
      parent:
        student.guardian?.name ??
        student.parent?.user.name ??
        "No guardian linked",
      parentEmail:
        student.guardian?.email ?? student.parent?.user.email ?? null,
      attendanceRate:
        totalAttendance > 0
          ? Math.round((attendanceTotals.present / totalAttendance) * 100)
          : 0,
    },
    attendanceTotals,
    recentAttendance: student.attendances,
    recentResults: student.results,
  };
}

export async function listTeacherTimetable(userId: string) {
  const teacher = await requireTeacherPortalContext(userId);
  return prisma.timetable.findMany({
    where: { teacherId: teacher.id },
    orderBy: [{ day: "asc" }, { startTime: "asc" }],
    select: {
      id: true,
      day: true,
      startTime: true,
      endTime: true,
      class: { select: { name: true } },
      subject: { select: { name: true } },
    },
  });
}

export async function listTeacherNotices(userId: string) {
  await syncExpiredNotices();
  const teacher = await requireTeacherPortalContext(userId);
  const classIds = getTeacherManagedClassIds(teacher);

  return prisma.notice.findMany({
    where: {
      ...buildVisibleNoticeWhere(),
      OR: [
        { audience: "ALL" },
        { audience: "TEACHERS" },
        ...(classIds.length ? [{ classId: { in: classIds } }] : []),
      ],
    },
    orderBy: { createdAt: "desc" },
    take: 20,
    select: {
      id: true,
      title: true,
      content: true,
      audience: true,
      createdAt: true,
      class: { select: { name: true } },
    },
  });
}

export async function listTeacherAttendanceWorkspace(
  userId: string,
  filters?: {
    classId?: string;
    subjectId?: string;
    date?: string;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  const classes = getTeacherManagedClasses(teacher);
  const assignments = teacher.subjects.map((item) => ({
    classId: item.classId,
    className: item.class.name,
    subjectId: item.subjectId,
    subjectName: item.subject.name,
  }));
  const classIds = classes.map((item) => item.id);
  const subjectIds = uniqueValues(assignments.map((item) => item.subjectId));

  if (filters?.classId && !classIds.includes(filters.classId)) {
    throw new HttpError("You are not assigned to this class", 403);
  }
  if (filters?.subjectId && !subjectIds.includes(filters.subjectId)) {
    throw new HttpError("You are not assigned to this subject", 403);
  }

  const selectedClassId = filters?.classId ?? classes[0]?.id;
  const allowedSubjectIds = assignments
    .filter((item) => item.classId === selectedClassId)
    .map((item) => item.subjectId);
  const selectedSubjectId =
    filters?.subjectId && allowedSubjectIds.includes(filters.subjectId)
      ? filters.subjectId
      : allowedSubjectIds[0];

  if (
    filters?.classId &&
    filters?.subjectId &&
    !isSubjectAllowedForClass(assignments, filters.classId, filters.subjectId)
  ) {
    throw new HttpError("You are not assigned to this class and subject", 403);
  }

  const [students, records] = await Promise.all([
    prisma.student.findMany({
      where: {
        classId: selectedClassId,
        isDeleted: false,
      },
      orderBy: [{ rollNumber: "asc" }, { createdAt: "asc" }],
      select: {
        id: true,
        rollNumber: true,
        user: {
          select: {
            name: true,
          },
        },
        class: {
          select: {
            name: true,
          },
        },
      },
    }),
    selectedClassId && selectedSubjectId
      ? prisma.attendance.findMany({
          where: {
            classId: selectedClassId,
            subjectId: selectedSubjectId,
            ...(filters?.date
              ? {
                  date: {
                    gte: new Date(filters.date),
                    lt: new Date(
                      new Date(filters.date).getTime() + 24 * 60 * 60 * 1000,
                    ),
                  },
                }
              : {}),
          },
          orderBy: [{ date: "desc" }, { createdAt: "desc" }],
          select: {
            id: true,
            date: true,
            status: true,
            period: true,
            studentId: true,
            student: {
              select: {
                user: {
                  select: {
                    name: true,
                  },
                },
                rollNumber: true,
                class: {
                  select: {
                    name: true,
                  },
                },
              },
            },
          },
        })
      : Promise.resolve([]),
  ]);

  return {
    classes,
    assignments,
    selected: {
      classId: selectedClassId ?? null,
      subjectId: selectedSubjectId ?? null,
      date: filters?.date ?? new Date().toISOString().split("T")[0],
    },
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      roll: student.rollNumber ?? 0,
      className: student.class.name,
    })),
    records,
    stats: {
      present: records.filter((item) => item.status === "PRESENT").length,
      absent: records.filter((item) => item.status === "ABSENT").length,
      late: records.filter((item) => item.status === "LATE").length,
    },
  };
}

export async function saveTeacherAttendance(
  userId: string,
  payload: {
    classId: string;
    subjectId: string;
    date: string;
    period?: number;
    entries: Array<{
      studentId: string;
      status: "PRESENT" | "ABSENT" | "LATE";
      remarks?: string;
    }>;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  assertUniqueStudentEntries(payload.entries);
  const assignment = teacher.subjects.find(
    (item) =>
      item.classId === payload.classId && item.subjectId === payload.subjectId,
  );

  if (!assignment) {
    throw new HttpError("You are not assigned to this class and subject", 403);
  }

  const students = await prisma.student.findMany({
    where: {
      id: { in: payload.entries.map((item) => item.studentId) },
      classId: payload.classId,
      isDeleted: false,
    },
    select: { id: true },
  });

  if (students.length !== payload.entries.length) {
    throw new HttpError(
      "One or more students do not belong to the selected class",
      400,
    );
  }

  const date = new Date(payload.date);

  const records = await prisma.$transaction(
    payload.entries.map((entry) =>
      prisma.attendance.upsert({
        where: {
          studentId_subjectId_date_period: {
            studentId: entry.studentId,
            subjectId: payload.subjectId,
            date,
            period: payload.period ?? 1,
          },
        },
        update: {
          status: entry.status,
          classId: payload.classId,
          markedBy: teacher.user.name,
          remarks: entry.remarks?.trim() || null,
        },
        create: {
          student: { connect: { id: entry.studentId } },
          class: { connect: { id: payload.classId } },
          subject: { connect: { id: payload.subjectId } },
          date,
          period: payload.period ?? 1,
          status: entry.status,
          markedBy: teacher.user.name,
          remarks: entry.remarks?.trim() || null,
        },
        select: {
          id: true,
          status: true,
        },
      }),
    ),
  );

  await recordAuditEvent({
    actorId: userId,
    action: "teacher.attendance.saved",
    entityType: "Attendance",
    metadata: {
      classId: payload.classId,
      subjectId: payload.subjectId,
      date: payload.date,
      count: payload.entries.length,
    },
  });

  return {
    summary: {
      total: records.length,
      present: records.filter((item) => item.status === "PRESENT").length,
      absent: records.filter((item) => item.status === "ABSENT").length,
      late: records.filter((item) => item.status === "LATE").length,
    },
  };
}

export async function listTeacherResultsWorkspace(
  userId: string,
  filters?: {
    classId?: string;
    subjectId?: string;
    examId?: string;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  const assignments = teacher.subjects.map((item) => ({
    classId: item.classId,
    className: item.class.name,
    subjectId: item.subjectId,
    subjectName: item.subject.name,
  }));
  const classIds = uniqueValues(assignments.map((item) => item.classId));
  const subjectIds = uniqueValues(assignments.map((item) => item.subjectId));

  if (filters?.classId && !classIds.includes(filters.classId)) {
    throw new HttpError("You are not assigned to this class", 403);
  }
  if (filters?.subjectId && !subjectIds.includes(filters.subjectId)) {
    throw new HttpError("You are not assigned to this subject", 403);
  }

  const selectedClassId = filters?.classId ?? classIds[0];
  const allowedSubjectIds = assignments
    .filter((item) => item.classId === selectedClassId)
    .map((item) => item.subjectId);
  const selectedSubjectId =
    filters?.subjectId && allowedSubjectIds.includes(filters.subjectId)
      ? filters.subjectId
      : allowedSubjectIds[0];

  if (
    filters?.classId &&
    filters?.subjectId &&
    !isSubjectAllowedForClass(assignments, filters.classId, filters.subjectId)
  ) {
    throw new HttpError("You are not assigned to this class and subject", 403);
  }

  const [students, exams, results] = await Promise.all([
    prisma.student.findMany({
      where: {
        classId: selectedClassId,
        isDeleted: false,
      },
      orderBy: [{ rollNumber: "asc" }, { createdAt: "asc" }],
      select: {
        id: true,
        rollNumber: true,
        user: { select: { name: true } },
        class: { select: { name: true } },
      },
    }),
    prisma.exam.findMany({
      where: selectedClassId
        ? {
            OR: [
              { classId: selectedClassId },
              { assignedClasses: { some: { classId: selectedClassId } } },
            ],
          }
        : undefined,
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      select: {
        id: true,
        name: true,
        date: true,
        classId: true,
        class: { select: { name: true } },
        assignedClasses: { select: { classId: true } },
        subjects: {
          select: {
            classId: true,
            subjectId: true,
            fullMarks: true,
            components: {
              select: {
                fullMarks: true,
              },
            },
          },
        },
      },
    }),
    selectedClassId && selectedSubjectId
      ? prisma.result.findMany({
          where: {
            student: { classId: selectedClassId },
            subjectId: selectedSubjectId,
            ...(filters?.examId ? { examId: filters.examId } : {}),
          },
          orderBy: [{ exam: { date: "desc" } }, { createdAt: "desc" }],
          select: {
            id: true,
            marks: true,
            grade: true,
            studentId: true,
            subjectId: true,
            student: {
              select: {
                user: { select: { name: true } },
                rollNumber: true,
                class: { select: { id: true, name: true } },
              },
            },
            subject: { select: { name: true } },
            exam: {
              select: {
                id: true,
                name: true,
                date: true,
                subjects: {
                  select: {
                    classId: true,
                    subjectId: true,
                    fullMarks: true,
                    components: {
                      select: {
                        fullMarks: true,
                      },
                    },
                  },
                },
              },
            },
          },
        })
      : Promise.resolve([]),
  ]);
  const selectedExamId = filters?.examId ?? exams[0]?.id ?? null;
  const selectedTotalMarks = resolveTotalMarksFromExamSubjects(
    exams.find((exam) => exam.id === selectedExamId)?.subjects,
    selectedClassId,
    selectedSubjectId,
  );
  const mappedExams = exams.map((exam) => ({
    id: exam.id,
    name: exam.name,
    date: exam.date,
    classId: exam.classId,
    class: exam.class,
    assignedClasses: exam.assignedClasses,
    totalMarks: resolveTotalMarksFromExamSubjects(
      exam.subjects,
      selectedClassId,
      selectedSubjectId,
    ),
  }));
  const mappedResults = results.map((result) => ({
    ...result,
    exam: {
      id: result.exam.id,
      name: result.exam.name,
      date: result.exam.date,
    },
    totalMarks: resolveTotalMarksFromExamSubjects(
      result.exam.subjects,
      result.student.class.id,
      result.subjectId,
    ),
  }));

  return {
    assignments,
    selected: {
      classId: selectedClassId ?? null,
      subjectId: selectedSubjectId ?? null,
      examId: selectedExamId,
      totalMarks: selectedTotalMarks,
    },
    students: students.map((student) => ({
      id: student.id,
      name: student.user.name,
      roll: student.rollNumber ?? 0,
      className: student.class.name,
    })),
    exams: mappedExams,
    results: mappedResults,
    stats: {
      total: mappedResults.length,
      averageMarks:
        mappedResults.length > 0
          ? Number(
              (
                mappedResults.reduce((sum, item) => sum + item.marks, 0) /
                mappedResults.length
              ).toFixed(2),
            )
          : 0,
    },
  };
}

export async function saveTeacherResults(
  userId: string,
  payload: {
    classId: string;
    subjectId: string;
    examId: string;
    entries: Array<{
      studentId: string;
      marks: number;
      grade?: string;
    }>;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  assertUniqueStudentEntries(payload.entries);
  const assignment = teacher.subjects.find(
    (item) =>
      item.classId === payload.classId && item.subjectId === payload.subjectId,
  );

  if (!assignment) {
    throw new HttpError("You are not assigned to this class and subject", 403);
  }

  const exam = await prisma.exam.findUnique({
    where: { id: payload.examId },
    select: {
      id: true,
      classId: true,
      name: true,
      isAllClasses: true,
      assignedClasses: { select: { classId: true } },
      subjects: {
        select: {
          classId: true,
          subjectId: true,
          fullMarks: true,
          components: {
            select: {
              fullMarks: true,
            },
          },
        },
      },
    },
  });

  const examCoversClass =
    exam?.isAllClasses ||
    exam?.classId === payload.classId ||
    exam?.assignedClasses.some((item) => item.classId === payload.classId);

  if (!exam || !examCoversClass) {
    throw new HttpError(
      "Selected exam does not belong to the chosen class",
      400,
    );
  }

  const students = await prisma.student.findMany({
    where: {
      id: { in: payload.entries.map((item) => item.studentId) },
      classId: payload.classId,
      isDeleted: false,
    },
    select: { id: true },
  });

  if (students.length !== payload.entries.length) {
    throw new HttpError(
      "One or more students do not belong to the selected class",
      400,
    );
  }

  const totalMarks = resolveTotalMarksFromExamSubjects(
    exam.subjects,
    payload.classId,
    payload.subjectId,
  );
  payload.entries.forEach((entry) => assertMarksWithinTotal(entry.marks, totalMarks));

  const results = await prisma.$transaction(
    payload.entries.map((entry) =>
      prisma.result.upsert({
        where: {
          studentId_examId_subjectId: {
            studentId: entry.studentId,
            examId: payload.examId,
            subjectId: payload.subjectId,
          },
        },
        update: {
          marks: entry.marks,
          grade: entry.grade?.trim() || deriveGrade(entry.marks, totalMarks),
        },
        create: {
          student: { connect: { id: entry.studentId } },
          exam: { connect: { id: payload.examId } },
          subject: { connect: { id: payload.subjectId } },
          marks: entry.marks,
          grade: entry.grade?.trim() || deriveGrade(entry.marks, totalMarks),
        },
        select: {
          id: true,
          marks: true,
        },
      }),
    ),
  );

  await recordAuditEvent({
    actorId: userId,
    action: "teacher.results.saved",
    entityType: "Result",
    metadata: {
      classId: payload.classId,
      subjectId: payload.subjectId,
      examId: payload.examId,
      count: payload.entries.length,
    },
  });

  return {
    summary: {
      total: results.length,
      averageMarks:
        results.length > 0
          ? Number(
              (
                results.reduce((sum, item) => sum + item.marks, 0) /
                results.length
              ).toFixed(2),
            )
          : 0,
    },
  };
}

export async function getTeacherSettings(userId: string) {
  const teacher = await requireTeacherPortalContext(userId);
  const theme = await fetchUserTheme(userId);

  return {
    profile: {
      name: teacher.user.name,
      email: teacher.user.email,
      phone: teacher.phone,
      address: teacher.address,
    },
    theme,
  };
}

export async function updateTeacherProfile(
  userId: string,
  payload: {
    name: string;
    email: string;
  },
) {
  const teacher = await requireTeacherPortalContext(userId);
  const normalizedEmail = payload.email.trim().toLowerCase();
  const otherUser = await findUserByEmail(normalizedEmail);

  if (otherUser && otherUser.id !== teacher.user.id) {
    throw new HttpError("Email already exists", 409);
  }

  const user = await prisma.user.update({
    where: { id: teacher.user.id },
    data: {
      name: payload.name.trim(),
      email: normalizedEmail,
    },
    select: {
      id: true,
      name: true,
      email: true,
    },
  });

  await recordAuditEvent({
    actorId: userId,
    action: "teacher.profile.updated",
    entityType: "User",
    entityId: user.id,
    metadata: {
      name: user.name,
      email: user.email,
    },
  });

  return user;
}

export async function updateTeacherPassword(
  userId: string,
  payload: {
    currentPassword: string;
    newPassword: string;
  },
) {
  const teacher = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      password: true,
      role: true,
    },
  });

  if (!teacher || teacher.role !== Role.TEACHER) {
    throw new HttpError("Teacher account not found", 404);
  }

  const valid = await comparePassword(
    payload.currentPassword,
    teacher.password,
  );
  if (!valid) {
    throw new HttpError("Current password is incorrect", 400);
  }

  await prisma.user.update({
    where: { id: teacher.id },
    data: {
      password: await hashPassword(payload.newPassword),
    },
  });

  await recordAuditEvent({
    actorId: userId,
    action: "teacher.password.updated",
    entityType: "User",
    entityId: teacher.id,
  });

  return { message: "Password updated successfully" };
}
