import { AttendanceStatus, PayrollItemStatus, PayrollRunStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getScopedBranchId } from "@/lib/request-context";
import {
  createPayrollRun,
  findPayrollRunById,
  findPayrollRunByPeriod,
  listPayrollItems,
  listPayrollRuns,
  markPayrollRunItemsPaid,
  updatePayrollItem,
  updatePayrollRun,
} from "@/repositories/payroll.repository";
import { HttpError } from "@/utils/error-handler";

function assertValidPeriod(month: number, year: number) {
  if (!Number.isInteger(month) || month < 1 || month > 12) {
    throw new HttpError("Invalid month", 400);
  }
  if (!Number.isInteger(year) || year < 2000 || year > 2100) {
    throw new HttpError("Invalid year", 400);
  }
}

function monthRangeLocal(month: number, year: number) {
  const from = new Date(year, month - 1, 1, 0, 0, 0, 0);
  const to = new Date(year, month, 0, 23, 59, 59, 999);
  return { from, to };
}

function computeNet(base: number, allowances: number, deductions: number) {
  return Math.max(base + allowances - deductions, 0);
}

export async function listPayrollRunsForAdmin(filters: { status?: PayrollRunStatus } = {}) {
  const runs = await listPayrollRuns(filters);
  return { runs };
}

export async function getPayrollRunDetailsForAdmin(payrollRunId: string) {
  const run = await findPayrollRunById(payrollRunId);
  if (!run) throw new HttpError("Payroll run not found", 404);
  const items = await listPayrollItems(payrollRunId);
  return { run, items };
}

export async function generatePayrollRunForAdmin(payload: {
  month: number;
  year: number;
  actorId: string;
}) {
  assertValidPeriod(payload.month, payload.year);
  const branchId = getScopedBranchId();

  const existing = await findPayrollRunByPeriod(payload.month, payload.year);
  if (existing) {
    throw new HttpError("Payroll run already exists for this period", 409);
  }

  const { from, to } = monthRangeLocal(payload.month, payload.year);

  const teachers = await prisma.teacher.findMany({
    where: { isDeleted: false, user: { isDeleted: false } },
    select: { id: true, salary: true },
    orderBy: { createdAt: "asc" },
  });

  const teacherIds = teachers.map((t) => t.id);
  const attendance = teacherIds.length
    ? await prisma.teacherAttendance.findMany({
        where: {
          teacherId: { in: teacherIds },
          date: { gte: from, lte: to },
        },
        select: { teacherId: true, status: true },
      })
    : [];

  const attendanceByTeacher = new Map<string, { present: number; absent: number }>();
  for (const row of attendance) {
    const current = attendanceByTeacher.get(row.teacherId) ?? { present: 0, absent: 0 };
    if (row.status === AttendanceStatus.ABSENT) {
      current.absent += 1;
    } else {
      current.present += 1;
    }
    attendanceByTeacher.set(row.teacherId, current);
  }

  return prisma.$transaction(async (tx) => {
    const run = await createPayrollRun(
      {
        month: payload.month,
        year: payload.year,
        status: PayrollRunStatus.DRAFT,
        createdBy: { connect: { id: payload.actorId } },
        items: {
          create: teachers.map((teacher) => {
            const baseSalary = teacher.salary ?? 0;
            const counts = attendanceByTeacher.get(teacher.id) ?? { present: 0, absent: 0 };
            const allowances = 0;
            const deductions = 0;
            const netPay = computeNet(baseSalary, allowances, deductions);
            return {
              ...(branchId ? { branchId } : {}),
              teacher: { connect: { id: teacher.id } },
              baseSalarySnapshot: baseSalary,
              allowances,
              deductions,
              netPay,
              presentDays: attendance.length ? counts.present : null,
              absentDays: attendance.length ? counts.absent : null,
              status: PayrollItemStatus.UNPAID,
            };
          }),
        },
      },
      tx,
    );

    return run;
  });
}

export async function updatePayrollItemForAdmin(payload: {
  payrollItemId: string;
  allowances?: number;
  deductions?: number;
}) {
  const item = await prisma.payrollItem.findUnique({
    where: { id: payload.payrollItemId },
    select: { id: true, payrollRunId: true, baseSalarySnapshot: true, allowances: true, deductions: true },
  });
  if (!item) throw new HttpError("Payroll item not found", 404);

  const allowances = payload.allowances ?? item.allowances;
  const deductions = payload.deductions ?? item.deductions;
  const netPay = computeNet(item.baseSalarySnapshot, allowances, deductions);

  return updatePayrollItem(item.id, {
    ...(payload.allowances !== undefined ? { allowances: payload.allowances } : {}),
    ...(payload.deductions !== undefined ? { deductions: payload.deductions } : {}),
    netPay,
  });
}

export async function lockPayrollRunForAdmin(payrollRunId: string) {
  const run = await findPayrollRunById(payrollRunId);
  if (!run) throw new HttpError("Payroll run not found", 404);
  if (run.status === PayrollRunStatus.LOCKED) return run;
  return updatePayrollRun(payrollRunId, { status: PayrollRunStatus.LOCKED });
}

export async function markPayrollRunPaidForAdmin(payrollRunId: string) {
  const run = await findPayrollRunById(payrollRunId);
  if (!run) throw new HttpError("Payroll run not found", 404);
  if (run.status !== PayrollRunStatus.LOCKED) {
    throw new HttpError("Lock the payroll run before marking it paid", 409);
  }

  const result = await markPayrollRunItemsPaid(payrollRunId);
  return { ...result };
}
