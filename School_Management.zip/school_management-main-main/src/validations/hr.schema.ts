import { z } from "zod";

export const hrListQuerySchema = z.object({
  search: z.string().trim().optional(),
});

export const createDepartmentSchema = z.object({
  name: z.string().trim().min(2).max(120),
  isActive: z.boolean().optional(),
});

export const updateDepartmentSchema = z
  .object({
    name: z.string().trim().min(2).max(120).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const createDesignationSchema = z.object({
  name: z.string().trim().min(2).max(120),
  isActive: z.boolean().optional(),
});

export const updateDesignationSchema = z
  .object({
    name: z.string().trim().min(2).max(120).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const leaveStatusSchema = z.enum([
  "PENDING",
  "APPROVED",
  "REJECTED",
  "CANCELLED",
]);

export const teacherLeaveListQuerySchema = z.object({
  status: leaveStatusSchema.optional(),
  teacherId: z.string().optional(),
});

export const createTeacherLeaveSchema = z.object({
  teacherId: z.string().min(1),
  startDate: z.string().min(4),
  endDate: z.string().min(4),
  reason: z.string().trim().max(500).optional(),
});

export const decideTeacherLeaveSchema = z.object({
  status: z.enum(["APPROVED", "REJECTED", "CANCELLED"]),
});

