import { z } from "zod";

export const teacherAttendanceEntrySchema = z.object({
  studentId: z.string().trim().min(1),
  status: z.enum(["PRESENT", "ABSENT", "LATE"]),
  remarks: z.string().trim().max(300).optional(),
});

export const teacherAttendanceUpsertSchema = z.object({
  classId: z.string().trim().min(1),
  subjectId: z.string().trim().min(1),
  date: z.string().trim().min(1),
  period: z.number().int().min(1).max(12).optional(),
  entries: z.array(teacherAttendanceEntrySchema).min(1),
});

export const teacherResultsSaveSchema = z.object({
  classId: z.string().trim().min(1),
  subjectId: z.string().trim().min(1),
  examId: z.string().trim().min(1),
  entries: z.array(
    z.object({
      studentId: z.string().trim().min(1),
      marks: z.number().min(0).max(1000),
      grade: z.string().trim().max(10).optional(),
    })
  ).min(1),
});

export const teacherProfileUpdateSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email(),
});

export const teacherPasswordUpdateSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8),
  confirmPassword: z.string().min(8),
}).refine((value) => value.newPassword === value.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});
