import { z } from "zod";

export const duePeriodSchema = z.object({
  month: z.coerce.number().int().min(1).max(12),
  year: z.coerce.number().int().min(2000).max(2100),
  classId: z.string().optional(),
});

export const dueReportQuerySchema = duePeriodSchema.extend({
  search: z.string().trim().optional(),
});

