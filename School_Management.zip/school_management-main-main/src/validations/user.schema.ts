import { z } from "zod";

const managedRoleEnum = z.enum([
  "USER",
  "SUPER_ADMIN",
  "ADMIN",
  "ACCOUNTANT",
  "ACADEMIC_ADMIN",
  "ADMISSION_ADMIN",
  "TEACHER",
  "STUDENT",
]);

export const userListQuerySchema = z.object({
  search: z.string().trim().optional(),
  role: managedRoleEnum.optional(),
  includeDeleted: z.coerce.boolean().optional().default(false),
});

export const createManagedUserSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8).max(128),
  role: managedRoleEnum,
  branchId: z.string().min(1).optional(),
});

export const updateManagedUserSchema = z
  .object({
    name: z.string().trim().min(2).max(80).optional(),
    email: z.string().email().optional(),
    password: z.string().min(8).max(128).optional(),
    role: managedRoleEnum.optional(),
    branchId: z.string().min(1).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
