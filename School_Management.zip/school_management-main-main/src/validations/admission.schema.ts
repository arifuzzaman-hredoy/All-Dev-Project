import { z } from "zod";

const admissionStatusEnum = z.enum(["PENDING", "APPROVED", "REJECTED"]);
const genderEnum = z.enum(["MALE", "FEMALE", "OTHER"]);

export const admissionDetailsSchema = z.object({
  gender: genderEnum.nullable().optional(),
  fatherName: z.string().trim().max(120).nullable().optional(),
  fatherPhone: z.string().trim().max(30).nullable().optional(),
  motherName: z.string().trim().max(120).nullable().optional(),
  motherPhone: z.string().trim().max(30).nullable().optional(),
  guardianName: z.string().trim().max(120).nullable().optional(),
  guardianEmail: z.string().trim().email().nullable().optional(),
  guardianRelation: z.string().trim().max(80).nullable().optional(),
  guardianPhone: z.string().trim().max(30).nullable().optional(),
  guardianAddress: z.string().trim().max(255).nullable().optional(),
  nidNumber: z.string().trim().max(80).nullable().optional(),
  nidImage: z.string().trim().max(2048).nullable().optional(),
  profileImage: z.string().trim().max(2048).nullable().optional(),
  fatherNidNumber: z.string().trim().max(80).nullable().optional(),
  fatherNidImage: z.string().trim().max(2048).nullable().optional(),
  motherNidNumber: z.string().trim().max(80).nullable().optional(),
  motherNidImage: z.string().trim().max(2048).nullable().optional(),
});

export type AdmissionDetailsInput = z.infer<typeof admissionDetailsSchema>;

export const admissionListQuerySchema = z.object({
  search: z.string().trim().optional(),
  status: admissionStatusEnum.optional(),
});

export const createAdmissionSchema = z.object({
  branchId: z.string().trim().min(1),
  classId: z.string().trim().min(1),
  name: z.string().trim().min(2).max(80),
  email: z
    .string()
    .trim()
    .email()
    .transform((s) => s.toLowerCase()),
  phone: z.string().trim().min(6).max(30).optional(),
  className: z.string().trim().min(1).max(80),
  message: z.string().trim().max(1000).optional(),
  gender: genderEnum.optional(),
  fatherName: z.string().trim().max(120).optional(),
  fatherPhone: z.string().trim().max(30).optional(),
  motherName: z.string().trim().max(120).optional(),
  motherPhone: z.string().trim().max(30).optional(),
  guardianName: z.string().trim().min(2).max(120),
  guardianEmail: z.string().trim().email(),
  guardianRelation: z.string().trim().max(80).optional(),
  guardianPhone: z.string().trim().min(6).max(30),
  guardianAddress: z.string().trim().max(255).optional(),
  nidNumber: z.string().trim().max(80).optional(),
  nidImage: z.string().optional(),
  profileImage: z.string().optional(),
  fatherNidNumber: z.string().trim().max(80).optional(),
  fatherNidImage: z.string().optional(),
  motherNidNumber: z.string().trim().max(80).optional(),
  motherNidImage: z.string().optional(),
});

export const updateAdmissionSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  email: z
    .string()
    .trim()
    .email()
    .transform((value) => value.toLowerCase())
    .optional(),
  phone: z.string().trim().min(6).max(30).nullable().optional(),
  className: z.string().trim().min(1).max(80).optional(),
  message: z.string().trim().max(1000).nullable().optional(),
  details: admissionDetailsSchema.partial().optional(),
  status: admissionStatusEnum,
  convertedToStudentId: z.string().nullable().optional(),
});
