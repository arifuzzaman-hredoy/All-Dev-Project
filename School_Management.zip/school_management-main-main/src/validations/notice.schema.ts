import { z } from "zod";

const noticeAudienceEnum = z.enum(["ALL", "STUDENTS", "TEACHERS", "ADMINS"]);

export const noticeListQuerySchema = z.object({
  search: z.string().trim().optional(),
  audience: noticeAudienceEnum.optional(),
  classId: z.string().optional(),
});

export const createNoticeSchema = z.object({
  title: z.string().trim().min(1).max(120),
  content: z.string().trim().max(5000).optional().default(""),
  audience: noticeAudienceEnum,
  startsAt: z.string().trim().min(1).optional(),
  endsAt: z.string().trim().min(1).optional(),
  classId: z.string().optional(),
});

export const updateNoticeSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  content: z.string().trim().max(5000).optional(),
  audience: noticeAudienceEnum.optional(),
  startsAt: z.string().trim().min(1).nullable().optional(),
  endsAt: z.string().trim().min(1).nullable().optional(),
  classId: z.string().nullable().optional(),
}).refine((value) => Object.keys(value).length > 0, {
  message: "Provide at least one field to update",
});
