import { ExamLifecycleStatus, ExamTypeCategory } from "@prisma/client";
import { z } from "zod";

const idSchema = z.string().trim().min(1);
const optionalObjectSchema = z.record(z.string(), z.unknown()).optional();

export const examListQuerySchema = z.object({
  search: z.string().trim().optional(),
  classId: z.string().trim().optional(),
  status: z.nativeEnum(ExamLifecycleStatus).optional(),
  academicYear: z.string().trim().optional(),
  examTypeId: z.nativeEnum(ExamTypeCategory).optional(),
  includeArchived: z
    .union([z.literal("true"), z.literal("false"), z.boolean()])
    .optional()
    .transform((value) => value === true || value === "true"),
});

export const createExamSchema = z.object({
  name: z.string().trim().min(1).max(120),
  code: z
    .string()
    .trim()
    .min(1)
    .max(60)
    .transform((value) => value.toUpperCase()),
  date: z.string().trim().min(1),
  description: z.string().trim().max(500).optional(),
  academicYear: z.string().trim().min(1).max(40),
  classIds: z.array(idSchema).min(1),
  isAllClasses: z.boolean().optional().default(false),
  examTypeId: z.nativeEnum(ExamTypeCategory).optional().nullable(),
  status: z.nativeEnum(ExamLifecycleStatus).optional(),
  visibleToStudents: z.boolean().optional(),
  visibleToParents: z.boolean().optional(),
  visibleToTeachers: z.boolean().optional(),
  generateResult: z.boolean().optional(),
  includeInFinalReport: z.boolean().optional(),
  includeInTranscript: z.boolean().optional(),
  includeInMeritList: z.boolean().optional(),
  lockAfterPublish: z.boolean().optional(),
  publishStartsAt: z.string().trim().optional().nullable(),
  publishEndsAt: z.string().trim().optional().nullable(),
  resultPublishAt: z.string().trim().optional().nullable(),
});

export const updateExamSchema = z
  .object({
    name: z.string().trim().min(1).max(120).optional(),
    code: z.string().trim().min(1).max(60).optional(),
    date: z.string().trim().optional(),
    description: z.string().trim().max(500).optional(),
    academicYear: z.string().trim().min(1).max(40).optional(),
    classIds: z.array(idSchema).min(1).optional(),
    isAllClasses: z.boolean().optional(),
    examTypeId: z.nativeEnum(ExamTypeCategory).optional().nullable(),
    status: z.nativeEnum(ExamLifecycleStatus).optional(),
    visibleToStudents: z.boolean().optional(),
    visibleToParents: z.boolean().optional(),
    visibleToTeachers: z.boolean().optional(),
    generateResult: z.boolean().optional(),
    includeInFinalReport: z.boolean().optional(),
    includeInTranscript: z.boolean().optional(),
    includeInMeritList: z.boolean().optional(),
    lockAfterPublish: z.boolean().optional(),
    publishStartsAt: z.string().trim().optional().nullable(),
    publishEndsAt: z.string().trim().optional().nullable(),
    resultPublishAt: z.string().trim().optional().nullable(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const examClassAssignmentsSchema = z.object({
  classIds: z.array(idSchema).min(1),
  isAllClasses: z.boolean().optional().default(false),
});

export const examSubjectSchema = z.object({
  classId: idSchema,
  subjectId: idSchema,
  displayOrder: z.coerce.number().int().min(0).optional().default(0),
  isMandatory: z.boolean().optional().default(true),
  fullMarks: z.coerce.number().positive().optional().nullable(),
  passMarks: z.coerce.number().nonnegative().optional().nullable(),
});

export const examComponentSchema = z.object({
  examSubjectId: idSchema,
  name: z.string().trim().min(1).max(120),
  displayOrder: z.coerce.number().int().min(0).optional().default(0),
  fullMarks: z.coerce.number().positive().optional().nullable(),
  isMandatory: z.boolean().optional().default(true),
});

export const examTeacherAssignmentSchema = z.object({
  teacherId: idSchema,
  classId: idSchema,
  subjectId: z.string().trim().optional().nullable(),
  canEdit: z.boolean().optional().default(false),
});

export const examTypeSchema = z.object({
  name: z.string().trim().min(1).max(120),
  code: z
    .string()
    .trim()
    .min(1)
    .max(60)
    .transform((value) => value.toUpperCase()),
  description: z.string().trim().max(500).optional(),
  isActive: z.boolean().optional(),
  defaultBehavior: optionalObjectSchema,
});

export const examHistoryQuerySchema = z.object({
  examId: idSchema.optional(),
  limit: z.coerce.number().int().min(1).max(100).optional().default(30),
});
