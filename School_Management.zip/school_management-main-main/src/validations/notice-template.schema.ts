import { z } from "zod";

export const noticeTemplateSchema = z.object({
  header: z.string().max(2000).optional().default(""),
  footer: z.string().max(2000).optional().default(""),
  signature: z.string().max(2000).optional().default(""),
});

