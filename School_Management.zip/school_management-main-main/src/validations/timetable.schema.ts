import { z } from "zod";

const weekDayEnum = z.enum([
  "MONDAY",
  "TUESDAY",
  "WEDNESDAY",
  "THURSDAY",
  "FRIDAY",
  "SATURDAY",
]);

export const timetableListQuerySchema = z.object({
  classId: z.string().optional(),
  teacherId: z.string().optional(),
  day: weekDayEnum.optional(),
});

export const createTimetableSchema = z.object({
  classId: z.string().min(1),
  subjectId: z.string().min(1),
  teacherId: z.string().min(1),
  day: weekDayEnum,
  startTime: z.string().min(1),
  endTime: z.string().min(1),
});

export const updateTimetableSchema = z
  .object({
    classId: z.string().optional(),
    subjectId: z.string().optional(),
    teacherId: z.string().optional(),
    day: weekDayEnum.optional(),
    startTime: z.string().min(1).optional(),
    endTime: z.string().min(1).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
