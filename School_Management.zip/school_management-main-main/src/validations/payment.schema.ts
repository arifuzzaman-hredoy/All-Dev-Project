import { z } from "zod";

const paymentStatusEnum = z.enum(["PAID", "PARTIAL", "DUE"]);

export const feeCategoryListQuerySchema = z.object({
  search: z.string().trim().optional(),
});

export const createFeeCategorySchema = z.object({
  name: z.string().trim().min(1).max(80),
  amount: z.number().positive(),
  classIds: z.array(z.string().min(1)).optional(),
});

export const updateFeeCategorySchema = z
  .object({
    name: z.string().trim().min(1).max(80).optional(),
    amount: z.number().positive().optional(),
    classIds: z.array(z.string().min(1)).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const deleteFeeCategorySchema = z
  .object({
    permanent: z.boolean().optional(),
    force: z.boolean().optional(),
    currentPassword: z.string().trim().min(1).optional(),
  })
  .refine((value) => !value.force || Boolean(value.currentPassword), {
    message: "Admin password is required for force delete",
    path: ["currentPassword"],
  });

export const paymentListQuerySchema = z.object({
  search: z.string().trim().optional(),
  status: paymentStatusEnum.optional(),
  studentId: z.string().optional(),
  feeCategoryId: z.string().optional(),
});

export const createPaymentSchema = z.object({
  studentId: z.string().min(1),
  feeCategoryId: z.string().min(1),
  amountPaid: z.number().nonnegative(),
  status: paymentStatusEnum,
  paymentMethod: z.string().trim().max(80).optional(),
  transactionId: z.string().trim().max(120).optional(),
  month: z.number().int().min(1).max(12),
  year: z.number().int().min(2000).max(2100),
  dueDate: z.string().optional(),
});

export const updatePaymentSchema = z
  .object({
    amountPaid: z.number().nonnegative().optional(),
    status: paymentStatusEnum.optional(),
    paymentMethod: z.string().trim().max(80).nullable().optional(),
    transactionId: z.string().trim().max(120).nullable().optional(),
    month: z.number().int().min(1).max(12).nullable().optional(),
    year: z.number().int().min(2000).max(2100).nullable().optional(),
    dueDate: z.string().nullable().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
