import { z } from "zod";

export const createSessionSchema = z.object({
  name: z.string().trim().min(3).max(60),
  startsAt: z.string().optional(),
  endsAt: z.string().optional(),
  isActive: z.boolean().optional(),
  makeCurrent: z.boolean().optional().default(false),
});

export const updateSessionSchema = z
  .object({
    name: z.string().trim().min(3).max(60).optional(),
    startsAt: z.string().nullable().optional(),
    endsAt: z.string().nullable().optional(),
    isActive: z.boolean().optional(),
    isCurrent: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const sessionListQuerySchema = z.object({
  search: z.string().trim().optional(),
  includeInactive: z.coerce.boolean().optional().default(false),
});

export const setCurrentSessionSchema = z.object({
  sessionId: z.string().min(1),
});

export const sessionMigrationSchema = z.object({
  fromSessionId: z.string().min(1),
  toSessionId: z.string().min(1),
  classMappings: z
    .array(
      z.object({
        fromClassId: z.string().min(1),
        toClassId: z.string().min(1),
      }),
    )
    .min(1),
  resetRollNumbers: z.boolean().optional().default(true),
  clearGroupSection: z.boolean().optional().default(true),
});

export const sessionAutoNextMigrationSchema = z.object({
  fromSessionId: z.string().min(1),
  toSessionId: z.string().min(1),
  resetRollNumbers: z.boolean().optional().default(true),
  clearGroupSection: z.boolean().optional().default(true),
});
