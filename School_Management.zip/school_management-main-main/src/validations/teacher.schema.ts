import { z } from "zod";

export const teacherListQuerySchema = z.object({
  search: z.string().trim().optional(),
  includeDeleted: z.coerce.boolean().optional().default(false),
});

export const createTeacherSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8).max(128),
  phone: z.string().trim().min(6).max(30).optional(),
  address: z.string().trim().max(255).optional(),
  salary: z.number().nonnegative().optional(),
  classIds: z.array(z.string().trim().min(1)).optional(),
  subjectAssignments: z.array(z.object({
    classId: z.string().trim().min(1),
    subjectId: z.string().trim().min(1),
  })).optional(),
});

export const updateTeacherSchema = z
  .object({
    name: z.string().trim().min(2).max(80).optional(),
    email: z.string().email().optional(),
    password: z.string().min(8).max(128).optional(),
    phone: z.string().trim().min(6).max(30).nullable().optional(),
    address: z.string().trim().max(255).nullable().optional(),
    salary: z.number().nonnegative().nullable().optional(),
    classIds: z.array(z.string().trim().min(1)).optional(),
    subjectAssignments: z.array(z.object({
      classId: z.string().trim().min(1),
      subjectId: z.string().trim().min(1),
    })).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
