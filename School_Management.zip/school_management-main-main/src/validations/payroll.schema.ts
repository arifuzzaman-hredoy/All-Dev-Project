import { z } from "zod";

export const payrollRunStatusSchema = z.enum(["DRAFT", "LOCKED"]);

export const payrollRunListQuerySchema = z.object({
  status: payrollRunStatusSchema.optional(),
});

export const generatePayrollRunSchema = z.object({
  month: z.number().int().min(1).max(12),
  year: z.number().int().min(2000).max(2100),
});

export const updatePayrollItemSchema = z
  .object({
    allowances: z.number().min(0).optional(),
    deductions: z.number().min(0).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

