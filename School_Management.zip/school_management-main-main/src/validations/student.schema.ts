import { z } from "zod";

const genderEnum = z.enum(["MALE", "FEMALE", "OTHER"]);
const optionalPasswordSchema = z
  .union([z.string().trim().min(8).max(128), z.literal(""), z.undefined()])
  .transform((value) => (typeof value === "string" && value ? value : undefined));

export const studentListQuerySchema = z.object({
  search: z.string().trim().optional(),
  classId: z.string().optional(),
  includeDeleted: z.coerce.boolean().optional().default(false),
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(5).max(100).optional().default(20),
});

export const createStudentSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  password: optionalPasswordSchema,
  phone: z.string().trim().min(6).max(30).optional(),
  gender: genderEnum,
  classId: z.string().optional(),
  groupId: z.string().optional(),
  sectionId: z.string().optional(),
  guardianName: z.string().trim().min(2).max(120),
  guardianEmail: z.string().trim().email().optional(),
  guardianPhone: z.string().trim().min(6).max(30).optional(),
  guardianAddress: z.string().trim().max(255).optional(),
  guardianRelation: z.string().trim().max(80).optional(),
  fatherName: z.string().trim().max(120).optional(),
  fatherPhone: z.string().trim().max(30).optional(),
  motherName: z.string().trim().max(120).optional(),
  motherPhone: z.string().trim().max(30).optional(),
  nidNumber: z.string().trim().min(1).max(80),
  nidImage: z.string().min(1),
  profileImage: z.string().min(1),
  fatherNidNumber: z.string().trim().min(1).max(80),
  fatherNidImage: z.string().min(1),
  motherNidNumber: z.string().trim().min(1).max(80),
  motherNidImage: z.string().min(1),
  rollNumber: z.number().int().positive().optional(),
});

export const updateStudentSchema = z
  .object({
    name: z.string().trim().min(2).max(80).optional(),
    email: z.string().email().optional(),
    password: z.string().min(8).max(128).optional(),
    phone: z.string().trim().min(6).max(30).nullable().optional(),
    gender: genderEnum.optional(),
    classId: z.string().optional(),
    groupId: z.string().nullable().optional(),
    sectionId: z.string().nullable().optional(),
    guardianName: z.string().trim().min(2).max(120).optional(),
    guardianEmail: z.string().trim().email().nullable().optional(),
    guardianPhone: z.string().trim().min(6).max(30).nullable().optional(),
    guardianAddress: z.string().trim().max(255).nullable().optional(),
    guardianRelation: z.string().trim().max(80).nullable().optional(),
    fatherName: z.string().trim().max(120).nullable().optional(),
    fatherPhone: z.string().trim().max(30).nullable().optional(),
    motherName: z.string().trim().max(120).nullable().optional(),
    motherPhone: z.string().trim().max(30).nullable().optional(),
    rollNumber: z.number().int().positive().nullable().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
