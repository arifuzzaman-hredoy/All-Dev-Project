import { z } from "zod";
import {
  DEFAULT_STUDENT_DOCUMENT_TEMPLATE,
  isHexColor,
  type StudentDocumentTemplateConfig,
} from "@/lib/student-document-template";

const hexColorSchema = z.string().trim().refine(isHexColor, "Must be a valid hex color");

export const studentDocumentTemplateSchema = z.object({
  schoolName: z.string().trim().min(1, "School name is required"),
  headerTitle: z.string().trim().min(1, "Header title is required"),
  headerSubtitle: z.string().trim().min(1, "Header subtitle is required"),
  watermarkText: z.string().trim().min(1, "Watermark text is required"),
  noteText: z.string().trim().min(1, "Note text is required"),
  footerLeftText: z.string().trim().min(1, "Left footer text is required"),
  footerRightText: z.string().trim().min(1, "Right footer text is required"),
  primaryColor: hexColorSchema,
  secondaryColor: hexColorSchema,
  accentColor: hexColorSchema,
  backgroundColor: hexColorSchema,
  surfaceColor: hexColorSchema,
  borderColor: hexColorSchema,
});

export const updateStudentDocumentTemplateSchema = studentDocumentTemplateSchema;

export type StudentDocumentTemplateInput = z.infer<typeof studentDocumentTemplateSchema>;

export function studentDocumentTemplateDefaults(): StudentDocumentTemplateInput {
  return DEFAULT_STUDENT_DOCUMENT_TEMPLATE;
}

export function toStudentDocumentTemplateConfig(
  value: StudentDocumentTemplateConfig | StudentDocumentTemplateInput,
): StudentDocumentTemplateConfig {
  return {
    ...DEFAULT_STUDENT_DOCUMENT_TEMPLATE,
    ...value,
  };
}
