import { z } from "zod";

export const teacherSubjectListQuerySchema = z.object({
  teacherId: z.string().optional(),
  classId: z.string().optional(),
  subjectId: z.string().optional(),
});

export const createTeacherSubjectSchema = z.object({
  teacherId: z.string().min(1),
  subjectId: z.string().min(1),
  classId: z.string().min(1),
});

export const updateTeacherSubjectSchema = z
  .object({
    teacherId: z.string().optional(),
    subjectId: z.string().optional(),
    classId: z.string().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
