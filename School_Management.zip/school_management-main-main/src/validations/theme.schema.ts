import { z } from "zod";

const hexColor = z
  .string()
  .trim()
  .regex(/^#(?:[0-9a-fA-F]{3}){1,2}$/, "Expected a valid hex color");

const themeShape = {
  background: hexColor,
  foreground: hexColor,
  primary: hexColor,
  secondary: hexColor,
  accent: hexColor,
  destructive: hexColor,
  muted: hexColor,
  border: hexColor,
  input: hexColor,
  ring: hexColor,
  card: hexColor,
  popover: hexColor,
  sidebar: hexColor,
  "sidebar-foreground": hexColor,
  "sidebar-border": hexColor,
} as const;

export const updateGlobalThemeSchema = z.object(themeShape);

export const updateUserThemeSchema = z.object(themeShape).partial().refine(
  (value) => Object.keys(value).length > 0,
  {
    message: "Provide at least one theme value to update",
  }
);
