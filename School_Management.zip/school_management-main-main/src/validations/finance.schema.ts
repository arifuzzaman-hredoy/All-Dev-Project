import { z } from "zod";

export const financeEntryTypeSchema = z.enum(["INCOME", "EXPENSE"]);

export const financeCategoryListQuerySchema = z.object({
  type: financeEntryTypeSchema.optional(),
  search: z.string().trim().optional(),
});

export const createFinanceCategorySchema = z.object({
  name: z.string().trim().min(2).max(120),
  type: financeEntryTypeSchema,
  isActive: z.boolean().optional(),
});

export const updateFinanceCategorySchema = z
  .object({
    name: z.string().trim().min(2).max(120).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const financeEntryListQuerySchema = z.object({
  type: financeEntryTypeSchema.optional(),
  categoryId: z.string().optional(),
  studentId: z.string().optional(),
  search: z.string().trim().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  includeDeleted: z.coerce.boolean().optional().default(false),
});

export const createFinanceEntrySchema = z.object({
  type: financeEntryTypeSchema,
  categoryId: z.string().min(1),
  amount: z.number().positive(),
  occurredAt: z.string().min(4),
  description: z.string().trim().max(500).optional(),
  studentId: z.string().optional(),
});

export const updateFinanceEntrySchema = z
  .object({
    categoryId: z.string().optional(),
    amount: z.number().positive().optional(),
    occurredAt: z.string().optional(),
    description: z.string().trim().max(500).nullable().optional(),
    studentId: z.string().nullable().optional(),
    isDeleted: z.boolean().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const financeMonthlyReportQuerySchema = z.object({
  month: z.coerce.number().int().min(1).max(12),
  year: z.coerce.number().int().min(2000).max(2100),
});

