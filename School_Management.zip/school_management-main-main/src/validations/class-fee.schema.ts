import { z } from "zod";

export const classMonthlyFeeSchema = z.object({
  classId: z.string().trim().min(1),
  monthlyFee: z.number().nonnegative().nullable(),
  isActive: z.boolean().optional(),
});
