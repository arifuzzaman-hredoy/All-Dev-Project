import { z } from "zod";

export const updateSystemSettingSchema = z.object({
  key: z.string().trim().min(1, "Setting key is required"),
  value: z.union([
    z.record(z.string(), z.unknown()),
    z.array(z.unknown()),
    z.string(),
    z.number(),
    z.boolean(),
  ]),
});
