import { z } from "zod";

export const branchListQuerySchema = z.object({
  includeInactive: z
    .string()
    .optional()
    .transform((value) => value === "true"),
});

export const createBranchSchema = z.object({
  schoolId: z.string().min(1).optional(),
  name: z.string().trim().min(1).max(120),
  slug: z
    .string()
    .trim()
    .min(2)
    .max(60)
    .regex(/^[a-z0-9-]+$/, "slug must be lowercase letters, numbers, hyphen"),
  isActive: z.boolean().optional(),
});

export const updateBranchSchema = z.object({
  name: z.string().trim().min(1).max(120).optional(),
  slug: z
    .string()
    .trim()
    .min(2)
    .max(60)
    .regex(/^[a-z0-9-]+$/, "slug must be lowercase letters, numbers, hyphen")
    .optional(),
  isActive: z.boolean().optional(),
});
