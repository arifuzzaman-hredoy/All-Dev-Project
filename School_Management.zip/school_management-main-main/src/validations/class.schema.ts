import { z } from "zod";

export const classListQuerySchema = z.object({
  search: z.string().trim().optional(),
});

export const createClassSchema = z.object({
  name: z.string().trim().min(1).max(80),
  studentLimit: z.number().int().positive().nullable().optional(),
});

export const updateClassSchema = z.object({
  name: z.string().trim().min(1).max(80).optional(),
  studentLimit: z.number().int().positive().nullable().optional(),
});

export const reorderClassesSchema = z.object({
  orderedClassIds: z.array(z.string().min(1)).min(1),
});

export const groupListQuerySchema = z.object({
  search: z.string().trim().optional(),
});

export const createGroupSchema = z.object({
  name: z.string().trim().min(1).max(40),
  studentLimit: z.number().int().positive().nullable().optional(),
});

export const updateGroupSchema = z.object({
  name: z.string().trim().min(1).max(40).optional(),
  studentLimit: z.number().int().positive().nullable().optional(),
});
