import { z } from "zod";

export const resultListQuerySchema = z.object({
  search: z.string().trim().optional(),
  examId: z.string().optional(),
  studentId: z.string().optional(),
  classId: z.string().optional(),
  subjectId: z.string().optional(),
});

export const createResultSchema = z.object({
  studentId: z.string().min(1),
  examId: z.string().min(1),
  subjectId: z.string().min(1),
  marks: z.number().min(0).max(1000),
  grade: z.string().trim().max(8).optional(),
});

export const updateResultSchema = z
  .object({
    marks: z.number().min(0).max(1000).optional(),
    grade: z.string().trim().max(8).nullable().optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });
