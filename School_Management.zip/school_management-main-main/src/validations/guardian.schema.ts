import { z } from "zod";

export const guardianListQuerySchema = z.object({
  search: z.string().trim().optional(),
  unlinkedStudentsOnly: z.coerce.boolean().optional().default(false),
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(5).max(100).optional().default(20),
});

export const createGuardianSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8).max(128),
  phone: z.string().trim().min(6).max(30).optional(),
  address: z.string().trim().max(255).optional(),
  studentIds: z.array(z.string()).optional(),
});

export const updateGuardianSchema = z
  .object({
    name: z.string().trim().min(2).max(80).optional(),
    email: z.string().email().optional(),
    password: z.string().min(8).max(128).optional(),
    phone: z.string().trim().min(6).max(30).nullable().optional(),
    address: z.string().trim().max(255).nullable().optional(),
    studentIds: z.array(z.string()).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, {
    message: "Provide at least one field to update",
  });

export const updateGuardianProfileSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  phone: z.string().trim().min(6).max(30).nullable().optional(),
  address: z.string().trim().max(255).nullable().optional(),
});

export const transferGuardianStudentSchema = z.object({
  studentId: z.string().trim().min(1),
  currentGuardianId: z.string().trim().min(1),
  targetGuardianId: z.string().trim().min(1),
});
