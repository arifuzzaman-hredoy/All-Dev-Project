import { z } from "zod";

export const trashEntityTypeSchema = z.enum([
  "User",
  "Student",
  "Teacher",
  "Guardian",
]);

export const trashListQuerySchema = z.object({
  search: z.string().trim().optional(),
  entityType: trashEntityTypeSchema.optional(),
  limit: z.coerce.number().int().positive().max(200).optional(),
  page: z.coerce.number().int().positive().optional(),
});

export const trashRestoreSchema = z.object({
  entityType: trashEntityTypeSchema,
  entityId: z.string().min(1),
});

