import { z } from "zod";

export const studentGenderCountQuerySchema = z.object({
  classId: z.string().optional(),
});

