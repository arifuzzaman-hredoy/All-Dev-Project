import { z } from "zod";

export const subjectListQuerySchema = z.object({
  search: z.string().trim().optional(),
  classId: z.string().optional(),
});

export const createSubjectSchema = z.object({
  name: z.string().trim().min(1).max(80),
  classId: z.string().min(1),
});

export const updateSubjectSchema = z.object({
  name: z.string().trim().min(1).max(80).optional(),
  classId: z.string().optional(),
}).refine((value) => Object.keys(value).length > 0, {
  message: "Provide at least one field to update",
});
