import { z } from "zod";

const attendanceStatusEnum = z.enum(["PRESENT", "ABSENT", "LATE"]);

export const attendanceListQuerySchema = z.object({
  classId: z.string().optional(),
  studentId: z.string().optional(),
  subjectId: z.string().optional(),
  status: attendanceStatusEnum.optional(),
  date: z.string().optional(),
  search: z.string().trim().optional(),
});

export const attendanceEntrySchema = z.object({
  studentId: z.string().min(1),
  status: attendanceStatusEnum,
  remarks: z.string().trim().max(255).optional(),
});

export const upsertAttendanceSchema = z.object({
  date: z.string().min(1),
  subjectId: z.string().min(1),
  classId: z.string().min(1),
  period: z.number().int().positive().optional(),
  markedBy: z.string().optional(),
  entries: z.array(attendanceEntrySchema).min(1),
});
