import { Resend } from "resend";

export function getResendClient() {
  const apiKey = process.env.RESEND_API_KEY;

  if (!apiKey || apiKey.trim().length === 0) {
    return null;
  }

  return new Resend(apiKey);
}

export default getResendClient;
