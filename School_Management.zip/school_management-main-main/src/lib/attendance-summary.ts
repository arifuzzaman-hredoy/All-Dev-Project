export type AttendanceStatusValue = "PRESENT" | "ABSENT" | "LATE";

export type AttendanceSummaryItem = {
  date: Date | string;
  status: AttendanceStatusValue;
  subject?: { name: string } | null;
};

export type AttendanceSummary = {
  total: number;
  present: number;
  absent: number;
  late: number;
  attendanceRate: number;
  bySubject: Array<{
    subject: string;
    total: number;
    present: number;
    absent: number;
    late: number;
    attendanceRate: number;
  }>;
  byMonth: Array<{
    month: string;
    total: number;
    present: number;
    absent: number;
    late: number;
    attendanceRate: number;
  }>;
};

function emptyBucket() {
  return { total: 0, present: 0, absent: 0, late: 0 };
}

function addStatus(bucket: ReturnType<typeof emptyBucket>, status: AttendanceStatusValue) {
  bucket.total += 1;
  if (status === "PRESENT") bucket.present += 1;
  if (status === "ABSENT") bucket.absent += 1;
  if (status === "LATE") bucket.late += 1;
}

function rate(bucket: { total: number; present: number }) {
  return bucket.total > 0 ? Math.round((bucket.present / bucket.total) * 100) : 0;
}

function monthKey(date: Date | string) {
  const value = new Date(date);
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}`;
}

export function buildAttendanceSummary(
  records: AttendanceSummaryItem[],
): AttendanceSummary {
  const totals = emptyBucket();
  const subjects = new Map<string, ReturnType<typeof emptyBucket>>();
  const months = new Map<string, ReturnType<typeof emptyBucket>>();

  for (const record of records) {
    addStatus(totals, record.status);

    const subjectName = record.subject?.name ?? "General";
    const subjectBucket = subjects.get(subjectName) ?? emptyBucket();
    addStatus(subjectBucket, record.status);
    subjects.set(subjectName, subjectBucket);

    const key = monthKey(record.date);
    const monthBucket = months.get(key) ?? emptyBucket();
    addStatus(monthBucket, record.status);
    months.set(key, monthBucket);
  }

  return {
    ...totals,
    attendanceRate: rate(totals),
    bySubject: Array.from(subjects.entries())
      .map(([subject, bucket]) => ({
        subject,
        ...bucket,
        attendanceRate: rate(bucket),
      }))
      .sort((left, right) => left.subject.localeCompare(right.subject)),
    byMonth: Array.from(months.entries())
      .map(([month, bucket]) => ({
        month,
        ...bucket,
        attendanceRate: rate(bucket),
      }))
      .sort((left, right) => left.month.localeCompare(right.month)),
  };
}
