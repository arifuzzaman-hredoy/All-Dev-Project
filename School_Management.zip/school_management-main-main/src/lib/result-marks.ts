const DEFAULT_TOTAL_MARKS = 100;

type ExamSubjectMarksConfig = {
  classId: string;
  subjectId: string;
  fullMarks: number | null;
  components?: Array<{
    fullMarks: number | null;
  }>;
};

function validPositiveMark(value: number | null | undefined): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

export function getExamSubjectTotalMarks(
  config: ExamSubjectMarksConfig | null | undefined,
) {
  const fullMarks = config?.fullMarks;
  if (validPositiveMark(fullMarks)) {
    return fullMarks;
  }

  const componentTotal =
    config?.components?.reduce(
      (total, component) => total + (component.fullMarks ?? 0),
      0,
    ) ?? 0;

  return validPositiveMark(componentTotal) ? componentTotal : DEFAULT_TOTAL_MARKS;
}

export function resolveTotalMarksFromExamSubjects(
  subjects: ExamSubjectMarksConfig[] | null | undefined,
  classId: string | null | undefined,
  subjectId: string | null | undefined,
) {
  const config = subjects?.find(
    (item) => item.classId === classId && item.subjectId === subjectId,
  );

  return getExamSubjectTotalMarks(config);
}

export function deriveGradeFromMarks(marks: number, totalMarks = DEFAULT_TOTAL_MARKS) {
  const percentage = totalMarks > 0 ? (marks / totalMarks) * 100 : marks;

  if (percentage >= 90) return "A";
  if (percentage >= 80) return "A-";
  if (percentage >= 70) return "B+";
  if (percentage >= 60) return "B";
  if (percentage >= 50) return "C";
  return "D";
}
