import { readAuth } from "@/utils/auth-storage";

let syncedToken: string | null = null;

async function ensureServerSession(token: string) {
  if (syncedToken === token) {
    return;
  }

  const response = await fetch("/api/v1/auth/session", {
    method: "POST",
    credentials: "include",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error("Unable to initialize authenticated session");
  }

  syncedToken = token;
}

export async function fetchWithAuth<T>(
  input: string,
  init: RequestInit = {}
) {
  const auth = readAuth();

  if (!auth?.token) {
    throw new Error("Please log in to continue");
  }

  await ensureServerSession(auth.token);

  const response = await fetch(input, {
    ...init,
    credentials: "include",
    headers: {
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...(init.headers ?? {}),
      Authorization: `Bearer ${auth.token}`,
    },
  });

  const payload = await response.json();

  if (!response.ok || !payload.success) {
    throw new Error(payload.message ?? "Request failed");
  }

  return payload.data as T;
}

export async function downloadWithAuth(input: string, filename?: string) {
  const auth = readAuth();

  if (!auth?.token) {
    throw new Error("Please log in to continue");
  }

  await ensureServerSession(auth.token);

  const response = await fetch(input, {
    credentials: "include",
    headers: {
      Authorization: `Bearer ${auth.token}`,
    },
  });

  if (!response.ok) {
    let message = "Download failed";
    try {
      const payload = await response.json();
      message = payload.message ?? message;
    } catch {
      // Ignore non-JSON responses and keep fallback message.
    }
    throw new Error(message);
  }

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download =
    filename ??
    response.headers.get("Content-Disposition")?.match(/filename="?(.*?)"?$/)?.[1] ??
    "download";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
