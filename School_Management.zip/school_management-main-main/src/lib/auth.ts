import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import type { Role } from "@prisma/client";
import type { ResponseCookie } from "next/dist/compiled/@edge-runtime/cookies";
import { HttpError } from "@/utils/error-handler";
import type { NextRequest } from "next/server";
import { setAuthRequestContext } from "@/lib/request-context";

const TOKEN_SECRET = process.env.JWT_SECRET ?? "change-me-in-production";
const TOKEN_EXPIRATION = "7d";
export const AUTH_COOKIE_NAME = "school_erp_session";

export interface TokenPayload {
  id: string;
  role: Role;
  branchId?: string | null;
}

/**
 * Hashes a raw password before persisting it.
 */
export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

/**
 * Compares a stored hash with an incoming password attempt.
 */
export async function comparePassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

/**
 * Builds a JWT for the authenticated user payload.
 */
export function generateToken(payload: TokenPayload) {
  return jwt.sign(payload, TOKEN_SECRET, { expiresIn: TOKEN_EXPIRATION });
}

/**
 * Verifies the token and returns the decoded payload.
 */
export function verifyToken(token: string) {
  return jwt.verify(token, TOKEN_SECRET) as TokenPayload;
}

const AUTH_HEADER = "authorization";

function parseBearer(tokenHeader: string | null) {
  if (!tokenHeader) return null;
  const segments = tokenHeader.split(" ");
  if (segments.length !== 2 || segments[0].toLowerCase() !== "bearer") {
    return null;
  }
  return segments[1];
}

export function getAuthCookieOptions(): Partial<ResponseCookie> {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  };
}

export function requireAuth(req?: NextRequest | null) {
  const headerValue = req?.headers?.get?.(AUTH_HEADER) ?? null;
  const token =
    parseBearer(headerValue) ??
    req?.cookies?.get?.(AUTH_COOKIE_NAME)?.value ??
    null;

  if (!token) {
    throw new HttpError("Authentication token missing", 401);
  }

  try {
    const payload = verifyToken(token);
    setAuthRequestContext(payload);
    return payload;
  } catch {
    throw new HttpError("Invalid authentication token", 401);
  }
}
