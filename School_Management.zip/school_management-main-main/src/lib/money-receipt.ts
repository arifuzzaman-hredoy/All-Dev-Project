type MoneyReceiptPayment = {
  id: string;
  amountPaid: number;
  status: string;
  paymentMethod: string | null;
  transactionId: string | null;
  billingMonth: number;
  billingYear: number;
  month?: number | null;
  year?: number | null;
  dueDate: string | Date | null;
  createdAt: string | Date;
  billingPeriodLabel: string;
  monthlyFeeDue: number;
  extraCategoryDue: number;
  totalAmount: number;
  dueAmount: number;
  feeCategory: {
    name: string;
  };
  student: {
    user: {
      name: string;
    };
    class: {
      name: string;
    };
  };
};

type MoneyReceiptOptions = {
  schoolName?: string;
};

function escapeHtml(value: string | number | null | undefined) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatMoney(value: number) {
  return `Tk. ${new Intl.NumberFormat("en-IN").format(value)}`;
}

function formatDateTime(value: string | Date | null | undefined) {
  if (!value) return "-";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function formatDate(value: string | Date | null | undefined) {
  if (!value) return "-";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
  }).format(date);
}

function buildReceiptNumber(payment: MoneyReceiptPayment) {
  const month = payment.billingMonth ?? payment.month ?? 0;
  const year = payment.billingYear ?? payment.year ?? new Date().getFullYear();
  return `MR-${year}${String(month).padStart(2, "0")}-${payment.id.slice(-6).toUpperCase()}`;
}

export function buildMoneyReceiptHtml(
  payment: MoneyReceiptPayment,
  options: MoneyReceiptOptions = {},
) {
  const schoolName = options.schoolName?.trim() || "School ERP";
  const receiptNumber = buildReceiptNumber(payment);
  const generatedAt = formatDateTime(new Date());

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Money Receipt - ${escapeHtml(payment.student.user.name)}</title>
    <style>
      :root {
        color-scheme: light;
      }
      * {
        box-sizing: border-box;
      }
      body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
        background: #eef2ff;
        color: #111827;
      }
      .page {
        max-width: 920px;
        margin: 0 auto;
        padding: 24px;
      }
      .receipt {
        background: #ffffff;
        border: 1px solid #dbeafe;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
      }
      .header {
        background: linear-gradient(135deg, #0f172a, #1d4ed8);
        color: #ffffff;
        padding: 28px 32px;
      }
      .header-row {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 16px;
        align-items: flex-start;
      }
      .school-name {
        margin: 0;
        font-size: 28px;
        font-weight: 700;
      }
      .subtitle {
        margin: 8px 0 0;
        color: rgba(255, 255, 255, 0.85);
        font-size: 14px;
        line-height: 1.6;
      }
      .receipt-title {
        text-align: right;
      }
      .receipt-title h1 {
        margin: 0;
        font-size: 26px;
        letter-spacing: 0.04em;
      }
      .receipt-title p {
        margin: 6px 0 0;
        font-size: 13px;
        color: rgba(255, 255, 255, 0.9);
      }
      .content {
        padding: 28px 32px 32px;
      }
      .meta-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 24px;
      }
      .meta-box {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px;
        background: #f8fafc;
      }
      .meta-label {
        display: block;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #64748b;
        margin-bottom: 8px;
      }
      .meta-value {
        font-size: 14px;
        font-weight: 700;
        color: #0f172a;
      }
      .section {
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 20px;
        margin-bottom: 18px;
      }
      .section h2 {
        margin: 0 0 16px;
        font-size: 16px;
        color: #0f172a;
      }
      .detail-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px 18px;
      }
      .detail {
        padding: 12px 14px;
        border-radius: 12px;
        background: #f8fafc;
      }
      .detail span {
        display: block;
      }
      .detail .label {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #64748b;
        margin-bottom: 6px;
      }
      .detail .value {
        font-size: 14px;
        font-weight: 700;
        color: #111827;
      }
      .money-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
      }
      .money-card {
        border-radius: 16px;
        padding: 16px;
        background: #f8fafc;
        border: 1px solid #e5e7eb;
      }
      .money-card .label {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #64748b;
        margin-bottom: 8px;
      }
      .money-card .value {
        font-size: 18px;
        font-weight: 800;
        color: #0f172a;
      }
      .money-card.highlight {
        background: #eff6ff;
        border-color: #bfdbfe;
      }
      .summary {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 16px;
      }
      .footer {
        padding: 0 32px 28px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
      }
      .sign-box {
        border-top: 1px dashed #cbd5e1;
        padding-top: 18px;
        color: #475569;
        font-size: 13px;
      }
      .sign-line {
        height: 36px;
      }
      .note {
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 16px;
        background: #f8fafc;
        font-size: 13px;
        color: #334155;
        line-height: 1.6;
      }
      .status-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border-radius: 999px;
        padding: 6px 12px;
        background: #dbeafe;
        color: #1d4ed8;
        font-size: 12px;
        font-weight: 700;
      }
      .muted {
        color: #64748b;
        font-size: 12px;
      }
      @media print {
        body {
          background: #ffffff;
        }
        .page {
          padding: 0;
        }
        .receipt {
          box-shadow: none;
          border-radius: 0;
          border: none;
        }
      }
      @media (max-width: 800px) {
        .meta-grid,
        .money-grid,
        .summary,
        .footer,
        .detail-grid {
          grid-template-columns: 1fr;
        }
        .receipt-title {
          text-align: left;
        }
      }
    </style>
  </head>
  <body>
    <div class="page">
      <div class="receipt">
        <div class="header">
          <div class="header-row">
            <div>
              <p class="school-name">${escapeHtml(schoolName)}</p>
              <p class="subtitle">
                Official Money Receipt
                <br />
                Student fees and payment acknowledgements
              </p>
            </div>
            <div class="receipt-title">
              <h1>Money Receipt</h1>
              <p>Receipt No: ${escapeHtml(receiptNumber)}</p>
            </div>
          </div>
        </div>

        <div class="content">
          <div class="meta-grid">
            <div class="meta-box">
              <span class="meta-label">Generated At</span>
              <span class="meta-value">${escapeHtml(generatedAt)}</span>
            </div>
            <div class="meta-box">
              <span class="meta-label">Payment Date</span>
              <span class="meta-value">${escapeHtml(formatDateTime(payment.createdAt))}</span>
            </div>
            <div class="meta-box">
              <span class="meta-label">Billing Period</span>
              <span class="meta-value">${escapeHtml(payment.billingPeriodLabel)}</span>
            </div>
            <div class="meta-box">
              <span class="meta-label">Status</span>
              <span class="meta-value">${escapeHtml(payment.status)}</span>
            </div>
          </div>

          <div class="section">
            <h2>Student and Payment Details</h2>
            <div class="detail-grid">
              <div class="detail">
                <span class="label">Student Name</span>
                <span class="value">${escapeHtml(payment.student.user.name)}</span>
              </div>
              <div class="detail">
                <span class="label">Class</span>
                <span class="value">${escapeHtml(payment.student.class.name)}</span>
              </div>
              <div class="detail">
                <span class="label">Fee Category</span>
                <span class="value">${escapeHtml(payment.feeCategory.name)}</span>
              </div>
              <div class="detail">
                <span class="label">Payment Method</span>
                <span class="value">${escapeHtml(payment.paymentMethod ?? "-")}</span>
              </div>
              <div class="detail">
                <span class="label">Transaction ID</span>
                <span class="value">${escapeHtml(payment.transactionId ?? "-")}</span>
              </div>
              <div class="detail">
                <span class="label">Due Date</span>
                <span class="value">${escapeHtml(formatDate(payment.dueDate))}</span>
              </div>
            </div>
          </div>

          <div class="section">
            <h2>Money Breakdown</h2>
            <div class="money-grid">
              <div class="money-card">
                <div class="label">Monthly Due</div>
                <div class="value">${escapeHtml(formatMoney(payment.monthlyFeeDue))}</div>
              </div>
              <div class="money-card">
                <div class="label">Extra Category Due</div>
                <div class="value">${escapeHtml(formatMoney(payment.extraCategoryDue))}</div>
              </div>
              <div class="money-card highlight">
                <div class="label">Total Amount</div>
                <div class="value">${escapeHtml(formatMoney(payment.totalAmount))}</div>
              </div>
              <div class="money-card highlight">
                <div class="label">Amount Paid</div>
                <div class="value">${escapeHtml(formatMoney(payment.amountPaid))}</div>
              </div>
            </div>
          </div>

          <div class="summary">
            <div class="note">
              <strong>Payment Summary</strong><br />
              This money receipt confirms that ${escapeHtml(payment.student.user.name)} has made a payment for ${escapeHtml(payment.billingPeriodLabel)} under ${escapeHtml(payment.feeCategory.name)}.
              The receipt can be used for record keeping and print archive.
            </div>
            <div class="section" style="margin: 0;">
              <h2 style="margin-bottom: 10px;">Balance Status</h2>
              <div class="status-pill">${escapeHtml(payment.dueAmount > 0 ? "PARTIAL / DUE" : "PAID")}</div>
              <p class="muted" style="margin-top: 10px;">
                Remaining due: ${escapeHtml(formatMoney(payment.dueAmount))}
              </p>
            </div>
          </div>
        </div>

        <div class="footer">
          <div class="sign-box">
            <div class="sign-line"></div>
            <strong>Receiver Signature</strong><br />
            Accounts / Cashier
          </div>
          <div class="sign-box">
            <div class="sign-line"></div>
            <strong>Student / Guardian Signature</strong><br />
            Acknowledged the above payment
          </div>
        </div>
      </div>
    </div>
  </body>
</html>`;
}