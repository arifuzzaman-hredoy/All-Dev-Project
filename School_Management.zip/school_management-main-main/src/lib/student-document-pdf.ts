import type { StudentDocumentRecord } from "@/repositories/student.repository";
import type { StudentDocumentType } from "@/lib/student-document";
import {
  normalizeStudentDocumentTemplate,
  type StudentDocumentTemplateConfig,
} from "@/lib/student-document-template";
import {
  buildCharacterCertificatePdfBuffer,
} from "@/lib/student-document-pdf-modules/character-certificate";
import {
  buildTestimonialCertificatePdfBuffer,
} from "@/lib/student-document-pdf-modules/testimonial";
import {
  buildTransferCertificatePdfBuffer,
} from "@/lib/student-document-pdf-modules/transfer-certificate";
import type { StudentDocumentOptions } from "@/lib/student-document-pdf-modules/common";

export type { StudentDocumentOptions } from "@/lib/student-document-pdf-modules/common";

export async function buildStudentDocumentPdfBuffer(
  student: StudentDocumentRecord,
  type: StudentDocumentType,
  options: StudentDocumentOptions = {},
  templateInput: StudentDocumentTemplateConfig | unknown = {},
) {
  const template = normalizeStudentDocumentTemplate(templateInput);

  switch (type) {
    case "testimonial":
      return buildTestimonialCertificatePdfBuffer(student, options, template);
    case "tc":
      return buildTransferCertificatePdfBuffer(student, options, template);
    default:
      return buildCharacterCertificatePdfBuffer(student, options, template);
  }
}
