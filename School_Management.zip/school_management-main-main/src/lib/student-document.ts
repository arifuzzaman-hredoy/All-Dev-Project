import type { StudentDocumentRecord } from "@/repositories/student.repository";

export type StudentDocumentType = "testimonial" | "tc" | "character";

type StudentDocumentOptions = {
  schoolName?: string;
};

const documentMeta: Record<
  StudentDocumentType,
  {
    title: string;
    shortTitle: string;
    subject: string;
    body: (student: StudentDocumentRecord) => string;
  }
> = {
  testimonial: {
    title: "Testimonial",
    shortTitle: "Testimonial",
    subject: "Application for testimonial",
    body: (student) =>
      `This is to certify that ${escapeHtml(student.user.name)} of class ${escapeHtml(student.class.name)} (Roll ${escapeHtml(formatRollNumber(student.rollNumber))}) has been a student of this institution since ${escapeHtml(formatDate(student.createdAt))}. According to school records, the student has maintained satisfactory conduct and discipline throughout the academic period.`,
  },
  tc: {
    title: "Transfer Certificate",
    shortTitle: "TC",
    subject: "Transfer certificate request",
    body: (student) =>
      `This is to certify that ${escapeHtml(student.user.name)} of class ${escapeHtml(student.class.name)} (Roll ${escapeHtml(formatRollNumber(student.rollNumber))}) was enrolled in this institution from ${escapeHtml(formatDate(student.createdAt))}. This certificate is issued on the basis of the official student record for admission elsewhere.`,
  },
  character: {
    title: "Character Certificate",
    shortTitle: "Character Certificate",
    subject: "Character certificate request",
    body: (student) =>
      `This is to certify that ${escapeHtml(student.user.name)} of class ${escapeHtml(student.class.name)} (Roll ${escapeHtml(formatRollNumber(student.rollNumber))}) has been known to the school administration as a disciplined and respectful student. This certificate is issued from the official student record and school conduct file.`,
  },
};

function escapeHtml(value: string | number | null | undefined) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatDate(value: string | Date | null | undefined) {
  if (!value) return "-";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
  }).format(date);
}

function formatDateTime(value: string | Date | null | undefined) {
  if (!value) return "-";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function formatRollNumber(value: number | null | undefined) {
  return value === null || value === undefined ? "N/A" : String(value);
}

function genderLabel(value: StudentDocumentRecord["gender"]) {
  switch (value) {
    case "MALE":
      return "Male";
    case "FEMALE":
      return "Female";
    default:
      return "Other";
  }
}

function documentNumber(student: StudentDocumentRecord, type: StudentDocumentType) {
  const year = new Date(student.createdAt).getFullYear();
  return `DOC-${type.toUpperCase()}-${year}-${student.id.slice(-6).toUpperCase()}`;
}

function documentLabel(type: StudentDocumentType) {
  return documentMeta[type].title;
}

export function buildStudentDocumentHtml(
  student: StudentDocumentRecord,
  type: StudentDocumentType,
  options: StudentDocumentOptions = {},
) {
  const schoolName = options.schoolName?.trim() || "School ERP";
  const meta = documentMeta[type];
  const generatedAt = formatDateTime(new Date());
  const docNumber = documentNumber(student, type);
  const contactName = student.guardian?.name ?? student.parent?.user.name ?? "N/A";
  const contactPhone = student.guardian?.phone ?? student.parent?.phone ?? student.phone ?? "N/A";
  const contactAddress = student.guardian?.address ?? student.parent?.address ?? "N/A";
  const groupName = student.group?.name ?? "General";
  const sectionName = student.section?.name ?? "Default";

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${escapeHtml(meta.title)} - ${escapeHtml(student.user.name)}</title>
    <style>
      * { box-sizing: border-box; }
      body {
        margin: 0;
        background: #f8fafc;
        color: #0f172a;
        font-family: "Times New Roman", Times, serif;
      }
      .page {
        max-width: 960px;
        margin: 0 auto;
        padding: 24px;
      }
      .document {
        position: relative;
        overflow: hidden;
        background: #fffdf8;
        border: 2px solid #cbd5e1;
        border-radius: 22px;
        padding: 28px 32px 30px;
        box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
      }
      .document::before {
        content: "${escapeHtml(schoolName)}";
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        font-size: 68px;
        font-weight: 700;
        color: rgba(148, 163, 184, 0.08);
        transform: rotate(-18deg);
        pointer-events: none;
        white-space: nowrap;
      }
      .header {
        position: relative;
        text-align: center;
        border-bottom: 3px double #1d4ed8;
        padding-bottom: 18px;
        margin-bottom: 22px;
      }
      .school-name {
        margin: 0;
        font-size: 30px;
        font-weight: 700;
        letter-spacing: 0.02em;
      }
      .subheading {
        margin: 8px 0 0;
        font-size: 14px;
        color: #475569;
        line-height: 1.6;
      }
      .badge-row {
        display: flex;
        justify-content: center;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 14px;
      }
      .badge {
        border: 1px solid #93c5fd;
        background: #eff6ff;
        color: #1d4ed8;
        padding: 6px 12px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .meta-grid {
        position: relative;
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 18px;
      }
      .meta-card {
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        background: rgba(248, 250, 252, 0.92);
        padding: 12px 14px;
      }
      .meta-label {
        display: block;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #64748b;
        margin-bottom: 6px;
      }
      .meta-value {
        font-size: 14px;
        font-weight: 700;
      }
      .section {
        position: relative;
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 20px 22px;
        background: rgba(255, 255, 255, 0.94);
        margin-bottom: 16px;
      }
      .section h2 {
        margin: 0 0 12px;
        font-size: 16px;
        color: #0f172a;
      }
      .detail-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }
      .detail {
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 12px 14px;
        background: #f8fafc;
      }
      .detail span {
        display: block;
      }
      .detail .label {
        font-size: 11px;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        color: #64748b;
        margin-bottom: 6px;
      }
      .detail .value {
        font-size: 14px;
        font-weight: 700;
        color: #0f172a;
      }
      .letter {
        position: relative;
        line-height: 1.9;
        font-size: 16px;
        color: #111827;
        text-align: justify;
      }
      .letter p {
        margin: 0 0 12px;
      }
      .sign-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 20px;
        margin-top: 22px;
      }
      .sign-box {
        border-top: 1px dashed #94a3b8;
        padding-top: 14px;
        min-height: 78px;
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 12px;
        color: #334155;
        font-size: 13px;
      }
      .signature-label {
        font-weight: 700;
      }
      .footer {
        position: relative;
        display: flex;
        justify-content: space-between;
        gap: 12px;
        margin-top: 20px;
        font-size: 12px;
        color: #475569;
      }
      .footer-note {
        max-width: 58ch;
        line-height: 1.6;
      }
      @media print {
        body { background: #fff; }
        .page { padding: 0; max-width: none; }
        .document { border-radius: 0; box-shadow: none; border: 0; }
      }
    </style>
  </head>
  <body>
    <main class="page">
      <article class="document">
        <header class="header">
          <h1 class="school-name">${escapeHtml(schoolName)}</h1>
          <p class="subheading">Official Academic Document</p>
          <div class="badge-row">
            <span class="badge">${escapeHtml(meta.shortTitle)}</span>
            <span class="badge">${escapeHtml(meta.subject)}</span>
          </div>
        </header>

        <div class="meta-grid">
          <div class="meta-card">
            <span class="meta-label">Document No</span>
            <span class="meta-value">${escapeHtml(docNumber)}</span>
          </div>
          <div class="meta-card">
            <span class="meta-label">Student ID</span>
            <span class="meta-value">${escapeHtml(student.id)}</span>
          </div>
          <div class="meta-card">
            <span class="meta-label">Generated At</span>
            <span class="meta-value">${escapeHtml(generatedAt)}</span>
          </div>
          <div class="meta-card">
            <span class="meta-label">Admission Date</span>
            <span class="meta-value">${escapeHtml(formatDate(student.createdAt))}</span>
          </div>
        </div>

        <section class="section">
          <h2>${escapeHtml(documentLabel(type))}</h2>
          <div class="letter">
            <p>${meta.body(student)}</p>
            <p>
              This certificate is prepared from the live student record in the school ERP and may be verified through the academic office at any time.
            </p>
          </div>
        </section>

        <section class="section">
          <h2>Student Profile</h2>
          <div class="detail-grid">
            <div class="detail"><span class="label">Student Name</span><span class="value">${escapeHtml(student.user.name)}</span></div>
            <div class="detail"><span class="label">Class</span><span class="value">${escapeHtml(student.class.name)}</span></div>
            <div class="detail"><span class="label">Roll Number</span><span class="value">${escapeHtml(formatRollNumber(student.rollNumber))}</span></div>
            <div class="detail"><span class="label">Gender</span><span class="value">${escapeHtml(genderLabel(student.gender))}</span></div>
            <div class="detail"><span class="label">Group</span><span class="value">${escapeHtml(groupName)}</span></div>
            <div class="detail"><span class="label">Section</span><span class="value">${escapeHtml(sectionName)}</span></div>
              <div class="detail"><span class="label">Guardian</span><span class="value">${escapeHtml(contactName)}</span></div>
              <div class="detail"><span class="label">Contact</span><span class="value">${escapeHtml(contactPhone)}</span></div>
              <div class="detail" style="grid-column: 1 / -1;"><span class="label">Address</span><span class="value">${escapeHtml(contactAddress)}</span></div>
          </div>
        </section>

        <div class="sign-grid">
          <div class="sign-box">
            <span>Prepared by Academic Office</span>
            <span class="signature-label">Authorized Signature</span>
          </div>
          <div class="sign-box">
            <span>Checked and approved</span>
            <span class="signature-label">Principal / Head Teacher</span>
          </div>
        </div>

        <div class="footer">
          <div class="footer-note">
            <strong>Note:</strong> This document is generated automatically from the current student profile in the system. For manual corrections, update the student record before reissuing.
          </div>
          <div>Issue date: ${escapeHtml(formatDateTime(new Date()))}</div>
        </div>
      </article>
    </main>
  </body>
</html>`;
}
