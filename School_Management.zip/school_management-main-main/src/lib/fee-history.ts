import {
  getClassMonthlyFee,
  getFeeAllocation,
  getPaymentTotalAmount,
} from "@/lib/fee-utils";

type FeePaymentSource = {
  id: string;
  amountPaid: number;
  status: "PAID" | "PARTIAL" | "DUE";
  paymentMethod: string | null;
  transactionId: string | null;
  month: number | null;
  year: number | null;
  dueDate: Date | string | null;
  createdAt: Date | string;
  feeCategory: {
    id: string;
    name: string;
    amount: number;
  };
  monthlyFeeSnapshot?: number | null;
  feeAmountSnapshot?: number | null;
  student: {
    id: string;
    user: {
      name: string;
    };
    class: {
      name: string;
      monthlyFeeSetting?: {
        monthlyFee: number | null;
        isActive?: boolean;
      } | null;
    };
  };
};

export type FeeTransactionRecord = Omit<
  FeePaymentSource,
  "createdAt" | "dueDate"
> & {
  createdAt: string;
  dueDate: string | null;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  totalAmount: number;
  dueAmount: number;
  billingMonth: number;
  billingYear: number;
  billingPeriodKey: string;
  billingPeriodLabel: string;
};

export type FeeHistoryRecord = {
  key: string;
  studentId: string;
  studentName: string;
  className: string;
  month: number;
  year: number;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: FeeTransactionRecord[];
};

export type FeeLedger = {
  payments: FeeTransactionRecord[];
  history: FeeHistoryRecord[];
};

const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function toDate(value: Date | string | null | undefined) {
  if (!value) {
    return null;
  }

  return value instanceof Date ? value : new Date(value);
}

function formatBillingPeriod(month: number, year: number) {
  const monthLabel = monthNames[month - 1] ?? `Month ${month}`;
  return `${monthLabel} ${year}`;
}

export function buildFeeLedger(payments: FeePaymentSource[]): FeeLedger {
  const enrichedPayments = payments.map((payment) => {
    const createdAt = toDate(payment.createdAt) ?? new Date();
    const billingMonth = payment.month ?? createdAt.getMonth() + 1;
    const billingYear = payment.year ?? createdAt.getFullYear();
    const monthlyFeeSetting = payment.student.class.monthlyFeeSetting;
    const monthlyFeeBase = getClassMonthlyFee(
      monthlyFeeSetting?.isActive === false
        ? 0
        : (payment.monthlyFeeSnapshot ?? monthlyFeeSetting?.monthlyFee),
    );
    const categoryFee = payment.feeAmountSnapshot ?? payment.feeCategory.amount;
    const allocation = getFeeAllocation(
      monthlyFeeBase,
      categoryFee,
      payment.amountPaid,
    );
    const totalAmount = getPaymentTotalAmount(monthlyFeeBase, categoryFee);
    const dueAmount = allocation.dueAmount;

    return {
      ...payment,
      createdAt: createdAt.toISOString(),
      dueDate: toDate(payment.dueDate)?.toISOString() ?? null,
      monthlyFeeBase,
      monthlyFeeDue: allocation.monthlyFeeDue,
      categoryFee,
      extraCategoryDue: allocation.categoryDue,
      totalAmount,
      dueAmount,
      billingMonth,
      billingYear,
      billingPeriodKey: `${payment.student.id}:${billingYear}-${String(billingMonth).padStart(2, "0")}`,
      billingPeriodLabel: formatBillingPeriod(billingMonth, billingYear),
    };
  });

  const historyMap = new Map<string, FeeHistoryRecord>();
  const seenCategoriesMap = new Map<string, Set<string>>();

  for (const payment of enrichedPayments) {
    const existing = historyMap.get(payment.billingPeriodKey);
    if (existing) {
      const seenCategories =
        seenCategoriesMap.get(payment.billingPeriodKey) ?? new Set<string>();

      if (!seenCategories.has(payment.feeCategory.id)) {
        existing.extraCategoryFees += payment.categoryFee;
        seenCategories.add(payment.feeCategory.id);
        seenCategoriesMap.set(payment.billingPeriodKey, seenCategories);
      }

      existing.amountPaid += payment.amountPaid;
      existing.totalExpected =
        existing.monthlyFeeBase + existing.extraCategoryFees;
      existing.monthlyFeeDue = Math.max(
        existing.monthlyFeeBase - existing.amountPaid,
        0,
      );
      existing.extraCategoryDue = Math.max(
        existing.extraCategoryFees -
          Math.max(existing.amountPaid - existing.monthlyFeeBase, 0),
        0,
      );
      existing.dueAmount = existing.monthlyFeeDue + existing.extraCategoryDue;
      existing.transactions.push(payment);
      continue;
    }

    historyMap.set(payment.billingPeriodKey, {
      key: payment.billingPeriodKey,
      studentId: payment.student.id,
      studentName: payment.student.user.name,
      className: payment.student.class.name,
      month: payment.billingMonth,
      year: payment.billingYear,
      label: payment.billingPeriodLabel,
      monthlyFeeBase: payment.monthlyFeeBase,
      monthlyFeeDue: payment.monthlyFeeDue,
      extraCategoryFees: payment.categoryFee,
      extraCategoryDue: payment.extraCategoryDue,
      totalExpected: payment.totalAmount,
      amountPaid: payment.amountPaid,
      dueAmount: payment.dueAmount,
      transactions: [payment],
    });
    seenCategoriesMap.set(
      payment.billingPeriodKey,
      new Set([payment.feeCategory.id]),
    );
  }

  const history = Array.from(historyMap.values()).sort((left, right) => {
    if (left.year !== right.year) {
      return right.year - left.year;
    }

    if (left.month !== right.month) {
      return right.month - left.month;
    }

    return left.studentName.localeCompare(right.studentName);
  });

  for (const entry of history) {
    entry.transactions.sort((left, right) => {
      if (left.createdAt !== right.createdAt) {
        return right.createdAt.localeCompare(left.createdAt);
      }

      return left.id.localeCompare(right.id);
    });
  }

  return {
    payments: enrichedPayments,
    history,
  };
}
