import type { Role } from "@prisma/client";
import { ROLE_DEFINITIONS } from "@/constants/roles";

export function getDashboardRoute(role?: Role | null) {
  if (!role) {
    return "/";
  }

  return ROLE_DEFINITIONS[role]?.dashboardRoute ?? "/";
}