export type StudentDocumentTemplateConfig = {
  schoolName: string;
  headerTitle: string;
  headerSubtitle: string;
  watermarkText: string;
  noteText: string;
  footerLeftText: string;
  footerRightText: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  surfaceColor: string;
  borderColor: string;
};

export type RgbTuple = [number, number, number];

export const STUDENT_DOCUMENT_TEMPLATE_KEY = "student_document_template";

export const DEFAULT_STUDENT_DOCUMENT_TEMPLATE: StudentDocumentTemplateConfig = {
  schoolName: "School ERP Academy",
  headerTitle: "Official Academic Document",
  headerSubtitle: "Custom certificate design",
  watermarkText: "School ERP",
  noteText:
    "This PDF is generated automatically from the current student profile in the system. For manual corrections, update the student record before reissuing.",
  footerLeftText: "Prepared by Academic Office",
  footerRightText: "Principal / Head Teacher",
  primaryColor: "#0f172a",
  secondaryColor: "#1d4ed8",
  accentColor: "#60a5fa",
  backgroundColor: "#f8fafc",
  surfaceColor: "#ffffff",
  borderColor: "#cbd5e1",
};

const HEX_COLOR_PATTERN = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

export function isHexColor(value: string) {
  return HEX_COLOR_PATTERN.test(value.trim());
}

export function normalizeHexColor(
  value: string | null | undefined,
  fallback: string,
) {
  const trimmed = value?.trim();
  return trimmed && isHexColor(trimmed) ? trimmed : fallback;
}

export function hexToRgbTuple(value: string): RgbTuple {
  const hex = value.replace(/^#/, "");
  const expanded = hex.length === 3
    ? hex.split("").map((char) => `${char}${char}`).join("")
    : hex;

  const red = Number.parseInt(expanded.slice(0, 2), 16) / 255;
  const green = Number.parseInt(expanded.slice(2, 4), 16) / 255;
  const blue = Number.parseInt(expanded.slice(4, 6), 16) / 255;

  return [red, green, blue];
}

export function normalizeStudentDocumentTemplate(
  value: unknown,
): StudentDocumentTemplateConfig {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return DEFAULT_STUDENT_DOCUMENT_TEMPLATE;
  }

  const candidate = value as Partial<StudentDocumentTemplateConfig>;

  return {
    schoolName: candidate.schoolName?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.schoolName,
    headerTitle: candidate.headerTitle?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.headerTitle,
    headerSubtitle:
      candidate.headerSubtitle?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.headerSubtitle,
    watermarkText: candidate.watermarkText?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.watermarkText,
    noteText: candidate.noteText?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.noteText,
    footerLeftText:
      candidate.footerLeftText?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.footerLeftText,
    footerRightText:
      candidate.footerRightText?.trim() || DEFAULT_STUDENT_DOCUMENT_TEMPLATE.footerRightText,
    primaryColor: normalizeHexColor(candidate.primaryColor, DEFAULT_STUDENT_DOCUMENT_TEMPLATE.primaryColor),
    secondaryColor: normalizeHexColor(candidate.secondaryColor, DEFAULT_STUDENT_DOCUMENT_TEMPLATE.secondaryColor),
    accentColor: normalizeHexColor(candidate.accentColor, DEFAULT_STUDENT_DOCUMENT_TEMPLATE.accentColor),
    backgroundColor: normalizeHexColor(
      candidate.backgroundColor,
      DEFAULT_STUDENT_DOCUMENT_TEMPLATE.backgroundColor,
    ),
    surfaceColor: normalizeHexColor(candidate.surfaceColor, DEFAULT_STUDENT_DOCUMENT_TEMPLATE.surfaceColor),
    borderColor: normalizeHexColor(candidate.borderColor, DEFAULT_STUDENT_DOCUMENT_TEMPLATE.borderColor),
  };
}
