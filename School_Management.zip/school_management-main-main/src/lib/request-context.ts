import { AsyncLocalStorage } from "node:async_hooks";
import type { Role } from "@prisma/client";

export type AuthRequestContext = {
  id: string;
  role: Role;
  branchId?: string | null;
};

const authContext = new AsyncLocalStorage<AuthRequestContext>();

export function setAuthRequestContext(context: AuthRequestContext) {
  authContext.enterWith(context);
}

export function getAuthRequestContext() {
  return authContext.getStore() ?? null;
}

export function getScopedBranchId() {
  const context = getAuthRequestContext();
  if (!context?.branchId) return null;
  return context.branchId;
}
