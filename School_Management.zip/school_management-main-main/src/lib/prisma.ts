import "dotenv/config";
import { PrismaClient, type Prisma } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { getScopedBranchId } from "@/lib/request-context";

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL,
});

declare global {
  var prisma: PrismaClient | undefined;
}

type PrismaClientDelegates = Pick<
  PrismaClient,
  | "user"
  | "academicSession"
  | "department"
  | "designation"
  | "teacherLeaveRequest"
  | "teacherAttendance"
  | "payrollRun"
  | "payrollItem"
  | "teacher"
  | "parent"
  | "guardian"
  | "student"
  | "class"
  | "group"
  | "section"
  | "subject"
  | "teacherSubject"
  | "attendance"
  | "exam"
  | "result"
  | "feeCategory"
  | "feeCategoryClass"
  | "payment"
  | "classMonthlyFee"
  | "financeCategory"
  | "financeEntry"
  | "timetable"
  | "notice"
  | "admissionApplication"
  | "passwordResetToken"
  | "systemSetting"
  | "auditLog"
  | "notificationTemplate"
  | "notificationQueue"
>;

const client = global.prisma ?? new PrismaClient({ adapter });

if (process.env.NODE_ENV !== "production") {
  global.prisma = client;
}

const BRANCH_SCOPED_MODELS = new Set([
  "AcademicSession",
  "Department",
  "Designation",
  "TeacherLeaveRequest",
  "TeacherAttendance",
  "PayrollRun",
  "PayrollItem",
  "Parent",
  "Guardian",
  "Class",
  "Group",
  "Section",
  "Student",
  "TeacherClassAssignment",
  "Subject",
  "TeacherSubject",
  "Attendance",
  "Exam",
  "ExamClassAssignment",
  "ExamSubject",
  "ExamComponent",
  "ExamTeacherAssignment",
  "ExamHistory",
  "Result",
  "ClassMonthlyFee",
  "FeeCategory",
  "FeeCategoryClass",
  "Payment",
  "Timetable",
  "Notice",
  "AdmissionApplication",
  "SystemSetting",
  "FinanceCategory",
  "FinanceEntry",
  "AuditLog",
  "NotificationTemplate",
  "NotificationQueue",
]);

function withBranchWhere(args: Record<string, unknown>, branchId: string) {
  const where = args.where as Record<string, unknown> | undefined;
  return {
    ...args,
    where: where ? { AND: [where, { branchId }] } : { branchId },
  };
}

function withBranchUniqueWhere(args: Record<string, unknown>, branchId: string) {
  const where = args.where as Record<string, unknown> | undefined;
  return {
    ...args,
    where: where ? { ...where, branchId } : { branchId },
  };
}

function withBranchCreateData(args: Record<string, unknown>, branchId: string) {
  const data = args.data;
  if (Array.isArray(data)) {
    return {
      ...args,
      data: data.map((item) =>
        item && typeof item === "object" && !("branchId" in item)
          ? { ...item, branchId }
          : item,
      ),
    };
  }

  if (data && typeof data === "object" && !("branchId" in data)) {
    return { ...args, data: { ...data, branchId } };
  }

  return args;
}

function withBranchUpsertCreate(args: Record<string, unknown>, branchId: string) {
  const create = args.create;
  if (create && typeof create === "object" && !("branchId" in create)) {
    return { ...args, create: { ...create, branchId } };
  }

  return args;
}

function applyBranchScope({
  model,
  operation,
  args,
  branchId,
}: {
  model?: string;
  operation: string;
  args: unknown;
  branchId: string;
}) {
  if (!model || !BRANCH_SCOPED_MODELS.has(model)) return args;

  const nextArgs = { ...((args as Record<string, unknown> | undefined) ?? {}) };

  switch (operation) {
    case "findMany":
    case "findFirst":
    case "findFirstOrThrow":
    case "count":
    case "aggregate":
    case "groupBy":
    case "updateMany":
    case "deleteMany":
      return withBranchWhere(nextArgs, branchId);
    case "findUnique":
    case "findUniqueOrThrow":
    case "update":
    case "delete":
      return withBranchUniqueWhere(nextArgs, branchId);
    case "create":
    case "createMany":
      return withBranchCreateData(nextArgs, branchId);
    case "upsert":
      return withBranchUpsertCreate(
        withBranchUniqueWhere(nextArgs, branchId),
        branchId,
      );
    default:
      return args;
  }
}

const scopedClient = client.$extends({
  query: {
    $allModels: {
      async $allOperations({ model, operation, args, query }) {
        const branchId = getScopedBranchId();
        if (!branchId) {
          return query(args);
        }

        return query(
          applyBranchScope({
            model,
            operation,
            args,
            branchId,
          }) as never,
        );
      },
    },
  },
});

/**
 * Singleton Prisma client that survives hot reloads in development environments.
 */
export const prisma = scopedClient as unknown as PrismaClient;

export type PrismaClientLike =
  | PrismaClient
  | (Prisma.TransactionClient & PrismaClientDelegates);
