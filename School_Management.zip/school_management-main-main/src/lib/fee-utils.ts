export function getClassMonthlyFee(monthlyFee: number | null | undefined) {
  return monthlyFee ?? 0;
}

export function getPaymentTotalAmount(
  monthlyFee: number | null | undefined,
  categoryAmount: number,
) {
  return getClassMonthlyFee(monthlyFee) + categoryAmount;
}

export function getFeeAllocation(
  monthlyFee: number | null | undefined,
  categoryAmount: number,
  amountPaid: number,
) {
  const monthlyFeeTotal = getClassMonthlyFee(monthlyFee);
  const paidAgainstMonthlyFee = Math.min(amountPaid, monthlyFeeTotal);
  const remainingPaid = Math.max(amountPaid - monthlyFeeTotal, 0);
  const paidAgainstCategory = Math.min(remainingPaid, categoryAmount);

  return {
    monthlyFeeTotal,
    monthlyFeeDue: Math.max(monthlyFeeTotal - amountPaid, 0),
    categoryDue: Math.max(categoryAmount - remainingPaid, 0),
    paidAgainstMonthlyFee,
    paidAgainstCategory,
    totalAmount: monthlyFeeTotal + categoryAmount,
    dueAmount: Math.max(monthlyFeeTotal + categoryAmount - amountPaid, 0),
  };
}

export function getPaymentDueAmount(
  monthlyFee: number | null | undefined,
  categoryAmount: number,
  amountPaid: number,
) {
  return getFeeAllocation(monthlyFee, categoryAmount, amountPaid).dueAmount;
}
