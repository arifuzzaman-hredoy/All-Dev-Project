import { Role } from "@prisma/client";
import { HttpError } from "@/utils/error-handler";
import type { TokenPayload } from "@/lib/auth";
import { roleHasPermission, type AdminPermission } from "@/constants/roles";

/**
 * Validates the decoded payload carries one of the permitted roles.
 */
export function requireRole(payload: TokenPayload | null | undefined, allowedRoles: Role[]) {
  if (!payload || !allowedRoles.includes(payload.role)) {
    throw new HttpError("Unauthorized role", 403);
  }
  return payload.role;
}

/**
 * Validates the decoded payload carries a role with the requested permission.
 */
export function requirePermission(
  payload: TokenPayload | null | undefined,
  permission: AdminPermission
) {
  if (!payload || !roleHasPermission(payload.role, permission)) {
    throw new HttpError("Insufficient permissions", 403);
  }

  return payload.role;
}

/**
 * Ensures that token payload exists and yields the user identifier.
 */
export function requireUserId(payload: TokenPayload | null | undefined) {
  if (!payload?.id) {
    throw new HttpError("Missing user identifier", 401);
  }
  return payload.id;
}
