import type { StudentDocumentTemplateConfig } from "@/lib/student-document-template";
import type { StudentDocumentRecord } from "@/repositories/student.repository";
import {
  buildCertificatePdfBufferFromHtml,
  escapeHtml,
  formatBanglaDate,
  formatDateTime,
  formatDocumentNumber,
  formatRollNumber,
  type StudentDocumentOptions,
} from "@/lib/student-document-pdf-modules/common";

function genderLabel(value: StudentDocumentRecord["gender"]) {
  switch (value) {
    case "MALE":
      return "Male";
    case "FEMALE":
      return "Female";
    default:
      return "Other";
  }
}

function buildTestimonialHtml(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  const schoolName = options.schoolName?.trim() || template.schoolName.trim();
  const generatedAt = formatDateTime(new Date());
  const issueDate = formatBanglaDate(options.issueDate ?? new Date());
  const documentNumber = formatDocumentNumber(options.studentDocumentNumber);
  const studentName = escapeHtml(student.user.name);
  const className = escapeHtml(student.class.name);
  const groupName = escapeHtml(student.group?.name ?? "General");
  const sectionName = escapeHtml(student.section?.name ?? "Default");
  const rollNumber = escapeHtml(formatRollNumber(student.rollNumber));
  const phone = escapeHtml(student.phone ?? student.guardian?.phone ?? student.parent?.phone ?? "N/A");
  const parentName = escapeHtml(student.guardian?.name ?? student.parent?.user.name ?? "N/A");
  const parentAddress = escapeHtml(student.guardian?.address ?? student.parent?.address ?? "N/A");
  const conductLine = escapeHtml(
    `${studentName} has maintained a disciplined, respectful, and sincere attitude during the period of study.`,
  );
  const footerLeft = escapeHtml(template.footerLeftText);
  const footerRight = escapeHtml(template.footerRightText);
  const watermarkText = escapeHtml(template.watermarkText);
  const primaryColor = template.primaryColor;
  const secondaryColor = template.secondaryColor;
  const accentColor = template.accentColor;
  const backgroundColor = template.backgroundColor;
  const surfaceColor = template.surfaceColor;
  const borderColor = template.borderColor;

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Testimonial - ${studentName}</title>
    <style>
      * { box-sizing: border-box; }
      body {
        margin: 0;
        background: ${backgroundColor};
        color: ${primaryColor};
        font-family: "Times New Roman", Times, serif;
      }
      .page {
        max-width: 960px;
        margin: 0 auto;
        padding: 24px;
      }
      .card {
        position: relative;
        overflow: hidden;
        min-height: 1360px;
        border: 2px solid ${borderColor};
        border-radius: 22px;
        background:
          linear-gradient(180deg, rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.96)),
          ${surfaceColor};
        box-shadow: 0 28px 70px rgba(15, 23, 42, 0.08);
        padding: 30px 34px 28px;
      }
      .card::before {
        content: "${watermarkText}";
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        font-size: 82px;
        font-weight: 700;
        color: rgba(15, 23, 42, 0.05);
        letter-spacing: 0.08em;
        transform: rotate(-22deg);
        pointer-events: none;
        white-space: nowrap;
      }
      .topband {
        position: relative;
        display: grid;
        grid-template-columns: 110px 1fr 110px;
        gap: 18px;
        align-items: center;
        border-bottom: 3px solid ${secondaryColor};
        padding-bottom: 18px;
        margin-bottom: 18px;
      }
      .logo-box {
        height: 92px;
        border: 2px solid ${secondaryColor};
        border-radius: 18px;
        display: grid;
        place-items: center;
        font-size: 15px;
        font-weight: 700;
        color: ${secondaryColor};
        background: rgba(255, 255, 255, 0.9);
        text-align: center;
        padding: 10px;
      }
      .logo-box img {
        max-width: 100%;
        max-height: 74px;
        object-fit: contain;
      }
      .head {
        text-align: center;
      }
      .school-name {
        margin: 0;
        font-size: 30px;
        letter-spacing: 0.02em;
      }
      .subheading {
        margin: 8px 0 0;
        font-size: 13px;
        line-height: 1.6;
        color: rgba(15, 23, 42, 0.8);
      }
      .doc-chip-row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        justify-content: flex-end;
      }
      .chip {
        border: 1px solid rgba(29, 78, 216, 0.24);
        background: rgba(239, 246, 255, 0.92);
        color: ${secondaryColor};
        padding: 7px 12px;
        border-radius: 14px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .title {
        position: relative;
        margin: 8px 0 8px;
        text-align: center;
      }
      .title h1 {
        margin: 0;
        font-size: 24px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .title .underline {
        width: 180px;
        height: 4px;
        margin: 10px auto 0;
        background: linear-gradient(90deg, ${secondaryColor}, ${accentColor});
      }
      .meta-grid {
        position: relative;
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin: 18px 0 16px;
      }
      .meta-card {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        background: rgba(248, 250, 252, 0.9);
        padding: 12px 14px;
      }
      .meta-label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .meta-value {
        font-size: 14px;
        font-weight: 700;
        color: ${primaryColor};
      }
      .grid {
        position: relative;
        display: grid;
        grid-template-columns: 1.25fr 0.75fr;
        gap: 14px;
      }
      .section {
        border: 1px solid ${borderColor};
        border-radius: 18px;
        background: rgba(255, 255, 255, 0.94);
        padding: 18px 20px;
      }
      .section h2 {
        margin: 0 0 12px;
        font-size: 16px;
        letter-spacing: 0.04em;
      }
      .letter {
        font-size: 16px;
        line-height: 1.95;
        text-align: justify;
        color: rgba(15, 23, 42, 0.92);
      }
      .letter p { margin: 0 0 12px; }
      .facts {
        display: grid;
        gap: 10px;
      }
      .fact {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        padding: 12px 14px;
        background: #f8fafc;
      }
      .fact .label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .fact .value {
        font-size: 14px;
        font-weight: 700;
      }
      .signature-row {
        position: relative;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        align-items: end;
        margin-top: 20px;
      }
      .signature {
        min-height: 118px;
        border-top: 1px solid ${borderColor};
        display: flex;
        align-items: end;
        justify-content: center;
        padding-top: 18px;
        text-align: center;
        font-size: 14px;
      }
      .signature strong {
        display: block;
        margin-bottom: 4px;
        font-size: 15px;
      }
      .footer {
        position: relative;
        display: flex;
        justify-content: space-between;
        gap: 12px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid ${borderColor};
        font-size: 12px;
        color: rgba(15, 23, 42, 0.7);
      }
      .footer .stamp {
        font-weight: 700;
        color: ${secondaryColor};
      }
      .note {
        position: relative;
        margin-top: 14px;
        border-left: 4px solid ${accentColor};
        background: rgba(255, 247, 237, 0.7);
        padding: 12px 14px;
        border-radius: 12px;
        font-size: 12px;
        line-height: 1.7;
        color: rgba(15, 23, 42, 0.76);
      }
      .muted {
        color: rgba(15, 23, 42, 0.68);
      }
    </style>
  </head>
  <body>
    <div class="page">
      <section class="card">
        <div class="topband">
          <div class="logo-box">School<br />Logo</div>
          <div class="head">
            <h1 class="school-name">${schoolName}</h1>
            <p class="subheading">${escapeHtml(template.headerTitle)}<br />${escapeHtml(template.headerSubtitle)}</p>
          </div>
          <div class="doc-chip-row">
            <div class="chip">DOC # ${escapeHtml(documentNumber)}</div>
            <div class="chip">ISSUED ${escapeHtml(issueDate)}</div>
          </div>
        </div>

        <div class="title">
          <h1>Testimonial</h1>
          <div class="underline"></div>
        </div>

        <div class="meta-grid">
          <div class="meta-card"><span class="meta-label">Student</span><div class="meta-value">${studentName}</div></div>
          <div class="meta-card"><span class="meta-label">Class</span><div class="meta-value">${className}</div></div>
          <div class="meta-card"><span class="meta-label">Roll</span><div class="meta-value">${rollNumber}</div></div>
          <div class="meta-card"><span class="meta-label">Gender</span><div class="meta-value">${escapeHtml(genderLabel(student.gender))}</div></div>
        </div>

        <div class="grid">
          <article class="section">
            <h2>Testimonial Note</h2>
            <div class="letter">
              <p>This is to certify that <strong>${studentName}</strong> of class <strong>${className}</strong>, group <strong>${groupName}</strong>, section <strong>${sectionName}</strong>, roll <strong>${rollNumber}</strong>, has been a regular student of this institution.</p>
              <p>${conductLine}</p>
              <p>The student has shown good academic engagement and maintained a respectful relationship with teachers, classmates, and the school community throughout the recorded period.</p>
              <p>This testimonial is issued upon request for academic and personal record purposes.</p>
            </div>
          </article>

          <aside class="section">
            <h2>Profile Snapshot</h2>
            <div class="facts">
              <div class="fact"><span class="label">Guardian</span><div class="value">${parentName}</div></div>
              <div class="fact"><span class="label">Contact</span><div class="value">${phone}</div></div>
              <div class="fact"><span class="label">Address</span><div class="value">${parentAddress}</div></div>
              <div class="fact"><span class="label">Generated</span><div class="value">${escapeHtml(generatedAt)}</div></div>
            </div>
          </aside>
        </div>

        <div class="note">${escapeHtml(template.noteText)}</div>

        <div class="signature-row">
          <div class="signature">
            <div>
              <strong>${footerLeft}</strong>
              Academic Office
            </div>
          </div>
          <div class="signature">
            <div>
              <strong>${footerRight}</strong>
              Principal / Head Teacher
            </div>
          </div>
        </div>

        <div class="footer">
          <div class="stamp">${escapeHtml(schoolName)}</div>
          <div>Class: ${className} | Roll: ${rollNumber} | Guardian: ${parentName}</div>
        </div>
      </section>
    </div>
  </body>
</html>`;
}

export function buildTestimonialCertificatePdfBuffer(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  return buildCertificatePdfBufferFromHtml(buildTestimonialHtml(student, options, template));
}
