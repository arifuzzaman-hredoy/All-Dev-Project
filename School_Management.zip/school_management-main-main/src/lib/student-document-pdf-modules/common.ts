import puppeteer from "puppeteer-core";
import { existsSync } from "node:fs";

const CHROMIUM_EXECUTABLE_CANDIDATES = [
  process.env.PUPPETEER_EXECUTABLE_PATH,
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
  "/snap/bin/chromium",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/usr/bin/chrome",
  "/usr/bin/microsoft-edge",
].filter((candidate): candidate is string => Boolean(candidate));

function resolveChromiumExecutablePath() {
  for (const candidate of CHROMIUM_EXECUTABLE_CANDIDATES) {
    if (existsSync(candidate)) {
      return candidate;
    }
  }

  throw new Error(
    "No Chromium or Chrome executable was found. Set PUPPETEER_EXECUTABLE_PATH to a valid browser binary.",
  );
}

export interface StudentDocumentOptions {
  schoolName?: string | null;
  studentDocumentNumber?: string | null;
  issueDate?: string | Date | null;
  template?: {
    schoolName?: string | null;
    schoolAddress?: string | null;
    headerText?: string | null;
    footerText?: string | null;
    primaryColor?: string | null;
    accentColor?: string | null;
    logoUrl?: string | null;
    signatoryName?: string | null;
    signatoryTitle?: string | null;
  } | null;
}

export function escapeHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function formatBanglaDate(value: string | Date | null | undefined): string {
  if (!value) {
    return "";
  }

  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return new Intl.DateTimeFormat("bn-BD", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) {
    return "";
  }

  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function formatRollNumber(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") {
    return "";
  }

  return String(value);
}

export function formatDocumentNumber(value: string | null | undefined): string {
  return value ? value : "Generated automatically";
}

export async function buildCertificatePdfBufferFromHtml(html: string): Promise<Buffer> {
  const executablePath = resolveChromiumExecutablePath();

  const browser = await puppeteer.launch({
    executablePath,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
    headless: true,
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1810, deviceScaleFactor: 1 });
    await page.setContent(html, { waitUntil: "networkidle0" });
    await page.emulateMediaType("screen");
    await page.evaluate(async () => {
      const fonts = (document as Document).fonts;
      if (fonts && "ready" in fonts) {
        await fonts.ready;
      }
    });

    const buffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: {
        top: "0",
        bottom: "0",
        left: "0",
        right: "0",
      },
    });

    await page.close();
    return Buffer.from(buffer);
  } finally {
    await browser.close();
  }
}
