import type { StudentDocumentTemplateConfig } from "@/lib/student-document-template";
import type { StudentDocumentRecord } from "@/repositories/student.repository";
import {
  buildCertificatePdfBufferFromHtml,
  escapeHtml,
  formatBanglaDate,
  formatDateTime,
  formatDocumentNumber,
  formatRollNumber,
  type StudentDocumentOptions,
} from "@/lib/student-document-pdf-modules/common";

function genderLabel(value: StudentDocumentRecord["gender"]) {
  switch (value) {
    case "MALE":
      return "Male";
    case "FEMALE":
      return "Female";
    default:
      return "Other";
  }
}

function buildTransferCertificateHtml(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  const schoolName = options.schoolName?.trim() || template.schoolName.trim();
  const generatedAt = formatDateTime(new Date());
  const issueDate = formatBanglaDate(options.issueDate ?? new Date());
  const documentNumber = formatDocumentNumber(options.studentDocumentNumber);
  const studentName = escapeHtml(student.user.name);
  const className = escapeHtml(student.class.name);
  const groupName = escapeHtml(student.group?.name ?? "General");
  const sectionName = escapeHtml(student.section?.name ?? "Default");
  const rollNumber = escapeHtml(formatRollNumber(student.rollNumber));
  const phone = escapeHtml(student.phone ?? student.guardian?.phone ?? student.parent?.phone ?? "N/A");
  const parentName = escapeHtml(student.guardian?.name ?? student.parent?.user.name ?? "N/A");
  const parentAddress = escapeHtml(student.guardian?.address ?? student.parent?.address ?? "N/A");
  const footerLeft = escapeHtml(template.footerLeftText);
  const footerRight = escapeHtml(template.footerRightText);
  const watermarkText = escapeHtml(template.watermarkText);
  const primaryColor = template.primaryColor;
  const secondaryColor = template.secondaryColor;
  const accentColor = template.accentColor;
  const backgroundColor = template.backgroundColor;
  const surfaceColor = template.surfaceColor;
  const borderColor = template.borderColor;

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Transfer Certificate - ${studentName}</title>
    <style>
      * { box-sizing: border-box; }
      body {
        margin: 0;
        background: ${backgroundColor};
        color: ${primaryColor};
        font-family: Arial, Helvetica, sans-serif;
      }
      .page {
        max-width: 960px;
        margin: 0 auto;
        padding: 24px;
      }
      .card {
        position: relative;
        overflow: hidden;
        min-height: 1360px;
        border: 2px solid ${borderColor};
        border-radius: 18px;
        background: linear-gradient(180deg, ${surfaceColor}, rgba(248, 250, 252, 0.98));
        box-shadow: 0 28px 70px rgba(15, 23, 42, 0.08);
        padding: 28px 30px 26px;
      }
      .card::before {
        content: "${watermarkText}";
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        font-size: 78px;
        font-weight: 800;
        color: rgba(29, 78, 216, 0.05);
        letter-spacing: 0.18em;
        transform: rotate(-18deg);
        pointer-events: none;
        white-space: nowrap;
      }
      .header {
        position: relative;
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 16px;
        align-items: start;
        padding-bottom: 18px;
        margin-bottom: 18px;
        border-bottom: 4px solid ${secondaryColor};
      }
      .heading {
        position: relative;
      }
      .school-name {
        margin: 0;
        font-size: 32px;
        letter-spacing: 0.02em;
      }
      .subheading {
        margin: 8px 0 0;
        font-size: 13px;
        line-height: 1.6;
        color: rgba(15, 23, 42, 0.78);
      }
      .chips {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }
      .chip {
        border: 1px solid rgba(29, 78, 216, 0.22);
        background: rgba(239, 246, 255, 0.95);
        color: ${secondaryColor};
        padding: 7px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .title {
        position: relative;
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 18px;
        align-items: center;
        margin: 8px 0 18px;
      }
      .title h1 {
        margin: 0;
        font-size: 25px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
      }
      .title .rule {
        width: 180px;
        height: 6px;
        border-radius: 999px;
        background: linear-gradient(90deg, ${secondaryColor}, ${accentColor});
      }
      .meta-grid {
        position: relative;
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 16px;
      }
      .meta-card {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        background: rgba(248, 250, 252, 0.88);
        padding: 12px 14px;
      }
      .meta-label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .meta-value {
        font-size: 14px;
        font-weight: 700;
      }
      .content {
        position: relative;
        display: grid;
        grid-template-columns: 1.2fr 0.8fr;
        gap: 14px;
      }
      .panel {
        border: 1px solid ${borderColor};
        border-radius: 18px;
        padding: 18px 20px;
        background: rgba(255, 255, 255, 0.95);
      }
      .panel h2 {
        margin: 0 0 12px;
        font-size: 16px;
        letter-spacing: 0.04em;
      }
      .paragraphs {
        font-size: 15px;
        line-height: 2;
        color: rgba(15, 23, 42, 0.9);
        text-align: justify;
      }
      .paragraphs p { margin: 0 0 12px; }
      .facts {
        display: grid;
        gap: 10px;
      }
      .fact {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        padding: 12px 14px;
        background: #f8fafc;
      }
      .fact .label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .fact .value {
        font-size: 14px;
        font-weight: 700;
      }
      .status-strip {
        margin-top: 14px;
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
      }
      .status {
        border-radius: 14px;
        padding: 12px 14px;
        border: 1px solid rgba(29, 78, 216, 0.16);
        background: rgba(239, 246, 255, 0.8);
        text-align: center;
        font-size: 12px;
        line-height: 1.6;
        color: rgba(15, 23, 42, 0.78);
      }
      .status strong {
        display: block;
        margin-bottom: 4px;
        font-size: 14px;
        color: ${secondaryColor};
      }
      .note {
        margin-top: 14px;
        border-left: 4px solid ${accentColor};
        background: rgba(249, 250, 251, 0.92);
        padding: 12px 14px;
        border-radius: 12px;
        font-size: 12px;
        line-height: 1.7;
        color: rgba(15, 23, 42, 0.74);
      }
      .signatures {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        margin-top: 18px;
      }
      .signature {
        min-height: 116px;
        border-top: 1px solid ${borderColor};
        display: flex;
        align-items: end;
        justify-content: center;
        padding-top: 18px;
        text-align: center;
        font-size: 14px;
      }
      .signature strong {
        display: block;
        margin-bottom: 4px;
        font-size: 15px;
      }
      .footer {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid ${borderColor};
        font-size: 12px;
        color: rgba(15, 23, 42, 0.68);
      }
      .footer .stamp {
        font-weight: 700;
        color: ${secondaryColor};
      }
    </style>
  </head>
  <body>
    <div class="page">
      <section class="card">
        <header class="header">
          <div class="heading">
            <h1 class="school-name">${schoolName}</h1>
            <p class="subheading">${escapeHtml(template.headerTitle)}<br />${escapeHtml(template.headerSubtitle)}</p>
          </div>
          <div class="chips">
            <div class="chip">DOC # ${escapeHtml(documentNumber)}</div>
            <div class="chip">ISSUED ${escapeHtml(issueDate)}</div>
          </div>
        </header>

        <div class="title">
          <h1>Transfer Certificate</h1>
          <div class="rule"></div>
        </div>

        <div class="meta-grid">
          <div class="meta-card"><span class="meta-label">Student</span><div class="meta-value">${studentName}</div></div>
          <div class="meta-card"><span class="meta-label">Class</span><div class="meta-value">${className}</div></div>
          <div class="meta-card"><span class="meta-label">Roll</span><div class="meta-value">${rollNumber}</div></div>
          <div class="meta-card"><span class="meta-label">Gender</span><div class="meta-value">${escapeHtml(genderLabel(student.gender))}</div></div>
        </div>

        <div class="content">
          <article class="panel">
            <h2>Transfer Statement</h2>
            <div class="paragraphs">
              <p>This is to certify that <strong>${studentName}</strong> of class <strong>${className}</strong>, group <strong>${groupName}</strong>, section <strong>${sectionName}</strong>, roll <strong>${rollNumber}</strong>, was enrolled in this institution and the official academic record is maintained in our register.</p>
              <p>The student is being issued this transfer certificate for further admission or school migration. All known academic and administrative details are based on the available student profile and school records.</p>
              <p>During the period of study, the student remained under the supervision of the institution and no outstanding record issue has been noted in the digital profile attached to this certificate.</p>
            </div>
            <div class="status-strip">
              <div class="status"><strong>Contact</strong>${phone}</div>
              <div class="status"><strong>Guardian</strong>${parentName}</div>
              <div class="status"><strong>Address</strong>${parentAddress}</div>
            </div>
            <div class="note">This certificate is generated from the current school database. If any record is updated later, reissue the document to keep it aligned with the latest profile.</div>
          </article>

          <aside class="panel">
            <h2>Record Details</h2>
            <div class="facts">
              <div class="fact"><span class="label">Document No</span><div class="value">${escapeHtml(documentNumber)}</div></div>
              <div class="fact"><span class="label">Issue Date</span><div class="value">${escapeHtml(issueDate)}</div></div>
              <div class="fact"><span class="label">Generated</span><div class="value">${escapeHtml(generatedAt)}</div></div>
              <div class="fact"><span class="label">Class / Group / Section</span><div class="value">${className} / ${groupName} / ${sectionName}</div></div>
              <div class="fact"><span class="label">Roll Number</span><div class="value">${rollNumber}</div></div>
              <div class="fact"><span class="label">Gender</span><div class="value">${escapeHtml(genderLabel(student.gender))}</div></div>
            </div>
          </aside>
        </div>

        <div class="signatures">
          <div class="signature"><div><strong>${footerLeft}</strong>Academic Office</div></div>
          <div class="signature"><div><strong>${footerRight}</strong>Principal / Head Teacher</div></div>
        </div>

        <div class="footer">
          <div class="stamp">${escapeHtml(schoolName)}</div>
          <div>Student: ${studentName} | Guardian: ${parentName} | Contact: ${phone}</div>
        </div>
      </section>
    </div>
  </body>
</html>`;
}

export function buildTransferCertificatePdfBuffer(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  return buildCertificatePdfBufferFromHtml(buildTransferCertificateHtml(student, options, template));
}
