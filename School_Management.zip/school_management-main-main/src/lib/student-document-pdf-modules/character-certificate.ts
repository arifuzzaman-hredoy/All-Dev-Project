import type { StudentDocumentTemplateConfig } from "@/lib/student-document-template";
import type { StudentDocumentRecord } from "@/repositories/student.repository";
import {
  buildCertificatePdfBufferFromHtml,
  escapeHtml,
  formatBanglaDate,
  formatDateTime,
  formatDocumentNumber,
  formatRollNumber,
  type StudentDocumentOptions,
} from "@/lib/student-document-pdf-modules/common";

function genderLabel(value: StudentDocumentRecord["gender"]) {
  switch (value) {
    case "MALE":
      return "Male";
    case "FEMALE":
      return "Female";
    default:
      return "Other";
  }
}

function buildCharacterCertificateHtml(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  const schoolName = options.schoolName?.trim() || template.schoolName.trim();
  const generatedAt = formatDateTime(new Date());
  const issueDate = formatBanglaDate(options.issueDate ?? new Date());
  const documentNumber = formatDocumentNumber(options.studentDocumentNumber);
  const studentName = escapeHtml(student.user.name);
  const className = escapeHtml(student.class.name);
  const groupName = escapeHtml(student.group?.name ?? "General");
  const sectionName = escapeHtml(student.section?.name ?? "Default");
  const rollNumber = escapeHtml(formatRollNumber(student.rollNumber));
  const phone = escapeHtml(student.phone ?? student.guardian?.phone ?? student.parent?.phone ?? "N/A");
  const parentName = escapeHtml(student.guardian?.name ?? student.parent?.user.name ?? "N/A");
  const parentAddress = escapeHtml(student.guardian?.address ?? student.parent?.address ?? "N/A");
  const footerLeft = escapeHtml(template.footerLeftText);
  const footerRight = escapeHtml(template.footerRightText);
  const watermarkText = escapeHtml(template.watermarkText);
  const primaryColor = template.primaryColor;
  const secondaryColor = template.secondaryColor;
  const accentColor = template.accentColor;
  const backgroundColor = template.backgroundColor;
  const surfaceColor = template.surfaceColor;
  const borderColor = template.borderColor;

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Character Certificate - ${studentName}</title>
    <style>
      * { box-sizing: border-box; }
      body {
        margin: 0;
        background: ${backgroundColor};
        color: ${primaryColor};
        font-family: Georgia, "Times New Roman", serif;
      }
      .page {
        max-width: 960px;
        margin: 0 auto;
        padding: 24px;
      }
      .card {
        position: relative;
        overflow: hidden;
        min-height: 1360px;
        border: 2px solid ${borderColor};
        border-radius: 20px;
        background: radial-gradient(circle at top right, rgba(16, 185, 129, 0.1), transparent 28%),
          linear-gradient(180deg, ${surfaceColor}, rgba(248, 250, 252, 0.98));
        box-shadow: 0 28px 70px rgba(15, 23, 42, 0.08);
        padding: 28px 30px 26px;
      }
      .card::before {
        content: "${watermarkText}";
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        font-size: 84px;
        font-weight: 700;
        color: rgba(16, 185, 129, 0.05);
        letter-spacing: 0.14em;
        transform: rotate(-24deg);
        pointer-events: none;
        white-space: nowrap;
      }
      .top {
        position: relative;
        display: grid;
        grid-template-columns: 140px 1fr;
        gap: 18px;
        align-items: center;
        padding-bottom: 18px;
        margin-bottom: 18px;
        border-bottom: 3px double ${secondaryColor};
      }
      .crest {
        min-height: 102px;
        border: 2px solid ${secondaryColor};
        border-radius: 18px;
        padding: 12px;
        display: grid;
        place-items: center;
        text-align: center;
        font-size: 14px;
        font-weight: 700;
        color: ${secondaryColor};
        background: rgba(255, 255, 255, 0.88);
      }
      .heading {
        text-align: center;
      }
      .school-name {
        margin: 0;
        font-size: 30px;
        letter-spacing: 0.02em;
      }
      .subheading {
        margin: 8px 0 0;
        font-size: 13px;
        line-height: 1.6;
        color: rgba(15, 23, 42, 0.78);
      }
      .chips {
        position: absolute;
        top: 0;
        right: 0;
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }
      .chip {
        border: 1px solid rgba(16, 185, 129, 0.18);
        background: rgba(240, 253, 244, 0.94);
        color: #047857;
        padding: 7px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .title {
        position: relative;
        text-align: center;
        margin: 8px 0 18px;
      }
      .title h1 {
        margin: 0;
        font-size: 25px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .title .bar {
        width: 220px;
        height: 5px;
        margin: 10px auto 0;
        border-radius: 999px;
        background: linear-gradient(90deg, ${secondaryColor}, ${accentColor});
      }
      .meta-grid {
        position: relative;
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 16px;
      }
      .meta-card {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        background: rgba(248, 250, 252, 0.92);
        padding: 12px 14px;
      }
      .meta-label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .meta-value {
        font-size: 14px;
        font-weight: 700;
      }
      .layout {
        position: relative;
        display: grid;
        grid-template-columns: 0.9fr 1.1fr;
        gap: 14px;
      }
      .panel {
        border: 1px solid ${borderColor};
        border-radius: 18px;
        padding: 18px 20px;
        background: rgba(255, 255, 255, 0.95);
      }
      .panel h2 {
        margin: 0 0 12px;
        font-size: 16px;
        letter-spacing: 0.04em;
      }
      .facts {
        display: grid;
        gap: 10px;
      }
      .fact {
        border: 1px solid ${borderColor};
        border-radius: 14px;
        padding: 12px 14px;
        background: #f8fafc;
      }
      .fact .label {
        display: block;
        margin-bottom: 6px;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: rgba(15, 23, 42, 0.58);
      }
      .fact .value {
        font-size: 14px;
        font-weight: 700;
      }
      .story {
        font-size: 15px;
        line-height: 2;
        color: rgba(15, 23, 42, 0.9);
        text-align: justify;
      }
      .story p { margin: 0 0 12px; }
      .bullet-list {
        display: grid;
        gap: 10px;
        margin-top: 14px;
      }
      .bullet {
        border-left: 4px solid ${secondaryColor};
        background: rgba(240, 253, 244, 0.86);
        border-radius: 12px;
        padding: 12px 14px;
        font-size: 12px;
        line-height: 1.7;
      }
      .note {
        margin-top: 14px;
        border-left: 4px solid ${accentColor};
        background: rgba(249, 250, 251, 0.92);
        padding: 12px 14px;
        border-radius: 12px;
        font-size: 12px;
        line-height: 1.7;
        color: rgba(15, 23, 42, 0.74);
      }
      .signatures {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        margin-top: 18px;
      }
      .signature {
        min-height: 116px;
        border-top: 1px solid ${borderColor};
        display: flex;
        align-items: end;
        justify-content: center;
        padding-top: 18px;
        text-align: center;
        font-size: 14px;
      }
      .signature strong {
        display: block;
        margin-bottom: 4px;
        font-size: 15px;
      }
      .footer {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid ${borderColor};
        font-size: 12px;
        color: rgba(15, 23, 42, 0.68);
      }
      .footer .stamp {
        font-weight: 700;
        color: #047857;
      }
    </style>
  </head>
  <body>
    <div class="page">
      <section class="card">
        <div class="chips">
          <div class="chip">DOC # ${escapeHtml(documentNumber)}</div>
          <div class="chip">ISSUED ${escapeHtml(issueDate)}</div>
        </div>

        <header class="top">
          <div class="crest">Character<br />Certificate</div>
          <div class="heading">
            <h1 class="school-name">${schoolName}</h1>
            <p class="subheading">${escapeHtml(template.headerTitle)}<br />${escapeHtml(template.headerSubtitle)}</p>
          </div>
        </header>

        <div class="title">
          <h1>Character Certificate</h1>
          <div class="bar"></div>
        </div>

        <div class="meta-grid">
          <div class="meta-card"><span class="meta-label">Student</span><div class="meta-value">${studentName}</div></div>
          <div class="meta-card"><span class="meta-label">Class</span><div class="meta-value">${className}</div></div>
          <div class="meta-card"><span class="meta-label">Roll</span><div class="meta-value">${rollNumber}</div></div>
          <div class="meta-card"><span class="meta-label">Gender</span><div class="meta-value">${escapeHtml(genderLabel(student.gender))}</div></div>
        </div>

        <div class="layout">
          <aside class="panel">
            <h2>Reference Card</h2>
            <div class="facts">
              <div class="fact"><span class="label">Guardian</span><div class="value">${parentName}</div></div>
              <div class="fact"><span class="label">Contact</span><div class="value">${phone}</div></div>
              <div class="fact"><span class="label">Address</span><div class="value">${parentAddress}</div></div>
              <div class="fact"><span class="label">Class / Group / Section</span><div class="value">${className} / ${groupName} / ${sectionName}</div></div>
              <div class="fact"><span class="label">Generated</span><div class="value">${escapeHtml(generatedAt)}</div></div>
            </div>
          </aside>

          <article class="panel">
            <h2>Character Statement</h2>
            <div class="story">
              <p>This is to certify that <strong>${studentName}</strong> of class <strong>${className}</strong>, roll <strong>${rollNumber}</strong>, has been known to this institution as a student of good conduct and regular behaviour.</p>
              <p>${studentName} has consistently shown respect toward teachers, classmates, and school staff, and has maintained the discipline expected of a responsible student.</p>
              <p>This certificate is issued from the official student record for use in academic and administrative purposes.</p>
            </div>

            <div class="bullet-list">
              <div class="bullet"><strong>Academic Profile:</strong> The record is linked to the current student profile stored in the school system.</div>
              <div class="bullet"><strong>Conduct:</strong> The certificate reflects the conduct information available in the institutional record.</div>
              <div class="bullet"><strong>Issue Context:</strong> ${escapeHtml(template.noteText)}</div>
            </div>
            <div class="note">This PDF should be reissued whenever the student record is updated so the certificate stays aligned with the latest profile data.</div>
          </article>
        </div>

        <div class="signatures">
          <div class="signature"><div><strong>${footerLeft}</strong>Academic Office</div></div>
          <div class="signature"><div><strong>${footerRight}</strong>Principal / Head Teacher</div></div>
        </div>

        <div class="footer">
          <div class="stamp">${escapeHtml(schoolName)}</div>
          <div>Document No: ${escapeHtml(documentNumber)} | Issue Date: ${escapeHtml(issueDate)}</div>
        </div>
      </section>
    </div>
  </body>
</html>`;
}

export function buildCharacterCertificatePdfBuffer(
  student: StudentDocumentRecord,
  options: StudentDocumentOptions,
  template: StudentDocumentTemplateConfig,
) {
  return buildCertificatePdfBufferFromHtml(buildCharacterCertificateHtml(student, options, template));
}
