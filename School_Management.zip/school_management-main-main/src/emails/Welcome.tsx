import React from "react";

type Props = {
  name?: string;
  actionUrl?: string;
};

export function WelcomeEmail({ name = "there", actionUrl = "#" }: Props) {
  return (
    <html>
      <body
        style={{
          fontFamily:
            "system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
          margin: 0,
        }}
      >
        <table width="100%" cellPadding={0} cellSpacing={0} role="presentation">
          <tr>
            <td align="center">
              <table
                width="640"
                cellPadding={0}
                cellSpacing={0}
                role="presentation"
                style={{ margin: "24px 0" }}
              >
                <tr>
                  <td
                    style={{
                      padding: 24,
                      border: "1px solid #eaeaea",
                      borderRadius: 8,
                    }}
                  >
                    <h1 style={{ margin: 0, fontSize: 20 }}>
                      Welcome, {name}!
                    </h1>
                    <p style={{ marginTop: 8 }}>
                      Thanks for submitting your application — click below to
                      view your dashboard.
                    </p>
                    <p style={{ marginTop: 18 }}>
                      <a
                        href={actionUrl}
                        style={{
                          background: "#2563eb",
                          color: "#fff",
                          padding: "8px 12px",
                          borderRadius: 6,
                          textDecoration: "none",
                        }}
                      >
                        Open dashboard
                      </a>
                    </p>
                    <p style={{ marginTop: 18, color: "#666", fontSize: 13 }}>
                      Regards,
                      <br />
                      School Administration
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </body>
    </html>
  );
}

export default WelcomeEmail;
