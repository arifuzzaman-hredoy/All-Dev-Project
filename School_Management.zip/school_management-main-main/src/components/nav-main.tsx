"use client";

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar";
import { IconChevronRight } from "@tabler/icons-react";
import { usePathname } from "next/navigation";
import Link from "next/link";

type NavItem = {
  title: string;
  url: string;
  icon?: React.ReactNode;
  isActive?: boolean;
  items?: NavItem[];
};

function isItemActive(item: NavItem, pathname: string): boolean {
  if (pathname === item.url || pathname.startsWith(`${item.url}/`)) {
    return true;
  }

  return item.items?.some((child) => isItemActive(child, pathname)) ?? false;
}

function NavItemRow({
  item,
  pathname,
  level = 0,
}: {
  item: NavItem;
  pathname: string;
  level?: number;
}) {
  const hasSubRoutes = Boolean(item.items?.length);
  const active = item.isActive ?? isItemActive(item, pathname);

  if (level === 0) {
    return (
      <Collapsible asChild defaultOpen={active} className="group/collapsible">
        <SidebarMenuItem>
          <CollapsibleTrigger asChild>
            <SidebarMenuButton tooltip={item.title} asChild={!hasSubRoutes}>
              {hasSubRoutes ? (
                <>
                  {item.icon}
                  <span>{item.title}</span>
                  <IconChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                </>
              ) : (
                <Link href={item.url} className="flex items-center gap-2">
                  {item.icon}
                  <span>{item.title}</span>
                </Link>
              )}
            </SidebarMenuButton>
          </CollapsibleTrigger>

          {hasSubRoutes && (
            <CollapsibleContent>
              <SidebarMenuSub>
                {item.items!.map((subItem) => (
                  <NavItemRow
                    key={subItem.title}
                    item={subItem}
                    pathname={pathname}
                    level={1}
                  />
                ))}
              </SidebarMenuSub>
            </CollapsibleContent>
          )}
        </SidebarMenuItem>
      </Collapsible>
    );
  }

  return (
    <Collapsible asChild defaultOpen={active} className="group/collapsible">
      <SidebarMenuSubItem>
        <CollapsibleTrigger asChild>
          <SidebarMenuSubButton asChild isActive={active}>
            {hasSubRoutes ? (
              <button type="button" className="w-full justify-start">
                {item.icon}
                <span>{item.title}</span>
                <IconChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
              </button>
            ) : (
              <Link href={item.url}>
                {item.icon}
                <span>{item.title}</span>
              </Link>
            )}
          </SidebarMenuSubButton>
        </CollapsibleTrigger>

        {hasSubRoutes && (
          <CollapsibleContent>
            <SidebarMenuSub className="my-1">
              {item.items!.map((subItem) => (
                <NavItemRow
                  key={subItem.title}
                  item={subItem}
                  pathname={pathname}
                  level={2}
                />
              ))}
            </SidebarMenuSub>
          </CollapsibleContent>
        )}
      </SidebarMenuSubItem>
    </Collapsible>
  );
}

export function NavMain({ items }: { items: NavItem[] }) {
  const pathname = usePathname();

  return (
    <SidebarGroup>
      <SidebarGroupLabel>Platform</SidebarGroupLabel>
      <SidebarMenu>
        {items.map((item) => (
          <NavItemRow key={item.title} item={item} pathname={pathname} />
        ))}
      </SidebarMenu>
    </SidebarGroup>
  );
}
