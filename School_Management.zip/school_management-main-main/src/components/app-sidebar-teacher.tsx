"use client"

import * as React from "react"

import { NavMain } from "@/components/nav-main"
import { NavProjects } from "@/components/nav-projects"
import { NavUser } from "@/components/nav-user"
import { TeamSwitcher } from "@/components/team-switcher"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar"

import {
  IconLayoutRows,
  IconUsers,
  IconChecklist,
  IconFileText,
  IconCalendar,
  IconBell,
  IconSettings,
} from "@tabler/icons-react"

// This is sample data.
const data = {
  user: {
    name: "Teacher",
    email: "teacher@email.com",
    avatar: "/avatars/teacher.svg",
  },

  teams: [
    {
      name: "School ERP",
      logo: <IconLayoutRows />,
      plan: "Teacher Panel",
    },
  ],

  navMain: [
    {
      title: "Dashboard",
      url: "/teacher/",
      icon: <IconLayoutRows />,
    },

    {
      title: "Students",
      url: "/teacher/students",
      icon: <IconUsers />,
      items: [
        {
          title: "View Students",
          url: "/teacher/students/view",
        },
      ],
    },

    {
      title: "Attendance",
      url: "/teacher/attendance",
      icon: <IconChecklist />,
      items: [
        {
          title: "Take Attendance",
          url: "/teacher/attendance/take",
        },
        {
          title: "View Attendance",
          url: "/teacher/attendance/view",
        },
      ],
    },

    {
      title: "Results",
      url: "/teacher/results",
      icon: <IconFileText />,
      items: [
        {
          title: "Create Result",
          url: "/teacher/results/create",
        },
        {
          title: "View Results",
          url: "/teacher/results/view",
        },
      ],
    },

    {
      title: "Timetable",
      url: "/teacher/timetable",
      icon: <IconCalendar />,
    },

    {
      title: "Notices",
      url: "/teacher/notices",
      icon: <IconBell />,
    },

    {
      title: "Settings",
      url: "/teacher/settings",
      icon: <IconSettings />,
    },
  ],

  projects: [], // ❌ REMOVE (not needed for ERP)
}

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <TeamSwitcher teams={data.teams} />
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        <NavProjects projects={data.projects} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
