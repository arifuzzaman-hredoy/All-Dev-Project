import React from "react";

type Props = {
  title: string;
  description?: string;
  sourcePath?: string;
};

export function PageHeader({ title, description, sourcePath }: Props) {
  return (
    <header className="mb-6">
      <h1 className="text-2xl font-semibold">{title}</h1>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      {sourcePath && (
        <div className="mt-2 text-xs text-muted-foreground">
          Source: {sourcePath}
        </div>
      )}
    </header>
  );
}

export default PageHeader;
