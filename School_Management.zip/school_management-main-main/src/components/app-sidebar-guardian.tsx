"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar";
import {
  Bell,
  CalendarCheck,
  CreditCard,
  FileText,
  LayoutDashboard,
  Settings,
  User,
  Users,
} from "lucide-react";

const navItems = [
  { title: "Dashboard", url: "/guardian", icon: LayoutDashboard },
  { title: "Profile", url: "/guardian/profile", icon: User },
  { title: "Children", url: "/guardian/children", icon: Users },
  { title: "Attendance", url: "/guardian/attendance", icon: CalendarCheck },
  { title: "Results", url: "/guardian/results", icon: FileText },
  { title: "Fees", url: "/guardian/fees", icon: CreditCard },
  { title: "Notices", url: "/guardian/notices", icon: Bell },
  { title: "Settings", url: "/guardian/settings", icon: Settings },
];

export function AppSidebar(props: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();

  return (
    <Sidebar {...props}>
      <SidebarHeader>
        <div className="px-2 py-1 text-lg font-semibold">Guardian Panel</div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link href={item.url} className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
  );
}
