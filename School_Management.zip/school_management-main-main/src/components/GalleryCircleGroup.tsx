import React from 'react'
import CirclePath from './circle-path'
import { SendIcon } from 'lucide-react'
import { Button } from './ui/button'
import Link from 'next/link'

const GalleryCircleGroup = () => {
  return (
    <div className='mx-auto w-full max-w-3xl  text-center sm:max-w-3xl'>
      <div className="mx-auto mb-8 max-w-xl text-center sm:max-w-3xl">
        <h2 className="font-heading mb-6 text-4xl text-balance lg:text-5xl lg:leading-14">
          Our Image Gallery <span className="font-serif italic">You can see</span>
        </h2>
        <p className="text-muted-foreground mx-auto max-w-xl text-balance">
          Book a free 30 min call and see how we turn property views into serious buyers
        </p>
      </div>

      {/* CTA Button */}
      <div className="mb-16 flex justify-center">
        <Button asChild size="lg" className="rounded-full">
          <Link href="/gallery" className='flex items-center gap-2'>
            <SendIcon />
            View Gallery
          </Link>
        </Button>
      </div>
      <CirclePath />
    </div>
  )
}

export default GalleryCircleGroup