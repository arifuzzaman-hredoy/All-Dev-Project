import React from "react";

type Props = {
  data?: unknown;
  error?: string | null;
  loading?: boolean;
  title?: string;
};

export function ResultDisplay({ data, error, loading, title }: Props) {
  return (
    <div className="mt-4">
      {title && <h3 className="text-lg font-medium">{title}</h3>}
      {loading && <p className="text-sm text-muted-foreground">Loading…</p>}
      {error && <pre className="text-sm text-destructive">{error}</pre>}
      {data !== undefined && data !== null && (
        <pre className="mt-2 rounded border p-2 text-sm bg-background">
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  );
}

export default ResultDisplay;
