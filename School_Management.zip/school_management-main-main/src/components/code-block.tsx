import React from "react";

type Props = {
  code: string;
  title?: string;
};

export function CodeBlock({ code, title }: Props) {
  return (
    <div className="rounded-md border border-border bg-muted p-4 text-sm">
      {title && <div className="mb-2 font-medium">{title}</div>}
      <pre className="whitespace-pre-wrap overflow-x-auto">{code}</pre>
    </div>
  );
}

export default CodeBlock;
