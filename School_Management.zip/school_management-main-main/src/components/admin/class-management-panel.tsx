"use client";

import {
  useCallback,
  useEffect,
  useState,
  type DragEvent,
  type FormEvent,
} from "react";
import Link from "next/link";
import { GripVertical } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type ClassRecord = {
  id: string;
  name: string;
  sortOrder: number;
  studentLimit: number | null;
  createdAt: string;
  _count: { students: number; groups: number; subjects: number };
  totalStudents: number;
  studentSummary: GenderSummary;
  groupSummaries: Array<{
    id: string | null;
    name: string;
    totalStudents: number;
    totals: GenderSummary;
  }>;
};

type ClassResponse = {
  classes: ClassRecord[];
  stats: {
    total: number;
    totalStudents: number;
    totalBoys: number;
    totalGirls: number;
    totalOther: number;
    totalGroups: number;
    totalSubjects: number;
  };
};

type GenderSummary = {
  MALE: number;
  FEMALE: number;
  OTHER: number;
};

export function ClassManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [classes, setClasses] = useState<ClassRecord[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    totalStudents: 0,
    totalBoys: 0,
    totalGirls: 0,
    totalOther: 0,
    totalGroups: 0,
    totalSubjects: 0,
  });
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [name, setName] = useState("");
  const [studentLimit, setStudentLimit] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [editingStudentLimit, setEditingStudentLimit] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isDefaultClass = (item: ClassRecord) =>
    item.name.trim().toLowerCase() === "unassigned";

  const isDeletable = (item: ClassRecord) => {
    return (
      !isDefaultClass(item) &&
      item._count.students === 0 &&
      item._count.groups === 0 &&
      item._count.subjects === 0
    );
  };

  const isOrderingDisabled = search.trim().length > 0;

  useEffect(() => setAuthState(readAuth()), []);

  const loadClasses = useCallback(
    async (nextAuth: AuthStorage, currentSearch = search) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) params.set("search", currentSearch.trim());
        const response = await fetch(`/api/v1/classes?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok)
          throw new Error(json.message ?? "Unable to load classes");
        const data = json.data as ClassResponse;
        setClasses(data.classes);
        setStats(data.stats);
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load classes",
        );
      } finally {
        setLoading(false);
      }
    },
    [search],
  );

  useEffect(() => {
    if (authState) void loadClasses(authState);
  }, [authState, loadClasses]);

  const refresh = async () => {
    if (authState) await loadClasses(authState);
  };

  const persistOrder = async (nextClasses: ClassRecord[]) => {
    if (!authState) return;
    if (isOrderingDisabled) {
      setError("Clear the search filter before changing class order.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const orderedClassIds = nextClasses
        .filter((item) => !isDefaultClass(item))
        .map((item) => item.id);
      const response = await fetch("/api/v1/classes/order", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ orderedClassIds }),
      });
      const json = await response.json();
      if (!response.ok)
        throw new Error(json.message ?? "Unable to update class order");
      const data = json.data as ClassResponse;
      setClasses(data.classes);
      setStats(data.stats);
    } catch (exception) {
      await loadClasses(authState, "");
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update class order",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const moveClass = async (id: string, direction: -1 | 1) => {
    if (isOrderingDisabled) {
      setError("Clear the search filter before changing class order.");
      return;
    }
    const index = classes.findIndex((item) => item.id === id);
    if (index < 0) return;
    if (isDefaultClass(classes[index])) return;

    const swapIndex = index + direction;
    if (swapIndex < 0 || swapIndex >= classes.length) return;
    if (isDefaultClass(classes[swapIndex])) return;

    const next = [...classes];
    const temp = next[index];
    next[index] = next[swapIndex];
    next[swapIndex] = temp;
    setClasses(next);
    await persistOrder(next);
  };

  const moveDraggedClass = async (sourceId: string, targetId: string) => {
    if (sourceId === targetId || isOrderingDisabled) return;
    const sourceIndex = classes.findIndex((item) => item.id === sourceId);
    const targetIndex = classes.findIndex((item) => item.id === targetId);
    if (sourceIndex < 0 || targetIndex < 0) return;
    if (isDefaultClass(classes[sourceIndex]) || isDefaultClass(classes[targetIndex])) {
      return;
    }

    const next = [...classes];
    const [moved] = next.splice(sourceIndex, 1);
    next.splice(targetIndex, 0, moved);
    setClasses(next);
    await persistOrder(next);
  };

  const onDragStart = (event: DragEvent<HTMLElement>, item: ClassRecord) => {
    if (isDefaultClass(item) || isOrderingDisabled || editingId) {
      event.preventDefault();
      return;
    }
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", item.id);
    setDraggingId(item.id);
  };

  const onDrop = (event: DragEvent<HTMLElement>, target: ClassRecord) => {
    event.preventDefault();
    const sourceId = event.dataTransfer.getData("text/plain") || draggingId;
    setDraggingId(null);
    if (!sourceId) return;
    void moveDraggedClass(sourceId, target.id);
  };

  const createClass = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/v1/classes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name,
          studentLimit: studentLimit ? Number(studentLimit) : null,
        }),
      });
      const json = await response.json();
      if (!response.ok)
        throw new Error(json.message ?? "Unable to create class");
      setName("");
      setStudentLimit("");
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create class",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const saveClass = async (id: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/classes/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name: editingName,
          studentLimit: editingStudentLimit
            ? Number(editingStudentLimit)
            : null,
        }),
      });
      const json = await response.json();
      if (!response.ok)
        throw new Error(json.message ?? "Unable to update class");
      setEditingId(null);
      setEditingName("");
      setEditingStudentLimit("");
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update class",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteClass = async (id: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/classes/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      });
      const json = await response.json();
      if (!response.ok)
        throw new Error(json.message ?? "Unable to delete class");

      const deletedClass = classes.find((item) => item.id === id);
      setClasses((currentClasses) =>
        currentClasses.filter((item) => item.id !== id),
      );
      setStats((currentStats) => ({
        ...currentStats,
        total: Math.max(currentStats.total - 1, 0),
        totalStudents: Math.max(
          currentStats.totalStudents - (deletedClass?.totalStudents ?? 0),
          0,
        ),
        totalBoys: Math.max(
          currentStats.totalBoys - (deletedClass?.studentSummary.MALE ?? 0),
          0,
        ),
        totalGirls: Math.max(
          currentStats.totalGirls - (deletedClass?.studentSummary.FEMALE ?? 0),
          0,
        ),
        totalOther: Math.max(
          currentStats.totalOther - (deletedClass?.studentSummary.OTHER ?? 0),
          0,
        ),
        totalGroups: Math.max(
          currentStats.totalGroups - (deletedClass?._count.groups ?? 0),
          0,
        ),
        totalSubjects: Math.max(
          currentStats.totalSubjects - (deletedClass?._count.subjects ?? 0),
          0,
        ),
      }));

      if (editingId === id) {
        setEditingId(null);
        setEditingName("");
      }
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to delete class",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Structure
        </p>
        <h1 className="text-2xl font-semibold">Class management</h1>
      </section>
      <div className="grid gap-4 sm:grid-cols-4">
        <Card>
          <CardHeader>
            <CardDescription>Classes</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Active students</CardDescription>
            <CardTitle>{stats.totalStudents}</CardTitle>
            <CardDescription>
              Boys {stats.totalBoys} · Girls {stats.totalGirls}
              {stats.totalOther > 0 ? ` · Other ${stats.totalOther}` : ""}
            </CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Groups</CardDescription>
            <CardTitle>{stats.totalGroups}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Subjects</CardDescription>
            <CardTitle>{stats.totalSubjects}</CardTitle>
          </CardHeader>
        </Card>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Add class</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createClass}>
              <div className="space-y-2">
                <Label htmlFor="class-name">Class name</Label>
                <Input
                  id="class-name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="class-student-limit">Class student limit</Label>
                <Input
                  id="class-student-limit"
                  type="number"
                  min={1}
                  value={studentLimit}
                  onChange={(event) => setStudentLimit(event.target.value)}
                  placeholder="Unlimited"
                />
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create class"}
              </Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Classes</CardTitle>
            <CardDescription>
              Drag classes to set the promotion/migration order. Clear search
              before reordering so the full sequence is saved safely.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search classes"
              />
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>
            {error && <div className="text-xs text-destructive">{error}</div>}
            {isOrderingDisabled ? (
              <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                Ordering is paused while search is active. Clear the filter to
                drag or move classes.
              </div>
            ) : null}
            {loading ? (
              <p className="text-xs text-muted-foreground">Loading classes…</p>
            ) : (
              <div className="space-y-3">
                {classes.map((item) => (
                  <article
                    key={item.id}
                    draggable={!isDefaultClass(item) && !isOrderingDisabled && !editingId}
                    onDragStart={(event) => onDragStart(event, item)}
                    onDragOver={(event) => {
                      if (!isDefaultClass(item) && !isOrderingDisabled) {
                        event.preventDefault();
                      }
                    }}
                    onDrop={(event) => onDrop(event, item)}
                    onDragEnd={() => setDraggingId(null)}
                    className={`rounded-none border border-border bg-background/60 p-4 transition ${
                      draggingId === item.id ? "opacity-50" : ""
                    }`}
                  >
                    <div className="flex gap-3">
                      <button
                        type="button"
                        aria-label={`Drag ${item.name}`}
                        title="Drag to reorder"
                        disabled={submitting || isDefaultClass(item) || isOrderingDisabled || Boolean(editingId)}
                        className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        <GripVertical className="h-4 w-4" aria-hidden="true" />
                      </button>
                      <div className="min-w-0 flex-1 space-y-2">
                        {editingId === item.id ? (
                          <div className="grid gap-2 sm:grid-cols-2">
                            <Input
                              value={editingName}
                              onChange={(event) =>
                                setEditingName(event.target.value)
                              }
                            />
                            <Input
                              type="number"
                              min={1}
                              value={editingStudentLimit}
                              onChange={(event) =>
                                setEditingStudentLimit(event.target.value)
                              }
                              placeholder="Unlimited class limit"
                            />
                          </div>
                        ) : (
                          <h3 className="text-sm font-semibold text-foreground">
                            {item.name}
                          </h3>
                        )}
                        {!isDefaultClass(item) ? (
                          <p className="text-[11px] text-muted-foreground">
                            Promotion order: {item.sortOrder || "Not set"}
                          </p>
                        ) : (
                          <p className="text-[11px] text-muted-foreground">
                            Default holding class
                          </p>
                        )}
                        <div className="grid gap-2 text-xs text-muted-foreground sm:grid-cols-3">
                          <div className="rounded-md border border-border px-3 py-2">
                            <span className="block text-[11px] uppercase text-muted-foreground">
                              Total
                            </span>
                            <strong className="text-sm text-foreground">
                              {item.totalStudents}
                            </strong>
                          </div>
                          <div className="rounded-md border border-border px-3 py-2">
                            <span className="block text-[11px] uppercase text-muted-foreground">
                              Boys
                            </span>
                            <strong className="text-sm text-foreground">
                              {item.studentSummary.MALE}
                            </strong>
                          </div>
                          <div className="rounded-md border border-border px-3 py-2">
                            <span className="block text-[11px] uppercase text-muted-foreground">
                              Girls
                            </span>
                            <strong className="text-sm text-foreground">
                              {item.studentSummary.FEMALE}
                            </strong>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {item._count.groups} groups · {item._count.subjects} subjects
                          {" · "}
                          Class limit {item.studentLimit ?? "Unlimited"}
                          {item.studentSummary.OTHER > 0
                            ? ` · Other ${item.studentSummary.OTHER}`
                            : ""}
                        </p>
                        {item.groupSummaries.length > 0 ? (
                          <div className="grid gap-2 sm:grid-cols-2">
                            {item.groupSummaries.map((group) => (
                              <div
                                key={group.id ?? `${item.id}-unassigned`}
                                className="rounded-md bg-muted/40 px-3 py-2 text-xs"
                              >
                                <div className="font-medium text-foreground">
                                  {group.name}
                                </div>
                                <div className="text-muted-foreground">
                                  Total {group.totalStudents} · Boys{" "}
                                  {group.totals.MALE} · Girls{" "}
                                  {group.totals.FEMALE}
                                  {group.totals.OTHER > 0
                                    ? ` · Other ${group.totals.OTHER}`
                                    : ""}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : null}
                      {!isDeletable(item) ? (
                        <p className="text-[11px] text-muted-foreground">
                          This class cannot be deleted until all linked records
                          are moved away.
                        </p>
                      ) : null}
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      {editingId === item.id ? (
                        <>
                          <Button
                            size="sm"
                            type="button"
                            onClick={() => void saveClass(item.id)}
                            disabled={submitting}
                          >
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(null);
                              setEditingName("");
                              setEditingStudentLimit("");
                            }}
                          >
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            size="sm"
                            variant="secondary"
                            type="button"
                            asChild
                            disabled={submitting || isDefaultClass(item)}
                          >
                            <Link href={`/admin/classes/${item.id}/groups`}>Groups</Link>
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => void moveClass(item.id, -1)}
                            disabled={submitting || isDefaultClass(item) || isOrderingDisabled}
                          >
                            Up
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => void moveClass(item.id, 1)}
                            disabled={submitting || isDefaultClass(item) || isOrderingDisabled}
                          >
                            Down
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(item.id);
                              setEditingName(item.name);
                              setEditingStudentLimit(
                                item.studentLimit?.toString() ?? "",
                              );
                            }}
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            type="button"
                            onClick={() => void deleteClass(item.id)}
                            disabled={
                              submitting || !isDeletable(item) || isDefaultClass(item)
                            }
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
