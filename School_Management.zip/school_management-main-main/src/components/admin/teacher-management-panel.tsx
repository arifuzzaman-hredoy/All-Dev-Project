"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type TeacherRecord = {
  id: string
  phone: string | null
  address: string | null
  salary: number | null
  isDeleted: boolean
  createdAt: string
  managedClasses: Array<{ id: string; classId: string; class: { id: string; name: string } }>
  subjects: Array<{ id: string; classId: string; subjectId: string; class: { id: string; name: string }; subject: { id: string; name: string } }>
  user: { id: string; name: string; email: string }
}

type ClassOption = {
  id: string
  name: string
}

type SubjectOption = {
  id: string
  name: string
  classId: string
  className: string
}

type TeacherResponse = {
  teachers: TeacherRecord[]
  classes: ClassOption[]
  subjects: SubjectOption[]
  stats: { total: number; active: number; deleted: number }
}

type TeacherForm = {
  name: string
  email: string
  password: string
  phone: string
  address: string
  salary: string
  classIds: string[]
  subjectAssignments: Array<{ classId: string; subjectId: string }>
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value))
}

export function TeacherManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [teachers, setTeachers] = useState<TeacherRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [subjects, setSubjects] = useState<SubjectOption[]>([])
  const [stats, setStats] = useState({ total: 0, active: 0, deleted: 0 })
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [createForm, setCreateForm] = useState<TeacherForm>({
    name: "",
    email: "",
    password: "",
    phone: "",
    address: "",
    salary: "",
    classIds: [],
    subjectAssignments: [],
  })
  const [editForm, setEditForm] = useState<TeacherForm | null>(null)

  useEffect(() => {
    setAuthState(readAuth())
  }, [])

  const loadTeachers = useCallback(
    async (nextAuthState: AuthStorage, currentSearch = search) => {
      setLoading(true)
      setError(null)

      try {
        const params = new URLSearchParams()
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim())
        }

        const response = await fetch(`/api/v1/teachers?${params.toString()}`, {
          headers: {
            Authorization: `Bearer ${nextAuthState.token}`,
          },
        })
        const json = await response.json()
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load teachers")
        }

        const data = json.data as TeacherResponse
        setTeachers(data.teachers)
        setClasses(data.classes)
        setSubjects(data.subjects)
        setStats(data.stats)
      } catch (exception) {
        console.error(exception)
        setError(exception instanceof Error ? exception.message : "Unable to load teachers")
      } finally {
        setLoading(false)
      }
    },
    [search]
  )

  useEffect(() => {
    if (!authState) return
    void loadTeachers(authState)
  }, [authState, loadTeachers])

  const refresh = async () => {
    if (authState) {
      await loadTeachers(authState)
    }
  }

  const serializePayload = (form: TeacherForm) => ({
    name: form.name,
    email: form.email,
    password: form.password || undefined,
    phone: form.phone || undefined,
    address: form.address || undefined,
    salary: form.salary ? Number(form.salary) : undefined,
    classIds: form.classIds,
    subjectAssignments: form.subjectAssignments,
  })

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!authState) return

    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch("/api/v1/teachers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(serializePayload(createForm)),
      })
      const json = await response.json()
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create teacher")
      }

      setCreateForm({
        name: "",
        email: "",
        password: "",
        phone: "",
        address: "",
        salary: "",
        classIds: [],
        subjectAssignments: [],
      })
      await refresh()
    } catch (exception) {
      console.error(exception)
      setError(exception instanceof Error ? exception.message : "Unable to create teacher")
    } finally {
      setSubmitting(false)
    }
  }

  const startEditing = (teacher: TeacherRecord) => {
    setEditingId(teacher.id)
    setEditForm({
      name: teacher.user.name,
      email: teacher.user.email,
      password: "",
      phone: teacher.phone ?? "",
      address: teacher.address ?? "",
      salary: teacher.salary?.toString() ?? "",
      classIds: teacher.managedClasses.map((item) => item.classId),
      subjectAssignments: teacher.subjects.map((item) => ({
        classId: item.classId,
        subjectId: item.subjectId,
      })),
    })
  }

  const toggleClass = (target: "create" | "edit", classId: string) => {
    const apply = (currentIds: string[]) =>
      currentIds.includes(classId)
        ? currentIds.filter((id) => id !== classId)
        : [...currentIds, classId]

    if (target === "create") {
      setCreateForm((prev) => {
        const nextClassIds = apply(prev.classIds)
        return {
          ...prev,
          classIds: nextClassIds,
          subjectAssignments: prev.subjectAssignments.filter((item) => nextClassIds.includes(item.classId)),
        }
      })
      return
    }

    setEditForm((prev) => {
      if (!prev) return prev
      const nextClassIds = apply(prev.classIds)
      return {
        ...prev,
        classIds: nextClassIds,
        subjectAssignments: prev.subjectAssignments.filter((item) => nextClassIds.includes(item.classId)),
      }
    })
  }

  const toggleSubjectAssignment = (target: "create" | "edit", classId: string, subjectId: string) => {
    const apply = (current: TeacherForm["subjectAssignments"]) => {
      const exists = current.some((item) => item.classId === classId && item.subjectId === subjectId)
      if (exists) {
        return current.filter((item) => !(item.classId === classId && item.subjectId === subjectId))
      }
      return [...current, { classId, subjectId }]
    }

    if (target === "create") {
      setCreateForm((prev) => ({ ...prev, subjectAssignments: apply(prev.subjectAssignments) }))
      return
    }

    setEditForm((prev) => (prev ? { ...prev, subjectAssignments: apply(prev.subjectAssignments) } : prev))
  }

  const handleUpdate = async (teacherId: string) => {
    if (!authState || !editForm) return

    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch(`/api/v1/teachers/${teacherId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(serializePayload(editForm)),
      })
      const json = await response.json()
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update teacher")
      }

      setEditingId(null)
      setEditForm(null)
      await refresh()
    } catch (exception) {
      console.error(exception)
      setError(exception instanceof Error ? exception.message : "Unable to update teacher")
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (teacherId: string) => {
    if (!authState) return

    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch(`/api/v1/teachers/${teacherId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${authState.token}`,
        },
      })
      const json = await response.json()
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to deactivate teacher")
      }

      await refresh()
    } catch (exception) {
      console.error(exception)
      setError(exception instanceof Error ? exception.message : "Unable to deactivate teacher")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Operations</p>
        <h1 className="text-2xl font-semibold">Teacher management</h1>
        <p className="max-w-3xl text-sm text-slate-200">Create and maintain teacher portal accounts, contact records, and salary references.</p>
      </section>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card><CardHeader><CardDescription>Total</CardDescription><CardTitle>{stats.total}</CardTitle></CardHeader></Card>
        <Card><CardHeader><CardDescription>Active</CardDescription><CardTitle>{stats.active}</CardTitle></CardHeader></Card>
        <Card><CardHeader><CardDescription>Deactivated</CardDescription><CardTitle>{stats.deleted}</CardTitle></CardHeader></Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader><CardTitle>Add teacher</CardTitle><CardDescription>Create a teacher account and HR profile baseline.</CardDescription></CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleCreate}>
              <div className="space-y-2"><Label htmlFor="teacher-name">Name</Label><Input id="teacher-name" value={createForm.name} onChange={(event) => setCreateForm((prev) => ({ ...prev, name: event.target.value }))} required /></div>
              <div className="space-y-2"><Label htmlFor="teacher-email">Email</Label><Input id="teacher-email" type="email" value={createForm.email} onChange={(event) => setCreateForm((prev) => ({ ...prev, email: event.target.value }))} required /></div>
              <div className="space-y-2"><Label htmlFor="teacher-password">Password</Label><Input id="teacher-password" type="password" minLength={8} value={createForm.password} onChange={(event) => setCreateForm((prev) => ({ ...prev, password: event.target.value }))} required /></div>
              <div className="space-y-2"><Label htmlFor="teacher-phone">Phone</Label><Input id="teacher-phone" value={createForm.phone} onChange={(event) => setCreateForm((prev) => ({ ...prev, phone: event.target.value }))} /></div>
              <div className="space-y-2"><Label htmlFor="teacher-address">Address</Label><Input id="teacher-address" value={createForm.address} onChange={(event) => setCreateForm((prev) => ({ ...prev, address: event.target.value }))} /></div>
              <div className="space-y-2"><Label htmlFor="teacher-salary">Salary</Label><Input id="teacher-salary" type="number" min="0" value={createForm.salary} onChange={(event) => setCreateForm((prev) => ({ ...prev, salary: event.target.value }))} /></div>
              <div className="space-y-2">
                <Label>Managed classes</Label>
                <div className="max-h-40 space-y-2 overflow-y-auto rounded-none border border-border p-3">
                  {classes.map((item) => (
                    <label key={item.id} className="flex items-center gap-2 text-xs">
                      <input
                        type="checkbox"
                        checked={createForm.classIds.includes(item.id)}
                        onChange={() => toggleClass("create", item.id)}
                      />
                      <span>{item.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Assigned subjects</Label>
                <div className="max-h-48 space-y-3 overflow-y-auto rounded-none border border-border p-3">
                  {classes.filter((item) => createForm.classIds.includes(item.id)).map((classItem) => {
                    const classSubjects = subjects.filter((subject) => subject.classId === classItem.id)
                    return (
                      <div key={classItem.id} className="space-y-2">
                        <p className="text-xs font-semibold text-foreground">{classItem.name}</p>
                        <div className="space-y-2">
                          {classSubjects.length === 0 ? (
                            <p className="text-xs text-muted-foreground">No subjects in this class</p>
                          ) : classSubjects.map((subject) => (
                            <label key={subject.id} className="flex items-center gap-2 text-xs">
                              <input
                                type="checkbox"
                                checked={createForm.subjectAssignments.some((item) => item.classId === classItem.id && item.subjectId === subject.id)}
                                onChange={() => toggleSubjectAssignment("create", classItem.id, subject.id)}
                              />
                              <span>{subject.name}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                  {createForm.classIds.length === 0 ? (
                    <p className="text-xs text-muted-foreground">Select classes first to assign subjects.</p>
                  ) : null}
                </div>
              </div>
              <Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create teacher"}</Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Directory</CardTitle><CardDescription>Search and update teacher records.</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <form className="grid gap-3 md:grid-cols-[1fr_auto]" onSubmit={(event) => { event.preventDefault(); void refresh() }}>
              <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name, email, phone" />
              <Button type="submit" variant="outline">Filter</Button>
            </form>
            {error && <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">{error}</div>}
            {loading ? <p className="text-xs text-muted-foreground">Loading teachers…</p> : (
              <div className="space-y-3">
                {teachers.map((teacher) => {
                  const isEditing = editingId === teacher.id && editForm !== null
                  return (
                    <article key={teacher.id} className="space-y-3 rounded-none border border-border bg-background/60 p-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant={teacher.isDeleted ? "destructive" : "secondary"}>{teacher.isDeleted ? "Deactivated" : "Active"}</Badge>
                        <span className="text-xs text-muted-foreground">Created {formatDate(teacher.createdAt)}</span>
                      </div>
                      {isEditing ? (
                        <div className="grid gap-3 md:grid-cols-2">
                          <Input value={editForm.name} onChange={(event) => setEditForm((prev) => prev ? { ...prev, name: event.target.value } : prev)} />
                          <Input type="email" value={editForm.email} onChange={(event) => setEditForm((prev) => prev ? { ...prev, email: event.target.value } : prev)} />
                          <Input type="password" placeholder="New password" value={editForm.password} onChange={(event) => setEditForm((prev) => prev ? { ...prev, password: event.target.value } : prev)} />
                          <Input value={editForm.phone} onChange={(event) => setEditForm((prev) => prev ? { ...prev, phone: event.target.value } : prev)} />
                          <Input value={editForm.address} onChange={(event) => setEditForm((prev) => prev ? { ...prev, address: event.target.value } : prev)} />
                          <Input type="number" min="0" value={editForm.salary} onChange={(event) => setEditForm((prev) => prev ? { ...prev, salary: event.target.value } : prev)} />
                          <div className="space-y-2 md:col-span-2">
                            <Label>Managed classes</Label>
                            <div className="max-h-40 space-y-2 overflow-y-auto rounded-none border border-border p-3">
                              {classes.map((item) => (
                                <label key={item.id} className="flex items-center gap-2 text-xs">
                                  <input
                                    type="checkbox"
                                    checked={editForm.classIds.includes(item.id)}
                                    onChange={() => toggleClass("edit", item.id)}
                                  />
                                  <span>{item.name}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                          <div className="space-y-2 md:col-span-2">
                            <Label>Assigned subjects</Label>
                            <div className="max-h-48 space-y-3 overflow-y-auto rounded-none border border-border p-3">
                              {classes.filter((item) => editForm.classIds.includes(item.id)).map((classItem) => {
                                const classSubjects = subjects.filter((subject) => subject.classId === classItem.id)
                                return (
                                  <div key={classItem.id} className="space-y-2">
                                    <p className="text-xs font-semibold text-foreground">{classItem.name}</p>
                                    <div className="space-y-2">
                                      {classSubjects.length === 0 ? (
                                        <p className="text-xs text-muted-foreground">No subjects in this class</p>
                                      ) : classSubjects.map((subject) => (
                                        <label key={subject.id} className="flex items-center gap-2 text-xs">
                                          <input
                                            type="checkbox"
                                            checked={editForm.subjectAssignments.some((item) => item.classId === classItem.id && item.subjectId === subject.id)}
                                            onChange={() => toggleSubjectAssignment("edit", classItem.id, subject.id)}
                                          />
                                          <span>{subject.name}</span>
                                        </label>
                                      ))}
                                    </div>
                                  </div>
                                )
                              })}
                              {editForm.classIds.length === 0 ? (
                                <p className="text-xs text-muted-foreground">Select classes first to assign subjects.</p>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <h3 className="text-sm font-semibold text-foreground">{teacher.user.name}</h3>
                          <p className="text-xs text-muted-foreground">{teacher.user.email}</p>
                          <p className="text-xs text-muted-foreground">{teacher.phone ?? "No phone"} · {teacher.salary ? `Salary ${teacher.salary}` : "Salary not set"}</p>
                          <p className="text-xs text-muted-foreground">
                            Managed classes: {teacher.managedClasses.length > 0 ? teacher.managedClasses.map((item) => item.class.name).join(", ") : "No class assigned"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Assigned subjects: {teacher.subjects.length > 0 ? teacher.subjects.map((item) => `${item.subject.name} (${item.class.name})`).join(", ") : "No subject assigned"}
                          </p>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-2">
                        {isEditing ? (
                          <>
                            <Button size="sm" onClick={() => void handleUpdate(teacher.id)} type="button" disabled={submitting}>{submitting ? "Saving…" : "Save changes"}</Button>
                            <Button size="sm" variant="outline" onClick={() => { setEditingId(null); setEditForm(null) }} type="button">Cancel</Button>
                          </>
                        ) : (
                          <>
                            <Button size="sm" variant="outline" onClick={() => startEditing(teacher)} type="button" disabled={teacher.isDeleted}>Edit</Button>
                            <Button size="sm" variant="destructive" onClick={() => void handleDelete(teacher.id)} type="button" disabled={submitting || teacher.isDeleted}>Deactivate</Button>
                          </>
                        )}
                      </div>
                    </article>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
