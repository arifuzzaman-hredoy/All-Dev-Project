"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
} from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type ClassOption = { id: string; name: string };
type TargetClassRecord = { classId: string; class: ClassOption };
type CategoryRecord = {
  id: string;
  name: string;
  amount: number;
  isActive: boolean;
  _count: { payments: number };
  targetClasses: TargetClassRecord[];
};

type CategoryResponse = {
  categories: CategoryRecord[];
  classes: ClassOption[];
  stats: { total: number; configuredAmount: number };
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-BD", {
    style: "currency",
    currency: "BDT",
    maximumFractionDigits: 0,
  }).format(value);
}

function classNamesFromCategory(category: CategoryRecord) {
  return category.targetClasses.map((item) => item.class.name);
}

function toggleClassId(currentIds: string[], classId: string) {
  return currentIds.includes(classId)
    ? currentIds.filter((item) => item !== classId)
    : [...currentIds, classId];
}

export function FeeCategoryManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [categories, setCategories] = useState<CategoryRecord[]>([]);
  const [classes, setClasses] = useState<ClassOption[]>([]);
  const [stats, setStats] = useState({ total: 0, configuredAmount: 0 });
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({
    name: "",
    amount: "",
    classIds: [] as string[],
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingForm, setEditingForm] = useState({
    name: "",
    amount: "",
    classIds: [] as string[],
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setAuthState(readAuth()), []);

  const loadCategories = useCallback(
    async (nextAuth: AuthStorage, currentSearch = search) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) params.set("search", currentSearch.trim());

        const response = await fetch(
          `/api/v1/fees/categories?${params.toString()}`,
          {
            headers: { Authorization: `Bearer ${nextAuth.token}` },
          },
        );
        const json = await response.json();

        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load fee categories");
        }

        const data = json.data as CategoryResponse;
        setCategories(data.categories);
        setClasses(data.classes);
        setStats(data.stats);
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load fee categories",
        );
      } finally {
        setLoading(false);
      }
    },
    [search],
  );

  useEffect(() => {
    if (authState) {
      void loadCategories(authState);
    }
  }, [authState, loadCategories]);

  const refresh = async () => {
    if (authState) {
      await loadCategories(authState);
    }
  };

  const createCategory = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/v1/fees/categories", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name: form.name,
          amount: Number(form.amount),
          classIds: form.classIds,
        }),
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create fee category");
      }

      setForm({ name: "", amount: "", classIds: [] });
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create fee category",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const saveCategory = async (id: string) => {
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/fees/categories/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name: editingForm.name,
          amount: Number(editingForm.amount),
          classIds: editingForm.classIds,
        }),
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update fee category");
      }

      setEditingId(null);
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update fee category",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const toggleCategoryStatus = async (id: string, nextActive: boolean) => {
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/fees/categories/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ isActive: nextActive }),
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update fee category status");
      }

      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update fee category status",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteCategory = async (
    id: string,
    options: { permanent?: boolean; force?: boolean } = {},
  ) => {
    if (!authState) return;

    const { permanent = false, force = false } = options;

    if (force) {
      const currentPassword = window.prompt(
        "Enter admin password to force delete this fee category",
      );

      if (!currentPassword) {
        return;
      }

      setSubmitting(true);
      setError(null);

      try {
        const response = await fetch(`/api/v1/fees/categories/${id}`, {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${authState.token}`,
          },
          body: JSON.stringify({ force: true, currentPassword }),
        });
        const json = await response.json();

        if (!response.ok) {
          throw new Error(
            json.message ?? "Unable to force delete fee category",
          );
        }

        await refresh();
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to force delete fee category",
        );
      } finally {
        setSubmitting(false);
      }

      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      if (
        permanent &&
        !window.confirm(
          "Delete this fee category permanently? This cannot be undone.",
        )
      ) {
        return;
      }

      const response = await fetch(
        `/api/v1/fees/categories/${id}${permanent ? "?permanent=true" : ""}`,
        {
          method: "DELETE",
          headers: { Authorization: `Bearer ${authState.token}` },
        },
      );
      const json = await response.json();

      if (!response.ok) {
        throw new Error(
          json.message ??
            (permanent
              ? "Unable to permanently delete fee category"
              : "Unable to deactivate fee category"),
        );
      }

      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : permanent
            ? "Unable to permanently delete fee category"
            : "Unable to deactivate fee category",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const sortedClasses = useMemo(
    () =>
      [...classes].sort((left, right) => left.name.localeCompare(right.name)),
    [classes],
  );
  const allClassIds = useMemo(
    () => sortedClasses.map((item) => item.id),
    [sortedClasses],
  );

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Finance
        </p>
        <h1 className="text-2xl font-semibold">Secondary fees</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-200/80">
          Create one-time fee heads, target them to classes, and let the system
          auto-assign due records to every student in scope.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardDescription>Fees</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Total configured amount</CardDescription>
            <CardTitle>{formatCurrency(stats.configuredAmount)}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Add secondary fee</CardTitle>
            <CardDescription>
              Select one or more classes to auto-create due records for the fee.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createCategory}>
              <div className="space-y-2">
                <Label htmlFor="fee-name">Fee name</Label>
                <Input
                  id="fee-name"
                  value={form.name}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, name: event.target.value }))
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fee-amount">Amount</Label>
                <Input
                  id="fee-amount"
                  type="number"
                  min="0"
                  value={form.amount}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, amount: event.target.value }))
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <Label>Target classes</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setForm((prev) => ({ ...prev, classIds: allClassIds }))
                      }
                      disabled={sortedClasses.length === 0}
                    >
                      Select all
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setForm((prev) => ({ ...prev, classIds: [] }))
                      }
                      disabled={sortedClasses.length === 0}
                    >
                      Remove all
                    </Button>
                  </div>
                </div>
                <div className="max-h-40 space-y-2 overflow-y-auto rounded-md border border-input px-3 py-3 flex flex-wrap gap-4">
                  {sortedClasses.length > 0 ? (
                    sortedClasses.map((item) => (
                      <label
                        key={item.id}
                        className="flex items-center gap-2 text-sm"
                      >
                        <input
                          type="checkbox"
                          checked={form.classIds.includes(item.id)}
                          onChange={() =>
                            setForm((prev) => ({
                              ...prev,
                              classIds: toggleClassId(prev.classIds, item.id),
                            }))
                          }
                        />
                        <span>{item.name}</span>
                      </label>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground">
                      No classes available.
                    </p>
                  )}
                </div>
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create fee"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configured fees</CardTitle>
            <CardDescription>
              Update the fee amount or class targets without losing existing
              dues.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search fees"
              />
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>

            {error && <div className="text-xs text-destructive">{error}</div>}

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading fees…</p>
            ) : (
              <div className="space-y-4">
                {categories.map((item) => {
                  const targetClassNames = classNamesFromCategory(item);

                  return (
                    <article
                      key={item.id}
                      className="overflow-hidden rounded-2xl border border-border/60 bg-background shadow-sm transition hover:shadow-md"
                    >
                      {editingId === item.id ? (
                        <div className="space-y-5 p-5">
                          <div className="grid gap-4 lg:grid-cols-2">
                            <div className="space-y-2">
                              <Label>Fee name</Label>
                              <Input
                                value={editingForm.name}
                                onChange={(event) =>
                                  setEditingForm((prev) => ({
                                    ...prev,
                                    name: event.target.value,
                                  }))
                                }
                                placeholder="Enter fee name"
                              />
                            </div>

                            <div className="space-y-2">
                              <Label>Amount</Label>
                              <Input
                                type="number"
                                min="0"
                                value={editingForm.amount}
                                onChange={(event) =>
                                  setEditingForm((prev) => ({
                                    ...prev,
                                    amount: event.target.value,
                                  }))
                                }
                                placeholder="Enter amount"
                              />
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                              <Label>Target classes</Label>

                              <div className="flex flex-wrap gap-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setEditingForm((prev) => ({
                                      ...prev,
                                      classIds: allClassIds,
                                    }))
                                  }
                                  disabled={sortedClasses.length === 0}
                                >
                                  Select all
                                </Button>

                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setEditingForm((prev) => ({
                                      ...prev,
                                      classIds: [],
                                    }))
                                  }
                                  disabled={sortedClasses.length === 0}
                                >
                                  Remove all
                                </Button>
                              </div>
                            </div>

                            <div className="grid max-h-52 gap-3 overflow-y-auto rounded-xl border border-input bg-muted/20 p-4 sm:grid-cols-2 xl:grid-cols-3">
                              {sortedClasses.length > 0 ? (
                                sortedClasses.map((classItem) => (
                                  <label
                                    key={classItem.id}
                                    className="flex items-center gap-3 rounded-lg border border-transparent bg-background px-3 py-2 text-sm transition hover:border-border"
                                  >
                                    <input
                                      type="checkbox"
                                      checked={editingForm.classIds.includes(
                                        classItem.id,
                                      )}
                                      onChange={() =>
                                        setEditingForm((prev) => ({
                                          ...prev,
                                          classIds: toggleClassId(
                                            prev.classIds,
                                            classItem.id,
                                          ),
                                        }))
                                      }
                                    />
                                    <span className="font-medium text-foreground">
                                      {classItem.name}
                                    </span>
                                  </label>
                                ))
                              ) : (
                                <p className="text-sm text-muted-foreground">
                                  No classes available.
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2 border-t border-border/60 pt-4">
                            <Button
                              size="sm"
                              type="button"
                              onClick={() => void saveCategory(item.id)}
                              disabled={submitting}
                            >
                              Save Changes
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              type="button"
                              onClick={() => setEditingId(null)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="p-5">
                          <div className="grid gap-5 xl:grid-cols-[1.4fr_180px_180px_1.2fr_160px] xl:items-start">
                            {/* Fee Info */}
                            <div className="space-y-1">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Fee Name
                              </p>
                              <h3 className="text-base font-semibold text-foreground">
                                {item.name}
                              </h3>
                            </div>

                            {/* Amount */}
                            <div className="space-y-1">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Amount
                              </p>
                              <p className="text-sm font-semibold text-foreground">
                                {formatCurrency(item.amount)}
                              </p>
                            </div>

                            {/* Status */}
                            <div className="space-y-1">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Status
                              </p>
                              <div className="flex flex-wrap items-center gap-2">
                                <span
                                  className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-medium ${
                                    item.isActive
                                      ? "bg-emerald-500/10 text-emerald-600"
                                      : "bg-red-500/10 text-red-600"
                                  }`}
                                >
                                  {item.isActive ? "Active" : "Inactive"}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {item._count.payments} due rows
                                </span>
                              </div>
                            </div>

                            {/* Target Classes */}
                            <div className="space-y-2">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                class
                              </p>

                              <div className="flex flex-wrap gap-2">
                                {targetClassNames.length > 0 ? (
                                  targetClassNames.map((className) => (
                                    <span
                                      key={className}
                                      className="rounded-full border border-border bg-muted/30 px-2.5 py-1 text-[11px] font-medium text-muted-foreground"
                                    >
                                      {className}
                                    </span>
                                  ))
                                ) : (
                                  <span className="text-xs text-muted-foreground">
                                    No classes assigned
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="space-y-2 xl:justify-self-end">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Actions
                              </p>

                              <div className="flex flex-wrap gap-2 xl:justify-end">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  type="button"
                                  onClick={() => {
                                    setEditingId(item.id);
                                    setEditingForm({
                                      name: item.name,
                                      amount: String(item.amount),
                                      classIds: item.targetClasses.map(
                                        (target) => target.classId,
                                      ),
                                    });
                                  }}
                                >
                                  Edit
                                </Button>

                                <Button
                                  size="sm"
                                  variant="outline"
                                  type="button"
                                  onClick={() =>
                                    void toggleCategoryStatus(
                                      item.id,
                                      !item.isActive,
                                    )
                                  }
                                  disabled={submitting}
                                >
                                  {item.isActive ? "Deactivate" : "Activate"}
                                </Button>

                                <Button
                                  size="sm"
                                  variant="destructive"
                                  type="button"
                                  onClick={() =>
                                    void deleteCategory(item.id, {
                                      permanent: true,
                                    })
                                  }
                                  disabled={
                                    submitting || item._count.payments > 0
                                  }
                                >
                                  Delete
                                </Button>

                                <Button
                                  size="sm"
                                  variant="destructive"
                                  type="button"
                                  onClick={() =>
                                    void deleteCategory(item.id, {
                                      force: true,
                                    })
                                  }
                                  disabled={submitting}
                                >
                                  Force delete
                                </Button>
                              </div>
                            </div>
                          </div>
                          <p className="mt-3 text-xs text-muted-foreground">
                            {item._count.payments > 0
                              ? "Delete is disabled because this fee category already has linked payment records. Use force delete and enter the admin password if you want to remove everything."
                              : "Delete is available only when no payment records exist yet."}
                          </p>
                        </div>
                      )}
                    </article>
                  );
                })}

                {categories.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-border bg-muted/20 px-4 py-8 text-center">
                    <p className="text-sm text-muted-foreground">
                      No fee categories match the current search.
                    </p>
                  </div>
                ) : null}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
