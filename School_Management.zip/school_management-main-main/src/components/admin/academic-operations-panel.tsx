"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type ClassOption = { id: string; name: string }
type TeacherOption = { id: string; name: string }
type SubjectOption = { id: string; name: string; classId?: string; className?: string }
type TeacherSubjectAssignment = {
  id: string
  teacher: { user: { name: string } }
  subject: { name: string }
  class: { name: string }
}
type TimetableEntry = {
  id: string
  day: string
  startTime: string
  endTime: string
  teacher: { user: { name: string } }
  subject: { name: string }
  class: { name: string }
}
type TeacherSubjectResponse = {
  assignments: TeacherSubjectAssignment[]
  teachers: TeacherOption[]
  classes: ClassOption[]
  subjects: SubjectOption[]
  stats: { total: number }
}
type TimetableResponse = {
  entries: TimetableEntry[]
  teachers: TeacherOption[]
  classes: ClassOption[]
  subjects: SubjectOption[]
  stats: { total: number }
}

const weekdays = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"] as const

export function AcademicOperationsPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [assignments, setAssignments] = useState<TeacherSubjectAssignment[]>([])
  const [entries, setEntries] = useState<TimetableEntry[]>([])
  const [teachers, setTeachers] = useState<TeacherOption[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [subjects, setSubjects] = useState<SubjectOption[]>([])
  const [assignmentStats, setAssignmentStats] = useState({ total: 0 })
  const [timetableStats, setTimetableStats] = useState({ total: 0 })
  const [assignmentForm, setAssignmentForm] = useState({ teacherId: "", subjectId: "", classId: "" })
  const [timetableForm, setTimetableForm] = useState({ classId: "", subjectId: "", teacherId: "", day: "MONDAY", startTime: "", endTime: "" })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => setAuthState(readAuth()), [])

  const loadData = useCallback(async (nextAuth: AuthStorage) => {
    setLoading(true)
    setError(null)
    try {
      const [assignmentResponse, timetableResponse] = await Promise.all([
        fetch("/api/v1/teacher-subjects", { headers: { Authorization: `Bearer ${nextAuth.token}` } }),
        fetch("/api/v1/timetable", { headers: { Authorization: `Bearer ${nextAuth.token}` } }),
      ])
      const assignmentJson = await assignmentResponse.json()
      const timetableJson = await timetableResponse.json()
      if (!assignmentResponse.ok) throw new Error(assignmentJson.message ?? "Unable to load teacher subject assignments")
      if (!timetableResponse.ok) throw new Error(timetableJson.message ?? "Unable to load timetable")

      const assignmentData = assignmentJson.data as TeacherSubjectResponse
      const timetableData = timetableJson.data as TimetableResponse

      setAssignments(assignmentData.assignments)
      setEntries(timetableData.entries)
      setTeachers(assignmentData.teachers)
      setClasses(assignmentData.classes)
      setSubjects(assignmentData.subjects)
      setAssignmentStats(assignmentData.stats)
      setTimetableStats(timetableData.stats)
      setAssignmentForm((prev) => ({
        teacherId: prev.teacherId || assignmentData.teachers[0]?.id || "",
        subjectId: prev.subjectId || assignmentData.subjects[0]?.id || "",
        classId: prev.classId || assignmentData.classes[0]?.id || "",
      }))
      setTimetableForm((prev) => ({
        ...prev,
        classId: prev.classId || timetableData.classes[0]?.id || "",
        teacherId: prev.teacherId || timetableData.teachers[0]?.id || "",
        subjectId: prev.subjectId || timetableData.subjects[0]?.id || "",
      }))
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to load academic operations")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (authState) void loadData(authState)
  }, [authState, loadData])

  const refresh = async () => {
    if (authState) await loadData(authState)
  }

  const createAssignment = async (event: FormEvent) => {
    event.preventDefault()
    if (!authState) return
    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch("/api/v1/teacher-subjects", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(assignmentForm),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to create assignment")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create assignment")
    } finally {
      setSubmitting(false)
    }
  }

  const deleteAssignment = async (id: string) => {
    if (!authState) return
    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch(`/api/v1/teacher-subjects/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to delete assignment")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to delete assignment")
    } finally {
      setSubmitting(false)
    }
  }

  const createTimetableEntry = async (event: FormEvent) => {
    event.preventDefault()
    if (!authState) return
    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch("/api/v1/timetable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(timetableForm),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to create timetable entry")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create timetable entry")
    } finally {
      setSubmitting(false)
    }
  }

  const deleteEntry = async (id: string) => {
    if (!authState) return
    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch(`/api/v1/timetable/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to delete timetable entry")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to delete timetable entry")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Academics</p>
        <h1 className="text-2xl font-semibold">Academic operations</h1>
      </section>
      <div className="grid gap-4 sm:grid-cols-2">
        <Card><CardHeader><CardDescription>Teacher-subject mappings</CardDescription><CardTitle>{assignmentStats.total}</CardTitle></CardHeader></Card>
        <Card><CardHeader><CardDescription>Timetable entries</CardDescription><CardTitle>{timetableStats.total}</CardTitle></CardHeader></Card>
      </div>
      {error && <div className="px-6 text-xs text-destructive">{error}</div>}
      <div className="grid gap-6 xl:grid-cols-2">
        <Card className="h-fit">
          <CardHeader><CardTitle>Teacher subject mapping</CardTitle><CardDescription>Assign a teacher to a subject and class.</CardDescription></CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createAssignment}>
              <div className="space-y-2"><Label htmlFor="assignment-teacher">Teacher</Label><select id="assignment-teacher" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={assignmentForm.teacherId} onChange={(event) => setAssignmentForm((prev) => ({ ...prev, teacherId: event.target.value }))}>{teachers.map((teacher) => <option key={teacher.id} value={teacher.id}>{teacher.name}</option>)}</select></div>
              <div className="space-y-2"><Label htmlFor="assignment-subject">Subject</Label><select id="assignment-subject" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={assignmentForm.subjectId} onChange={(event) => setAssignmentForm((prev) => ({ ...prev, subjectId: event.target.value }))}>{subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name} · {subject.className}</option>)}</select></div>
              <div className="space-y-2"><Label htmlFor="assignment-class">Class</Label><select id="assignment-class" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={assignmentForm.classId} onChange={(event) => setAssignmentForm((prev) => ({ ...prev, classId: event.target.value }))}>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div>
              <Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create mapping"}</Button>
            </form>
            <div className="mt-6 space-y-3">
              {loading ? <p className="text-xs text-muted-foreground">Loading mappings…</p> : assignments.map((item) => (
                <article key={item.id} className="rounded-none border border-border bg-background/60 p-4">
                  <h3 className="text-sm font-semibold text-foreground">{item.teacher.user.name}</h3>
                  <p className="text-xs text-muted-foreground">{item.subject.name} · {item.class.name}</p>
                  <div className="mt-3">
                    <Button size="sm" variant="destructive" type="button" onClick={() => void deleteAssignment(item.id)} disabled={submitting}>Delete</Button>
                  </div>
                </article>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="h-fit">
          <CardHeader><CardTitle>Timetable</CardTitle><CardDescription>Create weekly class schedule entries.</CardDescription></CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createTimetableEntry}>
              <div className="space-y-2"><Label htmlFor="timetable-class">Class</Label><select id="timetable-class" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={timetableForm.classId} onChange={(event) => setTimetableForm((prev) => ({ ...prev, classId: event.target.value }))}>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div>
              <div className="space-y-2"><Label htmlFor="timetable-subject">Subject</Label><select id="timetable-subject" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={timetableForm.subjectId} onChange={(event) => setTimetableForm((prev) => ({ ...prev, subjectId: event.target.value }))}>{subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name} · {subject.className}</option>)}</select></div>
              <div className="space-y-2"><Label htmlFor="timetable-teacher">Teacher</Label><select id="timetable-teacher" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={timetableForm.teacherId} onChange={(event) => setTimetableForm((prev) => ({ ...prev, teacherId: event.target.value }))}>{teachers.map((teacher) => <option key={teacher.id} value={teacher.id}>{teacher.name}</option>)}</select></div>
              <div className="grid gap-3 md:grid-cols-3">
                <div className="space-y-2"><Label htmlFor="timetable-day">Day</Label><select id="timetable-day" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={timetableForm.day} onChange={(event) => setTimetableForm((prev) => ({ ...prev, day: event.target.value }))}>{weekdays.map((day) => <option key={day} value={day}>{day}</option>)}</select></div>
                <div className="space-y-2"><Label htmlFor="timetable-start">Start</Label><Input id="timetable-start" type="time" value={timetableForm.startTime} onChange={(event) => setTimetableForm((prev) => ({ ...prev, startTime: event.target.value }))} required /></div>
                <div className="space-y-2"><Label htmlFor="timetable-end">End</Label><Input id="timetable-end" type="time" value={timetableForm.endTime} onChange={(event) => setTimetableForm((prev) => ({ ...prev, endTime: event.target.value }))} required /></div>
              </div>
              <Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create entry"}</Button>
            </form>
            <div className="mt-6 space-y-3">
              {loading ? <p className="text-xs text-muted-foreground">Loading timetable…</p> : entries.map((item) => (
                <article key={item.id} className="rounded-none border border-border bg-background/60 p-4">
                  <h3 className="text-sm font-semibold text-foreground">{item.class.name} · {item.subject.name}</h3>
                  <p className="text-xs text-muted-foreground">{item.teacher.user.name} · {item.day} · {item.startTime} - {item.endTime}</p>
                  <div className="mt-3">
                    <Button size="sm" variant="destructive" type="button" onClick={() => void deleteEntry(item.id)} disabled={submitting}>Delete</Button>
                  </div>
                </article>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
