"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type ClassOption = { id: string; name: string }
type SubjectRecord = { id: string; name: string; class: ClassOption; _count: { teachers: number; results: number; attendances: number } }
type SubjectResponse = { subjects: SubjectRecord[]; classes: ClassOption[]; stats: { total: number; linkedTeachers: number } }

export function SubjectManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [subjects, setSubjects] = useState<SubjectRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [stats, setStats] = useState({ total: 0, linkedTeachers: 0 })
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("ALL")
  const [createForm, setCreateForm] = useState({ name: "", classId: "" })
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingForm, setEditingForm] = useState({ name: "", classId: "" })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => setAuthState(readAuth()), [])

  const loadSubjects = useCallback(async (nextAuth: AuthStorage, currentSearch = search, currentClass = classFilter) => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      if (currentSearch.trim()) params.set("search", currentSearch.trim())
      if (currentClass !== "ALL") params.set("classId", currentClass)
      const response = await fetch(`/api/v1/subjects?${params.toString()}`, { headers: { Authorization: `Bearer ${nextAuth.token}` } })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to load subjects")
      const data = json.data as SubjectResponse
      setSubjects(data.subjects)
      setClasses(data.classes)
      setStats(data.stats)
      setCreateForm((prev) => ({ ...prev, classId: prev.classId || data.classes[0]?.id || "" }))
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to load subjects")
    } finally {
      setLoading(false)
    }
  }, [classFilter, search])

  useEffect(() => { if (authState) void loadSubjects(authState) }, [authState, loadSubjects])
  const refresh = async () => { if (authState) await loadSubjects(authState) }

  const createSubject = async (event: FormEvent) => {
    event.preventDefault()
    if (!authState) return
    setSubmitting(true)
    setError(null)
    try {
      const response = await fetch("/api/v1/subjects", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${authState.token}` }, body: JSON.stringify(createForm) })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to create subject")
      setCreateForm({ name: "", classId: classes[0]?.id || "" })
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create subject")
    } finally { setSubmitting(false) }
  }

  const saveSubject = async (id: string) => {
    if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const response = await fetch(`/api/v1/subjects/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: `Bearer ${authState.token}` }, body: JSON.stringify(editingForm) })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to update subject")
      setEditingId(null)
      await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to update subject") } finally { setSubmitting(false) }
  }

  const deleteSubject = async (id: string) => {
    if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const response = await fetch(`/api/v1/subjects/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${authState.token}` } })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to delete subject")
      await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to delete subject") } finally { setSubmitting(false) }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40"><p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Curriculum</p><h1 className="text-2xl font-semibold">Subject management</h1></section>
      <div className="grid gap-4 sm:grid-cols-2"><Card><CardHeader><CardDescription>Subjects</CardDescription><CardTitle>{stats.total}</CardTitle></CardHeader></Card><Card><CardHeader><CardDescription>Teacher links</CardDescription><CardTitle>{stats.linkedTeachers}</CardTitle></CardHeader></Card></div>
      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit"><CardHeader><CardTitle>Add subject</CardTitle></CardHeader><CardContent><form className="space-y-4" onSubmit={createSubject}><div className="space-y-2"><Label htmlFor="subject-name">Subject</Label><Input id="subject-name" value={createForm.name} onChange={(event) => setCreateForm((prev) => ({ ...prev, name: event.target.value }))} required /></div><div className="space-y-2"><Label htmlFor="subject-class">Class</Label><select id="subject-class" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={createForm.classId} onChange={(event) => setCreateForm((prev) => ({ ...prev, classId: event.target.value }))}>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create subject"}</Button></form></CardContent></Card>
        <Card><CardHeader><CardTitle>Subject list</CardTitle><CardDescription>Manage subjects by class.</CardDescription></CardHeader><CardContent className="space-y-4"><form className="grid gap-2 md:grid-cols-[1fr_180px_auto]" onSubmit={(event) => { event.preventDefault(); void refresh() }}><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search subjects" /><select className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={classFilter} onChange={(event) => setClassFilter(event.target.value)}><option value="ALL">All classes</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><Button type="submit" variant="outline">Filter</Button></form>{error && <div className="text-xs text-destructive">{error}</div>}{loading ? <p className="text-xs text-muted-foreground">Loading subjects…</p> : <div className="space-y-3">{subjects.map((item) => <article key={item.id} className="rounded-none border border-border bg-background/60 p-4"><div className="space-y-2">{editingId === item.id ? <div className="grid gap-2 md:grid-cols-2"><Input value={editingForm.name} onChange={(event) => setEditingForm((prev) => ({ ...prev, name: event.target.value }))} /><select className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={editingForm.classId} onChange={(event) => setEditingForm((prev) => ({ ...prev, classId: event.target.value }))}>{classes.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}</select></div> : <><h3 className="text-sm font-semibold text-foreground">{item.name}</h3><p className="text-xs text-muted-foreground">{item.class.name} · {item._count.teachers} teachers linked</p></>}</div><div className="mt-3 flex gap-2">{editingId === item.id ? <><Button size="sm" type="button" onClick={() => void saveSubject(item.id)} disabled={submitting}>Save</Button><Button size="sm" variant="outline" type="button" onClick={() => setEditingId(null)}>Cancel</Button></> : <><Button size="sm" variant="outline" type="button" onClick={() => { setEditingId(item.id); setEditingForm({ name: item.name, classId: item.class.id }) }}>Edit</Button><Button size="sm" variant="destructive" type="button" onClick={() => void deleteSubject(item.id)} disabled={submitting}>Delete</Button></>}</div></article>)}</div>}</CardContent></Card>
      </div>
    </div>
  )
}
