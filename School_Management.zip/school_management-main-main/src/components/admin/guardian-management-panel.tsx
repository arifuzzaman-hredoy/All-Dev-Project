"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type StudentOption = {
  id: string
  name: string
  className: string
  guardianId: string | null
  guardianName: string | null
}
type GuardianRecord = {
  id: string
  phone: string | null
  address: string | null
  user: { id: string; name: string; email: string; isDeleted: boolean }
  students: Array<{ id: string; user: { name: string }; class: { name: string } }>
}
type GuardianResponse = {
  guardians: GuardianRecord[]
  students: StudentOption[]
  stats: { total: number; linkedStudents: number }
  pagination: { page: number; pageSize: number; total: number; totalPages: number }
}

type TransferState = {
  studentId: string
  studentName: string
  currentGuardianId: string
  currentGuardianName: string
}

export function GuardianManagementPanel({
  mode = "all",
}: {
  mode?: "all" | "create" | "view"
}) {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [guardians, setGuardians] = useState<GuardianRecord[]>([])
  const [students, setStudents] = useState<StudentOption[]>([])
  const [stats, setStats] = useState({ total: 0, linkedStudents: 0 })
  const [search, setSearch] = useState("")
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [pagination, setPagination] = useState<GuardianResponse["pagination"]>({
    page: 1,
    pageSize: 20,
    total: 0,
    totalPages: 1,
  })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [, setEditingGuardianId] = useState<string | null>(null)
  const [linkDraftStudentIds, setLinkDraftStudentIds] = useState<string[]>([])
  const [linkDraftBaselineStudentIds, setLinkDraftBaselineStudentIds] = useState<
    string[]
  >([])
  const [detailsGuardianId, setDetailsGuardianId] = useState<string | null>(null)
  const [studentPickerOpen, setStudentPickerOpen] = useState(false)
  const [studentPickerMode, setStudentPickerMode] = useState<"create" | "link">(
    "create",
  )
  const [studentPickerGuardian, setStudentPickerGuardian] = useState<{
    id: string
    name: string
  } | null>(null)
  const [studentPickerSearch, setStudentPickerSearch] = useState("")
  const [studentPickerShowNotLinked, setStudentPickerShowNotLinked] =
    useState(true)
  const [studentPickerShowLinked, setStudentPickerShowLinked] = useState(true)
  const [transferState, setTransferState] = useState<TransferState | null>(null)
  const [transferTargetGuardianId, setTransferTargetGuardianId] = useState("")
  const [transferConfirmation, setTransferConfirmation] = useState("")
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    address: "",
    studentIds: [] as string[],
  })

  useEffect(() => setAuthState(readAuth()), [])

  const loadGuardians = useCallback(async (nextAuth: AuthStorage, currentSearch = search, currentPage = page) => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      if (currentSearch.trim()) params.set("search", currentSearch.trim())
      params.set("page", String(currentPage))
      params.set("pageSize", String(pageSize))
      const response = await fetch(`/api/v1/guardians?${params.toString()}`, {
        headers: { Authorization: `Bearer ${nextAuth.token}` },
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to load guardians")
      const data = json.data as GuardianResponse
      setGuardians(data.guardians)
      setStudents(data.students)
      setStats(data.stats)
      setPagination(data.pagination)
      setPage(data.pagination.page)
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to load guardians")
    } finally {
      setLoading(false)
    }
  }, [page, pageSize, search])

  useEffect(() => {
    if (authState) void loadGuardians(authState)
  }, [authState, loadGuardians])

  const refresh = async () => {
    if (authState) await loadGuardians(authState, search, page)
  }

  const handleStudentSelection = (studentId: string) => {
    setForm((prev) => ({
      ...prev,
      studentIds: prev.studentIds.includes(studentId)
        ? prev.studentIds.filter((id) => id !== studentId)
        : [...prev.studentIds, studentId],
    }))
  }

  const createGuardian = async (event: FormEvent) => {
    event.preventDefault()
    if (!authState) return
    setSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      const response = await fetch("/api/v1/guardians", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(form),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to create guardian")
      setForm({
        name: "",
        email: "",
        password: "",
        phone: "",
        address: "",
        studentIds: [],
      })
      setSuccess("Guardian created successfully")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create guardian")
    } finally {
      setSubmitting(false)
    }
  }

  const deleteGuardian = async (id: string) => {
    if (!authState) return
    setSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      const response = await fetch(`/api/v1/guardians/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to deactivate guardian")
      await refresh()
      setSuccess("Guardian deactivated")
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to deactivate guardian")
    } finally {
      setSubmitting(false)
    }
  }

  const startLinking = (parent: GuardianRecord) => {
    const baseline = parent.students.map((student) => student.id)
    setEditingGuardianId(parent.id)
    setLinkDraftStudentIds(baseline)
    setLinkDraftBaselineStudentIds(baseline)
    setStudentPickerMode("link")
    setStudentPickerGuardian({ id: parent.id, name: parent.user.name })
    setStudentPickerSearch("")
    setStudentPickerOpen(true)
    setError(null)
    setSuccess(null)
  }

  const openDetails = (parent: GuardianRecord) => {
    setDetailsGuardianId(parent.id)
    setEditingGuardianId(null)
    setTransferState(null)
    setTransferTargetGuardianId("")
    setTransferConfirmation("")
    setStudentPickerOpen(false)
    setError(null)
    setSuccess(null)
  }

  const openStudentPickerForCreate = () => {
    setStudentPickerMode("create")
    setStudentPickerGuardian(null)
    setStudentPickerSearch("")
    setStudentPickerOpen(true)
  }

  const closeStudentPicker = () => {
    setStudentPickerOpen(false)
    setStudentPickerGuardian(null)
    setStudentPickerSearch("")
  }

  const cancelStudentPicker = () => {
    if (studentPickerMode === "link") {
      setLinkDraftStudentIds(linkDraftBaselineStudentIds)
      setEditingGuardianId(null)
    }
    closeStudentPicker()
  }

  const toggleLinkDraftStudent = (studentId: string) => {
    setLinkDraftStudentIds((prev) =>
      prev.includes(studentId)
        ? prev.filter((id) => id !== studentId)
        : [...prev, studentId]
    )
  }

  const saveStudentLinks = async (guardianId: string) => {
    if (!authState) return
    setSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      const response = await fetch(`/api/v1/guardians/${guardianId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          studentIds: linkDraftStudentIds,
        }),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to update guardian links")
      setEditingGuardianId(null)
      setLinkDraftStudentIds([])
      setLinkDraftBaselineStudentIds([])
      closeStudentPicker()
      setSuccess("Guardian-student links updated")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update guardian links")
    } finally {
      setSubmitting(false)
    }
  }

  const startTransfer = (studentId: string, studentName: string, currentGuardianId: string, currentGuardianName: string) => {
    setTransferState({
      studentId,
      studentName,
      currentGuardianId,
      currentGuardianName,
    })
    setTransferTargetGuardianId("")
    setTransferConfirmation("")
    setError(null)
    setSuccess(null)
  }

  const confirmTransfer = async () => {
    if (!authState || !transferState) return

    if (!transferTargetGuardianId) {
      setError("Select a target guardian first")
      return
    }

    if (transferTargetGuardianId === transferState.currentGuardianId) {
      setError("Target guardian must be different from current guardian")
      return
    }

    if (transferConfirmation.trim().toUpperCase() !== "TRANSFER") {
      setError("Type TRANSFER to confirm")
      return
    }

    setSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      const response = await fetch("/api/v1/guardians/transfer-student", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          studentId: transferState.studentId,
          currentGuardianId: transferState.currentGuardianId,
          targetGuardianId: transferTargetGuardianId,
        }),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to transfer student")
      setTransferState(null)
      setTransferTargetGuardianId("")
      setTransferConfirmation("")
      setSuccess("Student transferred successfully")
      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to transfer student")
    } finally {
      setSubmitting(false)
    }
  }

  const detailsGuardian = detailsGuardianId
    ? guardians.find((item) => item.id === detailsGuardianId) ?? null
    : null
  const availableTransferGuardians = guardians.filter(
    (guardian) => !guardian.user.isDeleted && guardian.id !== transferState?.currentGuardianId
  )
  const normalizedStudentPickerSearch = studentPickerSearch.trim().toLowerCase()

  const studentPickerStudents = students
    .map((student) => {
      const linkedStatus = student.guardianId
        ? student.guardianId === studentPickerGuardian?.id
          ? "LINKED_TO_THIS"
          : "LINKED_TO_OTHER"
        : "NOT_LINKED"
      return { ...student, linkedStatus }
    })
    .filter((student) => {
      const includeNotLinked =
        studentPickerShowNotLinked && student.linkedStatus === "NOT_LINKED"
      const includeLinked =
        studentPickerShowLinked && student.linkedStatus !== "NOT_LINKED"

      if (!includeNotLinked && !includeLinked) return false

      if (!normalizedStudentPickerSearch) return true

      return `${student.name} ${student.className} ${student.guardianName ?? ""}`
        .toLowerCase()
        .includes(normalizedStudentPickerSearch)
    })

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Family</p>
        <h1 className="text-2xl font-semibold">Guardian management</h1>
      </section>
      <div className="grid gap-4 sm:grid-cols-2">
        <Card><CardHeader><CardDescription>Total guardians</CardDescription><CardTitle>{stats.total}</CardTitle></CardHeader></Card>
        <Card><CardHeader><CardDescription>Linked students</CardDescription><CardTitle>{stats.linkedStudents}</CardTitle></CardHeader></Card>
      </div>
      <div
        className={
          mode === "create"
            ? "grid gap-6 xl:grid-cols-1"
            : mode === "view"
              ? "grid gap-6 xl:grid-cols-1"
              : "grid gap-6 xl:grid-cols-[1fr_1.4fr]"
        }
      >
        {mode !== "view" ? (
          <Card className="h-fit">
            <CardHeader><CardTitle>Add guardian</CardTitle></CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={createGuardian}>
                <div className="space-y-2"><Label htmlFor="guardian-name">Name</Label><Input id="guardian-name" value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} required /></div>
                <div className="space-y-2"><Label htmlFor="guardian-email">Email</Label><Input id="guardian-email" type="email" value={form.email} onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))} required /></div>
                <div className="space-y-2"><Label htmlFor="guardian-password">Password</Label><Input id="guardian-password" type="password" value={form.password} onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))} required /></div>
                <div className="space-y-2"><Label htmlFor="guardian-phone">Phone</Label><Input id="guardian-phone" value={form.phone} onChange={(event) => setForm((prev) => ({ ...prev, phone: event.target.value }))} /></div>
                <div className="space-y-2"><Label htmlFor="guardian-address">Address</Label><Input id="guardian-address" value={form.address} onChange={(event) => setForm((prev) => ({ ...prev, address: event.target.value }))} /></div>
                <div className="space-y-2">
                  <Label>Linked students</Label>
                  <div className="rounded-none border border-border bg-muted/20 p-3">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                      Selected students
                    </p>
                    {form.studentIds.length ? (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {form.studentIds.map((studentId) => {
                          const student = students.find((s) => s.id === studentId)
                          return (
                            <Button
                              key={studentId}
                              type="button"
                              size="sm"
                              variant="outline"
                              onClick={() => handleStudentSelection(studentId)}
                            >
                              {student ? `${student.name} · ${student.className}` : studentId}
                            </Button>
                          )
                        })}
                      </div>
                    ) : (
                      <p className="mt-2 text-xs text-muted-foreground">
                        No students selected yet.
                      </p>
                    )}
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={openStudentPickerForCreate}
                      >
                        Select students
                      </Button>
                      <p className="text-xs text-muted-foreground">
                        Opens a popup where you can search & filter students.
                      </p>
                    </div>
                  </div>
                </div>
                <Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create guardian"}</Button>
              </form>
            </CardContent>
          </Card>
        ) : null}

        {mode !== "create" ? (
          <Card>
          <CardHeader><CardTitle>Guardian list</CardTitle><CardDescription>Guardian records linked to student records.</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <form className="flex gap-2" onSubmit={(event) => { event.preventDefault(); void refresh() }}>
              <Input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1) }} placeholder="Search guardians" />
              <Button type="submit" variant="outline">Filter</Button>
            </form>
            {error && <div className="text-xs text-destructive">{error}</div>}
            {success && <div className="text-xs text-emerald-600">{success}</div>}
            {loading ? <p className="text-xs text-muted-foreground">Loading guardians…</p> : (
              <>
                {/* Mobile / small devices: cards */}
                <div className="space-y-3 lg:hidden">
                  {guardians.map((parent) => (
                    <article key={parent.id} className="rounded-none border border-border bg-background/60 p-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant={parent.user.isDeleted ? "destructive" : "secondary"}>{parent.user.isDeleted ? "Deactivated" : "Active"}</Badge>
                      </div>
                      <h3 className="mt-2 text-sm font-semibold text-foreground">{parent.user.name}</h3>
                      <p className="text-xs text-muted-foreground">{parent.user.email}</p>
                      <p className="text-xs text-muted-foreground">{parent.phone ?? "No phone"}{parent.address ? ` · ${parent.address}` : ""}</p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        Students: {parent.students.length > 0 ? parent.students.map((student) => `${student.user.name} (${student.class.name})`).join(", ") : "None linked"}
                      </p>
                      <div className="mt-3 flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          type="button"
                          onClick={() => openDetails(parent)}
                        >
                          View details
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          type="button"
                          onClick={() => startLinking(parent)}
                          disabled={submitting || parent.user.isDeleted}
                        >
                          Manage children
                        </Button>
                        <Button size="sm" variant="destructive" type="button" onClick={() => void deleteGuardian(parent.id)} disabled={submitting || parent.user.isDeleted}>Deactivate</Button>
                      </div>
                    </article>
                  ))}
                  {guardians.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No guardians found.</p>
                  ) : null}
                </div>

                {/* Large devices: table */}
                <div className="hidden lg:block">
                  <div className="overflow-x-auto rounded-none border border-border">
                    <table className="min-w-full text-sm">
                      <thead className="bg-muted/30 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        <tr>
                          <th className="px-3 py-3 text-left font-semibold">Status</th>
                          <th className="px-3 py-3 text-left font-semibold">Guardian</th>
                          <th className="px-3 py-3 text-left font-semibold">Contact</th>
                          <th className="px-3 py-3 text-left font-semibold">Students</th>
                          <th className="px-3 py-3 text-right font-semibold">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {guardians.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-3 py-6 text-center text-xs text-muted-foreground">
                              No guardians found.
                            </td>
                          </tr>
                        ) : (
                          guardians.map((parent) => {
                            const studentLabel = parent.students.length
                              ? parent.students
                                  .slice(0, 3)
                                  .map((student) => `${student.user.name} (${student.class.name})`)
                                  .join(", ")
                              : "None linked"

                            return (
                              <tr key={parent.id} className="align-top">
                                <td className="px-3 py-3">
                                  <Badge variant={parent.user.isDeleted ? "destructive" : "secondary"}>
                                    {parent.user.isDeleted ? "Deactivated" : "Active"}
                                  </Badge>
                                </td>
                                <td className="px-3 py-3">
                                  <p className="font-medium text-foreground">{parent.user.name}</p>
                                  <p className="text-xs text-muted-foreground">{parent.user.email}</p>
                                </td>
                                <td className="px-3 py-3">
                                  <p className="text-foreground">{parent.phone ?? "No phone"}</p>
                                  {parent.address ? (
                                    <p className="text-xs text-muted-foreground">{parent.address}</p>
                                  ) : null}
                                </td>
                                <td className="px-3 py-3">
                                  <p className="text-foreground">{parent.students.length} linked</p>
                                  <p className="text-xs text-muted-foreground">
                                    {studentLabel}
                                    {parent.students.length > 3 ? `, +${parent.students.length - 3} more` : ""}
                                  </p>
                                </td>
                                <td className="px-3 py-3">
                                  <div className="flex justify-end gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      type="button"
                                      onClick={() => openDetails(parent)}
                                    >
                                      View details
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      type="button"
                                      onClick={() => startLinking(parent)}
                                      disabled={submitting || parent.user.isDeleted}
                                    >
                                      Manage children
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      type="button"
                                      onClick={() => void deleteGuardian(parent.id)}
                                      disabled={submitting || parent.user.isDeleted}
                                    >
                                      Deactivate
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            )
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <p className="text-xs text-muted-foreground">
                    Showing page {pagination.page} of {pagination.totalPages} ·{" "}
                    {pagination.total} guardians
                  </p>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={loading || pagination.page <= 1}
                      onClick={() => {
                        const nextPage = Math.max(1, pagination.page - 1)
                        setPage(nextPage)
                        if (authState) {
                          void loadGuardians(authState, search, nextPage)
                        }
                      }}
                    >
                      Prev
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={loading || pagination.page >= pagination.totalPages}
                      onClick={() => {
                        const nextPage = Math.min(pagination.totalPages, pagination.page + 1)
                        setPage(nextPage)
                        if (authState) {
                          void loadGuardians(authState, search, nextPage)
                        }
                      }}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        ) : null}
      </div>

      {studentPickerOpen ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 px-4 py-6 backdrop-blur-sm"
          role="presentation"
          onClick={cancelStudentPicker}
        >
          <div
            className="w-full max-w-3xl rounded-3xl border border-border bg-background p-6 shadow-2xl shadow-slate-950/40"
            role="dialog"
            aria-modal="true"
            aria-labelledby="guardian-student-picker-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
                Students
              </p>
              <h2
                id="guardian-student-picker-title"
                className="text-xl font-semibold text-foreground"
              >
                {studentPickerMode === "create"
                  ? "Select students to link"
                  : `Link students to ${studentPickerGuardian?.name ?? "guardian"}`}
              </h2>
              <p className="text-sm text-muted-foreground">
                Search and filter students. Linked students can be shown using
                the checkmarks.
              </p>
            </div>

            <div className="mt-6 grid gap-3 md:grid-cols-[1fr_auto_auto]">
              <Input
                value={studentPickerSearch}
                onChange={(event) => setStudentPickerSearch(event.target.value)}
                placeholder="Search by student name / class / guardian"
              />
              <label className="flex items-center gap-2 text-xs text-muted-foreground">
                <input
                  type="checkbox"
                  checked={studentPickerShowNotLinked}
                  onChange={(event) =>
                    setStudentPickerShowNotLinked(event.target.checked)
                  }
                />
                <span>Not linked</span>
              </label>
              <label className="flex items-center gap-2 text-xs text-muted-foreground">
                <input
                  type="checkbox"
                  checked={studentPickerShowLinked}
                  onChange={(event) =>
                    setStudentPickerShowLinked(event.target.checked)
                  }
                />
                <span>Already linked</span>
              </label>
            </div>

            <div className="mt-4 rounded-2xl border border-border bg-background/60">
              <div className="max-h-[50vh] overflow-y-auto p-2">
                {studentPickerStudents.length ? (
                  <div className="space-y-2">
                    {studentPickerStudents.map((student) => {
                      const selectedIds =
                        studentPickerMode === "create"
                          ? form.studentIds
                          : linkDraftStudentIds
                      const isSelected = selectedIds.includes(student.id)

                      const isLinkedToOther =
                        student.linkedStatus === "LINKED_TO_OTHER"
                      const isSelectable =
                        studentPickerMode === "create"
                          ? student.linkedStatus === "NOT_LINKED"
                          : student.linkedStatus === "NOT_LINKED" ||
                            student.linkedStatus === "LINKED_TO_THIS"

                      const disabled = !isSelectable || isLinkedToOther

                      const statusLabel =
                        student.linkedStatus === "NOT_LINKED"
                          ? "Not linked"
                          : student.linkedStatus === "LINKED_TO_THIS"
                            ? "Linked (this guardian)"
                            : `Linked (${student.guardianName ?? "guardian"})`

                      const toggle = () => {
                        if (disabled) return
                        if (studentPickerMode === "create") {
                          handleStudentSelection(student.id)
                        } else {
                          toggleLinkDraftStudent(student.id)
                        }
                      }

                      return (
                        <Button
                          key={student.id}
                          type="button"
                          variant={isSelected ? "secondary" : "ghost"}
                          size="sm"
                          className={`h-auto w-full justify-between gap-3 whitespace-normal px-3 py-3 text-left ${disabled ? "opacity-60" : ""}`}
                          disabled={disabled}
                          onClick={toggle}
                        >
                          <span>
                            <span className="font-medium text-foreground">
                              {student.name}
                            </span>{" "}
                            <span className="text-muted-foreground">
                              · {student.className}
                            </span>
                            <span className="block text-xs text-muted-foreground">
                              {statusLabel}
                            </span>
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {disabled
                              ? "Unavailable"
                              : isSelected
                                ? "Selected"
                                : "Select"}
                          </span>
                        </Button>
                      )
                    })}
                  </div>
                ) : (
                  <p className="p-4 text-xs text-muted-foreground">
                    No students found.
                  </p>
                )}
              </div>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-end gap-2">
              {studentPickerMode === "link" && studentPickerGuardian ? (
                <Button
                  type="button"
                  onClick={() => void saveStudentLinks(studentPickerGuardian.id)}
                  disabled={submitting}
                >
                  {submitting ? "Saving…" : "Save links"}
                </Button>
              ) : null}
              <Button type="button" variant="outline" onClick={cancelStudentPicker}>
                Cancel
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {detailsGuardian ? (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40">
          <div className="h-full w-full max-w-xl overflow-y-auto bg-background p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Guardian details</p>
                <h2 className="text-xl font-semibold">{detailsGuardian.user.name}</h2>
                <p className="text-sm text-muted-foreground">{detailsGuardian.user.email}</p>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setDetailsGuardianId(null)
                  setEditingGuardianId(null)
                  setTransferState(null)
                  setTransferTargetGuardianId("")
                  setTransferConfirmation("")
                }}
              >
                Close
              </Button>
            </div>
            <div className="mt-4 space-y-2 rounded-none border border-border p-4 text-sm">
              <p><span className="font-semibold">Phone:</span> {detailsGuardian.phone ?? "No phone"}</p>
              <p><span className="font-semibold">Address:</span> {detailsGuardian.address ?? "No address"}</p>
              <p><span className="font-semibold">Linked students:</span> {detailsGuardian.students.length}</p>
            </div>
            <div className="mt-6 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-sm font-semibold">Linked children</h3>
                <Button
                  size="sm"
                  variant="outline"
                  type="button"
                  onClick={() => startLinking(detailsGuardian)}
                  disabled={detailsGuardian.user.isDeleted}
                >
                  Manage children
                </Button>
              </div>
              {detailsGuardian.students.length === 0 ? (
                <p className="text-sm text-muted-foreground">No linked children.</p>
              ) : (
                detailsGuardian.students.map((student) => (
                  <div key={student.id} className="rounded-none border border-border p-3">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold">{student.user.name}</p>
                        <p className="text-xs text-muted-foreground">{student.class.name}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        type="button"
                        onClick={() => startTransfer(student.id, student.user.name, detailsGuardian.id, detailsGuardian.user.name)}
                        disabled={submitting || detailsGuardian.user.isDeleted}
                      >
                        Transfer
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
            {transferState ? (
              <div className="mt-6 space-y-4 rounded-none border border-destructive/40 bg-destructive/5 p-4">
                <div>
                  <h3 className="text-sm font-semibold">Transfer child</h3>
                  <p className="text-xs text-muted-foreground">
                    Move {transferState.studentName} from {transferState.currentGuardianName} to another guardian.
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="transfer-parent">Target guardian</Label>
                  <select
                    id="transfer-parent"
                    className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                    value={transferTargetGuardianId}
                    onChange={(event) => setTransferTargetGuardianId(event.target.value)}
                  >
                    <option value="">Select guardian</option>
                    {availableTransferGuardians.map((guardian) => (
                      <option key={guardian.id} value={guardian.id}>
                        {guardian.user.name} ({guardian.user.email})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="transfer-confirmation">Type TRANSFER to confirm</Label>
                  <Input
                    id="transfer-confirmation"
                    value={transferConfirmation}
                    onChange={(event) => setTransferConfirmation(event.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="button" onClick={() => void confirmTransfer()} disabled={submitting}>
                    {submitting ? "Transferring…" : "Confirm transfer"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setTransferState(null)
                      setTransferTargetGuardianId("")
                      setTransferConfirmation("")
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  )
}
