"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type StudentOption = { id: string; name: string; className: string };
type FeeCategoryOption = { id: string; name: string; amount: number };

type PaymentRecord = {
  id: string;
  createdAt: string;
  amountPaid: number;
  status: "PAID" | "PARTIAL" | "DUE";
  paymentMethod: string | null;
  transactionId: string | null;
  month: number | null;
  year: number | null;
  dueDate: string | null;
  billingMonth: number;
  billingYear: number;
  billingPeriodKey: string;
  billingPeriodLabel: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  totalAmount: number;
  dueAmount: number;
  feeCategory: FeeCategoryOption;
  student: {
    id: string;
    user: { name: string; email: string };
    class: { name: string };
    rollNumber: number | null;
  };
};

type HistoryItem = {
  key: string;
  studentId: string;
  studentName: string;
  className: string;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: PaymentRecord[];
};

type PaymentResponse = {
  payments: PaymentRecord[];
  history: HistoryItem[];
  students: StudentOption[];
  feeCategories: FeeCategoryOption[];
  stats: {
    total: number;
    collectedAmount: number;
    expectedAmount: number;
    dueAmount: number;
    dueCount: number;
  };
};

const formatMoney = (value: number) => `৳${value}`;

export function PaymentManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [students, setStudents] = useState<StudentOption[]>([]);
  const [feeCategories, setFeeCategories] = useState<FeeCategoryOption[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    collectedAmount: 0,
    expectedAmount: 0,
    dueAmount: 0,
    dueCount: 0,
  });
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const now = new Date();
  const [form, setForm] = useState({
    studentId: "",
    feeCategoryId: "",
    amountPaid: "",
    status: "PAID",
    paymentMethod: "",
    transactionId: "",
    month: String(now.getMonth() + 1),
    year: String(now.getFullYear()),
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setAuthState(readAuth());
  }, []);

  const loadPayments = useCallback(
    async (
      nextAuth: AuthStorage,
      currentSearch = search,
      currentStatus = statusFilter,
    ) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim());
        }
        if (currentStatus !== "ALL") {
          params.set("status", currentStatus);
        }

        const response = await fetch(
          `/api/v1/fees/payments?${params.toString()}`,
          {
            headers: {
              Authorization: `Bearer ${nextAuth.token}`,
            },
          },
        );
        const json = await response.json();

        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load payments");
        }

        const data = json.data as PaymentResponse;
        setPayments(data.payments);
        setHistory(data.history);
        setStudents(data.students);
        setFeeCategories(data.feeCategories);
        setStats(data.stats);
        setForm((prev) => ({
          ...prev,
          studentId: prev.studentId || data.students[0]?.id || "",
          feeCategoryId: prev.feeCategoryId || data.feeCategories[0]?.id || "",
        }));
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load payments",
        );
      } finally {
        setLoading(false);
      }
    },
    [search, statusFilter],
  );

  useEffect(() => {
    if (authState) {
      void loadPayments(authState);
    }
  }, [authState, loadPayments]);

  const refresh = useCallback(async () => {
    if (authState) {
      await loadPayments(authState);
    }
  }, [authState, loadPayments]);

  const createPayment = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/v1/fees/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          ...form,
          amountPaid: Number(form.amountPaid),
          month: Number(form.month),
          year: Number(form.year),
        }),
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create payment");
      }

      setForm((prev) => ({
        ...prev,
        amountPaid: "",
        paymentMethod: "",
        transactionId: "",
        month: String(now.getMonth() + 1),
        year: String(now.getFullYear()),
      }));
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create payment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deletePayment = async (id: string) => {
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/fees/payments/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to delete payment");
      }

      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to delete payment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const monthCount = history.length;

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Finance
        </p>
        <h1 className="text-2xl font-semibold">Payment management</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-200/80">
          Month-ledger view with monthly base, extra category fees, paid amount,
          due amount, and transaction details for every billing period.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Card>
          <CardHeader>
            <CardDescription>Billing periods</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Transactions</CardDescription>
            <CardTitle>{payments.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Collected</CardDescription>
            <CardTitle>{formatMoney(stats.collectedAmount)}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Expected</CardDescription>
            <CardTitle>{formatMoney(stats.expectedAmount)}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Due</CardDescription>
            <CardTitle>{formatMoney(stats.dueAmount)}</CardTitle>
            <CardDescription>{stats.dueCount} open periods</CardDescription>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Record payment</CardTitle>
            <CardDescription>
              Assign a fee category payment to a student.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createPayment}>
              <div className="space-y-2">
                <Label htmlFor="payment-student">Student</Label>
                <select
                  id="payment-student"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.studentId}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      studentId: event.target.value,
                    }))
                  }
                >
                  {students.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} · {item.className}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-category">Category</Label>
                <select
                  id="payment-category"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.feeCategoryId}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      feeCategoryId: event.target.value,
                    }))
                  }
                >
                  {feeCategories.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} · {item.amount}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-amount">Amount paid</Label>
                <Input
                  id="payment-amount"
                  type="number"
                  min="0"
                  value={form.amountPaid}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      amountPaid: event.target.value,
                    }))
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-status">Status</Label>
                <select
                  id="payment-status"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.status}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, status: event.target.value }))
                  }
                >
                  <option value="PAID">Paid</option>
                  <option value="PARTIAL">Partial</option>
                  <option value="DUE">Due</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-method">Method</Label>
                <Input
                  id="payment-method"
                  value={form.paymentMethod}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      paymentMethod: event.target.value,
                    }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-transaction">Transaction ID</Label>
                <Input
                  id="payment-transaction"
                  value={form.transactionId}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      transactionId: event.target.value,
                    }))
                  }
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="payment-month">Billing month</Label>
                  <Input
                    id="payment-month"
                    type="number"
                    min="1"
                    max="12"
                    value={form.month}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        month: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payment-year">Billing year</Label>
                  <Input
                    id="payment-year"
                    type="number"
                    min="2000"
                    max="2100"
                    value={form.year}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, year: event.target.value }))
                    }
                    required
                  />
                </div>
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Record payment"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly ledger</CardTitle>
            <CardDescription>
              {monthCount} billing period{monthCount === 1 ? "" : "s"} in the
              current filter.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-2 md:grid-cols-[1fr_180px_auto]"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search student or transaction"
              />
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
              >
                <option value="ALL">All statuses</option>
                <option value="PAID">Paid</option>
                <option value="PARTIAL">Partial</option>
                <option value="DUE">Due</option>
              </select>
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>

            {error ? (
              <div className="text-xs text-destructive">{error}</div>
            ) : null}
            {loading ? (
              <p className="text-xs text-muted-foreground">Loading payments…</p>
            ) : (
              <div className="space-y-4">
                {history.map((period) => (
                  <article
                    key={period.key}
                    className="rounded-2xl border border-border bg-background/60 p-4"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                          Billing period
                        </p>
                        <h3 className="mt-1 text-sm font-semibold text-foreground">
                          {period.label} · {period.studentName}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          {period.className} · Monthly due{" "}
                          {formatMoney(period.monthlyFeeDue)} · Extra due{" "}
                          {formatMoney(period.extraCategoryDue)}
                        </p>
                      </div>
                      <div className="rounded-2xl border border-border bg-muted/40 px-3 py-2 text-right">
                        <p className="text-xs text-muted-foreground">Due</p>
                        <p className="text-sm font-semibold">
                          {formatMoney(period.dueAmount)}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 grid gap-3 sm:grid-cols-3">
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">
                          Expected
                        </p>
                        <p className="text-sm font-semibold">
                          {formatMoney(period.totalExpected)}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">Paid</p>
                        <p className="text-sm font-semibold">
                          {formatMoney(period.amountPaid)}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">
                          Transactions
                        </p>
                        <p className="text-sm font-semibold">
                          {period.transactions.length}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 space-y-3">
                      {period.transactions.map((item) => (
                        <div
                          key={item.id}
                          className="rounded-2xl border border-border bg-background/80 p-4"
                        >
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <Badge
                                  variant={
                                    item.status === "PAID"
                                      ? "secondary"
                                      : item.status === "PARTIAL"
                                        ? "outline"
                                        : "destructive"
                                  }
                                >
                                  {item.status}
                                </Badge>
                                <Badge variant="outline">
                                  {item.feeCategory.name}
                                </Badge>
                              </div>
                              <p className="font-medium text-sm">
                                {item.student.user.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Roll {item.student.rollNumber ?? "N/A"} ·{" "}
                                {item.student.class.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Monthly due {formatMoney(item.monthlyFeeDue)} ·
                                Extra due {formatMoney(item.extraCategoryDue)}
                              </p>
                              <div className="flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                                <span>Method: {item.paymentMethod ?? "-"}</span>
                                <span>Txn: {item.transactionId ?? "-"}</span>
                                <span>
                                  Due date:{" "}
                                  {item.dueDate
                                    ? new Date(
                                        item.dueDate,
                                      ).toLocaleDateString()
                                    : "-"}
                                </span>
                              </div>
                            </div>

                            <div className="text-right space-y-2">
                              <p className="text-sm font-semibold">
                                {formatMoney(item.amountPaid)} /{" "}
                                {formatMoney(item.totalAmount)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Due {formatMoney(item.dueAmount)}
                              </p>
                              <div>
                                <button
                                  type="button"
                                  onClick={() => void deletePayment(item.id)}
                                  disabled={submitting}
                                  className="rounded-full border border-destructive px-3 py-1 text-xs font-semibold text-destructive"
                                >
                                  Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
