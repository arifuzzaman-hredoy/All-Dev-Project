"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";

import { ROLE_DEFINITIONS } from "@/constants/roles";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type ManagedRole =
  | "USER"
  | "SUPER_ADMIN"
  | "ADMIN"
  | "ACCOUNTANT"
  | "ACADEMIC_ADMIN"
  | "ADMISSION_ADMIN"
  | "TEACHER"
  | "STUDENT";

type UserListResponse = {
  allowedRoles: ManagedRole[];
};

type CreateForm = {
  name: string;
  email: string;
  password: string;
  role: ManagedRole;
  branchId?: string;
};

const defaultCreateForm: CreateForm = {
  name: "",
  email: "",
  password: "",
  role: "USER",
  branchId: undefined,
};

type PublicBranch = {
  id: string;
  name: string;
  slug: string;
  school: { id: string; name: string; slug: string };
};

type BranchesResponse = { branches: PublicBranch[] };

function roleRequiresBranch(role: ManagedRole) {
  return (
    role === "ADMIN" ||
    role === "ACCOUNTANT" ||
    role === "ACADEMIC_ADMIN" ||
    role === "ADMISSION_ADMIN" ||
    role === "TEACHER"
  );
}

export function UserCreatePanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [allowedRoles, setAllowedRoles] = useState<ManagedRole[]>([]);
  const [form, setForm] = useState<CreateForm>(defaultCreateForm);
  const [branches, setBranches] = useState<PublicBranch[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const availableRoles = useMemo(() => {
    if (allowedRoles.length > 0) {
      return allowedRoles;
    }

    return [
      "USER",
      "ADMIN",
      "ACCOUNTANT",
      "ACADEMIC_ADMIN",
      "ADMISSION_ADMIN",
      "TEACHER",
      "STUDENT",
    ] satisfies ManagedRole[];
  }, [allowedRoles]);

  useEffect(() => {
    const currentAuth = readAuth();
    setAuthState(currentAuth);
  }, []);

  useEffect(() => {
    let active = true;
    async function loadBranches() {
      try {
        const response = await fetch("/api/v1/public/branches");
        const json = await response.json();
        if (!response.ok) throw new Error(json.message ?? "Unable to load branches");
        const data = json.data as BranchesResponse;
        if (!active) return;
        setBranches(data.branches);
      } catch (exception) {
        console.error(exception);
      }
    }
    void loadBranches();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!authState) return;

    const currentAuth = authState;

    let active = true;

    async function loadAllowedRoles() {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch("/api/v1/users", {
          headers: {
            Authorization: `Bearer ${currentAuth.token}`,
          },
        });

        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load allowed roles");
        }

        const data = json.data as UserListResponse;
        if (!active) return;

        setAllowedRoles(data.allowedRoles);
        setForm((prev) => ({
          ...prev,
          role: data.allowedRoles.includes(prev.role)
            ? prev.role
            : (data.allowedRoles[0] ?? "USER"),
        }));
      } catch (exception) {
        if (!active) return;
        console.error(exception);
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load allowed roles",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void loadAllowedRoles();

    return () => {
      active = false;
    };
  }, [authState]);

  useEffect(() => {
    setForm((prev) => {
      if (!roleRequiresBranch(prev.role)) {
        if (prev.branchId === undefined) return prev;
        return { ...prev, branchId: undefined };
      }

      const fixedBranchId = authState?.user.branchId ?? undefined;
      if (fixedBranchId) {
        if (prev.branchId === fixedBranchId) return prev;
        return { ...prev, branchId: fixedBranchId };
      }
      if (prev.branchId) return prev;
      return { ...prev, branchId: branches[0]?.id };
    });
  }, [authState?.user.branchId, branches, form.role]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!authState) {
      return;
    }

    setSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch("/api/v1/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(form),
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create user");
      }

      setSuccess("User account created successfully.");
      setForm({
        name: "",
        email: "",
        password: "",
        role: availableRoles[0] ?? "USER",
        branchId: authState.user.branchId ?? undefined,
      });
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create user",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="border-border/70 bg-background/85 shadow-sm">
      <CardHeader>
        <CardTitle>Create account</CardTitle>
        <CardDescription>
          Add school users with scoped roles and secure credentials.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-xs text-muted-foreground">
            Loading allowed roles…
          </p>
        ) : (
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="create-name">Full name</Label>
                <Input
                  id="create-name"
                  value={form.name}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, name: event.target.value }))
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="create-email">Email</Label>
                <Input
                  id="create-email"
                  type="email"
                  value={form.email}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, email: event.target.value }))
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="create-password">Temporary password</Label>
                <Input
                  id="create-password"
                  type="password"
                  minLength={8}
                  value={form.password}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      password: event.target.value,
                    }))
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="create-role">Role</Label>
                <select
                  id="create-role"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.role}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      role: event.target.value as ManagedRole,
                    }))
                  }
                >
                  {availableRoles.map((role) => (
                    <option key={role} value={role}>
                      {ROLE_DEFINITIONS[role].label}
                    </option>
                  ))}
                </select>
              </div>

              {roleRequiresBranch(form.role) ? (
                <div className="space-y-2">
                  <Label htmlFor="create-branch">Branch</Label>
                  <select
                    id="create-branch"
                    className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                    value={form.branchId ?? ""}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, branchId: event.target.value }))
                    }
                    disabled={Boolean(authState?.user.branchId)}
                    required
                  >
                    {branches.length === 0 ? (
                      <option value="" disabled>
                        No branches found
                      </option>
                    ) : null}
                    {branches.map((branch) => (
                      <option key={branch.id} value={branch.id}>
                        {branch.school.name} · {branch.name}
                      </option>
                    ))}
                  </select>
                  {authState?.user.branchId ? (
                    <p className="text-[11px] text-muted-foreground">
                      Your account is locked to a branch.
                    </p>
                  ) : null}
                </div>
              ) : null}
            </div>

            {error && (
              <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                {error}
              </div>
            )}

            {success && (
              <div className="rounded-none border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-700">
                {success}
              </div>
            )}

            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving…" : "Create account"}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
