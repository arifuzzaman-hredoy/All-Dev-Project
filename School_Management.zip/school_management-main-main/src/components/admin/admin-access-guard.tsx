"use client"

import type { ReactNode } from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

import { ADMIN_ROLES, roleHasPermission, type AdminPermission } from "@/constants/roles"
import { getDashboardRoute } from "@/lib/role-routes"
import { clearAuth, readAuth, type AuthStorage } from "@/utils/auth-storage"

type AdminAccessGuardProps = {
  children: ReactNode
  permission?: AdminPermission
  anyPermissions?: AdminPermission[]
}

export function AdminAccessGuard({
  children,
  permission,
  anyPermissions,
}: AdminAccessGuardProps) {
  const router = useRouter()
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    const nextAuthState = readAuth()
    let timeoutId: number | null = null

    if (!nextAuthState) {
      router.replace("/staff/login")
      return
    }

    if (!ADMIN_ROLES.includes(nextAuthState.user.role)) {
      router.replace(getDashboardRoute(nextAuthState.user.role))
      return
    }

    if (nextAuthState.user.role === "SUPER_ADMIN" && !nextAuthState.user.branchId) {
      clearAuth()
      router.replace("/staff/login")
      return
    }

    if (permission && !roleHasPermission(nextAuthState.user.role, permission)) {
      router.replace("/admin/dashboard")
      return
    }

    if (
      anyPermissions &&
      anyPermissions.length > 0 &&
      !anyPermissions.some((required) =>
        roleHasPermission(nextAuthState.user.role, required)
      )
    ) {
      router.replace("/admin/dashboard")
      return
    }

    timeoutId = window.setTimeout(() => {
      setAuthState(nextAuthState)
      setIsReady(true)
    }, 0)

    return () => {
      if (timeoutId !== null) {
        window.clearTimeout(timeoutId)
      }
    }
  }, [anyPermissions, permission, router])

  if (!isReady || !authState) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center px-6 py-10 text-sm text-muted-foreground">
        Verifying your access…
      </div>
    )
  }

  return <>{children}</>
}
