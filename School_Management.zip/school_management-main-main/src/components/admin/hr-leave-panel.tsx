"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type TeacherOption = { id: string; name: string; email: string };

type LeaveRecord = {
  id: string;
  teacherId: string;
  startDate: string;
  endDate: string;
  reason: string | null;
  status: "PENDING" | "APPROVED" | "REJECTED" | "CANCELLED";
  decidedAt: string | null;
  teacher: {
    id: string;
    user: { name: string; email: string; isDeleted: boolean };
    isDeleted: boolean;
  };
  decidedBy: { id: string; name: string; email: string } | null;
  createdAt: string;
};

type LeavesResponse = { leaves: LeaveRecord[] };
type TeachersResponse = { teachers: Array<{ id: string; user: { name: string; email: string } }> };

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
  }).format(new Date(value));
}

export function HrLeavePanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [leaves, setLeaves] = useState<LeaveRecord[]>([]);
  const [teacherOptions, setTeacherOptions] = useState<TeacherOption[]>([]);

  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [teacherFilter, setTeacherFilter] = useState<string>("");

  const [createForm, setCreateForm] = useState({
    teacherId: "",
    startDate: "",
    endDate: "",
    reason: "",
  });

  useEffect(() => setAuthState(readAuth()), []);

  const load = useCallback(
    async (nextAuth: AuthStorage) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (statusFilter !== "ALL") params.set("status", statusFilter);
        if (teacherFilter) params.set("teacherId", teacherFilter);

        const [leavesResponse, teachersResponse] = await Promise.all([
          fetch(`/api/v1/hr/leaves?${params.toString()}`, {
            headers: { Authorization: `Bearer ${nextAuth.token}` },
          }),
          fetch(`/api/v1/teachers`, {
            headers: { Authorization: `Bearer ${nextAuth.token}` },
          }),
        ]);

        const leavesJson = await leavesResponse.json();
        if (!leavesResponse.ok)
          throw new Error(leavesJson.message ?? "Unable to load leaves");
        const leavesData = leavesJson.data as LeavesResponse;
        setLeaves(leavesData.leaves);

        const teachersJson = await teachersResponse.json();
        if (!teachersResponse.ok)
          throw new Error(teachersJson.message ?? "Unable to load teachers");
        const teachersData = teachersJson.data as TeachersResponse;
        const options = teachersData.teachers.map((teacher) => ({
          id: teacher.id,
          name: teacher.user.name,
          email: teacher.user.email,
        }));
        setTeacherOptions(options);
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load leaves");
      } finally {
        setLoading(false);
      }
    },
    [statusFilter, teacherFilter],
  );

  useEffect(() => {
    if (authState) void load(authState);
  }, [authState, load]);

  const refresh = async () => {
    if (authState) await load(authState);
  };

  const counts = useMemo(() => {
    return leaves.reduce(
      (acc, item) => {
        acc.total += 1;
        acc[item.status] += 1;
        return acc;
      },
      {
        total: 0,
        PENDING: 0,
        APPROVED: 0,
        REJECTED: 0,
        CANCELLED: 0,
      },
    );
  }, [leaves]);

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/v1/hr/leaves", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          teacherId: createForm.teacherId,
          startDate: createForm.startDate,
          endDate: createForm.endDate,
          reason: createForm.reason || undefined,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to create leave");
      setCreateForm({ teacherId: "", startDate: "", endDate: "", reason: "" });
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create leave");
    } finally {
      setSubmitting(false);
    }
  };

  const decide = async (leaveId: string, status: "APPROVED" | "REJECTED" | "CANCELLED") => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/hr/leaves/${leaveId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ status }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update leave");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update leave");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          HR
        </p>
        <h1 className="text-2xl font-semibold">Leave management</h1>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Card>
          <CardHeader>
            <CardDescription>Total</CardDescription>
            <CardTitle>{counts.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Pending</CardDescription>
            <CardTitle>{counts.PENDING}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Approved</CardDescription>
            <CardTitle>{counts.APPROVED}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Rejected</CardDescription>
            <CardTitle>{counts.REJECTED}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Cancelled</CardDescription>
            <CardTitle>{counts.CANCELLED}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Create leave request</CardTitle>
            <CardDescription>Admins can log leaves on behalf of staff.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleCreate}>
              <div className="space-y-2">
                <Label htmlFor="leave-teacher">Teacher</Label>
                <select
                  id="leave-teacher"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={createForm.teacherId}
                  onChange={(event) =>
                    setCreateForm((prev) => ({ ...prev, teacherId: event.target.value }))
                  }
                  required
                >
                  <option value="">Select teacher</option>
                  {teacherOptions.map((teacher) => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.name} ({teacher.email})
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="leave-start">Start date</Label>
                  <Input
                    id="leave-start"
                    type="date"
                    value={createForm.startDate}
                    onChange={(event) =>
                      setCreateForm((prev) => ({ ...prev, startDate: event.target.value }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="leave-end">End date</Label>
                  <Input
                    id="leave-end"
                    type="date"
                    value={createForm.endDate}
                    onChange={(event) =>
                      setCreateForm((prev) => ({ ...prev, endDate: event.target.value }))
                    }
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="leave-reason">Reason</Label>
                <Input
                  id="leave-reason"
                  value={createForm.reason}
                  onChange={(event) =>
                    setCreateForm((prev) => ({ ...prev, reason: event.target.value }))
                  }
                  placeholder="Optional"
                />
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create"}
              </Button>
              {error ? <p className="text-xs text-destructive">{error}</p> : null}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Leave requests</CardTitle>
            <CardDescription>Filter and decide pending leaves.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2 md:grid-cols-[180px_1fr_auto]">
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
              >
                <option value="ALL">All statuses</option>
                <option value="PENDING">Pending</option>
                <option value="APPROVED">Approved</option>
                <option value="REJECTED">Rejected</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={teacherFilter}
                onChange={(event) => setTeacherFilter(event.target.value)}
              >
                <option value="">All teachers</option>
                {teacherOptions.map((teacher) => (
                  <option key={teacher.id} value={teacher.id}>
                    {teacher.name}
                  </option>
                ))}
              </select>
              <Button type="button" variant="outline" disabled={submitting} onClick={() => void refresh()}>
                Apply
              </Button>
            </div>

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading…</p>
            ) : (
              <div className="space-y-3">
                {leaves.map((item) => (
                  <article key={item.id} className="rounded-none border border-border bg-background/60 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold">
                          {item.teacher.user.name}
                          <span className="ml-2 text-xs font-normal text-muted-foreground">
                            ({item.teacher.user.email})
                          </span>
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {formatDate(item.startDate)} → {formatDate(item.endDate)}
                        </p>
                        {item.reason ? (
                          <p className="mt-1 text-xs text-muted-foreground">{item.reason}</p>
                        ) : null}
                      </div>
                      <Badge variant={item.status === "PENDING" ? "secondary" : item.status === "APPROVED" ? "outline" : "destructive"}>
                        {item.status}
                      </Badge>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        type="button"
                        onClick={() => void decide(item.id, "APPROVED")}
                        disabled={submitting || item.status !== "PENDING"}
                      >
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        type="button"
                        onClick={() => void decide(item.id, "REJECTED")}
                        disabled={submitting || item.status !== "PENDING"}
                      >
                        Reject
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        type="button"
                        onClick={() => void decide(item.id, "CANCELLED")}
                        disabled={submitting || item.status !== "PENDING"}
                      >
                        Cancel
                      </Button>
                    </div>
                  </article>
                ))}
                {leaves.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No leave requests found.</p>
                ) : null}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

