"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
} from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { type ExamTypeValue } from "@/constants/exam-types";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type ClassOption = { id: string; name: string };
type TeacherOption = { id: string; name: string };
type SubjectOption = {
  id: string;
  name: string;
  classId: string;
  class: { id: string; name: string };
};
type ExamTypeOption = {
  id: ExamTypeValue;
  name: string;
  code: string;
};
type ExamListRecord = {
  id: string;
  name: string;
  code: string;
  date: string;
  description: string | null;
  academicYear: string;
  status: string;
  generateResult: boolean;
  includeInFinalReport: boolean;
  includeInTranscript: boolean;
  includeInMeritList: boolean;
  lockAfterPublish: boolean;
  publishStartsAt: string | null;
  publishEndsAt: string | null;
  resultPublishAt: string | null;
  visibleToStudents: boolean;
  visibleToParents: boolean;
  visibleToTeachers: boolean;
  isAllClasses: boolean;
  class: { id: string; name: string };
  examType: ExamTypeValue;
  _count: {
    results: number;
    assignedClasses: number;
    subjects: number;
    teacherAssignments: number;
    history: number;
  };
};
type ExamDetail = {
  exam: ExamListRecord & {
    assignedClasses: Array<{
      id: string;
      createdAt: string;
      class: { id: string; name: string };
    }>;
    subjects: Array<{
      id: string;
      displayOrder: number;
      isMandatory: boolean;
      fullMarks: number | null;
      passMarks: number | null;
      classId: string;
      class: { id: string; name: string };
      subjectId: string;
      subject: { id: string; name: string };
      components: Array<{
        id: string;
        name: string;
        displayOrder: number;
        fullMarks: number | null;
        isMandatory: boolean;
      }>;
    }>;
    teacherAssignments: Array<{
      id: string;
      canEdit: boolean;
      teacher: { id: string; user: { name: string } };
      class: { id: string; name: string };
      subject: { id: string; name: string } | null;
    }>;
    history: Array<{
      id: string;
      action: string;
      snapshot: Record<string, unknown>;
      metadata: Record<string, unknown> | null;
      createdAt: string;
      actor: { id: string; name: string; email: string } | null;
    }>;
  };
};
type WorkspaceResponse = {
  dashboard: {
    exams: ExamListRecord[];
    classes: ClassOption[];
    subjects: SubjectOption[];
    teachers: TeacherOption[];
    examTypes: ExamTypeOption[];
    stats: {
      total: number;
      upcoming: number;
      published: number;
      resultPublished: number;
      archived: number;
    };
  };
};
type CoreForm = {
  name: string;
  code: string;
  date: string;
  description: string;
  academicYear: string;
  classId: string;
  classIds: string[];
  isAllClasses: boolean;
  examTypeId: string;
  status: string;
  visibleToStudents: boolean;
  visibleToParents: boolean;
  visibleToTeachers: boolean;
  generateResult: boolean;
  includeInFinalReport: boolean;
  includeInTranscript: boolean;
  includeInMeritList: boolean;
  lockAfterPublish: boolean;
  publishStartsAt: string;
  publishEndsAt: string;
  resultPublishAt: string;
};
type SubjectForm = {
  classId: string;
  subjectId: string;
  displayOrder: string;
  fullMarks: string;
  passMarks: string;
  isMandatory: boolean;
};
type ComponentForm = {
  examSubjectId: string;
  name: string;
  displayOrder: string;
  fullMarks: string;
  isMandatory: boolean;
};
type TeacherForm = {
  teacherId: string;
  classId: string;
  subjectId: string;
  canEdit: boolean;
};
function emptyCoreForm(): CoreForm {
  return {
    name: "",
    code: "",
    date: new Date().toISOString().split("T")[0] ?? "",
    description: "",
    academicYear: new Date().getFullYear().toString(),
    classId: "",
    classIds: [],
    isAllClasses: false,
    examTypeId: "",
    status: "DRAFT",
    visibleToStudents: false,
    visibleToParents: false,
    visibleToTeachers: true,
    generateResult: true,
    includeInFinalReport: false,
    includeInTranscript: false,
    includeInMeritList: false,
    lockAfterPublish: true,
    publishStartsAt: "",
    publishEndsAt: "",
    resultPublishAt: "",
  };
}

function toDateTimeInput(value: string | null | undefined) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  const hours = `${date.getHours()}`.padStart(2, "0");
  const minutes = `${date.getMinutes()}`.padStart(2, "0");
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

function getAssignmentClassIds(
  exam: ExamDetail["exam"],
  classes: ClassOption[],
) {
  if (exam.isAllClasses) {
    return classes.map((item) => item.id);
  }

  const selected = exam.assignedClasses.map((item) => item.class.id);
  if (selected.length > 0) {
    return selected;
  }

  return [exam.class.id];
}

function buildCoreFormFromExam(
  exam: ExamDetail["exam"],
  classes: ClassOption[],
) {
  return {
    name: exam.name,
    code: exam.code,
    date: new Date(exam.date).toISOString().split("T")[0] ?? "",
    description: exam.description ?? "",
    academicYear: exam.academicYear,
    classId: exam.class.id,
    classIds: getAssignmentClassIds(exam, classes),
    isAllClasses: exam.isAllClasses,
    examTypeId: exam.examType,
    status: exam.status,
    visibleToStudents: exam.visibleToStudents,
    visibleToParents: exam.visibleToParents,
    visibleToTeachers: exam.visibleToTeachers,
    generateResult: exam.generateResult,
    includeInFinalReport: exam.includeInFinalReport,
    includeInTranscript: exam.includeInTranscript,
    includeInMeritList: exam.includeInMeritList,
    lockAfterPublish: exam.lockAfterPublish,
    publishStartsAt: toDateTimeInput(exam.publishStartsAt),
    publishEndsAt: toDateTimeInput(exam.publishEndsAt),
    resultPublishAt: toDateTimeInput(exam.resultPublishAt),
  };
}

export function ExamManagementPanel({
  allowCreateExam = false,
}: {
  allowCreateExam?: boolean;
} = {}) {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [workspace, setWorkspace] = useState<
    WorkspaceResponse["dashboard"] | null
  >(null);
  const [selectedExamId, setSelectedExamId] = useState<string | null>(null);
  const [selectedExam, setSelectedExam] = useState<ExamDetail["exam"] | null>(
    null,
  );
  const selectedExamIdRef = useRef<string | null>(null);
  const [search, setSearch] = useState("");
  const [classFilter, setClassFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [academicYearFilter, setAcademicYearFilter] = useState("");
  const [examTypeFilter, setExamTypeFilter] = useState("ALL");
  const [coreForm, setCoreForm] = useState<CoreForm>(emptyCoreForm());
  const [subjectForm, setSubjectForm] = useState<SubjectForm>({
    classId: "",
    subjectId: "",
    displayOrder: "0",
    fullMarks: "",
    passMarks: "",
    isMandatory: true,
  });
  const [componentForm, setComponentForm] = useState<ComponentForm>({
    examSubjectId: "",
    name: "",
    displayOrder: "0",
    fullMarks: "",
    isMandatory: true,
  });
  const [teacherForm, setTeacherForm] = useState<TeacherForm>({
    teacherId: "",
    classId: "",
    subjectId: "",
    canEdit: false,
  });
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setAuthState(readAuth()), []);

  useEffect(() => {
    selectedExamIdRef.current = selectedExamId;
  }, [selectedExamId]);

  const loadWorkspace = useCallback(
    async (nextAuth: AuthStorage) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (search.trim()) params.set("search", search.trim());
        if (classFilter !== "ALL") params.set("classId", classFilter);
        if (statusFilter !== "ALL") params.set("status", statusFilter);
        if (academicYearFilter.trim())
          params.set("academicYear", academicYearFilter.trim());
        if (examTypeFilter !== "ALL") params.set("examTypeId", examTypeFilter);

        const response = await fetch(`/api/v1/exams?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok)
          throw new Error(json.message ?? "Unable to load exam workspace");
        const payload = json.data as WorkspaceResponse["dashboard"];
        setWorkspace(payload);
        if (!selectedExamIdRef.current && payload.exams[0]) {
          setSelectedExamId(payload.exams[0].id);
        }
        if (!selectedExamIdRef.current) {
          setCoreForm(() => ({
            ...emptyCoreForm(),
            classId: payload.classes[0]?.id ?? "",
            classIds: payload.classes[0]?.id ? [payload.classes[0].id] : [],
            examTypeId: payload.examTypes[0]?.id ?? "",
          }));
        }
      } catch (nextError) {
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load exam workspace",
        );
      } finally {
        setLoading(false);
      }
    },
    [academicYearFilter, classFilter, examTypeFilter, search, statusFilter],
  );

  const loadExamDetail = useCallback(
    async (nextAuth: AuthStorage, examId: string) => {
      setDetailLoading(true);
      try {
        const response = await fetch(`/api/v1/exams/${examId}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok)
          throw new Error(json.message ?? "Unable to load exam detail");
        const payload = json.data as ExamDetail;
        setSelectedExam(payload.exam);
        const classSource = workspace?.classes ?? [];
        if (classSource.length > 0) {
          setCoreForm(buildCoreFormFromExam(payload.exam, classSource));
        }
        setSubjectForm((prev) => ({
          ...prev,
          classId:
            payload.exam.subjects[0]?.classId ??
            payload.exam.class.id ??
            workspace?.classes[0]?.id ??
            "",
          subjectId: payload.exam.subjects[0]?.subjectId ?? "",
        }));
        setComponentForm((prev) => ({
          ...prev,
          examSubjectId: payload.exam.subjects[0]?.id ?? "",
        }));
        setTeacherForm((prev) => ({
          ...prev,
          classId:
            payload.exam.assignedClasses[0]?.class.id ??
            payload.exam.class.id ??
            workspace?.classes[0]?.id ??
            "",
        }));
      } catch (nextError) {
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load exam detail",
        );
      } finally {
        setDetailLoading(false);
      }
    },
    [workspace],
  );

  useEffect(() => {
    if (authState) void loadWorkspace(authState);
  }, [authState, loadWorkspace]);

  useEffect(() => {
    if (authState && selectedExamId) {
      void loadExamDetail(authState, selectedExamId);
    } else {
      setSelectedExam(null);
    }
  }, [authState, loadExamDetail, selectedExamId]);

  const refreshWorkspace = async () => {
    if (authState) await loadWorkspace(authState);
  };

  const refreshSelectedExam = async () => {
    if (authState && selectedExamId)
      await loadExamDetail(authState, selectedExamId);
  };

  const request = async (
    url: string,
    init: RequestInit,
    fallbackMessage: string,
  ) => {
    if (!authState) throw new Error("Authentication is required");
    const response = await fetch(url, {
      ...init,
      headers: {
        ...(init.headers ?? {}),
        Authorization: `Bearer ${authState.token}`,
      },
    });
    const json = await response.json();
    if (!response.ok) {
      throw new Error(json.message ?? fallbackMessage);
    }
    return json.data;
  };

  const classIdsForSubmit = useMemo(() => {
    if (!workspace) return [];
    if (coreForm.isAllClasses) return workspace.classes.map((item) => item.id);
    const selected = new Set(coreForm.classIds.filter(Boolean));
    if (coreForm.classId) selected.add(coreForm.classId);
    return Array.from(selected);
  }, [coreForm.classId, coreForm.classIds, coreForm.isAllClasses, workspace]);

  const subjectClassOptions = useMemo(() => {
    if (!workspace) return [];
    const allowedClassIds = selectedExam?.assignedClasses.length
      ? selectedExam.assignedClasses.map((item) => item.class.id)
      : classIdsForSubmit;
    return workspace.classes.filter((item) =>
      allowedClassIds.includes(item.id),
    );
  }, [classIdsForSubmit, selectedExam, workspace]);

  const subjectOptionsForClass = useMemo(() => {
    if (!workspace) return [];
    return workspace.subjects.filter(
      (subject) => subject.classId === subjectForm.classId,
    );
  }, [subjectForm.classId, workspace]);

  const teacherSubjectOptions = useMemo(() => {
    if (!workspace) return [];
    return workspace.subjects.filter(
      (subject) => subject.classId === teacherForm.classId,
    );
  }, [teacherForm.classId, workspace]);

  useEffect(() => {
    if (!workspace) return;
    if (!coreForm.classId) {
      setCoreForm((prev) => ({
        ...prev,
        classId: workspace.classes[0]?.id ?? "",
        classIds: workspace.classes[0]?.id ? [workspace.classes[0].id] : [],
        examTypeId: prev.examTypeId || workspace.examTypes[0]?.id || "",
      }));
    }
    if (!subjectForm.classId) {
      setSubjectForm((prev) => ({
        ...prev,
        classId: workspace.classes[0]?.id ?? "",
      }));
    }
    if (!teacherForm.teacherId) {
      setTeacherForm((prev) => ({
        ...prev,
        teacherId: workspace.teachers[0]?.id ?? "",
      }));
    }
    if (!teacherForm.classId) {
      setTeacherForm((prev) => ({
        ...prev,
        classId: workspace.classes[0]?.id ?? "",
      }));
    }
    if (!componentForm.examSubjectId) {
      setComponentForm((prev) => ({
        ...prev,
        examSubjectId: selectedExam?.subjects[0]?.id ?? "",
      }));
    }
  }, [
    componentForm.examSubjectId,
    coreForm.classId,
    selectedExam,
    subjectForm.classId,
    teacherForm.classId,
    teacherForm.teacherId,
    workspace,
  ]);

  useEffect(() => {
    if (!selectedExam || !workspace) return;
    setCoreForm(buildCoreFormFromExam(selectedExam, workspace.classes));
    setSubjectForm((prev) => ({
      ...prev,
      classId:
        selectedExam.subjects[0]?.classId ??
        selectedExam.class.id ??
        workspace.classes[0]?.id ??
        "",
      subjectId: selectedExam.subjects[0]?.subjectId ?? prev.subjectId,
    }));
    setComponentForm((prev) => ({
      ...prev,
      examSubjectId: selectedExam.subjects[0]?.id ?? prev.examSubjectId,
    }));
    setTeacherForm((prev) => ({
      ...prev,
      classId:
        selectedExam.assignedClasses[0]?.class.id ??
        selectedExam.class.id ??
        workspace.classes[0]?.id ??
        "",
    }));
  }, [selectedExam, workspace]);

  const handleCoreSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState || !workspace) return;
    if (!selectedExamId && !allowCreateExam) {
      setError("Please select an exam to update");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const body = {
        ...coreForm,
        classIds: classIdsForSubmit,
        description: coreForm.description.trim() || undefined,
        examTypeId: coreForm.examTypeId || null,
        publishStartsAt: coreForm.publishStartsAt || null,
        publishEndsAt: coreForm.publishEndsAt || null,
        resultPublishAt: coreForm.resultPublishAt || null,
      };

      const data = selectedExamId
        ? await request(
            `/api/v1/exams/${selectedExamId}`,
            {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
            },
            "Unable to update exam",
          )
        : await request(
            "/api/v1/exams",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
            },
            "Unable to create exam",
          );

      const exam = data.exam as ExamListRecord | ExamDetail["exam"];
      if (!selectedExamId) {
        selectedExamIdRef.current = exam.id;
        setSelectedExamId(exam.id);
      }
      await refreshWorkspace();
    } catch (nextError) {
      setError(
        nextError instanceof Error ? nextError.message : "Unable to save exam",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const archiveExam = async (examId: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${examId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "archive" }),
        },
        "Unable to archive exam",
      );
      await refreshWorkspace();
      if (selectedExamId === examId) {
        await refreshSelectedExam();
      }
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to archive exam",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteExam = async (examId: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${examId}`,
        {
          method: "DELETE",
        },
        "Unable to delete exam",
      );
      if (selectedExamId === examId) {
        selectedExamIdRef.current = null;
        setSelectedExamId(null);
        setSelectedExam(null);
      }
      await refreshWorkspace();
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to delete exam",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const submitSubject = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "subject-upsert",
            classId: subjectForm.classId,
            subjectId: subjectForm.subjectId,
            displayOrder: Number(subjectForm.displayOrder || 0),
            isMandatory: subjectForm.isMandatory,
            fullMarks: subjectForm.fullMarks
              ? Number(subjectForm.fullMarks)
              : null,
            passMarks: subjectForm.passMarks
              ? Number(subjectForm.passMarks)
              : null,
          }),
        },
        "Unable to save subject mapping",
      );
      await refreshSelectedExam();
      await refreshWorkspace();
      setSubjectForm((prev) => ({
        ...prev,
        subjectId: "",
        fullMarks: "",
        passMarks: "",
        displayOrder: "0",
      }));
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to save subject mapping",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteSubject = async (classId: string, subjectId: string) => {
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "subject-delete",
            classId,
            subjectId,
          }),
        },
        "Unable to delete subject mapping",
      );
      await refreshSelectedExam();
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to delete subject mapping",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const submitComponent = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "component-upsert",
            examSubjectId: componentForm.examSubjectId,
            name: componentForm.name,
            displayOrder: Number(componentForm.displayOrder || 0),
            fullMarks: componentForm.fullMarks
              ? Number(componentForm.fullMarks)
              : null,
            isMandatory: componentForm.isMandatory,
          }),
        },
        "Unable to save component",
      );
      await refreshSelectedExam();
      setComponentForm((prev) => ({
        ...prev,
        name: "",
        fullMarks: "",
        displayOrder: "0",
      }));
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to save component",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteComponent = async (componentId: string) => {
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "component-delete", componentId }),
        },
        "Unable to delete component",
      );
      await refreshSelectedExam();
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to delete component",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const submitTeacherAssignment = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "teacher-upsert",
            teacherId: teacherForm.teacherId,
            classId: teacherForm.classId,
            subjectId: teacherForm.subjectId || null,
            canEdit: teacherForm.canEdit,
          }),
        },
        "Unable to save teacher assignment",
      );
      await refreshSelectedExam();
      setTeacherForm((prev) => ({ ...prev, subjectId: "", canEdit: false }));
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to save teacher assignment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteTeacherAssignment = async (assignmentId: string) => {
    if (!selectedExamId) return;
    setSubmitting(true);
    setError(null);
    try {
      await request(
        `/api/v1/exams/${selectedExamId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "teacher-delete", assignmentId }),
        },
        "Unable to delete teacher assignment",
      );
      await refreshSelectedExam();
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to delete teacher assignment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-linear-to-r from-slate-950 via-slate-900 to-slate-950 px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Assessment
        </p>
        <h1 className="text-2xl font-semibold">Exam management workspace</h1>
        <p className="mt-2 max-w-3xl text-sm text-slate-300">
          Build exams, assign them to classes, map subjects and teachers, and
          prepare the evaluation structure before results are published.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <Card>
          <CardHeader>
            <CardDescription>Total exams</CardDescription>
            <CardTitle>{workspace?.stats.total ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Upcoming</CardDescription>
            <CardTitle>{workspace?.stats.upcoming ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Published</CardDescription>
            <CardTitle>{workspace?.stats.published ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Result published</CardDescription>
            <CardTitle>{workspace?.stats.resultPublished ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Archived</CardDescription>
            <CardTitle>{workspace?.stats.archived ?? 0}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {error ? (
        <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-4 py-3 text-xs text-destructive">
          {error}
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1.1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>
              {selectedExamId
                ? "Update exam"
                : allowCreateExam
                  ? "Create exam"
                  : "Select an exam to edit"}
            </CardTitle>
            <CardDescription>
              Core settings, visibility, lifecycle, and class assignment.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-5" onSubmit={handleCoreSubmit}>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="exam-name">Exam name</Label>
                  <Input
                    id="exam-name"
                    value={coreForm.name}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="exam-code">Exam code</Label>
                  <Input
                    id="exam-code"
                    value={coreForm.code}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        code: event.target.value.toUpperCase(),
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="exam-date">Exam date</Label>
                  <Input
                    id="exam-date"
                    type="date"
                    value={coreForm.date}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        date: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="exam-year">Academic year</Label>
                  <Input
                    id="exam-year"
                    value={coreForm.academicYear}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        academicYear: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="exam-description">Description</Label>
                  <Textarea
                    id="exam-description"
                    value={coreForm.description}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        description: event.target.value,
                      }))
                    }
                    rows={3}
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="exam-type">Exam type</Label>
                  <select
                    id="exam-type"
                    className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                    value={coreForm.examTypeId}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        examTypeId: event.target.value,
                      }))
                    }
                  >
                    <option value="">Select type</option>
                    {workspace?.examTypes.map((examType) => (
                      <option key={examType.id} value={examType.id}>
                        {examType.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="exam-status">Lifecycle status</Label>
                  <select
                    id="exam-status"
                    className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                    value={coreForm.status}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        status: event.target.value,
                      }))
                    }
                  >
                    {[
                      "DRAFT",
                      "ASSIGNED",
                      "PUBLISHED",
                      "ONGOING",
                      "COMPLETED",
                      "RESULT_PENDING",
                      "RESULT_PUBLISHED",
                      "ARCHIVED",
                    ].map((status) => (
                      <option key={status} value={status}>
                        {status.replaceAll("_", " ")}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-3 rounded-xl border border-border bg-background/50 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">Class assignment</p>
                    <p className="text-xs text-muted-foreground">
                      Assign one, many, or every class.
                    </p>
                  </div>
                  <label className="flex items-center gap-2 text-xs font-medium">
                    <input
                      type="checkbox"
                      checked={coreForm.isAllClasses}
                      onChange={(event) => {
                        const nextAllClasses = event.target.checked;
                        setCoreForm((prev) => ({
                          ...prev,
                          isAllClasses: nextAllClasses,
                          classIds: nextAllClasses
                            ? (workspace?.classes.map((item) => item.id) ?? [])
                            : prev.classIds,
                        }));
                      }}
                    />
                    All classes
                  </label>
                </div>
                <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                  {workspace?.classes.map((item) => {
                    const checked =
                      coreForm.isAllClasses ||
                      coreForm.classIds.includes(item.id);
                    return (
                      <label
                        key={item.id}
                        className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-xs"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          disabled={coreForm.isAllClasses}
                          onChange={(event) => {
                            const nextChecked = event.target.checked;
                            setCoreForm((prev) => {
                              const nextIds = new Set(prev.classIds);
                              if (nextChecked) nextIds.add(item.id);
                              else nextIds.delete(item.id);
                              if (!nextIds.has(prev.classId))
                                nextIds.add(prev.classId);
                              return { ...prev, classIds: Array.from(nextIds) };
                            });
                          }}
                        />
                        <span>{item.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-3 rounded-xl border border-border bg-background/50 p-4">
                  <p className="text-sm font-semibold">Visibility</p>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.visibleToStudents}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          visibleToStudents: event.target.checked,
                        }))
                      }
                    />
                    Students
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.visibleToParents}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          visibleToParents: event.target.checked,
                        }))
                      }
                    />
                    Guardians
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.visibleToTeachers}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          visibleToTeachers: event.target.checked,
                        }))
                      }
                    />
                    Teachers
                  </label>
                </div>
                <div className="space-y-3 rounded-xl border border-border bg-background/50 p-4">
                  <p className="text-sm font-semibold">Result readiness</p>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.generateResult}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          generateResult: event.target.checked,
                        }))
                      }
                    />
                    Generate result
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.includeInFinalReport}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          includeInFinalReport: event.target.checked,
                        }))
                      }
                    />
                    Include in final report
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.includeInTranscript}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          includeInTranscript: event.target.checked,
                        }))
                      }
                    />
                    Include in transcript
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.includeInMeritList}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          includeInMeritList: event.target.checked,
                        }))
                      }
                    />
                    Include in merit list
                  </label>
                  <label className="flex items-center gap-2 text-xs">
                    <input
                      type="checkbox"
                      checked={coreForm.lockAfterPublish}
                      onChange={(event) =>
                        setCoreForm((prev) => ({
                          ...prev,
                          lockAfterPublish: event.target.checked,
                        }))
                      }
                    />
                    Lock critical settings after publish
                  </label>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="publish-starts">Publish starts</Label>
                  <Input
                    id="publish-starts"
                    type="datetime-local"
                    value={coreForm.publishStartsAt}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        publishStartsAt: event.target.value,
                      }))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="publish-ends">Publish ends</Label>
                  <Input
                    id="publish-ends"
                    type="datetime-local"
                    value={coreForm.publishEndsAt}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        publishEndsAt: event.target.value,
                      }))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="result-publish-at">Result publish time</Label>
                  <Input
                    id="result-publish-at"
                    type="datetime-local"
                    value={coreForm.resultPublishAt}
                    onChange={(event) =>
                      setCoreForm((prev) => ({
                        ...prev,
                        resultPublishAt: event.target.value,
                      }))
                    }
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <Button type="submit" disabled={submitting}>
                  {submitting
                    ? "Saving…"
                    : selectedExamId || !allowCreateExam
                      ? "Update exam"
                      : "Create exam"}
                </Button>
                {selectedExamId && allowCreateExam ? (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      selectedExamIdRef.current = null;
                      setSelectedExamId(null);
                      setSelectedExam(null);
                      setCoreForm(emptyCoreForm());
                    }}
                  >
                    New exam
                  </Button>
                ) : null}
                {detailLoading ? (
                  <span className="text-xs text-muted-foreground">
                    Loading selected exam…
                  </span>
                ) : null}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Exam list</CardTitle>
            <CardDescription>
              Search, filter, select, archive, and purge draft exams.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-2 md:grid-cols-[1fr_160px_160px_160px_auto]"
              onSubmit={(event) => {
                event.preventDefault();
                void refreshWorkspace();
              }}
            >
              <Input
                placeholder="Search exam name or code"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
              <select
                className="h-9 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={classFilter}
                onChange={(event) => setClassFilter(event.target.value)}
              >
                <option value="ALL">All classes</option>
                {workspace?.classes.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <select
                className="h-9 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
              >
                <option value="ALL">All statuses</option>
                {[
                  "DRAFT",
                  "ASSIGNED",
                  "PUBLISHED",
                  "ONGOING",
                  "COMPLETED",
                  "RESULT_PENDING",
                  "RESULT_PUBLISHED",
                  "ARCHIVED",
                ].map((status) => (
                  <option key={status} value={status}>
                    {status.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
              <Input
                placeholder="Academic year"
                value={academicYearFilter}
                onChange={(event) => setAcademicYearFilter(event.target.value)}
              />
              <select
                className="h-9 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={examTypeFilter}
                onChange={(event) => setExamTypeFilter(event.target.value)}
              >
                <option value="ALL">All types</option>
                {workspace?.examTypes.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <Button type="submit" variant="outline" className="md:col-span-5">
                Filter
              </Button>
            </form>
            <div className="space-y-3">
              {loading ? (
                <p className="text-xs text-muted-foreground">Loading exams…</p>
              ) : null}
              {workspace?.exams.map((exam) => (
                <article
                  key={exam.id}
                  className={`rounded-xl border p-4 ${selectedExamId === exam.id ? "border-primary bg-primary/5" : "border-border bg-background/60"}`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold text-foreground">
                        {exam.name}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {exam.code} · {exam.academicYear} ·{" "}
                        {new Date(exam.date).toLocaleDateString()}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {exam.class.name} · {exam.status.replaceAll("_", " ")} ·{" "}
                        {exam._count.assignedClasses} class links ·{" "}
                        {exam._count.subjects} subjects
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        type="button"
                        variant="outline"
                        onClick={() => {
                          selectedExamIdRef.current = exam.id;
                          setSelectedExamId(exam.id);
                        }}
                      >
                        Select
                      </Button>
                      <Button
                        size="sm"
                        type="button"
                        variant="outline"
                        onClick={() => void archiveExam(exam.id)}
                        disabled={submitting || exam.status === "ARCHIVED"}
                      >
                        Archive
                      </Button>
                      <Button
                        size="sm"
                        type="button"
                        variant="destructive"
                        onClick={() => void deleteExam(exam.id)}
                        disabled={
                          submitting ||
                          (exam.status !== "DRAFT" &&
                            exam.status !== "ASSIGNED")
                        }
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Type:{" "}
                    {workspace?.examTypes.find(
                      (item) => item.id === exam.examType,
                    )?.name ?? exam.examType.replaceAll("_", " ")}
                  </p>
                </article>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {selectedExam ? (
        <div className="grid gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Subject mapping</CardTitle>
              <CardDescription>
                Attach class subjects, marks, and order.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <form className="space-y-4" onSubmit={submitSubject}>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="subject-class">Class</Label>
                    <select
                      id="subject-class"
                      className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={subjectForm.classId}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          classId: event.target.value,
                          subjectId: "",
                        }))
                      }
                    >
                      {subjectClassOptions.map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-name">Subject</Label>
                    <select
                      id="subject-name"
                      className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={subjectForm.subjectId}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          subjectId: event.target.value,
                        }))
                      }
                    >
                      <option value="">Select subject</option>
                      {subjectOptionsForClass.map((subject) => (
                        <option key={subject.id} value={subject.id}>
                          {subject.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-order">Order</Label>
                    <Input
                      id="subject-order"
                      type="number"
                      min="0"
                      value={subjectForm.displayOrder}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          displayOrder: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-full-marks">Full marks</Label>
                    <Input
                      id="subject-full-marks"
                      type="number"
                      min="0"
                      step="0.01"
                      value={subjectForm.fullMarks}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          fullMarks: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-pass-marks">Pass marks</Label>
                    <Input
                      id="subject-pass-marks"
                      type="number"
                      min="0"
                      step="0.01"
                      value={subjectForm.passMarks}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          passMarks: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <label className="flex items-center gap-2 self-end text-xs">
                    <input
                      type="checkbox"
                      checked={subjectForm.isMandatory}
                      onChange={(event) =>
                        setSubjectForm((prev) => ({
                          ...prev,
                          isMandatory: event.target.checked,
                        }))
                      }
                    />
                    Mandatory
                  </label>
                </div>
                <Button type="submit" disabled={submitting}>
                  Save subject
                </Button>
              </form>

              <div className="space-y-3">
                {selectedExam.subjects.length ? (
                  selectedExam.subjects.map((item) => (
                    <article
                      key={item.id}
                      className="rounded-xl border border-border bg-background/60 p-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="text-sm font-semibold">
                            {item.class.name} · {item.subject.name}
                          </h3>
                          <p className="text-xs text-muted-foreground">
                            Order {item.displayOrder} ·{" "}
                            {item.isMandatory ? "Mandatory" : "Optional"} · Full
                            marks {item.fullMarks ?? "N/A"} · Pass marks{" "}
                            {item.passMarks ?? "N/A"}
                          </p>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="destructive"
                          onClick={() =>
                            void deleteSubject(item.classId, item.subjectId)
                          }
                          disabled={submitting}
                        >
                          Remove
                        </Button>
                      </div>
                      <div className="mt-3 space-y-2">
                        <p className="text-xs font-medium text-muted-foreground">
                          Components
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {item.components.length ? (
                            item.components.map((component) => (
                              <span
                                key={component.id}
                                className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 text-[11px]"
                              >
                                {component.name} · {component.fullMarks ?? "?"}
                                <button
                                  type="button"
                                  className="text-destructive"
                                  onClick={() =>
                                    void deleteComponent(component.id)
                                  }
                                >
                                  Remove
                                </button>
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-muted-foreground">
                              No components yet.
                            </span>
                          )}
                        </div>
                      </div>
                    </article>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No subjects mapped yet.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Components and teachers</CardTitle>
              <CardDescription>
                Define component marks and map teachers to exam
                responsibilities.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form className="space-y-4" onSubmit={submitComponent}>
                <div className="space-y-2">
                  <Label htmlFor="component-subject">Exam subject</Label>
                  <select
                    id="component-subject"
                    className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                    value={componentForm.examSubjectId}
                    onChange={(event) =>
                      setComponentForm((prev) => ({
                        ...prev,
                        examSubjectId: event.target.value,
                      }))
                    }
                  >
                    <option value="">Select subject</option>
                    {selectedExam.subjects.map((subject) => (
                      <option key={subject.id} value={subject.id}>
                        {subject.class.name} · {subject.subject.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="component-name">Component name</Label>
                    <Input
                      id="component-name"
                      value={componentForm.name}
                      onChange={(event) =>
                        setComponentForm((prev) => ({
                          ...prev,
                          name: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="component-order">Order</Label>
                    <Input
                      id="component-order"
                      type="number"
                      min="0"
                      value={componentForm.displayOrder}
                      onChange={(event) =>
                        setComponentForm((prev) => ({
                          ...prev,
                          displayOrder: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="component-full-marks">Full marks</Label>
                    <Input
                      id="component-full-marks"
                      type="number"
                      min="0"
                      step="0.01"
                      value={componentForm.fullMarks}
                      onChange={(event) =>
                        setComponentForm((prev) => ({
                          ...prev,
                          fullMarks: event.target.value,
                        }))
                      }
                    />
                  </div>
                  <label className="flex items-center gap-2 self-end text-xs">
                    <input
                      type="checkbox"
                      checked={componentForm.isMandatory}
                      onChange={(event) =>
                        setComponentForm((prev) => ({
                          ...prev,
                          isMandatory: event.target.checked,
                        }))
                      }
                    />
                    Mandatory
                  </label>
                </div>
                <Button type="submit" disabled={submitting}>
                  Save component
                </Button>
              </form>

              <form className="space-y-4" onSubmit={submitTeacherAssignment}>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="teacher-name">Teacher</Label>
                    <select
                      id="teacher-name"
                      className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={teacherForm.teacherId}
                      onChange={(event) =>
                        setTeacherForm((prev) => ({
                          ...prev,
                          teacherId: event.target.value,
                        }))
                      }
                    >
                      <option value="">Select teacher</option>
                      {workspace?.teachers.map((teacher) => (
                        <option key={teacher.id} value={teacher.id}>
                          {teacher.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="teacher-class">Class</Label>
                    <select
                      id="teacher-class"
                      className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={teacherForm.classId}
                      onChange={(event) =>
                        setTeacherForm((prev) => ({
                          ...prev,
                          classId: event.target.value,
                          subjectId: "",
                        }))
                      }
                    >
                      {selectedExam.assignedClasses.length ? (
                        selectedExam.assignedClasses.map((item) => (
                          <option key={item.class.id} value={item.class.id}>
                            {item.class.name}
                          </option>
                        ))
                      ) : (
                        <option value={selectedExam.class.id}>
                          {selectedExam.class.name}
                        </option>
                      )}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="teacher-subject">Subject</Label>
                    <select
                      id="teacher-subject"
                      className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={teacherForm.subjectId}
                      onChange={(event) =>
                        setTeacherForm((prev) => ({
                          ...prev,
                          subjectId: event.target.value,
                        }))
                      }
                    >
                      <option value="">Class responsibility only</option>
                      {teacherSubjectOptions.map((subject) => (
                        <option key={subject.id} value={subject.id}>
                          {subject.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <label className="flex items-center gap-2 self-end text-xs">
                    <input
                      type="checkbox"
                      checked={teacherForm.canEdit}
                      onChange={(event) =>
                        setTeacherForm((prev) => ({
                          ...prev,
                          canEdit: event.target.checked,
                        }))
                      }
                    />
                    Can edit
                  </label>
                </div>
                <Button type="submit" disabled={submitting}>
                  Save teacher mapping
                </Button>
              </form>

              <div className="space-y-3">
                <p className="text-sm font-semibold">Assigned teachers</p>
                {selectedExam.teacherAssignments.length ? (
                  selectedExam.teacherAssignments.map((item) => (
                    <article
                      key={item.id}
                      className="rounded-xl border border-border bg-background/60 p-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="text-sm font-semibold">
                            {item.teacher.user.name}
                          </h3>
                          <p className="text-xs text-muted-foreground">
                            {item.class.name}
                            {item.subject
                              ? ` · ${item.subject.name}`
                              : ""} · {item.canEdit ? "Can edit" : "View only"}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          type="button"
                          variant="destructive"
                          onClick={() => void deleteTeacherAssignment(item.id)}
                          disabled={submitting}
                        >
                          Remove
                        </Button>
                      </div>
                    </article>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No teacher mappings yet.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {selectedExam ? (
        <Card>
          <CardHeader>
            <CardTitle>Exam history</CardTitle>
            <CardDescription>
              Change log and snapshots for the selected exam.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {selectedExam.history.length ? (
              selectedExam.history.map((entry) => (
                <article
                  key={entry.id}
                  className="rounded-xl border border-border bg-background/60 p-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold">{entry.action}</h3>
                      <p className="text-xs text-muted-foreground">
                        {entry.actor
                          ? `${entry.actor.name} · ${entry.actor.email}`
                          : "System"}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(entry.createdAt).toLocaleString()}
                    </span>
                  </div>
                </article>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No history yet.</p>
            )}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
