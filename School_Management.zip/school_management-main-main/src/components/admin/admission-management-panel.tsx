"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import Image from "next/image";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";
import { toast } from "sonner";

type AdmissionDetails = {
  gender?: "MALE" | "FEMALE" | "OTHER" | null;
  fatherName?: string | null;
  fatherPhone?: string | null;
  motherName?: string | null;
  motherPhone?: string | null;
  guardianName?: string | null;
  guardianEmail?: string | null;
  guardianRelation?: string | null;
  guardianPhone?: string | null;
  guardianAddress?: string | null;
  nidNumber?: string | null;
  nidImage?: string | null;
  profileImage?: string | null;
  fatherNidNumber?: string | null;
  fatherNidImage?: string | null;
  motherNidNumber?: string | null;
  motherNidImage?: string | null;
};

type AdmissionRecord = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  className: string;
  message: string | null;
  details: AdmissionDetails | null;
  status: "PENDING" | "APPROVED" | "REJECTED";
  convertedToStudentId: string | null;
  createdAt: string;
};

type AdmissionResponse = {
  admissions: AdmissionRecord[];
  stats: { total: number; pending: number; approved: number; rejected: number };
};

type AdmissionDetailsDraft = {
  gender: "MALE" | "FEMALE" | "OTHER" | "";
  fatherName: string;
  fatherPhone: string;
  motherName: string;
  motherPhone: string;
  guardianName: string;
  guardianEmail: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianAddress: string;
  nidNumber: string;
  nidImage: string;
  profileImage: string;
  fatherNidNumber: string;
  fatherNidImage: string;
  motherNidNumber: string;
  motherNidImage: string;
};

type AdmissionDraft = {
  name: string;
  email: string;
  phone: string;
  className: string;
  message: string;
  status: AdmissionRecord["status"];
  details: AdmissionDetailsDraft;
};

const admissionStatusOptions: Array<AdmissionRecord["status"]> = [
  "PENDING",
  "APPROVED",
  "REJECTED",
];

function buildAdmissionDraft(admission: AdmissionRecord): AdmissionDraft {
  return {
    name: admission.name,
    email: admission.email,
    phone: admission.phone ?? "",
    className: admission.className,
    message: admission.message ?? "",
    status: admission.status,
    details: {
      gender: admission.details?.gender ?? "",
      fatherName: admission.details?.fatherName ?? "",
      fatherPhone: admission.details?.fatherPhone ?? "",
      motherName: admission.details?.motherName ?? "",
      motherPhone: admission.details?.motherPhone ?? "",
      guardianName: admission.details?.guardianName ?? "",
      guardianEmail: admission.details?.guardianEmail ?? "",
      guardianRelation: admission.details?.guardianRelation ?? "",
      guardianPhone: admission.details?.guardianPhone ?? "",
      guardianAddress: admission.details?.guardianAddress ?? "",
      nidNumber: admission.details?.nidNumber ?? "",
      nidImage: admission.details?.nidImage ?? "",
      profileImage: admission.details?.profileImage ?? "",
      fatherNidNumber: admission.details?.fatherNidNumber ?? "",
      fatherNidImage: admission.details?.fatherNidImage ?? "",
      motherNidNumber: admission.details?.motherNidNumber ?? "",
      motherNidImage: admission.details?.motherNidImage ?? "",
    },
  };
}

function cleanOptional(value: string) {
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function formatAdmissionStatus(status: AdmissionRecord["status"]) {
  return status[0] + status.slice(1).toLowerCase();
}

function imagePreview(value?: string | null) {
  if (!value) return null;

  return (
    <a href={value} target="_blank" rel="noreferrer" className="block">
      <div className="relative h-36 w-full overflow-hidden rounded-none border border-border">
        <Image
          src={value}
          alt="Admission attachment preview"
          fill
          unoptimized
          className="object-cover"
        />
      </div>
    </a>
  );
}

export function AdmissionManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [admissions, setAdmissions] = useState<AdmissionRecord[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
  });
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<
    "ALL" | "PENDING" | "APPROVED" | "REJECTED"
  >("ALL");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedAdmission, setSelectedAdmission] =
    useState<AdmissionRecord | null>(null);
  const [draftAdmission, setDraftAdmission] = useState<AdmissionDraft | null>(
    null,
  );

  useEffect(() => {
    setAuthState(readAuth());
  }, []);

  const loadAdmissions = useCallback(
    async (
      nextAuthState: AuthStorage,
      currentSearch = search,
      currentStatus = statusFilter,
    ) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim());
        }
        if (currentStatus !== "ALL") {
          params.set("status", currentStatus);
        }

        const response = await fetch(
          `/api/v1/admissions?${params.toString()}`,
          {
            headers: {
              Authorization: `Bearer ${nextAuthState.token}`,
            },
          },
        );
        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load admissions");
        }

        const data = json.data as AdmissionResponse;
        setAdmissions(data.admissions);
        setStats(data.stats);
      } catch (exception) {
        console.error(exception);
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load admissions",
        );
      } finally {
        setLoading(false);
      }
    },
    [search, statusFilter],
  );

  useEffect(() => {
    if (!authState) return;
    void loadAdmissions(authState);
  }, [authState, loadAdmissions]);

  useEffect(() => {
    if (!selectedAdmission) {
      setDraftAdmission(null);
      return;
    }

    setDraftAdmission(buildAdmissionDraft(selectedAdmission));
  }, [selectedAdmission]);

  const refresh = async () => {
    if (authState) {
      await loadAdmissions(authState);
    }
  };

  const updateAdmissionStatus = async (
    admissionId: string,
    admissionName: string,
    status: AdmissionRecord["status"],
  ) => {
    if (!authState) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/admissions/${admissionId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ status }),
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update admission status");
      }

      toast.success(`${admissionName} marked as ${status.toLowerCase()}`);
      await refresh();
    } catch (exception) {
      console.error(exception);
      toast.error(
        exception instanceof Error
          ? exception.message
          : "Unable to update admission status",
      );
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update admission status",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deleteAdmission = async (
    admissionId: string,
    admissionName: string,
  ) => {
    if (!authState) {
      return;
    }

    const confirmed = window.confirm(
      `Delete admission submission for ${admissionName}?`,
    );

    if (!confirmed) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/admissions/${admissionId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${authState.token}`,
        },
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to delete admission");
      }

      toast.success(`Deleted admission for ${admissionName}`);
      if (selectedAdmission?.id === admissionId) {
        setSelectedAdmission(null);
      }
      await refresh();
    } catch (exception) {
      console.error(exception);
      toast.error(
        exception instanceof Error
          ? exception.message
          : "Unable to delete admission",
      );
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to delete admission",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const closeDetails = () => setSelectedAdmission(null);

  const updateDraft = <K extends keyof AdmissionDraft>(
    field: K,
    value: AdmissionDraft[K],
  ) => {
    setDraftAdmission((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const updateDraftDetails = <K extends keyof AdmissionDetailsDraft>(
    field: K,
    value: AdmissionDetailsDraft[K],
  ) => {
    setDraftAdmission((prev) =>
      prev
        ? {
            ...prev,
            details: {
              ...prev.details,
              [field]: value,
            },
          }
        : prev,
    );
  };

  const persistAdmission = async (
    nextDraft: AdmissionDraft,
    options: { closeAfterSave?: boolean } = {},
  ) => {
    if (!authState || !selectedAdmission) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/v1/admissions/${selectedAdmission.id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${authState.token}`,
          },
          body: JSON.stringify({
            name: nextDraft.name.trim(),
            email: nextDraft.email.trim(),
            phone: cleanOptional(nextDraft.phone),
            className: nextDraft.className.trim(),
            message: cleanOptional(nextDraft.message),
            status: nextDraft.status,
            details: {
              gender: nextDraft.details.gender || null,
              fatherName: cleanOptional(nextDraft.details.fatherName),
              fatherPhone: cleanOptional(nextDraft.details.fatherPhone),
              motherName: cleanOptional(nextDraft.details.motherName),
              motherPhone: cleanOptional(nextDraft.details.motherPhone),
              guardianName: cleanOptional(nextDraft.details.guardianName),
              guardianEmail: cleanOptional(nextDraft.details.guardianEmail),
              guardianRelation: cleanOptional(
                nextDraft.details.guardianRelation,
              ),
              guardianPhone: cleanOptional(nextDraft.details.guardianPhone),
              guardianAddress: cleanOptional(nextDraft.details.guardianAddress),
              nidNumber: cleanOptional(nextDraft.details.nidNumber),
              nidImage: cleanOptional(nextDraft.details.nidImage),
              profileImage: cleanOptional(nextDraft.details.profileImage),
              fatherNidNumber: cleanOptional(nextDraft.details.fatherNidNumber),
              fatherNidImage: cleanOptional(nextDraft.details.fatherNidImage),
              motherNidNumber: cleanOptional(nextDraft.details.motherNidNumber),
              motherNidImage: cleanOptional(nextDraft.details.motherNidImage),
            },
          }),
        },
      );

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update admission");
      }

      if (options.closeAfterSave) {
        setSelectedAdmission(null);
      }
      await refresh();
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update admission",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const saveAdmission = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!draftAdmission) {
      return;
    }

    await persistAdmission(draftAdmission, { closeAfterSave: true });
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Intake
        </p>
        <h1 className="text-2xl font-semibold">Admissions</h1>
        <p className="max-w-3xl text-sm text-slate-200">
          Track incoming applications, review status, and coordinate the next
          cohort.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-4">
        <Card>
          <CardHeader>
            <CardDescription>Total</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Pending</CardDescription>
            <CardTitle>{stats.pending}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Approved</CardDescription>
            <CardTitle>{stats.approved}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Rejected</CardDescription>
            <CardTitle>{stats.rejected}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Application queue</CardTitle>
            <CardDescription>
              Review and update admission decisions.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-3 md:grid-cols-[1fr_180px_auto]"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by applicant or class"
              />
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={statusFilter}
                onChange={(event) =>
                  setStatusFilter(event.target.value as typeof statusFilter)
                }
              >
                <option value="ALL">All statuses</option>
                {admissionStatusOptions.map((status) => (
                  <option key={status} value={status}>
                    {status[0] + status.slice(1).toLowerCase()}
                  </option>
                ))}
              </select>
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>
            {error && (
              <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                {error}
              </div>
            )}
            {loading ? (
              <p className="text-xs text-muted-foreground">
                Loading applications…
              </p>
            ) : admissions.length ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-230 text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                      <th className="px-3 py-3 font-medium">Name</th>
                      <th className="px-3 py-3 font-medium">Email</th>
                      <th className="px-3 py-3 font-medium">Class</th>
                      <th className="px-3 py-3 font-medium">Created at</th>
                      <th className="px-3 py-3 font-medium">Status</th>
                      <th className="px-3 py-3 font-medium">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {admissions.map((admission) => (
                      <tr
                        key={admission.id}
                        className="border-b border-border/60 last:border-b-0"
                      >
                        <td className="px-3 py-4 align-top">
                          <div className="space-y-1">
                            <p className="font-medium text-foreground">
                              {admission.name}
                            </p>
                            {admission.message && (
                              <p className="text-xs text-muted-foreground">
                                {admission.message}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-4 align-top text-muted-foreground">
                          {admission.email}
                        </td>
                        <td className="px-3 py-4 align-top text-muted-foreground">
                          {admission.className}
                        </td>
                        <td className="px-3 py-4 align-top text-muted-foreground">
                          {formatDate(admission.createdAt)}
                        </td>
                        <td className="px-3 py-4 align-top">
                          <div className="space-y-2">
                            <Badge
                              variant={
                                admission.status === "APPROVED"
                                  ? "secondary"
                                  : admission.status === "REJECTED"
                                    ? "destructive"
                                    : "outline"
                              }
                            >
                              {formatAdmissionStatus(admission.status)}
                            </Badge>
                            <select
                              className="h-9 w-full rounded-none border border-input bg-background px-2.5 py-1 text-xs"
                              value={admission.status}
                              disabled={submitting}
                              onChange={(event) =>
                                void updateAdmissionStatus(
                                  admission.id,
                                  admission.name,
                                  event.target
                                    .value as AdmissionRecord["status"],
                                )
                              }
                              aria-label={`Change status for ${admission.name}`}
                            >
                              {admissionStatusOptions.map((status) => (
                                <option key={status} value={status}>
                                  {formatAdmissionStatus(status)}
                                </option>
                              ))}
                            </select>
                          </div>
                        </td>
                        <td className="px-3 py-4 align-top">
                          <div className="flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedAdmission(admission)}
                              type="button"
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              type="button"
                              onClick={() =>
                                void deleteAdmission(
                                  admission.id,
                                  admission.name,
                                )
                              }
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">
                No applications found.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Sheet
        open={!!selectedAdmission}
        onOpenChange={(open) => {
          if (!open) closeDetails();
        }}
      >
        <SheetContent className="overflow-y-auto sm:max-w-2xl">
          {selectedAdmission && draftAdmission ? (
            <form className="space-y-6 p-2 pt-8" onSubmit={saveAdmission}>
              <SheetHeader className="px-2">
                <SheetTitle>Edit admission</SheetTitle>
                <SheetDescription>
                  Update the submitted form fields and review status for{" "}
                  {selectedAdmission.name}.
                </SheetDescription>
              </SheetHeader>

              <section className="space-y-4 rounded-none border border-border bg-background/70 p-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="admission-status">Status</Label>
                    <select
                      id="admission-status"
                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={draftAdmission.status}
                      disabled={submitting}
                      onChange={(event) => {
                        const nextStatus = event.target
                          .value as AdmissionDraft["status"];
                        const nextDraft = {
                          ...draftAdmission,
                          status: nextStatus,
                        };
                        setDraftAdmission(nextDraft);
                        void persistAdmission(nextDraft);
                      }}
                    >
                      {admissionStatusOptions.map((status) => (
                        <option key={status} value={status}>
                          {status[0] + status.slice(1).toLowerCase()}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-name">Name</Label>
                    <Input
                      id="admission-name"
                      value={draftAdmission.name}
                      onChange={(event) =>
                        updateDraft("name", event.target.value)
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-email">Email</Label>
                    <Input
                      id="admission-email"
                      type="email"
                      value={draftAdmission.email}
                      onChange={(event) =>
                        updateDraft("email", event.target.value)
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-phone">Phone</Label>
                    <Input
                      id="admission-phone"
                      value={draftAdmission.phone}
                      onChange={(event) =>
                        updateDraft("phone", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-class">Requested class</Label>
                    <Input
                      id="admission-class"
                      value={draftAdmission.className}
                      onChange={(event) =>
                        updateDraft("className", event.target.value)
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="admission-message">Message</Label>
                    <Textarea
                      id="admission-message"
                      value={draftAdmission.message}
                      onChange={(event) =>
                        updateDraft("message", event.target.value)
                      }
                      rows={3}
                    />
                  </div>
                </div>
              </section>

              <section className="space-y-4 rounded-none border border-border bg-background/70 p-4">
                <h3 className="text-sm font-semibold">Family details</h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="admission-gender">Gender</Label>
                    <select
                      id="admission-gender"
                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={draftAdmission.details.gender}
                      onChange={(event) =>
                        updateDraftDetails(
                          "gender",
                          event.target.value as AdmissionDetailsDraft["gender"],
                        )
                      }
                    >
                      <option value="">Not provided</option>
                      <option value="MALE">Male</option>
                      <option value="FEMALE">Female</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-guardian-name">
                      Guardian name
                    </Label>
                    <Input
                      id="admission-guardian-name"
                      value={draftAdmission.details.guardianName}
                      onChange={(event) =>
                        updateDraftDetails("guardianName", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-guardian-relation">
                      Guardian relation
                    </Label>
                    <Input
                      id="admission-guardian-relation"
                      value={draftAdmission.details.guardianRelation}
                      onChange={(event) =>
                        updateDraftDetails(
                          "guardianRelation",
                          event.target.value,
                        )
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-guardian-email">
                      Guardian email
                    </Label>
                    <Input
                      id="admission-guardian-email"
                      type="email"
                      value={draftAdmission.details.guardianEmail}
                      onChange={(event) =>
                        updateDraftDetails("guardianEmail", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-guardian-phone">
                      Guardian phone
                    </Label>
                    <Input
                      id="admission-guardian-phone"
                      value={draftAdmission.details.guardianPhone}
                      onChange={(event) =>
                        updateDraftDetails("guardianPhone", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="admission-guardian-address">
                      Guardian address
                    </Label>
                    <Textarea
                      id="admission-guardian-address"
                      value={draftAdmission.details.guardianAddress}
                      onChange={(event) =>
                        updateDraftDetails(
                          "guardianAddress",
                          event.target.value,
                        )
                      }
                      rows={2}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-father-name">Father name</Label>
                    <Input
                      id="admission-father-name"
                      value={draftAdmission.details.fatherName}
                      onChange={(event) =>
                        updateDraftDetails("fatherName", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-father-phone">Father phone</Label>
                    <Input
                      id="admission-father-phone"
                      value={draftAdmission.details.fatherPhone}
                      onChange={(event) =>
                        updateDraftDetails("fatherPhone", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-mother-name">Mother name</Label>
                    <Input
                      id="admission-mother-name"
                      value={draftAdmission.details.motherName}
                      onChange={(event) =>
                        updateDraftDetails("motherName", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-mother-phone">Mother phone</Label>
                    <Input
                      id="admission-mother-phone"
                      value={draftAdmission.details.motherPhone}
                      onChange={(event) =>
                        updateDraftDetails("motherPhone", event.target.value)
                      }
                    />
                  </div>
                </div>
              </section>

              <section className="space-y-4 rounded-none border border-border bg-background/70 p-4">
                <h3 className="text-sm font-semibold">Identity documents</h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="admission-nid-number">
                      Student NID number
                    </Label>
                    <Input
                      id="admission-nid-number"
                      value={draftAdmission.details.nidNumber}
                      onChange={(event) =>
                        updateDraftDetails("nidNumber", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-profile-image">
                      Profile image URL
                    </Label>
                    <Input
                      id="admission-profile-image"
                      value={draftAdmission.details.profileImage}
                      onChange={(event) =>
                        updateDraftDetails("profileImage", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-nid-image">
                      Student NID image URL
                    </Label>
                    <Input
                      id="admission-nid-image"
                      value={draftAdmission.details.nidImage}
                      onChange={(event) =>
                        updateDraftDetails("nidImage", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-father-nid-number">
                      Father NID number
                    </Label>
                    <Input
                      id="admission-father-nid-number"
                      value={draftAdmission.details.fatherNidNumber}
                      onChange={(event) =>
                        updateDraftDetails(
                          "fatherNidNumber",
                          event.target.value,
                        )
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-father-nid-image">
                      Father NID image URL
                    </Label>
                    <Input
                      id="admission-father-nid-image"
                      value={draftAdmission.details.fatherNidImage}
                      onChange={(event) =>
                        updateDraftDetails("fatherNidImage", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-mother-nid-number">
                      Mother NID number
                    </Label>
                    <Input
                      id="admission-mother-nid-number"
                      value={draftAdmission.details.motherNidNumber}
                      onChange={(event) =>
                        updateDraftDetails(
                          "motherNidNumber",
                          event.target.value,
                        )
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admission-mother-nid-image">
                      Mother NID image URL
                    </Label>
                    <Input
                      id="admission-mother-nid-image"
                      value={draftAdmission.details.motherNidImage}
                      onChange={(event) =>
                        updateDraftDetails("motherNidImage", event.target.value)
                      }
                    />
                  </div>
                </div>
              </section>

              <section className="space-y-3 rounded-none border border-border bg-background/70 p-4">
                <h3 className="text-sm font-semibold">Current attachments</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                      Student profile image
                    </p>
                    {imagePreview(
                      selectedAdmission.details?.profileImage ?? null,
                    ) ?? (
                      <p className="text-sm text-muted-foreground">
                        Not provided
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                      Student NID image
                    </p>
                    {imagePreview(
                      selectedAdmission.details?.nidImage ?? null,
                    ) ?? (
                      <p className="text-sm text-muted-foreground">
                        Not provided
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                      Father NID image
                    </p>
                    {imagePreview(
                      selectedAdmission.details?.fatherNidImage ?? null,
                    ) ?? (
                      <p className="text-sm text-muted-foreground">
                        Not provided
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                      Mother NID image
                    </p>
                    {imagePreview(
                      selectedAdmission.details?.motherNidImage ?? null,
                    ) ?? (
                      <p className="text-sm text-muted-foreground">
                        Not provided
                      </p>
                    )}
                  </div>
                </div>
              </section>

              <div className="flex flex-wrap gap-2 px-2">
                <Button type="submit" disabled={submitting}>
                  {submitting ? "Saving…" : "Save changes"}
                </Button>
                <Button type="button" variant="outline" onClick={closeDetails}>
                  Close
                </Button>
              </div>
            </form>
          ) : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}
