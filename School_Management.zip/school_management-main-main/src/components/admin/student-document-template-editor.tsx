"use client"

import { useCallback, useEffect, useMemo, useState } from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { fetchWithAuth } from "@/lib/client-api"
import {
  DEFAULT_STUDENT_DOCUMENT_TEMPLATE,
  type StudentDocumentTemplateConfig,
} from "@/lib/student-document-template"

type TemplateResponse = {
  template: StudentDocumentTemplateConfig
}

const colorFields: Array<keyof Pick<
  StudentDocumentTemplateConfig,
  | "primaryColor"
  | "secondaryColor"
  | "accentColor"
  | "backgroundColor"
  | "surfaceColor"
  | "borderColor"
>> = [
  "primaryColor",
  "secondaryColor",
  "accentColor",
  "backgroundColor",
  "surfaceColor",
  "borderColor",
]

export function StudentDocumentTemplateEditor() {
  const [template, setTemplate] = useState<StudentDocumentTemplateConfig>(DEFAULT_STUDENT_DOCUMENT_TEMPLATE)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  const loadTemplate = useCallback(async () => {
    setLoading(true)
    setError(null)

    try {
      const payload = await fetchWithAuth<TemplateResponse>("/api/v1/student-document-template")
      setTemplate(payload.template ?? DEFAULT_STUDENT_DOCUMENT_TEMPLATE)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to load document template")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void loadTemplate()
  }, [loadTemplate])

  const previewSummary = useMemo(
    () => [
      template.schoolName,
      template.headerTitle,
      template.headerSubtitle,
      template.watermarkText,
    ],
    [template],
  )

  const updateField = <K extends keyof StudentDocumentTemplateConfig>(field: K, value: StudentDocumentTemplateConfig[K]) => {
    setTemplate((prev) => ({ ...prev, [field]: value }))
  }

  const saveTemplate = async () => {
    setSaving(true)
    setError(null)
    setMessage(null)

    try {
      const payload = await fetchWithAuth<TemplateResponse>("/api/v1/student-document-template", {
        method: "PATCH",
        body: JSON.stringify(template),
      })
      setTemplate(payload.template)
      setMessage("Document design saved")
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to save document template")
    } finally {
      setSaving(false)
    }
  }

  const resetTemplate = () => {
    setTemplate(DEFAULT_STUDENT_DOCUMENT_TEMPLATE)
    setMessage("Demo design restored locally. Save it to persist in the database.")
  }

  return (
    <Card className="overflow-hidden rounded-3xl border-border/70 shadow-sm">
      <CardHeader className="border-b border-border/60 bg-muted/20">
        <CardDescription>Design studio</CardDescription>
        <CardTitle>Certificate template</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-5">
        {loading ? <p className="text-sm text-muted-foreground">Loading template…</p> : null}
        {error ? <div className="rounded-2xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">{error}</div> : null}
        {message ? <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 px-4 py-3 text-sm text-emerald-700">{message}</div> : null}

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="doc-school-name">School name</Label>
            <Input id="doc-school-name" value={template.schoolName} onChange={(event) => updateField("schoolName", event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-header-title">Header title</Label>
            <Input id="doc-header-title" value={template.headerTitle} onChange={(event) => updateField("headerTitle", event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-header-subtitle">Header subtitle</Label>
            <Input id="doc-header-subtitle" value={template.headerSubtitle} onChange={(event) => updateField("headerSubtitle", event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-watermark">Watermark text</Label>
            <Input id="doc-watermark" value={template.watermarkText} onChange={(event) => updateField("watermarkText", event.target.value)} />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="doc-note">Document note</Label>
            <Textarea id="doc-note" rows={3} value={template.noteText} onChange={(event) => updateField("noteText", event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-footer-left">Left footer text</Label>
            <Input id="doc-footer-left" value={template.footerLeftText} onChange={(event) => updateField("footerLeftText", event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-footer-right">Right footer text</Label>
            <Input id="doc-footer-right" value={template.footerRightText} onChange={(event) => updateField("footerRightText", event.target.value)} />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          {colorFields.map((field) => (
            <div key={field} className="space-y-2">
              <Label htmlFor={`doc-${field}`}>{field}</Label>
              <Input
                id={`doc-${field}`}
                type="color"
                value={template[field]}
                onChange={(event) => updateField(field, event.target.value)}
                className="h-11 w-full rounded-2xl p-1"
              />
            </div>
          ))}
        </div>

        <div className="rounded-3xl border border-border bg-background/70 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">Live preview</p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {previewSummary.map((item) => (
              <div key={item} className="rounded-2xl border border-border/70 bg-muted/30 px-4 py-3 text-sm font-medium text-foreground">
                {item}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button type="button" className="rounded-2xl" onClick={saveTemplate} disabled={saving}>
            {saving ? "Saving…" : "Save design"}
          </Button>
          <Button type="button" variant="outline" className="rounded-2xl" onClick={resetTemplate} disabled={saving}>
            Restore demo
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
