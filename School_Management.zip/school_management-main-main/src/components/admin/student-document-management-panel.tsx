"use client"

import { useCallback, useEffect, useState } from "react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { downloadWithAuth } from "@/lib/client-api"
import { StudentDocumentTemplateEditor } from "@/components/admin/student-document-template-editor"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type ClassOption = { id: string; name: string }
type StudentCardRecord = {
  id: string
  rollNumber: number | null
  phone: string | null
  gender: "MALE" | "FEMALE" | "OTHER"
  isDeleted: boolean
  createdAt: string
  class: { id: string; name: string }
  group: { id: string; name: string } | null
  section: { id: string; name: string } | null
  user: { id: string; name: string; email: string }
}
type StudentResponse = {
  students: StudentCardRecord[]
  classes: ClassOption[]
  stats: { total: number; active: number; deleted: number }
}

const documentTypes = [
  { type: "testimonial", label: "Testimonial PDF" },
  { type: "tc", label: "Transfer Certificate PDF" },
  { type: "character", label: "Character Certificate PDF" },
] as const

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
  }).format(new Date(value))
}

function buildFilename(studentName: string, type: string) {
  const slug = studentName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40)

  return `${type}-${slug || "student"}.pdf`
}

export function StudentDocumentManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [students, setStudents] = useState<StudentCardRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [stats, setStats] = useState({ total: 0, active: 0, deleted: 0 })
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("ALL")
  const [loading, setLoading] = useState(true)
  const [submittingId, setSubmittingId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setAuthState(readAuth())
  }, [])

  const loadStudents = useCallback(
    async (nextAuth: AuthStorage, currentSearch = search, currentClass = classFilter) => {
      setLoading(true)
      setError(null)

      try {
        const params = new URLSearchParams()
        if (currentSearch.trim()) params.set("search", currentSearch.trim())
        if (currentClass !== "ALL") params.set("classId", currentClass)

        const response = await fetch(`/api/v1/students?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        })
        const json = await response.json()
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load students")
        }

        const data = json.data as StudentResponse
        setStudents(data.students)
        setClasses(data.classes)
        setStats(data.stats)
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load students")
      } finally {
        setLoading(false)
      }
    },
    [classFilter, search],
  )

  useEffect(() => {
    if (authState) {
      void loadStudents(authState)
    }
  }, [authState, loadStudents])

  const refresh = useCallback(async () => {
    if (authState) {
      await loadStudents(authState)
    }
  }, [authState, loadStudents])

  const generateDocument = useCallback(
    async (student: StudentCardRecord, type: string) => {
      if (!authState) return

      setSubmittingId(`${student.id}:${type}`)
      setError(null)

      try {
        await downloadWithAuth(
          `/api/v1/students/${student.id}/documents?type=${type}`,
          buildFilename(student.user.name, type),
        )
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to generate document")
      } finally {
        setSubmittingId(null)
      }
    },
    [authState],
  )

  return (
    <div className="space-y-6">
      <StudentDocumentTemplateEditor />

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Total students</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Active students</CardDescription>
            <CardTitle>{stats.active}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Document types</CardDescription>
            <CardTitle>{documentTypes.length}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Search students</CardTitle>
            <CardDescription>Pick a student and issue a document immediately.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-3 md:grid-cols-[1fr_180px_auto]"
              onSubmit={(event) => {
                event.preventDefault()
                void refresh()
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by name, email, or phone"
              />
              <select
                className="h-10 rounded-2xl border border-input bg-background/90 px-3 text-sm outline-none transition focus:border-primary"
                value={classFilter}
                onChange={(event) => setClassFilter(event.target.value)}
              >
                <option value="ALL">All classes</option>
                {classes.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <Button type="submit" variant="outline" className="rounded-2xl">
                Filter
              </Button>
            </form>

            {error ? (
              <div className="rounded-2xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
                {error}
              </div>
            ) : null}

            {loading ? (
              <p className="text-sm text-muted-foreground">Loading students…</p>
            ) : students.length === 0 ? (
              <div className="rounded-3xl border border-dashed border-border bg-muted/20 p-10 text-center">
                <p className="text-base font-medium">No students found</p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Adjust the search or class filter to locate the student record.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {students.map((student) => (
                  <article
                    key={student.id}
                    className="rounded-3xl border border-border bg-background/80 p-5 shadow-sm"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge variant={student.isDeleted ? "destructive" : "secondary"}>
                            {student.isDeleted ? "Deactivated" : "Active"}
                          </Badge>
                          <Badge variant="outline">{student.class.name}</Badge>
                        </div>
                        <h3 className="text-lg font-semibold text-foreground">
                          {student.user.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {student.user.email}
                        </p>
                        <div className="grid gap-1 text-sm text-muted-foreground sm:grid-cols-2">
                          <span>Roll: {student.rollNumber ?? "Auto"}</span>
                          <span>Gender: {student.gender}</span>
                          <span>Group: {student.group?.name ?? "General"}</span>
                          <span>Section: {student.section?.name ?? "Default"}</span>
                          <span>Phone: {student.phone ?? "N/A"}</span>
                          <span>Admission: {formatDate(student.createdAt)}</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {documentTypes.map((item) => (
                          <Button
                            key={item.type}
                            type="button"
                            variant={item.type === "tc" ? "default" : "outline"}
                            className="rounded-full"
                            disabled={submittingId === `${student.id}:${item.type}`}
                            onClick={() => void generateDocument(student, item.type)}
                          >
                            {submittingId === `${student.id}:${item.type}`
                              ? "Preparing…"
                              : item.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
