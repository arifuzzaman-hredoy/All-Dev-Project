"use client"

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type ClassOption = { id: string; name: string }
type StudentOption = { id: string; name: string; classId: string; className: string }
type SubjectOption = { id: string; name: string; classId: string; className: string }
type AttendanceRecord = {
  id: string
  date: string
  status: "PRESENT" | "ABSENT" | "LATE"
  student: { user: { name: string }; class: { name: string }; rollNumber: number | null }
  subject: { name: string }
}
type AttendanceResponse = {
  records: AttendanceRecord[]
  classes: ClassOption[]
  students: StudentOption[]
  subjects: SubjectOption[]
  stats: { total: number; present: number; absent: number; late: number }
}

export function AttendanceManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [records, setRecords] = useState<AttendanceRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [students, setStudents] = useState<StudentOption[]>([])
  const [subjects, setSubjects] = useState<SubjectOption[]>([])
  const [stats, setStats] = useState({ total: 0, present: 0, absent: 0, late: 0 })
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("ALL")
  const [dateFilter, setDateFilter] = useState("")
  const [subjectFilter] = useState("ALL")
  const [markingForm, setMarkingForm] = useState({ date: "", classId: "", subjectId: "" })
  const [statusMap, setStatusMap] = useState<Record<string, "PRESENT" | "ABSENT" | "LATE">>({})
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => setAuthState(readAuth()), [])

  const loadAttendance = useCallback(async (nextAuth: AuthStorage, currentClass = classFilter, currentDate = dateFilter, currentSubject = subjectFilter, currentSearch = search) => {
    setLoading(true); setError(null)
    try {
      const params = new URLSearchParams()
      if (currentClass !== "ALL") params.set("classId", currentClass)
      if (currentDate) params.set("date", currentDate)
      if (currentSubject !== "ALL") params.set("subjectId", currentSubject)
      if (currentSearch.trim()) params.set("search", currentSearch.trim())
      const response = await fetch(`/api/v1/attendance?${params.toString()}`, { headers: { Authorization: `Bearer ${nextAuth.token}` } })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to load attendance")
      const data = json.data as AttendanceResponse
      setRecords(data.records); setClasses(data.classes); setStudents(data.students); setSubjects(data.subjects); setStats(data.stats)
      setMarkingForm((prev) => ({ ...prev, classId: prev.classId || data.classes[0]?.id || "", subjectId: prev.subjectId || data.subjects[0]?.id || "", date: prev.date || new Date().toISOString().split("T")[0] || "" }))
      setStatusMap((prev) => {
        if (Object.keys(prev).length > 0) return prev
        return data.students.reduce<Record<string, "PRESENT" | "ABSENT" | "LATE">>((acc, student) => {
          acc[student.id] = "PRESENT"
          return acc
        }, {})
      })
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to load attendance") } finally { setLoading(false) }
  }, [classFilter, dateFilter, search, subjectFilter])

  useEffect(() => { if (authState) void loadAttendance(authState) }, [authState, loadAttendance])
  const refresh = async () => { if (authState) await loadAttendance(authState) }

  const eligibleStudents = useMemo(() => {
    return students.filter((student) => !markingForm.classId || student.classId === markingForm.classId)
  }, [students, markingForm.classId])

  const availableSubjects = useMemo(() => {
    return subjects.filter((subject) => !markingForm.classId || subject.classId === markingForm.classId)
  }, [subjects, markingForm.classId])

  useEffect(() => {
    if (!availableSubjects.length) return
    if (!availableSubjects.some((subject) => subject.id === markingForm.subjectId)) {
      setMarkingForm((prev) => ({ ...prev, subjectId: availableSubjects[0].id }))
    }
  }, [availableSubjects, markingForm.subjectId])

  const submitAttendance = async (event: FormEvent) => {
    event.preventDefault(); if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const entries = eligibleStudents.map((student) => ({
        studentId: student.id,
        status: statusMap[student.id] ?? "PRESENT",
      }))
      const response = await fetch("/api/v1/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${authState.token}` },
        body: JSON.stringify({
          date: markingForm.date,
          classId: markingForm.classId,
          subjectId: markingForm.subjectId,
          entries,
        }),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to save attendance")
      await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to save attendance") } finally { setSubmitting(false) }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40"><p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Engagement</p><h1 className="text-2xl font-semibold">Attendance management</h1></section>
      <div className="grid gap-4 sm:grid-cols-4"><Card><CardHeader><CardDescription>Total</CardDescription><CardTitle>{stats.total}</CardTitle></CardHeader></Card><Card><CardHeader><CardDescription>Present</CardDescription><CardTitle>{stats.present}</CardTitle></CardHeader></Card><Card><CardHeader><CardDescription>Absent</CardDescription><CardTitle>{stats.absent}</CardTitle></CardHeader></Card><Card><CardHeader><CardDescription>Late</CardDescription><CardTitle>{stats.late}</CardTitle></CardHeader></Card></div>
      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit"><CardHeader><CardTitle>Mark attendance</CardTitle></CardHeader><CardContent><form className="space-y-4" onSubmit={submitAttendance}><div className="space-y-2"><Label htmlFor="attendance-date-admin">Date</Label><Input id="attendance-date-admin" type="date" value={markingForm.date} onChange={(event) => setMarkingForm((prev) => ({ ...prev, date: event.target.value }))} required /></div><div className="space-y-2"><Label htmlFor="attendance-class-admin">Class</Label><select id="attendance-class-admin" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={markingForm.classId} onChange={(event) => setMarkingForm((prev) => ({ ...prev, classId: event.target.value }))}>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><div className="space-y-2"><Label htmlFor="attendance-subject-admin">Subject</Label><select id="attendance-subject-admin" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={markingForm.subjectId} onChange={(event) => setMarkingForm((prev) => ({ ...prev, subjectId: event.target.value }))}>{availableSubjects.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.className}</option>)}</select></div><div className="space-y-3">{eligibleStudents.map((student) => <div key={student.id} className="rounded-none border border-border bg-background/60 p-3"><p className="text-xs font-semibold text-foreground">{student.name}</p><p className="text-xs text-muted-foreground">{student.className}</p><div className="mt-2 flex gap-2">{(["PRESENT", "ABSENT", "LATE"] as const).map((status) => <Button key={status} size="sm" type="button" variant={(statusMap[student.id] ?? "PRESENT") === status ? "default" : "outline"} onClick={() => setStatusMap((prev) => ({ ...prev, [student.id]: status }))}>{status}</Button>)}</div></div>)}</div><Button type="submit" disabled={submitting || !eligibleStudents.length || !availableSubjects.length}>{submitting ? "Saving…" : "Save attendance"}</Button></form></CardContent></Card>
        <Card><CardHeader><CardTitle>Attendance ledger</CardTitle><CardDescription>Review and filter submitted records.</CardDescription></CardHeader><CardContent className="space-y-4"><form className="grid gap-2 md:grid-cols-[1fr_160px_160px_auto]" onSubmit={(event) => { event.preventDefault(); void refresh() }}><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search student" /><select className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={classFilter} onChange={(event) => setClassFilter(event.target.value)}><option value="ALL">All classes</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><Input type="date" value={dateFilter} onChange={(event) => setDateFilter(event.target.value)} /><Button type="submit" variant="outline">Filter</Button></form>{error && <div className="text-xs text-destructive">{error}</div>}{loading ? <p className="text-xs text-muted-foreground">Loading attendance…</p> : <div className="space-y-3">{records.map((item) => <article key={item.id} className="rounded-none border border-border bg-background/60 p-4"><div className="flex flex-wrap items-center gap-2"><Badge variant={item.status === "PRESENT" ? "secondary" : item.status === "ABSENT" ? "destructive" : "outline"}>{item.status}</Badge><Badge variant="outline">{item.subject.name}</Badge></div><h3 className="mt-2 text-sm font-semibold text-foreground">{item.student.user.name}</h3><p className="text-xs text-muted-foreground">{item.student.class.name} · Roll {item.student.rollNumber ?? "N/A"} · {new Date(item.date).toLocaleDateString()}</p></article>)}</div>}</CardContent></Card>
      </div>
    </div>
  )
}
