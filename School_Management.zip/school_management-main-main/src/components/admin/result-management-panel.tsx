"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type StudentOption = { id: string; name: string; className: string }
type ExamOption = { id: string; name: string; className: string }
type SubjectOption = { id: string; name: string; className: string }
type ResultRecord = {
  id: string
  marks: number
  totalMarks: number
  grade: string | null
  student: { user: { name: string }; class: { name: string }; rollNumber: number | null }
  exam: { id: string; name: string; date: string }
  subject: { id: string; name: string }
}
type ResultResponse = {
  results: ResultRecord[]
  students: StudentOption[]
  exams: ExamOption[]
  subjects: SubjectOption[]
  stats: { total: number; averageMarks: number }
}

export function ResultManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [results, setResults] = useState<ResultRecord[]>([])
  const [students, setStudents] = useState<StudentOption[]>([])
  const [exams, setExams] = useState<ExamOption[]>([])
  const [subjects, setSubjects] = useState<SubjectOption[]>([])
  const [stats, setStats] = useState({ total: 0, averageMarks: 0 })
  const [search, setSearch] = useState("")
  const [examFilter, setExamFilter] = useState("ALL")
  const [form, setForm] = useState({ studentId: "", examId: "", subjectId: "", marks: "", grade: "" })
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingForm, setEditingForm] = useState({ marks: "", grade: "" })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => setAuthState(readAuth()), [])

  const loadResults = useCallback(async (nextAuth: AuthStorage, currentSearch = search, currentExam = examFilter) => {
    setLoading(true); setError(null)
    try {
      const params = new URLSearchParams()
      if (currentSearch.trim()) params.set("search", currentSearch.trim())
      if (currentExam !== "ALL") params.set("examId", currentExam)
      const response = await fetch(`/api/v1/results?${params.toString()}`, { headers: { Authorization: `Bearer ${nextAuth.token}` } })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to load results")
      const data = json.data as ResultResponse
      setResults(data.results); setStudents(data.students); setExams(data.exams); setSubjects(data.subjects); setStats(data.stats)
      setForm((prev) => ({
        ...prev,
        studentId: prev.studentId || data.students[0]?.id || "",
        examId: prev.examId || data.exams[0]?.id || "",
        subjectId: prev.subjectId || data.subjects[0]?.id || "",
      }))
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to load results") } finally { setLoading(false) }
  }, [examFilter, search])

  useEffect(() => { if (authState) void loadResults(authState) }, [authState, loadResults])
  const refresh = async () => { if (authState) await loadResults(authState) }

  const createResult = async (event: FormEvent) => {
    event.preventDefault(); if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const response = await fetch("/api/v1/results", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${authState.token}` }, body: JSON.stringify({ ...form, marks: Number(form.marks), grade: form.grade || undefined }) })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to create result")
      setForm((prev) => ({ ...prev, marks: "", grade: "" })); await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to create result") } finally { setSubmitting(false) }
  }

  const saveResult = async (id: string) => {
    if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const response = await fetch(`/api/v1/results/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: `Bearer ${authState.token}` }, body: JSON.stringify({ marks: Number(editingForm.marks), grade: editingForm.grade || null }) })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to update result")
      setEditingId(null); await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to update result") } finally { setSubmitting(false) }
  }

  const deleteResult = async (id: string) => {
    if (!authState) return
    setSubmitting(true); setError(null)
    try {
      const response = await fetch(`/api/v1/results/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${authState.token}` } })
      const json = await response.json()
      if (!response.ok) throw new Error(json.message ?? "Unable to delete result")
      await refresh()
    } catch (exception) { setError(exception instanceof Error ? exception.message : "Unable to delete result") } finally { setSubmitting(false) }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40"><p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Academic</p><h1 className="text-2xl font-semibold">Result management</h1></section>
      <div className="grid gap-4 sm:grid-cols-2"><Card><CardHeader><CardDescription>Results</CardDescription><CardTitle>{stats.total}</CardTitle></CardHeader></Card><Card><CardHeader><CardDescription>Average marks</CardDescription><CardTitle>{stats.averageMarks}</CardTitle></CardHeader></Card></div>
      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit"><CardHeader><CardTitle>Create result</CardTitle></CardHeader><CardContent><form className="space-y-4" onSubmit={createResult}><div className="space-y-2"><Label htmlFor="result-student">Student</Label><select id="result-student" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={form.studentId} onChange={(event) => setForm((prev) => ({ ...prev, studentId: event.target.value }))}>{students.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.className}</option>)}</select></div><div className="space-y-2"><Label htmlFor="result-exam">Exam</Label><select id="result-exam" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={form.examId} onChange={(event) => setForm((prev) => ({ ...prev, examId: event.target.value }))}>{exams.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.className}</option>)}</select></div><div className="space-y-2"><Label htmlFor="result-subject">Subject</Label><select id="result-subject" className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={form.subjectId} onChange={(event) => setForm((prev) => ({ ...prev, subjectId: event.target.value }))}>{subjects.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.className}</option>)}</select></div><div className="space-y-2"><Label htmlFor="result-marks">Obtained marks</Label><Input id="result-marks" type="number" min="0" max="1000" value={form.marks} onChange={(event) => setForm((prev) => ({ ...prev, marks: event.target.value }))} required /></div><div className="space-y-2"><Label htmlFor="result-grade">Grade</Label><Input id="result-grade" value={form.grade} onChange={(event) => setForm((prev) => ({ ...prev, grade: event.target.value }))} /></div><Button type="submit" disabled={submitting}>{submitting ? "Saving…" : "Create result"}</Button></form></CardContent></Card>
        <Card><CardHeader><CardTitle>Result sheet</CardTitle><CardDescription>Approved and draft marks from live data.</CardDescription></CardHeader><CardContent className="space-y-4"><form className="grid gap-2 md:grid-cols-[1fr_180px_auto]" onSubmit={(event) => { event.preventDefault(); void refresh() }}><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search results" /><select className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs" value={examFilter} onChange={(event) => setExamFilter(event.target.value)}><option value="ALL">All exams</option>{exams.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><Button type="submit" variant="outline">Filter</Button></form>{error && <div className="text-xs text-destructive">{error}</div>}{loading ? <p className="text-xs text-muted-foreground">Loading results…</p> : <div className="space-y-3">{results.map((item) => <article key={item.id} className="rounded-none border border-border bg-background/60 p-4">{editingId === item.id ? <div className="grid gap-2 md:grid-cols-2"><Input type="number" min="0" max={item.totalMarks} value={editingForm.marks} onChange={(event) => setEditingForm((prev) => ({ ...prev, marks: event.target.value }))} /><Input value={editingForm.grade} onChange={(event) => setEditingForm((prev) => ({ ...prev, grade: event.target.value }))} /></div> : <div><h3 className="text-sm font-semibold text-foreground">{item.student.user.name}</h3><p className="text-xs text-muted-foreground">{item.exam.name} · {item.subject.name} · Marks {item.marks} out of {item.totalMarks} · Grade {item.grade ?? "N/A"}</p></div>}<div className="mt-3 flex gap-2">{editingId === item.id ? <><Button size="sm" type="button" onClick={() => void saveResult(item.id)} disabled={submitting}>Save</Button><Button size="sm" variant="outline" type="button" onClick={() => setEditingId(null)}>Cancel</Button></> : <><Button size="sm" variant="outline" type="button" onClick={() => { setEditingId(item.id); setEditingForm({ marks: String(item.marks), grade: item.grade ?? "" }) }}>Edit</Button><Button size="sm" variant="destructive" type="button" onClick={() => void deleteResult(item.id)} disabled={submitting}>Delete</Button></>}</div></article>)}</div>}</CardContent></Card>
      </div>
    </div>
  )
}
