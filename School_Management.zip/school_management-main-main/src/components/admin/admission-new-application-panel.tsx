"use client";

import { useEffect, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

const initialForm = {
  name: "",
  email: "",
  phone: "",
  classId: "",
  className: "",
  message: "",
  guardianName: "",
  guardianEmail: "",
  guardianRelation: "",
  guardianPhone: "",
  guardianAddress: "",
  fatherName: "",
  fatherPhone: "",
  motherName: "",
  motherPhone: "",
};

type ClassOption = { id: string; name: string };

export function AdmissionNewApplicationPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [classes, setClasses] = useState<ClassOption[]>([]);
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const nextAuth = readAuth();
    setAuthState(nextAuth);
    if (!nextAuth) return;

    const loadClasses = async () => {
      const response = await fetch("/api/v1/classes", {
        headers: { Authorization: `Bearer ${nextAuth.token}` },
      });
      const json = await response.json();
      if (!response.ok) return;
      const nextClasses = (json.data?.classes ?? []) as ClassOption[];
      setClasses(nextClasses);
      setForm((prev) => ({
        ...prev,
        classId: prev.classId || nextClasses[0]?.id || "",
        className: prev.className || nextClasses[0]?.name || "",
      }));
    };

    void loadClasses();
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setFeedback(null);

    try {
      const selectedClass = classes.find((item) => item.id === form.classId);
      if (!authState?.user.branchId || !selectedClass) {
        throw new Error("Select a branch-scoped class first");
      }

      const response = await fetch("/api/v1/admissions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: form.name.trim(),
          branchId: authState.user.branchId,
          classId: selectedClass.id,
          email: form.email.trim(),
          phone: form.phone.trim(),
          className: selectedClass.name,
          message: form.message.trim(),
          guardianName: form.guardianName.trim(),
          guardianEmail: form.guardianEmail.trim(),
          guardianRelation: form.guardianRelation.trim(),
          guardianPhone: form.guardianPhone.trim(),
          guardianAddress: form.guardianAddress.trim(),
          fatherName: form.fatherName.trim(),
          fatherPhone: form.fatherPhone.trim(),
          motherName: form.motherName.trim(),
          motherPhone: form.motherPhone.trim(),
        }),
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to submit application");
      }

      setFeedback(
        "Admission application submitted successfully.",
      );
      setForm(initialForm);
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Unable to submit application",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader>
        <CardTitle>New application</CardTitle>
        <CardDescription>
          Add a new admission submission directly from the admin panel.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="space-y-2">
            <Label htmlFor="admission-name">Name</Label>
            <Input
              id="admission-name"
              value={form.name}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, name: event.target.value }))
              }
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admission-email">Email</Label>
            <Input
              id="admission-email"
              type="email"
              value={form.email}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, email: event.target.value }))
              }
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admission-phone">Phone</Label>
            <Input
              id="admission-phone"
              value={form.phone}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, phone: event.target.value }))
              }
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admission-class">Requested class</Label>
            <select
              id="admission-class"
              className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-sm"
              value={form.classId}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  classId: event.target.value,
                  className:
                    classes.find((item) => item.id === event.target.value)
                      ?.name ?? "",
                }))
              }
              required
            >
              {classes.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="admission-message">Message</Label>
            <Textarea
              id="admission-message"
              value={form.message}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, message: event.target.value }))
              }
            />
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="admission-guardian-name">Guardian name</Label>
              <Input
                id="admission-guardian-name"
                value={form.guardianName}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, guardianName: event.target.value }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-guardian-relation">Guardian relation</Label>
              <Input
                id="admission-guardian-relation"
                value={form.guardianRelation}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, guardianRelation: event.target.value }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-guardian-email">Guardian email</Label>
              <Input
                id="admission-guardian-email"
                type="email"
                value={form.guardianEmail}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, guardianEmail: event.target.value }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-guardian-phone">Guardian phone</Label>
              <Input
                id="admission-guardian-phone"
                value={form.guardianPhone}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, guardianPhone: event.target.value }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-guardian-address">Guardian address</Label>
              <Input
                id="admission-guardian-address"
                value={form.guardianAddress}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, guardianAddress: event.target.value }))
                }
              />
            </div>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="admission-father-name">Father name</Label>
              <Input
                id="admission-father-name"
                value={form.fatherName}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, fatherName: event.target.value }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-father-phone">Father phone</Label>
              <Input
                id="admission-father-phone"
                value={form.fatherPhone}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, fatherPhone: event.target.value }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-mother-name">Mother name</Label>
              <Input
                id="admission-mother-name"
                value={form.motherName}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, motherName: event.target.value }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admission-mother-phone">Mother phone</Label>
              <Input
                id="admission-mother-phone"
                value={form.motherPhone}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, motherPhone: event.target.value }))
                }
              />
            </div>
          </div>
          {feedback && (
            <div className="rounded-none border border-border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
              {feedback}
            </div>
          )}
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : "Submit application"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
