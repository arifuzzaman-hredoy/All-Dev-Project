"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { fetchWithAuth } from "@/lib/client-api";

type ClassOption = { id: string; name: string };

type NoticeTemplate = {
  header: string;
  footer: string;
  signature: string;
};

type NoticeRecord = {
  id: string;
  title: string;
  content: string;
  audience: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS";
  startsAt: string | null;
  endsAt: string | null;
  isActive: boolean;
  status: "DRAFT" | "PUBLISHED";
  publishedAt: string | null;
  classId: string | null;
  class: ClassOption | null;
  createdAt: string;
  updatedAt: string;
};

function toDateInput(value: string | null) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function NoticeEditorPad(props: { noticeId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [classes, setClasses] = useState<ClassOption[]>([]);
  const [template, setTemplate] = useState<NoticeTemplate>({
    header: "",
    footer: "",
    signature: "",
  });
  const [templateDraft, setTemplateDraft] = useState<NoticeTemplate>({
    header: "",
    footer: "",
    signature: "",
  });

  const [notice, setNotice] = useState<NoticeRecord | null>(null);
  const [form, setForm] = useState({
    title: "",
    content: "",
    audience: "ALL" as NoticeRecord["audience"],
    startsAt: "",
    endsAt: "",
    classId: "",
  });

  const load = useCallback(async () => {
    const [noticePayload, templatePayload, sessionsPayload] =
      await Promise.all([
        fetchWithAuth<{ notice: NoticeRecord }>(
          `/api/v1/notices/${props.noticeId}`,
        ),
        fetchWithAuth<{ template: NoticeTemplate }>(`/api/v1/notices/template`),
        fetchWithAuth<{ notices: unknown[]; classes: ClassOption[]; stats: unknown }>(
          `/api/v1/notices`,
        ),
      ]);

    setNotice(noticePayload.notice);
    setClasses(sessionsPayload.classes);

    setForm({
      title: noticePayload.notice.title,
      content: noticePayload.notice.content ?? "",
      audience: noticePayload.notice.audience,
      startsAt: toDateInput(noticePayload.notice.startsAt),
      endsAt: toDateInput(noticePayload.notice.endsAt),
      classId: noticePayload.notice.classId ?? "",
    });

    setTemplate(templatePayload.template);
    setTemplateDraft(templatePayload.template);
  }, [props.noticeId]);

  useEffect(() => {
    let active = true;

    async function bootstrap() {
      setLoading(true);
      setError("");
      try {
        await load();
      } catch (nextError) {
        if (!active) return;
        setError(nextError instanceof Error ? nextError.message : "Failed to load notice");
      } finally {
        if (active) setLoading(false);
      }
    }

    void bootstrap();
    return () => {
      active = false;
    };
  }, [load]);

  const preview = useMemo(() => {
    return {
      header: templateDraft.header,
      title: form.title.trim() || "Untitled notice",
      content: form.content,
      signature: templateDraft.signature,
      footer: templateDraft.footer,
    };
  }, [form.content, form.title, templateDraft.footer, templateDraft.header, templateDraft.signature]);

  const saveDraft = async () => {
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const payload = await fetchWithAuth<{ notice: NoticeRecord }>(
        `/api/v1/notices/${props.noticeId}`,
        {
          method: "PATCH",
          body: JSON.stringify({
            title: form.title,
            content: form.content,
            audience: form.audience,
            startsAt: form.startsAt || null,
            endsAt: form.endsAt || null,
            classId: form.classId || null,
          }),
        },
      );
      setNotice(payload.notice);
      setMessage("Draft saved");
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to save draft");
    } finally {
      setSaving(false);
    }
  };

  const publish = async () => {
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const payload = await fetchWithAuth<{ notice: NoticeRecord }>(
        `/api/v1/notices/${props.noticeId}/publish`,
        { method: "POST" },
      );
      setNotice(payload.notice);
      setMessage("Notice published");
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to publish");
    } finally {
      setSaving(false);
    }
  };

  const saveTemplate = async () => {
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const payload = await fetchWithAuth<{ template: NoticeTemplate }>(
        "/api/v1/notices/template",
        { method: "PATCH", body: JSON.stringify(templateDraft) },
      );
      setTemplate(payload.template);
      setTemplateDraft(payload.template);
      setMessage("Template updated");
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update template");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="px-6 py-6">
        <p className="text-sm text-muted-foreground">Loading notice pad…</p>
      </div>
    );
  }

  if (!notice) {
    return (
      <div className="px-6 py-6">
        <p className="text-sm text-destructive">Notice not found.</p>
        <Button className="mt-3" variant="outline" onClick={() => router.push("/admin/notices")}>
          Back
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Communications
        </p>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold">Notice pad</h1>
            <p className="mt-1 text-xs text-slate-200">
              Write, save, and publish your notice with a reusable header/footer/signature.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline">{notice.status}</Badge>
            <Button variant="outline" onClick={() => router.push("/admin/notices")}>
              Back
            </Button>
          </div>
        </div>
      </section>

      {error ? <div className="text-sm text-destructive">{error}</div> : null}
      {message ? <div className="text-sm text-emerald-600">{message}</div> : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_1.1fr]">
        <Card>
          <CardHeader>
            <CardTitle>Draft editor</CardTitle>
            <CardDescription>Save drafts frequently, then publish when ready.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="notice-title">Title</Label>
              <Input
                id="notice-title"
                value={form.title}
                onChange={(event) => setForm((prev) => ({ ...prev, title: event.target.value }))}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="notice-starts">Start date</Label>
                <Input
                  id="notice-starts"
                  type="date"
                  value={form.startsAt}
                  onChange={(event) => setForm((prev) => ({ ...prev, startsAt: event.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notice-ends">End date</Label>
                <Input
                  id="notice-ends"
                  type="date"
                  value={form.endsAt}
                  onChange={(event) => setForm((prev) => ({ ...prev, endsAt: event.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notice-audience">Audience</Label>
              <select
                id="notice-audience"
                className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={form.audience}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, audience: event.target.value as NoticeRecord["audience"] }))
                }
              >
                <option value="ALL">All</option>
                <option value="STUDENTS">Students</option>
                <option value="TEACHERS">Teachers</option>
                <option value="ADMINS">Admins</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notice-class">Class (optional)</Label>
              <select
                id="notice-class"
                className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={form.classId}
                onChange={(event) => setForm((prev) => ({ ...prev, classId: event.target.value }))}
              >
                <option value="">All classes</option>
                {classes.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notice-content">Notice content</Label>
              <Textarea
                id="notice-content"
                value={form.content}
                onChange={(event) => setForm((prev) => ({ ...prev, content: event.target.value }))}
                rows={10}
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <Button type="button" onClick={() => void saveDraft()} disabled={saving}>
                {saving ? "Saving…" : "Save draft"}
              </Button>
              <Button type="button" variant="secondary" onClick={() => void publish()} disabled={saving}>
                Publish
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Pad setup</CardTitle>
              <CardDescription>Header, footer, and signature are reused for all notices.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tpl-header">Header</Label>
                <Textarea
                  id="tpl-header"
                  value={templateDraft.header}
                  onChange={(event) => setTemplateDraft((prev) => ({ ...prev, header: event.target.value }))}
                  rows={4}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tpl-signature">Signature</Label>
                <Textarea
                  id="tpl-signature"
                  value={templateDraft.signature}
                  onChange={(event) => setTemplateDraft((prev) => ({ ...prev, signature: event.target.value }))}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tpl-footer">Footer</Label>
                <Textarea
                  id="tpl-footer"
                  value={templateDraft.footer}
                  onChange={(event) => setTemplateDraft((prev) => ({ ...prev, footer: event.target.value }))}
                  rows={4}
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="outline" onClick={() => void saveTemplate()} disabled={saving}>
                  Save template
                </Button>
                {templateDraft.header !== template.header ||
                templateDraft.footer !== template.footer ||
                templateDraft.signature !== template.signature ? (
                  <span className="text-xs text-muted-foreground">
                    Unsaved template changes
                  </span>
                ) : null}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Preview</CardTitle>
              <CardDescription>How the notice will look with header/footer/signature.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-xl border border-border bg-background p-4">
                <div className="text-xs text-muted-foreground whitespace-pre-wrap">
                  {preview.header}
                </div>
                <div className="my-4 border-t border-border" />
                <div className="text-base font-semibold">{preview.title}</div>
                <div className="mt-2 whitespace-pre-wrap text-sm">{preview.content}</div>
                <div className="my-4 border-t border-border" />
                <div className="text-xs whitespace-pre-wrap text-muted-foreground">
                  {preview.signature}
                </div>
                <div className="mt-4 border-t border-border pt-3 text-xs whitespace-pre-wrap text-muted-foreground">
                  {preview.footer}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

