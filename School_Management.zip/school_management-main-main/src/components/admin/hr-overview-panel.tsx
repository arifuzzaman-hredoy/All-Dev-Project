"use client";

import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function HrOverviewPanel() {
  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          HR
        </p>
        <h1 className="text-2xl font-semibold">Staff management</h1>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Link href="/admin/hr/departments">
          <Card className="hover:bg-muted/40">
            <CardHeader>
              <CardTitle>Departments</CardTitle>
              <CardDescription>Configure staff departments.</CardDescription>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              Create, edit, activate/deactivate
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/hr/designations">
          <Card className="hover:bg-muted/40">
            <CardHeader>
              <CardTitle>Designations</CardTitle>
              <CardDescription>Configure job titles.</CardDescription>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              Teacher/staff role labels
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/hr/leaves">
          <Card className="hover:bg-muted/40">
            <CardHeader>
              <CardTitle>Leaves</CardTitle>
              <CardDescription>Approve or reject staff leave.</CardDescription>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              Requests + status tracking
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/hr/payroll">
          <Card className="hover:bg-muted/40">
            <CardHeader>
              <CardTitle>Payroll</CardTitle>
              <CardDescription>Generate monthly salary sheets.</CardDescription>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              Runs, items, lock & pay
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}

