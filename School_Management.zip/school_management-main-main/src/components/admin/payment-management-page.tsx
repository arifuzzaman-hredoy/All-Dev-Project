"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
} from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type StudentOption = { id: string; name: string; className: string };
type FeeCategoryOption = { id: string; name: string; amount: number };

type PaymentRecord = {
  id: string;
  createdAt: string;
  amountPaid: number;
  status: "PAID" | "PARTIAL" | "DUE";
  paymentMethod: string | null;
  transactionId: string | null;
  month: number | null;
  year: number | null;
  dueDate: string | null;
  billingMonth: number;
  billingYear: number;
  billingPeriodKey: string;
  billingPeriodLabel: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  totalAmount: number;
  dueAmount: number;
  feeCategory: FeeCategoryOption;
  student: {
    id: string;
    user: { name: string; email: string };
    class: { name: string };
    rollNumber: number | null;
  };
};

type HistoryItem = {
  key: string;
  studentId: string;
  studentName: string;
  className: string;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: PaymentRecord[];
};

type PaymentResponse = {
  payments: PaymentRecord[];
  history: HistoryItem[];
  students: StudentOption[];
  feeCategories: FeeCategoryOption[];
  stats: {
    total: number;
    collectedAmount: number;
    expectedAmount: number;
    dueAmount: number;
    dueCount: number;
  };
};

const statusOptions = ["ALL", "PAID", "PARTIAL", "DUE"] as const;
type StatusFilter = (typeof statusOptions)[number];
export type PaymentScope = "monthly" | "secondary";

const currencyFormatter = new Intl.NumberFormat("en-BD", {
  maximumFractionDigits: 0,
});

const formatMoney = (value: number) => `৳${currencyFormatter.format(value)}`;

function getStatusTone(status: PaymentRecord["status"]) {
  switch (status) {
    case "PAID":
      return "secondary";
    case "PARTIAL":
      return "outline";
    default:
      return "destructive";
  }
}

function getStatusLabel(status: PaymentRecord["status"]) {
  return status.charAt(0) + status.slice(1).toLowerCase();
}

function formatBillingMonth(month: number, year: number) {
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    year: "numeric",
  }).format(new Date(year, month - 1, 1));
}

function getScopeConfig(scope: PaymentScope) {
  if (scope === "monthly") {
    return {
      title: "Monthly payments",
      description:
        "Record monthly fee collection, inspect how each payment reduces the monthly balance first, and review open billing periods.",
      ledgerTitle: "Monthly dues ledger",
      ledgerDescription:
        "Track monthly balances, collected amounts, and the periods that still need payment.",
      scopeDueLabel: "Monthly due",
      scopeBalanceLabel: "Monthly due balance",
      scopeFocusText: "Monthly fee focus",
      scopeHeaderText: "Monthly payment capture",
      scopeNote:
        "Monthly dues are prioritized before secondary charges in the shared ledger.",
    };
  }

  return {
    title: "Secondary payments",
    description:
      "Record category-fee collection, inspect the extra charges that remain open, and keep secondary balances visible.",
    ledgerTitle: "Secondary dues ledger",
    ledgerDescription:
      "Track category fees, collected amounts, and the periods that still carry extra charges.",
    scopeDueLabel: "Secondary due",
    scopeBalanceLabel: "Secondary due balance",
    scopeFocusText: "Secondary fee focus",
    scopeHeaderText: "Secondary payment capture",
    scopeNote:
      "Secondary charges sit after monthly dues in the shared payment history.",
  };
}

export function PaymentManagementPage({
  scope = "monthly",
}: {
  scope?: PaymentScope;
}) {
  const scopeConfig = getScopeConfig(scope);
  const isMonthlyScope = scope === "monthly";
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [students, setStudents] = useState<StudentOption[]>([]);
  const [feeCategories, setFeeCategories] = useState<FeeCategoryOption[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("ALL");
  const today = new Date();
  const [form, setForm] = useState({
    studentId: "",
    feeCategoryId: "",
    amountPaid: "",
    status: "PAID",
    paymentMethod: "",
    transactionId: "",
    month: String(today.getMonth() + 1),
    year: String(today.getFullYear()),
    dueDate: "",
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [receiptLoadingId, setReceiptLoadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setAuthState(readAuth());
  }, []);

  const selectedStudent = useMemo(
    () => students.find((item) => item.id === form.studentId) ?? null,
    [students, form.studentId],
  );

  const selectedCategory = useMemo(
    () => feeCategories.find((item) => item.id === form.feeCategoryId) ?? null,
    [feeCategories, form.feeCategoryId],
  );

  const visibleHistory = useMemo(
    () =>
      history.filter((item) =>
        scope === "monthly"
          ? item.monthlyFeeBase > 0 || item.monthlyFeeDue > 0
          : item.extraCategoryFees > 0 || item.extraCategoryDue > 0,
      ),
    [history, scope],
  );

  const scopeSummary = useMemo(
    () =>
      visibleHistory.reduce(
        (acc, item) => {
          acc.monthlyDue += item.monthlyFeeDue;
          acc.extraDue += item.extraCategoryDue;
          acc.expected += item.totalExpected;
          acc.paid += item.amountPaid;
          acc.due += item.dueAmount;
          return acc;
        },
        { monthlyDue: 0, extraDue: 0, expected: 0, paid: 0, due: 0 },
      ),
    [visibleHistory],
  );

  const availableFeeCategories = useMemo(() => {
    if (!form.studentId) {
      return feeCategories;
    }

    const selectedMonth = Number(form.month);
    const selectedYear = Number(form.year);
    const settledCategoryIds = new Set(
      payments
        .filter(
          (item) =>
            item.student.id === form.studentId &&
            item.billingMonth === selectedMonth &&
            item.billingYear === selectedYear &&
            item.dueAmount <= 0,
        )
        .map((item) => item.feeCategory.id),
    );

    return feeCategories.filter((item) => !settledCategoryIds.has(item.id));
  }, [feeCategories, form.month, form.studentId, form.year, payments]);

  const latestPeriod = visibleHistory[0] ?? null;
  const openPeriods = visibleHistory.filter(
    (period) => period.dueAmount > 0,
  ).length;
  const canSubmitPayment =
    Boolean(form.studentId) &&
    Boolean(form.feeCategoryId) &&
    availableFeeCategories.length > 0 &&
    Number(form.amountPaid) >= 0 &&
    form.amountPaid.trim() !== "";

  useEffect(() => {
    if (availableFeeCategories.length === 0) {
      if (form.feeCategoryId !== "") {
        setForm((prev) => ({
          ...prev,
          feeCategoryId: "",
        }));
      }

      return;
    }

    const isSelectedCategoryAvailable = availableFeeCategories.some(
      (item) => item.id === form.feeCategoryId,
    );

    if (!isSelectedCategoryAvailable) {
      setForm((prev) => ({
        ...prev,
        feeCategoryId: availableFeeCategories[0]?.id ?? "",
      }));
    }
  }, [availableFeeCategories, form.feeCategoryId]);

  const loadPayments = useCallback(
    async (
      nextAuth: AuthStorage,
      currentSearch = search,
      currentStatus: StatusFilter = statusFilter,
    ) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim());
        }
        if (currentStatus !== "ALL") {
          params.set("status", currentStatus);
        }

        const response = await fetch(
          `/api/v1/fees/payments?${params.toString()}`,
          {
            headers: {
              Authorization: `Bearer ${nextAuth.token}`,
            },
          },
        );
        const json = await response.json();

        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load payments");
        }

        const data = json.data as PaymentResponse;
        setPayments(data.payments);
        setHistory(data.history);
        setStudents(data.students);
        setFeeCategories(data.feeCategories);
        setForm((prev) => ({
          ...prev,
          studentId: prev.studentId || data.students[0]?.id || "",
          feeCategoryId: prev.feeCategoryId || data.feeCategories[0]?.id || "",
        }));
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load payments",
        );
      } finally {
        setLoading(false);
      }
    },
    [search, statusFilter],
  );

  useEffect(() => {
    if (authState) {
      void loadPayments(authState);
    }
  }, [authState, loadPayments]);

  const refresh = useCallback(async () => {
    if (authState) {
      await loadPayments(authState);
    }
  }, [authState, loadPayments]);

  const downloadReceipt = useCallback(
    async (id: string) => {
      if (!authState) return;

      setReceiptLoadingId(id);
      setError(null);

      try {
        const response = await fetch(`/api/v1/fees/payments/${id}/receipt`, {
          headers: {
            Authorization: `Bearer ${authState.token}`,
          },
        });

        if (!response.ok) {
          const json = await response.json().catch(() => null);
          throw new Error(json?.message ?? "Unable to download receipt");
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = `money-receipt-${id}.html`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
      } catch (exception) {
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to download receipt",
        );
      } finally {
        setReceiptLoadingId(null);
      }
    },
    [authState],
  );

  const createPayment = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/v1/fees/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          ...form,
          amountPaid: Number(form.amountPaid),
          month: Number(form.month),
          year: Number(form.year),
          dueDate: form.dueDate || undefined,
        }),
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create payment");
      }

      setForm((prev) => ({
        ...prev,
        amountPaid: "",
        paymentMethod: "",
        transactionId: "",
        dueDate: "",
        month: String(today.getMonth() + 1),
        year: String(today.getFullYear()),
      }));
      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create payment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const deletePayment = async (id: string) => {
    if (!authState) return;

    const confirmed = window.confirm(
      "Delete this payment record? This action cannot be undone.",
    );
    if (!confirmed) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/fees/payments/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      });
      const json = await response.json();

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to delete payment");
      }

      await refresh();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to delete payment",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-linear-to-br from-slate-50 via-background to-amber-50/50 text-foreground">
      <div className="mx-auto w-full max-w-7xl px-4 py-6 lg:px-6">
        <section className="relative overflow-hidden rounded-[2rem] border border-border/70 bg-card/90 p-6 shadow-[0_30px_80px_-40px_rgba(15,23,42,0.35)] backdrop-blur">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(250,204,21,0.14),transparent_28%),radial-gradient(circle_at_bottom_left,rgba(14,165,233,0.14),transparent_30%)]" />
          <div className="relative flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
            <div className="max-w-3xl space-y-4">
              <div className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-background/80 px-3 py-1 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                Finance / {scope === "monthly" ? "Monthly" : "Secondary"}
              </div>
              <div className="space-y-3">
                <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
                  {scopeConfig.title}
                </h1>
                <p className="max-w-2xl text-sm leading-6 text-muted-foreground sm:text-base">
                  {scopeConfig.description}
                </p>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 shadow-sm">
                <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                  Billing periods
                </p>
                <p className="mt-2 text-2xl font-semibold">
                  {visibleHistory.length}
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 shadow-sm">
                <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                  Collected
                </p>
                <p className="mt-2 text-2xl font-semibold">
                  {formatMoney(scopeSummary.paid)}
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 shadow-sm">
                <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                  Expected
                </p>
                <p className="mt-2 text-2xl font-semibold">
                  {formatMoney(scopeSummary.expected)}
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 shadow-sm">
                <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                  Due
                </p>
                <p className="mt-2 text-2xl font-semibold text-destructive">
                  {formatMoney(scopeSummary.due)}
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Card className="rounded-3xl border-border/70 shadow-sm">
            <CardHeader className="space-y-1 pb-3">
              <CardDescription>
                {scopeConfig.scopeDueLabel} open periods
              </CardDescription>
              <CardTitle className="text-3xl">{openPeriods}</CardTitle>
            </CardHeader>
          </Card>
          <Card className="rounded-3xl border-border/70 shadow-sm">
            <CardHeader className="space-y-1 pb-3">
              <CardDescription>Transactions</CardDescription>
              <CardTitle className="text-3xl">{payments.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card className="rounded-3xl border-border/70 shadow-sm">
            <CardHeader className="space-y-1 pb-3">
              <CardDescription>
                {scopeConfig.scopeDueLabel} on latest period
              </CardDescription>
              <CardTitle className="text-2xl">
                {latestPeriod
                  ? formatMoney(
                      isMonthlyScope
                        ? latestPeriod.monthlyFeeDue
                        : latestPeriod.extraCategoryDue,
                    )
                  : "৳0"}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card className="rounded-3xl border-border/70 shadow-sm">
            <CardHeader className="space-y-1 pb-3">
              <CardDescription>{scopeConfig.scopeBalanceLabel}</CardDescription>
              <CardTitle className="text-2xl">
                {latestPeriod
                  ? isMonthlyScope
                    ? formatMoney(latestPeriod.monthlyFeeDue)
                    : formatMoney(latestPeriod.extraCategoryDue)
                  : "৳0"}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        <div className="mt-6 grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
          <div className="space-y-6 xl:sticky xl:top-6 xl:self-start">
            <Card className="overflow-hidden rounded-3xl border-border/70 shadow-sm">
              <CardHeader className="border-b border-border/60 bg-muted/20">
                <CardDescription>{scopeConfig.scopeHeaderText}</CardDescription>
                <CardTitle>{scopeConfig.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5 p-5">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl border border-border/70 bg-muted/30 p-4">
                    <p className="text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
                      Selected student
                    </p>
                    <p className="mt-2 text-sm font-semibold">
                      {selectedStudent?.name ?? "Choose a student"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {selectedStudent?.className ?? "Class will appear here"}
                    </p>
                  </div>
                  <div className="rounded-2xl border border-border/70 bg-muted/30 p-4">
                    <p className="text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
                      Selected category
                    </p>
                    <p className="mt-2 text-sm font-semibold">
                      {selectedCategory?.name ?? "Choose a fee category"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {selectedCategory
                        ? `Base amount ${formatMoney(selectedCategory.amount)}`
                        : "Settled categories are hidden automatically"}
                    </p>
                  </div>
                </div>

                <form className="space-y-4" onSubmit={createPayment}>
                  <div className="space-y-2">
                    <Label htmlFor="payment-student">Student</Label>
                    <select
                      id="payment-student"
                      className="h-10 w-full rounded-2xl border border-input bg-background/90 px-3 text-sm outline-none transition focus:border-primary"
                      value={form.studentId}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          studentId: event.target.value,
                        }))
                      }
                    >
                      {students.map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.name} · {item.className}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="payment-category">Category</Label>
                    <select
                      id="payment-category"
                      className="h-10 w-full rounded-2xl border border-input bg-background/90 px-3 text-sm outline-none transition focus:border-primary"
                      value={form.feeCategoryId}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          feeCategoryId: event.target.value,
                        }))
                      }
                    >
                      {availableFeeCategories.length > 0 ? (
                        availableFeeCategories.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name} · {formatMoney(item.amount)}
                          </option>
                        ))
                      ) : (
                        <option value="">No active categories available</option>
                      )}
                    </select>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="payment-amount">Amount paid</Label>
                      <Input
                        id="payment-amount"
                        type="number"
                        min="0"
                        value={form.amountPaid}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            amountPaid: event.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-status">Status</Label>
                      <select
                        id="payment-status"
                        className="h-10 w-full rounded-2xl border border-input bg-background/90 px-3 text-sm outline-none transition focus:border-primary"
                        value={form.status}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            status: event.target.value,
                          }))
                        }
                      >
                        <option value="PAID">Paid</option>
                        <option value="PARTIAL">Partial</option>
                        <option value="DUE">Due</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="payment-method">Method</Label>
                      <Input
                        id="payment-method"
                        value={form.paymentMethod}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            paymentMethod: event.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-transaction">
                        Transaction ID
                      </Label>
                      <Input
                        id="payment-transaction"
                        value={form.transactionId}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            transactionId: event.target.value,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="payment-month">Billing month</Label>
                      <Input
                        id="payment-month"
                        type="number"
                        min="1"
                        max="12"
                        value={form.month}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            month: event.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-year">Billing year</Label>
                      <Input
                        id="payment-year"
                        type="number"
                        min="2000"
                        max="2100"
                        value={form.year}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            year: event.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-due-date">Due date</Label>
                      <Input
                        id="payment-due-date"
                        type="date"
                        value={form.dueDate}
                        onChange={(event) =>
                          setForm((prev) => ({
                            ...prev,
                            dueDate: event.target.value,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-3 rounded-2xl border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">
                      Live billing note
                    </span>
                    <span>{scopeConfig.scopeNote}</span>
                  </div>

                  <Button
                    type="submit"
                    className="w-full rounded-2xl"
                    disabled={submitting || !canSubmitPayment}
                  >
                    {submitting ? "Saving…" : "Record payment"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="rounded-3xl border-border/70 shadow-sm">
              <CardHeader>
                <CardDescription>Selected scope</CardDescription>
                <CardTitle>Current context</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center justify-between gap-4 rounded-2xl bg-muted/40 px-4 py-3">
                  <span className="text-muted-foreground">Student</span>
                  <span className="font-medium">
                    {selectedStudent?.name ?? "Not selected"}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4 rounded-2xl bg-muted/40 px-4 py-3">
                  <span className="text-muted-foreground">Category</span>
                  <span className="font-medium">
                    {selectedCategory?.name ?? "Not selected"}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4 rounded-2xl bg-muted/40 px-4 py-3">
                  <span className="text-muted-foreground">Period</span>
                  <span className="font-medium">
                    {formatBillingMonth(Number(form.month), Number(form.year))}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="overflow-hidden rounded-3xl border-border/70 shadow-sm">
            <CardHeader className="border-b border-border/60 bg-muted/20">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div>
                  <CardDescription>{scopeConfig.ledgerTitle}</CardDescription>
                  <CardTitle>Review billing periods</CardTitle>
                  <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
                    {scopeConfig.ledgerDescription}
                  </p>
                </div>
                <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 text-right">
                  <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                    Visible periods
                  </p>
                  <p className="mt-1 text-2xl font-semibold">
                    {visibleHistory.length}
                  </p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-5 p-5">
              <form
                className="grid gap-3 md:grid-cols-[1fr_180px_auto_auto]"
                onSubmit={(event) => {
                  event.preventDefault();
                  void refresh();
                }}
              >
                <Input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search student or transaction"
                  className="rounded-2xl"
                />
                <select
                  className="h-10 rounded-2xl border border-input bg-background/90 px-3 text-sm outline-none transition focus:border-primary"
                  value={statusFilter}
                  onChange={(event) =>
                    setStatusFilter(event.target.value as StatusFilter)
                  }
                >
                  {statusOptions.map((option) => (
                    <option key={option} value={option}>
                      {option === "ALL"
                        ? "All statuses"
                        : getStatusLabel(option as PaymentRecord["status"])}
                    </option>
                  ))}
                </select>
                <Button type="submit" variant="outline" className="rounded-2xl">
                  Filter
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  className="rounded-2xl"
                  onClick={() => void refresh()}
                >
                  Refresh
                </Button>
              </form>

              {error ? (
                <div className="rounded-2xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
                  {error}
                </div>
              ) : null}

              {loading ? (
                <p className="text-sm text-muted-foreground">
                  Loading payments…
                </p>
              ) : visibleHistory.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-border bg-muted/20 p-10 text-center">
                  <p className="text-base font-medium">
                    No billing periods yet
                  </p>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Create a payment to seed the ledger, or adjust the filters
                    above to inspect existing records.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {visibleHistory.map((period) => (
                    <article
                      key={period.key}
                      className="overflow-hidden rounded-3xl border border-border bg-background/80 shadow-sm"
                    >
                      <div className="border-b border-border/60 px-5 py-4">
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div>
                            <p className="text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
                              Billing period
                            </p>
                            <h3 className="mt-1 text-lg font-semibold">
                              {period.label} · {period.studentName}
                            </h3>
                            <p className="mt-1 text-sm text-muted-foreground">
                              {period.className} · {scopeConfig.scopeDueLabel}{" "}
                              {formatMoney(
                                isMonthlyScope
                                  ? period.monthlyFeeDue
                                  : period.extraCategoryDue,
                              )}
                            </p>
                          </div>
                          <div className="rounded-2xl border border-border/70 bg-muted/30 px-4 py-3 text-right">
                            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                              Due
                            </p>
                            <p className="mt-1 text-lg font-semibold text-destructive">
                              {formatMoney(
                                isMonthlyScope
                                  ? period.monthlyFeeDue
                                  : period.extraCategoryDue,
                              )}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {(isMonthlyScope
                                ? period.monthlyFeeDue
                                : period.extraCategoryDue) > 0
                                ? "Open period"
                                : "Settled"}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="grid gap-3 px-5 py-4 sm:grid-cols-3">
                        <div className="rounded-2xl bg-muted/50 p-3">
                          <p className="text-xs text-muted-foreground">
                            Expected
                          </p>
                          <p className="mt-1 text-sm font-semibold">
                            {formatMoney(
                              isMonthlyScope
                                ? period.monthlyFeeBase
                                : period.extraCategoryFees,
                            )}
                          </p>
                        </div>
                        <div className="rounded-2xl bg-muted/50 p-3">
                          <p className="text-xs text-muted-foreground">Paid</p>
                          <p className="mt-1 text-sm font-semibold">
                            {formatMoney(period.amountPaid)}
                          </p>
                        </div>
                        <div className="rounded-2xl bg-muted/50 p-3">
                          <p className="text-xs text-muted-foreground">
                            Transactions
                          </p>
                          <p className="mt-1 text-sm font-semibold">
                            {period.transactions.length}
                          </p>
                        </div>
                      </div>

                      <div className="space-y-3 border-t border-border/60 px-5 py-4">
                        {period.transactions.map((item) => (
                          <div
                            key={item.id}
                            className="rounded-2xl border border-border bg-background/80 p-4"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-3">
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge variant={getStatusTone(item.status)}>
                                    {getStatusLabel(item.status)}
                                  </Badge>
                                  <Badge variant="outline">
                                    {item.feeCategory.name}
                                  </Badge>
                                </div>
                                <p className="font-medium text-sm">
                                  {item.student.user.name}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  Roll {item.student.rollNumber ?? "N/A"} ·{" "}
                                  {item.student.class.name}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {scopeConfig.scopeDueLabel}{" "}
                                  {formatMoney(
                                    isMonthlyScope
                                      ? item.monthlyFeeDue
                                      : item.extraCategoryDue,
                                  )}
                                </p>
                                <div className="flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                                  <span>
                                    Method: {item.paymentMethod ?? "-"}
                                  </span>
                                  <span>Txn: {item.transactionId ?? "-"}</span>
                                  <span>
                                    Due date:{" "}
                                    {item.dueDate
                                      ? new Date(
                                          item.dueDate,
                                        ).toLocaleDateString()
                                      : "-"}
                                  </span>
                                </div>
                              </div>

                              <div className="space-y-3 text-right">
                                <p className="text-sm font-semibold">
                                  {formatMoney(item.amountPaid)} /{" "}
                                  {formatMoney(
                                    isMonthlyScope
                                      ? item.monthlyFeeBase
                                      : item.categoryFee,
                                  )}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  Due{" "}
                                  {formatMoney(
                                    isMonthlyScope
                                      ? item.monthlyFeeDue
                                      : item.extraCategoryDue,
                                  )}
                                </p>
                                <div>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => void downloadReceipt(item.id)}
                                    disabled={submitting || receiptLoadingId === item.id}
                                    className="mr-2 rounded-full"
                                  >
                                    {receiptLoadingId === item.id
                                      ? "Preparing…"
                                      : "Money Receipt"}
                                  </Button>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => void deletePayment(item.id)}
                                    disabled={submitting || receiptLoadingId === item.id}
                                    className="rounded-full border-destructive/40 text-destructive hover:bg-destructive/5 hover:text-destructive"
                                  >
                                    Delete
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
