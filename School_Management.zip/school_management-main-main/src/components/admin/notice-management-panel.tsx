"use client"

import { useCallback, useEffect, useState, type FormEvent } from "react"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { readAuth, type AuthStorage } from "@/utils/auth-storage"

type ClassOption = { id: string; name: string }

type NoticeRecord = {
  id: string
  title: string
  content: string
  audience: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS"
  startsAt: string | null
  endsAt: string | null
  isActive: boolean
  status: "DRAFT" | "PUBLISHED"
  classId: string | null
  class: ClassOption | null
  createdAt: string
}

type NoticeResponse = {
  notices: NoticeRecord[]
  classes: ClassOption[]
  stats: { total: number; classSpecific: number }
}

type NoticeFormState = {
  title: string
  audience: NoticeRecord["audience"]
  startsAt: string
  endsAt: string
  classId: string
}

function getNoticeStatus(notice: NoticeRecord) {
  const now = new Date()
  const startsAt = notice.startsAt ? new Date(notice.startsAt) : null
  const endsAt = notice.endsAt ? new Date(notice.endsAt) : null

  if (!notice.isActive || (endsAt !== null && endsAt < now)) {
    return { label: "Inactive", tone: "destructive" as const }
  }

  if (startsAt !== null && startsAt > now) {
    return { label: "Scheduled", tone: "secondary" as const }
  }

  return { label: "Active", tone: "outline" as const }
}

function formatSchedule(notice: NoticeRecord) {
  if (!notice.startsAt && !notice.endsAt) {
    return "No date range"
  }

  const parts = [notice.startsAt, notice.endsAt]
    .filter(Boolean)
    .map((value) => new Date(value as string).toLocaleDateString())

  return parts.join(" to ")
}

export function NoticeManagementPanel() {
  const router = useRouter()
  const [authState, setAuthState] = useState<AuthStorage | null>(null)
  const [notices, setNotices] = useState<NoticeRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [stats, setStats] = useState({ total: 0, classSpecific: 0 })
  const [search, setSearch] = useState("")
  const [audienceFilter, setAudienceFilter] = useState("ALL_FILTER")
  const [form, setForm] = useState<NoticeFormState>({
    title: "",
    audience: "ALL",
    startsAt: "",
    endsAt: "",
    classId: "",
  })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setAuthState(readAuth())
  }, [])

  const loadNotices = useCallback(
    async (
      nextAuth: AuthStorage,
      currentSearch = search,
      currentAudience = audienceFilter,
    ) => {
      setLoading(true)
      setError(null)

      try {
        const params = new URLSearchParams()
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim())
        }
        if (currentAudience !== "ALL_FILTER") {
          params.set("audience", currentAudience)
        }

        const response = await fetch(`/api/v1/notices?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        })
        const json = await response.json()

        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load notices")
        }

        const data = json.data as NoticeResponse
        setNotices(data.notices)
        setClasses(data.classes)
        setStats(data.stats)
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load notices")
      } finally {
        setLoading(false)
      }
    },
    [audienceFilter, search],
  )

  useEffect(() => {
    if (authState) {
      void loadNotices(authState)
    }
  }, [authState, loadNotices])

  const refresh = async () => {
    if (authState) {
      await loadNotices(authState)
    }
  }

  const createNotice = async (event: FormEvent) => {
    event.preventDefault()
    if (!authState) return

    setSubmitting(true)
    setError(null)

    try {
      const response = await fetch("/api/v1/notices", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          ...form,
          classId: form.classId || undefined,
          startsAt: form.startsAt || undefined,
          endsAt: form.endsAt || undefined,
        }),
      })
      const json = await response.json()

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create notice")
      }

      const noticeId = (json.data?.notice?.id as string | undefined) ?? undefined
      setForm({
        title: "",
        audience: "ALL",
        startsAt: "",
        endsAt: "",
        classId: "",
      })
      if (noticeId) {
        router.push(`/admin/notices/${noticeId}`)
      } else {
        await refresh()
      }
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create notice")
    } finally {
      setSubmitting(false)
    }
  }

  const deleteNotice = async (id: string) => {
    if (!authState) return

    setSubmitting(true)
    setError(null)

    try {
      const response = await fetch(`/api/v1/notices/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      })
      const json = await response.json()

      if (!response.ok) {
        throw new Error(json.message ?? "Unable to delete notice")
      }

      await refresh()
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to delete notice")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Communications
        </p>
        <h1 className="text-2xl font-semibold">Notice management</h1>
      </section>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardDescription>Total</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Class-specific</CardDescription>
            <CardTitle>{stats.classSpecific}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Create notice</CardTitle>
            <CardDescription>Create a draft, then write and publish from the notice pad.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={createNotice}>
              <div className="space-y-2">
                <Label htmlFor="notice-title">Title</Label>
                <Input
                  id="notice-title"
                  value={form.title}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, title: event.target.value }))
                  }
                  required
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="notice-start-date">Start date</Label>
                  <Input
                    id="notice-start-date"
                    type="date"
                    value={form.startsAt}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, startsAt: event.target.value }))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notice-end-date">End date</Label>
                  <Input
                    id="notice-end-date"
                    type="date"
                    value={form.endsAt}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, endsAt: event.target.value }))
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notice-audience-admin">Audience</Label>
                <select
                  id="notice-audience-admin"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.audience}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      audience: event.target.value as NoticeRecord["audience"],
                    }))
                  }
                >
                  <option value="ALL">All</option>
                  <option value="STUDENTS">Students</option>
                  <option value="TEACHERS">Teachers</option>
                  <option value="ADMINS">Admins</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notice-class-admin">Class</Label>
                <select
                  id="notice-class-admin"
                  className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                  value={form.classId}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, classId: event.target.value }))
                  }
                >
                  <option value="">All classes</option>
                  {classes.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>

              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create draft & open pad"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Notice board</CardTitle>
            <CardDescription>Latest notices from the live system.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-2 md:grid-cols-[1fr_180px_auto]"
              onSubmit={(event) => {
                event.preventDefault()
                void refresh()
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search notices"
              />
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={audienceFilter}
                onChange={(event) => setAudienceFilter(event.target.value)}
              >
                <option value="ALL_FILTER">All audiences</option>
                <option value="ALL">All</option>
                <option value="STUDENTS">Students</option>
                <option value="TEACHERS">Teachers</option>
                <option value="ADMINS">Admins</option>
              </select>
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>

            {error ? <div className="text-xs text-destructive">{error}</div> : null}

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading notices…</p>
            ) : (
              <div className="space-y-3">
                {notices.map((item) => {
                  const status = getNoticeStatus(item)

                  return (
                    <article
                      key={item.id}
                      className="rounded-none border border-border bg-background/60 p-4"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline">{item.audience}</Badge>
                        <Badge variant="secondary">{item.status}</Badge>
                        <Badge variant={status.tone}>{status.label}</Badge>
                        {item.class ? (
                          <Badge variant="secondary">{item.class.name}</Badge>
                        ) : null}
                      </div>

                      <h3 className="mt-2 text-sm font-semibold text-foreground">
                        {item.title}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground whitespace-pre-wrap">
                        {item.content}
                      </p>
                      <p className="mt-2 text-[11px] text-muted-foreground">
                        {formatSchedule(item)}
                      </p>

                      <div className="mt-3 flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          type="button"
                          onClick={() => router.push(`/admin/notices/${item.id}`)}
                          disabled={submitting}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          type="button"
                          onClick={() => void deleteNotice(item.id)}
                          disabled={submitting}
                        >
                          Delete
                        </Button>
                      </div>
                    </article>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
