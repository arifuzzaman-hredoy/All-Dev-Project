import Link from "next/link"
import type { ReactNode } from "react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"

export type AdminStat = {
  label: string
  value: string
  caption?: string
}

export type AdminAction = {
  label: string
  href: string
  variant?: string
  description?: string
}

type AdminSectionPageProps = {
  title: string
  description: string
  meta?: string
  stats?: AdminStat[]
  actions?: AdminAction[]
  children?: ReactNode
}

export function AdminSectionPage({
  title,
  description,
  meta,
  stats,
  actions,
  children,
}: AdminSectionPageProps) {
  return (
    <section className="space-y-6">
      <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        {meta && (
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
            {meta}
          </p>
        )}
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold">{title}</h1>
          <p className="max-w-3xl text-sm text-slate-200">{description}</p>
        </div>
      </div>

      {stats && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <article
              key={stat.label}
              className="rounded-2xl border border-border bg-background/60 p-4 text-sm shadow-sm"
            >
              <p className="text-xs uppercase tracking-widest text-muted-foreground">
                {stat.label}
              </p>
              <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
              {stat.caption && (
                <p className="text-xs text-muted-foreground">{stat.caption}</p>
              )}
            </article>
          ))}
        </div>
      )}

      {actions && (
        <div className="flex flex-wrap gap-2">
          {actions.map((action) => (
            <Button
              asChild
              variant={
                action.variant === "outline" || action.variant === "secondary"
                  ? action.variant
                  : "default"
              }
              size="sm"
              key={action.label}
            >
              <Link href={action.href}>{action.label}</Link>
            </Button>
          ))}
        </div>
      )}

      {children && (
        <div className="space-y-4 rounded-2xl border border-border bg-background/60 p-4 text-sm text-muted-foreground">
          {children}
        </div>
      )}

      <Separator />
    </section>
  )
}
