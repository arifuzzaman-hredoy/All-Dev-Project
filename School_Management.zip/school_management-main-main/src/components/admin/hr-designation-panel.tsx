"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type DesignationRecord = {
  id: string;
  name: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  _count: { teachers: number };
};

type DesignationResponse = {
  designations: DesignationRecord[];
};

export function HrDesignationPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [designations, setDesignations] = useState<DesignationRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [createName, setCreateName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  useEffect(() => setAuthState(readAuth()), []);

  const load = useCallback(
    async (nextAuth: AuthStorage, currentSearch = search) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) params.set("search", currentSearch.trim());
        const response = await fetch(`/api/v1/hr/designations?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok) throw new Error(json.message ?? "Unable to load designations");
        const data = json.data as DesignationResponse;
        setDesignations(data.designations);
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load designations");
      } finally {
        setLoading(false);
      }
    },
    [search],
  );

  useEffect(() => {
    if (authState) void load(authState);
  }, [authState, load]);

  const refresh = async () => {
    if (authState) await load(authState);
  };

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/v1/hr/designations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ name: createName, isActive: true }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to create designation");
      setCreateName("");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create designation");
    } finally {
      setSubmitting(false);
    }
  };

  const handleSave = async (id: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/hr/designations/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ name: editingName }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update designation");
      setEditingId(null);
      setEditingName("");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update designation");
    } finally {
      setSubmitting(false);
    }
  };

  const toggleActive = async (designation: DesignationRecord) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/hr/designations/${designation.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ isActive: !designation.isActive }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update designation");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update designation");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          HR
        </p>
        <h1 className="text-2xl font-semibold">Designations</h1>
      </section>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Add designation</CardTitle>
            <CardDescription>Job titles for staff/teachers.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleCreate}>
              <div className="space-y-2">
                <Label htmlFor="designation-name">Designation name</Label>
                <Input
                  id="designation-name"
                  value={createName}
                  onChange={(event) => setCreateName(event.target.value)}
                  required
                />
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create"}
              </Button>
              {error ? <p className="text-xs text-destructive">{error}</p> : null}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Designation list</CardTitle>
            <CardDescription>Manage and deactivate old titles.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search designations"
              />
              <Button type="submit" variant="outline" disabled={submitting}>
                Filter
              </Button>
            </form>

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading…</p>
            ) : (
              <div className="space-y-3">
                {designations.map((item) => (
                  <article
                    key={item.id}
                    className="rounded-none border border-border bg-background/60 p-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        {editingId === item.id ? (
                          <Input
                            value={editingName}
                            onChange={(event) => setEditingName(event.target.value)}
                          />
                        ) : (
                          <h3 className="text-sm font-semibold">{item.name}</h3>
                        )}
                        <p className="mt-1 text-xs text-muted-foreground">
                          {item._count.teachers} teachers
                        </p>
                      </div>
                      <Badge variant={item.isActive ? "outline" : "destructive"}>
                        {item.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      {editingId === item.id ? (
                        <>
                          <Button
                            size="sm"
                            type="button"
                            disabled={submitting}
                            onClick={() => void handleSave(item.id)}
                          >
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(null);
                              setEditingName("");
                            }}
                          >
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(item.id);
                              setEditingName(item.name);
                            }}
                            disabled={submitting}
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            type="button"
                            onClick={() => void toggleActive(item)}
                            disabled={submitting}
                          >
                            {item.isActive ? "Deactivate" : "Activate"}
                          </Button>
                        </>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

