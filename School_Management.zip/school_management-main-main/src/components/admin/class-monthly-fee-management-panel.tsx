"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { fetchWithAuth } from "@/lib/client-api";

type ClassMonthlyFeeRecord = {
  id: string;
  name: string;
  monthlyFee: number | null;
  isActive: boolean;
};

type ClassMonthlyFeePayload = {
  classes: ClassMonthlyFeeRecord[];
  stats: {
    total: number;
    configured: number;
    totalMonthlyFee: number;
  };
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-BD", {
    style: "currency",
    currency: "BDT",
    maximumFractionDigits: 0,
  }).format(value);
}

export function ClassMonthlyFeeManagementPanel() {
  const [data, setData] = useState<ClassMonthlyFeePayload | null>(null);
  const [search, setSearch] = useState("");
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [savingClassId, setSavingClassId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const payload = await fetchWithAuth<ClassMonthlyFeePayload>(
        "/api/v1/fees/monthly",
      );
      setData(payload);
      setDrafts(
        payload.classes.reduce<Record<string, string>>((acc, item) => {
          acc[item.id] =
            item.monthlyFee === null ? "" : String(item.monthlyFee);
          return acc;
        }, {}),
      );
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to load monthly fees",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const filteredClasses = useMemo(() => {
    if (!data) return [];
    const trimmedSearch = search.trim().toLowerCase();
    if (!trimmedSearch) return data.classes;
    return data.classes.filter((item) =>
      item.name.toLowerCase().includes(trimmedSearch),
    );
  }, [data, search]);

  const saveMonthlyFee = async (classId: string) => {
    const nextValue = drafts[classId];
    setSavingClassId(classId);
    setError(null);

    try {
      const monthlyFee = nextValue.trim() === "" ? null : Number(nextValue);

      if (monthlyFee !== null && Number.isNaN(monthlyFee)) {
        throw new Error("Enter a valid monthly fee");
      }

      const response = await fetchWithAuth<{ classFee: unknown }>(
        "/api/v1/fees/monthly",
        {
          method: "PATCH",
          body: JSON.stringify({
            classId,
            monthlyFee,
            isActive: monthlyFee !== null,
          }),
        },
      );

      if (!response) {
        throw new Error("Unable to save monthly fee");
      }

      await load();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to save monthly fee",
      );
    } finally {
      setSavingClassId(null);
    }
  };

  const toggleMonthlyFee = async (classId: string, nextActive: boolean) => {
    if (!data) return;

    const current = data.classes.find((item) => item.id === classId);
    if (!current || current.monthlyFee === null) {
      return;
    }

    setSavingClassId(classId);
    setError(null);

    try {
      const response = await fetchWithAuth<{ classFee: unknown }>(
        "/api/v1/fees/monthly",
        {
          method: "PATCH",
          body: JSON.stringify({
            classId,
            monthlyFee: current.monthlyFee,
            isActive: nextActive,
          }),
        },
      );

      if (!response) {
        throw new Error("Unable to update monthly fee status");
      }

      await load();
    } catch (exception) {
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update monthly fee status",
      );
    } finally {
      setSavingClassId(null);
    }
  };

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border border-border bg-background/70 px-6 py-6 shadow-sm">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          Fees
        </p>
        <h2 className="text-2xl font-semibold text-foreground">
          Monthly class fee
        </h2>
        <p className="mt-2 max-w-3xl text-sm text-muted-foreground">
          Set the monthly fee for each class. Leave a value blank to remove the
          configured amount.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Total classes</CardDescription>
            <CardTitle>{data?.stats.total ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Configured classes</CardDescription>
            <CardTitle>{data?.stats.configured ?? 0}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Total monthly fee</CardDescription>
            <CardTitle>
              {formatCurrency(data?.stats.totalMonthlyFee ?? 0)}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Class fee setup</CardTitle>
          <CardDescription>
            Adjust the recurring monthly fee for each class.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-[1fr_auto]">
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search class"
            />
            <Button type="button" variant="outline" onClick={() => void load()}>
              Refresh
            </Button>
          </div>

          {error && (
            <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
              {error}
            </div>
          )}

          {loading ? (
            <p className="text-xs text-muted-foreground">
              Loading monthly fees…
            </p>
          ) : (
            <div className="space-y-3">
              {filteredClasses.map((item) => {
                const feeValue = drafts[item.id] ?? "";

                return (
                  <article
                    key={item.id}
                    className="space-y-3 rounded-none border border-border bg-background/60 p-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h3 className="text-sm font-semibold text-foreground">
                          {item.name}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          Current monthly fee:{" "}
                          {item.monthlyFee === null
                            ? "Not set"
                            : formatCurrency(item.monthlyFee)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Status: {item.isActive ? "Active" : "Inactive"}
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() =>
                          void toggleMonthlyFee(item.id, !item.isActive)
                        }
                        disabled={
                          savingClassId === item.id || item.monthlyFee === null
                        }
                      >
                        {item.isActive ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                    <div className="grid gap-3 md:grid-cols-[1fr_auto]">
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={feeValue}
                        onChange={(event) =>
                          setDrafts((prev) => ({
                            ...prev,
                            [item.id]: event.target.value,
                          }))
                        }
                        placeholder="Enter monthly fee"
                      />
                      <Button
                        type="button"
                        onClick={() => void saveMonthlyFee(item.id)}
                        disabled={savingClassId === item.id}
                      >
                        {savingClassId === item.id ? "Saving…" : "Save fee"}
                      </Button>
                    </div>
                  </article>
                );
              })}
              {filteredClasses.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  No classes match the current search.
                </p>
              ) : null}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
