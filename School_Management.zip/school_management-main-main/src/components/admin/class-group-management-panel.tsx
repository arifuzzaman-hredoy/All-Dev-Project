"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type ClassRecord = {
  id: string;
  name: string;
  sortOrder: number;
  studentLimit: number | null;
  _count: { students: number; groups: number; subjects: number };
};

type GroupRecord = {
  id: string;
  name: string;
  studentLimit: number | null;
  classId: string;
  createdAt: string;
  _count: { students: number; sections: number };
};

type GroupsResponse = {
  class: ClassRecord;
  groups: GroupRecord[];
  stats: { total: number; totalStudents: number; totalSections: number };
};

const DEFAULT_GROUP_NAME = "General";

function isDefaultGroup(group: GroupRecord) {
  return group.name.trim().toLowerCase() === DEFAULT_GROUP_NAME.toLowerCase();
}

export function ClassGroupManagementPanel({ classId }: { classId: string }) {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [classRecord, setClassRecord] = useState<ClassRecord | null>(null);
  const [groups, setGroups] = useState<GroupRecord[]>([]);
  const [stats, setStats] = useState({ total: 0, totalStudents: 0, totalSections: 0 });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [createName, setCreateName] = useState("");
  const [createStudentLimit, setCreateStudentLimit] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [editingStudentLimit, setEditingStudentLimit] = useState("");

  useEffect(() => setAuthState(readAuth()), []);

  const load = useCallback(
    async (nextAuth: AuthStorage, currentSearch = search) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) params.set("search", currentSearch.trim());
        const response = await fetch(`/api/v1/classes/${classId}/groups?${params.toString()}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok) throw new Error(json.message ?? "Unable to load groups");
        const data = json.data as GroupsResponse;
        setClassRecord(data.class);
        setGroups(data.groups);
        setStats(data.stats);
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load groups");
      } finally {
        setLoading(false);
      }
    },
    [classId, search],
  );

  useEffect(() => {
    if (authState) void load(authState);
  }, [authState, load]);

  const refresh = async () => {
    if (authState) await load(authState);
  };

  const canDelete = useMemo(() => {
    return new Set(
      groups
        .filter((group) => !isDefaultGroup(group) && group._count.students === 0)
        .map((group) => group.id),
    );
  }, [groups]);

  const allocatedGroupLimit = useMemo(
    () => groups.reduce((sum, group) => sum + (group.studentLimit ?? 0), 0),
    [groups],
  );
  const remainingGroupLimit =
    classRecord?.studentLimit === null || classRecord?.studentLimit === undefined
      ? null
      : Math.max(classRecord.studentLimit - allocatedGroupLimit, 0);
  const availableLimitForEditing = (group: GroupRecord) =>
    classRecord?.studentLimit === null || classRecord?.studentLimit === undefined
      ? undefined
      : Math.max(
          classRecord.studentLimit -
            (allocatedGroupLimit - (group.studentLimit ?? 0)),
          0,
        );

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/classes/${classId}/groups`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name: createName,
          studentLimit: createStudentLimit ? Number(createStudentLimit) : null,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to create group");
      setCreateName("");
      setCreateStudentLimit("");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to create group");
    } finally {
      setSubmitting(false);
    }
  };

  const handleSave = async (id: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/classes/${classId}/groups/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          name: editingName,
          studentLimit: editingStudentLimit
            ? Number(editingStudentLimit)
            : null,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update group");
      setEditingId(null);
      setEditingName("");
      setEditingStudentLimit("");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update group");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/classes/${classId}/groups/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${authState.token}` },
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to delete group");
      await refresh();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to delete group");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">Structure</p>
        <h1 className="text-2xl font-semibold">
          Groups {classRecord ? `· ${classRecord.name}` : ""}
        </h1>
        <div className="mt-3">
          <Button asChild size="sm" variant="secondary">
            <Link href="/admin/classes">Back to classes</Link>
          </Button>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Groups</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Students</CardDescription>
            <CardTitle>{stats.totalStudents}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Sections</CardDescription>
            <CardTitle>{stats.totalSections}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Add group</CardTitle>
            <CardDescription>Example: A, B, Science, Commerce, etc.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleCreate}>
              <div className="space-y-2">
                <Label htmlFor="group-name">Group name</Label>
                <Input
                  id="group-name"
                  value={createName}
                  onChange={(event) => setCreateName(event.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="group-student-limit">Group student limit</Label>
                <Input
                  id="group-student-limit"
                  type="number"
                  min={1}
                  max={remainingGroupLimit ?? undefined}
                  value={createStudentLimit}
                  onChange={(event) => setCreateStudentLimit(event.target.value)}
                  placeholder="Unlimited"
                />
                {classRecord?.studentLimit ? (
                  <p className="text-xs text-muted-foreground">
                    Class limit {classRecord.studentLimit}; remaining group
                    seats {remainingGroupLimit}
                  </p>
                ) : null}
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Saving…" : "Create"}
              </Button>
              {error ? <p className="text-xs text-destructive">{error}</p> : null}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Group list</CardTitle>
            <CardDescription>Manage groups under this class.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search groups"
              />
              <Button type="submit" variant="outline" disabled={submitting}>
                Filter
              </Button>
            </form>

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading…</p>
            ) : (
              <div className="space-y-3">
                {groups.map((group) => (
                  <article key={group.id} className="rounded-none border border-border bg-background/60 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        {editingId === group.id ? (
                          <div className="grid gap-2 sm:grid-cols-2">
                            <Input
                              value={editingName}
                              onChange={(event) => setEditingName(event.target.value)}
                            />
                            <Input
                              type="number"
                              min={1}
                              max={availableLimitForEditing(group)}
                              value={editingStudentLimit}
                              onChange={(event) =>
                                setEditingStudentLimit(event.target.value)
                              }
                              placeholder="Unlimited group limit"
                            />
                          </div>
                        ) : (
                          <h3 className="text-sm font-semibold">{group.name}</h3>
                        )}
                        <p className="mt-1 text-xs text-muted-foreground">
                          {group._count.students} students · {group._count.sections} sections · Limit{" "}
                          {group.studentLimit ?? "Unlimited"}
                        </p>
                      </div>
                      <Badge variant={isDefaultGroup(group) ? "secondary" : "outline"}>
                        {isDefaultGroup(group) ? "Default" : "Group"}
                      </Badge>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      {editingId === group.id ? (
                        <>
                          <Button
                            size="sm"
                            type="button"
                            disabled={submitting}
                            onClick={() => void handleSave(group.id)}
                          >
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(null);
                              setEditingName("");
                              setEditingStudentLimit("");
                            }}
                          >
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            type="button"
                            onClick={() => {
                              setEditingId(group.id);
                              setEditingName(group.name);
                              setEditingStudentLimit(
                                group.studentLimit?.toString() ?? "",
                              );
                            }}
                            disabled={submitting}
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            type="button"
                            onClick={() => void handleDelete(group.id)}
                            disabled={submitting || !canDelete.has(group.id)}
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </div>

                    {!canDelete.has(group.id) && !isDefaultGroup(group) ? (
                      <p className="mt-2 text-[11px] text-muted-foreground">
                        Cannot delete while students exist.
                      </p>
                    ) : null}
                  </article>
                ))}

                {groups.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No groups yet.</p>
                ) : null}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
