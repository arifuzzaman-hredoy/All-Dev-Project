"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type PayrollRunRecord = {
  id: string;
  month: number;
  year: number;
  status: "DRAFT" | "LOCKED";
  createdAt: string;
  updatedAt: string;
  _count: { items: number };
};

type PayrollItemRecord = {
  id: string;
  teacherId: string;
  baseSalarySnapshot: number;
  allowances: number;
  deductions: number;
  netPay: number;
  presentDays: number | null;
  absentDays: number | null;
  status: "UNPAID" | "PAID";
  paidAt: string | null;
  teacher: {
    id: string;
    employeeCode: string | null;
    user: { name: string; email: string; isDeleted: boolean };
    isDeleted: boolean;
  };
};

type PayrollRunListResponse = { runs: PayrollRunRecord[] };
type PayrollRunDetailsResponse = { run: PayrollRunRecord; items: PayrollItemRecord[] };

function formatPeriod(month: number, year: number) {
  const date = new Date(year, month - 1, 1);
  return date.toLocaleString(undefined, { month: "long", year: "numeric" });
}

export function PayrollManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [runs, setRuns] = useState<PayrollRunRecord[]>([]);
  const [activeRun, setActiveRun] = useState<PayrollRunRecord | null>(null);
  const [items, setItems] = useState<PayrollItemRecord[]>([]);

  const [month, setMonth] = useState(String(new Date().getMonth() + 1));
  const [year, setYear] = useState(String(new Date().getFullYear()));

  const loadRuns = useCallback(async (nextAuth: AuthStorage) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/v1/hr/payroll/runs", {
        headers: { Authorization: `Bearer ${nextAuth.token}` },
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to load payroll runs");
      const data = json.data as PayrollRunListResponse;
      setRuns(data.runs);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to load payroll runs");
    } finally {
      setLoading(false);
    }
  }, []);

  const loadRunDetails = useCallback(
    async (nextAuth: AuthStorage, runId: string) => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`/api/v1/hr/payroll/runs/${runId}`, {
          headers: { Authorization: `Bearer ${nextAuth.token}` },
        });
        const json = await response.json();
        if (!response.ok) throw new Error(json.message ?? "Unable to load payroll details");
        const data = json.data as PayrollRunDetailsResponse;
        setActiveRun(data.run);
        setItems(data.items);
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load payroll details");
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  useEffect(() => setAuthState(readAuth()), []);

  useEffect(() => {
    if (authState) void loadRuns(authState);
  }, [authState, loadRuns]);

  const refresh = async () => {
    if (!authState) return;
    await loadRuns(authState);
    if (activeRun) {
      await loadRunDetails(authState, activeRun.id);
    }
  };

  const handleGenerate = async (event: FormEvent) => {
    event.preventDefault();
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/v1/hr/payroll/runs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({ month: Number(month), year: Number(year) }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to generate payroll run");
      const runId = json.data?.run?.id as string | undefined;
      await refresh();
      if (runId) {
        await loadRunDetails(authState, runId);
      }
      setMessage("Payroll run generated");
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to generate payroll run");
    } finally {
      setSubmitting(false);
    }
  };

  const handleRunAction = async (action: "lock" | "pay") => {
    if (!authState || !activeRun) return;
    setSubmitting(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`/api/v1/hr/payroll/runs/${activeRun.id}?action=${action}`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${authState.token}` },
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update payroll run");
      await refresh();
      setMessage(action === "lock" ? "Payroll run locked" : "Payroll marked paid");
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update payroll run");
    } finally {
      setSubmitting(false);
    }
  };

  const updateItem = async (itemId: string, payload: { allowances?: number; deductions?: number }) => {
    if (!authState) return;
    setSubmitting(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`/api/v1/hr/payroll/items/${itemId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(payload),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.message ?? "Unable to update payroll item");
      await refresh();
      setMessage("Payroll item updated");
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "Unable to update payroll item");
    } finally {
      setSubmitting(false);
    }
  };

  const totals = useMemo(() => {
    return items.reduce(
      (acc, item) => {
        acc.totalNet += item.netPay;
        acc.totalAllowances += item.allowances;
        acc.totalDeductions += item.deductions;
        acc.paid += item.status === "PAID" ? 1 : 0;
        return acc;
      },
      { totalNet: 0, totalAllowances: 0, totalDeductions: 0, paid: 0 },
    );
  }, [items]);

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          HR
        </p>
        <h1 className="text-2xl font-semibold">Payroll</h1>
      </section>

      {error ? <div className="text-sm text-destructive">{error}</div> : null}
      {message ? <div className="text-sm text-emerald-600">{message}</div> : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Generate salary sheet</CardTitle>
            <CardDescription>Creates a payroll run (month/year) with salary snapshots.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleGenerate}>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="payroll-month">Month</Label>
                  <Input
                    id="payroll-month"
                    type="number"
                    min={1}
                    max={12}
                    value={month}
                    onChange={(event) => setMonth(event.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payroll-year">Year</Label>
                  <Input
                    id="payroll-year"
                    type="number"
                    min={2000}
                    max={2100}
                    value={year}
                    onChange={(event) => setYear(event.target.value)}
                    required
                  />
                </div>
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Generating…" : "Generate"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payroll runs</CardTitle>
            <CardDescription>Select a run to review items.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              <p className="text-xs text-muted-foreground">Loading…</p>
            ) : (
              <div className="space-y-3">
                {runs.map((run) => (
                  <button
                    key={run.id}
                    type="button"
                    className="w-full rounded-none border border-border bg-background/60 p-4 text-left hover:bg-muted/40"
                    onClick={() => authState && void loadRunDetails(authState, run.id)}
                    disabled={submitting}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold">
                          {formatPeriod(run.month, run.year)}
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {run._count.items} items
                        </p>
                      </div>
                      <Badge variant={run.status === "LOCKED" ? "secondary" : "outline"}>
                        {run.status}
                      </Badge>
                    </div>
                  </button>
                ))}
                {runs.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No payroll runs yet.</p>
                ) : null}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {activeRun ? (
        <Card>
          <CardHeader>
            <CardTitle>
              {formatPeriod(activeRun.month, activeRun.year)} · Items
            </CardTitle>
            <CardDescription>
              Total net: ৳{totals.totalNet.toFixed(2)} · Allowances: ৳{totals.totalAllowances.toFixed(2)} · Deductions: ৳{totals.totalDeductions.toFixed(2)} · Paid: {totals.paid}/{items.length}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => void handleRunAction("lock")}
                disabled={submitting || activeRun.status === "LOCKED"}
              >
                Lock run
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => void handleRunAction("pay")}
                disabled={submitting || activeRun.status !== "LOCKED"}
              >
                Mark paid
              </Button>
            </div>

            <div className="space-y-3">
              {items.map((item) => (
                <PayrollItemRow
                  key={`${item.id}:${item.allowances}:${item.deductions}:${item.status}`}
                  item={item}
                  disabled={submitting || activeRun.status === "LOCKED" || item.status === "PAID"}
                  onUpdate={(payload) => void updateItem(item.id, payload)}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

function PayrollItemRow(props: {
  item: PayrollItemRecord;
  disabled: boolean;
  onUpdate: (payload: { allowances?: number; deductions?: number }) => void;
}) {
  const [allowances, setAllowances] = useState(() => String(props.item.allowances ?? 0));
  const [deductions, setDeductions] = useState(() => String(props.item.deductions ?? 0));

  return (
    <div className="rounded-none border border-border bg-background/60 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">{props.item.teacher.user.name}</p>
          <p className="text-xs text-muted-foreground">
            {props.item.teacher.user.email}
            {props.item.teacher.employeeCode ? ` · ${props.item.teacher.employeeCode}` : ""}
          </p>
        </div>
        <Badge variant={props.item.status === "PAID" ? "secondary" : "outline"}>
          {props.item.status}
        </Badge>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-4">
        <div className="text-xs text-muted-foreground">
          Base: ৳{props.item.baseSalarySnapshot.toFixed(2)}
        </div>
        <div className="text-xs text-muted-foreground">
          Net: ৳{props.item.netPay.toFixed(2)}
        </div>
        <div className="text-xs text-muted-foreground">
          Present: {props.item.presentDays ?? "—"} / Absent: {props.item.absentDays ?? "—"}
        </div>
        <div className="text-xs text-muted-foreground">
          Paid at: {props.item.paidAt ? new Date(props.item.paidAt).toLocaleString() : "—"}
        </div>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <div className="space-y-2">
          <Label>Allowances</Label>
          <Input
            type="number"
            min={0}
            value={allowances}
            onChange={(event) => setAllowances(event.target.value)}
            disabled={props.disabled}
          />
        </div>
        <div className="space-y-2">
          <Label>Deductions</Label>
          <Input
            type="number"
            min={0}
            value={deductions}
            onChange={(event) => setDeductions(event.target.value)}
            disabled={props.disabled}
          />
        </div>
        <div className="flex items-end">
          <Button
            type="button"
            onClick={() =>
              props.onUpdate({
                allowances: Number(allowances),
                deductions: Number(deductions),
              })
            }
            disabled={props.disabled}
          >
            Update
          </Button>
        </div>
      </div>
    </div>
  );
}
