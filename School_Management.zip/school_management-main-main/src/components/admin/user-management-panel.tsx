"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
} from "react";

import { ROLE_DEFINITIONS } from "@/constants/roles";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type ManagedRole =
  | "USER"
  | "SUPER_ADMIN"
  | "ADMIN"
  | "ACCOUNTANT"
  | "ACADEMIC_ADMIN"
  | "ADMISSION_ADMIN"
  | "TEACHER"
  | "STUDENT";

type ManagedUser = {
  id: string;
  name: string;
  email: string;
  role: ManagedRole;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
};

type UserStats = {
  total: number;
  active: number;
  deleted: number;
  roleCounts: Record<ManagedRole, number>;
};

type UserListResponse = {
  users: ManagedUser[];
  stats: UserStats;
  allowedRoles: ManagedRole[];
};

type EditForm = {
  name: string;
  email: string;
  password: string;
  role: ManagedRole;
};

const emptyStats: UserStats = {
  total: 0,
  active: 0,
  deleted: 0,
  roleCounts: {
    USER: 0,
    SUPER_ADMIN: 0,
    ADMIN: 0,
    ACCOUNTANT: 0,
    ACADEMIC_ADMIN: 0,
    ADMISSION_ADMIN: 0,
    TEACHER: 0,
    STUDENT: 0,
  },
};

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export function UserManagementPanel() {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [stats, setStats] = useState<UserStats>(emptyStats);
  const [allowedRoles, setAllowedRoles] = useState<ManagedRole[]>([]);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<ManagedRole | "ALL">("ALL");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<EditForm | null>(null);

  const availableRoles = useMemo(() => {
    if (allowedRoles.length > 0) {
      return allowedRoles;
    }

    return [
      "USER",
      "ADMIN",
      "ACCOUNTANT",
      "ACADEMIC_ADMIN",
      "ADMISSION_ADMIN",
      "TEACHER",
      "STUDENT",
    ] satisfies ManagedRole[];
  }, [allowedRoles]);

  useEffect(() => {
    setAuthState(readAuth());
  }, []);

  const loadUsers = useCallback(
    async (
      nextAuthState: AuthStorage,
      currentSearch = search,
      currentRole = roleFilter,
    ) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim());
        }
        if (currentRole !== "ALL") {
          params.set("role", currentRole);
        }

        const response = await fetch(`/api/v1/users?${params.toString()}`, {
          headers: {
            Authorization: `Bearer ${nextAuthState.token}`,
          },
        });

        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load users");
        }

        const data = json.data as UserListResponse;
        setUsers(data.users);
        setStats(data.stats);
        setAllowedRoles(data.allowedRoles);
      } catch (exception) {
        console.error(exception);
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load users",
        );
      } finally {
        setLoading(false);
      }
    },
    [roleFilter, search],
  );

  useEffect(() => {
    if (!authState) {
      return;
    }

    void loadUsers(authState);
  }, [authState, loadUsers]);

  const handleSearchSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!authState) {
      return;
    }

    await loadUsers(authState);
  };

  const startEditing = (user: ManagedUser) => {
    setEditingId(user.id);
    setEditForm({
      name: user.name,
      email: user.email,
      password: "",
      role: user.role,
    });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const handleUpdateUser = async (userId: string) => {
    if (!authState || !editForm) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const payload: Record<string, string> = {
        name: editForm.name,
        email: editForm.email,
        role: editForm.role,
      };

      if (editForm.password.trim()) {
        payload.password = editForm.password;
      }

      const response = await fetch(`/api/v1/users/${userId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(payload),
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update user");
      }

      cancelEditing();
      await loadUsers(authState);
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update user",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeactivateUser = async (userId: string) => {
    if (!authState) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/users/${userId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${authState.token}`,
        },
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to deactivate user");
      }

      if (editingId === userId) {
        cancelEditing();
      }

      await loadUsers(authState);
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to deactivate user",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary px-6 py-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Identity
        </p>
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold">User directory</h1>
          <p className="max-w-3xl text-sm text-slate-200">
            Manage the full school user directory, including administrators,
            teachers, students, and guardians. Super admins can manage every role,
            while admins can manage delegated users within their scope.
          </p>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader>
            <CardDescription>Total records</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Active accounts</CardDescription>
            <CardTitle>{stats.active}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Deactivated</CardDescription>
            <CardTitle>{stats.deleted}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Your scope</CardDescription>
            <CardTitle>
              {authState
                ? ROLE_DEFINITIONS[authState.user.role].label
                : "Loading"}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Directory</CardTitle>
            <CardDescription>
              Search, update, and deactivate the administrative accounts in your
              scope.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-3 md:grid-cols-[1fr_180px_auto]"
              onSubmit={handleSearchSubmit}
            >
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by name or email"
              />
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={roleFilter}
                onChange={(event) =>
                  setRoleFilter(event.target.value as ManagedRole | "ALL")
                }
              >
                <option value="ALL">All roles</option>
                {availableRoles.map((role) => (
                  <option key={role} value={role}>
                    {ROLE_DEFINITIONS[role].label}
                  </option>
                ))}
              </select>
              <Button type="submit" variant="outline" disabled={loading}>
                Filter
              </Button>
            </form>

            {error && (
              <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                {error}
              </div>
            )}

            {loading ? (
              <p className="text-xs text-muted-foreground">Loading accounts…</p>
            ) : users.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                No users matched the current filter.
              </p>
            ) : (
              <div className="space-y-3">
                {users.map((user) => {
                  const isEditing = editingId === user.id && editForm !== null;

                  return (
                    <article
                      key={user.id}
                      className="space-y-3 rounded-none border border-border bg-background/60 p-4"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge
                          variant={user.isDeleted ? "destructive" : "secondary"}
                        >
                          {user.isDeleted ? "Deactivated" : "Active"}
                        </Badge>
                        <Badge variant="outline">
                          {ROLE_DEFINITIONS[user.role].label}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          Created {formatDate(user.createdAt)}
                        </span>
                      </div>

                      {isEditing ? (
                        <div className="grid gap-3 md:grid-cols-2">
                          <div className="space-y-2">
                            <Label htmlFor={`name-${user.id}`}>Name</Label>
                            <Input
                              id={`name-${user.id}`}
                              value={editForm.name}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, name: event.target.value }
                                    : prev,
                                )
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`email-${user.id}`}>Email</Label>
                            <Input
                              id={`email-${user.id}`}
                              type="email"
                              value={editForm.email}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, email: event.target.value }
                                    : prev,
                                )
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`role-${user.id}`}>Role</Label>
                            <select
                              id={`role-${user.id}`}
                              className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                              value={editForm.role}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        role: event.target.value as ManagedRole,
                                      }
                                    : prev,
                                )
                              }
                            >
                              {availableRoles.map((role) => (
                                <option key={role} value={role}>
                                  {ROLE_DEFINITIONS[role].label}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`password-${user.id}`}>
                              New password
                            </Label>
                            <Input
                              id={`password-${user.id}`}
                              type="password"
                              minLength={8}
                              value={editForm.password}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, password: event.target.value }
                                    : prev,
                                )
                              }
                              placeholder="Leave blank to keep current password"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <h3 className="text-sm font-semibold text-foreground">
                            {user.name}
                          </h3>
                          <p className="text-xs text-muted-foreground">
                            {user.email}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Last updated {formatDate(user.updatedAt)}
                          </p>
                        </div>
                      )}

                      <div className="flex flex-wrap gap-2">
                        {isEditing ? (
                          <>
                            <Button
                              size="sm"
                              onClick={() => void handleUpdateUser(user.id)}
                              disabled={submitting}
                              type="button"
                            >
                              {submitting ? "Saving…" : "Save changes"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={cancelEditing}
                              type="button"
                            >
                              Cancel
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => startEditing(user)}
                              type="button"
                              disabled={user.isDeleted}
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => void handleDeactivateUser(user.id)}
                              type="button"
                              disabled={submitting || user.isDeleted}
                            >
                              Deactivate
                            </Button>
                          </>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
