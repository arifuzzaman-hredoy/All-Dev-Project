"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
} from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";

type GroupOption = {
  id: string;
  name: string;
  studentLimit: number | null;
  activeStudentCount: number;
};
type ClassOption = {
  id: string;
  name: string;
  studentLimit: number | null;
  activeStudentCount: number;
  groups: GroupOption[];
};
type BasicClassOption = { id: string; name: string };
type StudentRecord = {
  id: string;
  rollNumber: number | null;
  phone: string | null;
  gender: "MALE" | "FEMALE" | "OTHER";
  placementStatus: "ACTIVE" | "WAITING_LIST";
  isDeleted: boolean;
  createdAt: string;
  class: BasicClassOption;
  group: { id: string; name: string } | null;
  section: { id: string; name: string } | null;
  user: { id: string; name: string; email: string };
};

type StudentResponse = {
  students: StudentRecord[];
  classes: ClassOption[];
  stats: { total: number; active: number; waitingList: number; deleted: number };
  pagination: { page: number; pageSize: number; total: number; totalPages: number };
};

type CreateForm = {
  name: string;
  email: string;
  password: string;
  phone: string;
  gender: "MALE" | "FEMALE" | "OTHER";
  classId: string;
  groupId: string;
  guardianName: string;
  guardianEmail: string;
  guardianPhone: string;
  guardianAddress: string;
  guardianRelation: string;
  fatherName: string;
  fatherPhone: string;
  motherName: string;
  motherPhone: string;
  nidNumber: string;
  nidImage: string;
  profileImage: string;
  fatherNidNumber: string;
  fatherNidImage: string;
  motherNidNumber: string;
  motherNidImage: string;
};

type EditForm = {
  name: string;
  email: string;
  phone: string;
  gender: "MALE" | "FEMALE" | "OTHER";
  classId: string;
  rollNumber: string;
};

type PasswordForm = {
  password: string;
};

const PASSWORD_CHARACTERS =
  "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*";

function generatePassword(length = 12) {
  const randomValues = new Uint32Array(length);
  globalThis.crypto.getRandomValues(randomValues);

  return Array.from(
    randomValues,
    (value) => PASSWORD_CHARACTERS[value % PASSWORD_CHARACTERS.length],
  ).join("");
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

type CreateFileField =
  | "nidImage"
  | "profileImage"
  | "fatherNidImage"
  | "motherNidImage";

export function StudentManagementPanel({
  mode = "all",
}: {
  mode?: "all" | "create" | "view"
}) {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [classes, setClasses] = useState<ClassOption[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    waitingList: 0,
    deleted: 0,
  });
  const [search, setSearch] = useState("");
  const [classFilter, setClassFilter] = useState<string>("ALL");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [pagination, setPagination] = useState<StudentResponse["pagination"]>({
    page: 1,
    pageSize: 20,
    total: 0,
    totalPages: 1,
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<EditForm | null>(null);
  const [passwordTarget, setPasswordTarget] = useState<StudentRecord | null>(
    null,
  );
  const [passwordForm, setPasswordForm] = useState<PasswordForm>({
    password: "",
  });
  const [createForm, setCreateForm] = useState<CreateForm>({
    name: "",
    email: "",
    password: generatePassword(),
    phone: "",
    gender: "MALE",
    classId: "",
    groupId: "",
    guardianName: "",
    guardianEmail: "",
    guardianPhone: "",
    guardianAddress: "",
    guardianRelation: "",
    fatherName: "",
    fatherPhone: "",
    motherName: "",
    motherPhone: "",
    nidNumber: "",
    nidImage: "",
    profileImage: "",
    fatherNidNumber: "",
    fatherNidImage: "",
    motherNidNumber: "",
    motherNidImage: "",
  });

  const readFileAsDataUrl = (file: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });

  const handleCreateFileChange = async (field: CreateFileField, file?: File) => {
    if (!file) {
      setCreateForm((prev) => ({ ...prev, [field]: "" }));
      return;
    }

    try {
      const dataUrl = await readFileAsDataUrl(file);
      setCreateForm((prev) => ({ ...prev, [field]: dataUrl }));
    } catch {
      setError("Unable to read the selected image");
    }
  };

  useEffect(() => {
    setAuthState(readAuth());
  }, []);

  const loadStudents = useCallback(
    async (
      nextAuthState: AuthStorage,
      currentSearch = search,
      currentClass = classFilter,
      currentPage = page,
    ) => {
      setLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        if (currentSearch.trim()) {
          params.set("search", currentSearch.trim());
        }
        if (currentClass !== "ALL") {
          params.set("classId", currentClass);
        }
        params.set("page", String(currentPage));
        params.set("pageSize", String(pageSize));

        const response = await fetch(`/api/v1/students?${params.toString()}`, {
          headers: {
            Authorization: `Bearer ${nextAuthState.token}`,
          },
        });
        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load students");
        }

        const data = json.data as StudentResponse;
        setStudents(data.students);
        setClasses(data.classes);
        setStats(data.stats);
        setPagination(data.pagination);
        setPage(data.pagination.page);
        setCreateForm((prev) => ({
          ...prev,
          classId: prev.classId || data.classes[0]?.id || "",
          groupId:
            prev.groupId ||
            data.classes.find((item) => item.id === prev.classId)?.groups[0]
              ?.id ||
            data.classes[0]?.groups[0]?.id ||
            "",
        }));
      } catch (exception) {
        console.error(exception);
        setError(
          exception instanceof Error
            ? exception.message
            : "Unable to load students",
        );
      } finally {
        setLoading(false);
      }
    },
    [classFilter, page, pageSize, search],
  );

  useEffect(() => {
    if (!authState) return;
    void loadStudents(authState);
  }, [authState, loadStudents]);

  const refresh = async () => {
    if (authState) {
      await loadStudents(authState, search, classFilter, page);
    }
  };

  const selectedCreateClass = useMemo(
    () => classes.find((item) => item.id === createForm.classId) ?? null,
    [classes, createForm.classId],
  );

  const selectedCreateGroup = useMemo(
    () =>
      selectedCreateClass?.groups.find((item) => item.id === createForm.groupId) ??
      null,
    [createForm.groupId, selectedCreateClass],
  );

  const classFull =
    selectedCreateClass?.studentLimit !== null &&
    selectedCreateClass?.studentLimit !== undefined &&
    selectedCreateClass.activeStudentCount >= selectedCreateClass.studentLimit;
  const groupFull =
    selectedCreateGroup?.studentLimit !== null &&
    selectedCreateGroup?.studentLimit !== undefined &&
    selectedCreateGroup.activeStudentCount >= selectedCreateGroup.studentLimit;
  const willJoinWaitingList = Boolean(classFull || groupFull);

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!authState) return;

    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/v1/students", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify(createForm),
      });
      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to create student");
      }

      setCreateForm({
        name: "",
        email: "",
        password: generatePassword(),
        phone: "",
        gender: "MALE",
        classId: classes[0]?.id || "",
        groupId: classes[0]?.groups[0]?.id || "",
        guardianName: "",
        guardianEmail: "",
        guardianPhone: "",
        guardianAddress: "",
        guardianRelation: "",
        fatherName: "",
        fatherPhone: "",
        motherName: "",
        motherPhone: "",
        nidNumber: "",
        nidImage: "",
        profileImage: "",
        fatherNidNumber: "",
        fatherNidImage: "",
        motherNidNumber: "",
        motherNidImage: "",
      });
      if (json?.data?.credentialEmail?.sent === false) {
        setError(
          "Student created, but credentials email could not be sent. Check email settings.",
        );
      }
      await refresh();
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to create student",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const startEditing = (student: StudentRecord) => {
    setEditingId(student.id);
    setEditForm({
      name: student.user.name,
      email: student.user.email,
      phone: student.phone ?? "",
      gender: student.gender,
      classId: student.class.id,
      rollNumber: student.rollNumber?.toString() ?? "",
    });
  };

  const startPasswordUpdate = (student: StudentRecord) => {
    setPasswordTarget(student);
    setPasswordForm({
      password: generatePassword(),
    });
  };

  const closePasswordUpdate = () => {
    setPasswordTarget(null);
    setPasswordForm({
      password: "",
    });
  };

  const regeneratePassword = () => {
    setPasswordForm({
      password: generatePassword(),
    });
  };

  const handleUpdate = async (studentId: string) => {
    if (!authState || !editForm) return;

    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/students/${studentId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          ...editForm,
          rollNumber: editForm.rollNumber ? Number(editForm.rollNumber) : null,
        }),
      });
      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update student");
      }

      setEditingId(null);
      setEditForm(null);
      await refresh();
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update student",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handlePasswordUpdate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!authState || !passwordTarget) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/students/${passwordTarget.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authState.token}`,
        },
        body: JSON.stringify({
          password: passwordForm.password,
        }),
      });
      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to update student password");
      }

      closePasswordUpdate();
      await refresh();
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to update student password",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (studentId: string) => {
    if (!authState) return;

    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch(`/api/v1/students/${studentId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${authState.token}`,
        },
      });
      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message ?? "Unable to deactivate student");
      }

      await refresh();
    } catch (exception) {
      console.error(exception);
      setError(
        exception instanceof Error
          ? exception.message
          : "Unable to deactivate student",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 px-6 py-6">
      <section className="rounded-3xl border border-white/10 bg-primary p-6 text-white shadow-lg shadow-slate-900/40">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
          Academics
        </p>
        <h1 className="text-2xl font-semibold">Student management</h1>
        <p className="max-w-3xl text-sm text-slate-200">
          Create student accounts, assign classes, and keep enrollment records
          clean.
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-4">
        <Card>
          <CardHeader>
            <CardDescription>Total</CardDescription>
            <CardTitle>{stats.total}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Active</CardDescription>
            <CardTitle>{stats.active}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Waiting list</CardDescription>
            <CardTitle>{stats.waitingList}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Deactivated</CardDescription>
            <CardTitle>{stats.deleted}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div
        className={
          mode === "create"
            ? "grid gap-6 xl:grid-cols-1"
            : mode === "view"
              ? "grid gap-6 xl:grid-cols-1"
              : "grid gap-6 xl:grid-cols-[1fr_1.4fr]"
        }
      >
        {mode !== "view" ? (
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Add student</CardTitle>
              <CardDescription>
                Create a student portal account and class assignment.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleCreate}>
                <div className="space-y-2">
                  <Label htmlFor="student-name">Name</Label>
                  <Input
                    id="student-name"
                    value={createForm.name}
                    onChange={(event) =>
                      setCreateForm((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-email">Email</Label>
                  <Input
                    id="student-email"
                    type="email"
                    value={createForm.email}
                    onChange={(event) =>
                      setCreateForm((prev) => ({
                        ...prev,
                        email: event.target.value,
                      }))
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-password">Password</Label>
                  <Input
                    id="student-password"
                    type="text"
                    minLength={8}
                    autoComplete="new-password"
                    spellCheck={false}
                    value={createForm.password}
                    onChange={(event) =>
                      setCreateForm((prev) => ({
                        ...prev,
                        password: event.target.value,
                      }))
                    }
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setCreateForm((prev) => ({
                          ...prev,
                          password: generatePassword(),
                        }))
                      }
                    >
                      Generate password
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Credentials are emailed to the student&apos;s email.
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-phone">Phone</Label>
                  <Input
                    id="student-phone"
                    value={createForm.phone}
                    onChange={(event) =>
                      setCreateForm((prev) => ({
                        ...prev,
                        phone: event.target.value,
                      }))
                    }
                  />
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="student-gender">Gender</Label>
                    <select
                      id="student-gender"
                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={createForm.gender}
                      onChange={(event) =>
                        setCreateForm((prev) => ({
                          ...prev,
                          gender: event.target.value as CreateForm["gender"],
                        }))
                      }
                    >
                      <option value="MALE">Male</option>
                      <option value="FEMALE">Female</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-class">Class</Label>
                    <select
                      id="student-class"
                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={createForm.classId}
                      onChange={(event) =>
                        setCreateForm((prev) => ({
                          ...prev,
                          classId: event.target.value,
                          groupId:
                            classes.find(
                              (item) => item.id === event.target.value,
                            )?.groups[0]?.id || "",
                        }))
                      }
                    >
                      {classes.map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-group">Group</Label>
                    <select
                      id="student-group"
                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                      value={createForm.groupId}
                      onChange={(event) =>
                        setCreateForm((prev) => ({
                          ...prev,
                          groupId: event.target.value,
                        }))
                      }
                      disabled={!selectedCreateClass?.groups.length}
                    >
                      {selectedCreateClass?.groups.length ? (
                        selectedCreateClass.groups.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name}
                          </option>
                        ))
                      ) : (
                        <option value="">No groups available</option>
                      )}
                    </select>
                  </div>
                </div>
                {selectedCreateClass ? (
                  <div className="rounded-none border border-border bg-muted/20 p-3 text-xs">
                    <div className="grid gap-2 md:grid-cols-2">
                      <div>
                        <p className="font-medium text-foreground">
                          {selectedCreateClass.name}
                        </p>
                        <p className="text-muted-foreground">
                          Active {selectedCreateClass.activeStudentCount} /{" "}
                          {selectedCreateClass.studentLimit ?? "Unlimited"}
                        </p>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">
                          {selectedCreateGroup?.name ?? "No group selected"}
                        </p>
                        <p className="text-muted-foreground">
                          Active {selectedCreateGroup?.activeStudentCount ?? 0} /{" "}
                          {selectedCreateGroup?.studentLimit ?? "Unlimited"}
                        </p>
                      </div>
                    </div>
                    {selectedCreateClass.groups.length > 0 ? (
                      <div className="mt-3 grid gap-2 md:grid-cols-3">
                        {selectedCreateClass.groups.map((group) => (
                          <div
                            key={group.id}
                            className="rounded-md bg-background px-3 py-2"
                          >
                            <p className="font-medium text-foreground">
                              {group.name}
                            </p>
                            <p className="text-muted-foreground">
                              {group.activeStudentCount} /{" "}
                              {group.studentLimit ?? "Unlimited"}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : null}
                    {willJoinWaitingList ? (
                      <p className="mt-3 text-amber-700">
                        Capacity is full. This student will be created in the
                        waiting list for the selected placement.
                      </p>
                    ) : null}
                  </div>
                ) : null}
                <div className="space-y-3 rounded-none border border-border bg-muted/20 p-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Guardian Info</p>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="student-guardian-name">Guardian name</Label>
                      <Input id="student-guardian-name" value={createForm.guardianName} onChange={(event) => setCreateForm((prev) => ({ ...prev, guardianName: event.target.value }))} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-guardian-email">Guardian email</Label>
                      <Input id="student-guardian-email" type="email" value={createForm.guardianEmail} onChange={(event) => setCreateForm((prev) => ({ ...prev, guardianEmail: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-guardian-phone">Guardian phone</Label>
                      <Input id="student-guardian-phone" value={createForm.guardianPhone} onChange={(event) => setCreateForm((prev) => ({ ...prev, guardianPhone: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-guardian-relation">Guardian relation</Label>
                      <Input id="student-guardian-relation" value={createForm.guardianRelation} onChange={(event) => setCreateForm((prev) => ({ ...prev, guardianRelation: event.target.value }))} />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="student-guardian-address">Guardian address</Label>
                      <Input id="student-guardian-address" value={createForm.guardianAddress} onChange={(event) => setCreateForm((prev) => ({ ...prev, guardianAddress: event.target.value }))} />
                    </div>
                  </div>
                </div>
                <div className="space-y-3 rounded-none border border-border bg-muted/20 p-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Identity &amp; Media</p>
                  <div className="space-y-2">
                    <Label htmlFor="student-nid-number">Student NID number</Label>
                    <Input id="student-nid-number" value={createForm.nidNumber} onChange={(event) => setCreateForm((prev) => ({ ...prev, nidNumber: event.target.value }))} required />
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="student-nid-image">Student NID image</Label>
                      <Input id="student-nid-image" type="file" accept="image/*" onChange={(event) => void handleCreateFileChange("nidImage", event.target.files?.[0])} required />
                      {createForm.nidImage ? (
                        <p className="text-xs text-muted-foreground">Student NID attached</p>
                      ) : null}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-profile-image">Student photo</Label>
                      <Input id="student-profile-image" type="file" accept="image/*" onChange={(event) => void handleCreateFileChange("profileImage", event.target.files?.[0])} required />
                      {createForm.profileImage ? (
                        <p className="text-xs text-muted-foreground">Student photo attached</p>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div className="space-y-3 rounded-none border border-border bg-muted/20 p-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Father / Mother Info</p>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="student-father-name">Father name</Label>
                      <Input id="student-father-name" value={createForm.fatherName} onChange={(event) => setCreateForm((prev) => ({ ...prev, fatherName: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-father-phone">Father phone</Label>
                      <Input id="student-father-phone" value={createForm.fatherPhone} onChange={(event) => setCreateForm((prev) => ({ ...prev, fatherPhone: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-father-nid-number">Father NID number</Label>
                      <Input id="student-father-nid-number" value={createForm.fatherNidNumber} onChange={(event) => setCreateForm((prev) => ({ ...prev, fatherNidNumber: event.target.value }))} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-father-nid-image">Father NID image</Label>
                      <Input id="student-father-nid-image" type="file" accept="image/*" onChange={(event) => void handleCreateFileChange("fatherNidImage", event.target.files?.[0])} required />
                      {createForm.fatherNidImage ? (
                        <p className="text-xs text-muted-foreground">Father NID attached</p>
                      ) : null}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-mother-name">Mother name</Label>
                      <Input id="student-mother-name" value={createForm.motherName} onChange={(event) => setCreateForm((prev) => ({ ...prev, motherName: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-mother-phone">Mother phone</Label>
                      <Input id="student-mother-phone" value={createForm.motherPhone} onChange={(event) => setCreateForm((prev) => ({ ...prev, motherPhone: event.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-mother-nid-number">Mother NID number</Label>
                      <Input id="student-mother-nid-number" value={createForm.motherNidNumber} onChange={(event) => setCreateForm((prev) => ({ ...prev, motherNidNumber: event.target.value }))} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-mother-nid-image">Mother NID image</Label>
                      <Input id="student-mother-nid-image" type="file" accept="image/*" onChange={(event) => void handleCreateFileChange("motherNidImage", event.target.files?.[0])} required />
                      {createForm.motherNidImage ? (
                        <p className="text-xs text-muted-foreground">Mother NID attached</p>
                      ) : null}
                    </div>
                  </div>
                </div>
                <Button type="submit" disabled={submitting}>
                  {submitting ? "Saving…" : "Create student"}
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : null}

        {mode !== "create" ? (
          <Card>
            <CardHeader>
              <CardTitle>Roster</CardTitle>
              <CardDescription>
                Filter and maintain current student records.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
            <form
              className="grid gap-3 md:grid-cols-[1fr_180px_auto]"
              onSubmit={(event) => {
                event.preventDefault();
                void refresh();
              }}
            >
              <Input
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setPage(1);
                }}
                placeholder="Search by name, email, phone"
              />
              <select
                className="h-8 rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                value={classFilter}
                onChange={(event) => {
                  setClassFilter(event.target.value);
                  setPage(1);
                }}
              >
                <option value="ALL">All classes</option>
                {classes.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <Button type="submit" variant="outline">
                Filter
              </Button>
            </form>

            {error && (
              <div className="rounded-none border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                {error}
              </div>
            )}
            {loading ? (
              <p className="text-xs text-muted-foreground">Loading students…</p>
            ) : (
              <>
                {/* Mobile / small devices: cards */}
                <div className="space-y-3 lg:hidden">
                  {students.map((student) => {
                    const isEditing =
                      editingId === student.id && editForm !== null;
                    return (
                      <article
                        key={student.id}
                        className="space-y-3 rounded-none border border-border bg-background/60 p-4"
                      >
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge
                            variant={
                              student.isDeleted ? "destructive" : "secondary"
                            }
                          >
                            {student.isDeleted ? "Deactivated" : "Active"}
                          </Badge>
                          {student.placementStatus === "WAITING_LIST" ? (
                            <Badge variant="outline">Waiting list</Badge>
                          ) : null}
                          <Badge variant="outline">{student.class.name}</Badge>
                          <span className="text-xs text-muted-foreground">
                            Created {formatDate(student.createdAt)}
                          </span>
                        </div>

                        {isEditing ? (
                          <div className="grid gap-3 md:grid-cols-2">
                            <Input
                              value={editForm.name}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, name: event.target.value }
                                    : prev,
                                )
                              }
                            />
                            <Input
                              type="email"
                              value={editForm.email}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, email: event.target.value }
                                    : prev,
                                )
                              }
                            />
                            <Input
                              value={editForm.phone}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, phone: event.target.value }
                                    : prev,
                                )
                              }
                            />
                            <select
                              className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                              value={editForm.gender}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        gender: event.target
                                          .value as EditForm["gender"],
                                      }
                                    : prev,
                                )
                              }
                            >
                              <option value="MALE">Male</option>
                              <option value="FEMALE">Female</option>
                              <option value="OTHER">Other</option>
                            </select>
                            <select
                              className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                              value={editForm.classId}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? { ...prev, classId: event.target.value }
                                    : prev,
                                )
                              }
                            >
                              {classes.map((item) => (
                                <option key={item.id} value={item.id}>
                                  {item.name}
                                </option>
                              ))}
                            </select>
                            <Input
                              value={editForm.rollNumber}
                              onChange={(event) =>
                                setEditForm((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        rollNumber: event.target.value,
                                      }
                                    : prev,
                                )
                              }
                              placeholder="Roll number"
                            />
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <h3 className="text-sm font-semibold text-foreground">
                              {student.user.name}
                            </h3>
                            <p className="text-xs text-muted-foreground">
                              {student.user.email}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Roll {student.rollNumber ?? "Auto"} ·{" "}
                              {student.gender} ·{" "}
                              {student.placementStatus === "WAITING_LIST"
                                ? "Waiting list · "
                                : ""}
                              {student.group?.name ?? "General"} /{" "}
                              {student.section?.name ?? "A"}
                            </p>
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2">
                          {isEditing ? (
                            <>
                              <Button
                                size="sm"
                                onClick={() => void handleUpdate(student.id)}
                                type="button"
                                disabled={submitting}
                              >
                                {submitting ? "Saving…" : "Save changes"}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingId(null);
                                  setEditForm(null);
                                }}
                                type="button"
                              >
                                Cancel
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startEditing(student)}
                                type="button"
                                disabled={student.isDeleted}
                              >
                                Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startPasswordUpdate(student)}
                                type="button"
                                disabled={student.isDeleted}
                              >
                                Update password
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => void handleDelete(student.id)}
                                type="button"
                                disabled={submitting || student.isDeleted}
                              >
                                Deactivate
                              </Button>
                            </>
                          )}
                        </div>
                      </article>
                    );
                  })}
                </div>

                {/* Large devices: table */}
                <div className="hidden lg:block">
                  <div className="overflow-x-auto rounded-none border border-border">
                    <table className="min-w-full text-sm">
                      <thead className="bg-muted/30 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        <tr>
                          <th className="px-3 py-3 text-left font-semibold">
                            Status
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Student
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Class
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Roll
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Gender
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Group / Section
                          </th>
                          <th className="px-3 py-3 text-left font-semibold">
                            Created
                          </th>
                          <th className="px-3 py-3 text-right font-semibold">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {students.length === 0 ? (
                          <tr>
                            <td
                              colSpan={8}
                              className="px-3 py-6 text-center text-xs text-muted-foreground"
                            >
                              No students found.
                            </td>
                          </tr>
                        ) : (
                          students.map((student) => {
                            const isEditing =
                              editingId === student.id && editForm !== null;

                            return (
                              <tr key={student.id} className="align-top">
                                <td className="px-3 py-3">
                                  <Badge
                                    variant={
                                      student.isDeleted
                                        ? "destructive"
                                        : "secondary"
                                    }
                                  >
                                    {student.isDeleted
                                      ? "Deactivated"
                                      : "Active"}
                                  </Badge>
                                  {student.placementStatus === "WAITING_LIST" ? (
                                    <Badge variant="outline" className="mt-1">
                                      Waiting list
                                    </Badge>
                                  ) : null}
                                </td>
                                <td className="px-3 py-3">
                                  {isEditing ? (
                                    <div className="grid gap-2">
                                      <Input
                                        value={editForm.name}
                                        onChange={(event) =>
                                          setEditForm((prev) =>
                                            prev
                                              ? {
                                                  ...prev,
                                                  name: event.target.value,
                                                }
                                              : prev,
                                          )
                                        }
                                      />
                                      <Input
                                        type="email"
                                        value={editForm.email}
                                        onChange={(event) =>
                                          setEditForm((prev) =>
                                            prev
                                              ? {
                                                  ...prev,
                                                  email: event.target.value,
                                                }
                                              : prev,
                                          )
                                        }
                                      />
                                      <Input
                                        value={editForm.phone}
                                        onChange={(event) =>
                                          setEditForm((prev) =>
                                            prev
                                              ? {
                                                  ...prev,
                                                  phone: event.target.value,
                                                }
                                              : prev,
                                          )
                                        }
                                        placeholder="Phone"
                                      />
                                    </div>
                                  ) : (
                                    <div>
                                      <p className="font-medium text-foreground">
                                        {student.user.name}
                                      </p>
                                      <p className="text-xs text-muted-foreground">
                                        {student.user.email}
                                      </p>
                                      {student.phone ? (
                                        <p className="text-xs text-muted-foreground">
                                          {student.phone}
                                        </p>
                                      ) : null}
                                    </div>
                                  )}
                                </td>
                                <td className="px-3 py-3">
                                  {isEditing ? (
                                    <select
                                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                                      value={editForm.classId}
                                      onChange={(event) =>
                                        setEditForm((prev) =>
                                          prev
                                            ? {
                                                ...prev,
                                                classId: event.target.value,
                                              }
                                            : prev,
                                        )
                                      }
                                    >
                                      {classes.map((item) => (
                                        <option key={item.id} value={item.id}>
                                          {item.name}
                                        </option>
                                      ))}
                                    </select>
                                  ) : (
                                    <Badge variant="outline">
                                      {student.class.name}
                                    </Badge>
                                  )}
                                </td>
                                <td className="px-3 py-3">
                                  {isEditing ? (
                                    <Input
                                      value={editForm.rollNumber}
                                      onChange={(event) =>
                                        setEditForm((prev) =>
                                          prev
                                            ? {
                                                ...prev,
                                                rollNumber: event.target.value,
                                              }
                                            : prev,
                                        )
                                      }
                                      placeholder="Auto"
                                    />
                                  ) : (
                                    <span className="text-foreground">
                                      {student.rollNumber ?? "Auto"}
                                    </span>
                                  )}
                                </td>
                                <td className="px-3 py-3">
                                  {isEditing ? (
                                    <select
                                      className="h-8 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-xs"
                                      value={editForm.gender}
                                      onChange={(event) =>
                                        setEditForm((prev) =>
                                          prev
                                            ? {
                                                ...prev,
                                                gender: event.target
                                                  .value as EditForm["gender"],
                                              }
                                            : prev,
                                        )
                                      }
                                    >
                                      <option value="MALE">Male</option>
                                      <option value="FEMALE">Female</option>
                                      <option value="OTHER">Other</option>
                                    </select>
                                  ) : (
                                    <span className="text-foreground">
                                      {student.gender}
                                    </span>
                                  )}
                                </td>
                                <td className="px-3 py-3">
                                  <span className="text-foreground">
                                    {student.group?.name ?? "General"} /{" "}
                                    {student.section?.name ?? "A"}
                                  </span>
                                </td>
                                <td className="px-3 py-3">
                                  <span className="text-xs text-muted-foreground">
                                    {formatDate(student.createdAt)}
                                  </span>
                                </td>
                                <td className="px-3 py-3">
                                  <div className="flex justify-end gap-2">
                                    {isEditing ? (
                                      <>
                                        <Button
                                          size="sm"
                                          onClick={() =>
                                            void handleUpdate(student.id)
                                          }
                                          type="button"
                                          disabled={submitting}
                                        >
                                          {submitting ? "Saving…" : "Save"}
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => {
                                            setEditingId(null);
                                            setEditForm(null);
                                          }}
                                          type="button"
                                        >
                                          Cancel
                                        </Button>
                                      </>
                                    ) : (
                                      <>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => startEditing(student)}
                                          type="button"
                                          disabled={student.isDeleted}
                                        >
                                          Edit
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() =>
                                            startPasswordUpdate(student)
                                          }
                                          type="button"
                                          disabled={student.isDeleted}
                                        >
                                          Password
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="destructive"
                                          onClick={() =>
                                            void handleDelete(student.id)
                                          }
                                          type="button"
                                          disabled={
                                            submitting || student.isDeleted
                                          }
                                        >
                                          Deactivate
                                        </Button>
                                      </>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <p className="text-xs text-muted-foreground">
                    Showing page {pagination.page} of {pagination.totalPages} ·{" "}
                    {pagination.total} students
                  </p>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={loading || pagination.page <= 1}
                      onClick={() => {
                        const nextPage = Math.max(1, pagination.page - 1);
                        setPage(nextPage);
                        if (authState) {
                          void loadStudents(authState, search, classFilter, nextPage);
                        }
                      }}
                    >
                      Prev
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={loading || pagination.page >= pagination.totalPages}
                      onClick={() => {
                        const nextPage = Math.min(
                          pagination.totalPages,
                          pagination.page + 1,
                        );
                        setPage(nextPage);
                        if (authState) {
                          void loadStudents(authState, search, classFilter, nextPage);
                        }
                      }}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        ) : null}
      </div>

      {passwordTarget ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 px-4 py-6 backdrop-blur-sm"
          role="presentation"
          onClick={closePasswordUpdate}
        >
          <div
            className="w-full max-w-lg rounded-3xl border border-border bg-background p-6 shadow-2xl shadow-slate-950/40"
            role="dialog"
            aria-modal="true"
            aria-labelledby="student-password-dialog-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
                Security
              </p>
              <h2
                id="student-password-dialog-title"
                className="text-xl font-semibold text-foreground"
              >
                Update student password
              </h2>
              <p className="text-sm text-muted-foreground">
                Change the password for {passwordTarget.user.name} (
                {passwordTarget.user.email}). You can type a custom value or
                generate a secure one.
              </p>
            </div>

            <form className="mt-6 space-y-4" onSubmit={handlePasswordUpdate}>
              <div className="space-y-2">
                <Label htmlFor="student-new-password">New password</Label>
                <Input
                  id="student-new-password"
                  type="text"
                  autoComplete="new-password"
                  spellCheck={false}
                  minLength={8}
                  value={passwordForm.password}
                  onChange={(event) =>
                    setPasswordForm({ password: event.target.value })
                  }
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Use a minimum of 8 characters. Generated passwords are ready
                  to save immediately.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={regeneratePassword}
                >
                  Generate new password
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={closePasswordUpdate}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? "Saving…" : "Save password"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  );
}
