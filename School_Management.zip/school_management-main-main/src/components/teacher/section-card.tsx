import { ReactNode } from "react"

import { cn } from "@/lib/utils"

type TeacherSectionCardProps = {
  children: ReactNode
  title?: ReactNode
  description?: ReactNode
  className?: string
}

export function TeacherSectionCard({
  children,
  title,
  description,
  className,
}: TeacherSectionCardProps) {
  return (
    <section
      className={cn(
        "rounded-2xl border border-border bg-background p-4 shadow-sm transition-shadow hover:shadow"
        + " focus-visible:ring-1 focus-visible:ring-ring/50",
        className
      )}
    >
      {(title || description) && (
        <header className="mb-3 space-y-1">
          {title && (
            <p className="text-lg font-semibold text-foreground">{title}</p>
          )}
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </header>
      )}
      <div className="space-y-4">{children}</div>
    </section>
  )
}
