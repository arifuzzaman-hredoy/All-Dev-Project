import { ReactNode } from "react"

import { cn } from "@/lib/utils"

type TeacherPageShellProps = {
  children: ReactNode
  header?: ReactNode
  className?: string
}

export function TeacherPageShell({
  children,
  header,
  className,
}: TeacherPageShellProps) {
  return (
    <div className={cn("flex-1 min-w-0 overflow-x-hidden", className)}>
      <div className="max-w-5xl mx-auto px-4 py-5 space-y-5">
        {header}
        {children}
      </div>
    </div>
  )
}
