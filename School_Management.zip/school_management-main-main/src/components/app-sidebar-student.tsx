"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"

import {
  Bell,
  CalendarCheck,
  CalendarDays,
  CreditCard,
  FileText,
  LayoutDashboard,
  Settings,
  User,
} from "lucide-react"

const navItems = [
  {
    title: "Dashboard",
    url: "/student",
    icon: LayoutDashboard,
  },
  {
    title: "Profile",
    url: "/student/profile",
    icon: User,
  },
  {
    title: "Attendance",
    url: "/student/attendance",
    icon: CalendarCheck,
  },
  {
    title: "Results",
    url: "/student/results",
    icon: FileText,
  },
  {
    title: "Timetable",
    url: "/student/routine",
    icon: CalendarDays,
  },
  {
    title: "Fees",
    url: "/student/fees",
    icon: CreditCard,
  },
  {
    title: "Notices",
    url: "/student/notices",
    icon: Bell,
  },
  {
    title: "Settings",
    url: "/student/settings",
    icon: Settings,
  },
]

export function AppSidebar(props: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname()

  return (
    <Sidebar {...props}>
      
      {/* Header */}
      <SidebarHeader>
        <div className="px-2 py-1 text-lg font-semibold">
          Student Panel
        </div>
      </SidebarHeader>

      {/* Content */}
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>

          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.url

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link href={item.url} className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarRail />
    </Sidebar>
  )
}