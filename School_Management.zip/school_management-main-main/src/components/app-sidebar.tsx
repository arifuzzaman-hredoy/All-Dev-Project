"use client";

import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { Role } from "@prisma/client";
import {
  IconBell,
  IconBriefcase,
  IconBuildingSkyscraper,
  IconBook2,
  IconChalkboard,
  IconFileText,
  IconCoin,
  IconLayoutDashboard,
  IconSchool,
  IconSettings,
  IconUserCheck,
  IconUsers,
} from "@tabler/icons-react";

import { NavMain } from "@/components/nav-main";
import { NavProjects } from "@/components/nav-projects";
import { NavUser } from "@/components/nav-user";
import { TeamSwitcher } from "@/components/team-switcher";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar";
import { readAuth, type AuthStorage } from "@/utils/auth-storage";
import {
  ROLE_DEFINITIONS,
  roleHasPermission,
  type AdminPermission,
} from "@/constants/roles";

const ICON_SIZE = "size-4";

const navConfig: AdminNavItem[] = [
  {
    title: "Dashboard",
    url: "/admin/dashboard",
    icon: <IconLayoutDashboard className={ICON_SIZE} />,
    permission: "viewDashboard",
  },
  {
    title: "Users",
    url: "/admin/users",
    icon: <IconUsers className={ICON_SIZE} />,
    permission: "manageUsers",
    items: [
      {
        title: "Create users",
        url: "/admin/users/create",
        permission: "manageUsers",
      },
      {
        title: "View users",
        url: "/admin/users/view",
        permission: "manageUsers",
      },
    ],
  },
  {
    title: "Students",
    url: "/admin/students",
    icon: <IconSchool className={ICON_SIZE} />,
    permission: "manageStudents",
    items: [
      {
        title: "Create student",
        url: "/admin/students/create",
        permission: "manageStudents",
      },
      {
        title: "View students",
        url: "/admin/students/view",
        permission: "manageStudents",
      },
    ],
  },
  {
    title: "Guardians",
    url: "/admin/guardians",
    icon: <IconUsers className={ICON_SIZE} />,
    permission: "manageUsers",
    items: [
      {
        title: "Create guardian",
        url: "/admin/guardians/create",
        permission: "manageUsers",
      },
      {
        title: "View guardians",
        url: "/admin/guardians/view",
        permission: "manageUsers",
      },
    ],
  },
  {
    title: "Teachers",
    url: "/admin/teachers",
    icon: <IconChalkboard className={ICON_SIZE} />,
    permission: "manageTeachers",
  },
  {
    title: "HR",
    url: "/admin/hr",
    icon: <IconBriefcase className={ICON_SIZE} />,
    anyPermissions: ["manageTeachers", "manageFinance"],
    items: [
      {
        title: "Overview",
        url: "/admin/hr",
        anyPermissions: ["manageTeachers", "manageFinance"],
      },
      {
        title: "Departments",
        url: "/admin/hr/departments",
        permission: "manageTeachers",
      },
      {
        title: "Designations",
        url: "/admin/hr/designations",
        permission: "manageTeachers",
      },
      {
        title: "Leaves",
        url: "/admin/hr/leaves",
        permission: "manageTeachers",
      },
      {
        title: "Payroll",
        url: "/admin/hr/payroll",
        permission: "manageFinance",
      },
    ],
  },
  {
    title: "Classes",
    url: "/admin/classes",
    icon: <IconBuildingSkyscraper className={ICON_SIZE} />,
    permission: "manageClasses",
  },
  {
    title: "Subjects",
    url: "/admin/subjects",
    icon: <IconBook2 className={ICON_SIZE} />,
    permission: "manageSubjects",
  },
  {
    title: "Academic",
    url: "/admin/academic",
    icon: <IconSchool className={ICON_SIZE} />,
    permission: "manageAcademicData",
    items: [
      {
        title: "Documents",
        url: "/admin/academic/documents",
        icon: <IconFileText className={ICON_SIZE} />,
        permission: "manageAcademicData",
      },
      {
        title: "Exams",
        url: "/admin/academic/exams",
        icon: <IconBook2 className={ICON_SIZE} />,
        permission: "manageAcademicData",
        items: [
          {
            title: "Create",
            url: "/admin/academic/exams/create",
            permission: "manageAcademicData",
          },
          {
            title: "Show / Edit",
            url: "/admin/academic/exams/show",
            permission: "manageAcademicData",
          },
        ],
      },
      {
        title: "Results",
        url: "/admin/academic/results",
        permission: "manageAcademicData",
      },
      {
        title: "Attendance",
        url: "/admin/academic/attendance",
        permission: "manageAttendance",
      },
    ],
  },
  {
    title: "Fees",
    url: "/admin/fees",
    icon: <IconCoin className={ICON_SIZE} />,
    permission: "manageFees",
    items: [
      {
        title: "Categories",
        url: "/admin/fees/categories",
        permission: "manageFees",
      },
      {
        title: "Monthly fees",
        url: "/admin/fees/monthly",
        permission: "manageFees",
      },
      {
        title: "Payments",
        url: "/admin/fees/payments",
        permission: "managePayments",
      },
      {
        title: "Reports",
        url: "/admin/fees/reports",
        permission: "manageFeeReports",
      },
    ],
  },
  {
    title: "Admissions",
    url: "/admin/admissions",
    icon: <IconUserCheck className={ICON_SIZE} />,
    permission: "manageAdmissions",
  },
  {
    title: "Notices",
    url: "/admin/notices",
    icon: <IconBell className={ICON_SIZE} />,
    permission: "manageNotices",
  },
  {
    title: "Settings",
    url: "/admin/settings",
    icon: <IconSettings className={ICON_SIZE} />,
    permission: "manageSettings",
  },
];

type AdminNavItem = {
  title: string;
  url: string;
  icon?: ReactNode;
  permission?: AdminPermission;
  anyPermissions?: AdminPermission[];
  items?: AdminNavItem[];
};

export function filterNav(items: AdminNavItem[], role?: Role | null): AdminNavItem[] {
  return items.flatMap((item) => {
    const children = item.items ? filterNav(item.items, role) : undefined;
    const canView = item.permission
      ? roleHasPermission(role, item.permission)
      : item.anyPermissions
        ? item.anyPermissions.some((permission) => roleHasPermission(role, permission))
        : true;

    if (!canView && (!children || children.length === 0)) {
      return [];
    }

    return [
      {
        ...item,
        items: children && children.length > 0 ? children : undefined,
      },
    ];
  });
}

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const [authState, setAuthState] = useState<AuthStorage | null>(null);

  useEffect(() => {
    const syncAuth = () => setAuthState(readAuth());
    syncAuth();
    window.addEventListener("storage", syncAuth);
    return () => window.removeEventListener("storage", syncAuth);
  }, []);

  const role = authState?.user.role ?? null;
  const roleDefinition = role ? ROLE_DEFINITIONS[role] : undefined;
  const navItems = useMemo(() => filterNav(navConfig, role), [role]);

  const teams = [
    {
      name: authState?.user.branch?.school?.name ?? "School ERP",
      plan: roleDefinition
        ? `${authState?.user.branch?.name ?? roleDefinition.label} Console`
        : "Admin Console",
      logo: <IconLayoutDashboard className={ICON_SIZE} />,
    },
  ];

  const user = {
    name: authState?.user.name ?? `${roleDefinition?.label ?? "Admin"} Desk`,
    email: authState?.user.email ?? "admin@school-erp.com",
    avatar: authState?.user.avatar ?? "/avatars/admin.svg",
  };

  return (
    <Sidebar collapsible="icon" variant="inset" {...props}>
      <SidebarHeader>
        <TeamSwitcher teams={teams} />
      </SidebarHeader>

      <SidebarContent>
        <NavMain items={navItems} />
        <NavProjects projects={[]} />
      </SidebarContent>

      <SidebarFooter>
        <NavUser user={user} />
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  );
}
