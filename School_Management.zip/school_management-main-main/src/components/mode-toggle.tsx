"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ModeToggle() {
    const { theme, setTheme, resolvedTheme } = useTheme();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        const frame = requestAnimationFrame(() => setMounted(true));
        return () => cancelAnimationFrame(frame);
    }, []);
    if (!mounted) return null;

    const current = theme === "system" ? resolvedTheme : theme;

    return (
        <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(current === "dark" ? "light" : "dark")}
            aria-label="Toggle theme">
            {current === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </Button>
    );
}
