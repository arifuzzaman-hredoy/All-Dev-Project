"use client";

import { FormEvent, Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { RESET_PASSWORD_ROUTE } from "@/constants/api";

function ResetPasswordPageContent() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [status, setStatus] = useState<{ message: string; success: boolean } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus(null);

    if (!token) {
      setStatus({ message: "Missing reset token.", success: false });
      return;
    }

    if (password.length < 8) {
      setStatus({ message: "Password must be at least 8 characters.", success: false });
      return;
    }

    if (password !== confirmPassword) {
      setStatus({ message: "Passwords do not match.", success: false });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(RESET_PASSWORD_ROUTE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password })
      });

      const payload = await response.json();
      if (!response.ok || !payload.success) {
        setStatus({ message: payload.message ?? "Unable to reset password", success: false });
        return;
      }

      setStatus({ message: payload.data?.message ?? "Password set. You can now log in.", success: true });
      setPassword("");
      setConfirmPassword("");
    } catch (error) {
      console.error(error);
      setStatus({ message: "Unable to reset password", success: false });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 py-8">
      <div className="max-w-md w-full space-y-6 rounded-3xl border border-border/60 bg-card/80 p-8 shadow-2xl">
        <div className="space-y-3">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Password reset</p>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Set a new password</h1>
          <p className="text-sm text-muted-foreground">Enter a secure password and confirm it to finish resetting your account.</p>
        </div>

        {!token && (
          <p className="rounded-xl border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            The reset link is missing a token. Please request a new password reset and use the link sent to your inbox.
          </p>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <label className="block text-sm font-semibold text-foreground">
            New password
            <input
              type="password"
              className="mt-2 w-full rounded-xl border border-border/70 bg-transparent px-3 py-2 text-sm focus:border-primary focus:outline-none"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="••••••••"
              autoComplete="new-password"
            />
          </label>
          <label className="block text-sm font-semibold text-foreground">
            Confirm password
            <input
              type="password"
              className="mt-2 w-full rounded-xl border border-border/70 bg-transparent px-3 py-2 text-sm focus:border-primary focus:outline-none"
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              placeholder="••••••••"
              autoComplete="new-password"
            />
          </label>
          <Button type="submit" disabled={!token || loading} className="w-full text-sm font-semibold">
            {loading ? "Saving…" : "Reset password"}
          </Button>
        </form>

        {status && (
          <p
            className={`rounded-xl px-4 py-3 text-sm ${
              status.success
                ? "border border-emerald-300 bg-emerald-500/10 text-emerald-300"
                : "border border-destructive/50 bg-destructive/10 text-destructive"
            }`}>
            {status.message}
          </p>
        )}
      </div>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background flex items-center justify-center px-4 py-8">
          <div className="text-sm text-muted-foreground">Loading reset form...</div>
        </div>
      }
    >
      <ResetPasswordPageContent />
    </Suspense>
  );
}
