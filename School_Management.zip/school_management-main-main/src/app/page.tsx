import Contact from "@/components/contact-section";
import CTASection from "@/components/cta-sections-03";
import FooterSection from "@/components/footer-01";
import GalleryCircleGroup from "@/components/GalleryCircleGroup";
import HeroSection from "@/components/hero-sections-05";
import Navbar from "@/components/navbars-02";
import Testimonials from "@/components/testimonials-03";

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="space-y-16">

        <div>
          <HeroSection />
        </div>

        <div className="bg-secondary py-6 sm:py-16 md:py-20 lg:py-24">
          <GalleryCircleGroup />
        </div>

        <div>
          <CTASection />
        </div>

        <div className="bg-secondary">
          <Testimonials />
        </div>

        <div>
          <Contact />
        </div>

        <div className="bg-secondary">
          <FooterSection />
        </div>
      </main>
    </>
  );
}
