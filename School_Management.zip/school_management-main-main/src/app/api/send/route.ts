import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { getResendClient } from "@/lib/resend";
import { logDelivery } from "@/utils/email-logger";
import { z } from "zod";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const sendSchema = z.object({
  to: z.union([z.string(), z.array(z.string())]),
  subject: z.string(),
  message: z.string().optional(),
  html: z.string().optional(),
  useReactEmail: z.boolean().optional(),
  name: z.string().optional(),
  preventThreading: z.boolean().optional(),
  actionUrl: z.string().optional(),
});

type EmailSendResult = {
  data?: {
    id?: string | null;
  } | null;
};

type EmailOptions = {
  from: string;
  to: string[];
  subject: string;
  html: string;
  headers?: Record<string, string>;
};

export async function POST(request: Request) {
  try {
    const resend = getResendClient();

    if (!resend || !resend.emails || typeof resend.emails.send !== "function") {
      return NextResponse.json(
        { error: "Email provider not configured. Set RESEND_API_KEY first." },
        { status: 500 },
      );
    }

    const body = sendSchema.parse(await request.json());
    const {
      to,
      subject,
      message,
      useReactEmail,
      name,
      preventThreading,
      actionUrl,
    } = body;

    if (!to || !subject) {
      return NextResponse.json(
        { error: "Missing required fields: to, subject" },
        { status: 400 },
      );
    }

    const from = process.env.EMAIL_FROM || "Acme <onboarding@resend.dev>";

    const match = String(from).match(/<([^>]+)>/);
    const fromEmail = match ? match[1] : String(from);
    const fromDomain = fromEmail.split("@")[1] || "";

    if (/localhost|localhost\.com/.test(fromDomain)) {
      return NextResponse.json(
        {
          error:
            "EMAIL_FROM uses an unverified localhost domain. Set EMAIL_FROM to a domain verified in Resend.",
        },
        { status: 400 },
      );
    }

    let html: string | undefined;

    if (useReactEmail) {
      try {
        const React = await import("react");
        const { render } = await import("@react-email/render");
        const WelcomeEmail = (await import("@/emails/Welcome")).default;

        html = await render(
          React.createElement(WelcomeEmail, { name, actionUrl }),
        );
      } catch (renderErr) {
        const msg =
          renderErr instanceof Error ? renderErr.message : String(renderErr);

        return NextResponse.json(
          { error: "Failed to render email template", details: msg },
          { status: 500 },
        );
      }
    } else if (body.html) {
      html = String(body.html);
    } else if (message) {
      html = `<p>${String(message)}</p>`;
    }

    if (!html) {
      return NextResponse.json(
        { error: "Missing message content" },
        { status: 400 },
      );
    }

    const toList = Array.isArray(to) ? to.map(String) : [String(to)];
    const validTo = toList.filter((email) => /\S+@\S+\.\S+/.test(email));

    if (validTo.length === 0) {
      return NextResponse.json(
        { error: "No valid recipient emails provided" },
        { status: 400 },
      );
    }

    const emailOptions: EmailOptions = {
      from,
      to: validTo,
      subject: String(subject),
      html: String(html),
    };

    if (preventThreading) {
      emailOptions.headers = { "X-Entity-Ref-ID": randomUUID() };
    }

    let result: Awaited<ReturnType<typeof resend.emails.send>> | null = null;

    try {
      result = await resend.emails.send(emailOptions);
    } catch (sendErr: unknown) {
      const details =
        sendErr instanceof Error ? sendErr.message : String(sendErr);

      return NextResponse.json(
        { error: "Email provider error", details },
        { status: 502 },
      );
    }

    const resultId = (result as EmailSendResult | null)?.data?.id ?? null;

    try {
      await logDelivery({
        id: resultId,
        to: validTo,
        subject: String(subject),
        timestamp: new Date().toISOString(),
        preventThreading: !!preventThreading,
        raw: result,
      });
    } catch {
      // Email sent successfully; logging failure should not fail request.
    }

    return NextResponse.json({
      success: true,
      id: resultId,
      result,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);

    return NextResponse.json(
      { error: message || "Failed to send email" },
      { status: 500 },
    );
  }
}
