import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  archiveExamForAdmin,
  deleteExamForAdmin,
  deleteExamComponentForAdmin,
  deleteExamSubjectForAdmin,
  deleteExamTeacherAssignmentForAdmin,
  getExamDetailForAdmin,
  syncExamClassAssignmentsForAdmin,
  updateExamForAdmin,
  upsertExamComponentForAdmin,
  upsertExamSubjectForAdmin,
  upsertExamTeacherAssignmentForAdmin,
} from "@/services/exam.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  examClassAssignmentsSchema,
  examComponentSchema,
  examSubjectSchema,
  examTeacherAssignmentSchema,
  updateExamSchema,
} from "@/validations/exam.schema";
import { z } from "zod";

type RouteContext = { params: Promise<{ id: string }> };

function getAction(body: unknown) {
  if (!body || typeof body !== "object") return undefined;
  const action = (body as { action?: unknown }).action;
  return typeof action === "string" ? action : undefined;
}

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const auth = requireAuth(req);
    requirePermission(auth, "manageAcademicData");
    const { id } = await context.params;
    return successResponse(await getExamDetailForAdmin(id));
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const auth = requireAuth(req);
    requirePermission(auth, "manageAcademicData");
    const body = await req.json();
    const action = getAction(body);
    const { id } = await context.params;

    if (action === "archive") {
      return successResponse({ exam: await archiveExamForAdmin(id) });
    }

    if (action === "assign-classes") {
      const payload = examClassAssignmentsSchema.parse(body);
      return successResponse({
        exam: await syncExamClassAssignmentsForAdmin(id, payload),
      });
    }

    if (action === "subject-upsert") {
      const payload = examSubjectSchema.parse(body);
      return successResponse({
        examSubject: await upsertExamSubjectForAdmin(id, payload),
      });
    }

    if (action === "subject-delete") {
      const payload = examSubjectSchema
        .pick({ classId: true, subjectId: true })
        .parse(body);
      return successResponse({
        examSubject: await deleteExamSubjectForAdmin(id, payload),
      });
    }

    if (action === "component-upsert") {
      const payload = examComponentSchema.parse(body);
      return successResponse({
        examComponent: await upsertExamComponentForAdmin(id, payload),
      });
    }

    if (action === "component-delete") {
      const payload = z
        .object({ componentId: z.string().trim().min(1) })
        .parse(body);
      return successResponse({
        examComponent: await deleteExamComponentForAdmin(
          id,
          payload.componentId,
        ),
      });
    }

    if (action === "teacher-upsert") {
      const payload = examTeacherAssignmentSchema.parse(body);
      return successResponse({
        teacherAssignment: await upsertExamTeacherAssignmentForAdmin(
          id,
          payload,
        ),
      });
    }

    if (action === "teacher-delete") {
      const payload = z
        .object({ assignmentId: z.string().trim().min(1) })
        .parse(body);
      return successResponse({
        teacherAssignment: await deleteExamTeacherAssignmentForAdmin(
          id,
          payload.assignmentId,
        ),
      });
    }

    const payload = updateExamSchema.parse(body);
    return successResponse({ exam: await updateExamForAdmin(id, payload) });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const auth = requireAuth(req);
    requirePermission(auth, "manageAcademicData");
    const { id } = await context.params;
    return successResponse({ exam: await deleteExamForAdmin(id) });
  } catch (error) {
    return handleError(error);
  }
}
