import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createExamForAdmin, listExamWorkspace } from "@/services/exam.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createExamSchema,
  examListQuerySchema,
} from "@/validations/exam.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const filters = examListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      status: req.nextUrl.searchParams.get("status") ?? undefined,
      academicYear: req.nextUrl.searchParams.get("academicYear") ?? undefined,
      examTypeId: req.nextUrl.searchParams.get("examTypeId") ?? undefined,
      includeArchived:
        req.nextUrl.searchParams.get("includeArchived") ?? undefined,
    });
    const result = await listExamWorkspace(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = requireAuth(req);
    requirePermission(auth, "manageAcademicData");
    const body = createExamSchema.parse(await req.json());
    const exam = await createExamForAdmin(body);
    return successResponse({ exam }, 201);
  } catch (error) {
    return handleError(error);
  }
}
