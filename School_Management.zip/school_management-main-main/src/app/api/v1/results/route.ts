import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createResultForAdmin, listResultsForAdmin } from "@/services/result.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createResultSchema, resultListQuerySchema } from "@/validations/result.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const filters = resultListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      examId: req.nextUrl.searchParams.get("examId") ?? undefined,
      studentId: req.nextUrl.searchParams.get("studentId") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      subjectId: req.nextUrl.searchParams.get("subjectId") ?? undefined,
    });
    const result = await listResultsForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = createResultSchema.parse(await req.json());
    const resultRecord = await createResultForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.result.created",
      entityType: "Result",
      entityId: resultRecord.id,
    });
    return successResponse({ result: resultRecord }, 201);
  } catch (error) {
    return handleError(error);
  }
}
