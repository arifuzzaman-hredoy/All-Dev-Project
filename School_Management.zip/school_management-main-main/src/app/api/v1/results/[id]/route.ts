import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deleteResultForAdmin, updateResultForAdmin } from "@/services/result.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateResultSchema } from "@/validations/result.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = updateResultSchema.parse(await req.json());
    const { id } = await context.params;
    const result = await updateResultForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.result.updated",
      entityType: "Result",
      entityId: result.id,
    });
    return successResponse({ result });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const { id } = await context.params;
    const result = await deleteResultForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.result.deleted",
      entityType: "Result",
      entityId: id,
    });
    return successResponse({ result });
  } catch (error) {
    return handleError(error);
  }
}
