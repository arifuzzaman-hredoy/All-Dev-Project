import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { listResultsForAdmin } from "@/services/result.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";

type RouteContext = { params: Promise<{ studentId: string }> };

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const { studentId } = await context.params;
    const result = await listResultsForAdmin({
      studentId,
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      examId: req.nextUrl.searchParams.get("examId") ?? undefined,
      subjectId: req.nextUrl.searchParams.get("subjectId") ?? undefined,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
