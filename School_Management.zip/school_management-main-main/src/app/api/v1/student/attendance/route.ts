import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { listStudentAttendance } from "@/services/studentPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.STUDENT]);
    const userId = requireUserId(payload);
    const result = await listStudentAttendance(userId);
    return successResponse({ attendance: result.records, summary: result.summary });
  } catch (error) {
    return handleError(error);
  }
}
