import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { getStudentProfile } from "@/services/studentPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.STUDENT]);
    const userId = requireUserId(payload);
    const profile = await getStudentProfile(userId);
    return successResponse({ profile });
  } catch (error) {
    return handleError(error);
  }
}
