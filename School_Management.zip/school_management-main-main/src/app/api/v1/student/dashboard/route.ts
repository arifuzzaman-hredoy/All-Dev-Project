import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { getStudentDashboard } from "@/services/studentPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.STUDENT]);
    const userId = requireUserId(payload);
    const dashboard = await getStudentDashboard(userId);
    return successResponse({ dashboard });
  } catch (error) {
    return handleError(error);
  }
}
