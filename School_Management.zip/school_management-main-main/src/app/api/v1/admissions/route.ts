import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  listAdmissionsForAdmin,
  submitAdmissionApplication,
} from "@/services/admission.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  admissionListQuerySchema,
  createAdmissionSchema,
} from "@/validations/admission.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAdmissions");

    const filters = admissionListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      status: req.nextUrl.searchParams.get("status") ?? undefined,
    });

    const result = await listAdmissionsForAdmin({
      search: filters.search,
      status: filters.status,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = createAdmissionSchema.parse(await req.json());
    const admission = await submitAdmissionApplication(body);

    return successResponse(
      {
        admission,
        message: "Admission application submitted successfully",
      },
      201
    );
  } catch (error) {
    return handleError(error);
  }
}
