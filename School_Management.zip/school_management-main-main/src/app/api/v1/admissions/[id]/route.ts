import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deleteAdmissionForAdmin,
  updateAdmissionForAdmin,
} from "@/services/admission.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateAdmissionSchema } from "@/validations/admission.schema";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAdmissions");

    const body = updateAdmissionSchema.parse(await req.json());
    const { id } = await context.params;
    const admission = await updateAdmissionForAdmin(id, {
      name: body.name,
      email: body.email,
      phone: body.phone,
      className: body.className,
      message: body.message,
      details: body.details,
      status: body.status,
      convertedToStudentId: body.convertedToStudentId,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.admission.updated",
      entityType: "AdmissionApplication",
      entityId: admission.id,
      metadata: { status: admission.status },
    });

    return successResponse({ admission });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAdmissions");

    const { id } = await context.params;
    const admission = await deleteAdmissionForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.admission.deleted",
      entityType: "AdmissionApplication",
      entityId: admission.id,
    });

    return successResponse({ admission });
  } catch (error) {
    return handleError(error);
  }
}
