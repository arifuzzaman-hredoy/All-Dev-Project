import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";

import { requireAuth } from "@/lib/auth";
import { requireRole } from "@/lib/permissions";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { branchListQuerySchema, createBranchSchema } from "@/validations/branch.schema";
import { createBranchForSuperAdmin, listBranchesForSuperAdmin } from "@/services/branch.service";
import { recordAuditEvent } from "@/services/audit.service";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.SUPER_ADMIN]);
    const query = branchListQuerySchema.parse({
      includeInactive: req.nextUrl.searchParams.get("includeInactive") ?? undefined,
    });
    const result = await listBranchesForSuperAdmin(query.includeInactive);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.SUPER_ADMIN]);
    const body = createBranchSchema.parse(await req.json());
    const branch = await createBranchForSuperAdmin(body);
    void recordAuditEvent({
      actorId: payload.id,
      action: "super.branch.created",
      entityType: "Branch",
      entityId: branch.id,
    }).catch((error) => {
      console.error("Failed to record branch create audit event", error);
    });
    return successResponse({ branch }, 201);
  } catch (error) {
    return handleError(error);
  }
}

