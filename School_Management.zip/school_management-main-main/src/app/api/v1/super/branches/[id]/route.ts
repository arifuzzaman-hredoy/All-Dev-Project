import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";

import { requireAuth } from "@/lib/auth";
import { requireRole } from "@/lib/permissions";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateBranchSchema } from "@/validations/branch.schema";
import { updateBranchForSuperAdmin } from "@/services/branch.service";
import { recordAuditEvent } from "@/services/audit.service";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.SUPER_ADMIN]);
    const body = updateBranchSchema.parse(await req.json());
    const { id } = await context.params;
    const branch = await updateBranchForSuperAdmin({ branchId: id, ...body });
    void recordAuditEvent({
      actorId: payload.id,
      action: "super.branch.updated",
      entityType: "Branch",
      entityId: branch.id,
    }).catch((error) => {
      console.error("Failed to record branch update audit event", error);
    });
    return successResponse({ branch });
  } catch (error) {
    return handleError(error);
  }
}

