import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { dispatchReminders, getReminderPreview } from "@/services/notification.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSettings");
    const preview = await getReminderPreview();
    return successResponse(preview);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSettings");
    const actorId = requireUserId(payload);
    const body = await req.json() as { type?: "fees" | "attendance" | "all" };
    const result = await dispatchReminders(actorId, { type: body.type ?? "all" });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
