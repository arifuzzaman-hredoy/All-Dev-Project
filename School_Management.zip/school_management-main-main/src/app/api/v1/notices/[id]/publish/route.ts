import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { publishNoticeForAdmin } from "@/services/notice.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const { id } = await context.params;
    const notice = await publishNoticeForAdmin(id);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.notice.published",
      entityType: "Notice",
      entityId: notice.id,
    });

    return successResponse({ notice });
  } catch (error) {
    return handleError(error);
  }
}

