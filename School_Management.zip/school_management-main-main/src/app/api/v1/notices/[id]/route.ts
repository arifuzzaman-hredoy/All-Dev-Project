import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deleteNoticeForAdmin, updateNoticeForAdmin } from "@/services/notice.service";
import { findNoticeById } from "@/repositories/notice.repository";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError, HttpError } from "@/utils/error-handler";
import { updateNoticeSchema } from "@/validations/notice.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const body = updateNoticeSchema.parse(await req.json());
    const { id } = await context.params;
    const notice = await updateNoticeForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.notice.updated",
      entityType: "Notice",
      entityId: notice.id,
    });
    return successResponse({ notice });
  } catch (error) {
    return handleError(error);
  }
}

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const { id } = await context.params;
    const notice = await findNoticeById(id);
    if (!notice) {
      throw new HttpError("Notice not found", 404);
    }
    return successResponse({ notice });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const { id } = await context.params;
    const notice = await deleteNoticeForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.notice.deleted",
      entityType: "Notice",
      entityId: id,
    });
    return successResponse({ notice });
  } catch (error) {
    return handleError(error);
  }
}
