import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createNoticeForAdmin, listNoticesForAdmin } from "@/services/notice.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createNoticeSchema, noticeListQuerySchema } from "@/validations/notice.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const filters = noticeListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      audience: req.nextUrl.searchParams.get("audience") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
    });
    const result = await listNoticesForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const body = createNoticeSchema.parse(await req.json());
    const notice = await createNoticeForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.notice.created",
      entityType: "Notice",
      entityId: notice.id,
    });
    return successResponse({ notice }, 201);
  } catch (error) {
    return handleError(error);
  }
}
