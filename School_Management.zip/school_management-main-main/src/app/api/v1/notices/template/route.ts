import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  getNoticeTemplateForAdmin,
  updateNoticeTemplateForAdmin,
} from "@/services/noticeTemplate.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { noticeTemplateSchema } from "@/validations/notice-template.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const result = await getNoticeTemplateForAdmin();
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageNotices");
    const actorId = requireUserId(payload);

    const body = noticeTemplateSchema.parse(await req.json());
    const result = await updateNoticeTemplateForAdmin({
      template: body,
      actorId,
    });

    await recordAuditEvent({
      actorId,
      action: "admin.notice_template.updated",
      entityType: "SystemSetting",
      entityId: result.setting.id,
      metadata: { key: "notice_template" },
    });

    return successResponse({ template: result.template });
  } catch (error) {
    return handleError(error);
  }
}

