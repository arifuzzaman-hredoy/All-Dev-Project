import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { AUTH_COOKIE_NAME, getAuthCookieOptions, requireAuth } from "@/lib/auth";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function POST(req: NextRequest) {
  try {
    const headerValue = req.headers.get("authorization");
    const payload = requireAuth(req);
    const response = successResponse({ userId: payload.id });
    const token = headerValue?.split(" ")[1];

    if (!token) {
      return response;
    }

    response.cookies.set(AUTH_COOKIE_NAME, token, getAuthCookieOptions());
    return response;
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE() {
  const response = NextResponse.json({ success: true, data: { message: "Session cleared" } });
  response.cookies.set(AUTH_COOKIE_NAME, "", {
    ...getAuthCookieOptions(),
    maxAge: 0,
  });
  return response;
}
