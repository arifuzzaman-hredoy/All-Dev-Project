import type { NextRequest } from "next/server";
import { ZodError } from "zod";
import { resetPasswordSchema } from "@/validations/auth.schema";
import { resetPassword } from "@/services/passwordReset.service";
import { errorResponse, successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";

export async function POST(req: NextRequest) {
  try {
    const { token, password } = resetPasswordSchema.parse(await req.json());
    const payload = await resetPassword(token, password);
    return successResponse(payload);
  } catch (error) {
    if (error instanceof ZodError) {
      const tokenIssue = error.issues.find((issue) => issue.path[0] === "token");
      const message = tokenIssue ? "Missing reset token" : error.issues[0]?.message ?? "Invalid payload";
      return errorResponse(message, 400);
    }
    return handleError(error);
  }
}
