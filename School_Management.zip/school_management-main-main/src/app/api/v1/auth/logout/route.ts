import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { AUTH_COOKIE_NAME, getAuthCookieOptions, requireAuth } from "@/lib/auth";

export async function POST(req: NextRequest) {
	try {
		requireAuth(req);
		const response = successResponse({ message: "Signed out" });
		response.cookies.set(AUTH_COOKIE_NAME, "", {
			...getAuthCookieOptions(),
			maxAge: 0,
		});
		return response;
	} catch (error) {
		const response = handleError(error) as NextResponse;
		response.cookies.set(AUTH_COOKIE_NAME, "", {
			...getAuthCookieOptions(),
			maxAge: 0,
		});
		return response;
	}
}
