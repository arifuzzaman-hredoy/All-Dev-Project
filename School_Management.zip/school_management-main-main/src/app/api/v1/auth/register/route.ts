import type { NextRequest } from "next/server";
import type { Role } from "@prisma/client";
import { AUTH_COOKIE_NAME, getAuthCookieOptions } from "@/lib/auth";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { registerUser } from "@/services/auth.service";
import { registerSchema } from "@/validations/auth.schema";

export async function POST(req: NextRequest) {
  try {
    const payload = registerSchema.parse(await req.json());
    const result = await registerUser({
      ...payload,
      role: payload.role as Role
    });

    const response = successResponse(result, 201);
    if (result.token) {
      response.cookies.set(AUTH_COOKIE_NAME, result.token, getAuthCookieOptions());
    }
    return response;
  } catch (error) {
    return handleError(error);
  }
}
