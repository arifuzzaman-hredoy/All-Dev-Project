import type { NextRequest } from "next/server";
import { HttpError, handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";
import { requireAuth } from "@/lib/auth";
import { findUserById } from "@/repositories/user.repository";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    const user = await findUserById(payload.id);

    if (!user) {
      throw new HttpError("Authenticated user not found", 404);
    }

    return successResponse({ user });
  } catch (error) {
    return handleError(error);
  }
}
