import type { NextRequest } from "next/server";
import { AUTH_COOKIE_NAME, getAuthCookieOptions } from "@/lib/auth";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { loginUser } from "@/services/auth.service";
import { loginSchema } from "@/validations/auth.schema";

export async function POST(req: NextRequest) {
	try {
		const payload = loginSchema.parse(await req.json());
		const result = await loginUser(payload);
		const response = successResponse(result);
		response.cookies.set(AUTH_COOKIE_NAME, result.token, getAuthCookieOptions());
		return response;
	} catch (error) {
		return handleError(error);
	}
}
