import type { NextRequest } from "next/server";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { forgotPasswordSchema } from "@/validations/auth.schema";
import { requestPasswordReset } from "@/services/passwordReset.service";

export async function POST(req: NextRequest) {
  try {
    const { email } = forgotPasswordSchema.parse(await req.json());
    const payload = await requestPasswordReset(email);
    return successResponse(payload);
  } catch (error) {
    return handleError(error);
  }
}
