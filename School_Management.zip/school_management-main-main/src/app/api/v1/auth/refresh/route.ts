import type { NextRequest } from "next/server";
import { HttpError, handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";
import { findUserById } from "@/repositories/user.repository";
import { AUTH_COOKIE_NAME, generateToken, getAuthCookieOptions, requireAuth } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    const user = await findUserById(payload.id);

    if (!user) {
      throw new HttpError("Authenticated user not found", 404);
    }

    const token = generateToken({ id: user.id, role: user.role });

    const response = successResponse({ token, user });
    response.cookies.set(AUTH_COOKIE_NAME, token, getAuthCookieOptions());
    return response;
  } catch (error) {
    return handleError(error);
  }
}
