import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deleteSubjectForAdmin, updateSubjectForAdmin } from "@/services/subject.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateSubjectSchema } from "@/validations/subject.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSubjects");
    const body = updateSubjectSchema.parse(await req.json());
    const { id } = await context.params;
    const subject = await updateSubjectForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.subject.updated",
      entityType: "Subject",
      entityId: subject.id,
    });
    return successResponse({ subject });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSubjects");
    const { id } = await context.params;
    const subject = await deleteSubjectForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.subject.deleted",
      entityType: "Subject",
      entityId: id,
    });
    return successResponse({ subject });
  } catch (error) {
    return handleError(error);
  }
}
