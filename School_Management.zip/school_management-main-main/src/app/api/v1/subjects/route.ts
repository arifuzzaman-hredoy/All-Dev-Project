import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createSubjectForAdmin, listSubjectsForAdmin } from "@/services/subject.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createSubjectSchema, subjectListQuerySchema } from "@/validations/subject.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSubjects");
    const filters = subjectListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
    });
    const result = await listSubjectsForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSubjects");
    const body = createSubjectSchema.parse(await req.json());
    const subject = await createSubjectForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.subject.created",
      entityType: "Subject",
      entityId: subject.id,
    });
    return successResponse({ subject }, 201);
  } catch (error) {
    return handleError(error);
  }
}
