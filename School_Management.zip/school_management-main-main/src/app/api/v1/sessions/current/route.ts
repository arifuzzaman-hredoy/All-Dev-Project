import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  getCurrentAcademicSession,
  setCurrentAcademicSessionForAdmin,
} from "@/services/session.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { setCurrentSessionSchema } from "@/validations/session.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSessions");

    const current = await getCurrentAcademicSession();
    return successResponse({ current });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSessions");

    const body = setCurrentSessionSchema.parse(await req.json());
    const session = await setCurrentAcademicSessionForAdmin(body.sessionId);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.session.set_current",
      entityType: "AcademicSession",
      entityId: session.id,
    });

    return successResponse({ session });
  } catch (error) {
    return handleError(error);
  }
}

