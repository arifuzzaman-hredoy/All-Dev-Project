import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { migrateStudentsToSessionForAdmin } from "@/services/session.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { sessionMigrationSchema } from "@/validations/session.schema";

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSessions");

    const body = sessionMigrationSchema.parse(await req.json());
    const result = await migrateStudentsToSessionForAdmin(body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.session.migrated",
      entityType: "Student",
      entityId: null,
      metadata: result,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

