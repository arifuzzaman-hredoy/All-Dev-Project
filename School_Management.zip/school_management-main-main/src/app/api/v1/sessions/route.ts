import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  createAcademicSessionForAdmin,
  listAcademicSessionsForAdmin,
} from "@/services/session.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createSessionSchema,
  sessionListQuerySchema,
} from "@/validations/session.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSessions");

    const filters = sessionListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      includeInactive: req.nextUrl.searchParams.get("includeInactive") ?? undefined,
    });

    const result = await listAcademicSessionsForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSessions");

    const body = createSessionSchema.parse(await req.json());
    const session = await createAcademicSessionForAdmin(body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.session.created",
      entityType: "AcademicSession",
      entityId: session.id,
      metadata: { isCurrent: session.isCurrent },
    });

    return successResponse({ session }, 201);
  } catch (error) {
    return handleError(error);
  }
}

