import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { listBranchesPublic } from "@/services/branch.service";

export async function GET() {
  try {
    const result = await listBranchesPublic();
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

