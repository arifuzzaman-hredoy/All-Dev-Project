import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { getDueListReport } from "@/services/due.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { dueReportQuerySchema } from "@/validations/due.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFeeReports");

    const { searchParams } = new URL(req.url);
    const query = dueReportQuerySchema.parse({
      month: searchParams.get("month"),
      year: searchParams.get("year"),
      classId: searchParams.get("classId") ?? undefined,
      search: searchParams.get("search") ?? undefined,
    });

    const report = await getDueListReport(query);
    return successResponse(report);
  } catch (error) {
    return handleError(error);
  }
}

