import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { getStudentGenderCounts } from "@/services/studentStats.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { studentGenderCountQuerySchema } from "@/validations/student-stats.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageStudents");

    const { searchParams } = new URL(req.url);
    const query = studentGenderCountQuerySchema.parse({
      classId: searchParams.get("classId") ?? undefined,
    });

    const report = await getStudentGenderCounts(query);
    return successResponse(report);
  } catch (error) {
    return handleError(error);
  }
}

