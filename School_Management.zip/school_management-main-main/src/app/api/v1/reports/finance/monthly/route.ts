import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { getMonthlyFinanceReport } from "@/services/finance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { financeMonthlyReportQuerySchema } from "@/validations/finance.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinanceReports");

    const query = financeMonthlyReportQuerySchema.parse({
      month: req.nextUrl.searchParams.get("month"),
      year: req.nextUrl.searchParams.get("year"),
    });

    const report = await getMonthlyFinanceReport(query);
    return successResponse(report);
  } catch (error) {
    return handleError(error);
  }
}

