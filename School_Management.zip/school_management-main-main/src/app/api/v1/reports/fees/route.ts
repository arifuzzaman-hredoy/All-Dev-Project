import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { buildFeeLedger } from "@/lib/fee-history";
import { requirePermission } from "@/lib/permissions";
import { listPayments } from "@/repositories/payment.repository";
import { handleError, HttpError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFeeReports");

    const { searchParams } = new URL(req.url);
    const yearParam = searchParams.get("year");
    const yearFilter = yearParam ? Number(yearParam) : undefined;

    if (
      yearFilter !== undefined &&
      (!Number.isInteger(yearFilter) || yearFilter < 2000 || yearFilter > 2100)
    ) {
      throw new HttpError("Invalid report year", 400);
    }

    const payments = await listPayments({});
    const ledger = buildFeeLedger(payments);
    const paymentsWithTotals = yearFilter
      ? ledger.payments.filter((payment) => payment.billingYear === yearFilter)
      : ledger.payments;
    const history = yearFilter
      ? ledger.history.filter((entry) => entry.year === yearFilter)
      : ledger.history;

    const totals = history.reduce(
      (acc, payment) => {
        acc.income += payment.amountPaid;
        acc.expected += payment.totalExpected;
        acc.due += payment.dueAmount;
        return acc;
      },
      {
        income: 0,
        expected: 0,
        due: 0,
        byStatus: {
          PAID: 0,
          PARTIAL: 0,
          DUE: 0,
        },
      },
    );

    for (const payment of paymentsWithTotals) {
      totals.byStatus[payment.status] += 1;
    }

    const byMonthMap = new Map<
      string,
      { label: string; income: number; due: number }
    >();
    for (const entry of history) {
      const label = `${entry.year}-${String(entry.month).padStart(2, "0")}`;
      const current = byMonthMap.get(label) ?? { label, income: 0, due: 0 };
      current.income += entry.amountPaid;
      current.due += entry.dueAmount;
      byMonthMap.set(label, current);
    }

    return successResponse({
      totals,
      monthly: Array.from(byMonthMap.values()).sort((a, b) =>
        a.label < b.label ? 1 : -1,
      ),
      payments: paymentsWithTotals,
    });
  } catch (error) {
    return handleError(error);
  }
}
