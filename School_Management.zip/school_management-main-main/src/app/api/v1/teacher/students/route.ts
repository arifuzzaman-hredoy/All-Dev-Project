import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import {
  listTeacherStudentDirectory,
  listTeacherStudents,
} from "@/services/teacherPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const { searchParams } = new URL(req.url);
    if (searchParams.get("mode") === "directory") {
      const directory = await listTeacherStudentDirectory(userId, {
        classId: searchParams.get("classId") ?? undefined,
        search: searchParams.get("search") ?? undefined,
      });
      return successResponse(directory);
    }
    const students = await listTeacherStudents(
      userId,
      searchParams.get("search") ?? undefined
    );

    return successResponse({ students });
  } catch (error) {
    return handleError(error);
  }
}
