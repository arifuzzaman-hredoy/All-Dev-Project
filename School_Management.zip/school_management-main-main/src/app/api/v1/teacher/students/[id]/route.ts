import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { getTeacherStudentProfile } from "@/services/teacherPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const { id } = await context.params;
    const student = await getTeacherStudentProfile(userId, id);
    return successResponse(student);
  } catch (error) {
    return handleError(error);
  }
}
