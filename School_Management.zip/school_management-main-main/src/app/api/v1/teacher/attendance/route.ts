import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import {
  listTeacherAttendanceWorkspace,
  saveTeacherAttendance,
} from "@/services/teacherPortal.service";
import { teacherAttendanceUpsertSchema } from "@/validations/teacher-portal.schema";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const { searchParams } = new URL(req.url);
    const workspace = await listTeacherAttendanceWorkspace(userId, {
      classId: searchParams.get("classId") ?? undefined,
      subjectId: searchParams.get("subjectId") ?? undefined,
      date: searchParams.get("date") ?? undefined,
    });
    return successResponse(workspace);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const body = teacherAttendanceUpsertSchema.parse(await req.json());
    const result = await saveTeacherAttendance(userId, body);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
