import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { listTeacherTimetable } from "@/services/teacherPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const timetable = await listTeacherTimetable(userId);
    return successResponse({ timetable });
  } catch (error) {
    return handleError(error);
  }
}
