import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import {
  getTeacherSettings,
  updateTeacherProfile,
} from "@/services/teacherPortal.service";
import { teacherProfileUpdateSchema } from "@/validations/teacher-portal.schema";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const settings = await getTeacherSettings(userId);
    return successResponse(settings);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.TEACHER]);
    const userId = requireUserId(payload);
    const body = teacherProfileUpdateSchema.parse(await req.json());
    const user = await updateTeacherProfile(userId, body);
    return successResponse({ user });
  } catch (error) {
    return handleError(error);
  }
}
