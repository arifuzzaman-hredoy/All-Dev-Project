import type { NextRequest } from "next/server";
import { WeekDay } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deleteTimetableForAdmin, updateTimetableForAdmin } from "@/services/timetable.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateTimetableSchema } from "@/validations/timetable.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = updateTimetableSchema.parse(await req.json());
    const { id } = await context.params;
    const entry = await updateTimetableForAdmin(id, {
      ...body,
      day: body.day as WeekDay | undefined,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.timetable.updated",
      entityType: "Timetable",
      entityId: entry.id,
    });
    return successResponse({ entry });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const { id } = await context.params;
    const entry = await deleteTimetableForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.timetable.deleted",
      entityType: "Timetable",
      entityId: id,
    });
    return successResponse({ entry });
  } catch (error) {
    return handleError(error);
  }
}
