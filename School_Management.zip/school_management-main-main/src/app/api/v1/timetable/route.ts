import type { NextRequest } from "next/server";
import { WeekDay } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createTimetableForAdmin, listTimetablesForAdmin } from "@/services/timetable.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createTimetableSchema, timetableListQuerySchema } from "@/validations/timetable.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const filters = timetableListQuerySchema.parse({
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      teacherId: req.nextUrl.searchParams.get("teacherId") ?? undefined,
      day: req.nextUrl.searchParams.get("day") ?? undefined,
    });
    const result = await listTimetablesForAdmin({
      ...filters,
      day: filters.day as WeekDay | undefined,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = createTimetableSchema.parse(await req.json());
    const entry = await createTimetableForAdmin({
      ...body,
      day: body.day as WeekDay,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.timetable.created",
      entityType: "Timetable",
      entityId: entry.id,
    });
    return successResponse({ entry }, 201);
  } catch (error) {
    return handleError(error);
  }
}
