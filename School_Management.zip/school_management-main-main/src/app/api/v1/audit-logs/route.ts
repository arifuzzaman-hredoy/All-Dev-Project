import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { listAuditEvents } from "@/services/audit.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSettings");

    const { searchParams } = new URL(req.url);
    const logs = await listAuditEvents({
      search: searchParams.get("search") ?? undefined,
      action: searchParams.get("action") ?? undefined,
      entityType: searchParams.get("entityType") ?? undefined,
      actorId: searchParams.get("actorId") ?? undefined,
      skip: searchParams.get("page")
        ? (Math.max(Number(searchParams.get("page")), 1) - 1) *
          Number(searchParams.get("limit") ?? 25)
        : 0,
      limit: searchParams.get("limit")
        ? Number(searchParams.get("limit"))
        : undefined,
    });

    if (searchParams.get("format") === "csv") {
      const csvRows = [
        ["id", "action", "entityType", "entityId", "actorName", "actorEmail", "createdAt"].join(","),
        ...logs.logs.map((log) =>
          [
            log.id,
            log.action,
            log.entityType,
            log.entityId ?? "",
            log.actor?.name ?? "System",
            log.actor?.email ?? "",
            log.createdAt.toISOString(),
          ]
            .map((value) => `"${String(value).replace(/"/g, '""')}"`)
            .join(",")
        ),
      ].join("\n");

      return new NextResponse(csvRows, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="audit-logs.csv"',
        },
      });
    }

    return successResponse(logs);
  } catch (error) {
    return handleError(error);
  }
}
