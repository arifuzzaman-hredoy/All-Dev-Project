import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { updateGlobalThemeSchema } from "@/validations/theme.schema";
import { fetchGlobalTheme, updateGlobalTheme } from "@/services/theme.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";

/**
 * Returns the palette that every user inherits when no personal overrides exist.
 */
export async function GET() {
  try {
    const theme = await fetchGlobalTheme();
    return successResponse({ theme });
  } catch (error) {
    return handleError(error);
  }
}

/**
 * Allows the super admin to rewrite the shared palette.
 */
export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.SUPER_ADMIN]);
    const themePayload = updateGlobalThemeSchema.parse(await req.json());
    const userId = requireUserId(payload);
    const theme = await updateGlobalTheme(themePayload, userId);
    return successResponse({ theme });
  } catch (error) {
    return handleError(error);
  }
}
