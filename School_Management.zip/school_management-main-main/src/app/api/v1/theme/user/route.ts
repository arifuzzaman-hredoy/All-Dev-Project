import type { NextRequest } from "next/server";
import { updateUserThemeSchema } from "@/validations/theme.schema";
import { fetchUserTheme, updateUserTheme } from "@/services/theme.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { requireAuth } from "@/lib/auth";
import { requireUserId } from "@/lib/permissions";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    const userId = requireUserId(payload);

    const theme = await fetchUserTheme(userId);

    return successResponse({ theme });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    const userId = requireUserId(payload);

    const themePayload = updateUserThemeSchema.parse(await req.json());

    const theme = await updateUserTheme(userId, themePayload, userId);

    return successResponse({ theme });
  } catch (error) {
    return handleError(error);
  }
}
