import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { type StudentDocumentType } from "@/lib/student-document";
import { buildStudentDocumentPdfBuffer } from "@/lib/student-document-pdf";
import { findStudentDocumentById } from "@/repositories/student.repository";
import { recordAuditEvent } from "@/services/audit.service";
import { fetchStudentDocumentTemplate } from "@/services/studentDocumentTemplate.service";
import { handleError } from "@/utils/error-handler";

const allowedTypes = new Set<StudentDocumentType>(["testimonial", "tc", "character"]);

function getDocumentType(value: string | null): StudentDocumentType | null {
  if (!value) return null;
  return allowedTypes.has(value as StudentDocumentType)
    ? (value as StudentDocumentType)
    : null;
}

function buildFilename(studentName: string, type: StudentDocumentType) {
  const slug = studentName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);

  return `${type}-${slug || "student"}.pdf`;
}

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const userId = requireUserId(payload);
    const params = await context.params;
    const documentType = getDocumentType(req.nextUrl.searchParams.get("type"));

    if (!documentType) {
      return new NextResponse("Invalid document type", { status: 400 });
    }

    const student = await findStudentDocumentById(params.id);

    if (!student) {
      return new NextResponse("Student not found", { status: 404 });
    }

    const template = await fetchStudentDocumentTemplate();

    await recordAuditEvent({
      actorId: userId,
      action: "admin.student_document.downloaded",
      entityType: "Student",
      entityId: student.id,
      metadata: {
        documentType,
        classId: student.class.id,
        rollNumber: student.rollNumber,
      },
    });

    const pdfBuffer = await buildStudentDocumentPdfBuffer(student, documentType, {
      schoolName: process.env.SCHOOL_NAME,
    }, template);

    const pdfData = Uint8Array.from(pdfBuffer);

    return new NextResponse(pdfData, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${buildFilename(student.user.name, documentType)}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
