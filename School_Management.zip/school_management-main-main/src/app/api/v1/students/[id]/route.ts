import type { NextRequest } from "next/server";
import { Gender } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deactivateStudentForAdmin,
  updateStudentForAdmin,
} from "@/services/student.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateStudentSchema } from "@/validations/student.schema";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageStudents");

    const body = updateStudentSchema.parse(await req.json());
    const { id } = await context.params;
    const student = await updateStudentForAdmin(id, {
      ...body,
      gender: body.gender as Gender | undefined,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.student.updated",
      entityType: "Student",
      entityId: student.id,
    });

    return successResponse({ student });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageStudents");

    const { id } = await context.params;
    const student = await deactivateStudentForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.student.deactivated",
      entityType: "Student",
      entityId: id,
    });

    return successResponse({ student });
  } catch (error) {
    return handleError(error);
  }
}
