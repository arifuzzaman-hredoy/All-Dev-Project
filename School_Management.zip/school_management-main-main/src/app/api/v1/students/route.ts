import type { NextRequest } from "next/server";
import { Gender } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  createStudentForAdmin,
  listStudentsForAdmin,
} from "@/services/student.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createStudentSchema,
  studentListQuerySchema,
} from "@/validations/student.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageStudents");

    const filters = studentListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      includeDeleted: req.nextUrl.searchParams.get("includeDeleted") ?? false,
      page: req.nextUrl.searchParams.get("page") ?? undefined,
      pageSize: req.nextUrl.searchParams.get("pageSize") ?? undefined,
    });

    const result = await listStudentsForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageStudents");

    const body = createStudentSchema.parse(await req.json());
    const result = await createStudentForAdmin({
      ...body,
      gender: body.gender as Gender,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.student.created",
      entityType: "Student",
      entityId: result.student.id,
      metadata: { classId: result.student.classId },
    });

    return successResponse(result, 201);
  } catch (error) {
    return handleError(error);
  }
}
