import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { getAdminDashboard } from "@/services/adminDashboard.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "viewDashboard");
    const dashboard = await getAdminDashboard();
    return successResponse({ dashboard });
  } catch (error) {
    return handleError(error);
  }
}
