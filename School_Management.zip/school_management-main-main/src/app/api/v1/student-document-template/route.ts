import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import {
  fetchStudentDocumentTemplate,
  updateStudentDocumentTemplateForAdmin,
} from "@/services/studentDocumentTemplate.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";
import {
  updateStudentDocumentTemplateSchema,
} from "@/validations/student-document-template.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const template = await fetchStudentDocumentTemplate();

    return successResponse({ template });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const actorId = requireUserId(payload);
    const body = updateStudentDocumentTemplateSchema.parse(await req.json());

    const template = await updateStudentDocumentTemplateForAdmin({
      template: body,
      actorId,
    });

    return successResponse({ template });
  } catch (error) {
    return handleError(error);
  }
}
