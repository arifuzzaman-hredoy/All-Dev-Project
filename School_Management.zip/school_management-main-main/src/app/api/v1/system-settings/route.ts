import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import {
  listSystemSettingsForAdmin,
  updateSystemSettingForAdmin,
} from "@/services/systemSetting.service";
import { updateSystemSettingSchema } from "@/validations/system-setting.schema";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSettings");

    const { searchParams } = new URL(req.url);
    const settings = await listSystemSettingsForAdmin(
      searchParams.get("search") ?? undefined
    );

    return successResponse({ settings });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageSettings");
    const actorId = requireUserId(payload);
    const body = updateSystemSettingSchema.parse(await req.json());

    const setting = await updateSystemSettingForAdmin({
      key: body.key,
      value: body.value as Prisma.InputJsonValue,
      actorId,
    });

    return successResponse({ setting });
  } catch (error) {
    return handleError(error);
  }
}
