import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { listAttendanceForAdmin, upsertAttendanceBatch } from "@/services/attendance.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { attendanceListQuerySchema, upsertAttendanceSchema } from "@/validations/attendance.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAttendance");
    const filters = attendanceListQuerySchema.parse({
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      studentId: req.nextUrl.searchParams.get("studentId") ?? undefined,
      subjectId: req.nextUrl.searchParams.get("subjectId") ?? undefined,
      status: req.nextUrl.searchParams.get("status") ?? undefined,
      date: req.nextUrl.searchParams.get("date") ?? undefined,
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listAttendanceForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAttendance");
    const body = upsertAttendanceSchema.parse(await req.json());
    const result = await upsertAttendanceBatch({
      ...body,
      markedBy: requireUserId(payload),
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.attendance.upserted",
      entityType: "Attendance",
      metadata: { classId: body.classId, subjectId: body.subjectId, date: body.date, count: body.entries.length },
    });
    return successResponse(result, 201);
  } catch (error) {
    return handleError(error);
  }
}
