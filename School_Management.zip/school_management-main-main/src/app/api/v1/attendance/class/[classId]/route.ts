import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { listAttendanceForAdmin } from "@/services/attendance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { attendanceListQuerySchema } from "@/validations/attendance.schema";

type RouteContext = { params: Promise<{ classId: string }> };

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAttendance");
    const { classId } = await context.params;
    const filters = attendanceListQuerySchema.parse({
      classId,
      subjectId: req.nextUrl.searchParams.get("subjectId") ?? undefined,
      status: req.nextUrl.searchParams.get("status") ?? undefined,
      date: req.nextUrl.searchParams.get("date") ?? undefined,
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listAttendanceForAdmin({
      ...filters,
      classId,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
