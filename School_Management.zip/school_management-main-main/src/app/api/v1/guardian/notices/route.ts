import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { listGuardianNotices } from "@/services/guardianPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const { searchParams } = new URL(req.url);
    const result = await listGuardianNotices(userId, searchParams.get("studentId"));
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
