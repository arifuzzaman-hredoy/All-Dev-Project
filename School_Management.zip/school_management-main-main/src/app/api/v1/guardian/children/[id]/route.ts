import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { getGuardianChildDetail } from "@/services/guardianPortal.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const { id } = await context.params;
    const child = await getGuardianChildDetail(userId, id);
    return successResponse(child);
  } catch (error) {
    return handleError(error);
  }
}
