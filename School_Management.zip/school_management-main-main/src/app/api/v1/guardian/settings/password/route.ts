import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { updateGuardianPassword } from "@/services/guardianPortal.service";
import { teacherPasswordUpdateSchema } from "@/validations/teacher-portal.schema";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const body = teacherPasswordUpdateSchema.parse(await req.json());
    const result = await updateGuardianPassword(userId, {
      currentPassword: body.currentPassword,
      newPassword: body.newPassword,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
