import { Role } from "@prisma/client";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { listGuardianFees } from "@/services/guardianPortal.service";
import { recordAuditEvent } from "@/services/audit.service";
import { buildMoneyReceiptHtml } from "@/lib/money-receipt";
import { handleError } from "@/utils/error-handler";

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const params = await context.params;
    const { searchParams } = new URL(req.url);
    const studentId = searchParams.get("studentId");

    const result = await listGuardianFees(userId, studentId);
    const payment = result.payments.find((item) => item.id === params.id);

    if (!payment) {
      return new NextResponse("Receipt not found", { status: 404 });
    }

    await recordAuditEvent({
      actorId: userId,
      action: "guardian.payment_receipt.downloaded",
      entityType: "Payment",
      entityId: payment.id,
      metadata: {
        studentId: payment.student.id,
        status: payment.status,
        month: payment.billingMonth,
        year: payment.billingYear,
        amountPaid: payment.amountPaid,
      },
    });

    const html = buildMoneyReceiptHtml(payment, {
      schoolName: process.env.SCHOOL_NAME,
    });

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Disposition": `attachment; filename="money-receipt-${payment.id}.html"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
