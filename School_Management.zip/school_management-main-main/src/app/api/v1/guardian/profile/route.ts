import type { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { getGuardianProfile, updateGuardianProfile } from "@/services/guardianPortal.service";
import { updateGuardianProfileSchema } from "@/validations/guardian.schema";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const profile = await getGuardianProfile(userId);
    return successResponse(profile);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const raw = updateGuardianProfileSchema.parse(await req.json());
    const result = await updateGuardianProfile(userId, {
      name: raw.name,
      email: raw.email,
      phone: raw.phone ?? null,
      address: raw.address ?? null,
    });
    return successResponse({ profile: result });
  } catch (error) {
    return handleError(error);
  }
}
