import { Role } from "@prisma/client";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requireRole, requireUserId } from "@/lib/permissions";
import { listGuardianResults } from "@/services/guardianPortal.service";
import { recordAuditEvent } from "@/services/audit.service";
import { handleError } from "@/utils/error-handler";

function escapeHtml(value: string | number | null | undefined) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requireRole(payload, [Role.PARENT]);
    const userId = requireUserId(payload);
    const { searchParams } = new URL(req.url);
    const studentId = searchParams.get("studentId");

    const result = await listGuardianResults(userId, studentId);
    const selectedChild =
      result.children.find((child) => child.id === result.selectedStudentId) ??
      result.children[0];

    if (!selectedChild) {
      return new NextResponse("No child linked to this guardian account", { status: 404 });
    }

    const filteredResults = result.results.filter((item) => item.student.id === selectedChild.id);

    await recordAuditEvent({
      actorId: userId,
      action: "guardian.report_card.downloaded",
      entityType: "Student",
      entityId: selectedChild.id,
      metadata: {
        totalResults: filteredResults.length,
      },
    });

    const html = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Report Card - ${escapeHtml(selectedChild.name)}</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 32px; color: #111827; }
      h1, h2, p { margin: 0 0 12px; }
      table { width: 100%; border-collapse: collapse; margin-top: 16px; }
      th, td { border: 1px solid #d1d5db; padding: 10px; text-align: left; font-size: 14px; }
      th { background: #f3f4f6; }
      .meta { color: #4b5563; font-size: 14px; }
    </style>
  </head>
  <body>
    <h1>Student Report Card</h1>
    <p class="meta">${escapeHtml(selectedChild.name)} · ${escapeHtml(selectedChild.className)} · Roll ${selectedChild.rollNumber ?? "-"}</p>
    <p class="meta">Generated on ${new Date().toLocaleString()}</p>
    <table>
      <thead>
        <tr>
          <th>Exam</th>
          <th>Date</th>
          <th>Subject</th>
          <th>Marks</th>
          <th>Grade</th>
        </tr>
      </thead>
      <tbody>
        ${
          filteredResults.length > 0
            ? filteredResults
                .map(
                  (item) => `<tr>
          <td>${escapeHtml(item.exam.name)}</td>
          <td>${escapeHtml(new Date(item.exam.date).toLocaleDateString())}</td>
          <td>${escapeHtml(item.subject.name)}</td>
          <td>${item.marks} out of ${item.totalMarks}</td>
          <td>${escapeHtml(item.grade ?? "-")}</td>
        </tr>`
                )
                .join("")
            : '<tr><td colspan="5">No results available.</td></tr>'
        }
      </tbody>
    </table>
  </body>
</html>`;

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Disposition": `attachment; filename="report-card-${selectedChild.id}.html"`,
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
