import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { listTrashItems } from "@/services/trash.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { trashListQuerySchema } from "@/validations/trash.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTrash");

    const { searchParams } = new URL(req.url);
    const query = trashListQuerySchema.parse({
      search: searchParams.get("search") ?? undefined,
      entityType: searchParams.get("entityType") ?? undefined,
      limit: searchParams.get("limit") ?? undefined,
      page: searchParams.get("page") ?? undefined,
    });

    const trash = await listTrashItems(payload.role, query);
    return successResponse(trash);
  } catch (error) {
    return handleError(error);
  }
}

