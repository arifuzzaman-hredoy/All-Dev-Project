import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { restoreTrashItem } from "@/services/trash.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { trashRestoreSchema } from "@/validations/trash.schema";

const RESTORE_ACTIONS: Record<string, string> = {
  User: "admin.user.restored",
  Student: "admin.student.restored",
  Teacher: "admin.teacher.restored",
  Guardian: "admin.guardian.restored",
};

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTrash");

    const body = trashRestoreSchema.parse(await req.json());
    const result = await restoreTrashItem(payload.role, body);

    await recordAuditEvent({
      actorId: payload.id,
      action: RESTORE_ACTIONS[body.entityType] ?? "admin.trash.restored",
      entityType: body.entityType,
      entityId: body.entityId,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

