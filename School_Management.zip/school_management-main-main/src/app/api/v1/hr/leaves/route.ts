import type { NextRequest } from "next/server";
import type { LeaveStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { createTeacherLeaveForAdmin, listTeacherLeavesForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createTeacherLeaveSchema, teacherLeaveListQuerySchema } from "@/validations/hr.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const query = teacherLeaveListQuerySchema.parse({
      status: req.nextUrl.searchParams.get("status") ?? undefined,
      teacherId: req.nextUrl.searchParams.get("teacherId") ?? undefined,
    });

    const result = await listTeacherLeavesForAdmin({
      status: query.status as LeaveStatus | undefined,
      teacherId: query.teacherId,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const actorId = requireUserId(payload);
    const body = createTeacherLeaveSchema.parse(await req.json());
    const leave = await createTeacherLeaveForAdmin(body);
    await recordAuditEvent({
      actorId,
      action: "admin.teacher_leave.created",
      entityType: "TeacherLeaveRequest",
      entityId: leave.id,
    });
    return successResponse({ leave }, 201);
  } catch (error) {
    return handleError(error);
  }
}
