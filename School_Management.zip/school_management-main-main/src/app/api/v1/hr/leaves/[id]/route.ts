import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { decideTeacherLeaveForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { decideTeacherLeaveSchema } from "@/validations/hr.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const actorId = requireUserId(payload);
    const body = decideTeacherLeaveSchema.parse(await req.json());
    const { id } = await context.params;
    const leave = await decideTeacherLeaveForAdmin({
      leaveId: id,
      status: body.status as "APPROVED" | "REJECTED" | "CANCELLED",
      actorId,
    });
    await recordAuditEvent({
      actorId,
      action: "admin.teacher_leave.decided",
      entityType: "TeacherLeaveRequest",
      entityId: leave.id,
      metadata: { status: leave.status },
    });
    return successResponse({ leave });
  } catch (error) {
    return handleError(error);
  }
}
