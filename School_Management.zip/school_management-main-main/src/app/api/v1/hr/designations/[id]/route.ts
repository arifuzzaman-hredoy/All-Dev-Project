import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { updateDesignationForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateDesignationSchema } from "@/validations/hr.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const body = updateDesignationSchema.parse(await req.json());
    const { id } = await context.params;
    const designation = await updateDesignationForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.designation.updated",
      entityType: "Designation",
      entityId: designation.id,
    });
    return successResponse({ designation });
  } catch (error) {
    return handleError(error);
  }
}

