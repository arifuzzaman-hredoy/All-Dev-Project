import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { createDesignationForAdmin, listDesignationsForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createDesignationSchema, hrListQuerySchema } from "@/validations/hr.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const query = hrListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listDesignationsForAdmin(query.search);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const body = createDesignationSchema.parse(await req.json());
    const designation = await createDesignationForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.designation.created",
      entityType: "Designation",
      entityId: designation.id,
    });
    return successResponse({ designation }, 201);
  } catch (error) {
    return handleError(error);
  }
}

