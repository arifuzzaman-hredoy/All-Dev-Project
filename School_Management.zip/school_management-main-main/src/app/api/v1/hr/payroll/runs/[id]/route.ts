import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { getPayrollRunDetailsForAdmin, lockPayrollRunForAdmin, markPayrollRunPaidForAdmin } from "@/services/payroll.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");
    const { id } = await context.params;
    const result = await getPayrollRunDetailsForAdmin(id);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");
    const actorId = requireUserId(payload);
    const { id } = await context.params;
    const action = req.nextUrl.searchParams.get("action");
    if (action === "lock") {
      const run = await lockPayrollRunForAdmin(id);
      await recordAuditEvent({
        actorId,
        action: "admin.payroll_run.locked",
        entityType: "PayrollRun",
        entityId: run.id,
      });
      return successResponse({ run });
    }
    if (action === "pay") {
      const result = await markPayrollRunPaidForAdmin(id);
      await recordAuditEvent({
        actorId,
        action: "admin.payroll_run.paid",
        entityType: "PayrollRun",
        entityId: id,
        metadata: result,
      });
      return successResponse(result);
    }

    return successResponse({ message: "No action taken" });
  } catch (error) {
    return handleError(error);
  }
}

