import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { updatePayrollItemForAdmin } from "@/services/payroll.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updatePayrollItemSchema } from "@/validations/payroll.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");
    const actorId = requireUserId(payload);
    const body = updatePayrollItemSchema.parse(await req.json());
    const { id } = await context.params;
    const item = await updatePayrollItemForAdmin({ payrollItemId: id, ...body });
    await recordAuditEvent({
      actorId,
      action: "admin.payroll_item.updated",
      entityType: "PayrollItem",
      entityId: item.id,
    });
    return successResponse({ item });
  } catch (error) {
    return handleError(error);
  }
}

