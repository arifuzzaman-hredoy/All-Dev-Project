import type { NextRequest } from "next/server";
import { PayrollRunStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { generatePayrollRunForAdmin, listPayrollRunsForAdmin } from "@/services/payroll.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { generatePayrollRunSchema, payrollRunListQuerySchema } from "@/validations/payroll.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");
    const query = payrollRunListQuerySchema.parse({
      status: req.nextUrl.searchParams.get("status") ?? undefined,
    });
    const result = await listPayrollRunsForAdmin({
      status: query.status as PayrollRunStatus | undefined,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");
    const actorId = requireUserId(payload);
    const body = generatePayrollRunSchema.parse(await req.json());
    const run = await generatePayrollRunForAdmin({ ...body, actorId });
    await recordAuditEvent({
      actorId,
      action: "admin.payroll_run.generated",
      entityType: "PayrollRun",
      entityId: run.id,
      metadata: { month: run.month, year: run.year },
    });
    return successResponse({ run }, 201);
  } catch (error) {
    return handleError(error);
  }
}

