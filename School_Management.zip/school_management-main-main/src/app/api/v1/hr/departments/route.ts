import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { createDepartmentForAdmin, listDepartmentsForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createDepartmentSchema, hrListQuerySchema } from "@/validations/hr.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const query = hrListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listDepartmentsForAdmin(query.search);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const body = createDepartmentSchema.parse(await req.json());
    const department = await createDepartmentForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.department.created",
      entityType: "Department",
      entityId: department.id,
    });
    return successResponse({ department }, 201);
  } catch (error) {
    return handleError(error);
  }
}

