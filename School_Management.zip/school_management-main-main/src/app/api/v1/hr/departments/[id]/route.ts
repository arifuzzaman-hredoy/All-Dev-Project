import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { updateDepartmentForAdmin } from "@/services/hr.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateDepartmentSchema } from "@/validations/hr.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");
    const body = updateDepartmentSchema.parse(await req.json());
    const { id } = await context.params;
    const department = await updateDepartmentForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.department.updated",
      entityType: "Department",
      entityId: department.id,
    });
    return successResponse({ department });
  } catch (error) {
    return handleError(error);
  }
}

