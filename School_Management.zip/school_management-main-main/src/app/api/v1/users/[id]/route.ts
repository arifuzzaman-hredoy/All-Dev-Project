import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deactivateAdminUser, updateAdminUser } from "@/services/user.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateManagedUserSchema } from "@/validations/user.schema";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");

    const body = updateManagedUserSchema.parse(await req.json());
    const { id } = await context.params;
    const user = await updateAdminUser(payload.id, payload.role, payload.branchId, id, {
      ...body,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.user.updated",
      entityType: "User",
      entityId: user.id,
      metadata: { role: user.role },
    });

    return successResponse({ user });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");

    const { id } = await context.params;
    const user = await deactivateAdminUser(payload.id, payload.role, payload.branchId, id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.user.deactivated",
      entityType: "User",
      entityId: id,
    });

    return successResponse({ user });
  } catch (error) {
    return handleError(error);
  }
}
