import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createAdminUser, listAdminUsers } from "@/services/user.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createManagedUserSchema,
  userListQuerySchema,
} from "@/validations/user.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");

    const filters = userListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      role: req.nextUrl.searchParams.get("role") ?? undefined,
      includeDeleted: req.nextUrl.searchParams.get("includeDeleted") ?? false,
    });

    const result = await listAdminUsers(payload.role, payload.branchId, {
      search: filters.search,
      role: filters.role,
      includeDeleted: filters.includeDeleted,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");

    const body = createManagedUserSchema.parse(await req.json());
    const user = await createAdminUser(payload.role, payload.branchId, {
      ...body,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.user.created",
      entityType: "User",
      entityId: user.id,
      metadata: { role: user.role },
    });

    return successResponse(
      {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          branchId: user.branchId,
          isDeleted: user.isDeleted,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
        },
      },
      201
    );
  } catch (error) {
    return handleError(error);
  }
}
