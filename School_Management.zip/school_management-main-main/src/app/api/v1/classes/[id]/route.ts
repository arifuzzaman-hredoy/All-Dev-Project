import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deleteClassForAdmin,
  updateClassForAdmin,
} from "@/services/class.service";
import { recordAuditEvent } from "@/services/audit.service";
import { handleError } from "@/utils/error-handler";
import { successResponse } from "@/utils/api-response";
import { updateClassSchema } from "@/validations/class.schema";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const body = updateClassSchema.parse(await req.json());
    const { id } = await context.params;
    const classRecord = await updateClassForAdmin(id, body);
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.updated",
      entityType: "Class",
      entityId: classRecord.id,
    }).catch((error) => {
      console.error("Failed to record class update audit event", error);
    });
    return successResponse({ class: classRecord });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const { id } = await context.params;
    const classRecord = await deleteClassForAdmin(id);
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.deleted",
      entityType: "Class",
      entityId: id,
    }).catch((error) => {
      console.error("Failed to record class delete audit event", error);
    });
    return successResponse({ class: classRecord });
  } catch (error) {
    return handleError(error);
  }
}
