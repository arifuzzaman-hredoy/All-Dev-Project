import type { NextRequest } from "next/server";

import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateGroupSchema } from "@/validations/class.schema";
import {
  deleteGroupForClassForAdmin,
  updateGroupForClassForAdmin,
} from "@/services/class-group.service";
import { recordAuditEvent } from "@/services/audit.service";

type RouteContext = {
  params: Promise<{ id: string; groupId: string }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const body = updateGroupSchema.parse(await req.json());
    const { id: classId, groupId } = await context.params;
    const group = await updateGroupForClassForAdmin({ classId, groupId, ...body });
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.group.updated",
      entityType: "Group",
      entityId: group.id,
    }).catch((error) => {
      console.error("Failed to record group update audit event", error);
    });
    return successResponse({ group });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const { id: classId, groupId } = await context.params;
    const group = await deleteGroupForClassForAdmin({ classId, groupId });
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.group.deleted",
      entityType: "Group",
      entityId: groupId,
    }).catch((error) => {
      console.error("Failed to record group delete audit event", error);
    });
    return successResponse({ group });
  } catch (error) {
    return handleError(error);
  }
}
