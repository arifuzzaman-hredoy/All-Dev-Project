import type { NextRequest } from "next/server";

import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createGroupSchema, groupListQuerySchema } from "@/validations/class.schema";
import {
  createGroupForClassForAdmin,
  listGroupsForClassForAdmin,
} from "@/services/class-group.service";
import { recordAuditEvent } from "@/services/audit.service";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const { id: classId } = await context.params;
    const filters = groupListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listGroupsForClassForAdmin({ classId, search: filters.search });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const { id: classId } = await context.params;
    const body = createGroupSchema.parse(await req.json());
    const group = await createGroupForClassForAdmin({ classId, ...body });
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.group.created",
      entityType: "Group",
      entityId: group.id,
    }).catch((error) => {
      console.error("Failed to record group create audit event", error);
    });
    return successResponse({ group }, 201);
  } catch (error) {
    return handleError(error);
  }
}
