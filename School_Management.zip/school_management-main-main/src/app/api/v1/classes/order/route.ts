import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { reorderClassesForAdmin } from "@/services/class.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { reorderClassesSchema } from "@/validations/class.schema";

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");

    const body = reorderClassesSchema.parse(await req.json());
    const result = await reorderClassesForAdmin(body.orderedClassIds);

    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.reordered",
      entityType: "Class",
      entityId: null,
      metadata: { orderedClassIds: body.orderedClassIds },
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

