import type { NextRequest } from "next/server";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createClassForAdmin,
  listClassesForAdmin,
} from "@/services/class.service";
import { recordAuditEvent } from "@/services/audit.service";
import {
  createClassSchema,
  classListQuerySchema,
} from "@/validations/class.schema";
import { listClassesForBranch } from "@/repositories/class.repository";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";

export async function GET(req: NextRequest) {
  try {
    const headerValue = req.headers.get("authorization");
    if (!headerValue) {
      const branchId = req.nextUrl.searchParams.get("branchId")?.trim();
      if (!branchId) {
        return successResponse({ classes: [] });
      }
      const classes = await listClassesForBranch(branchId);
      return successResponse({ classes });
    }

    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const filters = classListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listClassesForAdmin(filters.search);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageClasses");
    const body = createClassSchema.parse(await req.json());
    const classRecord = await createClassForAdmin(body);
    void recordAuditEvent({
      actorId: payload.id,
      action: "admin.class.created",
      entityType: "Class",
      entityId: classRecord.id,
    }).catch((error) => {
      console.error("Failed to record class create audit event", error);
    });
    return successResponse({ class: classRecord }, 201);
  } catch (error) {
    return handleError(error);
  }
}
