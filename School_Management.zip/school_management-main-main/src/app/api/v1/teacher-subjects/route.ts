import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  createTeacherSubjectForAdmin,
  listTeacherSubjectsForAdmin,
} from "@/services/teacherSubject.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createTeacherSubjectSchema,
  teacherSubjectListQuerySchema,
} from "@/validations/teacher-subject.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const filters = teacherSubjectListQuerySchema.parse({
      teacherId: req.nextUrl.searchParams.get("teacherId") ?? undefined,
      classId: req.nextUrl.searchParams.get("classId") ?? undefined,
      subjectId: req.nextUrl.searchParams.get("subjectId") ?? undefined,
    });
    const result = await listTeacherSubjectsForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = createTeacherSubjectSchema.parse(await req.json());
    const assignment = await createTeacherSubjectForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher_subject.created",
      entityType: "TeacherSubject",
      entityId: assignment.id,
    });
    return successResponse({ assignment }, 201);
  } catch (error) {
    return handleError(error);
  }
}
