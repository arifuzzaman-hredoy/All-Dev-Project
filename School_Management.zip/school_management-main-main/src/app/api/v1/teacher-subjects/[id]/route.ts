import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deleteTeacherSubjectForAdmin,
  updateTeacherSubjectForAdmin,
} from "@/services/teacherSubject.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateTeacherSubjectSchema } from "@/validations/teacher-subject.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const body = updateTeacherSubjectSchema.parse(await req.json());
    const { id } = await context.params;
    const assignment = await updateTeacherSubjectForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher_subject.updated",
      entityType: "TeacherSubject",
      entityId: assignment.id,
    });
    return successResponse({ assignment });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageAcademicData");
    const { id } = await context.params;
    const assignment = await deleteTeacherSubjectForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher_subject.deleted",
      entityType: "TeacherSubject",
      entityId: id,
    });
    return successResponse({ assignment });
  } catch (error) {
    return handleError(error);
  }
}
