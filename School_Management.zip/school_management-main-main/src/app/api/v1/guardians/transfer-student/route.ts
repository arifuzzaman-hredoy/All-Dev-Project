import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { transferStudentToGuardianForAdmin } from "@/services/guardian.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { transferGuardianStudentSchema } from "@/validations/guardian.schema";

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");
    const body = transferGuardianStudentSchema.parse(await req.json());
    const result = await transferStudentToGuardianForAdmin(body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.guardian_student.transferred",
      entityType: "Student",
      entityId: result.student.id,
      metadata: {
        fromGuardianId: result.fromGuardian.id,
        fromGuardianName: result.fromGuardian.name,
        toGuardianId: result.toGuardian.id,
        toGuardianName: result.toGuardian.name,
      },
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}
