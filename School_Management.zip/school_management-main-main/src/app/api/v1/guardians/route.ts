import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createGuardianForAdmin, listGuardiansForAdmin } from "@/services/guardian.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createGuardianSchema, guardianListQuerySchema } from "@/validations/guardian.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");
    const filters = guardianListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      unlinkedStudentsOnly: req.nextUrl.searchParams.get("unlinkedStudentsOnly") ?? false,
      page: req.nextUrl.searchParams.get("page") ?? undefined,
      pageSize: req.nextUrl.searchParams.get("pageSize") ?? undefined,
    });
    const result = await listGuardiansForAdmin(filters);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");
    const body = createGuardianSchema.parse(await req.json());
    const guardian = await createGuardianForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.guardian.created",
      entityType: "Guardian",
      entityId: guardian.id,
    });
    return successResponse({ guardian }, 201);
  } catch (error) {
    return handleError(error);
  }
}
