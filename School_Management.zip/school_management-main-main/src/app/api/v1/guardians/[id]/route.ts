import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deactivateGuardianForAdmin, updateGuardianForAdmin } from "@/services/guardian.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateGuardianSchema } from "@/validations/guardian.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");
    const body = updateGuardianSchema.parse(await req.json());
    const { id } = await context.params;
    const guardian = await updateGuardianForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.guardian.updated",
      entityType: "Guardian",
      entityId: guardian.id,
    });
    return successResponse({ guardian });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageUsers");
    const { id } = await context.params;
    const guardian = await deactivateGuardianForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.guardian.deactivated",
      entityType: "Guardian",
      entityId: id,
    });
    return successResponse({ guardian });
  } catch (error) {
    return handleError(error);
  }
}
