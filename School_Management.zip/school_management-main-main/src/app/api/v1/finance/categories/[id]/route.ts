import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { updateFinanceCategoryForAdmin } from "@/services/finance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateFinanceCategorySchema } from "@/validations/finance.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const body = updateFinanceCategorySchema.parse(await req.json());
    const { id } = await context.params;
    const category = await updateFinanceCategoryForAdmin(id, body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.finance_category.updated",
      entityType: "FinanceCategory",
      entityId: category.id,
    });

    return successResponse({ category });
  } catch (error) {
    return handleError(error);
  }
}

