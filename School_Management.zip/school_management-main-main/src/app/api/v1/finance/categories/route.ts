import type { NextRequest } from "next/server";
import { FinanceEntryType } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  createFinanceCategoryForAdmin,
  listFinanceCategoriesForAdmin,
} from "@/services/finance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createFinanceCategorySchema,
  financeCategoryListQuerySchema,
} from "@/validations/finance.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const filters = financeCategoryListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      type: req.nextUrl.searchParams.get("type") ?? undefined,
    });

    const result = await listFinanceCategoriesForAdmin({
      search: filters.search,
      type: filters.type as FinanceEntryType | undefined,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const body = createFinanceCategorySchema.parse(await req.json());
    const category = await createFinanceCategoryForAdmin({
      name: body.name,
      type: body.type as FinanceEntryType,
      isActive: body.isActive,
    });

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.finance_category.created",
      entityType: "FinanceCategory",
      entityId: category.id,
    });

    return successResponse({ category }, 201);
  } catch (error) {
    return handleError(error);
  }
}

