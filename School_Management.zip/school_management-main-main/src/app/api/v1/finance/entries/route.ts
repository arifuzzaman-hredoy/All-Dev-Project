import type { NextRequest } from "next/server";
import { FinanceEntryType } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  createFinanceEntryForAdmin,
  listFinanceEntriesForAdmin,
} from "@/services/finance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createFinanceEntrySchema,
  financeEntryListQuerySchema,
} from "@/validations/finance.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const query = financeEntryListQuerySchema.parse({
      type: req.nextUrl.searchParams.get("type") ?? undefined,
      categoryId: req.nextUrl.searchParams.get("categoryId") ?? undefined,
      studentId: req.nextUrl.searchParams.get("studentId") ?? undefined,
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      from: req.nextUrl.searchParams.get("from") ?? undefined,
      to: req.nextUrl.searchParams.get("to") ?? undefined,
      includeDeleted: req.nextUrl.searchParams.get("includeDeleted") ?? undefined,
    });

    const result = await listFinanceEntriesForAdmin({
      ...query,
      type: query.type as FinanceEntryType | undefined,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const body = createFinanceEntrySchema.parse(await req.json());
    const entry = await createFinanceEntryForAdmin(payload.id, {
      type: body.type as FinanceEntryType,
      categoryId: body.categoryId,
      amount: body.amount,
      occurredAt: body.occurredAt,
      description: body.description,
      studentId: body.studentId,
    });

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.finance_entry.created",
      entityType: "FinanceEntry",
      entityId: entry.id,
      metadata: {
        type: entry.type,
        amount: entry.amount,
        categoryId: entry.category.id,
      },
    });

    return successResponse({ entry }, 201);
  } catch (error) {
    return handleError(error);
  }
}

