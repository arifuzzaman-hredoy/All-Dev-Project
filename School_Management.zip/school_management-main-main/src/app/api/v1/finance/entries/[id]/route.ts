import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  softDeleteFinanceEntryForAdmin,
  updateFinanceEntryForAdmin,
} from "@/services/finance.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateFinanceEntrySchema } from "@/validations/finance.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const body = updateFinanceEntrySchema.parse(await req.json());
    const { id } = await context.params;
    const entry = await updateFinanceEntryForAdmin(id, body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.finance_entry.updated",
      entityType: "FinanceEntry",
      entityId: entry.id,
    });

    return successResponse({ entry });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFinance");

    const { id } = await context.params;
    const entry = await softDeleteFinanceEntryForAdmin(id);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.finance_entry.deleted",
      entityType: "FinanceEntry",
      entityId: entry.id,
    });

    return successResponse({ entry });
  } catch (error) {
    return handleError(error);
  }
}

