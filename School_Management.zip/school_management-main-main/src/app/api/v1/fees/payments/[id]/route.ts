import type { NextRequest } from "next/server";
import { PaymentStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { deletePaymentForAdmin, updatePaymentForAdmin } from "@/services/payment.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updatePaymentSchema } from "@/validations/payment.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "managePayments");
    const body = updatePaymentSchema.parse(await req.json());
    const { id } = await context.params;
    const payment = await updatePaymentForAdmin(id, {
      ...body,
      status: body.status as PaymentStatus | undefined,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.payment.updated",
      entityType: "Payment",
      entityId: payment.id,
    });
    return successResponse({ payment });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "managePayments");
    const { id } = await context.params;
    const payment = await deletePaymentForAdmin(id);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.payment.deleted",
      entityType: "Payment",
      entityId: id,
    });
    return successResponse({ payment });
  } catch (error) {
    return handleError(error);
  }
}
