import type { NextRequest } from "next/server";
import { PaymentStatus } from "@prisma/client";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createPaymentForAdmin, listPaymentsForAdmin } from "@/services/payment.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createPaymentSchema, paymentListQuerySchema } from "@/validations/payment.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "managePayments");
    const filters = paymentListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      status: req.nextUrl.searchParams.get("status") ?? undefined,
      studentId: req.nextUrl.searchParams.get("studentId") ?? undefined,
      feeCategoryId: req.nextUrl.searchParams.get("feeCategoryId") ?? undefined,
    });
    const result = await listPaymentsForAdmin({
      ...filters,
      status: filters.status as PaymentStatus | undefined,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "managePayments");
    const body = createPaymentSchema.parse(await req.json());
    const payment = await createPaymentForAdmin({
      ...body,
      status: body.status as PaymentStatus,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.payment.created",
      entityType: "Payment",
      entityId: payment.id,
    });
    return successResponse({ payment }, 201);
  } catch (error) {
    return handleError(error);
  }
}
