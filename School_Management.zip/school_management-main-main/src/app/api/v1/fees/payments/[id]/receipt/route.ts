import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { buildFeeLedger } from "@/lib/fee-history";
import { requireAuth } from "@/lib/auth";
import { requirePermission, requireUserId } from "@/lib/permissions";
import { buildMoneyReceiptHtml } from "@/lib/money-receipt";
import { findPaymentById } from "@/repositories/payment.repository";
import { recordAuditEvent } from "@/services/audit.service";
import { handleError } from "@/utils/error-handler";

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "managePayments");
    const userId = requireUserId(payload);
    const params = await context.params;

    const sourcePayment = await findPaymentById(params.id);
    const payment = sourcePayment
      ? buildFeeLedger([sourcePayment]).payments[0]
      : null;

    if (!payment) {
      return new NextResponse("Receipt not found", { status: 404 });
    }

    await recordAuditEvent({
      actorId: userId,
      action: "admin.payment_receipt.downloaded",
      entityType: "Payment",
      entityId: payment.id,
      metadata: {
        studentId: payment.student.id,
        status: payment.status,
        month: payment.billingMonth,
        year: payment.billingYear,
        amountPaid: payment.amountPaid,
      },
    });

    const html = buildMoneyReceiptHtml(payment, {
      schoolName: process.env.SCHOOL_NAME,
    });

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Disposition": `attachment; filename="money-receipt-${payment.id}.html"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return handleError(error);
  }
}