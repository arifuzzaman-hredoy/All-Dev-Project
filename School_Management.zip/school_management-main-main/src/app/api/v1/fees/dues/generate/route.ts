import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import { generateDuesForPeriod } from "@/services/due.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { duePeriodSchema } from "@/validations/due.schema";

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");

    const body = duePeriodSchema.parse(await req.json());
    const result = await generateDuesForPeriod(body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.dues.generated",
      entityType: "Payment",
      entityId: null,
      metadata: body,
    });

    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

