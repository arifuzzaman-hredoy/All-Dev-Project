import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { createFeeCategoryForAdmin, listFeeCategoriesForAdmin } from "@/services/feeCategory.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { createFeeCategorySchema, feeCategoryListQuerySchema } from "@/validations/payment.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const filters = feeCategoryListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
    });
    const result = await listFeeCategoriesForAdmin(filters.search);
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const body = createFeeCategorySchema.parse(await req.json());
    const category = await createFeeCategoryForAdmin(body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.fee_category.created",
      entityType: "FeeCategory",
      entityId: category.id,
    });
    return successResponse({ category }, 201);
  } catch (error) {
    return handleError(error);
  }
}
