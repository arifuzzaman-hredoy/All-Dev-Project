import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deleteFeeCategoryForAdmin,
  updateFeeCategoryForAdmin,
} from "@/services/feeCategory.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  deleteFeeCategorySchema,
  updateFeeCategorySchema,
} from "@/validations/payment.schema";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const body = updateFeeCategorySchema.parse(await req.json());
    const { id } = await context.params;
    const category = await updateFeeCategoryForAdmin(id, body);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.fee_category.updated",
      entityType: "FeeCategory",
      entityId: category.id,
    });
    return successResponse({ category });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const { id } = await context.params;
    // Read JSON body if present; Next.js `NextRequest` may not expose `body` directly,
    // so always attempt to parse JSON and fallback to an empty object on error.
    const rawBody = await req.json().catch(() => ({}));
    const body = deleteFeeCategorySchema.parse(rawBody);
    const permanent =
      body.force || req.nextUrl.searchParams.get("permanent") === "true";
    const category = await deleteFeeCategoryForAdmin(id, {
      actorId: payload.id,
      permanent,
      force: body.force,
      currentPassword: body.currentPassword,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: body.force
        ? "admin.fee_category.force_deleted"
        : permanent
          ? "admin.fee_category.permanently_deleted"
          : "admin.fee_category.deleted",
      entityType: "FeeCategory",
      entityId: id,
    });
    return successResponse({ category });
  } catch (error) {
    return handleError(error);
  }
}
