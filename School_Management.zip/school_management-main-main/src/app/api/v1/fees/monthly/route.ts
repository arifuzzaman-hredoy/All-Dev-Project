import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import { recordAuditEvent } from "@/services/audit.service";
import {
  listClassMonthlyFeesForAdmin,
  setClassMonthlyFeeForAdmin,
} from "@/services/classFee.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { classMonthlyFeeSchema } from "@/validations/class-fee.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const result = await listClassMonthlyFeesForAdmin();
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageFees");
    const body = classMonthlyFeeSchema.parse(await req.json());
    const classFee = await setClassMonthlyFeeForAdmin(body);

    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.class_monthly_fee.updated",
      entityType: "Class",
      entityId: classFee.classId,
      metadata: { monthlyFee: classFee.monthlyFee },
    });

    return successResponse({ classFee });
  } catch (error) {
    return handleError(error);
  }
}
