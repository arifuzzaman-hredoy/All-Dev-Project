import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  deactivateTeacherForAdmin,
  updateTeacherForAdmin,
} from "@/services/teacher.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import { updateTeacherSchema } from "@/validations/teacher.schema";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");

    const body = updateTeacherSchema.parse(await req.json());
    const { id } = await context.params;
    const teacher = await updateTeacherForAdmin(id, body, payload);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher.updated",
      entityType: "Teacher",
      entityId: teacher.id,
    });

    return successResponse({ teacher });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");

    const { id } = await context.params;
    const teacher = await deactivateTeacherForAdmin(id, payload);
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher.deactivated",
      entityType: "Teacher",
      entityId: id,
    });

    return successResponse({ teacher });
  } catch (error) {
    return handleError(error);
  }
}
