import type { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { requirePermission } from "@/lib/permissions";
import {
  createTeacherForAdmin,
  listTeachersForAdmin,
} from "@/services/teacher.service";
import { recordAuditEvent } from "@/services/audit.service";
import { successResponse } from "@/utils/api-response";
import { handleError } from "@/utils/error-handler";
import {
  createTeacherSchema,
  teacherListQuerySchema,
} from "@/validations/teacher.schema";

export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");

    const filters = teacherListQuerySchema.parse({
      search: req.nextUrl.searchParams.get("search") ?? undefined,
      includeDeleted: req.nextUrl.searchParams.get("includeDeleted") ?? false,
    });

    const result = await listTeachersForAdmin({
      ...filters,
      branchId: payload.branchId,
    });
    return successResponse(result);
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req);
    requirePermission(payload, "manageTeachers");

    const body = createTeacherSchema.parse(await req.json());
    const teacher = await createTeacherForAdmin({
      ...body,
      branchId: payload.branchId,
    });
    await recordAuditEvent({
      actorId: payload.id,
      action: "admin.teacher.created",
      entityType: "Teacher",
      entityId: teacher.id,
    });

    return successResponse({ teacher }, 201);
  } catch (error) {
    return handleError(error);
  }
}
