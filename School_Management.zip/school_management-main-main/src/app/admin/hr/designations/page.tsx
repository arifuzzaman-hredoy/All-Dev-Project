import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { HrDesignationPanel } from "@/components/admin/hr-designation-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageTeachers">
      <HrDesignationPanel />
    </AdminAccessGuard>
  );
}

