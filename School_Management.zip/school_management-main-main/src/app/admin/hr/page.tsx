import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { HrOverviewPanel } from "@/components/admin/hr-overview-panel";

export default function Page() {
  return (
    <AdminAccessGuard anyPermissions={["manageTeachers", "manageFinance"]}>
      <HrOverviewPanel />
    </AdminAccessGuard>
  );
}
