import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { HrDepartmentPanel } from "@/components/admin/hr-department-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageTeachers">
      <HrDepartmentPanel />
    </AdminAccessGuard>
  );
}

