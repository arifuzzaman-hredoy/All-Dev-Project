import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { PayrollManagementPanel } from "@/components/admin/payroll-management-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageFinance">
      <PayrollManagementPanel />
    </AdminAccessGuard>
  );
}

