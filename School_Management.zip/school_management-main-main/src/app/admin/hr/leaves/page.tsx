import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { HrLeavePanel } from "@/components/admin/hr-leave-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageTeachers">
      <HrLeavePanel />
    </AdminAccessGuard>
  );
}

