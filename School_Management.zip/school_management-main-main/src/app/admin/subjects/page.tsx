import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { SubjectManagementPanel } from "@/components/admin/subject-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageSubjects">
      <SubjectManagementPanel />
    </AdminAccessGuard>
  )
}
