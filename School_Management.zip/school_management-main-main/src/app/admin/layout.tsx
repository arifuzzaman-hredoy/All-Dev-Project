import type { ReactNode } from "react"

import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { AppSidebar } from "@/components/app-sidebar"
import ModeToggle from "@/components/mode-toggle"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"

type AdminLayoutProps = {
  children: ReactNode
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  return (
    <AdminAccessGuard>
      <SidebarProvider>
        <AppSidebar />

        <SidebarInset className="flex min-h-screen flex-1 flex-col">
          <header className="flex h-14 items-center justify-between border-b px-4">
            <div className="flex items-center gap-2">
              <SidebarTrigger />
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">
                  Admin Console
                </p>
                <h1 className="text-sm font-semibold text-foreground">Control Room</h1>
              </div>
            </div>
            <ModeToggle />
          </header>

          <div className="flex flex-1 flex-col">{children}</div>
        </SidebarInset>
      </SidebarProvider>
    </AdminAccessGuard>
  )
}
