import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { ClassGroupManagementPanel } from "@/components/admin/class-group-management-panel";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function Page(props: PageProps) {
  const { id } = await props.params;

  return (
    <AdminAccessGuard permission="manageClasses">
      <ClassGroupManagementPanel classId={id} />
    </AdminAccessGuard>
  );
}

