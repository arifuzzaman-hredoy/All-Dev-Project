import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { ClassManagementPanel } from "@/components/admin/class-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageClasses">
      <ClassManagementPanel />
    </AdminAccessGuard>
  )
}
