import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { UserCreatePanel } from "@/components/admin/user-create-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageUsers">
      <AdminSectionPage
        title="Create user"
        description="Open a dedicated workspace for creating administrative user accounts."
        meta="Users"
      >
        <UserCreatePanel />
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
