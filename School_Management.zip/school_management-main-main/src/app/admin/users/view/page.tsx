import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { UserManagementPanel } from "@/components/admin/user-management-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageUsers">
      <UserManagementPanel />
    </AdminAccessGuard>
  );
}
