import Link from "next/link";

import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { Button } from "@/components/ui/button";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageUsers">
      <AdminSectionPage
        title="Users hub"
        description="Choose between creating a new administrative user account or browsing the current user directory."
        meta="Identity"
        actions={[
          {
            label: "Create users",
            href: "/admin/users/create",
            variant: "primary",
          },
          {
            label: "View users",
            href: "/admin/users/view",
            variant: "secondary",
          },
        ]}
      >
        <div className="grid gap-4 md:grid-cols-2">
          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              Create users
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Add a new account
            </h2>
            <p className="mt-2 leading-6">
              Open the create workspace to add a new administrative account with
              a scoped role and temporary password.
            </p>
            <Button asChild className="mt-4 rounded-2xl">
              <Link href="/admin/users/create">Open create page</Link>
            </Button>
          </article>

          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              View users
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Manage the directory
            </h2>
            <p className="mt-2 leading-6">
              Open the view workspace to search, edit, and deactivate existing
              administrative accounts.
            </p>
            <Button asChild variant="secondary" className="mt-4 rounded-2xl">
              <Link href="/admin/users/view">Open view page</Link>
            </Button>
          </article>
        </div>
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
