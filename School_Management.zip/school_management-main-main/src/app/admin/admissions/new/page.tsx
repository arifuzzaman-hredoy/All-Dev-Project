import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { AdmissionNewApplicationPanel } from "@/components/admin/admission-new-application-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAdmissions">
      <AdminSectionPage
        title="New admission application"
        description="Create a fresh admission submission without opening the full admission queue."
        meta="Admissions"
      >
        <AdmissionNewApplicationPanel />
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
