import Link from "next/link";

import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { Button } from "@/components/ui/button";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAdmissions">
      <AdminSectionPage
        title="Admissions hub"
        description="Open the new application workspace or jump straight into the admissions queue to review and edit submissions."
        meta="Admissions"
        actions={[
          {
            label: "New application",
            href: "/admin/admissions/new",
            variant: "primary",
          },
          {
            label: "View admissions",
            href: "/admin/admissions/view",
            variant: "secondary",
          },
        ]}
      >
        <div className="grid gap-4 md:grid-cols-2">
          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              New application
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Create a new submission
            </h2>
            <p className="mt-2 leading-6">
              Use the new application workspace when you want to add a fresh
              admission entry without reviewing the full queue.
            </p>
            <Button asChild className="mt-4 rounded-2xl">
              <Link href="/admin/admissions/new">Open new application</Link>
            </Button>
          </article>

          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              View admission
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Review the admissions queue
            </h2>
            <p className="mt-2 leading-6">
              Open the admissions queue to search, edit, delete, and change
              status for existing submissions.
            </p>
            <Button asChild variant="secondary" className="mt-4 rounded-2xl">
              <Link href="/admin/admissions/view">Open view page</Link>
            </Button>
          </article>
        </div>
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
