import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdmissionManagementPanel } from "@/components/admin/admission-management-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAdmissions">
      <AdmissionManagementPanel />
    </AdminAccessGuard>
  );
}
