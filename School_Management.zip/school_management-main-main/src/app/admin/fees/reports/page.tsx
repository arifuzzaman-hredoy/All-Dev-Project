"use client";

import { useEffect, useState } from "react";
import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { fetchWithAuth } from "@/lib/client-api";

type FeeReportData = {
  totals: {
    income: number;
    expected: number;
    due: number;
    byStatus: {
      PAID: number;
      PARTIAL: number;
      DUE: number;
    };
  };
  monthly: Array<{
    label: string;
    income: number;
    due: number;
  }>;
  payments: Array<{
    id: string;
    amountPaid: number;
    status: string;
    month: number | null;
    year: number | null;
    feeCategory: {
      name: string;
      amount: number;
    };
    totalAmount: number;
    dueAmount: number;
    student: {
      user: {
        name: string;
      };
      class: {
        name: string;
      };
    };
  }>;
};

export default function Page() {
  const [report, setReport] = useState<FeeReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const payload = await fetchWithAuth<FeeReportData>(
          "/api/v1/reports/fees",
        );
        if (!active) return;
        setReport(payload);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load fee reports",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, []);

  const stats = report
    ? [
        {
          label: "Income",
          value: `৳${report.totals.income}`,
          caption: "Collected",
        },
        {
          label: "Expected",
          value: `৳${report.totals.expected}`,
          caption: "Scheduled",
        },
        {
          label: "Dues",
          value: `৳${report.totals.due}`,
          caption: "Outstanding",
        },
      ]
    : [];

  return (
    <AdminAccessGuard permission="manageFeeReports">
      <div className="space-y-6">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
            Finance
          </p>
          <h1 className="text-2xl font-semibold">Income reports</h1>
          <p className="text-sm text-muted-foreground">
            Live fee collection, outstanding balances, and monthly movement.
          </p>
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground">Loading reports...</p>
        ) : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        {report ? (
          <>
            <div className="grid gap-4 md:grid-cols-3">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-border bg-background p-4"
                >
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-semibold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">
                    {stat.caption}
                  </p>
                </div>
              ))}
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-border bg-background p-4">
                <h2 className="text-lg font-semibold">Status summary</h2>
                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  {Object.entries(report.totals.byStatus).map(
                    ([key, value]) => (
                      <div
                        key={key}
                        className="rounded-xl border border-border p-3"
                      >
                        <p className="text-xs text-muted-foreground">{key}</p>
                        <p className="text-xl font-semibold">{value}</p>
                      </div>
                    ),
                  )}
                </div>
              </div>

              <div className="rounded-2xl border border-border bg-background p-4">
                <h2 className="text-lg font-semibold">Monthly movement</h2>
                <div className="mt-3 space-y-3">
                  {report.monthly.map((item) => (
                    <div
                      key={item.label}
                      className="rounded-xl border border-border p-3"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-semibold">{item.label}</p>
                        <p className="text-xs text-muted-foreground">
                          Income ৳{item.income} · Due ৳{item.due}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-background p-4">
              <h2 className="text-lg font-semibold">Recent payment rows</h2>
              <div className="mt-3 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="px-3 py-2 text-left">Student</th>
                      <th className="px-3 py-2 text-left">Class</th>
                      <th className="px-3 py-2 text-left">Fee</th>
                      <th className="px-3 py-2 text-left">Paid</th>
                      <th className="px-3 py-2 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.payments.slice(0, 12).map((payment) => (
                      <tr key={payment.id} className="border-t">
                        <td className="px-3 py-2">
                          {payment.student.user.name}
                        </td>
                        <td className="px-3 py-2">
                          {payment.student.class.name}
                        </td>
                        <td className="px-3 py-2">
                          {payment.feeCategory.name}
                        </td>
                        <td className="px-3 py-2">
                          ৳{payment.amountPaid}/৳{payment.totalAmount}
                        </td>
                        <td className="px-3 py-2">{payment.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </AdminAccessGuard>
  );
}
