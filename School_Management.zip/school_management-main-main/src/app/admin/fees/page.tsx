import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { ClassMonthlyFeeManagementPanel } from "@/components/admin/class-monthly-fee-management-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageFees">
      <AdminSectionPage
        title="Fees portal"
        description="Own every fee category, schedule due reminders, and surface solvency reports for the accountant."
        meta="Finance"
        actions={[
          {
            label: "Monthly fees",
            href: "/admin/fees/monthly",
            variant: "secondary",
          },
          {
            label: "Create category",
            href: "/admin/fees/categories",
            variant: "primary",
          },
          {
            label: "Track payments",
            href: "/admin/fees/payments",
            variant: "outline",
          },
        ]}
      >
        <ClassMonthlyFeeManagementPanel />
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
