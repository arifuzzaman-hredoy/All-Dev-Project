import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { ClassMonthlyFeeManagementPanel } from "@/components/admin/class-monthly-fee-management-panel";

export default function Page() {
  return (
    <AdminAccessGuard permission="manageFees">
      <ClassMonthlyFeeManagementPanel />
    </AdminAccessGuard>
  );
}
