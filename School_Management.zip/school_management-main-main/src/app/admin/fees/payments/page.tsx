import Link from "next/link";

import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { AdminSectionPage } from "@/components/admin/section-page";
import { Button } from "@/components/ui/button";

export default function Page() {
  return (
    <AdminAccessGuard permission="managePayments">
      <AdminSectionPage
        title="Payments hub"
        description={
          "Choose the monthly payment workspace or the secondary fee workspace. Both subpages use the same fee ledger, but each one focuses on a different balance."
        }
        meta="Finance"
        actions={[
          {
            label: "Monthly payments",
            href: "/admin/fees/payments/monthly",
            variant: "primary",
          },
          {
            label: "Secondary payments",
            href: "/admin/fees/payments/secondary",
            variant: "secondary",
          },
        ]}
      >
        <div className="grid gap-4 md:grid-cols-2">
          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              Monthly payments
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Monthly fee collection
            </h2>
            <p className="mt-2 leading-6">
              Open the monthly workspace to record regular tuition payments and
              review the periods that still carry monthly dues.
            </p>
            <Button asChild className="mt-4 rounded-2xl">
              <Link href="/admin/fees/payments/monthly">Open monthly page</Link>
            </Button>
          </article>

          <article className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm">
            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
              Secondary payments
            </p>
            <h2 className="mt-2 text-lg font-semibold text-foreground">
              Category fee collection
            </h2>
            <p className="mt-2 leading-6">
              Open the secondary workspace to record category fees and track the
              extra charges that remain after monthly dues.
            </p>
            <Button asChild variant="secondary" className="mt-4 rounded-2xl">
              <Link href="/admin/fees/payments/secondary">
                Open secondary page
              </Link>
            </Button>
          </article>
        </div>
      </AdminSectionPage>
    </AdminAccessGuard>
  );
}
