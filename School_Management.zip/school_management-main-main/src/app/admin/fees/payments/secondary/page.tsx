import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { PaymentManagementPage } from "@/components/admin/payment-management-page";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function Page() {
  return (
    <AdminAccessGuard permission="managePayments">
      <PaymentManagementPage scope="secondary" />
    </AdminAccessGuard>
  );
}
