import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { FeeCategoryManagementPanel } from "@/components/admin/fee-category-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageFees">
      <FeeCategoryManagementPanel />
    </AdminAccessGuard>
  )
}
