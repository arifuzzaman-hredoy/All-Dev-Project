import Link from "next/link"

import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { AcademicOperationsPanel } from "@/components/admin/academic-operations-panel"

const cards = [
  {
    href: "/admin/academic/documents",
    title: "Student Documents",
    description:
      "Generate testimonial, TC, and character certificates from live student records.",
  },
  {
    href: "/admin/academic/exams/create",
    title: "Create Exam",
    description: "Add a new exam with class assignment and exam type.",
  },
  {
    href: "/admin/academic/exams/show",
    title: "Show / Edit Exams",
    description:
      "Search by category, edit, archive, and manage the exam list.",
  },
  {
    href: "/admin/academic/results",
    title: "Results",
    description:
      "Create and update academic results from the live student roster.",
  },
]

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAcademicData">
      <div className="space-y-6">
        <div className="grid gap-4 lg:grid-cols-2">
          {cards.map((card) => (
            <Link
              key={card.href}
              href={card.href}
              className="rounded-3xl border border-border bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                Academic
              </p>
              <h2 className="mt-2 text-2xl font-semibold text-foreground">
                {card.title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">
                {card.description}
              </p>
            </Link>
          ))}
        </div>

        <AcademicOperationsPanel />
      </div>
    </AdminAccessGuard>
  )
}
