import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { ResultManagementPanel } from "@/components/admin/result-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAcademicData">
      <ResultManagementPanel />
    </AdminAccessGuard>
  )
}
