import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { AttendanceManagementPanel } from "@/components/admin/attendance-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAttendance">
      <AttendanceManagementPanel />
    </AdminAccessGuard>
  )
}
