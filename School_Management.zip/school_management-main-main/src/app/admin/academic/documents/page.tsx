import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { AdminSectionPage } from "@/components/admin/section-page"
import { StudentDocumentManagementPanel } from "@/components/admin/student-document-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageAcademicData">
      <AdminSectionPage
        title="Student documents"
        description="Issue testimonial, transfer certificate, and character certificate from live student records in one click."
        meta="Academic"
        actions={[
          {
            label: "Student roster",
            href: "/admin/students",
            variant: "outline",
          },
          {
            label: "Academic hub",
            href: "/admin/academic",
            variant: "secondary",
          },
        ]}
      >
        <StudentDocumentManagementPanel />
      </AdminSectionPage>
    </AdminAccessGuard>
  )
}
