import Link from "next/link";

const cards = [
  {
    href: "/admin/academic/exams/create",
    title: "Create Exam",
    description: "Add a new exam with class assignment and exam type.",
  },
  {
    href: "/admin/academic/exams/show",
    title: "Show / Edit Exams",
    description: "Search by category, edit, archive, and manage the exam list.",
  },
];

export default function Page() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {cards.map((card) => (
        <Link
          key={card.href}
          href={card.href}
          className="rounded-3xl border border-border bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
        >
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
            Exams
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-foreground">
            {card.title}
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {card.description}
          </p>
        </Link>
      ))}
    </div>
  );
}
