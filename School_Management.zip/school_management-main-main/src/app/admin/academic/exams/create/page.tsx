"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { type ExamTypeValue, EXAM_TYPE_OPTIONS } from "@/constants/exam-types";
import { fetchWithAuth } from "@/lib/client-api";

const EXAM_CREATE_DRAFT_STORAGE_KEY =
  "school-erp:admin:academic:exams:create-draft";

type WorkspaceResponse = {
  classes: Array<{ id: string; name: string }>;
  examTypes: Array<{ id: ExamTypeValue; name: string; code: string }>;
};

type ExamFormState = {
  name: string;
  code: string;
  date: string;
  description: string;
  academicYear: string;
  classIds: string[];
  isAllClasses: boolean;
  examTypeId: ExamTypeValue;
  visibleToStudents: boolean;
  visibleToParents: boolean;
  visibleToTeachers: boolean;
  generateResult: boolean;
  includeInFinalReport: boolean;
  includeInTranscript: boolean;
  includeInMeritList: boolean;
  lockAfterPublish: boolean;
};

function defaultForm(): ExamFormState {
  return {
    name: "",
    code: "",
    date: new Date().toISOString().slice(0, 10),
    description: "",
    academicYear: new Date().getFullYear().toString(),
    classIds: [] as string[],
    isAllClasses: false,
    examTypeId: EXAM_TYPE_OPTIONS[0]?.value ?? "MONTHLY_EXAM",
    visibleToStudents: false,
    visibleToParents: false,
    visibleToTeachers: true,
    generateResult: true,
    includeInFinalReport: false,
    includeInTranscript: false,
    includeInMeritList: false,
    lockAfterPublish: true,
  };
}

function isExamTypeValue(value: unknown): value is ExamTypeValue {
  return EXAM_TYPE_OPTIONS.some((item) => item.value === value);
}

function parseDraftForm(raw: string | null): ExamFormState | null {
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw) as Partial<ExamFormState>;
    const fallback = defaultForm();

    return {
      name: typeof parsed.name === "string" ? parsed.name : fallback.name,
      code: typeof parsed.code === "string" ? parsed.code : fallback.code,
      date: typeof parsed.date === "string" ? parsed.date : fallback.date,
      description:
        typeof parsed.description === "string"
          ? parsed.description
          : fallback.description,
      academicYear:
        typeof parsed.academicYear === "string"
          ? parsed.academicYear
          : fallback.academicYear,
      classIds: Array.isArray(parsed.classIds)
        ? parsed.classIds.filter(
            (item): item is string =>
              typeof item === "string" && item.trim().length > 0,
          )
        : fallback.classIds,
      isAllClasses:
        typeof parsed.isAllClasses === "boolean"
          ? parsed.isAllClasses
          : fallback.isAllClasses,
      examTypeId: isExamTypeValue(parsed.examTypeId)
        ? parsed.examTypeId
        : fallback.examTypeId,
      visibleToStudents:
        typeof parsed.visibleToStudents === "boolean"
          ? parsed.visibleToStudents
          : fallback.visibleToStudents,
      visibleToParents:
        typeof parsed.visibleToParents === "boolean"
          ? parsed.visibleToParents
          : fallback.visibleToParents,
      visibleToTeachers:
        typeof parsed.visibleToTeachers === "boolean"
          ? parsed.visibleToTeachers
          : fallback.visibleToTeachers,
      generateResult:
        typeof parsed.generateResult === "boolean"
          ? parsed.generateResult
          : fallback.generateResult,
      includeInFinalReport:
        typeof parsed.includeInFinalReport === "boolean"
          ? parsed.includeInFinalReport
          : fallback.includeInFinalReport,
      includeInTranscript:
        typeof parsed.includeInTranscript === "boolean"
          ? parsed.includeInTranscript
          : fallback.includeInTranscript,
      includeInMeritList:
        typeof parsed.includeInMeritList === "boolean"
          ? parsed.includeInMeritList
          : fallback.includeInMeritList,
      lockAfterPublish:
        typeof parsed.lockAfterPublish === "boolean"
          ? parsed.lockAfterPublish
          : fallback.lockAfterPublish,
    };
  } catch {
    return null;
  }
}

export default function Page() {
  const router = useRouter();
  const [workspace, setWorkspace] = useState<WorkspaceResponse | null>(null);
  const [form, setForm] = useState<ExamFormState>(defaultForm());
  const [loading, setLoading] = useState(true);
  const [draftReady, setDraftReady] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const skipNextDraftSaveRef = useRef(false);

  useEffect(() => {
    let active = true;
    async function load() {
      const storedDraft = parseDraftForm(
        window.localStorage.getItem(EXAM_CREATE_DRAFT_STORAGE_KEY),
      );

      if (storedDraft) {
        setForm(storedDraft);
      }

      try {
        const payload = await fetchWithAuth<WorkspaceResponse>("/api/v1/exams");
        if (!active) return;
        setWorkspace(payload);
        setForm((prev) => ({
          ...prev,
          classIds:
            storedDraft || prev.classIds.length > 0
              ? prev.classIds
              : payload.classes[0]?.id
                ? [payload.classes[0].id]
                : prev.classIds,
          examTypeId:
            storedDraft || isExamTypeValue(prev.examTypeId)
              ? prev.examTypeId
              : (payload.examTypes[0]?.id ?? prev.examTypeId),
        }));
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load exam setup",
        );
      } finally {
        if (active) setLoading(false);
        if (active) setDraftReady(true);
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!draftReady || submitting) return;

    if (skipNextDraftSaveRef.current) {
      skipNextDraftSaveRef.current = false;
      return;
    }

    try {
      window.localStorage.setItem(
        EXAM_CREATE_DRAFT_STORAGE_KEY,
        JSON.stringify(form),
      );
    } catch {
      // Ignore localStorage failures and keep the form usable.
    }
  }, [draftReady, form, submitting, skipNextDraftSaveRef]);

  const allClassIds = useMemo(
    () => workspace?.classes.map((item) => item.id) ?? [],
    [workspace],
  );

  const selectedClassIds = form.isAllClasses ? allClassIds : form.classIds;

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setMessage("");

    try {
      const payload = await fetchWithAuth<{ exam: { id: string } }>(
        "/api/v1/exams",
        {
          method: "POST",
          body: JSON.stringify({
            ...form,
            classIds: selectedClassIds,
            examTypeId: form.examTypeId,
          }),
        },
      );
      skipNextDraftSaveRef.current = true;
      try {
        window.localStorage.removeItem(EXAM_CREATE_DRAFT_STORAGE_KEY);
      } catch {
        // Ignore localStorage cleanup failures after a successful submit.
      }
      setMessage("Exam created successfully.");
      setForm(defaultForm());
      router.push("/admin/academic/exams/show");
      router.refresh();
      void payload;
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to create exam",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Create Exam</CardTitle>
        <CardDescription>
          Add a new exam and assign one or more classes before publishing.
        </CardDescription>
        <p className="text-xs text-muted-foreground">
          Draft data is saved in your browser until you submit this form.
        </p>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading setup…</p>
        ) : null}
        {error ? (
          <p className="mb-4 text-sm text-destructive">{error}</p>
        ) : null}
        {message ? (
          <p className="mb-4 text-sm text-emerald-600">{message}</p>
        ) : null}

        <form className="space-y-5" onSubmit={handleSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Exam name</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, name: event.target.value }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="code">Exam code</Label>
              <Input
                id="code"
                value={form.code}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    code: event.target.value.toUpperCase(),
                  }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={form.date}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, date: event.target.value }))
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="academicYear">Academic year</Label>
              <Input
                id="academicYear"
                value={form.academicYear}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    academicYear: event.target.value,
                  }))
                }
                required
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                rows={3}
                value={form.description}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    description: event.target.value,
                  }))
                }
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="examTypeId">Exam type</Label>
              <select
                id="examTypeId"
                className="h-10 w-full rounded-md border border-input bg-background px-3"
                value={form.examTypeId}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    examTypeId: event.target.value as ExamTypeValue,
                  }))
                }
              >
                {workspace?.examTypes.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label>Classes</Label>
              <div className="rounded-xl border border-border bg-background p-3">
                <label className="flex items-center gap-2 text-sm font-medium">
                  <input
                    type="checkbox"
                    checked={form.isAllClasses}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        isAllClasses: event.target.checked,
                      }))
                    }
                  />
                  All classes
                </label>
                <div className="mt-3 grid gap-2 md:grid-cols-2">
                  {workspace?.classes.map((item) => {
                    const checked =
                      form.isAllClasses || form.classIds.includes(item.id);
                    return (
                      <label
                        key={item.id}
                        className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          disabled={form.isAllClasses}
                          onChange={(event) => {
                            const nextChecked = event.target.checked;
                            setForm((prev) => {
                              const next = new Set(prev.classIds);
                              if (nextChecked) next.add(item.id);
                              else next.delete(item.id);
                              return { ...prev, classIds: Array.from(next) };
                            });
                          }}
                        />
                        {item.name}
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.visibleToStudents}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    visibleToStudents: event.target.checked,
                  }))
                }
              />
              Visible to students
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.visibleToParents}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    visibleToParents: event.target.checked,
                  }))
                }
              />
              Visible to guardians
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.visibleToTeachers}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    visibleToTeachers: event.target.checked,
                  }))
                }
              />
              Visible to teachers
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.generateResult}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    generateResult: event.target.checked,
                  }))
                }
              />
              Generate result
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.includeInFinalReport}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    includeInFinalReport: event.target.checked,
                  }))
                }
              />
              Final report
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.lockAfterPublish}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    lockAfterPublish: event.target.checked,
                  }))
                }
              />
              Lock after publish
            </label>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="submit" disabled={submitting || loading}>
              {submitting ? "Saving..." : "Create Exam"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
