import Link from "next/link";
import { AdminAccessGuard } from "@/components/admin/admin-access-guard";

const navItems = [
  { href: "/admin/academic/exams/create", label: "Create" },
  { href: "/admin/academic/exams/show", label: "Show / Edit" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <AdminAccessGuard permission="manageAcademicData">
      <div className="space-y-6 px-6 py-6">

        <nav className="flex flex-wrap gap-2 rounded-2xl border border-border bg-card p-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-full border border-border px-4 py-2 text-sm font-semibold text-foreground transition hover:border-primary hover:text-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {children}
      </div>
    </AdminAccessGuard>
  );
}
