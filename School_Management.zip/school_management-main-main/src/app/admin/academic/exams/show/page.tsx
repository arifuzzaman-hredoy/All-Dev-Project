import { ExamManagementPanel } from "@/components/admin/exam-management-panel";

export default function Page() {
  return <ExamManagementPanel />;
}
