import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { TeacherManagementPanel } from "@/components/admin/teacher-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageTeachers">
      <TeacherManagementPanel />
    </AdminAccessGuard>
  )
}
