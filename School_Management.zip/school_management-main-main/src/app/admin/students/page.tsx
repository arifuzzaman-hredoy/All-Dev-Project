import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { StudentManagementPanel } from "@/components/admin/student-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageStudents">
      <StudentManagementPanel />
    </AdminAccessGuard>
  )
}
