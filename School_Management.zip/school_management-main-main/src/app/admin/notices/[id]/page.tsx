import { AdminAccessGuard } from "@/components/admin/admin-access-guard";
import { NoticeEditorPad } from "@/components/admin/notice-editor-pad";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function Page(props: PageProps) {
  const { id } = await props.params;

  return (
    <AdminAccessGuard permission="manageNotices">
      <NoticeEditorPad noticeId={id} />
    </AdminAccessGuard>
  );
}

