import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { NoticeManagementPanel } from "@/components/admin/notice-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageNotices">
      <NoticeManagementPanel />
    </AdminAccessGuard>
  )
}
