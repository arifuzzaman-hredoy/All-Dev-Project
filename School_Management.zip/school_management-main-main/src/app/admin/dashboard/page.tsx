"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  BadgeCheck,
  BellRing,
  CalendarDays,
  CircleDollarSign,
  GraduationCap,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserPlus,
  Users,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { fetchWithAuth } from "@/lib/client-api";

type AdminDashboardData = {
  dashboard: {
    hero: {
      activeStudents: number;
      totalCollected: number;
      attendanceRate: number;
      pendingAdmissions: number;
    };
    focus: {
      liveNotices: number;
      activeTeachers: number;
      totalParents: number;
      totalClasses: number;
      totalSubjects: number;
      upcomingExams: number;
      duePayments: number;
    };
    pulse: {
      recentNotices: Array<{
        id: string;
        title: string;
        detail: string;
        tag: string;
        createdAt: string;
      }>;
      recentAdmissions: Array<{
        id: string;
        title: string;
        detail: string;
        tag: string;
        createdAt: string;
      }>;
      recentPayments: Array<{
        id: string;
        title: string;
        detail: string;
        tag: string;
        createdAt: string;
      }>;
    };
    insights: {
      monthlyAdmissions: Array<{
        month: string;
        total: number;
        pending: number;
        approved: number;
        incomplete: number;
        rejected: number;
      }>;
      attendanceTrends: Array<{
        day: string;
        present: number;
        absent: number;
        late: number;
        rate: number;
      }>;
      teacherActivity: Array<{
        id: string;
        name: string;
        createdAt: string;
        phone: string | null;
        salary: number | null;
      }>;
      systemPerformance: {
        attendanceRate: number;
        duePayments: number;
        upcomingExams: number;
        liveNotices: number;
      };
    };
  };
};

type KpiCard = {
  label: string;
  value: string;
  caption: string;
  icon: typeof Users;
  accent: string;
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-BD", {
    style: "currency",
    currency: "BDT",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function formatShortNumber(value: number) {
  return new Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}

function formatPercentage(value: number) {
  return `${value}%`;
}

type ChartTooltipPayload = ReadonlyArray<{
  name?: string | number;
  value?: unknown;
}>;

function chartTooltipContent({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: ChartTooltipPayload;
  label?: unknown;
}) {
  if (!active || !payload?.length) return null;

  return (
    <div className="rounded-2xl border border-border bg-background/95 px-3 py-2 text-xs shadow-xl backdrop-blur">
      <p className="font-semibold text-foreground">{String(label ?? "")}</p>
      <div className="mt-2 space-y-1">
        {payload.map(
          (entry) => (
            <div
              key={entry.name ?? String(entry.value)}
              className="flex items-center justify-between gap-4"
            >
              <span className="text-muted-foreground">{String(entry.name ?? "")}</span>
              <span className="font-medium text-foreground">{String(entry.value ?? "")}</span>
            </div>
          ),
        )}
      </div>
    </div>
  );
}

export default function Page() {
  const [data, setData] = useState<AdminDashboardData["dashboard"] | null>(
    null,
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const payload = await fetchWithAuth<AdminDashboardData>(
          "/api/v1/admin/dashboard",
        );
        if (!active) return;
        setData(payload.dashboard);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load admin dashboard",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, []);

  const kpiCards = useMemo<KpiCard[]>(() => {
    if (!data) return [];

    return [
      {
        label: "Total Students",
        value: formatShortNumber(data.hero.activeStudents),
        caption: `${data.focus.totalClasses} active classes in system`,
        icon: Users,
        accent: "from-sky-500/20 via-sky-500/10 to-transparent",
      },
      {
        label: "Active Admissions",
        value: formatShortNumber(data.hero.pendingAdmissions),
        caption: "Waiting in review queue",
        icon: UserPlus,
        accent: "from-amber-500/20 via-amber-500/10 to-transparent",
      },
      {
        label: "Teachers",
        value: formatShortNumber(data.focus.activeTeachers),
        caption: `${data.focus.totalSubjects} subjects covered`,
        icon: GraduationCap,
        accent: "from-emerald-500/20 via-emerald-500/10 to-transparent",
      },
      {
        label: "Revenue",
        value: formatCurrency(data.hero.totalCollected),
        caption: `${data.insights.systemPerformance.duePayments} payments need follow-up`,
        icon: CircleDollarSign,
        accent: "from-violet-500/20 via-violet-500/10 to-transparent",
      },
    ];
  }, [data]);

  const activityFeed = useMemo(() => {
    if (!data) return [];

    return [
      ...data.pulse.recentAdmissions.map((item) => ({
        id: item.id,
        title: item.title,
        detail: item.detail,
        tag: item.tag,
        createdAt: item.createdAt,
        tone: "admission",
      })),
      ...data.pulse.recentPayments.map((item) => ({
        id: item.id,
        title: item.title,
        detail: item.detail,
        tag: item.tag,
        createdAt: item.createdAt,
        tone: "finance",
      })),
      ...data.pulse.recentNotices.map((item) => ({
        id: item.id,
        title: item.title,
        detail: item.detail,
        tag: item.tag,
        createdAt: item.createdAt,
        tone: "notice",
      })),
    ]
      .sort(
        (left, right) =>
          new Date(right.createdAt).getTime() -
          new Date(left.createdAt).getTime(),
      )
      .slice(0, 8);
  }, [data]);

  const teacherHighlights = useMemo(() => {
    if (!data) return [];
    return data.insights.teacherActivity;
  }, [data]);

  const monthlyAdmissions = data?.insights.monthlyAdmissions ?? [];
  const attendanceTrends = data?.insights.attendanceTrends ?? [];

  return (
    <div className="space-y-6 px-4 py-6 md:px-6 lg:px-8">
      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative overflow-hidden rounded-[32px] border border-slate-200/10 bg-linear-to-br from-slate-950 via-slate-900 to-slate-950 px-6 py-7 text-white shadow-[0_30px_90px_rgba(15,23,42,0.35)] md:px-8"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(56,189,248,0.18),transparent_28%),radial-gradient(circle_at_bottom_left,rgba(168,85,247,0.18),transparent_30%)]" />
        <div className="relative flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
          <div className="max-w-3xl space-y-4">
            <Badge className="w-fit border border-white/15 bg-white/10 text-slate-100 hover:bg-white/10">
              <Sparkles className="mr-2 h-3.5 w-3.5" />
              School ERP · Command Center
            </Badge>
            <div className="space-y-2">
              <h1 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
                Admin Dashboard
              </h1>
              <p className="max-w-2xl text-sm leading-6 text-slate-200 md:text-base">
                A premium overview of students, admissions, teachers, finance,
                and system health. Scan the key numbers, review activity, and
                move quickly.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button
                asChild
                size="sm"
                className="rounded-full bg-white text-slate-950 hover:bg-slate-100"
              >
                <Link href="/admin/students">Add Student</Link>
              </Button>
              <Button
                asChild
                size="sm"
                variant="secondary"
                className="rounded-full"
              >
                <Link href="/admin/admissions/view">Approve Admission</Link>
              </Button>
              <Button
                asChild
                size="sm"
                variant="outline"
                className="rounded-full border-white/20 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              >
                <Link href="/admin/fees/reports">View Finance</Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:w-136 xl:grid-cols-2">
            {kpiCards.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.article
                  key={item.label}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: 0.05 * index }}
                  className="rounded-3xl border border-white/10 bg-white/8 p-4 backdrop-blur"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.28em] text-slate-300">
                        {item.label}
                      </p>
                      <p className="mt-2 text-2xl font-semibold text-white">
                        {item.value}
                      </p>
                    </div>
                    <div
                      className={`rounded-2xl bg-linear-to-br ${item.accent} p-2.5`}
                    >
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-slate-300">{item.caption}</p>
                </motion.article>
              );
            })}
          </div>
        </div>
      </motion.section>

      {loading ? (
        <p className="text-sm text-muted-foreground">
          Loading dashboard metrics...
        </p>
      ) : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {data ? (
        <div className="grid gap-6 xl:grid-cols-[1.45fr_0.95fr]">
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {[
                {
                  label: "Attendance rate",
                  value: formatPercentage(data.hero.attendanceRate),
                  caption: "Today’s present ratio",
                  icon: BadgeCheck,
                },
                {
                  label: "Due payments",
                  value: formatShortNumber(
                    data.insights.systemPerformance.duePayments,
                  ),
                  caption: "Needs finance follow-up",
                  icon: CircleDollarSign,
                },
                {
                  label: "Upcoming exams",
                  value: formatShortNumber(
                    data.insights.systemPerformance.upcomingExams,
                  ),
                  caption: "Within the next 30 days",
                  icon: CalendarDays,
                },
                {
                  label: "Live notices",
                  value: formatShortNumber(
                    data.insights.systemPerformance.liveNotices,
                  ),
                  caption: "Currently visible to users",
                  icon: BellRing,
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <Card
                    key={item.label}
                    className="border-border/70 bg-background/80 shadow-sm"
                  >
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">
                            {item.label}
                          </p>
                          <p className="mt-2 text-2xl font-semibold text-foreground">
                            {item.value}
                          </p>
                        </div>
                        <div className="rounded-2xl bg-muted p-2.5 text-foreground">
                          <Icon className="h-5 w-5" />
                        </div>
                      </div>
                      <p className="mt-3 text-xs text-muted-foreground">
                        {item.caption}
                      </p>
                      {item.label === "Attendance rate" ? (
                        <div className="mt-4 h-2 rounded-full bg-muted">
                          <div
                            className="h-2 rounded-full bg-linear-to-r from-sky-500 to-emerald-500"
                            style={{
                              width: `${Math.min(data.hero.attendanceRate, 100)}%`,
                            }}
                          />
                        </div>
                      ) : null}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>Monthly admissions</CardTitle>
                    <CardDescription>
                      Track how applications move through review stages over the
                      last six months.
                    </CardDescription>
                  </div>
                  <Badge variant="outline">Admissions</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-85 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyAdmissions}
                      margin={{ top: 8, right: 8, left: -12, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="month"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip content={chartTooltipContent} />
                      <Bar
                        dataKey="pending"
                        stackId="a"
                        fill="#f59e0b"
                        radius={[8, 8, 0, 0]}
                        name="Pending"
                      />
                      <Bar
                        dataKey="approved"
                        stackId="a"
                        fill="#22c55e"
                        name="Approved"
                      />
                      <Bar
                        dataKey="incomplete"
                        stackId="a"
                        fill="#8b5cf6"
                        name="Incomplete"
                      />
                      <Bar
                        dataKey="rejected"
                        stackId="a"
                        fill="#ef4444"
                        name="Rejected"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>Attendance trends</CardTitle>
                    <CardDescription>
                      Daily classroom attendance performance over the recent
                      two-week window.
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">System health</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-85 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart
                      data={attendanceTrends}
                      margin={{ top: 8, right: 8, left: -12, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="day" tickLine={false} axisLine={false} />
                      <YAxis
                        yAxisId="left"
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <YAxis
                        yAxisId="right"
                        orientation="right"
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                        domain={[0, 100]}
                      />
                      <Tooltip content={chartTooltipContent} />
                      <Bar
                        yAxisId="left"
                        dataKey="present"
                        fill="#14b8a6"
                        radius={[8, 8, 0, 0]}
                        name="Present"
                      />
                      <Bar
                        yAxisId="left"
                        dataKey="absent"
                        fill="#ef4444"
                        radius={[8, 8, 0, 0]}
                        name="Absent"
                      />
                      <Bar
                        yAxisId="left"
                        dataKey="late"
                        fill="#f59e0b"
                        radius={[8, 8, 0, 0]}
                        name="Late"
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="rate"
                        stroke="#2563eb"
                        strokeWidth={3}
                        dot={false}
                        name="Attendance rate"
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>Quick actions</CardTitle>
                    <CardDescription>
                      Fast paths to the most common admin operations.
                    </CardDescription>
                  </div>
                  <Badge variant="outline">One click</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  {[
                    {
                      label: "Add Student",
                      href: "/admin/students",
                      icon: UserPlus,
                      variant: "default" as const,
                    },
                    {
                      label: "Approve Admission",
                      href: "/admin/admissions/view",
                      icon: ShieldCheck,
                      variant: "secondary" as const,
                    },
                    {
                      label: "Review Attendance",
                      href: "/admin/academic/attendance",
                      icon: Activity,
                      variant: "outline" as const,
                    },
                    {
                      label: "Open Finance",
                      href: "/admin/fees/reports",
                      icon: TrendingUp,
                      variant: "ghost" as const,
                    },
                  ].map((action) => {
                    const Icon = action.icon;
                    return (
                      <Button
                        key={action.label}
                        asChild
                        variant={action.variant}
                        className="h-auto justify-start rounded-2xl px-4 py-4 text-left"
                      >
                        <Link
                          href={action.href}
                          className="flex w-full items-center justify-between gap-4"
                        >
                          <span className="flex items-center gap-3 text-sm font-medium">
                            <Icon className="h-4 w-4" />
                            {action.label}
                          </span>
                          <ArrowUpRight className="h-4 w-4" />
                        </Link>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>Recent activity</CardTitle>
                    <CardDescription>
                      Admissions, payments, and notices flowing through the
                      system.
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">Live feed</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activityFeed.map((item) => (
                    <article
                      key={`${item.tag}-${item.id}`}
                      className="rounded-2xl border border-border/70 bg-muted/30 p-4"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold text-foreground">
                              {item.title}
                            </p>
                            <Badge
                              variant="outline"
                              className="border-border/80 text-[10px]"
                            >
                              {item.tag}
                            </Badge>
                          </div>
                          <p className="text-xs leading-5 text-muted-foreground">
                            {item.detail}
                          </p>
                        </div>
                        <span className="whitespace-nowrap text-[11px] text-muted-foreground">
                          {formatDateTime(item.createdAt)}
                        </span>
                      </div>
                    </article>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>Teacher activity</CardTitle>
                    <CardDescription>
                      Recently onboarded teachers and current staffing picture.
                    </CardDescription>
                  </div>
                  <Badge variant="outline">
                    {data.focus.activeTeachers} active
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {teacherHighlights.length ? (
                    teacherHighlights.map((teacher, index) => (
                      <div
                        key={teacher.id}
                        className="flex items-center justify-between gap-3 rounded-2xl border border-border/70 bg-muted/30 p-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold text-foreground">
                              {teacher.name}
                            </p>
                            {index === 0 ? (
                              <Badge
                                variant="secondary"
                                className="text-[10px]"
                              >
                                Newest
                              </Badge>
                            ) : null}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Joined {formatDateTime(teacher.createdAt)}
                            {teacher.phone ? ` · ${teacher.phone}` : ""}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                            Salary
                          </p>
                          <p className="text-sm font-medium text-foreground">
                            {teacher.salary
                              ? formatCurrency(teacher.salary)
                              : "Not set"}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No recent teacher activity.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/70 bg-background/85 shadow-sm">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <CardTitle>System performance</CardTitle>
                    <CardDescription>
                      A compact read on operational health and workload.
                    </CardDescription>
                  </div>
                  <Badge variant="outline">Snapshot</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 sm:grid-cols-2">
                  {[
                    {
                      label: "Attendance",
                      value: `${data.insights.systemPerformance.attendanceRate}%`,
                      icon: BadgeCheck,
                    },
                    {
                      label: "Due payments",
                      value: formatShortNumber(
                        data.insights.systemPerformance.duePayments,
                      ),
                      icon: CircleDollarSign,
                    },
                    {
                      label: "Upcoming exams",
                      value: formatShortNumber(
                        data.insights.systemPerformance.upcomingExams,
                      ),
                      icon: CalendarDays,
                    },
                    {
                      label: "Live notices",
                      value: formatShortNumber(
                        data.insights.systemPerformance.liveNotices,
                      ),
                      icon: BellRing,
                    },
                  ].map((item) => {
                    const Icon = item.icon;
                    return (
                      <article
                        key={item.label}
                        className="rounded-2xl border border-border/70 bg-muted/30 p-4"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                              {item.label}
                            </p>
                            <p className="mt-2 text-2xl font-semibold text-foreground">
                              {item.value}
                            </p>
                          </div>
                          <div className="rounded-2xl bg-background p-2 text-foreground shadow-sm">
                            <Icon className="h-4 w-4" />
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : null}
    </div>
  );
}
