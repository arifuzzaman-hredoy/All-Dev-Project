import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { GuardianManagementPanel } from "@/components/admin/guardian-management-panel"

export default function Page() {
  return (
    <AdminAccessGuard permission="manageUsers">
      <GuardianManagementPanel mode="view" />
    </AdminAccessGuard>
  )
}
