"use client"

import { useCallback, useEffect, useState } from "react"
import { AdminAccessGuard } from "@/components/admin/admin-access-guard"
import { downloadWithAuth, fetchWithAuth } from "@/lib/client-api"

type ThemeColors = Record<string, string>

type SettingRecord = {
  id: string
  key: string
  value: unknown
  updatedAt: string
  updatedBy: {
    name: string
    email: string
  } | null
}

type AuditLogRecord = {
  id: string
  action: string
  entityType: string
  entityId: string | null
  createdAt: string
  actor: {
    name: string
    email: string
  } | null
}

type AuditActor = {
  id: string
  name: string
  email: string
}

type AuditPayload = {
  logs: AuditLogRecord[]
  total: number
  actors: AuditActor[]
}

type NotificationTemplateRecord = {
  id: string
  key: string
  channel: string
  subject: string
  description: string | null
  isActive: boolean
}

type NotificationQueueRecord = {
  id: string
  recipientName: string | null
  recipientEmail: string
  subject: string
  status: string
  errorMessage: string | null
  createdAt: string
  sentAt: string | null
  template: {
    id: string
    key: string
    channel: string
  } | null
}

type ReminderPreview = {
  settings: unknown
  templates: NotificationTemplateRecord[]
  queue: NotificationQueueRecord[]
  feeTargets: Array<{ paymentId: string; studentName: string; feeCategory: string; amountDue: number; parentEmail: string | null }>
  attendanceTargets: Array<{ studentId: string; studentName: string; percentage: number; parentEmail: string | null }>
}

export default function Page() {
  const [theme, setTheme] = useState<ThemeColors | null>(null)
  const [settings, setSettings] = useState<SettingRecord[]>([])
  const [logs, setLogs] = useState<AuditLogRecord[]>([])
  const [featureFlagsText, setFeatureFlagsText] = useState("{}")
  const [auditSearch, setAuditSearch] = useState("")
  const [auditEntityType, setAuditEntityType] = useState("")
  const [auditAction, setAuditAction] = useState("")
  const [auditActorId, setAuditActorId] = useState("")
  const [auditActors, setAuditActors] = useState<AuditActor[]>([])
  const [auditTotal, setAuditTotal] = useState(0)
  const [auditPage, setAuditPage] = useState(1)
  const [auditPageSize] = useState(10)
  const [reminders, setReminders] = useState<ReminderPreview | null>(null)
  const [dispatching, setDispatching] = useState(false)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  const load = useCallback(async (logFilters?: {
    search?: string
    entityType?: string
    action?: string
    actorId?: string
    page?: number
  }) => {
    const auditParams = new URLSearchParams()
    auditParams.set("limit", String(auditPageSize))
    auditParams.set("page", String(logFilters?.page ?? 1))
    if (logFilters?.search) auditParams.set("search", logFilters.search)
    if (logFilters?.entityType) auditParams.set("entityType", logFilters.entityType)
    if (logFilters?.action) auditParams.set("action", logFilters.action)
    if (logFilters?.actorId) auditParams.set("actorId", logFilters.actorId)

    const [themePayload, settingsPayload, logsPayload, remindersPayload] = await Promise.all([
      fetchWithAuth<{ theme: ThemeColors }>("/api/v1/theme/global"),
      fetchWithAuth<{ settings: SettingRecord[] }>("/api/v1/system-settings"),
      fetchWithAuth<AuditPayload>(`/api/v1/audit-logs?${auditParams.toString()}`),
      fetchWithAuth<ReminderPreview>("/api/v1/notifications/reminders"),
    ])

    setTheme(themePayload.theme)
    setSettings(settingsPayload.settings)
    setLogs(logsPayload.logs)
    setAuditTotal(logsPayload.total)
    setAuditActors(logsPayload.actors)
    setReminders(remindersPayload)

    const featureFlags = settingsPayload.settings.find((item) => item.key === "feature_flags")
    setFeatureFlagsText(JSON.stringify(featureFlags?.value ?? {}, null, 2))
  }, [auditPageSize])

  useEffect(() => {
    let active = true

    async function bootstrap() {
      try {
        await load()
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load settings")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void bootstrap()
    return () => {
      active = false
    }
  }, [load])

  async function handleSaveFeatureFlags() {
    setMessage("")
    setError("")
    try {
      const parsed = JSON.parse(featureFlagsText)
      await fetchWithAuth<{ setting: SettingRecord }>("/api/v1/system-settings", {
        method: "PATCH",
        body: JSON.stringify({
          key: "feature_flags",
          value: parsed,
        }),
      })
      setMessage("Feature flags updated")
      await load({ search: auditSearch, entityType: auditEntityType, action: auditAction, actorId: auditActorId, page: auditPage })
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update settings")
    }
  }

  async function handleAuditSearch() {
    setError("")
    try {
      setAuditPage(1)
      await load({ search: auditSearch, entityType: auditEntityType, action: auditAction, actorId: auditActorId, page: 1 })
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to load audit logs")
    }
  }

  async function handleAuditPage(nextPage: number) {
    setError("")
    try {
      setAuditPage(nextPage)
      await load({
        search: auditSearch,
        entityType: auditEntityType,
        action: auditAction,
        actorId: auditActorId,
        page: nextPage,
      })
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to change audit page")
    }
  }

  async function handleDispatch(type: "fees" | "attendance" | "all") {
    setDispatching(true)
    setError("")
    setMessage("")
    try {
      const payload = await fetchWithAuth<{ message: string }>("/api/v1/notifications/reminders", {
        method: "POST",
        body: JSON.stringify({ type }),
      })
      setMessage(payload.message)
      await load({ search: auditSearch, entityType: auditEntityType, action: auditAction, actorId: auditActorId, page: auditPage })
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to dispatch reminders")
    } finally {
      setDispatching(false)
    }
  }

  async function handleAuditExport() {
    setError("")
    try {
      await downloadWithAuth(`/api/v1/audit-logs?${csvParams.toString()}`, "audit-logs.csv")
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to export audit logs")
    }
  }

  const totalPages = Math.max(Math.ceil(auditTotal / auditPageSize), 1)
  const csvParams = new URLSearchParams({
    format: "csv",
    limit: "200",
  })
  if (auditSearch) csvParams.set("search", auditSearch)
  if (auditEntityType) csvParams.set("entityType", auditEntityType)
  if (auditAction) csvParams.set("action", auditAction)
  if (auditActorId) csvParams.set("actorId", auditActorId)

  return (
    <AdminAccessGuard permission="manageSettings">
      <div className="space-y-6">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Platform</p>
          <h1 className="text-2xl font-semibold">System settings</h1>
          <p className="text-sm text-muted-foreground">
            Persistent configuration, theme defaults, and recent audit activity.
          </p>
        </div>

        {loading ? <p className="text-sm text-muted-foreground">Loading system settings...</p> : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        {message ? <p className="text-sm text-emerald-600">{message}</p> : null}

        {theme ? (
          <div className="rounded-2xl border border-border bg-background p-4">
            <h2 className="text-lg font-semibold">Global theme</h2>
            <div className="mt-3 grid gap-3 md:grid-cols-5">
              {Object.entries(theme).slice(0, 10).map(([key, value]) => (
                <div key={key} className="rounded-xl border border-border p-3">
                  <div className="mb-2 h-8 rounded-md border border-border" style={{ backgroundColor: value }} />
                  <p className="text-xs font-semibold">{key}</p>
                  <p className="text-[11px] text-muted-foreground">{value}</p>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-background p-4">
            <h2 className="text-lg font-semibold">Feature flags</h2>
            <p className="text-sm text-muted-foreground">Stored in the database and audited on change.</p>
            <textarea
              value={featureFlagsText}
              onChange={(event) => setFeatureFlagsText(event.target.value)}
              className="mt-3 min-h-[220px] w-full rounded-xl border border-border bg-background p-3 text-sm"
            />
            <button
              type="button"
              onClick={handleSaveFeatureFlags}
              className="mt-3 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              Save feature flags
            </button>
          </div>

          <div className="rounded-2xl border border-border bg-background p-4">
            <h2 className="text-lg font-semibold">Recent audit events</h2>
            <div className="mt-3 grid gap-3 md:grid-cols-3">
              <input
                value={auditSearch}
                onChange={(event) => setAuditSearch(event.target.value)}
                placeholder="Search action, entity, actor"
                className="rounded-xl border border-border bg-background px-3 py-2 text-sm"
              />
              <input
                value={auditEntityType}
                onChange={(event) => setAuditEntityType(event.target.value)}
                placeholder="Entity type"
                className="rounded-xl border border-border bg-background px-3 py-2 text-sm"
              />
              <input
                value={auditAction}
                onChange={(event) => setAuditAction(event.target.value)}
                placeholder="Action"
                className="rounded-xl border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
            <div className="mt-3">
              <select
                value={auditActorId}
                onChange={(event) => setAuditActorId(event.target.value)}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm"
              >
                <option value="">All actors</option>
                {auditActors.map((actor) => (
                  <option key={actor.id} value={actor.id}>
                    {actor.name} ({actor.email})
                  </option>
                ))}
              </select>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={() => void handleAuditSearch()} className="rounded-full border border-border px-4 py-2 text-xs font-semibold">
                Filter logs
              </button>
              <button
                type="button"
                onClick={() => void handleAuditExport()}
                className="rounded-full border border-border px-4 py-2 text-xs font-semibold"
              >
                Export CSV
              </button>
            </div>
            <div className="mt-3 space-y-3">
              {logs.map((log) => (
                <div key={log.id} className="rounded-xl border border-border p-3">
                  <p className="text-sm font-semibold">{log.action}</p>
                  <p className="text-xs text-muted-foreground">{log.entityType}{log.entityId ? ` · ${log.entityId}` : ""}</p>
                  <p className="text-xs text-muted-foreground">
                    {log.actor?.name ?? "System"} · {new Date(log.createdAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-3">
              <p className="text-xs text-muted-foreground">
                Page {auditPage} of {totalPages} · {auditTotal} events
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={auditPage <= 1}
                  onClick={() => void handleAuditPage(auditPage - 1)}
                  className="rounded-full border border-border px-4 py-2 text-xs font-semibold disabled:opacity-50"
                >
                  Previous
                </button>
                <button
                  type="button"
                  disabled={auditPage >= totalPages}
                  onClick={() => void handleAuditPage(auditPage + 1)}
                  className="rounded-full border border-border px-4 py-2 text-xs font-semibold disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        </div>

        {reminders ? (
          <div className="rounded-2xl border border-border bg-background p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-semibold">Notifications & reminders</h2>
                <p className="text-sm text-muted-foreground">Preview due-fee and low-attendance reminder targets before dispatch.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button disabled={dispatching} onClick={() => void handleDispatch("fees")} className="rounded-full border border-border px-4 py-2 text-xs font-semibold disabled:opacity-60">Send fee reminders</button>
                <button disabled={dispatching} onClick={() => void handleDispatch("attendance")} className="rounded-full border border-border px-4 py-2 text-xs font-semibold disabled:opacity-60">Send attendance reminders</button>
                <button disabled={dispatching} onClick={() => void handleDispatch("all")} className="rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground disabled:opacity-60">Dispatch all</button>
              </div>
            </div>
            <div className="mt-4 grid gap-6 lg:grid-cols-2">
              <div>
                <h3 className="mb-2 text-sm font-semibold">Fee targets</h3>
                <div className="space-y-2">
                  {reminders.feeTargets.slice(0, 8).map((item) => (
                    <div key={item.paymentId} className="rounded-xl border border-border p-3">
                      <p className="text-sm font-semibold">{item.studentName}</p>
                      <p className="text-xs text-muted-foreground">{item.feeCategory} · Due ৳{item.amountDue}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="mb-2 text-sm font-semibold">Attendance targets</h3>
                <div className="space-y-2">
                  {reminders.attendanceTargets.slice(0, 8).map((item) => (
                    <div key={item.studentId} className="rounded-xl border border-border p-3">
                      <p className="text-sm font-semibold">{item.studentName}</p>
                      <p className="text-xs text-muted-foreground">Attendance {item.percentage}%</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-6 grid gap-6 lg:grid-cols-2">
              <div>
                <h3 className="mb-2 text-sm font-semibold">Email templates</h3>
                <div className="space-y-2">
                  {reminders.templates.map((template) => (
                    <div key={template.id} className="rounded-xl border border-border p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-semibold">{template.key}</p>
                        <span className="text-[11px] text-muted-foreground">{template.channel}</span>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">{template.subject}</p>
                      {template.description ? (
                        <p className="mt-1 text-xs text-muted-foreground">{template.description}</p>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="mb-2 text-sm font-semibold">Recent delivery queue</h3>
                <div className="space-y-2">
                  {reminders.queue.map((item) => (
                    <div key={item.id} className="rounded-xl border border-border p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-semibold">{item.recipientName ?? item.recipientEmail}</p>
                        <span className="text-[11px] text-muted-foreground">{item.status}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{item.subject}</p>
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        {item.template?.key ?? "manual"} · {new Date(item.createdAt).toLocaleString()}
                      </p>
                      {item.errorMessage ? (
                        <p className="mt-1 text-[11px] text-destructive">{item.errorMessage}</p>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : null}

        <div className="rounded-2xl border border-border bg-background p-4">
          <h2 className="text-lg font-semibold">All settings</h2>
          <div className="mt-3 space-y-3">
            {settings.map((setting) => (
              <div key={setting.id} className="rounded-xl border border-border p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold">{setting.key}</p>
                  <p className="text-xs text-muted-foreground">
                    Updated {new Date(setting.updatedAt).toLocaleString()}
                  </p>
                </div>
                <pre className="mt-2 overflow-x-auto rounded-lg bg-muted/40 p-3 text-xs">
                  {JSON.stringify(setting.value, null, 2)}
                </pre>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminAccessGuard>
  )
}
