"use client";

import type { FormEvent } from "react";
import { useState } from "react";
import { useRouter } from "next/navigation";

import Navbar from "@/components/navbars-02";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { persistAuth } from "@/utils/auth-storage";
import { getDashboardRoute } from "@/lib/role-routes";

export default function RegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    if (form.password !== form.confirmPassword) {
      setError("Passwords must match");
      return;
    }

    const payload: Record<string, string> = {
      name: form.name,
      email: form.email,
      password: form.password,
      role: "USER",
    };

    setLoading(true);

    try {
      const response = await fetch("/api/v1/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const json = await response.json();

      if (!response.ok) {
        setError(json.message ?? "Unable to create account");
        return;
      }

      persistAuth(json.data);
      router.push(getDashboardRoute(json.data.user.role));
      setForm({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
      });
    } catch (exception) {
      console.error(exception);
      setError("An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-background">
        <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-16">
          <Card className="border">
            <CardHeader>
              <CardTitle>User Registration</CardTitle>
              <p className="text-xl text-muted-foreground">
                একটি সাধারণ user account খুলুন। পরে দরকার হলে admin panel থেকে এই account-এর role update করা যাবে।
              </p>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={form.name}
                    onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={form.password}
                    onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
                    required
                    minLength={6}
                  />
                </div>

                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={form.confirmPassword}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, confirmPassword: event.target.value }))
                    }
                    required
                    minLength={6}
                  />
                </div>

                {error && <div className="text-xs text-destructive">{error}</div>}
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Submitting…" : "Register"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
