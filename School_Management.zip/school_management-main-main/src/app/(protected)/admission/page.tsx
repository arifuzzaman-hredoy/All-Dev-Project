
import AdmissionForm from "./admission-form"
import { listBranchesPublic } from "@/services/branch.service"
import Navbar from "@/components/navbars-02"

export default async function AdmissionPage() {
    const { branches } = await listBranchesPublic()

    return (
      <>
            <Navbar />

            <AdmissionForm branches={branches} />
</>
        
    )
}
