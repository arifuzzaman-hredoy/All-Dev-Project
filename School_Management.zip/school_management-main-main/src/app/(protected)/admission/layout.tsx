"use client"

import { type ReactNode } from "react"


type ProtectedLayoutProps = {
    children: ReactNode
}

export default function ProtectedLayout({ children }: ProtectedLayoutProps) {
    return (
        <div className="flex min-h-screen flex-col bg-background overflow-x-hidden">
            <div className="mx-auto flex w-full max-w-6xl  flex-col gap-6">
                <main className=" rounded-3xl border border-border/40 bg-background/70 p-6 shadow-2xl shadow-primary/10 backdrop-blur">
                    {children}
                </main>
            </div>
        </div>
    )
}
