"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { Gender } from "@prisma/client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const ADMISSION_DRAFT_STORAGE_KEY = "school-erp:admission:draft";

type FormState = {
  branchId: string;
  name: string;
  email: string;
  phone: string;
  gender: Gender | "";
  classId: string;
  fatherName: string;
  fatherPhone: string;
  motherName: string;
  motherPhone: string;
  guardianName: string;
  guardianEmail: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianAddress: string;
  nidNumber: string;
  nidImage: string;
  profileImage: string;
  fatherNidNumber: string;
  fatherNidImage: string;
  motherNidNumber: string;
  motherNidImage: string;
};

const BASE_FORM_STATE: FormState = {
  branchId: "",
  name: "",
  email: "",
  phone: "",
  gender: "",
  classId: "",
  fatherName: "",
  fatherPhone: "",
  motherName: "",
  motherPhone: "",
  guardianName: "",
  guardianEmail: "",
  guardianRelation: "",
  guardianPhone: "",
  guardianAddress: "",
  nidNumber: "",
  nidImage: "",
  profileImage: "",
  fatherNidNumber: "",
  fatherNidImage: "",
  motherNidNumber: "",
  motherNidImage: "",
};

type FormErrors = Partial<Record<keyof FormState, string>>;

type ClassOption = {
  id: string;
  name: string;
};

type BranchOption = {
  id: string;
  name: string;
  slug: string;
  school: { id: string; name: string; slug: string };
};

type AdmissionFormProps = {
  branches: BranchOption[];
};

function buildDefaultForm(
  branches: BranchOption[],
  classOptions: ClassOption[],
): FormState {
  return {
    ...BASE_FORM_STATE,
    branchId: branches[0]?.id ?? "",
    classId: classOptions[0]?.id ?? "",
  };
}

function parseDraftForm(
  raw: string | null,
  branches: BranchOption[],
  classOptions: ClassOption[],
): FormState | null {
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw) as Partial<FormState>;
    const fallback = buildDefaultForm(branches, classOptions);
    const branchIds = new Set(branches.map((item) => item.id));
    const classIds = new Set(classOptions.map((item) => item.id));

    return {
      branchId:
        typeof parsed.branchId === "string" && branchIds.has(parsed.branchId)
          ? parsed.branchId
          : fallback.branchId,
      name: typeof parsed.name === "string" ? parsed.name : fallback.name,
      email: typeof parsed.email === "string" ? parsed.email : fallback.email,
      phone: typeof parsed.phone === "string" ? parsed.phone : fallback.phone,
      gender:
        parsed.gender === "MALE" ||
        parsed.gender === "FEMALE" ||
        parsed.gender === "OTHER"
          ? parsed.gender
          : fallback.gender,
      classId:
        typeof parsed.classId === "string" &&
        (classIds.size === 0 || classIds.has(parsed.classId))
          ? parsed.classId
          : fallback.classId,
      fatherName:
        typeof parsed.fatherName === "string"
          ? parsed.fatherName
          : fallback.fatherName,
      fatherPhone:
        typeof parsed.fatherPhone === "string"
          ? parsed.fatherPhone
          : fallback.fatherPhone,
      motherName:
        typeof parsed.motherName === "string"
          ? parsed.motherName
          : fallback.motherName,
      motherPhone:
        typeof parsed.motherPhone === "string"
          ? parsed.motherPhone
          : fallback.motherPhone,
      guardianName:
        typeof parsed.guardianName === "string"
          ? parsed.guardianName
          : fallback.guardianName,
      guardianEmail:
        typeof parsed.guardianEmail === "string"
          ? parsed.guardianEmail
          : fallback.guardianEmail,
      guardianRelation:
        typeof parsed.guardianRelation === "string"
          ? parsed.guardianRelation
          : fallback.guardianRelation,
      guardianPhone:
        typeof parsed.guardianPhone === "string"
          ? parsed.guardianPhone
          : fallback.guardianPhone,
      guardianAddress:
        typeof parsed.guardianAddress === "string"
          ? parsed.guardianAddress
          : fallback.guardianAddress,
      nidNumber:
        typeof parsed.nidNumber === "string"
          ? parsed.nidNumber
          : fallback.nidNumber,
      nidImage:
        typeof parsed.nidImage === "string"
          ? parsed.nidImage
          : fallback.nidImage,
      profileImage:
        typeof parsed.profileImage === "string"
          ? parsed.profileImage
          : fallback.profileImage,
      fatherNidNumber:
        typeof parsed.fatherNidNumber === "string"
          ? parsed.fatherNidNumber
          : fallback.fatherNidNumber,
      fatherNidImage:
        typeof parsed.fatherNidImage === "string"
          ? parsed.fatherNidImage
          : fallback.fatherNidImage,
      motherNidNumber:
        typeof parsed.motherNidNumber === "string"
          ? parsed.motherNidNumber
          : fallback.motherNidNumber,
      motherNidImage:
        typeof parsed.motherNidImage === "string"
          ? parsed.motherNidImage
          : fallback.motherNidImage,
    };
  } catch {
    return null;
  }
}

export default function AdmissionForm({ branches }: AdmissionFormProps) {
  const router = useRouter();
  const [classOptions, setClassOptions] = useState<ClassOption[]>([]);
  const [classesLoading, setClassesLoading] = useState(false);
  const buildInitialState = () => buildDefaultForm(branches, classOptions);
  const [form, setForm] = useState<FormState>(() => buildInitialState());
  const [errors, setErrors] = useState<FormErrors>({});
  const [feedback, setFeedback] = useState<{
    kind: "success" | "error";
    message: string;
  } | null>(null);
  const [draftReady, setDraftReady] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPending, startTransition] = useTransition();
  const skipNextDraftSaveRef = useRef(false);

  useEffect(() => {
    const storedDraft = parseDraftForm(
      window.localStorage.getItem(ADMISSION_DRAFT_STORAGE_KEY),
      branches,
      classOptions,
    );

    if (storedDraft) {
      setForm(storedDraft);
    }

    setDraftReady(true);
  }, [branches, classOptions]);

  useEffect(() => {
    if (!form.branchId) {
      setClassOptions([]);
      return;
    }

    let cancelled = false;
    const loadClasses = async () => {
      setClassesLoading(true);
      try {
        const response = await fetch(`/api/v1/classes?branchId=${form.branchId}`);
        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load classes");
        }
        const nextClasses = (json.data?.classes ?? []) as ClassOption[];
        if (cancelled) return;
        setClassOptions(nextClasses);
        setForm((prev) => ({
          ...prev,
          classId: nextClasses.some((item) => item.id === prev.classId)
            ? prev.classId
            : nextClasses[0]?.id ?? "",
        }));
      } catch {
        if (!cancelled) {
          setClassOptions([]);
          setForm((prev) => ({ ...prev, classId: "" }));
        }
      } finally {
        if (!cancelled) setClassesLoading(false);
      }
    };

    void loadClasses();
    return () => {
      cancelled = true;
    };
  }, [form.branchId]);

  useEffect(() => {
    if (!draftReady || isSubmitting) return;

    if (skipNextDraftSaveRef.current) {
      skipNextDraftSaveRef.current = false;
      return;
    }

    try {
      window.localStorage.setItem(
        ADMISSION_DRAFT_STORAGE_KEY,
        JSON.stringify(form),
      );
    } catch {
      // Ignore localStorage failures and keep the form usable.
    }
  }, [draftReady, form, isSubmitting]);

  const updateField = <K extends keyof FormState>(
    field: K,
    value: FormState[K],
  ) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const buildErrors = (): FormErrors => {
    const next: FormErrors = {};
    if (!form.name.trim()) next.name = "Name is required";
    if (!form.email.trim()) next.email = "Email is required";
    if (!form.phone.trim()) next.phone = "Phone number is required";
    else if (form.phone.trim().length < 6)
      next.phone = "Phone number is too short";
    if (!form.gender) next.gender = "Select a gender";
    if (!form.branchId) next.branchId = "Select a school branch";
    if (classOptions.length && !form.classId) next.classId = "Select a class";
    if (!form.fatherName.trim()) next.fatherName = "Father's name is required";
    if (!form.fatherPhone.trim())
      next.fatherPhone = "Father's phone is required";
    if (!form.motherName.trim()) next.motherName = "Mother's name is required";
    if (!form.motherPhone.trim())
      next.motherPhone = "Mother's phone is required";
    if (!form.guardianName.trim())
      next.guardianName = "Guardian's name is required";
    if (!form.guardianEmail.trim())
      next.guardianEmail = "Guardian email is required";
    else if (!/\S+@\S+\.\S+/.test(form.guardianEmail.trim()))
      next.guardianEmail = "Enter a valid guardian email";
    if (!form.guardianRelation.trim())
      next.guardianRelation = "Guardian relation is required";
    if (!form.guardianPhone.trim())
      next.guardianPhone = "Guardian phone is required";
    if (!form.nidNumber.trim()) next.nidNumber = "NID number is required";
    if (!form.nidImage) next.nidImage = "Upload a NID picture";
    if (!form.fatherNidNumber.trim())
      next.fatherNidNumber = "Father's NID number is required";
    if (!form.fatherNidImage)
      next.fatherNidImage = "Upload father's NID picture";
    if (!form.motherNidNumber.trim())
      next.motherNidNumber = "Mother's NID number is required";
    if (!form.motherNidImage)
      next.motherNidImage = "Upload mother's NID picture";
    if (!form.profileImage) next.profileImage = "Upload a student picture";
    return next;
  };

  const readFileAsDataUrl = (file: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });

  const handleFileChange = async (
    field: "nidImage" | "profileImage" | "fatherNidImage" | "motherNidImage",
    file?: File,
  ) => {
    if (!file) {
      setForm((prev) => ({ ...prev, [field]: "" }));
      return;
    }

    try {
      const dataUrl = await readFileAsDataUrl(file);
      setForm((prev) => ({ ...prev, [field]: dataUrl }));
    } catch {
      setFeedback({
        kind: "error",
        message: "Unable to read the selected image",
      });
    }
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validation = buildErrors();
    if (Object.keys(validation).length) {
      setErrors(validation);
      setFeedback(null);
      return;
    }

    setErrors({});
    setIsSubmitting(true);
    startTransition(() => {
      (async () => {
        try {
          setFeedback(null);
          const selectedClass = classOptions.find(
            (item) => item.id === form.classId,
          );

          if (!selectedClass) {
            throw new Error(
              "Select a class before submitting the admission request",
            );
          }

          const response = await fetch("/api/v1/admissions", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name: form.name.trim(),
              branchId: form.branchId,
              classId: selectedClass.id,
              email: form.email.trim(),
              phone: form.phone.trim(),
              className: selectedClass.name,
              gender: form.gender || undefined,
              fatherName: form.fatherName.trim(),
              fatherPhone: form.fatherPhone.trim(),
              motherName: form.motherName.trim(),
              motherPhone: form.motherPhone.trim(),
              guardianName: form.guardianName.trim(),
              guardianEmail: form.guardianEmail.trim(),
              guardianRelation: form.guardianRelation.trim(),
              guardianPhone: form.guardianPhone.trim(),
              guardianAddress: form.guardianAddress.trim(),
              nidNumber: form.nidNumber.trim(),
              nidImage: form.nidImage,
              profileImage: form.profileImage,
              fatherNidNumber: form.fatherNidNumber.trim(),
              fatherNidImage: form.fatherNidImage,
              motherNidNumber: form.motherNidNumber.trim(),
              motherNidImage: form.motherNidImage,
            }),
          });

          const payload = await response.json();
          if (!response.ok || payload?.success === false) {
            throw new Error(
              payload?.message ?? "Failed to submit admission application",
            );
          }

          skipNextDraftSaveRef.current = true;
          try {
            window.localStorage.removeItem(ADMISSION_DRAFT_STORAGE_KEY);
          } catch {
            // Ignore localStorage cleanup failures after a successful submit.
          }
          toast.success(
            `Admission submitted successfully. Account details were sent to ${form.email.trim()} and ${form.guardianEmail.trim()}.`,
          );
          router.replace("/");
        } catch (error) {
          setFeedback({
            kind: "error",
            message:
              error instanceof Error
                ? error.message
                : "Unable to submit admission application",
          });
        } finally {
          setIsSubmitting(false);
        }
      })();
    });
  };

  const fieldClassName = (field: keyof FormState) =>
    cn(
      field === "gender" || field === "classId"
        ? ""
        : errors[field]
          ? "border-destructive focus-visible:border-destructive focus-visible:ring-destructive/30"
          : "",
    );

  const selectTriggerClass = (field: keyof FormState) =>
    cn(
      errors[field]
        ? "border-destructive focus-visible:border-destructive focus-visible:ring-destructive/30"
        : "",
    );

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="grid gap-3 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="student-name">Full name</Label>
          <Input
            id="student-name"
            placeholder="Full name"
            value={form.name}
            onChange={(event) => updateField("name", event.target.value)}
            className={fieldClassName("name")}
            aria-invalid={!!errors.name}
          />
          {errors.name && (
            <p className="text-xs text-destructive">{errors.name}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="student-email">Email address</Label>
          <Input
            id="student-email"
            placeholder="Email"
            type="email"
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
            className={fieldClassName("email")}
            aria-invalid={!!errors.email}
          />
          {errors.email && (
            <p className="text-xs text-destructive">{errors.email}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="student-phone">Phone number</Label>
        <Input
          id="student-phone"
          placeholder="Phone"
          value={form.phone}
          onChange={(event) => updateField("phone", event.target.value)}
          className={fieldClassName("phone")}
          aria-invalid={!!errors.phone}
        />
        {errors.phone && (
          <p className="text-xs text-destructive">{errors.phone}</p>
        )}
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="student-gender">Gender</Label>
          <Select
            value={form.gender}
            onValueChange={(value) => updateField("gender", value as Gender)}
          >
            <SelectTrigger
              className={cn("w-full", selectTriggerClass("gender"))}
              size="default"
              id="student-gender"
            >
              <SelectValue placeholder="Select gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MALE">Male</SelectItem>
              <SelectItem value="FEMALE">Female</SelectItem>
              <SelectItem value="OTHER">Non-binary</SelectItem>
            </SelectContent>
          </Select>
          {errors.gender && (
            <p className="text-xs text-destructive">{errors.gender}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="school-branch">School branch</Label>
          <Select
            value={form.branchId}
            onValueChange={(value) =>
              setForm((prev) => ({ ...prev, branchId: value, classId: "" }))
            }
            disabled={!branches.length}
          >
            <SelectTrigger
              className={cn("w-full", selectTriggerClass("branchId"))}
              size="default"
              id="school-branch"
            >
              <SelectValue
                placeholder={
                  branches.length ? "Select branch" : "No branches configured"
                }
              />
            </SelectTrigger>
            <SelectContent>
              {branches.length ? (
                branches.map((branch) => (
                  <SelectItem key={branch.id} value={branch.id}>
                    {branch.school.name} · {branch.name}
                  </SelectItem>
                ))
              ) : (
                <div className="px-2 py-2 text-xs text-muted-foreground">
                  No school branches configured
                </div>
              )}
            </SelectContent>
          </Select>
          {errors.branchId && (
            <p className="text-xs text-destructive">{errors.branchId}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="student-class">Class</Label>
          <Select
            value={form.classId}
            onValueChange={(value) => updateField("classId", value)}
            disabled={!classOptions.length}
          >
            <SelectTrigger
              className={cn("w-full", selectTriggerClass("classId"))}
              size="default"
              id="student-class"
            >
            <SelectValue
              placeholder={
                  classesLoading
                    ? "Loading classes"
                    : classOptions.length
                      ? "Select class"
                      : "No classes configured"
                }
              />
            </SelectTrigger>
            <SelectContent>
              {classOptions.length ? (
                classOptions.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                ))
              ) : (
                <div className="px-2 py-2 text-xs text-muted-foreground">
                  Create classes first
                </div>
              )}
            </SelectContent>
          </Select>
          {errors.classId && (
            <p className="text-xs text-destructive">{errors.classId}</p>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-muted-foreground">
          Parents&apos; details
        </h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-4 rounded-2xl border border-border/60 bg-background/80 p-4">
            <p className="text-sm font-medium">Father</p>
            <div className="space-y-2">
              <Label htmlFor="father-name">Name</Label>
              <Input
                id="father-name"
                placeholder="Father's name"
                value={form.fatherName}
                onChange={(event) =>
                  updateField("fatherName", event.target.value)
                }
                className={fieldClassName("fatherName")}
                aria-invalid={!!errors.fatherName}
              />
              {errors.fatherName && (
                <p className="text-xs text-destructive">{errors.fatherName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="father-phone">Phone</Label>
              <Input
                id="father-phone"
                placeholder="Father's phone"
                value={form.fatherPhone}
                onChange={(event) =>
                  updateField("fatherPhone", event.target.value)
                }
                className={fieldClassName("fatherPhone")}
                aria-invalid={!!errors.fatherPhone}
              />
              {errors.fatherPhone && (
                <p className="text-xs text-destructive">{errors.fatherPhone}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="father-nid-number">NID number</Label>
              <Input
                id="father-nid-number"
                placeholder="Father's NID number"
                value={form.fatherNidNumber}
                onChange={(event) =>
                  updateField("fatherNidNumber", event.target.value)
                }
                className={fieldClassName("fatherNidNumber")}
                aria-invalid={!!errors.fatherNidNumber}
              />
              {errors.fatherNidNumber && (
                <p className="text-xs text-destructive">
                  {errors.fatherNidNumber}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="father-nid-image">NID image</Label>
              <Input
                id="father-nid-image"
                type="file"
                accept="image/*"
                onChange={(event) =>
                  handleFileChange("fatherNidImage", event.target.files?.[0])
                }
              />
              {form.fatherNidImage && (
                <p className="text-xs text-muted-foreground">
                  Father NID attached
                </p>
              )}
              {errors.fatherNidImage && (
                <p className="text-xs text-destructive">
                  {errors.fatherNidImage}
                </p>
              )}
            </div>
          </div>

          <div className="space-y-4 rounded-2xl border border-border/60 bg-background/80 p-4">
            <p className="text-sm font-medium">Mother</p>
            <div className="space-y-2">
              <Label htmlFor="mother-name">Name</Label>
              <Input
                id="mother-name"
                placeholder="Mother's name"
                value={form.motherName}
                onChange={(event) =>
                  updateField("motherName", event.target.value)
                }
                className={fieldClassName("motherName")}
                aria-invalid={!!errors.motherName}
              />
              {errors.motherName && (
                <p className="text-xs text-destructive">{errors.motherName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="mother-phone">Phone</Label>
              <Input
                id="mother-phone"
                placeholder="Mother's phone"
                value={form.motherPhone}
                onChange={(event) =>
                  updateField("motherPhone", event.target.value)
                }
                className={fieldClassName("motherPhone")}
                aria-invalid={!!errors.motherPhone}
              />
              {errors.motherPhone && (
                <p className="text-xs text-destructive">{errors.motherPhone}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="mother-nid-number">NID number</Label>
              <Input
                id="mother-nid-number"
                placeholder="Mother's NID number"
                value={form.motherNidNumber}
                onChange={(event) =>
                  updateField("motherNidNumber", event.target.value)
                }
                className={fieldClassName("motherNidNumber")}
                aria-invalid={!!errors.motherNidNumber}
              />
              {errors.motherNidNumber && (
                <p className="text-xs text-destructive">
                  {errors.motherNidNumber}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="mother-nid-image">NID image</Label>
              <Input
                id="mother-nid-image"
                type="file"
                accept="image/*"
                onChange={(event) =>
                  handleFileChange("motherNidImage", event.target.files?.[0])
                }
              />
              {form.motherNidImage && (
                <p className="text-xs text-muted-foreground">
                  Mother NID attached
                </p>
              )}
              {errors.motherNidImage && (
                <p className="text-xs text-destructive">
                  {errors.motherNidImage}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-muted-foreground">
          Guardian details
        </h3>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="guardian-name">Guardian name</Label>
            <Input
              id="guardian-name"
              placeholder="Guardian name"
              value={form.guardianName}
              onChange={(event) =>
                updateField("guardianName", event.target.value)
              }
              className={fieldClassName("guardianName")}
              aria-invalid={!!errors.guardianName}
            />
            {errors.guardianName && (
              <p className="text-xs text-destructive">{errors.guardianName}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="guardian-email">Guardian email</Label>
            <Input
              id="guardian-email"
              placeholder="Guardian email"
              type="email"
              value={form.guardianEmail}
              onChange={(event) =>
                updateField("guardianEmail", event.target.value)
              }
              className={fieldClassName("guardianEmail")}
              aria-invalid={!!errors.guardianEmail}
            />
            {errors.guardianEmail && (
              <p className="text-xs text-destructive">{errors.guardianEmail}</p>
            )}
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="guardian-relation">Relation</Label>
            <Input
              id="guardian-relation"
              placeholder="Guardian relation"
              value={form.guardianRelation}
              onChange={(event) =>
                updateField("guardianRelation", event.target.value)
              }
              className={fieldClassName("guardianRelation")}
              aria-invalid={!!errors.guardianRelation}
            />
            {errors.guardianRelation && (
              <p className="text-xs text-destructive">
                {errors.guardianRelation}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="guardian-phone">Guardian phone</Label>
            <Input
              id="guardian-phone"
              placeholder="Guardian phone"
              value={form.guardianPhone}
              onChange={(event) =>
                updateField("guardianPhone", event.target.value)
              }
              className={fieldClassName("guardianPhone")}
              aria-invalid={!!errors.guardianPhone}
            />
            {errors.guardianPhone && (
              <p className="text-xs text-destructive">{errors.guardianPhone}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="guardian-address">Guardian address</Label>
            <Input
              id="guardian-address"
              placeholder="Guardian address"
              value={form.guardianAddress}
              onChange={(event) =>
                updateField("guardianAddress", event.target.value)
              }
              className={fieldClassName("guardianAddress")}
              aria-invalid={!!errors.guardianAddress}
            />
            {errors.guardianAddress && (
              <p className="text-xs text-destructive">
                {errors.guardianAddress}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-muted-foreground">
          Identity & media
        </h3>
        <div className="space-y-2">
          <Label htmlFor="nid-number">NID number</Label>
          <Input
            id="nid-number"
            placeholder="NID number"
            value={form.nidNumber}
            onChange={(event) => updateField("nidNumber", event.target.value)}
            className={fieldClassName("nidNumber")}
            aria-invalid={!!errors.nidNumber}
          />
          {errors.nidNumber && (
            <p className="text-xs text-destructive">{errors.nidNumber}</p>
          )}
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="nid-image">Upload NID image</Label>
            <Input
              id="nid-image"
              type="file"
              accept="image/*"
              onChange={(event) =>
                handleFileChange("nidImage", event.target.files?.[0])
              }
            />
            {form.nidImage && (
              <p className="text-xs text-muted-foreground">
                {"NID image attached"}
              </p>
            )}
            {errors.nidImage && (
              <p className="text-xs text-destructive">{errors.nidImage}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="profile-image">Upload student photo</Label>
            <Input
              id="profile-image"
              type="file"
              accept="image/*"
              onChange={(event) =>
                handleFileChange("profileImage", event.target.files?.[0])
              }
            />
            {form.profileImage && (
              <p className="text-xs text-muted-foreground">
                {"Student photo attached"}
              </p>
            )}
            {errors.profileImage && (
              <p className="text-xs text-destructive">{errors.profileImage}</p>
            )}
          </div>
        </div>
      </div>

      {feedback && (
        <div
          className={cn(
            "rounded-2xl border px-3 py-2 text-sm",
            feedback.kind === "success"
              ? "border-secondary/80 bg-secondary/10 text-secondary"
              : "border-destructive/80 bg-destructive/10 text-destructive",
          )}
          aria-live="polite"
        >
          {feedback.message}
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        Draft data is saved in your browser until you submit this form.
      </p>

      <Button
        className="w-full md:w-auto"
        type="submit"
        disabled={isPending || isSubmitting}
      >
        {isPending || isSubmitting ? "Saving..." : "Create student"}
      </Button>
    </form>
  );
}
