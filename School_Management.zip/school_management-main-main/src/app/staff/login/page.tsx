"use client";

import type { FormEvent } from "react";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import Navbar from "@/components/navbars-02";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getDashboardRoute } from "@/lib/role-routes";
import { persistAuth } from "@/utils/auth-storage";

type PublicBranch = {
  id: string;
  name: string;
  slug: string;
  school: { id: string; name: string; slug: string };
};

type BranchesResponse = { branches: PublicBranch[] };

export default function StaffLoginPage() {
  const router = useRouter();
  const [branches, setBranches] = useState<PublicBranch[]>([]);
  const [branchId, setBranchId] = useState("");
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [loadingBranches, setLoadingBranches] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoadingBranches(true);
      setError(null);

      try {
        const response = await fetch("/api/v1/public/branches");
        const json = await response.json();
        if (!response.ok) {
          throw new Error(json.message ?? "Unable to load branches");
        }

        const data = json.data as BranchesResponse;
        setBranches(data.branches);
        setBranchId((current) => current || data.branches[0]?.id || "");
      } catch (exception) {
        setError(exception instanceof Error ? exception.message : "Unable to load branches");
      } finally {
        setLoadingBranches(false);
      }
    };

    void load();
  }, []);

  const options = useMemo(() => {
    return [...branches].sort((a, b) => {
      const schoolCmp = a.school.name.localeCompare(b.school.name);
      if (schoolCmp !== 0) return schoolCmp;
      return a.name.localeCompare(b.name);
    });
  }, [branches]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError(null);

    if (!branchId) {
      setError("Please select a school branch");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/v1/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, branchId, loginScope: "staff" }),
      });

      const json = await response.json();
      if (!response.ok) {
        setError(json.message ?? "Unable to login");
        return;
      }

      persistAuth(json.data);
      router.push(getDashboardRoute(json.data.user.role));
    } catch (exception) {
      console.error(exception);
      setError("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-background">
        <div className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-16">
          <Card className="border">
            <CardHeader>
              <CardTitle>Staff sign in</CardTitle>
              <p className="text-xs text-muted-foreground">
                Select your branch, then sign in using your email and password.
              </p>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div>
                  <Label htmlFor="branch">Branch</Label>
                  <select
                    id="branch"
                    className="h-9 w-full rounded-none border border-input bg-transparent px-2.5 py-1 text-sm"
                    value={branchId}
                    onChange={(event) => setBranchId(event.target.value)}
                    disabled={loadingBranches || loading}
                  >
                    <option value="">Select school branch</option>
                    {options.length === 0 ? (
                      <option value="" disabled>
                        No branches found
                      </option>
                    ) : null}
                    {options.map((branch) => (
                      <option key={branch.id} value={branch.id}>
                        {branch.school.name} · {branch.name}
                      </option>
                    ))}
                  </select>
                  {loadingBranches ? (
                    <p className="mt-1 text-xs text-muted-foreground">Loading branches...</p>
                  ) : null}
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={form.password}
                    onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
                    required
                    minLength={6}
                  />
                </div>

                {error && <div className="text-xs text-destructive">{error}</div>}

                <Button type="submit" className="w-full" disabled={loading || loadingBranches}>
                  {loading ? "Signing in..." : "Sign In"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
