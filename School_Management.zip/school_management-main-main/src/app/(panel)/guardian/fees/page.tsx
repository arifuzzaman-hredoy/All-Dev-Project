"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { downloadWithAuth, fetchWithAuth } from "@/lib/client-api";
import { cn } from "@/lib/utils";

type PaymentItem = {
  id: string;
  createdAt: string;
  amountPaid: number;
  status: string;
  paymentMethod: string | null;
  transactionId: string | null;
  dueDate: string | null;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  totalAmount: number;
  dueAmount: number;
  billingPeriodLabel: string;
  feeCategory: { name: string; amount: number };
  student: { id: string; user: { name: string }; class: { name: string } };
};

type HistoryItem = {
  key: string;
  studentId: string;
  studentName: string;
  className: string;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: PaymentItem[];
};

type FeesPayload = {
  children: Array<{ id: string; name: string; className: string }>;
  selectedStudentId: string | null;
  payments: PaymentItem[];
  history: HistoryItem[];
};

const formatMoney = (value: number) => `৳${value}`;

export default function Page() {
  const [data, setData] = useState<FeesPayload | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState("");
  const [error, setError] = useState("");
  const [downloadingId, setDownloadingId] = useState("");

  async function load(studentId?: string) {
    const params = new URLSearchParams();
    if (studentId) params.set("studentId", studentId);
    const payload = await fetchWithAuth<FeesPayload>(
      `/api/v1/guardian/fees?${params.toString()}`,
    );
    setData(payload);
    setSelectedStudentId(payload.selectedStudentId ?? "");
  }
  useEffect(() => {
    let active = true;
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<FeesPayload>("/api/v1/guardian/fees");
        if (!active) return;
        setData(payload);
        setSelectedStudentId(payload.selectedStudentId ?? "");
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load fees",
        );
      }
    }
    void bootstrap();
    return () => {
      active = false;
    };
  }, []);

  async function handleDownloadReceipt(paymentId: string) {
    setError("");
    setDownloadingId(paymentId);
    try {
      await downloadWithAuth(
        `/api/v1/guardian/fees/${paymentId}/receipt${selectedStudentId ? `?studentId=${encodeURIComponent(selectedStudentId)}` : ""}`,
        `payment-receipt-${paymentId}.html`,
      );
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to download receipt",
      );
    } finally {
      setDownloadingId("");
    }
  }

  const selectedHistory = data?.history ?? [];
  const children = data?.children ?? [];
  const summary = selectedHistory.reduce(
    (acc, item) => {
      acc.monthlyDue += item.monthlyFeeDue;
      acc.extraDue += item.extraCategoryDue;
      acc.paid += item.amountPaid;
      acc.due += item.dueAmount;
      return acc;
    },
    { monthlyDue: 0, extraDue: 0, paid: 0, due: 0 },
  );

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
        <p className="text-xs uppercase tracking-[0.28em] text-muted-foreground">
          Guardian finance ledger
        </p>
        <h1 className="mt-2 text-xl font-semibold">Fees</h1>
        <p className="text-sm text-muted-foreground">
          See monthly due, extra due, amount paid, due amount,
          and transaction details for each child.
        </p>
      </div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <div className="flex flex-wrap gap-2 rounded-2xl border border-border bg-card p-4">
        {children.length ? (
          children.map((child) => (
            <button
              key={child.id}
              type="button"
              onClick={() =>
                void load(child.id).catch((nextError) =>
                  setError(
                    nextError instanceof Error
                      ? nextError.message
                      : "Unable to load fees",
                  ),
                )
              }
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-semibold transition",
                selectedStudentId === child.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-muted text-foreground",
              )}
            >
              {child.name} · {child.className}
            </button>
          ))
        ) : (
          <p className="text-sm text-muted-foreground">No linked children found.</p>
        )}
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        <Card className="rounded-2xl border border-border">
          <CardContent className="p-3">
            <p className="text-xs text-muted-foreground">Monthly due</p>
            <p className="text-lg font-semibold">{formatMoney(summary.monthlyDue)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border border-border">
          <CardContent className="p-3">
            <p className="text-xs text-muted-foreground">Extra due</p>
            <p className="text-lg font-semibold">{formatMoney(summary.extraDue)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border border-border">
          <CardContent className="p-3">
            <p className="text-xs text-muted-foreground">Amount paid</p>
            <p className="text-lg font-semibold">{formatMoney(summary.paid)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border border-border">
          <CardContent className="p-3">
            <p className="text-xs text-muted-foreground">Due amount</p>
            <p className="text-lg font-semibold">{formatMoney(summary.due)}</p>
          </CardContent>
        </Card>
      </div>

          <div className="space-y-4">
            {selectedHistory.length ? (
              selectedHistory.map((period) => (
                <Card key={period.key} className="rounded-3xl border border-border">
                  <CardContent className="space-y-4 p-5">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                          Billing period
                        </p>
                        <h2 className="mt-1 text-lg font-semibold">
                          {period.label} · {period.studentName}
                        </h2>
                        <p className="text-sm text-muted-foreground">
                          {period.className} · Base {formatMoney(period.monthlyFeeBase)} · Extra {formatMoney(period.extraCategoryFees)}
                        </p>
                      </div>
                      <div className="rounded-2xl border border-border bg-muted/40 px-4 py-3 text-right">
                        <p className="text-xs text-muted-foreground">Due</p>
                        <p className="text-lg font-semibold">{formatMoney(period.dueAmount)}</p>
                      </div>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-3">
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">Expected</p>
                        <p className="text-sm font-semibold">{formatMoney(period.totalExpected)}</p>
                      </div>
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">Paid</p>
                        <p className="text-sm font-semibold">{formatMoney(period.amountPaid)}</p>
                      </div>
                      <div className="rounded-2xl bg-muted/50 p-3">
                        <p className="text-xs text-muted-foreground">Transactions</p>
                        <p className="text-sm font-semibold">{period.transactions.length}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {period.transactions.map((payment) => (
                        <div key={payment.id} className="rounded-2xl border border-border bg-background/80 p-4">
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div className="space-y-1">
                              <p className="font-medium">{payment.feeCategory.name}</p>
                              <p className="text-xs text-muted-foreground">
                                Monthly due {formatMoney(payment.monthlyFeeDue)} · Extra due {formatMoney(payment.extraCategoryDue)}
                              </p>
                              <div className="flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                                <span>Method: {payment.paymentMethod ?? "-"}</span>
                                <span>Txn: {payment.transactionId ?? "-"}</span>
                                <span>Due date: {payment.dueDate ? new Date(payment.dueDate).toLocaleDateString() : "-"}</span>
                              </div>
                            </div>
                            <div className="text-right space-y-2">
                              <p className="text-sm font-semibold">{formatMoney(payment.amountPaid)} / {formatMoney(payment.totalAmount)}</p>
                              <p className="text-xs text-muted-foreground">Due {formatMoney(payment.dueAmount)}</p>
                              <span className={cn(
                                "inline-flex rounded-full border px-2 py-1 text-[10px] font-semibold",
                                payment.status === "PAID" && "border-primary bg-primary text-primary-foreground",
                                payment.status === "PARTIAL" && "border-border bg-muted text-foreground",
                                payment.status === "DUE" && "border-border bg-background text-muted-foreground",
                              )}>{payment.status}</span>
                              <div>
                                <button
                                  type="button"
                                  onClick={() => void handleDownloadReceipt(payment.id)}
                                  disabled={downloadingId === payment.id}
                                  className="rounded-full border px-3 py-1 text-xs font-semibold"
                                >
                                  {downloadingId === payment.id ? "Downloading..." : "Download receipt"}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
                No fee records available for this child.
              </div>
            )}
          </div>
        </div>
      );
    }
