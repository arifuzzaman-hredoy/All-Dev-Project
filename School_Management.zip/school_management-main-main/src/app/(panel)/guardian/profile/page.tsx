"use client"

import { useEffect, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type ProfilePayload = {
  profile: { name: string; email: string; phone: string | null; address: string | null }
  children: Array<{ id: string; name: string; className: string }>
}

export default function Page() {
  const [data, setData] = useState<ProfilePayload | null>(null)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true
    async function load() {
      try {
        const payload = await fetchWithAuth<ProfilePayload>("/api/v1/guardian/profile")
        if (!active) return
        setData(payload)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load profile")
      }
    }
    void load()
    return () => { active = false }
  }, [])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div><h1 className="text-xl font-semibold">Profile</h1><p className="text-sm text-muted-foreground">Guardian account information and linked children.</p></div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {data ? (
        <>
          <div className="rounded-xl border p-4">
            <p><span className="text-muted-foreground">Name:</span> {data.profile.name}</p>
            <p><span className="text-muted-foreground">Email:</span> {data.profile.email}</p>
            <p><span className="text-muted-foreground">Phone:</span> {data.profile.phone ?? "Not provided"}</p>
            <p><span className="text-muted-foreground">Address:</span> {data.profile.address ?? "Not provided"}</p>
          </div>
          <div className="rounded-xl border p-4">
            <h2 className="mb-3 font-semibold">Linked Children</h2>
            <div className="space-y-2">
              {data.children.map((child) => <p key={child.id} className="text-sm">{child.name} · <span className="text-muted-foreground">{child.className}</span></p>)}
            </div>
          </div>
        </>
      ) : null}
    </div>
  )
}
