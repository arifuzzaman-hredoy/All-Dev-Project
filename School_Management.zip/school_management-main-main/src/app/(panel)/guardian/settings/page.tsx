"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { fetchWithAuth } from "@/lib/client-api"
import { clearAuth, persistAuth, readAuth } from "@/utils/auth-storage"

type ProfilePayload = {
  profile: { name: string; email: string; phone: string | null; address: string | null }
}

export default function Page() {
  const router = useRouter()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true
    async function load() {
      try {
        const payload = await fetchWithAuth<ProfilePayload>("/api/v1/guardian/profile")
        if (!active) return
        setName(payload.profile.name)
        setEmail(payload.profile.email)
        setPhone(payload.profile.phone ?? "")
        setAddress(payload.profile.address ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load settings")
      }
    }
    void load()
    return () => { active = false }
  }, [])

  const saveProfile = async () => {
    setError("")
    setMessage("")
    try {
      await fetchWithAuth("/api/v1/guardian/profile", {
        method: "PATCH",
        body: JSON.stringify({ name, email, phone, address }),
      })
      const auth = readAuth()
      if (auth) {
        persistAuth({ ...auth, user: { ...auth.user, name, email } })
      }
      setMessage("Profile updated successfully")
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update profile")
    }
  }

  const savePassword = async () => {
    setError("")
    setMessage("")
    try {
      const payload = await fetchWithAuth<{ message: string }>("/api/v1/guardian/settings/password", {
        method: "PATCH",
        body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
      })
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setMessage(payload.message)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update password")
    }
  }

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div><h1 className="text-xl font-semibold">Settings</h1><p className="text-sm text-muted-foreground">Manage guardian account preferences.</p></div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {message ? <p className="text-sm text-emerald-600">{message}</p> : null}
      <div className="rounded-xl border p-4 space-y-3">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
        <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" />
        <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Address" />
        <button onClick={() => void saveProfile()} className="rounded-full border px-4 py-2 text-sm font-semibold">Save profile</button>
      </div>
      <div className="rounded-xl border p-4 space-y-3">
        <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="Current password" />
        <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="New password" />
        <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm password" />
        <div className="flex gap-2">
          <button onClick={() => void savePassword()} className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Save password</button>
          <button onClick={() => { clearAuth(); router.push('/login') }} className="rounded-full border px-4 py-2 text-sm font-semibold">Logout</button>
        </div>
      </div>
    </div>
  )
}
