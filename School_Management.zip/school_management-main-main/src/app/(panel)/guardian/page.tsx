"use client";

import { useEffect, useState } from "react";
import { fetchWithAuth } from "@/lib/client-api";

type GuardianDashboard = {
  dashboard: {
    guardian: { name: string };
    children: Array<{
      id: string;
      name: string;
      className: string;
      rollNumber: number | null;
    }>;
    stats: {
      totalChildren: number;
      attendanceRate: number;
      totalDue: number;
      recentResults: number;
    };
    upcomingExams: Array<{
      id: string;
      name: string;
      code: string;
      date: string;
      status: string;
      className: string;
      examType: string | null;
    }>;
    recentResults: Array<{
      id: string;
      marks: number;
      totalMarks: number;
      grade: string | null;
      student: { user: { name: string } };
      subject: { name: string };
    }>;
    notices: Array<{ id: string; title: string; content: string }>;
  };
};

export default function Page() {
  const [data, setData] = useState<GuardianDashboard["dashboard"] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const payload = await fetchWithAuth<GuardianDashboard>(
          "/api/v1/guardian/dashboard",
        );
        if (!active) return;
        setData(payload.dashboard);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load guardian dashboard",
        );
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div>
        <h1 className="text-2xl font-semibold">
          {data ? `${data.guardian.name}'s dashboard` : "Guardian Dashboard"}
        </h1>
        <p className="text-sm text-muted-foreground">
          Track all linked children from one view.
        </p>
      </div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {data ? (
        <>
          <div className="grid gap-4 md:grid-cols-5">
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Children</p>
              <p className="text-xl font-semibold">
                {data.stats.totalChildren}
              </p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Attendance</p>
              <p className="text-xl font-semibold">
                {data.stats.attendanceRate}%
              </p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Total Due</p>
              <p className="text-xl font-semibold">৳{data.stats.totalDue}</p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Recent Results</p>
              <p className="text-xl font-semibold">
                {data.stats.recentResults}
              </p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Visible Exams</p>
              <p className="text-xl font-semibold">
                {data.upcomingExams.length}
              </p>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Visible Exams</h2>
              <div className="space-y-2">
                {data.upcomingExams.length ? (
                  data.upcomingExams.map((exam) => (
                    <div key={exam.id} className="rounded-lg bg-muted/40 p-3">
                      <p className="font-medium">{exam.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {exam.code} · {exam.className} ·{" "}
                        {new Date(exam.date).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {exam.status.replaceAll("_", " ")}
                        {exam.examType ? ` · ${exam.examType}` : ""}
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No visible exams yet.
                  </p>
                )}
              </div>
            </div>
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Children</h2>
              <div className="space-y-2">
                {data.children.map((child) => (
                  <div key={child.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="font-medium">{child.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {child.className} · Roll {child.rollNumber ?? "-"}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Recent Results</h2>
              <div className="space-y-2">
                {data.recentResults.map((result) => (
                  <div key={result.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="font-medium">
                      {result.student.user.name} · {result.subject.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {result.marks} out of {result.totalMarks} {result.grade ? `· ${result.grade}` : ""}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="rounded-xl border p-4">
            <h2 className="mb-3 font-semibold">Notices</h2>
            <div className="space-y-2">
              {data.notices.map((notice) => (
                <div key={notice.id} className="rounded-lg bg-muted/40 p-3">
                  <p className="font-medium">{notice.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {notice.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
