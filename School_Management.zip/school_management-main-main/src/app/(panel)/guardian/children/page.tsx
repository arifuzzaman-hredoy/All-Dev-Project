"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { fetchWithAuth } from "@/lib/client-api"

type ChildrenPayload = { children: Array<{ id: string; name: string; className: string; groupName: string; sectionName: string; rollNumber: number | null; phone: string | null; gender: string }> }

export default function Page() {
  const [children, setChildren] = useState<ChildrenPayload["children"]>([])
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true
    async function load() {
      try {
        const payload = await fetchWithAuth<ChildrenPayload>("/api/v1/guardian/children")
        if (!active) return
        setChildren(payload.children)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load children")
      }
    }
    void load()
    return () => { active = false }
  }, [])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div><h1 className="text-xl font-semibold">Children</h1><p className="text-sm text-muted-foreground">Linked student records under this guardian.</p></div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <div className="grid gap-4 md:grid-cols-2">
        {children.map((child) => (
          <div key={child.id} className="rounded-xl border p-4">
            <h2 className="font-semibold">{child.name}</h2>
            <p className="text-sm text-muted-foreground">{child.className}</p>
            <p className="text-sm text-muted-foreground">Group {child.groupName} · Section {child.sectionName}</p>
            <p className="text-sm text-muted-foreground">Roll {child.rollNumber ?? "-"}</p>
            <p className="text-sm text-muted-foreground">{child.gender}</p>
            <Link href={`/guardian/children/${child.id}`} className="mt-3 inline-flex rounded-full border px-3 py-1 text-xs font-semibold">
              View details
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}
