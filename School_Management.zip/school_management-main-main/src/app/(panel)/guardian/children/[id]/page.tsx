"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { downloadWithAuth, fetchWithAuth } from "@/lib/client-api";

type PaymentItem = {
  id: string;
  createdAt: string;
  amountPaid: number;
  status: string;
  paymentMethod: string | null;
  transactionId: string | null;
  dueDate: string | null;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  feeCategory: { name: string; amount: number };
  totalAmount: number;
  dueAmount: number;
  billingPeriodLabel: string;
};

type HistoryItem = {
  key: string;
  studentId: string;
  studentName: string;
  className: string;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: PaymentItem[];
};

type ChildDetailPayload = {
  child: {
    id: string;
    name: string;
    email: string;
    className: string;
    groupName: string;
    sectionName: string;
    rollNumber: number | null;
    phone: string | null;
    gender: string;
    attendanceRate: number;
  };
  attendance: Array<{
    id: string;
    date: string;
    status: string;
    subject: { name: string };
  }>;
  results: Array<{
    id: string;
    marks: number;
    totalMarks: number;
    grade: string | null;
    subject: { name: string };
    exam: { name: string; date: string };
  }>;
  payments: PaymentItem[];
  history: HistoryItem[];
  timetable: Array<{
    id: string;
    day: string;
    startTime: string;
    endTime: string;
    subject: { name: string };
    teacher: { user: { name: string } };
  }>;
};

export default function Page() {
  const params = useParams<{ id: string }>();
  const [data, setData] = useState<ChildDetailPayload | null>(null);
  const [error, setError] = useState("");
  const [downloadingReport, setDownloadingReport] = useState(false);
  const [downloadingReceiptId, setDownloadingReceiptId] = useState("");

  const formatMoney = (value: number) => `৳${value}`;

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const payload = await fetchWithAuth<ChildDetailPayload>(
          `/api/v1/guardian/children/${params.id}`,
        );
        if (!active) return;
        setData(payload);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load child detail",
        );
      }
    }
    if (params.id) {
      void load();
    }
    return () => {
      active = false;
    };
  }, [params.id]);

  async function handleDownloadReportCard() {
    if (!data) return;
    setError("");
    setDownloadingReport(true);
    try {
      await downloadWithAuth(
        `/api/v1/guardian/results/export?studentId=${encodeURIComponent(data.child.id)}`,
        `report-card-${data.child.id}.html`,
      );
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to download report card",
      );
    } finally {
      setDownloadingReport(false);
    }
  }

  async function handleDownloadReceipt(paymentId: string) {
    if (!data) return;
    setError("");
    setDownloadingReceiptId(paymentId);
    try {
      await downloadWithAuth(
        `/api/v1/guardian/fees/${paymentId}/receipt?studentId=${encodeURIComponent(data.child.id)}`,
        `payment-receipt-${paymentId}.html`,
      );
    } catch (nextError) {
      setError(
        nextError instanceof Error
          ? nextError.message
          : "Unable to download receipt",
      );
    } finally {
      setDownloadingReceiptId("");
    }
  }

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {data ? (
        <>
          <div>
            <h1 className="text-2xl font-semibold">{data.child.name}</h1>
            <p className="text-sm text-muted-foreground">
              {data.child.className} · Roll {data.child.rollNumber ?? "-"}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => void handleDownloadReportCard()}
                disabled={downloadingReport}
                className="rounded-full border px-4 py-2 text-xs font-semibold"
              >
                {downloadingReport ? "Downloading..." : "Download report card"}
              </button>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Attendance</p>
              <p className="text-xl font-semibold">
                {data.child.attendanceRate}%
              </p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Group</p>
              <p className="text-xl font-semibold">{data.child.groupName}</p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Section</p>
              <p className="text-xl font-semibold">{data.child.sectionName}</p>
            </div>
            <div className="rounded-xl border p-4">
              <p className="text-sm text-muted-foreground">Gender</p>
              <p className="text-xl font-semibold">{data.child.gender}</p>
            </div>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Weekly Timetable</h2>
              <div className="space-y-2">
                {data.timetable.map((item) => (
                  <div key={item.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="font-medium">
                      {item.day} · {item.subject.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {item.startTime} - {item.endTime} ·{" "}
                      {item.teacher.user.name}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Recent Results</h2>
              <div className="space-y-2">
                {data.results.map((item) => (
                  <div key={item.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="font-medium">
                      {item.subject.name} · {item.exam.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {item.marks} out of {item.totalMarks} {item.grade ? `· ${item.grade}` : ""}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Recent Attendance</h2>
              <div className="space-y-2">
                {data.attendance.map((item) => (
                  <div key={item.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="font-medium">{item.subject.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(item.date).toLocaleDateString()} · {item.status}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Fee Snapshot</h2>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="rounded-lg bg-muted/40 p-3">
                  <p className="text-xs text-muted-foreground">Monthly due</p>
                  <p className="text-sm font-semibold">
                    {formatMoney(
                      data.history.reduce(
                        (sum, item) => sum + item.monthlyFeeDue,
                        0,
                      ),
                    )}
                  </p>
                </div>
                <div className="rounded-lg bg-muted/40 p-3">
                  <p className="text-xs text-muted-foreground">Extra due</p>
                  <p className="text-sm font-semibold">
                    {formatMoney(
                      data.history.reduce(
                        (sum, item) => sum + item.extraCategoryDue,
                        0,
                      ),
                    )}
                  </p>
                </div>
                <div className="rounded-lg bg-muted/40 p-3">
                  <p className="text-xs text-muted-foreground">Due</p>
                  <p className="text-sm font-semibold">
                    {formatMoney(
                      data.history.reduce(
                        (sum, item) => sum + item.dueAmount,
                        0,
                      ),
                    )}
                  </p>
                </div>
              </div>
              <div className="mt-4 space-y-3">
                {data.history.map((period) => (
                  <div
                    key={period.key}
                    className="rounded-lg border border-border bg-muted/10 p-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="font-medium">{period.label}</p>
                        <p className="text-xs text-muted-foreground">
                          Monthly due {formatMoney(period.monthlyFeeDue)} ·
                          Extra due {formatMoney(period.extraCategoryDue)} · Due{" "}
                          {formatMoney(period.dueAmount)}
                        </p>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {period.transactions.length} receipt
                        {period.transactions.length === 1 ? "" : "s"}
                      </p>
                    </div>
                    <div className="mt-3 space-y-2">
                      {period.transactions.map((item) => (
                        <div
                          key={item.id}
                          className="rounded-lg bg-background/70 p-3"
                        >
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div>
                              <p className="font-medium">
                                {item.feeCategory.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatMoney(item.amountPaid)} /{" "}
                                {formatMoney(item.totalAmount)} ·{" "}
                                {item.paymentMethod ?? "-"}
                              </p>
                              <p className="text-[11px] text-muted-foreground">
                                Txn {item.transactionId ?? "-"} · Due date{" "}
                                {item.dueDate
                                  ? new Date(item.dueDate).toLocaleDateString()
                                  : "-"}
                              </p>
                            </div>
                            <div className="text-right space-y-2">
                              <p className="text-xs font-semibold">
                                {item.status}
                              </p>
                              <button
                                type="button"
                                onClick={() =>
                                  void handleDownloadReceipt(item.id)
                                }
                                disabled={downloadingReceiptId === item.id}
                                className="rounded-full border px-3 py-1 text-xs font-semibold"
                              >
                                {downloadingReceiptId === item.id
                                  ? "Downloading..."
                                  : "Receipt"}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
