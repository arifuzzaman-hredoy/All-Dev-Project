"use client"

import { useEffect, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type NoticesPayload = {
  children: Array<{ id: string; name: string }>
  selectedStudentId: string | null
  notices: Array<{ id: string; title: string; content: string; createdAt: string; class: { name: string } | null }>
}

export default function Page() {
  const [data, setData] = useState<NoticesPayload | null>(null)
  const [selectedStudentId, setSelectedStudentId] = useState("")
  const [error, setError] = useState("")

  async function load(studentId?: string) {
    const params = new URLSearchParams()
    if (studentId) params.set("studentId", studentId)
    const payload = await fetchWithAuth<NoticesPayload>(`/api/v1/guardian/notices?${params.toString()}`)
    setData(payload)
    setSelectedStudentId(payload.selectedStudentId ?? "")
  }
  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<NoticesPayload>("/api/v1/guardian/notices")
        if (!active) return
        setData(payload)
        setSelectedStudentId(payload.selectedStudentId ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load notices")
      }
    }
    void bootstrap()
    return () => {
      active = false
    }
  }, [])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div><h1 className="text-xl font-semibold">Notices</h1><p className="text-sm text-muted-foreground">Announcements relevant to your children.</p></div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <div className="flex gap-2 flex-wrap">
        {data?.children.map((child) => <button key={child.id} onClick={() => void load(child.id).catch((e) => setError(e.message))} className={`rounded-full border px-3 py-1 text-xs ${selectedStudentId === child.id ? "bg-primary text-white" : "bg-muted"}`}>{child.name}</button>)}
      </div>
      <div className="space-y-2">
        {data?.notices.map((notice) => (
          <div key={notice.id} className="rounded-xl border p-3">
            <p className="font-medium">{notice.title}</p>
            <p className="text-sm text-muted-foreground">{notice.content}</p>
            <p className="text-xs text-muted-foreground">{new Date(notice.createdAt).toLocaleDateString()} {notice.class?.name ? `· ${notice.class.name}` : ""}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
