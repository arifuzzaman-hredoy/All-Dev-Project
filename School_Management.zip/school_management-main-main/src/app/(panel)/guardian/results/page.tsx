"use client"

import { useEffect, useState } from "react"
import { downloadWithAuth, fetchWithAuth } from "@/lib/client-api"

type ResultsPayload = {
  children: Array<{ id: string; name: string }>
  selectedStudentId: string | null
  results: Array<{ id: string; marks: number; totalMarks: number; grade: string | null; student: { user: { name: string } }; subject: { name: string }; exam: { name: string; date: string } }>
}

export default function Page() {
  const [data, setData] = useState<ResultsPayload | null>(null)
  const [selectedStudentId, setSelectedStudentId] = useState("")
  const [error, setError] = useState("")
  const [downloading, setDownloading] = useState(false)

  async function load(studentId?: string) {
    const params = new URLSearchParams()
    if (studentId) params.set("studentId", studentId)
    const payload = await fetchWithAuth<ResultsPayload>(`/api/v1/guardian/results?${params.toString()}`)
    setData(payload)
    setSelectedStudentId(payload.selectedStudentId ?? "")
  }
  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<ResultsPayload>("/api/v1/guardian/results")
        if (!active) return
        setData(payload)
        setSelectedStudentId(payload.selectedStudentId ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load results")
      }
    }
    void bootstrap()
    return () => {
      active = false
    }
  }, [])

  async function handleDownloadReportCard() {
    if (!selectedStudentId) return
    setError("")
    setDownloading(true)
    try {
      await downloadWithAuth(
        `/api/v1/guardian/results/export?studentId=${encodeURIComponent(selectedStudentId)}`,
        `report-card-${selectedStudentId}.html`
      )
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to download report card")
    } finally {
      setDownloading(false)
    }
  }

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Results</h1>
          <p className="text-sm text-muted-foreground">See academic performance by child.</p>
        </div>
        {selectedStudentId ? (
          <button
            type="button"
            onClick={() => void handleDownloadReportCard()}
            disabled={downloading}
            className="rounded-full border px-4 py-2 text-xs font-semibold"
          >
            {downloading ? "Downloading..." : "Download report card"}
          </button>
        ) : null}
      </div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <div className="flex gap-2 flex-wrap">
        {data?.children.map((child) => <button key={child.id} onClick={() => void load(child.id).catch((e) => setError(e.message))} className={`rounded-full border px-3 py-1 text-xs ${selectedStudentId === child.id ? "bg-primary text-white" : "bg-muted"}`}>{child.name}</button>)}
      </div>
      <div className="space-y-2">
        {data?.results.map((result) => (
          <div key={result.id} className="rounded-xl border p-3">
            <p className="font-medium">{result.student.user.name} · {result.subject.name}</p>
            <p className="text-sm text-muted-foreground">{result.exam.name} · {result.marks} out of {result.totalMarks} {result.grade ? `· ${result.grade}` : ""}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
