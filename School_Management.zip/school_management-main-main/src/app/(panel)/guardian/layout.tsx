"use client"

import type { ReactNode } from "react"
import { AppSidebar } from "@/components/app-sidebar-guardian"
import ModeToggle from "@/components/mode-toggle"
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"

type GuardianLayoutProps = {
  children: ReactNode
}

export default function GuardianLayout({ children }: GuardianLayoutProps) {
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex min-h-screen flex-1 flex-col">
        <header className="flex h-14 items-center justify-between border-b px-4">
          <div className="flex items-center gap-2">
            <SidebarTrigger />
            <h1 className="text-sm font-semibold">Guardian Panel</h1>
          </div>
          <ModeToggle />
        </header>
        <div className="flex flex-1 flex-col">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
