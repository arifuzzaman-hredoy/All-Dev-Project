"use client"

import { useEffect, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type AttendancePayload = {
  children: Array<{ id: string; name: string }>
  selectedStudentId: string | null
  records: Array<{ id: string; date: string; status: string; student: { user: { name: string } }; subject: { name: string } }>
  summary: {
    total: number
    present: number
    absent: number
    late: number
    attendanceRate: number
    bySubject: Array<{ subject: string; total: number; present: number; attendanceRate: number }>
    byMonth: Array<{ month: string; total: number; present: number; attendanceRate: number }>
  }
}

export default function Page() {
  const [data, setData] = useState<AttendancePayload | null>(null)
  const [selectedStudentId, setSelectedStudentId] = useState("")
  const [error, setError] = useState("")

  async function load(studentId?: string) {
    const params = new URLSearchParams()
    if (studentId) params.set("studentId", studentId)
    const payload = await fetchWithAuth<AttendancePayload>(`/api/v1/guardian/attendance?${params.toString()}`)
    setData(payload)
    setSelectedStudentId(payload.selectedStudentId ?? "")
  }

  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<AttendancePayload>("/api/v1/guardian/attendance")
        if (!active) return
        setData(payload)
        setSelectedStudentId(payload.selectedStudentId ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load attendance")
      }
    }
    void bootstrap()
    return () => {
      active = false
    }
  }, [])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div><h1 className="text-xl font-semibold">Attendance</h1><p className="text-sm text-muted-foreground">Monitor child attendance records.</p></div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <div className="flex gap-2 flex-wrap">
        {data?.children.map((child) => (
          <button key={child.id} onClick={() => void load(child.id).catch((e) => setError(e.message))} className={`rounded-full border px-3 py-1 text-xs ${selectedStudentId === child.id ? "bg-primary text-white" : "bg-muted"}`}>{child.name}</button>
        ))}
      </div>
      {data?.summary ? (
        <div className="grid gap-3 md:grid-cols-4">
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Attendance rate</p>
            <p className="text-2xl font-semibold">{data.summary.attendanceRate}%</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Present</p>
            <p className="text-2xl font-semibold text-green-600">{data.summary.present}</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Absent</p>
            <p className="text-2xl font-semibold text-red-600">{data.summary.absent}</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Late</p>
            <p className="text-2xl font-semibold text-amber-600">{data.summary.late}</p>
          </div>
        </div>
      ) : null}
      {data?.summary.bySubject.length ? (
        <div className="rounded-xl border p-4">
          <h2 className="mb-3 text-sm font-semibold">Subject-wise chart</h2>
          <div className="space-y-3">
            {data.summary.bySubject.map((item) => (
              <div key={item.subject} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>{item.subject}</span>
                  <span>{item.attendanceRate}% · {item.present}/{item.total}</span>
                </div>
                <div className="h-2 rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-green-500" style={{ width: `${item.attendanceRate}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}
      <div className="space-y-2">
        {data?.records.map((record) => (
          <div key={record.id} className="rounded-xl border p-3">
            <p className="font-medium">{record.student.user.name} · {record.subject.name}</p>
            <p className="text-sm text-muted-foreground">{new Date(record.date).toLocaleDateString()} · {record.status}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
