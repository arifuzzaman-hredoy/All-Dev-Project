"use client"

import { useEffect, useState } from "react"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type TeacherNotice = {
  id: string
  title: string
  content: string
  audience: string
  createdAt: string
  class: { name: string } | null
}

export default function Page() {
  const [notices, setNotices] = useState<TeacherNotice[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ notices: TeacherNotice[] }>("/api/v1/teacher/notices")
        if (!active) return
        setNotices(payload.notices)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load notices")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Notices</p>
          <h1 className="text-2xl font-semibold text-foreground">Announcements</h1>
        </div>
      }
    >
      {loading ? <p className="text-sm text-muted-foreground">Loading notices...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <TeacherSectionCard title="Notice board">
        <div className="space-y-3">
          {notices.length ? (
            notices.map((notice) => (
              <details key={notice.id} className="rounded-2xl border border-border bg-background p-4">
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-foreground">
                  <span>{notice.title}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(notice.createdAt).toLocaleDateString()}
                  </span>
                </summary>
                <div className="pt-2 text-xs text-muted-foreground">
                  <p>{notice.content}</p>
                  <p className="pt-1">Audience: {notice.audience}</p>
                  {notice.class?.name ? <p className="pt-1">Class: {notice.class.name}</p> : null}
                </div>
              </details>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">No notices available.</p>
          )}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
