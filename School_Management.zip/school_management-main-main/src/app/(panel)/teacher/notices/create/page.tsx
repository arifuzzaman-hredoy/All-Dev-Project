"use client"

import { useState } from "react"

import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"

const audienceOptions = ["All", "Class 10", "Science stream", "Staff"]

export default function Page() {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [audience, setAudience] = useState(audienceOptions[0])

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Notices</p>
          <h1 className="text-2xl font-semibold text-foreground">Create notice</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Draft notice">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="notice-title">
              Title
            </label>
            <Input
              id="notice-title"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Enter a short, descriptive title"
            />
            <p className="text-[10px] text-muted-foreground">Keep it concise for quick scanning.</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="notice-content">
              Content
            </label>
            <Textarea
              id="notice-content"
              value={content}
              onChange={(event) => setContent(event.target.value)}
              className="min-h-[120px]"
              placeholder="Add the message and any attachments or links here..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="notice-audience">
              Audience
            </label>
            <Select value={audience} onValueChange={(value) => setAudience(value)}>
              <SelectTrigger id="notice-audience">
                <SelectValue placeholder="Choose audience" />
              </SelectTrigger>
              <SelectContent>
                {audienceOptions.map((audienceOption) => (
                  <SelectItem key={audienceOption} value={audienceOption}>
                    {audienceOption}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground">Select the primary recipients.</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 pt-2">
          <button
            type="button"
            className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition hover:shadow-sm active:bg-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1"
          >
            Publish notice
          </button>
          <button
            type="button"
            className="inline-flex items-center justify-center rounded-full border border-border px-5 py-2 text-sm font-semibold text-foreground transition hover:shadow-sm"
          >
            Cancel
          </button>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
