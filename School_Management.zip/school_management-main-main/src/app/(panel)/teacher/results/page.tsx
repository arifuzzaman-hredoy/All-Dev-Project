import Link from "next/link"

import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"

const actions = [
  {
    label: "Create result",
    description: "Record marks for a recent exam",
    href: "/teacher/results/create",
    primary: true,
  },
  {
    label: "View results",
    description: "Review existing entries and rankings",
    href: "/teacher/results/view",
  },
]

export default function Page() {
  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Results</p>
          <h1 className="text-2xl font-semibold text-foreground">Manage assessments</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Entry points" description="Pick the workflow">
        <div className="flex flex-wrap gap-3">
          {actions.map((action) => (
            <Link
              key={action.label}
              href={action.href}
              className={`inline-flex w-full max-w-[220px] flex-col gap-1 rounded-2xl border border-border bg-background p-4 text-sm font-semibold text-foreground transition hover:shadow-sm ${action.primary
                  ? "border-primary shadow-sm"
                  : ""
                }`}
            >
              <p>{action.label}</p>
              <span className="text-xs font-normal text-muted-foreground">{action.description}</span>
            </Link>
          ))}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
