"use client"

import { useEffect, useMemo, useState } from "react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type ResultsViewData = {
  assignments: Array<{
    classId: string
    className: string
    subjectId: string
    subjectName: string
  }>
  selected: {
    classId: string | null
    subjectId: string | null
    examId: string | null
  }
  exams: Array<{
    id: string
    name: string
    date: string
    classId: string
  }>
  results: Array<{
    id: string
    marks: number
    totalMarks: number
    grade: string | null
    student: {
      user: { name: string }
      class: { name: string }
    }
    subject: { name: string }
    exam: { id: string; name: string; date: string }
  }>
  stats: {
    total: number
    averageMarks: number
  }
}

export default function Page() {
  const [data, setData] = useState<ResultsViewData | null>(null)
  const [classFilter, setClassFilter] = useState("")
  const [subjectFilter, setSubjectFilter] = useState("")
  const [examFilter, setExamFilter] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  async function load(classId?: string, subjectId?: string, examId?: string) {
    const params = new URLSearchParams()
    if (classId) params.set("classId", classId)
    if (subjectId) params.set("subjectId", subjectId)
    if (examId) params.set("examId", examId)
    const payload = await fetchWithAuth<ResultsViewData>(`/api/v1/teacher/results?${params.toString()}`)
    setData(payload)
    setClassFilter(payload.selected.classId ?? "")
    setSubjectFilter(payload.selected.subjectId ?? "")
    setExamFilter(payload.selected.examId ?? "")
  }

  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<ResultsViewData>("/api/v1/teacher/results")
        if (!active) return
        setData(payload)
        setClassFilter(payload.selected.classId ?? "")
        setSubjectFilter(payload.selected.subjectId ?? "")
        setExamFilter(payload.selected.examId ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load results records")
      } finally {
        if (active) setLoading(false)
      }
    }
    void bootstrap()
    return () => { active = false }
  }, [])

  const classOptions = useMemo(
    () => Array.from(new Map((data?.assignments ?? []).map((item) => [item.classId, item.className])).entries()),
    [data]
  )
  const subjectOptions = useMemo(
    () => (data?.assignments ?? []).filter((item) => item.classId === classFilter),
    [data, classFilter]
  )
  const examOptions = useMemo(
    () => (data?.exams ?? []).filter((exam) => exam.classId === classFilter),
    [data, classFilter]
  )

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Results</p>
          <h1 className="text-2xl font-semibold text-foreground">View records</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Filters">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-filter-class">Class</label>
            <Select value={classFilter} onValueChange={(value) => void load(value, undefined, undefined)}>
              <SelectTrigger id="results-filter-class"><SelectValue placeholder="Class" /></SelectTrigger>
              <SelectContent>
                {classOptions.map(([id, name]) => <SelectItem key={id} value={id}>{name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-filter-subject">Subject</label>
            <Select value={subjectFilter} onValueChange={(value) => void load(classFilter, value, undefined)}>
              <SelectTrigger id="results-filter-subject"><SelectValue placeholder="Subject" /></SelectTrigger>
              <SelectContent>
                {subjectOptions.map((subject) => <SelectItem key={subject.subjectId} value={subject.subjectId}>{subject.subjectName}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-filter-exam">Exam</label>
            <Select value={examFilter} onValueChange={(value) => void load(classFilter, subjectFilter, value)}>
              <SelectTrigger id="results-filter-exam"><SelectValue placeholder="Exam" /></SelectTrigger>
              <SelectContent>
                {examOptions.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>
                    {exam.name} · {new Date(exam.date).toLocaleDateString()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading results...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {data ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-border bg-background p-4">
            <p className="text-xs text-muted-foreground">Result rows</p>
            <p className="text-2xl font-semibold text-foreground">{data.stats.total}</p>
          </div>
          <div className="rounded-2xl border border-border bg-background p-4">
            <p className="text-xs text-muted-foreground">Average marks</p>
            <p className="text-2xl font-semibold text-foreground">{data.stats.averageMarks}</p>
          </div>
        </div>
      ) : null}

      <TeacherSectionCard title="Results table">
        <div className="overflow-x-auto rounded-2xl border border-border">
          <table className="w-full table-fixed text-sm">
            <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-2">Name</th>
                <th className="px-4 py-2">Class</th>
                <th className="px-4 py-2">Subject</th>
                <th className="px-4 py-2">Exam</th>
                <th className="px-4 py-2">Marks</th>
                <th className="px-4 py-2">Grade</th>
              </tr>
            </thead>
            <tbody>
              {data?.results.length ? data.results.map((entry) => (
                <tr key={entry.id} className="border-b border-border last:border-b-0">
                  <td className="px-4 py-3 text-foreground">{entry.student.user.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{entry.student.class.name}</td>
                  <td className="px-4 py-3 text-foreground">{entry.subject.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{entry.exam.name}</td>
                  <td className="px-4 py-3 text-foreground">{entry.marks} out of {entry.totalMarks}</td>
                  <td className="px-4 py-3 text-foreground">{entry.grade ?? "-"}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-sm text-muted-foreground">
                    No results found for the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
