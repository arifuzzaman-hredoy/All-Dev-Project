"use client"

import { useEffect, useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type ResultsWorkspace = {
  assignments: Array<{
    classId: string
    className: string
    subjectId: string
    subjectName: string
  }>
  selected: {
    classId: string | null
    subjectId: string | null
    examId: string | null
    totalMarks: number
  }
  students: Array<{
    id: string
    name: string
    roll: number
    className: string
  }>
  exams: Array<{
    id: string
    name: string
    date: string
    classId: string
    class: { name: string }
    assignedClasses: Array<{ classId: string }>
    totalMarks: number
  }>
  results: Array<{
    studentId: string
    marks: number
    totalMarks: number
    grade: string | null
  }>
}

const gradeFromScore = (score: number, totalMarks: number) => {
  const percentage = totalMarks > 0 ? (score / totalMarks) * 100 : score
  if (percentage >= 90) return "A"
  if (percentage >= 80) return "A-"
  if (percentage >= 70) return "B+"
  if (percentage >= 60) return "B"
  if (percentage >= 50) return "C"
  return "D"
}

export default function Page() {
  const [workspace, setWorkspace] = useState<ResultsWorkspace | null>(null)
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [selectedExam, setSelectedExam] = useState("")
  const [marks, setMarks] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [message, setMessage] = useState("")

  async function load(classId?: string, subjectId?: string, examId?: string) {
    const params = new URLSearchParams()
    if (classId) params.set("classId", classId)
    if (subjectId) params.set("subjectId", subjectId)
    if (examId) params.set("examId", examId)
    const payload = await fetchWithAuth<ResultsWorkspace>(`/api/v1/teacher/results?${params.toString()}`)
    setWorkspace(payload)
    setSelectedClass(payload.selected.classId ?? "")
    setSelectedSubject(payload.selected.subjectId ?? "")
    setSelectedExam(payload.selected.examId ?? "")
    const existing = payload.results.reduce<Record<string, number>>((acc, result) => {
      acc[result.studentId] = result.marks
      return acc
    }, {})
    setMarks(
      payload.students.reduce<Record<string, number>>((acc, student) => {
        acc[student.id] = existing[student.id] ?? 0
        return acc
      }, {})
    )
  }

  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<ResultsWorkspace>("/api/v1/teacher/results")
        if (!active) return
        setWorkspace(payload)
        setSelectedClass(payload.selected.classId ?? "")
        setSelectedSubject(payload.selected.subjectId ?? "")
        setSelectedExam(payload.selected.examId ?? "")
        const existing = payload.results.reduce<Record<string, number>>((acc, result) => {
          acc[result.studentId] = result.marks
          return acc
        }, {})
        setMarks(
          payload.students.reduce<Record<string, number>>((acc, student) => {
            acc[student.id] = existing[student.id] ?? 0
            return acc
          }, {})
        )
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load results workspace")
      } finally {
        if (active) setLoading(false)
      }
    }
    void bootstrap()
    return () => { active = false }
  }, [])

  const classOptions = useMemo(
    () => Array.from(new Map((workspace?.assignments ?? []).map((item) => [item.classId, item.className])).entries()),
    [workspace]
  )
  const subjectOptions = useMemo(
    () => (workspace?.assignments ?? []).filter((item) => item.classId === selectedClass),
    [workspace, selectedClass]
  )
  const examOptions = useMemo(
    () =>
      (workspace?.exams ?? []).filter(
        (exam) =>
          exam.classId === selectedClass ||
          exam.assignedClasses.some((item) => item.classId === selectedClass)
      ),
    [workspace, selectedClass]
  )
  const selectedTotalMarks = useMemo(
    () =>
      examOptions.find((exam) => exam.id === selectedExam)?.totalMarks ??
      workspace?.selected.totalMarks ??
      100,
    [examOptions, selectedExam, workspace]
  )

  const handleSave = async () => {
    if (!selectedClass || !selectedSubject || !selectedExam || !workspace?.students.length) {
      setError("Choose a valid class, subject, and exam")
      return
    }

    setSaving(true)
    setError("")
    setMessage("")
    try {
      const payload = await fetchWithAuth<{ summary: { total: number; averageMarks: number } }>("/api/v1/teacher/results", {
        method: "POST",
        body: JSON.stringify({
          classId: selectedClass,
          subjectId: selectedSubject,
          examId: selectedExam,
          entries: workspace.students.map((student) => ({
            studentId: student.id,
            marks: marks[student.id] ?? 0,
            grade: gradeFromScore(marks[student.id] ?? 0, selectedTotalMarks),
          })),
        }),
      })
      setMessage(`Saved ${payload.summary.total} result rows. Average ${payload.summary.averageMarks}`)
      await load(selectedClass, selectedSubject, selectedExam)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to save results")
    } finally {
      setSaving(false)
    }
  }

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Results</p>
          <h1 className="text-2xl font-semibold text-foreground">Create result</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Session settings">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-class">Class</label>
            <Select value={selectedClass} onValueChange={(value) => void load(value, undefined, undefined)}>
              <SelectTrigger id="results-class"><SelectValue placeholder="Class" /></SelectTrigger>
              <SelectContent>
                {classOptions.map(([id, name]) => <SelectItem key={id} value={id}>{name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-subject">Subject</label>
            <Select value={selectedSubject} onValueChange={(value) => void load(selectedClass, value, undefined)}>
              <SelectTrigger id="results-subject"><SelectValue placeholder="Subject" /></SelectTrigger>
              <SelectContent>
                {subjectOptions.map((subject) => <SelectItem key={subject.subjectId} value={subject.subjectId}>{subject.subjectName}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="results-exam">Exam</label>
            <Select value={selectedExam} onValueChange={(value) => setSelectedExam(value)}>
              <SelectTrigger id="results-exam"><SelectValue placeholder="Exam" /></SelectTrigger>
              <SelectContent>
                {examOptions.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>
                    {exam.name} · {new Date(exam.date).toLocaleDateString()} · out of {exam.totalMarks}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading results workspace...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {message ? <p className="text-sm text-emerald-600">{message}</p> : null}

      <TeacherSectionCard title="Student marks">
        <div className="space-y-3">
          {workspace?.students.length ? workspace.students.map((student) => (
            <div key={student.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-background p-4">
              <div>
                <p className="text-sm font-semibold text-foreground">{student.name}</p>
                <p className="text-xs text-muted-foreground">Roll {student.roll}</p>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs">
                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-muted-foreground" htmlFor={`marks-${student.id}`}>Marks out of {selectedTotalMarks}</label>
                  <Input
                    id={`marks-${student.id}`}
                    type="number"
                    min={0}
                    max={selectedTotalMarks}
                    value={marks[student.id] ?? 0}
                    onChange={(event) => {
                      const value = Number(event.target.value)
                      setMarks((prev) => ({ ...prev, [student.id]: Number.isNaN(value) ? 0 : value }))
                    }}
                    className="w-24"
                  />
                </div>
                <div className="space-y-1 text-right">
                  <p className="text-[10px] font-semibold text-muted-foreground">Grade</p>
                  <p className="text-sm font-semibold text-foreground">{gradeFromScore(marks[student.id] ?? 0, selectedTotalMarks)}</p>
                </div>
              </div>
            </div>
          )) : <p className="text-sm text-muted-foreground">No students found for this class.</p>}
        </div>
        <div className="flex justify-end">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || loading}
            className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground transition hover:shadow-sm disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save results"}
          </button>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
