"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { clearAuth, persistAuth, readAuth } from "@/utils/auth-storage"
import { fetchWithAuth } from "@/lib/client-api"

const themePresets = {
  system: {
    background: "#f8fafc",
    foreground: "#0f172a",
    primary: "#2563eb",
    secondary: "#64748b",
    accent: "#f59e0b",
    destructive: "#dc2626",
    muted: "#e2e8f0",
    border: "#cbd5e1",
    input: "#e5e7eb",
    ring: "#2563eb",
    card: "#ffffff",
    popover: "#ffffff",
    sidebar: "#ffffff",
    "sidebar-foreground": "#0f172a",
    "sidebar-border": "#e5e7eb",
  },
  light: {
    background: "#fffaf0",
    foreground: "#1f2937",
    primary: "#ea580c",
    secondary: "#fb923c",
    accent: "#facc15",
    destructive: "#dc2626",
    muted: "#fed7aa",
    border: "#fdba74",
    input: "#ffedd5",
    ring: "#ea580c",
    card: "#ffffff",
    popover: "#ffffff",
    sidebar: "#fff7ed",
    "sidebar-foreground": "#1f2937",
    "sidebar-border": "#fdba74",
  },
  dark: {
    background: "#0f172a",
    foreground: "#e2e8f0",
    primary: "#38bdf8",
    secondary: "#475569",
    accent: "#22c55e",
    destructive: "#ef4444",
    muted: "#1e293b",
    border: "#334155",
    input: "#1e293b",
    ring: "#38bdf8",
    card: "#111827",
    popover: "#111827",
    sidebar: "#111827",
    "sidebar-foreground": "#e2e8f0",
    "sidebar-border": "#334155",
  },
} as const

type TeacherSettingsData = {
  profile: {
    name: string
    email: string
    phone: string | null
    address: string | null
  }
}

export default function Page() {
  const router = useRouter()
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [theme, setTheme] = useState<keyof typeof themePresets>("system")
  const [loading, setLoading] = useState(true)
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)
  const [savingTheme, setSavingTheme] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true
    async function load() {
      try {
        const payload = await fetchWithAuth<TeacherSettingsData>("/api/v1/teacher/settings")
        if (!active) return
        setFullName(payload.profile.name)
        setEmail(payload.profile.email)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load settings")
      } finally {
        if (active) setLoading(false)
      }
    }
    void load()
    return () => { active = false }
  }, [])

  const cycleTheme = async () => {
    const order = Object.keys(themePresets) as Array<keyof typeof themePresets>
    const nextTheme = order[(order.indexOf(theme) + 1) % order.length]
    setTheme(nextTheme)
    setSavingTheme(true)
    setMessage("")
    setError("")
    try {
      await fetchWithAuth<{ theme: Record<string, string> }>("/api/v1/theme/user", {
        method: "PATCH",
        body: JSON.stringify(themePresets[nextTheme]),
      })
      setMessage(`Theme preset updated to ${nextTheme}`)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update theme")
    } finally {
      setSavingTheme(false)
    }
  }

  const saveProfile = async () => {
    setSavingProfile(true)
    setMessage("")
    setError("")
    try {
      const payload = await fetchWithAuth<{ user: { id: string; name: string; email: string } }>("/api/v1/teacher/settings", {
        method: "PATCH",
        body: JSON.stringify({ name: fullName, email }),
      })
      const auth = readAuth()
      if (auth) {
        persistAuth({
          ...auth,
          user: {
            ...auth.user,
            name: payload.user.name,
            email: payload.user.email,
          },
        })
      }
      setMessage("Profile updated successfully")
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update profile")
    } finally {
      setSavingProfile(false)
    }
  }

  const savePassword = async () => {
    setSavingPassword(true)
    setMessage("")
    setError("")
    try {
      const payload = await fetchWithAuth<{ message: string }>("/api/v1/teacher/settings/password", {
        method: "PATCH",
        body: JSON.stringify({
          currentPassword,
          newPassword,
          confirmPassword,
        }),
      })
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setMessage(payload.message)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to update password")
    } finally {
      setSavingPassword(false)
    }
  }

  const handleLogout = () => {
    clearAuth()
    void fetch("/api/v1/auth/logout", { method: "POST" })
    router.push("/login")
  }

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Settings</p>
          <h1 className="text-2xl font-semibold text-foreground">Account & preferences</h1>
        </div>
      }
    >
      {loading ? <p className="text-sm text-muted-foreground">Loading settings...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {message ? <p className="text-sm text-emerald-600">{message}</p> : null}

      <TeacherSectionCard title="Profile">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="settings-name">Full name</label>
            <Input id="settings-name" value={fullName} onChange={(event) => setFullName(event.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="settings-email">Email</label>
            <Input id="settings-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="button"
            onClick={saveProfile}
            disabled={savingProfile || loading}
            className="inline-flex items-center justify-center rounded-full border border-border px-5 py-2 text-sm font-semibold text-foreground transition hover:shadow-sm disabled:opacity-60"
          >
            {savingProfile ? "Saving..." : "Save profile"}
          </button>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Change password">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="settings-current-password">Current password</label>
            <Input id="settings-current-password" type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="settings-new-password">New password</label>
            <Input id="settings-new-password" type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="settings-confirm-password">Confirm password</label>
            <Input id="settings-confirm-password" type="password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} />
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="button"
            onClick={savePassword}
            disabled={savingPassword || loading}
            className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition hover:shadow-sm disabled:opacity-60"
          >
            {savingPassword ? "Saving..." : "Save password"}
          </button>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Theme">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-foreground">Current preset</p>
            <p className="text-xs text-muted-foreground">{theme}</p>
          </div>
          <button
            type="button"
            onClick={() => void cycleTheme()}
            disabled={savingTheme}
            className="inline-flex items-center justify-center rounded-full border border-border px-4 py-2 text-xs font-semibold text-foreground transition hover:shadow-sm disabled:opacity-60"
          >
            {savingTheme ? "Updating..." : "Cycle theme"}
          </button>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Security">
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center justify-center rounded-full border border-border px-5 py-2 text-sm font-semibold text-foreground transition hover:shadow-sm"
          >
            Logout
          </button>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
