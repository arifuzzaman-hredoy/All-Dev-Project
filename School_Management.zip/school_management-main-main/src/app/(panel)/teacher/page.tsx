"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { TeacherPageShell } from "@/components/teacher/page-shell";
import { TeacherSectionCard } from "@/components/teacher/section-card";
import { cn } from "@/lib/utils";
import { fetchWithAuth } from "@/lib/client-api";

type TeacherDashboardData = {
  dashboard: {
    teacher: {
      name: string;
      assignedSubjects: Array<{
        id: string;
        className: string;
        subjectName: string;
      }>;
    };
    stats: {
      totalStudents: number;
      todaysClasses: number;
      trackedResults: number;
      attendanceMarked: number;
      assignedExams: number;
    };
    assignedExams: Array<{
      id: string;
      name: string;
      code: string;
      date: string;
      status: string;
      className: string;
      examType: string | null;
    }>;
    todaySchedule: Array<{
      id: string;
      startTime: string;
      endTime: string;
      class: { name: string };
      subject: { name: string };
    }>;
    notices: Array<{
      id: string;
      title: string;
      content: string;
      createdAt: string;
      class: { name: string } | null;
    }>;
  };
};

const quickActions = [
  {
    label: "Take Attendance",
    href: "/teacher/attendance/take",
    variant: "primary",
  },
  {
    label: "Add Results",
    href: "/teacher/results/create",
    variant: "secondary",
  },
  { label: "View Students", href: "/teacher/students", variant: "secondary" },
  { label: "Timetable", href: "/teacher/timetable", variant: "secondary" },
];

const actionButtonBase =
  "inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1";

const actionButtonStyles = {
  primary:
    "bg-primary text-primary-foreground hover:shadow-sm active:bg-primary/80 focus-visible:ring-primary/70",
  secondary:
    "border border-border text-foreground hover:shadow-sm active:border-primary active:text-primary-foreground focus-visible:ring-primary/70",
};

export default function Page() {
  const [data, setData] = useState<TeacherDashboardData["dashboard"] | null>(
    null,
  );
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const payload = await fetchWithAuth<TeacherDashboardData>(
          "/api/v1/teacher/dashboard",
        );
        if (!active) return;
        setData(payload.dashboard);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load dashboard",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void load();

    return () => {
      active = false;
    };
  }, []);

  const stats = data
    ? [
        {
          label: "Total students",
          value: String(data.stats.totalStudents),
          caption: "Assigned to your classes",
        },
        {
          label: "Today’s classes",
          value: String(data.stats.todaysClasses),
          caption: "Scheduled in your routine",
        },
        {
          label: "Tracked results",
          value: String(data.stats.trackedResults),
          caption: "Recent marked assessments",
        },
        {
          label: "Attendance logs",
          value: String(data.stats.attendanceMarked),
          caption: "Latest attendance entries",
        },
        {
          label: "Assigned exams",
          value: String(data.stats.assignedExams),
          caption: "Visible or mapped exams",
        },
      ]
    : [];

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">
            Teacher panel
          </p>
          <h1 className="text-2xl font-semibold text-foreground">
            {data ? `${data.teacher.name}'s dashboard` : "Dashboard"}
          </h1>
        </div>
      }
    >
      {loading ? (
        <p className="text-sm text-muted-foreground">
          Loading teacher dashboard...
        </p>
      ) : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {data ? (
        <>
          <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-2xl border border-border bg-background p-4 shadow-sm transition-shadow hover:shadow"
              >
                <p className="text-xs leading-tight text-muted-foreground">
                  {stat.label}
                </p>
                <p className="text-2xl font-semibold text-foreground">
                  {stat.value}
                </p>
                <p className="text-xs text-muted-foreground">{stat.caption}</p>
              </div>
            ))}
          </section>

          <TeacherSectionCard
            title="Assigned subjects"
            description="Your active classroom responsibilities"
          >
            <div className="flex flex-wrap gap-2">
              {data.teacher.assignedSubjects.map((item) => (
                <span
                  key={item.id}
                  className="rounded-full border border-border px-3 py-1 text-xs"
                >
                  {item.subjectName} · {item.className}
                </span>
              ))}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard
            title="Today’s classes"
            description="Quick glance at the current schedule"
          >
            <div className="space-y-3">
              {data.todaySchedule.length ? (
                data.todaySchedule.map((session) => (
                  <article
                    key={session.id}
                    className="flex items-center justify-between rounded-xl border border-border bg-background px-3 py-2"
                  >
                    <div className="space-y-0.5">
                      <p className="text-sm font-semibold text-foreground">
                        {session.subject.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {session.class.name}
                      </p>
                    </div>
                    <p className="text-xs font-medium text-muted-foreground">
                      {session.startTime} - {session.endTime}
                    </p>
                  </article>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">
                  No classes scheduled today.
                </p>
              )}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard
            title="Quick actions"
            description="Jump into the most frequent workflows"
          >
            <div className="flex flex-wrap gap-3">
              {quickActions.map((action) => (
                <Link
                  key={action.label}
                  href={action.href}
                  className={cn(
                    actionButtonBase,
                    actionButtonStyles[
                      action.variant as keyof typeof actionButtonStyles
                    ],
                  )}
                >
                  {action.label}
                </Link>
              ))}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard
            title="Assigned exams"
            description="Exams visible to you or assigned to your classes and subjects"
          >
            <div className="space-y-3">
              {data.assignedExams.length ? (
                data.assignedExams.map((exam) => (
                  <article
                    key={exam.id}
                    className="rounded-xl border border-border bg-background p-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <h2 className="text-sm font-semibold text-foreground">
                          {exam.name}
                        </h2>
                        <p className="text-xs text-muted-foreground">
                          {exam.code} · {exam.className}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(exam.date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="pt-1 text-xs text-muted-foreground">
                      {exam.status.replaceAll("_", " ")}
                      {exam.examType ? ` · ${exam.examType}` : ""}
                    </p>
                  </article>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">
                  No assigned exams yet.
                </p>
              )}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard
            title="Notices"
            description="Recent updates relevant to your classes"
          >
            <div className="space-y-3">
              {data.notices.map((notice) => (
                <article
                  key={notice.id}
                  className="rounded-xl border border-border bg-background p-3"
                >
                  <div className="flex items-center justify-between gap-3">
                    <h2 className="text-sm font-semibold text-foreground">
                      {notice.title}
                    </h2>
                    <span className="text-xs text-muted-foreground">
                      {new Date(notice.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {notice.content}
                  </p>
                  {notice.class?.name ? (
                    <p className="pt-1 text-[11px] text-muted-foreground">
                      Class: {notice.class.name}
                    </p>
                  ) : null}
                </article>
              ))}
            </div>
          </TeacherSectionCard>
        </>
      ) : null}
    </TeacherPageShell>
  );
}
