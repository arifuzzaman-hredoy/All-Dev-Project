import Link from "next/link"
import { notFound } from "next/navigation"

import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { STUDENTS, isStudentSubjectAllowed } from "../../../students/data"

type AttendanceViewParams = {
  id: string | string[]
}

type AttendanceViewProps = {
  params: Promise<AttendanceViewParams>
}

const calendarEntries = [
  { label: "Mon 16", status: "Present" },
  { label: "Tue 17", status: "Present" },
  { label: "Wed 18", status: "Absent" },
  { label: "Thu 19", status: "Present" },
  { label: "Fri 20", status: "Present" },
  { label: "Mon 23", status: "Late" },
  { label: "Tue 24", status: "Present" },
  { label: "Wed 25", status: "Present" },
]

const statusPill = (status: string) => {
  const base = "inline-flex items-center justify-center rounded-full px-2 py-1 text-[10px] font-semibold"
  if (status === "Present") {
    return `${base} bg-primary text-primary-foreground`
  }
  if (status === "Absent") {
    return `${base} border border-border text-muted-foreground`
  }
  return `${base} border border-border text-muted-foreground`
}

export default async function Page({ params }: AttendanceViewProps) {
  const resolved = await params
  const studentId = Array.isArray(resolved.id) ? resolved.id[0] : resolved.id
  const student = STUDENTS.find((record) => record.id === studentId)

  if (!student || !isStudentSubjectAllowed(student)) {
    notFound()
  }

  const present = calendarEntries.filter((entry) => entry.status === "Present").length
  const absent = calendarEntries.filter((entry) => entry.status === "Absent").length
  const late = calendarEntries.filter((entry) => entry.status === "Late").length

  const quickActions = [
    { label: "Edit attendance", href: "/teacher/attendance/take" },
    { label: "View results", href: "/teacher/results/view" },
  ]

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Attendance</p>
          <h1 className="text-2xl font-semibold text-foreground">{student.name}</h1>
          <p className="text-xs text-muted-foreground">
            Roll {student.roll} · {student.className} · {student.group} · {student.subject}
          </p>
          <div className="flex flex-wrap gap-2">
            <Link href="/teacher/attendance/view" className="text-xs font-semibold text-primary">
              ← All students
            </Link>
            <Link href="/teacher/students" className="text-xs font-semibold text-primary">
              ← Students list
            </Link>
          </div>
        </div>
      }
    >
      <TeacherSectionCard title="Attendance summary">
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <p className="text-xs text-muted-foreground">Present</p>
            <p className="text-2xl font-semibold text-foreground">{present}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Absent</p>
            <p className="text-2xl font-semibold text-foreground">{absent}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Late</p>
            <p className="text-2xl font-semibold text-foreground">{late}</p>
          </div>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Calendar">
        <div className="grid gap-3 sm:grid-cols-4">
          {calendarEntries.map((entry) => (
            <article
              key={entry.label}
              className="flex flex-col gap-1 rounded-2xl border border-border bg-background p-3"
            >
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{entry.label}</p>
              <span className="text-sm font-semibold text-foreground">{entry.label.split(" ")[1]}</span>
              <span className={statusPill(entry.status)}>{entry.status}</span>
            </article>
          ))}
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Quick actions">
        <div className="flex flex-wrap gap-3">
          {quickActions.map((action) => (
            <Link
              key={action.label}
              href={action.href}
              className="inline-flex items-center justify-center rounded-full border border-border px-4 py-2 text-xs font-semibold text-foreground transition hover:shadow-sm active:border-primary active:text-primary-foreground"
            >
              {action.label}
            </Link>
          ))}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
