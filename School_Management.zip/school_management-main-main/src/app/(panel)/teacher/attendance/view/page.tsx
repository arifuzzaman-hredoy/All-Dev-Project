"use client"

import { useEffect, useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type AttendanceViewData = {
  classes: Array<{
    id: string
    name: string
  }>
  assignments: Array<{
    classId: string
    className: string
    subjectId: string
    subjectName: string
  }>
  selected: {
    classId: string | null
    subjectId: string | null
    date: string
  }
  records: Array<{
    id: string
    date: string
    status: "PRESENT" | "ABSENT" | "LATE"
    period: number | null
    studentId: string
    student: {
      user: { name: string }
      rollNumber: number | null
      class: { name: string }
    }
  }>
  stats: {
    present: number
    absent: number
    late: number
  }
}

const statusBadge = {
  PRESENT: "bg-primary/20 text-primary",
  ABSENT: "bg-background text-muted-foreground",
  LATE: "bg-amber-500/20 text-amber-700",
}

export default function Page() {
  const [data, setData] = useState<AttendanceViewData | null>(null)
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split("T")[0])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  async function load(classId?: string, subjectId?: string, date?: string) {
    const params = new URLSearchParams()
    if (classId) params.set("classId", classId)
    if (subjectId) params.set("subjectId", subjectId)
    if (date) params.set("date", date)
    const payload = await fetchWithAuth<AttendanceViewData>(`/api/v1/teacher/attendance?${params.toString()}`)
    setData(payload)
    setSelectedClass(payload.selected.classId ?? "")
    setSelectedSubject(payload.selected.subjectId ?? "")
    setSelectedDate(payload.selected.date)
  }

  useEffect(() => {
    let active = true
    async function bootstrap() {
      try {
        if (!active) return
        await load()
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load attendance records")
      } finally {
        if (active) setLoading(false)
      }
    }
    void bootstrap()
    return () => { active = false }
  }, [])

  const classOptions = useMemo(
    () => (data?.classes ?? []).map((item) => [item.id, item.name] as const),
    [data]
  )
  const subjectOptions = useMemo(
    () => (data?.assignments ?? []).filter((item) => item.classId === selectedClass),
    [data, selectedClass]
  )
  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase()
    return (data?.records ?? []).filter((record) => {
      if (!query) return true
      return (
        record.student.user.name.toLowerCase().includes(query) ||
        String(record.student.rollNumber ?? "").includes(query)
      )
    })
  }, [data, search])

  const handleDateChange = async (value: string) => {
    setSelectedDate(value)
    setError("")
    try {
      await load(selectedClass, selectedSubject, value)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to load attendance records")
    }
  }

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Attendance</p>
          <h1 className="text-2xl font-semibold text-foreground">Class view</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Filters" description="Adjust class, subject, and date">
        <div className="grid gap-3 md:grid-cols-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="filter-class">Class</label>
            <Select value={selectedClass} onValueChange={(value) => void load(value, undefined, selectedDate)}>
              <SelectTrigger id="filter-class"><SelectValue placeholder="Select class" /></SelectTrigger>
              <SelectContent>
                {classOptions.map(([id, name]) => <SelectItem key={id} value={id}>{name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="filter-subject">Subject</label>
            <Select value={selectedSubject} onValueChange={(value) => void load(selectedClass, value, selectedDate)}>
              <SelectTrigger id="filter-subject"><SelectValue placeholder="Select subject" /></SelectTrigger>
              <SelectContent>
                {subjectOptions.map((option) => <SelectItem key={option.subjectId} value={option.subjectId}>{option.subjectName}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="filter-date">Date</label>
            <Input
              id="filter-date"
              type="date"
              value={selectedDate}
              onChange={(event) => void handleDateChange(event.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="search-student">Search student</label>
            <Input id="search-student" placeholder="Name or roll" value={search} onChange={(event) => setSearch(event.target.value)} />
          </div>
        </div>
        <div className="pt-3">
          <button
            type="button"
            onClick={() => void load(selectedClass, selectedSubject, selectedDate)}
            className="rounded-full border border-border px-4 py-2 text-xs font-semibold"
          >
            Refresh records
          </button>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading attendance records...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        {data ? ([
          ["Present", data.stats.present],
          ["Absent", data.stats.absent],
          ["Late", data.stats.late],
        ] as const).map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-border bg-background p-4">
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-2xl font-semibold text-foreground">{value}</p>
          </div>
        )) : null}
      </div>

      <TeacherSectionCard title="Student table" description="Filtered attendance rows">
        <div className="overflow-x-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Roll</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-sm text-muted-foreground">
                    No attendance records match the current filter.
                  </td>
                </tr>
              ) : (
                filtered.map((record) => (
                  <tr key={record.id} className="border-b border-border last:border-b-0">
                    <td className="px-4 py-3">
                      <a href={`/teacher/students/${record.studentId}/attendance`} className="text-sm font-semibold text-foreground underline-offset-2 hover:underline">
                        {record.student.user.name}
                      </a>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{record.student.rollNumber ?? "-"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(record.date).toLocaleDateString()}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center rounded-full px-3 py-1 text-[11px] font-semibold tracking-wide ${statusBadge[record.status]} border border-border`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
