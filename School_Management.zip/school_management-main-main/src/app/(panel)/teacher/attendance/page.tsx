import Link from "next/link"

import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"

const actions = [
  {
    label: "Take Attendance",
    description: "Record the students for today",
    href: "/teacher/attendance/take",
    primary: true,
  },
  {
    label: "View Attendance",
    description: "Review previous sessions and calendar",
    href: "/teacher/attendance/view",
  },
]

export default function Page() {
  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Attendance</p>
          <h1 className="text-2xl font-semibold text-foreground">Session navigation</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Actions" description="Choose the flow you need">
        <div className="flex flex-wrap gap-3">
          {actions.map((action) => (
            <Link
              key={action.label}
              href={action.href}
              className={`inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 ${action.primary
                  ? "bg-primary text-primary-foreground hover:shadow-sm active:bg-primary/80"
                  : "border border-border text-foreground hover:shadow-sm"
                }`}
            >
              <div className="space-y-0.5">
                <p>{action.label}</p>
                <p className="text-xs text-muted-foreground">{action.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
