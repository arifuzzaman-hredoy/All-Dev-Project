"use client"

import { useEffect, useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

const statusOptions = ["PRESENT", "ABSENT", "LATE"] as const
type Status = (typeof statusOptions)[number]

type WorkspaceData = {
  classes: Array<{
    id: string
    name: string
  }>
  assignments: Array<{
    classId: string
    className: string
    subjectId: string
    subjectName: string
  }>
  selected: {
    classId: string | null
    subjectId: string | null
    date: string
  }
  students: Array<{
    id: string
    name: string
    roll: number
    className: string
  }>
  records: Array<{
    studentId: string
    status: Status
  }>
}

function buildAttendanceState(payload: WorkspaceData) {
  const recordMap = new Map(payload.records.map((record) => [record.studentId, record.status]))
  return payload.students.reduce<Record<string, Status>>((acc, student) => {
    acc[student.id] = recordMap.get(student.id) ?? "PRESENT"
    return acc
  }, {})
}

export default function Page() {
  const [workspace, setWorkspace] = useState<WorkspaceData | null>(null)
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [sessionDate, setSessionDate] = useState(() => new Date().toISOString().split("T")[0])
  const [attendance, setAttendance] = useState<Record<string, Status>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [message, setMessage] = useState("")

  async function loadWorkspace(nextClassId?: string, nextSubjectId?: string, nextDate?: string) {
    const params = new URLSearchParams()
    if (nextClassId) params.set("classId", nextClassId)
    if (nextSubjectId) params.set("subjectId", nextSubjectId)
    if (nextDate) params.set("date", nextDate)
    const payload = await fetchWithAuth<WorkspaceData>(`/api/v1/teacher/attendance?${params.toString()}`)
    setWorkspace(payload)
    setSelectedClass(payload.selected.classId ?? "")
    setSelectedSubject(payload.selected.subjectId ?? "")
    setSessionDate(payload.selected.date)
    setAttendance(buildAttendanceState(payload))
  }

  useEffect(() => {
    let active = true

    async function bootstrap() {
      try {
        const payload = await fetchWithAuth<WorkspaceData>("/api/v1/teacher/attendance")
        if (!active) return
        setWorkspace(payload)
        setSelectedClass(payload.selected.classId ?? "")
        setSelectedSubject(payload.selected.subjectId ?? "")
        setSessionDate(payload.selected.date)
        setAttendance(buildAttendanceState(payload))
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load attendance workspace")
      } finally {
        if (active) setLoading(false)
      }
    }

    void bootstrap()
    return () => {
      active = false
    }
  }, [])

  const classOptions = useMemo(
    () => (workspace?.classes ?? []).map((item) => [item.id, item.name] as const),
    [workspace]
  )

  const subjectOptions = useMemo(
    () =>
      (workspace?.assignments ?? [])
        .filter((item) => item.classId === selectedClass)
        .map((item) => ({ id: item.subjectId, name: item.subjectName })),
    [selectedClass, workspace]
  )

  const handleClassChange = async (value: string) => {
    setError("")
    setMessage("")
    try {
      await loadWorkspace(value, undefined, sessionDate)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to switch class")
    }
  }

  const handleSubjectChange = async (value: string) => {
    setError("")
    setMessage("")
    try {
      await loadWorkspace(selectedClass, value, sessionDate)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to switch subject")
    }
  }

  const handleStatusChange = (id: string, value: Status) => {
    setAttendance((prev) => ({ ...prev, [id]: value }))
  }

  const handleDateChange = async (value: string) => {
    setSessionDate(value)
    if (!selectedClass || !selectedSubject) return
    setError("")
    setMessage("")
    try {
      await loadWorkspace(selectedClass, selectedSubject, value)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to switch date")
    }
  }

  const handleSave = async () => {
    if (!selectedClass || !selectedSubject || !workspace?.students.length) {
      setError("Select a valid class and subject first")
      return
    }

    setSaving(true)
    setError("")
    setMessage("")

    try {
      const payload = await fetchWithAuth<{ summary: { total: number } }>("/api/v1/teacher/attendance", {
        method: "POST",
        body: JSON.stringify({
          classId: selectedClass,
          subjectId: selectedSubject,
          date: sessionDate,
          entries: workspace.students.map((student) => ({
            studentId: student.id,
            status: attendance[student.id] ?? "PRESENT",
          })),
        }),
      })
      setMessage(`Attendance saved for ${payload.summary.total} students`)
      await loadWorkspace(selectedClass, selectedSubject, sessionDate)
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Unable to save attendance")
    } finally {
      setSaving(false)
    }
  }

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Attendance</p>
          <h1 className="text-2xl font-semibold text-foreground">Take attendance</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Session details">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="attendance-class">
              Class
            </label>
            <Select value={selectedClass} onValueChange={handleClassChange}>
              <SelectTrigger id="attendance-class">
                <SelectValue placeholder="Choose class" />
              </SelectTrigger>
              <SelectContent>
                {classOptions.map(([id, name]) => (
                  <SelectItem key={id} value={id}>
                    {name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="attendance-subject">
              Subject
            </label>
            <Select value={selectedSubject} onValueChange={handleSubjectChange}>
              <SelectTrigger id="attendance-subject">
                <SelectValue placeholder="Choose subject" />
              </SelectTrigger>
              <SelectContent>
                {subjectOptions.map((subject) => (
                  <SelectItem key={subject.id} value={subject.id}>
                    {subject.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="attendance-date">
              Date
            </label>
            <Input
              id="attendance-date"
              type="date"
              value={sessionDate}
              onChange={(event) => void handleDateChange(event.target.value)}
            />
          </div>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading attendance roster...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {message ? <p className="text-sm text-emerald-600">{message}</p> : null}

      <TeacherSectionCard title="Student list">
        <div className="space-y-3">
          {workspace?.students.length ? (
            workspace.students.map((student) => (
              <div key={student.id} className="space-y-3 rounded-2xl border border-border bg-background p-4 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{student.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Roll {student.roll} · {student.className}
                    </p>
                  </div>
                  <p className="text-xs font-semibold text-muted-foreground">
                    Current: {attendance[student.id] ?? "PRESENT"}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {statusOptions.map((status) => {
                    const isActive = attendance[student.id] === status
                    return (
                      <button
                        key={status}
                        type="button"
                        onClick={() => handleStatusChange(student.id, status)}
                        className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${isActive
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-background text-foreground hover:shadow-sm"
                        }`}
                      >
                        {status.charAt(0) + status.slice(1).toLowerCase()}
                      </button>
                    )
                  })}
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">No students found for this class and subject.</p>
          )}
        </div>
      </TeacherSectionCard>

      <div className="relative">
        <div className="sticky bottom-4 z-10 flex justify-end">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || loading}
            className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground transition hover:shadow-sm disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save attendance"}
          </button>
        </div>
        <div className="h-12" />
      </div>
    </TeacherPageShell>
  )
}
