"use client"

import { useEffect, useMemo, useState } from "react"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

const days = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]

type TimetableEntry = {
  id: string
  day: string
  startTime: string
  endTime: string
  class: { name: string }
  subject: { name: string }
}

export default function Page() {
  const [entries, setEntries] = useState<TimetableEntry[]>([])
  const [activeDay, setActiveDay] = useState(days[0])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ timetable: TimetableEntry[] }>("/api/v1/teacher/timetable")
        if (!active) return
        setEntries(payload.timetable)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load timetable")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  const dayClasses = useMemo(
    () => entries.filter((entry) => entry.day === activeDay),
    [activeDay, entries]
  )

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Timetable</p>
          <h1 className="text-2xl font-semibold text-foreground">Weekly schedule</h1>
        </div>
      }
    >
      {loading ? <p className="text-sm text-muted-foreground">Loading timetable...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <TeacherSectionCard title="Days">
        <div className="flex flex-wrap gap-2">
          {days.map((day) => (
            <button
              key={day}
              type="button"
              onClick={() => setActiveDay(day)}
              className={`rounded-full border px-4 py-1 text-xs font-semibold transition hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 ${activeDay === day
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-background text-foreground"
                }`}
            >
              {day.slice(0, 3)}
            </button>
          ))}
        </div>
        <div className="space-y-3 pt-3">
          {dayClasses.length ? (
            dayClasses.map((session) => (
              <article key={session.id} className="rounded-2xl border border-border bg-background p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{session.subject.name}</p>
                    <p className="text-xs text-muted-foreground">{session.class.name}</p>
                  </div>
                  <p className="text-xs font-semibold text-muted-foreground">
                    {session.startTime} - {session.endTime}
                  </p>
                </div>
              </article>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">No classes scheduled for this day.</p>
          )}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
