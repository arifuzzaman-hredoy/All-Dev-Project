import Link from "next/link"
import { notFound } from "next/navigation"

import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { STUDENTS, isStudentSubjectAllowed } from "../../data"

type AttendanceParams = {
  id: string | string[]
}

type AttendanceProps = {
  params: Promise<AttendanceParams>
}

const calendarEntries = [
  { label: "Mon 01", status: "Present" },
  { label: "Tue 02", status: "Present" },
  { label: "Wed 03", status: "Absent" },
  { label: "Thu 04", status: "Present" },
  { label: "Fri 05", status: "Late" },
  { label: "Mon 08", status: "Present" },
  { label: "Tue 09", status: "Present" },
  { label: "Wed 10", status: "Present" },
  { label: "Thu 11", status: "Absent" },
  { label: "Fri 12", status: "Present" },
] as const

const statusPill = {
  Present: "bg-primary/20 text-primary",
  Absent: "bg-background text-muted-foreground",
  Late: "bg-background text-muted-foreground",
}

export default async function Page({ params }: AttendanceProps) {
  const resolved = await params
  const studentId = Array.isArray(resolved.id) ? resolved.id[0] : resolved.id
  const student = STUDENTS.find((entry) => entry.id === studentId)

  if (!student || !isStudentSubjectAllowed(student)) {
    notFound()
  }

  const present = calendarEntries.filter((entry) => entry.status === "Present").length
  const absent = calendarEntries.filter((entry) => entry.status === "Absent").length
  const late = calendarEntries.filter((entry) => entry.status === "Late").length
  const total = calendarEntries.length
  const presenceRate = ((present / total) * 100).toFixed(0)

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Attendance</p>
          <h1 className="text-2xl font-semibold text-foreground">{student?.name}</h1>
          <p className="text-xs text-muted-foreground">
            Roll {student.roll} · {student.className} · {student.subject}
          </p>
          <div className="flex flex-wrap gap-2">
            <Link href="/teacher/attendance/view" className="text-xs font-semibold text-primary">
              ← All students
            </Link>
            <Link href="/teacher/students" className="text-xs font-semibold text-primary">
              ← Back to students
            </Link>
          </div>
        </div>
      }
    >
      <TeacherSectionCard title="Stats">
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <p className="text-xs text-muted-foreground">Present</p>
            <p className="text-2xl font-semibold text-foreground">{present}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Absent</p>
            <p className="text-2xl font-semibold text-foreground">{absent}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Presence</p>
            <p className="text-2xl font-semibold text-foreground">{presenceRate}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Late</p>
            <p className="text-2xl font-semibold text-foreground">{late}</p>
          </div>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Calendar view" description="Month / year">
        <div className="grid gap-3 sm:grid-cols-4">
          {calendarEntries.map((entry) => (
            <article
              key={entry.label}
              className="flex flex-col gap-1 rounded-2xl border border-border bg-background p-3"
            >
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{entry.label}</p>
              <span className={`text-sm font-semibold text-foreground ${statusPill[entry.status]}`}>
                {entry.status}
              </span>
            </article>
          ))}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
