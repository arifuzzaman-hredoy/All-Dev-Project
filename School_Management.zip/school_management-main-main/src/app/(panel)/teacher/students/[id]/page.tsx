import Link from "next/link"
import { notFound } from "next/navigation"

import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { STUDENTS, isStudentSubjectAllowed } from "../data"

type StudentParams = {
  id: string | string[]
}

type StudentProps = {
  params: Promise<StudentParams>
}

const recentResults = [
  { exam: "Midterm", subject: "Mathematics", marks: 88, grade: "A-" },
  { exam: "Midterm", subject: "Physics", marks: 81, grade: "B+" },
  { exam: "Unit Test", subject: "English", marks: 91, grade: "A" },
]

const statusBadge = {
  Active: "Present in class",
  Inactive: "Temporarily paused",
}

export default async function Page({ params }: StudentProps) {
  const resolvedParams = await params
  const studentId = Array.isArray(resolvedParams.id)
    ? resolvedParams.id[0]
    : resolvedParams.id
  const student = STUDENTS.find((record) => record.id === studentId)

  if (!student || !isStudentSubjectAllowed(student)) {
    notFound()
  }

  const attendanceTotals = {
    present: Math.round(student.attendance / 100 * 150),
    absent: 10,
    late: 3,
  }

  const quickActionClasses =
    "inline-flex items-center justify-center rounded-full border border-border px-4 py-2 text-xs font-semibold text-foreground transition hover:shadow-sm active:border-primary active:text-primary-foreground"

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Student profile</p>
          <h1 className="text-2xl font-semibold text-foreground">{student.name}</h1>
          <p className="text-xs text-muted-foreground">
            Roll {student.roll} · {student.className} · {student.group}
          </p>
          <Link href="/teacher/students" className="text-xs font-semibold text-primary">
            ← Back to students
          </Link>
        </div>
      }
    >
      <TeacherSectionCard title="Profile information">
        <div className="grid gap-3 text-sm text-foreground sm:grid-cols-2">
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Class</p>
            <p>{student.className}</p>
          </div>
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Group</p>
            <p>{student.group}</p>
          </div>
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Subject</p>
            <p>{student.subject}</p>
          </div>
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Roll</p>
            <p>{student.roll}</p>
          </div>
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Status</p>
            <p className="text-xs font-semibold text-foreground">{statusBadge[student.status]}</p>
          </div>
        </div>
        <div className="grid gap-3 text-sm text-foreground md:grid-cols-2">
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Guardian</p>
            <p>{student.parent}</p>
          </div>
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Contact</p>
            <p>{student.phone}</p>
            <p className="text-xs text-muted-foreground">{student.email}</p>
          </div>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Attendance summary">
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <p className="text-xs text-muted-foreground">Days present</p>
            <p className="text-2xl font-semibold text-foreground">{attendanceTotals.present}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Days absent</p>
            <p className="text-2xl font-semibold text-foreground">{attendanceTotals.absent}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Late arrivals</p>
            <p className="text-2xl font-semibold text-foreground">{attendanceTotals.late}</p>
          </div>
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Recent results">
        <div className="space-y-2 text-sm text-foreground">
          {recentResults.map((result) => (
            <div
              key={`${result.exam}-${result.subject}`}
              className="flex items-center justify-between rounded-xl border border-border px-3 py-2"
            >
              <div>
                <p className="text-xs text-muted-foreground">{result.exam}</p>
                <p className="text-sm font-semibold">{result.subject}</p>
              </div>
              <div className="space-y-1 text-right">
                <p className="text-xs text-muted-foreground">Marks</p>
                <p className="text-sm font-semibold text-foreground">{result.marks}</p>
                <p className="text-xs text-muted-foreground">Grade {result.grade}</p>
              </div>
            </div>
          ))}
        </div>
      </TeacherSectionCard>

      <TeacherSectionCard title="Quick actions">
        <div className="flex flex-wrap gap-3">
          <Link href="/teacher/attendance/view" className={quickActionClasses}>
            View attendance
          </Link>
          <Link href="/teacher/results/create" className={quickActionClasses}>
            Add marks
          </Link>
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}

