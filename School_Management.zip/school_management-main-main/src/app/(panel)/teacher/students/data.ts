export type StudentSubject = "Mathematics" | "Physics" | "Chemistry" | "English"

export type StudentRecord = {
  id: string
  name: string
  className: string
  group: string
  roll: number
  attendance: number
  parent: string
  phone: string
  email: string
  subject: StudentSubject
  status: "Active" | "Inactive"
}

export const TEACHER_ASSIGNED_SUBJECT: StudentSubject = "Physics"
export const TEACHER_ALLOWED_SUBJECTS: StudentSubject[] = [TEACHER_ASSIGNED_SUBJECT]
export const teacherSubjectLabel =
  TEACHER_ALLOWED_SUBJECTS.length === 0 ? "All subjects" : TEACHER_ALLOWED_SUBJECTS.join(", ")

export const isStudentSubjectAllowed = (student: StudentRecord) =>
  TEACHER_ALLOWED_SUBJECTS.length === 0 || TEACHER_ALLOWED_SUBJECTS.includes(student.subject)

export const filterStudentsForAssignedSubject = (students: StudentRecord[]) =>
  students.filter(isStudentSubjectAllowed)

export const STUDENTS: StudentRecord[] = [
  {
    id: "1",
    name: "Mahi Alam",
    className: "Class 10",
    group: "Science",
    roll: 12,
    attendance: 94,
    parent: "Shamim Rahman",
    phone: "01700000001",
    email: "mahi.alam@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "2",
    name: "Nusrat Jahan",
    className: "Class 10",
    group: "Science",
    roll: 14,
    attendance: 88,
    parent: "Shamim Ahmed",
    phone: "01700000002",
    email: "nusrat.jahan@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "3",
    name: "Tanvir Hossain",
    className: "Class 9",
    group: "Science",
    roll: 7,
    attendance: 76,
    parent: "Rina Hossain",
    phone: "01700000003",
    email: "tanvir.hossain@example.com",
    subject: "Chemistry",
    status: "Inactive",
  },
  {
    id: "4",
    name: "Sabbir Rahman",
    className: "Class 8",
    group: "General",
    roll: 21,
    attendance: 95,
    parent: "Khaleda Begum",
    phone: "01700000004",
    email: "sabbir.rahman@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "5",
    name: "Rafiul Islam",
    className: "Class 10",
    group: "Commerce",
    roll: 18,
    attendance: 84,
    parent: "Salma Begum",
    phone: "01700000005",
    email: "rafiul.islam@example.com",
    subject: "Mathematics",
    status: "Active",
  },
  {
    id: "6",
    name: "Ayesha Akter",
    className: "Class 9",
    group: "Science",
    roll: 9,
    attendance: 91,
    parent: "Hasan Ali",
    phone: "01700000006",
    email: "ayesha.akter@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "7",
    name: "Arif Chowdhury",
    className: "Class 9",
    group: "Science",
    roll: 22,
    attendance: 89,
    parent: "Rashida Chowdhury",
    phone: "01700000007",
    email: "arif.chowdhury@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "8",
    name: "Nabila Sultana",
    className: "Class 10",
    group: "Commerce",
    roll: 19,
    attendance: 87,
    parent: "Farid Sultana",
    phone: "01700000008",
    email: "nabila.sultana@example.com",
    subject: "English",
    status: "Active",
  },
  {
    id: "9",
    name: "Rakibul Islam",
    className: "Class 8",
    group: "General",
    roll: 5,
    attendance: 82,
    parent: "Amina Islam",
    phone: "01700000009",
    email: "rakibul.islam@example.com",
    subject: "Mathematics",
    status: "Active",
  },
  {
    id: "10",
    name: "Tasnima Ahmed",
    className: "Class 10",
    group: "Science",
    roll: 15,
    attendance: 96,
    parent: "Mahfuz Ahmed",
    phone: "01700000010",
    email: "tasnima.ahmed@example.com",
    subject: "Physics",
    status: "Active",
  },
  {
    id: "11",
    name: "Imran Hossain",
    className: "Class 9",
    group: "General",
    roll: 3,
    attendance: 78,
    parent: "Sultana Hossain",
    phone: "01700000011",
    email: "imran.hossain@example.com",
    subject: "English",
    status: "Active",
  },
  {
    id: "12",
    name: "Sadia Khan",
    className: "Class 8",
    group: "General",
    roll: 2,
    attendance: 88,
    parent: "Nazrul Khan",
    phone: "01700000012",
    email: "sadia.khan@example.com",
    subject: "Chemistry",
    status: "Active",
  },
]
