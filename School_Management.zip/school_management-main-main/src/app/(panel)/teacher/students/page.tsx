"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type TeacherStudent = {
  id: string
  name: string
  email: string
  className: string
  group: string
  roll: number
  parent: string
  phone: string | null
  attendance: number
}

const buttonClasses =
  "inline-flex rounded-full border border-border px-3 py-1 text-xs font-semibold text-foreground transition hover:shadow-sm"

export default function Page() {
  const [students, setStudents] = useState<TeacherStudent[]>([])
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All")
  const [groupFilter, setGroupFilter] = useState("All")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ students: TeacherStudent[] }>("/api/v1/teacher/students")
        if (!active) return
        setStudents(payload.students)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load students")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  const classOptions = useMemo(
    () => ["All", ...Array.from(new Set(students.map((student) => student.className)))],
    [students]
  )
  const groupOptions = useMemo(() => {
    const filtered = classFilter === "All"
      ? students
      : students.filter((student) => student.className === classFilter)
    return ["All", ...Array.from(new Set(filtered.map((student) => student.group)))]
  }, [classFilter, students])

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesClass = classFilter === "All" || student.className === classFilter
      const matchesGroup = groupFilter === "All" || student.group === groupFilter
      const normalizedSearch = search.trim().toLowerCase()
      const matchesSearch =
        normalizedSearch === "" ||
        student.name.toLowerCase().includes(normalizedSearch) ||
        String(student.roll) === normalizedSearch

      return matchesClass && matchesGroup && matchesSearch
    })
  }, [classFilter, groupFilter, search, students])

  const averageAttendance = filteredStudents.length
    ? Math.round(
        filteredStudents.reduce((sum, student) => sum + student.attendance, 0) /
          filteredStudents.length
      )
    : 0

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Students</p>
          <h1 className="text-2xl font-semibold text-foreground">Assigned class list</h1>
        </div>
      }
    >
      <TeacherSectionCard title="Search & filters" description="Find students by name, class, or group">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="student-search">
              Search students
            </label>
            <Input
              id="student-search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Name or roll"
            />
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-foreground" htmlFor="class-select">
                Class
              </label>
              <Select value={classFilter} onValueChange={(value) => {
                setClassFilter(value)
                setGroupFilter("All")
              }}>
                <SelectTrigger id="class-select">
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-foreground" htmlFor="group-select">
                Group
              </label>
              <Select value={groupFilter} onValueChange={setGroupFilter}>
                <SelectTrigger id="group-select">
                  <SelectValue placeholder="Select group" />
                </SelectTrigger>
                <SelectContent>
                  {groupOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading students...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Showing</p>
          <p className="text-xl font-semibold text-foreground">{filteredStudents.length}</p>
          <p className="text-xs text-muted-foreground">students currently filtered</p>
        </div>
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Average attendance</p>
          <p className="text-xl font-semibold text-foreground">{averageAttendance}%</p>
          <p className="text-xs text-muted-foreground">across the current list</p>
        </div>
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Guardians linked</p>
          <p className="text-xl font-semibold text-foreground">
            {filteredStudents.filter((student) => student.parent !== "No guardian linked").length}
          </p>
          <p className="text-xs text-muted-foreground">guardian records available</p>
        </div>
      </div>

      <TeacherSectionCard title="Student list">
        <div className="space-y-3">
          {filteredStudents.length === 0 ? (
            <p className="text-sm text-muted-foreground">No students match the current filters.</p>
          ) : (
            filteredStudents.map((student) => (
              <div
                key={student.id}
                className="space-y-3 rounded-2xl border border-border bg-background p-4 shadow-sm transition-shadow hover:shadow"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{student.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {student.className} · {student.group}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Roll {student.roll} · {student.email}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Attendance</p>
                    <p className="text-sm font-semibold text-foreground">{student.attendance}%</p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/teacher/students/${student.id}`} className={buttonClasses}>
                    View profile
                  </Link>
                  <span className="text-xs text-muted-foreground">Guardian: {student.parent}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
