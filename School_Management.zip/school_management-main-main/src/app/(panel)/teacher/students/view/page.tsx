"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { fetchWithAuth } from "@/lib/client-api"

type DirectoryStudent = {
  id: string
  name: string
  email: string
  classId: string
  className: string
  group: string
  section: string
  roll: number
  parent: string
  phone: string | null
  attendance: number
}

type DirectoryPayload = {
  classes: Array<{ id: string; name: string }>
  selectedClassId: string | null
  students: DirectoryStudent[]
}

const buttonClasses =
  "inline-flex items-center justify-center rounded-full border border-border px-3 py-1 text-xs font-semibold text-foreground transition hover:shadow-sm"

export default function Page() {
  const [data, setData] = useState<DirectoryPayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [search, setSearch] = useState("")
  const [selectedClass, setSelectedClass] = useState("")

  async function load(nextClassId?: string, nextSearch?: string) {
    const params = new URLSearchParams({ mode: "directory" })
    if (nextClassId) params.set("classId", nextClassId)
    if (nextSearch?.trim()) params.set("search", nextSearch.trim())
    const payload = await fetchWithAuth<DirectoryPayload>(`/api/v1/teacher/students?${params.toString()}`)
    setData(payload)
    setSelectedClass(payload.selectedClassId ?? "")
  }

  useEffect(() => {
    let active = true

    async function bootstrap() {
      try {
        const params = new URLSearchParams({ mode: "directory" })
        const payload = await fetchWithAuth<DirectoryPayload>(`/api/v1/teacher/students?${params.toString()}`)
        if (!active) return
        setData(payload)
        setSelectedClass(payload.selectedClassId ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load students")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void bootstrap()
    return () => {
      active = false
    }
  }, [])

  const averageAttendance = useMemo(() => {
    if (!data?.students.length) return 0
    return Math.round(
      data.students.reduce((sum, student) => sum + student.attendance, 0) / data.students.length
    )
  }, [data])

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Students</p>
          <h1 className="text-2xl font-semibold text-foreground">Student directory</h1>
          <p className="text-sm text-muted-foreground">
            View only students from your assigned classes.
          </p>
        </div>
      }
    >
      <TeacherSectionCard title="Assigned class filter" description="Choose which assigned class you want to review">
        <div className="grid gap-3 md:grid-cols-[220px_1fr_auto]">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="teacher-directory-class">
              Assigned class
            </label>
            <Select
              value={selectedClass}
              onValueChange={(value) => {
                setSelectedClass(value)
                void load(value, search).catch((nextError) => setError(nextError.message))
              }}
            >
              <SelectTrigger id="teacher-directory-class">
                <SelectValue placeholder="Select class" />
              </SelectTrigger>
              <SelectContent>
                {data?.classes.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground" htmlFor="teacher-directory-search">
              Search student
            </label>
            <Input
              id="teacher-directory-search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Name or email"
            />
          </div>
          <div className="flex items-end">
            <button
              type="button"
              onClick={() => void load(selectedClass, search).catch((nextError) => setError(nextError.message))}
              className={buttonClasses}
            >
              Apply
            </button>
          </div>
        </div>
      </TeacherSectionCard>

      {loading ? <p className="text-sm text-muted-foreground">Loading students...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Visible students</p>
          <p className="text-xl font-semibold text-foreground">{data?.students.length ?? 0}</p>
        </div>
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Average attendance</p>
          <p className="text-xl font-semibold text-foreground">{averageAttendance}%</p>
        </div>
        <div className="rounded-2xl border border-border bg-background p-4 shadow-sm">
            <p className="text-xs text-muted-foreground">Guardians linked</p>
          <p className="text-xl font-semibold text-foreground">
            {data?.students.filter((student) => student.parent !== "No guardian linked").length ?? 0}
          </p>
        </div>
      </div>

      <TeacherSectionCard title="Assigned students">
        <div className="space-y-3">
          {data?.students.length ? data.students.map((student) => (
            <div
              key={student.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-background p-4 shadow-sm"
            >
              <div>
                <p className="text-sm font-semibold text-foreground">{student.name}</p>
                <p className="text-xs text-muted-foreground">
                  {student.className} · {student.group} · {student.section}
                </p>
                <p className="text-xs text-muted-foreground">
                  Roll {student.roll} · Attendance {student.attendance}%
                </p>
              </div>
              <Link href={`/teacher/students/view/${student.id}`} className={buttonClasses}>
                View profile
              </Link>
            </div>
          )) : (
            <p className="text-sm text-muted-foreground">No students found for the selected class.</p>
          )}
        </div>
      </TeacherSectionCard>
    </TeacherPageShell>
  )
}
