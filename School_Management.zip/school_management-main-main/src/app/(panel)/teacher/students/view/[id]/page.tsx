"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { TeacherPageShell } from "@/components/teacher/page-shell"
import { TeacherSectionCard } from "@/components/teacher/section-card"
import { fetchWithAuth } from "@/lib/client-api"

type StudentProfilePayload = {
  student: {
    id: string
    name: string
    email: string
    phone: string | null
    roll: number
    classId: string
    className: string
    group: string
    section: string
    parent: string
    parentEmail: string | null
    attendanceRate: number
  }
  attendanceTotals: {
    present: number
    absent: number
    late: number
  }
  recentAttendance: Array<{
    id: string
    date: string
    status: string
    subject: { name: string }
  }>
  recentResults: Array<{
    id: string
    marks: number
    grade: string | null
    subject: { name: string }
    exam: { name: string; date: string }
  }>
}

const quickActionClasses =
  "inline-flex items-center justify-center rounded-full border border-border px-4 py-2 text-xs font-semibold text-foreground transition hover:shadow-sm active:border-primary active:text-primary-foreground"

export default function Page() {
  const params = useParams<{ id: string }>()
  const [data, setData] = useState<StudentProfilePayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [notFoundState, setNotFoundState] = useState(false)

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<StudentProfilePayload>(`/api/v1/teacher/students/${params.id}`)
        if (!active) return
        setData(payload)
      } catch (nextError) {
        if (!active) return
        const message = nextError instanceof Error ? nextError.message : "Unable to load student"
        if (message.toLowerCase().includes("not found")) {
          setNotFoundState(true)
          return
        }
        setError(message)
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    if (params.id) {
      void load()
    }

    return () => {
      active = false
    }
  }, [params.id])

  if (notFoundState) {
    return (
      <TeacherPageShell
        header={
          <div className="space-y-1">
            <p className="text-sm uppercase tracking-wide text-muted-foreground">Student profile</p>
            <h1 className="text-2xl font-semibold text-foreground">Student not found</h1>
            <Link href="/teacher/students/view" className="text-xs font-semibold text-primary">
              ← Back to student directory
            </Link>
          </div>
        }
      >
        <p className="text-sm text-muted-foreground">
          This student is not available in your assigned classes.
        </p>
      </TeacherPageShell>
    )
  }

  return (
    <TeacherPageShell
      header={
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Student profile</p>
          <h1 className="text-2xl font-semibold text-foreground">{data?.student.name ?? "Student"}</h1>
          <p className="text-xs text-muted-foreground">
            {data ? `Roll ${data.student.roll} · ${data.student.className} · ${data.student.group}` : "Loading profile"}
          </p>
          <Link href="/teacher/students/view" className="text-xs font-semibold text-primary">
            ← Back to student directory
          </Link>
        </div>
      }
    >
      {loading ? <p className="text-sm text-muted-foreground">Loading student profile...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {data ? (
        <>
          <TeacherSectionCard title="Profile information">
            <div className="grid gap-3 text-sm text-foreground sm:grid-cols-2">
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Class</p>
                <p>{data.student.className}</p>
              </div>
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Group</p>
                <p>{data.student.group}</p>
              </div>
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Section</p>
                <p>{data.student.section}</p>
              </div>
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Roll</p>
                <p>{data.student.roll}</p>
              </div>
            </div>
            <div className="grid gap-3 text-sm text-foreground md:grid-cols-2">
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Guardian</p>
                <p>{data.student.parent}</p>
                {data.student.parentEmail ? (
                  <p className="text-xs text-muted-foreground">{data.student.parentEmail}</p>
                ) : null}
              </div>
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Contact</p>
                <p>{data.student.phone ?? "No phone"}</p>
                <p className="text-xs text-muted-foreground">{data.student.email}</p>
              </div>
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard title="Attendance summary">
            <div className="grid gap-3 sm:grid-cols-4">
              <div>
                <p className="text-xs text-muted-foreground">Attendance rate</p>
                <p className="text-2xl font-semibold text-foreground">{data.student.attendanceRate}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Present</p>
                <p className="text-2xl font-semibold text-foreground">{data.attendanceTotals.present}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Absent</p>
                <p className="text-2xl font-semibold text-foreground">{data.attendanceTotals.absent}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Late</p>
                <p className="text-2xl font-semibold text-foreground">{data.attendanceTotals.late}</p>
              </div>
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard title="Recent results">
            <div className="space-y-2 text-sm text-foreground">
              {data.recentResults.length > 0 ? data.recentResults.map((result) => (
                <div
                  key={result.id}
                  className="flex items-center justify-between rounded-xl border border-border px-3 py-2"
                >
                  <div>
                    <p className="text-xs text-muted-foreground">
                      {result.exam.name} · {new Date(result.exam.date).toLocaleDateString()}
                    </p>
                    <p className="text-sm font-semibold">{result.subject.name}</p>
                  </div>
                  <div className="space-y-1 text-right">
                    <p className="text-xs text-muted-foreground">Marks</p>
                    <p className="text-sm font-semibold text-foreground">{result.marks}</p>
                    <p className="text-xs text-muted-foreground">Grade {result.grade ?? "-"}</p>
                  </div>
                </div>
              )) : (
                <p className="text-sm text-muted-foreground">No recent results found.</p>
              )}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard title="Recent attendance">
            <div className="space-y-2 text-sm text-foreground">
              {data.recentAttendance.length > 0 ? data.recentAttendance.map((entry) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between rounded-xl border border-border px-3 py-2"
                >
                  <div>
                    <p className="text-sm font-semibold">{entry.subject.name}</p>
                    <p className="text-xs text-muted-foreground">{new Date(entry.date).toLocaleDateString()}</p>
                  </div>
                  <p className="text-xs font-semibold text-foreground">{entry.status}</p>
                </div>
              )) : (
                <p className="text-sm text-muted-foreground">No recent attendance found.</p>
              )}
            </div>
          </TeacherSectionCard>

          <TeacherSectionCard title="Quick actions">
            <div className="flex flex-wrap gap-3">
              <Link href="/teacher/attendance/view" className={quickActionClasses}>
                View attendance
              </Link>
              <Link href="/teacher/results/create" className={quickActionClasses}>
                Add marks
              </Link>
            </div>
          </TeacherSectionCard>
        </>
      ) : null}
    </TeacherPageShell>
  )
}
