"use client"

import { useEffect, useMemo, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type ResultItem = {
  id: string
  marks: number
  totalMarks: number
  grade: string | null
  exam: {
    id: string
    name: string
    date: string
  }
  subject: {
    name: string
  }
}

export default function Page() {
  const [results, setResults] = useState<ResultItem[]>([])
  const [selectedYear, setSelectedYear] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ results: ResultItem[] }>("/api/v1/student/results")
        if (!active) return
        setResults(payload.results)
        const years = Array.from(new Set(payload.results.map((item) => new Date(item.exam.date).getFullYear()))).sort((a, b) => b - a)
        setSelectedYear(years[0] ?? null)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load results")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  const availableYears = useMemo(
    () => Array.from(new Set(results.map((item) => new Date(item.exam.date).getFullYear()))).sort((a, b) => b - a),
    [results]
  )

  const groupedResults = useMemo(() => {
    return results
      .filter((item) => selectedYear === null || new Date(item.exam.date).getFullYear() === selectedYear)
      .reduce<Record<string, { exam: string; year: number; subjects: ResultItem[] }>>((acc, result) => {
        const key = result.exam.id
        if (!acc[key]) {
          acc[key] = {
            exam: result.exam.name,
            year: new Date(result.exam.date).getFullYear(),
            subjects: [],
          }
        }
        acc[key].subjects.push(result)
        return acc
      }, {})
  }, [results, selectedYear])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div>
        <h1 className="text-xl font-semibold">Results</h1>
        <p className="text-sm text-muted-foreground">
          View your academic history and exam performance
        </p>
      </div>

      {loading ? <p className="text-sm text-muted-foreground">Loading results...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      <div className="rounded-xl border p-4">
        <h2 className="mb-3 font-semibold">Exam years</h2>
        <div className="flex flex-wrap gap-2">
          {availableYears.map((year) => (
            <button
              key={year}
              onClick={() => setSelectedYear(year)}
              className={`px-3 py-1 rounded-md text-sm border ${
                selectedYear === year ? "bg-primary text-white" : "bg-muted"
              }`}
            >
              {year}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {Object.values(groupedResults).length ? (
          Object.values(groupedResults).map((exam) => (
            <div key={`${exam.exam}-${exam.year}`} className="rounded-xl border p-4">
              <div className="mb-3 flex justify-between items-center">
                <h2 className="font-semibold">{exam.exam}</h2>
                <span className="text-xs text-muted-foreground">{exam.year}</span>
              </div>

              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-3 py-2 text-left">Subject</th>
                      <th className="px-3 py-2 text-left">Marks</th>
                      <th className="px-3 py-2 text-left">Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {exam.subjects.map((subject) => (
                      <tr key={subject.id} className="border-t">
                        <td className="px-3 py-2">{subject.subject.name}</td>
                        <td className="px-3 py-2">{subject.marks} out of {subject.totalMarks}</td>
                        <td className="px-3 py-2 font-medium">{subject.grade ?? "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))
        ) : (
          <div className="rounded-xl border p-4 text-sm text-muted-foreground">
            No results recorded yet.
          </div>
        )}
      </div>
    </div>
  )
}
