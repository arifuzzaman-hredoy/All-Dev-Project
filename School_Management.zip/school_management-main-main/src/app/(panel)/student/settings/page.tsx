"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export default function StudentSettingsPage() {
  const [darkMode, setDarkMode] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground flex justify-center">

      {/* 📱 MOBILE FRAME */}
      <div className="w-full max-w-md px-4 py-5 space-y-5">

        {/* HEADER */}
        <div>
          <h1 className="text-xl font-semibold">Settings</h1>
          <p className="text-sm text-muted-foreground">
            Manage your account and preferences
          </p>
        </div>

        {/* 👤 PROFILE */}
        <Card className="border border-border rounded-2xl">
          <CardContent className="p-4 space-y-3">

            <p className="text-sm font-medium">Profile</p>

            <div className="text-sm">
              <p className="text-muted-foreground">Name</p>
              <p className="font-medium">Student Name</p>
            </div>

            <div className="text-sm">
              <p className="text-muted-foreground">Email</p>
              <p className="font-medium">student@email.com</p>
            </div>

          </CardContent>
        </Card>

        {/* 🎨 THEME */}
        <Card className="border border-border rounded-2xl">
          <CardContent className="p-4 space-y-3">

            <p className="text-sm font-medium">Appearance</p>

            <div className="flex items-center justify-between">
              <span className="text-sm">Dark Mode</span>

              <button
                onClick={() => setDarkMode(!darkMode)}
                className={cn(
                  "w-10 h-5 rounded-full transition relative",
                  darkMode ? "bg-primary" : "bg-muted"
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-background transition",
                    darkMode && "translate-x-5"
                  )}
                />
              </button>
            </div>

          </CardContent>
        </Card>

        {/* 🔐 SECURITY */}
        <Card className="border border-border rounded-2xl">
          <CardContent className="p-4 space-y-3">

            <p className="text-sm font-medium">Security</p>

            <button className="text-sm text-primary">
              Change Password
            </button>

          </CardContent>
        </Card>

        {/* 🚪 LOGOUT */}
        <Card className="border border-border rounded-2xl">
          <CardContent className="p-4">

            <button className="w-full text-sm font-medium text-destructive">
              Logout
            </button>

          </CardContent>
        </Card>

      </div>
    </div>
  )
}