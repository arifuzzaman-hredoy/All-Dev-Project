"use client";

import { useEffect, useState } from "react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { fetchWithAuth } from "@/lib/client-api";

type StudentDashboard = {
  dashboard: {
    student: {
      name: string;
      className: string;
      roll: number | null;
      attendanceRate: number;
      feesDue: number;
    };
    upcomingExams: Array<{
      id: string;
      name: string;
      code: string;
      date: string;
      status: string;
      className: string;
      examType: string | null;
    }>;
    recentResults: Array<{
      id: string;
      marks: number;
      totalMarks: number;
      grade: string | null;
      subject: { name: string };
    }>;
    notices: Array<{
      id: string;
      title: string;
      content: string;
    }>;
  };
};

export default function Page() {
  const [data, setData] = useState<StudentDashboard["dashboard"] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const payload = await fetchWithAuth<StudentDashboard>(
          "/api/v1/student/dashboard",
        );
        if (!active) return;
        setData(payload.dashboard);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load dashboard",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, []);

  return (
    <>
      <header className="flex h-16 items-center gap-2 border-b px-4">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbPage>Student Dashboard</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </header>

      <div className="flex flex-1 flex-col gap-4 p-4">
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading dashboard...</p>
        ) : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        {data ? (
          <>
            <div className="grid gap-4 md:grid-cols-5">
              <div className="rounded-xl border p-4">
                <p className="text-sm text-muted-foreground">Class</p>
                <p className="text-lg font-semibold">
                  {data.student.className}
                </p>
              </div>
              <div className="rounded-xl border p-4">
                <p className="text-sm text-muted-foreground">Roll</p>
                <p className="text-lg font-semibold">
                  {data.student.roll ?? "N/A"}
                </p>
              </div>
              <div className="rounded-xl border p-4">
                <p className="text-sm text-muted-foreground">Attendance</p>
                <p className="text-lg font-semibold">
                  {data.student.attendanceRate}%
                </p>
              </div>
              <div className="rounded-xl border p-4">
                <p className="text-sm text-muted-foreground">Fees Due</p>
                <p className="text-lg font-semibold text-red-500">
                  ৳{data.student.feesDue}
                </p>
              </div>
              <div className="rounded-xl border p-4">
                <p className="text-sm text-muted-foreground">Visible exams</p>
                <p className="text-lg font-semibold">
                  {data.upcomingExams.length}
                </p>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-xl border p-4">
                <h2 className="mb-3 font-semibold">Upcoming Exams</h2>
                <div className="space-y-2">
                  {data.upcomingExams.length ? (
                    data.upcomingExams.map((exam) => (
                      <div key={exam.id} className="rounded-lg bg-muted/50 p-3">
                        <p className="font-medium">{exam.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {exam.code} · {exam.className} ·{" "}
                          {new Date(exam.date).toLocaleDateString()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {exam.status.replaceAll("_", " ")}
                          {exam.examType ? ` · ${exam.examType}` : ""}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No visible exams yet.
                    </p>
                  )}
                </div>
              </div>

              <div className="rounded-xl border p-4">
                <h2 className="mb-3 font-semibold">Recent Results</h2>
                <div className="space-y-2">
                  {data.recentResults.length ? (
                    data.recentResults.map((result) => (
                      <div
                        key={result.id}
                        className="flex justify-between rounded-lg bg-muted/50 p-2"
                      >
                        <span>{result.subject.name}</span>
                        <span className="font-medium">
                          {result.marks} out of {result.totalMarks}
                          {result.grade ? ` · ${result.grade}` : ""}
                        </span>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No recent results found.
                    </p>
                  )}
                </div>
              </div>

              <div className="rounded-xl border p-4">
                <h2 className="mb-3 font-semibold">Notices</h2>
                <ul className="space-y-2">
                  {data.notices.length ? (
                    data.notices.map((notice) => (
                      <li
                        key={notice.id}
                        className="rounded-lg bg-muted/50 p-2 text-sm"
                      >
                        <p className="font-medium">{notice.title}</p>
                        <p className="text-muted-foreground">
                          {notice.content}
                        </p>
                      </li>
                    ))
                  ) : (
                    <li className="rounded-lg bg-muted/50 p-2 text-sm text-muted-foreground">
                      No notices available.
                    </li>
                  )}
                </ul>
              </div>
            </div>

            <div className="rounded-xl border p-4">
              <h2 className="mb-3 font-semibold">Welcome</h2>
              <p className="text-sm text-muted-foreground">
                Welcome back, {data.student.name}! Here you can check your
                attendance, results, fees and latest notices.
              </p>
            </div>
          </>
        ) : null}
      </div>
    </>
  );
}
