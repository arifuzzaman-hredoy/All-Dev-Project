"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { fetchWithAuth } from "@/lib/client-api"

const days = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]

type TimetableDay = {
  day: string
  sessions: Array<{
    id: string
    startTime: string
    endTime: string
    subject: { id: string; name: string }
    teacher: { user: { name: string } }
  }>
}

export default function StudentTimetablePage() {
  const getToday = () => {
    const todayIndex = new Date().getDay()
    const map = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]
    const today = map[todayIndex]
    return days.includes(today) ? today : days[0]
  }

  const [activeDay, setActiveDay] = useState(getToday)
  const [timetable, setTimetable] = useState<TimetableDay[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ timetable: TimetableDay[] }>("/api/v1/student/timetable")
        if (!active) return
        setTimetable(payload.timetable)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load timetable")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  const filtered = timetable.find((item) => item.day === activeDay)?.sessions ?? []

  return (
    <div className="min-h-screen bg-background text-foreground flex justify-center">
      <div className="w-full max-w-md px-4 py-5 space-y-5">
        <div>
          <h1 className="text-xl font-semibold">Timetable</h1>
          <p className="text-sm text-muted-foreground">Your weekly class schedule</p>
        </div>

        {loading ? <p className="text-sm text-muted-foreground">Loading timetable...</p> : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        <div className="flex gap-2 overflow-x-auto pb-1">
          {days.map((day) => {
            const isActive = activeDay === day

            return (
              <button
                key={day}
                onClick={() => setActiveDay(day)}
                className={cn(
                  "px-3 py-2 text-xs font-medium rounded-xl whitespace-nowrap transition-all border border-border",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-background text-muted-foreground hover:bg-muted"
                )}
              >
                {day.slice(0, 3)}
              </button>
            )
          })}
        </div>

        <div className="space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-sm text-muted-foreground">
              No classes scheduled
            </div>
          ) : (
            filtered.map((item) => (
              <Card key={item.id} className="rounded-2xl border border-border transition hover:shadow-sm">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="font-medium">{item.subject.name}</p>
                    <p className="text-xs text-muted-foreground">{item.teacher.user.name}</p>
                  </div>

                  <div className="text-right space-y-1">
                    <p className="text-sm font-semibold">{item.startTime}</p>
                    <p className="text-xs text-muted-foreground">to {item.endTime}</p>
                    <p className="text-[10px] text-muted-foreground">ID: {item.subject.id}</p>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
