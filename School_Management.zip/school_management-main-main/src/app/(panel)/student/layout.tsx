"use client"

import type { ReactNode } from "react"

import { AppSidebar } from "@/components/app-sidebar-student"
import ModeToggle from "@/components/mode-toggle"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"

type StudentLayoutProps = {
  children: ReactNode
}

export default function StudentLayout({ children }: StudentLayoutProps) {
  return (
    <SidebarProvider>
      <AppSidebar />

      <SidebarInset className="flex min-h-screen flex-1 flex-col">

        {/* 🔥 ADD THIS HEADER */}
        <header className="flex h-14 items-center justify-between border-b px-4">
          <div className="flex items-center gap-2">
            <SidebarTrigger /> {/* ✅ MOBILE FIX */}
            <h1 className="text-sm font-semibold">Student Panel</h1>
          </div>
          <ModeToggle />
        </header>

        {/* Page Content */}
        <div className="flex flex-1 flex-col">
          {children}
        </div>

      </SidebarInset>
    </SidebarProvider>
  )
}