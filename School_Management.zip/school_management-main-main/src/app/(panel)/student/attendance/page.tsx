"use client"

import { useEffect, useMemo, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type AttendanceItem = {
  id: string
  date: string
  status: "PRESENT" | "ABSENT" | "LATE"
  period: number | null
  subject: {
    name: string
  }
}

type AttendanceSummary = {
  total: number
  present: number
  absent: number
  late: number
  attendanceRate: number
  bySubject: Array<{ subject: string; total: number; present: number; absent: number; late: number; attendanceRate: number }>
  byMonth: Array<{ month: string; total: number; present: number; absent: number; late: number; attendanceRate: number }>
}

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
]

export default function Page() {
  const [attendance, setAttendance] = useState<AttendanceItem[]>([])
  const [summary, setSummary] = useState<AttendanceSummary | null>(null)
  const [selectedYear, setSelectedYear] = useState<number | null>(null)
  const [selectedSubject, setSelectedSubject] = useState<string>("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ attendance: AttendanceItem[]; summary: AttendanceSummary }>("/api/v1/student/attendance")
        if (!active) return
        setAttendance(payload.attendance)
        setSummary(payload.summary)

        const years = Array.from(
          new Set(payload.attendance.map((item) => new Date(item.date).getFullYear()))
        ).sort((a, b) => b - a)
        const subjects = Array.from(new Set(payload.attendance.map((item) => item.subject.name))).sort()

        setSelectedYear(years[0] ?? null)
        setSelectedSubject(subjects[0] ?? "")
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load attendance")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  const availableYears = useMemo(
    () => Array.from(new Set(attendance.map((item) => new Date(item.date).getFullYear()))).sort((a, b) => b - a),
    [attendance]
  )
  const subjects = useMemo(
    () => Array.from(new Set(attendance.map((item) => item.subject.name))).sort(),
    [attendance]
  )

  const currentMap = useMemo(() => {
    const grouped = attendance.reduce<Record<string, AttendanceItem["status"][]>>((acc, item) => {
      const sameYear = selectedYear === null || new Date(item.date).getFullYear() === selectedYear
      const sameSubject = !selectedSubject || item.subject.name === selectedSubject
      if (sameYear && sameSubject) {
        const key = new Date(item.date).toISOString().split("T")[0]
        acc[key] = [...(acc[key] ?? []), item.status]
      }
      return acc
    }, {})

    return Object.fromEntries(
      Object.entries(grouped).map(([date, statuses]) => [
        date,
        statuses.includes("ABSENT")
          ? "ABSENT"
          : statuses.includes("LATE")
            ? "LATE"
            : "PRESENT",
      ]),
    )
  }, [attendance, selectedSubject, selectedYear])

  const getDays = (year: number, month: number) => {
    const date = new Date(year, month, 1)
    const days: Date[] = []

    while (date.getMonth() === month) {
      days.push(new Date(date))
      date.setDate(date.getDate() + 1)
    }

    return days
  }

  return (
    <div className="flex flex-1 flex-col gap-6 p-4">
      <div className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold">Attendance Overview</h1>
        <p className="text-sm text-muted-foreground">
          Subject-wise attendance calendar
        </p>
      </div>

      {loading ? <p className="text-sm text-muted-foreground">Loading attendance...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {summary ? (
        <div className="grid gap-3 md:grid-cols-4">
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Attendance rate</p>
            <p className="text-2xl font-semibold">{summary.attendanceRate}%</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Present</p>
            <p className="text-2xl font-semibold text-green-600">{summary.present}</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Absent</p>
            <p className="text-2xl font-semibold text-red-600">{summary.absent}</p>
          </div>
          <div className="rounded-xl border p-4">
            <p className="text-xs text-muted-foreground">Late</p>
            <p className="text-2xl font-semibold text-amber-600">{summary.late}</p>
          </div>
        </div>
      ) : null}

      {summary?.bySubject.length ? (
        <div className="rounded-xl border p-4">
          <h2 className="mb-3 text-sm font-semibold">Subject-wise percentage</h2>
          <div className="space-y-3">
            {summary.bySubject.map((item) => (
              <div key={item.subject} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>{item.subject}</span>
                  <span>{item.attendanceRate}% · {item.present}/{item.total}</span>
                </div>
                <div className="h-2 rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-green-500" style={{ width: `${item.attendanceRate}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="flex gap-2 flex-wrap">
        {subjects.map((subject) => (
          <button
            key={subject}
            onClick={() => setSelectedSubject(subject)}
            className={`px-3 py-1 rounded-md text-sm border ${
              selectedSubject === subject ? "bg-primary text-white" : "bg-muted"
            }`}
          >
            {subject}
          </button>
        ))}
      </div>

      <div className="flex gap-2 flex-wrap">
        {availableYears.map((year) => (
          <button
            key={year}
            onClick={() => setSelectedYear(year)}
            className={`px-3 py-1 rounded-md text-sm border ${
              selectedYear === year ? "bg-primary text-white" : "bg-muted"
            }`}
          >
            {year}
          </button>
        ))}
      </div>

      {selectedYear ? (
        <div className="grid gap-6 md:grid-cols-3">
          {months.map((monthName, monthIndex) => {
            const days = getDays(selectedYear, monthIndex)

            return (
              <div key={monthName} className="rounded-xl border p-3">
                <h2 className="text-sm font-semibold mb-2">{monthName}</h2>
                <div className="grid grid-cols-7 gap-5 text-xs">
                  {days.map((day) => {
                    const dateStr = day.toISOString().split("T")[0]
                    const status = currentMap[dateStr]

                    return (
                      <div
                        key={dateStr}
                        className={`h-6 w-6 flex items-center justify-center rounded text-[10px] ${
                          status === "PRESENT"
                            ? "bg-green-500 text-white"
                            : status === "ABSENT"
                              ? "bg-red-500 text-white"
                              : status === "LATE"
                                ? "bg-amber-500 text-white"
                                : "bg-muted"
                        }`}
                      >
                        {day.getDate()}
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      ) : null}
    </div>
  )
}
