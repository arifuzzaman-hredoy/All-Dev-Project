"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { fetchWithAuth } from "@/lib/client-api";

type PaymentItem = {
  id: string;
  createdAt: string;
  amountPaid: number;
  status: "PAID" | "PARTIAL" | "DUE";
  month: number | null;
  year: number | null;
  paymentMethod: string | null;
  transactionId: string | null;
  billingMonth: number;
  billingYear: number;
  billingPeriodKey: string;
  billingPeriodLabel: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  categoryFee: number;
  extraCategoryDue: number;
  dueAmount: number;
  feeCategory: {
    name: string;
    amount: number;
  };
  totalAmount: number;
  dueDate: string | null;
};

type FeeHistoryItem = {
  key: string;
  label: string;
  monthlyFeeBase: number;
  monthlyFeeDue: number;
  extraCategoryFees: number;
  extraCategoryDue: number;
  totalExpected: number;
  amountPaid: number;
  dueAmount: number;
  transactions: PaymentItem[];
};

type FeesPayload = {
  payments: PaymentItem[];
  history: FeeHistoryItem[];
  currentMonthlyFee: number;
};

const formatMoney = (value: number) => `৳${value}`;

export default function StudentFeesPage() {
  const [history, setHistory] = useState<FeeHistoryItem[]>([]);
  const [currentMonthlyFee, setCurrentMonthlyFee] = useState(0);
  const [selectedMonth, setSelectedMonth] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const payload = await fetchWithAuth<FeesPayload>(
          "/api/v1/student/fees",
        );
        if (!active) return;
        setHistory(payload.history);
        setCurrentMonthlyFee(payload.currentMonthlyFee);
      } catch (nextError) {
        if (!active) return;
        setError(
          nextError instanceof Error
            ? nextError.message
            : "Unable to load fees",
        );
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, []);

  const monthOptions = useMemo(
    () => ["all", ...history.map((item) => item.key)],
    [history],
  );

  const selectedHistory = history.filter((item) => {
    if (selectedMonth === "all") {
      return true;
    }
    return item.key === selectedMonth;
  });

  const summary = selectedHistory.reduce(
    (acc, item) => {
      acc.monthlyDue += item.monthlyFeeDue;
      acc.extraDue += item.extraCategoryDue;
      acc.expected += item.totalExpected;
      acc.paid += item.amountPaid;
      acc.due += item.dueAmount;
      return acc;
    },
    { monthlyDue: 0, extraDue: 0, expected: 0, paid: 0, due: 0 },
  );

  const hasMonthlyFeeSnapshots = history.some(
    (item) => item.monthlyFeeBase > 0,
  );
  const monthlyDue = hasMonthlyFeeSnapshots
    ? summary.monthlyDue
    : summary.monthlyDue + currentMonthlyFee;
  const dueAmount = hasMonthlyFeeSnapshots
    ? summary.due
    : summary.due + currentMonthlyFee;

  return (
    <div className="min-h-screen bg-linear-to-b from-background via-background to-muted/30 text-foreground">
      <div className="mx-auto w-full max-w-5xl px-4 py-6 space-y-6">
        <div className="rounded-3xl border border-border bg-card/80 p-5 shadow-sm backdrop-blur">
          <p className="text-xs uppercase tracking-[0.28em] text-muted-foreground">
            Finance ledger
          </p>
          <h1 className="mt-2 text-2xl font-semibold">Fees</h1>
          <p className="text-sm text-muted-foreground">
            Monthly fee base, extra category charges, paid amount, due amount,
            and transaction details in one view.
          </p>
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground">
            Loading fee history...
          </p>
        ) : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">
            Billing periods
          </p>
          <div className="flex flex-wrap gap-2">
            {monthOptions.map((option) => {
              const period = history.find((item) => item.key === option);
              const label =
                option === "all" ? "All periods" : (period?.label ?? option);

              return (
                <button
                  key={option}
                  type="button"
                  onClick={() => setSelectedMonth(option)}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs font-semibold transition",
                    selectedMonth === option
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-muted/50 text-foreground",
                  )}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-4">
          <Card className="rounded-2xl border border-border">
            <CardContent className="p-3">
              <p className="text-xs text-muted-foreground">Monthly due</p>
              <p className="text-lg font-semibold">{formatMoney(monthlyDue)}</p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border border-border">
            <CardContent className="p-3">
              <p className="text-xs text-muted-foreground">Extra due</p>
              <p className="text-lg font-semibold">
                {formatMoney(summary.extraDue)}
              </p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border border-border">
            <CardContent className="p-3">
              <p className="text-xs text-muted-foreground">Amount paid</p>
              <p className="text-lg font-semibold">
                {formatMoney(summary.paid)}
              </p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border border-border">
            <CardContent className="p-3">
              <p className="text-xs text-muted-foreground">Due amount</p>
              <p className="text-lg font-semibold">{formatMoney(dueAmount)}</p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          {selectedHistory.length ? (
            selectedHistory.map((period) => (
              <Card
                key={period.key}
                className="overflow-hidden rounded-3xl border border-border"
              >
                <CardContent className="space-y-4 p-5">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
                        Billing period
                      </p>
                      <h2 className="mt-1 text-lg font-semibold">
                        {period.label}
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        Monthly due {formatMoney(period.monthlyFeeDue)} · Extra
                        due {formatMoney(period.extraCategoryDue)}
                      </p>
                    </div>
                    <div className="rounded-2xl border border-border bg-muted/40 px-4 py-3 text-right">
                      <p className="text-xs text-muted-foreground">Due</p>
                      <p className="text-lg font-semibold">
                        {formatMoney(period.dueAmount)}
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-2xl bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">Expected</p>
                      <p className="text-sm font-semibold">
                        {formatMoney(period.totalExpected)}
                      </p>
                    </div>
                    <div className="rounded-2xl bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">Paid</p>
                      <p className="text-sm font-semibold">
                        {formatMoney(period.amountPaid)}
                      </p>
                    </div>
                    <div className="rounded-2xl bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">
                        Transactions
                      </p>
                      <p className="text-sm font-semibold">
                        {period.transactions.length}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {period.transactions.map((payment) => (
                      <div
                        key={payment.id}
                        className="rounded-2xl border border-border bg-background/80 p-4"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="space-y-1">
                            <p className="font-medium">
                              {payment.feeCategory.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Monthly due {formatMoney(payment.monthlyFeeDue)} ·
                              Extra due {formatMoney(payment.extraCategoryDue)}
                            </p>
                            <div className="flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                              <span>
                                Method: {payment.paymentMethod ?? "-"}
                              </span>
                              <span>Txn: {payment.transactionId ?? "-"}</span>
                              <span>
                                Due date:{" "}
                                {payment.dueDate
                                  ? new Date(
                                      payment.dueDate,
                                    ).toLocaleDateString()
                                  : "-"}
                              </span>
                            </div>
                          </div>

                          <div className="text-right space-y-2">
                            <p className="text-sm font-semibold">
                              {formatMoney(payment.amountPaid)} /{" "}
                              {formatMoney(payment.totalAmount)}
                            </p>
                            <span
                              className={cn(
                                "inline-flex rounded-full border px-2 py-1 text-[10px] font-semibold",
                                payment.status === "PAID" &&
                                  "border-primary bg-primary text-primary-foreground",
                                payment.status === "PARTIAL" &&
                                  "border-border bg-muted text-foreground",
                                payment.status === "DUE" &&
                                  "border-border bg-background text-muted-foreground",
                              )}
                            >
                              {payment.status}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
              No fee records available for this period.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
