"use client"

import { useEffect, useState } from "react"
import { fetchWithAuth } from "@/lib/client-api"

type StudentProfileData = {
  profile: {
    name: string
    email: string
    phone: string | null
    gender: string
    className: string
    groupName: string | null
    sectionName: string | null
    rollNumber: number | null
    guardian: {
      name: string
      email: string | null
      phone: string | null
      address: string | null
      relation: string | null
    } | null
    father: {
      name: string
      phone: string | null
    } | null
    mother: {
      name: string
      phone: string | null
    } | null
  }
}

export default function Page() {
  const [profile, setProfile] = useState<StudentProfileData["profile"] | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<StudentProfileData>("/api/v1/student/profile")
        if (!active) return
        setProfile(payload.profile)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load profile")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  return (
    <div className="flex flex-1 flex-col gap-4 p-4">
      <div>
        <h1 className="text-xl font-semibold">Profile</h1>
        <p className="text-sm text-muted-foreground">
          View your personal and academic information
        </p>
      </div>

      {loading ? <p className="text-sm text-muted-foreground">Loading profile...</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {profile ? (
        <>
          <div className="rounded-xl border p-6 flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted text-lg font-semibold">
              {profile.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-lg font-semibold">{profile.name}</h2>
              <p className="text-sm text-muted-foreground">
                {profile.className} • Roll {profile.rollNumber ?? "N/A"}
              </p>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border p-4">
              <h3 className="mb-3 font-semibold">Personal Information</h3>
              <div className="space-y-2 text-sm">
                <p><span className="text-muted-foreground">Email:</span> {profile.email}</p>
                <p><span className="text-muted-foreground">Phone:</span> {profile.phone ?? "Not provided"}</p>
                <p><span className="text-muted-foreground">Gender:</span> {profile.gender}</p>
              </div>
            </div>

            <div className="rounded-xl border p-4">
              <h3 className="mb-3 font-semibold">Academic Information</h3>
              <div className="space-y-2 text-sm">
                <p><span className="text-muted-foreground">Class:</span> {profile.className}</p>
                <p><span className="text-muted-foreground">Group:</span> {profile.groupName ?? "General"}</p>
                <p><span className="text-muted-foreground">Section:</span> {profile.sectionName ?? "Default"}</p>
                <p><span className="text-muted-foreground">Roll:</span> {profile.rollNumber ?? "N/A"}</p>
              </div>
            </div>

            <div className="rounded-xl border p-4 md:col-span-2">
              <h3 className="mb-3 font-semibold">Guardian Information</h3>
              {profile.guardian ? (
                <div className="space-y-2 text-sm">
                  <p><span className="text-muted-foreground">Name:</span> {profile.guardian.name}</p>
                  <p><span className="text-muted-foreground">Email:</span> {profile.guardian.email ?? "Not provided"}</p>
                  <p><span className="text-muted-foreground">Phone:</span> {profile.guardian.phone ?? "Not provided"}</p>
                  <p><span className="text-muted-foreground">Address:</span> {profile.guardian.address ?? "Not provided"}</p>
                  <p><span className="text-muted-foreground">Relation:</span> {profile.guardian.relation ?? "Not provided"}</p>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No guardian information linked yet.</p>
              )}
            </div>

            <div className="rounded-xl border p-4 md:col-span-2">
              <h3 className="mb-3 font-semibold">Father / Mother Information</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2 text-sm">
                  <p className="font-medium">Father</p>
                  {profile.father ? (
                    <>
                      <p><span className="text-muted-foreground">Name:</span> {profile.father.name}</p>
                      <p><span className="text-muted-foreground">Phone:</span> {profile.father.phone ?? "Not provided"}</p>
                    </>
                  ) : (
                    <p className="text-muted-foreground">Not recorded</p>
                  )}
                </div>
                <div className="space-y-2 text-sm">
                  <p className="font-medium">Mother</p>
                  {profile.mother ? (
                    <>
                      <p><span className="text-muted-foreground">Name:</span> {profile.mother.name}</p>
                      <p><span className="text-muted-foreground">Phone:</span> {profile.mother.phone ?? "Not provided"}</p>
                    </>
                  ) : (
                    <p className="text-muted-foreground">Not recorded</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  )
}
