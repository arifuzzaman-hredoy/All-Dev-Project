"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { fetchWithAuth } from "@/lib/client-api"

type Notice = {
  id: string
  title: string
  content: string
  audience: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS"
  createdAt: string
  class: { name: string } | null
}

export default function Page() {
  const [notices, setNotices] = useState<Notice[]>([])
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true

    async function load() {
      try {
        const payload = await fetchWithAuth<{ notices: Notice[] }>("/api/v1/student/notices")
        if (!active) return
        setNotices(payload.notices)
      } catch (nextError) {
        if (!active) return
        setError(nextError instanceof Error ? nextError.message : "Unable to load notices")
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      active = false
    }
  }, [])

  return (
    <div className="min-h-screen bg-background text-foreground flex justify-center">
      <div className="w-full max-w-md px-4 py-5 space-y-5">
        <div>
          <h1 className="text-xl font-semibold">Notices</h1>
          <p className="text-sm text-muted-foreground">
            Latest announcements and updates
          </p>
        </div>

        {loading ? <p className="text-sm text-muted-foreground">Loading notices...</p> : null}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        <div className="space-y-3">
          {notices.length === 0 ? (
            <div className="text-center py-10 text-sm text-muted-foreground">
              No notices available
            </div>
          ) : (
            notices.map((notice) => {
              const isExpanded = expandedId === notice.id

              return (
                <Card
                  key={notice.id}
                  onClick={() => setExpandedId(isExpanded ? null : notice.id)}
                  className="cursor-pointer border border-border rounded-2xl transition hover:shadow-sm"
                >
                  <CardContent className="p-4 space-y-2">
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <p className="font-medium">{notice.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(notice.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <span
                        className={cn(
                          "text-[10px] px-2 py-1 rounded-full border",
                          notice.audience === "ALL"
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-muted text-foreground border-border"
                        )}
                      >
                        {notice.audience}
                      </span>
                    </div>

                    <p className={cn("text-sm text-muted-foreground transition-all", isExpanded ? "" : "line-clamp-2")}>
                      {notice.content}
                    </p>

                    {notice.class?.name ? (
                      <p className="text-[11px] text-muted-foreground">Class: {notice.class.name}</p>
                    ) : null}
                    {!isExpanded ? <p className="text-xs text-primary">Tap to read more</p> : null}
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
