import { ExamTypeCategory } from "@prisma/client";

export const EXAM_TYPE_OPTIONS = [
  { value: ExamTypeCategory.MONTHLY_EXAM, label: "Monthly Exam" },
  { value: ExamTypeCategory.CLASS_TEST, label: "Class Test" },
  { value: ExamTypeCategory.MID_TERM, label: "Mid Term" },
  { value: ExamTypeCategory.FINAL_EXAM, label: "Final Exam" },
  { value: ExamTypeCategory.ASSESSMENT, label: "Assessment" },
  { value: ExamTypeCategory.VIVA, label: "Viva" },
  { value: ExamTypeCategory.PRACTICAL, label: "Practical" },
  { value: ExamTypeCategory.MODEL_TEST, label: "Model Test" },
] as const satisfies ReadonlyArray<{ value: ExamTypeCategory; label: string }>;

export type ExamTypeValue = ExamTypeCategory;

export function getExamTypeLabel(
  value: ExamTypeCategory | string | null | undefined,
) {
  if (!value) return null;
  return EXAM_TYPE_OPTIONS.find((item) => item.value === value)?.label ?? value;
}
