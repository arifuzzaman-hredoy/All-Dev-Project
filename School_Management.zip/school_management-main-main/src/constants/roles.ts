import { Role } from "@prisma/client"

export const SUPER_ADMIN_ONLY: Role[] = [Role.SUPER_ADMIN]

export const ADMIN_ROLES: Role[] = [
	Role.SUPER_ADMIN,
	Role.ADMIN,
	Role.ACCOUNTANT,
	Role.ACADEMIC_ADMIN,
	Role.ADMISSION_ADMIN,
]

const ADMIN_PERMISSION_KEYS = [
	"viewDashboard",
	"manageUsers",
	"manageStudents",
	"manageTeachers",
	"manageClasses",
	"manageSubjects",
	"manageAcademicData",
	"manageSessions",
	"manageAttendance",
	"manageFees",
	"managePayments",
	"manageFeeReports",
	"manageFinance",
	"manageFinanceReports",
	"manageAdmissions",
	"manageNotices",
	"manageTrash",
	"manageSettings",
] as const

export type AdminPermission = (typeof ADMIN_PERMISSION_KEYS)[number]

export type RolePermissionSet = Record<AdminPermission, boolean>

const createPermissionSet = (
	overrides: Partial<RolePermissionSet> = {}
): RolePermissionSet => {
	return ADMIN_PERMISSION_KEYS.reduce((acc, permission) => {
		acc[permission] = overrides[permission] ?? false
		return acc
	}, {} as RolePermissionSet)
}

export interface RoleDefinition {
	label: string
	description: string
	dashboardRoute: string
	permissions: RolePermissionSet
}

export const ROLE_DEFINITIONS: Record<Role, RoleDefinition> = {
	[Role.USER]: {
		label: "User",
		description: "General account awaiting a school-assigned role.",
		dashboardRoute: "/",
		permissions: createPermissionSet({
			viewDashboard: true,
		}),
	},
	[Role.SUPER_ADMIN]: {
		label: "Super Admin",
		description: "Owner-level access to every module, configuration, and report.",
		dashboardRoute: "/admin/dashboard",
		permissions: createPermissionSet({
			viewDashboard: true,
			manageUsers: true,
			manageStudents: true,
			manageTeachers: true,
			manageClasses: true,
			manageSubjects: true,
			manageAcademicData: true,
			manageSessions: true,
			manageAttendance: true,
			manageFees: true,
			managePayments: true,
			manageFeeReports: true,
			manageFinance: true,
			manageFinanceReports: true,
			manageAdmissions: true,
			manageNotices: true,
			manageTrash: true,
			manageSettings: true,
		}),
	},
	[Role.ADMIN]: {
		label: "Admin",
		description: "Runs the day-to-day school operations and empowers staff.",
		dashboardRoute: "/admin/dashboard",
		permissions: createPermissionSet({
			viewDashboard: true,
			manageUsers: true,
			manageStudents: true,
			manageTeachers: true,
			manageClasses: true,
			manageSubjects: true,
			manageAcademicData: true,
			manageSessions: true,
			manageAttendance: true,
			manageFees: true,
			managePayments: true,
			manageFeeReports: true,
			manageFinance: true,
			manageFinanceReports: true,
			manageAdmissions: true,
			manageNotices: true,
			manageSettings: true,
		}),
	},
	[Role.ACCOUNTANT]: {
		label: "Accountant",
		description: "Manages everything related to fees, payments, and income tracking.",
		dashboardRoute: "/admin/dashboard",
		permissions: createPermissionSet({
			viewDashboard: true,
			manageFees: true,
			managePayments: true,
			manageFeeReports: true,
			manageFinance: true,
			manageFinanceReports: true,
		}),
	},
	[Role.ACADEMIC_ADMIN]: {
		label: "Academic Admin",
		description: "Designs curriculum flows, exams, timetables, and attendance rules.",
		dashboardRoute: "/admin/dashboard",
		permissions: createPermissionSet({
			viewDashboard: true,
			manageTeachers: true,
			manageClasses: true,
			manageSubjects: true,
			manageAcademicData: true,
			manageSessions: true,
			manageAttendance: true,
			manageNotices: true,
		}),
	},
	[Role.ADMISSION_ADMIN]: {
		label: "Admission Admin",
		description: "Handles all applications, approvals, and class placements.",
		dashboardRoute: "/admin/dashboard",
		permissions: createPermissionSet({
			viewDashboard: true,
			manageAdmissions: true,
		}),
	},
	[Role.TEACHER]: {
		label: "Teacher",
		description: "Focuses on classroom delivery and student progress.",
		dashboardRoute: "/teacher",
		permissions: createPermissionSet({
			viewDashboard: true,
		}),
	},
	[Role.STUDENT]: {
		label: "Student",
		description: "Learner view for checking schedules, grades, and notices.",
		dashboardRoute: "/student",
		permissions: createPermissionSet({
			viewDashboard: true,
		}),
	},
	[Role.PARENT]: {
		label: "Guardian",
		description: "Keeps track of children’s academics, attendance, and fees.",
		dashboardRoute: "/guardian",
		permissions: createPermissionSet({
			viewDashboard: true,
		}),
	},
}

export function roleHasPermission(
	role: Role | null | undefined,
	permission: AdminPermission
) {
	if (!role) {
		return false
	}

	return ROLE_DEFINITIONS[role]?.permissions[permission] ?? false
}
