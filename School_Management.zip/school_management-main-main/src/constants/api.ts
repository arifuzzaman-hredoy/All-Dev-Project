/**
 * API route helpers so consumers don't duplicate literal strings.
 */
export const API_V1_PREFIX = "/api/v1";
export const AUTH_ROUTE = `${API_V1_PREFIX}/auth`;
export const LOGIN_ROUTE = `${AUTH_ROUTE}/login`;
export const LOGOUT_ROUTE = `${AUTH_ROUTE}/logout`;
export const FORGOT_PASSWORD_ROUTE = `${AUTH_ROUTE}/forgot-password`;
export const RESET_PASSWORD_ROUTE = `${AUTH_ROUTE}/reset-password`;
