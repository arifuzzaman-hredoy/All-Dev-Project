/**
 * Shared error messages so documentation and clients stay in sync.
 */
export const ERROR_MESSAGES = {
	INTERNAL: "Internal server error",
	MISSING_USER_ID: "Missing user identifier header",
	UNAUTHORIZED: "Unauthorized role"
};
