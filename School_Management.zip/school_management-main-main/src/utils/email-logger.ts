import { appendFile, mkdir } from "node:fs/promises";
import { dirname, join } from "node:path";

const LOG_PATH = process.env.EMAIL_LOG_PATH ?? "./logs/email-delivery.log";

export async function logDelivery(entry: Record<string, unknown>) {
  const line = JSON.stringify(entry) + "\n";
  const path = join(process.cwd(), LOG_PATH);
  const dir = dirname(path);
  try {
    await mkdir(dir, { recursive: true });
  } catch (err) {
    // ignore mkdir errors and try to append anyway
    console.error("Failed to create log directory", err);
  }

  try {
    await appendFile(path, line, { encoding: "utf8" });
  } catch (err) {
    console.error("Failed to append email delivery log", err);
  }
}

export default logDelivery;
