import { errorResponse } from "@/utils/api-response";

/**
 * Generic HTTP error with a status code for API responses.
 */
export class HttpError extends Error {
	status: number;

	constructor(message: string, status = 400) {
		super(message);
		this.status = status;
	}
}

/**
 * Normalises thrown values into consistent API responses.
 */
export function handleError(error: unknown) {
	if (error instanceof HttpError) {
		return errorResponse(error.message, error.status);
	}

	console.error(error);
	return errorResponse("Internal server error", 500);
}
