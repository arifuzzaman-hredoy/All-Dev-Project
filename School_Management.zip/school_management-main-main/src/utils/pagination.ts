/**
 * Generates skip and take values for paginated queries.
 */
export function getPagination(page = 1, limit = 20) {
	const take = Math.min(Math.max(limit, 1), 100);
	const skip = Math.max(page - 1, 0) * take;

	return { skip, take };
}
