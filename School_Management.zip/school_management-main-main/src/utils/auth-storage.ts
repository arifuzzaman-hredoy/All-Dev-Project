import type { Role } from "@prisma/client";

const STORAGE_KEY = "school-erp-auth";

export type StoredUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
  branchId?: string | null;
  branch?: {
    id: string;
    name: string;
    slug: string;
    school?: { id: string; name: string; slug: string } | null;
  } | null;
  avatar?: string;
};

export type AuthStorage = {
  token: string;
  user: StoredUser;
};

export function persistAuth(storage: AuthStorage) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(storage));
  } catch (error) {
    console.error("Failed to persist auth state", error);
  }
}

export function readAuth(): AuthStorage | null {
  if (typeof window === "undefined") {
    return null;
  }

  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as AuthStorage;
  } catch (error) {
    console.error("Invalid auth state", error);
    return null;
  }
}

export function clearAuth() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear auth state", error);
  }
}
