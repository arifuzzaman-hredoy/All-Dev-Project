import { NextResponse } from "next/server";

/**
 * Resolves a successful API response in the standard envelope.
 */
export function successResponse(data: unknown, status = 200) {
	return NextResponse.json({ success: true, data }, { status });
}

/**
 * Resolves an error response so callers can show human-friendly messages.
 */
export function errorResponse(message: string, status = 400) {
	return NextResponse.json({ success: false, message }, { status });
}
