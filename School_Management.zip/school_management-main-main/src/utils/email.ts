import nodemailer from "nodemailer";
// Use global fetch (Node 18+) for Resend HTTP requests

const transportOptions = process.env.SMTP_HOST
  ? {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: process.env.SMTP_SECURE === "true",
      auth: process.env.SMTP_USER
        ? {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASSWORD ?? "",
          }
        : undefined,
    }
  : null;

const transporter = transportOptions
  ? nodemailer.createTransport(transportOptions)
  : null;

export type PasswordResetEmailPayload = {
  to: string;
  link: string;
  name?: string;
};

export type AppEmailPayload = {
  to: string;
  subject: string;
  html: string;
  text: string;
  name?: string;
};

export async function sendAppEmail(payload: AppEmailPayload) {
  const from =
    process.env.SMTP_FROM ??
    process.env.EMAIL_FROM ??
    "no-reply@school-erp.com";
  // If RESEND_API_KEY is available, use Resend HTTP API
  const resendApiKey = process.env.RESEND_API_KEY;
  if (resendApiKey) {
    const body = {
      from,
      to: payload.to,
      subject: payload.subject,
      html: payload.html,
    } as Record<string, unknown>;

    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("[Resend] send failed:", res.status, text);
        // fall through to nodemailer if configured, else log
      } else {
        return { accepted: [payload.to], preview: payload.text };
      }
    } catch (err) {
      console.error("[Resend] error sending email", err);
    }
  }

  if (!transporter) {
    console.info("[Email]", payload.subject, payload.to);
    return { accepted: [payload.to], preview: payload.text };
  }

  return transporter.sendMail({
    to: payload.to,
    from,
    subject: payload.subject,
    html: payload.html,
    text: payload.text,
  });
}

export async function sendPasswordResetEmail(
  payload: PasswordResetEmailPayload,
) {
  const subject = "Reset your password";
  const html = `
    <p>Hello ${payload.name ?? "user"},</p>
    <p>We received a request to reset your password.</p>
    <p><a href="${payload.link}">Click here to reset your password</a></p>
    <p>If you didn\'t request this, just ignore this email.</p>
    <p>Thanks,<br/>School ERP Team</p>
  `;
  const text = `Reset your password by visiting ${payload.link}`;

  await sendAppEmail({
    to: payload.to,
    name: payload.name,
    subject,
    html,
    text,
  });
}
