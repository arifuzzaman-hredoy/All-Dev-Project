import type { FinanceEntryType, Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const financeEntrySelect = {
  id: true,
  type: true,
  amount: true,
  occurredAt: true,
  description: true,
  isDeleted: true,
  createdAt: true,
  updatedAt: true,
  category: {
    select: {
      id: true,
      name: true,
      type: true,
    },
  },
  student: {
    select: {
      id: true,
      user: {
        select: {
          name: true,
        },
      },
      class: {
        select: {
          name: true,
        },
      },
    },
  },
  createdBy: {
    select: {
      id: true,
      name: true,
      email: true,
    },
  },
} satisfies Prisma.FinanceEntrySelect;

export type FinanceEntryRecord = Prisma.FinanceEntryGetPayload<{
  select: typeof financeEntrySelect;
}>;

export async function listFinanceEntries(
  options: {
    type?: FinanceEntryType;
    categoryId?: string;
    studentId?: string;
    search?: string;
    from?: Date;
    to?: Date;
    includeDeleted?: boolean;
  } = {},
  client: PrismaClientLike = prisma,
) {
  const search = options.search?.trim();

  return client.financeEntry.findMany({
    where: {
      ...(options.includeDeleted ? {} : { isDeleted: false }),
      ...(options.type ? { type: options.type } : {}),
      ...(options.categoryId ? { categoryId: options.categoryId } : {}),
      ...(options.studentId ? { studentId: options.studentId } : {}),
      ...(options.from || options.to
        ? {
            occurredAt: {
              ...(options.from ? { gte: options.from } : {}),
              ...(options.to ? { lte: options.to } : {}),
            },
          }
        : {}),
      ...(search
        ? {
            OR: [
              { description: { contains: search, mode: "insensitive" } },
              { category: { name: { contains: search, mode: "insensitive" } } },
              {
                student: {
                  user: { name: { contains: search, mode: "insensitive" } },
                },
              },
            ],
          }
        : {}),
    },
    orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
    select: financeEntrySelect,
  });
}

export async function findFinanceEntryById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.financeEntry.findUnique({
    where: { id },
    select: financeEntrySelect,
  });
}

export async function createFinanceEntry(
  data: Prisma.FinanceEntryCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.financeEntry.create({
    data,
    select: financeEntrySelect,
  });
}

export async function updateFinanceEntryRecord(
  id: string,
  data: Prisma.FinanceEntryUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.financeEntry.update({
    where: { id },
    data,
    select: financeEntrySelect,
  });
}

