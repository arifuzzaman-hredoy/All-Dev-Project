import type {
  ExamLifecycleStatus,
  ExamTypeCategory,
  Prisma,
} from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const examListSelect = {
  id: true,
  name: true,
  code: true,
  date: true,
  description: true,
  academicYear: true,
  status: true,
  visibleToStudents: true,
  visibleToParents: true,
  visibleToTeachers: true,
  generateResult: true,
  includeInFinalReport: true,
  includeInTranscript: true,
  includeInMeritList: true,
  lockAfterPublish: true,
  publishStartsAt: true,
  publishEndsAt: true,
  resultPublishAt: true,
  isAllClasses: true,
  classId: true,
  examType: true,
  createdAt: true,
  updatedAt: true,
  class: {
    select: {
      id: true,
      name: true,
    },
  },
  _count: {
    select: {
      results: true,
      assignedClasses: true,
      subjects: true,
      teacherAssignments: true,
      history: true,
    },
  },
} satisfies Prisma.ExamSelect;

const examDetailSelect = {
  ...examListSelect,
  assignedClasses: {
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      createdAt: true,
      class: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  subjects: {
    orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }],
    select: {
      id: true,
      displayOrder: true,
      isMandatory: true,
      fullMarks: true,
      passMarks: true,
      classId: true,
      subjectId: true,
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      subject: {
        select: {
          id: true,
          name: true,
        },
      },
      components: {
        orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }],
        select: {
          id: true,
          name: true,
          displayOrder: true,
          fullMarks: true,
          isMandatory: true,
        },
      },
    },
  },
  teacherAssignments: {
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      canEdit: true,
      classId: true,
      subjectId: true,
      teacher: {
        select: {
          id: true,
          user: {
            select: {
              name: true,
            },
          },
        },
      },
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      subject: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  history: {
    orderBy: { createdAt: "desc" },
    take: 30,
    select: {
      id: true,
      action: true,
      snapshot: true,
      metadata: true,
      createdAt: true,
      actor: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  },
} satisfies Prisma.ExamSelect;

export type ExamRecord = Prisma.ExamGetPayload<{
  select: typeof examListSelect;
}>;
export type ExamDetailRecord = Prisma.ExamGetPayload<{
  select: typeof examDetailSelect;
}>;

export async function listExams(
  options: {
    search?: string;
    classId?: string;
    status?: ExamLifecycleStatus;
    academicYear?: string;
    examTypeId?: ExamTypeCategory;
    includeArchived?: boolean;
  } = {},
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();
  const statusFilter = options.status
    ? { status: options.status }
    : options.includeArchived
      ? {}
      : { status: { not: "ARCHIVED" as ExamLifecycleStatus } };

  return client.exam.findMany({
    where: {
      ...statusFilter,
      ...(options.academicYear ? { academicYear: options.academicYear } : {}),
      ...(options.examTypeId ? { examType: options.examTypeId } : {}),
      ...(options.classId
        ? {
            OR: [
              { classId: options.classId },
              { assignedClasses: { some: { classId: options.classId } } },
            ],
          }
        : {}),
      ...(trimmedSearch
        ? {
            OR: [
              {
                name: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
              {
                code: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
              {
                description: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
            ],
          }
        : {}),
    },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    select: examListSelect,
  });
}

export async function findExamById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.exam.findUnique({
    where: { id },
    select: examDetailSelect,
  });
}

export async function createExamRecord(
  data: Prisma.ExamCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.exam.create({
    data,
    select: examDetailSelect,
  });
}

export async function updateExamRecord(
  id: string,
  data: Prisma.ExamUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.exam.update({
    where: { id },
    data,
    select: examDetailSelect,
  });
}

export async function deleteExamRecord(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.exam.delete({
    where: { id },
    select: examDetailSelect,
  });
}
