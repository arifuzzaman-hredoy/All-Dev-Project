import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const teacherSubjectSelect = {
  id: true,
  createdAt: true,
  teacherId: true,
  subjectId: true,
  classId: true,
  teacher: {
    select: {
      id: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
    },
  },
  subject: {
    select: {
      id: true,
      name: true,
    },
  },
  class: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.TeacherSubjectSelect;

export type TeacherSubjectRecord = Prisma.TeacherSubjectGetPayload<{
  select: typeof teacherSubjectSelect;
}>;

export async function listTeacherSubjects(
  options: {
    teacherId?: string;
    classId?: string;
    subjectId?: string;
  },
  client: PrismaClientLike = prisma
) {
  return client.teacherSubject.findMany({
    where: {
      ...(options.teacherId ? { teacherId: options.teacherId } : {}),
      ...(options.classId ? { classId: options.classId } : {}),
      ...(options.subjectId ? { subjectId: options.subjectId } : {}),
    },
    orderBy: [{ class: { name: "asc" } }, { createdAt: "desc" }],
    select: teacherSubjectSelect,
  });
}

export async function findTeacherSubjectById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.teacherSubject.findUnique({
    where: { id },
    select: teacherSubjectSelect,
  });
}

export async function createTeacherSubject(
  data: Prisma.TeacherSubjectCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.teacherSubject.create({
    data,
    select: teacherSubjectSelect,
  });
}

export async function updateTeacherSubjectRecord(
  id: string,
  data: Prisma.TeacherSubjectUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.teacherSubject.update({
    where: { id },
    data,
    select: teacherSubjectSelect,
  });
}

export async function deleteTeacherSubjectRecord(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.teacherSubject.delete({
    where: { id },
    select: teacherSubjectSelect,
  });
}
