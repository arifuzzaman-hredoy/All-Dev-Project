import { Role, type Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const managedUserSelect = {
  id: true,
  name: true,
  email: true,
  role: true,
  branchId: true,
  branch: {
    select: { id: true, name: true, slug: true, isActive: true, schoolId: true },
  },
  isDeleted: true,
  createdAt: true,
  updatedAt: true,
} satisfies Prisma.UserSelect;

export type ManagedUserRecord = Prisma.UserGetPayload<{
  select: typeof managedUserSelect;
}>;

export async function findUserByEmail(
  email: string,
  client: PrismaClientLike = prisma,
) {
  return client.user.findUnique({
    where: { email },
  });
}

export async function findUserByEmailWithBranch(
  email: string,
  client: PrismaClientLike = prisma,
) {
  return client.user.findUnique({
    where: { email },
    include: {
      branch: {
        select: { id: true, name: true, slug: true, isActive: true, schoolId: true },
      },
    },
  });
}

export async function createUser(
  data: Prisma.UserCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.user.create({ data });
}

export async function updateUserPassword(
  userId: string,
  password: string,
  client: PrismaClientLike = prisma,
) {
  return client.user.update({
    where: { id: userId },
    data: { password },
  });
}

export async function findUserById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.user.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      branchId: true,
      branch: {
        select: { id: true, name: true, slug: true, isActive: true, schoolId: true },
      },
    },
  });
}

export async function findManagedUserById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.user.findUnique({
    where: { id },
    select: managedUserSelect,
  });
}

type ListManagedUsersOptions = {
  roles: Role[];
  search?: string;
  role?: Role;
  includeDeleted?: boolean;
  branchId?: string | null;
};

export async function listManagedUsers(
  options: ListManagedUsersOptions,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  return client.user.findMany({
    where: {
      role: {
        in: options.roles,
        ...(options.role ? { equals: options.role } : {}),
      },
      ...(options.branchId ? { branchId: options.branchId } : {}),
      ...(options.includeDeleted ? {} : { isDeleted: false }),
      ...(trimmedSearch
        ? {
            OR: [
              { name: { contains: trimmedSearch, mode: "insensitive" } },
              { email: { contains: trimmedSearch, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    select: managedUserSelect,
    orderBy: [{ isDeleted: "asc" }, { createdAt: "desc" }],
  });
}

export async function updateManagedUser(
  id: string,
  data: Prisma.UserUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.user.update({
    where: { id },
    data,
    select: managedUserSelect,
  });
}

export async function countActiveUsersByRole(
  role: Role,
  client: PrismaClientLike = prisma,
) {
  return client.user.count({
    where: {
      role,
      isDeleted: false,
    },
  });
}
