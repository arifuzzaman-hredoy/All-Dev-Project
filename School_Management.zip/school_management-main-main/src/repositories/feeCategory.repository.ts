import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const feeCategorySelect = {
  id: true,
  name: true,
  amount: true,
  isActive: true,
  createdAt: true,
  _count: {
    select: {
      payments: true,
    },
  },
  targetClasses: {
    select: {
      classId: true,
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      createdAt: true,
    },
  },
} satisfies Prisma.FeeCategorySelect;

export type FeeCategoryRecord = Prisma.FeeCategoryGetPayload<{
  select: typeof feeCategorySelect;
}>;

export async function listFeeCategories(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = search?.trim();

  return client.feeCategory.findMany({
    where: trimmedSearch
      ? {
          name: {
            contains: trimmedSearch,
            mode: "insensitive",
          },
        }
      : undefined,
    orderBy: { createdAt: "desc" },
    select: feeCategorySelect,
  });
}

export async function findFeeCategoryById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.feeCategory.findUnique({
    where: { id },
    select: feeCategorySelect,
  });
}

export async function createFeeCategory(
  data: Prisma.FeeCategoryCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.feeCategory.create({
    data,
    select: feeCategorySelect,
  });
}

export async function updateFeeCategoryRecord(
  id: string,
  data: Prisma.FeeCategoryUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.feeCategory.update({
    where: { id },
    data,
    select: feeCategorySelect,
  });
}

export async function deleteFeeCategoryRecord(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.feeCategory.delete({
    where: { id },
    select: feeCategorySelect,
  });
}
