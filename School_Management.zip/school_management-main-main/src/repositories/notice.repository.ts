import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const noticeSelect = {
  id: true,
  title: true,
  content: true,
  audience: true,
  startsAt: true,
  endsAt: true,
  isActive: true,
  status: true,
  publishedAt: true,
  classId: true,
  createdAt: true,
  updatedAt: true,
  class: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.NoticeSelect;

export type NoticeRecord = Prisma.NoticeGetPayload<{
  select: typeof noticeSelect;
}>;

export async function listNotices(
  options: {
    audience?: "ALL" | "STUDENTS" | "TEACHERS" | "ADMINS";
    classId?: string;
    search?: string;
  },
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = options.search?.trim();

  return client.notice.findMany({
    where: {
      ...(options.audience ? { audience: options.audience } : {}),
      ...(options.classId ? { classId: options.classId } : {}),
      ...(trimmedSearch
        ? {
            OR: [
              { title: { contains: trimmedSearch, mode: "insensitive" } },
              { content: { contains: trimmedSearch, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    orderBy: { createdAt: "desc" },
    select: noticeSelect,
  });
}

export async function findNoticeById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.notice.findUnique({
    where: { id },
    select: noticeSelect,
  });
}

export async function createNotice(
  data: Prisma.NoticeCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.notice.create({
    data,
    select: noticeSelect,
  });
}

export async function updateNoticeRecord(
  id: string,
  data: Prisma.NoticeUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.notice.update({
    where: { id },
    data,
    select: noticeSelect,
  });
}

export async function deleteNoticeRecord(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.notice.delete({
    where: { id },
    select: noticeSelect,
  });
}

export function buildVisibleNoticeWhere(
  now = new Date(),
): Prisma.NoticeWhereInput {
  return {
    isActive: true,
    AND: [
      {
        OR: [{ startsAt: null }, { startsAt: { lte: now } }],
      },
      {
        OR: [{ endsAt: null }, { endsAt: { gte: now } }],
      },
    ],
  };
}
