import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const classMonthlyFeeSelect = {
  id: true,
  classId: true,
  monthlyFee: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  class: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.ClassMonthlyFeeSelect;

export type ClassMonthlyFeeRecord = Prisma.ClassMonthlyFeeGetPayload<{
  select: typeof classMonthlyFeeSelect;
}>;

export async function listClassMonthlyFees(client: PrismaClientLike = prisma) {
  return client.classMonthlyFee.findMany({
    select: classMonthlyFeeSelect,
    orderBy: [{ class: { name: "asc" } }],
  });
}

export async function upsertClassMonthlyFee(
  classId: string,
  monthlyFee: number | null,
  isActive = monthlyFee !== null,
  client: PrismaClientLike = prisma,
) {
  return client.classMonthlyFee.upsert({
    where: { classId },
    create: {
      class: { connect: { id: classId } },
      monthlyFee,
      isActive,
    },
    update: {
      monthlyFee,
      isActive,
    },
    select: classMonthlyFeeSelect,
  });
}
