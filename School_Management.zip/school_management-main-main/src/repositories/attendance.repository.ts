import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const attendanceSelect = {
  id: true,
  period: true,
  date: true,
  status: true,
  markedBy: true,
  remarks: true,
  studentId: true,
  classId: true,
  subjectId: true,
  createdAt: true,
  student: {
    select: {
      id: true,
      rollNumber: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
      class: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  subject: {
    select: {
      id: true,
      name: true,
    },
  },
  class: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.AttendanceSelect;

export type AttendanceRecord = Prisma.AttendanceGetPayload<{
  select: typeof attendanceSelect;
}>;

export async function listAttendance(
  options: {
    classId?: string;
    studentId?: string;
    subjectId?: string;
    status?: "PRESENT" | "ABSENT" | "LATE";
    date?: Date;
    search?: string;
  },
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = options.search?.trim();

  return client.attendance.findMany({
    where: {
      ...(options.classId ? { classId: options.classId } : {}),
      ...(options.studentId ? { studentId: options.studentId } : {}),
      ...(options.subjectId ? { subjectId: options.subjectId } : {}),
      ...(options.status ? { status: options.status } : {}),
      ...(options.date
        ? {
            date: {
              gte: new Date(
                options.date.getFullYear(),
                options.date.getMonth(),
                options.date.getDate()
              ),
              lt: new Date(
                options.date.getFullYear(),
                options.date.getMonth(),
                options.date.getDate() + 1
              ),
            },
          }
        : {}),
      ...(trimmedSearch
        ? {
            student: {
              user: {
                name: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
            },
          }
        : {}),
    },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    select: attendanceSelect,
  });
}

export async function upsertAttendance(
  payload: {
    studentId: string;
    subjectId: string;
    classId: string;
    date: Date;
    period?: number;
    status: "PRESENT" | "ABSENT" | "LATE";
    markedBy?: string | null;
    remarks?: string | null;
  },
  client: PrismaClientLike = prisma
) {
  return client.attendance.upsert({
    where: {
      studentId_subjectId_date_period: {
        studentId: payload.studentId,
        subjectId: payload.subjectId,
        date: payload.date,
        period: payload.period ?? 1,
      },
    },
    update: {
      status: payload.status,
      classId: payload.classId,
      markedBy: payload.markedBy ?? null,
      remarks: payload.remarks ?? null,
    },
    create: {
      student: { connect: { id: payload.studentId } },
      subject: { connect: { id: payload.subjectId } },
      class: { connect: { id: payload.classId } },
      date: payload.date,
      period: payload.period ?? 1,
      status: payload.status,
      markedBy: payload.markedBy ?? null,
      remarks: payload.remarks ?? null,
    },
    select: attendanceSelect,
  });
}
