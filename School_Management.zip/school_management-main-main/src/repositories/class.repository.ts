import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const DEFAULT_CLASS = { name: "Unassigned" };
const DEFAULT_GROUP_NAME = "General";
const DEFAULT_SECTION_NAME = "A";

export async function findClassByName(
  className: string,
  client: PrismaClientLike = prisma,
) {
  return client.class.findFirst({
    where: {
      name: {
        equals: className,
        mode: "insensitive",
      },
    },
  });
}

export async function findClassById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.class.findUnique({
    where: { id },
  });
}

export async function listClasses(client: PrismaClientLike = prisma) {
  return client.class.findMany({
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      sortOrder: true,
      studentLimit: true,
    },
  });
}

export async function listClassesForBranch(
  branchId: string,
  client: PrismaClientLike = prisma,
) {
  return client.class.findMany({
    where: { branchId },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      sortOrder: true,
      studentLimit: true,
    },
  });
}

const managedClassSelect = {
  id: true,
  name: true,
  sortOrder: true,
  studentLimit: true,
  createdAt: true,
  _count: {
    select: {
      students: true,
      groups: true,
      subjects: true,
    },
  },
} satisfies Prisma.ClassSelect;

export type ManagedClassRecord = Prisma.ClassGetPayload<{
  select: typeof managedClassSelect;
}>;

export async function listManagedClasses(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = search?.trim();

  return client.class.findMany({
    where: trimmedSearch
      ? {
          name: {
            contains: trimmedSearch,
            mode: "insensitive",
          },
        }
      : undefined,
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: managedClassSelect,
  });
}

export async function findManagedClassById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.class.findUnique({
    where: { id },
    select: managedClassSelect,
  });
}

export async function createManagedClass(
  payload: { name: string; sortOrder?: number; studentLimit?: number | null },
  client: PrismaClientLike = prisma,
) {
  return client.class.create({
    data: {
      name: payload.name,
      sortOrder: payload.sortOrder ?? 0,
      studentLimit: payload.studentLimit ?? null,
    },
    select: managedClassSelect,
  });
}

export async function updateManagedClass(
  id: string,
  payload: { name?: string; studentLimit?: number | null },
  client: PrismaClientLike = prisma,
) {
  return client.class.update({
    where: { id },
    data: {
      ...(payload.name !== undefined ? { name: payload.name } : {}),
      ...(payload.studentLimit !== undefined
        ? { studentLimit: payload.studentLimit }
        : {}),
    },
    select: managedClassSelect,
  });
}

export async function deleteManagedClass(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.class.delete({
    where: { id },
    select: managedClassSelect,
  });
}

export async function ensureDefaultClass(client: PrismaClientLike = prisma) {
  const existing = await client.class.findFirst({
    where: DEFAULT_CLASS,
  });

  if (existing) return existing;

  return client.class.create({
    data: { ...DEFAULT_CLASS, sortOrder: 999999 },
  });
}

export async function findGroupById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.group.findUnique({
    where: { id },
  });
}

export async function findGroupByName(
  classId: string,
  groupName: string,
  client: PrismaClientLike = prisma,
) {
  return client.group.findFirst({
    where: {
      classId,
      name: {
        equals: groupName,
        mode: "insensitive",
      },
    },
  });
}

const managedGroupSelect = {
  id: true,
  name: true,
  studentLimit: true,
  classId: true,
  createdAt: true,
  _count: {
    select: {
      students: true,
      sections: true,
    },
  },
} satisfies Prisma.GroupSelect;

export type ManagedGroupRecord = Prisma.GroupGetPayload<{
  select: typeof managedGroupSelect;
}>;

export async function listManagedGroupsForClass(
  classId: string,
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = search?.trim();
  return client.group.findMany({
    where: {
      classId,
      ...(trimmedSearch
        ? { name: { contains: trimmedSearch, mode: "insensitive" } }
        : {}),
    },
    orderBy: [{ name: "asc" }],
    select: managedGroupSelect,
  });
}

export async function createManagedGroup(
  payload: { classId: string; name: string; studentLimit?: number | null },
  client: PrismaClientLike = prisma,
) {
  return client.group.create({
    data: {
      classId: payload.classId,
      name: payload.name,
      studentLimit: payload.studentLimit ?? null,
    },
    select: managedGroupSelect,
  });
}

export async function updateManagedGroup(
  id: string,
  payload: { name?: string; studentLimit?: number | null },
  client: PrismaClientLike = prisma,
) {
  return client.group.update({
    where: { id },
    data: {
      ...(payload.name !== undefined ? { name: payload.name } : {}),
      ...(payload.studentLimit !== undefined
        ? { studentLimit: payload.studentLimit }
        : {}),
    },
    select: managedGroupSelect,
  });
}

export async function deleteManagedGroup(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.group.delete({
    where: { id },
    select: managedGroupSelect,
  });
}

export async function ensureDefaultGroup(
  classId: string,
  client: PrismaClientLike = prisma,
) {
  const existing = await findGroupByName(classId, DEFAULT_GROUP_NAME, client);

  if (existing) return existing;

  return client.group.create({
    data: {
      classId,
      name: DEFAULT_GROUP_NAME,
    },
  });
}

export async function findSectionById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.section.findUnique({
    where: { id },
    include: {
      group: true,
    },
  });
}

export async function findSectionByName(
  groupId: string,
  sectionName: string,
  client: PrismaClientLike = prisma,
) {
  return client.section.findFirst({
    where: {
      groupId,
      name: {
        equals: sectionName,
        mode: "insensitive",
      },
    },
  });
}

export async function ensureDefaultSection(
  groupId: string,
  client: PrismaClientLike = prisma,
) {
  const existing = await findSectionByName(
    groupId,
    DEFAULT_SECTION_NAME,
    client,
  );

  if (existing) return existing;

  return client.section.create({
    data: {
      groupId,
      name: DEFAULT_SECTION_NAME,
    },
  });
}
