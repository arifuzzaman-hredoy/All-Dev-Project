import { prisma } from "@/lib/prisma";

export const PASSWORD_RESET_EXPIRATION_MINUTES = 60;

export async function createPasswordResetToken(data: {
  userId: string;
  token: string;
  expiresAt: Date;
}) {
  return prisma.passwordResetToken.create({
    data
  });
}

export async function findValidPasswordResetToken(token: string) {
  return prisma.passwordResetToken.findFirst({
    where: {
      token,
      used: false,
      expiresAt: {
        gte: new Date()
      }
    },
    include: {
      user: true
    }
  });
}

export async function markPasswordResetTokenUsed(id: string) {
  return prisma.passwordResetToken.update({
    where: { id },
    data: { used: true }
  });
}

export async function invalidatePasswordResetTokens(userId: string) {
  return prisma.passwordResetToken.updateMany({
    where: {
      userId,
      used: false
    },
    data: {
      used: true
    }
  });
}
