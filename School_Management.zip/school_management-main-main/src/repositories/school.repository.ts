import type { Prisma } from "@prisma/client";

import { prisma, type PrismaClientLike } from "@/lib/prisma";

const schoolSelect = {
  id: true,
  name: true,
  slug: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  _count: { select: { branches: true } },
} satisfies Prisma.SchoolSelect;

export type SchoolRecord = Prisma.SchoolGetPayload<{
  select: typeof schoolSelect;
}>;

export async function listSchools(
  options: { includeInactive?: boolean } = {},
  client: PrismaClientLike = prisma,
) {
  return client.school.findMany({
    where: options.includeInactive ? undefined : { isActive: true },
    select: schoolSelect,
    orderBy: [{ name: "asc" }],
  });
}

export async function findSchoolById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.school.findUnique({
    where: { id },
    select: schoolSelect,
  });
}

export async function findSchoolBySlug(
  slug: string,
  client: PrismaClientLike = prisma,
) {
  return client.school.findUnique({
    where: { slug },
    select: schoolSelect,
  });
}

export async function createSchool(
  data: Prisma.SchoolCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.school.create({
    data,
    select: schoolSelect,
  });
}

