import type { LeaveStatus, Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const departmentSelect = {
  id: true,
  name: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  _count: { select: { teachers: true } },
} satisfies Prisma.DepartmentSelect;

const designationSelect = {
  id: true,
  name: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  _count: { select: { teachers: true } },
} satisfies Prisma.DesignationSelect;

const leaveSelect = {
  id: true,
  teacherId: true,
  startDate: true,
  endDate: true,
  reason: true,
  status: true,
  decidedAt: true,
  decidedById: true,
  decidedBy: {
    select: { id: true, name: true, email: true },
  },
  createdAt: true,
  updatedAt: true,
  teacher: {
    select: {
      id: true,
      user: { select: { name: true, email: true, isDeleted: true } },
      isDeleted: true,
    },
  },
} satisfies Prisma.TeacherLeaveRequestSelect;

export type DepartmentRecord = Prisma.DepartmentGetPayload<{
  select: typeof departmentSelect;
}>;

export type DesignationRecord = Prisma.DesignationGetPayload<{
  select: typeof designationSelect;
}>;

export type TeacherLeaveRecord = Prisma.TeacherLeaveRequestGetPayload<{
  select: typeof leaveSelect;
}>;

export async function listDepartments(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmed = search?.trim();
  return client.department.findMany({
    where: trimmed
      ? { name: { contains: trimmed, mode: "insensitive" } }
      : undefined,
    orderBy: [{ isActive: "desc" }, { name: "asc" }],
    select: departmentSelect,
  });
}

export async function createDepartment(
  data: Prisma.DepartmentCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.department.create({ data, select: departmentSelect });
}

export async function updateDepartment(
  id: string,
  data: Prisma.DepartmentUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.department.update({ where: { id }, data, select: departmentSelect });
}

export async function findDepartmentById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.department.findUnique({ where: { id }, select: departmentSelect });
}

export async function listDesignations(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmed = search?.trim();
  return client.designation.findMany({
    where: trimmed
      ? { name: { contains: trimmed, mode: "insensitive" } }
      : undefined,
    orderBy: [{ isActive: "desc" }, { name: "asc" }],
    select: designationSelect,
  });
}

export async function createDesignation(
  data: Prisma.DesignationCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.designation.create({ data, select: designationSelect });
}

export async function updateDesignation(
  id: string,
  data: Prisma.DesignationUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.designation.update({ where: { id }, data, select: designationSelect });
}

export async function findDesignationById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.designation.findUnique({ where: { id }, select: designationSelect });
}

export async function listTeacherLeaveRequests(
  options: { status?: LeaveStatus; teacherId?: string } = {},
  client: PrismaClientLike = prisma,
) {
  return client.teacherLeaveRequest.findMany({
    where: {
      ...(options.status ? { status: options.status } : {}),
      ...(options.teacherId ? { teacherId: options.teacherId } : {}),
    },
    orderBy: [{ createdAt: "desc" }],
    select: leaveSelect,
  });
}

export async function createTeacherLeaveRequest(
  data: Prisma.TeacherLeaveRequestCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.teacherLeaveRequest.create({ data, select: leaveSelect });
}

export async function updateTeacherLeaveRequest(
  id: string,
  data: Prisma.TeacherLeaveRequestUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.teacherLeaveRequest.update({ where: { id }, data, select: leaveSelect });
}

export async function findTeacherLeaveRequestById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.teacherLeaveRequest.findUnique({ where: { id }, select: leaveSelect });
}

