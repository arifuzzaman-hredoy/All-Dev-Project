import type { FinanceEntryType, Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const financeCategorySelect = {
  id: true,
  name: true,
  type: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  _count: {
    select: {
      entries: true,
    },
  },
} satisfies Prisma.FinanceCategorySelect;

export type FinanceCategoryRecord = Prisma.FinanceCategoryGetPayload<{
  select: typeof financeCategorySelect;
}>;

export async function listFinanceCategories(
  options: { type?: FinanceEntryType; search?: string } = {},
  client: PrismaClientLike = prisma,
) {
  const search = options.search?.trim();

  return client.financeCategory.findMany({
    where: {
      ...(options.type ? { type: options.type } : {}),
      ...(search
        ? { name: { contains: search, mode: "insensitive" } }
        : {}),
    },
    orderBy: [{ type: "asc" }, { name: "asc" }],
    select: financeCategorySelect,
  });
}

export async function findFinanceCategoryById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.financeCategory.findUnique({
    where: { id },
    select: financeCategorySelect,
  });
}

export async function createFinanceCategory(
  data: Prisma.FinanceCategoryCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.financeCategory.create({
    data,
    select: financeCategorySelect,
  });
}

export async function updateFinanceCategoryRecord(
  id: string,
  data: Prisma.FinanceCategoryUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.financeCategory.update({
    where: { id },
    data,
    select: financeCategorySelect,
  });
}

