import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { getScopedBranchId } from "@/lib/request-context";

const auditLogSelect = {
  id: true,
  action: true,
  entityType: true,
  entityId: true,
  metadata: true,
  createdAt: true,
  actorId: true,
  branchId: true,
  actor: {
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
    },
  },
} satisfies Prisma.AuditLogSelect;

export type AuditLogRecord = Prisma.AuditLogGetPayload<{
  select: typeof auditLogSelect;
}>;

export async function listAuditLogs(
  options: {
    search?: string;
    action?: string;
    entityType?: string;
    actorId?: string;
    limit?: number;
    skip?: number;
  } = {},
  client: PrismaClientLike = prisma,
) {
  const search = options.search?.trim();

  return client.auditLog.findMany({
    where: {
      ...(options.action ? { action: options.action } : {}),
      ...(options.entityType ? { entityType: options.entityType } : {}),
      ...(options.actorId ? { actorId: options.actorId } : {}),
      ...(search
        ? {
            OR: [
              { action: { contains: search, mode: "insensitive" } },
              { entityType: { contains: search, mode: "insensitive" } },
              { actor: { name: { contains: search, mode: "insensitive" } } },
              { actor: { email: { contains: search, mode: "insensitive" } } },
            ],
          }
        : {}),
    },
    orderBy: { createdAt: "desc" },
    skip: options.skip ?? 0,
    take: options.limit ?? 50,
    select: auditLogSelect,
  });
}

export async function countAuditLogs(
  options: {
    search?: string;
    action?: string;
    entityType?: string;
    actorId?: string;
  } = {},
  client: PrismaClientLike = prisma,
) {
  const search = options.search?.trim();

  return client.auditLog.count({
    where: {
      ...(options.action ? { action: options.action } : {}),
      ...(options.entityType ? { entityType: options.entityType } : {}),
      ...(options.actorId ? { actorId: options.actorId } : {}),
      ...(search
        ? {
            OR: [
              { action: { contains: search, mode: "insensitive" } },
              { entityType: { contains: search, mode: "insensitive" } },
              { actor: { name: { contains: search, mode: "insensitive" } } },
              { actor: { email: { contains: search, mode: "insensitive" } } },
            ],
          }
        : {}),
    },
  });
}

export async function listAuditActors(client: PrismaClientLike = prisma) {
  const rows = await client.auditLog.findMany({
    where: {
      actorId: {
        not: null,
      },
    },
    distinct: ["actorId"],
    orderBy: { createdAt: "desc" },
    select: {
      actorId: true,
      actor: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });

  return rows
    .map((row) => row.actor)
    .filter((actor): actor is NonNullable<typeof actor> => Boolean(actor));
}

export async function createAuditLog(
  payload: {
    actorId?: string | null;
    action: string;
    entityType: string;
    entityId?: string | null;
    metadata?: Prisma.InputJsonValue;
    branchId?: string | null;
  },
  client: PrismaClientLike = prisma,
) {
  const actorId = payload.actorId?.trim() || null;
  let resolvedActorId = actorId;
  let branchId = payload.branchId?.trim() || getScopedBranchId();

  if (resolvedActorId) {
    const actor = await client.user.findUnique({
      where: { id: resolvedActorId },
      select: { id: true, branchId: true },
    });

    if (!actor) {
      resolvedActorId = null;
    } else if (!branchId) {
      branchId = actor.branchId;
    }
  }

  return client.auditLog.create({
    data: {
      action: payload.action,
      entityType: payload.entityType,
      entityId: payload.entityId ?? null,
      metadata: payload.metadata,
      branchId,
      actorId: resolvedActorId,
    },
    select: auditLogSelect,
  });
}
