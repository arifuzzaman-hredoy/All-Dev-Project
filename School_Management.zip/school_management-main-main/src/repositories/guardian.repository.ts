import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const guardianSelect = {
  id: true,
  userId: true,
  name: true,
  email: true,
  phone: true,
  address: true,
  relation: true,
  isDeleted: true,
  createdAt: true,
  updatedAt: true,
  user: {
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isDeleted: true,
    },
  },
  students: {
    select: {
      id: true,
      rollNumber: true,
      user: {
        select: {
          name: true,
        },
      },
      class: {
        select: {
          name: true,
        },
      },
    },
  },
} satisfies Prisma.GuardianSelect;

export type GuardianRecord = Prisma.GuardianGetPayload<{
  select: typeof guardianSelect;
}>;

export async function createGuardian(
  data: Prisma.GuardianCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.guardian.create({
    data,
    select: guardianSelect,
  });
}

export async function findGuardianById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.guardian.findUnique({
    where: { id },
    select: guardianSelect,
  });
}

export async function findGuardianByUserId(
  userId: string,
  client: PrismaClientLike = prisma,
) {
  return client.guardian.findUnique({
    where: { userId },
    select: guardianSelect,
  });
}

export async function findGuardianByContact(
  input: { email?: string | null; phone?: string | null },
  client: PrismaClientLike = prisma,
) {
  if (!input.email && !input.phone) {
    return null;
  }

  return client.guardian.findFirst({
    where: {
      isDeleted: false,
      OR: [
        ...(input.email ? [{ email: input.email }] : []),
        ...(input.phone ? [{ phone: input.phone }] : []),
      ],
    },
    select: guardianSelect,
    orderBy: { createdAt: "desc" },
  });
}

export async function listGuardians(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = search?.trim();

  const where = {
    isDeleted: false,
    userId: { not: null },
    ...(trimmedSearch
      ? {
          OR: [
            { name: { contains: trimmedSearch, mode: "insensitive" } },
            { email: { contains: trimmedSearch, mode: "insensitive" } },
            { phone: { contains: trimmedSearch, mode: "insensitive" } },
            {
              user: {
                name: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            {
              user: {
                email: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
          ],
        }
      : {}),
  } satisfies Prisma.GuardianWhereInput;

  return client.guardian.findMany({
    where,
    select: guardianSelect,
    orderBy: { createdAt: "desc" },
  });
}

export async function updateGuardianRecord(
  id: string,
  data: Prisma.GuardianUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.guardian.update({
    where: { id },
    data,
    select: guardianSelect,
  });
}

export async function listGuardiansPaged(
  options: { search?: string; skip?: number; take?: number },
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  const where = {
    isDeleted: false,
    userId: { not: null },
    ...(trimmedSearch
      ? {
          OR: [
            { name: { contains: trimmedSearch, mode: "insensitive" } },
            { email: { contains: trimmedSearch, mode: "insensitive" } },
            { phone: { contains: trimmedSearch, mode: "insensitive" } },
            {
              user: {
                name: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            {
              user: {
                email: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
          ],
        }
      : {}),
  } satisfies Prisma.GuardianWhereInput;

  return client.guardian.findMany({
    where,
    select: guardianSelect,
    orderBy: { createdAt: "desc" },
    ...(options.take ? { take: options.take } : {}),
    ...(options.skip ? { skip: options.skip } : {}),
  });
}

export async function countGuardiansBySearch(
  search?: string,
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = search?.trim();

  const where = {
    isDeleted: false,
    userId: { not: null },
    ...(trimmedSearch
      ? {
          OR: [
            { name: { contains: trimmedSearch, mode: "insensitive" } },
            { email: { contains: trimmedSearch, mode: "insensitive" } },
            { phone: { contains: trimmedSearch, mode: "insensitive" } },
            {
              user: {
                name: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            {
              user: {
                email: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
          ],
        }
      : {}),
  } satisfies Prisma.GuardianWhereInput;

  return client.guardian.count({ where });
}
