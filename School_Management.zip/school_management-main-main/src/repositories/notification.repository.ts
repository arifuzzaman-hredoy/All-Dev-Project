import type { NotificationChannel, NotificationStatus, Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const notificationTemplateSelect = {
  id: true,
  key: true,
  channel: true,
  subject: true,
  body: true,
  description: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
} satisfies Prisma.NotificationTemplateSelect;

const notificationQueueSelect = {
  id: true,
  channel: true,
  status: true,
  recipientName: true,
  recipientEmail: true,
  subject: true,
  body: true,
  metadata: true,
  errorMessage: true,
  sentAt: true,
  createdAt: true,
  updatedAt: true,
  template: {
    select: {
      id: true,
      key: true,
      channel: true,
    },
  },
} satisfies Prisma.NotificationQueueSelect;

export type NotificationTemplateRecord = Prisma.NotificationTemplateGetPayload<{
  select: typeof notificationTemplateSelect;
}>;

export type NotificationQueueRecord = Prisma.NotificationQueueGetPayload<{
  select: typeof notificationQueueSelect;
}>;

export async function listNotificationTemplates(client: PrismaClientLike = prisma) {
  return client.notificationTemplate.findMany({
    orderBy: { key: "asc" },
    select: notificationTemplateSelect,
  });
}

export async function findNotificationTemplateByKey(
  key: string,
  client: PrismaClientLike = prisma
) {
  return client.notificationTemplate.findFirst({
    where: { key },
    select: notificationTemplateSelect,
  });
}

export async function upsertNotificationTemplate(
  payload: {
    key: string;
    channel: NotificationChannel;
    subject: string;
    body: string;
    description?: string | null;
    isActive?: boolean;
  },
  client: PrismaClientLike = prisma
) {
  const existing = await findNotificationTemplateByKey(payload.key, client);

  if (!existing) {
    return client.notificationTemplate.create({
      data: {
        key: payload.key,
        channel: payload.channel,
        subject: payload.subject,
        body: payload.body,
        description: payload.description ?? null,
        isActive: payload.isActive ?? true,
      },
      select: notificationTemplateSelect,
    });
  }

  return client.notificationTemplate.update({
    where: { id: existing.id },
    data: {
      key: payload.key,
      channel: payload.channel,
      subject: payload.subject,
      body: payload.body,
      description: payload.description ?? null,
      isActive: payload.isActive ?? true,
    },
    select: notificationTemplateSelect,
  });
}

export async function enqueueNotification(
  payload: {
    templateId?: string | null;
    channel: NotificationChannel;
    recipientName?: string | null;
    recipientEmail: string;
    subject: string;
    body: string;
    metadata?: Prisma.InputJsonValue;
  },
  client: PrismaClientLike = prisma
) {
  return client.notificationQueue.create({
    data: {
      template: payload.templateId ? { connect: { id: payload.templateId } } : undefined,
      channel: payload.channel,
      recipientName: payload.recipientName ?? null,
      recipientEmail: payload.recipientEmail,
      subject: payload.subject,
      body: payload.body,
      metadata: payload.metadata,
    },
    select: notificationQueueSelect,
  });
}

export async function listNotificationQueue(
  options: {
    status?: NotificationStatus;
    limit?: number;
  } = {},
  client: PrismaClientLike = prisma
) {
  return client.notificationQueue.findMany({
    where: options.status ? { status: options.status } : undefined,
    orderBy: { createdAt: "desc" },
    take: options.limit ?? 20,
    select: notificationQueueSelect,
  });
}

export async function updateNotificationQueueStatus(
  id: string,
  payload: {
    status: NotificationStatus;
    errorMessage?: string | null;
    sentAt?: Date | null;
  },
  client: PrismaClientLike = prisma
) {
  return client.notificationQueue.update({
    where: { id },
    data: {
      status: payload.status,
      errorMessage: payload.errorMessage ?? null,
      sentAt: payload.sentAt ?? null,
    },
    select: notificationQueueSelect,
  });
}
