import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const teacherSelect = {
  id: true,
  phone: true,
  address: true,
  salary: true,
  isDeleted: true,
  createdAt: true,
  managedClasses: {
    select: {
      id: true,
      classId: true,
      class: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  subjects: {
    select: {
      id: true,
      classId: true,
      subjectId: true,
      class: {
        select: {
          id: true,
          name: true,
        },
      },
      subject: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  user: {
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      branchId: true,
      isDeleted: true,
    },
  },
} satisfies Prisma.TeacherSelect;

export type TeacherRecord = Prisma.TeacherGetPayload<{
  select: typeof teacherSelect;
}>;

export async function createTeacher(
  data: Prisma.TeacherCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.teacher.create({
    data,
    select: teacherSelect,
  });
}

export async function listTeachers(
  options: {
    search?: string;
    includeDeleted?: boolean;
    branchId?: string | null;
  },
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = options.search?.trim();

  return client.teacher.findMany({
    where: {
      ...(options.includeDeleted ? {} : { isDeleted: false }),
      ...(options.branchId ? { user: { branchId: options.branchId } } : {}),
      ...(trimmedSearch
        ? {
            OR: [
              { user: { name: { contains: trimmedSearch, mode: "insensitive" } } },
              { user: { email: { contains: trimmedSearch, mode: "insensitive" } } },
              { phone: { contains: trimmedSearch, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    select: teacherSelect,
    orderBy: [{ isDeleted: "asc" }, { createdAt: "desc" }],
  });
}

export async function findTeacherById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.teacher.findUnique({
    where: { id },
    select: teacherSelect,
  });
}

export async function updateTeacherRecord(
  id: string,
  data: Prisma.TeacherUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.teacher.update({
    where: { id },
    data,
    select: teacherSelect,
  });
}

export async function countTeachers(
  includeDeleted = false,
  branchId?: string | null,
  client: PrismaClientLike = prisma
) {
  return client.teacher.count({
    where: {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...(branchId ? { user: { branchId } } : {}),
    },
  });
}
