import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const timetableSelect = {
  id: true,
  day: true,
  startTime: true,
  endTime: true,
  createdAt: true,
  classId: true,
  subjectId: true,
  teacherId: true,
  class: {
    select: {
      id: true,
      name: true,
    },
  },
  subject: {
    select: {
      id: true,
      name: true,
    },
  },
  teacher: {
    select: {
      id: true,
      user: {
        select: {
          name: true,
        },
      },
    },
  },
} satisfies Prisma.TimetableSelect;

export type TimetableRecord = Prisma.TimetableGetPayload<{
  select: typeof timetableSelect;
}>;

export async function listTimetables(
  options: {
    classId?: string;
    teacherId?: string;
    day?: "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY";
  },
  client: PrismaClientLike = prisma
) {
  return client.timetable.findMany({
    where: {
      ...(options.classId ? { classId: options.classId } : {}),
      ...(options.teacherId ? { teacherId: options.teacherId } : {}),
      ...(options.day ? { day: options.day } : {}),
    },
    orderBy: [{ day: "asc" }, { startTime: "asc" }],
    select: timetableSelect,
  });
}

export async function findTimetableById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.timetable.findUnique({
    where: { id },
    select: timetableSelect,
  });
}

export async function createTimetable(
  data: Prisma.TimetableCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.timetable.create({
    data,
    select: timetableSelect,
  });
}

export async function updateTimetableRecord(
  id: string,
  data: Prisma.TimetableUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.timetable.update({
    where: { id },
    data,
    select: timetableSelect,
  });
}

export async function deleteTimetableRecord(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.timetable.delete({
    where: { id },
    select: timetableSelect,
  });
}
