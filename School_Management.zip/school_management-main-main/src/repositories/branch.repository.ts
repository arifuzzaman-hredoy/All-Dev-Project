import type { Prisma } from "@prisma/client";

import { prisma, type PrismaClientLike } from "@/lib/prisma";

const branchSelect = {
  id: true,
  name: true,
  slug: true,
  isActive: true,
  school: {
    select: {
      id: true,
      name: true,
      slug: true,
      isActive: true,
    },
  },
  createdAt: true,
  updatedAt: true,
} satisfies Prisma.BranchSelect;

export type BranchRecord = Prisma.BranchGetPayload<{
  select: typeof branchSelect;
}>;

export async function listBranches(
  options: { includeInactive?: boolean } = {},
  client: PrismaClientLike = prisma,
) {
  return client.branch.findMany({
    where: options.includeInactive ? undefined : { isActive: true },
    select: branchSelect,
    orderBy: [{ school: { name: "asc" } }, { name: "asc" }],
  });
}

export async function findBranchById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.branch.findUnique({
    where: { id },
    select: branchSelect,
  });
}

export async function findBranchBySlug(
  slug: string,
  client: PrismaClientLike = prisma,
) {
  return client.branch.findUnique({
    where: { slug },
    select: branchSelect,
  });
}

export async function createBranch(
  data: Prisma.BranchCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.branch.create({
    data,
    select: branchSelect,
  });
}

export async function updateBranch(
  id: string,
  data: Prisma.BranchUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.branch.update({
    where: { id },
    data,
    select: branchSelect,
  });
}

