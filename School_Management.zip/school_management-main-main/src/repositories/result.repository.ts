import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const resultSelect = {
  id: true,
  marks: true,
  grade: true,
  createdAt: true,
  studentId: true,
  examId: true,
  subjectId: true,
  student: {
    select: {
      id: true,
      rollNumber: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
      class: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
  exam: {
    select: {
      id: true,
      name: true,
      date: true,
      subjects: {
        select: {
          classId: true,
          subjectId: true,
          fullMarks: true,
          components: {
            select: {
              fullMarks: true,
            },
          },
        },
      },
    },
  },
  subject: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.ResultSelect;

export type ResultRecord = Prisma.ResultGetPayload<{
  select: typeof resultSelect;
}>;

export async function listResults(
  options: {
    search?: string;
    examId?: string;
    studentId?: string;
    classId?: string;
    subjectId?: string;
  },
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = options.search?.trim();

  return client.result.findMany({
    where: {
      ...(options.examId ? { examId: options.examId } : {}),
      ...(options.studentId ? { studentId: options.studentId } : {}),
      ...(options.subjectId ? { subjectId: options.subjectId } : {}),
      ...(options.classId ? { student: { classId: options.classId } } : {}),
      ...(trimmedSearch
        ? {
            OR: [
              {
                student: {
                  user: {
                    name: {
                      contains: trimmedSearch,
                      mode: "insensitive",
                    },
                  },
                },
              },
              {
                subject: {
                  name: {
                    contains: trimmedSearch,
                    mode: "insensitive",
                  },
                },
              },
            ],
          }
        : {}),
    },
    orderBy: [{ createdAt: "desc" }],
    select: resultSelect,
  });
}

export async function findResultById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.result.findUnique({
    where: { id },
    select: resultSelect,
  });
}

export async function createResult(
  data: Prisma.ResultCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.result.create({
    data,
    select: resultSelect,
  });
}

export async function updateResultRecord(
  id: string,
  data: Prisma.ResultUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.result.update({
    where: { id },
    data,
    select: resultSelect,
  });
}

export async function deleteResultRecord(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.result.delete({
    where: { id },
    select: resultSelect,
  });
}
