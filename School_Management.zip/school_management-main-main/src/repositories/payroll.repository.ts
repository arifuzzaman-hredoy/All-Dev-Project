import type { PayrollItemStatus, PayrollRunStatus, Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const payrollRunSelect = {
  id: true,
  month: true,
  year: true,
  status: true,
  createdAt: true,
  updatedAt: true,
  createdBy: {
    select: { id: true, name: true, email: true },
  },
  _count: { select: { items: true } },
} satisfies Prisma.PayrollRunSelect;

const payrollItemSelect = {
  id: true,
  payrollRunId: true,
  teacherId: true,
  baseSalarySnapshot: true,
  allowances: true,
  deductions: true,
  netPay: true,
  presentDays: true,
  absentDays: true,
  status: true,
  paidAt: true,
  createdAt: true,
  updatedAt: true,
  teacher: {
    select: {
      id: true,
      salary: true,
      employeeCode: true,
      user: { select: { name: true, email: true, isDeleted: true } },
      isDeleted: true,
    },
  },
} satisfies Prisma.PayrollItemSelect;

export type PayrollRunRecord = Prisma.PayrollRunGetPayload<{
  select: typeof payrollRunSelect;
}>;

export type PayrollItemRecord = Prisma.PayrollItemGetPayload<{
  select: typeof payrollItemSelect;
}>;

export async function listPayrollRuns(
  filters: { status?: PayrollRunStatus } = {},
  client: PrismaClientLike = prisma,
) {
  return client.payrollRun.findMany({
    where: filters.status ? { status: filters.status } : undefined,
    orderBy: [{ year: "desc" }, { month: "desc" }, { createdAt: "desc" }],
    select: payrollRunSelect,
  });
}

export async function findPayrollRunById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.payrollRun.findUnique({
    where: { id },
    select: payrollRunSelect,
  });
}

export async function findPayrollRunByPeriod(
  month: number,
  year: number,
  client: PrismaClientLike = prisma,
) {
  return client.payrollRun.findFirst({
    where: { month, year },
    select: payrollRunSelect,
  });
}

export async function createPayrollRun(
  data: Prisma.PayrollRunCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.payrollRun.create({
    data,
    select: payrollRunSelect,
  });
}

export async function updatePayrollRun(
  id: string,
  data: Prisma.PayrollRunUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.payrollRun.update({
    where: { id },
    data,
    select: payrollRunSelect,
  });
}

export async function listPayrollItems(
  payrollRunId: string,
  filters: { status?: PayrollItemStatus } = {},
  client: PrismaClientLike = prisma,
) {
  return client.payrollItem.findMany({
    where: {
      payrollRunId,
      ...(filters.status ? { status: filters.status } : {}),
    },
    orderBy: [{ teacher: { user: { name: "asc" } } }],
    select: payrollItemSelect,
  });
}

export async function updatePayrollItem(
  id: string,
  data: Prisma.PayrollItemUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.payrollItem.update({
    where: { id },
    data,
    select: payrollItemSelect,
  });
}

export async function markPayrollRunItemsPaid(
  payrollRunId: string,
  client: PrismaClientLike = prisma,
) {
  const now = new Date();
  const updated = await client.payrollItem.updateMany({
    where: { payrollRunId, status: "UNPAID" },
    data: { status: "PAID", paidAt: now },
  });
  return { count: updated.count, paidAt: now };
}
