import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";
import { findUserById } from "@/repositories/user.repository";

const systemSettingSelect = {
  id: true,
  key: true,
  value: true,
  createdAt: true,
  updatedAt: true,
  updatedById: true,
  updatedBy: {
    select: {
      id: true,
      name: true,
      email: true,
    },
  },
} satisfies Prisma.SystemSettingSelect;

export type SystemSettingRecord = Prisma.SystemSettingGetPayload<{
  select: typeof systemSettingSelect;
}>;

export async function listSystemSettings(
  options: { search?: string } = {},
  client: PrismaClientLike = prisma
) {
  const search = options.search?.trim();

  return client.systemSetting.findMany({
    where: search
      ? {
          key: {
            contains: search,
            mode: "insensitive",
          },
        }
      : undefined,
    orderBy: { key: "asc" },
    select: systemSettingSelect,
  });
}

export async function findSystemSettingByKey(
  key: string,
  client: PrismaClientLike = prisma
) {
  return client.systemSetting.findFirst({
    where: { key },
    select: systemSettingSelect,
  });
}

export async function upsertSystemSetting(
  payload: {
    key: string;
    value: Prisma.InputJsonValue;
    updatedById?: string | null;
  },
  client: PrismaClientLike = prisma
) {
  const updatedById = payload.updatedById
    ? (await findUserById(payload.updatedById, client))
      ? payload.updatedById
      : null
    : null;

  const existing = await findSystemSettingByKey(payload.key, client);

  if (!existing) {
    return client.systemSetting.create({
      data: {
        key: payload.key,
        value: payload.value,
        updatedBy: updatedById ? { connect: { id: updatedById } } : undefined,
      },
      select: systemSettingSelect,
    });
  }

  return client.systemSetting.update({
    where: { id: existing.id },
    data: {
      key: payload.key,
      value: payload.value,
      updatedBy: updatedById ? { connect: { id: updatedById } } : { disconnect: true },
    },
    select: systemSettingSelect,
  });
}
