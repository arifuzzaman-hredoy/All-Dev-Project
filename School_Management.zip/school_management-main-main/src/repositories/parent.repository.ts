import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const parentSelect = {
  id: true,
  phone: true,
  address: true,
  createdAt: true,
  user: {
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isDeleted: true,
    },
  },
  students: {
    select: {
      id: true,
      rollNumber: true,
      user: {
        select: {
          name: true,
        },
      },
      class: {
        select: {
          name: true,
        },
      },
    },
  },
} satisfies Prisma.ParentSelect;

export type ParentRecord = Prisma.ParentGetPayload<{
  select: typeof parentSelect;
}>;

export async function createParent(
  data: Prisma.ParentCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.parent.create({
    data,
    select: parentSelect,
  });
}

export async function listParents(
  search?: string,
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = search?.trim();

  return client.parent.findMany({
    where: trimmedSearch
      ? {
          OR: [
            {
              user: {
                name: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
            },
            {
              user: {
                email: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
            },
            {
              phone: {
                contains: trimmedSearch,
                mode: "insensitive",
              },
            },
          ],
        }
      : undefined,
    orderBy: { createdAt: "desc" },
    select: parentSelect,
  });
}

export async function findParentById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.parent.findUnique({
    where: { id },
    select: parentSelect,
  });
}

export async function updateParentRecord(
  id: string,
  data: Prisma.ParentUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.parent.update({
    where: { id },
    data,
    select: parentSelect,
  });
}
