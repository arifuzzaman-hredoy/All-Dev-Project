import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const subjectSelect = {
  id: true,
  name: true,
  classId: true,
  createdAt: true,
  class: {
    select: {
      id: true,
      name: true,
    },
  },
  _count: {
    select: {
      teachers: true,
      results: true,
      attendances: true,
    },
  },
} satisfies Prisma.SubjectSelect;

export type SubjectRecord = Prisma.SubjectGetPayload<{
  select: typeof subjectSelect;
}>;

export async function listSubjects(
  options: {
    search?: string;
    classId?: string;
  },
  client: PrismaClientLike = prisma
) {
  const trimmedSearch = options.search?.trim();

  return client.subject.findMany({
    where: {
      ...(options.classId ? { classId: options.classId } : {}),
      ...(trimmedSearch
        ? {
            name: {
              contains: trimmedSearch,
              mode: "insensitive",
            },
          }
        : {}),
    },
    orderBy: [{ class: { name: "asc" } }, { name: "asc" }],
    select: subjectSelect,
  });
}

export async function findSubjectById(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.subject.findUnique({
    where: { id },
    select: subjectSelect,
  });
}

export async function createSubject(
  data: Prisma.SubjectCreateInput,
  client: PrismaClientLike = prisma
) {
  return client.subject.create({
    data,
    select: subjectSelect,
  });
}

export async function updateSubjectRecord(
  id: string,
  data: Prisma.SubjectUpdateInput,
  client: PrismaClientLike = prisma
) {
  return client.subject.update({
    where: { id },
    data,
    select: subjectSelect,
  });
}

export async function deleteSubjectRecord(
  id: string,
  client: PrismaClientLike = prisma
) {
  return client.subject.delete({
    where: { id },
    select: subjectSelect,
  });
}
