import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const studentListSelect = {
  id: true,
  rollNumber: true,
  phone: true,
  gender: true,
  placementStatus: true,
  isDeleted: true,
  classId: true,
  groupId: true,
  sectionId: true,
  fatherName: true,
  fatherPhone: true,
  motherName: true,
  motherPhone: true,
  parentId: true,
  createdAt: true,
  guardianId: true,
  user: {
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isDeleted: true,
    },
  },
  class: {
    select: {
      id: true,
      name: true,
      monthlyFeeSetting: {
        select: {
          monthlyFee: true,
          isActive: true,
        },
      },
    },
  },
  group: {
    select: {
      id: true,
      name: true,
    },
  },
  section: {
    select: {
      id: true,
      name: true,
    },
  },
  guardian: {
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      address: true,
      relation: true,
    },
  },
} satisfies Prisma.StudentSelect;

const studentDocumentSelect = {
  id: true,
  rollNumber: true,
  phone: true,
  gender: true,
  isDeleted: true,
  fatherName: true,
  fatherPhone: true,
  motherName: true,
  motherPhone: true,
  createdAt: true,
  user: {
    select: {
      id: true,
      name: true,
      email: true,
    },
  },
  class: {
    select: {
      id: true,
      name: true,
    },
  },
  group: {
    select: {
      id: true,
      name: true,
    },
  },
  section: {
    select: {
      id: true,
      name: true,
    },
  },
  parent: {
    select: {
      phone: true,
      address: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
    },
  },
  guardian: {
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      address: true,
      relation: true,
    },
  },
} satisfies Prisma.StudentSelect;

export type StudentRecord = Prisma.StudentGetPayload<{
  select: typeof studentListSelect;
}>;

export type StudentDocumentRecord = Prisma.StudentGetPayload<{
  select: typeof studentDocumentSelect;
}>;

export async function getNextRollNumber(
  classId: string,
  client: PrismaClientLike = prisma,
) {
  const result = await client.student.aggregate({
    where: { classId },
    _max: { rollNumber: true },
  });

  return (result._max.rollNumber ?? 0) + 1;
}

export async function createStudent(
  data: Prisma.StudentCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.student.create({ data, select: studentListSelect });
}

export async function listStudents(
  options: {
    search?: string;
    classId?: string;
    includeDeleted?: boolean;
    skip?: number;
    take?: number;
  },
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  const where = {
    ...(options.includeDeleted ? {} : { isDeleted: false }),
    ...(options.classId ? { classId: options.classId } : {}),
    ...(trimmedSearch
      ? {
          OR: [
            {
              user: {
                name: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            {
              user: {
                email: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            { phone: { contains: trimmedSearch, mode: "insensitive" } },
          ],
        }
      : {}),
  } satisfies Prisma.StudentWhereInput;

  return client.student.findMany({
    where,
    select: studentListSelect,
    orderBy: [{ isDeleted: "asc" }, { createdAt: "desc" }],
    ...(options.take ? { take: options.take } : {}),
    ...(options.skip ? { skip: options.skip } : {}),
  });
}

export async function findStudentById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.student.findUnique({
    where: { id },
    select: studentListSelect,
  });
}

export async function findStudentDocumentById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.student.findUnique({
    where: { id },
    select: studentDocumentSelect,
  });
}

export async function updateStudentRecord(
  id: string,
  data: Prisma.StudentUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.student.update({
    where: { id },
    data,
    select: studentListSelect,
  });
}

export async function countStudents(
  includeDeleted = false,
  client: PrismaClientLike = prisma,
) {
  return client.student.count({
    where: includeDeleted ? undefined : { isDeleted: false },
  });
}

export async function countStudentsByFilters(
  options: {
    search?: string;
    classId?: string;
    includeDeleted?: boolean;
  },
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  const where = {
    ...(options.includeDeleted ? {} : { isDeleted: false }),
    ...(options.classId ? { classId: options.classId } : {}),
    ...(trimmedSearch
      ? {
          OR: [
            {
              user: {
                name: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            {
              user: {
                email: { contains: trimmedSearch, mode: "insensitive" },
              },
            },
            { phone: { contains: trimmedSearch, mode: "insensitive" } },
          ],
        }
      : {}),
  } satisfies Prisma.StudentWhereInput;

  return client.student.count({ where });
}
