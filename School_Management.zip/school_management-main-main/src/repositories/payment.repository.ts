import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const paymentSelect = {
  id: true,
  amountPaid: true,
  status: true,
  paymentMethod: true,
  transactionId: true,
  month: true,
  year: true,
  dueDate: true,
  createdAt: true,
  student: {
    select: {
      id: true,
      user: {
        select: {
          name: true,
          email: true,
        },
      },
      class: {
        select: {
          name: true,
          monthlyFeeSetting: {
            select: {
              monthlyFee: true,
              isActive: true,
            },
          },
        },
      },
      rollNumber: true,
    },
  },
  monthlyFeeSnapshot: true,
  feeCategory: {
    select: {
      id: true,
      name: true,
      amount: true,
    },
  },
  feeAmountSnapshot: true,
  dedupeKey: true,
} satisfies Prisma.PaymentSelect;

export type PaymentRecord = Prisma.PaymentGetPayload<{
  select: typeof paymentSelect;
}>;

export async function listPayments(
  options: {
    status?: "PAID" | "PARTIAL" | "DUE";
    studentId?: string;
    feeCategoryId?: string;
    search?: string;
  },
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  return client.payment.findMany({
    where: {
      ...(options.status ? { status: options.status } : {}),
      ...(options.studentId ? { studentId: options.studentId } : {}),
      ...(options.feeCategoryId
        ? { feeCategoryId: options.feeCategoryId }
        : {}),
      ...(trimmedSearch
        ? {
            OR: [
              {
                student: {
                  user: {
                    name: {
                      contains: trimmedSearch,
                      mode: "insensitive",
                    },
                  },
                },
              },
              {
                transactionId: {
                  contains: trimmedSearch,
                  mode: "insensitive",
                },
              },
            ],
          }
        : {}),
    },
    orderBy: { createdAt: "desc" },
    select: paymentSelect,
  });
}

export async function findPaymentById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.payment.findUnique({
    where: { id },
    select: paymentSelect,
  });
}

export async function findPaymentByStudentCategoryPeriod(
  studentId: string,
  feeCategoryId: string,
  month: number,
  year: number,
  client: PrismaClientLike = prisma,
) {
  const dedupeKey = `${year}-${String(month).padStart(2, "0")}`;

  return client.payment.findFirst({
    where: {
      studentId,
      feeCategoryId,
      dedupeKey,
    },
    select: paymentSelect,
  });
}

export async function createPayment(
  data: Prisma.PaymentCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.payment.create({
    data,
    select: paymentSelect,
  });
}

export async function updatePaymentRecord(
  id: string,
  data: Prisma.PaymentUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.payment.update({
    where: { id },
    data,
    select: paymentSelect,
  });
}

export async function deletePaymentRecord(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.payment.delete({
    where: { id },
    select: paymentSelect,
  });
}
