import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const admissionSelect = {
  id: true,
  name: true,
  email: true,
  phone: true,
  className: true,
  message: true,
  details: true,
  status: true,
  convertedToStudentId: true,
  createdAt: true,
  updatedAt: true,
} satisfies Prisma.AdmissionApplicationSelect;

export type AdmissionRecord = Prisma.AdmissionApplicationGetPayload<{
  select: typeof admissionSelect;
}>;

export async function createAdmission(
  data: Prisma.AdmissionApplicationCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.admissionApplication.create({
    data,
    select: admissionSelect,
  });
}

export async function listAdmissions(
  options: {
    search?: string;
    status?: "PENDING" | "ACCEPTED" | "REJECTED";
  },
  client: PrismaClientLike = prisma,
) {
  const trimmedSearch = options.search?.trim();

  return client.admissionApplication.findMany({
    where: {
      ...(options.status ? { status: options.status } : {}),
      ...(trimmedSearch
        ? {
            OR: [
              { name: { contains: trimmedSearch, mode: "insensitive" } },
              { email: { contains: trimmedSearch, mode: "insensitive" } },
              { className: { contains: trimmedSearch, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    select: admissionSelect,
    orderBy: [{ createdAt: "desc" }],
  });
}

export async function findAdmissionById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.admissionApplication.findUnique({
    where: { id },
    select: admissionSelect,
  });
}

export async function findAdmissionByEmail(
  email: string,
  client: PrismaClientLike = prisma,
) {
  return client.admissionApplication.findFirst({
    where: {
      email,
    },
    select: admissionSelect,
    orderBy: { updatedAt: "desc" },
  });
}

export async function updateAdmissionRecord(
  id: string,
  data: Prisma.AdmissionApplicationUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.admissionApplication.update({
    where: { id },
    data,
    select: admissionSelect,
  });
}
