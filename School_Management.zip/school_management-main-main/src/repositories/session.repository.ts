import type { Prisma } from "@prisma/client";
import { prisma, type PrismaClientLike } from "@/lib/prisma";

const sessionSelect = {
  id: true,
  name: true,
  startsAt: true,
  endsAt: true,
  isActive: true,
  isCurrent: true,
  createdAt: true,
  updatedAt: true,
  _count: {
    select: {
      students: true,
    },
  },
} satisfies Prisma.AcademicSessionSelect;

export type AcademicSessionRecord = Prisma.AcademicSessionGetPayload<{
  select: typeof sessionSelect;
}>;

export async function listSessions(
  options: { search?: string; includeInactive?: boolean } = {},
  client: PrismaClientLike = prisma,
) {
  const search = options.search?.trim();

  return client.academicSession.findMany({
    where: {
      ...(options.includeInactive ? {} : { isActive: true }),
      ...(search
        ? { name: { contains: search, mode: "insensitive" } }
        : {}),
    },
    orderBy: [{ isCurrent: "desc" }, { createdAt: "desc" }],
    select: sessionSelect,
  });
}

export async function findSessionById(
  id: string,
  client: PrismaClientLike = prisma,
) {
  return client.academicSession.findUnique({
    where: { id },
    select: sessionSelect,
  });
}

export async function findCurrentSession(client: PrismaClientLike = prisma) {
  return client.academicSession.findFirst({
    where: { isCurrent: true },
    orderBy: { updatedAt: "desc" },
    select: sessionSelect,
  });
}

export async function createSession(
  data: Prisma.AcademicSessionCreateInput,
  client: PrismaClientLike = prisma,
) {
  return client.academicSession.create({
    data,
    select: sessionSelect,
  });
}

export async function updateSessionRecord(
  id: string,
  data: Prisma.AcademicSessionUpdateInput,
  client: PrismaClientLike = prisma,
) {
  return client.academicSession.update({
    where: { id },
    data,
    select: sessionSelect,
  });
}

export async function clearCurrentSession(client: PrismaClientLike = prisma) {
  return client.academicSession.updateMany({
    where: { isCurrent: true },
    data: { isCurrent: false },
  });
}

