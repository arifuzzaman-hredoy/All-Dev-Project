/**
 * Represents the envelope every API route returns to keep clients predictable.
 */
export interface ApiResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
}

export type ThemeColors = Record<string, string>
