This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.

## Theme customization

- The landing page now ships with a `ThemeManager` panel that lets super admins update the shared palette without touching the code.
- Clients sign in via `POST /api/v1/auth/login` with `email` and `password`; the response includes a JWT that must be sent as `Authorization: Bearer <token>` on every theme request. The seeded super admin credentials are `mahialamazad.bd@gmail.com` / `12345678` so you can experiment immediately.
- To sign out, hit `POST /api/v1/auth/logout` with the same Authorization header; the endpoint simply validates your token before you drop it on the client.
- Forgot your password? Call `POST /api/v1/auth/forgot-password` with the registered email and you will receive instructions shortly (the dev server logs a debug token while running locally).
- Reset links land users on `GET /reset-password?token=<token>` where they can choose a new password; the form sends the token plus the new password to `POST /api/v1/auth/reset-password` so you can wire up a customer-facing email provider via the SMTP env vars documented below.
- Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `SMTP_FROM` for real deliveries; otherwise the handler simply logs the reset link so developers can copy it from the server logs.
- Super admins call `PATCH /api/v1/theme/global` with the payload below while sending `Authorization: Bearer <token>` so the header proves their `Role.SUPER_ADMIN` identity:
  ```json
  {
    "primaryColor": "#123abc",
    "accentColor": "#f97316",
    "backgroundColor": "#f8fafc",
    "textColor": "#0f172a",
    "isDarkMode": false
  }
  ```
- Each user reads or overrides their palette via `GET|PATCH /api/v1/theme/user` with the same Authorization header; the backend derives the user id from the JWT, so the API works the same way for web and mobile clients.
- The UI applies the selected colours to the CSS custom properties (`--primary`, `--accent`, `--background`, `--foreground`) and works alongside the existing dark/light toggle.

## Planning workflow

- Feature work should start with a short plan under [`plan/`](plan/).
- Keep plans focused on scope, affected files, dependencies, and verification before implementation begins.
