# Feature Plan

## Goal

Describe the user-facing outcome and why it matters.

## Scope

List what is included and what is explicitly out of scope.

## Relevant Files

- `path/to/file` — what will be changed or reused

## Dependencies

List upstream decisions, data shape changes, or services this work depends on.

## Risks

Note likely regressions, edge cases, or migration concerns.

## Verification

Describe the tests, commands, or manual checks that will prove the change works.
