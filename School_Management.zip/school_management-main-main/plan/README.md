# Plan

Use this folder to prepare feature work before implementation.

Suggested structure:

- `plan/features/` for feature-specific plans
- `plan/templates/` for reusable plan templates

Keep each plan short and actionable. A good plan should include the goal, scope, relevant files, dependencies, risks, and verification steps.
