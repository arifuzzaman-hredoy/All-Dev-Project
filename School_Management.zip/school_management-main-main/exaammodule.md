# Exam Module ব্যবহারবিধি

এই ডকুমেন্টে School ERP-এর exam module কীভাবে কাজ করে, কারা কীভাবে ব্যবহার করবে, এবং পুরো ডাটা ফ্লো কীভাবে চলে তা Bangla ভাষায় লেখা হলো।

## ১) মডিউলের লক্ষ্য

Exam module-এর উদ্দেশ্য হলো স্কুলের পরীক্ষার পরিকল্পনা, ক্লাস assignment, result visibility, এবং শিক্ষক/অভিভাবক/শিক্ষার্থীর জন্য exam-related workflow এক জায়গায় রাখা।

এই মডিউলে মূলত চারটি কাজ হয়:

1. Admin নতুন exam তৈরি করে।
2. Admin exam list search, edit, archive, এবং manage করে।
3. Teacher live database থেকে exam নির্বাচন করে result তৈরি করে।
4. Student/Parent নির্দিষ্ট visibility rule অনুযায়ী exam/result দেখতে পারে।

## ২) কারা এই মডিউল ব্যবহার করবে

- Super Admin
- Admin
- Academic Admin
- Teacher
- Student
- Parent

## ৩) Admin side ব্যবহার

### ৩.১ Dashboard

Admin exam section-এ গেলে প্রথমে dashboard page খুলবে: `/admin/academic/exams`

এই page থেকে দুটি প্রধান entry point পাওয়া যায়:

- `Create Exam`
- `Show / Edit Exams`

Sidebar-এও এই দুইটি আলাদা submenu হিসেবে আছে, যাতে user সরাসরি প্রয়োজনীয় page-এ যেতে পারে।

### ৩.২ Create Exam

Route: `/admin/academic/exams/create`

এই page-এ admin নতুন exam তৈরি করে। ফর্মের ব্যবহার:

- Exam name লিখবে
- Exam code দেবে
- Exam date নির্ধারণ করবে
- Academic year দেবে
- Description দিতে পারবে
- Exam type fixed list থেকে বাছাই করবে
- এক বা একাধিক class assign করবে
- Visibility ঠিক করবে
- Result generate করার ফ্ল্যাগ সেট করবে
- Publish/lock-related option ঠিক করবে

#### Create page-এ গুরুত্বপূর্ণ নিয়ম

- Exam type fixed enum-based list থেকে আসবে
- Grading policy নেই
- Primary class আলাদা visible selector হিসেবে দেখানো হয় না
- অন্তত একটি class দিতে হবে
- Exam code duplicate হতে পারবে না
- একই academic year-এ একই class-এর জন্য একই নামের exam তৈরি করা যাবে না

#### Create flow

1. Page খুললে API থেকে class list এবং exam type list লোড হয়।
2. Admin form পূরণ করে।
3. Submit করলে request যায় `/api/v1/exams` এ।
4. Server validation হয়।
5. Prisma database-এ exam record তৈরি হয়।
6. Exam-এর সাথে class assignment record তৈরি হয়।
7. Admin success হলে `/admin/academic/exams/show` page-এ যায়।

### ৩.৩ Show / Edit Exams

Route: `/admin/academic/exams/show`

এই page-এ exam management panel থাকে। এখানে admin করতে পারবে:

- সব exam list দেখা
- search করা
- exam category / type অনুযায়ী filter করা
- class অনুযায়ী filter করা
- status অনুযায়ী filter করা
- exam edit করা
- archive বা lifecycle change করা
- subject assignment manage করা
- teacher assignment manage করা
- history দেখা

#### Show page-এর কাজ

এখানে মূল focus হলো exam administration। Admin সহজে বুঝতে পারবে কোন exam draft, কোনটা published, কোনটা archived, আর কোনটা result published অবস্থায় আছে।

### ৩.৪ Exam lifecycle

Exam সাধারণত এই অবস্থাগুলোর মধ্যে থাকে:

- Draft
- Assigned
- Published
- Result Published
- Archived

#### Lifecycle অর্থ

- Draft: exam তৈরি হয়েছে, কিন্তু publish হয়নি
- Assigned: class assignment দেওয়া হয়েছে
- Published: student/parent/teacher visibility on হয়েছে
- Result Published: result প্রকাশ করা হয়েছে
- Archived: পুরনো বা বন্ধ exam হিসেবে রাখা হয়েছে

## ৪) Teacher side ব্যবহার

### ৪.১ Result create page

Teacher result create page exam list database থেকে live আসে।

Teacher যখন result তৈরি করবে, তখন exam dropdown-এ শুধু hardcoded list থাকবে না। Live data অনুযায়ী exam দেখাবে।

#### Teacher কীভাবে exam পাবে

Teacher portal exam list এ এই দুটো source ব্যবহার করে:

- Primary class match
- Class assignment table-এর মাধ্যমে assigned exam

অর্থাৎ teacher যেই class নিয়ে কাজ করছে, সেই class-এর সাথে যুক্ত exam list dynamically দেখাবে।

#### Teacher flow

1. Teacher class select করে।
2. Subject select করে।
3. Exam select করে।
4. Result entry দেয়।
5. Submit করলে result service exam/class/subject validation করে।

## ৫) Student এবং Parent side ব্যবহার

Student এবং Parent সাধারণত exam তৈরি করে না। তারা শুধু visibility অনুযায়ী exam/result দেখতে পারে।

### Student/Parent কী দেখতে পারে

- Published exam list
- Result published হলে result
- Visibility flag অনুযায়ী নির্দিষ্ট তথ্য

### Visibility rule

Admin exam create বা update করার সময় এই flags set করতে পারে:

- Visible to students
- Visible to parents
- Visible to teachers

এই flags অনুযায়ী portal-এ data দেখানো হয়।

## ৬) API flow

### ৬.১ Exam list and create

- `GET /api/v1/exams`
  - exam workspace data দেয়
  - class list দেয়
  - exam type list দেয়
  - stats দেয়

- `POST /api/v1/exams`
  - নতুন exam create করে
  - class assignment তৈরি করে

### ৬.২ Single exam

- `GET /api/v1/exams/[id]`
- `PATCH /api/v1/exams/[id]`
- `DELETE /api/v1/exams/[id]`

### ৬.৩ Additional exam management

- class assignment manage
- subject assignment manage
- teacher assignment manage
- history view

## ৭) Validation rule

এই মডিউলে validation খুব গুরুত্বপূর্ণ। বর্তমান rules হলো:

1. Exam name required
2. Exam code required এবং unique
3. Exam date required
4. Academic year required
5. At least one class required
6. Exam type fixed enum list থেকে আসবে
7. একই class এবং academic year-এ duplicate exam name allowed নয়
8. Selected class অবশ্যই database-এ exist করতে হবে
9. Selected subject অবশ্যই selected class-এর সাথে match করতে হবে

## ৮) Exam type কীভাবে কাজ করে

Exam type এখন fixed selectable list হিসেবে কাজ করে। Admin dashboard থেকে upload বা choose করা যায়, কিন্তু এটা grading policy-এর সাথে tied নয়।

Available type উদাহরণ:

- Monthly Exam
- Class Test
- Mid Term
- Final Exam
- Assessment
- Viva
- Practical
- Model Test

## ৯) Data flow summary

পুরো flow সাধারণভাবে এভাবে চলে:

1. Admin form submit করে
2. API request যায়
3. Zod validation হয়
4. Service layer business rule check করে
5. Repository layer database access করে
6. Prisma দিয়ে data save/update হয়
7. History এবং audit log update হয়
8. Teacher/Student/Parent portal অনুযায়ী data consume করে

## ১০) Route map

### Admin pages

- `/admin/academic/exams`
- `/admin/academic/exams/create`
- `/admin/academic/exams/show`

### APIs

- `/api/v1/exams`
- `/api/v1/exams/[id]`

### Related portal flow

- Teacher result create page exam select করে live data থেকে
- Student/Parent portal published exam/result দেখে

## ১১) Use case example

### Example ১: নতুন exam তৈরি

1. Admin `Create Exam` এ যায়।
2. Exam name দেয়: `Monthly Exam`
3. Exam code দেয়: `MTH-2026-01`
4. Date দেয়
5. Exam type হিসেবে `Monthly Exam` select করে
6. Class assign করে
7. Submit করে
8. System exam create করে

### Example ২: Teacher result entry

1. Teacher result create page খোলে।
2. Class select করে।
3. System ওই class-এর জন্য available exam list দেখায়।
4. Teacher exam select করে result দেয়।
5. Submit করলে result save হয়।

### Example ৩: Exam search and edit

1. Admin `Show / Edit Exams` page খোলে।
2. Exam type বা class দিয়ে search করে।
3. Exam detail খোলে।
4. প্রয়োজন হলে update করে।
5. History record হয়ে যায়।

## ১২) সংক্ষিপ্ত সারাংশ

এই exam module-এর মূল শক্তি হলো:

- Admin-friendly create/show split
- Fixed exam type list
- No grading policy complexity
- Dynamic teacher exam loading
- Class assignment ভিত্তিক workflow
- Search, edit, and history support

এর ফলে exam lifecycle আরও পরিষ্কার, শিক্ষক workflow আরও dynamic, আর admin management আরও সহজ হয়।
