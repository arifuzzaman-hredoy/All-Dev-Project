# Summary

Date : 2026-04-15 22:00:40

Directory /home/mahi/github_p/school_erp/src

Total : 307 files,  32326 codes, 123 comments, 3054 blanks, all 35503 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript JSX | 138 | 19,402 | 53 | 1,648 | 21,103 |
| TypeScript | 168 | 12,800 | 70 | 1,401 | 14,271 |
| PostCSS | 1 | 124 | 0 | 5 | 129 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 307 | 32,326 | 123 | 3,054 | 35,503 |
| app | 151 | 10,826 | 27 | 1,034 | 11,887 |
| app (Files) | 3 | 198 | 0 | 20 | 218 |
| app/(panel) | 38 | 5,228 | 15 | 458 | 5,701 |
| app/(panel)/parent | 10 | 1,126 | 0 | 77 | 1,203 |
| app/(panel)/parent (Files) | 2 | 132 | 0 | 10 | 142 |
| app/(panel)/parent/attendance | 1 | 57 | 0 | 7 | 64 |
| app/(panel)/parent/children | 2 | 386 | 0 | 17 | 403 |
| app/(panel)/parent/children (Files) | 1 | 44 | 0 | 6 | 50 |
| app/(panel)/parent/children/[id] | 1 | 342 | 0 | 11 | 353 |
| app/(panel)/parent/fees | 1 | 266 | 0 | 16 | 282 |
| app/(panel)/parent/notices | 1 | 56 | 0 | 6 | 62 |
| app/(panel)/parent/profile | 1 | 48 | 0 | 6 | 54 |
| app/(panel)/parent/results | 1 | 86 | 0 | 7 | 93 |
| app/(panel)/parent/settings | 1 | 95 | 0 | 8 | 103 |
| app/(panel)/student | 9 | 1,161 | 8 | 146 | 1,315 |
| app/(panel)/student (Files) | 2 | 200 | 2 | 22 | 224 |
| app/(panel)/student/attendance | 1 | 149 | 0 | 22 | 171 |
| app/(panel)/student/fees | 1 | 304 | 0 | 23 | 327 |
| app/(panel)/student/notices | 1 | 100 | 0 | 13 | 113 |
| app/(panel)/student/profile | 1 | 106 | 0 | 13 | 119 |
| app/(panel)/student/results | 1 | 129 | 0 | 14 | 143 |
| app/(panel)/student/routine | 1 | 104 | 0 | 16 | 120 |
| app/(panel)/student/settings | 1 | 69 | 6 | 23 | 98 |
| app/(panel)/teacher | 19 | 2,941 | 7 | 235 | 3,183 |
| app/(panel)/teacher (Files) | 2 | 244 | 7 | 30 | 281 |
| app/(panel)/teacher/attendance | 4 | 667 | 0 | 53 | 720 |
| app/(panel)/teacher/attendance (Files) | 1 | 48 | 0 | 4 | 52 |
| app/(panel)/teacher/attendance/take | 1 | 284 | 0 | 23 | 307 |
| app/(panel)/teacher/attendance/view | 2 | 335 | 0 | 26 | 361 |
| app/(panel)/teacher/attendance/view (Files) | 1 | 224 | 0 | 13 | 237 |
| app/(panel)/teacher/attendance/view/[id] | 1 | 111 | 0 | 13 | 124 |
| app/(panel)/teacher/notices | 2 | 159 | 0 | 17 | 176 |
| app/(panel)/teacher/notices (Files) | 1 | 75 | 0 | 9 | 84 |
| app/(panel)/teacher/notices/create | 1 | 84 | 0 | 8 | 92 |
| app/(panel)/teacher/results | 3 | 485 | 0 | 28 | 513 |
| app/(panel)/teacher/results (Files) | 1 | 46 | 0 | 4 | 50 |
| app/(panel)/teacher/results/create | 1 | 248 | 0 | 13 | 261 |
| app/(panel)/teacher/results/view | 1 | 191 | 0 | 11 | 202 |
| app/(panel)/teacher/settings | 1 | 265 | 0 | 15 | 280 |
| app/(panel)/teacher/students | 6 | 1,027 | 0 | 81 | 1,108 |
| app/(panel)/teacher/students (Files) | 2 | 386 | 0 | 24 | 410 |
| app/(panel)/teacher/students/[id] | 2 | 233 | 0 | 26 | 259 |
| app/(panel)/teacher/students/[id] (Files) | 1 | 135 | 0 | 15 | 150 |
| app/(panel)/teacher/students/[id]/attendance | 1 | 98 | 0 | 11 | 109 |
| app/(panel)/teacher/students/view | 2 | 408 | 0 | 31 | 439 |
| app/(panel)/teacher/students/view (Files) | 1 | 182 | 0 | 15 | 197 |
| app/(panel)/teacher/students/view/[id] | 1 | 226 | 0 | 16 | 242 |
| app/(panel)/teacher/timetable | 1 | 94 | 0 | 11 | 105 |
| app/(protected) | 3 | 678 | 0 | 50 | 728 |
| app/(protected)/admission | 3 | 678 | 0 | 50 | 728 |
| app/(public) | 1 | 73 | 0 | 4 | 77 |
| app/(public)/gallery | 1 | 73 | 0 | 4 | 77 |
| app/admin | 23 | 1,144 | 0 | 108 | 1,252 |
| app/admin (Files) | 2 | 40 | 0 | 8 | 48 |
| app/admin/academic | 4 | 36 | 0 | 8 | 44 |
| app/admin/academic (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/academic/attendance | 1 | 9 | 0 | 2 | 11 |
| app/admin/academic/exams | 1 | 9 | 0 | 2 | 11 |
| app/admin/academic/results | 1 | 9 | 0 | 2 | 11 |
| app/admin/admissions | 1 | 9 | 0 | 2 | 11 |
| app/admin/classes | 1 | 9 | 0 | 2 | 11 |
| app/admin/dashboard | 1 | 222 | 0 | 15 | 237 |
| app/admin/fees | 7 | 338 | 0 | 30 | 368 |
| app/admin/fees (Files) | 1 | 33 | 0 | 2 | 35 |
| app/admin/fees/categories | 1 | 9 | 0 | 2 | 11 |
| app/admin/fees/monthly | 1 | 9 | 0 | 2 | 11 |
| app/admin/fees/payments | 3 | 86 | 0 | 10 | 96 |
| app/admin/fees/payments (Files) | 1 | 64 | 0 | 4 | 68 |
| app/admin/fees/payments/monthly | 1 | 11 | 0 | 3 | 14 |
| app/admin/fees/payments/secondary | 1 | 11 | 0 | 3 | 14 |
| app/admin/fees/reports | 1 | 201 | 0 | 14 | 215 |
| app/admin/notices | 1 | 9 | 0 | 2 | 11 |
| app/admin/parents | 1 | 9 | 0 | 2 | 11 |
| app/admin/settings | 1 | 436 | 0 | 31 | 467 |
| app/admin/students | 1 | 9 | 0 | 2 | 11 |
| app/admin/subjects | 1 | 9 | 0 | 2 | 11 |
| app/admin/teachers | 1 | 9 | 0 | 2 | 11 |
| app/admin/users | 1 | 9 | 0 | 2 | 11 |
| app/api | 78 | 2,943 | 12 | 316 | 3,271 |
| app/api/send | 1 | 141 | 4 | 16 | 161 |
| app/api/v1 | 77 | 2,802 | 8 | 300 | 3,110 |
| app/api/v1/admin | 1 | 16 | 0 | 2 | 18 |
| app/api/v1/admin/dashboard | 1 | 16 | 0 | 2 | 18 |
| app/api/v1/admissions | 2 | 82 | 0 | 12 | 94 |
| app/api/v1/admissions (Files) | 1 | 46 | 0 | 7 | 53 |
| app/api/v1/admissions/[id] | 1 | 36 | 0 | 5 | 41 |
| app/api/v1/attendance | 3 | 103 | 0 | 9 | 112 |
| app/api/v1/attendance (Files) | 1 | 46 | 0 | 3 | 49 |
| app/api/v1/attendance/class | 1 | 29 | 0 | 3 | 32 |
| app/api/v1/attendance/class/[classId] | 1 | 29 | 0 | 3 | 32 |
| app/api/v1/attendance/student | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/attendance/student/[studentId] | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/audit-logs | 1 | 55 | 0 | 6 | 61 |
| app/api/v1/auth | 8 | 160 | 0 | 25 | 185 |
| app/api/v1/auth/forgot-password | 1 | 14 | 0 | 2 | 16 |
| app/api/v1/auth/login | 1 | 17 | 0 | 2 | 19 |
| app/api/v1/auth/logout | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/auth/me | 1 | 17 | 0 | 4 | 21 |
| app/api/v1/auth/refresh | 1 | 20 | 0 | 5 | 25 |
| app/api/v1/auth/register | 1 | 21 | 0 | 3 | 24 |
| app/api/v1/auth/reset-password | 1 | 20 | 0 | 2 | 22 |
| app/api/v1/auth/session | 1 | 28 | 0 | 5 | 33 |
| app/api/v1/classes | 2 | 105 | 0 | 8 | 113 |
| app/api/v1/classes (Files) | 1 | 52 | 0 | 4 | 56 |
| app/api/v1/classes/[id] | 1 | 53 | 0 | 4 | 57 |
| app/api/v1/exams | 2 | 132 | 0 | 18 | 150 |
| app/api/v1/exams (Files) | 1 | 36 | 0 | 3 | 39 |
| app/api/v1/exams/[id] | 1 | 96 | 0 | 15 | 111 |
| app/api/v1/fees | 5 | 236 | 2 | 19 | 257 |
| app/api/v1/fees/categories | 2 | 101 | 2 | 7 | 110 |
| app/api/v1/fees/categories (Files) | 1 | 38 | 0 | 3 | 41 |
| app/api/v1/fees/categories/[id] | 1 | 63 | 2 | 4 | 69 |
| app/api/v1/fees/monthly | 1 | 39 | 0 | 5 | 44 |
| app/api/v1/fees/payments | 2 | 96 | 0 | 7 | 103 |
| app/api/v1/fees/payments (Files) | 1 | 48 | 0 | 3 | 51 |
| app/api/v1/fees/payments/[id] | 1 | 48 | 0 | 4 | 52 |
| app/api/v1/notices | 2 | 84 | 0 | 7 | 91 |
| app/api/v1/notices (Files) | 1 | 40 | 0 | 3 | 43 |
| app/api/v1/notices/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/notifications | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/notifications/reminders | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/parent | 11 | 390 | 0 | 37 | 427 |
| app/api/v1/parent/attendance | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/parent/children | 2 | 38 | 0 | 5 | 43 |
| app/api/v1/parent/children (Files) | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/parent/children/[id] | 1 | 20 | 0 | 3 | 23 |
| app/api/v1/parent/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/parent/fees | 2 | 119 | 0 | 10 | 129 |
| app/api/v1/parent/fees (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/parent/fees/[id] | 1 | 100 | 0 | 8 | 108 |
| app/api/v1/parent/fees/[id]/receipt | 1 | 100 | 0 | 8 | 108 |
| app/api/v1/parent/notices | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/parent/profile | 1 | 36 | 0 | 3 | 39 |
| app/api/v1/parent/results | 2 | 118 | 0 | 11 | 129 |
| app/api/v1/parent/results (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/parent/results/export | 1 | 99 | 0 | 9 | 108 |
| app/api/v1/parent/settings | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/parent/settings/password | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/parents | 3 | 114 | 0 | 11 | 125 |
| app/api/v1/parents (Files) | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/parents/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/parents/transfer-student | 1 | 31 | 0 | 4 | 35 |
| app/api/v1/reports | 1 | 113 | 0 | 8 | 121 |
| app/api/v1/reports/fees | 1 | 113 | 0 | 8 | 121 |
| app/api/v1/results | 4 | 132 | 0 | 13 | 145 |
| app/api/v1/results (Files) | 1 | 42 | 0 | 3 | 45 |
| app/api/v1/results/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/results/exam | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/exam/[examId] | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/student | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/student/[studentId] | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/student | 7 | 126 | 0 | 14 | 140 |
| app/api/v1/student/attendance | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/fees | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/notices | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/profile | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/results | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/timetable | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/students | 2 | 106 | 0 | 15 | 121 |
| app/api/v1/students (Files) | 1 | 51 | 0 | 7 | 58 |
| app/api/v1/students/[id] | 1 | 55 | 0 | 8 | 63 |
| app/api/v1/subjects | 2 | 83 | 0 | 7 | 90 |
| app/api/v1/subjects (Files) | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/subjects/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/system-settings | 1 | 40 | 0 | 7 | 47 |
| app/api/v1/teacher | 9 | 243 | 0 | 23 | 266 |
| app/api/v1/teacher-subjects | 2 | 93 | 0 | 7 | 100 |
| app/api/v1/teacher-subjects (Files) | 1 | 46 | 0 | 3 | 49 |
| app/api/v1/teacher-subjects/[id] | 1 | 47 | 0 | 4 | 51 |
| app/api/v1/teacher/attendance | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/teacher/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teacher/notices | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teacher/results | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/teacher/settings | 2 | 57 | 0 | 5 | 62 |
| app/api/v1/teacher/settings (Files) | 1 | 34 | 0 | 3 | 37 |
| app/api/v1/teacher/settings/password | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/teacher/students | 2 | 54 | 0 | 6 | 60 |
| app/api/v1/teacher/students (Files) | 1 | 32 | 0 | 3 | 35 |
| app/api/v1/teacher/students/[id] | 1 | 22 | 0 | 3 | 25 |
| app/api/v1/teacher/timetable | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teachers | 2 | 96 | 0 | 15 | 111 |
| app/api/v1/teachers (Files) | 1 | 45 | 0 | 7 | 52 |
| app/api/v1/teachers/[id] | 1 | 51 | 0 | 8 | 59 |
| app/api/v1/theme | 2 | 56 | 6 | 11 | 73 |
| app/api/v1/theme/global | 1 | 28 | 6 | 3 | 37 |
| app/api/v1/theme/user | 1 | 28 | 0 | 8 | 36 |
| app/api/v1/timetable | 2 | 95 | 0 | 7 | 102 |
| app/api/v1/timetable (Files) | 1 | 47 | 0 | 3 | 50 |
| app/api/v1/timetable/[id] | 1 | 48 | 0 | 4 | 52 |
| app/api/v1/users | 2 | 114 | 0 | 16 | 130 |
| app/api/v1/users (Files) | 1 | 63 | 0 | 8 | 71 |
| app/api/v1/users/[id] | 1 | 51 | 0 | 8 | 59 |
| app/dashboard | 1 | 4 | 0 | 2 | 6 |
| app/login | 1 | 88 | 0 | 12 | 100 |
| app/register | 1 | 243 | 0 | 32 | 275 |
| app/reset-password | 1 | 116 | 0 | 16 | 132 |
| app/send-email | 1 | 111 | 0 | 16 | 127 |
| components | 66 | 11,753 | 38 | 937 | 12,728 |
| components (Files) | 24 | 2,109 | 21 | 159 | 2,289 |
| components/admin | 18 | 7,276 | 5 | 535 | 7,816 |
| components/gallery | 1 | 48 | 2 | 6 | 56 |
| components/teacher | 2 | 57 | 0 | 8 | 65 |
| components/ui | 21 | 2,263 | 10 | 229 | 2,502 |
| constants | 4 | 178 | 6 | 16 | 200 |
| emails | 1 | 70 | 0 | 4 | 74 |
| hooks | 1 | 15 | 0 | 5 | 20 |
| lib | 9 | 460 | 25 | 80 | 565 |
| repositories | 20 | 2,249 | 0 | 197 | 2,446 |
| services | 26 | 6,002 | 5 | 643 | 6,650 |
| types | 4 | 6 | 3 | 5 | 14 |
| utils | 6 | 179 | 19 | 36 | 234 |
| validations | 19 | 588 | 0 | 97 | 685 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)