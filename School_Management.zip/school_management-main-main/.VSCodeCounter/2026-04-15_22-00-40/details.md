# Details

Date : 2026-04-15 22:00:40

Directory /home/mahi/github_p/school_erp/src

Total : 307 files,  32326 codes, 123 comments, 3054 blanks, all 35503 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/app/(panel)/parent/attendance/page.tsx](/src/app/(panel)/parent/attendance/page.tsx) | TypeScript JSX | 57 | 0 | 7 | 64 |
| [src/app/(panel)/parent/children/\[id\]/page.tsx](/src/app/(panel)/parent/children/%5Bid%5D/page.tsx) | TypeScript JSX | 342 | 0 | 11 | 353 |
| [src/app/(panel)/parent/children/page.tsx](/src/app/(panel)/parent/children/page.tsx) | TypeScript JSX | 44 | 0 | 6 | 50 |
| [src/app/(panel)/parent/fees/page.tsx](/src/app/(panel)/parent/fees/page.tsx) | TypeScript JSX | 266 | 0 | 16 | 282 |
| [src/app/(panel)/parent/layout.tsx](/src/app/(panel)/parent/layout.tsx) | TypeScript JSX | 25 | 0 | 4 | 29 |
| [src/app/(panel)/parent/notices/page.tsx](/src/app/(panel)/parent/notices/page.tsx) | TypeScript JSX | 56 | 0 | 6 | 62 |
| [src/app/(panel)/parent/page.tsx](/src/app/(panel)/parent/page.tsx) | TypeScript JSX | 107 | 0 | 6 | 113 |
| [src/app/(panel)/parent/profile/page.tsx](/src/app/(panel)/parent/profile/page.tsx) | TypeScript JSX | 48 | 0 | 6 | 54 |
| [src/app/(panel)/parent/results/page.tsx](/src/app/(panel)/parent/results/page.tsx) | TypeScript JSX | 86 | 0 | 7 | 93 |
| [src/app/(panel)/parent/settings/page.tsx](/src/app/(panel)/parent/settings/page.tsx) | TypeScript JSX | 95 | 0 | 8 | 103 |
| [src/app/(panel)/student/attendance/page.tsx](/src/app/(panel)/student/attendance/page.tsx) | TypeScript JSX | 149 | 0 | 22 | 171 |
| [src/app/(panel)/student/fees/page.tsx](/src/app/(panel)/student/fees/page.tsx) | TypeScript JSX | 304 | 0 | 23 | 327 |
| [src/app/(panel)/student/layout.tsx](/src/app/(panel)/student/layout.tsx) | TypeScript JSX | 31 | 2 | 8 | 41 |
| [src/app/(panel)/student/notices/page.tsx](/src/app/(panel)/student/notices/page.tsx) | TypeScript JSX | 100 | 0 | 13 | 113 |
| [src/app/(panel)/student/page.tsx](/src/app/(panel)/student/page.tsx) | TypeScript JSX | 169 | 0 | 14 | 183 |
| [src/app/(panel)/student/profile/page.tsx](/src/app/(panel)/student/profile/page.tsx) | TypeScript JSX | 106 | 0 | 13 | 119 |
| [src/app/(panel)/student/results/page.tsx](/src/app/(panel)/student/results/page.tsx) | TypeScript JSX | 129 | 0 | 14 | 143 |
| [src/app/(panel)/student/routine/page.tsx](/src/app/(panel)/student/routine/page.tsx) | TypeScript JSX | 104 | 0 | 16 | 120 |
| [src/app/(panel)/student/settings/page.tsx](/src/app/(panel)/student/settings/page.tsx) | TypeScript JSX | 69 | 6 | 23 | 98 |
| [src/app/(panel)/teacher/attendance/page.tsx](/src/app/(panel)/teacher/attendance/page.tsx) | TypeScript JSX | 48 | 0 | 4 | 52 |
| [src/app/(panel)/teacher/attendance/take/page.tsx](/src/app/(panel)/teacher/attendance/take/page.tsx) | TypeScript JSX | 284 | 0 | 23 | 307 |
| [src/app/(panel)/teacher/attendance/view/\[id\]/page.tsx](/src/app/(panel)/teacher/attendance/view/%5Bid%5D/page.tsx) | TypeScript JSX | 111 | 0 | 13 | 124 |
| [src/app/(panel)/teacher/attendance/view/page.tsx](/src/app/(panel)/teacher/attendance/view/page.tsx) | TypeScript JSX | 224 | 0 | 13 | 237 |
| [src/app/(panel)/teacher/layout.tsx](/src/app/(panel)/teacher/layout.tsx) | TypeScript JSX | 31 | 7 | 11 | 49 |
| [src/app/(panel)/teacher/notices/create/page.tsx](/src/app/(panel)/teacher/notices/create/page.tsx) | TypeScript JSX | 84 | 0 | 8 | 92 |
| [src/app/(panel)/teacher/notices/page.tsx](/src/app/(panel)/teacher/notices/page.tsx) | TypeScript JSX | 75 | 0 | 9 | 84 |
| [src/app/(panel)/teacher/page.tsx](/src/app/(panel)/teacher/page.tsx) | TypeScript JSX | 213 | 0 | 19 | 232 |
| [src/app/(panel)/teacher/results/create/page.tsx](/src/app/(panel)/teacher/results/create/page.tsx) | TypeScript JSX | 248 | 0 | 13 | 261 |
| [src/app/(panel)/teacher/results/page.tsx](/src/app/(panel)/teacher/results/page.tsx) | TypeScript JSX | 46 | 0 | 4 | 50 |
| [src/app/(panel)/teacher/results/view/page.tsx](/src/app/(panel)/teacher/results/view/page.tsx) | TypeScript JSX | 191 | 0 | 11 | 202 |
| [src/app/(panel)/teacher/settings/page.tsx](/src/app/(panel)/teacher/settings/page.tsx) | TypeScript JSX | 265 | 0 | 15 | 280 |
| [src/app/(panel)/teacher/students/\[id\]/attendance/page.tsx](/src/app/(panel)/teacher/students/%5Bid%5D/attendance/page.tsx) | TypeScript JSX | 98 | 0 | 11 | 109 |
| [src/app/(panel)/teacher/students/\[id\]/page.tsx](/src/app/(panel)/teacher/students/%5Bid%5D/page.tsx) | TypeScript JSX | 135 | 0 | 15 | 150 |
| [src/app/(panel)/teacher/students/data.ts](/src/app/(panel)/teacher/students/data.ts) | TypeScript | 180 | 0 | 6 | 186 |
| [src/app/(panel)/teacher/students/page.tsx](/src/app/(panel)/teacher/students/page.tsx) | TypeScript JSX | 206 | 0 | 18 | 224 |
| [src/app/(panel)/teacher/students/view/\[id\]/page.tsx](/src/app/(panel)/teacher/students/view/%5Bid%5D/page.tsx) | TypeScript JSX | 226 | 0 | 16 | 242 |
| [src/app/(panel)/teacher/students/view/page.tsx](/src/app/(panel)/teacher/students/view/page.tsx) | TypeScript JSX | 182 | 0 | 15 | 197 |
| [src/app/(panel)/teacher/timetable/page.tsx](/src/app/(panel)/teacher/timetable/page.tsx) | TypeScript JSX | 94 | 0 | 11 | 105 |
| [src/app/(protected)/admission/admission-form.tsx](/src/app/(protected)/admission/admission-form.tsx) | TypeScript JSX | 650 | 0 | 39 | 689 |
| [src/app/(protected)/admission/layout.tsx](/src/app/(protected)/admission/layout.tsx) | TypeScript JSX | 16 | 0 | 5 | 21 |
| [src/app/(protected)/admission/page.tsx](/src/app/(protected)/admission/page.tsx) | TypeScript JSX | 12 | 0 | 6 | 18 |
| [src/app/(public)/gallery/page.tsx](/src/app/(public)/gallery/page.tsx) | TypeScript JSX | 73 | 0 | 4 | 77 |
| [src/app/admin/academic/attendance/page.tsx](/src/app/admin/academic/attendance/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/academic/exams/page.tsx](/src/app/admin/academic/exams/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/academic/page.tsx](/src/app/admin/academic/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/academic/results/page.tsx](/src/app/admin/academic/results/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/admissions/page.tsx](/src/app/admin/admissions/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/classes/page.tsx](/src/app/admin/classes/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/dashboard/page.tsx](/src/app/admin/dashboard/page.tsx) | TypeScript JSX | 222 | 0 | 15 | 237 |
| [src/app/admin/fees/categories/page.tsx](/src/app/admin/fees/categories/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/fees/monthly/page.tsx](/src/app/admin/fees/monthly/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/fees/page.tsx](/src/app/admin/fees/page.tsx) | TypeScript JSX | 33 | 0 | 2 | 35 |
| [src/app/admin/fees/payments/monthly/page.tsx](/src/app/admin/fees/payments/monthly/page.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/app/admin/fees/payments/page.tsx](/src/app/admin/fees/payments/page.tsx) | TypeScript JSX | 64 | 0 | 4 | 68 |
| [src/app/admin/fees/payments/secondary/page.tsx](/src/app/admin/fees/payments/secondary/page.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/app/admin/fees/reports/page.tsx](/src/app/admin/fees/reports/page.tsx) | TypeScript JSX | 201 | 0 | 14 | 215 |
| [src/app/admin/layout.tsx](/src/app/admin/layout.tsx) | TypeScript JSX | 36 | 0 | 6 | 42 |
| [src/app/admin/notices/page.tsx](/src/app/admin/notices/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/page.tsx](/src/app/admin/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/parents/page.tsx](/src/app/admin/parents/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/settings/page.tsx](/src/app/admin/settings/page.tsx) | TypeScript JSX | 436 | 0 | 31 | 467 |
| [src/app/admin/students/page.tsx](/src/app/admin/students/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/subjects/page.tsx](/src/app/admin/subjects/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/teachers/page.tsx](/src/app/admin/teachers/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/users/page.tsx](/src/app/admin/users/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/api/send/route.ts](/src/app/api/send/route.ts) | TypeScript | 141 | 4 | 16 | 161 |
| [src/app/api/v1/admin/dashboard/route.ts](/src/app/api/v1/admin/dashboard/route.ts) | TypeScript | 16 | 0 | 2 | 18 |
| [src/app/api/v1/admissions/\[id\]/route.ts](/src/app/api/v1/admissions/%5Bid%5D/route.ts) | TypeScript | 36 | 0 | 5 | 41 |
| [src/app/api/v1/admissions/route.ts](/src/app/api/v1/admissions/route.ts) | TypeScript | 46 | 0 | 7 | 53 |
| [src/app/api/v1/attendance/class/\[classId\]/route.ts](/src/app/api/v1/attendance/class/%5BclassId%5D/route.ts) | TypeScript | 29 | 0 | 3 | 32 |
| [src/app/api/v1/attendance/route.ts](/src/app/api/v1/attendance/route.ts) | TypeScript | 46 | 0 | 3 | 49 |
| [src/app/api/v1/attendance/student/\[studentId\]/route.ts](/src/app/api/v1/attendance/student/%5BstudentId%5D/route.ts) | TypeScript | 28 | 0 | 3 | 31 |
| [src/app/api/v1/audit-logs/route.ts](/src/app/api/v1/audit-logs/route.ts) | TypeScript | 55 | 0 | 6 | 61 |
| [src/app/api/v1/auth/forgot-password/route.ts](/src/app/api/v1/auth/forgot-password/route.ts) | TypeScript | 14 | 0 | 2 | 16 |
| [src/app/api/v1/auth/login/route.ts](/src/app/api/v1/auth/login/route.ts) | TypeScript | 17 | 0 | 2 | 19 |
| [src/app/api/v1/auth/logout/route.ts](/src/app/api/v1/auth/logout/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/auth/me/route.ts](/src/app/api/v1/auth/me/route.ts) | TypeScript | 17 | 0 | 4 | 21 |
| [src/app/api/v1/auth/refresh/route.ts](/src/app/api/v1/auth/refresh/route.ts) | TypeScript | 20 | 0 | 5 | 25 |
| [src/app/api/v1/auth/register/route.ts](/src/app/api/v1/auth/register/route.ts) | TypeScript | 21 | 0 | 3 | 24 |
| [src/app/api/v1/auth/reset-password/route.ts](/src/app/api/v1/auth/reset-password/route.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [src/app/api/v1/auth/session/route.ts](/src/app/api/v1/auth/session/route.ts) | TypeScript | 28 | 0 | 5 | 33 |
| [src/app/api/v1/classes/\[id\]/route.ts](/src/app/api/v1/classes/%5Bid%5D/route.ts) | TypeScript | 53 | 0 | 4 | 57 |
| [src/app/api/v1/classes/route.ts](/src/app/api/v1/classes/route.ts) | TypeScript | 52 | 0 | 4 | 56 |
| [src/app/api/v1/exams/\[id\]/route.ts](/src/app/api/v1/exams/%5Bid%5D/route.ts) | TypeScript | 96 | 0 | 15 | 111 |
| [src/app/api/v1/exams/route.ts](/src/app/api/v1/exams/route.ts) | TypeScript | 36 | 0 | 3 | 39 |
| [src/app/api/v1/fees/categories/\[id\]/route.ts](/src/app/api/v1/fees/categories/%5Bid%5D/route.ts) | TypeScript | 63 | 2 | 4 | 69 |
| [src/app/api/v1/fees/categories/route.ts](/src/app/api/v1/fees/categories/route.ts) | TypeScript | 38 | 0 | 3 | 41 |
| [src/app/api/v1/fees/monthly/route.ts](/src/app/api/v1/fees/monthly/route.ts) | TypeScript | 39 | 0 | 5 | 44 |
| [src/app/api/v1/fees/payments/\[id\]/route.ts](/src/app/api/v1/fees/payments/%5Bid%5D/route.ts) | TypeScript | 48 | 0 | 4 | 52 |
| [src/app/api/v1/fees/payments/route.ts](/src/app/api/v1/fees/payments/route.ts) | TypeScript | 48 | 0 | 3 | 51 |
| [src/app/api/v1/notices/\[id\]/route.ts](/src/app/api/v1/notices/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/notices/route.ts](/src/app/api/v1/notices/route.ts) | TypeScript | 40 | 0 | 3 | 43 |
| [src/app/api/v1/notifications/reminders/route.ts](/src/app/api/v1/notifications/reminders/route.ts) | TypeScript | 28 | 0 | 3 | 31 |
| [src/app/api/v1/parent/attendance/route.ts](/src/app/api/v1/parent/attendance/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/parent/children/\[id\]/route.ts](/src/app/api/v1/parent/children/%5Bid%5D/route.ts) | TypeScript | 20 | 0 | 3 | 23 |
| [src/app/api/v1/parent/children/route.ts](/src/app/api/v1/parent/children/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/parent/dashboard/route.ts](/src/app/api/v1/parent/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/parent/fees/\[id\]/receipt/route.ts](/src/app/api/v1/parent/fees/%5Bid%5D/receipt/route.ts) | TypeScript | 100 | 0 | 8 | 108 |
| [src/app/api/v1/parent/fees/route.ts](/src/app/api/v1/parent/fees/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/parent/notices/route.ts](/src/app/api/v1/parent/notices/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/parent/profile/route.ts](/src/app/api/v1/parent/profile/route.ts) | TypeScript | 36 | 0 | 3 | 39 |
| [src/app/api/v1/parent/results/export/route.ts](/src/app/api/v1/parent/results/export/route.ts) | TypeScript | 99 | 0 | 9 | 108 |
| [src/app/api/v1/parent/results/route.ts](/src/app/api/v1/parent/results/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/parent/settings/password/route.ts](/src/app/api/v1/parent/settings/password/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/parents/\[id\]/route.ts](/src/app/api/v1/parents/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/parents/route.ts](/src/app/api/v1/parents/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/parents/transfer-student/route.ts](/src/app/api/v1/parents/transfer-student/route.ts) | TypeScript | 31 | 0 | 4 | 35 |
| [src/app/api/v1/reports/fees/route.ts](/src/app/api/v1/reports/fees/route.ts) | TypeScript | 113 | 0 | 8 | 121 |
| [src/app/api/v1/results/\[id\]/route.ts](/src/app/api/v1/results/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/results/exam/\[examId\]/route.ts](/src/app/api/v1/results/exam/%5BexamId%5D/route.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [src/app/api/v1/results/route.ts](/src/app/api/v1/results/route.ts) | TypeScript | 42 | 0 | 3 | 45 |
| [src/app/api/v1/results/student/\[studentId\]/route.ts](/src/app/api/v1/results/student/%5BstudentId%5D/route.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [src/app/api/v1/student/attendance/route.ts](/src/app/api/v1/student/attendance/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/dashboard/route.ts](/src/app/api/v1/student/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/fees/route.ts](/src/app/api/v1/student/fees/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/notices/route.ts](/src/app/api/v1/student/notices/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/profile/route.ts](/src/app/api/v1/student/profile/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/results/route.ts](/src/app/api/v1/student/results/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/timetable/route.ts](/src/app/api/v1/student/timetable/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/students/\[id\]/route.ts](/src/app/api/v1/students/%5Bid%5D/route.ts) | TypeScript | 55 | 0 | 8 | 63 |
| [src/app/api/v1/students/route.ts](/src/app/api/v1/students/route.ts) | TypeScript | 51 | 0 | 7 | 58 |
| [src/app/api/v1/subjects/\[id\]/route.ts](/src/app/api/v1/subjects/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/subjects/route.ts](/src/app/api/v1/subjects/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/system-settings/route.ts](/src/app/api/v1/system-settings/route.ts) | TypeScript | 40 | 0 | 7 | 47 |
| [src/app/api/v1/teacher-subjects/\[id\]/route.ts](/src/app/api/v1/teacher-subjects/%5Bid%5D/route.ts) | TypeScript | 47 | 0 | 4 | 51 |
| [src/app/api/v1/teacher-subjects/route.ts](/src/app/api/v1/teacher-subjects/route.ts) | TypeScript | 46 | 0 | 3 | 49 |
| [src/app/api/v1/teacher/attendance/route.ts](/src/app/api/v1/teacher/attendance/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/teacher/dashboard/route.ts](/src/app/api/v1/teacher/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teacher/notices/route.ts](/src/app/api/v1/teacher/notices/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teacher/results/route.ts](/src/app/api/v1/teacher/results/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/teacher/settings/password/route.ts](/src/app/api/v1/teacher/settings/password/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/teacher/settings/route.ts](/src/app/api/v1/teacher/settings/route.ts) | TypeScript | 34 | 0 | 3 | 37 |
| [src/app/api/v1/teacher/students/\[id\]/route.ts](/src/app/api/v1/teacher/students/%5Bid%5D/route.ts) | TypeScript | 22 | 0 | 3 | 25 |
| [src/app/api/v1/teacher/students/route.ts](/src/app/api/v1/teacher/students/route.ts) | TypeScript | 32 | 0 | 3 | 35 |
| [src/app/api/v1/teacher/timetable/route.ts](/src/app/api/v1/teacher/timetable/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teachers/\[id\]/route.ts](/src/app/api/v1/teachers/%5Bid%5D/route.ts) | TypeScript | 51 | 0 | 8 | 59 |
| [src/app/api/v1/teachers/route.ts](/src/app/api/v1/teachers/route.ts) | TypeScript | 45 | 0 | 7 | 52 |
| [src/app/api/v1/theme/global/route.ts](/src/app/api/v1/theme/global/route.ts) | TypeScript | 28 | 6 | 3 | 37 |
| [src/app/api/v1/theme/user/route.ts](/src/app/api/v1/theme/user/route.ts) | TypeScript | 28 | 0 | 8 | 36 |
| [src/app/api/v1/timetable/\[id\]/route.ts](/src/app/api/v1/timetable/%5Bid%5D/route.ts) | TypeScript | 48 | 0 | 4 | 52 |
| [src/app/api/v1/timetable/route.ts](/src/app/api/v1/timetable/route.ts) | TypeScript | 47 | 0 | 3 | 50 |
| [src/app/api/v1/users/\[id\]/route.ts](/src/app/api/v1/users/%5Bid%5D/route.ts) | TypeScript | 51 | 0 | 8 | 59 |
| [src/app/api/v1/users/route.ts](/src/app/api/v1/users/route.ts) | TypeScript | 63 | 0 | 8 | 71 |
| [src/app/dashboard/page.tsx](/src/app/dashboard/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/globals.css](/src/app/globals.css) | PostCSS | 124 | 0 | 5 | 129 |
| [src/app/layout.tsx](/src/app/layout.tsx) | TypeScript JSX | 40 | 0 | 7 | 47 |
| [src/app/login/page.tsx](/src/app/login/page.tsx) | TypeScript JSX | 88 | 0 | 12 | 100 |
| [src/app/page.tsx](/src/app/page.tsx) | TypeScript JSX | 34 | 0 | 8 | 42 |
| [src/app/register/page.tsx](/src/app/register/page.tsx) | TypeScript JSX | 243 | 0 | 32 | 275 |
| [src/app/reset-password/page.tsx](/src/app/reset-password/page.tsx) | TypeScript JSX | 116 | 0 | 16 | 132 |
| [src/app/send-email/page.tsx](/src/app/send-email/page.tsx) | TypeScript JSX | 111 | 0 | 16 | 127 |
| [src/components/GalleryCircleGroup.tsx](/src/components/GalleryCircleGroup.tsx) | TypeScript JSX | 29 | 1 | 3 | 33 |
| [src/components/admin/academic-operations-panel.tsx](/src/components/admin/academic-operations-panel.tsx) | TypeScript JSX | 246 | 0 | 16 | 262 |
| [src/components/admin/admin-access-guard.tsx](/src/components/admin/admin-access-guard.tsx) | TypeScript JSX | 52 | 0 | 13 | 65 |
| [src/components/admin/admission-management-panel.tsx](/src/components/admin/admission-management-panel.tsx) | TypeScript JSX | 682 | 0 | 35 | 717 |
| [src/components/admin/attendance-management-panel.tsx](/src/components/admin/attendance-management-panel.tsx) | TypeScript JSX | 104 | 0 | 10 | 114 |
| [src/components/admin/class-management-panel.tsx](/src/components/admin/class-management-panel.tsx) | TypeScript JSX | 364 | 0 | 17 | 381 |
| [src/components/admin/class-monthly-fee-management-panel.tsx](/src/components/admin/class-monthly-fee-management-panel.tsx) | TypeScript JSX | 281 | 0 | 29 | 310 |
| [src/components/admin/exam-management-panel.tsx](/src/components/admin/exam-management-panel.tsx) | TypeScript JSX | 1,013 | 0 | 52 | 1,065 |
| [src/components/admin/fee-category-management-panel.tsx](/src/components/admin/fee-category-management-panel.tsx) | TypeScript JSX | 727 | 5 | 69 | 801 |
| [src/components/admin/notice-management-panel.tsx](/src/components/admin/notice-management-panel.tsx) | TypeScript JSX | 72 | 0 | 10 | 82 |
| [src/components/admin/parent-management-panel.tsx](/src/components/admin/parent-management-panel.tsx) | TypeScript JSX | 535 | 0 | 24 | 559 |
| [src/components/admin/payment-management-page.tsx](/src/components/admin/payment-management-page.tsx) | TypeScript JSX | 956 | 0 | 65 | 1,021 |
| [src/components/admin/payment-management-panel.tsx](/src/components/admin/payment-management-panel.tsx) | TypeScript JSX | 597 | 0 | 35 | 632 |
| [src/components/admin/result-management-panel.tsx](/src/components/admin/result-management-panel.tsx) | TypeScript JSX | 103 | 0 | 11 | 114 |
| [src/components/admin/section-page.tsx](/src/components/admin/section-page.tsx) | TypeScript JSX | 89 | 0 | 10 | 99 |
| [src/components/admin/student-management-panel.tsx](/src/components/admin/student-management-panel.tsx) | TypeScript JSX | 337 | 0 | 33 | 370 |
| [src/components/admin/subject-management-panel.tsx](/src/components/admin/subject-management-panel.tsx) | TypeScript JSX | 94 | 0 | 11 | 105 |
| [src/components/admin/teacher-management-panel.tsx](/src/components/admin/teacher-management-panel.tsx) | TypeScript JSX | 450 | 0 | 38 | 488 |
| [src/components/admin/user-management-panel.tsx](/src/components/admin/user-management-panel.tsx) | TypeScript JSX | 574 | 0 | 57 | 631 |
| [src/components/app-sidebar-parent.tsx](/src/components/app-sidebar-parent.tsx) | TypeScript JSX | 70 | 0 | 5 | 75 |
| [src/components/app-sidebar-student.tsx](/src/components/app-sidebar-student.tsx) | TypeScript JSX | 104 | 2 | 11 | 117 |
| [src/components/app-sidebar-teacher.tsx](/src/components/app-sidebar-teacher.tsx) | TypeScript JSX | 117 | 1 | 15 | 133 |
| [src/components/app-sidebar.tsx](/src/components/app-sidebar.tsx) | TypeScript JSX | 212 | 0 | 18 | 230 |
| [src/components/circle-path.tsx](/src/components/circle-path.tsx) | TypeScript JSX | 114 | 0 | 7 | 121 |
| [src/components/code-block.tsx](/src/components/code-block.tsx) | TypeScript JSX | 14 | 0 | 4 | 18 |
| [src/components/contact-section.tsx](/src/components/contact-section.tsx) | TypeScript JSX | 156 | 1 | 3 | 160 |
| [src/components/cta-sections-03.tsx](/src/components/cta-sections-03.tsx) | TypeScript JSX | 55 | 2 | 6 | 63 |
| [src/components/footer-01.tsx](/src/components/footer-01.tsx) | TypeScript JSX | 91 | 0 | 3 | 94 |
| [src/components/gallery/gallery-component-01.tsx](/src/components/gallery/gallery-component-01.tsx) | TypeScript JSX | 48 | 2 | 6 | 56 |
| [src/components/hero-sections-05.tsx](/src/components/hero-sections-05.tsx) | TypeScript JSX | 100 | 0 | 8 | 108 |
| [src/components/marquee-effect.tsx](/src/components/marquee-effect.tsx) | TypeScript JSX | 90 | 0 | 11 | 101 |
| [src/components/mode-toggle.tsx](/src/components/mode-toggle.tsx) | TypeScript JSX | 24 | 0 | 6 | 30 |
| [src/components/nav-main.tsx](/src/components/nav-main.tsx) | TypeScript JSX | 88 | 0 | 5 | 93 |
| [src/components/nav-projects.tsx](/src/components/nav-projects.tsx) | TypeScript JSX | 83 | 0 | 4 | 87 |
| [src/components/nav-user.tsx](/src/components/nav-user.tsx) | TypeScript JSX | 108 | 0 | 4 | 112 |
| [src/components/navbars-02.tsx](/src/components/navbars-02.tsx) | TypeScript JSX | 281 | 14 | 10 | 305 |
| [src/components/page-header.tsx](/src/components/page-header.tsx) | TypeScript JSX | 22 | 0 | 4 | 26 |
| [src/components/result-display.tsx](/src/components/result-display.tsx) | TypeScript JSX | 22 | 0 | 4 | 26 |
| [src/components/search-form.tsx](/src/components/search-form.tsx) | TypeScript JSX | 27 | 0 | 3 | 30 |
| [src/components/teacher/page-shell.tsx](/src/components/teacher/page-shell.tsx) | TypeScript JSX | 21 | 0 | 4 | 25 |
| [src/components/teacher/section-card.tsx](/src/components/teacher/section-card.tsx) | TypeScript JSX | 36 | 0 | 4 | 40 |
| [src/components/team-switcher.tsx](/src/components/team-switcher.tsx) | TypeScript JSX | 86 | 0 | 6 | 92 |
| [src/components/testimonials-03.tsx](/src/components/testimonials-03.tsx) | TypeScript JSX | 147 | 0 | 10 | 157 |
| [src/components/theme-provider.tsx](/src/components/theme-provider.tsx) | TypeScript JSX | 7 | 0 | 4 | 11 |
| [src/components/ui/avatar.tsx](/src/components/ui/avatar.tsx) | TypeScript JSX | 103 | 0 | 10 | 113 |
| [src/components/ui/badge.tsx](/src/components/ui/badge.tsx) | TypeScript JSX | 44 | 0 | 6 | 50 |
| [src/components/ui/breadcrumb.tsx](/src/components/ui/breadcrumb.tsx) | TypeScript JSX | 112 | 0 | 11 | 123 |
| [src/components/ui/button.tsx](/src/components/ui/button.tsx) | TypeScript JSX | 60 | 0 | 6 | 66 |
| [src/components/ui/card.tsx](/src/components/ui/card.tsx) | TypeScript JSX | 94 | 0 | 10 | 104 |
| [src/components/ui/checkbox.tsx](/src/components/ui/checkbox.tsx) | TypeScript JSX | 29 | 0 | 5 | 34 |
| [src/components/ui/collapsible.tsx](/src/components/ui/collapsible.tsx) | TypeScript JSX | 28 | 0 | 6 | 34 |
| [src/components/ui/dropdown-menu.tsx](/src/components/ui/dropdown-menu.tsx) | TypeScript JSX | 251 | 0 | 19 | 270 |
| [src/components/ui/input-group.tsx](/src/components/ui/input-group.tsx) | TypeScript JSX | 144 | 0 | 12 | 156 |
| [src/components/ui/input.tsx](/src/components/ui/input.tsx) | TypeScript JSX | 16 | 0 | 4 | 20 |
| [src/components/ui/label.tsx](/src/components/ui/label.tsx) | TypeScript JSX | 20 | 0 | 5 | 25 |
| [src/components/ui/navigation-menu.tsx](/src/components/ui/navigation-menu.tsx) | TypeScript JSX | 153 | 0 | 12 | 165 |
| [src/components/ui/popover.tsx](/src/components/ui/popover.tsx) | TypeScript JSX | 79 | 0 | 11 | 90 |
| [src/components/ui/select.tsx](/src/components/ui/select.tsx) | TypeScript JSX | 179 | 0 | 14 | 193 |
| [src/components/ui/separator.tsx](/src/components/ui/separator.tsx) | TypeScript JSX | 24 | 0 | 5 | 29 |
| [src/components/ui/sheet.tsx](/src/components/ui/sheet.tsx) | TypeScript JSX | 131 | 0 | 14 | 145 |
| [src/components/ui/sidebar.tsx](/src/components/ui/sidebar.tsx) | TypeScript JSX | 638 | 10 | 55 | 703 |
| [src/components/ui/skeleton.tsx](/src/components/ui/skeleton.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/components/ui/tabs.tsx](/src/components/ui/tabs.tsx) | TypeScript JSX | 82 | 0 | 9 | 91 |
| [src/components/ui/textarea.tsx](/src/components/ui/textarea.tsx) | TypeScript JSX | 15 | 0 | 4 | 19 |
| [src/components/ui/tooltip.tsx](/src/components/ui/tooltip.tsx) | TypeScript JSX | 50 | 0 | 8 | 58 |
| [src/components/version-switcher.tsx](/src/components/version-switcher.tsx) | TypeScript JSX | 62 | 0 | 5 | 67 |
| [src/constants/api.ts](/src/constants/api.ts) | TypeScript | 6 | 3 | 1 | 10 |
| [src/constants/errors.ts](/src/constants/errors.ts) | TypeScript | 5 | 3 | 1 | 9 |
| [src/constants/exam-types.ts](/src/constants/exam-types.ts) | TypeScript | 16 | 0 | 3 | 19 |
| [src/constants/roles.ts](/src/constants/roles.ts) | TypeScript | 151 | 0 | 11 | 162 |
| [src/emails/Welcome.tsx](/src/emails/Welcome.tsx) | TypeScript JSX | 70 | 0 | 4 | 74 |
| [src/hooks/use-mobile.ts](/src/hooks/use-mobile.ts) | TypeScript | 15 | 0 | 5 | 20 |
| [src/lib/auth.ts](/src/lib/auth.ts) | TypeScript | 58 | 12 | 13 | 83 |
| [src/lib/client-api.ts](/src/lib/client-api.ts) | TypeScript | 76 | 1 | 19 | 96 |
| [src/lib/fee-history.ts](/src/lib/fee-history.ts) | TypeScript | 205 | 0 | 22 | 227 |
| [src/lib/fee-utils.ts](/src/lib/fee-utils.ts) | TypeScript | 35 | 0 | 5 | 40 |
| [src/lib/permissions.ts](/src/lib/permissions.ts) | TypeScript | 25 | 9 | 5 | 39 |
| [src/lib/prisma.ts](/src/lib/prisma.ts) | TypeScript | 44 | 3 | 8 | 55 |
| [src/lib/resend.ts](/src/lib/resend.ts) | TypeScript | 4 | 0 | 4 | 8 |
| [src/lib/role-routes.ts](/src/lib/role-routes.ts) | TypeScript | 8 | 0 | 2 | 10 |
| [src/lib/utils.ts](/src/lib/utils.ts) | TypeScript | 5 | 0 | 2 | 7 |
| [src/repositories/admission.repository.ts](/src/repositories/admission.repository.ts) | TypeScript | 72 | 0 | 8 | 80 |
| [src/repositories/attendance.repository.ts](/src/repositories/attendance.repository.ts) | TypeScript | 139 | 0 | 6 | 145 |
| [src/repositories/auditLog.repository.ts](/src/repositories/auditLog.repository.ts) | TypeScript | 140 | 0 | 13 | 153 |
| [src/repositories/class.repository.ts](/src/repositories/class.repository.ts) | TypeScript | 194 | 0 | 26 | 220 |
| [src/repositories/classMonthlyFee.repository.ts](/src/repositories/classMonthlyFee.repository.ts) | TypeScript | 45 | 0 | 5 | 50 |
| [src/repositories/exam.repository.ts](/src/repositories/exam.repository.ts) | TypeScript | 240 | 0 | 11 | 251 |
| [src/repositories/feeCategory.repository.ts](/src/repositories/feeCategory.repository.ts) | TypeScript | 85 | 0 | 9 | 94 |
| [src/repositories/notice.repository.ts](/src/repositories/notice.repository.ts) | TypeScript | 83 | 0 | 9 | 92 |
| [src/repositories/notification.repository.ts](/src/repositories/notification.repository.ts) | TypeScript | 144 | 0 | 11 | 155 |
| [src/repositories/parent.repository.ts](/src/repositories/parent.repository.ts) | TypeScript | 103 | 0 | 8 | 111 |
| [src/repositories/passwordReset.repository.ts](/src/repositories/passwordReset.repository.ts) | TypeScript | 42 | 0 | 6 | 48 |
| [src/repositories/payment.repository.ts](/src/repositories/payment.repository.ts) | TypeScript | 148 | 0 | 11 | 159 |
| [src/repositories/result.repository.ts](/src/repositories/result.repository.ts) | TypeScript | 129 | 0 | 9 | 138 |
| [src/repositories/student.repository.ts](/src/repositories/student.repository.ts) | TypeScript | 129 | 0 | 11 | 140 |
| [src/repositories/subject.repository.ts](/src/repositories/subject.repository.ts) | TypeScript | 86 | 0 | 9 | 95 |
| [src/repositories/systemSetting.repository.ts](/src/repositories/systemSetting.repository.ts) | TypeScript | 73 | 0 | 7 | 80 |
| [src/repositories/teacher.repository.ts](/src/repositories/teacher.repository.ts) | TypeScript | 115 | 0 | 9 | 124 |
| [src/repositories/teacherSubject.repository.ts](/src/repositories/teacherSubject.repository.ts) | TypeScript | 91 | 0 | 8 | 99 |
| [src/repositories/timetable.repository.ts](/src/repositories/timetable.repository.ts) | TypeScript | 93 | 0 | 8 | 101 |
| [src/repositories/user.repository.ts](/src/repositories/user.repository.ts) | TypeScript | 98 | 0 | 13 | 111 |
| [src/services/adminDashboard.service.ts](/src/services/adminDashboard.service.ts) | TypeScript | 157 | 0 | 5 | 162 |
| [src/services/admission.service.ts](/src/services/admission.service.ts) | TypeScript | 131 | 2 | 16 | 149 |
| [src/services/attendance.service.ts](/src/services/attendance.service.ts) | TypeScript | 80 | 0 | 7 | 87 |
| [src/services/audit.service.ts](/src/services/audit.service.ts) | TypeScript | 42 | 0 | 4 | 46 |
| [src/services/auth.service.ts](/src/services/auth.service.ts) | TypeScript | 180 | 3 | 32 | 215 |
| [src/services/class.service.ts](/src/services/class.service.ts) | TypeScript | 63 | 0 | 12 | 75 |
| [src/services/classFee.service.ts](/src/services/classFee.service.ts) | TypeScript | 48 | 0 | 6 | 54 |
| [src/services/exam.service.ts](/src/services/exam.service.ts) | TypeScript | 994 | 0 | 132 | 1,126 |
| [src/services/feeCategory.service.ts](/src/services/feeCategory.service.ts) | TypeScript | 313 | 0 | 47 | 360 |
| [src/services/notice.service.ts](/src/services/notice.service.ts) | TypeScript | 89 | 0 | 10 | 99 |
| [src/services/notification.service.ts](/src/services/notification.service.ts) | TypeScript | 251 | 0 | 19 | 270 |
| [src/services/parent.service.ts](/src/services/parent.service.ts) | TypeScript | 242 | 0 | 25 | 267 |
| [src/services/parentPortal.service.ts](/src/services/parentPortal.service.ts) | TypeScript | 611 | 0 | 43 | 654 |
| [src/services/passwordReset.service.ts](/src/services/passwordReset.service.ts) | TypeScript | 41 | 0 | 12 | 53 |
| [src/services/payment.service.ts](/src/services/payment.service.ts) | TypeScript | 155 | 0 | 14 | 169 |
| [src/services/result.service.ts](/src/services/result.service.ts) | TypeScript | 114 | 0 | 12 | 126 |
| [src/services/student.service.ts](/src/services/student.service.ts) | TypeScript | 247 | 0 | 36 | 283 |
| [src/services/studentPortal.service.ts](/src/services/studentPortal.service.ts) | TypeScript | 397 | 0 | 20 | 417 |
| [src/services/subject.service.ts](/src/services/subject.service.ts) | TypeScript | 73 | 0 | 10 | 83 |
| [src/services/systemSetting.service.ts](/src/services/systemSetting.service.ts) | TypeScript | 62 | 0 | 7 | 69 |
| [src/services/teacher.service.ts](/src/services/teacher.service.ts) | TypeScript | 269 | 0 | 33 | 302 |
| [src/services/teacherPortal.service.ts](/src/services/teacherPortal.service.ts) | TypeScript | 1,014 | 0 | 72 | 1,086 |
| [src/services/teacherSubject.service.ts](/src/services/teacherSubject.service.ts) | TypeScript | 80 | 0 | 8 | 88 |
| [src/services/theme.service.ts](/src/services/theme.service.ts) | TypeScript | 77 | 0 | 11 | 88 |
| [src/services/timetable.service.ts](/src/services/timetable.service.ts) | TypeScript | 93 | 0 | 8 | 101 |
| [src/services/user.service.ts](/src/services/user.service.ts) | TypeScript | 179 | 0 | 42 | 221 |
| [src/types/api.types.ts](/src/types/api.types.ts) | TypeScript | 6 | 3 | 2 | 11 |
| [src/types/auth.types.ts](/src/types/auth.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/types/student.types.ts](/src/types/student.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/types/teacher.types.ts](/src/types/teacher.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/utils/api-response.ts](/src/utils/api-response.ts) | TypeScript | 7 | 6 | 3 | 16 |
| [src/utils/auth-storage.ts](/src/utils/auth-storage.ts) | TypeScript | 40 | 0 | 9 | 49 |
| [src/utils/email-logger.ts](/src/utils/email-logger.ts) | TypeScript | 19 | 1 | 5 | 25 |
| [src/utils/email.ts](/src/utils/email.ts) | TypeScript | 93 | 3 | 12 | 108 |
| [src/utils/error-handler.ts](/src/utils/error-handler.ts) | TypeScript | 15 | 6 | 5 | 26 |
| [src/utils/pagination.ts](/src/utils/pagination.ts) | TypeScript | 5 | 3 | 2 | 10 |
| [src/validations/admission.schema.ts](/src/validations/admission.schema.ts) | TypeScript | 37 | 0 | 5 | 42 |
| [src/validations/attendance.schema.ts](/src/validations/attendance.schema.ts) | TypeScript | 23 | 0 | 5 | 28 |
| [src/validations/auth.schema.ts](/src/validations/auth.schema.ts) | TypeScript | 30 | 0 | 6 | 36 |
| [src/validations/class-fee.schema.ts](/src/validations/class-fee.schema.ts) | TypeScript | 6 | 0 | 2 | 8 |
| [src/validations/class.schema.ts](/src/validations/class.schema.ts) | TypeScript | 10 | 0 | 4 | 14 |
| [src/validations/exam.schema.ts](/src/validations/exam.schema.ts) | TypeScript | 99 | 0 | 11 | 110 |
| [src/validations/notice.schema.ts](/src/validations/notice.schema.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/validations/parent.schema.ts](/src/validations/parent.schema.ts) | TypeScript | 36 | 0 | 6 | 42 |
| [src/validations/payment.schema.ts](/src/validations/payment.schema.ts) | TypeScript | 60 | 0 | 9 | 69 |
| [src/validations/result.schema.ts](/src/validations/result.schema.ts) | TypeScript | 23 | 0 | 4 | 27 |
| [src/validations/student.schema.ts](/src/validations/student.schema.ts) | TypeScript | 33 | 0 | 5 | 38 |
| [src/validations/subject.schema.ts](/src/validations/subject.schema.ts) | TypeScript | 15 | 0 | 4 | 19 |
| [src/validations/system-setting.schema.ts](/src/validations/system-setting.schema.ts) | TypeScript | 11 | 0 | 2 | 13 |
| [src/validations/teacher-portal.schema.ts](/src/validations/teacher-portal.schema.ts) | TypeScript | 37 | 0 | 6 | 43 |
| [src/validations/teacher-subject.schema.ts](/src/validations/teacher-subject.schema.ts) | TypeScript | 20 | 0 | 4 | 24 |
| [src/validations/teacher.schema.ts](/src/validations/teacher.schema.ts) | TypeScript | 35 | 0 | 4 | 39 |
| [src/validations/theme.schema.ts](/src/validations/theme.schema.ts) | TypeScript | 29 | 0 | 5 | 34 |
| [src/validations/timetable.schema.ts](/src/validations/timetable.schema.ts) | TypeScript | 34 | 0 | 5 | 39 |
| [src/validations/user.schema.ts](/src/validations/user.schema.ts) | TypeScript | 29 | 0 | 5 | 34 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)