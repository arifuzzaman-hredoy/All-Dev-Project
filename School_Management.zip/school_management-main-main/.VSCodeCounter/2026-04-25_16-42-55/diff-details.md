# Diff Details

Date : 2026-04-25 16:42:55

Directory /home/mahi/github_p/school_erp/src

Total : 241 files,  16961 codes, 10 comments, 1391 blanks, all 18362 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/app/(panel)/guardian/attendance/page.tsx](/src/app/(panel)/guardian/attendance/page.tsx) | TypeScript JSX | 104 | 0 | 7 | 111 |
| [src/app/(panel)/guardian/children/\[id\]/page.tsx](/src/app/(panel)/guardian/children/%5Bid%5D/page.tsx) | TypeScript JSX | 342 | 0 | 11 | 353 |
| [src/app/(panel)/guardian/children/page.tsx](/src/app/(panel)/guardian/children/page.tsx) | TypeScript JSX | 44 | 0 | 6 | 50 |
| [src/app/(panel)/guardian/fees/page.tsx](/src/app/(panel)/guardian/fees/page.tsx) | TypeScript JSX | 266 | 0 | 16 | 282 |
| [src/app/(panel)/guardian/layout.tsx](/src/app/(panel)/guardian/layout.tsx) | TypeScript JSX | 25 | 0 | 4 | 29 |
| [src/app/(panel)/guardian/notices/page.tsx](/src/app/(panel)/guardian/notices/page.tsx) | TypeScript JSX | 56 | 0 | 6 | 62 |
| [src/app/(panel)/guardian/page.tsx](/src/app/(panel)/guardian/page.tsx) | TypeScript JSX | 178 | 0 | 6 | 184 |
| [src/app/(panel)/guardian/profile/page.tsx](/src/app/(panel)/guardian/profile/page.tsx) | TypeScript JSX | 48 | 0 | 6 | 54 |
| [src/app/(panel)/guardian/results/page.tsx](/src/app/(panel)/guardian/results/page.tsx) | TypeScript JSX | 86 | 0 | 7 | 93 |
| [src/app/(panel)/guardian/settings/page.tsx](/src/app/(panel)/guardian/settings/page.tsx) | TypeScript JSX | 95 | 0 | 8 | 103 |
| [src/app/(panel)/parent/attendance/page.tsx](/src/app/(panel)/parent/attendance/page.tsx) | TypeScript JSX | -57 | 0 | -7 | -64 |
| [src/app/(panel)/parent/children/\[id\]/page.tsx](/src/app/(panel)/parent/children/%5Bid%5D/page.tsx) | TypeScript JSX | -342 | 0 | -11 | -353 |
| [src/app/(panel)/parent/children/page.tsx](/src/app/(panel)/parent/children/page.tsx) | TypeScript JSX | -44 | 0 | -6 | -50 |
| [src/app/(panel)/parent/fees/page.tsx](/src/app/(panel)/parent/fees/page.tsx) | TypeScript JSX | -266 | 0 | -16 | -282 |
| [src/app/(panel)/parent/layout.tsx](/src/app/(panel)/parent/layout.tsx) | TypeScript JSX | -25 | 0 | -4 | -29 |
| [src/app/(panel)/parent/notices/page.tsx](/src/app/(panel)/parent/notices/page.tsx) | TypeScript JSX | -56 | 0 | -6 | -62 |
| [src/app/(panel)/parent/page.tsx](/src/app/(panel)/parent/page.tsx) | TypeScript JSX | -107 | 0 | -6 | -113 |
| [src/app/(panel)/parent/profile/page.tsx](/src/app/(panel)/parent/profile/page.tsx) | TypeScript JSX | -48 | 0 | -6 | -54 |
| [src/app/(panel)/parent/results/page.tsx](/src/app/(panel)/parent/results/page.tsx) | TypeScript JSX | -86 | 0 | -7 | -93 |
| [src/app/(panel)/parent/settings/page.tsx](/src/app/(panel)/parent/settings/page.tsx) | TypeScript JSX | -95 | 0 | -8 | -103 |
| [src/app/(panel)/student/attendance/page.tsx](/src/app/(panel)/student/attendance/page.tsx) | TypeScript JSX | 60 | 0 | 4 | 64 |
| [src/app/(panel)/student/page.tsx](/src/app/(panel)/student/page.tsx) | TypeScript JSX | 36 | 0 | 0 | 36 |
| [src/app/(panel)/student/profile/page.tsx](/src/app/(panel)/student/profile/page.tsx) | TypeScript JSX | 37 | 0 | 1 | 38 |
| [src/app/(panel)/teacher/page.tsx](/src/app/(panel)/teacher/page.tsx) | TypeScript JSX | 96 | 0 | 0 | 96 |
| [src/app/(panel)/teacher/results/create/page.tsx](/src/app/(panel)/teacher/results/create/page.tsx) | TypeScript JSX | 6 | 0 | 0 | 6 |
| [src/app/(protected)/admission/admission-form.tsx](/src/app/(protected)/admission/admission-form.tsx) | TypeScript JSX | 160 | 2 | 12 | 174 |
| [src/app/admin/academic/documents/page.tsx](/src/app/admin/academic/documents/page.tsx) | TypeScript JSX | 28 | 0 | 2 | 30 |
| [src/app/admin/academic/exams/create/page.tsx](/src/app/admin/academic/exams/create/page.tsx) | TypeScript JSX | 486 | 2 | 26 | 514 |
| [src/app/admin/academic/exams/layout.tsx](/src/app/admin/academic/exams/layout.tsx) | TypeScript JSX | 26 | 0 | 5 | 31 |
| [src/app/admin/academic/exams/page.tsx](/src/app/admin/academic/exams/page.tsx) | TypeScript JSX | 27 | 0 | 1 | 28 |
| [src/app/admin/academic/exams/show/page.tsx](/src/app/admin/academic/exams/show/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/academic/page.tsx](/src/app/admin/academic/page.tsx) | TypeScript JSX | 47 | 0 | 3 | 50 |
| [src/app/admin/admissions/new/page.tsx](/src/app/admin/admissions/new/page.tsx) | TypeScript JSX | 16 | 0 | 2 | 18 |
| [src/app/admin/admissions/page.tsx](/src/app/admin/admissions/page.tsx) | TypeScript JSX | 51 | 0 | 2 | 53 |
| [src/app/admin/admissions/view/page.tsx](/src/app/admin/admissions/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/classes/\[id\]/groups/page.tsx](/src/app/admin/classes/%5Bid%5D/groups/page.tsx) | TypeScript JSX | 13 | 0 | 5 | 18 |
| [src/app/admin/dashboard/page.tsx](/src/app/admin/dashboard/page.tsx) | TypeScript JSX | 593 | 0 | 16 | 609 |
| [src/app/admin/fees/category/page.tsx](/src/app/admin/fees/category/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/fees/catgegory/page.tsx](/src/app/admin/fees/catgegory/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/guardians/create/page.tsx](/src/app/admin/guardians/create/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/guardians/page.tsx](/src/app/admin/guardians/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/guardians/view/page.tsx](/src/app/admin/guardians/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/hr/departments/page.tsx](/src/app/admin/hr/departments/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/designations/page.tsx](/src/app/admin/hr/designations/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/leaves/page.tsx](/src/app/admin/hr/leaves/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/page.tsx](/src/app/admin/hr/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/hr/payroll/page.tsx](/src/app/admin/hr/payroll/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/login/page.tsx](/src/app/admin/login/page.tsx) | TypeScript JSX | 150 | 1 | 17 | 168 |
| [src/app/admin/notices/\[id\]/page.tsx](/src/app/admin/notices/%5Bid%5D/page.tsx) | TypeScript JSX | 13 | 0 | 5 | 18 |
| [src/app/admin/parents/page.tsx](/src/app/admin/parents/page.tsx) | TypeScript JSX | -9 | 0 | -2 | -11 |
| [src/app/admin/students/create/page.tsx](/src/app/admin/students/create/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/students/view/page.tsx](/src/app/admin/students/view/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/users/create/page.tsx](/src/app/admin/users/create/page.tsx) | TypeScript JSX | 16 | 0 | 2 | 18 |
| [src/app/admin/users/page.tsx](/src/app/admin/users/page.tsx) | TypeScript JSX | 51 | 0 | 2 | 53 |
| [src/app/admin/users/view/page.tsx](/src/app/admin/users/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/api/v1/admissions/\[id\]/route.ts](/src/app/api/v1/admissions/%5Bid%5D/route.ts) | TypeScript | 25 | 0 | 3 | 28 |
| [src/app/api/v1/admissions/route.ts](/src/app/api/v1/admissions/route.ts) | TypeScript | -1 | 0 | 0 | -1 |
| [src/app/api/v1/auth/register/route.ts](/src/app/api/v1/auth/register/route.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [src/app/api/v1/classes/\[id\]/groups/\[groupId\]/route.ts](/src/app/api/v1/classes/%5Bid%5D/groups/%5BgroupId%5D/route.ts) | TypeScript | 53 | 0 | 6 | 59 |
| [src/app/api/v1/classes/\[id\]/groups/route.ts](/src/app/api/v1/classes/%5Bid%5D/groups/route.ts) | TypeScript | 48 | 0 | 6 | 54 |
| [src/app/api/v1/classes/order/route.ts](/src/app/api/v1/classes/order/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/exams/\[id\]/route.ts](/src/app/api/v1/exams/%5Bid%5D/route.ts) | TypeScript | 29 | 0 | 0 | 29 |
| [src/app/api/v1/exams/route.ts](/src/app/api/v1/exams/route.ts) | TypeScript | 4 | 0 | 0 | 4 |
| [src/app/api/v1/fees/dues/generate/route.ts](/src/app/api/v1/fees/dues/generate/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/fees/payments/\[id\]/receipt/route.ts](/src/app/api/v1/fees/payments/%5Bid%5D/receipt/route.ts) | TypeScript | 53 | 0 | 6 | 59 |
| [src/app/api/v1/finance/categories/\[id\]/route.ts](/src/app/api/v1/finance/categories/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 7 | 34 |
| [src/app/api/v1/finance/categories/route.ts](/src/app/api/v1/finance/categories/route.ts) | TypeScript | 53 | 0 | 10 | 63 |
| [src/app/api/v1/finance/entries/\[id\]/route.ts](/src/app/api/v1/finance/entries/%5Bid%5D/route.ts) | TypeScript | 47 | 0 | 11 | 58 |
| [src/app/api/v1/finance/entries/route.ts](/src/app/api/v1/finance/entries/route.ts) | TypeScript | 66 | 0 | 10 | 76 |
| [src/app/api/v1/guardian/attendance/route.ts](/src/app/api/v1/guardian/attendance/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/children/\[id\]/route.ts](/src/app/api/v1/guardian/children/%5Bid%5D/route.ts) | TypeScript | 20 | 0 | 3 | 23 |
| [src/app/api/v1/guardian/children/route.ts](/src/app/api/v1/guardian/children/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/guardian/dashboard/route.ts](/src/app/api/v1/guardian/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/guardian/fees/\[id\]/receipt/route.ts](/src/app/api/v1/guardian/fees/%5Bid%5D/receipt/route.ts) | TypeScript | 53 | 0 | 7 | 60 |
| [src/app/api/v1/guardian/fees/route.ts](/src/app/api/v1/guardian/fees/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/notices/route.ts](/src/app/api/v1/guardian/notices/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/profile/route.ts](/src/app/api/v1/guardian/profile/route.ts) | TypeScript | 36 | 0 | 3 | 39 |
| [src/app/api/v1/guardian/results/export/route.ts](/src/app/api/v1/guardian/results/export/route.ts) | TypeScript | 99 | 0 | 9 | 108 |
| [src/app/api/v1/guardian/results/route.ts](/src/app/api/v1/guardian/results/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/settings/password/route.ts](/src/app/api/v1/guardian/settings/password/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/guardians/\[id\]/route.ts](/src/app/api/v1/guardians/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/guardians/route.ts](/src/app/api/v1/guardians/route.ts) | TypeScript | 41 | 0 | 3 | 44 |
| [src/app/api/v1/guardians/transfer-student/route.ts](/src/app/api/v1/guardians/transfer-student/route.ts) | TypeScript | 31 | 0 | 4 | 35 |
| [src/app/api/v1/hr/departments/\[id\]/route.ts](/src/app/api/v1/hr/departments/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 4 | 31 |
| [src/app/api/v1/hr/departments/route.ts](/src/app/api/v1/hr/departments/route.ts) | TypeScript | 38 | 0 | 4 | 42 |
| [src/app/api/v1/hr/designations/\[id\]/route.ts](/src/app/api/v1/hr/designations/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 4 | 31 |
| [src/app/api/v1/hr/designations/route.ts](/src/app/api/v1/hr/designations/route.ts) | TypeScript | 38 | 0 | 4 | 42 |
| [src/app/api/v1/hr/leaves/\[id\]/route.ts](/src/app/api/v1/hr/leaves/%5Bid%5D/route.ts) | TypeScript | 33 | 0 | 3 | 36 |
| [src/app/api/v1/hr/leaves/route.ts](/src/app/api/v1/hr/leaves/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/hr/payroll/items/\[id\]/route.ts](/src/app/api/v1/hr/payroll/items/%5Bid%5D/route.ts) | TypeScript | 28 | 0 | 4 | 32 |
| [src/app/api/v1/hr/payroll/runs/\[id\]/route.ts](/src/app/api/v1/hr/payroll/runs/%5Bid%5D/route.ts) | TypeScript | 52 | 0 | 6 | 58 |
| [src/app/api/v1/hr/payroll/runs/route.ts](/src/app/api/v1/hr/payroll/runs/route.ts) | TypeScript | 43 | 0 | 4 | 47 |
| [src/app/api/v1/notices/\[id\]/publish/route.ts](/src/app/api/v1/notices/%5Bid%5D/publish/route.ts) | TypeScript | 25 | 0 | 6 | 31 |
| [src/app/api/v1/notices/\[id\]/route.ts](/src/app/api/v1/notices/%5Bid%5D/route.ts) | TypeScript | 15 | 0 | 1 | 16 |
| [src/app/api/v1/notices/template/route.ts](/src/app/api/v1/notices/template/route.ts) | TypeScript | 43 | 0 | 7 | 50 |
| [src/app/api/v1/parent/attendance/route.ts](/src/app/api/v1/parent/attendance/route.ts) | TypeScript | -19 | 0 | -2 | -21 |
| [src/app/api/v1/parent/children/\[id\]/route.ts](/src/app/api/v1/parent/children/%5Bid%5D/route.ts) | TypeScript | -20 | 0 | -3 | -23 |
| [src/app/api/v1/parent/children/route.ts](/src/app/api/v1/parent/children/route.ts) | TypeScript | -18 | 0 | -2 | -20 |
| [src/app/api/v1/parent/dashboard/route.ts](/src/app/api/v1/parent/dashboard/route.ts) | TypeScript | -18 | 0 | -2 | -20 |
| [src/app/api/v1/parent/fees/\[id\]/receipt/route.ts](/src/app/api/v1/parent/fees/%5Bid%5D/receipt/route.ts) | TypeScript | -100 | 0 | -8 | -108 |
| [src/app/api/v1/parent/fees/route.ts](/src/app/api/v1/parent/fees/route.ts) | TypeScript | -19 | 0 | -2 | -21 |
| [src/app/api/v1/parent/notices/route.ts](/src/app/api/v1/parent/notices/route.ts) | TypeScript | -19 | 0 | -2 | -21 |
| [src/app/api/v1/parent/profile/route.ts](/src/app/api/v1/parent/profile/route.ts) | TypeScript | -36 | 0 | -3 | -39 |
| [src/app/api/v1/parent/results/export/route.ts](/src/app/api/v1/parent/results/export/route.ts) | TypeScript | -99 | 0 | -9 | -108 |
| [src/app/api/v1/parent/results/route.ts](/src/app/api/v1/parent/results/route.ts) | TypeScript | -19 | 0 | -2 | -21 |
| [src/app/api/v1/parent/settings/password/route.ts](/src/app/api/v1/parent/settings/password/route.ts) | TypeScript | -23 | 0 | -2 | -25 |
| [src/app/api/v1/parents/\[id\]/route.ts](/src/app/api/v1/parents/%5Bid%5D/route.ts) | TypeScript | -44 | 0 | -4 | -48 |
| [src/app/api/v1/parents/route.ts](/src/app/api/v1/parents/route.ts) | TypeScript | -39 | 0 | -3 | -42 |
| [src/app/api/v1/parents/transfer-student/route.ts](/src/app/api/v1/parents/transfer-student/route.ts) | TypeScript | -31 | 0 | -4 | -35 |
| [src/app/api/v1/public/branches/route.ts](/src/app/api/v1/public/branches/route.ts) | TypeScript | 11 | 0 | 3 | 14 |
| [src/app/api/v1/reports/dues/route.ts](/src/app/api/v1/reports/dues/route.ts) | TypeScript | 24 | 0 | 5 | 29 |
| [src/app/api/v1/reports/fees/route.ts](/src/app/api/v1/reports/fees/route.ts) | TypeScript | -42 | 0 | 1 | -41 |
| [src/app/api/v1/reports/finance/monthly/route.ts](/src/app/api/v1/reports/finance/monthly/route.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/app/api/v1/reports/gender-count/route.ts](/src/app/api/v1/reports/gender-count/route.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/app/api/v1/sessions/current/route.ts](/src/app/api/v1/sessions/current/route.ts) | TypeScript | 38 | 0 | 8 | 46 |
| [src/app/api/v1/sessions/migrate/auto-next/route.ts](/src/app/api/v1/sessions/migrate/auto-next/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/sessions/migrate/route.ts](/src/app/api/v1/sessions/migrate/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/sessions/route.ts](/src/app/api/v1/sessions/route.ts) | TypeScript | 46 | 0 | 9 | 55 |
| [src/app/api/v1/student-document-template/route.ts](/src/app/api/v1/student-document-template/route.ts) | TypeScript | 37 | 0 | 6 | 43 |
| [src/app/api/v1/students/\[id\]/documents/route.ts](/src/app/api/v1/students/%5Bid%5D/documents/route.ts) | TypeScript | 70 | 0 | 14 | 84 |
| [src/app/api/v1/students/route.ts](/src/app/api/v1/students/route.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [src/app/api/v1/super/branches/\[id\]/route.ts](/src/app/api/v1/super/branches/%5Bid%5D/route.ts) | TypeScript | 32 | 0 | 5 | 37 |
| [src/app/api/v1/super/branches/route.ts](/src/app/api/v1/super/branches/route.ts) | TypeScript | 41 | 0 | 5 | 46 |
| [src/app/api/v1/teachers/route.ts](/src/app/api/v1/teachers/route.ts) | TypeScript | 6 | 0 | 0 | 6 |
| [src/app/api/v1/trash/restore/route.ts](/src/app/api/v1/trash/restore/route.ts) | TypeScript | 31 | 0 | 7 | 38 |
| [src/app/api/v1/trash/route.ts](/src/app/api/v1/trash/route.ts) | TypeScript | 24 | 0 | 5 | 29 |
| [src/app/api/v1/users/route.ts](/src/app/api/v1/users/route.ts) | TypeScript | 1 | 0 | 0 | 1 |
| [src/app/layout.tsx](/src/app/layout.tsx) | TypeScript JSX | 11 | 0 | -1 | 10 |
| [src/app/register/page.tsx](/src/app/register/page.tsx) | TypeScript JSX | -113 | 0 | -15 | -128 |
| [src/components/admin/admin-access-guard.tsx](/src/components/admin/admin-access-guard.tsx) | TypeScript JSX | 12 | 0 | 1 | 13 |
| [src/components/admin/admission-management-panel.tsx](/src/components/admin/admission-management-panel.tsx) | TypeScript JSX | 332 | 0 | 21 | 353 |
| [src/components/admin/admission-new-application-panel.tsx](/src/components/admin/admission-new-application-panel.tsx) | TypeScript JSX | 251 | 0 | 10 | 261 |
| [src/components/admin/attendance-management-panel.tsx](/src/components/admin/attendance-management-panel.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/components/admin/class-group-management-panel.tsx](/src/components/admin/class-group-management-panel.tsx) | TypeScript JSX | 317 | 0 | 27 | 344 |
| [src/components/admin/class-management-panel.tsx](/src/components/admin/class-management-panel.tsx) | TypeScript JSX | 87 | 0 | 5 | 92 |
| [src/components/admin/exam-management-panel.tsx](/src/components/admin/exam-management-panel.tsx) | TypeScript JSX | 846 | 0 | 0 | 846 |
| [src/components/admin/guardian-management-panel.tsx](/src/components/admin/guardian-management-panel.tsx) | TypeScript JSX | 863 | 2 | 45 | 910 |
| [src/components/admin/hr-department-panel.tsx](/src/components/admin/hr-department-panel.tsx) | TypeScript JSX | 268 | 0 | 19 | 287 |
| [src/components/admin/hr-designation-panel.tsx](/src/components/admin/hr-designation-panel.tsx) | TypeScript JSX | 268 | 0 | 19 | 287 |
| [src/components/admin/hr-leave-panel.tsx](/src/components/admin/hr-leave-panel.tsx) | TypeScript JSX | 371 | 0 | 27 | 398 |
| [src/components/admin/hr-overview-panel.tsx](/src/components/admin/hr-overview-panel.tsx) | TypeScript JSX | 61 | 0 | 5 | 66 |
| [src/components/admin/notice-editor-pad.tsx](/src/components/admin/notice-editor-pad.tsx) | TypeScript JSX | 388 | 0 | 34 | 422 |
| [src/components/admin/notice-management-panel.tsx](/src/components/admin/notice-management-panel.tsx) | TypeScript JSX | 313 | 0 | 35 | 348 |
| [src/components/admin/parent-management-panel.tsx](/src/components/admin/parent-management-panel.tsx) | TypeScript JSX | -535 | 0 | -24 | -559 |
| [src/components/admin/payment-management-page.tsx](/src/components/admin/payment-management-page.tsx) | TypeScript JSX | 59 | 0 | 6 | 65 |
| [src/components/admin/payroll-management-panel.tsx](/src/components/admin/payroll-management-panel.tsx) | TypeScript JSX | 396 | 0 | 28 | 424 |
| [src/components/admin/student-document-management-panel.tsx](/src/components/admin/student-document-management-panel.tsx) | TypeScript JSX | 242 | 0 | 25 | 267 |
| [src/components/admin/student-document-template-editor.tsx](/src/components/admin/student-document-template-editor.tsx) | TypeScript JSX | 163 | 0 | 20 | 183 |
| [src/components/admin/student-management-panel.tsx](/src/components/admin/student-management-panel.tsx) | TypeScript JSX | 974 | 2 | 21 | 997 |
| [src/components/admin/user-create-panel.tsx](/src/components/admin/user-create-panel.tsx) | TypeScript JSX | 328 | 0 | 40 | 368 |
| [src/components/admin/user-management-panel.tsx](/src/components/admin/user-management-panel.tsx) | TypeScript JSX | -71 | 0 | -11 | -82 |
| [src/components/app-sidebar-guardian.tsx](/src/components/app-sidebar-guardian.tsx) | TypeScript JSX | 70 | 0 | 5 | 75 |
| [src/components/app-sidebar-parent.tsx](/src/components/app-sidebar-parent.tsx) | TypeScript JSX | -70 | 0 | -5 | -75 |
| [src/components/app-sidebar.tsx](/src/components/app-sidebar.tsx) | TypeScript JSX | 93 | 0 | 0 | 93 |
| [src/components/hero-sections-05.tsx](/src/components/hero-sections-05.tsx) | TypeScript JSX | -8 | 0 | 0 | -8 |
| [src/components/nav-main.tsx](/src/components/nav-main.tsx) | TypeScript JSX | 43 | 0 | 7 | 50 |
| [src/constants/exam-types.ts](/src/constants/exam-types.ts) | TypeScript | 2 | 0 | 1 | 3 |
| [src/constants/roles.ts](/src/constants/roles.ts) | TypeScript | 23 | 0 | 0 | 23 |
| [src/lib/attendance-summary.ts](/src/lib/attendance-summary.ts) | TypeScript | 81 | 0 | 12 | 93 |
| [src/lib/auth.ts](/src/lib/auth.ts) | TypeScript | 1 | 0 | 0 | 1 |
| [src/lib/money-receipt.ts](/src/lib/money-receipt.ts) | TypeScript | 426 | 0 | 10 | 436 |
| [src/lib/prisma.ts](/src/lib/prisma.ts) | TypeScript | 10 | 0 | 0 | 10 |
| [src/lib/result-marks.ts](/src/lib/result-marks.ts) | TypeScript | 44 | 0 | 10 | 54 |
| [src/lib/student-document-pdf-modules/character-certificate.ts](/src/lib/student-document-pdf-modules/character-certificate.ts) | TypeScript | 375 | 0 | 5 | 380 |
| [src/lib/student-document-pdf-modules/common.ts](/src/lib/student-document-pdf-modules/common.ts) | TypeScript | 119 | 0 | 22 | 141 |
| [src/lib/student-document-pdf-modules/testimonial.ts](/src/lib/student-document-pdf-modules/testimonial.ts) | TypeScript | 379 | 0 | 5 | 384 |
| [src/lib/student-document-pdf-modules/transfer-certificate.ts](/src/lib/student-document-pdf-modules/transfer-certificate.ts) | TypeScript | 367 | 0 | 5 | 372 |
| [src/lib/student-document-pdf.ts](/src/lib/student-document-pdf.ts) | TypeScript | 33 | 0 | 4 | 37 |
| [src/lib/student-document-template.ts](/src/lib/student-document-template.ts) | TypeScript | 83 | 0 | 13 | 96 |
| [src/lib/student-document.ts](/src/lib/student-document.ts) | TypeScript | 365 | 0 | 15 | 380 |
| [src/repositories/admission.repository.ts](/src/repositories/admission.repository.ts) | TypeScript | 12 | 0 | 1 | 13 |
| [src/repositories/branch.repository.ts](/src/repositories/branch.repository.ts) | TypeScript | 69 | 0 | 10 | 79 |
| [src/repositories/class.repository.ts](/src/repositories/class.repository.ts) | TypeScript | 63 | 0 | 6 | 69 |
| [src/repositories/exam.repository.ts](/src/repositories/exam.repository.ts) | TypeScript | 8 | 0 | -1 | 7 |
| [src/repositories/financeCategory.repository.ts](/src/repositories/financeCategory.repository.ts) | TypeScript | 63 | 0 | 9 | 72 |
| [src/repositories/financeEntry.repository.ts](/src/repositories/financeEntry.repository.ts) | TypeScript | 118 | 0 | 9 | 127 |
| [src/repositories/guardian.repository.ts](/src/repositories/guardian.repository.ts) | TypeScript | 199 | 0 | 18 | 217 |
| [src/repositories/hr.repository.ts](/src/repositories/hr.repository.ts) | TypeScript | 145 | 0 | 20 | 165 |
| [src/repositories/notice.repository.ts](/src/repositories/notice.repository.ts) | TypeScript | 21 | 0 | 1 | 22 |
| [src/repositories/payroll.repository.ts](/src/repositories/payroll.repository.ts) | TypeScript | 129 | 0 | 14 | 143 |
| [src/repositories/result.repository.ts](/src/repositories/result.repository.ts) | TypeScript | 12 | 0 | 0 | 12 |
| [src/repositories/school.repository.ts](/src/repositories/school.repository.ts) | TypeScript | 51 | 0 | 9 | 60 |
| [src/repositories/session.repository.ts](/src/repositories/session.repository.ts) | TypeScript | 78 | 0 | 11 | 89 |
| [src/repositories/student.repository.ts](/src/repositories/student.repository.ts) | TypeScript | 123 | 0 | 7 | 130 |
| [src/repositories/systemSetting.repository.ts](/src/repositories/systemSetting.repository.ts) | TypeScript | 2 | 0 | 1 | 3 |
| [src/repositories/teacher.repository.ts](/src/repositories/teacher.repository.ts) | TypeScript | 7 | 0 | 0 | 7 |
| [src/repositories/user.repository.ts](/src/repositories/user.repository.ts) | TypeScript | 37 | 0 | 1 | 38 |
| [src/services/adminDashboard.service.ts](/src/services/adminDashboard.service.ts) | TypeScript | 155 | 0 | 9 | 164 |
| [src/services/admission.service.ts](/src/services/admission.service.ts) | TypeScript | 517 | -2 | 65 | 580 |
| [src/services/attendance.service.ts](/src/services/attendance.service.ts) | TypeScript | 31 | 0 | 5 | 36 |
| [src/services/auth.service.ts](/src/services/auth.service.ts) | TypeScript | -50 | 0 | -11 | -61 |
| [src/services/branch.service.ts](/src/services/branch.service.ts) | TypeScript | 77 | 0 | 9 | 86 |
| [src/services/class-group.service.ts](/src/services/class-group.service.ts) | TypeScript | 96 | 0 | 17 | 113 |
| [src/services/class.service.ts](/src/services/class.service.ts) | TypeScript | 56 | 0 | 7 | 63 |
| [src/services/due.service.ts](/src/services/due.service.ts) | TypeScript | 229 | 1 | 26 | 256 |
| [src/services/exam.service.ts](/src/services/exam.service.ts) | TypeScript | 140 | 0 | -2 | 138 |
| [src/services/finance.service.ts](/src/services/finance.service.ts) | TypeScript | 347 | 0 | 33 | 380 |
| [src/services/guardian.service.ts](/src/services/guardian.service.ts) | TypeScript | 372 | 0 | 39 | 411 |
| [src/services/guardianPortal.service.ts](/src/services/guardianPortal.service.ts) | TypeScript | 627 | 0 | 43 | 670 |
| [src/services/hr.service.ts](/src/services/hr.service.ts) | TypeScript | 153 | 0 | 20 | 173 |
| [src/services/notice.service.ts](/src/services/notice.service.ts) | TypeScript | 110 | 0 | 16 | 126 |
| [src/services/noticeTemplate.service.ts](/src/services/noticeTemplate.service.ts) | TypeScript | 31 | 0 | 6 | 37 |
| [src/services/notification.service.ts](/src/services/notification.service.ts) | TypeScript | 8 | 0 | 0 | 8 |
| [src/services/parent.service.ts](/src/services/parent.service.ts) | TypeScript | -242 | 0 | -25 | -267 |
| [src/services/parentPortal.service.ts](/src/services/parentPortal.service.ts) | TypeScript | -611 | 0 | -43 | -654 |
| [src/services/payment.service.ts](/src/services/payment.service.ts) | TypeScript | 83 | 0 | 14 | 97 |
| [src/services/payroll.service.ts](/src/services/payroll.service.ts) | TypeScript | 141 | 0 | 21 | 162 |
| [src/services/result.service.ts](/src/services/result.service.ts) | TypeScript | 30 | 0 | 3 | 33 |
| [src/services/session.service.ts](/src/services/session.service.ts) | TypeScript | 300 | 0 | 40 | 340 |
| [src/services/student.service.ts](/src/services/student.service.ts) | TypeScript | 220 | 1 | 17 | 238 |
| [src/services/studentDocumentTemplate.service.ts](/src/services/studentDocumentTemplate.service.ts) | TypeScript | 41 | 0 | 8 | 49 |
| [src/services/studentPortal.service.ts](/src/services/studentPortal.service.ts) | TypeScript | 48 | 0 | 3 | 51 |
| [src/services/studentStats.service.ts](/src/services/studentStats.service.ts) | TypeScript | 75 | 0 | 14 | 89 |
| [src/services/systemSetting.service.ts](/src/services/systemSetting.service.ts) | TypeScript | 30 | 0 | 7 | 37 |
| [src/services/teacher.service.ts](/src/services/teacher.service.ts) | TypeScript | 42 | 0 | 1 | 43 |
| [src/services/teacherPortal.service.ts](/src/services/teacherPortal.service.ts) | TypeScript | 262 | 0 | 7 | 269 |
| [src/services/teacherSubject.service.ts](/src/services/teacherSubject.service.ts) | TypeScript | 32 | 0 | 6 | 38 |
| [src/services/trash.service.ts](/src/services/trash.service.ts) | TypeScript | 387 | 0 | 52 | 439 |
| [src/services/user.service.ts](/src/services/user.service.ts) | TypeScript | 71 | 1 | 3 | 75 |
| [src/types/global-imports.d.ts](/src/types/global-imports.d.ts) | TypeScript | 4 | 0 | 1 | 5 |
| [src/types/pdfkit-standalone.d.ts](/src/types/pdfkit-standalone.d.ts) | TypeScript | 4 | 0 | 1 | 5 |
| [src/utils/auth-storage.ts](/src/utils/auth-storage.ts) | TypeScript | 2 | 0 | 0 | 2 |
| [src/validations/admission.schema.ts](/src/validations/admission.schema.ts) | TypeScript | 33 | 0 | 2 | 35 |
| [src/validations/auth.schema.ts](/src/validations/auth.schema.ts) | TypeScript | -10 | 0 | -1 | -11 |
| [src/validations/branch.schema.ts](/src/validations/branch.schema.ts) | TypeScript | 29 | 0 | 4 | 33 |
| [src/validations/class.schema.ts](/src/validations/class.schema.ts) | TypeScript | 12 | 0 | 4 | 16 |
| [src/validations/due.schema.ts](/src/validations/due.schema.ts) | TypeScript | 9 | 0 | 4 | 13 |
| [src/validations/exam.schema.ts](/src/validations/exam.schema.ts) | TypeScript | 10 | 0 | 0 | 10 |
| [src/validations/finance.schema.ts](/src/validations/finance.schema.ts) | TypeScript | 52 | 0 | 10 | 62 |
| [src/validations/guardian.schema.ts](/src/validations/guardian.schema.ts) | TypeScript | 38 | 0 | 6 | 44 |
| [src/validations/hr.schema.ts](/src/validations/hr.schema.ts) | TypeScript | 47 | 0 | 11 | 58 |
| [src/validations/notice-template.schema.ts](/src/validations/notice-template.schema.ts) | TypeScript | 6 | 0 | 3 | 9 |
| [src/validations/notice.schema.ts](/src/validations/notice.schema.ts) | TypeScript | 4 | 0 | 0 | 4 |
| [src/validations/parent.schema.ts](/src/validations/parent.schema.ts) | TypeScript | -36 | 0 | -6 | -42 |
| [src/validations/payroll.schema.ts](/src/validations/payroll.schema.ts) | TypeScript | 17 | 0 | 6 | 23 |
| [src/validations/session.schema.ts](/src/validations/session.schema.ts) | TypeScript | 46 | 0 | 7 | 53 |
| [src/validations/student-document-template.schema.ts](/src/validations/student-document-template.schema.ts) | TypeScript | 35 | 0 | 7 | 42 |
| [src/validations/student-stats.schema.ts](/src/validations/student-stats.schema.ts) | TypeScript | 4 | 0 | 3 | 7 |
| [src/validations/student.schema.ts](/src/validations/student.schema.ts) | TypeScript | 30 | 0 | 0 | 30 |
| [src/validations/trash.schema.ts](/src/validations/trash.schema.ts) | TypeScript | 17 | 0 | 5 | 22 |
| [src/validations/user.schema.ts](/src/validations/user.schema.ts) | TypeScript | 5 | 0 | 0 | 5 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details