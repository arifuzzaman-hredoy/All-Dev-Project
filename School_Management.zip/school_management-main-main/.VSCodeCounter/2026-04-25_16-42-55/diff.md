# Diff Summary

Date : 2026-04-25 16:42:55

Directory /home/mahi/github_p/school_erp/src

Total : 241 files,  16961 codes, 10 comments, 1391 blanks, all 18362 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 157 | 8,852 | 1 | 906 | 9,759 |
| TypeScript JSX | 84 | 8,109 | 9 | 485 | 8,603 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 241 | 16,961 | 10 | 1,391 | 18,362 |
| app | 129 | 3,280 | 5 | 334 | 3,619 |
| app (Files) | 1 | 11 | 0 | -1 | 10 |
| app/(panel) | 25 | 353 | 0 | 5 | 358 |
| app/(panel)/guardian | 10 | 1,244 | 0 | 77 | 1,321 |
| app/(panel)/guardian (Files) | 2 | 203 | 0 | 10 | 213 |
| app/(panel)/guardian/attendance | 1 | 104 | 0 | 7 | 111 |
| app/(panel)/guardian/children | 2 | 386 | 0 | 17 | 403 |
| app/(panel)/guardian/children (Files) | 1 | 44 | 0 | 6 | 50 |
| app/(panel)/guardian/children/[id] | 1 | 342 | 0 | 11 | 353 |
| app/(panel)/guardian/fees | 1 | 266 | 0 | 16 | 282 |
| app/(panel)/guardian/notices | 1 | 56 | 0 | 6 | 62 |
| app/(panel)/guardian/profile | 1 | 48 | 0 | 6 | 54 |
| app/(panel)/guardian/results | 1 | 86 | 0 | 7 | 93 |
| app/(panel)/guardian/settings | 1 | 95 | 0 | 8 | 103 |
| app/(panel)/parent | 10 | -1,126 | 0 | -77 | -1,203 |
| app/(panel)/parent (Files) | 2 | -132 | 0 | -10 | -142 |
| app/(panel)/parent/attendance | 1 | -57 | 0 | -7 | -64 |
| app/(panel)/parent/children | 2 | -386 | 0 | -17 | -403 |
| app/(panel)/parent/children (Files) | 1 | -44 | 0 | -6 | -50 |
| app/(panel)/parent/children/[id] | 1 | -342 | 0 | -11 | -353 |
| app/(panel)/parent/fees | 1 | -266 | 0 | -16 | -282 |
| app/(panel)/parent/notices | 1 | -56 | 0 | -6 | -62 |
| app/(panel)/parent/profile | 1 | -48 | 0 | -6 | -54 |
| app/(panel)/parent/results | 1 | -86 | 0 | -7 | -93 |
| app/(panel)/parent/settings | 1 | -95 | 0 | -8 | -103 |
| app/(panel)/student | 3 | 133 | 0 | 5 | 138 |
| app/(panel)/student (Files) | 1 | 36 | 0 | 0 | 36 |
| app/(panel)/student/attendance | 1 | 60 | 0 | 4 | 64 |
| app/(panel)/student/profile | 1 | 37 | 0 | 1 | 38 |
| app/(panel)/teacher | 2 | 102 | 0 | 0 | 102 |
| app/(panel)/teacher (Files) | 1 | 96 | 0 | 0 | 96 |
| app/(panel)/teacher/results | 1 | 6 | 0 | 0 | 6 |
| app/(panel)/teacher/results/create | 1 | 6 | 0 | 0 | 6 |
| app/(protected) | 1 | 160 | 2 | 12 | 174 |
| app/(protected)/admission | 1 | 160 | 2 | 12 | 174 |
| app/admin | 29 | 1,628 | 3 | 122 | 1,753 |
| app/admin/academic | 6 | 618 | 2 | 39 | 659 |
| app/admin/academic (Files) | 1 | 47 | 0 | 3 | 50 |
| app/admin/academic/documents | 1 | 28 | 0 | 2 | 30 |
| app/admin/academic/exams | 4 | 543 | 2 | 34 | 579 |
| app/admin/academic/exams (Files) | 2 | 53 | 0 | 6 | 59 |
| app/admin/academic/exams/create | 1 | 486 | 2 | 26 | 514 |
| app/admin/academic/exams/show | 1 | 4 | 0 | 2 | 6 |
| app/admin/admissions | 3 | 76 | 0 | 6 | 82 |
| app/admin/admissions (Files) | 1 | 51 | 0 | 2 | 53 |
| app/admin/admissions/new | 1 | 16 | 0 | 2 | 18 |
| app/admin/admissions/view | 1 | 9 | 0 | 2 | 11 |
| app/admin/classes | 1 | 13 | 0 | 5 | 18 |
| app/admin/classes/[id] | 1 | 13 | 0 | 5 | 18 |
| app/admin/classes/[id]/groups | 1 | 13 | 0 | 5 | 18 |
| app/admin/dashboard | 1 | 593 | 0 | 16 | 609 |
| app/admin/fees | 2 | 8 | 0 | 4 | 12 |
| app/admin/fees/category | 1 | 4 | 0 | 2 | 6 |
| app/admin/fees/catgegory | 1 | 4 | 0 | 2 | 6 |
| app/admin/guardians | 3 | 27 | 0 | 6 | 33 |
| app/admin/guardians (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/guardians/create | 1 | 9 | 0 | 2 | 11 |
| app/admin/guardians/view | 1 | 9 | 0 | 2 | 11 |
| app/admin/hr | 5 | 45 | 0 | 14 | 59 |
| app/admin/hr (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/hr/departments | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/designations | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/leaves | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/payroll | 1 | 9 | 0 | 3 | 12 |
| app/admin/login | 1 | 150 | 1 | 17 | 168 |
| app/admin/notices | 1 | 13 | 0 | 5 | 18 |
| app/admin/notices/[id] | 1 | 13 | 0 | 5 | 18 |
| app/admin/parents | 1 | -9 | 0 | -2 | -11 |
| app/admin/students | 2 | 18 | 0 | 6 | 24 |
| app/admin/students/create | 1 | 9 | 0 | 3 | 12 |
| app/admin/students/view | 1 | 9 | 0 | 3 | 12 |
| app/admin/users | 3 | 76 | 0 | 6 | 82 |
| app/admin/users (Files) | 1 | 51 | 0 | 2 | 53 |
| app/admin/users/create | 1 | 16 | 0 | 2 | 18 |
| app/admin/users/view | 1 | 9 | 0 | 2 | 11 |
| app/api | 72 | 1,241 | 0 | 211 | 1,452 |
| app/api/v1 | 72 | 1,241 | 0 | 211 | 1,452 |
| app/api/v1/admissions | 2 | 24 | 0 | 3 | 27 |
| app/api/v1/admissions (Files) | 1 | -1 | 0 | 0 | -1 |
| app/api/v1/admissions/[id] | 1 | 25 | 0 | 3 | 28 |
| app/api/v1/auth | 1 | 2 | 0 | 0 | 2 |
| app/api/v1/auth/register | 1 | 2 | 0 | 0 | 2 |
| app/api/v1/classes | 3 | 127 | 0 | 18 | 145 |
| app/api/v1/classes/[id] | 2 | 101 | 0 | 12 | 113 |
| app/api/v1/classes/[id]/groups | 2 | 101 | 0 | 12 | 113 |
| app/api/v1/classes/[id]/groups (Files) | 1 | 48 | 0 | 6 | 54 |
| app/api/v1/classes/[id]/groups/[groupId] | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/classes/order | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/exams | 2 | 33 | 0 | 0 | 33 |
| app/api/v1/exams (Files) | 1 | 4 | 0 | 0 | 4 |
| app/api/v1/exams/[id] | 1 | 29 | 0 | 0 | 29 |
| app/api/v1/fees | 2 | 79 | 0 | 12 | 91 |
| app/api/v1/fees/dues | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/fees/dues/generate | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/fees/payments | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/fees/payments/[id] | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/fees/payments/[id]/receipt | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/finance | 4 | 193 | 0 | 38 | 231 |
| app/api/v1/finance/categories | 2 | 80 | 0 | 17 | 97 |
| app/api/v1/finance/categories (Files) | 1 | 53 | 0 | 10 | 63 |
| app/api/v1/finance/categories/[id] | 1 | 27 | 0 | 7 | 34 |
| app/api/v1/finance/entries | 2 | 113 | 0 | 21 | 134 |
| app/api/v1/finance/entries (Files) | 1 | 66 | 0 | 10 | 76 |
| app/api/v1/finance/entries/[id] | 1 | 47 | 0 | 11 | 58 |
| app/api/v1/guardian | 11 | 343 | 0 | 36 | 379 |
| app/api/v1/guardian/attendance | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/children | 2 | 38 | 0 | 5 | 43 |
| app/api/v1/guardian/children (Files) | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/guardian/children/[id] | 1 | 20 | 0 | 3 | 23 |
| app/api/v1/guardian/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/guardian/fees | 2 | 72 | 0 | 9 | 81 |
| app/api/v1/guardian/fees (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/fees/[id] | 1 | 53 | 0 | 7 | 60 |
| app/api/v1/guardian/fees/[id]/receipt | 1 | 53 | 0 | 7 | 60 |
| app/api/v1/guardian/notices | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/profile | 1 | 36 | 0 | 3 | 39 |
| app/api/v1/guardian/results | 2 | 118 | 0 | 11 | 129 |
| app/api/v1/guardian/results (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/results/export | 1 | 99 | 0 | 9 | 108 |
| app/api/v1/guardian/settings | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/guardian/settings/password | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/guardians | 3 | 116 | 0 | 11 | 127 |
| app/api/v1/guardians (Files) | 1 | 41 | 0 | 3 | 44 |
| app/api/v1/guardians/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/guardians/transfer-student | 1 | 31 | 0 | 4 | 35 |
| app/api/v1/hr | 9 | 330 | 0 | 37 | 367 |
| app/api/v1/hr/departments | 2 | 65 | 0 | 8 | 73 |
| app/api/v1/hr/departments (Files) | 1 | 38 | 0 | 4 | 42 |
| app/api/v1/hr/departments/[id] | 1 | 27 | 0 | 4 | 31 |
| app/api/v1/hr/designations | 2 | 65 | 0 | 8 | 73 |
| app/api/v1/hr/designations (Files) | 1 | 38 | 0 | 4 | 42 |
| app/api/v1/hr/designations/[id] | 1 | 27 | 0 | 4 | 31 |
| app/api/v1/hr/leaves | 2 | 77 | 0 | 7 | 84 |
| app/api/v1/hr/leaves (Files) | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/hr/leaves/[id] | 1 | 33 | 0 | 3 | 36 |
| app/api/v1/hr/payroll | 3 | 123 | 0 | 14 | 137 |
| app/api/v1/hr/payroll/items | 1 | 28 | 0 | 4 | 32 |
| app/api/v1/hr/payroll/items/[id] | 1 | 28 | 0 | 4 | 32 |
| app/api/v1/hr/payroll/runs | 2 | 95 | 0 | 10 | 105 |
| app/api/v1/hr/payroll/runs (Files) | 1 | 43 | 0 | 4 | 47 |
| app/api/v1/hr/payroll/runs/[id] | 1 | 52 | 0 | 6 | 58 |
| app/api/v1/notices | 3 | 83 | 0 | 14 | 97 |
| app/api/v1/notices/[id] | 2 | 40 | 0 | 7 | 47 |
| app/api/v1/notices/[id] (Files) | 1 | 15 | 0 | 1 | 16 |
| app/api/v1/notices/[id]/publish | 1 | 25 | 0 | 6 | 31 |
| app/api/v1/notices/template | 1 | 43 | 0 | 7 | 50 |
| app/api/v1/parent | 11 | -390 | 0 | -37 | -427 |
| app/api/v1/parent/attendance | 1 | -19 | 0 | -2 | -21 |
| app/api/v1/parent/children | 2 | -38 | 0 | -5 | -43 |
| app/api/v1/parent/children (Files) | 1 | -18 | 0 | -2 | -20 |
| app/api/v1/parent/children/[id] | 1 | -20 | 0 | -3 | -23 |
| app/api/v1/parent/dashboard | 1 | -18 | 0 | -2 | -20 |
| app/api/v1/parent/fees | 2 | -119 | 0 | -10 | -129 |
| app/api/v1/parent/fees (Files) | 1 | -19 | 0 | -2 | -21 |
| app/api/v1/parent/fees/[id] | 1 | -100 | 0 | -8 | -108 |
| app/api/v1/parent/fees/[id]/receipt | 1 | -100 | 0 | -8 | -108 |
| app/api/v1/parent/notices | 1 | -19 | 0 | -2 | -21 |
| app/api/v1/parent/profile | 1 | -36 | 0 | -3 | -39 |
| app/api/v1/parent/results | 2 | -118 | 0 | -11 | -129 |
| app/api/v1/parent/results (Files) | 1 | -19 | 0 | -2 | -21 |
| app/api/v1/parent/results/export | 1 | -99 | 0 | -9 | -108 |
| app/api/v1/parent/settings | 1 | -23 | 0 | -2 | -25 |
| app/api/v1/parent/settings/password | 1 | -23 | 0 | -2 | -25 |
| app/api/v1/parents | 3 | -114 | 0 | -11 | -125 |
| app/api/v1/parents (Files) | 1 | -39 | 0 | -3 | -42 |
| app/api/v1/parents/[id] | 1 | -44 | 0 | -4 | -48 |
| app/api/v1/parents/transfer-student | 1 | -31 | 0 | -4 | -35 |
| app/api/v1/public | 1 | 11 | 0 | 3 | 14 |
| app/api/v1/public/branches | 1 | 11 | 0 | 3 | 14 |
| app/api/v1/reports | 4 | 24 | 0 | 16 | 40 |
| app/api/v1/reports/dues | 1 | 24 | 0 | 5 | 29 |
| app/api/v1/reports/fees | 1 | -42 | 0 | 1 | -41 |
| app/api/v1/reports/finance | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/reports/finance/monthly | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/reports/gender-count | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/sessions | 4 | 136 | 0 | 29 | 165 |
| app/api/v1/sessions (Files) | 1 | 46 | 0 | 9 | 55 |
| app/api/v1/sessions/current | 1 | 38 | 0 | 8 | 46 |
| app/api/v1/sessions/migrate | 2 | 52 | 0 | 12 | 64 |
| app/api/v1/sessions/migrate (Files) | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/sessions/migrate/auto-next | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/student-document-template | 1 | 37 | 0 | 6 | 43 |
| app/api/v1/students | 2 | 72 | 0 | 14 | 86 |
| app/api/v1/students (Files) | 1 | 2 | 0 | 0 | 2 |
| app/api/v1/students/[id] | 1 | 70 | 0 | 14 | 84 |
| app/api/v1/students/[id]/documents | 1 | 70 | 0 | 14 | 84 |
| app/api/v1/super | 2 | 73 | 0 | 10 | 83 |
| app/api/v1/super/branches | 2 | 73 | 0 | 10 | 83 |
| app/api/v1/super/branches (Files) | 1 | 41 | 0 | 5 | 46 |
| app/api/v1/super/branches/[id] | 1 | 32 | 0 | 5 | 37 |
| app/api/v1/teachers | 1 | 6 | 0 | 0 | 6 |
| app/api/v1/trash | 2 | 55 | 0 | 12 | 67 |
| app/api/v1/trash (Files) | 1 | 24 | 0 | 5 | 29 |
| app/api/v1/trash/restore | 1 | 31 | 0 | 7 | 38 |
| app/api/v1/users | 1 | 1 | 0 | 0 | 1 |
| app/register | 1 | -113 | 0 | -15 | -128 |
| components | 27 | 6,070 | 4 | 362 | 6,436 |
| components (Files) | 5 | 128 | 0 | 7 | 135 |
| components/admin | 22 | 5,942 | 4 | 355 | 6,301 |
| constants | 2 | 25 | 0 | 1 | 26 |
| lib | 12 | 2,283 | 0 | 101 | 2,384 |
| lib (Files) | 8 | 1,043 | 0 | 64 | 1,107 |
| lib/student-document-pdf-modules | 4 | 1,240 | 0 | 37 | 1,277 |
| repositories | 17 | 1,137 | 0 | 116 | 1,253 |
| services | 32 | 3,808 | 1 | 410 | 4,219 |
| types | 2 | 8 | 0 | 2 | 10 |
| utils | 1 | 2 | 0 | 0 | 2 |
| validations | 19 | 348 | 0 | 65 | 413 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)