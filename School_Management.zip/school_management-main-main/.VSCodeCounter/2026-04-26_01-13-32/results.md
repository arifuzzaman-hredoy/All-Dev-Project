# Summary

Date : 2026-04-26 01:13:32

Directory /home/mahi/github_p/school_erp/src

Total : 416 files,  49446 codes, 133 comments, 4459 blanks, all 54038 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript JSX | 172 | 27,534 | 62 | 2,139 | 29,735 |
| TypeScript | 243 | 21,788 | 71 | 2,315 | 24,174 |
| PostCSS | 1 | 124 | 0 | 5 | 129 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 416 | 49,446 | 133 | 4,459 | 54,038 |
| app | 208 | 14,128 | 32 | 1,374 | 15,534 |
| app (Files) | 3 | 209 | 0 | 19 | 228 |
| app/(panel) | 38 | 5,597 | 15 | 463 | 6,075 |
| app/(panel)/guardian | 10 | 1,246 | 0 | 77 | 1,323 |
| app/(panel)/guardian (Files) | 2 | 204 | 0 | 10 | 214 |
| app/(panel)/guardian/attendance | 1 | 104 | 0 | 7 | 111 |
| app/(panel)/guardian/children | 2 | 387 | 0 | 17 | 404 |
| app/(panel)/guardian/children (Files) | 1 | 44 | 0 | 6 | 50 |
| app/(panel)/guardian/children/[id] | 1 | 343 | 0 | 11 | 354 |
| app/(panel)/guardian/fees | 1 | 266 | 0 | 16 | 282 |
| app/(panel)/guardian/notices | 1 | 56 | 0 | 6 | 62 |
| app/(panel)/guardian/profile | 1 | 48 | 0 | 6 | 54 |
| app/(panel)/guardian/results | 1 | 86 | 0 | 7 | 93 |
| app/(panel)/guardian/settings | 1 | 95 | 0 | 8 | 103 |
| app/(panel)/student | 9 | 1,296 | 8 | 151 | 1,455 |
| app/(panel)/student (Files) | 2 | 237 | 2 | 22 | 261 |
| app/(panel)/student/attendance | 1 | 209 | 0 | 26 | 235 |
| app/(panel)/student/fees | 1 | 304 | 0 | 23 | 327 |
| app/(panel)/student/notices | 1 | 100 | 0 | 13 | 113 |
| app/(panel)/student/profile | 1 | 143 | 0 | 14 | 157 |
| app/(panel)/student/results | 1 | 130 | 0 | 14 | 144 |
| app/(panel)/student/routine | 1 | 104 | 0 | 16 | 120 |
| app/(panel)/student/settings | 1 | 69 | 6 | 23 | 98 |
| app/(panel)/teacher | 19 | 3,055 | 7 | 235 | 3,297 |
| app/(panel)/teacher (Files) | 2 | 340 | 7 | 30 | 377 |
| app/(panel)/teacher/attendance | 4 | 667 | 0 | 53 | 720 |
| app/(panel)/teacher/attendance (Files) | 1 | 48 | 0 | 4 | 52 |
| app/(panel)/teacher/attendance/take | 1 | 284 | 0 | 23 | 307 |
| app/(panel)/teacher/attendance/view | 2 | 335 | 0 | 26 | 361 |
| app/(panel)/teacher/attendance/view (Files) | 1 | 224 | 0 | 13 | 237 |
| app/(panel)/teacher/attendance/view/[id] | 1 | 111 | 0 | 13 | 124 |
| app/(panel)/teacher/notices | 2 | 159 | 0 | 17 | 176 |
| app/(panel)/teacher/notices (Files) | 1 | 75 | 0 | 9 | 84 |
| app/(panel)/teacher/notices/create | 1 | 84 | 0 | 8 | 92 |
| app/(panel)/teacher/results | 3 | 503 | 0 | 28 | 531 |
| app/(panel)/teacher/results (Files) | 1 | 46 | 0 | 4 | 50 |
| app/(panel)/teacher/results/create | 1 | 265 | 0 | 13 | 278 |
| app/(panel)/teacher/results/view | 1 | 192 | 0 | 11 | 203 |
| app/(panel)/teacher/settings | 1 | 265 | 0 | 15 | 280 |
| app/(panel)/teacher/students | 6 | 1,027 | 0 | 81 | 1,108 |
| app/(panel)/teacher/students (Files) | 2 | 386 | 0 | 24 | 410 |
| app/(panel)/teacher/students/[id] | 2 | 233 | 0 | 26 | 259 |
| app/(panel)/teacher/students/[id] (Files) | 1 | 135 | 0 | 15 | 150 |
| app/(panel)/teacher/students/[id]/attendance | 1 | 98 | 0 | 11 | 109 |
| app/(panel)/teacher/students/view | 2 | 408 | 0 | 31 | 439 |
| app/(panel)/teacher/students/view (Files) | 1 | 182 | 0 | 15 | 197 |
| app/(panel)/teacher/students/view/[id] | 1 | 226 | 0 | 16 | 242 |
| app/(panel)/teacher/timetable | 1 | 94 | 0 | 11 | 105 |
| app/(protected) | 3 | 838 | 2 | 62 | 902 |
| app/(protected)/admission | 3 | 838 | 2 | 62 | 902 |
| app/(public) | 1 | 73 | 0 | 4 | 77 |
| app/(public)/gallery | 1 | 73 | 0 | 4 | 77 |
| app/admin | 45 | 2,626 | 2 | 215 | 2,843 |
| app/admin (Files) | 2 | 40 | 0 | 8 | 48 |
| app/admin/academic | 8 | 654 | 2 | 47 | 703 |
| app/admin/academic (Files) | 1 | 56 | 0 | 5 | 61 |
| app/admin/academic/attendance | 1 | 9 | 0 | 2 | 11 |
| app/admin/academic/documents | 1 | 28 | 0 | 2 | 30 |
| app/admin/academic/exams | 4 | 552 | 2 | 36 | 590 |
| app/admin/academic/exams (Files) | 2 | 62 | 0 | 8 | 70 |
| app/admin/academic/exams/create | 1 | 486 | 2 | 26 | 514 |
| app/admin/academic/exams/show | 1 | 4 | 0 | 2 | 6 |
| app/admin/academic/results | 1 | 9 | 0 | 2 | 11 |
| app/admin/admissions | 3 | 85 | 0 | 8 | 93 |
| app/admin/admissions (Files) | 1 | 60 | 0 | 4 | 64 |
| app/admin/admissions/new | 1 | 16 | 0 | 2 | 18 |
| app/admin/admissions/view | 1 | 9 | 0 | 2 | 11 |
| app/admin/classes | 2 | 22 | 0 | 7 | 29 |
| app/admin/classes (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/classes/[id] | 1 | 13 | 0 | 5 | 18 |
| app/admin/classes/[id]/groups | 1 | 13 | 0 | 5 | 18 |
| app/admin/dashboard | 1 | 815 | 0 | 31 | 846 |
| app/admin/fees | 9 | 346 | 0 | 34 | 380 |
| app/admin/fees (Files) | 1 | 33 | 0 | 2 | 35 |
| app/admin/fees/categories | 1 | 9 | 0 | 2 | 11 |
| app/admin/fees/category | 1 | 4 | 0 | 2 | 6 |
| app/admin/fees/catgegory | 1 | 4 | 0 | 2 | 6 |
| app/admin/fees/monthly | 1 | 9 | 0 | 2 | 11 |
| app/admin/fees/payments | 3 | 86 | 0 | 10 | 96 |
| app/admin/fees/payments (Files) | 1 | 64 | 0 | 4 | 68 |
| app/admin/fees/payments/monthly | 1 | 11 | 0 | 3 | 14 |
| app/admin/fees/payments/secondary | 1 | 11 | 0 | 3 | 14 |
| app/admin/fees/reports | 1 | 201 | 0 | 14 | 215 |
| app/admin/guardians | 3 | 27 | 0 | 6 | 33 |
| app/admin/guardians (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/guardians/create | 1 | 9 | 0 | 2 | 11 |
| app/admin/guardians/view | 1 | 9 | 0 | 2 | 11 |
| app/admin/hr | 5 | 45 | 0 | 14 | 59 |
| app/admin/hr (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/hr/departments | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/designations | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/leaves | 1 | 9 | 0 | 3 | 12 |
| app/admin/hr/payroll | 1 | 9 | 0 | 3 | 12 |
| app/admin/login | 1 | 4 | 0 | 2 | 6 |
| app/admin/notices | 2 | 22 | 0 | 7 | 29 |
| app/admin/notices (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/notices/[id] | 1 | 13 | 0 | 5 | 18 |
| app/admin/settings | 1 | 436 | 0 | 31 | 467 |
| app/admin/students | 3 | 27 | 0 | 8 | 35 |
| app/admin/students (Files) | 1 | 9 | 0 | 2 | 11 |
| app/admin/students/create | 1 | 9 | 0 | 3 | 12 |
| app/admin/students/view | 1 | 9 | 0 | 3 | 12 |
| app/admin/subjects | 1 | 9 | 0 | 2 | 11 |
| app/admin/teachers | 1 | 9 | 0 | 2 | 11 |
| app/admin/users | 3 | 85 | 0 | 8 | 93 |
| app/admin/users (Files) | 1 | 60 | 0 | 4 | 64 |
| app/admin/users/create | 1 | 16 | 0 | 2 | 18 |
| app/admin/users/view | 1 | 9 | 0 | 2 | 11 |
| app/api | 112 | 4,184 | 12 | 527 | 4,723 |
| app/api/send | 1 | 141 | 4 | 16 | 161 |
| app/api/v1 | 111 | 4,043 | 8 | 511 | 4,562 |
| app/api/v1/admin | 1 | 16 | 0 | 2 | 18 |
| app/api/v1/admin/dashboard | 1 | 16 | 0 | 2 | 18 |
| app/api/v1/admissions | 2 | 106 | 0 | 15 | 121 |
| app/api/v1/admissions (Files) | 1 | 45 | 0 | 7 | 52 |
| app/api/v1/admissions/[id] | 1 | 61 | 0 | 8 | 69 |
| app/api/v1/attendance | 3 | 103 | 0 | 9 | 112 |
| app/api/v1/attendance (Files) | 1 | 46 | 0 | 3 | 49 |
| app/api/v1/attendance/class | 1 | 29 | 0 | 3 | 32 |
| app/api/v1/attendance/class/[classId] | 1 | 29 | 0 | 3 | 32 |
| app/api/v1/attendance/student | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/attendance/student/[studentId] | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/audit-logs | 1 | 55 | 0 | 6 | 61 |
| app/api/v1/auth | 8 | 162 | 0 | 25 | 187 |
| app/api/v1/auth/forgot-password | 1 | 14 | 0 | 2 | 16 |
| app/api/v1/auth/login | 1 | 17 | 0 | 2 | 19 |
| app/api/v1/auth/logout | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/auth/me | 1 | 17 | 0 | 4 | 21 |
| app/api/v1/auth/refresh | 1 | 20 | 0 | 5 | 25 |
| app/api/v1/auth/register | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/auth/reset-password | 1 | 20 | 0 | 2 | 22 |
| app/api/v1/auth/session | 1 | 28 | 0 | 5 | 33 |
| app/api/v1/classes | 5 | 232 | 0 | 26 | 258 |
| app/api/v1/classes (Files) | 1 | 52 | 0 | 4 | 56 |
| app/api/v1/classes/[id] | 3 | 154 | 0 | 16 | 170 |
| app/api/v1/classes/[id] (Files) | 1 | 53 | 0 | 4 | 57 |
| app/api/v1/classes/[id]/groups | 2 | 101 | 0 | 12 | 113 |
| app/api/v1/classes/[id]/groups (Files) | 1 | 48 | 0 | 6 | 54 |
| app/api/v1/classes/[id]/groups/[groupId] | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/classes/order | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/exams | 2 | 165 | 0 | 18 | 183 |
| app/api/v1/exams (Files) | 1 | 40 | 0 | 3 | 43 |
| app/api/v1/exams/[id] | 1 | 125 | 0 | 15 | 140 |
| app/api/v1/fees | 7 | 315 | 2 | 31 | 348 |
| app/api/v1/fees/categories | 2 | 101 | 2 | 7 | 110 |
| app/api/v1/fees/categories (Files) | 1 | 38 | 0 | 3 | 41 |
| app/api/v1/fees/categories/[id] | 1 | 63 | 2 | 4 | 69 |
| app/api/v1/fees/dues | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/fees/dues/generate | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/fees/monthly | 1 | 39 | 0 | 5 | 44 |
| app/api/v1/fees/payments | 3 | 149 | 0 | 13 | 162 |
| app/api/v1/fees/payments (Files) | 1 | 48 | 0 | 3 | 51 |
| app/api/v1/fees/payments/[id] | 2 | 101 | 0 | 10 | 111 |
| app/api/v1/fees/payments/[id] (Files) | 1 | 48 | 0 | 4 | 52 |
| app/api/v1/fees/payments/[id]/receipt | 1 | 53 | 0 | 6 | 59 |
| app/api/v1/finance | 4 | 193 | 0 | 38 | 231 |
| app/api/v1/finance/categories | 2 | 80 | 0 | 17 | 97 |
| app/api/v1/finance/categories (Files) | 1 | 53 | 0 | 10 | 63 |
| app/api/v1/finance/categories/[id] | 1 | 27 | 0 | 7 | 34 |
| app/api/v1/finance/entries | 2 | 113 | 0 | 21 | 134 |
| app/api/v1/finance/entries (Files) | 1 | 66 | 0 | 10 | 76 |
| app/api/v1/finance/entries/[id] | 1 | 47 | 0 | 11 | 58 |
| app/api/v1/guardian | 11 | 343 | 0 | 36 | 379 |
| app/api/v1/guardian/attendance | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/children | 2 | 38 | 0 | 5 | 43 |
| app/api/v1/guardian/children (Files) | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/guardian/children/[id] | 1 | 20 | 0 | 3 | 23 |
| app/api/v1/guardian/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/guardian/fees | 2 | 72 | 0 | 9 | 81 |
| app/api/v1/guardian/fees (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/fees/[id] | 1 | 53 | 0 | 7 | 60 |
| app/api/v1/guardian/fees/[id]/receipt | 1 | 53 | 0 | 7 | 60 |
| app/api/v1/guardian/notices | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/profile | 1 | 36 | 0 | 3 | 39 |
| app/api/v1/guardian/results | 2 | 118 | 0 | 11 | 129 |
| app/api/v1/guardian/results (Files) | 1 | 19 | 0 | 2 | 21 |
| app/api/v1/guardian/results/export | 1 | 99 | 0 | 9 | 108 |
| app/api/v1/guardian/settings | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/guardian/settings/password | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/guardians | 3 | 116 | 0 | 11 | 127 |
| app/api/v1/guardians (Files) | 1 | 41 | 0 | 3 | 44 |
| app/api/v1/guardians/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/guardians/transfer-student | 1 | 31 | 0 | 4 | 35 |
| app/api/v1/hr | 9 | 330 | 0 | 37 | 367 |
| app/api/v1/hr/departments | 2 | 65 | 0 | 8 | 73 |
| app/api/v1/hr/departments (Files) | 1 | 38 | 0 | 4 | 42 |
| app/api/v1/hr/departments/[id] | 1 | 27 | 0 | 4 | 31 |
| app/api/v1/hr/designations | 2 | 65 | 0 | 8 | 73 |
| app/api/v1/hr/designations (Files) | 1 | 38 | 0 | 4 | 42 |
| app/api/v1/hr/designations/[id] | 1 | 27 | 0 | 4 | 31 |
| app/api/v1/hr/leaves | 2 | 77 | 0 | 7 | 84 |
| app/api/v1/hr/leaves (Files) | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/hr/leaves/[id] | 1 | 33 | 0 | 3 | 36 |
| app/api/v1/hr/payroll | 3 | 123 | 0 | 14 | 137 |
| app/api/v1/hr/payroll/items | 1 | 28 | 0 | 4 | 32 |
| app/api/v1/hr/payroll/items/[id] | 1 | 28 | 0 | 4 | 32 |
| app/api/v1/hr/payroll/runs | 2 | 95 | 0 | 10 | 105 |
| app/api/v1/hr/payroll/runs (Files) | 1 | 43 | 0 | 4 | 47 |
| app/api/v1/hr/payroll/runs/[id] | 1 | 52 | 0 | 6 | 58 |
| app/api/v1/notices | 4 | 167 | 0 | 21 | 188 |
| app/api/v1/notices (Files) | 1 | 40 | 0 | 3 | 43 |
| app/api/v1/notices/[id] | 2 | 84 | 0 | 11 | 95 |
| app/api/v1/notices/[id] (Files) | 1 | 59 | 0 | 5 | 64 |
| app/api/v1/notices/[id]/publish | 1 | 25 | 0 | 6 | 31 |
| app/api/v1/notices/template | 1 | 43 | 0 | 7 | 50 |
| app/api/v1/notifications | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/notifications/reminders | 1 | 28 | 0 | 3 | 31 |
| app/api/v1/public | 1 | 11 | 0 | 3 | 14 |
| app/api/v1/public/branches | 1 | 11 | 0 | 3 | 14 |
| app/api/v1/reports | 4 | 137 | 0 | 24 | 161 |
| app/api/v1/reports/dues | 1 | 24 | 0 | 5 | 29 |
| app/api/v1/reports/fees | 1 | 71 | 0 | 9 | 80 |
| app/api/v1/reports/finance | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/reports/finance/monthly | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/reports/gender-count | 1 | 21 | 0 | 5 | 26 |
| app/api/v1/results | 4 | 132 | 0 | 13 | 145 |
| app/api/v1/results (Files) | 1 | 42 | 0 | 3 | 45 |
| app/api/v1/results/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/results/exam | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/exam/[examId] | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/student | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/results/student/[studentId] | 1 | 23 | 0 | 3 | 26 |
| app/api/v1/sessions | 4 | 136 | 0 | 29 | 165 |
| app/api/v1/sessions (Files) | 1 | 46 | 0 | 9 | 55 |
| app/api/v1/sessions/current | 1 | 38 | 0 | 8 | 46 |
| app/api/v1/sessions/migrate | 2 | 52 | 0 | 12 | 64 |
| app/api/v1/sessions/migrate (Files) | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/sessions/migrate/auto-next | 1 | 26 | 0 | 6 | 32 |
| app/api/v1/student | 7 | 126 | 0 | 14 | 140 |
| app/api/v1/student-document-template | 1 | 37 | 0 | 6 | 43 |
| app/api/v1/student/attendance | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/fees | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/notices | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/profile | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/results | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/student/timetable | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/students | 3 | 178 | 0 | 29 | 207 |
| app/api/v1/students (Files) | 1 | 53 | 0 | 7 | 60 |
| app/api/v1/students/[id] | 2 | 125 | 0 | 22 | 147 |
| app/api/v1/students/[id] (Files) | 1 | 55 | 0 | 8 | 63 |
| app/api/v1/students/[id]/documents | 1 | 70 | 0 | 14 | 84 |
| app/api/v1/subjects | 2 | 83 | 0 | 7 | 90 |
| app/api/v1/subjects (Files) | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/subjects/[id] | 1 | 44 | 0 | 4 | 48 |
| app/api/v1/super | 2 | 73 | 0 | 10 | 83 |
| app/api/v1/super/branches | 2 | 73 | 0 | 10 | 83 |
| app/api/v1/super/branches (Files) | 1 | 41 | 0 | 5 | 46 |
| app/api/v1/super/branches/[id] | 1 | 32 | 0 | 5 | 37 |
| app/api/v1/system-settings | 1 | 40 | 0 | 7 | 47 |
| app/api/v1/teacher | 9 | 243 | 0 | 23 | 266 |
| app/api/v1/teacher-subjects | 2 | 93 | 0 | 7 | 100 |
| app/api/v1/teacher-subjects (Files) | 1 | 46 | 0 | 3 | 49 |
| app/api/v1/teacher-subjects/[id] | 1 | 47 | 0 | 4 | 51 |
| app/api/v1/teacher/attendance | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/teacher/dashboard | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teacher/notices | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teacher/results | 1 | 39 | 0 | 3 | 42 |
| app/api/v1/teacher/settings | 2 | 57 | 0 | 5 | 62 |
| app/api/v1/teacher/settings (Files) | 1 | 34 | 0 | 3 | 37 |
| app/api/v1/teacher/settings/password | 1 | 23 | 0 | 2 | 25 |
| app/api/v1/teacher/students | 2 | 54 | 0 | 6 | 60 |
| app/api/v1/teacher/students (Files) | 1 | 32 | 0 | 3 | 35 |
| app/api/v1/teacher/students/[id] | 1 | 22 | 0 | 3 | 25 |
| app/api/v1/teacher/timetable | 1 | 18 | 0 | 2 | 20 |
| app/api/v1/teachers | 2 | 102 | 0 | 15 | 117 |
| app/api/v1/teachers (Files) | 1 | 51 | 0 | 7 | 58 |
| app/api/v1/teachers/[id] | 1 | 51 | 0 | 8 | 59 |
| app/api/v1/theme | 2 | 56 | 6 | 11 | 73 |
| app/api/v1/theme/global | 1 | 28 | 6 | 3 | 37 |
| app/api/v1/theme/user | 1 | 28 | 0 | 8 | 36 |
| app/api/v1/timetable | 2 | 95 | 0 | 7 | 102 |
| app/api/v1/timetable (Files) | 1 | 47 | 0 | 3 | 50 |
| app/api/v1/timetable/[id] | 1 | 48 | 0 | 4 | 52 |
| app/api/v1/trash | 2 | 55 | 0 | 12 | 67 |
| app/api/v1/trash (Files) | 1 | 24 | 0 | 5 | 29 |
| app/api/v1/trash/restore | 1 | 31 | 0 | 7 | 38 |
| app/api/v1/users | 2 | 115 | 0 | 16 | 131 |
| app/api/v1/users (Files) | 1 | 64 | 0 | 8 | 72 |
| app/api/v1/users/[id] | 1 | 51 | 0 | 8 | 59 |
| app/dashboard | 1 | 4 | 0 | 2 | 6 |
| app/login | 1 | 88 | 0 | 13 | 101 |
| app/register | 1 | 130 | 0 | 17 | 147 |
| app/reset-password | 1 | 116 | 0 | 16 | 132 |
| app/send-email | 1 | 111 | 0 | 16 | 127 |
| app/staff | 1 | 152 | 1 | 20 | 173 |
| app/staff/login | 1 | 152 | 1 | 20 | 173 |
| components | 77 | 17,824 | 42 | 1,299 | 19,165 |
| components (Files) | 24 | 2,237 | 21 | 166 | 2,424 |
| components/admin | 29 | 13,219 | 9 | 890 | 14,118 |
| components/gallery | 1 | 48 | 2 | 6 | 56 |
| components/teacher | 2 | 57 | 0 | 8 | 65 |
| components/ui | 21 | 2,263 | 10 | 229 | 2,502 |
| constants | 4 | 203 | 6 | 17 | 226 |
| emails | 1 | 70 | 0 | 4 | 74 |
| hooks | 1 | 15 | 0 | 5 | 20 |
| lib | 19 | 2,744 | 25 | 181 | 2,950 |
| lib (Files) | 15 | 1,504 | 25 | 144 | 1,673 |
| lib/student-document-pdf-modules | 4 | 1,240 | 0 | 37 | 1,277 |
| repositories | 28 | 3,386 | 0 | 313 | 3,699 |
| services | 37 | 9,944 | 6 | 1,061 | 11,011 |
| types | 6 | 14 | 3 | 7 | 24 |
| utils | 6 | 181 | 19 | 36 | 236 |
| validations | 29 | 937 | 0 | 162 | 1,099 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)