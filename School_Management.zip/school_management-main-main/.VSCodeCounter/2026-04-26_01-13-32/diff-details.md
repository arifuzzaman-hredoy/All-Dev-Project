# Diff Details

Date : 2026-04-26 01:13:32

Directory /home/mahi/github_p/school_erp/src

Total : 447 files,  46429 codes, 130 comments, 4064 blanks, all 50623 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/app/(panel)/guardian/attendance/page.tsx](/src/app/(panel)/guardian/attendance/page.tsx) | TypeScript JSX | 104 | 0 | 7 | 111 |
| [src/app/(panel)/guardian/children/\[id\]/page.tsx](/src/app/(panel)/guardian/children/%5Bid%5D/page.tsx) | TypeScript JSX | 343 | 0 | 11 | 354 |
| [src/app/(panel)/guardian/children/page.tsx](/src/app/(panel)/guardian/children/page.tsx) | TypeScript JSX | 44 | 0 | 6 | 50 |
| [src/app/(panel)/guardian/fees/page.tsx](/src/app/(panel)/guardian/fees/page.tsx) | TypeScript JSX | 266 | 0 | 16 | 282 |
| [src/app/(panel)/guardian/layout.tsx](/src/app/(panel)/guardian/layout.tsx) | TypeScript JSX | 25 | 0 | 4 | 29 |
| [src/app/(panel)/guardian/notices/page.tsx](/src/app/(panel)/guardian/notices/page.tsx) | TypeScript JSX | 56 | 0 | 6 | 62 |
| [src/app/(panel)/guardian/page.tsx](/src/app/(panel)/guardian/page.tsx) | TypeScript JSX | 179 | 0 | 6 | 185 |
| [src/app/(panel)/guardian/profile/page.tsx](/src/app/(panel)/guardian/profile/page.tsx) | TypeScript JSX | 48 | 0 | 6 | 54 |
| [src/app/(panel)/guardian/results/page.tsx](/src/app/(panel)/guardian/results/page.tsx) | TypeScript JSX | 86 | 0 | 7 | 93 |
| [src/app/(panel)/guardian/settings/page.tsx](/src/app/(panel)/guardian/settings/page.tsx) | TypeScript JSX | 95 | 0 | 8 | 103 |
| [src/app/(panel)/student/attendance/page.tsx](/src/app/(panel)/student/attendance/page.tsx) | TypeScript JSX | 209 | 0 | 26 | 235 |
| [src/app/(panel)/student/fees/page.tsx](/src/app/(panel)/student/fees/page.tsx) | TypeScript JSX | 304 | 0 | 23 | 327 |
| [src/app/(panel)/student/layout.tsx](/src/app/(panel)/student/layout.tsx) | TypeScript JSX | 31 | 2 | 8 | 41 |
| [src/app/(panel)/student/notices/page.tsx](/src/app/(panel)/student/notices/page.tsx) | TypeScript JSX | 100 | 0 | 13 | 113 |
| [src/app/(panel)/student/page.tsx](/src/app/(panel)/student/page.tsx) | TypeScript JSX | 206 | 0 | 14 | 220 |
| [src/app/(panel)/student/profile/page.tsx](/src/app/(panel)/student/profile/page.tsx) | TypeScript JSX | 143 | 0 | 14 | 157 |
| [src/app/(panel)/student/results/page.tsx](/src/app/(panel)/student/results/page.tsx) | TypeScript JSX | 130 | 0 | 14 | 144 |
| [src/app/(panel)/student/routine/page.tsx](/src/app/(panel)/student/routine/page.tsx) | TypeScript JSX | 104 | 0 | 16 | 120 |
| [src/app/(panel)/student/settings/page.tsx](/src/app/(panel)/student/settings/page.tsx) | TypeScript JSX | 69 | 6 | 23 | 98 |
| [src/app/(panel)/teacher/attendance/page.tsx](/src/app/(panel)/teacher/attendance/page.tsx) | TypeScript JSX | 48 | 0 | 4 | 52 |
| [src/app/(panel)/teacher/attendance/take/page.tsx](/src/app/(panel)/teacher/attendance/take/page.tsx) | TypeScript JSX | 284 | 0 | 23 | 307 |
| [src/app/(panel)/teacher/attendance/view/\[id\]/page.tsx](/src/app/(panel)/teacher/attendance/view/%5Bid%5D/page.tsx) | TypeScript JSX | 111 | 0 | 13 | 124 |
| [src/app/(panel)/teacher/attendance/view/page.tsx](/src/app/(panel)/teacher/attendance/view/page.tsx) | TypeScript JSX | 224 | 0 | 13 | 237 |
| [src/app/(panel)/teacher/layout.tsx](/src/app/(panel)/teacher/layout.tsx) | TypeScript JSX | 31 | 7 | 11 | 49 |
| [src/app/(panel)/teacher/notices/create/page.tsx](/src/app/(panel)/teacher/notices/create/page.tsx) | TypeScript JSX | 84 | 0 | 8 | 92 |
| [src/app/(panel)/teacher/notices/page.tsx](/src/app/(panel)/teacher/notices/page.tsx) | TypeScript JSX | 75 | 0 | 9 | 84 |
| [src/app/(panel)/teacher/page.tsx](/src/app/(panel)/teacher/page.tsx) | TypeScript JSX | 309 | 0 | 19 | 328 |
| [src/app/(panel)/teacher/results/create/page.tsx](/src/app/(panel)/teacher/results/create/page.tsx) | TypeScript JSX | 265 | 0 | 13 | 278 |
| [src/app/(panel)/teacher/results/page.tsx](/src/app/(panel)/teacher/results/page.tsx) | TypeScript JSX | 46 | 0 | 4 | 50 |
| [src/app/(panel)/teacher/results/view/page.tsx](/src/app/(panel)/teacher/results/view/page.tsx) | TypeScript JSX | 192 | 0 | 11 | 203 |
| [src/app/(panel)/teacher/settings/page.tsx](/src/app/(panel)/teacher/settings/page.tsx) | TypeScript JSX | 265 | 0 | 15 | 280 |
| [src/app/(panel)/teacher/students/\[id\]/attendance/page.tsx](/src/app/(panel)/teacher/students/%5Bid%5D/attendance/page.tsx) | TypeScript JSX | 98 | 0 | 11 | 109 |
| [src/app/(panel)/teacher/students/\[id\]/page.tsx](/src/app/(panel)/teacher/students/%5Bid%5D/page.tsx) | TypeScript JSX | 135 | 0 | 15 | 150 |
| [src/app/(panel)/teacher/students/data.ts](/src/app/(panel)/teacher/students/data.ts) | TypeScript | 180 | 0 | 6 | 186 |
| [src/app/(panel)/teacher/students/page.tsx](/src/app/(panel)/teacher/students/page.tsx) | TypeScript JSX | 206 | 0 | 18 | 224 |
| [src/app/(panel)/teacher/students/view/\[id\]/page.tsx](/src/app/(panel)/teacher/students/view/%5Bid%5D/page.tsx) | TypeScript JSX | 226 | 0 | 16 | 242 |
| [src/app/(panel)/teacher/students/view/page.tsx](/src/app/(panel)/teacher/students/view/page.tsx) | TypeScript JSX | 182 | 0 | 15 | 197 |
| [src/app/(panel)/teacher/timetable/page.tsx](/src/app/(panel)/teacher/timetable/page.tsx) | TypeScript JSX | 94 | 0 | 11 | 105 |
| [src/app/(protected)/admission/admission-form.tsx](/src/app/(protected)/admission/admission-form.tsx) | TypeScript JSX | 810 | 2 | 51 | 863 |
| [src/app/(protected)/admission/layout.tsx](/src/app/(protected)/admission/layout.tsx) | TypeScript JSX | 16 | 0 | 5 | 21 |
| [src/app/(protected)/admission/page.tsx](/src/app/(protected)/admission/page.tsx) | TypeScript JSX | 12 | 0 | 6 | 18 |
| [src/app/(public)/gallery/page.tsx](/src/app/(public)/gallery/page.tsx) | TypeScript JSX | 73 | 0 | 4 | 77 |
| [src/app/admin/academic/attendance/page.tsx](/src/app/admin/academic/attendance/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/academic/documents/page.tsx](/src/app/admin/academic/documents/page.tsx) | TypeScript JSX | 28 | 0 | 2 | 30 |
| [src/app/admin/academic/exams/create/page.tsx](/src/app/admin/academic/exams/create/page.tsx) | TypeScript JSX | 486 | 2 | 26 | 514 |
| [src/app/admin/academic/exams/layout.tsx](/src/app/admin/academic/exams/layout.tsx) | TypeScript JSX | 26 | 0 | 5 | 31 |
| [src/app/admin/academic/exams/page.tsx](/src/app/admin/academic/exams/page.tsx) | TypeScript JSX | 36 | 0 | 3 | 39 |
| [src/app/admin/academic/exams/show/page.tsx](/src/app/admin/academic/exams/show/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/academic/page.tsx](/src/app/admin/academic/page.tsx) | TypeScript JSX | 56 | 0 | 5 | 61 |
| [src/app/admin/academic/results/page.tsx](/src/app/admin/academic/results/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/admissions/new/page.tsx](/src/app/admin/admissions/new/page.tsx) | TypeScript JSX | 16 | 0 | 2 | 18 |
| [src/app/admin/admissions/page.tsx](/src/app/admin/admissions/page.tsx) | TypeScript JSX | 60 | 0 | 4 | 64 |
| [src/app/admin/admissions/view/page.tsx](/src/app/admin/admissions/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/classes/\[id\]/groups/page.tsx](/src/app/admin/classes/%5Bid%5D/groups/page.tsx) | TypeScript JSX | 13 | 0 | 5 | 18 |
| [src/app/admin/classes/page.tsx](/src/app/admin/classes/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/dashboard/page.tsx](/src/app/admin/dashboard/page.tsx) | TypeScript JSX | 815 | 0 | 31 | 846 |
| [src/app/admin/fees/categories/page.tsx](/src/app/admin/fees/categories/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/fees/category/page.tsx](/src/app/admin/fees/category/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/fees/catgegory/page.tsx](/src/app/admin/fees/catgegory/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/fees/monthly/page.tsx](/src/app/admin/fees/monthly/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/fees/page.tsx](/src/app/admin/fees/page.tsx) | TypeScript JSX | 33 | 0 | 2 | 35 |
| [src/app/admin/fees/payments/monthly/page.tsx](/src/app/admin/fees/payments/monthly/page.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/app/admin/fees/payments/page.tsx](/src/app/admin/fees/payments/page.tsx) | TypeScript JSX | 64 | 0 | 4 | 68 |
| [src/app/admin/fees/payments/secondary/page.tsx](/src/app/admin/fees/payments/secondary/page.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/app/admin/fees/reports/page.tsx](/src/app/admin/fees/reports/page.tsx) | TypeScript JSX | 201 | 0 | 14 | 215 |
| [src/app/admin/guardians/create/page.tsx](/src/app/admin/guardians/create/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/guardians/page.tsx](/src/app/admin/guardians/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/guardians/view/page.tsx](/src/app/admin/guardians/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/hr/departments/page.tsx](/src/app/admin/hr/departments/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/designations/page.tsx](/src/app/admin/hr/designations/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/leaves/page.tsx](/src/app/admin/hr/leaves/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/hr/page.tsx](/src/app/admin/hr/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/hr/payroll/page.tsx](/src/app/admin/hr/payroll/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/layout.tsx](/src/app/admin/layout.tsx) | TypeScript JSX | 36 | 0 | 6 | 42 |
| [src/app/admin/login/page.tsx](/src/app/admin/login/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/notices/\[id\]/page.tsx](/src/app/admin/notices/%5Bid%5D/page.tsx) | TypeScript JSX | 13 | 0 | 5 | 18 |
| [src/app/admin/notices/page.tsx](/src/app/admin/notices/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/page.tsx](/src/app/admin/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/admin/settings/page.tsx](/src/app/admin/settings/page.tsx) | TypeScript JSX | 436 | 0 | 31 | 467 |
| [src/app/admin/students/create/page.tsx](/src/app/admin/students/create/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/students/page.tsx](/src/app/admin/students/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/students/view/page.tsx](/src/app/admin/students/view/page.tsx) | TypeScript JSX | 9 | 0 | 3 | 12 |
| [src/app/admin/subjects/page.tsx](/src/app/admin/subjects/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/teachers/page.tsx](/src/app/admin/teachers/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/admin/users/create/page.tsx](/src/app/admin/users/create/page.tsx) | TypeScript JSX | 16 | 0 | 2 | 18 |
| [src/app/admin/users/page.tsx](/src/app/admin/users/page.tsx) | TypeScript JSX | 60 | 0 | 4 | 64 |
| [src/app/admin/users/view/page.tsx](/src/app/admin/users/view/page.tsx) | TypeScript JSX | 9 | 0 | 2 | 11 |
| [src/app/api/send/route.ts](/src/app/api/send/route.ts) | TypeScript | 141 | 4 | 16 | 161 |
| [src/app/api/v1/admin/dashboard/route.ts](/src/app/api/v1/admin/dashboard/route.ts) | TypeScript | 16 | 0 | 2 | 18 |
| [src/app/api/v1/admissions/\[id\]/route.ts](/src/app/api/v1/admissions/%5Bid%5D/route.ts) | TypeScript | 61 | 0 | 8 | 69 |
| [src/app/api/v1/admissions/route.ts](/src/app/api/v1/admissions/route.ts) | TypeScript | 45 | 0 | 7 | 52 |
| [src/app/api/v1/attendance/class/\[classId\]/route.ts](/src/app/api/v1/attendance/class/%5BclassId%5D/route.ts) | TypeScript | 29 | 0 | 3 | 32 |
| [src/app/api/v1/attendance/route.ts](/src/app/api/v1/attendance/route.ts) | TypeScript | 46 | 0 | 3 | 49 |
| [src/app/api/v1/attendance/student/\[studentId\]/route.ts](/src/app/api/v1/attendance/student/%5BstudentId%5D/route.ts) | TypeScript | 28 | 0 | 3 | 31 |
| [src/app/api/v1/audit-logs/route.ts](/src/app/api/v1/audit-logs/route.ts) | TypeScript | 55 | 0 | 6 | 61 |
| [src/app/api/v1/auth/forgot-password/route.ts](/src/app/api/v1/auth/forgot-password/route.ts) | TypeScript | 14 | 0 | 2 | 16 |
| [src/app/api/v1/auth/login/route.ts](/src/app/api/v1/auth/login/route.ts) | TypeScript | 17 | 0 | 2 | 19 |
| [src/app/api/v1/auth/logout/route.ts](/src/app/api/v1/auth/logout/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/auth/me/route.ts](/src/app/api/v1/auth/me/route.ts) | TypeScript | 17 | 0 | 4 | 21 |
| [src/app/api/v1/auth/refresh/route.ts](/src/app/api/v1/auth/refresh/route.ts) | TypeScript | 20 | 0 | 5 | 25 |
| [src/app/api/v1/auth/register/route.ts](/src/app/api/v1/auth/register/route.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [src/app/api/v1/auth/reset-password/route.ts](/src/app/api/v1/auth/reset-password/route.ts) | TypeScript | 20 | 0 | 2 | 22 |
| [src/app/api/v1/auth/session/route.ts](/src/app/api/v1/auth/session/route.ts) | TypeScript | 28 | 0 | 5 | 33 |
| [src/app/api/v1/classes/\[id\]/groups/\[groupId\]/route.ts](/src/app/api/v1/classes/%5Bid%5D/groups/%5BgroupId%5D/route.ts) | TypeScript | 53 | 0 | 6 | 59 |
| [src/app/api/v1/classes/\[id\]/groups/route.ts](/src/app/api/v1/classes/%5Bid%5D/groups/route.ts) | TypeScript | 48 | 0 | 6 | 54 |
| [src/app/api/v1/classes/\[id\]/route.ts](/src/app/api/v1/classes/%5Bid%5D/route.ts) | TypeScript | 53 | 0 | 4 | 57 |
| [src/app/api/v1/classes/order/route.ts](/src/app/api/v1/classes/order/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/classes/route.ts](/src/app/api/v1/classes/route.ts) | TypeScript | 52 | 0 | 4 | 56 |
| [src/app/api/v1/exams/\[id\]/route.ts](/src/app/api/v1/exams/%5Bid%5D/route.ts) | TypeScript | 125 | 0 | 15 | 140 |
| [src/app/api/v1/exams/route.ts](/src/app/api/v1/exams/route.ts) | TypeScript | 40 | 0 | 3 | 43 |
| [src/app/api/v1/fees/categories/\[id\]/route.ts](/src/app/api/v1/fees/categories/%5Bid%5D/route.ts) | TypeScript | 63 | 2 | 4 | 69 |
| [src/app/api/v1/fees/categories/route.ts](/src/app/api/v1/fees/categories/route.ts) | TypeScript | 38 | 0 | 3 | 41 |
| [src/app/api/v1/fees/dues/generate/route.ts](/src/app/api/v1/fees/dues/generate/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/fees/monthly/route.ts](/src/app/api/v1/fees/monthly/route.ts) | TypeScript | 39 | 0 | 5 | 44 |
| [src/app/api/v1/fees/payments/\[id\]/receipt/route.ts](/src/app/api/v1/fees/payments/%5Bid%5D/receipt/route.ts) | TypeScript | 53 | 0 | 6 | 59 |
| [src/app/api/v1/fees/payments/\[id\]/route.ts](/src/app/api/v1/fees/payments/%5Bid%5D/route.ts) | TypeScript | 48 | 0 | 4 | 52 |
| [src/app/api/v1/fees/payments/route.ts](/src/app/api/v1/fees/payments/route.ts) | TypeScript | 48 | 0 | 3 | 51 |
| [src/app/api/v1/finance/categories/\[id\]/route.ts](/src/app/api/v1/finance/categories/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 7 | 34 |
| [src/app/api/v1/finance/categories/route.ts](/src/app/api/v1/finance/categories/route.ts) | TypeScript | 53 | 0 | 10 | 63 |
| [src/app/api/v1/finance/entries/\[id\]/route.ts](/src/app/api/v1/finance/entries/%5Bid%5D/route.ts) | TypeScript | 47 | 0 | 11 | 58 |
| [src/app/api/v1/finance/entries/route.ts](/src/app/api/v1/finance/entries/route.ts) | TypeScript | 66 | 0 | 10 | 76 |
| [src/app/api/v1/guardian/attendance/route.ts](/src/app/api/v1/guardian/attendance/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/children/\[id\]/route.ts](/src/app/api/v1/guardian/children/%5Bid%5D/route.ts) | TypeScript | 20 | 0 | 3 | 23 |
| [src/app/api/v1/guardian/children/route.ts](/src/app/api/v1/guardian/children/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/guardian/dashboard/route.ts](/src/app/api/v1/guardian/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/guardian/fees/\[id\]/receipt/route.ts](/src/app/api/v1/guardian/fees/%5Bid%5D/receipt/route.ts) | TypeScript | 53 | 0 | 7 | 60 |
| [src/app/api/v1/guardian/fees/route.ts](/src/app/api/v1/guardian/fees/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/notices/route.ts](/src/app/api/v1/guardian/notices/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/profile/route.ts](/src/app/api/v1/guardian/profile/route.ts) | TypeScript | 36 | 0 | 3 | 39 |
| [src/app/api/v1/guardian/results/export/route.ts](/src/app/api/v1/guardian/results/export/route.ts) | TypeScript | 99 | 0 | 9 | 108 |
| [src/app/api/v1/guardian/results/route.ts](/src/app/api/v1/guardian/results/route.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/app/api/v1/guardian/settings/password/route.ts](/src/app/api/v1/guardian/settings/password/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/guardians/\[id\]/route.ts](/src/app/api/v1/guardians/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/guardians/route.ts](/src/app/api/v1/guardians/route.ts) | TypeScript | 41 | 0 | 3 | 44 |
| [src/app/api/v1/guardians/transfer-student/route.ts](/src/app/api/v1/guardians/transfer-student/route.ts) | TypeScript | 31 | 0 | 4 | 35 |
| [src/app/api/v1/hr/departments/\[id\]/route.ts](/src/app/api/v1/hr/departments/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 4 | 31 |
| [src/app/api/v1/hr/departments/route.ts](/src/app/api/v1/hr/departments/route.ts) | TypeScript | 38 | 0 | 4 | 42 |
| [src/app/api/v1/hr/designations/\[id\]/route.ts](/src/app/api/v1/hr/designations/%5Bid%5D/route.ts) | TypeScript | 27 | 0 | 4 | 31 |
| [src/app/api/v1/hr/designations/route.ts](/src/app/api/v1/hr/designations/route.ts) | TypeScript | 38 | 0 | 4 | 42 |
| [src/app/api/v1/hr/leaves/\[id\]/route.ts](/src/app/api/v1/hr/leaves/%5Bid%5D/route.ts) | TypeScript | 33 | 0 | 3 | 36 |
| [src/app/api/v1/hr/leaves/route.ts](/src/app/api/v1/hr/leaves/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/hr/payroll/items/\[id\]/route.ts](/src/app/api/v1/hr/payroll/items/%5Bid%5D/route.ts) | TypeScript | 28 | 0 | 4 | 32 |
| [src/app/api/v1/hr/payroll/runs/\[id\]/route.ts](/src/app/api/v1/hr/payroll/runs/%5Bid%5D/route.ts) | TypeScript | 52 | 0 | 6 | 58 |
| [src/app/api/v1/hr/payroll/runs/route.ts](/src/app/api/v1/hr/payroll/runs/route.ts) | TypeScript | 43 | 0 | 4 | 47 |
| [src/app/api/v1/notices/\[id\]/publish/route.ts](/src/app/api/v1/notices/%5Bid%5D/publish/route.ts) | TypeScript | 25 | 0 | 6 | 31 |
| [src/app/api/v1/notices/\[id\]/route.ts](/src/app/api/v1/notices/%5Bid%5D/route.ts) | TypeScript | 59 | 0 | 5 | 64 |
| [src/app/api/v1/notices/route.ts](/src/app/api/v1/notices/route.ts) | TypeScript | 40 | 0 | 3 | 43 |
| [src/app/api/v1/notices/template/route.ts](/src/app/api/v1/notices/template/route.ts) | TypeScript | 43 | 0 | 7 | 50 |
| [src/app/api/v1/notifications/reminders/route.ts](/src/app/api/v1/notifications/reminders/route.ts) | TypeScript | 28 | 0 | 3 | 31 |
| [src/app/api/v1/public/branches/route.ts](/src/app/api/v1/public/branches/route.ts) | TypeScript | 11 | 0 | 3 | 14 |
| [src/app/api/v1/reports/dues/route.ts](/src/app/api/v1/reports/dues/route.ts) | TypeScript | 24 | 0 | 5 | 29 |
| [src/app/api/v1/reports/fees/route.ts](/src/app/api/v1/reports/fees/route.ts) | TypeScript | 71 | 0 | 9 | 80 |
| [src/app/api/v1/reports/finance/monthly/route.ts](/src/app/api/v1/reports/finance/monthly/route.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/app/api/v1/reports/gender-count/route.ts](/src/app/api/v1/reports/gender-count/route.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/app/api/v1/results/\[id\]/route.ts](/src/app/api/v1/results/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/results/exam/\[examId\]/route.ts](/src/app/api/v1/results/exam/%5BexamId%5D/route.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [src/app/api/v1/results/route.ts](/src/app/api/v1/results/route.ts) | TypeScript | 42 | 0 | 3 | 45 |
| [src/app/api/v1/results/student/\[studentId\]/route.ts](/src/app/api/v1/results/student/%5BstudentId%5D/route.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [src/app/api/v1/sessions/current/route.ts](/src/app/api/v1/sessions/current/route.ts) | TypeScript | 38 | 0 | 8 | 46 |
| [src/app/api/v1/sessions/migrate/auto-next/route.ts](/src/app/api/v1/sessions/migrate/auto-next/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/sessions/migrate/route.ts](/src/app/api/v1/sessions/migrate/route.ts) | TypeScript | 26 | 0 | 6 | 32 |
| [src/app/api/v1/sessions/route.ts](/src/app/api/v1/sessions/route.ts) | TypeScript | 46 | 0 | 9 | 55 |
| [src/app/api/v1/student-document-template/route.ts](/src/app/api/v1/student-document-template/route.ts) | TypeScript | 37 | 0 | 6 | 43 |
| [src/app/api/v1/student/attendance/route.ts](/src/app/api/v1/student/attendance/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/dashboard/route.ts](/src/app/api/v1/student/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/fees/route.ts](/src/app/api/v1/student/fees/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/notices/route.ts](/src/app/api/v1/student/notices/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/profile/route.ts](/src/app/api/v1/student/profile/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/results/route.ts](/src/app/api/v1/student/results/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/student/timetable/route.ts](/src/app/api/v1/student/timetable/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/students/\[id\]/documents/route.ts](/src/app/api/v1/students/%5Bid%5D/documents/route.ts) | TypeScript | 70 | 0 | 14 | 84 |
| [src/app/api/v1/students/\[id\]/route.ts](/src/app/api/v1/students/%5Bid%5D/route.ts) | TypeScript | 55 | 0 | 8 | 63 |
| [src/app/api/v1/students/route.ts](/src/app/api/v1/students/route.ts) | TypeScript | 53 | 0 | 7 | 60 |
| [src/app/api/v1/subjects/\[id\]/route.ts](/src/app/api/v1/subjects/%5Bid%5D/route.ts) | TypeScript | 44 | 0 | 4 | 48 |
| [src/app/api/v1/subjects/route.ts](/src/app/api/v1/subjects/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/super/branches/\[id\]/route.ts](/src/app/api/v1/super/branches/%5Bid%5D/route.ts) | TypeScript | 32 | 0 | 5 | 37 |
| [src/app/api/v1/super/branches/route.ts](/src/app/api/v1/super/branches/route.ts) | TypeScript | 41 | 0 | 5 | 46 |
| [src/app/api/v1/system-settings/route.ts](/src/app/api/v1/system-settings/route.ts) | TypeScript | 40 | 0 | 7 | 47 |
| [src/app/api/v1/teacher-subjects/\[id\]/route.ts](/src/app/api/v1/teacher-subjects/%5Bid%5D/route.ts) | TypeScript | 47 | 0 | 4 | 51 |
| [src/app/api/v1/teacher-subjects/route.ts](/src/app/api/v1/teacher-subjects/route.ts) | TypeScript | 46 | 0 | 3 | 49 |
| [src/app/api/v1/teacher/attendance/route.ts](/src/app/api/v1/teacher/attendance/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/teacher/dashboard/route.ts](/src/app/api/v1/teacher/dashboard/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teacher/notices/route.ts](/src/app/api/v1/teacher/notices/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teacher/results/route.ts](/src/app/api/v1/teacher/results/route.ts) | TypeScript | 39 | 0 | 3 | 42 |
| [src/app/api/v1/teacher/settings/password/route.ts](/src/app/api/v1/teacher/settings/password/route.ts) | TypeScript | 23 | 0 | 2 | 25 |
| [src/app/api/v1/teacher/settings/route.ts](/src/app/api/v1/teacher/settings/route.ts) | TypeScript | 34 | 0 | 3 | 37 |
| [src/app/api/v1/teacher/students/\[id\]/route.ts](/src/app/api/v1/teacher/students/%5Bid%5D/route.ts) | TypeScript | 22 | 0 | 3 | 25 |
| [src/app/api/v1/teacher/students/route.ts](/src/app/api/v1/teacher/students/route.ts) | TypeScript | 32 | 0 | 3 | 35 |
| [src/app/api/v1/teacher/timetable/route.ts](/src/app/api/v1/teacher/timetable/route.ts) | TypeScript | 18 | 0 | 2 | 20 |
| [src/app/api/v1/teachers/\[id\]/route.ts](/src/app/api/v1/teachers/%5Bid%5D/route.ts) | TypeScript | 51 | 0 | 8 | 59 |
| [src/app/api/v1/teachers/route.ts](/src/app/api/v1/teachers/route.ts) | TypeScript | 51 | 0 | 7 | 58 |
| [src/app/api/v1/theme/global/route.ts](/src/app/api/v1/theme/global/route.ts) | TypeScript | 28 | 6 | 3 | 37 |
| [src/app/api/v1/theme/user/route.ts](/src/app/api/v1/theme/user/route.ts) | TypeScript | 28 | 0 | 8 | 36 |
| [src/app/api/v1/timetable/\[id\]/route.ts](/src/app/api/v1/timetable/%5Bid%5D/route.ts) | TypeScript | 48 | 0 | 4 | 52 |
| [src/app/api/v1/timetable/route.ts](/src/app/api/v1/timetable/route.ts) | TypeScript | 47 | 0 | 3 | 50 |
| [src/app/api/v1/trash/restore/route.ts](/src/app/api/v1/trash/restore/route.ts) | TypeScript | 31 | 0 | 7 | 38 |
| [src/app/api/v1/trash/route.ts](/src/app/api/v1/trash/route.ts) | TypeScript | 24 | 0 | 5 | 29 |
| [src/app/api/v1/users/\[id\]/route.ts](/src/app/api/v1/users/%5Bid%5D/route.ts) | TypeScript | 51 | 0 | 8 | 59 |
| [src/app/api/v1/users/route.ts](/src/app/api/v1/users/route.ts) | TypeScript | 64 | 0 | 8 | 72 |
| [src/app/dashboard/page.tsx](/src/app/dashboard/page.tsx) | TypeScript JSX | 4 | 0 | 2 | 6 |
| [src/app/globals.css](/src/app/globals.css) | PostCSS | 124 | 0 | 5 | 129 |
| [src/app/layout.tsx](/src/app/layout.tsx) | TypeScript JSX | 51 | 0 | 6 | 57 |
| [src/app/login/page.tsx](/src/app/login/page.tsx) | TypeScript JSX | 88 | 0 | 13 | 101 |
| [src/app/page.tsx](/src/app/page.tsx) | TypeScript JSX | 34 | 0 | 8 | 42 |
| [src/app/register/page.tsx](/src/app/register/page.tsx) | TypeScript JSX | 130 | 0 | 17 | 147 |
| [src/app/reset-password/page.tsx](/src/app/reset-password/page.tsx) | TypeScript JSX | 116 | 0 | 16 | 132 |
| [src/app/send-email/page.tsx](/src/app/send-email/page.tsx) | TypeScript JSX | 111 | 0 | 16 | 127 |
| [src/app/staff/login/page.tsx](/src/app/staff/login/page.tsx) | TypeScript JSX | 152 | 1 | 20 | 173 |
| [src/components/GalleryCircleGroup.tsx](/src/components/GalleryCircleGroup.tsx) | TypeScript JSX | 29 | 1 | 3 | 33 |
| [src/components/admin/academic-operations-panel.tsx](/src/components/admin/academic-operations-panel.tsx) | TypeScript JSX | 246 | 0 | 16 | 262 |
| [src/components/admin/admin-access-guard.tsx](/src/components/admin/admin-access-guard.tsx) | TypeScript JSX | 64 | 0 | 14 | 78 |
| [src/components/admin/admission-management-panel.tsx](/src/components/admin/admission-management-panel.tsx) | TypeScript JSX | 1,014 | 0 | 56 | 1,070 |
| [src/components/admin/admission-new-application-panel.tsx](/src/components/admin/admission-new-application-panel.tsx) | TypeScript JSX | 251 | 0 | 10 | 261 |
| [src/components/admin/attendance-management-panel.tsx](/src/components/admin/attendance-management-panel.tsx) | TypeScript JSX | 113 | 0 | 12 | 125 |
| [src/components/admin/class-group-management-panel.tsx](/src/components/admin/class-group-management-panel.tsx) | TypeScript JSX | 317 | 0 | 27 | 344 |
| [src/components/admin/class-management-panel.tsx](/src/components/admin/class-management-panel.tsx) | TypeScript JSX | 451 | 0 | 22 | 473 |
| [src/components/admin/class-monthly-fee-management-panel.tsx](/src/components/admin/class-monthly-fee-management-panel.tsx) | TypeScript JSX | 281 | 0 | 29 | 310 |
| [src/components/admin/exam-management-panel.tsx](/src/components/admin/exam-management-panel.tsx) | TypeScript JSX | 1,859 | 0 | 52 | 1,911 |
| [src/components/admin/fee-category-management-panel.tsx](/src/components/admin/fee-category-management-panel.tsx) | TypeScript JSX | 727 | 5 | 69 | 801 |
| [src/components/admin/guardian-management-panel.tsx](/src/components/admin/guardian-management-panel.tsx) | TypeScript JSX | 863 | 2 | 45 | 910 |
| [src/components/admin/hr-department-panel.tsx](/src/components/admin/hr-department-panel.tsx) | TypeScript JSX | 268 | 0 | 19 | 287 |
| [src/components/admin/hr-designation-panel.tsx](/src/components/admin/hr-designation-panel.tsx) | TypeScript JSX | 268 | 0 | 19 | 287 |
| [src/components/admin/hr-leave-panel.tsx](/src/components/admin/hr-leave-panel.tsx) | TypeScript JSX | 371 | 0 | 27 | 398 |
| [src/components/admin/hr-overview-panel.tsx](/src/components/admin/hr-overview-panel.tsx) | TypeScript JSX | 61 | 0 | 5 | 66 |
| [src/components/admin/notice-editor-pad.tsx](/src/components/admin/notice-editor-pad.tsx) | TypeScript JSX | 388 | 0 | 34 | 422 |
| [src/components/admin/notice-management-panel.tsx](/src/components/admin/notice-management-panel.tsx) | TypeScript JSX | 385 | 0 | 45 | 430 |
| [src/components/admin/payment-management-page.tsx](/src/components/admin/payment-management-page.tsx) | TypeScript JSX | 1,015 | 0 | 71 | 1,086 |
| [src/components/admin/payment-management-panel.tsx](/src/components/admin/payment-management-panel.tsx) | TypeScript JSX | 597 | 0 | 35 | 632 |
| [src/components/admin/payroll-management-panel.tsx](/src/components/admin/payroll-management-panel.tsx) | TypeScript JSX | 396 | 0 | 28 | 424 |
| [src/components/admin/result-management-panel.tsx](/src/components/admin/result-management-panel.tsx) | TypeScript JSX | 104 | 0 | 11 | 115 |
| [src/components/admin/section-page.tsx](/src/components/admin/section-page.tsx) | TypeScript JSX | 89 | 0 | 10 | 99 |
| [src/components/admin/student-document-management-panel.tsx](/src/components/admin/student-document-management-panel.tsx) | TypeScript JSX | 242 | 0 | 25 | 267 |
| [src/components/admin/student-document-template-editor.tsx](/src/components/admin/student-document-template-editor.tsx) | TypeScript JSX | 163 | 0 | 20 | 183 |
| [src/components/admin/student-management-panel.tsx](/src/components/admin/student-management-panel.tsx) | TypeScript JSX | 1,311 | 2 | 54 | 1,367 |
| [src/components/admin/subject-management-panel.tsx](/src/components/admin/subject-management-panel.tsx) | TypeScript JSX | 94 | 0 | 11 | 105 |
| [src/components/admin/teacher-management-panel.tsx](/src/components/admin/teacher-management-panel.tsx) | TypeScript JSX | 450 | 0 | 38 | 488 |
| [src/components/admin/user-create-panel.tsx](/src/components/admin/user-create-panel.tsx) | TypeScript JSX | 328 | 0 | 40 | 368 |
| [src/components/admin/user-management-panel.tsx](/src/components/admin/user-management-panel.tsx) | TypeScript JSX | 503 | 0 | 46 | 549 |
| [src/components/app-sidebar-guardian.tsx](/src/components/app-sidebar-guardian.tsx) | TypeScript JSX | 70 | 0 | 5 | 75 |
| [src/components/app-sidebar-student.tsx](/src/components/app-sidebar-student.tsx) | TypeScript JSX | 104 | 2 | 11 | 117 |
| [src/components/app-sidebar-teacher.tsx](/src/components/app-sidebar-teacher.tsx) | TypeScript JSX | 117 | 1 | 15 | 133 |
| [src/components/app-sidebar.tsx](/src/components/app-sidebar.tsx) | TypeScript JSX | 305 | 0 | 18 | 323 |
| [src/components/circle-path.tsx](/src/components/circle-path.tsx) | TypeScript JSX | 114 | 0 | 7 | 121 |
| [src/components/code-block.tsx](/src/components/code-block.tsx) | TypeScript JSX | 14 | 0 | 4 | 18 |
| [src/components/contact-section.tsx](/src/components/contact-section.tsx) | TypeScript JSX | 156 | 1 | 3 | 160 |
| [src/components/cta-sections-03.tsx](/src/components/cta-sections-03.tsx) | TypeScript JSX | 55 | 2 | 6 | 63 |
| [src/components/footer-01.tsx](/src/components/footer-01.tsx) | TypeScript JSX | 91 | 0 | 3 | 94 |
| [src/components/gallery/gallery-component-01.tsx](/src/components/gallery/gallery-component-01.tsx) | TypeScript JSX | 48 | 2 | 6 | 56 |
| [src/components/hero-sections-05.tsx](/src/components/hero-sections-05.tsx) | TypeScript JSX | 92 | 0 | 8 | 100 |
| [src/components/marquee-effect.tsx](/src/components/marquee-effect.tsx) | TypeScript JSX | 90 | 0 | 11 | 101 |
| [src/components/mode-toggle.tsx](/src/components/mode-toggle.tsx) | TypeScript JSX | 24 | 0 | 6 | 30 |
| [src/components/nav-main.tsx](/src/components/nav-main.tsx) | TypeScript JSX | 131 | 0 | 12 | 143 |
| [src/components/nav-projects.tsx](/src/components/nav-projects.tsx) | TypeScript JSX | 83 | 0 | 4 | 87 |
| [src/components/nav-user.tsx](/src/components/nav-user.tsx) | TypeScript JSX | 108 | 0 | 4 | 112 |
| [src/components/navbars-02.tsx](/src/components/navbars-02.tsx) | TypeScript JSX | 281 | 14 | 10 | 305 |
| [src/components/page-header.tsx](/src/components/page-header.tsx) | TypeScript JSX | 22 | 0 | 4 | 26 |
| [src/components/result-display.tsx](/src/components/result-display.tsx) | TypeScript JSX | 22 | 0 | 4 | 26 |
| [src/components/search-form.tsx](/src/components/search-form.tsx) | TypeScript JSX | 27 | 0 | 3 | 30 |
| [src/components/teacher/page-shell.tsx](/src/components/teacher/page-shell.tsx) | TypeScript JSX | 21 | 0 | 4 | 25 |
| [src/components/teacher/section-card.tsx](/src/components/teacher/section-card.tsx) | TypeScript JSX | 36 | 0 | 4 | 40 |
| [src/components/team-switcher.tsx](/src/components/team-switcher.tsx) | TypeScript JSX | 86 | 0 | 6 | 92 |
| [src/components/testimonials-03.tsx](/src/components/testimonials-03.tsx) | TypeScript JSX | 147 | 0 | 10 | 157 |
| [src/components/theme-provider.tsx](/src/components/theme-provider.tsx) | TypeScript JSX | 7 | 0 | 4 | 11 |
| [src/components/ui/avatar.tsx](/src/components/ui/avatar.tsx) | TypeScript JSX | 103 | 0 | 10 | 113 |
| [src/components/ui/badge.tsx](/src/components/ui/badge.tsx) | TypeScript JSX | 44 | 0 | 6 | 50 |
| [src/components/ui/breadcrumb.tsx](/src/components/ui/breadcrumb.tsx) | TypeScript JSX | 112 | 0 | 11 | 123 |
| [src/components/ui/button.tsx](/src/components/ui/button.tsx) | TypeScript JSX | 60 | 0 | 6 | 66 |
| [src/components/ui/card.tsx](/src/components/ui/card.tsx) | TypeScript JSX | 94 | 0 | 10 | 104 |
| [src/components/ui/checkbox.tsx](/src/components/ui/checkbox.tsx) | TypeScript JSX | 29 | 0 | 5 | 34 |
| [src/components/ui/collapsible.tsx](/src/components/ui/collapsible.tsx) | TypeScript JSX | 28 | 0 | 6 | 34 |
| [src/components/ui/dropdown-menu.tsx](/src/components/ui/dropdown-menu.tsx) | TypeScript JSX | 251 | 0 | 19 | 270 |
| [src/components/ui/input-group.tsx](/src/components/ui/input-group.tsx) | TypeScript JSX | 144 | 0 | 12 | 156 |
| [src/components/ui/input.tsx](/src/components/ui/input.tsx) | TypeScript JSX | 16 | 0 | 4 | 20 |
| [src/components/ui/label.tsx](/src/components/ui/label.tsx) | TypeScript JSX | 20 | 0 | 5 | 25 |
| [src/components/ui/navigation-menu.tsx](/src/components/ui/navigation-menu.tsx) | TypeScript JSX | 153 | 0 | 12 | 165 |
| [src/components/ui/popover.tsx](/src/components/ui/popover.tsx) | TypeScript JSX | 79 | 0 | 11 | 90 |
| [src/components/ui/select.tsx](/src/components/ui/select.tsx) | TypeScript JSX | 179 | 0 | 14 | 193 |
| [src/components/ui/separator.tsx](/src/components/ui/separator.tsx) | TypeScript JSX | 24 | 0 | 5 | 29 |
| [src/components/ui/sheet.tsx](/src/components/ui/sheet.tsx) | TypeScript JSX | 131 | 0 | 14 | 145 |
| [src/components/ui/sidebar.tsx](/src/components/ui/sidebar.tsx) | TypeScript JSX | 638 | 10 | 55 | 703 |
| [src/components/ui/skeleton.tsx](/src/components/ui/skeleton.tsx) | TypeScript JSX | 11 | 0 | 3 | 14 |
| [src/components/ui/tabs.tsx](/src/components/ui/tabs.tsx) | TypeScript JSX | 82 | 0 | 9 | 91 |
| [src/components/ui/textarea.tsx](/src/components/ui/textarea.tsx) | TypeScript JSX | 15 | 0 | 4 | 19 |
| [src/components/ui/tooltip.tsx](/src/components/ui/tooltip.tsx) | TypeScript JSX | 50 | 0 | 8 | 58 |
| [src/components/version-switcher.tsx](/src/components/version-switcher.tsx) | TypeScript JSX | 62 | 0 | 5 | 67 |
| [src/constants/api.ts](/src/constants/api.ts) | TypeScript | 6 | 3 | 1 | 10 |
| [src/constants/errors.ts](/src/constants/errors.ts) | TypeScript | 5 | 3 | 1 | 9 |
| [src/constants/exam-types.ts](/src/constants/exam-types.ts) | TypeScript | 18 | 0 | 4 | 22 |
| [src/constants/roles.ts](/src/constants/roles.ts) | TypeScript | 174 | 0 | 11 | 185 |
| [src/emails/Welcome.tsx](/src/emails/Welcome.tsx) | TypeScript JSX | 70 | 0 | 4 | 74 |
| [src/hooks/use-mobile.ts](/src/hooks/use-mobile.ts) | TypeScript | 15 | 0 | 5 | 20 |
| [src/lib/attendance-summary.ts](/src/lib/attendance-summary.ts) | TypeScript | 81 | 0 | 12 | 93 |
| [src/lib/auth.ts](/src/lib/auth.ts) | TypeScript | 59 | 12 | 13 | 84 |
| [src/lib/client-api.ts](/src/lib/client-api.ts) | TypeScript | 76 | 1 | 19 | 96 |
| [src/lib/fee-history.ts](/src/lib/fee-history.ts) | TypeScript | 205 | 0 | 22 | 227 |
| [src/lib/fee-utils.ts](/src/lib/fee-utils.ts) | TypeScript | 35 | 0 | 5 | 40 |
| [src/lib/money-receipt.ts](/src/lib/money-receipt.ts) | TypeScript | 426 | 0 | 10 | 436 |
| [src/lib/permissions.ts](/src/lib/permissions.ts) | TypeScript | 25 | 9 | 5 | 39 |
| [src/lib/prisma.ts](/src/lib/prisma.ts) | TypeScript | 54 | 3 | 8 | 65 |
| [src/lib/resend.ts](/src/lib/resend.ts) | TypeScript | 4 | 0 | 4 | 8 |
| [src/lib/result-marks.ts](/src/lib/result-marks.ts) | TypeScript | 45 | 0 | 10 | 55 |
| [src/lib/role-routes.ts](/src/lib/role-routes.ts) | TypeScript | 8 | 0 | 2 | 10 |
| [src/lib/student-document-pdf-modules/character-certificate.ts](/src/lib/student-document-pdf-modules/character-certificate.ts) | TypeScript | 375 | 0 | 5 | 380 |
| [src/lib/student-document-pdf-modules/common.ts](/src/lib/student-document-pdf-modules/common.ts) | TypeScript | 119 | 0 | 22 | 141 |
| [src/lib/student-document-pdf-modules/testimonial.ts](/src/lib/student-document-pdf-modules/testimonial.ts) | TypeScript | 379 | 0 | 5 | 384 |
| [src/lib/student-document-pdf-modules/transfer-certificate.ts](/src/lib/student-document-pdf-modules/transfer-certificate.ts) | TypeScript | 367 | 0 | 5 | 372 |
| [src/lib/student-document-pdf.ts](/src/lib/student-document-pdf.ts) | TypeScript | 33 | 0 | 4 | 37 |
| [src/lib/student-document-template.ts](/src/lib/student-document-template.ts) | TypeScript | 83 | 0 | 13 | 96 |
| [src/lib/student-document.ts](/src/lib/student-document.ts) | TypeScript | 365 | 0 | 15 | 380 |
| [src/lib/utils.ts](/src/lib/utils.ts) | TypeScript | 5 | 0 | 2 | 7 |
| [src/repositories/admission.repository.ts](/src/repositories/admission.repository.ts) | TypeScript | 84 | 0 | 9 | 93 |
| [src/repositories/attendance.repository.ts](/src/repositories/attendance.repository.ts) | TypeScript | 139 | 0 | 6 | 145 |
| [src/repositories/auditLog.repository.ts](/src/repositories/auditLog.repository.ts) | TypeScript | 140 | 0 | 13 | 153 |
| [src/repositories/branch.repository.ts](/src/repositories/branch.repository.ts) | TypeScript | 69 | 0 | 10 | 79 |
| [src/repositories/class.repository.ts](/src/repositories/class.repository.ts) | TypeScript | 257 | 0 | 32 | 289 |
| [src/repositories/classMonthlyFee.repository.ts](/src/repositories/classMonthlyFee.repository.ts) | TypeScript | 45 | 0 | 5 | 50 |
| [src/repositories/exam.repository.ts](/src/repositories/exam.repository.ts) | TypeScript | 248 | 0 | 10 | 258 |
| [src/repositories/feeCategory.repository.ts](/src/repositories/feeCategory.repository.ts) | TypeScript | 85 | 0 | 9 | 94 |
| [src/repositories/financeCategory.repository.ts](/src/repositories/financeCategory.repository.ts) | TypeScript | 63 | 0 | 9 | 72 |
| [src/repositories/financeEntry.repository.ts](/src/repositories/financeEntry.repository.ts) | TypeScript | 118 | 0 | 9 | 127 |
| [src/repositories/guardian.repository.ts](/src/repositories/guardian.repository.ts) | TypeScript | 199 | 0 | 18 | 217 |
| [src/repositories/hr.repository.ts](/src/repositories/hr.repository.ts) | TypeScript | 145 | 0 | 20 | 165 |
| [src/repositories/notice.repository.ts](/src/repositories/notice.repository.ts) | TypeScript | 104 | 0 | 10 | 114 |
| [src/repositories/notification.repository.ts](/src/repositories/notification.repository.ts) | TypeScript | 144 | 0 | 11 | 155 |
| [src/repositories/parent.repository.ts](/src/repositories/parent.repository.ts) | TypeScript | 103 | 0 | 8 | 111 |
| [src/repositories/passwordReset.repository.ts](/src/repositories/passwordReset.repository.ts) | TypeScript | 42 | 0 | 6 | 48 |
| [src/repositories/payment.repository.ts](/src/repositories/payment.repository.ts) | TypeScript | 148 | 0 | 11 | 159 |
| [src/repositories/payroll.repository.ts](/src/repositories/payroll.repository.ts) | TypeScript | 129 | 0 | 14 | 143 |
| [src/repositories/result.repository.ts](/src/repositories/result.repository.ts) | TypeScript | 141 | 0 | 9 | 150 |
| [src/repositories/school.repository.ts](/src/repositories/school.repository.ts) | TypeScript | 51 | 0 | 9 | 60 |
| [src/repositories/session.repository.ts](/src/repositories/session.repository.ts) | TypeScript | 78 | 0 | 11 | 89 |
| [src/repositories/student.repository.ts](/src/repositories/student.repository.ts) | TypeScript | 252 | 0 | 18 | 270 |
| [src/repositories/subject.repository.ts](/src/repositories/subject.repository.ts) | TypeScript | 86 | 0 | 9 | 95 |
| [src/repositories/systemSetting.repository.ts](/src/repositories/systemSetting.repository.ts) | TypeScript | 75 | 0 | 8 | 83 |
| [src/repositories/teacher.repository.ts](/src/repositories/teacher.repository.ts) | TypeScript | 122 | 0 | 9 | 131 |
| [src/repositories/teacherSubject.repository.ts](/src/repositories/teacherSubject.repository.ts) | TypeScript | 91 | 0 | 8 | 99 |
| [src/repositories/timetable.repository.ts](/src/repositories/timetable.repository.ts) | TypeScript | 93 | 0 | 8 | 101 |
| [src/repositories/user.repository.ts](/src/repositories/user.repository.ts) | TypeScript | 135 | 0 | 14 | 149 |
| [src/services/adminDashboard.service.ts](/src/services/adminDashboard.service.ts) | TypeScript | 312 | 0 | 14 | 326 |
| [src/services/admission.service.ts](/src/services/admission.service.ts) | TypeScript | 648 | 0 | 81 | 729 |
| [src/services/attendance.service.ts](/src/services/attendance.service.ts) | TypeScript | 111 | 0 | 12 | 123 |
| [src/services/audit.service.ts](/src/services/audit.service.ts) | TypeScript | 42 | 0 | 4 | 46 |
| [src/services/auth.service.ts](/src/services/auth.service.ts) | TypeScript | 133 | 3 | 22 | 158 |
| [src/services/branch.service.ts](/src/services/branch.service.ts) | TypeScript | 77 | 0 | 9 | 86 |
| [src/services/class-group.service.ts](/src/services/class-group.service.ts) | TypeScript | 96 | 0 | 17 | 113 |
| [src/services/class.service.ts](/src/services/class.service.ts) | TypeScript | 119 | 0 | 19 | 138 |
| [src/services/classFee.service.ts](/src/services/classFee.service.ts) | TypeScript | 48 | 0 | 6 | 54 |
| [src/services/due.service.ts](/src/services/due.service.ts) | TypeScript | 229 | 1 | 26 | 256 |
| [src/services/exam.service.ts](/src/services/exam.service.ts) | TypeScript | 1,134 | 0 | 130 | 1,264 |
| [src/services/feeCategory.service.ts](/src/services/feeCategory.service.ts) | TypeScript | 313 | 0 | 47 | 360 |
| [src/services/finance.service.ts](/src/services/finance.service.ts) | TypeScript | 347 | 0 | 33 | 380 |
| [src/services/guardian.service.ts](/src/services/guardian.service.ts) | TypeScript | 372 | 0 | 39 | 411 |
| [src/services/guardianPortal.service.ts](/src/services/guardianPortal.service.ts) | TypeScript | 699 | 0 | 46 | 745 |
| [src/services/hr.service.ts](/src/services/hr.service.ts) | TypeScript | 153 | 0 | 20 | 173 |
| [src/services/notice.service.ts](/src/services/notice.service.ts) | TypeScript | 199 | 0 | 26 | 225 |
| [src/services/noticeTemplate.service.ts](/src/services/noticeTemplate.service.ts) | TypeScript | 31 | 0 | 6 | 37 |
| [src/services/notification.service.ts](/src/services/notification.service.ts) | TypeScript | 259 | 0 | 19 | 278 |
| [src/services/passwordReset.service.ts](/src/services/passwordReset.service.ts) | TypeScript | 41 | 0 | 12 | 53 |
| [src/services/payment.service.ts](/src/services/payment.service.ts) | TypeScript | 238 | 0 | 28 | 266 |
| [src/services/payroll.service.ts](/src/services/payroll.service.ts) | TypeScript | 141 | 0 | 21 | 162 |
| [src/services/result.service.ts](/src/services/result.service.ts) | TypeScript | 144 | 0 | 15 | 159 |
| [src/services/session.service.ts](/src/services/session.service.ts) | TypeScript | 300 | 0 | 40 | 340 |
| [src/services/student.service.ts](/src/services/student.service.ts) | TypeScript | 467 | 1 | 53 | 521 |
| [src/services/studentDocumentTemplate.service.ts](/src/services/studentDocumentTemplate.service.ts) | TypeScript | 41 | 0 | 8 | 49 |
| [src/services/studentPortal.service.ts](/src/services/studentPortal.service.ts) | TypeScript | 503 | 0 | 27 | 530 |
| [src/services/studentStats.service.ts](/src/services/studentStats.service.ts) | TypeScript | 75 | 0 | 14 | 89 |
| [src/services/subject.service.ts](/src/services/subject.service.ts) | TypeScript | 73 | 0 | 10 | 83 |
| [src/services/systemSetting.service.ts](/src/services/systemSetting.service.ts) | TypeScript | 92 | 0 | 14 | 106 |
| [src/services/teacher.service.ts](/src/services/teacher.service.ts) | TypeScript | 311 | 0 | 34 | 345 |
| [src/services/teacherPortal.service.ts](/src/services/teacherPortal.service.ts) | TypeScript | 1,277 | 0 | 79 | 1,356 |
| [src/services/teacherSubject.service.ts](/src/services/teacherSubject.service.ts) | TypeScript | 112 | 0 | 14 | 126 |
| [src/services/theme.service.ts](/src/services/theme.service.ts) | TypeScript | 77 | 0 | 11 | 88 |
| [src/services/timetable.service.ts](/src/services/timetable.service.ts) | TypeScript | 93 | 0 | 8 | 101 |
| [src/services/trash.service.ts](/src/services/trash.service.ts) | TypeScript | 387 | 0 | 52 | 439 |
| [src/services/user.service.ts](/src/services/user.service.ts) | TypeScript | 250 | 1 | 45 | 296 |
| [src/types/api.types.ts](/src/types/api.types.ts) | TypeScript | 6 | 3 | 2 | 11 |
| [src/types/auth.types.ts](/src/types/auth.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/types/global-imports.d.ts](/src/types/global-imports.d.ts) | TypeScript | 4 | 0 | 1 | 5 |
| [src/types/pdfkit-standalone.d.ts](/src/types/pdfkit-standalone.d.ts) | TypeScript | 4 | 0 | 1 | 5 |
| [src/types/student.types.ts](/src/types/student.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/types/teacher.types.ts](/src/types/teacher.types.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/utils/api-response.ts](/src/utils/api-response.ts) | TypeScript | 7 | 6 | 3 | 16 |
| [src/utils/auth-storage.ts](/src/utils/auth-storage.ts) | TypeScript | 42 | 0 | 9 | 51 |
| [src/utils/email-logger.ts](/src/utils/email-logger.ts) | TypeScript | 19 | 1 | 5 | 25 |
| [src/utils/email.ts](/src/utils/email.ts) | TypeScript | 93 | 3 | 12 | 108 |
| [src/utils/error-handler.ts](/src/utils/error-handler.ts) | TypeScript | 15 | 6 | 5 | 26 |
| [src/utils/pagination.ts](/src/utils/pagination.ts) | TypeScript | 5 | 3 | 2 | 10 |
| [src/validations/admission.schema.ts](/src/validations/admission.schema.ts) | TypeScript | 70 | 0 | 7 | 77 |
| [src/validations/attendance.schema.ts](/src/validations/attendance.schema.ts) | TypeScript | 23 | 0 | 5 | 28 |
| [src/validations/auth.schema.ts](/src/validations/auth.schema.ts) | TypeScript | 21 | 0 | 5 | 26 |
| [src/validations/branch.schema.ts](/src/validations/branch.schema.ts) | TypeScript | 29 | 0 | 4 | 33 |
| [src/validations/class-fee.schema.ts](/src/validations/class-fee.schema.ts) | TypeScript | 6 | 0 | 2 | 8 |
| [src/validations/class.schema.ts](/src/validations/class.schema.ts) | TypeScript | 22 | 0 | 8 | 30 |
| [src/validations/due.schema.ts](/src/validations/due.schema.ts) | TypeScript | 9 | 0 | 4 | 13 |
| [src/validations/exam.schema.ts](/src/validations/exam.schema.ts) | TypeScript | 109 | 0 | 11 | 120 |
| [src/validations/finance.schema.ts](/src/validations/finance.schema.ts) | TypeScript | 52 | 0 | 10 | 62 |
| [src/validations/guardian.schema.ts](/src/validations/guardian.schema.ts) | TypeScript | 38 | 0 | 6 | 44 |
| [src/validations/hr.schema.ts](/src/validations/hr.schema.ts) | TypeScript | 47 | 0 | 11 | 58 |
| [src/validations/notice-template.schema.ts](/src/validations/notice-template.schema.ts) | TypeScript | 6 | 0 | 3 | 9 |
| [src/validations/notice.schema.ts](/src/validations/notice.schema.ts) | TypeScript | 25 | 0 | 5 | 30 |
| [src/validations/payment.schema.ts](/src/validations/payment.schema.ts) | TypeScript | 60 | 0 | 9 | 69 |
| [src/validations/payroll.schema.ts](/src/validations/payroll.schema.ts) | TypeScript | 17 | 0 | 6 | 23 |
| [src/validations/result.schema.ts](/src/validations/result.schema.ts) | TypeScript | 23 | 0 | 4 | 27 |
| [src/validations/session.schema.ts](/src/validations/session.schema.ts) | TypeScript | 46 | 0 | 7 | 53 |
| [src/validations/student-document-template.schema.ts](/src/validations/student-document-template.schema.ts) | TypeScript | 35 | 0 | 7 | 42 |
| [src/validations/student-stats.schema.ts](/src/validations/student-stats.schema.ts) | TypeScript | 4 | 0 | 3 | 7 |
| [src/validations/student.schema.ts](/src/validations/student.schema.ts) | TypeScript | 63 | 0 | 5 | 68 |
| [src/validations/subject.schema.ts](/src/validations/subject.schema.ts) | TypeScript | 15 | 0 | 4 | 19 |
| [src/validations/system-setting.schema.ts](/src/validations/system-setting.schema.ts) | TypeScript | 11 | 0 | 2 | 13 |
| [src/validations/teacher-portal.schema.ts](/src/validations/teacher-portal.schema.ts) | TypeScript | 37 | 0 | 6 | 43 |
| [src/validations/teacher-subject.schema.ts](/src/validations/teacher-subject.schema.ts) | TypeScript | 20 | 0 | 4 | 24 |
| [src/validations/teacher.schema.ts](/src/validations/teacher.schema.ts) | TypeScript | 35 | 0 | 4 | 39 |
| [src/validations/theme.schema.ts](/src/validations/theme.schema.ts) | TypeScript | 29 | 0 | 5 | 34 |
| [src/validations/timetable.schema.ts](/src/validations/timetable.schema.ts) | TypeScript | 34 | 0 | 5 | 39 |
| [src/validations/trash.schema.ts](/src/validations/trash.schema.ts) | TypeScript | 17 | 0 | 5 | 22 |
| [src/validations/user.schema.ts](/src/validations/user.schema.ts) | TypeScript | 34 | 0 | 5 | 39 |
| [tests/admission-service.test.ts](/tests/admission-service.test.ts) | TypeScript | -263 | 0 | -26 | -289 |
| [tests/admissions.test.ts](/tests/admissions.test.ts) | TypeScript | -104 | 0 | -10 | -114 |
| [tests/api-route-auth-coverage.test.ts](/tests/api-route-auth-coverage.test.ts) | TypeScript | -93 | -1 | -16 | -110 |
| [tests/app-sidebar-nav.test.ts](/tests/app-sidebar-nav.test.ts) | TypeScript | -52 | 0 | -9 | -61 |
| [tests/attendance-summary.test.ts](/tests/attendance-summary.test.ts) | TypeScript | -66 | 0 | -3 | -69 |
| [tests/attendance.service.test.ts](/tests/attendance.service.test.ts) | TypeScript | -113 | 0 | -18 | -131 |
| [tests/audit-service.test.ts](/tests/audit-service.test.ts) | TypeScript | -24 | 0 | -6 | -30 |
| [tests/auth-branch-login.test.ts](/tests/auth-branch-login.test.ts) | TypeScript | -80 | 0 | -15 | -95 |
| [tests/auth.test.ts](/tests/auth.test.ts) | TypeScript | -61 | 0 | -13 | -74 |
| [tests/class-monthly-fees.test.ts](/tests/class-monthly-fees.test.ts) | TypeScript | -74 | 0 | -15 | -89 |
| [tests/due-service.test.ts](/tests/due-service.test.ts) | TypeScript | -117 | 0 | -9 | -126 |
| [tests/fee-category-service.test.ts](/tests/fee-category-service.test.ts) | TypeScript | -250 | 0 | -28 | -278 |
| [tests/fee-history.test.ts](/tests/fee-history.test.ts) | TypeScript | -202 | 0 | -10 | -212 |
| [tests/fee-utils.test.ts](/tests/fee-utils.test.ts) | TypeScript | -18 | 0 | -4 | -22 |
| [tests/finance.service.test.ts](/tests/finance.service.test.ts) | TypeScript | -76 | 0 | -8 | -84 |
| [tests/hr.service.test.ts](/tests/hr.service.test.ts) | TypeScript | -71 | 0 | -12 | -83 |
| [tests/notice-service.test.ts](/tests/notice-service.test.ts) | TypeScript | -84 | 0 | -15 | -99 |
| [tests/notice-template.service.test.ts](/tests/notice-template.service.test.ts) | TypeScript | -38 | 0 | -10 | -48 |
| [tests/payment-service.test.ts](/tests/payment-service.test.ts) | TypeScript | -257 | 0 | -20 | -277 |
| [tests/payroll.service.test.ts](/tests/payroll.service.test.ts) | TypeScript | -71 | 0 | -13 | -84 |
| [tests/portal-auth.test.ts](/tests/portal-auth.test.ts) | TypeScript | -38 | 0 | -10 | -48 |
| [tests/role-permissions.test.ts](/tests/role-permissions.test.ts) | TypeScript | -12 | 0 | -4 | -16 |
| [tests/role-routes.test.ts](/tests/role-routes.test.ts) | TypeScript | -17 | 0 | -5 | -22 |
| [tests/session.service.test.ts](/tests/session.service.test.ts) | TypeScript | -175 | -2 | -28 | -205 |
| [tests/student-portal.service.test.ts](/tests/student-portal.service.test.ts) | TypeScript | -186 | 0 | -13 | -199 |
| [tests/student-stats.service.test.ts](/tests/student-stats.service.test.ts) | TypeScript | -56 | 0 | -9 | -65 |
| [tests/teacher-portal.service.test.ts](/tests/teacher-portal.service.test.ts) | TypeScript | -122 | 0 | -20 | -142 |
| [tests/teacher-subject.service.test.ts](/tests/teacher-subject.service.test.ts) | TypeScript | -60 | 0 | -12 | -72 |
| [tests/teacher.service.test.ts](/tests/teacher.service.test.ts) | TypeScript | -118 | 0 | -16 | -134 |
| [tests/theme-auth.test.ts](/tests/theme-auth.test.ts) | TypeScript | -34 | 0 | -8 | -42 |
| [tests/trash-service.test.ts](/tests/trash-service.test.ts) | TypeScript | -85 | 0 | -10 | -95 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details