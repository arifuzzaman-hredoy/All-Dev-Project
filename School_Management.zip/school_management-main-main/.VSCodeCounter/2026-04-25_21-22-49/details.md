# Details

Date : 2026-04-25 21:22:49

Directory /home/mahi/github_p/school_erp/tests

Total : 31 files,  3017 codes, 3 comments, 395 blanks, all 3415 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [tests/admission-service.test.ts](/tests/admission-service.test.ts) | TypeScript | 263 | 0 | 26 | 289 |
| [tests/admissions.test.ts](/tests/admissions.test.ts) | TypeScript | 104 | 0 | 10 | 114 |
| [tests/api-route-auth-coverage.test.ts](/tests/api-route-auth-coverage.test.ts) | TypeScript | 93 | 1 | 16 | 110 |
| [tests/app-sidebar-nav.test.ts](/tests/app-sidebar-nav.test.ts) | TypeScript | 52 | 0 | 9 | 61 |
| [tests/attendance-summary.test.ts](/tests/attendance-summary.test.ts) | TypeScript | 66 | 0 | 3 | 69 |
| [tests/attendance.service.test.ts](/tests/attendance.service.test.ts) | TypeScript | 113 | 0 | 18 | 131 |
| [tests/audit-service.test.ts](/tests/audit-service.test.ts) | TypeScript | 24 | 0 | 6 | 30 |
| [tests/auth-branch-login.test.ts](/tests/auth-branch-login.test.ts) | TypeScript | 80 | 0 | 15 | 95 |
| [tests/auth.test.ts](/tests/auth.test.ts) | TypeScript | 61 | 0 | 13 | 74 |
| [tests/class-monthly-fees.test.ts](/tests/class-monthly-fees.test.ts) | TypeScript | 74 | 0 | 15 | 89 |
| [tests/due-service.test.ts](/tests/due-service.test.ts) | TypeScript | 117 | 0 | 9 | 126 |
| [tests/fee-category-service.test.ts](/tests/fee-category-service.test.ts) | TypeScript | 250 | 0 | 28 | 278 |
| [tests/fee-history.test.ts](/tests/fee-history.test.ts) | TypeScript | 202 | 0 | 10 | 212 |
| [tests/fee-utils.test.ts](/tests/fee-utils.test.ts) | TypeScript | 18 | 0 | 4 | 22 |
| [tests/finance.service.test.ts](/tests/finance.service.test.ts) | TypeScript | 76 | 0 | 8 | 84 |
| [tests/hr.service.test.ts](/tests/hr.service.test.ts) | TypeScript | 71 | 0 | 12 | 83 |
| [tests/notice-service.test.ts](/tests/notice-service.test.ts) | TypeScript | 84 | 0 | 15 | 99 |
| [tests/notice-template.service.test.ts](/tests/notice-template.service.test.ts) | TypeScript | 38 | 0 | 10 | 48 |
| [tests/payment-service.test.ts](/tests/payment-service.test.ts) | TypeScript | 257 | 0 | 20 | 277 |
| [tests/payroll.service.test.ts](/tests/payroll.service.test.ts) | TypeScript | 71 | 0 | 13 | 84 |
| [tests/portal-auth.test.ts](/tests/portal-auth.test.ts) | TypeScript | 38 | 0 | 10 | 48 |
| [tests/role-permissions.test.ts](/tests/role-permissions.test.ts) | TypeScript | 12 | 0 | 4 | 16 |
| [tests/role-routes.test.ts](/tests/role-routes.test.ts) | TypeScript | 17 | 0 | 5 | 22 |
| [tests/session.service.test.ts](/tests/session.service.test.ts) | TypeScript | 175 | 2 | 28 | 205 |
| [tests/student-portal.service.test.ts](/tests/student-portal.service.test.ts) | TypeScript | 186 | 0 | 13 | 199 |
| [tests/student-stats.service.test.ts](/tests/student-stats.service.test.ts) | TypeScript | 56 | 0 | 9 | 65 |
| [tests/teacher-portal.service.test.ts](/tests/teacher-portal.service.test.ts) | TypeScript | 122 | 0 | 20 | 142 |
| [tests/teacher-subject.service.test.ts](/tests/teacher-subject.service.test.ts) | TypeScript | 60 | 0 | 12 | 72 |
| [tests/teacher.service.test.ts](/tests/teacher.service.test.ts) | TypeScript | 118 | 0 | 16 | 134 |
| [tests/theme-auth.test.ts](/tests/theme-auth.test.ts) | TypeScript | 34 | 0 | 8 | 42 |
| [tests/trash-service.test.ts](/tests/trash-service.test.ts) | TypeScript | 85 | 0 | 10 | 95 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)