# Diff Summary

Date : 2026-04-25 21:22:49

Directory /home/mahi/github_p/school_erp/tests

Total : 446 files,  -46270 codes, -130 comments, -4050 blanks, all -50450 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| PostCSS | 1 | -124 | 0 | -5 | -129 |
| TypeScript | 274 | -18,635 | -68 | -1,912 | -20,615 |
| TypeScript JSX | 171 | -27,511 | -62 | -2,133 | -29,706 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 446 | -46,270 | -130 | -4,050 | -50,450 |
| . (Files) | 31 | 3,017 | 3 | 395 | 3,415 |
| .. | 415 | -49,287 | -133 | -4,445 | -53,865 |
| ../src | 415 | -49,287 | -133 | -4,445 | -53,865 |
| ../src/app | 207 | -14,106 | -32 | -1,368 | -15,506 |
| ../src/app (Files) | 3 | -209 | 0 | -19 | -228 |
| ../src/app/(panel) | 38 | -5,581 | -15 | -463 | -6,059 |
| ../src/app/(panel)/guardian | 10 | -1,244 | 0 | -77 | -1,321 |
| ../src/app/(panel)/guardian (Files) | 2 | -203 | 0 | -10 | -213 |
| ../src/app/(panel)/guardian/attendance | 1 | -104 | 0 | -7 | -111 |
| ../src/app/(panel)/guardian/children | 2 | -386 | 0 | -17 | -403 |
| ../src/app/(panel)/guardian/children (Files) | 1 | -44 | 0 | -6 | -50 |
| ../src/app/(panel)/guardian/children/[id] | 1 | -342 | 0 | -11 | -353 |
| ../src/app/(panel)/guardian/fees | 1 | -266 | 0 | -16 | -282 |
| ../src/app/(panel)/guardian/notices | 1 | -56 | 0 | -6 | -62 |
| ../src/app/(panel)/guardian/profile | 1 | -48 | 0 | -6 | -54 |
| ../src/app/(panel)/guardian/results | 1 | -86 | 0 | -7 | -93 |
| ../src/app/(panel)/guardian/settings | 1 | -95 | 0 | -8 | -103 |
| ../src/app/(panel)/student | 9 | -1,294 | -8 | -151 | -1,453 |
| ../src/app/(panel)/student (Files) | 2 | -236 | -2 | -22 | -260 |
| ../src/app/(panel)/student/attendance | 1 | -209 | 0 | -26 | -235 |
| ../src/app/(panel)/student/fees | 1 | -304 | 0 | -23 | -327 |
| ../src/app/(panel)/student/notices | 1 | -100 | 0 | -13 | -113 |
| ../src/app/(panel)/student/profile | 1 | -143 | 0 | -14 | -157 |
| ../src/app/(panel)/student/results | 1 | -129 | 0 | -14 | -143 |
| ../src/app/(panel)/student/routine | 1 | -104 | 0 | -16 | -120 |
| ../src/app/(panel)/student/settings | 1 | -69 | -6 | -23 | -98 |
| ../src/app/(panel)/teacher | 19 | -3,043 | -7 | -235 | -3,285 |
| ../src/app/(panel)/teacher (Files) | 2 | -340 | -7 | -30 | -377 |
| ../src/app/(panel)/teacher/attendance | 4 | -667 | 0 | -53 | -720 |
| ../src/app/(panel)/teacher/attendance (Files) | 1 | -48 | 0 | -4 | -52 |
| ../src/app/(panel)/teacher/attendance/take | 1 | -284 | 0 | -23 | -307 |
| ../src/app/(panel)/teacher/attendance/view | 2 | -335 | 0 | -26 | -361 |
| ../src/app/(panel)/teacher/attendance/view (Files) | 1 | -224 | 0 | -13 | -237 |
| ../src/app/(panel)/teacher/attendance/view/[id] | 1 | -111 | 0 | -13 | -124 |
| ../src/app/(panel)/teacher/notices | 2 | -159 | 0 | -17 | -176 |
| ../src/app/(panel)/teacher/notices (Files) | 1 | -75 | 0 | -9 | -84 |
| ../src/app/(panel)/teacher/notices/create | 1 | -84 | 0 | -8 | -92 |
| ../src/app/(panel)/teacher/results | 3 | -491 | 0 | -28 | -519 |
| ../src/app/(panel)/teacher/results (Files) | 1 | -46 | 0 | -4 | -50 |
| ../src/app/(panel)/teacher/results/create | 1 | -254 | 0 | -13 | -267 |
| ../src/app/(panel)/teacher/results/view | 1 | -191 | 0 | -11 | -202 |
| ../src/app/(panel)/teacher/settings | 1 | -265 | 0 | -15 | -280 |
| ../src/app/(panel)/teacher/students | 6 | -1,027 | 0 | -81 | -1,108 |
| ../src/app/(panel)/teacher/students (Files) | 2 | -386 | 0 | -24 | -410 |
| ../src/app/(panel)/teacher/students/[id] | 2 | -233 | 0 | -26 | -259 |
| ../src/app/(panel)/teacher/students/[id] (Files) | 1 | -135 | 0 | -15 | -150 |
| ../src/app/(panel)/teacher/students/[id]/attendance | 1 | -98 | 0 | -11 | -109 |
| ../src/app/(panel)/teacher/students/view | 2 | -408 | 0 | -31 | -439 |
| ../src/app/(panel)/teacher/students/view (Files) | 1 | -182 | 0 | -15 | -197 |
| ../src/app/(panel)/teacher/students/view/[id] | 1 | -226 | 0 | -16 | -242 |
| ../src/app/(panel)/teacher/timetable | 1 | -94 | 0 | -11 | -105 |
| ../src/app/(protected) | 3 | -838 | -2 | -62 | -902 |
| ../src/app/(protected)/admission | 3 | -838 | -2 | -62 | -902 |
| ../src/app/(public) | 1 | -73 | 0 | -4 | -77 |
| ../src/app/(public)/gallery | 1 | -73 | 0 | -4 | -77 |
| ../src/app/admin | 45 | -2,772 | -3 | -230 | -3,005 |
| ../src/app/admin (Files) | 2 | -40 | 0 | -8 | -48 |
| ../src/app/admin/academic | 8 | -654 | -2 | -47 | -703 |
| ../src/app/admin/academic (Files) | 1 | -56 | 0 | -5 | -61 |
| ../src/app/admin/academic/attendance | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/academic/documents | 1 | -28 | 0 | -2 | -30 |
| ../src/app/admin/academic/exams | 4 | -552 | -2 | -36 | -590 |
| ../src/app/admin/academic/exams (Files) | 2 | -62 | 0 | -8 | -70 |
| ../src/app/admin/academic/exams/create | 1 | -486 | -2 | -26 | -514 |
| ../src/app/admin/academic/exams/show | 1 | -4 | 0 | -2 | -6 |
| ../src/app/admin/academic/results | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/admissions | 3 | -85 | 0 | -8 | -93 |
| ../src/app/admin/admissions (Files) | 1 | -60 | 0 | -4 | -64 |
| ../src/app/admin/admissions/new | 1 | -16 | 0 | -2 | -18 |
| ../src/app/admin/admissions/view | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/classes | 2 | -22 | 0 | -7 | -29 |
| ../src/app/admin/classes (Files) | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/classes/[id] | 1 | -13 | 0 | -5 | -18 |
| ../src/app/admin/classes/[id]/groups | 1 | -13 | 0 | -5 | -18 |
| ../src/app/admin/dashboard | 1 | -815 | 0 | -31 | -846 |
| ../src/app/admin/fees | 9 | -346 | 0 | -34 | -380 |
| ../src/app/admin/fees (Files) | 1 | -33 | 0 | -2 | -35 |
| ../src/app/admin/fees/categories | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/fees/category | 1 | -4 | 0 | -2 | -6 |
| ../src/app/admin/fees/catgegory | 1 | -4 | 0 | -2 | -6 |
| ../src/app/admin/fees/monthly | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/fees/payments | 3 | -86 | 0 | -10 | -96 |
| ../src/app/admin/fees/payments (Files) | 1 | -64 | 0 | -4 | -68 |
| ../src/app/admin/fees/payments/monthly | 1 | -11 | 0 | -3 | -14 |
| ../src/app/admin/fees/payments/secondary | 1 | -11 | 0 | -3 | -14 |
| ../src/app/admin/fees/reports | 1 | -201 | 0 | -14 | -215 |
| ../src/app/admin/guardians | 3 | -27 | 0 | -6 | -33 |
| ../src/app/admin/guardians (Files) | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/guardians/create | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/guardians/view | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/hr | 5 | -45 | 0 | -14 | -59 |
| ../src/app/admin/hr (Files) | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/hr/departments | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/hr/designations | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/hr/leaves | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/hr/payroll | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/login | 1 | -150 | -1 | -17 | -168 |
| ../src/app/admin/notices | 2 | -22 | 0 | -7 | -29 |
| ../src/app/admin/notices (Files) | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/notices/[id] | 1 | -13 | 0 | -5 | -18 |
| ../src/app/admin/settings | 1 | -436 | 0 | -31 | -467 |
| ../src/app/admin/students | 3 | -27 | 0 | -8 | -35 |
| ../src/app/admin/students (Files) | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/students/create | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/students/view | 1 | -9 | 0 | -3 | -12 |
| ../src/app/admin/subjects | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/teachers | 1 | -9 | 0 | -2 | -11 |
| ../src/app/admin/users | 3 | -85 | 0 | -8 | -93 |
| ../src/app/admin/users (Files) | 1 | -60 | 0 | -4 | -64 |
| ../src/app/admin/users/create | 1 | -16 | 0 | -2 | -18 |
| ../src/app/admin/users/view | 1 | -9 | 0 | -2 | -11 |
| ../src/app/api | 112 | -4,184 | -12 | -527 | -4,723 |
| ../src/app/api/send | 1 | -141 | -4 | -16 | -161 |
| ../src/app/api/v1 | 111 | -4,043 | -8 | -511 | -4,562 |
| ../src/app/api/v1/admin | 1 | -16 | 0 | -2 | -18 |
| ../src/app/api/v1/admin/dashboard | 1 | -16 | 0 | -2 | -18 |
| ../src/app/api/v1/admissions | 2 | -106 | 0 | -15 | -121 |
| ../src/app/api/v1/admissions (Files) | 1 | -45 | 0 | -7 | -52 |
| ../src/app/api/v1/admissions/[id] | 1 | -61 | 0 | -8 | -69 |
| ../src/app/api/v1/attendance | 3 | -103 | 0 | -9 | -112 |
| ../src/app/api/v1/attendance (Files) | 1 | -46 | 0 | -3 | -49 |
| ../src/app/api/v1/attendance/class | 1 | -29 | 0 | -3 | -32 |
| ../src/app/api/v1/attendance/class/[classId] | 1 | -29 | 0 | -3 | -32 |
| ../src/app/api/v1/attendance/student | 1 | -28 | 0 | -3 | -31 |
| ../src/app/api/v1/attendance/student/[studentId] | 1 | -28 | 0 | -3 | -31 |
| ../src/app/api/v1/audit-logs | 1 | -55 | 0 | -6 | -61 |
| ../src/app/api/v1/auth | 8 | -162 | 0 | -25 | -187 |
| ../src/app/api/v1/auth/forgot-password | 1 | -14 | 0 | -2 | -16 |
| ../src/app/api/v1/auth/login | 1 | -17 | 0 | -2 | -19 |
| ../src/app/api/v1/auth/logout | 1 | -23 | 0 | -2 | -25 |
| ../src/app/api/v1/auth/me | 1 | -17 | 0 | -4 | -21 |
| ../src/app/api/v1/auth/refresh | 1 | -20 | 0 | -5 | -25 |
| ../src/app/api/v1/auth/register | 1 | -23 | 0 | -3 | -26 |
| ../src/app/api/v1/auth/reset-password | 1 | -20 | 0 | -2 | -22 |
| ../src/app/api/v1/auth/session | 1 | -28 | 0 | -5 | -33 |
| ../src/app/api/v1/classes | 5 | -232 | 0 | -26 | -258 |
| ../src/app/api/v1/classes (Files) | 1 | -52 | 0 | -4 | -56 |
| ../src/app/api/v1/classes/[id] | 3 | -154 | 0 | -16 | -170 |
| ../src/app/api/v1/classes/[id] (Files) | 1 | -53 | 0 | -4 | -57 |
| ../src/app/api/v1/classes/[id]/groups | 2 | -101 | 0 | -12 | -113 |
| ../src/app/api/v1/classes/[id]/groups (Files) | 1 | -48 | 0 | -6 | -54 |
| ../src/app/api/v1/classes/[id]/groups/[groupId] | 1 | -53 | 0 | -6 | -59 |
| ../src/app/api/v1/classes/order | 1 | -26 | 0 | -6 | -32 |
| ../src/app/api/v1/exams | 2 | -165 | 0 | -18 | -183 |
| ../src/app/api/v1/exams (Files) | 1 | -40 | 0 | -3 | -43 |
| ../src/app/api/v1/exams/[id] | 1 | -125 | 0 | -15 | -140 |
| ../src/app/api/v1/fees | 7 | -315 | -2 | -31 | -348 |
| ../src/app/api/v1/fees/categories | 2 | -101 | -2 | -7 | -110 |
| ../src/app/api/v1/fees/categories (Files) | 1 | -38 | 0 | -3 | -41 |
| ../src/app/api/v1/fees/categories/[id] | 1 | -63 | -2 | -4 | -69 |
| ../src/app/api/v1/fees/dues | 1 | -26 | 0 | -6 | -32 |
| ../src/app/api/v1/fees/dues/generate | 1 | -26 | 0 | -6 | -32 |
| ../src/app/api/v1/fees/monthly | 1 | -39 | 0 | -5 | -44 |
| ../src/app/api/v1/fees/payments | 3 | -149 | 0 | -13 | -162 |
| ../src/app/api/v1/fees/payments (Files) | 1 | -48 | 0 | -3 | -51 |
| ../src/app/api/v1/fees/payments/[id] | 2 | -101 | 0 | -10 | -111 |
| ../src/app/api/v1/fees/payments/[id] (Files) | 1 | -48 | 0 | -4 | -52 |
| ../src/app/api/v1/fees/payments/[id]/receipt | 1 | -53 | 0 | -6 | -59 |
| ../src/app/api/v1/finance | 4 | -193 | 0 | -38 | -231 |
| ../src/app/api/v1/finance/categories | 2 | -80 | 0 | -17 | -97 |
| ../src/app/api/v1/finance/categories (Files) | 1 | -53 | 0 | -10 | -63 |
| ../src/app/api/v1/finance/categories/[id] | 1 | -27 | 0 | -7 | -34 |
| ../src/app/api/v1/finance/entries | 2 | -113 | 0 | -21 | -134 |
| ../src/app/api/v1/finance/entries (Files) | 1 | -66 | 0 | -10 | -76 |
| ../src/app/api/v1/finance/entries/[id] | 1 | -47 | 0 | -11 | -58 |
| ../src/app/api/v1/guardian | 11 | -343 | 0 | -36 | -379 |
| ../src/app/api/v1/guardian/attendance | 1 | -19 | 0 | -2 | -21 |
| ../src/app/api/v1/guardian/children | 2 | -38 | 0 | -5 | -43 |
| ../src/app/api/v1/guardian/children (Files) | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/guardian/children/[id] | 1 | -20 | 0 | -3 | -23 |
| ../src/app/api/v1/guardian/dashboard | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/guardian/fees | 2 | -72 | 0 | -9 | -81 |
| ../src/app/api/v1/guardian/fees (Files) | 1 | -19 | 0 | -2 | -21 |
| ../src/app/api/v1/guardian/fees/[id] | 1 | -53 | 0 | -7 | -60 |
| ../src/app/api/v1/guardian/fees/[id]/receipt | 1 | -53 | 0 | -7 | -60 |
| ../src/app/api/v1/guardian/notices | 1 | -19 | 0 | -2 | -21 |
| ../src/app/api/v1/guardian/profile | 1 | -36 | 0 | -3 | -39 |
| ../src/app/api/v1/guardian/results | 2 | -118 | 0 | -11 | -129 |
| ../src/app/api/v1/guardian/results (Files) | 1 | -19 | 0 | -2 | -21 |
| ../src/app/api/v1/guardian/results/export | 1 | -99 | 0 | -9 | -108 |
| ../src/app/api/v1/guardian/settings | 1 | -23 | 0 | -2 | -25 |
| ../src/app/api/v1/guardian/settings/password | 1 | -23 | 0 | -2 | -25 |
| ../src/app/api/v1/guardians | 3 | -116 | 0 | -11 | -127 |
| ../src/app/api/v1/guardians (Files) | 1 | -41 | 0 | -3 | -44 |
| ../src/app/api/v1/guardians/[id] | 1 | -44 | 0 | -4 | -48 |
| ../src/app/api/v1/guardians/transfer-student | 1 | -31 | 0 | -4 | -35 |
| ../src/app/api/v1/hr | 9 | -330 | 0 | -37 | -367 |
| ../src/app/api/v1/hr/departments | 2 | -65 | 0 | -8 | -73 |
| ../src/app/api/v1/hr/departments (Files) | 1 | -38 | 0 | -4 | -42 |
| ../src/app/api/v1/hr/departments/[id] | 1 | -27 | 0 | -4 | -31 |
| ../src/app/api/v1/hr/designations | 2 | -65 | 0 | -8 | -73 |
| ../src/app/api/v1/hr/designations (Files) | 1 | -38 | 0 | -4 | -42 |
| ../src/app/api/v1/hr/designations/[id] | 1 | -27 | 0 | -4 | -31 |
| ../src/app/api/v1/hr/leaves | 2 | -77 | 0 | -7 | -84 |
| ../src/app/api/v1/hr/leaves (Files) | 1 | -44 | 0 | -4 | -48 |
| ../src/app/api/v1/hr/leaves/[id] | 1 | -33 | 0 | -3 | -36 |
| ../src/app/api/v1/hr/payroll | 3 | -123 | 0 | -14 | -137 |
| ../src/app/api/v1/hr/payroll/items | 1 | -28 | 0 | -4 | -32 |
| ../src/app/api/v1/hr/payroll/items/[id] | 1 | -28 | 0 | -4 | -32 |
| ../src/app/api/v1/hr/payroll/runs | 2 | -95 | 0 | -10 | -105 |
| ../src/app/api/v1/hr/payroll/runs (Files) | 1 | -43 | 0 | -4 | -47 |
| ../src/app/api/v1/hr/payroll/runs/[id] | 1 | -52 | 0 | -6 | -58 |
| ../src/app/api/v1/notices | 4 | -167 | 0 | -21 | -188 |
| ../src/app/api/v1/notices (Files) | 1 | -40 | 0 | -3 | -43 |
| ../src/app/api/v1/notices/[id] | 2 | -84 | 0 | -11 | -95 |
| ../src/app/api/v1/notices/[id] (Files) | 1 | -59 | 0 | -5 | -64 |
| ../src/app/api/v1/notices/[id]/publish | 1 | -25 | 0 | -6 | -31 |
| ../src/app/api/v1/notices/template | 1 | -43 | 0 | -7 | -50 |
| ../src/app/api/v1/notifications | 1 | -28 | 0 | -3 | -31 |
| ../src/app/api/v1/notifications/reminders | 1 | -28 | 0 | -3 | -31 |
| ../src/app/api/v1/public | 1 | -11 | 0 | -3 | -14 |
| ../src/app/api/v1/public/branches | 1 | -11 | 0 | -3 | -14 |
| ../src/app/api/v1/reports | 4 | -137 | 0 | -24 | -161 |
| ../src/app/api/v1/reports/dues | 1 | -24 | 0 | -5 | -29 |
| ../src/app/api/v1/reports/fees | 1 | -71 | 0 | -9 | -80 |
| ../src/app/api/v1/reports/finance | 1 | -21 | 0 | -5 | -26 |
| ../src/app/api/v1/reports/finance/monthly | 1 | -21 | 0 | -5 | -26 |
| ../src/app/api/v1/reports/gender-count | 1 | -21 | 0 | -5 | -26 |
| ../src/app/api/v1/results | 4 | -132 | 0 | -13 | -145 |
| ../src/app/api/v1/results (Files) | 1 | -42 | 0 | -3 | -45 |
| ../src/app/api/v1/results/[id] | 1 | -44 | 0 | -4 | -48 |
| ../src/app/api/v1/results/exam | 1 | -23 | 0 | -3 | -26 |
| ../src/app/api/v1/results/exam/[examId] | 1 | -23 | 0 | -3 | -26 |
| ../src/app/api/v1/results/student | 1 | -23 | 0 | -3 | -26 |
| ../src/app/api/v1/results/student/[studentId] | 1 | -23 | 0 | -3 | -26 |
| ../src/app/api/v1/sessions | 4 | -136 | 0 | -29 | -165 |
| ../src/app/api/v1/sessions (Files) | 1 | -46 | 0 | -9 | -55 |
| ../src/app/api/v1/sessions/current | 1 | -38 | 0 | -8 | -46 |
| ../src/app/api/v1/sessions/migrate | 2 | -52 | 0 | -12 | -64 |
| ../src/app/api/v1/sessions/migrate (Files) | 1 | -26 | 0 | -6 | -32 |
| ../src/app/api/v1/sessions/migrate/auto-next | 1 | -26 | 0 | -6 | -32 |
| ../src/app/api/v1/student | 7 | -126 | 0 | -14 | -140 |
| ../src/app/api/v1/student-document-template | 1 | -37 | 0 | -6 | -43 |
| ../src/app/api/v1/student/attendance | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/dashboard | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/fees | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/notices | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/profile | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/results | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/student/timetable | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/students | 3 | -178 | 0 | -29 | -207 |
| ../src/app/api/v1/students (Files) | 1 | -53 | 0 | -7 | -60 |
| ../src/app/api/v1/students/[id] | 2 | -125 | 0 | -22 | -147 |
| ../src/app/api/v1/students/[id] (Files) | 1 | -55 | 0 | -8 | -63 |
| ../src/app/api/v1/students/[id]/documents | 1 | -70 | 0 | -14 | -84 |
| ../src/app/api/v1/subjects | 2 | -83 | 0 | -7 | -90 |
| ../src/app/api/v1/subjects (Files) | 1 | -39 | 0 | -3 | -42 |
| ../src/app/api/v1/subjects/[id] | 1 | -44 | 0 | -4 | -48 |
| ../src/app/api/v1/super | 2 | -73 | 0 | -10 | -83 |
| ../src/app/api/v1/super/branches | 2 | -73 | 0 | -10 | -83 |
| ../src/app/api/v1/super/branches (Files) | 1 | -41 | 0 | -5 | -46 |
| ../src/app/api/v1/super/branches/[id] | 1 | -32 | 0 | -5 | -37 |
| ../src/app/api/v1/system-settings | 1 | -40 | 0 | -7 | -47 |
| ../src/app/api/v1/teacher | 9 | -243 | 0 | -23 | -266 |
| ../src/app/api/v1/teacher-subjects | 2 | -93 | 0 | -7 | -100 |
| ../src/app/api/v1/teacher-subjects (Files) | 1 | -46 | 0 | -3 | -49 |
| ../src/app/api/v1/teacher-subjects/[id] | 1 | -47 | 0 | -4 | -51 |
| ../src/app/api/v1/teacher/attendance | 1 | -39 | 0 | -3 | -42 |
| ../src/app/api/v1/teacher/dashboard | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/teacher/notices | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/teacher/results | 1 | -39 | 0 | -3 | -42 |
| ../src/app/api/v1/teacher/settings | 2 | -57 | 0 | -5 | -62 |
| ../src/app/api/v1/teacher/settings (Files) | 1 | -34 | 0 | -3 | -37 |
| ../src/app/api/v1/teacher/settings/password | 1 | -23 | 0 | -2 | -25 |
| ../src/app/api/v1/teacher/students | 2 | -54 | 0 | -6 | -60 |
| ../src/app/api/v1/teacher/students (Files) | 1 | -32 | 0 | -3 | -35 |
| ../src/app/api/v1/teacher/students/[id] | 1 | -22 | 0 | -3 | -25 |
| ../src/app/api/v1/teacher/timetable | 1 | -18 | 0 | -2 | -20 |
| ../src/app/api/v1/teachers | 2 | -102 | 0 | -15 | -117 |
| ../src/app/api/v1/teachers (Files) | 1 | -51 | 0 | -7 | -58 |
| ../src/app/api/v1/teachers/[id] | 1 | -51 | 0 | -8 | -59 |
| ../src/app/api/v1/theme | 2 | -56 | -6 | -11 | -73 |
| ../src/app/api/v1/theme/global | 1 | -28 | -6 | -3 | -37 |
| ../src/app/api/v1/theme/user | 1 | -28 | 0 | -8 | -36 |
| ../src/app/api/v1/timetable | 2 | -95 | 0 | -7 | -102 |
| ../src/app/api/v1/timetable (Files) | 1 | -47 | 0 | -3 | -50 |
| ../src/app/api/v1/timetable/[id] | 1 | -48 | 0 | -4 | -52 |
| ../src/app/api/v1/trash | 2 | -55 | 0 | -12 | -67 |
| ../src/app/api/v1/trash (Files) | 1 | -24 | 0 | -5 | -29 |
| ../src/app/api/v1/trash/restore | 1 | -31 | 0 | -7 | -38 |
| ../src/app/api/v1/users | 2 | -115 | 0 | -16 | -131 |
| ../src/app/api/v1/users (Files) | 1 | -64 | 0 | -8 | -72 |
| ../src/app/api/v1/users/[id] | 1 | -51 | 0 | -8 | -59 |
| ../src/app/dashboard | 1 | -4 | 0 | -2 | -6 |
| ../src/app/login | 1 | -88 | 0 | -12 | -100 |
| ../src/app/register | 1 | -130 | 0 | -17 | -147 |
| ../src/app/reset-password | 1 | -116 | 0 | -16 | -132 |
| ../src/app/send-email | 1 | -111 | 0 | -16 | -127 |
| ../src/components | 77 | -17,823 | -42 | -1,299 | -19,164 |
| ../src/components (Files) | 24 | -2,237 | -21 | -166 | -2,424 |
| ../src/components/admin | 29 | -13,218 | -9 | -890 | -14,117 |
| ../src/components/gallery | 1 | -48 | -2 | -6 | -56 |
| ../src/components/teacher | 2 | -57 | 0 | -8 | -65 |
| ../src/components/ui | 21 | -2,263 | -10 | -229 | -2,502 |
| ../src/constants | 4 | -203 | -6 | -17 | -226 |
| ../src/emails | 1 | -70 | 0 | -4 | -74 |
| ../src/hooks | 1 | -15 | 0 | -5 | -20 |
| ../src/lib | 19 | -2,743 | -25 | -181 | -2,949 |
| ../src/lib (Files) | 15 | -1,503 | -25 | -144 | -1,672 |
| ../src/lib/student-document-pdf-modules | 4 | -1,240 | 0 | -37 | -1,277 |
| ../src/repositories | 28 | -3,386 | 0 | -313 | -3,699 |
| ../src/services | 37 | -9,810 | -6 | -1,053 | -10,869 |
| ../src/types | 6 | -14 | -3 | -7 | -24 |
| ../src/utils | 6 | -181 | -19 | -36 | -236 |
| ../src/validations | 29 | -936 | 0 | -162 | -1,098 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)