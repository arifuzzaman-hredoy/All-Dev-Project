# Summary

Date : 2026-04-25 21:22:49

Directory /home/mahi/github_p/school_erp/tests

Total : 31 files,  3017 codes, 3 comments, 395 blanks, all 3415 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 31 | 3,017 | 3 | 395 | 3,415 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 31 | 3,017 | 3 | 395 | 3,415 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)