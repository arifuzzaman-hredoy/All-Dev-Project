# Diff Summary

Date : 2026-04-15 14:29:00

Directory /home/mahi/github_p/school_erp/prisma

Total : 24 files,  -240 codes, 258 comments, 227 blanks, all 245 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Prisma | 1 | 384 | 66 | 163 | 613 |
| MS SQL | 10 | 376 | 168 | 170 | 714 |
| TypeScript | 13 | -1,000 | 24 | -106 | -1,082 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 24 | -240 | 258 | 227 | 245 |
| . (Files) | 2 | 546 | 90 | 193 | 829 |
| .. | 12 | -1,162 | 0 | -136 | -1,298 |
| ../tests | 12 | -1,162 | 0 | -136 | -1,298 |
| migrations | 10 | 376 | 168 | 170 | 714 |
| migrations/20260310201748_init | 1 | 204 | 61 | 78 | 343 |
| migrations/20260311071340_add_student_phone | 1 | 12 | 4 | 5 | 21 |
| migrations/20260311091049_make_roll_optional | 1 | 1 | 1 | 1 | 3 |
| migrations/20260317144442_full_rewrite | 1 | 11 | 15 | 8 | 34 |
| migrations/20260317205721_add_groups_and_sections | 1 | 44 | 40 | 31 | 115 |
| migrations/20260318083218_remove_theme_system | 1 | 4 | 11 | 4 | 19 |
| migrations/20260413081119_add | 1 | 73 | 24 | 29 | 126 |
| migrations/20260413095359_add | 1 | 10 | 3 | 4 | 17 |
| migrations/20260415000000_fee_secondary_assignment_snapshots | 1 | 16 | 8 | 9 | 33 |
| migrations/20260415031249_add_class_monthly_fee_active_flag | 1 | 1 | 1 | 1 | 3 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)