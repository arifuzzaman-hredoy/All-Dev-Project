# Diff Details

Date : 2026-04-15 14:29:00

Directory /home/mahi/github_p/school_erp/prisma

Total : 24 files,  -240 codes, 258 comments, 227 blanks, all 245 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [prisma/migrations/20260310201748\_init/migration.sql](/prisma/migrations/20260310201748_init/migration.sql) | MS SQL | 204 | 61 | 78 | 343 |
| [prisma/migrations/20260311071340\_add\_student\_phone/migration.sql](/prisma/migrations/20260311071340_add_student_phone/migration.sql) | MS SQL | 12 | 4 | 5 | 21 |
| [prisma/migrations/20260311091049\_make\_roll\_optional/migration.sql](/prisma/migrations/20260311091049_make_roll_optional/migration.sql) | MS SQL | 1 | 1 | 1 | 3 |
| [prisma/migrations/20260317144442\_full\_rewrite/migration.sql](/prisma/migrations/20260317144442_full_rewrite/migration.sql) | MS SQL | 11 | 15 | 8 | 34 |
| [prisma/migrations/20260317205721\_add\_groups\_and\_sections/migration.sql](/prisma/migrations/20260317205721_add_groups_and_sections/migration.sql) | MS SQL | 44 | 40 | 31 | 115 |
| [prisma/migrations/20260318083218\_remove\_theme\_system/migration.sql](/prisma/migrations/20260318083218_remove_theme_system/migration.sql) | MS SQL | 4 | 11 | 4 | 19 |
| [prisma/migrations/20260413081119\_add/migration.sql](/prisma/migrations/20260413081119_add/migration.sql) | MS SQL | 73 | 24 | 29 | 126 |
| [prisma/migrations/20260413095359\_add/migration.sql](/prisma/migrations/20260413095359_add/migration.sql) | MS SQL | 10 | 3 | 4 | 17 |
| [prisma/migrations/20260415000000\_fee\_secondary\_assignment\_snapshots/migration.sql](/prisma/migrations/20260415000000_fee_secondary_assignment_snapshots/migration.sql) | MS SQL | 16 | 8 | 9 | 33 |
| [prisma/migrations/20260415031249\_add\_class\_monthly\_fee\_active\_flag/migration.sql](/prisma/migrations/20260415031249_add_class_monthly_fee_active_flag/migration.sql) | MS SQL | 1 | 1 | 1 | 3 |
| [prisma/schema.prisma](/prisma/schema.prisma) | Prisma | 384 | 66 | 163 | 613 |
| [prisma/seed.ts](/prisma/seed.ts) | TypeScript | 162 | 24 | 30 | 216 |
| [tests/admissions.test.ts](/tests/admissions.test.ts) | TypeScript | -101 | 0 | -10 | -111 |
| [tests/audit-service.test.ts](/tests/audit-service.test.ts) | TypeScript | -24 | 0 | -6 | -30 |
| [tests/auth.test.ts](/tests/auth.test.ts) | TypeScript | -55 | 0 | -12 | -67 |
| [tests/class-monthly-fees.test.ts](/tests/class-monthly-fees.test.ts) | TypeScript | -74 | 0 | -15 | -89 |
| [tests/fee-category-service.test.ts](/tests/fee-category-service.test.ts) | TypeScript | -250 | 0 | -28 | -278 |
| [tests/fee-history.test.ts](/tests/fee-history.test.ts) | TypeScript | -202 | 0 | -10 | -212 |
| [tests/fee-utils.test.ts](/tests/fee-utils.test.ts) | TypeScript | -18 | 0 | -4 | -22 |
| [tests/payment-service.test.ts](/tests/payment-service.test.ts) | TypeScript | -177 | 0 | -16 | -193 |
| [tests/portal-auth.test.ts](/tests/portal-auth.test.ts) | TypeScript | -38 | 0 | -10 | -48 |
| [tests/role-routes.test.ts](/tests/role-routes.test.ts) | TypeScript | -17 | 0 | -5 | -22 |
| [tests/student-portal.service.test.ts](/tests/student-portal.service.test.ts) | TypeScript | -172 | 0 | -12 | -184 |
| [tests/theme-auth.test.ts](/tests/theme-auth.test.ts) | TypeScript | -34 | 0 | -8 | -42 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details