# Testing helpers

## Postman

- Import: `testing/postman_finance_payments.collection.json`

## Automated “agent” smoke test (Node)

Runs the same finance + payments routes automatically (login → create/update/list/delete).

```bash
BASE_URL=http://localhost:3000 \
API_EMAIL=superadmin@example.com \
API_PASSWORD=your_password \
node testing/api_agent_finance_payments.mjs
```

If you are logging in as a staff/admin role, branch selection is required:

```bash
API_BRANCH_ID=your_branch_id \
BASE_URL=http://localhost:3000 \
API_EMAIL=admin@example.com \
API_PASSWORD=your_password \
node testing/api_agent_finance_payments.mjs
```

