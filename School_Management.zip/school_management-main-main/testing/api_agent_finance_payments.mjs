/**
 * Automated API smoke runner (Postman alternative) for:
 * - Finance categories/entries
 * - Fee categories
 * - Payments + receipt download
 *
 * Usage:
 *   BASE_URL=http://localhost:3000 API_EMAIL=... API_PASSWORD=... node testing/api_agent_finance_payments.mjs
 *
 * Optional:
 *   API_BRANCH_ID=... (staff/admin roles must provide; super admin optional)
 */

const BASE_URL = process.env.BASE_URL ?? "http://localhost:3000";
const API_EMAIL = process.env.API_EMAIL;
const API_PASSWORD = process.env.API_PASSWORD;
const API_BRANCH_ID = process.env.API_BRANCH_ID || "";

if (!API_EMAIL || !API_PASSWORD) {
  console.error("Missing env vars: API_EMAIL and API_PASSWORD are required.");
  process.exit(1);
}

function assert(condition, message) {
  if (!condition) {
    const error = new Error(message);
    error.name = "AssertionError";
    throw error;
  }
}

function nowId() {
  return new Date().toISOString().replace(/[-:.TZ]/g, "");
}

async function requestJson(method, path, { token, body, headers } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(headers ?? {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const text = await res.text();
  const contentType = res.headers.get("content-type") ?? "";
  const isJson = contentType.includes("application/json");
  const parsed = isJson ? JSON.parse(text || "{}") : null;

  return { res, text, json: parsed, contentType };
}

async function requestText(method, path, { token, headers } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(headers ?? {}),
    },
  });
  const text = await res.text();
  const contentType = res.headers.get("content-type") ?? "";
  return { res, text, contentType };
}

async function step(name, fn) {
  process.stdout.write(`- ${name}... `);
  const started = Date.now();
  try {
    const result = await fn();
    const ms = Date.now() - started;
    process.stdout.write(`OK (${ms}ms)\n`);
    return result;
  } catch (err) {
    const ms = Date.now() - started;
    process.stdout.write(`FAILED (${ms}ms)\n`);
    throw err;
  }
}

async function main() {
  const idSuffix = nowId();

  const branchId = await step("Load branches (public)", async () => {
    const { res, json } = await requestJson("GET", "/api/v1/public/branches");
    assert(res.ok, `Branches failed: HTTP ${res.status}`);
    const branches = json?.data?.branches ?? [];
    if (API_BRANCH_ID) return API_BRANCH_ID;
    return branches?.[0]?.id ?? "";
  });

  const auth = await step("Login", async () => {
    const { res, json } = await requestJson("POST", "/api/v1/auth/login", {
      body: { email: API_EMAIL, password: API_PASSWORD, ...(branchId ? { branchId } : {}) },
    });
    assert(res.ok, `Login failed: HTTP ${res.status} ${(json && json.message) || ""}`.trim());
    const token = json?.data?.token;
    assert(token, "Login response missing token");
    return { token, user: json?.data?.user ?? null };
  });

  const token = auth.token;

  const studentId = await step("Ensure a student exists (create test student)", async () => {
    // Try fetch first
    const list = await requestJson("GET", "/api/v1/students?search=", { token });
    if (list.res.ok) {
      const students = list.json?.data?.students ?? [];
      if (students.length > 0) return students[0].id;
    }

    // Create one (requires manageStudents)
    const email = `smoke.student.${idSuffix}@example.com`;
    const create = await requestJson("POST", "/api/v1/students", {
      token,
      body: {
        name: `Smoke Student ${idSuffix}`,
        email,
        password: `Pass-${idSuffix}-1234`,
        gender: "MALE",
        guardianName: `Guardian ${idSuffix}`,
        guardianPhone: "01700000000",
        guardianRelation: "Guardian",
      },
    });
    assert(create.res.status === 201, `Create student failed: HTTP ${create.res.status} ${(create.json && create.json.message) || ""}`.trim());
    const createdId = create.json?.data?.student?.id;
    assert(createdId, "Create student response missing student.id");
    return createdId;
  });

  const feeCategoryId = await step("Create fee category (for payment)", async () => {
    const create = await requestJson("POST", "/api/v1/fees/categories", {
      token,
      body: { name: `Smoke Fee ${idSuffix}`, amount: 500, classIds: [] },
    });
    assert(create.res.status === 201, `Create fee category failed: HTTP ${create.res.status} ${(create.json && create.json.message) || ""}`.trim());
    const id = create.json?.data?.category?.id;
    assert(id, "Create fee category response missing category.id");
    return id;
  });

  const paymentId = await step("Create payment", async () => {
    const create = await requestJson("POST", "/api/v1/fees/payments", {
      token,
      body: {
        studentId,
        feeCategoryId,
        amountPaid: 500,
        status: "PAID",
        paymentMethod: "cash",
        transactionId: `SMOKE-${idSuffix}`,
        month: 4,
        year: 2026,
        dueDate: "2026-04-30",
      },
    });
    assert(create.res.status === 201, `Create payment failed: HTTP ${create.res.status} ${(create.json && create.json.message) || ""}`.trim());
    const id = create.json?.data?.payment?.id;
    assert(id, "Create payment response missing payment.id");
    return id;
  });

  await step("Update payment", async () => {
    const update = await requestJson("PATCH", `/api/v1/fees/payments/${paymentId}`, {
      token,
      body: { amountPaid: 450, status: "PARTIAL" },
    });
    assert(update.res.ok, `Update payment failed: HTTP ${update.res.status} ${(update.json && update.json.message) || ""}`.trim());
  });

  await step("Download payment receipt (HTML)", async () => {
    const receipt = await requestText("GET", `/api/v1/fees/payments/${paymentId}/receipt`, { token });
    assert(receipt.res.ok, `Receipt failed: HTTP ${receipt.res.status}`);
    assert(receipt.contentType.includes("text/html"), `Receipt expected text/html but got ${receipt.contentType}`);
    assert(receipt.text.includes("<html") || receipt.text.includes("<!DOCTYPE"), "Receipt body doesn't look like HTML");
  });

  await step("List payments", async () => {
    const list = await requestJson("GET", "/api/v1/fees/payments?search=&status=&studentId=&feeCategoryId=", { token });
    assert(list.res.ok, `List payments failed: HTTP ${list.res.status}`);
  });

  const financeCategoryId = await step("Create finance category", async () => {
    const create = await requestJson("POST", "/api/v1/finance/categories", {
      token,
      body: { name: `Smoke Income ${idSuffix}`, type: "INCOME", isActive: true },
    });
    assert(create.res.status === 201, `Create finance category failed: HTTP ${create.res.status} ${(create.json && create.json.message) || ""}`.trim());
    const id = create.json?.data?.category?.id;
    assert(id, "Create finance category response missing category.id");
    return id;
  });

  const financeEntryId = await step("Create finance entry", async () => {
    const create = await requestJson("POST", "/api/v1/finance/entries", {
      token,
      body: {
        type: "INCOME",
        categoryId: financeCategoryId,
        amount: 1000,
        occurredAt: "2026-04-24T00:00:00.000Z",
        description: `Smoke entry ${idSuffix}`,
        studentId,
      },
    });
    assert(create.res.status === 201, `Create finance entry failed: HTTP ${create.res.status} ${(create.json && create.json.message) || ""}`.trim());
    const id = create.json?.data?.entry?.id;
    assert(id, "Create finance entry response missing entry.id");
    return id;
  });

  await step("Update finance entry", async () => {
    const update = await requestJson("PATCH", `/api/v1/finance/entries/${financeEntryId}`, {
      token,
      body: { description: `Updated smoke entry ${idSuffix}` },
    });
    assert(update.res.ok, `Update finance entry failed: HTTP ${update.res.status} ${(update.json && update.json.message) || ""}`.trim());
  });

  await step("List finance entries", async () => {
    const list = await requestJson(
      "GET",
      "/api/v1/finance/entries?type=&categoryId=&studentId=&search=&from=&to=&includeDeleted=false",
      { token },
    );
    assert(list.res.ok, `List finance entries failed: HTTP ${list.res.status}`);
  });

  await step("Monthly finance report", async () => {
    const report = await requestJson("GET", "/api/v1/reports/finance/monthly?month=4&year=2026", { token });
    assert(report.res.ok, `Monthly report failed: HTTP ${report.res.status} ${(report.json && report.json.message) || ""}`.trim());
  });

  await step("Delete finance entry (soft)", async () => {
    const del = await requestJson("DELETE", `/api/v1/finance/entries/${financeEntryId}`, { token });
    assert(del.res.ok, `Delete finance entry failed: HTTP ${del.res.status} ${(del.json && del.json.message) || ""}`.trim());
  });

  await step("Delete payment", async () => {
    const del = await requestJson("DELETE", `/api/v1/fees/payments/${paymentId}`, { token });
    assert(del.res.ok, `Delete payment failed: HTTP ${del.res.status} ${(del.json && del.json.message) || ""}`.trim());
  });

  console.log("\nAll finance/payments smoke checks passed.");
  console.log(`Base URL: ${BASE_URL}`);
  console.log(`User: ${auth.user?.email ?? API_EMAIL}`);
  if (branchId) console.log(`Branch: ${branchId}`);
}

main().catch((err) => {
  console.error("\nSmoke runner failed:");
  console.error(err?.stack || err);
  process.exit(1);
});

