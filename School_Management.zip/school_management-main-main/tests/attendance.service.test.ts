import { beforeEach, describe, expect, it, vi } from "vitest";
import { HttpError } from "../src/utils/error-handler";

const mocks = vi.hoisted(() => ({
  classFindUnique: vi.fn(),
  subjectFindUnique: vi.fn(),
  studentFindMany: vi.fn(),
  upsertAttendance: vi.fn(),
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    class: { findUnique: mocks.classFindUnique },
    subject: { findUnique: mocks.subjectFindUnique },
    student: { findMany: mocks.studentFindMany },
  },
}));

vi.mock("../src/repositories/attendance.repository", () => ({
  listAttendance: vi.fn(),
  upsertAttendance: mocks.upsertAttendance,
}));

vi.mock("../src/repositories/class.repository", () => ({
  listClasses: vi.fn(),
}));

vi.mock("../src/repositories/student.repository", () => ({
  listStudents: vi.fn(),
}));

vi.mock("../src/repositories/subject.repository", () => ({
  listSubjects: vi.fn(),
}));

import { upsertAttendanceBatch } from "../src/services/attendance.service";

describe("attendance service", () => {
  beforeEach(() => {
    mocks.classFindUnique.mockReset();
    mocks.subjectFindUnique.mockReset();
    mocks.studentFindMany.mockReset();
    mocks.upsertAttendance.mockReset();
  });

  it("rejects a subject from another class before writing attendance", async () => {
    mocks.classFindUnique.mockResolvedValue({ id: "class_1" });
    mocks.subjectFindUnique.mockResolvedValue({
      id: "subject_1",
      classId: "class_2",
    });
    mocks.studentFindMany.mockResolvedValue([{ id: "student_1" }]);

    await expect(
      upsertAttendanceBatch({
        date: "2026-04-24",
        classId: "class_1",
        subjectId: "subject_1",
        entries: [{ studentId: "student_1", status: "PRESENT" }],
      }),
    ).rejects.toThrow(HttpError);

    expect(mocks.upsertAttendance).not.toHaveBeenCalled();
  });

  it("rejects students outside the selected class before writing attendance", async () => {
    mocks.classFindUnique.mockResolvedValue({ id: "class_1" });
    mocks.subjectFindUnique.mockResolvedValue({
      id: "subject_1",
      classId: "class_1",
    });
    mocks.studentFindMany.mockResolvedValue([{ id: "student_1" }]);

    await expect(
      upsertAttendanceBatch({
        date: "2026-04-24",
        classId: "class_1",
        subjectId: "subject_1",
        entries: [
          { studentId: "student_1", status: "PRESENT" },
          { studentId: "student_2", status: "ABSENT" },
        ],
      }),
    ).rejects.toThrow("One or more students do not belong to the selected class");

    expect(mocks.upsertAttendance).not.toHaveBeenCalled();
  });

  it("writes valid attendance entries and returns a summary", async () => {
    mocks.classFindUnique.mockResolvedValue({ id: "class_1" });
    mocks.subjectFindUnique.mockResolvedValue({
      id: "subject_1",
      classId: "class_1",
    });
    mocks.studentFindMany.mockResolvedValue([
      { id: "student_1" },
      { id: "student_2" },
    ]);
    mocks.upsertAttendance
      .mockResolvedValueOnce({
        date: new Date("2026-04-24T00:00:00.000Z"),
        status: "PRESENT",
        subject: { name: "Bangla" },
      })
      .mockResolvedValueOnce({
        date: new Date("2026-04-24T00:00:00.000Z"),
        status: "LATE",
        subject: { name: "Bangla" },
      });

    const result = await upsertAttendanceBatch({
      date: "2026-04-24",
      classId: "class_1",
      subjectId: "subject_1",
      markedBy: "admin_1",
      entries: [
        { studentId: "student_1", status: "PRESENT" },
        { studentId: "student_2", status: "LATE" },
      ],
    });

    expect(mocks.upsertAttendance).toHaveBeenCalledTimes(2);
    expect(result.summary).toMatchObject({
      total: 2,
      present: 1,
      late: 1,
      attendanceRate: 50,
    });
  });
});
