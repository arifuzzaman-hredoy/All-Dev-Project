import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  studentFindUnique: vi.fn(),
  admissionFindFirst: vi.fn(),
  attendanceFindMany: vi.fn(),
  resultFindMany: vi.fn(),
  paymentFindMany: vi.fn(),
  noticeFindMany: vi.fn(),
  listVisibleStudentExams: vi.fn(),
}));

vi.mock("../src/services/exam.service", () => ({
  listVisibleStudentExams: mocks.listVisibleStudentExams,
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    student: {
      findUnique: mocks.studentFindUnique,
    },
    admissionApplication: {
      findFirst: mocks.admissionFindFirst,
    },
    attendance: {
      findMany: mocks.attendanceFindMany,
    },
    result: {
      findMany: mocks.resultFindMany,
    },
    payment: {
      findMany: mocks.paymentFindMany,
    },
    notice: {
      findMany: mocks.noticeFindMany,
    },
  },
}));

import { getStudentDashboard } from "../src/services/studentPortal.service";

describe("student portal service", () => {
  beforeEach(() => {
    mocks.studentFindUnique.mockReset();
    mocks.admissionFindFirst.mockReset();
    mocks.attendanceFindMany.mockReset();
    mocks.resultFindMany.mockReset();
    mocks.paymentFindMany.mockReset();
    mocks.noticeFindMany.mockReset();
    mocks.listVisibleStudentExams.mockReset();
  });

  it("uses the latest billing period due amount for the dashboard", async () => {
    mocks.admissionFindFirst.mockResolvedValue(null);
    mocks.listVisibleStudentExams.mockResolvedValue([]);
    mocks.studentFindUnique.mockResolvedValue({
      id: "student_1",
      rollNumber: 7,
      phone: "01700000000",
      gender: "MALE",
      classId: "class_1",
      user: {
        id: "user_1",
        name: "Amina",
        email: "amina@example.com",
        role: "STUDENT",
      },
      class: {
        id: "class_1",
        name: "Grade 1",
      },
      group: null,
      section: null,
      parent: null,
    });
    mocks.attendanceFindMany.mockResolvedValue([
      { status: "PRESENT" },
      { status: "ABSENT" },
    ]);
    mocks.resultFindMany.mockResolvedValue([]);
    mocks.noticeFindMany.mockResolvedValue([]);
    mocks.paymentFindMany.mockResolvedValue([
      {
        id: "payment_old_1",
        amountPaid: 1900,
        status: "PAID",
        paymentMethod: null,
        transactionId: null,
        month: 3,
        year: 2026,
        dueDate: null,
        createdAt: "2026-03-05T00:00:00.000Z",
        feeCategory: { id: "cat_old", name: "Old extra", amount: 0 },
        student: {
          id: "student_1",
          user: { name: "Amina" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 2000 },
          },
        },
      },
      {
        id: "payment_latest_1",
        amountPaid: 0,
        status: "DUE",
        paymentMethod: null,
        transactionId: null,
        month: 4,
        year: 2026,
        dueDate: null,
        createdAt: "2026-04-05T00:00:00.000Z",
        feeCategory: { id: "cat_latest", name: "Exam fee", amount: 50 },
        student: {
          id: "student_1",
          user: { name: "Amina" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 2000 },
          },
        },
      },
      {
        id: "payment_latest_2",
        amountPaid: 0,
        status: "DUE",
        paymentMethod: null,
        transactionId: null,
        month: 4,
        year: 2026,
        dueDate: null,
        createdAt: "2026-04-06T00:00:00.000Z",
        feeCategory: { id: "cat_latest_2", name: "Sports fee", amount: 100 },
        student: {
          id: "student_1",
          user: { name: "Amina" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 2000 },
          },
        },
      },
    ]);

    const dashboard = await getStudentDashboard("user_1");

    expect(mocks.paymentFindMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          studentId: "student_1",
          feeCategory: {
            isActive: true,
          },
        },
      }),
    );

    expect(dashboard.student.feesDue).toBe(2150);
    expect(dashboard.student.attendanceRate).toBe(50);
  });

  it("falls back to the current class monthly fee when no monthly-fee snapshots exist", async () => {
    mocks.admissionFindFirst.mockResolvedValue(null);
    mocks.listVisibleStudentExams.mockResolvedValue([]);
    mocks.studentFindUnique.mockResolvedValue({
      id: "student_1",
      rollNumber: 7,
      phone: "01700000000",
      gender: "MALE",
      classId: "class_1",
      user: {
        id: "user_1",
        name: "Amina",
        email: "amina@example.com",
        role: "STUDENT",
      },
      class: {
        id: "class_1",
        name: "Grade 1",
        monthlyFeeSetting: {
          monthlyFee: 2000,
          isActive: true,
        },
      },
      group: null,
      section: null,
      parent: null,
    });
    mocks.attendanceFindMany.mockResolvedValue([]);
    mocks.resultFindMany.mockResolvedValue([]);
    mocks.noticeFindMany.mockResolvedValue([]);
    mocks.paymentFindMany.mockResolvedValue([]);

    const dashboard = await getStudentDashboard("user_1");

    expect(dashboard.student.feesDue).toBe(2000);
  });
});
