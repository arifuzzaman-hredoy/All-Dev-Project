import { describe, expect, it, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  findSystemSettingByKey: vi.fn(),
  upsertSystemSetting: vi.fn(),
}));

vi.mock("../src/repositories/systemSetting.repository", () => ({
  findSystemSettingByKey: mocks.findSystemSettingByKey,
  upsertSystemSetting: mocks.upsertSystemSetting,
}));

import {
  getNoticeTemplateForAdmin,
  updateNoticeTemplateForAdmin,
} from "../src/services/noticeTemplate.service";

describe("notice template service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns empty template when setting does not exist", async () => {
    mocks.findSystemSettingByKey.mockResolvedValueOnce(null);

    const result = await getNoticeTemplateForAdmin();
    expect(result.template).toEqual({ header: "", footer: "", signature: "" });
  });

  it("upserts a validated notice template", async () => {
    mocks.upsertSystemSetting.mockResolvedValueOnce({ id: "setting_1" });

    const result = await updateNoticeTemplateForAdmin({
      actorId: "actor_1",
      template: { header: "H", footer: "F", signature: "S" },
    });

    expect(mocks.upsertSystemSetting).toHaveBeenCalledWith(
      expect.objectContaining({
        key: "notice_template",
        updatedById: "actor_1",
        value: { header: "H", footer: "F", signature: "S" },
      }),
    );
    expect(result.template).toEqual({ header: "H", footer: "F", signature: "S" });
  });
});
