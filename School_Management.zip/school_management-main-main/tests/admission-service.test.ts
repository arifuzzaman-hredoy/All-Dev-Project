import { Role } from "@prisma/client";
import { beforeEach, describe, expect, it, vi } from "vitest";

const txClient = {
  class: {
    findFirst: vi.fn(),
  },
};

const mocks = vi.hoisted(() => ({
  prismaTransaction: vi.fn(),
  findAdmissionByEmail: vi.fn(),
  findAdmissionById: vi.fn(),
  createAdmission: vi.fn(),
  updateAdmissionRecord: vi.fn(),
  findUserByEmail: vi.fn(),
  createUser: vi.fn(),
  findClassByName: vi.fn(),
  ensureDefaultGroup: vi.fn(),
  ensureDefaultSection: vi.fn(),
  createStudent: vi.fn(),
  findGuardianByContact: vi.fn(),
  findGuardianByUserId: vi.fn(),
  createGuardian: vi.fn(),
  updateGuardianRecord: vi.fn(),
  syncFeeCategoryAssignmentsForStudent: vi.fn(),
  sendAppEmail: vi.fn(),
  hashPassword: vi.fn(),
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    $transaction: mocks.prismaTransaction,
  },
}));

vi.mock("../src/repositories/admission.repository", () => ({
  createAdmission: mocks.createAdmission,
  findAdmissionByEmail: mocks.findAdmissionByEmail,
  findAdmissionById: mocks.findAdmissionById,
  listAdmissions: vi.fn(),
  updateAdmissionRecord: mocks.updateAdmissionRecord,
}));

vi.mock("../src/repositories/class.repository", () => ({
  ensureDefaultGroup: mocks.ensureDefaultGroup,
  ensureDefaultSection: mocks.ensureDefaultSection,
  findClassByName: mocks.findClassByName,
}));

vi.mock("../src/repositories/student.repository", () => ({
  createStudent: mocks.createStudent,
}));

vi.mock("../src/repositories/guardian.repository", () => ({
  createGuardian: mocks.createGuardian,
  findGuardianByContact: mocks.findGuardianByContact,
  findGuardianByUserId: mocks.findGuardianByUserId,
  updateGuardianRecord: mocks.updateGuardianRecord,
}));

vi.mock("../src/repositories/user.repository", () => ({
  createUser: mocks.createUser,
  findUserByEmail: mocks.findUserByEmail,
}));

vi.mock("../src/services/feeCategory.service", () => ({
  syncFeeCategoryAssignmentsForStudent:
    mocks.syncFeeCategoryAssignmentsForStudent,
}));

vi.mock("../src/utils/email", () => ({
  sendAppEmail: mocks.sendAppEmail,
}));

vi.mock("../src/lib/auth", () => ({
  hashPassword: mocks.hashPassword,
}));

import {
  submitAdmissionApplication,
  updateAdmissionForAdmin,
} from "../src/services/admission.service";

function buildAdmissionRecord(overrides: Record<string, unknown> = {}) {
  return {
    id: "adm_1",
    name: "Jane Doe",
    email: "jane@example.com",
    phone: "123456789",
    className: "Grade 1",
    message: null,
    details: {
      guardianName: "Mary Doe",
      guardianEmail: "guardian@example.com",
      guardianPhone: "999999999",
      guardianRelation: "Aunt",
      guardianAddress: "Dhaka",
      gender: "FEMALE",
    },
    status: "PENDING",
    convertedToStudentId: null,
    createdAt: new Date("2026-04-20T00:00:00.000Z"),
    updatedAt: new Date("2026-04-20T00:00:00.000Z"),
    ...overrides,
  };
}

describe("admission service", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    mocks.prismaTransaction.mockImplementation(async (callback) =>
      callback(txClient),
    );
    mocks.findAdmissionByEmail.mockResolvedValue(null);
    mocks.findAdmissionById.mockResolvedValue(buildAdmissionRecord());
    mocks.createAdmission.mockImplementation(async (data) => ({
      id: "adm_1",
      createdAt: new Date("2026-04-20T00:00:00.000Z"),
      updatedAt: new Date("2026-04-20T00:00:00.000Z"),
      status: "PENDING",
      convertedToStudentId: null,
      ...data,
    }));
    mocks.updateAdmissionRecord.mockImplementation(async (_id, data) => ({
      ...buildAdmissionRecord(),
      ...data,
      status: data.status ?? "ACCEPTED",
    }));
    mocks.findClassByName.mockResolvedValue({ id: "class_1", name: "Grade 1" });
    txClient.class.findFirst.mockResolvedValue({ id: "class_1", name: "Grade 1" });
    mocks.ensureDefaultGroup.mockResolvedValue({ id: "group_1" });
    mocks.ensureDefaultSection.mockResolvedValue({ id: "section_1" });
    mocks.createStudent.mockResolvedValue({
      id: "student_1",
      user: {
        id: "user_student",
        name: "Jane Doe",
        email: "jane@example.com",
        role: Role.STUDENT,
      },
    });
    mocks.createUser.mockImplementation(async (data) => ({
      id: data.role === Role.STUDENT ? "user_student" : "user_guardian",
      name: data.name,
      email: data.email,
      role: data.role,
    }));
    mocks.findGuardianByContact.mockResolvedValue(null);
    mocks.findGuardianByUserId.mockResolvedValue(null);
    mocks.createGuardian.mockResolvedValue({
      id: "guardian_1",
      userId: "user_guardian",
      name: "Mary Doe",
      email: "guardian@example.com",
      phone: "999999999",
      address: "Dhaka",
      relation: "Aunt",
      isDeleted: false,
      user: {
        id: "user_guardian",
        name: "Mary Doe",
        email: "guardian@example.com",
        role: Role.PARENT,
        isDeleted: false,
      },
      students: [],
      createdAt: new Date("2026-04-20T00:00:00.000Z"),
      updatedAt: new Date("2026-04-20T00:00:00.000Z"),
    });
    mocks.updateGuardianRecord.mockImplementation(async (_id, data) => ({
      ...mocks.createGuardian.mock.results[0]?.value,
      ...data,
    }));
    mocks.syncFeeCategoryAssignmentsForStudent.mockResolvedValue(undefined);
    mocks.sendAppEmail.mockResolvedValue(undefined);
    mocks.hashPassword.mockImplementation(async (password) => `hashed:${password}`);
  });

  it("creates only the admission record on submission", async () => {
    const admission = await submitAdmissionApplication({
      branchId: "branch_1",
      classId: "class_1",
      name: "Jane Doe",
      email: "jane@example.com",
      phone: "123456789",
      className: "Grade 1",
      guardianName: "Mary Doe",
      guardianEmail: "guardian@example.com",
      guardianPhone: "999999999",
    });

    expect(admission.id).toBe("adm_1");
    expect(mocks.createAdmission).toHaveBeenCalledTimes(1);
    expect(mocks.findUserByEmail).not.toHaveBeenCalled();
    expect(mocks.createUser).not.toHaveBeenCalled();
    expect(mocks.createStudent).not.toHaveBeenCalled();
    expect(mocks.createGuardian).not.toHaveBeenCalled();
    expect(mocks.sendAppEmail).not.toHaveBeenCalled();
  });

  it("creates a student on approval and reuses an existing guardian", async () => {
    mocks.findUserByEmail.mockImplementation(async (email: string) => {
      if (email === "jane@example.com") {
        return null;
      }

      if (email === "guardian@example.com") {
        return {
          id: "user_guardian",
          name: "Mary Doe",
          email: "guardian@example.com",
          role: Role.PARENT,
        };
      }

      return null;
    });
    mocks.findGuardianByUserId.mockResolvedValue({
      id: "guardian_1",
      userId: "user_guardian",
      name: "Mary Doe",
      email: "guardian@example.com",
      phone: "999999999",
      address: "Dhaka",
      relation: "Aunt",
      isDeleted: false,
      user: {
        id: "user_guardian",
        name: "Mary Doe",
        email: "guardian@example.com",
        role: Role.PARENT,
        isDeleted: false,
      },
      students: [],
      createdAt: new Date("2026-04-20T00:00:00.000Z"),
      updatedAt: new Date("2026-04-20T00:00:00.000Z"),
    });

    const admission = await updateAdmissionForAdmin("adm_1", {
      status: "APPROVED",
    });

    expect(admission.status).toBe("APPROVED");
    expect(mocks.createUser).toHaveBeenCalledTimes(1);
    expect(mocks.createStudent).toHaveBeenCalledTimes(1);
    expect(mocks.createGuardian).not.toHaveBeenCalled();
    expect(mocks.updateGuardianRecord).not.toHaveBeenCalled();
    expect(mocks.updateAdmissionRecord).toHaveBeenCalledWith(
      "adm_1",
      expect.objectContaining({
        convertedToStudentId: "student_1",
        status: "ACCEPTED",
      }),
      txClient,
    );
    expect(mocks.sendAppEmail).toHaveBeenCalledTimes(3);
    expect(mocks.sendAppEmail.mock.calls.map((call) => call[0].subject)).toEqual(
      expect.arrayContaining([
        "Your student account is ready",
        "Your guardian account has been linked",
        "Admission application approved",
      ]),
    );
  });

  it("rejects approval when the student email already exists", async () => {
    mocks.findUserByEmail.mockImplementation(async (email: string) => {
      if (email === "jane@example.com") {
        return {
          id: "user_student_existing",
          name: "Existing Student",
          email: "jane@example.com",
          role: Role.STUDENT,
        };
      }

      return null;
    });

    await expect(
      updateAdmissionForAdmin("adm_1", {
        status: "APPROVED",
      }),
    ).rejects.toMatchObject({
      status: 409,
      message: "Student email is already in use.",
    });

    expect(mocks.createUser).not.toHaveBeenCalled();
    expect(mocks.createStudent).not.toHaveBeenCalled();
    expect(mocks.updateAdmissionRecord).not.toHaveBeenCalled();
  });
});
