import { describe, expect, it } from "vitest";
import { Role } from "@prisma/client";

import { filterNav } from "@/components/app-sidebar";

describe("filterNav", () => {
  it("keeps items when anyPermissions match", () => {
    const items: Parameters<typeof filterNav>[0] = [
      {
        title: "HR",
        url: "/admin/hr",
        anyPermissions: ["manageTeachers", "manageFinance"],
        items: [
          { title: "Overview", url: "/admin/hr", anyPermissions: ["manageTeachers", "manageFinance"] },
          { title: "Departments", url: "/admin/hr/departments", permission: "manageTeachers" },
          { title: "Payroll", url: "/admin/hr/payroll", permission: "manageFinance" },
        ],
      },
    ];

    const accountantView = filterNav(items, Role.ACCOUNTANT);
    expect(accountantView).toHaveLength(1);
    expect(accountantView[0].title).toBe("HR");
    expect(accountantView[0].items?.map((item) => item.title)).toEqual(["Overview", "Payroll"]);

    const academicAdminView = filterNav(items, Role.ACADEMIC_ADMIN);
    expect(academicAdminView).toHaveLength(1);
    expect(academicAdminView[0].items?.map((item) => item.title)).toEqual(["Overview", "Departments"]);
  });

  it("drops parents when no children remain and permission fails", () => {
    const items: Parameters<typeof filterNav>[0] = [
      {
        title: "HR",
        url: "/admin/hr",
        anyPermissions: ["manageTeachers", "manageFinance"],
        items: [{ title: "Payroll", url: "/admin/hr/payroll", permission: "manageFinance" }],
      },
    ];

    const admissionAdminView = filterNav(items, Role.ADMISSION_ADMIN);
    expect(admissionAdminView).toEqual([]);
  });

  it("keeps parents when children are visible", () => {
    const items: Parameters<typeof filterNav>[0] = [
      {
        title: "Parent",
        url: "/parent",
        permission: "manageStudents",
        items: [{ title: "Child", url: "/child", permission: "manageFinance" }],
      },
    ];

    const view = filterNav(items, Role.ACCOUNTANT);
    expect(view).toHaveLength(1);
    expect(view[0].title).toBe("Parent");
    expect(view[0].items?.map((item) => item.title)).toEqual(["Child"]);
  });
});
