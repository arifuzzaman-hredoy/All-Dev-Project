import { describe, expect, it } from "vitest";
import { Role } from "@prisma/client";
import { roleHasPermission } from "../src/constants/roles";

describe("role permissions", () => {
  it("grants admins access to settings", () => {
    expect(roleHasPermission(Role.ADMIN, "manageSettings")).toBe(true);
  });

  it("keeps trash restricted to super admins", () => {
    expect(roleHasPermission(Role.ADMIN, "manageTrash")).toBe(false);
    expect(roleHasPermission(Role.SUPER_ADMIN, "manageTrash")).toBe(true);
  });
});

