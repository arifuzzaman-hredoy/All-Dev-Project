import { describe, expect, it, vi } from "vitest";
import type { NextRequest } from "next/server";
import { POST as logoutHandler } from "../src/app/api/v1/auth/logout/route";
import { POST as forgotPasswordHandler } from "../src/app/api/v1/auth/forgot-password/route";
import { POST as resetPasswordHandler } from "../src/app/api/v1/auth/reset-password/route";
import { generateToken } from "../src/lib/auth";
import { Role } from "@prisma/client";

vi.mock("../src/services/passwordReset.service", () => ({
  requestPasswordReset: vi.fn(async () => ({
    message:
      "If an account exists for that email address, you will receive instructions shortly.",
  })),
}));

type RequestOptions = {
  headers?: Array<[string, string]>;
  body?: unknown;
};

function buildRequest(options: RequestOptions = {}) {
  const headers = new Headers();
  options.headers?.forEach(([name, value]) => headers.set(name, value));
  const payload = options.body ?? {};

  return {
    headers,
    json: async () => payload
  } as unknown as NextRequest;
}

describe("Auth routes", () => {
  it("requires an Authorization header to log out", async () => {
    const response = await logoutHandler(buildRequest());
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.success).toBe(false);
    expect(body.message).toBe("Authentication token missing");
  });

  it("confirms logout when a valid token is supplied", async () => {
    const token = generateToken({ id: "test", role: Role.PARENT });
    const response = await logoutHandler(
      buildRequest({ headers: [["authorization", `Bearer ${token}`]] })
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.data?.message).toBe("Signed out");
  });

  it("accepts a forgot password request", async () => {
    const response = await forgotPasswordHandler(
      buildRequest({ body: { email: "user@example.com" } })
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.data?.message).toMatch(/instructions/);
  });

  it("requires a token for reset", async () => {
    const response = await resetPasswordHandler(buildRequest({ body: { password: "newpassword" } }));
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.success).toBe(false);
    expect(body.message).toMatch(/token/);
  });
});
