import { describe, expect, it } from "vitest";
import { Role } from "@prisma/client";
import { getDashboardRoute } from "../src/lib/role-routes";

describe("Role dashboard routing", () => {
  it("routes guardians to the guardian panel", () => {
    expect(getDashboardRoute(Role.PARENT)).toBe("/guardian");
  });

  it("routes teachers to the teacher panel", () => {
    expect(getDashboardRoute(Role.TEACHER)).toBe("/teacher");
  });

  it("routes students to the student panel", () => {
    expect(getDashboardRoute(Role.STUDENT)).toBe("/student");
  });

  it("falls back to the public landing page when role is missing", () => {
    expect(getDashboardRoute()).toBe("/");
  });
});
