import { describe, expect, it, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  listDepartments: vi.fn(),
  createDepartment: vi.fn(),
  findDepartmentById: vi.fn(),
  updateDepartment: vi.fn(),
  listDesignations: vi.fn(),
  createDesignation: vi.fn(),
  findDesignationById: vi.fn(),
  updateDesignation: vi.fn(),
  createTeacherLeaveRequest: vi.fn(),
  listTeacherLeaveRequests: vi.fn(),
  findTeacherLeaveRequestById: vi.fn(),
  updateTeacherLeaveRequest: vi.fn(),
  prismaTeacherFindUnique: vi.fn(),
  prismaTeacherLeaveRequestCount: vi.fn(),
}));

vi.mock("../src/repositories/hr.repository", () => ({
  listDepartments: mocks.listDepartments,
  createDepartment: mocks.createDepartment,
  findDepartmentById: mocks.findDepartmentById,
  updateDepartment: mocks.updateDepartment,
  listDesignations: mocks.listDesignations,
  createDesignation: mocks.createDesignation,
  findDesignationById: mocks.findDesignationById,
  updateDesignation: mocks.updateDesignation,
  createTeacherLeaveRequest: mocks.createTeacherLeaveRequest,
  listTeacherLeaveRequests: mocks.listTeacherLeaveRequests,
  findTeacherLeaveRequestById: mocks.findTeacherLeaveRequestById,
  updateTeacherLeaveRequest: mocks.updateTeacherLeaveRequest,
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    teacher: { findUnique: mocks.prismaTeacherFindUnique },
    teacherLeaveRequest: { count: mocks.prismaTeacherLeaveRequestCount },
  },
}));

import {
  createTeacherLeaveForAdmin,
  updateDepartmentForAdmin,
} from "../src/services/hr.service";

describe("hr service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("updates department after ensuring it exists", async () => {
    mocks.findDepartmentById.mockResolvedValueOnce({ id: "dep_1" });
    mocks.updateDepartment.mockResolvedValueOnce({ id: "dep_1", name: "Admin", isActive: true });

    const department = await updateDepartmentForAdmin("dep_1", { name: "Admin" });

    expect(mocks.updateDepartment).toHaveBeenCalledWith(
      "dep_1",
      expect.objectContaining({ name: "Admin" }),
    );
    expect(department.id).toBe("dep_1");
  });

  it("rejects overlapping teacher leave requests", async () => {
    mocks.prismaTeacherFindUnique.mockResolvedValueOnce({
      id: "t1",
      isDeleted: false,
      user: { isDeleted: false },
    });
    mocks.prismaTeacherLeaveRequestCount.mockResolvedValueOnce(1);

    await expect(
      createTeacherLeaveForAdmin({
        teacherId: "t1",
        startDate: "2026-04-01",
        endDate: "2026-04-05",
      }),
    ).rejects.toMatchObject({ status: 409 });
  });
});

