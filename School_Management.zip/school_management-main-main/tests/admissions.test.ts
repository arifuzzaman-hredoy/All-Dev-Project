import type { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  submitAdmissionApplication: vi.fn(),
}));

vi.mock("../src/services/admission.service", () => ({
  submitAdmissionApplication: mocks.submitAdmissionApplication,
  listAdmissionsForAdmin: vi.fn(),
}));

import { POST } from "../src/app/api/v1/admissions/route";

function buildRequest(body: unknown) {
  return {
    json: async () => body,
    headers: new Headers(),
    nextUrl: new URL("http://localhost:3000/api/v1/admissions"),
  } as unknown as NextRequest;
}

describe("Admission routes", () => {
  beforeEach(() => {
    mocks.submitAdmissionApplication.mockReset();
  });

  it("creates an admission application from the public form payload", async () => {
    mocks.submitAdmissionApplication.mockResolvedValue({
      id: "adm_123",
      name: "Jane Doe",
      email: "jane@example.com",
      phone: "123456789",
      className: "Grade 1",
      message: "Interested in the morning section",
      details: {
        gender: "FEMALE",
        fatherName: "John Doe",
        fatherPhone: "1111111111",
        motherName: "Jane Doe Sr.",
        motherPhone: "2222222222",
        guardianName: "Mary Doe",
        guardianEmail: "mary@example.com",
        guardianRelation: "Aunt",
        guardianPhone: "3333333333",
        nidNumber: "NID-123",
        nidImage: "data:image/png;base64,abc",
        profileImage: "data:image/png;base64,def",
        fatherNidNumber: "FNID-123",
        fatherNidImage: "data:image/png;base64,ghi",
        motherNidNumber: "MNID-123",
        motherNidImage: "data:image/png;base64,jkl",
      },
      status: "PENDING",
      convertedToStudentId: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const response = await POST(
      buildRequest({
        name: "Jane Doe",
        branchId: "branch_1",
        classId: "class_1",
        email: "jane@example.com",
        phone: "123456789",
        className: "Grade 1",
        gender: "FEMALE",
        fatherName: "John Doe",
        fatherPhone: "1111111111",
        motherName: "Jane Doe Sr.",
        motherPhone: "2222222222",
        guardianName: "Mary Doe",
        guardianEmail: "mary@example.com",
        guardianRelation: "Aunt",
        guardianPhone: "3333333333",
        nidNumber: "NID-123",
        nidImage: "data:image/png;base64,abc",
        profileImage: "data:image/png;base64,def",
        fatherNidNumber: "FNID-123",
        fatherNidImage: "data:image/png;base64,ghi",
        motherNidNumber: "MNID-123",
        motherNidImage: "data:image/png;base64,jkl",
      }),
    );

    const body = await response.json();

    expect(response.status).toBe(201);
    expect(body.success).toBe(true);
    expect(body.data?.admission?.name).toBe("Jane Doe");
    expect(mocks.submitAdmissionApplication).toHaveBeenCalledWith({
      name: "Jane Doe",
      branchId: "branch_1",
      classId: "class_1",
      email: "jane@example.com",
      phone: "123456789",
      className: "Grade 1",
      gender: "FEMALE",
      fatherName: "John Doe",
      fatherPhone: "1111111111",
      motherName: "Jane Doe Sr.",
      motherPhone: "2222222222",
      guardianName: "Mary Doe",
      guardianEmail: "mary@example.com",
      guardianRelation: "Aunt",
      guardianPhone: "3333333333",
      nidNumber: "NID-123",
      nidImage: "data:image/png;base64,abc",
      profileImage: "data:image/png;base64,def",
      fatherNidNumber: "FNID-123",
      fatherNidImage: "data:image/png;base64,ghi",
      motherNidNumber: "MNID-123",
      motherNidImage: "data:image/png;base64,jkl",
    });
  });
});
