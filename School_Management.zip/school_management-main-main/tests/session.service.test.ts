import { describe, expect, it, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  clearCurrentSession: vi.fn(),
  createSession: vi.fn(),
  updateSessionRecord: vi.fn(),
  findSessionById: vi.fn(),
  findCurrentSession: vi.fn(),
  listSessions: vi.fn(),
  listClasses: vi.fn(),
  prismaStudentFindMany: vi.fn(),
  prismaClassFindMany: vi.fn(),
  prismaTransaction: vi.fn(),
  txStudentFindMany: vi.fn(),
  txStudentUpdate: vi.fn(),
}));

vi.mock("../src/repositories/session.repository", () => ({
  clearCurrentSession: mocks.clearCurrentSession,
  createSession: mocks.createSession,
  updateSessionRecord: mocks.updateSessionRecord,
  findSessionById: mocks.findSessionById,
  findCurrentSession: mocks.findCurrentSession,
  listSessions: mocks.listSessions,
}));

vi.mock("../src/repositories/class.repository", () => ({
  listClasses: mocks.listClasses,
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    class: {
      findMany: mocks.prismaClassFindMany,
    },
    student: {
      findMany: mocks.prismaStudentFindMany,
    },
    $transaction: mocks.prismaTransaction,
  },
}));

type TxCallback = (tx: unknown) => unknown | Promise<unknown>;

import {
  createAcademicSessionForAdmin,
  buildNextClassMappings,
  migrateStudentsToSessionForAdmin,
  setCurrentAcademicSessionForAdmin,
} from "../src/services/session.service";

describe("session service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("creates a session and clears previous current when makeCurrent is true", async () => {
    mocks.clearCurrentSession.mockResolvedValueOnce({ count: 1 });
    mocks.createSession.mockResolvedValueOnce({
      id: "sess_2",
      name: "2026",
      isCurrent: true,
      isActive: true,
      startsAt: null,
      endsAt: null,
    });

    mocks.prismaTransaction.mockImplementationOnce(async (fn: TxCallback) => fn({}));

    const session = await createAcademicSessionForAdmin({
      name: "2026",
      makeCurrent: true,
    });

    expect(mocks.clearCurrentSession).toHaveBeenCalledTimes(1);
    expect(mocks.createSession).toHaveBeenCalledTimes(1);
    expect(session.isCurrent).toBe(true);
  });

  it("sets a session as current and clears existing current sessions", async () => {
    mocks.findSessionById.mockResolvedValueOnce({
      id: "sess_2",
      name: "2026",
      isCurrent: false,
      isActive: true,
    });
    mocks.clearCurrentSession.mockResolvedValueOnce({ count: 1 });
    mocks.updateSessionRecord.mockResolvedValueOnce({
      id: "sess_2",
      isCurrent: true,
    });
    mocks.prismaTransaction.mockImplementationOnce(async (fn: TxCallback) => fn({}));

    const updated = await setCurrentAcademicSessionForAdmin("sess_2");

    expect(mocks.clearCurrentSession).toHaveBeenCalledTimes(1);
    expect(mocks.updateSessionRecord).toHaveBeenCalledWith("sess_2", { isCurrent: true }, expect.anything());
    expect(updated.isCurrent).toBe(true);
  });

  it("migrates only mapped students and resets roll numbers", async () => {
    mocks.findSessionById
      .mockResolvedValueOnce({ id: "sess_from", isActive: true })
      .mockResolvedValueOnce({ id: "sess_to", isActive: true });

    mocks.prismaClassFindMany.mockResolvedValueOnce([
      { id: "class_1" },
      { id: "class_2" },
    ]);

    mocks.prismaStudentFindMany.mockResolvedValueOnce([
      { id: "student_1", classId: "class_1" },
      { id: "student_2", classId: "class_1" },
      { id: "student_3", classId: "class_unmapped" },
    ]);

    const tx = {
      student: {
        update: mocks.txStudentUpdate,
        findMany: mocks.txStudentFindMany,
      },
    };

    mocks.prismaTransaction.mockImplementationOnce(async (fn: TxCallback) => fn(tx));

    // roll reset loads students in target class + session
    mocks.txStudentFindMany.mockResolvedValueOnce([
      { id: "student_1" },
      { id: "student_2" },
    ]);

    const result = await migrateStudentsToSessionForAdmin({
      fromSessionId: "sess_from",
      toSessionId: "sess_to",
      classMappings: [{ fromClassId: "class_1", toClassId: "class_2" }],
      resetRollNumbers: true,
      clearGroupSection: true,
    });

    expect(result.totalInFromSession).toBe(3);
    expect(result.updated).toBe(2);
    expect(result.skipped).toBe(1);
    expect(mocks.txStudentUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          rollNumber: null,
          groupId: null,
          sectionId: null,
        }),
      }),
    );

    // roll numbers assigned 1..n
    expect(mocks.txStudentUpdate).toHaveBeenCalledWith({
      where: { id: "student_1" },
      data: { rollNumber: 1 },
    });
    expect(mocks.txStudentUpdate).toHaveBeenCalledWith({
      where: { id: "student_2" },
      data: { rollNumber: 2 },
    });
  });

  it("rejects migration when sessions are the same", async () => {
    await expect(
      migrateStudentsToSessionForAdmin({
        fromSessionId: "sess_1",
        toSessionId: "sess_1",
        classMappings: [{ fromClassId: "class_1", toClassId: "class_2" }],
      }),
    ).rejects.toMatchObject({ status: 400 });
  });

  it("builds next-class mappings from class order and ignores Unassigned and last class", () => {
    const mappings = buildNextClassMappings([
      { id: "u", name: "Unassigned", sortOrder: 999999 },
      { id: "c1", name: "One", sortOrder: 1 },
      { id: "c2", name: "Two", sortOrder: 2 },
      { id: "c3", name: "Three", sortOrder: 3 },
    ]);

    expect(mappings).toEqual([
      { fromClassId: "c1", toClassId: "c2" },
      { fromClassId: "c2", toClassId: "c3" },
    ]);
  });

  it("builds next-class mappings that keep legacy A/B variants together", () => {
    const mappings = buildNextClassMappings([
      { id: "u", name: "Unassigned", sortOrder: 999999 },
      { id: "1a", name: "1A", sortOrder: 1 },
      { id: "1b", name: "1B", sortOrder: 2 },
      { id: "2a", name: "2A", sortOrder: 3 },
      { id: "2b", name: "2B", sortOrder: 4 },
      { id: "3a", name: "3A", sortOrder: 5 },
      { id: "3b", name: "3B", sortOrder: 6 },
    ]);

    expect(mappings).toEqual([
      { fromClassId: "1a", toClassId: "2a" },
      { fromClassId: "1b", toClassId: "2b" },
      { fromClassId: "2a", toClassId: "3a" },
      { fromClassId: "2b", toClassId: "3b" },
    ]);
  });
});
