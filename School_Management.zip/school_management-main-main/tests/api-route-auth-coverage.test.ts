/// <reference types="vite/client" />

import fs from "node:fs";
import { describe, expect, it } from "vitest";
import type { NextRequest } from "next/server";

type RouteModule = Partial<
  Record<
    "GET" | "POST" | "PATCH" | "PUT" | "DELETE",
    (request: NextRequest, context?: unknown) => Promise<Response> | Response
  >
>;

const routeModules = import.meta.glob<RouteModule>("../src/app/api/**/route.ts");

const publicRouteMethods = new Set([
  "../src/app/api/send/route.ts:POST",
  "../src/app/api/v1/admissions/route.ts:POST",
  "../src/app/api/v1/auth/forgot-password/route.ts:POST",
  "../src/app/api/v1/auth/login/route.ts:POST",
  "../src/app/api/v1/auth/register/route.ts:POST",
  "../src/app/api/v1/auth/reset-password/route.ts:POST",
  "../src/app/api/v1/auth/session/route.ts:DELETE",
  "../src/app/api/v1/classes/route.ts:GET",
  "../src/app/api/v1/public/branches/route.ts:GET",
  "../src/app/api/v1/theme/global/route.ts:GET",
]);

function exportedMethods(routePath: string) {
  const source = fs.readFileSync(new URL(routePath, import.meta.url), "utf8");
  return Array.from(
    source.matchAll(/export\s+async\s+function\s+(GET|POST|PATCH|PUT|DELETE)\b/g),
    (match) => match[1] as keyof RouteModule,
  );
}

function buildUrl(routePath: string) {
  const apiPath = routePath
    .replace("../src/app", "")
    .replace("/route.ts", "")
    .replace(/\[[^\]]+\]/g, "test-id");
  return `http://localhost:3000${apiPath}`;
}

function buildRequest(routePath: string) {
  const url = buildUrl(routePath);
  const headers = new Headers();
  return {
    url,
    nextUrl: new URL(url),
    headers,
    cookies: {
      get: () => undefined,
    },
    json: async () => ({}),
  } as unknown as NextRequest;
}

function buildContext() {
  return {
    params: Promise.resolve({
      id: "test-id",
      classId: "class-id",
      studentId: "student-id",
      examId: "exam-id",
      groupId: "group-id",
    }),
  };
}

const protectedRouteCases = Object.keys(routeModules)
  .sort()
  .flatMap((routePath) =>
    exportedMethods(routePath).map((method) => ({ routePath, method })),
  )
  .filter(({ routePath, method }) => !publicRouteMethods.has(`${routePath}:${method}`));

describe("API route auth coverage", () => {
  it("keeps the public API allowlist explicit", () => {
    const allRouteMethods = new Set(
      Object.keys(routeModules).flatMap((routePath) =>
        exportedMethods(routePath).map((method) => `${routePath}:${method}`),
      ),
    );

    for (const routeMethod of publicRouteMethods) {
      expect(allRouteMethods.has(routeMethod), `${routeMethod} should exist`).toBe(true);
    }
  });

  it.each(protectedRouteCases)(
    "$method $routePath rejects missing auth before feature logic",
    async ({ routePath, method }) => {
      const routeModule = await routeModules[routePath]();
      const handler = routeModule[method];

      expect(handler, `${method} handler should exist for ${routePath}`).toBeTypeOf("function");

      const response = await handler!(buildRequest(routePath), buildContext());
      const body = await response.json();

      expect(response.status).toBe(401);
      expect(body).toMatchObject({
        success: false,
        message: "Authentication token missing",
      });
    },
  );
});
