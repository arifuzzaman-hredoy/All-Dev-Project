import { describe, expect, it, vi } from "vitest";
import { FinanceEntryType } from "@prisma/client";
import type { PrismaClientLike } from "../src/lib/prisma";
import {
  createFinanceEntryForAdmin,
  getMonthlyFinanceReport,
} from "../src/services/finance.service";

function createClientStub() {
  type ClientStub = {
    payment: { aggregate: ReturnType<typeof vi.fn> };
    financeEntry: {
      aggregate: ReturnType<typeof vi.fn>;
      groupBy: ReturnType<typeof vi.fn>;
      create: ReturnType<typeof vi.fn>;
    };
    financeCategory: {
      findMany: ReturnType<typeof vi.fn>;
      findUnique: ReturnType<typeof vi.fn>;
    };
    student: { findUnique: ReturnType<typeof vi.fn> };
  };
  const client = {} as ClientStub;
  client.payment = { aggregate: vi.fn() };
  client.financeEntry = {
    aggregate: vi.fn(),
    groupBy: vi.fn(),
    create: vi.fn(),
  };
  client.financeCategory = {
    findMany: vi.fn(),
    findUnique: vi.fn(),
  };
  client.student = { findUnique: vi.fn() };
  return client as PrismaClientLike & ClientStub;
}

describe("finance service", () => {
  it("builds a monthly finance report that includes fee income + other income and expenses", async () => {
    const client = createClientStub();
    client.payment.aggregate.mockResolvedValueOnce({ _sum: { amountPaid: 2500 } });
    client.financeEntry.aggregate
      .mockResolvedValueOnce({ _sum: { amount: 300 } }) // income
      .mockResolvedValueOnce({ _sum: { amount: 900 } }); // expense
    client.financeEntry.groupBy
      .mockResolvedValueOnce([{ categoryId: "cat_donation", _sum: { amount: 300 } }])
      .mockResolvedValueOnce([{ categoryId: "cat_salary", _sum: { amount: 900 } }]);
    client.financeCategory.findMany.mockResolvedValueOnce([
      { id: "cat_donation", name: "Donation", type: "INCOME" },
      { id: "cat_salary", name: "Salary", type: "EXPENSE" },
    ]);

    const report = await getMonthlyFinanceReport(
      { month: 4, year: 2026 },
      client,
    );

    expect(report.totals).toEqual({
      feeIncome: 2500,
      otherIncome: 300,
      income: 2800,
      expense: 900,
      net: 1900,
    });
    expect(report.breakdown.incomeByCategory[0]).toMatchObject({
      categoryName: "Donation",
      amount: 300,
    });
    expect(report.breakdown.expenseByCategory[0]).toMatchObject({
      categoryName: "Salary",
      amount: 900,
    });
  });

  it("rejects finance entry creation when category type mismatches", async () => {
    const client = createClientStub();
    client.financeCategory.findUnique.mockResolvedValueOnce({
      id: "cat_salary",
      type: FinanceEntryType.EXPENSE,
      isActive: true,
    });

    await expect(
      createFinanceEntryForAdmin(
        "actor_1",
        {
          type: FinanceEntryType.INCOME,
          categoryId: "cat_salary",
          amount: 100,
          occurredAt: "2026-04-01T00:00:00.000Z",
        },
        client,
      ),
    ).rejects.toMatchObject({ status: 400 });
  });
});
