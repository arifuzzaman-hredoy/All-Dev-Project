import { describe, expect, it } from "vitest";
import type { NextRequest } from "next/server";
import { GET as guardianDashboardHandler } from "../src/app/api/v1/guardian/dashboard/route";
import { GET as teacherDashboardHandler } from "../src/app/api/v1/teacher/dashboard/route";
import { GET as auditLogsHandler } from "../src/app/api/v1/audit-logs/route";
import { GET as remindersHandler } from "../src/app/api/v1/notifications/reminders/route";

function buildRequest(url = "http://localhost:3000/api/test") {
  return {
    url,
    headers: new Headers(),
  } as unknown as NextRequest;
}

describe("Portal route auth", () => {
  it("rejects guardian dashboard without an Authorization header", async () => {
    const response = await guardianDashboardHandler(buildRequest("http://localhost:3000/api/v1/guardian/dashboard"));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.message).toBe("Authentication token missing");
  });

  it("rejects teacher dashboard without an Authorization header", async () => {
    const response = await teacherDashboardHandler(buildRequest("http://localhost:3000/api/v1/teacher/dashboard"));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.message).toBe("Authentication token missing");
  });

  it("rejects audit log reads without an Authorization header", async () => {
    const response = await auditLogsHandler(buildRequest("http://localhost:3000/api/v1/audit-logs"));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.message).toBe("Authentication token missing");
  });

  it("rejects reminder preview without an Authorization header", async () => {
    const response = await remindersHandler(buildRequest("http://localhost:3000/api/v1/notifications/reminders"));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.message).toBe("Authentication token missing");
  });
});
