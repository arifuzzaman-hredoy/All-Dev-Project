import { describe, expect, it } from "vitest";
import {
  getPaymentDueAmount,
  getPaymentTotalAmount,
} from "../src/lib/fee-utils";

describe("fee utils", () => {
  it("uses the category amount when no monthly fee is configured", () => {
    expect(getPaymentTotalAmount(null, 500)).toBe(500);
    expect(getPaymentDueAmount(null, 500, 200)).toBe(300);
  });

  it("adds the class monthly fee before calculating due amounts", () => {
    expect(getPaymentTotalAmount(1000, 500)).toBe(1500);
    expect(getPaymentDueAmount(1000, 500, 1200)).toBe(300);
  });

  it("never returns a negative due amount", () => {
    expect(getPaymentDueAmount(1000, 500, 2000)).toBe(0);
  });
});
