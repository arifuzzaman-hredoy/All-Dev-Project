import { describe, expect, it, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  findPayrollRunByPeriod: vi.fn(),
  createPayrollRun: vi.fn(),
  listPayrollRuns: vi.fn(),
  findPayrollRunById: vi.fn(),
  listPayrollItems: vi.fn(),
  updatePayrollItem: vi.fn(),
  markPayrollRunItemsPaid: vi.fn(),
  updatePayrollRun: vi.fn(),
  prismaTeacherFindMany: vi.fn(),
  prismaTeacherAttendanceFindMany: vi.fn(),
  prismaPayrollItemFindUnique: vi.fn(),
  prismaTransaction: vi.fn(),
}));

vi.mock("../src/repositories/payroll.repository", () => ({
  findPayrollRunByPeriod: mocks.findPayrollRunByPeriod,
  createPayrollRun: mocks.createPayrollRun,
  listPayrollRuns: mocks.listPayrollRuns,
  findPayrollRunById: mocks.findPayrollRunById,
  listPayrollItems: mocks.listPayrollItems,
  updatePayrollItem: mocks.updatePayrollItem,
  markPayrollRunItemsPaid: mocks.markPayrollRunItemsPaid,
  updatePayrollRun: mocks.updatePayrollRun,
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    teacher: { findMany: mocks.prismaTeacherFindMany },
    teacherAttendance: { findMany: mocks.prismaTeacherAttendanceFindMany },
    payrollItem: { findUnique: mocks.prismaPayrollItemFindUnique },
    $transaction: mocks.prismaTransaction,
  },
}));

import {
  generatePayrollRunForAdmin,
  updatePayrollItemForAdmin,
} from "../src/services/payroll.service";

describe("payroll service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.prismaTransaction.mockImplementation(async (fn) => fn({}));
  });

  it("generates a payroll run with items based on teacher salary snapshots", async () => {
    mocks.findPayrollRunByPeriod.mockResolvedValueOnce(null);
    mocks.prismaTeacherFindMany.mockResolvedValueOnce([
      { id: "t1", salary: 1000 },
      { id: "t2", salary: null },
    ]);
    mocks.prismaTeacherAttendanceFindMany.mockResolvedValueOnce([]);
    mocks.createPayrollRun.mockResolvedValueOnce({ id: "run1", month: 4, year: 2026 });

    const run = await generatePayrollRunForAdmin({ month: 4, year: 2026, actorId: "a1" });

    expect(mocks.createPayrollRun).toHaveBeenCalled();
    expect(run.id).toBe("run1");
  });

  it("recomputes net pay when allowances change", async () => {
    mocks.prismaPayrollItemFindUnique.mockResolvedValueOnce({
      id: "item1",
      payrollRunId: "run1",
      baseSalarySnapshot: 1000,
      allowances: 0,
      deductions: 0,
    });
    mocks.updatePayrollItem.mockResolvedValueOnce({ id: "item1", netPay: 1200 });

    const item = await updatePayrollItemForAdmin({ payrollItemId: "item1", allowances: 200 });

    expect(mocks.updatePayrollItem).toHaveBeenCalledWith(
      "item1",
      expect.objectContaining({ netPay: 1200 }),
    );
    expect(item.id).toBe("item1");
  });
});

