import { beforeEach, describe, expect, it, vi } from "vitest";
import { Role } from "@prisma/client";

const mocks = vi.hoisted(() => ({
  prismaTeacherFindUnique: vi.fn(),
  prismaStudentFindMany: vi.fn(),
  prismaExamFindUnique: vi.fn(),
  prismaAttendanceUpsert: vi.fn(),
  prismaResultUpsert: vi.fn(),
  prismaTransaction: vi.fn(),
  prismaTimetableFindMany: vi.fn(),
  recordAuditEvent: vi.fn(),
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    teacher: { findUnique: mocks.prismaTeacherFindUnique },
    student: { findMany: mocks.prismaStudentFindMany },
    exam: { findUnique: mocks.prismaExamFindUnique },
    attendance: { upsert: mocks.prismaAttendanceUpsert },
    result: { upsert: mocks.prismaResultUpsert },
    timetable: { findMany: mocks.prismaTimetableFindMany },
    $transaction: mocks.prismaTransaction,
  },
}));

vi.mock("../src/services/audit.service", () => ({
  recordAuditEvent: mocks.recordAuditEvent,
}));

vi.mock("../src/services/exam.service", () => ({
  listVisibleTeacherExams: vi.fn(async () => []),
}));

vi.mock("../src/services/notice.service", () => ({
  syncExpiredNotices: vi.fn(async () => undefined),
}));

vi.mock("../src/services/theme.service", () => ({
  fetchUserTheme: vi.fn(async () => null),
}));

vi.mock("../src/repositories/user.repository", () => ({
  findUserByEmail: vi.fn(),
}));

vi.mock("../src/repositories/notice.repository", () => ({
  buildVisibleNoticeWhere: vi.fn(() => ({})),
}));

import {
  listTeacherTimetable,
  saveTeacherAttendance,
  saveTeacherResults,
} from "../src/services/teacherPortal.service";

function activeTeacher() {
  return {
    id: "teacher_1",
    phone: null,
    address: null,
    isDeleted: false,
    user: {
      id: "user_1",
      name: "Teacher",
      email: "teacher@example.com",
      role: Role.TEACHER,
      isDeleted: false,
    },
    subjects: [
      {
        id: "assignment_1",
        classId: "class_1",
        subjectId: "subject_1",
        class: { id: "class_1", name: "Class 1" },
        subject: { id: "subject_1", name: "Bangla" },
      },
    ],
    managedClasses: [],
  };
}

describe("teacher portal service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.prismaTransaction.mockImplementation(async (operations) =>
      Promise.all(operations),
    );
  });

  it("blocks deactivated teacher accounts from portal data", async () => {
    mocks.prismaTeacherFindUnique.mockResolvedValueOnce({
      ...activeTeacher(),
      isDeleted: true,
    });

    await expect(listTeacherTimetable("user_1")).rejects.toThrow(
      "Teacher account not found",
    );
  });

  it("rejects duplicate attendance student entries before writing", async () => {
    mocks.prismaTeacherFindUnique.mockResolvedValueOnce(activeTeacher());

    await expect(
      saveTeacherAttendance("user_1", {
        classId: "class_1",
        subjectId: "subject_1",
        date: "2026-04-24",
        entries: [
          { studentId: "student_1", status: "PRESENT" },
          { studentId: "student_1", status: "ABSENT" },
        ],
      }),
    ).rejects.toThrow("Duplicate student entries are not allowed");

    expect(mocks.prismaAttendanceUpsert).not.toHaveBeenCalled();
  });

  it("allows result entry when exam covers class through assigned classes", async () => {
    mocks.prismaTeacherFindUnique.mockResolvedValueOnce(activeTeacher());
    mocks.prismaExamFindUnique.mockResolvedValueOnce({
      id: "exam_1",
      classId: "class_primary",
      isAllClasses: false,
      assignedClasses: [{ classId: "class_1" }],
    });
    mocks.prismaStudentFindMany.mockResolvedValueOnce([{ id: "student_1" }]);
    mocks.prismaResultUpsert.mockResolvedValueOnce({ id: "result_1", marks: 80 });

    const result = await saveTeacherResults("user_1", {
      classId: "class_1",
      subjectId: "subject_1",
      examId: "exam_1",
      entries: [{ studentId: "student_1", marks: 80 }],
    });

    expect(result.summary).toMatchObject({ total: 1, averageMarks: 80 });
    expect(mocks.prismaResultUpsert).toHaveBeenCalled();
  });
});
