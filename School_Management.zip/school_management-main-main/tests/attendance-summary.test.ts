import { describe, expect, it } from "vitest";
import { buildAttendanceSummary } from "../src/lib/attendance-summary";

describe("attendance summary", () => {
  it("builds totals, percentages, subject buckets, and month buckets", () => {
    const summary = buildAttendanceSummary([
      {
        date: new Date("2026-04-01T00:00:00.000Z"),
        status: "PRESENT",
        subject: { name: "Bangla" },
      },
      {
        date: new Date("2026-04-02T00:00:00.000Z"),
        status: "ABSENT",
        subject: { name: "Bangla" },
      },
      {
        date: new Date("2026-05-01T00:00:00.000Z"),
        status: "LATE",
        subject: { name: "Math" },
      },
    ]);

    expect(summary).toMatchObject({
      total: 3,
      present: 1,
      absent: 1,
      late: 1,
      attendanceRate: 33,
    });
    expect(summary.bySubject).toEqual([
      {
        subject: "Bangla",
        total: 2,
        present: 1,
        absent: 1,
        late: 0,
        attendanceRate: 50,
      },
      {
        subject: "Math",
        total: 1,
        present: 0,
        absent: 0,
        late: 1,
        attendanceRate: 0,
      },
    ]);
    expect(summary.byMonth).toEqual([
      {
        month: "2026-04",
        total: 2,
        present: 1,
        absent: 1,
        late: 0,
        attendanceRate: 50,
      },
      {
        month: "2026-05",
        total: 1,
        present: 0,
        absent: 0,
        late: 1,
        attendanceRate: 0,
      },
    ]);
  });
});
