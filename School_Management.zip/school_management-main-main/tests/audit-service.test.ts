import { describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  createAuditLog: vi.fn(),
}));

vi.mock("../src/repositories/auditLog.repository", () => ({
  createAuditLog: mocks.createAuditLog,
  countAuditLogs: vi.fn(),
  listAuditActors: vi.fn(),
  listAuditLogs: vi.fn(),
}));

import { recordAuditEvent } from "../src/services/audit.service";

describe("audit service", () => {
  it("does not throw when audit persistence fails", async () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    mocks.createAuditLog.mockRejectedValueOnce(new Error("missing actor"));

    try {
      await expect(
        recordAuditEvent({
          actorId: "missing-user",
          action: "admin.class.created",
          entityType: "Class",
          entityId: "class_1",
        }),
      ).resolves.toBeNull();
    } finally {
      errorSpy.mockRestore();
    }
  });
});
