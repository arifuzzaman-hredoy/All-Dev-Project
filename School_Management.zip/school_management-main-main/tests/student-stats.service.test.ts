import { describe, expect, it, vi } from "vitest";
import type { PrismaClientLike } from "../src/lib/prisma";
import { getStudentGenderCounts } from "../src/services/studentStats.service";

function createClientStub() {
  type ClientStub = {
    student: { groupBy: ReturnType<typeof vi.fn> };
    class: { findMany: ReturnType<typeof vi.fn> };
  };
  const client = {} as ClientStub;
  client.student = { groupBy: vi.fn() };
  client.class = { findMany: vi.fn() };
  return client as PrismaClientLike & ClientStub;
}

describe("student stats service", () => {
  it("returns overall gender counts and class breakdowns", async () => {
    const client = createClientStub();
    client.student.groupBy
      .mockResolvedValueOnce([
        { gender: "MALE", _count: { _all: 5 } },
        { gender: "FEMALE", _count: { _all: 7 } },
      ])
      .mockResolvedValueOnce([
        { classId: "class_1", gender: "MALE", _count: { _all: 2 } },
        { classId: "class_1", gender: "FEMALE", _count: { _all: 3 } },
        { classId: "class_2", gender: "MALE", _count: { _all: 3 } },
        { classId: "class_2", gender: "FEMALE", _count: { _all: 4 } },
      ]);
    client.class.findMany.mockResolvedValueOnce([
      { id: "class_1", name: "Grade 1" },
      { id: "class_2", name: "Grade 2" },
    ]);

    const report = await getStudentGenderCounts({}, client);

    expect(report.totals).toMatchObject({
      MALE: 5,
      FEMALE: 7,
      OTHER: 0,
    });
    expect(report.totalStudents).toBe(12);
    expect(report.byClass).toHaveLength(2);
    expect(report.byClass[0]).toMatchObject({
      classId: "class_1",
      className: "Grade 1",
      totalStudents: 5,
    });
  });

  it("returns only class totals when classId filter is provided", async () => {
    const client = createClientStub();
    client.student.groupBy.mockResolvedValueOnce([
      { gender: "OTHER", _count: { _all: 1 } },
    ]);

    const report = await getStudentGenderCounts({ classId: "class_1" }, client);

    expect(report.classId).toBe("class_1");
    expect(report.byClass).toEqual([]);
    expect(report.totals).toMatchObject({
      MALE: 0,
      FEMALE: 0,
      OTHER: 1,
    });
    expect(report.totalStudents).toBe(1);
  });
});
