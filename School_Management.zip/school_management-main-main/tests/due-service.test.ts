import { describe, expect, it, vi } from "vitest";
import type { PrismaClientLike } from "../src/lib/prisma";
import { generateDuesForPeriod, getDueListReport } from "../src/services/due.service";

function createClientStub() {
  type ClientStub = {
    student: { findMany: ReturnType<typeof vi.fn> };
    feeCategoryClass: { findMany: ReturnType<typeof vi.fn> };
    payment: {
      createMany: ReturnType<typeof vi.fn>;
      findMany: ReturnType<typeof vi.fn>;
    };
  };
  const client = {} as ClientStub;
  client.student = { findMany: vi.fn() };
  client.feeCategoryClass = { findMany: vi.fn() };
  client.payment = {
    createMany: vi.fn(),
    findMany: vi.fn(),
  };
  return client as PrismaClientLike & ClientStub;
}

describe("due service", () => {
  it("generates DUE payment rows for a billing period and skips duplicates", async () => {
    const client = createClientStub();
    client.student.findMany.mockResolvedValueOnce([
      {
        id: "student_1",
        classId: "class_1",
        class: { monthlyFeeSetting: { monthlyFee: 1000, isActive: true } },
      },
      {
        id: "student_2",
        classId: "class_1",
        class: { monthlyFeeSetting: { monthlyFee: 1000, isActive: true } },
      },
    ]);
    client.feeCategoryClass.findMany.mockResolvedValueOnce([
      {
        classId: "class_1",
        feeCategoryId: "cat_1",
        feeCategory: { amount: 100 },
      },
      {
        classId: "class_1",
        feeCategoryId: "cat_2",
        feeCategory: { amount: 50 },
      },
    ]);
    client.payment.createMany.mockResolvedValueOnce({ count: 3 });

    const result = await generateDuesForPeriod(
      { month: 4, year: 2026, classId: "class_1" },
      client,
    );

    expect(client.payment.createMany).toHaveBeenCalledWith(
      expect.objectContaining({
        skipDuplicates: true,
      }),
    );
    expect(result).toEqual({ expected: 4, created: 3, skipped: 1 });
  });

  it("builds a due list report for month + class", async () => {
    const client = createClientStub();
    client.payment.findMany.mockResolvedValueOnce([
      {
        id: "payment_1",
        amountPaid: 0,
        status: "DUE",
        paymentMethod: null,
        transactionId: null,
        month: 4,
        year: 2026,
        dueDate: new Date("2026-04-30T00:00:00.000Z"),
        createdAt: new Date("2026-04-01T00:00:00.000Z"),
        monthlyFeeSnapshot: 1000,
        feeAmountSnapshot: 100,
        feeCategory: { id: "cat_1", name: "Exam fee", amount: 100 },
        student: {
          id: "student_1",
          user: { name: "Amina" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 1000, isActive: true },
          },
        },
      },
      {
        id: "payment_2",
        amountPaid: 0,
        status: "DUE",
        paymentMethod: null,
        transactionId: null,
        month: 4,
        year: 2026,
        dueDate: new Date("2026-04-30T00:00:00.000Z"),
        createdAt: new Date("2026-04-02T00:00:00.000Z"),
        monthlyFeeSnapshot: 1000,
        feeAmountSnapshot: 200,
        feeCategory: { id: "cat_2", name: "Sports fee", amount: 200 },
        student: {
          id: "student_1",
          user: { name: "Amina" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 1000, isActive: true },
          },
        },
      },
    ]);

    const report = await getDueListReport(
      { month: 4, year: 2026, classId: "class_1" },
      client,
    );

    expect(report.items).toHaveLength(1);
    expect(report.items[0]).toMatchObject({
      studentId: "student_1",
      studentName: "Amina",
      className: "Grade 1",
      totalExpected: 1300,
      amountPaid: 0,
      dueAmount: 1300,
      monthlyFeeBase: 1000,
      extraCategoryFees: 300,
    });
    expect(report.stats.totalDue).toBe(1300);
  });
});
