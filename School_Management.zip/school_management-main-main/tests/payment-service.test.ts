import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  listPayments: vi.fn(),
  listStudents: vi.fn(),
  listFeeCategories: vi.fn(),
  findFeeCategoryById: vi.fn(),
  findStudentById: vi.fn(),
  findPaymentByStudentCategoryPeriod: vi.fn(),
  createPayment: vi.fn(),
  updatePaymentRecord: vi.fn(),
}));

vi.mock("../src/repositories/feeCategory.repository", () => ({
  findFeeCategoryById: mocks.findFeeCategoryById,
  listFeeCategories: mocks.listFeeCategories,
}));

vi.mock("../src/repositories/payment.repository", () => ({
  createPayment: mocks.createPayment,
  deletePaymentRecord: vi.fn(),
  findPaymentById: vi.fn(),
  findPaymentByStudentCategoryPeriod: mocks.findPaymentByStudentCategoryPeriod,
  listPayments: mocks.listPayments,
  updatePaymentRecord: mocks.updatePaymentRecord,
}));

vi.mock("../src/repositories/student.repository", () => ({
  findStudentById: mocks.findStudentById,
  listStudents: mocks.listStudents,
}));

import { listPaymentsForAdmin } from "../src/services/payment.service";
import { createPaymentForAdmin } from "../src/services/payment.service";

describe("payment service", () => {
  beforeEach(() => {
    mocks.listPayments.mockReset();
    mocks.listStudents.mockReset();
    mocks.listFeeCategories.mockReset();
    mocks.findFeeCategoryById.mockReset();
    mocks.findStudentById.mockReset();
    mocks.findPaymentByStudentCategoryPeriod.mockReset();
    mocks.createPayment.mockReset();
    mocks.updatePaymentRecord.mockReset();
  });

  it("returns admin payment history with monthly base and extra category totals", async () => {
    mocks.listPayments.mockResolvedValue([
      {
        id: "payment_1",
        amountPaid: 900,
        status: "PARTIAL",
        paymentMethod: "bKash",
        transactionId: "TXN-100",
        month: 4,
        year: 2026,
        dueDate: "2026-04-30T00:00:00.000Z",
        createdAt: "2026-04-05T10:00:00.000Z",
        student: {
          id: "student_1",
          user: { name: "Amina", email: "amina@example.com" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 1000 },
          },
          rollNumber: 12,
        },
        feeCategory: { id: "cat_1", name: "Exam fee", amount: 200 },
      },
      {
        id: "payment_2",
        amountPaid: 300,
        status: "PAID",
        paymentMethod: "Nagad",
        transactionId: "TXN-101",
        month: 4,
        year: 2026,
        dueDate: "2026-04-30T00:00:00.000Z",
        createdAt: "2026-04-20T10:00:00.000Z",
        student: {
          id: "student_1",
          user: { name: "Amina", email: "amina@example.com" },
          class: {
            name: "Grade 1",
            monthlyFeeSetting: { monthlyFee: 1000 },
          },
          rollNumber: 12,
        },
        feeCategory: { id: "cat_2", name: "Lab fee", amount: 100 },
      },
    ]);
    mocks.listStudents.mockResolvedValue([
      {
        id: "student_1",
        user: { name: "Amina" },
        class: { name: "Grade 1" },
      },
    ]);
    mocks.listFeeCategories.mockResolvedValue([
      { id: "cat_1", name: "Exam fee", amount: 200, isActive: true },
    ]);

    const result = await listPaymentsForAdmin({ status: "PARTIAL" });

    expect(mocks.listPayments).toHaveBeenCalledWith({ status: "PARTIAL" });
    expect(result.payments).toHaveLength(2);
    expect(result.payments[0].monthlyFeeBase).toBe(1000);
    expect(result.payments[0].totalAmount).toBe(1200);
    expect(result.history).toHaveLength(1);
    expect(result.history[0].label).toBe("April 2026");
    expect(result.history[0].extraCategoryFees).toBe(300);
    expect(result.history[0].totalExpected).toBe(1300);
    expect(result.history[0].amountPaid).toBe(1200);
    expect(result.history[0].dueAmount).toBe(100);
    expect(result.stats.total).toBe(1);
    expect(result.stats.collectedAmount).toBe(1200);
    expect(result.stats.expectedAmount).toBe(1300);
    expect(result.stats.dueAmount).toBe(100);
    expect(result.stats.dueCount).toBe(1);
  });

  it("rejects duplicate category fees for the same student and billing period", async () => {
    mocks.findStudentById.mockResolvedValue({
      id: "student_1",
      classId: "class_1",
      class: {
        monthlyFeeSetting: {
          monthlyFee: 1000,
          isActive: true,
        },
      },
    });
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 0 },
      targetClasses: [],
    });
    mocks.findPaymentByStudentCategoryPeriod.mockResolvedValue({
      id: "payment_1",
      amountPaid: 1200,
      monthlyFeeSnapshot: 1000,
      feeAmountSnapshot: 200,
      feeCategory: { id: "cat_1", name: "Exam fee", amount: 200 },
      student: {
        class: {
          monthlyFeeSetting: {
            monthlyFee: 1000,
            isActive: true,
          },
        },
      },
    });

    await expect(
      createPaymentForAdmin({
        studentId: "student_1",
        feeCategoryId: "cat_1",
        amountPaid: 500,
        status: "PAID",
        month: 4,
        year: 2026,
      }),
    ).rejects.toMatchObject({
      status: 409,
      message:
        "This fee category is already settled for this student in the selected billing period",
    });

    expect(mocks.createPayment).not.toHaveBeenCalled();
  });

  it("settles an existing generated due row instead of creating a duplicate", async () => {
    mocks.findStudentById.mockResolvedValue({
      id: "student_1",
      classId: "class_1",
      class: {
        monthlyFeeSetting: {
          monthlyFee: 1000,
          isActive: true,
        },
      },
    });
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 250,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 1 },
      targetClasses: [{ classId: "class_1" }],
    });
    mocks.findPaymentByStudentCategoryPeriod.mockResolvedValue({
      id: "payment_1",
      amountPaid: 0,
      monthlyFeeSnapshot: 1000,
      feeAmountSnapshot: 250,
      feeCategory: { id: "cat_1", name: "Exam fee", amount: 250 },
      student: {
        class: {
          monthlyFeeSetting: {
            monthlyFee: 1000,
            isActive: true,
          },
        },
      },
    });

    mocks.updatePaymentRecord.mockResolvedValue({ id: "payment_1" });

    await createPaymentForAdmin({
      studentId: "student_1",
      feeCategoryId: "cat_1",
      amountPaid: 500,
      status: "PAID",
      paymentMethod: "Cash",
      month: 4,
      year: 2026,
    });

    expect(mocks.createPayment).not.toHaveBeenCalled();
    expect(mocks.updatePaymentRecord).toHaveBeenCalledWith(
      "payment_1",
      expect.objectContaining({
        amountPaid: 500,
        status: "PARTIAL",
        paymentMethod: "Cash",
      }),
    );
  });

  it("snapshots fee amounts when creating a payment record", async () => {
    mocks.findStudentById.mockResolvedValue({
      id: "student_1",
      classId: "class_1",
      class: {
        monthlyFeeSetting: {
          monthlyFee: 1000,
          isActive: true,
        },
      },
    });
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 250,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 0 },
      targetClasses: [{ classId: "class_1" }],
    });
    mocks.findPaymentByStudentCategoryPeriod.mockResolvedValue(null);
    mocks.createPayment.mockResolvedValue({ id: "payment_2" });

    await createPaymentForAdmin({
      studentId: "student_1",
      feeCategoryId: "cat_1",
      amountPaid: 100,
      status: "PARTIAL",
      month: 4,
      year: 2026,
    });

    expect(mocks.createPayment).toHaveBeenCalledWith(
      expect.objectContaining({
        monthlyFeeSnapshot: 1000,
        feeAmountSnapshot: 250,
        dedupeKey: "2026-04",
      }),
    );
  });
});
