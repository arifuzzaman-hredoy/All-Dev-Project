import { beforeEach, describe, expect, it, vi } from "vitest";
import { Role } from "@prisma/client";

const mocks = vi.hoisted(() => ({
  findUserByEmailWithBranch: vi.fn(),
  comparePassword: vi.fn(),
  generateToken: vi.fn(() => "token"),
  assertBranchIsActive: vi.fn(),
}));

vi.mock("../src/repositories/user.repository", () => ({
  findUserByEmailWithBranch: mocks.findUserByEmailWithBranch,
  findUserByEmail: vi.fn(),
  createUser: vi.fn(),
}));

vi.mock("../src/services/branch.service", () => ({
  assertBranchIsActive: mocks.assertBranchIsActive,
}));

vi.mock("../src/lib/auth", async () => {
  const actual = await vi.importActual<typeof import("../src/lib/auth")>(
    "../src/lib/auth",
  );
  return {
    ...actual,
    comparePassword: mocks.comparePassword,
    generateToken: mocks.generateToken,
  };
});

import { loginUser } from "../src/services/auth.service";

describe("loginUser branch selection", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.comparePassword.mockResolvedValue(true);
    mocks.assertBranchIsActive.mockResolvedValue({
      id: "branch_1",
      name: "Main",
      slug: "main",
      isActive: true,
      school: { id: "s1", name: "School", slug: "school" },
    });
  });

  it("requires branch selection for staff/admin roles", async () => {
    mocks.findUserByEmailWithBranch.mockResolvedValueOnce({
      id: "u1",
      name: "Admin",
      email: "admin@example.com",
      password: "hash",
      role: Role.ADMIN,
      branchId: "branch_1",
      branch: { id: "branch_1", name: "Main", slug: "main", isActive: true, schoolId: "s1" },
    });

    await expect(
      loginUser({ email: "admin@example.com", password: "pass" }),
    ).rejects.toMatchObject({ status: 400 });
  });

  it("rejects mismatched branch for staff/admin roles", async () => {
    mocks.findUserByEmailWithBranch.mockResolvedValueOnce({
      id: "u1",
      name: "Admin",
      email: "admin@example.com",
      password: "hash",
      role: Role.ADMIN,
      branchId: "branch_1",
      branch: { id: "branch_1", name: "Main", slug: "main", isActive: true, schoolId: "s1" },
    });

    await expect(
      loginUser({ email: "admin@example.com", password: "pass", branchId: "branch_2" }),
    ).rejects.toMatchObject({ status: 403 });
  });

  it("requires super admin to choose a branch", async () => {
    mocks.findUserByEmailWithBranch.mockResolvedValueOnce({
      id: "u1",
      name: "Super",
      email: "super@example.com",
      password: "hash",
      role: Role.SUPER_ADMIN,
      branchId: null,
      branch: null,
    });

    await expect(
      loginUser({ email: "super@example.com", password: "pass" }),
    ).rejects.toMatchObject({ status: 400 });
  });

  it("allows super admin to choose a branch", async () => {
    mocks.findUserByEmailWithBranch.mockResolvedValueOnce({
      id: "u1",
      name: "Super",
      email: "super@example.com",
      password: "hash",
      role: Role.SUPER_ADMIN,
      branchId: null,
      branch: null,
    });

    const result = await loginUser({
      email: "super@example.com",
      password: "pass",
      branchId: "branch_1",
    });

    expect(mocks.assertBranchIsActive).toHaveBeenCalledWith("branch_1");
    expect(result.user?.branchId).toBe("branch_1");
  });
});
