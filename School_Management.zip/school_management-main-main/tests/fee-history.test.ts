import { describe, expect, it } from "vitest";
import { buildFeeLedger } from "../src/lib/fee-history";

function buildPayment(
  overrides: Partial<Parameters<typeof buildFeeLedger>[0][number]> = {},
) {
  return {
    id: "payment_1",
    amountPaid: 800,
    status: "PARTIAL",
    paymentMethod: "bKash",
    transactionId: "TXN-001",
    month: 4,
    year: 2026,
    dueDate: "2026-04-30",
    createdAt: "2026-04-02T10:00:00.000Z",
    feeCategory: {
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
    },
    student: {
      id: "student_1",
      user: {
        name: "Amina",
      },
      class: {
        name: "Grade 1",
        monthlyFeeSetting: {
          monthlyFee: 1000,
        },
      },
    },
    ...overrides,
  } as Parameters<typeof buildFeeLedger>[0][number];
}

describe("fee ledger builder", () => {
  it("groups transactions by month and keeps the monthly base separate from category fees", () => {
    const ledger = buildFeeLedger([
      buildPayment(),
      buildPayment({
        id: "payment_2",
        amountPaid: 500,
        transactionId: "TXN-002",
        createdAt: "2026-04-18T09:00:00.000Z",
        feeCategory: {
          id: "cat_2",
          name: "Transport fee",
          amount: 100,
        },
      }),
    ]);

    expect(ledger.payments).toHaveLength(2);
    expect(ledger.payments[0].monthlyFeeBase).toBe(1000);
    expect(ledger.payments[0].monthlyFeeDue).toBe(200);
    expect(ledger.payments[0].extraCategoryDue).toBe(200);
    expect(ledger.payments[0].totalAmount).toBe(1200);
    expect(ledger.history).toHaveLength(1);
    expect(ledger.history[0].label).toBe("April 2026");
    expect(ledger.history[0].monthlyFeeBase).toBe(1000);
    expect(ledger.history[0].monthlyFeeDue).toBe(0);
    expect(ledger.history[0].extraCategoryFees).toBe(300);
    expect(ledger.history[0].extraCategoryDue).toBe(0);
    expect(ledger.history[0].totalExpected).toBe(1300);
    expect(ledger.history[0].amountPaid).toBe(1300);
    expect(ledger.history[0].dueAmount).toBe(0);
    expect(ledger.history[0].transactions).toHaveLength(2);
  });

  it("falls back to the createdAt month when month and year are missing", () => {
    const ledger = buildFeeLedger([
      buildPayment({
        id: "payment_3",
        amountPaid: 1000,
        month: null,
        year: null,
        createdAt: "2026-05-05T08:00:00.000Z",
        feeCategory: {
          id: "cat_3",
          name: "Library fee",
          amount: 50,
        },
        student: {
          id: "student_2",
          user: {
            name: "Rafi",
          },
          class: {
            name: "Grade 2",
            monthlyFeeSetting: {
              monthlyFee: null,
            },
          },
        },
      }),
      buildPayment({
        id: "payment_4",
        amountPaid: 250,
        month: 3,
        year: 2026,
        createdAt: "2026-03-01T08:00:00.000Z",
        feeCategory: {
          id: "cat_4",
          name: "Activity fee",
          amount: 25,
        },
        student: {
          id: "student_3",
          user: {
            name: "Nila",
          },
          class: {
            name: "Grade 3",
            monthlyFeeSetting: {
              monthlyFee: 500,
            },
          },
        },
      }),
    ]);

    expect(ledger.history[0].label).toBe("May 2026");
    expect(ledger.history[0].monthlyFeeBase).toBe(0);
    expect(ledger.history[0].monthlyFeeDue).toBe(0);
    expect(ledger.history[0].extraCategoryDue).toBe(0);
    expect(ledger.history[0].totalExpected).toBe(50);
    expect(ledger.history[1].label).toBe("March 2026");
    expect(ledger.history[1].monthlyFeeBase).toBe(500);
    expect(ledger.history[1].monthlyFeeDue).toBe(250);
    expect(ledger.history[1].extraCategoryDue).toBe(25);
    expect(ledger.history[1].dueAmount).toBe(275);
  });

  it("uses stored snapshots instead of live fee settings when they are present", () => {
    const ledger = buildFeeLedger([
      buildPayment({
        id: "payment_5",
        amountPaid: 400,
        monthlyFeeSnapshot: 1200,
        feeAmountSnapshot: 300,
        createdAt: "2026-06-10T08:00:00.000Z",
        feeCategory: {
          id: "cat_5",
          name: "Event fee",
          amount: 999,
        },
        student: {
          id: "student_4",
          user: {
            name: "Toma",
          },
          class: {
            name: "Grade 4",
            monthlyFeeSetting: {
              monthlyFee: 700,
            },
          },
        },
      }),
    ]);

    expect(ledger.payments[0].monthlyFeeBase).toBe(1200);
    expect(ledger.payments[0].monthlyFeeDue).toBe(800);
    expect(ledger.payments[0].extraCategoryDue).toBe(300);
    expect(ledger.payments[0].categoryFee).toBe(300);
    expect(ledger.history[0].monthlyFeeBase).toBe(1200);
    expect(ledger.history[0].monthlyFeeDue).toBe(800);
    expect(ledger.history[0].extraCategoryFees).toBe(300);
    expect(ledger.history[0].extraCategoryDue).toBe(300);
    expect(ledger.history[0].totalExpected).toBe(1500);
    expect(ledger.history[0].dueAmount).toBe(1100);
  });

  it("treats inactive monthly fees as zero in the ledger", () => {
    const ledger = buildFeeLedger([
      buildPayment({
        id: "payment_6",
        amountPaid: 100,
        feeCategory: {
          id: "cat_6",
          name: "Activity fee",
          amount: 150,
        },
        student: {
          id: "student_5",
          user: {
            name: "Nila",
          },
          class: {
            name: "Grade 5",
            monthlyFeeSetting: {
              monthlyFee: 1200,
              isActive: false,
            },
          },
        },
      }),
    ]);

    expect(ledger.payments[0].monthlyFeeBase).toBe(0);
    expect(ledger.payments[0].monthlyFeeDue).toBe(0);
    expect(ledger.payments[0].extraCategoryDue).toBe(50);
    expect(ledger.payments[0].totalAmount).toBe(150);
    expect(ledger.history[0].monthlyFeeBase).toBe(0);
    expect(ledger.history[0].monthlyFeeDue).toBe(0);
    expect(ledger.history[0].extraCategoryDue).toBe(50);
    expect(ledger.history[0].totalExpected).toBe(150);
  });
});
