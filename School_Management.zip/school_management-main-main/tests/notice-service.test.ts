import { describe, expect, it, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  findClassById: vi.fn(),
  createNotice: vi.fn(),
  findNoticeById: vi.fn(),
  updateNoticeRecord: vi.fn(),
}));

vi.mock("../src/repositories/class.repository", () => ({
  findClassById: mocks.findClassById,
  listClasses: vi.fn(),
}));

vi.mock("../src/repositories/notice.repository", () => ({
  createNotice: mocks.createNotice,
  deleteNoticeRecord: vi.fn(),
  findNoticeById: mocks.findNoticeById,
  listNotices: vi.fn(),
  updateNoticeRecord: mocks.updateNoticeRecord,
  buildVisibleNoticeWhere: vi.fn(),
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    notice: {
      updateMany: vi.fn(),
    },
  },
}));

import { createNoticeForAdmin, publishNoticeForAdmin } from "../src/services/notice.service";

describe("notice service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.findClassById.mockResolvedValue({ id: "class_1" });
    mocks.createNotice.mockImplementation(async (data: Record<string, unknown>) => ({
      id: "notice_1",
      ...data,
    }));
    mocks.updateNoticeRecord.mockImplementation(async (_id: string, data: Record<string, unknown>) => ({
      id: "notice_1",
      ...data,
    }));
  });

  it("creates notices as drafts (inactive) and allows empty content", async () => {
    const notice = await createNoticeForAdmin({
      title: "Test notice",
      content: "",
      audience: "ALL",
      classId: "class_1",
    });

    expect(mocks.createNotice).toHaveBeenCalledWith(
      expect.objectContaining({
        title: "Test notice",
        content: "",
        status: "DRAFT",
        isActive: false,
      }),
    );
    expect(notice.status).toBe("DRAFT");
    expect(notice.isActive).toBe(false);
  });

  it("rejects publishing a notice with empty content", async () => {
    mocks.findNoticeById.mockResolvedValueOnce({
      id: "notice_1",
      content: "   ",
    });

    await expect(publishNoticeForAdmin("notice_1")).rejects.toMatchObject({
      status: 400,
    });
  });

  it("publishes a notice and marks it active", async () => {
    mocks.findNoticeById.mockResolvedValueOnce({
      id: "notice_1",
      content: "Hello",
    });

    const updated = await publishNoticeForAdmin("notice_1");

    expect(mocks.updateNoticeRecord).toHaveBeenCalledWith(
      "notice_1",
      expect.objectContaining({
        status: "PUBLISHED",
        isActive: true,
      }),
    );
    expect(updated.status).toBe("PUBLISHED");
    expect(updated.isActive).toBe(true);
  });
});
