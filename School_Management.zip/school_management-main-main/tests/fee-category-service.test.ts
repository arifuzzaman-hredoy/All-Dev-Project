import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  findFeeCategoryById: vi.fn(),
  deleteFeeCategoryRecord: vi.fn(),
  updateFeeCategoryRecord: vi.fn(),
  comparePassword: vi.fn(),
  transaction: vi.fn(),
  userFindUnique: vi.fn(),
  paymentDeleteMany: vi.fn(),
  feeCategoryDelete: vi.fn(),
}));

vi.mock("../src/repositories/feeCategory.repository", () => ({
  createFeeCategory: vi.fn(),
  deleteFeeCategoryRecord: mocks.deleteFeeCategoryRecord,
  findFeeCategoryById: mocks.findFeeCategoryById,
  listFeeCategories: vi.fn(),
  updateFeeCategoryRecord: mocks.updateFeeCategoryRecord,
}));

vi.mock("../src/repositories/class.repository", () => ({
  listClasses: vi.fn(),
}));

vi.mock("../src/lib/auth", () => ({
  comparePassword: mocks.comparePassword,
}));

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    $transaction: mocks.transaction,
  },
}));

import {
  deleteFeeCategoryForAdmin,
  updateFeeCategoryForAdmin,
  syncFeeCategoryAssignmentsForStudent,
} from "../src/services/feeCategory.service";

describe("fee category service", () => {
  beforeEach(() => {
    mocks.findFeeCategoryById.mockReset();
    mocks.deleteFeeCategoryRecord.mockReset();
    mocks.updateFeeCategoryRecord.mockReset();
    mocks.comparePassword.mockReset();
    mocks.transaction.mockReset();
    mocks.userFindUnique.mockReset();
    mocks.paymentDeleteMany.mockReset();
    mocks.feeCategoryDelete.mockReset();
  });

  it("creates one due record per targeted fee and snapshots the current monthly fee", async () => {
    const paymentCreateMany = vi.fn().mockResolvedValue({ count: 2 });
    const client = {
      student: {
        findUnique: vi.fn().mockResolvedValue({
          class: {
            monthlyFeeSetting: {
              monthlyFee: 1500,
            },
          },
        }),
      },
      feeCategory: {
        findMany: vi.fn().mockResolvedValue([
          { id: "cat_1", amount: 200 },
          { id: "cat_2", amount: 300 },
        ]),
      },
      payment: {
        createMany: paymentCreateMany,
      },
    } as never;

    const count = await syncFeeCategoryAssignmentsForStudent(
      "student_1",
      "class_1",
      client,
    );

    expect(count).toBe(2);
    expect(paymentCreateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        skipDuplicates: true,
        data: [
          expect.objectContaining({
            studentId: "student_1",
            feeCategoryId: "cat_1",
            monthlyFeeSnapshot: 1500,
            feeAmountSnapshot: 200,
            dedupeKey: "secondary:cat_1",
          }),
          expect.objectContaining({
            studentId: "student_1",
            feeCategoryId: "cat_2",
            monthlyFeeSnapshot: 1500,
            feeAmountSnapshot: 300,
            dedupeKey: "secondary:cat_2",
          }),
        ],
      }),
    );
  });

  it("permanently deletes a fee category when no payment records exist", async () => {
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 0 },
      targetClasses: [],
    });
    mocks.deleteFeeCategoryRecord.mockResolvedValue({ id: "cat_1" });

    await deleteFeeCategoryForAdmin("cat_1", { permanent: true });

    expect(mocks.deleteFeeCategoryRecord).toHaveBeenCalledWith("cat_1");
    expect(mocks.updateFeeCategoryRecord).not.toHaveBeenCalled();
  });

  it("toggles fee category active state through update", async () => {
    mocks.findFeeCategoryById.mockResolvedValueOnce({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 0 },
      targetClasses: [],
    });
    mocks.findFeeCategoryById.mockResolvedValueOnce({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: false,
      createdAt: new Date().toISOString(),
      _count: { payments: 0 },
      targetClasses: [],
    });

    const transaction = vi.fn(async (callback) => callback({} as never));
    mocks.updateFeeCategoryRecord.mockResolvedValue({ id: "cat_1" });
    mocks.transaction.mockImplementation(transaction);

    const updated = await updateFeeCategoryForAdmin("cat_1", {
      isActive: false,
    });

    expect(mocks.updateFeeCategoryRecord).toHaveBeenCalledWith(
      "cat_1",
      expect.objectContaining({ isActive: false }),
      expect.any(Object),
    );
    expect(updated.isActive).toBe(false);
  });

  it("rejects permanent delete when payment records already exist", async () => {
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 2 },
      targetClasses: [],
    });

    await expect(
      deleteFeeCategoryForAdmin("cat_1", { permanent: true }),
    ).rejects.toMatchObject({
      status: 409,
      message:
        "Use force delete to remove linked payment records before permanently deleting this fee category",
    });

    expect(mocks.deleteFeeCategoryRecord).not.toHaveBeenCalled();
  });

  it("force deletes linked fee records after password verification", async () => {
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 2 },
      targetClasses: [],
    });
    mocks.comparePassword.mockResolvedValue(true);
    mocks.deleteFeeCategoryRecord.mockImplementation(async (_id, client) => {
      if (client?.feeCategory?.delete) {
        return client.feeCategory.delete({ where: { id: "cat_1" } });
      }

      return { id: "cat_1" };
    });
    mocks.transaction.mockImplementation(async (callback) =>
      callback({
        user: {
          findUnique: mocks.userFindUnique.mockResolvedValue({
            password: "hashed-password",
          }),
        },
        payment: {
          deleteMany: mocks.paymentDeleteMany.mockResolvedValue({ count: 2 }),
        },
        feeCategory: {
          delete: mocks.feeCategoryDelete.mockResolvedValue({ id: "cat_1" }),
        },
      } as never),
    );

    const result = await deleteFeeCategoryForAdmin("cat_1", {
      actorId: "admin_1",
      force: true,
      currentPassword: "admin-password",
    });

    expect(mocks.comparePassword).toHaveBeenCalledWith(
      "admin-password",
      "hashed-password",
    );
    expect(mocks.paymentDeleteMany).toHaveBeenCalledWith({
      where: { feeCategoryId: "cat_1" },
    });
    expect(mocks.feeCategoryDelete).toHaveBeenCalledWith({
      where: { id: "cat_1" },
    });
    expect(result).toEqual({ id: "cat_1" });
  });

  it("rejects force delete when the admin password is invalid", async () => {
    mocks.findFeeCategoryById.mockResolvedValue({
      id: "cat_1",
      name: "Exam fee",
      amount: 200,
      isActive: true,
      createdAt: new Date().toISOString(),
      _count: { payments: 2 },
      targetClasses: [],
    });
    mocks.transaction.mockImplementation(async (callback) =>
      callback({
        user: {
          findUnique: mocks.userFindUnique.mockResolvedValue({
            password: "hashed-password",
          }),
        },
        payment: {
          deleteMany: mocks.paymentDeleteMany,
        },
        feeCategory: {
          delete: mocks.feeCategoryDelete,
        },
      } as never),
    );
    mocks.comparePassword.mockResolvedValue(false);

    await expect(
      deleteFeeCategoryForAdmin("cat_1", {
        actorId: "admin_1",
        force: true,
        currentPassword: "wrong-password",
      }),
    ).rejects.toMatchObject({
      status: 401,
      message: "Admin password is incorrect",
    });

    expect(mocks.paymentDeleteMany).not.toHaveBeenCalled();
    expect(mocks.feeCategoryDelete).not.toHaveBeenCalled();
  });
});
