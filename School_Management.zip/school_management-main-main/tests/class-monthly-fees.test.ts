import type { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  listClassMonthlyFeesForAdmin: vi.fn(),
  setClassMonthlyFeeForAdmin: vi.fn(),
  recordAuditEvent: vi.fn(),
  requireAuth: vi.fn(() => ({ id: "admin_1", role: "ACCOUNTANT" })),
  requirePermission: vi.fn(),
}));

vi.mock("../src/services/classFee.service", () => ({
  listClassMonthlyFeesForAdmin: mocks.listClassMonthlyFeesForAdmin,
  setClassMonthlyFeeForAdmin: mocks.setClassMonthlyFeeForAdmin,
}));

vi.mock("../src/services/audit.service", () => ({
  recordAuditEvent: mocks.recordAuditEvent,
}));

vi.mock("../src/lib/auth", () => ({
  requireAuth: mocks.requireAuth,
}));

vi.mock("../src/lib/permissions", () => ({
  requirePermission: mocks.requirePermission,
}));

import { GET, PATCH } from "../src/app/api/v1/fees/monthly/route";

function buildRequest(
  body: unknown = {},
  url = "http://localhost:3000/api/v1/fees/monthly",
) {
  return {
    json: async () => body,
    headers: new Headers(),
    nextUrl: new URL(url),
  } as unknown as NextRequest;
}

describe("Monthly class fee routes", () => {
  beforeEach(() => {
    mocks.listClassMonthlyFeesForAdmin.mockReset();
    mocks.setClassMonthlyFeeForAdmin.mockReset();
    mocks.recordAuditEvent.mockReset();
    mocks.requireAuth.mockReset();
    mocks.requireAuth.mockReturnValue({ id: "admin_1", role: "ACCOUNTANT" });
    mocks.requirePermission.mockReset();
  });

  it("returns monthly fee settings for classes", async () => {
    mocks.listClassMonthlyFeesForAdmin.mockResolvedValue({
      classes: [{ id: "class_1", name: "Grade 1", monthlyFee: 2500 }],
      stats: { total: 1, configured: 1, totalMonthlyFee: 2500 },
    });

    const response = await GET(buildRequest());
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.data?.classes?.[0]?.monthlyFee).toBe(2500);
  });

  it("updates a class monthly fee", async () => {
    mocks.setClassMonthlyFeeForAdmin.mockResolvedValue({
      id: "fee_1",
      classId: "class_1",
      monthlyFee: 3500,
      class: { id: "class_1", name: "Grade 1" },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const response = await PATCH(
      buildRequest({ classId: "class_1", monthlyFee: 3500 }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(mocks.setClassMonthlyFeeForAdmin).toHaveBeenCalledWith({
      classId: "class_1",
      monthlyFee: 3500,
    });
  });
});
