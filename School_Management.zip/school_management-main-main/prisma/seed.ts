import "dotenv/config";
import {
  Prisma,
  PrismaClient,
  Role,
  Gender,
  FinanceEntryType,
  WeekDay,
  AttendanceStatus,
  LeaveStatus,
  PayrollRunStatus,
  PayrollItemStatus,
  PaymentStatus,
  NoticeAudience,
  NoticeStatus,
  ExamLifecycleStatus,
  ExamTypeCategory,
  AdmissionStatus,
  NotificationChannel,
  NotificationStatus,
} from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient({
  adapter: new PrismaPg({
    connectionString: process.env.DATABASE_URL,
  }),
});

const DEFAULT_PASSWORD = "12345678";
const SUPER_ADMIN_EMAIL = "mahialamazad.bd@gmail.com";
const SEED_TAG = "seed-2026-full";

const BULK_CONFIG = {
  admins: 12,
  accountants: 6,
  academicAdmins: 6,
  admissionAdmins: 6,
  genericUsers: 8,
  teachers: 30,
  guardians: 150,
  parents: 60,
  studentsPerClass: 30,
};

const CLASS_NAMES = Array.from(
  { length: 10 },
  (_, index) => `Class ${index + 1}`,
);
const GROUP_NAMES = ["Science", "Commerce", "Humanities"];
const SECTION_NAMES = ["A", "B"];
const SUBJECT_NAMES = [
  "Bangla",
  "English",
  "Mathematics",
  "General Science",
  "ICT",
];
const WEEK_DAYS: WeekDay[] = [
  WeekDay.MONDAY,
  WeekDay.TUESDAY,
  WeekDay.WEDNESDAY,
  WeekDay.THURSDAY,
  WeekDay.FRIDAY,
  WeekDay.SATURDAY,
];

type UserSeedInput = {
  name: string;
  email: string;
  role: Role;
  branchId: string;
  passwordHash: string;
};

type BasicUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
};

type SeedTeacher = {
  id: string;
  userId: string;
  salary: number | null;
};

type SeedGuardian = {
  id: string;
  userId: string | null;
  phone: string | null;
};

type SeedParent = {
  id: string;
  userId: string;
  phone: string | null;
};

type SeedStudent = {
  id: string;
  classId: string;
  groupId: string | null;
  sectionId: string | null;
  guardianId: string | null;
  parentId: string | null;
  serial: number;
};

type ClassGroupSection = {
  classId: string;
  className: string;
  classIndex: number;
  groups: Array<{
    groupId: string;
    sectionIds: string[];
  }>;
};

type SubjectAssignment = {
  subjectId: string;
  subjectName: string;
  teacherId: string;
};

async function ensureUser(input: UserSeedInput) {
  return prisma.user.upsert({
    where: {
      email: input.email,
    },
    update: {
      name: input.name,
      role: input.role,
      password: input.passwordHash,
      branchId: input.branchId,
      isDeleted: false,
    },
    create: {
      name: input.name,
      email: input.email,
      role: input.role,
      password: input.passwordHash,
      branchId: input.branchId,
    },
  });
}

async function seedRoleUsers(params: {
  namePrefix: string;
  emailPrefix: string;
  count: number;
  role: Role;
  branchId: string;
  passwordHash: string;
}) {
  const users: BasicUser[] = [];

  for (let index = 1; index <= params.count; index += 1) {
    const user = await ensureUser({
      name: `${params.namePrefix} ${index}`,
      email: `${params.emailPrefix}${index}@gmail.com`,
      role: params.role,
      branchId: params.branchId,
      passwordHash: params.passwordHash,
    });

    users.push({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  }

  return users;
}

async function findOrCreateSubject(classId: string, name: string) {
  const existing = await prisma.subject.findFirst({
    where: {
      classId,
      name,
    },
  });

  if (existing) {
    return existing;
  }

  return prisma.subject.create({
    data: {
      classId,
      name,
    },
  });
}

async function ensureFeeCategory(name: string, amount: number) {
  const existing = await prisma.feeCategory.findFirst({
    where: {
      name,
    },
  });

  if (existing) {
    return prisma.feeCategory.update({
      where: {
        id: existing.id,
      },
      data: {
        amount,
        isActive: true,
      },
    });
  }

  return prisma.feeCategory.create({
    data: {
      name,
      amount,
      isActive: true,
    },
  });
}

async function ensureNotice(input: {
  title: string;
  content: string;
  audience: NoticeAudience;
  classId?: string | null;
  status: NoticeStatus;
  isActive: boolean;
  startsAt?: Date | null;
  endsAt?: Date | null;
  publishedAt?: Date | null;
}) {
  const existing = await prisma.notice.findFirst({
    where: {
      title: input.title,
      audience: input.audience,
      classId: input.classId ?? null,
    },
  });

  const data: Prisma.NoticeUpdateInput = {
    title: input.title,
    content: input.content,
    audience: input.audience,
    status: input.status,
    isActive: input.isActive,
    startsAt: input.startsAt ?? null,
    endsAt: input.endsAt ?? null,
    publishedAt: input.publishedAt ?? null,
    class: input.classId
      ? {
          connect: {
            id: input.classId,
          },
        }
      : {
          disconnect: true,
        },
  };

  if (existing) {
    return prisma.notice.update({
      where: {
        id: existing.id,
      },
      data,
    });
  }

  const createData: Prisma.NoticeCreateInput = {
    title: input.title,
    content: input.content,
    audience: input.audience,
    status: input.status,
    isActive: input.isActive,
    startsAt: input.startsAt ?? null,
    endsAt: input.endsAt ?? null,
    publishedAt: input.publishedAt ?? null,
    ...(input.classId
      ? {
          class: {
            connect: {
              id: input.classId,
            },
          },
        }
      : {}),
  };

  return prisma.notice.create({
    data: createData,
  });
}

async function ensureAdmissionApplication(input: {
  name: string;
  email: string;
  phone?: string | null;
  className: string;
  message?: string | null;
  status: AdmissionStatus;
  convertedToStudentId?: string | null;
  details?: Prisma.InputJsonValue;
}) {
  const existing = await prisma.admissionApplication.findFirst({
    where: {
      email: input.email,
      className: input.className,
    },
  });

  const data: Prisma.AdmissionApplicationUpdateInput = {
    name: input.name,
    email: input.email,
    phone: input.phone ?? null,
    className: input.className,
    message: input.message ?? null,
    status: input.status,
    convertedToStudentId: input.convertedToStudentId ?? null,
    details: input.details ?? Prisma.DbNull,
  };

  if (existing) {
    return prisma.admissionApplication.update({
      where: {
        id: existing.id,
      },
      data,
    });
  }

  return prisma.admissionApplication.create({
    data: {
      name: input.name,
      email: input.email,
      phone: input.phone ?? null,
      className: input.className,
      message: input.message ?? null,
      status: input.status,
      convertedToStudentId: input.convertedToStudentId ?? null,
      details: input.details ?? Prisma.DbNull,
    },
  });
}

async function ensureFinanceEntry(input: {
  key: string;
  type: FinanceEntryType;
  categoryId: string;
  amount: number;
  occurredAt: Date;
  description: string;
  createdById: string;
  studentId?: string | null;
}) {
  const taggedDescription = `[${SEED_TAG}:${input.key}] ${input.description}`;

  const existing = await prisma.financeEntry.findFirst({
    where: {
      description: taggedDescription,
    },
  });

  const data: Prisma.FinanceEntryUpdateInput = {
    type: input.type,
    category: {
      connect: {
        id: input.categoryId,
      },
    },
    amount: input.amount,
    occurredAt: input.occurredAt,
    description: taggedDescription,
    createdBy: {
      connect: {
        id: input.createdById,
      },
    },
    isDeleted: false,
    student: input.studentId
      ? {
          connect: {
            id: input.studentId,
          },
        }
      : {
          disconnect: true,
        },
  };

  if (existing) {
    return prisma.financeEntry.update({
      where: {
        id: existing.id,
      },
      data,
    });
  }

  const createData: Prisma.FinanceEntryCreateInput = {
    type: input.type,
    category: {
      connect: {
        id: input.categoryId,
      },
    },
    amount: input.amount,
    occurredAt: input.occurredAt,
    description: taggedDescription,
    createdBy: {
      connect: {
        id: input.createdById,
      },
    },
    ...(input.studentId
      ? {
          student: {
            connect: {
              id: input.studentId,
            },
          },
        }
      : {}),
  };

  return prisma.financeEntry.create({
    data: createData,
  });
}

async function ensureNotificationQueue(input: {
  templateId?: string | null;
  channel: NotificationChannel;
  status: NotificationStatus;
  recipientName?: string | null;
  recipientEmail: string;
  subject: string;
  body: string;
  metadata?: Prisma.InputJsonValue;
  errorMessage?: string | null;
  sentAt?: Date | null;
}) {
  const existing = await prisma.notificationQueue.findFirst({
    where: {
      templateId: input.templateId ?? null,
      recipientEmail: input.recipientEmail,
      subject: input.subject,
    },
  });

  const data: Prisma.NotificationQueueUpdateInput = {
    channel: input.channel,
    status: input.status,
    recipientName: input.recipientName ?? null,
    recipientEmail: input.recipientEmail,
    subject: input.subject,
    body: input.body,
    metadata: input.metadata ?? Prisma.DbNull,
    errorMessage: input.errorMessage ?? null,
    sentAt: input.sentAt ?? null,
    template: input.templateId
      ? {
          connect: {
            id: input.templateId,
          },
        }
      : {
          disconnect: true,
        },
  };

  if (existing) {
    return prisma.notificationQueue.update({
      where: {
        id: existing.id,
      },
      data,
    });
  }

  const createData: Prisma.NotificationQueueCreateInput = {
    channel: input.channel,
    status: input.status,
    recipientName: input.recipientName ?? null,
    recipientEmail: input.recipientEmail,
    subject: input.subject,
    body: input.body,
    metadata: input.metadata ?? Prisma.DbNull,
    errorMessage: input.errorMessage ?? null,
    sentAt: input.sentAt ?? null,
    ...(input.templateId
      ? {
          template: {
            connect: {
              id: input.templateId,
            },
          },
        }
      : {}),
  };

  return prisma.notificationQueue.create({
    data: createData,
  });
}

async function ensureAuditLog(input: {
  action: string;
  entityType: string;
  entityId?: string | null;
  actorId?: string | null;
  metadata?: Prisma.InputJsonValue;
}) {
  const existing = await prisma.auditLog.findFirst({
    where: {
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId ?? null,
    },
  });

  if (existing) {
    return existing;
  }

  return prisma.auditLog.create({
    data: {
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId ?? null,
      actorId: input.actorId ?? null,
      metadata: input.metadata ?? Prisma.DbNull,
    },
  });
}

function gradeFromMarks(marks: number) {
  if (marks >= 80) return "A+";
  if (marks >= 70) return "A";
  if (marks >= 60) return "A-";
  if (marks >= 50) return "B";
  if (marks >= 40) return "C";
  if (marks >= 33) return "D";
  return "F";
}

async function main() {
  const passwordHash = await bcrypt.hash(DEFAULT_PASSWORD, 10);

  const school = await prisma.school.upsert({
    where: {
      slug: "school-erp-demo",
    },
    update: {
      name: "School ERP Demo",
      isActive: true,
    },
    create: {
      name: "School ERP Demo",
      slug: "school-erp-demo",
      isActive: true,
    },
  });

  const mainBranch = await prisma.branch.upsert({
    where: {
      slug: "main-branch",
    },
    update: {
      schoolId: school.id,
      name: "Main Branch",
      isActive: true,
    },
    create: {
      schoolId: school.id,
      name: "Main Branch",
      slug: "main-branch",
      isActive: true,
    },
  });

  const cityBranch = await prisma.branch.upsert({
    where: {
      slug: "city-branch",
    },
    update: {
      schoolId: school.id,
      name: "City Branch",
      isActive: true,
    },
    create: {
      schoolId: school.id,
      name: "City Branch",
      slug: "city-branch",
      isActive: true,
    },
  });

  await prisma.academicSession.updateMany({
    data: {
      isCurrent: false,
    },
  });

  await prisma.academicSession.upsert({
    where: {
      branchId_name: { branchId: mainBranch.id, name: "2025 Session" },
    },
    update: {
      startsAt: new Date("2025-01-01T00:00:00.000Z"),
      endsAt: new Date("2025-12-31T00:00:00.000Z"),
      isActive: true,
      isCurrent: false,
    },
    create: {
      branchId: mainBranch.id,
      name: "2025 Session",
      startsAt: new Date("2025-01-01T00:00:00.000Z"),
      endsAt: new Date("2025-12-31T00:00:00.000Z"),
      isActive: true,
      isCurrent: false,
    },
  });

  const currentSession = await prisma.academicSession.upsert({
    where: {
      branchId_name: { branchId: mainBranch.id, name: "2026 Session" },
    },
    update: {
      startsAt: new Date("2026-01-01T00:00:00.000Z"),
      endsAt: new Date("2026-12-31T00:00:00.000Z"),
      isActive: true,
      isCurrent: true,
    },
    create: {
      branchId: mainBranch.id,
      name: "2026 Session",
      startsAt: new Date("2026-01-01T00:00:00.000Z"),
      endsAt: new Date("2026-12-31T00:00:00.000Z"),
      isActive: true,
      isCurrent: true,
    },
  });

  const superAdminUser = await ensureUser({
    name: "Super Admin",
    email: SUPER_ADMIN_EMAIL,
    role: Role.SUPER_ADMIN,
    branchId: mainBranch.id,
    passwordHash,
  });

  const adminUsers = await seedRoleUsers({
    namePrefix: "Admin",
    emailPrefix: "admin",
    count: BULK_CONFIG.admins,
    role: Role.ADMIN,
    branchId: mainBranch.id,
    passwordHash,
  });

  const accountantUsers = await seedRoleUsers({
    namePrefix: "Accountant",
    emailPrefix: "accountant",
    count: BULK_CONFIG.accountants,
    role: Role.ACCOUNTANT,
    branchId: cityBranch.id,
    passwordHash,
  });

  await seedRoleUsers({
    namePrefix: "Academic Admin",
    emailPrefix: "academicadmin",
    count: BULK_CONFIG.academicAdmins,
    role: Role.ACADEMIC_ADMIN,
    branchId: cityBranch.id,
    passwordHash,
  });

  await seedRoleUsers({
    namePrefix: "Admission Admin",
    emailPrefix: "admissionadmin",
    count: BULK_CONFIG.admissionAdmins,
    role: Role.ADMISSION_ADMIN,
    branchId: mainBranch.id,
    passwordHash,
  });

  await seedRoleUsers({
    namePrefix: "User",
    emailPrefix: "user",
    count: BULK_CONFIG.genericUsers,
    role: Role.USER,
    branchId: mainBranch.id,
    passwordHash,
  });

  const departments = await Promise.all(
    ["Science", "Commerce", "Humanities", "Arts", "Mathematics", "ICT"].map(
      (name) =>
        prisma.department.upsert({
          where: {
            branchId_name: { branchId: mainBranch.id, name },
          },
          update: {
            isActive: true,
          },
          create: {
            branchId: mainBranch.id,
            name,
            isActive: true,
          },
        }),
    ),
  );

  const designations = await Promise.all(
    [
      "Assistant Teacher",
      "Senior Teacher",
      "Head Teacher",
      "Department Head",
    ].map((name) =>
      prisma.designation.upsert({
        where: {
          branchId_name: { branchId: mainBranch.id, name },
        },
        update: {
          isActive: true,
        },
        create: {
          branchId: mainBranch.id,
          name,
          isActive: true,
        },
      }),
    ),
  );

  const teachers: SeedTeacher[] = [];
  const teacherUsers: BasicUser[] = [];

  for (let index = 1; index <= BULK_CONFIG.teachers; index += 1) {
    const branchId = index % 2 === 0 ? cityBranch.id : mainBranch.id;

    const teacherUser = await ensureUser({
      name: `Teacher ${index}`,
      email: `teacher${index}@gmail.com`,
      role: Role.TEACHER,
      branchId,
      passwordHash,
    });

    teacherUsers.push({
      id: teacherUser.id,
      name: teacherUser.name,
      email: teacherUser.email,
      role: teacherUser.role,
    });

    const phone = `01810${String(index).padStart(6, "0")}`;

    const teacher = await prisma.teacher.upsert({
      where: {
        userId: teacherUser.id,
      },
      update: {
        phone,
        address: `Teacher Area ${index}`,
        salary: 28000 + (index % 6) * 2200,
        departmentId: departments[index % departments.length].id,
        designationId: designations[index % designations.length].id,
        employeeCode: `EMP-${String(index).padStart(4, "0")}`,
        joiningDate: new Date("2024-01-01T00:00:00.000Z"),
        isDeleted: false,
      },
      create: {
        userId: teacherUser.id,
        phone,
        address: `Teacher Area ${index}`,
        salary: 28000 + (index % 6) * 2200,
        departmentId: departments[index % departments.length].id,
        designationId: designations[index % designations.length].id,
        employeeCode: `EMP-${String(index).padStart(4, "0")}`,
        joiningDate: new Date("2024-01-01T00:00:00.000Z"),
      },
    });

    teachers.push({
      id: teacher.id,
      userId: teacher.userId,
      salary: teacher.salary,
    });
  }

  const guardians: SeedGuardian[] = [];
  const guardianUsers: BasicUser[] = [];

  for (let index = 1; index <= BULK_CONFIG.guardians; index += 1) {
    const branchId = index % 2 === 0 ? mainBranch.id : cityBranch.id;

    const guardianUser = await ensureUser({
      name: `Guardian ${index}`,
      email: `guardian${index}@gmail.com`,
      role: Role.PARENT,
      branchId,
      passwordHash,
    });

    guardianUsers.push({
      id: guardianUser.id,
      name: guardianUser.name,
      email: guardianUser.email,
      role: guardianUser.role,
    });

    const phone = `01720${String(index).padStart(6, "0")}`;

    const guardian = await prisma.guardian.upsert({
      where: {
        userId: guardianUser.id,
      },
      update: {
        name: `Guardian ${index}`,
        email: guardianUser.email,
        phone,
        relation: "Parent",
        address: `Area ${index}`,
        isDeleted: false,
      },
      create: {
        userId: guardianUser.id,
        name: `Guardian ${index}`,
        email: guardianUser.email,
        phone,
        relation: "Parent",
        address: `Area ${index}`,
      },
    });

    guardians.push({
      id: guardian.id,
      userId: guardian.userId,
      phone: guardian.phone,
    });
  }

  const parents: SeedParent[] = [];
  const parentUsers: BasicUser[] = [];

  for (let index = 1; index <= BULK_CONFIG.parents; index += 1) {
    const branchId = index % 2 === 0 ? cityBranch.id : mainBranch.id;

    const parentUser = await ensureUser({
      name: `Parent ${index}`,
      email: `parent${index}@gmail.com`,
      role: Role.PARENT,
      branchId,
      passwordHash,
    });

    parentUsers.push({
      id: parentUser.id,
      name: parentUser.name,
      email: parentUser.email,
      role: parentUser.role,
    });

    const phone = `01930${String(index).padStart(6, "0")}`;

    const parent = await prisma.parent.upsert({
      where: {
        userId: parentUser.id,
      },
      update: {
        phone,
        address: `Parent Address ${index}`,
      },
      create: {
        userId: parentUser.id,
        phone,
        address: `Parent Address ${index}`,
      },
    });

    parents.push({
      id: parent.id,
      userId: parent.userId,
      phone: parent.phone,
    });
  }

  const classStructures: ClassGroupSection[] = [];
  const classFeeByClassId = new Map<string, number>();

  for (let classIndex = 0; classIndex < CLASS_NAMES.length; classIndex += 1) {
    const classRecord = await prisma.class.upsert({
      where: {
        branchId_name: { branchId: mainBranch.id, name: CLASS_NAMES[classIndex] },
      },
      update: {
        sortOrder: classIndex + 1,
      },
      create: {
        branchId: mainBranch.id,
        name: CLASS_NAMES[classIndex],
        sortOrder: classIndex + 1,
      },
    });

    const classMonthlyFee = 1200 + classIndex * 40;
    classFeeByClassId.set(classRecord.id, classMonthlyFee);

    await prisma.classMonthlyFee.upsert({
      where: {
        classId: classRecord.id,
      },
      update: {
        monthlyFee: classMonthlyFee,
        isActive: true,
      },
      create: {
        classId: classRecord.id,
        monthlyFee: classMonthlyFee,
        isActive: true,
      },
    });

    const groups: ClassGroupSection["groups"] = [];

    for (const groupName of GROUP_NAMES) {
      const group = await prisma.group.upsert({
        where: {
          classId_name: {
            classId: classRecord.id,
            name: groupName,
          },
        },
        update: {},
        create: {
          classId: classRecord.id,
          name: groupName,
        },
      });

      const sectionIds: string[] = [];

      for (const sectionName of SECTION_NAMES) {
        const section = await prisma.section.upsert({
          where: {
            groupId_name: {
              groupId: group.id,
              name: sectionName,
            },
          },
          update: {},
          create: {
            groupId: group.id,
            name: sectionName,
          },
        });

        sectionIds.push(section.id);
      }

      groups.push({
        groupId: group.id,
        sectionIds,
      });
    }

    classStructures.push({
      classId: classRecord.id,
      className: classRecord.name,
      classIndex,
      groups,
    });
  }

  const subjectAssignmentsByClass = new Map<string, SubjectAssignment[]>();
  let teacherCursor = 0;

  for (const classStructure of classStructures) {
    const assignments: SubjectAssignment[] = [];

    for (const subjectName of SUBJECT_NAMES) {
      const subject = await findOrCreateSubject(
        classStructure.classId,
        subjectName,
      );

      const teacher = teachers[teacherCursor % teachers.length];
      teacherCursor += 1;

      await prisma.teacherClassAssignment.upsert({
        where: {
          teacherId_classId: {
            teacherId: teacher.id,
            classId: classStructure.classId,
          },
        },
        update: {},
        create: {
          teacherId: teacher.id,
          classId: classStructure.classId,
        },
      });

      await prisma.teacherSubject.upsert({
        where: {
          teacherId_subjectId_classId: {
            teacherId: teacher.id,
            subjectId: subject.id,
            classId: classStructure.classId,
          },
        },
        update: {},
        create: {
          teacherId: teacher.id,
          subjectId: subject.id,
          classId: classStructure.classId,
        },
      });

      assignments.push({
        subjectId: subject.id,
        subjectName: subject.name,
        teacherId: teacher.id,
      });
    }

    subjectAssignmentsByClass.set(classStructure.classId, assignments);

    const timetableAssignment = assignments[0];
    if (timetableAssignment) {
      const startHour = 8 + classStructure.classIndex;
      const startTime = `${String(startHour).padStart(2, "0")}:00`;
      const endTime = `${String(startHour + 1).padStart(2, "0")}:00`;
      const day = WEEK_DAYS[classStructure.classIndex % WEEK_DAYS.length];

      await prisma.timetable.upsert({
        where: {
          classId_day_startTime: {
            classId: classStructure.classId,
            day,
            startTime,
          },
        },
        update: {
          subjectId: timetableAssignment.subjectId,
          teacherId: timetableAssignment.teacherId,
          endTime,
        },
        create: {
          classId: classStructure.classId,
          subjectId: timetableAssignment.subjectId,
          teacherId: timetableAssignment.teacherId,
          day,
          startTime,
          endTime,
        },
      });
    }
  }

  const seededStudents: SeedStudent[] = [];
  const studentsByClass = new Map<string, SeedStudent[]>();
  let studentCounter = 1;

  for (const classStructure of classStructures) {
    for (
      let studentIndex = 1;
      studentIndex <= BULK_CONFIG.studentsPerClass;
      studentIndex += 1
    ) {
      const branchId =
        classStructure.classIndex % 2 === 0 ? mainBranch.id : cityBranch.id;

      const studentUser = await ensureUser({
        name: `Student ${studentCounter}`,
        email: `student${studentCounter}@gmail.com`,
        role: Role.STUDENT,
        branchId,
        passwordHash,
      });

      const group =
        classStructure.groups[studentIndex % classStructure.groups.length];
      const sectionId =
        group.sectionIds[studentIndex % group.sectionIds.length];
      const guardian = guardians[(studentCounter - 1) % guardians.length];
      const parent = parents[(studentCounter - 1) % parents.length];

      const student = await prisma.student.upsert({
        where: {
          userId: studentUser.id,
        },
        update: {
          rollNumber: (classStructure.classIndex + 1) * 1000 + studentIndex,
          phone: `01630${String(studentCounter).padStart(6, "0")}`,
          gender: studentCounter % 2 === 0 ? Gender.FEMALE : Gender.MALE,
          classId: classStructure.classId,
          groupId: group.groupId,
          sectionId,
          guardianId: guardian.id,
          parentId: parent.id,
          sessionId: currentSession.id,
          fatherName: `Father ${studentCounter}`,
          fatherPhone: parent.phone,
          motherName: `Mother ${studentCounter}`,
          motherPhone: guardian.phone,
          isDeleted: false,
        },
        create: {
          userId: studentUser.id,
          rollNumber: (classStructure.classIndex + 1) * 1000 + studentIndex,
          phone: `01630${String(studentCounter).padStart(6, "0")}`,
          gender: studentCounter % 2 === 0 ? Gender.FEMALE : Gender.MALE,
          classId: classStructure.classId,
          groupId: group.groupId,
          sectionId,
          guardianId: guardian.id,
          parentId: parent.id,
          sessionId: currentSession.id,
          fatherName: `Father ${studentCounter}`,
          fatherPhone: parent.phone,
          motherName: `Mother ${studentCounter}`,
          motherPhone: guardian.phone,
        },
      });

      const seedStudent: SeedStudent = {
        id: student.id,
        classId: student.classId,
        groupId: student.groupId,
        sectionId: student.sectionId,
        guardianId: student.guardianId,
        parentId: student.parentId,
        serial: studentCounter,
      };

      seededStudents.push(seedStudent);

      const classBucket = studentsByClass.get(student.classId) ?? [];
      classBucket.push(seedStudent);
      studentsByClass.set(student.classId, classBucket);

      studentCounter += 1;
    }
  }

  const monthlyFeeCategory = await ensureFeeCategory("Monthly Fee", 1200);
  const examFeeCategory = await ensureFeeCategory("Exam Fee", 700);
  const admissionFeeCategory = await ensureFeeCategory("Admission Fee", 3000);
  const libraryFeeCategory = await ensureFeeCategory("Library Fee", 400);
  const sportsFeeCategory = await ensureFeeCategory("Sports Fee", 350);

  const allFeeCategories = [
    monthlyFeeCategory,
    examFeeCategory,
    admissionFeeCategory,
    libraryFeeCategory,
    sportsFeeCategory,
  ];

  for (const classStructure of classStructures) {
    for (const feeCategory of allFeeCategories) {
      await prisma.feeCategoryClass.upsert({
        where: {
          feeCategoryId_classId: {
            feeCategoryId: feeCategory.id,
            classId: classStructure.classId,
          },
        },
        update: {},
        create: {
          feeCategoryId: feeCategory.id,
          classId: classStructure.classId,
        },
      });
    }
  }

  const aprilDueDate = new Date("2026-04-30T00:00:00.000Z");

  for (const student of seededStudents) {
    const classMonthlyFee = classFeeByClassId.get(student.classId) ?? 1200;

    const monthlyState = student.serial % 3;
    const monthlyTotal = classMonthlyFee + monthlyFeeCategory.amount;
    const monthlyStatus =
      monthlyState === 0
        ? PaymentStatus.PAID
        : monthlyState === 1
          ? PaymentStatus.PARTIAL
          : PaymentStatus.DUE;
    const monthlyAmountPaid =
      monthlyStatus === PaymentStatus.PAID
        ? monthlyTotal
        : monthlyStatus === PaymentStatus.PARTIAL
          ? Math.floor(monthlyTotal * 0.6)
          : 0;

    await prisma.payment.upsert({
      where: {
        studentId_feeCategoryId_dedupeKey: {
          studentId: student.id,
          feeCategoryId: monthlyFeeCategory.id,
          dedupeKey: "seed-2026-04-monthly",
        },
      },
      update: {
        amountPaid: monthlyAmountPaid,
        status: monthlyStatus,
        monthlyFeeSnapshot: classMonthlyFee,
        feeAmountSnapshot: monthlyFeeCategory.amount,
        paymentMethod: monthlyAmountPaid > 0 ? "cash" : null,
        transactionId:
          monthlyAmountPaid > 0
            ? `SEED-M-${String(student.serial).padStart(4, "0")}`
            : null,
        month: 4,
        year: 2026,
        dueDate: aprilDueDate,
      },
      create: {
        studentId: student.id,
        feeCategoryId: monthlyFeeCategory.id,
        dedupeKey: "seed-2026-04-monthly",
        amountPaid: monthlyAmountPaid,
        status: monthlyStatus,
        monthlyFeeSnapshot: classMonthlyFee,
        feeAmountSnapshot: monthlyFeeCategory.amount,
        paymentMethod: monthlyAmountPaid > 0 ? "cash" : null,
        transactionId:
          monthlyAmountPaid > 0
            ? `SEED-M-${String(student.serial).padStart(4, "0")}`
            : null,
        month: 4,
        year: 2026,
        dueDate: aprilDueDate,
      },
    });

    const examStatus =
      student.serial % 2 === 0 ? PaymentStatus.PAID : PaymentStatus.DUE;
    const examAmountPaid =
      examStatus === PaymentStatus.PAID ? examFeeCategory.amount : 0;

    await prisma.payment.upsert({
      where: {
        studentId_feeCategoryId_dedupeKey: {
          studentId: student.id,
          feeCategoryId: examFeeCategory.id,
          dedupeKey: "seed-2026-04-exam",
        },
      },
      update: {
        amountPaid: examAmountPaid,
        status: examStatus,
        monthlyFeeSnapshot: null,
        feeAmountSnapshot: examFeeCategory.amount,
        paymentMethod: examAmountPaid > 0 ? "mobile_banking" : null,
        transactionId:
          examAmountPaid > 0
            ? `SEED-E-${String(student.serial).padStart(4, "0")}`
            : null,
        month: 4,
        year: 2026,
        dueDate: aprilDueDate,
      },
      create: {
        studentId: student.id,
        feeCategoryId: examFeeCategory.id,
        dedupeKey: "seed-2026-04-exam",
        amountPaid: examAmountPaid,
        status: examStatus,
        monthlyFeeSnapshot: null,
        feeAmountSnapshot: examFeeCategory.amount,
        paymentMethod: examAmountPaid > 0 ? "mobile_banking" : null,
        transactionId:
          examAmountPaid > 0
            ? `SEED-E-${String(student.serial).padStart(4, "0")}`
            : null,
        month: 4,
        year: 2026,
        dueDate: aprilDueDate,
      },
    });

    if (student.serial <= 120) {
      await prisma.payment.upsert({
        where: {
          studentId_feeCategoryId_dedupeKey: {
            studentId: student.id,
            feeCategoryId: admissionFeeCategory.id,
            dedupeKey: "seed-2026-admission",
          },
        },
        update: {
          amountPaid: admissionFeeCategory.amount,
          status: PaymentStatus.PAID,
          monthlyFeeSnapshot: null,
          feeAmountSnapshot: admissionFeeCategory.amount,
          paymentMethod: "bank_transfer",
          transactionId: `SEED-A-${String(student.serial).padStart(4, "0")}`,
          month: 1,
          year: 2026,
          dueDate: new Date("2026-01-31T00:00:00.000Z"),
        },
        create: {
          studentId: student.id,
          feeCategoryId: admissionFeeCategory.id,
          dedupeKey: "seed-2026-admission",
          amountPaid: admissionFeeCategory.amount,
          status: PaymentStatus.PAID,
          monthlyFeeSnapshot: null,
          feeAmountSnapshot: admissionFeeCategory.amount,
          paymentMethod: "bank_transfer",
          transactionId: `SEED-A-${String(student.serial).padStart(4, "0")}`,
          month: 1,
          year: 2026,
          dueDate: new Date("2026-01-31T00:00:00.000Z"),
        },
      });
    }
  }

  const tuitionIncomeCategory = await prisma.financeCategory.upsert({
    where: {
      branchId_type_name: {
        branchId: mainBranch.id,
        type: FinanceEntryType.INCOME,
        name: "Tuition Income",
      },
    },
    update: {
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      name: "Tuition Income",
      type: FinanceEntryType.INCOME,
      isActive: true,
    },
  });

  const admissionIncomeCategory = await prisma.financeCategory.upsert({
    where: {
      branchId_type_name: {
        branchId: mainBranch.id,
        type: FinanceEntryType.INCOME,
        name: "Admission Income",
      },
    },
    update: {
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      name: "Admission Income",
      type: FinanceEntryType.INCOME,
      isActive: true,
    },
  });

  const salaryExpenseCategory = await prisma.financeCategory.upsert({
    where: {
      branchId_type_name: {
        branchId: mainBranch.id,
        type: FinanceEntryType.EXPENSE,
        name: "Salary Expense",
      },
    },
    update: {
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      name: "Salary Expense",
      type: FinanceEntryType.EXPENSE,
      isActive: true,
    },
  });

  const officeExpenseCategory = await prisma.financeCategory.upsert({
    where: {
      branchId_type_name: {
        branchId: mainBranch.id,
        type: FinanceEntryType.EXPENSE,
        name: "Office Expense",
      },
    },
    update: {
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      name: "Office Expense",
      type: FinanceEntryType.EXPENSE,
      isActive: true,
    },
  });

  const financeActorId = accountantUsers[0]?.id ?? superAdminUser.id;

  for (const student of seededStudents.slice(0, 40)) {
    await ensureFinanceEntry({
      key: `tuition-${student.serial}`,
      type: FinanceEntryType.INCOME,
      categoryId: tuitionIncomeCategory.id,
      amount: 1500 + (student.serial % 5) * 100,
      occurredAt: new Date(
        Date.UTC(2026, 3, (student.serial % 20) + 1, 10, 0, 0),
      ),
      description: `Tuition collected for student ${student.serial}`,
      createdById: financeActorId,
      studentId: student.id,
    });
  }

  for (const student of seededStudents.slice(0, 20)) {
    await ensureFinanceEntry({
      key: `admission-${student.serial}`,
      type: FinanceEntryType.INCOME,
      categoryId: admissionIncomeCategory.id,
      amount: 3000,
      occurredAt: new Date(
        Date.UTC(2026, 0, (student.serial % 20) + 1, 9, 0, 0),
      ),
      description: `Admission payment for student ${student.serial}`,
      createdById: financeActorId,
      studentId: student.id,
    });
  }

  for (let index = 1; index <= 8; index += 1) {
    await ensureFinanceEntry({
      key: `office-expense-${index}`,
      type: FinanceEntryType.EXPENSE,
      categoryId: officeExpenseCategory.id,
      amount: 800 + index * 120,
      occurredAt: new Date(Date.UTC(2026, 3, index + 1, 14, 0, 0)),
      description: `Office expense voucher ${index}`,
      createdById: financeActorId,
    });
  }

  for (let index = 1; index <= 6; index += 1) {
    await ensureFinanceEntry({
      key: `salary-expense-${index}`,
      type: FinanceEntryType.EXPENSE,
      categoryId: salaryExpenseCategory.id,
      amount: 20000 + index * 750,
      occurredAt: new Date(Date.UTC(2026, 3, index + 3, 15, 0, 0)),
      description: `Salary payout batch ${index}`,
      createdById: financeActorId,
    });
  }

  const attendanceDates = [
    new Date("2026-04-20T00:00:00.000Z"),
    new Date("2026-04-21T00:00:00.000Z"),
    new Date("2026-04-22T00:00:00.000Z"),
  ];

  for (const classStructure of classStructures) {
    const primarySubject = subjectAssignmentsByClass.get(
      classStructure.classId,
    )?.[0];
    const classStudents = studentsByClass.get(classStructure.classId) ?? [];

    if (!primarySubject) {
      continue;
    }

    for (const student of classStudents.slice(0, 8)) {
      for (
        let dateIndex = 0;
        dateIndex < attendanceDates.length;
        dateIndex += 1
      ) {
        const mod = (student.serial + dateIndex) % 5;
        const status =
          mod === 0
            ? AttendanceStatus.ABSENT
            : mod === 1
              ? AttendanceStatus.LATE
              : AttendanceStatus.PRESENT;

        await prisma.attendance.upsert({
          where: {
            studentId_subjectId_date_period: {
              studentId: student.id,
              subjectId: primarySubject.subjectId,
              date: attendanceDates[dateIndex],
              period: 1,
            },
          },
          update: {
            classId: classStructure.classId,
            status,
            markedBy: superAdminUser.id,
            remarks: `${SEED_TAG} attendance`,
          },
          create: {
            studentId: student.id,
            classId: classStructure.classId,
            subjectId: primarySubject.subjectId,
            period: 1,
            date: attendanceDates[dateIndex],
            status,
            markedBy: superAdminUser.id,
            remarks: `${SEED_TAG} attendance`,
          },
        });
      }
    }
  }

  const teacherAttendanceDates = [
    new Date("2026-04-20T00:00:00.000Z"),
    new Date("2026-04-21T00:00:00.000Z"),
  ];

  for (let index = 0; index < Math.min(20, teachers.length); index += 1) {
    const teacher = teachers[index];

    for (
      let dateIndex = 0;
      dateIndex < teacherAttendanceDates.length;
      dateIndex += 1
    ) {
      const status =
        (index + dateIndex) % 6 === 0
          ? AttendanceStatus.LATE
          : AttendanceStatus.PRESENT;

      await prisma.teacherAttendance.upsert({
        where: {
          teacherId_date: {
            teacherId: teacher.id,
            date: teacherAttendanceDates[dateIndex],
          },
        },
        update: {
          status,
          remarks: `${SEED_TAG} teacher attendance`,
          markedById: superAdminUser.id,
        },
        create: {
          teacherId: teacher.id,
          date: teacherAttendanceDates[dateIndex],
          status,
          remarks: `${SEED_TAG} teacher attendance`,
          markedById: superAdminUser.id,
        },
      });
    }
  }

  for (let index = 0; index < Math.min(6, teachers.length); index += 1) {
    const teacher = teachers[index];
    const startDate = new Date(Date.UTC(2026, 3, 5 + index * 2, 0, 0, 0));
    const endDate = new Date(Date.UTC(2026, 3, 6 + index * 2, 0, 0, 0));
    const leaveStatus =
      index === 0
        ? LeaveStatus.APPROVED
        : index === 1
          ? LeaveStatus.REJECTED
          : LeaveStatus.PENDING;

    const existingLeave = await prisma.teacherLeaveRequest.findFirst({
      where: {
        teacherId: teacher.id,
        startDate,
        endDate,
      },
    });

    const leaveData: Prisma.TeacherLeaveRequestUpdateInput = {
      startDate,
      endDate,
      reason: `${SEED_TAG} leave request ${index + 1}`,
      status: leaveStatus,
      decidedBy:
        leaveStatus === LeaveStatus.PENDING
          ? {
              disconnect: true,
            }
          : {
              connect: {
                id: superAdminUser.id,
              },
            },
      decidedAt:
        leaveStatus === LeaveStatus.PENDING
          ? null
          : new Date(Date.UTC(2026, 3, 4 + index, 12, 0, 0)),
    };

    if (existingLeave) {
      await prisma.teacherLeaveRequest.update({
        where: {
          id: existingLeave.id,
        },
        data: leaveData,
      });
    } else {
      await prisma.teacherLeaveRequest.create({
        data: {
          teacherId: teacher.id,
          startDate,
          endDate,
          reason: `${SEED_TAG} leave request ${index + 1}`,
          status: leaveStatus,
          ...(leaveStatus === LeaveStatus.PENDING
            ? {}
            : {
                decidedById: superAdminUser.id,
                decidedAt: new Date(Date.UTC(2026, 3, 4 + index, 12, 0, 0)),
              }),
        },
      });
    }
  }

  const payrollCreatorId = accountantUsers[0]?.id ?? superAdminUser.id;

  const payrollRun = await prisma.payrollRun.upsert({
    where: {
      branchId_month_year: {
        branchId: mainBranch.id,
        month: 4,
        year: 2026,
      },
    },
    update: {
      status: PayrollRunStatus.LOCKED,
      createdById: payrollCreatorId,
    },
    create: {
      branchId: mainBranch.id,
      month: 4,
      year: 2026,
      status: PayrollRunStatus.LOCKED,
      createdById: payrollCreatorId,
    },
  });

  for (let index = 0; index < Math.min(20, teachers.length); index += 1) {
    const teacher = teachers[index];
    const baseSalary = teacher.salary ?? 25000;
    const allowances = (index % 4) * 500;
    const deductions = (index % 3) * 300;
    const netPay = Math.max(baseSalary + allowances - deductions, 0);
    const payrollStatus =
      index < 6 ? PayrollItemStatus.PAID : PayrollItemStatus.UNPAID;

    await prisma.payrollItem.upsert({
      where: {
        payrollRunId_teacherId: {
          payrollRunId: payrollRun.id,
          teacherId: teacher.id,
        },
      },
      update: {
        baseSalarySnapshot: baseSalary,
        allowances,
        deductions,
        netPay,
        presentDays: 22 - (index % 3),
        absentDays: index % 3,
        status: payrollStatus,
        paidAt:
          payrollStatus === PayrollItemStatus.PAID
            ? new Date(Date.UTC(2026, 3, 30, 12, 0, 0))
            : null,
      },
      create: {
        payrollRunId: payrollRun.id,
        teacherId: teacher.id,
        baseSalarySnapshot: baseSalary,
        allowances,
        deductions,
        netPay,
        presentDays: 22 - (index % 3),
        absentDays: index % 3,
        status: payrollStatus,
        paidAt:
          payrollStatus === PayrollItemStatus.PAID
            ? new Date(Date.UTC(2026, 3, 30, 12, 0, 0))
            : null,
      },
    });
  }

  const seededExamIds: string[] = [];

  for (const classStructure of classStructures) {
    const examCode = `SEED-EXAM-${String(classStructure.classIndex + 1).padStart(2, "0")}-2026`;
    const examDate = new Date(
      Date.UTC(2026, 3, 10 + classStructure.classIndex, 8, 0, 0),
    );

    const exam = await prisma.exam.upsert({
      where: {
        branchId_code: { branchId: mainBranch.id, code: examCode },
      },
      update: {
        name: `Monthly Exam ${classStructure.classIndex + 1}`,
        date: examDate,
        description: `${SEED_TAG} generated exam`,
        academicYear: "2026",
        status: ExamLifecycleStatus.PUBLISHED,
        visibleToStudents: true,
        visibleToParents: true,
        visibleToTeachers: true,
        generateResult: true,
        lockAfterPublish: true,
        resultPublishAt: new Date(Date.UTC(2026, 3, 25, 9, 0, 0)),
        classId: classStructure.classId,
        examType: ExamTypeCategory.MONTHLY_EXAM,
      },
      create: {
        branchId: mainBranch.id,
        name: `Monthly Exam ${classStructure.classIndex + 1}`,
        code: examCode,
        date: examDate,
        description: `${SEED_TAG} generated exam`,
        academicYear: "2026",
        status: ExamLifecycleStatus.PUBLISHED,
        visibleToStudents: true,
        visibleToParents: true,
        visibleToTeachers: true,
        generateResult: true,
        lockAfterPublish: true,
        resultPublishAt: new Date(Date.UTC(2026, 3, 25, 9, 0, 0)),
        classId: classStructure.classId,
        examType: ExamTypeCategory.MONTHLY_EXAM,
      },
    });

    seededExamIds.push(exam.id);

    await prisma.examClassAssignment.upsert({
      where: {
        examId_classId: {
          examId: exam.id,
          classId: classStructure.classId,
        },
      },
      update: {},
      create: {
        examId: exam.id,
        classId: classStructure.classId,
      },
    });

    const classAssignments =
      subjectAssignmentsByClass.get(classStructure.classId)?.slice(0, 3) ?? [];

    const examSubjectRecords: Array<{ subjectId: string }> = [];

    for (
      let subjectIndex = 0;
      subjectIndex < classAssignments.length;
      subjectIndex += 1
    ) {
      const assignment = classAssignments[subjectIndex];

      const examSubject = await prisma.examSubject.upsert({
        where: {
          examId_classId_subjectId: {
            examId: exam.id,
            classId: classStructure.classId,
            subjectId: assignment.subjectId,
          },
        },
        update: {
          displayOrder: subjectIndex + 1,
          isMandatory: true,
          fullMarks: 100,
          passMarks: 33,
        },
        create: {
          examId: exam.id,
          classId: classStructure.classId,
          subjectId: assignment.subjectId,
          displayOrder: subjectIndex + 1,
          isMandatory: true,
          fullMarks: 100,
          passMarks: 33,
        },
      });

      examSubjectRecords.push({
        subjectId: assignment.subjectId,
      });

      await prisma.examComponent.upsert({
        where: {
          examSubjectId_name: {
            examSubjectId: examSubject.id,
            name: "Written",
          },
        },
        update: {
          displayOrder: 1,
          fullMarks: 70,
          isMandatory: true,
        },
        create: {
          examSubjectId: examSubject.id,
          name: "Written",
          displayOrder: 1,
          fullMarks: 70,
          isMandatory: true,
        },
      });

      await prisma.examComponent.upsert({
        where: {
          examSubjectId_name: {
            examSubjectId: examSubject.id,
            name: "MCQ",
          },
        },
        update: {
          displayOrder: 2,
          fullMarks: 30,
          isMandatory: true,
        },
        create: {
          examSubjectId: examSubject.id,
          name: "MCQ",
          displayOrder: 2,
          fullMarks: 30,
          isMandatory: true,
        },
      });

      await prisma.examTeacherAssignment.upsert({
        where: {
          examId_teacherId_classId_subjectId: {
            examId: exam.id,
            teacherId: assignment.teacherId,
            classId: classStructure.classId,
            subjectId: assignment.subjectId,
          },
        },
        update: {
          canEdit: true,
        },
        create: {
          examId: exam.id,
          teacherId: assignment.teacherId,
          classId: classStructure.classId,
          subjectId: assignment.subjectId,
          canEdit: true,
        },
      });
    }

    const existingHistory = await prisma.examHistory.findFirst({
      where: {
        examId: exam.id,
        action: "seed.exam.initialized",
      },
    });

    if (!existingHistory) {
      await prisma.examHistory.create({
        data: {
          examId: exam.id,
          actorId: superAdminUser.id,
          action: "seed.exam.initialized",
          snapshot: {
            code: exam.code,
            classId: classStructure.classId,
            className: classStructure.className,
            academicYear: exam.academicYear,
          },
          metadata: {
            seedTag: SEED_TAG,
          },
        },
      });
    }

    const classStudents = (
      studentsByClass.get(classStructure.classId) ?? []
    ).slice(0, 8);

    for (const student of classStudents) {
      for (
        let subjectIndex = 0;
        subjectIndex < examSubjectRecords.length;
        subjectIndex += 1
      ) {
        const examSubject = examSubjectRecords[subjectIndex];
        const marks = 40 + ((student.serial + subjectIndex * 9) % 61);

        await prisma.result.upsert({
          where: {
            studentId_examId_subjectId: {
              studentId: student.id,
              examId: exam.id,
              subjectId: examSubject.subjectId,
            },
          },
          update: {
            marks,
            grade: gradeFromMarks(marks),
          },
          create: {
            studentId: student.id,
            examId: exam.id,
            subjectId: examSubject.subjectId,
            marks,
            grade: gradeFromMarks(marks),
          },
        });
      }
    }
  }

  const firstClassId = classStructures[0]?.classId;

  await ensureNotice({
    title: "Seed: Welcome Notice",
    content: "Welcome to School ERP demo dataset.",
    audience: NoticeAudience.ALL,
    status: NoticeStatus.PUBLISHED,
    isActive: true,
    startsAt: new Date("2026-04-01T00:00:00.000Z"),
    endsAt: new Date("2026-12-31T00:00:00.000Z"),
    publishedAt: new Date("2026-04-01T09:00:00.000Z"),
  });

  await ensureNotice({
    title: "Seed: Student Exam Update",
    content: "Monthly exam schedule has been published.",
    audience: NoticeAudience.STUDENTS,
    classId: firstClassId,
    status: NoticeStatus.PUBLISHED,
    isActive: true,
    startsAt: new Date("2026-04-05T00:00:00.000Z"),
    endsAt: new Date("2026-06-30T00:00:00.000Z"),
    publishedAt: new Date("2026-04-05T09:00:00.000Z"),
  });

  await ensureNotice({
    title: "Seed: Teacher Meeting",
    content: "All teachers must attend the monthly review meeting.",
    audience: NoticeAudience.TEACHERS,
    status: NoticeStatus.PUBLISHED,
    isActive: true,
    startsAt: new Date("2026-04-07T00:00:00.000Z"),
    endsAt: new Date("2026-05-07T00:00:00.000Z"),
    publishedAt: new Date("2026-04-07T09:00:00.000Z"),
  });

  await ensureNotice({
    title: "Seed: Admin Circular",
    content: "Fee reconciliation must be completed by month end.",
    audience: NoticeAudience.ADMINS,
    status: NoticeStatus.PUBLISHED,
    isActive: true,
    startsAt: new Date("2026-04-08T00:00:00.000Z"),
    endsAt: new Date("2026-05-08T00:00:00.000Z"),
    publishedAt: new Date("2026-04-08T09:00:00.000Z"),
  });

  for (let index = 1; index <= 12; index += 1) {
    const status =
      index % 3 === 0
        ? AdmissionStatus.ACCEPTED
        : index % 3 === 1
          ? AdmissionStatus.PENDING
          : AdmissionStatus.REJECTED;

    const convertedToStudentId =
      status === AdmissionStatus.ACCEPTED
        ? (seededStudents[(index * 3) % seededStudents.length]?.id ?? null)
        : null;

    await ensureAdmissionApplication({
      name: `Admission Applicant ${index}`,
      email: `admission${index}@gmail.com`,
      phone: `01550${String(index).padStart(6, "0")}`,
      className: CLASS_NAMES[(index - 1) % CLASS_NAMES.length],
      message: `${SEED_TAG} generated admission request ${index}`,
      status,
      convertedToStudentId,
      details: {
        source: SEED_TAG,
        applicantNumber: index,
      },
    });
  }

  const resetUsers: BasicUser[] = [
    {
      id: superAdminUser.id,
      name: superAdminUser.name,
      email: superAdminUser.email,
      role: superAdminUser.role,
    },
    ...(adminUsers[0] ? [adminUsers[0]] : []),
    ...(teacherUsers[0] ? [teacherUsers[0]] : []),
    ...(guardianUsers[0] ? [guardianUsers[0]] : []),
    ...(parentUsers[0] ? [parentUsers[0]] : []),
  ];

  for (let index = 0; index < resetUsers.length; index += 1) {
    const user = resetUsers[index];
    const token = `seed-reset-${index + 1}-${user.id.slice(0, 8)}`;

    await prisma.passwordResetToken.upsert({
      where: {
        token,
      },
      update: {
        userId: user.id,
        expiresAt: new Date("2026-12-31T23:59:59.000Z"),
        used: false,
      },
      create: {
        token,
        userId: user.id,
        expiresAt: new Date("2026-12-31T23:59:59.000Z"),
        used: false,
      },
    });
  }

  await prisma.systemSetting.upsert({
    where: {
      branchId_key: { branchId: mainBranch.id, key: "notice_template" },
    },
    update: {
      value: {
        header: "School ERP Official Notice",
        footer: "Generated from seeded template.",
        signature: "Principal Office",
      },
      updatedById: superAdminUser.id,
    },
    create: {
      branchId: mainBranch.id,
      key: "notice_template",
      value: {
        header: "School ERP Official Notice",
        footer: "Generated from seeded template.",
        signature: "Principal Office",
      },
      updatedById: superAdminUser.id,
    },
  });

  await prisma.systemSetting.upsert({
    where: {
      branchId_key: { branchId: mainBranch.id, key: "student_document_template" },
    },
    update: {
      value: {
        title: "Student Document",
        primaryColor: "#0f172a",
        accentColor: "#1d4ed8",
        bodyFont: "Helvetica",
        footerNote: "This is a seeded system template.",
      },
      updatedById: superAdminUser.id,
    },
    create: {
      branchId: mainBranch.id,
      key: "student_document_template",
      value: {
        title: "Student Document",
        primaryColor: "#0f172a",
        accentColor: "#1d4ed8",
        bodyFont: "Helvetica",
        footerNote: "This is a seeded system template.",
      },
      updatedById: superAdminUser.id,
    },
  });

  await prisma.systemSetting.upsert({
    where: {
      branchId_key: { branchId: mainBranch.id, key: "platform_meta" },
    },
    update: {
      value: {
        seedTag: SEED_TAG,
        seededAt: new Date().toISOString(),
        activeSession: currentSession.name,
      },
      updatedById: superAdminUser.id,
    },
    create: {
      branchId: mainBranch.id,
      key: "platform_meta",
      value: {
        seedTag: SEED_TAG,
        seededAt: new Date().toISOString(),
        activeSession: currentSession.name,
      },
      updatedById: superAdminUser.id,
    },
  });

  const guardianNoticeTemplate = await prisma.notificationTemplate.upsert({
    where: {
      branchId_key: { branchId: mainBranch.id, key: "guardian_notice_email" },
    },
    update: {
      channel: NotificationChannel.EMAIL,
      subject: "School Notice Update",
      body: "Dear {{name}}, there is a new notice for your children.",
      description: "Seeded guardian notice template",
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      key: "guardian_notice_email",
      channel: NotificationChannel.EMAIL,
      subject: "School Notice Update",
      body: "Dear {{name}}, there is a new notice for your children.",
      description: "Seeded guardian notice template",
      isActive: true,
    },
  });

  const paymentReceiptTemplate = await prisma.notificationTemplate.upsert({
    where: {
      branchId_key: { branchId: mainBranch.id, key: "payment_receipt_email" },
    },
    update: {
      channel: NotificationChannel.EMAIL,
      subject: "Payment Receipt",
      body: "Dear {{name}}, your fee payment has been recorded.",
      description: "Seeded payment receipt template",
      isActive: true,
    },
    create: {
      branchId: mainBranch.id,
      key: "payment_receipt_email",
      channel: NotificationChannel.EMAIL,
      subject: "Payment Receipt",
      body: "Dear {{name}}, your fee payment has been recorded.",
      description: "Seeded payment receipt template",
      isActive: true,
    },
  });

  for (let index = 0; index < Math.min(6, guardianUsers.length); index += 1) {
    const guardianUser = guardianUsers[index];
    const status =
      index < 2 ? NotificationStatus.SENT : NotificationStatus.PENDING;

    await ensureNotificationQueue({
      templateId: guardianNoticeTemplate.id,
      channel: NotificationChannel.EMAIL,
      status,
      recipientName: guardianUser.name,
      recipientEmail: guardianUser.email,
      subject: `Notice Update ${index + 1}`,
      body: `Hello ${guardianUser.name}, this is seeded notice queue ${index + 1}.`,
      metadata: {
        seedTag: SEED_TAG,
        queueType: "guardian-notice",
      },
      sentAt:
        status === NotificationStatus.SENT
          ? new Date("2026-04-10T10:00:00.000Z")
          : null,
    });
  }

  for (let index = 0; index < Math.min(4, parentUsers.length); index += 1) {
    const parentUser = parentUsers[index];

    await ensureNotificationQueue({
      templateId: paymentReceiptTemplate.id,
      channel: NotificationChannel.EMAIL,
      status: NotificationStatus.PROCESSING,
      recipientName: parentUser.name,
      recipientEmail: parentUser.email,
      subject: `Payment Receipt Queue ${index + 1}`,
      body: `Hello ${parentUser.name}, your seeded payment receipt is being prepared.`,
      metadata: {
        seedTag: SEED_TAG,
        queueType: "payment-receipt",
      },
    });
  }

  await ensureAuditLog({
    action: "seed.run.completed",
    entityType: "Seed",
    entityId: SEED_TAG,
    actorId: superAdminUser.id,
    metadata: {
      admins: BULK_CONFIG.admins,
      teachers: BULK_CONFIG.teachers,
      guardians: BULK_CONFIG.guardians,
      students: BULK_CONFIG.studentsPerClass * CLASS_NAMES.length,
      classes: CLASS_NAMES.length,
      exams: seededExamIds.length,
    },
  });

  await ensureAuditLog({
    action: "admin.payroll_run.generated",
    entityType: "PayrollRun",
    entityId: payrollRun.id,
    actorId: payrollCreatorId,
    metadata: {
      month: payrollRun.month,
      year: payrollRun.year,
      seedTag: SEED_TAG,
    },
  });

  if (seededExamIds[0]) {
    await ensureAuditLog({
      action: "admin.exam.seeded",
      entityType: "Exam",
      entityId: seededExamIds[0],
      actorId: superAdminUser.id,
      metadata: {
        seedTag: SEED_TAG,
      },
    });
  }

  const [
    userCount,
    teacherCount,
    guardianCount,
    parentCount,
    studentCount,
    attendanceCount,
    examCount,
    resultCount,
    paymentCount,
    financeEntryCount,
    noticeCount,
    payrollRunCount,
    queueCount,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.teacher.count(),
    prisma.guardian.count(),
    prisma.parent.count(),
    prisma.student.count(),
    prisma.attendance.count(),
    prisma.exam.count(),
    prisma.result.count(),
    prisma.payment.count(),
    prisma.financeEntry.count(),
    prisma.notice.count(),
    prisma.payrollRun.count(),
    prisma.notificationQueue.count(),
  ]);

  console.log("Seed completed successfully");
  console.log(`Super admin: ${SUPER_ADMIN_EMAIL} / ${DEFAULT_PASSWORD}`);
  console.log(`Seed tag: ${SEED_TAG}`);
  console.log(`Users: ${userCount}`);
  console.log(`Teachers: ${teacherCount}`);
  console.log(`Guardians: ${guardianCount}`);
  console.log(`Parents: ${parentCount}`);
  console.log(`Students: ${studentCount}`);
  console.log(`Attendance records: ${attendanceCount}`);
  console.log(`Exams: ${examCount}`);
  console.log(`Results: ${resultCount}`);
  console.log(`Payments: ${paymentCount}`);
  console.log(`Finance entries: ${financeEntryCount}`);
  console.log(`Notices: ${noticeCount}`);
  console.log(`Payroll runs: ${payrollRunCount}`);
  console.log(`Notification queue items: ${queueCount}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
