-- CreateTable
CREATE TABLE "ClassMonthlyFee" (
    "id" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "monthlyFee" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ClassMonthlyFee_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ClassMonthlyFee_classId_key" ON "ClassMonthlyFee"("classId");

-- AddForeignKey
ALTER TABLE "ClassMonthlyFee" ADD CONSTRAINT "ClassMonthlyFee_classId_fkey" FOREIGN KEY ("classId") REFERENCES "Class"("id") ON DELETE CASCADE ON UPDATE CASCADE;
