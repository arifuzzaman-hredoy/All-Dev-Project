-- Add optional details JSON to store admission-like fields for students.
ALTER TABLE "Student" ADD COLUMN "details" JSONB;

