-- AlterTable
ALTER TABLE "ClassMonthlyFee" ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true;
