-- Add capacity controls and waiting-list placement without changing existing assignments.
CREATE TYPE "StudentPlacementStatus" AS ENUM ('ACTIVE', 'WAITING_LIST');

ALTER TABLE "Class" ADD COLUMN "studentLimit" INTEGER;
ALTER TABLE "Group" ADD COLUMN "studentLimit" INTEGER;
ALTER TABLE "Student" ADD COLUMN "placementStatus" "StudentPlacementStatus" NOT NULL DEFAULT 'ACTIVE';

CREATE INDEX "Student_placementStatus_idx" ON "Student"("placementStatus");
