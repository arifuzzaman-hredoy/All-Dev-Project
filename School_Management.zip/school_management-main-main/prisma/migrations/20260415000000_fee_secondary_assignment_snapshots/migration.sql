-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "monthlyFeeSnapshot" DOUBLE PRECISION,
ADD COLUMN     "feeAmountSnapshot" DOUBLE PRECISION,
ADD COLUMN     "dedupeKey" TEXT;

-- AlterTable
ALTER TABLE "FeeCategory" ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true;

-- CreateTable
CREATE TABLE "FeeCategoryClass" (
    "id" TEXT NOT NULL,
    "feeCategoryId" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FeeCategoryClass_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "FeeCategoryClass_feeCategoryId_classId_key" ON "FeeCategoryClass"("feeCategoryId", "classId");

-- CreateIndex
CREATE INDEX "FeeCategoryClass_classId_idx" ON "FeeCategoryClass"("classId");

-- CreateIndex
CREATE UNIQUE INDEX "Payment_studentId_feeCategoryId_dedupeKey_key" ON "Payment"("studentId", "feeCategoryId", "dedupeKey");

-- AddForeignKey
ALTER TABLE "FeeCategoryClass" ADD CONSTRAINT "FeeCategoryClass_feeCategoryId_fkey" FOREIGN KEY ("feeCategoryId") REFERENCES "FeeCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FeeCategoryClass" ADD CONSTRAINT "FeeCategoryClass_classId_fkey" FOREIGN KEY ("classId") REFERENCES "Class"("id") ON DELETE CASCADE ON UPDATE CASCADE;
