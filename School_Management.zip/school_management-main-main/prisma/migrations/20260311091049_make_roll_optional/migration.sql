-- AlterTable
ALTER TABLE "Student" ALTER COLUMN "rollNumber" DROP NOT NULL;
