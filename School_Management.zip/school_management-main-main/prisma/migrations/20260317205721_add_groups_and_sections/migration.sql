/*
  Warnings:

  - You are about to drop the column `section` on the `Class` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[studentId,subjectId,date,period]` on the table `Attendance` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[name]` on the table `Class` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId,subjectId,classId]` on the table `TeacherSubject` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId,day,startTime]` on the table `Timetable` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[classId,day,startTime]` on the table `Timetable` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "Attendance_studentId_subjectId_date_key";

-- DropIndex
DROP INDEX "Class_name_section_key";

-- AlterTable
ALTER TABLE "AdmissionApplication" ADD COLUMN     "convertedToStudentId" TEXT;

-- AlterTable
ALTER TABLE "Class" DROP COLUMN "section";

-- AlterTable
ALTER TABLE "Notice" ADD COLUMN     "classId" TEXT;

-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "paymentMethod" TEXT,
ADD COLUMN     "transactionId" TEXT;

-- AlterTable
ALTER TABLE "Student" ADD COLUMN     "groupId" TEXT,
ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "sectionId" TEXT;

-- AlterTable
ALTER TABLE "Teacher" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "TeacherSubject" ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "Group" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Group_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Section" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "groupId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Section_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Group_classId_idx" ON "Group"("classId");

-- CreateIndex
CREATE UNIQUE INDEX "Group_classId_name_key" ON "Group"("classId", "name");

-- CreateIndex
CREATE INDEX "Section_groupId_idx" ON "Section"("groupId");

-- CreateIndex
CREATE UNIQUE INDEX "Section_groupId_name_key" ON "Section"("groupId", "name");

-- CreateIndex
CREATE INDEX "Attendance_classId_idx" ON "Attendance"("classId");

-- CreateIndex
CREATE INDEX "Attendance_studentId_date_idx" ON "Attendance"("studentId", "date");

-- CreateIndex
CREATE UNIQUE INDEX "Attendance_studentId_subjectId_date_period_key" ON "Attendance"("studentId", "subjectId", "date", "period");

-- CreateIndex
CREATE UNIQUE INDEX "Class_name_key" ON "Class"("name");

-- CreateIndex
CREATE INDEX "Payment_transactionId_idx" ON "Payment"("transactionId");

-- CreateIndex
CREATE UNIQUE INDEX "TeacherSubject_teacherId_subjectId_classId_key" ON "TeacherSubject"("teacherId", "subjectId", "classId");

-- CreateIndex
CREATE UNIQUE INDEX "Timetable_teacherId_day_startTime_key" ON "Timetable"("teacherId", "day", "startTime");

-- CreateIndex
CREATE UNIQUE INDEX "Timetable_classId_day_startTime_key" ON "Timetable"("classId", "day", "startTime");

-- AddForeignKey
ALTER TABLE "Group" ADD CONSTRAINT "Group_classId_fkey" FOREIGN KEY ("classId") REFERENCES "Class"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Section" ADD CONSTRAINT "Section_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Student" ADD CONSTRAINT "Student_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Student" ADD CONSTRAINT "Student_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "Section"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notice" ADD CONSTRAINT "Notice_classId_fkey" FOREIGN KEY ("classId") REFERENCES "Class"("id") ON DELETE SET NULL ON UPDATE CASCADE;
