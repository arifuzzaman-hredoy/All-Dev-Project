-- Add branch scope to operational data. Existing data is backfilled to a
-- default branch so branch-scoped admins do not see an empty system after
-- migration.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM "School") THEN
    INSERT INTO "School" ("id", "name", "slug", "isActive", "createdAt", "updatedAt")
    VALUES ('default_school', 'Default School', 'default-school', true, NOW(), NOW());
  END IF;

  IF NOT EXISTS (SELECT 1 FROM "Branch") THEN
    INSERT INTO "Branch" ("id", "schoolId", "name", "slug", "isActive", "createdAt", "updatedAt")
    VALUES (
      'default_branch',
      (SELECT "id" FROM "School" ORDER BY "createdAt" ASC LIMIT 1),
      'Main Branch',
      'main-branch',
      true,
      NOW(),
      NOW()
    );
  END IF;
END $$;

ALTER TABLE "AcademicSession" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Department" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Designation" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "TeacherLeaveRequest" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "TeacherAttendance" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "PayrollRun" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "PayrollItem" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Parent" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Guardian" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Class" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Group" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Section" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Student" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "TeacherClassAssignment" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Subject" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "TeacherSubject" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Attendance" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Exam" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ExamClassAssignment" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ExamSubject" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ExamComponent" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ExamTeacherAssignment" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ExamHistory" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Result" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "ClassMonthlyFee" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "FeeCategory" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "FeeCategoryClass" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Timetable" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Notice" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "AdmissionApplication" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "SystemSetting" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "FinanceCategory" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "FinanceEntry" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "NotificationTemplate" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "NotificationQueue" ADD COLUMN IF NOT EXISTS "branchId" TEXT;

WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "User" SET "branchId" = (SELECT "id" FROM default_branch)
WHERE "branchId" IS NULL AND "role" <> 'SUPER_ADMIN';

WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "AcademicSession" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "Department" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "Designation" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "Class" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "FeeCategory" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "FinanceCategory" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "SystemSetting" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "AdmissionApplication" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "NotificationTemplate" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "NotificationQueue" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;

UPDATE "Student" s SET "branchId" = u."branchId" FROM "User" u WHERE s."userId" = u."id" AND s."branchId" IS NULL;
UPDATE "Parent" p SET "branchId" = u."branchId" FROM "User" u WHERE p."userId" = u."id" AND p."branchId" IS NULL;
UPDATE "Guardian" g SET "branchId" = u."branchId" FROM "User" u WHERE g."userId" = u."id" AND g."branchId" IS NULL;
UPDATE "Group" g SET "branchId" = c."branchId" FROM "Class" c WHERE g."classId" = c."id" AND g."branchId" IS NULL;
UPDATE "Section" s SET "branchId" = g."branchId" FROM "Group" g WHERE s."groupId" = g."id" AND s."branchId" IS NULL;
UPDATE "Subject" s SET "branchId" = c."branchId" FROM "Class" c WHERE s."classId" = c."id" AND s."branchId" IS NULL;
UPDATE "ClassMonthlyFee" f SET "branchId" = c."branchId" FROM "Class" c WHERE f."classId" = c."id" AND f."branchId" IS NULL;
UPDATE "TeacherClassAssignment" a SET "branchId" = c."branchId" FROM "Class" c WHERE a."classId" = c."id" AND a."branchId" IS NULL;
UPDATE "TeacherSubject" ts SET "branchId" = c."branchId" FROM "Class" c WHERE ts."classId" = c."id" AND ts."branchId" IS NULL;
UPDATE "Attendance" a SET "branchId" = c."branchId" FROM "Class" c WHERE a."classId" = c."id" AND a."branchId" IS NULL;
UPDATE "Exam" e SET "branchId" = c."branchId" FROM "Class" c WHERE e."classId" = c."id" AND e."branchId" IS NULL;
UPDATE "ExamClassAssignment" a SET "branchId" = e."branchId" FROM "Exam" e WHERE a."examId" = e."id" AND a."branchId" IS NULL;
UPDATE "ExamSubject" es SET "branchId" = e."branchId" FROM "Exam" e WHERE es."examId" = e."id" AND es."branchId" IS NULL;
UPDATE "ExamComponent" ec SET "branchId" = es."branchId" FROM "ExamSubject" es WHERE ec."examSubjectId" = es."id" AND ec."branchId" IS NULL;
UPDATE "ExamTeacherAssignment" eta SET "branchId" = e."branchId" FROM "Exam" e WHERE eta."examId" = e."id" AND eta."branchId" IS NULL;
UPDATE "ExamHistory" h SET "branchId" = e."branchId" FROM "Exam" e WHERE h."examId" = e."id" AND h."branchId" IS NULL;
UPDATE "Result" r SET "branchId" = s."branchId" FROM "Student" s WHERE r."studentId" = s."id" AND r."branchId" IS NULL;
UPDATE "FeeCategoryClass" fc SET "branchId" = c."branchId" FROM "Class" c WHERE fc."classId" = c."id" AND fc."branchId" IS NULL;
UPDATE "Payment" p SET "branchId" = s."branchId" FROM "Student" s WHERE p."studentId" = s."id" AND p."branchId" IS NULL;
UPDATE "Timetable" t SET "branchId" = c."branchId" FROM "Class" c WHERE t."classId" = c."id" AND t."branchId" IS NULL;
UPDATE "Notice" n SET "branchId" = c."branchId" FROM "Class" c WHERE n."classId" = c."id" AND n."branchId" IS NULL;
UPDATE "FinanceEntry" fe SET "branchId" = fc."branchId" FROM "FinanceCategory" fc WHERE fe."categoryId" = fc."id" AND fe."branchId" IS NULL;
UPDATE "AuditLog" a SET "branchId" = u."branchId" FROM "User" u WHERE a."actorId" = u."id" AND a."branchId" IS NULL;
UPDATE "TeacherLeaveRequest" tl SET "branchId" = u."branchId" FROM "Teacher" t JOIN "User" u ON u."id" = t."userId" WHERE tl."teacherId" = t."id" AND tl."branchId" IS NULL;
UPDATE "TeacherAttendance" ta SET "branchId" = u."branchId" FROM "Teacher" t JOIN "User" u ON u."id" = t."userId" WHERE ta."teacherId" = t."id" AND ta."branchId" IS NULL;
UPDATE "PayrollItem" pi SET "branchId" = u."branchId" FROM "Teacher" t JOIN "User" u ON u."id" = t."userId" WHERE pi."teacherId" = t."id" AND pi."branchId" IS NULL;
UPDATE "PayrollRun" pr SET "branchId" = pi."branchId" FROM "PayrollItem" pi WHERE pr."id" = pi."payrollRunId" AND pr."branchId" IS NULL;

WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "Guardian" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "Notice" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "FinanceEntry" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "AuditLog" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;
WITH default_branch AS (SELECT "id" FROM "Branch" ORDER BY "createdAt" ASC LIMIT 1)
UPDATE "PayrollRun" SET "branchId" = (SELECT "id" FROM default_branch) WHERE "branchId" IS NULL;

DROP INDEX IF EXISTS "AcademicSession_name_key";
DROP INDEX IF EXISTS "Department_name_key";
DROP INDEX IF EXISTS "Designation_name_key";
DROP INDEX IF EXISTS "PayrollRun_month_year_key";
DROP INDEX IF EXISTS "Class_name_key";
DROP INDEX IF EXISTS "Exam_code_key";
DROP INDEX IF EXISTS "Exam_name_classId_academicYear_key";
DROP INDEX IF EXISTS "SystemSetting_key_key";
DROP INDEX IF EXISTS "FinanceCategory_type_name_key";
DROP INDEX IF EXISTS "NotificationTemplate_key_key";

CREATE UNIQUE INDEX IF NOT EXISTS "AcademicSession_branchId_name_key" ON "AcademicSession"("branchId", "name");
CREATE UNIQUE INDEX IF NOT EXISTS "Department_branchId_name_key" ON "Department"("branchId", "name");
CREATE UNIQUE INDEX IF NOT EXISTS "Designation_branchId_name_key" ON "Designation"("branchId", "name");
CREATE UNIQUE INDEX IF NOT EXISTS "PayrollRun_branchId_month_year_key" ON "PayrollRun"("branchId", "month", "year");
CREATE UNIQUE INDEX IF NOT EXISTS "Class_branchId_name_key" ON "Class"("branchId", "name");
CREATE UNIQUE INDEX IF NOT EXISTS "Exam_branchId_code_key" ON "Exam"("branchId", "code");
CREATE UNIQUE INDEX IF NOT EXISTS "Exam_branchId_name_classId_academicYear_key" ON "Exam"("branchId", "name", "classId", "academicYear");
CREATE UNIQUE INDEX IF NOT EXISTS "SystemSetting_branchId_key_key" ON "SystemSetting"("branchId", "key");
CREATE UNIQUE INDEX IF NOT EXISTS "FinanceCategory_branchId_type_name_key" ON "FinanceCategory"("branchId", "type", "name");
CREATE UNIQUE INDEX IF NOT EXISTS "NotificationTemplate_branchId_key_key" ON "NotificationTemplate"("branchId", "key");

CREATE INDEX IF NOT EXISTS "AcademicSession_branchId_idx" ON "AcademicSession"("branchId");
CREATE INDEX IF NOT EXISTS "Department_branchId_idx" ON "Department"("branchId");
CREATE INDEX IF NOT EXISTS "Designation_branchId_idx" ON "Designation"("branchId");
CREATE INDEX IF NOT EXISTS "TeacherLeaveRequest_branchId_idx" ON "TeacherLeaveRequest"("branchId");
CREATE INDEX IF NOT EXISTS "TeacherAttendance_branchId_idx" ON "TeacherAttendance"("branchId");
CREATE INDEX IF NOT EXISTS "PayrollRun_branchId_idx" ON "PayrollRun"("branchId");
CREATE INDEX IF NOT EXISTS "PayrollItem_branchId_idx" ON "PayrollItem"("branchId");
CREATE INDEX IF NOT EXISTS "Parent_branchId_idx" ON "Parent"("branchId");
CREATE INDEX IF NOT EXISTS "Guardian_branchId_idx" ON "Guardian"("branchId");
CREATE INDEX IF NOT EXISTS "Class_branchId_idx" ON "Class"("branchId");
CREATE INDEX IF NOT EXISTS "Group_branchId_idx" ON "Group"("branchId");
CREATE INDEX IF NOT EXISTS "Section_branchId_idx" ON "Section"("branchId");
CREATE INDEX IF NOT EXISTS "Student_branchId_idx" ON "Student"("branchId");
CREATE INDEX IF NOT EXISTS "TeacherClassAssignment_branchId_idx" ON "TeacherClassAssignment"("branchId");
CREATE INDEX IF NOT EXISTS "Subject_branchId_idx" ON "Subject"("branchId");
CREATE INDEX IF NOT EXISTS "TeacherSubject_branchId_idx" ON "TeacherSubject"("branchId");
CREATE INDEX IF NOT EXISTS "Attendance_branchId_idx" ON "Attendance"("branchId");
CREATE INDEX IF NOT EXISTS "Exam_branchId_idx" ON "Exam"("branchId");
CREATE INDEX IF NOT EXISTS "ExamClassAssignment_branchId_idx" ON "ExamClassAssignment"("branchId");
CREATE INDEX IF NOT EXISTS "ExamSubject_branchId_idx" ON "ExamSubject"("branchId");
CREATE INDEX IF NOT EXISTS "ExamComponent_branchId_idx" ON "ExamComponent"("branchId");
CREATE INDEX IF NOT EXISTS "ExamTeacherAssignment_branchId_idx" ON "ExamTeacherAssignment"("branchId");
CREATE INDEX IF NOT EXISTS "ExamHistory_branchId_idx" ON "ExamHistory"("branchId");
CREATE INDEX IF NOT EXISTS "Result_branchId_idx" ON "Result"("branchId");
CREATE INDEX IF NOT EXISTS "ClassMonthlyFee_branchId_idx" ON "ClassMonthlyFee"("branchId");
CREATE INDEX IF NOT EXISTS "FeeCategory_branchId_idx" ON "FeeCategory"("branchId");
CREATE INDEX IF NOT EXISTS "FeeCategoryClass_branchId_idx" ON "FeeCategoryClass"("branchId");
CREATE INDEX IF NOT EXISTS "Payment_branchId_idx" ON "Payment"("branchId");
CREATE INDEX IF NOT EXISTS "Timetable_branchId_idx" ON "Timetable"("branchId");
CREATE INDEX IF NOT EXISTS "Notice_branchId_idx" ON "Notice"("branchId");
CREATE INDEX IF NOT EXISTS "AdmissionApplication_branchId_idx" ON "AdmissionApplication"("branchId");
CREATE INDEX IF NOT EXISTS "SystemSetting_branchId_idx" ON "SystemSetting"("branchId");
CREATE INDEX IF NOT EXISTS "FinanceCategory_branchId_idx" ON "FinanceCategory"("branchId");
CREATE INDEX IF NOT EXISTS "FinanceEntry_branchId_idx" ON "FinanceEntry"("branchId");
CREATE INDEX IF NOT EXISTS "AuditLog_branchId_idx" ON "AuditLog"("branchId");
CREATE INDEX IF NOT EXISTS "NotificationTemplate_branchId_idx" ON "NotificationTemplate"("branchId");
CREATE INDEX IF NOT EXISTS "NotificationQueue_branchId_idx" ON "NotificationQueue"("branchId");
