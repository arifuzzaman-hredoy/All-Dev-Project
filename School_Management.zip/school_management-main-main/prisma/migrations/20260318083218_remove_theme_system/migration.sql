/*
  Warnings:

  - You are about to drop the `ThemePalette` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `UserThemePreference` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "ThemePalette" DROP CONSTRAINT "ThemePalette_updatedBy_fkey";

-- DropForeignKey
ALTER TABLE "UserThemePreference" DROP CONSTRAINT "UserThemePreference_userId_fkey";

-- DropTable
DROP TABLE "ThemePalette";

-- DropTable
DROP TABLE "UserThemePreference";
