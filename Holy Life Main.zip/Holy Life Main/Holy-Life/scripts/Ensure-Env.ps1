$ErrorActionPreference = "Stop"
$projectDir = Split-Path -Parent $PSScriptRoot
Set-Location $projectDir

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
}

function New-HolyLifePassword {
    return "Hl9!" + [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(20)).ToLowerInvariant()
}

$content = Get-Content ".env" -Raw
$content = $content.Replace("replace-with-a-long-random-password", [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant())
$content = $content.Replace("replace-with-at-least-32-random-bytes", [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(48)).ToLowerInvariant())
$content = $content.Replace("replace-with-random-owner-password", (New-HolyLifePassword))
$content = $content.Replace("replace-with-random-member-password", (New-HolyLifePassword))

$required = [ordered]@{
    AUTH_REQUIRE_VERIFIED_CONTACT = "true"
    TRUST_PROXY = "false"
    AUTH_DELIVERY_MODE = "log"
    SESSION_DAYS = "14"
    MAX_ACTIVE_SESSIONS = "8"
    LOGIN_MAX_ATTEMPTS = "5"
    LOGIN_WINDOW_MINUTES = "15"
    LOGIN_LOCK_MINUTES = "15"
    VERIFICATION_TTL_MINUTES = "15"
    VERIFICATION_RESEND_SECONDS = "60"
    PASSWORD_RESET_TTL_MINUTES = "30"
    INITIAL_SUPER_ADMIN_NAME = "Holy Life Owner"
    INITIAL_SUPER_ADMIN_EMAIL = "owner@holylife.local"
    INITIAL_SUPER_ADMIN_PASSWORD = (New-HolyLifePassword)
    INITIAL_MEMBER_NAME = "Demo Member"
    INITIAL_MEMBER_EMAIL = "member@holylife.local"
    INITIAL_MEMBER_PHONE = "01700000000"
    INITIAL_MEMBER_PASSWORD = (New-HolyLifePassword)
}

foreach ($entry in $required.GetEnumerator()) {
    if ($content -notmatch "(?m)^$([Regex]::Escape($entry.Key))=") {
        $content = $content.TrimEnd() + "`r`n$($entry.Key)=$($entry.Value)`r`n"
    }
}
Set-Content ".env" $content -NoNewline
