#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker is required." >&2
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 22 is required for host development mode." >&2
  exit 1
fi
node_major="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$node_major" != "22" ]]; then
  echo "ERROR: Node.js 22 is required; detected $(node --version)." >&2
  exit 1
fi

chmod +x scripts/ensure-env.sh
./scripts/ensure-env.sh
npm install --no-audit --no-fund
docker compose up -d db
npm run db:generate
npm run db:deploy
npm run db:seed

echo
echo "Development environment is ready."
echo "Run: npm run dev"
echo "Open: http://localhost:3000"
echo "Credentials are stored in .env. Keep that file private."
