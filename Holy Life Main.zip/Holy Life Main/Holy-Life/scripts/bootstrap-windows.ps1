$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw "Docker is required." }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js 22 is required for host development mode." }
$nodeMajor = [int]((node -p 'process.versions.node.split(".")[0]').Trim())
if ($nodeMajor -ne 22) { throw "Node.js 22 is required; detected $(node --version)." }

& "$PSScriptRoot\Ensure-Env.ps1"
npm install --no-audit --no-fund
docker compose up -d db
npm run db:generate
npm run db:deploy
npm run db:seed

Write-Host ""
Write-Host "Development environment is ready."
Write-Host "Run: npm run dev"
Write-Host "Open: http://localhost:3000"
Write-Host "Credentials are stored in .env. Keep that file private."
