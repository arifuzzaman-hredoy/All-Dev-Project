#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

if [[ ! -f .env ]]; then
  cp .env.example .env
fi

python3 - <<'PY'
from pathlib import Path
import secrets

path = Path('.env')
content = path.read_text()
replacements = {
    'replace-with-a-long-random-password': secrets.token_urlsafe(32),
    'replace-with-at-least-32-random-bytes': secrets.token_urlsafe(48),
    'replace-with-random-owner-password': 'Hl9!' + secrets.token_urlsafe(20),
    'replace-with-random-member-password': 'Hl9!' + secrets.token_urlsafe(20),
}
for old, new in replacements.items():
    content = content.replace(old, new)

required = {
    'AUTH_REQUIRE_VERIFIED_CONTACT': 'true',
    'TRUST_PROXY': 'false',
    'AUTH_DELIVERY_MODE': 'log',
    'SESSION_DAYS': '14',
    'MAX_ACTIVE_SESSIONS': '8',
    'LOGIN_MAX_ATTEMPTS': '5',
    'LOGIN_WINDOW_MINUTES': '15',
    'LOGIN_LOCK_MINUTES': '15',
    'VERIFICATION_TTL_MINUTES': '15',
    'VERIFICATION_RESEND_SECONDS': '60',
    'PASSWORD_RESET_TTL_MINUTES': '30',
    'INITIAL_SUPER_ADMIN_NAME': 'Holy Life Owner',
    'INITIAL_SUPER_ADMIN_EMAIL': 'owner@holylife.local',
    'INITIAL_SUPER_ADMIN_PASSWORD': 'Hl9!' + secrets.token_urlsafe(20),
    'INITIAL_MEMBER_NAME': 'Demo Member',
    'INITIAL_MEMBER_EMAIL': 'member@holylife.local',
    'INITIAL_MEMBER_PHONE': '01700000000',
    'INITIAL_MEMBER_PASSWORD': 'Hl9!' + secrets.token_urlsafe(20),
}
existing = {line.split('=', 1)[0].strip() for line in content.splitlines() if '=' in line and not line.lstrip().startswith('#')}
missing = [f'{key}={value}' for key, value in required.items() if key not in existing]
if missing:
    content = content.rstrip() + '\n\n' + '\n'.join(missing) + '\n'
path.write_text(content)
PY
