#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

ALLOW_MARKER = "HOLY_LIFE_ALLOW_DESTRUCTIVE_MIGRATION"

PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("DROP TABLE", re.compile(r"\bDROP\s+TABLE\b", re.IGNORECASE)),
    ("DROP COLUMN", re.compile(r"\bDROP\s+COLUMN\b", re.IGNORECASE)),
    ("DROP TYPE", re.compile(r"\bDROP\s+TYPE\b", re.IGNORECASE)),
    ("TRUNCATE", re.compile(r"\bTRUNCATE\b", re.IGNORECASE)),
    ("DELETE FROM", re.compile(r"\bDELETE\s+FROM\b", re.IGNORECASE)),
    ("ALTER COLUMN TYPE", re.compile(r"\bALTER\s+COLUMN\b[\s\S]{0,180}\bTYPE\b", re.IGNORECASE)),
)

def without_sql_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.DOTALL)
    return "\n".join(line.split("--", 1)[0] for line in text.splitlines())

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default="prisma/migrations")
    args = parser.parse_args()

    root = Path(args.root)
    if not root.is_dir():
        print(f"Migration directory not found: {root}", file=sys.stderr)
        return 2

    failures: list[str] = []
    files = sorted(root.glob("*/migration.sql"))
    for path in files:
        raw = path.read_text(encoding="utf-8")
        if ALLOW_MARKER in raw:
            continue
        sql = without_sql_comments(raw)
        for label, pattern in PATTERNS:
            if pattern.search(sql):
                failures.append(f"{path}: destructive migration token detected: {label}")

    if failures:
        print("Destructive migration safety gate failed.", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        print(
            f"If a destructive migration is intentionally reviewed, add the explicit marker "
            f"{ALLOW_MARKER} with a documented rollout/rollback plan.",
            file=sys.stderr,
        )
        return 1

    print(f"Migration safety scan passed: {len(files)} migration file(s).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
