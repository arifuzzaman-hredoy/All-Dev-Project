#!/usr/bin/env python3
"""High-confidence repository secret scanner used without third-party Actions."""
from __future__ import annotations

import math
import os
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
EXCLUDED_PARTS = {
    ".git", ".next", "node_modules", "coverage", "out", "dist", ".terraform",
    ".phase3-rollback", ".phase4-rollback", "backups", "diagnostics",
}
EXCLUDED_NAMES = {
    ".env.example", ".env.production.example", "terraform.tfvars.example",
    "package-lock.json", "FILE_INDEX.txt",
}
TEXT_SUFFIXES = {
    ".ts", ".tsx", ".js", ".mjs", ".cjs", ".json", ".yml", ".yaml", ".tf",
    ".tfvars", ".sh", ".ps1", ".py", ".md", ".txt", ".env", ".toml", ".sql",
}
PATTERNS = [
    ("private key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("GitHub token", re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{30,}\b")),
    ("AWS access key", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b")),
]
ASSIGNMENT = re.compile(
    r"(?i)\b(?:password|passwd|secret|api[_-]?key|access[_-]?token|private[_-]?key)\b\s*[:=]\s*[\"']?([^\s\"'`]{20,})"
)
PLACEHOLDERS = ("example", "replace", "change", "dummy", "your_", "ci-only", "<", "${", "***")


def entropy(value: str) -> float:
    if not value:
        return 0.0
    counts = {char: value.count(char) for char in set(value)}
    return -sum((count / len(value)) * math.log2(count / len(value)) for count in counts.values())


def candidate_files():
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.name in EXCLUDED_NAMES:
            continue
        if any(part in EXCLUDED_PARTS for part in path.parts):
            continue
        if path.name.startswith(".env") and path.name not in EXCLUDED_NAMES:
            yield path
        elif path.suffix.lower() in TEXT_SUFFIXES and path.stat().st_size <= 2_000_000:
            yield path


def main() -> int:
    findings: list[str] = []
    for path in candidate_files():
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = path.relative_to(ROOT)
        for line_number, line in enumerate(text.splitlines(), start=1):
            for label, pattern in PATTERNS:
                if pattern.search(line):
                    findings.append(f"{rel}:{line_number}: possible {label}")
            match = ASSIGNMENT.search(line)
            if match:
                value = match.group(1).strip()
                lowered = value.lower()
                if not any(marker in lowered for marker in PLACEHOLDERS) and entropy(value) >= 3.6:
                    findings.append(f"{rel}:{line_number}: high-entropy secret assignment")
    if findings:
        print("Potential secrets detected:", file=sys.stderr)
        print("\n".join(sorted(set(findings))), file=sys.stderr)
        return 1
    print("High-confidence secret scan passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
