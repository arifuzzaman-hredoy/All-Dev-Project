-- Holy Life Phase 6: transactional e-commerce catalog, cart, checkout, inventory and order operations.
CREATE TYPE "ProductStatus" AS ENUM ('DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED');
CREATE TYPE "CommerceOrderStatus" AS ENUM ('PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED');
CREATE TYPE "CommercePaymentStatus" AS ENUM ('UNPAID', 'PENDING_VERIFICATION', 'PAID', 'PARTIAL', 'REFUNDED');
CREATE TYPE "CommercePaymentMethod" AS ENUM ('CASH_ON_DELIVERY', 'MANUAL_PAYMENT');
CREATE TYPE "StockMovementType" AS ENUM ('OPENING', 'PURCHASE', 'SALE', 'SALE_REVERSAL', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT', 'RETURN_IN', 'DAMAGE_OUT');
CREATE TYPE "CouponType" AS ENUM ('FIXED', 'PERCENTAGE');
CREATE TYPE "ReviewStatus" AS ENUM ('PENDING', 'PUBLISHED', 'REJECTED');
CREATE TYPE "RefundStatus" AS ENUM ('REQUESTED', 'APPROVED', 'REJECTED', 'COMPLETED');

CREATE TABLE "ProductCategory" (
  "id" TEXT NOT NULL, "parentId" TEXT, "name" TEXT NOT NULL, "slug" TEXT NOT NULL,
  "description" TEXT, "imageUrl" TEXT, "isActive" BOOLEAN NOT NULL DEFAULT true,
  "displayOrder" INTEGER NOT NULL DEFAULT 0, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ProductCategory_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "ProductBrand" (
  "id" TEXT NOT NULL, "name" TEXT NOT NULL, "slug" TEXT NOT NULL, "description" TEXT, "logoUrl" TEXT,
  "isActive" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "ProductBrand_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "Product" (
  "id" TEXT NOT NULL, "categoryId" TEXT NOT NULL, "brandId" TEXT, "name" TEXT NOT NULL, "slug" TEXT NOT NULL,
  "shortDescription" TEXT, "description" TEXT, "status" "ProductStatus" NOT NULL DEFAULT 'DRAFT',
  "isFeatured" BOOLEAN NOT NULL DEFAULT false, "requiresShipping" BOOLEAN NOT NULL DEFAULT true,
  "taxRate" DECIMAL(5,2) NOT NULL DEFAULT 0, "seoTitle" TEXT, "seoDescription" TEXT,
  "displayOrder" INTEGER NOT NULL DEFAULT 0, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "ProductImage" (
  "id" TEXT NOT NULL, "productId" TEXT NOT NULL, "url" TEXT NOT NULL, "altText" TEXT,
  "position" INTEGER NOT NULL DEFAULT 0, "isPrimary" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "ProductImage_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "ProductVariant" (
  "id" TEXT NOT NULL, "productId" TEXT NOT NULL, "sku" TEXT NOT NULL, "name" TEXT NOT NULL, "attributes" JSONB,
  "price" DECIMAL(12,2) NOT NULL, "compareAtPrice" DECIMAL(12,2), "costPrice" DECIMAL(12,2),
  "stockOnHand" INTEGER NOT NULL DEFAULT 0, "reservedStock" INTEGER NOT NULL DEFAULT 0,
  "lowStockAt" INTEGER NOT NULL DEFAULT 5, "weightGrams" INTEGER, "isDefault" BOOLEAN NOT NULL DEFAULT false,
  "isActive" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "ProductVariant_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CommerceCart" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "expiresAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CommerceCart_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CommerceCartItem" (
  "id" TEXT NOT NULL, "cartId" TEXT NOT NULL, "variantId" TEXT NOT NULL, "quantity" INTEGER NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CommerceCartItem_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CommerceAddress" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "label" TEXT NOT NULL DEFAULT 'Home', "recipientName" TEXT NOT NULL,
  "phone" TEXT NOT NULL, "addressLine1" TEXT NOT NULL, "addressLine2" TEXT, "area" TEXT, "city" TEXT NOT NULL,
  "district" TEXT, "postalCode" TEXT, "isDefault" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CommerceAddress_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "ShippingMethod" (
  "id" TEXT NOT NULL, "code" TEXT NOT NULL, "name" TEXT NOT NULL, "description" TEXT,
  "fee" DECIMAL(12,2) NOT NULL DEFAULT 0, "freeAbove" DECIMAL(12,2), "estimatedDays" TEXT,
  "isActive" BOOLEAN NOT NULL DEFAULT true, "displayOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ShippingMethod_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "Coupon" (
  "id" TEXT NOT NULL, "code" TEXT NOT NULL, "name" TEXT NOT NULL, "type" "CouponType" NOT NULL,
  "value" DECIMAL(12,2) NOT NULL, "minimumSubtotal" DECIMAL(12,2), "maximumDiscount" DECIMAL(12,2),
  "usageLimit" INTEGER, "perUserLimit" INTEGER NOT NULL DEFAULT 1, "startsAt" TIMESTAMP(3), "endsAt" TIMESTAMP(3),
  "isActive" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "Coupon_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CommerceOrder" (
  "id" TEXT NOT NULL, "code" TEXT NOT NULL, "checkoutKey" TEXT NOT NULL, "userId" TEXT NOT NULL,
  "addressId" TEXT, "shippingMethodId" TEXT, "couponId" TEXT,
  "status" "CommerceOrderStatus" NOT NULL DEFAULT 'PENDING',
  "paymentStatus" "CommercePaymentStatus" NOT NULL DEFAULT 'UNPAID',
  "paymentMethod" "CommercePaymentMethod" NOT NULL, "manualPaymentReference" TEXT,
  "subtotal" DECIMAL(12,2) NOT NULL, "discountTotal" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "shippingTotal" DECIMAL(12,2) NOT NULL DEFAULT 0, "taxTotal" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "grandTotal" DECIMAL(12,2) NOT NULL, "currency" TEXT NOT NULL DEFAULT 'BDT',
  "customerName" TEXT NOT NULL, "customerPhone" TEXT NOT NULL, "customerEmail" TEXT,
  "shippingAddress" JSONB NOT NULL, "customerNote" TEXT, "adminNote" TEXT,
  "confirmedAt" TIMESTAMP(3), "shippedAt" TIMESTAMP(3), "deliveredAt" TIMESTAMP(3),
  "cancelledAt" TIMESTAMP(3), "cancellationReason" TEXT, "updatedById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CommerceOrder_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CommerceOrderItem" (
  "id" TEXT NOT NULL, "orderId" TEXT NOT NULL, "productId" TEXT NOT NULL, "variantId" TEXT NOT NULL,
  "productName" TEXT NOT NULL, "variantName" TEXT NOT NULL, "sku" TEXT NOT NULL,
  "unitPrice" DECIMAL(12,2) NOT NULL, "quantity" INTEGER NOT NULL, "lineTotal" DECIMAL(12,2) NOT NULL,
  "attributes" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CommerceOrderItem_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "CouponRedemption" (
  "id" TEXT NOT NULL, "couponId" TEXT NOT NULL, "userId" TEXT NOT NULL, "orderId" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CouponRedemption_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "StockMovement" (
  "id" TEXT NOT NULL, "variantId" TEXT NOT NULL, "type" "StockMovementType" NOT NULL,
  "quantity" INTEGER NOT NULL, "balanceAfter" INTEGER NOT NULL, "referenceType" TEXT, "referenceId" TEXT,
  "note" TEXT, "createdById" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "StockMovement_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "OrderStatusHistory" (
  "id" TEXT NOT NULL, "orderId" TEXT NOT NULL, "fromStatus" "CommerceOrderStatus",
  "toStatus" "CommerceOrderStatus" NOT NULL, "note" TEXT, "actorId" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "OrderStatusHistory_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "RefundRequest" (
  "id" TEXT NOT NULL, "orderId" TEXT NOT NULL, "userId" TEXT NOT NULL,
  "status" "RefundStatus" NOT NULL DEFAULT 'REQUESTED', "amount" DECIMAL(12,2) NOT NULL,
  "reason" TEXT NOT NULL, "resolutionNote" TEXT, "resolvedById" TEXT, "resolvedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "RefundRequest_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "ProductReview" (
  "id" TEXT NOT NULL, "productId" TEXT NOT NULL, "orderId" TEXT NOT NULL, "userId" TEXT NOT NULL,
  "rating" INTEGER NOT NULL, "title" TEXT, "body" TEXT, "status" "ReviewStatus" NOT NULL DEFAULT 'PENDING',
  "moderatedAt" TIMESTAMP(3), "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "ProductReview_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "ProductCategory_slug_key" ON "ProductCategory"("slug");
CREATE INDEX "ProductCategory_parentId_isActive_displayOrder_idx" ON "ProductCategory"("parentId", "isActive", "displayOrder");
CREATE INDEX "ProductCategory_isActive_displayOrder_idx" ON "ProductCategory"("isActive", "displayOrder");
CREATE UNIQUE INDEX "ProductBrand_slug_key" ON "ProductBrand"("slug");
CREATE INDEX "ProductBrand_isActive_name_idx" ON "ProductBrand"("isActive", "name");
CREATE UNIQUE INDEX "Product_slug_key" ON "Product"("slug");
CREATE INDEX "Product_categoryId_status_displayOrder_idx" ON "Product"("categoryId", "status", "displayOrder");
CREATE INDEX "Product_brandId_status_idx" ON "Product"("brandId", "status");
CREATE INDEX "Product_status_isFeatured_displayOrder_idx" ON "Product"("status", "isFeatured", "displayOrder");
CREATE INDEX "ProductImage_productId_position_idx" ON "ProductImage"("productId", "position");
CREATE UNIQUE INDEX "ProductVariant_sku_key" ON "ProductVariant"("sku");
CREATE INDEX "ProductVariant_productId_isActive_idx" ON "ProductVariant"("productId", "isActive");
CREATE INDEX "ProductVariant_stockOnHand_lowStockAt_idx" ON "ProductVariant"("stockOnHand", "lowStockAt");
CREATE UNIQUE INDEX "CommerceCart_userId_key" ON "CommerceCart"("userId");
CREATE INDEX "CommerceCart_updatedAt_idx" ON "CommerceCart"("updatedAt");
CREATE UNIQUE INDEX "CommerceCartItem_cartId_variantId_key" ON "CommerceCartItem"("cartId", "variantId");
CREATE INDEX "CommerceCartItem_variantId_idx" ON "CommerceCartItem"("variantId");
CREATE INDEX "CommerceAddress_userId_isDefault_idx" ON "CommerceAddress"("userId", "isDefault");
CREATE UNIQUE INDEX "ShippingMethod_code_key" ON "ShippingMethod"("code");
CREATE INDEX "ShippingMethod_isActive_displayOrder_idx" ON "ShippingMethod"("isActive", "displayOrder");
CREATE UNIQUE INDEX "Coupon_code_key" ON "Coupon"("code");
CREATE INDEX "Coupon_isActive_startsAt_endsAt_idx" ON "Coupon"("isActive", "startsAt", "endsAt");
CREATE UNIQUE INDEX "CommerceOrder_code_key" ON "CommerceOrder"("code");
CREATE UNIQUE INDEX "CommerceOrder_checkoutKey_key" ON "CommerceOrder"("checkoutKey");
CREATE INDEX "CommerceOrder_userId_createdAt_idx" ON "CommerceOrder"("userId", "createdAt");
CREATE INDEX "CommerceOrder_status_createdAt_idx" ON "CommerceOrder"("status", "createdAt");
CREATE INDEX "CommerceOrder_paymentStatus_createdAt_idx" ON "CommerceOrder"("paymentStatus", "createdAt");
CREATE INDEX "CommerceOrderItem_orderId_idx" ON "CommerceOrderItem"("orderId");
CREATE INDEX "CommerceOrderItem_productId_createdAt_idx" ON "CommerceOrderItem"("productId", "createdAt");
CREATE INDEX "CommerceOrderItem_variantId_createdAt_idx" ON "CommerceOrderItem"("variantId", "createdAt");
CREATE UNIQUE INDEX "CouponRedemption_orderId_key" ON "CouponRedemption"("orderId");
CREATE INDEX "CouponRedemption_couponId_userId_createdAt_idx" ON "CouponRedemption"("couponId", "userId", "createdAt");
CREATE INDEX "StockMovement_variantId_createdAt_idx" ON "StockMovement"("variantId", "createdAt");
CREATE INDEX "StockMovement_referenceType_referenceId_idx" ON "StockMovement"("referenceType", "referenceId");
CREATE INDEX "OrderStatusHistory_orderId_createdAt_idx" ON "OrderStatusHistory"("orderId", "createdAt");
CREATE INDEX "RefundRequest_orderId_status_idx" ON "RefundRequest"("orderId", "status");
CREATE INDEX "RefundRequest_status_createdAt_idx" ON "RefundRequest"("status", "createdAt");
CREATE UNIQUE INDEX "ProductReview_productId_orderId_userId_key" ON "ProductReview"("productId", "orderId", "userId");
CREATE INDEX "ProductReview_productId_status_createdAt_idx" ON "ProductReview"("productId", "status", "createdAt");
CREATE INDEX "ProductReview_status_createdAt_idx" ON "ProductReview"("status", "createdAt");

ALTER TABLE "ProductCategory" ADD CONSTRAINT "ProductCategory_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "ProductCategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "Product" ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ProductCategory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Product" ADD CONSTRAINT "Product_brandId_fkey" FOREIGN KEY ("brandId") REFERENCES "ProductBrand"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "ProductImage" ADD CONSTRAINT "ProductImage_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ProductVariant" ADD CONSTRAINT "ProductVariant_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CommerceCart" ADD CONSTRAINT "CommerceCart_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CommerceCartItem" ADD CONSTRAINT "CommerceCartItem_cartId_fkey" FOREIGN KEY ("cartId") REFERENCES "CommerceCart"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CommerceCartItem" ADD CONSTRAINT "CommerceCartItem_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "ProductVariant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CommerceAddress" ADD CONSTRAINT "CommerceAddress_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CommerceOrder" ADD CONSTRAINT "CommerceOrder_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CommerceOrder" ADD CONSTRAINT "CommerceOrder_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES "CommerceAddress"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "CommerceOrder" ADD CONSTRAINT "CommerceOrder_shippingMethodId_fkey" FOREIGN KEY ("shippingMethodId") REFERENCES "ShippingMethod"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "CommerceOrder" ADD CONSTRAINT "CommerceOrder_couponId_fkey" FOREIGN KEY ("couponId") REFERENCES "Coupon"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "CommerceOrder" ADD CONSTRAINT "CommerceOrder_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "CommerceOrderItem" ADD CONSTRAINT "CommerceOrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "CommerceOrder"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CommerceOrderItem" ADD CONSTRAINT "CommerceOrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CommerceOrderItem" ADD CONSTRAINT "CommerceOrderItem_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "ProductVariant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CouponRedemption" ADD CONSTRAINT "CouponRedemption_couponId_fkey" FOREIGN KEY ("couponId") REFERENCES "Coupon"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CouponRedemption" ADD CONSTRAINT "CouponRedemption_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "CouponRedemption" ADD CONSTRAINT "CouponRedemption_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "CommerceOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "StockMovement" ADD CONSTRAINT "StockMovement_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "ProductVariant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "StockMovement" ADD CONSTRAINT "StockMovement_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "OrderStatusHistory" ADD CONSTRAINT "OrderStatusHistory_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "CommerceOrder"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "RefundRequest" ADD CONSTRAINT "RefundRequest_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "CommerceOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "RefundRequest" ADD CONSTRAINT "RefundRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "RefundRequest" ADD CONSTRAINT "RefundRequest_resolvedById_fkey" FOREIGN KEY ("resolvedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "ProductReview" ADD CONSTRAINT "ProductReview_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ProductReview" ADD CONSTRAINT "ProductReview_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "CommerceOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ProductReview" ADD CONSTRAINT "ProductReview_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "CommerceCartItem" ADD CONSTRAINT "CommerceCartItem_quantity_check" CHECK ("quantity" > 0);
ALTER TABLE "ProductVariant" ADD CONSTRAINT "ProductVariant_stock_check" CHECK ("stockOnHand" >= 0 AND "reservedStock" >= 0 AND "lowStockAt" >= 0);
ALTER TABLE "CommerceOrderItem" ADD CONSTRAINT "CommerceOrderItem_quantity_check" CHECK ("quantity" > 0);
ALTER TABLE "ProductReview" ADD CONSTRAINT "ProductReview_rating_check" CHECK ("rating" BETWEEN 1 AND 5);
