-- Phase 15: additive bilingual managed content fields.
-- All columns are nullable or have safe defaults; no destructive data changes.

ALTER TABLE "MedicalDepartment"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "DoctorProfile"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "designationBn" TEXT,
  ADD COLUMN "specializationBn" TEXT,
  ADD COLUMN "qualificationsBn" TEXT,
  ADD COLUMN "bioBn" TEXT,
  ADD COLUMN "roomLabelBn" TEXT,
  ADD COLUMN "locationBn" TEXT;

ALTER TABLE "ProductCategory"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "ProductBrand"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "Product"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "shortDescriptionBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "ProductImage"
  ADD COLUMN "altTextBn" TEXT;

ALTER TABLE "ProductVariant"
  ADD COLUMN "nameBn" TEXT;

ALTER TABLE "CourseCategory"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "InstructorProfile"
  ADD COLUMN "nameBn" TEXT,
  ADD COLUMN "titleBn" TEXT,
  ADD COLUMN "bioBn" TEXT,
  ADD COLUMN "expertiseBn" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];

ALTER TABLE "Course"
  ADD COLUMN "titleBn" TEXT,
  ADD COLUMN "shortDescriptionBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT,
  ADD COLUMN "learningOutcomesBn" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  ADD COLUMN "requirementsBn" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];

ALTER TABLE "CourseModule"
  ADD COLUMN "titleBn" TEXT,
  ADD COLUMN "descriptionBn" TEXT;

ALTER TABLE "CourseLesson"
  ADD COLUMN "titleBn" TEXT,
  ADD COLUMN "summaryBn" TEXT,
  ADD COLUMN "contentBn" TEXT;

-- Shipping-method public copy is bilingual and remains Admin-managed.
ALTER TABLE "ShippingMethod" ADD COLUMN "nameBn" TEXT;
ALTER TABLE "ShippingMethod" ADD COLUMN "descriptionBn" TEXT;
ALTER TABLE "ShippingMethod" ADD COLUMN "estimatedDaysBn" TEXT;
