CREATE TYPE "PaymentGatewayProvider" AS ENUM ('SSLCOMMERZ');

CREATE TYPE "PaymentGatewayAttemptStatus" AS ENUM (
  'CREATED',
  'SESSION_CREATED',
  'VALIDATING',
  'SUCCEEDED',
  'FAILED',
  'CANCELLED',
  'REVIEW_REQUIRED',
  'EXPIRED'
);

ALTER TABLE "PaymentTransaction"
ADD COLUMN "gatewayAttemptId" TEXT;

CREATE TABLE "PaymentGatewayAttempt" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "accountId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "provider" "PaymentGatewayProvider" NOT NULL,
  "status" "PaymentGatewayAttemptStatus" NOT NULL DEFAULT 'CREATED',
  "idempotencyKey" TEXT NOT NULL,
  "providerTransactionId" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'BDT',
  "sessionKey" TEXT,
  "gatewayUrl" TEXT,
  "validationId" TEXT,
  "bankTransactionId" TEXT,
  "providerStatus" TEXT,
  "riskLevel" INTEGER,
  "riskTitle" TEXT,
  "reviewReason" TEXT,
  "failureReason" TEXT,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "validatedAt" TIMESTAMP(3),
  "completedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PaymentGatewayAttempt_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "PaymentGatewayAttempt_code_key" ON "PaymentGatewayAttempt"("code");
CREATE UNIQUE INDEX "PaymentGatewayAttempt_providerTransactionId_key" ON "PaymentGatewayAttempt"("providerTransactionId");
CREATE UNIQUE INDEX "PaymentGatewayAttempt_sessionKey_key" ON "PaymentGatewayAttempt"("sessionKey");
CREATE UNIQUE INDEX "PaymentGatewayAttempt_userId_idempotencyKey_key" ON "PaymentGatewayAttempt"("userId", "idempotencyKey");
CREATE INDEX "PaymentGatewayAttempt_accountId_status_createdAt_idx" ON "PaymentGatewayAttempt"("accountId", "status", "createdAt");
CREATE INDEX "PaymentGatewayAttempt_userId_createdAt_idx" ON "PaymentGatewayAttempt"("userId", "createdAt");
CREATE INDEX "PaymentGatewayAttempt_provider_status_updatedAt_idx" ON "PaymentGatewayAttempt"("provider", "status", "updatedAt");
CREATE INDEX "PaymentGatewayAttempt_bankTransactionId_idx" ON "PaymentGatewayAttempt"("bankTransactionId");
CREATE UNIQUE INDEX "PaymentTransaction_gatewayAttemptId_key" ON "PaymentTransaction"("gatewayAttemptId");

ALTER TABLE "PaymentGatewayAttempt"
ADD CONSTRAINT "PaymentGatewayAttempt_accountId_fkey"
FOREIGN KEY ("accountId") REFERENCES "PaymentAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "PaymentGatewayAttempt"
ADD CONSTRAINT "PaymentGatewayAttempt_userId_fkey"
FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "PaymentTransaction"
ADD CONSTRAINT "PaymentTransaction_gatewayAttemptId_fkey"
FOREIGN KEY ("gatewayAttemptId") REFERENCES "PaymentGatewayAttempt"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TYPE "CommercePaymentMethod" ADD VALUE 'ONLINE_GATEWAY';
