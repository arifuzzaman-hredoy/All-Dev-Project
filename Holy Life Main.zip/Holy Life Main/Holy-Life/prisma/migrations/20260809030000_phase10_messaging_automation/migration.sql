CREATE TYPE "MessagingChannel" AS ENUM ('EMAIL', 'SMS', 'WHATSAPP');
CREATE TYPE "MessagingPurpose" AS ENUM ('SERVICE', 'MARKETING');
CREATE TYPE "MessagingTemplateStatus" AS ENUM ('DRAFT', 'ACTIVE', 'ARCHIVED');
CREATE TYPE "MessagingCampaignStatus" AS ENUM ('QUEUED', 'PROCESSING', 'COMPLETED', 'CANCELED');
CREATE TYPE "MessagingDeliveryStatus" AS ENUM ('QUEUED', 'SENDING', 'SENT', 'DELIVERED', 'FAILED', 'CANCELED');
CREATE TYPE "MessagingAudience" AS ENUM ('USER', 'ALL_ACTIVE');

CREATE TABLE "MessagingPreference" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "emailEnabled" BOOLEAN NOT NULL DEFAULT true,
    "smsEnabled" BOOLEAN NOT NULL DEFAULT true,
    "whatsappEnabled" BOOLEAN NOT NULL DEFAULT false,
    "marketingEnabled" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "MessagingPreference_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "MessagingTemplate" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "channel" "MessagingChannel" NOT NULL,
    "department" "DepartmentCode",
    "subject" TEXT,
    "body" TEXT NOT NULL,
    "status" "MessagingTemplateStatus" NOT NULL DEFAULT 'DRAFT',
    "createdById" TEXT,
    "updatedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "MessagingTemplate_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "MessagingCampaign" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "channel" "MessagingChannel" NOT NULL,
    "purpose" "MessagingPurpose" NOT NULL DEFAULT 'SERVICE',
    "audience" "MessagingAudience" NOT NULL,
    "department" "DepartmentCode",
    "templateId" TEXT,
    "recipient" TEXT,
    "subject" TEXT,
    "body" TEXT,
    "status" "MessagingCampaignStatus" NOT NULL DEFAULT 'QUEUED',
    "scheduledAt" TIMESTAMP(3),
    "queuedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "recipientCount" INTEGER NOT NULL DEFAULT 0,
    "sentCount" INTEGER NOT NULL DEFAULT 0,
    "deliveredCount" INTEGER NOT NULL DEFAULT 0,
    "failedCount" INTEGER NOT NULL DEFAULT 0,
    "createdById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "MessagingCampaign_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "MessagingDelivery" (
    "id" TEXT NOT NULL,
    "campaignId" TEXT,
    "templateId" TEXT,
    "userId" TEXT,
    "channel" "MessagingChannel" NOT NULL,
    "purpose" "MessagingPurpose" NOT NULL DEFAULT 'SERVICE',
    "target" TEXT NOT NULL,
    "subject" TEXT,
    "body" TEXT NOT NULL,
    "status" "MessagingDeliveryStatus" NOT NULL DEFAULT 'QUEUED',
    "dedupeKey" TEXT NOT NULL,
    "attemptCount" INTEGER NOT NULL DEFAULT 0,
    "maxAttempts" INTEGER NOT NULL DEFAULT 5,
    "nextAttemptAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lockedAt" TIMESTAMP(3),
    "providerMessageId" TEXT,
    "providerStatus" TEXT,
    "lastError" TEXT,
    "sentAt" TIMESTAMP(3),
    "deliveredAt" TIMESTAMP(3),
    "failedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "MessagingDelivery_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "MessagingPreference_userId_key" ON "MessagingPreference"("userId");
CREATE UNIQUE INDEX "MessagingTemplate_code_key" ON "MessagingTemplate"("code");
CREATE INDEX "MessagingTemplate_channel_status_idx" ON "MessagingTemplate"("channel", "status");
CREATE INDEX "MessagingTemplate_department_status_idx" ON "MessagingTemplate"("department", "status");
CREATE UNIQUE INDEX "MessagingCampaign_code_key" ON "MessagingCampaign"("code");
CREATE INDEX "MessagingCampaign_status_scheduledAt_idx" ON "MessagingCampaign"("status", "scheduledAt");
CREATE INDEX "MessagingCampaign_channel_createdAt_idx" ON "MessagingCampaign"("channel", "createdAt");
CREATE INDEX "MessagingCampaign_purpose_createdAt_idx" ON "MessagingCampaign"("purpose", "createdAt");
CREATE UNIQUE INDEX "MessagingDelivery_dedupeKey_key" ON "MessagingDelivery"("dedupeKey");
CREATE INDEX "MessagingDelivery_status_nextAttemptAt_idx" ON "MessagingDelivery"("status", "nextAttemptAt");
CREATE INDEX "MessagingDelivery_campaignId_status_idx" ON "MessagingDelivery"("campaignId", "status");
CREATE INDEX "MessagingDelivery_userId_createdAt_idx" ON "MessagingDelivery"("userId", "createdAt");
CREATE INDEX "MessagingDelivery_providerMessageId_idx" ON "MessagingDelivery"("providerMessageId");

ALTER TABLE "MessagingPreference" ADD CONSTRAINT "MessagingPreference_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MessagingTemplate" ADD CONSTRAINT "MessagingTemplate_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingTemplate" ADD CONSTRAINT "MessagingTemplate_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingCampaign" ADD CONSTRAINT "MessagingCampaign_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "MessagingTemplate"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingCampaign" ADD CONSTRAINT "MessagingCampaign_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingDelivery" ADD CONSTRAINT "MessagingDelivery_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "MessagingCampaign"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingDelivery" ADD CONSTRAINT "MessagingDelivery_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "MessagingTemplate"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MessagingDelivery" ADD CONSTRAINT "MessagingDelivery_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
