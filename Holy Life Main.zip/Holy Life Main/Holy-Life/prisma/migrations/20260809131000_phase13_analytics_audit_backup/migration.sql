ALTER TYPE "AuditAction" ADD VALUE 'EXPORT';

CREATE TYPE "OperationalRunKind" AS ENUM ('BACKUP', 'RESTORE', 'RESTORE_TEST', 'REPOSITORY_CHECK', 'DIAGNOSTICS', 'SECURITY_SCAN');
CREATE TYPE "OperationalRunStatus" AS ENUM ('RUNNING', 'SUCCEEDED', 'FAILED');

CREATE TABLE "OperationalRun" (
    "id" TEXT NOT NULL,
    "runKey" TEXT NOT NULL,
    "kind" "OperationalRunKind" NOT NULL,
    "status" "OperationalRunStatus" NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "finishedAt" TIMESTAMP(3),
    "host" TEXT,
    "release" TEXT,
    "snapshotId" TEXT,
    "summary" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "OperationalRun_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "OperationalRun_runKey_key" ON "OperationalRun"("runKey");
CREATE INDEX "OperationalRun_kind_createdAt_idx" ON "OperationalRun"("kind", "createdAt");
CREATE INDEX "OperationalRun_status_createdAt_idx" ON "OperationalRun"("status", "createdAt");
