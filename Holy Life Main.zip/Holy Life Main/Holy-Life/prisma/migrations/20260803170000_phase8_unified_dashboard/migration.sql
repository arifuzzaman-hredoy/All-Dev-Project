-- Phase 8: Unified public user dashboard
CREATE TYPE "DashboardNotificationKind" AS ENUM ('INFO', 'SUCCESS', 'WARNING', 'ACTION');
CREATE TYPE "SavedItemType" AS ENUM ('DOCTOR', 'PRODUCT', 'COURSE');

CREATE TABLE "DashboardNotification" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "kind" "DashboardNotificationKind" NOT NULL DEFAULT 'INFO',
  "department" "DepartmentCode",
  "dedupeKey" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "message" TEXT,
  "href" TEXT,
  "isRead" BOOLEAN NOT NULL DEFAULT false,
  "readAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DashboardNotification_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "SavedItem" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "itemType" "SavedItemType" NOT NULL,
  "referenceId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SavedItem_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "DashboardNotification_userId_dedupeKey_key" ON "DashboardNotification"("userId", "dedupeKey");
CREATE INDEX "DashboardNotification_userId_isRead_createdAt_idx" ON "DashboardNotification"("userId", "isRead", "createdAt");
CREATE INDEX "DashboardNotification_userId_department_createdAt_idx" ON "DashboardNotification"("userId", "department", "createdAt");
CREATE UNIQUE INDEX "SavedItem_userId_itemType_referenceId_key" ON "SavedItem"("userId", "itemType", "referenceId");
CREATE INDEX "SavedItem_userId_itemType_createdAt_idx" ON "SavedItem"("userId", "itemType", "createdAt");

ALTER TABLE "DashboardNotification" ADD CONSTRAINT "DashboardNotification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SavedItem" ADD CONSTRAINT "SavedItem_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
