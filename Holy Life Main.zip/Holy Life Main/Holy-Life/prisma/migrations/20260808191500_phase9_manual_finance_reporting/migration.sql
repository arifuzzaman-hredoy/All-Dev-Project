-- Phase 9: local/manual finance, in-app notifications, and reporting.

CREATE TYPE "PaymentDomain" AS ENUM ('HEALTHCARE', 'COMMERCE', 'LEARNING');
CREATE TYPE "PaymentAccountStatus" AS ENUM ('UNPAID', 'PENDING_VERIFICATION', 'PARTIAL', 'PAID', 'FAILED', 'REFUNDED');
CREATE TYPE "PaymentTransactionType" AS ENUM ('PAYMENT', 'REFUND', 'ADJUSTMENT');
CREATE TYPE "ManualPaymentMethod" AS ENUM ('CASH', 'BKASH', 'NAGAD', 'ROCKET', 'BANK_TRANSFER', 'OTHER');
CREATE TYPE "PaymentTransactionStatus" AS ENUM ('PENDING', 'VERIFIED', 'REJECTED');

CREATE TABLE "PaymentAccount" (
  "id" TEXT NOT NULL,
  "userId" TEXT,
  "domain" "PaymentDomain" NOT NULL,
  "referenceType" TEXT NOT NULL,
  "referenceId" TEXT NOT NULL,
  "referenceCode" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "amountDue" DECIMAL(12,2) NOT NULL,
  "openingPaidAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "openingRefundedAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "paidAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "refundedAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "currency" TEXT NOT NULL DEFAULT 'BDT',
  "status" "PaymentAccountStatus" NOT NULL DEFAULT 'UNPAID',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PaymentAccount_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "PaymentTransaction" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "accountId" TEXT NOT NULL,
  "type" "PaymentTransactionType" NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "method" "ManualPaymentMethod",
  "status" "PaymentTransactionStatus" NOT NULL DEFAULT 'PENDING',
  "transactionReference" TEXT,
  "note" TEXT,
  "submittedById" TEXT,
  "verifiedById" TEXT,
  "verifiedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PaymentTransaction_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "PaymentAccount_domain_referenceType_referenceId_key"
  ON "PaymentAccount"("domain", "referenceType", "referenceId");
CREATE INDEX "PaymentAccount_userId_createdAt_idx"
  ON "PaymentAccount"("userId", "createdAt");
CREATE INDEX "PaymentAccount_domain_status_createdAt_idx"
  ON "PaymentAccount"("domain", "status", "createdAt");
CREATE INDEX "PaymentAccount_referenceCode_idx"
  ON "PaymentAccount"("referenceCode");

CREATE UNIQUE INDEX "PaymentTransaction_code_key"
  ON "PaymentTransaction"("code");
CREATE INDEX "PaymentTransaction_accountId_createdAt_idx"
  ON "PaymentTransaction"("accountId", "createdAt");
CREATE INDEX "PaymentTransaction_accountId_transactionReference_idx"
  ON "PaymentTransaction"("accountId", "transactionReference");
CREATE INDEX "PaymentTransaction_status_createdAt_idx"
  ON "PaymentTransaction"("status", "createdAt");
CREATE INDEX "PaymentTransaction_type_status_createdAt_idx"
  ON "PaymentTransaction"("type", "status", "createdAt");

ALTER TABLE "PaymentAccount"
  ADD CONSTRAINT "PaymentAccount_userId_fkey"
  FOREIGN KEY ("userId") REFERENCES "User"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "PaymentTransaction"
  ADD CONSTRAINT "PaymentTransaction_accountId_fkey"
  FOREIGN KEY ("accountId") REFERENCES "PaymentAccount"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "PaymentTransaction"
  ADD CONSTRAINT "PaymentTransaction_submittedById_fkey"
  FOREIGN KEY ("submittedById") REFERENCES "User"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "PaymentTransaction"
  ADD CONSTRAINT "PaymentTransaction_verifiedById_fkey"
  FOREIGN KEY ("verifiedById") REFERENCES "User"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;

-- Import historical appointment payment state without inventing partial amounts.
INSERT INTO "PaymentAccount" (
  "id", "userId", "domain", "referenceType", "referenceId", "referenceCode",
  "description", "amountDue", "openingPaidAmount", "openingRefundedAmount",
  "paidAmount", "refundedAmount", "currency", "status", "createdAt", "updatedAt"
)
SELECT
  'p9h_' || md5(a."id"),
  a."userId",
  'HEALTHCARE'::"PaymentDomain",
  'Appointment',
  a."id",
  a."code",
  'Appointment fee · ' || a."code",
  a."fee",
  CASE WHEN a."paymentStatus" IN ('PAID', 'REFUNDED') THEN a."fee" ELSE 0 END,
  CASE WHEN a."paymentStatus" = 'REFUNDED' THEN a."fee" ELSE 0 END,
  CASE WHEN a."paymentStatus" IN ('PAID', 'REFUNDED') THEN a."fee" ELSE 0 END,
  CASE WHEN a."paymentStatus" = 'REFUNDED' THEN a."fee" ELSE 0 END,
  'BDT',
  CASE
    WHEN a."paymentStatus" = 'PAID' THEN 'PAID'::"PaymentAccountStatus"
    WHEN a."paymentStatus" = 'REFUNDED' THEN 'REFUNDED'::"PaymentAccountStatus"
    ELSE 'UNPAID'::"PaymentAccountStatus"
  END,
  a."createdAt",
  a."updatedAt"
FROM "Appointment" a
ON CONFLICT ("domain", "referenceType", "referenceId") DO NOTHING;

-- Import historical commerce payment state.
INSERT INTO "PaymentAccount" (
  "id", "userId", "domain", "referenceType", "referenceId", "referenceCode",
  "description", "amountDue", "openingPaidAmount", "openingRefundedAmount",
  "paidAmount", "refundedAmount", "currency", "status", "createdAt", "updatedAt"
)
SELECT
  'p9c_' || md5(o."id"),
  o."userId",
  'COMMERCE'::"PaymentDomain",
  'CommerceOrder',
  o."id",
  o."code",
  'Shop order · ' || o."code",
  o."grandTotal",
  CASE WHEN o."paymentStatus" IN ('PAID', 'REFUNDED') THEN o."grandTotal" ELSE 0 END,
  CASE WHEN o."paymentStatus" = 'REFUNDED' THEN o."grandTotal" ELSE 0 END,
  CASE WHEN o."paymentStatus" IN ('PAID', 'REFUNDED') THEN o."grandTotal" ELSE 0 END,
  CASE WHEN o."paymentStatus" = 'REFUNDED' THEN o."grandTotal" ELSE 0 END,
  o."currency",
  CASE
    WHEN o."paymentStatus" = 'PENDING_VERIFICATION' AND o."manualPaymentReference" IS NOT NULL
      THEN 'PENDING_VERIFICATION'::"PaymentAccountStatus"
    WHEN o."paymentStatus" = 'PAID' THEN 'PAID'::"PaymentAccountStatus"
    WHEN o."paymentStatus" = 'REFUNDED' THEN 'REFUNDED'::"PaymentAccountStatus"
    ELSE 'UNPAID'::"PaymentAccountStatus"
  END,
  o."createdAt",
  o."updatedAt"
FROM "CommerceOrder" o
ON CONFLICT ("domain", "referenceType", "referenceId") DO NOTHING;

-- Existing manual-payment orders carried one checkout reference for the full order.
-- Convert that explicit legacy evidence into a pending local verification transaction.
INSERT INTO "PaymentTransaction" (
  "id", "code", "accountId", "type", "amount", "method", "status",
  "transactionReference", "note", "submittedById", "createdAt", "updatedAt"
)
SELECT
  'p9t_' || md5(o."id"),
  'PAY-LEGACY-' || upper(substr(md5(o."id"), 1, 12)),
  pa."id",
  'PAYMENT'::"PaymentTransactionType",
  o."grandTotal",
  'OTHER'::"ManualPaymentMethod",
  'PENDING'::"PaymentTransactionStatus",
  o."manualPaymentReference",
  'Imported from the pre-Phase 9 manual checkout reference.',
  o."userId",
  o."createdAt",
  o."updatedAt"
FROM "CommerceOrder" o
JOIN "PaymentAccount" pa
  ON pa."domain" = 'COMMERCE'::"PaymentDomain"
 AND pa."referenceType" = 'CommerceOrder'
 AND pa."referenceId" = o."id"
WHERE o."paymentStatus" = 'PENDING_VERIFICATION'
  AND o."manualPaymentReference" IS NOT NULL
ON CONFLICT ("code") DO NOTHING;

-- Historical PARTIAL states did not record a trustworthy amount before Phase 9.
-- Their finance accounts therefore remain UNPAID until an admin reconciles the known amount.

-- Paid course enrollments did not have a finance ledger before Phase 9.
-- Preserve the enrollment and create an unpaid local account instead of
-- inventing historical payment evidence.
INSERT INTO "PaymentAccount" (
  "id", "userId", "domain", "referenceType", "referenceId", "referenceCode",
  "description", "amountDue", "currency", "status", "createdAt", "updatedAt"
)
SELECT
  'p9l_' || md5(e."id"),
  e."userId",
  'LEARNING'::"PaymentDomain",
  'CourseEnrollment',
  e."id",
  e."id",
  c."title",
  c."price",
  c."currency",
  'UNPAID'::"PaymentAccountStatus",
  e."createdAt",
  e."updatedAt"
FROM "CourseEnrollment" e
JOIN "Course" c ON c."id" = e."courseId"
WHERE c."price" > 0
ON CONFLICT ("domain", "referenceType", "referenceId") DO NOTHING;
