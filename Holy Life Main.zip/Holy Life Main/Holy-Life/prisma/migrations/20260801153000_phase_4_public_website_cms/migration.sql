-- Phase 4: Public Website CMS
CREATE TYPE "WebsitePageStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');
CREATE TYPE "WebsiteSectionType" AS ENUM ('HERO', 'RICH_TEXT', 'FEATURE_GRID', 'STATS', 'CTA', 'FAQ', 'CARD_GRID', 'CONTACT');

CREATE TABLE "WebsitePage" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "navigationLabel" TEXT,
  "excerpt" TEXT,
  "status" "WebsitePageStatus" NOT NULL DEFAULT 'DRAFT',
  "isSystem" BOOLEAN NOT NULL DEFAULT false,
  "showInHeader" BOOLEAN NOT NULL DEFAULT false,
  "showInFooter" BOOLEAN NOT NULL DEFAULT false,
  "headerOrder" INTEGER NOT NULL DEFAULT 0,
  "footerOrder" INTEGER NOT NULL DEFAULT 0,
  "seoTitle" TEXT,
  "seoDescription" TEXT,
  "canonicalPath" TEXT,
  "publishedAt" TIMESTAMP(3),
  "archivedAt" TIMESTAMP(3),
  "version" INTEGER NOT NULL DEFAULT 1,
  "createdById" TEXT,
  "updatedById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WebsitePage_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "WebsiteSection" (
  "id" TEXT NOT NULL,
  "pageId" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "type" "WebsiteSectionType" NOT NULL,
  "title" TEXT NOT NULL,
  "position" INTEGER NOT NULL DEFAULT 0,
  "isEnabled" BOOLEAN NOT NULL DEFAULT true,
  "content" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WebsiteSection_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "WebsitePageRevision" (
  "id" TEXT NOT NULL,
  "pageId" TEXT NOT NULL,
  "version" INTEGER NOT NULL,
  "note" TEXT,
  "snapshot" JSONB NOT NULL,
  "createdById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WebsitePageRevision_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "WebsiteMedia" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "url" TEXT NOT NULL,
  "altText" TEXT NOT NULL,
  "mimeType" TEXT,
  "width" INTEGER,
  "height" INTEGER,
  "provider" TEXT NOT NULL DEFAULT 'REMOTE_URL',
  "isArchived" BOOLEAN NOT NULL DEFAULT false,
  "createdById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WebsiteMedia_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "WebsitePage_slug_key" ON "WebsitePage"("slug");
CREATE INDEX "WebsitePage_status_showInHeader_headerOrder_idx" ON "WebsitePage"("status", "showInHeader", "headerOrder");
CREATE INDEX "WebsitePage_status_showInFooter_footerOrder_idx" ON "WebsitePage"("status", "showInFooter", "footerOrder");
CREATE INDEX "WebsitePage_updatedAt_idx" ON "WebsitePage"("updatedAt");
CREATE UNIQUE INDEX "WebsiteSection_pageId_key_key" ON "WebsiteSection"("pageId", "key");
CREATE INDEX "WebsiteSection_pageId_position_idx" ON "WebsiteSection"("pageId", "position");
CREATE UNIQUE INDEX "WebsitePageRevision_pageId_version_key" ON "WebsitePageRevision"("pageId", "version");
CREATE INDEX "WebsitePageRevision_pageId_createdAt_idx" ON "WebsitePageRevision"("pageId", "createdAt");
CREATE INDEX "WebsiteMedia_isArchived_createdAt_idx" ON "WebsiteMedia"("isArchived", "createdAt");

ALTER TABLE "WebsitePage" ADD CONSTRAINT "WebsitePage_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WebsitePage" ADD CONSTRAINT "WebsitePage_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WebsiteSection" ADD CONSTRAINT "WebsiteSection_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "WebsitePage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WebsitePageRevision" ADD CONSTRAINT "WebsitePageRevision_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "WebsitePage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WebsitePageRevision" ADD CONSTRAINT "WebsitePageRevision_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WebsiteMedia" ADD CONSTRAINT "WebsiteMedia_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
