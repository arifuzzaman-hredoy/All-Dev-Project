-- Phase 3: production RBAC, admin lifecycle, role lifecycle, invitations, and data scopes.

ALTER TYPE "UserStatus" ADD VALUE IF NOT EXISTS 'INVITED' BEFORE 'ACTIVE';

CREATE TYPE "RoleStatus" AS ENUM ('ACTIVE', 'ARCHIVED');
CREATE TYPE "DataScope" AS ENUM ('OWN', 'ASSIGNED', 'DEPARTMENT', 'BRANCH', 'ALL');

ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'ROLE_ASSIGN';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'ROLE_CHANGE';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'INVITE';
ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'ARCHIVE';

ALTER TABLE "Role"
  ADD COLUMN "status" "RoleStatus" NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN "defaultDataScope" "DataScope" NOT NULL DEFAULT 'DEPARTMENT',
  ADD COLUMN "displayOrder" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "archivedAt" TIMESTAMP(3);

ALTER TABLE "UserRole"
  ADD COLUMN "dataScope" "DataScope" NOT NULL DEFAULT 'DEPARTMENT',
  ADD COLUMN "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "RolePermission"
  ADD COLUMN "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE "AdminInvitation" (
  "id" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "tokenHash" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "consumedAt" TIMESTAMP(3),
  "revokedAt" TIMESTAMP(3),
  "invitedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AdminInvitation_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AdminInvitationRole" (
  "invitationId" TEXT NOT NULL,
  "roleId" TEXT NOT NULL,
  "dataScope" "DataScope" NOT NULL DEFAULT 'DEPARTMENT',
  CONSTRAINT "AdminInvitationRole_pkey" PRIMARY KEY ("invitationId", "roleId")
);

CREATE UNIQUE INDEX "AdminInvitation_tokenHash_key" ON "AdminInvitation"("tokenHash");
CREATE INDEX "AdminInvitation_email_expiresAt_idx" ON "AdminInvitation"("email", "expiresAt");
CREATE INDEX "AdminInvitation_invitedById_createdAt_idx" ON "AdminInvitation"("invitedById", "createdAt");
CREATE INDEX "AdminInvitationRole_roleId_idx" ON "AdminInvitationRole"("roleId");
CREATE INDEX "Role_status_isAdminRole_displayOrder_idx" ON "Role"("status", "isAdminRole", "displayOrder");
CREATE INDEX "User_isSuperAdmin_status_idx" ON "User"("isSuperAdmin", "status");
CREATE INDEX "UserRole_dataScope_idx" ON "UserRole"("dataScope");
CREATE INDEX "AuditLog_action_createdAt_idx" ON "AuditLog"("action", "createdAt");

ALTER TABLE "AdminInvitation"
  ADD CONSTRAINT "AdminInvitation_invitedById_fkey"
  FOREIGN KEY ("invitedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "AdminInvitationRole"
  ADD CONSTRAINT "AdminInvitationRole_invitationId_fkey"
  FOREIGN KEY ("invitationId") REFERENCES "AdminInvitation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AdminInvitationRole"
  ADD CONSTRAINT "AdminInvitationRole_roleId_fkey"
  FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
