import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { Prisma, PrismaClient } from "../src/generated/prisma/client";
import { hashPassword } from "../src/lib/auth/crypto";
import { normalizeEmail, normalizePhone } from "../src/lib/auth/normalize";
import {
  DEFAULT_WEBSITE_BRANDING,
  DEFAULT_WEBSITE_PAGES,
} from "../src/lib/cms/defaults";
import {
  PERMISSION_CATALOG,
  ROLE_PRESETS,
  permissionKeysForPatterns,
} from "../src/lib/rbac/catalog";
import { resolveSeedPosition } from "./seed-utils";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required to seed the database.");
}

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: databaseUrl }),
});

type NavigationSeed = {
  key: string;
  title: string;
  href?: string;
  iconKey?: string;
  order: number;
  depth: number;
  department?: "HEALTHCARE" | "COMMERCE" | "LEARNING" | "WEBSITE" | "SYSTEM";
  requiredPermissionKey?: string;
  parentKey?: string;
  surface:
    "PUBLIC_SITE" | "USER_DASHBOARD" | "ADMIN_PANEL" | "SUPER_ADMIN_PANEL";
};

const navigationItems: NavigationSeed[] = [
  {
    key: "public.home",
    title: "Home",
    href: "/",
    iconKey: "home",
    order: 10,
    depth: 0,
    surface: "PUBLIC_SITE",
  },
  {
    key: "public.appointment",
    title: "Doctors & appointment",
    href: "/appointment",
    iconKey: "doctor",
    order: 20,
    depth: 0,
    department: "HEALTHCARE",
    surface: "PUBLIC_SITE",
  },
  {
    key: "public.courses",
    title: "Courses",
    href: "/courses",
    iconKey: "learning",
    order: 30,
    depth: 0,
    department: "LEARNING",
    surface: "PUBLIC_SITE",
  },
  {
    key: "public.shop",
    title: "Shop",
    href: "/shop",
    iconKey: "shop",
    order: 40,
    depth: 0,
    department: "COMMERCE",
    surface: "PUBLIC_SITE",
  },

  {
    key: "dashboard.overview",
    title: "Overview",
    href: "/dashboard",
    iconKey: "dashboard",
    order: 10,
    depth: 0,
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.healthcare",
    title: "Healthcare",
    iconKey: "heart",
    order: 20,
    depth: 0,
    department: "HEALTHCARE",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.healthcare.appointments",
    title: "Appointments",
    href: "/dashboard/healthcare/appointments",
    order: 10,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "dashboard.healthcare",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.healthcare.prescriptions",
    title: "Prescriptions",
    href: "/dashboard/healthcare/prescriptions",
    order: 20,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "dashboard.healthcare",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.learning",
    title: "Learning",
    iconKey: "learning",
    order: 30,
    depth: 0,
    department: "LEARNING",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.learning.courses",
    title: "My courses",
    href: "/dashboard/learning/courses",
    order: 10,
    depth: 1,
    department: "LEARNING",
    parentKey: "dashboard.learning",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.shopping",
    title: "Shopping",
    iconKey: "shop",
    order: 40,
    depth: 0,
    department: "COMMERCE",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.shopping.orders",
    title: "My orders",
    href: "/dashboard/shopping/orders",
    order: 10,
    depth: 1,
    department: "COMMERCE",
    parentKey: "dashboard.shopping",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.activity",
    title: "Activity",
    href: "/dashboard/activity",
    iconKey: "activity",
    order: 50,
    depth: 0,
    department: "SYSTEM",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.payments",
    title: "Payments",
    href: "/dashboard/payments",
    iconKey: "file",
    order: 60,
    depth: 0,
    department: "SYSTEM",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.saved",
    title: "Saved items",
    href: "/dashboard/saved",
    iconKey: "heart",
    order: 70,
    depth: 0,
    department: "SYSTEM",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.notifications",
    title: "Notifications",
    href: "/dashboard/notifications",
    iconKey: "bell",
    order: 80,
    depth: 0,
    department: "SYSTEM",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.profile",
    title: "Profile & security",
    href: "/dashboard/profile",
    iconKey: "profile",
    order: 90,
    depth: 0,
    department: "SYSTEM",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.profile.addresses",
    title: "Address book",
    href: "/dashboard/profile/addresses",
    order: 10,
    depth: 1,
    department: "SYSTEM",
    parentKey: "dashboard.profile",
    surface: "USER_DASHBOARD",
  },
  {
    key: "dashboard.profile.security",
    title: "Security & sessions",
    href: "/dashboard/profile/security",
    order: 20,
    depth: 1,
    department: "SYSTEM",
    parentKey: "dashboard.profile",
    surface: "USER_DASHBOARD",
  },

  {
    key: "admin.overview",
    title: "Dashboard",
    href: "/admin",
    iconKey: "dashboard",
    order: 10,
    depth: 0,
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare",
    title: "Doctor & appointment",
    iconKey: "doctor",
    order: 20,
    depth: 0,
    department: "HEALTHCARE",
    requiredPermissionKey: "healthcare.appointments.appointment.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.doctors",
    title: "Doctors",
    href: "/admin/healthcare/doctors",
    order: 5,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.doctors.doctor.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.departments",
    title: "Departments",
    href: "/admin/healthcare/departments",
    order: 6,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.doctors.department.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.schedules",
    title: "Schedules",
    href: "/admin/healthcare/schedules",
    order: 8,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.doctors.schedule.manage",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.appointments",
    title: "Appointment management",
    href: "/admin/healthcare/appointments",
    order: 10,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.appointments.appointment.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.patients",
    title: "Patients",
    href: "/admin/healthcare/patients",
    order: 20,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.patients.patient.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.clinical-records",
    title: "Clinical records",
    href: "/admin/healthcare/patients/records",
    order: 22,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.patients.clinical-record.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.healthcare.prescriptions",
    title: "Prescriptions",
    href: "/admin/healthcare/prescriptions",
    order: 24,
    depth: 1,
    department: "HEALTHCARE",
    parentKey: "admin.healthcare",
    requiredPermissionKey: "healthcare.prescriptions.prescription.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce",
    title: "E-commerce",
    iconKey: "shop",
    order: 30,
    depth: 0,
    department: "COMMERCE",
    requiredPermissionKey: "commerce.catalog.product.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.products",
    title: "Product management",
    href: "/admin/commerce/products",
    order: 10,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.catalog.product.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.categories",
    title: "Categories & brands",
    href: "/admin/commerce/products/categories",
    order: 12,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.catalog.category.manage",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.inventory",
    title: "Inventory",
    href: "/admin/commerce/products/inventory",
    order: 14,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.inventory.stock.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.orders",
    title: "Order management",
    href: "/admin/commerce/orders",
    order: 20,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.orders.order.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.coupons",
    title: "Coupons",
    href: "/admin/commerce/coupons",
    order: 30,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.catalog.coupon.manage",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.shipping",
    title: "Shipping settings",
    href: "/admin/commerce/settings",
    order: 40,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.shipping.shipping.manage",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.reviews",
    title: "Reviews",
    href: "/admin/commerce/reviews",
    order: 50,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.catalog.product.edit",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.commerce.reports",
    title: "Commerce reports",
    href: "/admin/commerce/reports",
    order: 60,
    depth: 1,
    department: "COMMERCE",
    parentKey: "admin.commerce",
    requiredPermissionKey: "commerce.reports.commerce-report.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.learning",
    title: "Course management",
    iconKey: "learning",
    order: 40,
    depth: 0,
    department: "LEARNING",
    requiredPermissionKey: "learning.courses.course.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.learning.courses",
    title: "Courses",
    href: "/admin/learning/courses",
    order: 10,
    depth: 1,
    department: "LEARNING",
    parentKey: "admin.learning",
    requiredPermissionKey: "learning.courses.course.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.learning.enrollments",
    title: "Enrollments",
    href: "/admin/learning/enrollments",
    order: 20,
    depth: 1,
    department: "LEARNING",
    parentKey: "admin.learning",
    requiredPermissionKey: "learning.enrollments.enrollment.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.learning.assessments",
    title: "Assessments",
    href: "/admin/learning/assessments",
    order: 30,
    depth: 1,
    department: "LEARNING",
    parentKey: "admin.learning",
    requiredPermissionKey: "learning.assessments.quiz.manage",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.learning.certificates",
    title: "Certificates",
    href: "/admin/learning/certificates",
    order: 40,
    depth: 1,
    department: "LEARNING",
    parentKey: "admin.learning",
    requiredPermissionKey: "learning.certificates.certificate.issue",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.website",
    title: "Website management",
    href: "/admin/website",
    iconKey: "globe",
    order: 50,
    depth: 0,
    department: "WEBSITE",
    requiredPermissionKey: "website.cms.content.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.messages",
    title: "Communications",
    href: "/admin/messages",
    iconKey: "message",
    order: 55,
    depth: 0,
    department: "SYSTEM",
    requiredPermissionKey: "system.messaging.campaign.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.finance",
    title: "Finance & reports",
    iconKey: "reports",
    order: 60,
    depth: 0,
    department: "SYSTEM",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.finance.payments",
    title: "Manual payments",
    href: "/admin/finance/payments",
    order: 10,
    depth: 1,
    department: "SYSTEM",
    parentKey: "admin.finance",
    requiredPermissionKey: "system.finance.payment.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.finance.transactions",
    title: "Transactions",
    href: "/admin/finance/transactions",
    order: 20,
    depth: 1,
    department: "SYSTEM",
    parentKey: "admin.finance",
    requiredPermissionKey: "system.finance.payment.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.finance.reports",
    title: "Revenue reports",
    href: "/admin/reports",
    order: 30,
    depth: 1,
    department: "SYSTEM",
    parentKey: "admin.finance",
    requiredPermissionKey: "system.reports.financial-report.view",
    surface: "ADMIN_PANEL",
  },
  {
    key: "admin.notifications",
    title: "Notifications",
    href: "/admin/notifications",
    iconKey: "bell",
    order: 70,
    depth: 0,
    department: "SYSTEM",
    requiredPermissionKey: "system.notifications.notification.manage",
    surface: "ADMIN_PANEL",
  },

  {
    key: "super.overview",
    title: "System overview",
    href: "/super-admin",
    iconKey: "dashboard",
    order: 10,
    depth: 0,
    department: "SYSTEM",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.administration",
    title: "Administration",
    iconKey: "users",
    order: 20,
    depth: 0,
    department: "SYSTEM",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.administration.admins",
    title: "Admin management",
    href: "/super-admin/administration/admins",
    order: 10,
    depth: 1,
    department: "SYSTEM",
    parentKey: "super.administration",
    requiredPermissionKey: "system.administration.admin.view",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.administration.roles",
    title: "Roles & permissions",
    href: "/super-admin/administration/roles",
    order: 20,
    depth: 1,
    department: "SYSTEM",
    parentKey: "super.administration",
    requiredPermissionKey: "system.authorization.role.view",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.control",
    title: "Platform control",
    iconKey: "settings",
    order: 30,
    depth: 0,
    department: "SYSTEM",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.control.dashboard",
    title: "User dashboard",
    href: "/super-admin/control/dashboard",
    order: 10,
    depth: 1,
    department: "SYSTEM",
    parentKey: "super.control",
    requiredPermissionKey: "system.navigation.navigation.manage",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.control.public",
    title: "Public website",
    href: "/super-admin/control/public-site",
    order: 20,
    depth: 1,
    department: "WEBSITE",
    parentKey: "super.control",
    requiredPermissionKey: "website.cms.content.edit",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.audit",
    title: "Audit logs",
    href: "/super-admin/audit",
    iconKey: "clipboard",
    order: 80,
    depth: 0,
    department: "SYSTEM",
    requiredPermissionKey: "system.audit.audit-log.view",
    surface: "SUPER_ADMIN_PANEL",
  },
  {
    key: "super.security",
    title: "Security",
    href: "/super-admin/security",
    iconKey: "shield",
    order: 90,
    depth: 0,
    department: "SYSTEM",
    surface: "SUPER_ADMIN_PANEL",
  },
];

async function seedPermissionsAndRoles(): Promise<void> {
  const phase3SeedMarker = await prisma.systemSetting.findUnique({
    where: { key: "phase3.rbac.seed-version" },
    select: { id: true },
  });
  const firstPhase3Seed = !phase3SeedMarker;

  for (const item of PERMISSION_CATALOG) {
    await prisma.permission.upsert({
      where: { key: item.key },
      update: {
        department: item.department,
        module: item.module,
        resource: item.resource,
        action: item.action,
        description: item.description,
      },
      create: item,
    });
  }

  if (firstPhase3Seed) {
    await prisma.permission.deleteMany({
      where: { key: { notIn: PERMISSION_CATALOG.map((item) => item.key) } },
    });
  }

  const permissions = await prisma.permission.findMany({
    select: { id: true, key: true },
  });
  const permissionsByKey = new Map(
    permissions.map((item) => [item.key, item.id]),
  );

  for (const [index, preset] of ROLE_PRESETS.entries()) {
    const existing = await prisma.role.findUnique({
      where: { code: preset.code },
      select: { id: true },
    });
    const role = existing
      ? await prisma.role.update({
          where: { id: existing.id },
          data: {
            isSystem: preset.isSystem,
            isAdminRole: preset.isAdminRole,
            isMasterAdmin: preset.isMasterAdmin,
            ...(firstPhase3Seed
              ? {
                  name: preset.name,
                  description: preset.description,
                  status: "ACTIVE" as const,
                  defaultDataScope: preset.defaultDataScope,
                  displayOrder: index * 10,
                  archivedAt: null,
                }
              : {}),
          },
        })
      : await prisma.role.create({
          data: {
            code: preset.code,
            name: preset.name,
            description: preset.description,
            status: "ACTIVE",
            defaultDataScope: preset.defaultDataScope,
            isSystem: preset.isSystem,
            isAdminRole: preset.isAdminRole,
            isMasterAdmin: preset.isMasterAdmin,
            displayOrder: index * 10,
          },
        });

    if (firstPhase3Seed || !existing) {
      const desiredPermissionKeys = permissionKeysForPatterns(preset.patterns);
      const desiredIds = desiredPermissionKeys
        .map((key) => permissionsByKey.get(key))
        .filter((id): id is string => Boolean(id));

      await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
      for (const permissionId of desiredIds) {
        await prisma.rolePermission.create({
          data: {
            roleId: role.id,
            permissionId,
            allowed: true,
          },
        });
      }
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "phase3.rbac.seed-version" },
    update: { value: { version: 1, appliedAt: new Date().toISOString() } },
    create: {
      key: "phase3.rbac.seed-version",
      value: { version: 1, appliedAt: new Date().toISOString() },
    },
  });
}

async function seedNavigation(): Promise<void> {
  const idsByKey = new Map<string, string>();
  for (const item of navigationItems) {
    const parentId = item.parentKey ? idsByKey.get(item.parentKey) : undefined;
    if (item.parentKey && !parentId) {
      throw new Error(`Navigation parent was not seeded: ${item.parentKey}`);
    }
    const record = await prisma.navigationItem.upsert({
      where: { key: item.key },
      update: {
        surface: item.surface,
        title: item.title,
        href: item.href ?? null,
        iconKey: item.iconKey ?? null,
        order: item.order,
        depth: item.depth,
        department: item.department ?? null,
        requiredPermissionKey: item.requiredPermissionKey ?? null,
        parentId: parentId ?? null,
        isVisible: true,
      },
      create: {
        surface: item.surface,
        key: item.key,
        title: item.title,
        href: item.href ?? null,
        iconKey: item.iconKey ?? null,
        order: item.order,
        depth: item.depth,
        department: item.department ?? null,
        requiredPermissionKey: item.requiredPermissionKey ?? null,
        parentId: parentId ?? null,
        isVisible: true,
      },
      select: { id: true },
    });
    idsByKey.set(item.key, record.id);
  }
}

async function seedSiteConfiguration(): Promise<void> {
  const sections = [
    {
      key: "home.hero",
      page: "home",
      title: "Home hero",
      position: 10,
      content: {
        eyebrow: "Health, fitness & wellness—connected",
        title: "One simple place to care, learn, and live healthier.",
        primaryAction: "/appointment",
      },
    },
    {
      key: "home.departments",
      page: "home",
      title: "Core departments",
      position: 20,
      content: { departments: ["HEALTHCARE", "LEARNING", "COMMERCE"] },
    },
    {
      key: "dashboard.welcome",
      page: "dashboard",
      title: "Dashboard welcome",
      position: 10,
      content: {
        title: "Good afternoon",
        description:
          "Healthcare, learning, and shopping activity in one simple workspace.",
      },
    },
  ];

  for (const section of sections) {
    await prisma.siteSection.upsert({
      where: { key: section.key },
      update: section,
      create: section,
    });
  }

  await prisma.systemSetting.upsert({
    where: { key: "platform.departments" },
    update: {
      value: {
        healthcare: { enabled: true },
        commerce: { enabled: true },
        learning: { enabled: true },
      },
    },
    create: {
      key: "platform.departments",
      value: {
        healthcare: { enabled: true },
        commerce: { enabled: true },
        learning: { enabled: true },
      },
    },
  });
}

async function seedPhase4WebsiteCms(): Promise<void> {
  const marker = await prisma.systemSetting.findUnique({
    where: { key: "phase4.cms.seed-version" },
    select: { id: true },
  });
  const firstSeed = !marker;

  for (const pageSeed of DEFAULT_WEBSITE_PAGES) {
    const existing = await prisma.websitePage.findUnique({
      where: { slug: pageSeed.slug },
      select: { id: true },
    });
    const page = existing
      ? await prisma.websitePage.update({
          where: { id: existing.id },
          data: { isSystem: pageSeed.isSystem ?? false },
        })
      : await prisma.websitePage.create({
          data: {
            slug: pageSeed.slug,
            title: pageSeed.title,
            navigationLabel: pageSeed.navigationLabel ?? null,
            excerpt: pageSeed.excerpt,
            status: "PUBLISHED",
            isSystem: pageSeed.isSystem ?? false,
            showInHeader: pageSeed.showInHeader ?? false,
            showInFooter: pageSeed.showInFooter ?? false,
            headerOrder: pageSeed.headerOrder ?? 0,
            footerOrder: pageSeed.footerOrder ?? 0,
            seoTitle: pageSeed.seoTitle ?? pageSeed.title,
            seoDescription: pageSeed.seoDescription ?? pageSeed.excerpt,
            canonicalPath: pageSeed.slug === "home" ? "/" : `/${pageSeed.slug}`,
            publishedAt: new Date(),
          },
        });

    if (firstSeed || !existing) {
      for (const section of pageSeed.sections) {
        await prisma.websiteSection.upsert({
          where: { pageId_key: { pageId: page.id, key: section.key } },
          update: {},
          create: {
            pageId: page.id,
            key: section.key,
            type: section.type,
            title: section.title,
            position: section.position,
            isEnabled: true,
            content: section.content as Prisma.InputJsonValue,
          },
        });
      }
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "website.branding" },
    update: {},
    create: {
      key: "website.branding",
      value: DEFAULT_WEBSITE_BRANDING as Prisma.InputJsonValue,
    },
  });
  await prisma.systemSetting.upsert({
    where: { key: "phase4.cms.seed-version" },
    update: { value: { version: 1, checkedAt: new Date().toISOString() } },
    create: {
      key: "phase4.cms.seed-version",
      value: { version: 1, appliedAt: new Date().toISOString() },
    },
  });
}

async function seedPhase5Healthcare(): Promise<void> {
  const departments = [
    {
      code: "LIFESTYLE_MEDICINE",
      slug: "lifestyle-medicine",
      name: "Lifestyle Medicine",
      nameBn: "জীবনধারাভিত্তিক চিকিৎসা",
      description:
        "Doctor-led prevention, metabolic health, and sustainable lifestyle care.",
      descriptionBn:
        "রোগ প্রতিরোধ, বিপাকীয় স্বাস্থ্য এবং টেকসই জীবনযাপনের অভ্যাস নিয়ে চিকিৎসকের পরামর্শ ও ফলো-আপ।",
      displayOrder: 10,
    },
    {
      code: "NUTRITION",
      slug: "nutrition",
      name: "Nutrition & Dietetics",
      nameBn: "পুষ্টি ও খাদ্যবিদ্যা",
      description: "Evidence-based nutrition assessment and follow-up care.",
      descriptionBn:
        "খাদ্যাভ্যাস, পুষ্টি মূল্যায়ন এবং বাস্তবসম্মত ফলো-আপ পরিকল্পনার জন্য পেশাদার সহায়তা।",
      displayOrder: 20,
    },
    {
      code: "FITNESS_REHAB",
      slug: "fitness-rehab",
      name: "Fitness & Rehabilitation",
      nameBn: "ফিটনেস ও পুনর্বাসন",
      description:
        "Safe movement, fitness assessment, and rehabilitation support.",
      descriptionBn:
        "নিরাপদ শারীরিক কার্যক্রম, ফিটনেস মূল্যায়ন এবং পুনর্বাসনভিত্তিক সহায়তা।",
      displayOrder: 30,
    },
  ];

  const departmentByCode = new Map<string, string>();
  for (const item of departments) {
    const existing = await prisma.medicalDepartment.findUnique({
      where: { code: item.code },
    });
    const canRefreshSeedCopy =
      !existing ||
      [
        item.name,
        "Lifestyle Medicine",
        "Nutrition & Dietetics",
        "Fitness & Rehabilitation",
      ].includes(existing.name);
    const department = await prisma.medicalDepartment.upsert({
      where: { code: item.code },
      update: {
        slug: existing?.slug ?? item.slug,
        name: canRefreshSeedCopy ? item.name : existing?.name,
        nameBn: existing?.nameBn ?? item.nameBn,
        description: canRefreshSeedCopy
          ? item.description
          : existing?.description,
        descriptionBn: existing?.descriptionBn ?? item.descriptionBn,
        displayOrder: existing?.displayOrder ?? item.displayOrder,
        isActive: existing?.isActive ?? true,
      },
      create: { ...item, isActive: true },
      select: { id: true },
    });
    departmentByCode.set(item.code, department.id);
  }

  const owner = await prisma.user.findFirst({
    where: { isSuperAdmin: true, status: "ACTIVE" },
    orderBy: { createdAt: "asc" },
    select: { id: true, email: true, phone: true },
  });

  const ownerDepartmentId = departmentByCode.get("LIFESTYLE_MEDICINE");
  if (!ownerDepartmentId)
    throw new Error("Missing medical department: LIFESTYLE_MEDICINE");

  const ownerExisting = await prisma.doctorProfile.findUnique({
    where: { code: "DOC-0001" },
  });
  const ownerDoctor = await prisma.doctorProfile.upsert({
    where: { code: "DOC-0001" },
    update: {
      departmentId: ownerExisting?.departmentId ?? ownerDepartmentId,
      userId: owner?.id ?? ownerExisting?.userId ?? null,
      email: owner?.email ?? ownerExisting?.email ?? null,
      phone: owner?.phone ?? ownerExisting?.phone ?? null,
      nameBn: ownerExisting?.nameBn ?? "ডা. কাওসার আহমেদ",
      designationBn: ownerExisting?.designationBn ?? "কনসালট্যান্ট ফিজিশিয়ান",
      specializationBn:
        ownerExisting?.specializationBn ??
        "লাইফস্টাইল মেডিসিন ও মেটাবলিক স্বাস্থ্য",
      qualificationsBn: ownerExisting?.qualificationsBn ?? null,
      bioBn:
        ownerExisting?.bioBn ??
        "প্রতিরোধমূলক স্বাস্থ্য, দৈনন্দিন অভ্যাস এবং দীর্ঘমেয়াদি সুস্থতা নিয়ে চিকিৎসক-নির্দেশিত পরামর্শ ও ফলো-আপ।",
      roomLabelBn: ownerExisting?.roomLabelBn ?? "কনসালটেশন রুম ১",
      locationBn: ownerExisting?.locationBn ?? "Holy Life, রংপুর",
      status: ownerExisting?.status ?? "ACTIVE",
      isFeatured: ownerExisting?.isFeatured ?? true,
    },
    create: {
      userId: owner?.id ?? null,
      departmentId: ownerDepartmentId,
      code: "DOC-0001",
      slug: "dr-kawsar-ahmed",
      name: "Dr. Kawsar Ahmed",
      nameBn: "ডা. কাওসার আহমেদ",
      email: owner?.email ?? null,
      phone: owner?.phone ?? null,
      designation: "Consultant Physician",
      designationBn: "কনসালট্যান্ট ফিজিশিয়ান",
      specialization: "Lifestyle Medicine & Metabolic Health",
      specializationBn: "লাইফস্টাইল মেডিসিন ও মেটাবলিক স্বাস্থ্য",
      qualifications: null,
      qualificationsBn: null,
      experienceYears: 0,
      bio: "Doctor-led consultation focused on prevention, daily habits, and sustainable long-term wellbeing.",
      bioBn:
        "প্রতিরোধমূলক স্বাস্থ্য, দৈনন্দিন অভ্যাস এবং দীর্ঘমেয়াদি সুস্থতা নিয়ে চিকিৎসক-নির্দেশিত পরামর্শ ও ফলো-আপ।",
      consultationFee: new Prisma.Decimal(1000),
      followUpFee: new Prisma.Decimal(700),
      roomLabel: "Consultation Room 1",
      roomLabelBn: "কনসালটেশন রুম ১",
      location: "Holy Life, Rangpur",
      locationBn: "Holy Life, রংপুর",
      status: "ACTIVE",
      isFeatured: true,
      displayOrder: 10,
    },
    select: { id: true },
  });

  // Keep only the confirmed owner profile public. Legacy demo clinicians are retained for
  // relational/audit safety but hidden when they still match the original seed identities.
  for (const legacy of [
    { code: "DOC-0002", name: "Dr. Nusrat Jahan" },
    { code: "DOC-0003", name: "Dr. Farhan Kabir" },
  ]) {
    const existing = await prisma.doctorProfile.findUnique({
      where: { code: legacy.code },
      select: { id: true, name: true, status: true },
    });
    if (existing?.name === legacy.name && existing.status === "ACTIVE") {
      await prisma.doctorProfile.update({
        where: { id: existing.id },
        data: { status: "INACTIVE", isFeatured: false },
      });
    }
  }

  for (const weekday of [0, 1, 2, 3, 4, 6]) {
    await prisma.doctorSchedule.upsert({
      where: {
        doctorId_weekday_startTime_endTime: {
          doctorId: ownerDoctor.id,
          weekday,
          startTime: "09:00",
          endTime: "14:00",
        },
      },
      update: {
        slotMinutes: 30,
        maxPatients: 1,
        breakStart: "11:30",
        breakEnd: "12:00",
        isActive: true,
      },
      create: {
        doctorId: ownerDoctor.id,
        weekday,
        startTime: "09:00",
        endTime: "14:00",
        slotMinutes: 30,
        maxPatients: 1,
        breakStart: "11:30",
        breakEnd: "12:00",
        isActive: true,
      },
    });
  }

  const initialMemberEmail = process.env.INITIAL_MEMBER_EMAIL
    ? normalizeEmail(process.env.INITIAL_MEMBER_EMAIL)
    : null;
  if (initialMemberEmail) {
    const member = await prisma.user.findUnique({
      where: { email: initialMemberEmail },
      select: { id: true, name: true, phone: true, email: true },
    });
    if (member?.phone) {
      await prisma.patientProfile.upsert({
        where: { userId: member.id },
        update: {
          name: member.name,
          phone: member.phone,
          email: member.email,
          status: "ACTIVE",
        },
        create: {
          userId: member.id,
          patientCode: `HLP-${member.id.slice(-8).toUpperCase()}`,
          name: member.name,
          phone: member.phone,
          email: member.email,
          status: "ACTIVE",
        },
      });
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "phase5.appointments.settings" },
    update: {},
    create: {
      key: "phase5.appointments.settings",
      value: {
        bookingWindowDays: 90,
        allowSameDayBooking: true,
        defaultSlotMinutes: 30,
        cancellationHours: 12,
        timezone: "Asia/Dhaka",
      },
    },
  });

  await prisma.systemSetting.upsert({
    where: { key: "phase5.healthcare.seed-version" },
    update: {
      value: {
        version: 2,
        checkedAt: new Date().toISOString(),
        note: "Bilingual production-safe clinician catalog",
      },
    },
    create: {
      key: "phase5.healthcare.seed-version",
      value: {
        version: 2,
        appliedAt: new Date().toISOString(),
        note: "Bilingual production-safe clinician catalog",
      },
    },
  });
}

async function seedPhase6Commerce(): Promise<void> {
  const categories = [
    {
      name: "Nutrition & supplements",
      nameBn: "পুষ্টি ও সাপ্লিমেন্ট",
      slug: "nutrition-supplements",
      description: "Nutrition and wellness support products.",
      descriptionBn: "দৈনন্দিন সুস্থতা ও পুষ্টি সহায়তার জন্য নির্বাচিত পণ্য।",
      displayOrder: 10,
    },
    {
      name: "Healthy foods",
      nameBn: "স্বাস্থ্যকর খাবার",
      slug: "healthy-foods",
      description: "Practical healthier food choices.",
      descriptionBn:
        "দৈনন্দিন খাবারের জন্য ব্যবহারিক ও তুলনামূলক স্বাস্থ্যসম্মত পছন্দ।",
      displayOrder: 20,
    },
    {
      name: "Fitness & recovery",
      nameBn: "ফিটনেস ও রিকভারি",
      slug: "fitness-recovery",
      description: "Movement, recovery and fitness essentials.",
      descriptionBn: "ব্যায়াম, চলাফেরা ও রিকভারির জন্য প্রয়োজনীয় সরঞ্জাম।",
      displayOrder: 30,
    },
  ];
  const categoryIds = new Map<string, string>();
  for (const item of categories) {
    const existing = await prisma.productCategory.findUnique({
      where: { slug: item.slug },
    });
    const category = await prisma.productCategory.upsert({
      where: { slug: item.slug },
      update: {
        name: existing?.name ?? item.name,
        nameBn: existing?.nameBn ?? item.nameBn,
        description: existing?.description ?? item.description,
        descriptionBn: existing?.descriptionBn ?? item.descriptionBn,
        displayOrder: existing?.displayOrder ?? item.displayOrder,
        isActive: existing?.isActive ?? true,
      },
      create: { ...item, isActive: true },
      select: { id: true },
    });
    categoryIds.set(item.slug, category.id);
  }

  const existingBrand = await prisma.productBrand.findUnique({
    where: { slug: "holy-life" },
  });
  const brand = await prisma.productBrand.upsert({
    where: { slug: "holy-life" },
    update: {
      name: existingBrand?.name ?? "Holy Life",
      nameBn: existingBrand?.nameBn ?? "Holy Life",
      description:
        existingBrand?.description ?? "Holy Life selected wellness products.",
      descriptionBn:
        existingBrand?.descriptionBn ??
        "Holy Life-এর নির্বাচিত সুস্থতা ও জীবনধারার পণ্য।",
      isActive: existingBrand?.isActive ?? true,
    },
    create: {
      name: "Holy Life",
      nameBn: "Holy Life",
      slug: "holy-life",
      description: "Holy Life selected wellness products.",
      descriptionBn: "Holy Life-এর নির্বাচিত সুস্থতা ও জীবনধারার পণ্য।",
      isActive: true,
    },
    select: { id: true },
  });

  const products = [
    {
      legacyName: "Daily Wellness Starter Pack",
      slug: "daily-wellness-starter-pack",
      name: "Vitamin D3 Softgel — 1000 IU",
      nameBn: "ভিটামিন D3 সফটজেল — ১০০০ IU",
      category: "nutrition-supplements",
      shortDescription:
        "A standard-dose vitamin D3 softgel listing for routine wellness use.",
      shortDescriptionBn:
        "দৈনন্দিন সুস্থতার রুটিনে ব্যবহারের জন্য ১০০০ IU ভিটামিন D3 সফটজেল।",
      description:
        "Use according to the product label or advice from a qualified healthcare professional. Product information, stock and final packaging can be maintained from the Admin panel.",
      descriptionBn:
        "পণ্যের লেবেলে দেওয়া নির্দেশনা অথবা যোগ্য স্বাস্থ্যপেশাজীবীর পরামর্শ অনুযায়ী ব্যবহার করুন। পণ্যের তথ্য, স্টক ও চূড়ান্ত প্যাকেজিং Admin panel থেকে নিয়ন্ত্রণ করা যাবে।",
      sku: "HL-WELLNESS-001",
      variantName: "Bottle",
      variantNameBn: "বোতল",
      price: 690,
      compareAtPrice: 790,
      stock: 40,
      imageUrl:
        "https://images.unsplash.com/photo-1763668331599-487470fb85b2?auto=format&fit=crop&w=1600&q=80",
      imageAlt: "Vitamin D capsules",
      imageAltBn: "ভিটামিন D ক্যাপসুল",
      featured: true,
      order: 10,
    },
    {
      legacyName: "Healthy Breakfast Box",
      slug: "healthy-breakfast-box",
      name: "Whole Grain Breakfast Essentials",
      nameBn: "হোল গ্রেইন ব্রেকফাস্ট এসেনশিয়ালস",
      category: "healthy-foods",
      shortDescription:
        "Whole-grain breakfast staples for a convenient, balanced morning meal.",
      shortDescriptionBn:
        "সকালের সহজ ও ভারসাম্যপূর্ণ খাবারের জন্য হোল-গ্রেইন ব্রেকফাস্ট উপকরণ।",
      description:
        "A pantry-focused breakfast selection intended for convenient meal planning. Ingredients and pack composition can be updated by authorized commerce staff.",
      descriptionBn:
        "সহজ meal planning-এর জন্য pantry-focused breakfast selection। উপাদান ও pack composition অনুমোদিত Commerce staff Admin panel থেকে আপডেট করতে পারবেন।",
      sku: "HL-FOOD-001",
      variantName: "Standard pack",
      variantNameBn: "স্ট্যান্ডার্ড প্যাক",
      price: 1190,
      compareAtPrice: null,
      stock: 30,
      imageUrl:
        "https://images.unsplash.com/photo-1539279006849-35e5504ce752?auto=format&fit=crop&w=1600&q=80",
      imageAlt: "Healthy breakfast bowl",
      imageAltBn: "স্বাস্থ্যকর ব্রেকফাস্ট বোল",
      featured: true,
      order: 20,
    },
    {
      legacyName: "Recovery Resistance Band",
      slug: "recovery-resistance-band",
      name: "Resistance Training Band Set",
      nameBn: "রেজিস্ট্যান্স ট্রেনিং ব্যান্ড সেট",
      category: "fitness-recovery",
      shortDescription:
        "Portable resistance bands for progressive home and studio exercise.",
      shortDescriptionBn:
        "ঘর বা স্টুডিওতে ধাপে ধাপে ব্যায়ামের জন্য বহনযোগ্য রেজিস্ট্যান্স ব্যান্ড সেট।",
      description:
        "A compact resistance-band set for general strength and mobility routines. Choose resistance and exercise progression appropriate to your ability.",
      descriptionBn:
        "সাধারণ strength ও mobility routine-এর জন্য compact resistance-band set। নিজের সক্ষমতা অনুযায়ী resistance ও exercise progression বেছে নিন।",
      sku: "HL-FIT-001",
      variantName: "Multi-resistance set",
      variantNameBn: "মাল্টি-রেজিস্ট্যান্স সেট",
      price: 850,
      compareAtPrice: 950,
      stock: 55,
      imageUrl:
        "https://images.unsplash.com/photo-1767404890803-228d5390fcd4?auto=format&fit=crop&w=1600&q=80",
      imageAlt: "Resistance training bands",
      imageAltBn: "রেজিস্ট্যান্স ট্রেনিং ব্যান্ড",
      featured: true,
      order: 30,
    },
  ];

  for (const item of products) {
    const categoryId = categoryIds.get(item.category);
    if (!categoryId)
      throw new Error(`Missing product category: ${item.category}`);
    const existing = await prisma.product.findUnique({
      where: { slug: item.slug },
    });
    const seedManaged =
      !existing ||
      existing.name === item.legacyName ||
      existing.name === item.name;
    const product = existing
      ? await prisma.product.update({
          where: { id: existing.id },
          data: {
            categoryId,
            brandId: brand.id,
            name: seedManaged ? item.name : existing.name,
            nameBn: existing.nameBn ?? item.nameBn,
            shortDescription: seedManaged
              ? item.shortDescription
              : existing.shortDescription,
            shortDescriptionBn:
              existing.shortDescriptionBn ?? item.shortDescriptionBn,
            description: seedManaged ? item.description : existing.description,
            descriptionBn: existing.descriptionBn ?? item.descriptionBn,
            status: existing.status,
            isFeatured: seedManaged ? item.featured : existing.isFeatured,
            displayOrder: seedManaged ? item.order : existing.displayOrder,
          },
        })
      : await prisma.product.create({
          data: {
            name: item.name,
            nameBn: item.nameBn,
            slug: item.slug,
            categoryId,
            brandId: brand.id,
            shortDescription: item.shortDescription,
            shortDescriptionBn: item.shortDescriptionBn,
            description: item.description,
            descriptionBn: item.descriptionBn,
            status: "ACTIVE",
            isFeatured: item.featured,
            displayOrder: item.order,
          },
        });

    const existingVariant = await prisma.productVariant.findUnique({
      where: { sku: item.sku },
    });
    if (existingVariant) {
      const legacyVariantNames = [
        "Standard pack",
        "7-day box",
        "Medium resistance",
        item.variantName,
      ];
      const canRefreshVariant = legacyVariantNames.includes(
        existingVariant.name,
      );
      await prisma.productVariant.update({
        where: { id: existingVariant.id },
        data: {
          productId: product.id,
          name: canRefreshVariant ? item.variantName : existingVariant.name,
          nameBn: existingVariant.nameBn ?? item.variantNameBn,
          price: canRefreshVariant
            ? new Prisma.Decimal(item.price)
            : existingVariant.price,
          compareAtPrice: canRefreshVariant
            ? item.compareAtPrice
              ? new Prisma.Decimal(item.compareAtPrice)
              : null
            : existingVariant.compareAtPrice,
          isDefault: true,
          isActive: existingVariant.isActive,
        },
      });
    } else {
      const variant = await prisma.productVariant.create({
        data: {
          productId: product.id,
          sku: item.sku,
          name: item.variantName,
          nameBn: item.variantNameBn,
          price: new Prisma.Decimal(item.price),
          compareAtPrice: item.compareAtPrice
            ? new Prisma.Decimal(item.compareAtPrice)
            : null,
          stockOnHand: item.stock,
          lowStockAt: 5,
          isDefault: true,
          isActive: true,
        },
      });
      if (item.stock > 0) {
        await prisma.stockMovement.create({
          data: {
            variantId: variant.id,
            type: "OPENING",
            quantity: item.stock,
            balanceAfter: item.stock,
            note: "Opening stock for managed starter catalog",
          },
        });
      }
    }

    const existingImage = await prisma.productImage.findFirst({
      where: { productId: product.id, isPrimary: true },
    });
    const legacyImage =
      !existingImage ||
      existingImage.url.startsWith("/commerce/") ||
      existingImage.url === item.imageUrl;
    if (existingImage) {
      await prisma.productImage.update({
        where: { id: existingImage.id },
        data: {
          url: legacyImage ? item.imageUrl : existingImage.url,
          altText: legacyImage ? item.imageAlt : existingImage.altText,
          altTextBn: existingImage.altTextBn ?? item.imageAltBn,
          position: 0,
        },
      });
    } else {
      await prisma.productImage.create({
        data: {
          productId: product.id,
          url: item.imageUrl,
          altText: item.imageAlt,
          altTextBn: item.imageAltBn,
          isPrimary: true,
          position: 0,
        },
      });
    }
  }

  const shippingMethods = [
    {
      code: "DHAKA_STANDARD",
      name: "Dhaka standard delivery",
      nameBn: "ঢাকার ভেতরে স্ট্যান্ডার্ড ডেলিভারি",
      fee: 80,
      freeAbove: 3000,
      estimatedDays: "1-2 business days",
      estimatedDaysBn: "১–২ কার্যদিবস",
      displayOrder: 10,
    },
    {
      code: "BANGLADESH_STANDARD",
      name: "Outside Dhaka delivery",
      nameBn: "ঢাকার বাইরে স্ট্যান্ডার্ড ডেলিভারি",
      fee: 150,
      freeAbove: 5000,
      estimatedDays: "2-4 business days",
      estimatedDaysBn: "২–৪ কার্যদিবস",
      displayOrder: 20,
    },
  ];
  for (const item of shippingMethods) {
    const existing = await prisma.shippingMethod.findUnique({
      where: { code: item.code },
    });
    await prisma.shippingMethod.upsert({
      where: { code: item.code },
      update: {
        nameBn: existing?.nameBn ?? item.nameBn,
        estimatedDaysBn: existing?.estimatedDaysBn ?? item.estimatedDaysBn,
      },
      create: {
        ...item,
        fee: new Prisma.Decimal(item.fee),
        freeAbove: new Prisma.Decimal(item.freeAbove),
        isActive: true,
      },
    });
  }
  await prisma.coupon.upsert({
    where: { code: "WELCOME10" },
    update: {},
    create: {
      code: "WELCOME10",
      name: "Welcome 10%",
      type: "PERCENTAGE",
      value: new Prisma.Decimal(10),
      maximumDiscount: new Prisma.Decimal(500),
      minimumSubtotal: new Prisma.Decimal(1000),
      perUserLimit: 1,
      isActive: true,
    },
  });
  await prisma.systemSetting.upsert({
    where: { key: "phase6.commerce.seed-version" },
    update: {
      value: {
        version: 2,
        checkedAt: new Date().toISOString(),
        catalog: "production-style managed starter data",
      },
    },
    create: {
      key: "phase6.commerce.seed-version",
      value: {
        version: 2,
        appliedAt: new Date().toISOString(),
        currency: "BDT",
        paymentMethods: ["CASH_ON_DELIVERY", "MANUAL_PAYMENT"],
        catalog: "production-style managed starter data",
      },
    },
  });
}

async function seedAuthUsers(): Promise<void> {
  const masterAdminRole = await prisma.role.findUniqueOrThrow({
    where: { code: "MASTER_ADMIN" },
  });
  const memberRole = await prisma.role.findUniqueOrThrow({
    where: { code: "MEMBER" },
  });
  const now = new Date();

  const ownerEmailRaw = process.env.INITIAL_SUPER_ADMIN_EMAIL;
  const ownerPassword = process.env.INITIAL_SUPER_ADMIN_PASSWORD;
  if (ownerEmailRaw && ownerPassword) {
    const ownerEmail = normalizeEmail(ownerEmailRaw);
    const existing = await prisma.user.findUnique({
      where: { email: ownerEmail },
      select: { id: true },
    });
    const owner = existing
      ? await prisma.user.update({
          where: { id: existing.id },
          data: {
            name: process.env.INITIAL_SUPER_ADMIN_NAME ?? "Dr. Kawsar Ahmed",
            passwordHash: await hashPassword(ownerPassword),
            passwordChangedAt: now,
            isSuperAdmin: true,
            status: "ACTIVE",
            emailVerifiedAt: now,
          },
        })
      : await prisma.user.create({
          data: {
            name: process.env.INITIAL_SUPER_ADMIN_NAME ?? "Dr. Kawsar Ahmed",
            email: ownerEmail,
            passwordHash: await hashPassword(ownerPassword),
            passwordChangedAt: now,
            emailVerifiedAt: now,
            isSuperAdmin: true,
            status: "ACTIVE",
          },
        });

    await prisma.userRole.upsert({
      where: {
        userId_roleId: { userId: owner.id, roleId: masterAdminRole.id },
      },
      update: { dataScope: "ALL" },
      create: {
        userId: owner.id,
        roleId: masterAdminRole.id,
        dataScope: "ALL",
      },
    });
  }

  const memberEmailRaw = process.env.INITIAL_MEMBER_EMAIL;
  const memberPassword = process.env.INITIAL_MEMBER_PASSWORD;
  if (memberEmailRaw && memberPassword) {
    const memberEmail = normalizeEmail(memberEmailRaw);
    const memberPhone = process.env.INITIAL_MEMBER_PHONE
      ? normalizePhone(process.env.INITIAL_MEMBER_PHONE)
      : null;
    const existing = await prisma.user.findUnique({
      where: { email: memberEmail },
      select: { id: true },
    });
    const member = existing
      ? await prisma.user.update({
          where: { id: existing.id },
          data: {
            name: process.env.INITIAL_MEMBER_NAME ?? "Holy Life Member",
            status: "ACTIVE",
            emailVerifiedAt: now,
            phone: memberPhone,
            phoneVerifiedAt: memberPhone ? now : null,
          },
        })
      : await prisma.user.create({
          data: {
            name: process.env.INITIAL_MEMBER_NAME ?? "Holy Life Member",
            email: memberEmail,
            phone: memberPhone,
            passwordHash: await hashPassword(memberPassword),
            passwordChangedAt: now,
            emailVerifiedAt: now,
            phoneVerifiedAt: memberPhone ? now : null,
            status: "ACTIVE",
          },
        });

    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: member.id, roleId: memberRole.id } },
      update: { dataScope: "OWN" },
      create: { userId: member.id, roleId: memberRole.id, dataScope: "OWN" },
    });
  }
}

async function seedPhase7Learning(): Promise<void> {
  const categoryExisting = await prisma.courseCategory.findUnique({
    where: { slug: "healthy-living" },
  });
  const category = await prisma.courseCategory.upsert({
    where: { slug: "healthy-living" },
    update: {
      name: categoryExisting?.name ?? "Healthy Living",
      nameBn: categoryExisting?.nameBn ?? "স্বাস্থ্যকর জীবনযাপন",
      description:
        categoryExisting?.description ??
        "Practical wellness and lifestyle learning.",
      descriptionBn:
        categoryExisting?.descriptionBn ??
        "দৈনন্দিন সুস্থতা, খাবার, ঘুম ও চলাফেরা নিয়ে ব্যবহারিক শেখার বিষয়বস্তু।",
      isActive: categoryExisting?.isActive ?? true,
    },
    create: {
      name: "Healthy Living",
      nameBn: "স্বাস্থ্যকর জীবনযাপন",
      slug: "healthy-living",
      description: "Practical wellness and lifestyle learning.",
      descriptionBn:
        "দৈনন্দিন সুস্থতা, খাবার, ঘুম ও চলাফেরা নিয়ে ব্যবহারিক শেখার বিষয়বস্তু।",
      displayOrder: 10,
    },
  });

  const instructorExisting = await prisma.instructorProfile.findUnique({
    where: { slug: "holy-life-academy" },
  });
  const instructor = await prisma.instructorProfile.upsert({
    where: { slug: "holy-life-academy" },
    update: {
      name: instructorExisting?.name ?? "Holy Life Academy",
      nameBn: instructorExisting?.nameBn ?? "Holy Life Academy",
      title: instructorExisting?.title ?? "Health education team",
      titleBn: instructorExisting?.titleBn ?? "স্বাস্থ্যশিক্ষা টিম",
      bio:
        instructorExisting?.bio ??
        "A multidisciplinary learning team focused on practical and accessible health education.",
      bioBn:
        instructorExisting?.bioBn ??
        "সহজ ভাষায় ব্যবহারিক ও সবার নাগালে স্বাস্থ্যশিক্ষা পৌঁছে দেওয়ার জন্য কাজ করা Holy Life learning team।",
      expertise: instructorExisting?.expertise.length
        ? instructorExisting.expertise
        : ["Wellness", "Nutrition", "Healthy habits"],
      expertiseBn: instructorExisting?.expertiseBn.length
        ? instructorExisting.expertiseBn
        : ["সুস্থতা", "পুষ্টি", "স্বাস্থ্যকর অভ্যাস"],
      isActive: instructorExisting?.isActive ?? true,
    },
    create: {
      name: "Holy Life Academy",
      nameBn: "Holy Life Academy",
      slug: "holy-life-academy",
      title: "Health education team",
      titleBn: "স্বাস্থ্যশিক্ষা টিম",
      bio: "A multidisciplinary learning team focused on practical and accessible health education.",
      bioBn:
        "সহজ ভাষায় ব্যবহারিক ও সবার নাগালে স্বাস্থ্যশিক্ষা পৌঁছে দেওয়ার জন্য কাজ করা Holy Life learning team।",
      expertise: ["Wellness", "Nutrition", "Healthy habits"],
      expertiseBn: ["সুস্থতা", "পুষ্টি", "স্বাস্থ্যকর অভ্যাস"],
    },
  });

  const courseSeeds = [
    {
      slug: "healthy-habits-foundation",
      title: "Healthy Daily Habits",
      titleBn: "স্বাস্থ্যকর দৈনন্দিন অভ্যাস",
      shortDescription:
        "Build a realistic daily routine around sleep, food, movement, hydration and recovery.",
      shortDescriptionBn:
        "ঘুম, খাবার, চলাফেরা, পানি পান ও বিশ্রাম—এই পাঁচটি বিষয়ে বাস্তবসম্মত দৈনন্দিন রুটিন গড়ে তুলুন।",
      description:
        "A practical beginner course built around small actions, self-observation and sustainable routines rather than extreme plans.",
      descriptionBn:
        "অতিরিক্ত কঠিন পরিকল্পনার বদলে ছোট ছোট কাজ, নিজের অভ্যাস পর্যবেক্ষণ এবং দীর্ঘমেয়াদি রুটিন তৈরির ওপর ভিত্তি করে সাজানো প্রাথমিক কোর্স।",
      outcomes: [
        "Create a sustainable daily health routine",
        "Recognize the connection between sleep, meals, movement and recovery",
        "Build a simple weekly habit plan",
      ],
      outcomesBn: [
        "টেকসই দৈনন্দিন স্বাস্থ্যরুটিন তৈরি করা",
        "ঘুম, খাবার, চলাফেরা ও বিশ্রামের পারস্পরিক সম্পর্ক বোঝা",
        "সহজ সাপ্তাহিক habit plan তৈরি করা",
      ],
      requirements: [
        "No prior health education required",
        "A notebook or simple habit tracker is helpful",
      ],
      requirementsBn: [
        "আগে থেকে স্বাস্থ্যবিষয়ক পড়াশোনা প্রয়োজন নেই",
        "একটি নোটবুক বা সহজ habit tracker থাকলে সুবিধা হবে",
      ],
      thumbnailUrl:
        "https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=1600&q=80",
      estimatedMinutes: 75,
      displayOrder: 10,
      modules: [
        {
          title: "Start with your current routine",
          titleBn: "বর্তমান রুটিন থেকে শুরু করুন",
          description: "Observe first, then choose small improvements.",
          descriptionBn: "আগে নিজের অভ্যাস দেখুন, তারপর ছোট পরিবর্তন বেছে নিন।",
          lessons: [
            {
              slug: "your-health-baseline",
              title: "Your health baseline",
              titleBn: "আপনার বর্তমান স্বাস্থ্যরুটিন",
              type: "ARTICLE",
              summary: "Create a simple snapshot of your current habits.",
              summaryBn:
                "ঘুম, খাবার, পানি ও চলাফেরার বর্তমান চিত্র লিখে রাখুন।",
              content:
                "Observe your routine for three days without trying to be perfect. Record sleep, water, meals, movement and recovery, then choose one improvement that feels realistic.",
              contentBn:
                "তিন দিন কোনো কিছু নিখুঁত করার চেষ্টা না করে আপনার রুটিন লক্ষ্য করুন। ঘুম, পানি, খাবার, চলাফেরা ও বিশ্রাম লিখে রাখুন। এরপর এমন একটি ছোট পরিবর্তন বেছে নিন যা নিয়মিত করা সম্ভব।",
              durationMinutes: 15,
              isPreview: true,
            },
            {
              slug: "four-daily-pillars",
              title: "Four daily foundations",
              titleBn: "দৈনন্দিন সুস্থতার চার ভিত্তি",
              type: "VIDEO",
              summary: "Sleep, food, movement and recovery work together.",
              summaryBn: "ঘুম, খাবার, চলাফেরা ও বিশ্রাম একসঙ্গে কাজ করে।",
              content:
                "Consistency matters more than a perfect day. Build routines that can survive a busy schedule and review them each week.",
              contentBn:
                "একটি নিখুঁত দিনের চেয়ে নিয়মিততা বেশি গুরুত্বপূর্ণ। ব্যস্ত দিনেও করা যায় এমন রুটিন তৈরি করুন এবং প্রতি সপ্তাহে তা পর্যালোচনা করুন।",
              durationMinutes: 20,
              isPreview: false,
            },
          ],
        },
        {
          title: "Build a simple weekly plan",
          titleBn: "সহজ সাপ্তাহিক পরিকল্পনা তৈরি করুন",
          description: "Turn your observations into repeatable actions.",
          descriptionBn:
            "নিজের পর্যবেক্ষণকে নিয়মিত করা যায় এমন ছোট কাজে রূপ দিন।",
          lessons: [
            {
              slug: "seven-day-plan",
              title: "Design a seven-day plan",
              titleBn: "সাত দিনের পরিকল্পনা করুন",
              type: "ARTICLE",
              summary: "Choose actions that fit your actual schedule.",
              summaryBn: "নিজের বাস্তব সময়সূচির সঙ্গে মানানসই কাজ বেছে নিন।",
              content:
                "Choose one action for sleep, one for meals and one for movement. Keep each action small enough to complete on a busy day.",
              contentBn:
                "ঘুম, খাবার এবং চলাফেরার জন্য একটি করে কাজ বেছে নিন। প্রতিটি কাজ এত ছোট রাখুন যেন ব্যস্ত দিনেও শেষ করা যায়।",
              durationMinutes: 20,
              isPreview: false,
            },
          ],
        },
      ],
    },
    {
      slug: "balanced-meal-basics",
      title: "Balanced Meal Basics",
      titleBn: "সুষম খাবারের ভিত্তি",
      shortDescription:
        "Learn a simple plate-building method for everyday meals without complicated rules.",
      shortDescriptionBn:
        "জটিল নিয়ম ছাড়াই প্রতিদিনের খাবার সাজানোর সহজ plate method শিখুন।",
      description:
        "An introductory nutrition course covering meal structure, portions, hydration and practical grocery decisions for everyday life.",
      descriptionBn:
        "দৈনন্দিন জীবনের জন্য meal structure, portion, পানি পান এবং বাস্তবসম্মত বাজার পরিকল্পনা নিয়ে পরিচিতিমূলক nutrition course।",
      outcomes: [
        "Build a balanced everyday plate",
        "Plan practical meals for a busy week",
        "Read basic food information more confidently",
      ],
      outcomesBn: [
        "প্রতিদিনের জন্য সুষম plate সাজানো",
        "ব্যস্ত সপ্তাহের জন্য ব্যবহারিক meal plan করা",
        "খাবারের মৌলিক তথ্য আরও আত্মবিশ্বাসের সঙ্গে বোঝা",
      ],
      requirements: ["No nutrition background required"],
      requirementsBn: ["পুষ্টিবিদ্যা সম্পর্কে আগে থেকে ধারণা থাকা প্রয়োজন নেই"],
      thumbnailUrl:
        "https://images.unsplash.com/photo-1539279006849-35e5504ce752?auto=format&fit=crop&w=1600&q=80",
      estimatedMinutes: 55,
      displayOrder: 20,
      modules: [
        {
          title: "Build the plate",
          titleBn: "প্লেট সাজানোর ভিত্তি",
          description: "Use a simple visual method for everyday meals.",
          descriptionBn:
            "প্রতিদিনের খাবারের জন্য সহজ visual method ব্যবহার করুন।",
          lessons: [
            {
              slug: "balanced-plate-method",
              title: "The balanced plate method",
              titleBn: "সুষম প্লেট পদ্ধতি",
              type: "ARTICLE",
              summary: "Use food groups to create a practical meal.",
              summaryBn: "বিভিন্ন food group মিলিয়ে ব্যবহারিক meal তৈরি করুন।",
              content:
                "Start with vegetables or fruit, add a protein source, include a suitable whole-grain or other carbohydrate source, and adjust portions to your needs and guidance.",
              contentBn:
                "সবজি বা ফল দিয়ে শুরু করুন, একটি protein source যোগ করুন, উপযুক্ত whole-grain বা অন্য carbohydrate source রাখুন এবং নিজের প্রয়োজন ও পেশাদার পরামর্শ অনুযায়ী portion ঠিক করুন।",
              durationMinutes: 18,
              isPreview: true,
            },
            {
              slug: "meal-planning-shopping",
              title: "Meal planning and shopping",
              titleBn: "Meal planning ও বাজার",
              type: "ARTICLE",
              summary:
                "Reduce last-minute food decisions with a short weekly plan.",
              summaryBn:
                "ছোট সাপ্তাহিক পরিকল্পনা দিয়ে শেষ মুহূর্তের খাবারের সিদ্ধান্ত কমান।",
              content:
                "Choose a few repeatable breakfasts, lunches and dinners, then build a grocery list around those meals before shopping.",
              contentBn:
                "কয়েকটি সহজ breakfast, lunch ও dinner বেছে নিন। এরপর বাজারে যাওয়ার আগে সেই meal-গুলোর ভিত্তিতে grocery list তৈরি করুন।",
              durationMinutes: 17,
              isPreview: false,
            },
          ],
        },
      ],
    },
    {
      slug: "safe-home-movement",
      title: "Safe Home Movement",
      titleBn: "নিরাপদ ঘরোয়া ব্যায়ামের ভিত্তি",
      shortDescription:
        "Understand warm-up, progression and recovery principles for a safer home movement routine.",
      shortDescriptionBn:
        "ঘরে ব্যায়ামের আগে warm-up, ধীরে ধীরে progression এবং recovery-এর মৌলিক নিয়ম বুঝুন।",
      description:
        "A general education course for building a sensible home movement routine. It does not replace individualized medical or rehabilitation advice.",
      descriptionBn:
        "বাড়িতে নিরাপদ ও বাস্তবসম্মত movement routine তৈরির সাধারণ শিক্ষা। ব্যক্তিগত চিকিৎসা বা rehabilitation advice-এর বিকল্প নয়।",
      outcomes: [
        "Prepare for exercise with a simple warm-up",
        "Progress volume gradually",
        "Recognize when to stop and seek professional guidance",
      ],
      outcomesBn: [
        "সহজ warm-up দিয়ে ব্যায়ামের প্রস্তুতি নেওয়া",
        "ধীরে ধীরে exercise volume বাড়ানো",
        "কখন থামতে হবে এবং পেশাদার পরামর্শ নিতে হবে তা বোঝা",
      ],
      requirements: [
        "A clear, safe exercise space",
        "Follow clinician guidance if you have a medical condition or injury",
      ],
      requirementsBn: [
        "নিরাপদ ও খালি exercise space",
        "কোনো শারীরিক সমস্যা বা injury থাকলে চিকিৎসকের নির্দেশনা অনুসরণ করুন",
      ],
      thumbnailUrl:
        "https://images.unsplash.com/photo-1767404890803-228d5390fcd4?auto=format&fit=crop&w=1600&q=80",
      estimatedMinutes: 60,
      displayOrder: 30,
      modules: [
        {
          title: "Move with control",
          titleBn: "নিয়ন্ত্রিতভাবে নড়াচড়া করুন",
          description: "Start easy and build gradually.",
          descriptionBn: "সহজভাবে শুরু করুন এবং ধীরে ধীরে বাড়ান।",
          lessons: [
            {
              slug: "warm-up-basics",
              title: "Warm-up basics",
              titleBn: "Warm-up-এর ভিত্তি",
              type: "VIDEO",
              summary:
                "Prepare joints, breathing and movement before harder effort.",
              summaryBn:
                "কঠিন ব্যায়ামের আগে joints, breathing ও movement প্রস্তুত করুন।",
              content:
                "Begin with comfortable movement and gradually increase range and pace. Stop if you experience concerning pain, dizziness or other unusual symptoms.",
              contentBn:
                "আরামদায়ক নড়াচড়া দিয়ে শুরু করে ধীরে ধীরে range ও pace বাড়ান। উদ্বেগজনক ব্যথা, মাথা ঘোরা বা অস্বাভাবিক উপসর্গ হলে থামুন।",
              durationMinutes: 15,
              isPreview: true,
            },
            {
              slug: "progress-and-recovery",
              title: "Progress and recovery",
              titleBn: "Progression ও recovery",
              type: "ARTICLE",
              summary:
                "More is not always better; recovery supports consistency.",
              summaryBn:
                "সবসময় বেশি করাই ভালো নয়; recovery নিয়মিততা বজায় রাখতে সাহায্য করে।",
              content:
                "Increase one variable at a time, keep easy days in the week, and prioritize sleep, hydration and appropriate recovery between harder sessions.",
              contentBn:
                "একবারে একটি বিষয় বাড়ান, সপ্তাহে easy day রাখুন এবং কঠিন session-এর মাঝে ঘুম, পানি ও প্রয়োজনীয় recovery-কে গুরুত্ব দিন।",
              durationMinutes: 18,
              isPreview: false,
            },
          ],
        },
      ],
    },
  ];

  for (const item of courseSeeds) {
    const existing = await prisma.course.findUnique({
      where: { slug: item.slug },
    });
    const course = existing
      ? await prisma.course.update({
          where: { id: existing.id },
          data: {
            categoryId: category.id,
            instructorId: instructor.id,
            titleBn: existing.titleBn ?? item.titleBn,
            shortDescriptionBn:
              existing.shortDescriptionBn ?? item.shortDescriptionBn,
            descriptionBn: existing.descriptionBn ?? item.descriptionBn,
            learningOutcomesBn: existing.learningOutcomesBn.length
              ? existing.learningOutcomesBn
              : item.outcomesBn,
            requirementsBn: existing.requirementsBn.length
              ? existing.requirementsBn
              : item.requirementsBn,
            thumbnailUrl: existing.thumbnailUrl ?? item.thumbnailUrl,
            status: existing.status === "DRAFT" ? "PUBLISHED" : existing.status,
            publishedAt: existing.publishedAt ?? new Date(),
          },
        })
      : await prisma.course.create({
          data: {
            categoryId: category.id,
            instructorId: instructor.id,
            title: item.title,
            titleBn: item.titleBn,
            slug: item.slug,
            shortDescription: item.shortDescription,
            shortDescriptionBn: item.shortDescriptionBn,
            description: item.description,
            descriptionBn: item.descriptionBn,
            learningOutcomes: item.outcomes,
            learningOutcomesBn: item.outcomesBn,
            requirements: item.requirements,
            requirementsBn: item.requirementsBn,
            level: "BEGINNER",
            status: "PUBLISHED",
            language: "Bangla",
            thumbnailUrl: item.thumbnailUrl,
            price: 0,
            isFeatured: item.displayOrder === 10,
            certificateEnabled: true,
            estimatedMinutes: item.estimatedMinutes,
            publishedAt: new Date(),
            displayOrder: item.displayOrder,
          },
        });

    for (const [moduleIndex, moduleSeed] of item.modules.entries()) {
      const position = moduleIndex + 1;
      const courseModule = await prisma.courseModule.upsert({
        where: { courseId_position: { courseId: course.id, position } },
        update: { isPublished: true },
        create: {
          courseId: course.id,
          title: moduleSeed.title,
          titleBn: moduleSeed.titleBn,
          description: moduleSeed.description,
          descriptionBn: moduleSeed.descriptionBn,
          position,
          isPublished: true,
        },
      });
      const existingModule = await prisma.courseModule.findUnique({
        where: { id: courseModule.id },
      });
      if (
        existingModule &&
        (!existingModule.titleBn || !existingModule.descriptionBn)
      ) {
        await prisma.courseModule.update({
          where: { id: courseModule.id },
          data: {
            titleBn: existingModule.titleBn ?? moduleSeed.titleBn,
            descriptionBn:
              existingModule.descriptionBn ?? moduleSeed.descriptionBn,
            isPublished: true,
          },
        });
      }

      const occupiedLessonPositions = new Set(
        (
          await prisma.courseLesson.findMany({
            where: { moduleId: courseModule.id },
            select: { position: true },
          })
        ).map((lesson) => lesson.position),
      );

      for (const [lessonIndex, lessonSeed] of moduleSeed.lessons.entries()) {
        const lessonPosition = lessonIndex + 1;
        const existingLesson = await prisma.courseLesson.findUnique({
          where: {
            moduleId_slug: {
              moduleId: courseModule.id,
              slug: lessonSeed.slug,
            },
          },
        });

        if (existingLesson) {
          await prisma.courseLesson.update({
            where: { id: existingLesson.id },
            data: {
              titleBn: existingLesson.titleBn ?? lessonSeed.titleBn,
              summaryBn: existingLesson.summaryBn ?? lessonSeed.summaryBn,
              contentBn: existingLesson.contentBn ?? lessonSeed.contentBn,
              isPublished: true,
            },
          });
          continue;
        }

        const resolvedLessonPosition = resolveSeedPosition(
          lessonPosition,
          occupiedLessonPositions,
        );

        const createdLesson = await prisma.courseLesson.create({
          data: {
            moduleId: courseModule.id,
            title: lessonSeed.title,
            titleBn: lessonSeed.titleBn,
            slug: lessonSeed.slug,
            type: lessonSeed.type as "ARTICLE" | "VIDEO",
            summary: lessonSeed.summary,
            summaryBn: lessonSeed.summaryBn,
            content: lessonSeed.content,
            contentBn: lessonSeed.contentBn,
            durationMinutes: lessonSeed.durationMinutes,
            position: resolvedLessonPosition,
            isPreview: lessonSeed.isPreview,
            isPublished: true,
          },
        });

        occupiedLessonPositions.add(createdLesson.position);
      }
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "phase7.learning.seed-version" },
    update: {
      value: { version: 2, checkedAt: new Date().toISOString(), courses: 3 },
    },
    create: {
      key: "phase7.learning.seed-version",
      value: { version: 2, appliedAt: new Date().toISOString(), courses: 3 },
    },
  });
}

async function seedPhase8Dashboard(): Promise<void> {
  await prisma.systemSetting.upsert({
    where: { key: "phase8.dashboard.seed-version" },
    update: { value: { version: 1, appliedAt: new Date().toISOString() } },
    create: {
      key: "phase8.dashboard.seed-version",
      value: {
        version: 1,
        appliedAt: new Date().toISOString(),
        features: [
          "notifications",
          "saved-items",
          "unified-activity",
          "address-book",
        ],
      },
    },
  });

  const memberEmailRaw = process.env.INITIAL_MEMBER_EMAIL;
  if (!memberEmailRaw) return;

  const member = await prisma.user.findUnique({
    where: { email: normalizeEmail(memberEmailRaw) },
    select: { id: true },
  });
  if (!member) return;

  await prisma.dashboardNotification.upsert({
    where: {
      userId_dedupeKey: {
        userId: member.id,
        dedupeKey: "phase8:welcome",
      },
    },
    update: {
      kind: "INFO",
      department: "SYSTEM",
      title: "Your unified dashboard is ready",
      message:
        "Appointments, orders, courses, payments, and saved items now share one workspace.",
      href: "/dashboard",
    },
    create: {
      userId: member.id,
      dedupeKey: "phase8:welcome",
      kind: "INFO",
      department: "SYSTEM",
      title: "Your unified dashboard is ready",
      message:
        "Appointments, orders, courses, payments, and saved items now share one workspace.",
      href: "/dashboard",
    },
  });
}

async function seedPhase9Finance(): Promise<void> {
  const phase9PermissionKeys = [
    "system.finance.payment.view",
    "system.finance.payment.record",
    "system.finance.payment.verify",
    "system.finance.payment.refund",
    "system.reports.financial-report.view",
    "system.reports.financial-report.export",
    "system.notifications.notification.manage",
  ];

  const masterAdmin = await prisma.role.findUnique({
    where: { code: "MASTER_ADMIN" },
    select: { id: true },
  });

  if (masterAdmin) {
    const permissions = await prisma.permission.findMany({
      where: { key: { in: phase9PermissionKeys } },
      select: { id: true },
    });

    for (const permission of permissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: masterAdmin.id,
            permissionId: permission.id,
          },
        },
        update: { allowed: true },
        create: {
          roleId: masterAdmin.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "phase9.finance.seed-version" },
    update: {
      value: {
        version: 1,
        mode: "LOCAL_MANUAL_ONLY",
        appliedAt: new Date().toISOString(),
        externalPaymentGateway: false,
        externalEmail: false,
        externalSms: false,
        externalPush: false,
      },
    },
    create: {
      key: "phase9.finance.seed-version",
      value: {
        version: 1,
        mode: "LOCAL_MANUAL_ONLY",
        appliedAt: new Date().toISOString(),
        externalPaymentGateway: false,
        externalEmail: false,
        externalSms: false,
        externalPush: false,
      },
    },
  });
}

async function seedPhase10Messaging(): Promise<void> {
  const phase10PermissionKeys = [
    "system.messaging.template.view",
    "system.messaging.template.manage",
    "system.messaging.campaign.view",
    "system.messaging.campaign.send",
    "system.messaging.campaign.cancel",
    "system.messaging.delivery.view",
    "system.messaging.delivery.retry",
  ];

  const masterAdmin = await prisma.role.findUnique({
    where: { code: "MASTER_ADMIN" },
    select: { id: true },
  });
  if (masterAdmin) {
    const permissions = await prisma.permission.findMany({
      where: { key: { in: phase10PermissionKeys } },
      select: { id: true },
    });
    for (const permission of permissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: masterAdmin.id,
            permissionId: permission.id,
          },
        },
        update: { allowed: true },
        create: {
          roleId: masterAdmin.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }
  }

  await prisma.systemSetting.upsert({
    where: { key: "phase10.messaging.seed-version" },
    update: {
      value: {
        version: 1,
        architecture: "DB_OUTBOX_SIGNED_WEBHOOK",
        providerNeutral: true,
        externalMessagingDefault: "DISABLED",
        marketingRequiresOptIn: true,
        appliedAt: new Date().toISOString(),
      },
    },
    create: {
      key: "phase10.messaging.seed-version",
      value: {
        version: 1,
        architecture: "DB_OUTBOX_SIGNED_WEBHOOK",
        providerNeutral: true,
        externalMessagingDefault: "DISABLED",
        marketingRequiresOptIn: true,
        appliedAt: new Date().toISOString(),
      },
    },
  });
}

async function main(): Promise<void> {
  await seedPermissionsAndRoles();
  await seedNavigation();
  await seedSiteConfiguration();
  await seedPhase4WebsiteCms();
  await seedAuthUsers();
  await seedPhase5Healthcare();
  await seedPhase6Commerce();
  await seedPhase7Learning();
  await seedPhase8Dashboard();
  await seedPhase9Finance();
  await seedPhase10Messaging();
}

main()
  .catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
