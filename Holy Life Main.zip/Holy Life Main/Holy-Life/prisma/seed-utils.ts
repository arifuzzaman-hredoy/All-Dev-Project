export function resolveSeedPosition(
  preferredPosition: number,
  occupiedPositions: ReadonlySet<number>,
): number {
  let candidate =
    Number.isInteger(preferredPosition) && preferredPosition > 0
      ? preferredPosition
      : 1;

  while (occupiedPositions.has(candidate)) {
    candidate += 1;
  }

  return candidate;
}
