param(
    [string] $VpsHost = "198.54.121.88",
    [string] $Domain = "holylife.techteamlead.com",
    [int] $SshPort = 22
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Downloads = Join-Path $HOME "Downloads"
$OpsKey = Join-Path $HOME ".ssh\holy_life_ops_ed25519"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$ReportPath = Join-Path $Downloads "Holy-Life-Local-Only-Hardening-Report-$Timestamp.txt"
$Bundle = Join-Path $env:TEMP "holy-life-local-only-ops-$Timestamp.tar.gz"

function Invoke-Checked {
    param(
        [Parameter(Mandatory)] [scriptblock] $Command,
        [Parameter(Mandatory)] [string] $Message
    )

    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Message (exit $LASTEXITCODE)"
    }
}

function Write-Step {
    param([Parameter(Mandatory)] [string] $Text)

    Write-Host ""
    Write-Host "=== $Text ===" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HOLY LIFE LOCAL-ONLY OPERATIONS COMPLETION" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "R2/S3, off-site backup, restore testing, Telegram, SMTP," -ForegroundColor Yellow
Write-Host "HCP Terraform, and automatic SSH lock are skipped." -ForegroundColor Yellow

if (-not (Test-Path -LiteralPath $OpsKey)) {
    throw "Operations SSH key পাওয়া যায়নি: $OpsKey"
}

$RequiredFiles = @(
    "ops\monitor\holy-life-monitor.sh",
    "ops\monitor\send-alert.py",
    "ops\logs\collect-diagnostics.sh",
    "ops\systemd\holy-life-monitor.service",
    "ops\systemd\holy-life-monitor.timer",
    "ops\systemd\holy-life-diagnostics.service",
    "ops\systemd\holy-life-diagnostics.timer"
)

foreach ($RelativePath in $RequiredFiles) {
    $FullPath = Join-Path $ProjectRoot $RelativePath
    if (-not (Test-Path -LiteralPath $FullPath)) {
        throw "Required operations file missing: $RelativePath"
    }
}

Write-Step "VERIFY EXISTING HOLYOPS KEY ACCESS"
Invoke-Checked -Message "holyops passwordless SSH/sudo access failed" -Command {
    ssh.exe `
        -i $OpsKey `
        -p $SshPort `
        -o BatchMode=yes `
        -o StrictHostKeyChecking=accept-new `
        "holyops@$VpsHost" `
        "whoami && sudo -n true && docker version --format '{{.Server.Version}}'"
}

Write-Step "UPLOAD UPDATED LOCAL-ONLY OPERATIONS FILES"
Push-Location $ProjectRoot
try {
    if (Test-Path -LiteralPath $Bundle) {
        Remove-Item -LiteralPath $Bundle -Force
    }

    Invoke-Checked -Message "Operations bundle creation failed" -Command {
        tar.exe -czf $Bundle ops
    }
}
finally {
    Pop-Location
}

Invoke-Checked -Message "Operations bundle upload failed" -Command {
    scp.exe `
        -i $OpsKey `
        -P $SshPort `
        -o BatchMode=yes `
        -o StrictHostKeyChecking=accept-new `
        $Bundle `
        "holyops@${VpsHost}:/tmp/holy-life-local-only-ops.tar.gz"
}

$OpsValues = [ordered]@{
    APP_DOMAIN = $Domain
    HEALTH_URL = "https://$Domain/api/health"
    CHECK_OFFSITE_BACKUP = "false"
    CHECK_RESTORE_TEST = "false"
    DISK_WARN_PERCENT = "85"
    MEMORY_WARN_PERCENT = "90"
    LOAD_WARN_MULTIPLIER = "2"
    TELEGRAM_BOT_TOKEN = ""
    TELEGRAM_CHAT_ID = ""
    ALERT_SMTP_HOST = ""
    ALERT_SMTP_PORT = "587"
    ALERT_SMTP_USER = ""
    ALERT_SMTP_PASSWORD = ""
    ALERT_EMAIL_TO = ""
    ALERT_EMAIL_FROM = ""
    ALERT_SMTP_STARTTLS = "true"
    ALERT_SMTP_SSL = "false"
}

$OpsJson = $OpsValues | ConvertTo-Json -Compress
$OpsB64 = [Convert]::ToBase64String(
    [Text.Encoding]::UTF8.GetBytes($OpsJson)
)

$RemoteScript = @'
#!/usr/bin/env bash
set -Eeuo pipefail

cleanup() {
  rm -f \
    /tmp/holy-life-local-only-ops.tar.gz \
    /tmp/holy-life-local-only-ops.json \
    /tmp/holy-life-configure-local-only.sh
}
trap cleanup EXIT

sudo install -d -m 700 /etc/holy-life /var/lib/holy-life-ops
sudo tar -xzf /tmp/holy-life-local-only-ops.tar.gz -C /opt/holy-life
sudo find /opt/holy-life/ops -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod +x {} +
sudo chown -R holydeploy:holydeploy /opt/holy-life/ops

printf '%s' '__OPS_B64__' | base64 -d > /tmp/holy-life-local-only-ops.json
sudo python3 -c 'import json,shlex; d=json.load(open("/tmp/holy-life-local-only-ops.json", encoding="utf-8")); open("/etc/holy-life/ops.env","w",encoding="utf-8").write("".join(f"{k}={shlex.quote(str(v))}\n" for k,v in d.items()))'
sudo chmod 600 /etc/holy-life/ops.env

sudo systemctl disable --now \
  holy-life-offsite-backup.timer \
  holy-life-restore-test.timer \
  holy-life-offsite-backup.service \
  holy-life-restore-test.service 2>/dev/null || true

for unit in \
  holy-life-monitor.service \
  holy-life-monitor.timer \
  holy-life-diagnostics.service \
  holy-life-diagnostics.timer; do
  sudo install -m 644 \
    "/opt/holy-life/ops/systemd/$unit" \
    "/etc/systemd/system/$unit"
done

sudo install -d \
  -o root \
  -g root \
  -m 700 \
  /opt/holy-life/diagnostics

sudo systemctl daemon-reload
sudo systemctl reset-failed \
  holy-life-monitor.service \
  holy-life-diagnostics.service 2>/dev/null || true
sudo systemctl enable --now \
  holy-life-monitor.timer \
  holy-life-diagnostics.timer

sudo systemctl start holy-life-monitor.service
sudo systemctl start holy-life-diagnostics.service

monitor_result="$(sudo systemctl show \
  holy-life-monitor.service \
  --property=Result \
  --value)"
diagnostics_result="$(sudo systemctl show \
  holy-life-diagnostics.service \
  --property=Result \
  --value)"

if [[ "$monitor_result" != "success" ]]; then
  echo "Holy Life monitor service result: $monitor_result" >&2
  sudo systemctl status holy-life-monitor.service --no-pager >&2 || true
  exit 1
fi

if [[ "$diagnostics_result" != "success" ]]; then
  echo "Holy Life diagnostics service result: $diagnostics_result" >&2
  sudo systemctl status holy-life-diagnostics.service --no-pager >&2 || true
  exit 1
fi

latest_diagnostics="$(sudo find \
  /opt/holy-life/diagnostics \
  -maxdepth 1 \
  -type f \
  -name 'holy-life-diagnostics-*.txt' \
  -printf '%T@ %p\n' | sort -n | tail -n 1 | cut -d' ' -f2-)"

if [[ -z "$latest_diagnostics" ]]; then
  echo "Diagnostics service reported success but no diagnostics file was created." >&2
  exit 1
fi

sudo systemctl is-enabled \
  holy-life-monitor.timer \
  holy-life-diagnostics.timer
sudo systemctl is-active \
  holy-life-monitor.timer \
  holy-life-diagnostics.timer
printf 'Latest diagnostics: %s\n' "$latest_diagnostics"

echo
echo '--- ACTIVE SECURITY SERVICES ---'
for service in fail2ban unattended-upgrades auditd; do
  printf '%s: enabled=%s active=%s\n' \
    "$service" \
    "$(sudo systemctl is-enabled "$service" 2>/dev/null || true)" \
    "$(sudo systemctl is-active "$service" 2>/dev/null || true)"
done

echo
echo '--- ACTIVE LOCAL OPERATIONS TIMERS ---'
sudo systemctl list-timers \
  holy-life-monitor.timer \
  holy-life-diagnostics.timer \
  --all \
  --no-pager

echo
echo '--- MONITOR AND DIAGNOSTICS LOGS ---'
sudo journalctl \
  -u holy-life-monitor.service \
  -u holy-life-diagnostics.service \
  -n 120 \
  --no-pager || true

echo
echo '--- FIREWALL ---'
sudo ufw status
'@

$RemoteScript = $RemoteScript.Replace("__OPS_B64__", $OpsB64)
$RemoteScript = $RemoteScript.Replace("`r`n", "`n").Replace("`r", "`n")
$RemoteScriptPath = Join-Path $env:TEMP "holy-life-configure-local-only-$Timestamp.sh"
[IO.File]::WriteAllText(
    $RemoteScriptPath,
    $RemoteScript,
    [Text.UTF8Encoding]::new($false)
)

Invoke-Checked -Message "Remote configuration script upload failed" -Command {
    scp.exe `
        -i $OpsKey `
        -P $SshPort `
        -o BatchMode=yes `
        -o StrictHostKeyChecking=accept-new `
        $RemoteScriptPath `
        "holyops@${VpsHost}:/tmp/holy-life-configure-local-only.sh"
}


Write-Step "CONFIGURE LOCAL MONITORING AND DIAGNOSTICS"
Invoke-Checked -Message "Local-only operations setup failed" -Command {
    ssh.exe `
        -i $OpsKey `
        -p $SshPort `
        -o BatchMode=yes `
        "holyops@$VpsHost" `
        "bash /tmp/holy-life-configure-local-only.sh"
}

Write-Step "VERIFY LIVE HEALTH"
Invoke-Checked -Message "Live health endpoint failed" -Command {
    curl.exe `
        --fail `
        --silent `
        --show-error `
        --max-time 20 `
        "https://$Domain/api/health"
}

$Report = @"
Holy Life local-only production operations
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
Domain: https://$Domain
Health: https://$Domain/api/health
VPS: $VpsHost

Enabled:
- Existing holyops SSH key access
- Fail2ban
- UFW firewall and SSH rate limiting
- Unattended security updates
- auditd
- Persistent journald retention
- Application/database/resource/TLS monitoring every 5 minutes
- Daily local diagnostics (verified file creation)
- CI container vulnerability scanning and SBOM
- Production deployment workflow and runbooks

Skipped by owner:
- R2/S3 off-site backup
- Automated off-site restore test
- Telegram alerts
- SMTP email alerts
- HCP Terraform remote state
- Automatic root/password SSH lock

Important:
- Monitoring alerts remain in systemd journal only.
- Backups remain on the VPS; a total VPS loss can also lose those backups.
- Root/password SSH login was not changed by this completion script.
"@

[IO.File]::WriteAllText(
    $ReportPath,
    $Report,
    [Text.UTF8Encoding]::new($false)
)

Remove-Item -LiteralPath $Bundle -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $RemoteScriptPath -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "LOCAL-ONLY HARDENING COMPLETED" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Live: https://$Domain" -ForegroundColor Green
Write-Host "Report: $ReportPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "External backup, remote alerts, HCP state, and SSH lock were skipped." -ForegroundColor Yellow
