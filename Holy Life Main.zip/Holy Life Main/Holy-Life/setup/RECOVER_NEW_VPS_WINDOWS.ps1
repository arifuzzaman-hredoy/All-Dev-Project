param(
    [string] $Repository = "techtemlead-lab/Holy_Life",
    [string] $OperationsCredentialFile = ""
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot

function Invoke-Checked([scriptblock] $Command, [string] $Message) {
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Message (exit $LASTEXITCODE)" }
}
function Read-CredentialValue([string] $Text, [string] $Label) {
    $match = [regex]::Match($Text, "(?m)^" + [regex]::Escape($Label) + ":\s*(.+)$")
    if (-not $match.Success) { throw "Missing '$Label' in operations credential file." }
    $match.Groups[1].Value.Trim()
}

Write-Host "HOLY LIFE DISASTER RECOVERY TO A NEW VPS" -ForegroundColor Cyan
Write-Host "This restores the latest verified off-site database and the saved immutable release." -ForegroundColor Yellow
$Confirmation = Read-Host "Type RECOVER_HOLY_LIFE to continue"
if ($Confirmation -ne "RECOVER_HOLY_LIFE") { throw "Recovery cancelled." }

if ([string]::IsNullOrWhiteSpace($OperationsCredentialFile)) {
    $OperationsCredentialFile = Read-Host "Path to encrypted-vault-exported Holy Life operations credentials file"
}
if (-not (Test-Path -LiteralPath $OperationsCredentialFile)) { throw "Credentials file not found." }
$Credentials = Get-Content $OperationsCredentialFile -Raw
$ResticRepository = Read-CredentialValue $Credentials "Restic repository"
$ResticPassword = Read-CredentialValue $Credentials "Restic password"
$AccessKey = Read-CredentialValue $Credentials "Object storage access key"
$SecretKey = Read-CredentialValue $Credentials "Object storage secret key"

$NewHost = Read-Host "New VPS public IP"
$Domain = Read-Host "Production domain to recover"
$RootUser = Read-Host "Initial administrator user (default: root)"
if ([string]::IsNullOrWhiteSpace($RootUser)) { $RootUser = "root" }
$PortText = Read-Host "SSH port (default: 22)"
$Port = if ([string]::IsNullOrWhiteSpace($PortText)) { 22 } else { [int]$PortText }

$KeyPath = Join-Path $HOME ".ssh\holy_life_disaster_recovery_ed25519"
if (-not (Test-Path $KeyPath)) {
    ssh-keygen.exe -t ed25519 -a 64 -N "" -C "holy-life-disaster-recovery" -f $KeyPath
    if ($LASTEXITCODE -ne 0) { throw "Recovery key generation failed." }
}
$PublicKeyB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((Get-Content "$KeyPath.pub" -Raw).Trim()))
$BootstrapB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((Get-Content (Join-Path $ProjectRoot "deploy\bootstrap-vps.sh") -Raw))
Invoke-Checked -Message "New VPS bootstrap failed" -Command {
    ssh.exe -o StrictHostKeyChecking=accept-new -p $Port "${RootUser}@${NewHost}" "printf '%s' '$BootstrapB64' | base64 -d | bash -s -- '$Domain' '$PublicKeyB64'"
}

$Bundle = Join-Path $env:TEMP "holy-life-recovery-bundle.tar.gz"
Push-Location $ProjectRoot
try { tar.exe -czf $Bundle compose.production.yml deploy ops }
finally { Pop-Location }
Invoke-Checked -Message "Recovery bundle upload failed" -Command {
    scp.exe -i $KeyPath -P $Port $Bundle "holydeploy@${NewHost}:/tmp/holy-life-recovery-bundle.tar.gz"
}

$OpsData = @{
    APP_DOMAIN = $Domain
    HEALTH_URL = "https://$Domain/api/health"
    RESTIC_REPOSITORY = $ResticRepository
    RESTIC_PASSWORD = $ResticPassword
    AWS_ACCESS_KEY_ID = $AccessKey
    AWS_SECRET_ACCESS_KEY = $SecretKey
    AWS_DEFAULT_REGION = "auto"
} | ConvertTo-Json -Compress
$OpsB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($OpsData))
$Token = gh auth token
if ([string]::IsNullOrWhiteSpace($Token)) { gh auth login --hostname github.com --web; $Token = gh auth token }
$TokenB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Token))
$GitHubUser = gh api user --jq .login

$Remote = @"
set -Eeuo pipefail
cd /opt/holy-life
tar -xzf /tmp/holy-life-recovery-bundle.tar.gz -C /opt/holy-life
find deploy ops -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod +x {} +
sudo env OPS_PUBLIC_KEY_B64='$PublicKeyB64' SSH_PORT='$Port' /opt/holy-life/ops/hardening/harden-vps.sh prepare
sudo install -d -m 700 /etc/holy-life
printf '%s' '$OpsB64' | base64 -d > /tmp/ops.json
sudo python3 -c 'import json,shlex; d=json.load(open("/tmp/ops.json")); open("/etc/holy-life/ops.env","w").write("".join(f"{k}={shlex.quote(str(v))}\\n" for k,v in d.items()))'
sudo chown root:holydeploy /etc/holy-life/ops.env
sudo chmod 640 /etc/holy-life/ops.env
set -a
source /etc/holy-life/ops.env
set +a
export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_DEFAULT_REGION
export AWS_REGION="$AWS_DEFAULT_REGION"
if ! restic dump latest release/.env.production --tag holy-life > .env.production 2>/dev/null; then
  restic dump latest /release/.env.production --tag holy-life > .env.production
fi
mkdir -p releases
if ! restic dump latest release/current.env --tag holy-life > releases/current.env 2>/dev/null; then
  restic dump latest /release/current.env --tag holy-life > releases/current.env
fi
chmod 600 .env.production releases/current.env
printf '%s' '$TokenB64' | base64 -d | docker login ghcr.io -u '$GitHubUser' --password-stdin
APP_IMAGE=`$(python3 deploy/read-dotenv.py releases/current.env HOLY_LIFE_IMAGE)
MIGRATOR_IMAGE=`$(python3 deploy/read-dotenv.py releases/current.env HOLY_LIFE_MIGRATOR_IMAGE)
python3 - .env.production "`$APP_IMAGE" "`$MIGRATOR_IMAGE" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); updates={'HOLY_LIFE_IMAGE':sys.argv[2],'HOLY_LIFE_MIGRATOR_IMAGE':sys.argv[3]}
lines=p.read_text().splitlines(); seen=set(); out=[]
for line in lines:
    key=line.split('=',1)[0].strip() if '=' in line else ''
    if key in updates: out.append(f'{key}={updates[key]}'); seen.add(key)
    else: out.append(line)
for key,value in updates.items():
    if key not in seen: out.append(f'{key}={value}')
p.write_text('\\n'.join(out)+'\\n')
PY
docker compose --env-file .env.production -f compose.production.yml pull db app
docker compose --env-file .env.production -f compose.production.yml up -d --wait db
sudo CONFIRM_RESTORE=YES_RESTORE_HOLY_LIFE /opt/holy-life/ops/backup/restore-latest.sh
sudo chown root:root /etc/holy-life/ops.env
sudo chmod 600 /etc/holy-life/ops.env
sudo /opt/holy-life/ops/install-operations.sh
rm -f /tmp/ops.json /tmp/holy-life-recovery-bundle.tar.gz
"@
Invoke-Checked -Message "Encrypted recovery/restore failed" -Command {
    ssh.exe -i $KeyPath -p $Port "holydeploy@$NewHost" $Remote
}
Invoke-Checked -Message "Recovered operations-user verification failed" -Command {
    ssh.exe -i $KeyPath -p $Port -o BatchMode=yes "holyops@$NewHost" "sudo -n true && echo RECOVERY_OPS_ACCESS_OK"
}
Invoke-Checked -Message "Recovered VPS SSH lock failed" -Command {
    ssh.exe -i $KeyPath -p $Port "holyops@$NewHost" "sudo SSH_PORT='$Port' /opt/holy-life/ops/hardening/harden-vps.sh lock"
}

try {
    $Resolved = (Resolve-DnsName $Domain -Type A -ErrorAction Stop | Where-Object IPAddress | Select-Object -ExpandProperty IPAddress)
}
catch { $Resolved = @() }
if ($Resolved -notcontains $NewHost) {
    Write-Warning "Recovery is healthy on the new VPS, but DNS still does not resolve to $NewHost. Update the A record through the DNS provider before final cutover."
}

Invoke-WebRequest -Uri "https://$Domain/api/health" -UseBasicParsing -TimeoutSec 20 | Out-Null
Write-Host "DISASTER RECOVERY COMPLETED" -ForegroundColor Green
Write-Host "Recovered release is running at https://$Domain" -ForegroundColor Green
