param(
    [string] $Repository = "techtemlead-lab/Holy_Life",
    [string] $VpsHost = "198.54.121.88",
    [string] $Domain = "holylife.techteamlead.com",
    [int] $SshPort = 22,
    [string] $RootUser = "root",
    [switch] $SkipGitPushAndCi
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Downloads = Join-Path $HOME "Downloads"
$ReportPath = Join-Path $Downloads ("Holy-Life-Phase4-Hardening-Report-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt")
$CredentialPath = Join-Path $Downloads ("Holy-Life-Operations-Credentials-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt")
$OpsKey = Join-Path $HOME ".ssh\holy_life_ops_ed25519"

function Invoke-Checked {
    param([Parameter(Mandatory)] [scriptblock] $Command, [Parameter(Mandatory)] [string] $Message)
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Message (exit $LASTEXITCODE)" }
}

function ConvertTo-PlainText([Security.SecureString] $Value) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function New-RandomSecret([int] $Bytes = 48) {
    $buffer = New-Object byte[] $Bytes
    [Security.Cryptography.RandomNumberGenerator]::Fill($buffer)
    [Convert]::ToBase64String($buffer).TrimEnd("=").Replace("+", "-").Replace("/", "_")
}

function Write-Step([string] $Text) {
    Write-Host ""
    Write-Host "=== $Text ===" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HOLY LIFE PHASE 4 + PRODUCTION DEVOPS HARDENING" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

& (Join-Path $PSScriptRoot "01_INSTALL_REQUIRED_TOOLS.ps1")

if (-not $SkipGitPushAndCi) {
    Write-Step "VERIFY GITHUB AUTHENTICATION"

    gh auth status --hostname github.com *> $null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "GitHub login is required once for commit, CI, and deployment." -ForegroundColor Yellow
        Invoke-Checked -Message "GitHub authentication failed" -Command {
            gh auth login --hostname github.com --web --git-protocol https
        }
    }

    Invoke-Checked -Message "Cannot access $Repository" -Command {
        gh repo view $Repository *> $null
    }
}
else {
    Write-Step "OPERATIONS-ONLY RESUME MODE"
    Write-Host "GitHub login, token refresh, commit, CI, image publishing, and demo deployment are skipped." -ForegroundColor Green
    Write-Host "The script will continue directly from VPS operations hardening." -ForegroundColor Green
}

if (-not $SkipGitPushAndCi) {
    Write-Step "COMMIT AND PUSH PHASE 4 + HARDENING"
    Push-Location $ProjectRoot
    try {
        git remote get-url origin *> $null
        if ($LASTEXITCODE -ne 0) { git remote add origin "https://github.com/$Repository.git" }
        git fetch origin main
        git add -A
        git diff --cached --quiet
        if ($LASTEXITCODE -ne 0) {
            git commit -m "feat: add Phase 4 CMS and production DevOps hardening"
        }
        $CommitSha = (git rev-parse HEAD).Trim()
        git push origin main
    }
    finally { Pop-Location }

    Write-Step "WAIT FOR CI, SECURITY SCAN, IMAGE PUBLISH, AND DEMO DEPLOY"
    $RunId = $null
    for ($attempt = 1; $attempt -le 30; $attempt++) {
        $json = gh run list --repo $Repository --commit $CommitSha --workflow "Holy Life CI and Demo Deployment" --limit 1 --json databaseId 2>$null
        if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($json) -and $json -ne "[]") {
            $RunId = ($json | ConvertFrom-Json)[0].databaseId
            break
        }
        Start-Sleep -Seconds 3
    }
    if (-not $RunId) { throw "Could not find the GitHub Actions run for $CommitSha." }
    Invoke-Checked -Message "Phase 4 CI/CD failed. Open GitHub Actions for run $RunId." -Command {
        gh run watch $RunId --repo $Repository --exit-status
    }
}
else {
    Push-Location $ProjectRoot
    try { $CommitSha = (git rev-parse HEAD).Trim() }
    finally { Pop-Location }
    $RunId = "skipped"
}

Write-Step "GENERATE OPERATIONS SSH KEY"
New-Item -ItemType Directory -Path (Split-Path $OpsKey -Parent) -Force | Out-Null
if (-not (Test-Path -LiteralPath $OpsKey)) {
    Invoke-Checked -Message "Operations SSH key generation failed" -Command {
        ssh-keygen.exe -t ed25519 -a 64 -N "" -C "holy-life-operations" -f $OpsKey
    }
}
$OpsPublicKey = (Get-Content "$OpsKey.pub" -Raw).Trim()
$OpsPublicKeyB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($OpsPublicKey))

Write-Step "UPLOAD OPERATIONS BUNDLE AND PREPARE HARDENING"
Write-Host "The existing VPS administrator password may be requested once." -ForegroundColor Yellow
$Bundle = Join-Path $env:TEMP "holy-life-ops-bundle.tar.gz"
Push-Location $ProjectRoot
try {
    tar.exe -czf $Bundle ops
}
finally { Pop-Location }
Invoke-Checked -Message "Operations bundle upload failed" -Command {
    scp.exe -P $SshPort -o StrictHostKeyChecking=accept-new $Bundle "${RootUser}@${VpsHost}:/tmp/holy-life-ops-bundle.tar.gz"
}
$PrepareCommand = @"
set -Eeuo pipefail
mkdir -p /opt/holy-life
tar -xzf /tmp/holy-life-ops-bundle.tar.gz -C /opt/holy-life
find /opt/holy-life/ops -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod +x {} +
OPS_PUBLIC_KEY_B64='$OpsPublicKeyB64' SSH_PORT='$SshPort' /opt/holy-life/ops/hardening/harden-vps.sh prepare
chown -R holydeploy:holydeploy /opt/holy-life/ops
rm -f /tmp/holy-life-ops-bundle.tar.gz
"@
Invoke-Checked -Message "VPS hardening preparation failed" -Command {
    ssh.exe -p $SshPort -o StrictHostKeyChecking=accept-new "${RootUser}@${VpsHost}" $PrepareCommand
}

Write-Step "VERIFY PASSWORDLESS OPERATIONS ACCESS"
Invoke-Checked -Message "holyops SSH/sudo verification failed; SSH lock was not applied" -Command {
    ssh.exe -i $OpsKey -p $SshPort -o BatchMode=yes -o StrictHostKeyChecking=accept-new "holyops@$VpsHost" "whoami && sudo -n true && docker version --format '{{.Server.Version}}'"
}

Write-Step "CONFIGURE ENCRYPTED OFF-SITE BACKUP"
$StorageType = Read-Host "Object storage type: R2 or S3 (default: R2)"
if ([string]::IsNullOrWhiteSpace($StorageType)) { $StorageType = "R2" }
$Endpoint = Read-Host "S3-compatible HTTPS endpoint (example: https://ACCOUNT_ID.r2.cloudflarestorage.com)"
$Bucket = Read-Host "Backup bucket name"
$Region = Read-Host "Region (R2 default: auto)"
if ([string]::IsNullOrWhiteSpace($Region)) { $Region = "auto" }
$AccessKey = Read-Host "Object storage access key ID"
$SecretKey = ConvertTo-PlainText (Read-Host "Object storage secret access key" -AsSecureString)
if (@($Endpoint, $Bucket, $AccessKey, $SecretKey) | Where-Object { [string]::IsNullOrWhiteSpace($_) }) {
    throw "Endpoint, bucket, access key, and secret key are required."
}
$RepositoryUrl = "s3:$($Endpoint.TrimEnd('/'))/$Bucket"
$ResticPassword = New-RandomSecret 48
$OperationsReportSecret = New-RandomSecret 48

Write-Step "CONFIGURE MONITORING ALERTS"
$TelegramToken = ""
$TelegramChat = ""
$UseTelegram = Read-Host "Configure Telegram alerts? Type YES or press Enter to skip"
if ($UseTelegram -eq "YES") {
    $TelegramToken = ConvertTo-PlainText (Read-Host "Telegram bot token" -AsSecureString)
    $TelegramChat = Read-Host "Telegram chat ID"
}
$SmtpHost = ""; $SmtpPort = "587"; $SmtpUser = ""; $SmtpPassword = ""; $EmailTo = ""; $EmailFrom = ""
$UseEmail = Read-Host "Configure email alerts? Type YES or press Enter to skip"
if ($UseEmail -eq "YES") {
    $SmtpHost = Read-Host "Alert SMTP host"
    $SmtpPortInput = Read-Host "Alert SMTP port (default: 587)"
    if (-not [string]::IsNullOrWhiteSpace($SmtpPortInput)) { $SmtpPort = $SmtpPortInput }
    $SmtpUser = Read-Host "Alert SMTP username"
    $SmtpPassword = ConvertTo-PlainText (Read-Host "Alert SMTP password" -AsSecureString)
    $EmailTo = Read-Host "Alert recipient email"
    $EmailFrom = Read-Host "Alert sender email (default: SMTP username)"
    if ([string]::IsNullOrWhiteSpace($EmailFrom)) { $EmailFrom = $SmtpUser }
}

$OpsValues = [ordered]@{
    APP_DOMAIN = $Domain
    HEALTH_URL = "https://$Domain/api/health"
    CHECK_OFFSITE_BACKUP = "true"
    CHECK_RESTORE_TEST = "true"
    CHECK_REPOSITORY_INTEGRITY = "true"
    RESTIC_REPOSITORY = $RepositoryUrl
    RESTIC_PASSWORD = $ResticPassword
    AWS_ACCESS_KEY_ID = $AccessKey
    AWS_SECRET_ACCESS_KEY = $SecretKey
    AWS_DEFAULT_REGION = $Region
    RESTIC_KEEP_DAILY = "7"
    RESTIC_KEEP_WEEKLY = "4"
    RESTIC_KEEP_MONTHLY = "6"
    RESTIC_KEEP_YEARLY = "2"
    RESTIC_KEEP_LAST = "2"
    RESTIC_CHECK_DATA_SUBSET = "10%"
    BACKUP_MAX_AGE_HOURS = "30"
    RESTORE_TEST_MAX_AGE_HOURS = "192"
    REPOSITORY_CHECK_MAX_AGE_HOURS = "192"
    OPERATIONS_REPORT_SECRET = $OperationsReportSecret
    DISK_WARN_PERCENT = "85"
    MEMORY_WARN_PERCENT = "90"
    LOAD_WARN_MULTIPLIER = "2"
    TELEGRAM_BOT_TOKEN = $TelegramToken
    TELEGRAM_CHAT_ID = $TelegramChat
    ALERT_SMTP_HOST = $SmtpHost
    ALERT_SMTP_PORT = $SmtpPort
    ALERT_SMTP_USER = $SmtpUser
    ALERT_SMTP_PASSWORD = $SmtpPassword
    ALERT_EMAIL_TO = $EmailTo
    ALERT_EMAIL_FROM = $EmailFrom
    ALERT_SMTP_STARTTLS = "true"
    ALERT_SMTP_SSL = "false"
}
$OpsJson = $OpsValues | ConvertTo-Json -Compress
$OpsB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($OpsJson))
$UploadEnv = @"
printf '%s' '$OpsB64' | base64 -d > /tmp/holy-life-ops.json
sudo python3 -c 'import json,shlex; d=json.load(open("/tmp/holy-life-ops.json", encoding="utf-8")); open("/etc/holy-life/ops.env","w",encoding="utf-8").write("".join(f"{k}={shlex.quote(str(v))}\n" for k,v in d.items()))'
sudo chmod 600 /etc/holy-life/ops.env
rm -f /tmp/holy-life-ops.json
"@
Invoke-Checked -Message "Operations secret configuration failed" -Command {
    ssh.exe -i $OpsKey -p $SshPort "holyops@$VpsHost" $UploadEnv
}

$OperationsSecretB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($OperationsReportSecret))
$SyncApplicationSecret = @"
set -Eeuo pipefail
export OPERATIONS_SECRET_B64='$OperationsSecretB64'
sudo python3 - <<'PY'
import base64
import os
from pathlib import Path

path = Path("/opt/holy-life/.env.production")
report_key = base64.b64decode(os.environ["OPERATIONS_SECRET_B64"]).decode("utf-8")
lines = path.read_text(encoding="utf-8").splitlines()
result = []
written = False
for line in lines:
    if line.startswith("OPERATIONS_REPORT_SECRET="):
        result.append(f"OPERATIONS_REPORT_SECRET={report_key}")
        written = True
    else:
        result.append(line)
if not written:
    result.append(f"OPERATIONS_REPORT_SECRET={report_key}")
path.write_text("\n".join(result) + "\n", encoding="utf-8")
PY
sudo chmod 600 /opt/holy-life/.env.production
"@
Invoke-Checked -Message "Application operations reporting secret synchronization failed" -Command {
    ssh.exe -i $OpsKey -p $SshPort "holyops@$VpsHost" $SyncApplicationSecret
}

Write-Step "INSTALL TIMERS AND RUN BACKUP/RESTORE TEST"
$InstallCommand = @'
set -Eeuo pipefail
sudo chown -R holydeploy:holydeploy /opt/holy-life/ops
sudo /opt/holy-life/ops/install-operations.sh
sudo systemctl start holy-life-offsite-backup.service
sudo systemctl start holy-life-restore-test.service
sudo systemctl start holy-life-monitor.service || true
sudo systemctl --no-pager --full status holy-life-offsite-backup.service holy-life-restore-test.service | sed -n '1,160p'
'@
Invoke-Checked -Message "Backup/restore-test installation failed" -Command {
    ssh.exe -i $OpsKey -p $SshPort "holyops@$VpsHost" $InstallCommand
}

Write-Step "LOCK ROOT AND PASSWORD SSH AFTER KEY VERIFICATION"
$LockAnswer = Read-Host "Type LOCK to disable SSH root login and password login now"
if ($LockAnswer -eq "LOCK") {
    Invoke-Checked -Message "SSH hardening lock failed" -Command {
        ssh.exe -i $OpsKey -p $SshPort "holyops@$VpsHost" "sudo SSH_PORT='$SshPort' /opt/holy-life/ops/hardening/harden-vps.sh lock"
    }
    Invoke-Checked -Message "Post-lock holyops access verification failed" -Command {
        ssh.exe -i $OpsKey -p $SshPort -o BatchMode=yes "holyops@$VpsHost" "sudo -n true && echo SSH_HARDENING_VERIFIED"
    }
}
else {
    Write-Warning "SSH root/password lock was skipped. Run the lock phase later after verification."
}

Write-Step "OPTIONAL HCP TERRAFORM REMOTE STATE MIGRATION"
$HcpAnswer = Read-Host "Type HCP to migrate Terraform state to HCP Terraform now, or press Enter to defer"
if ($HcpAnswer -eq "HCP") {
    & (Join-Path $PSScriptRoot "MIGRATE_TERRAFORM_STATE_HCP.ps1") -Workspace "holy-life-demo"
}

$CredentialText = @"
Holy Life operations recovery credentials
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
Domain: $Domain
VPS: $VpsHost
Operations user: holyops
Operations private key: $OpsKey
Restic repository: $RepositoryUrl
Restic password: $ResticPassword
Object storage access key: $AccessKey
Object storage secret key: $SecretKey

Store this file in an encrypted password manager/offline vault, then delete the plaintext copy from Downloads.
"@
[IO.File]::WriteAllText($CredentialPath, $CredentialText, [Text.UTF8Encoding]::new($false))

$ReportText = @"
Holy Life Phase 4 + Production DevOps Hardening
Commit: $CommitSha
GitHub Actions run: $RunId
Live URL: https://$Domain
Health URL: https://$Domain/api/health
Off-site repository: $RepositoryUrl
Backup timer: daily
Restore test: weekly
Monitoring: every 5 minutes
Logs: journald, 14-day/1GB retention
Security: Fail2ban, UFW SSH rate limit, unattended updates, hardened containers
SSH lock applied: $($LockAnswer -eq 'LOCK')
HCP state migration requested: $($HcpAnswer -eq 'HCP')
Credentials file: $CredentialPath
"@
[IO.File]::WriteAllText($ReportPath, $ReportText, [Text.UTF8Encoding]::new($false))

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "PHASE 4 AND PRODUCTION HARDENING COMPLETED" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Live: https://$Domain" -ForegroundColor Green
Write-Host "Report: $ReportPath" -ForegroundColor Cyan
Write-Host "Recovery credentials: $CredentialPath" -ForegroundColor Yellow
Write-Host "Move the recovery credentials into an encrypted vault immediately." -ForegroundColor Yellow
