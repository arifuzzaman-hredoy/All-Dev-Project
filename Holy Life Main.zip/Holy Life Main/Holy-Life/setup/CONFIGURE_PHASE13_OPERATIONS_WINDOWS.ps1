param(
    [string] $VpsHost = "198.54.121.88",
    [int] $SshPort = 22,
    [string] $Domain = "holylife.techteamlead.com",
    [string] $OpsKey = "$HOME\.ssh\holy_life_ops_ed25519"
)

$ErrorActionPreference = "Stop"

function Invoke-Checked {
    param([Parameter(Mandatory)] [scriptblock] $Command, [Parameter(Mandatory)] [string] $Message)
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Message (exit $LASTEXITCODE)" }
}

if (-not (Test-Path -LiteralPath $OpsKey -PathType Leaf)) {
    throw "Operations SSH key was not found: $OpsKey"
}

$RemoteScript = @'
set -Eeuo pipefail

APP_DIR=/opt/holy-life
ENV_FILE="$APP_DIR/.env.production"
OPS_ENV=/etc/holy-life/ops.env
COMPOSE_FILE="$APP_DIR/compose.production.yml"

[[ -r "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 2; }
[[ -r "$OPS_ENV" ]] || { echo "Missing $OPS_ENV" >&2; exit 2; }
[[ -x "$APP_DIR/ops/install-operations.sh" ]] || { echo "Phase 13 operations bundle is not deployed." >&2; exit 2; }

sudo python3 - <<'PY'
from pathlib import Path
import secrets
import shlex

app_path = Path("/opt/holy-life/.env.production")
ops_path = Path("/etc/holy-life/ops.env")
report_key = secrets.token_urlsafe(48)

def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in line:
            continue
        key, raw = line.split("=", 1)
        try:
            parts = shlex.split(raw, posix=True)
            value = parts[0] if parts else ""
        except ValueError:
            value = raw.strip()
        values[key] = value
    return values

def replace_env(path: Path, key: str, value: str, shell_quote: bool) -> None:
    lines = path.read_text(encoding="utf-8").splitlines()
    replacement = f"{key}={shlex.quote(value) if shell_quote else value}"
    output = []
    seen = False
    for line in lines:
        if line.startswith(f"{key}="):
            output.append(replacement)
            seen = True
        else:
            output.append(line)
    if not seen:
        output.append(replacement)
    path.write_text("\n".join(output) + "\n", encoding="utf-8")

ops_values = read_env(ops_path)
offsite = ops_values.get("CHECK_OFFSITE_BACKUP", "true").lower()
restore = ops_values.get("CHECK_RESTORE_TEST", "true").lower()
local_only = offsite == "false" and restore == "false"

replace_env(app_path, "OPERATIONS_REPORT_SECRET", report_key, False)
replace_env(ops_path, "OPERATIONS_REPORT_SECRET", report_key, True)
replace_env(ops_path, "RESTIC_KEEP_LAST", "2", True)
replace_env(ops_path, "RESTIC_KEEP_YEARLY", "2", True)
replace_env(ops_path, "RESTIC_CHECK_DATA_SUBSET", "10%", True)
replace_env(ops_path, "REPOSITORY_CHECK_MAX_AGE_HOURS", "192", True)
replace_env(
    ops_path,
    "CHECK_REPOSITORY_INTEGRITY",
    "false" if local_only else "true",
    True,
)
PY

sudo chmod 600 "$ENV_FILE" "$OPS_ENV"

# shellcheck disable=SC1090
set -a
source "$OPS_ENV"
set +a

CHECK_OFFSITE_BACKUP="${CHECK_OFFSITE_BACKUP:-true}"
CHECK_RESTORE_TEST="${CHECK_RESTORE_TEST:-true}"
CHECK_REPOSITORY_INTEGRITY="${CHECK_REPOSITORY_INTEGRITY:-true}"

if [[ "$CHECK_OFFSITE_BACKUP" == "false" && "$CHECK_RESTORE_TEST" == "false" ]]; then
  PHASE13_BACKUP_MODE=local-only
else
  PHASE13_BACKUP_MODE=offsite
  : "${RESTIC_REPOSITORY:?RESTIC_REPOSITORY is required for off-site Phase 13 operations mode}"
  : "${RESTIC_PASSWORD:?RESTIC_PASSWORD is required for off-site Phase 13 operations mode}"
  if [[ "$RESTIC_REPOSITORY" == s3:* ]]; then
    : "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID is required for an S3 restic repository}"
    : "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY is required for an S3 restic repository}"
  fi
fi

sudo "$APP_DIR/ops/install-operations.sh"

cd "$APP_DIR"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --no-deps --force-recreate --wait app
APP_BIND_PORT="$(python3 "$APP_DIR/deploy/read-dotenv.py" "$ENV_FILE" APP_BIND_PORT 3100)"
curl --fail --silent --show-error --max-time 20 "http://127.0.0.1:${APP_BIND_PORT}/api/health" >/dev/null

if [[ "$PHASE13_BACKUP_MODE" == "offsite" && "$CHECK_REPOSITORY_INTEGRITY" == "true" ]]; then
  sudo systemctl start holy-life-restic-check.service
  sudo systemctl is-failed holy-life-restic-check.service >/dev/null 2>&1 && {
    sudo systemctl --no-pager --full status holy-life-restic-check.service || true
    exit 1
  }
fi

assert_timer_state() {
  local should_enable="$1"
  local timer="$2"

  if [[ "$should_enable" == "true" ]]; then
    sudo systemctl is-enabled "$timer"
  else
    if sudo systemctl is-enabled "$timer" >/dev/null 2>&1; then
      echo "Timer should be disabled in current operations mode: $timer" >&2
      exit 1
    fi
  fi
}

assert_timer_state "$CHECK_OFFSITE_BACKUP" holy-life-offsite-backup.timer
assert_timer_state "$CHECK_RESTORE_TEST" holy-life-restore-test.timer
assert_timer_state "$CHECK_REPOSITORY_INTEGRITY" holy-life-restic-check.timer

sudo systemctl is-enabled holy-life-monitor.timer
sudo systemctl is-enabled holy-life-diagnostics.timer
sudo systemctl is-enabled holy-life-messaging-dispatch.timer
sudo systemctl is-enabled holy-life-payment-reconcile.timer

MONITOR_RESULT="$(sudo systemctl show holy-life-monitor.service --property=Result --value 2>/dev/null || true)"
if [[ -n "$MONITOR_RESULT" && "$MONITOR_RESULT" != "success" ]]; then
  echo "WARNING: production monitor currently reports an operational alert (Result=$MONITOR_RESULT)." >&2
  sudo journalctl -u holy-life-monitor.service -n 20 --no-pager || true
fi

echo "PHASE13_BACKUP_MODE=$PHASE13_BACKUP_MODE"
echo "PHASE13_OPERATIONS_CONFIGURATION_OK"
'@

Write-Host ""
Write-Host "=== CONFIGURE PHASE 13 OPERATIONS TELEMETRY ===" -ForegroundColor Cyan

$RemoteScript | & ssh.exe `
    -i $OpsKey `
    -p $SshPort `
    -o BatchMode=yes `
    -o StrictHostKeyChecking=accept-new `
    "holyops@$VpsHost" `
    "sudo bash -s"
if ($LASTEXITCODE -ne 0) {
    throw "Phase 13 operations configuration failed."
}

$Health = Invoke-RestMethod -Uri "https://$Domain/api/health" -TimeoutSec 20
if ($Health.status -ne "ok" -or $Health.database -ne "reachable") {
    throw "Live health failed after Phase 13 operations configuration."
}

Write-Host "Phase 13 operations reporting secret synchronized and timers enabled." -ForegroundColor Green
