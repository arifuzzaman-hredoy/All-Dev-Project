param(
    [string]$ProjectPath = "G:\Current Project\Development\Holy Life Project\Holy Life Main\holy-life-phase-0-1-2",
    [string]$VpsHost = "198.54.121.88",
    [int]$SshPort = 22,
    [string]$Domain = "holylife.techteamlead.com",
    [string]$KeyPath = "$HOME\.ssh\holy_life_deploy_ed25519",
    [string]$OwnerEmail = "shaonk640@gmail.com"
)

$ErrorActionPreference = "Stop"

function ConvertFrom-SecureStringPlain {
    param([Security.SecureString]$Secure)
    $Ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Ptr) }
}

function Set-DotEnvValue {
    param([string]$Path, [string]$Key, [string]$Value)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    $Lines = [System.Collections.Generic.List[string]]::new()
    foreach ($Line in (Get-Content -LiteralPath $Path)) { $Lines.Add($Line) }
    $Replacement = "$Key=`"$Value`""
    $Found = $false
    for ($Index = 0; $Index -lt $Lines.Count; $Index++) {
        if ($Lines[$Index] -match "^$([Regex]::Escape($Key))=") {
            $Lines[$Index] = $Replacement
            $Found = $true
            break
        }
    }
    if (-not $Found) { $Lines.Add($Replacement) }
    [IO.File]::WriteAllLines($Path, $Lines, [Text.UTF8Encoding]::new($false))
}

if (-not (Test-Path -LiteralPath $ProjectPath -PathType Container)) { throw "Project path not found: $ProjectPath" }
if (-not (Test-Path -LiteralPath $KeyPath -PathType Leaf)) { throw "SSH key not found: $KeyPath" }

Write-Host ""
Write-Host "Super Admin email: $OwnerEmail" -ForegroundColor Cyan
$SecurePassword = Read-Host "Enter NEW Super Admin password (hidden)" -AsSecureString
$OwnerCredentialPlain = ConvertFrom-SecureStringPlain $SecurePassword
$SecureConfirm = Read-Host "Confirm NEW Super Admin password (hidden)" -AsSecureString
$OwnerCredentialConfirm = ConvertFrom-SecureStringPlain $SecureConfirm

try {
    if ($OwnerCredentialPlain -ne $OwnerCredentialConfirm) { throw "Passwords do not match." }
    if ($OwnerCredentialPlain.Length -lt 6 -or $OwnerCredentialPlain.Length -gt 128) { throw "Password must be 6-128 characters." }
    if ($OwnerCredentialPlain -notmatch '[a-z]') { throw "Password must contain a lowercase letter." }
    if ($OwnerCredentialPlain -notmatch '[A-Z]') { throw "Password must contain an uppercase letter." }
    if ($OwnerCredentialPlain -notmatch '\d') { throw "Password must contain a number." }

    $RemotePath = "/tmp/holy-life-set-super-admin-$([Guid]::NewGuid().ToString('N')).sh"
    $LocalTemp = Join-Path ([IO.Path]::GetTempPath()) "holy-life-set-super-admin-$([Guid]::NewGuid().ToString('N')).sh"

    $RemoteScript = @'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS= read -r NEW_PASSWORD
if [[ -z "$NEW_PASSWORD" ]]; then
  echo "Empty Super Admin password refused" >&2
  exit 20
fi

cd /opt/holy-life
ENV_FILE=.env.production
COMPOSE_FILE=compose.production.yml
OWNER_EMAIL="__OWNER_EMAIL__"
DOMAIN="__DOMAIN__"

export HOLY_OWNER_PASSWORD="$NEW_PASSWORD"
PASSWORD_HASH="$(python3 - <<'PY'
import base64, hashlib, os
password = os.environ['HOLY_OWNER_PASSWORD'].encode('utf-8')
salt = os.urandom(16)
dk = hashlib.scrypt(password, salt=salt, n=32768, r=8, p=1, dklen=64, maxmem=64*1024*1024)
def b64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')
print(f"scrypt$32768$8$1${b64url(salt)}${b64url(dk)}")
PY
)"
unset HOLY_OWNER_PASSWORD

export HOLY_OWNER_PASSWORD_FOR_ENV="$NEW_PASSWORD"
python3 - "$ENV_FILE" "$OWNER_EMAIL" <<'PY'
import os, sys, tempfile
from pathlib import Path
path=Path(sys.argv[1]); email=sys.argv[2]; password=os.environ['HOLY_OWNER_PASSWORD_FOR_ENV']
values={"INITIAL_SUPER_ADMIN_EMAIL": email, "INITIAL_SUPER_ADMIN_PASSWORD": password}
lines=path.read_text(encoding='utf-8').splitlines()
out=[]; seen=set()
for line in lines:
    key=line.split('=',1)[0] if '=' in line else ''
    if key in values:
        value=values[key].replace('\\','\\\\').replace('"','\\"')
        out.append(f'{key}="{value}"'); seen.add(key)
    else:
        out.append(line)
for key,value in values.items():
    if key not in seen:
        value=value.replace('\\','\\\\').replace('"','\\"')
        out.append(f'{key}="{value}"')
fd,tmp=tempfile.mkstemp(prefix='holy-life-env-', dir=str(path.parent), text=True); os.close(fd)
t=Path(tmp)
try:
    t.write_text('\n'.join(out)+'\n', encoding='utf-8'); os.chmod(t,0o600); os.replace(t,path)
finally:
    if t.exists(): t.unlink()
PY
unset HOLY_OWNER_PASSWORD_FOR_ENV
chmod 600 "$ENV_FILE"

POSTGRES_USER="$(python3 deploy/read-dotenv.py "$ENV_FILE" POSTGRES_USER holy_life_app)"
POSTGRES_DB="$(python3 deploy/read-dotenv.py "$ENV_FILE" POSTGRES_DB holy_life)"
SQL_FILE="$(mktemp)"
trap 'rm -f "$SQL_FILE"' EXIT
cat >"$SQL_FILE" <<SQL
BEGIN;
DO \$\$
DECLARE owner_id text; collision_id text; owner_count integer;
BEGIN
  SELECT COUNT(*) INTO owner_count FROM "User" WHERE "isSuperAdmin"=true;
  IF owner_count <> 1 THEN RAISE EXCEPTION 'Expected exactly one Super Admin, found %', owner_count; END IF;
  SELECT id INTO owner_id FROM "User" WHERE "isSuperAdmin"=true LIMIT 1;
  SELECT id INTO collision_id FROM "User" WHERE lower(COALESCE(email,''))=lower('${OWNER_EMAIL}') AND id<>owner_id LIMIT 1;
  IF collision_id IS NOT NULL THEN
    UPDATE "Session" SET "revokedAt"=COALESCE("revokedAt",NOW()) WHERE "userId"=collision_id AND "revokedAt" IS NULL;
    UPDATE "User" SET email=NULL,status='ARCHIVED',"sessionVersion"="sessionVersion"+1,"updatedAt"=NOW()
      WHERE id=collision_id AND "isSuperAdmin"=false;
    IF NOT FOUND THEN RAISE EXCEPTION 'Could not safely release owner email collision'; END IF;
  END IF;
  UPDATE "Session" SET "revokedAt"=COALESCE("revokedAt",NOW()) WHERE "userId"=owner_id AND "revokedAt" IS NULL;
  UPDATE "User"
    SET email='${OWNER_EMAIL}', "passwordHash"='${PASSWORD_HASH}', "passwordChangedAt"=NOW(), status='ACTIVE',
        "emailVerifiedAt"=COALESCE("emailVerifiedAt",NOW()), "sessionVersion"="sessionVersion"+1, "updatedAt"=NOW()
    WHERE id=owner_id;
END
\$\$;
COMMIT;
SQL

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" < "$SQL_FILE"

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --no-deps --force-recreate --wait app

OWNER_DB_EMAIL="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -At -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" \
  -c "SELECT COALESCE(email,'') FROM \"User\" WHERE \"isSuperAdmin\"=true;" </dev/null | tr -d '\r')"
[[ "$OWNER_DB_EMAIL" == "$OWNER_EMAIL" ]]
[[ "$(python3 deploy/read-dotenv.py "$ENV_FILE" INITIAL_SUPER_ADMIN_EMAIL '')" == "$OWNER_EMAIL" ]]

curl --fail --silent --show-error --max-time 20 "https://$DOMAIN/api/health" >/dev/null

echo "SUPER_ADMIN_ENV_CREDENTIALS_OK"
echo "Super Admin URL: https://$DOMAIN/super-admin"
echo "Super Admin email: $OWNER_EMAIL"
echo "Password was updated securely and was not printed."
'@

    $RemoteScript = $RemoteScript.Replace("__OWNER_EMAIL__", $OwnerEmail).Replace("__DOMAIN__", $Domain)
    [IO.File]::WriteAllText($LocalTemp, $RemoteScript, [Text.UTF8Encoding]::new($false))

    try {
        scp.exe -q -i $KeyPath -P $SshPort $LocalTemp "holydeploy@${VpsHost}:$RemotePath"
        if ($LASTEXITCODE -ne 0) { throw "Could not upload Super Admin credential helper." }

        $RemoteCommand = "chmod 700 '$RemotePath' && bash '$RemotePath'; code=`$?; rm -f '$RemotePath'; exit `$code"
        ($OwnerCredentialPlain + "`n") | ssh.exe -i $KeyPath -p $SshPort "holydeploy@$VpsHost" $RemoteCommand
        if ($LASTEXITCODE -ne 0) { throw "Remote Super Admin credential update failed." }
    }
    finally {
        Remove-Item -LiteralPath $LocalTemp -Force -ErrorAction SilentlyContinue
        ssh.exe -i $KeyPath -p $SshPort "holydeploy@$VpsHost" "rm -f '$RemotePath'" 2>$null | Out-Null
    }

    Set-DotEnvValue -Path (Join-Path $ProjectPath ".env") -Key "INITIAL_SUPER_ADMIN_EMAIL" -Value $OwnerEmail
    Set-DotEnvValue -Path (Join-Path $ProjectPath ".env") -Key "INITIAL_SUPER_ADMIN_PASSWORD" -Value $OwnerCredentialPlain

    Write-Host ""
    Write-Host "Super Admin credentials updated." -ForegroundColor Green
    Write-Host "URL: https://$Domain/super-admin"
    Write-Host "Email: $OwnerEmail"
    Write-Host "Password: [hidden / stored in .env]"
}
finally {
    $OwnerCredentialPlain = $null
    $OwnerCredentialConfirm = $null
}
