param(
    [string] $Domain = "holylife.techteamlead.com"
)

$ErrorActionPreference = "Stop"
$uri = "https://$Domain/api/health"
Write-Host "Checking $uri" -ForegroundColor Cyan
$response = Invoke-RestMethod -Uri $uri -TimeoutSec 30
$response | ConvertTo-Json -Depth 8
Write-Host "Holy Life live health check passed." -ForegroundColor Green
