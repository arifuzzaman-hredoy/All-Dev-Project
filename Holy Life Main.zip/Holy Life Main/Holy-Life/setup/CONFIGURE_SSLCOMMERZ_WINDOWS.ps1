param(
    [string] $VpsHost = "198.54.121.88",
    [int] $SshPort = 22,
    [string] $Domain = "holylife.techteamlead.com",
    [string] $KeyPath = "$HOME\.ssh\holy_life_deploy_ed25519"
)

$ErrorActionPreference = "Stop"

function New-RandomSecret([int] $ByteCount = 48) {
    $Bytes = New-Object byte[] $ByteCount
    [Security.Cryptography.RandomNumberGenerator]::Fill($Bytes)
    return [Convert]::ToBase64String($Bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
}

function ConvertFrom-SecureStringToPlain([Security.SecureString] $Value) {
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

if (-not (Test-Path -LiteralPath $KeyPath -PathType Leaf)) {
    throw "Deploy SSH key was not found: $KeyPath"
}

$Environment = (Read-Host "SSLCOMMERZ environment (sandbox/live, default sandbox)").Trim().ToLowerInvariant()
if ([string]::IsNullOrWhiteSpace($Environment)) { $Environment = "sandbox" }
if ($Environment -notin @("sandbox", "live")) { throw "Environment must be sandbox or live." }

$StoreId = (Read-Host "SSLCOMMERZ Store ID").Trim()
if ([string]::IsNullOrWhiteSpace($StoreId)) { throw "Store ID is required." }
$SecurePassword = Read-Host "SSLCOMMERZ Store Password" -AsSecureString
$StorePassword = ConvertFrom-SecureStringToPlain $SecurePassword
if ([string]::IsNullOrWhiteSpace($StorePassword)) { throw "Store password is required." }

$PaymentReconcileSecret = New-RandomSecret 48
$Payload = @{
    PAYMENT_GATEWAY_MODE = "sslcommerz"
    SSLCOMMERZ_ENVIRONMENT = $Environment
    SSLCOMMERZ_STORE_ID = $StoreId
    SSLCOMMERZ_STORE_PASSWORD = $StorePassword
    PAYMENT_RECONCILE_SECRET = $PaymentReconcileSecret
} | ConvertTo-Json -Compress

$RemotePython = @'
import json, os, sys, tempfile
from pathlib import Path

path = Path("/opt/holy-life/.env.production")
if not path.is_file():
    raise SystemExit("Missing /opt/holy-life/.env.production")
updates = json.load(sys.stdin)
lines = path.read_text(encoding="utf-8").splitlines()
seen = set()
out = []
for line in lines:
    if not line or line.lstrip().startswith("#") or "=" not in line:
        out.append(line)
        continue
    key = line.split("=", 1)[0]
    if key in updates:
        value = str(updates[key]).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
        out.append(f'{key}="{value}"')
        seen.add(key)
    else:
        out.append(line)
for key, raw in updates.items():
    if key in seen:
        continue
    value = str(raw).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
    out.append(f'{key}="{value}"')
fd, temp_name = tempfile.mkstemp(prefix="holy-life-env-", dir=str(path.parent), text=True)
os.close(fd)
temp = Path(temp_name)
try:
    temp.write_text("\n".join(out) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, path)
finally:
    if temp.exists():
        temp.unlink()
'@

$PythonB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($RemotePython))
$RemoteCommand = "python3 -c `"import base64;exec(base64.b64decode('$PythonB64'))`" && sudo -n /opt/holy-life/ops/install-operations.sh && cd /opt/holy-life && docker compose --env-file .env.production -f compose.production.yml up -d --no-deps --force-recreate app && sudo -n systemctl is-enabled holy-life-payment-reconcile.timer"

try {
    $Payload | ssh.exe -i $KeyPath -p $SshPort "holydeploy@$VpsHost" $RemoteCommand
    if ($LASTEXITCODE -ne 0) { throw "Remote SSLCOMMERZ configuration failed." }
}
finally {
    $StorePassword = $null
    $PaymentReconcileSecret = $null
    $Payload = $null
}

Write-Host "Waiting for application health..." -ForegroundColor Cyan
for ($Attempt = 1; $Attempt -le 20; $Attempt++) {
    try {
        $Health = Invoke-RestMethod -Uri "https://$Domain/api/health" -TimeoutSec 10
        if ($Health.status -eq "ok" -and $Health.database -eq "reachable") {
            Write-Host "SSLCOMMERZ configuration applied. Health is OK." -ForegroundColor Green
            exit 0
        }
    }
    catch { }
    Start-Sleep -Seconds 5
}
throw "Application did not return healthy after SSLCOMMERZ configuration."
