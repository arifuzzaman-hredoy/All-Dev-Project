param(
    [string] $Repository = "techtemlead-lab/Holy_Life",
    [string] $VpsHost = "198.54.121.88",
    [string] $Domain = "holylife.techteamlead.com",
    [string] $EnvironmentName = "demo"
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Downloads = Join-Path $HOME "Downloads"
$CredentialFile = Join-Path $Downloads "Holy-Life-Initial-Credentials.txt"
$DeployUser = "holydeploy"
$AppDirectory = "/opt/holy-life"

function New-RandomSecret {
    param([int] $Bytes = 36)
    $buffer = New-Object byte[] $Bytes
    [System.Security.Cryptography.RandomNumberGenerator]::Fill($buffer)
    return [Convert]::ToBase64String($buffer).TrimEnd("=").Replace("+", "-").Replace("/", "_")
}

function ConvertTo-PlainText {
    param([Security.SecureString] $SecureValue)
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

function ConvertTo-DotEnvValue {
    param([AllowNull()] [AllowEmptyString()] [string] $Value)

    if ($null -eq $Value) {
        $Value = ""
    }

    $escaped = $Value.Replace("\", "\\")
    $escaped = $escaped.Replace('"', '\"')
    $escaped = $escaped.Replace("`r", "\r")
    $escaped = $escaped.Replace("`n", "\n")
    $escaped = $escaped.Replace("`t", "\t")
    return '"' + $escaped + '"'
}

function Invoke-Checked {
    param([Parameter(Mandatory)] [scriptblock] $Command, [Parameter(Mandatory)] [string] $FailureMessage)
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$FailureMessage (exit $LASTEXITCODE)"
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HOLY LIFE TERMINAL-ONLY VPS + TERRAFORM + CI/CD SETUP" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

& (Join-Path $PSScriptRoot "01_INSTALL_REQUIRED_TOOLS.ps1")

$rootUser = Read-Host "Current VPS administrator username (default: root)"
if ([string]::IsNullOrWhiteSpace($rootUser)) { $rootUser = "root" }
$portText = Read-Host "Current VPS SSH port (default: 22)"
$VpsPort = if ([string]::IsNullOrWhiteSpace($portText)) { 22 } else { [int] $portText }

Write-Host "Authenticating GitHub CLI..." -ForegroundColor Cyan
gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
    gh auth login --hostname github.com --web --git-protocol https
}
gh auth refresh --hostname github.com --scopes repo,workflow,read:packages,write:packages
$GitHubToken = gh auth token
if ([string]::IsNullOrWhiteSpace($GitHubToken)) { throw "GitHub authentication failed." }

gh repo view $Repository *> $null
if ($LASTEXITCODE -ne 0) { throw "Cannot access private repository $Repository." }

$KeyDirectory = Join-Path $HOME ".ssh"
$KeyPath = Join-Path $KeyDirectory "holy_life_deploy_ed25519"
New-Item -ItemType Directory -Path $KeyDirectory -Force | Out-Null
if (-not (Test-Path $KeyPath)) {
    Invoke-Checked -FailureMessage "SSH deploy key generation failed" -Command {
        $keyArguments = @("-t", "ed25519", "-a", "64", "-N", "", "-C", "holy-life-github-actions", "-f", $KeyPath)
        & ssh-keygen.exe @keyArguments
    }
}
$PublicKey = (Get-Content "$KeyPath.pub" -Raw).Trim()
$PublicKeyB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($PublicKey))
$BootstrapText = Get-Content (Join-Path $ProjectRoot "deploy\bootstrap-vps.sh") -Raw
$BootstrapB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($BootstrapText))
$RemoteBootstrap = "printf '%s' '$BootstrapB64' | base64 -d | bash -s -- '$Domain' '$PublicKeyB64'"

Write-Host ""
Write-Host "First VPS authentication may request the existing root password once." -ForegroundColor Yellow
Invoke-Checked -FailureMessage "VPS bootstrap failed" -Command {
    ssh.exe -o StrictHostKeyChecking=accept-new -p $VpsPort "$rootUser@$VpsHost" $RemoteBootstrap
}

Write-Host "Testing passwordless deploy user..." -ForegroundColor Cyan
Invoke-Checked -FailureMessage "Deploy user key authentication failed" -Command {
    ssh.exe -i $KeyPath -o BatchMode=yes -o StrictHostKeyChecking=accept-new -p $VpsPort "$DeployUser@$VpsHost" "whoami && docker compose version"
}

$PostgresPassword = New-RandomSecret 42
$AuthSecret = New-RandomSecret 48
$MessagingWebhookSecret = New-RandomSecret 48
$MessagingCallbackSecret = New-RandomSecret 48
$MessagingDispatchSecret = New-RandomSecret 48
$PaymentReconcileSecret = New-RandomSecret 48
$OperationsReportSecret = New-RandomSecret 48
$OwnerPassword = New-RandomSecret 24
$OwnerEmail = Read-Host "Primary owner email (default: admin@gmail.com)"
if ([string]::IsNullOrWhiteSpace($OwnerEmail)) { $OwnerEmail = "admin@gmail.com" }
$OwnerName = Read-Host "Primary owner name (default: Dr. Kawsar Ahmed)"
if ([string]::IsNullOrWhiteSpace($OwnerName)) { $OwnerName = "Dr. Kawsar Ahmed" }

$OwnerNameEnv = ConvertTo-DotEnvValue $OwnerName
$OwnerEmailEnv = ConvertTo-DotEnvValue $OwnerEmail
$InitialMemberNameEnv = ConvertTo-DotEnvValue "Demo Member"

$EnvironmentText = @"
TZ=Asia/Dhaka
APP_URL=https://$Domain
APP_BIND_PORT=3100
HOLY_LIFE_IMAGE=ghcr.io/techtemlead-lab/holy-life-app:demo-latest
HOLY_LIFE_MIGRATOR_IMAGE=ghcr.io/techtemlead-lab/holy-life-migrator:demo-latest
POSTGRES_DB=holy_life
POSTGRES_USER=holy_life_app
POSTGRES_PASSWORD=$PostgresPassword
AUTH_SECRET=$AuthSecret
AUTH_REQUIRE_VERIFIED_CONTACT=true
TRUST_PROXY=true
AUTH_DELIVERY_MODE=disabled
AUTH_DELIVERY_WEBHOOK_URL=
AUTH_DELIVERY_WEBHOOK_SECRET=
MESSAGING_MODE=disabled
MESSAGING_WEBHOOK_URL=
MESSAGING_WEBHOOK_SECRET=$MessagingWebhookSecret
MESSAGING_CALLBACK_SECRET=$MessagingCallbackSecret
MESSAGING_DISPATCH_SECRET=$MessagingDispatchSecret
MESSAGING_AUTO_CHANNELS=
MESSAGING_MAX_ATTEMPTS=5
MESSAGING_DISPATCH_BATCH_SIZE=50
MESSAGING_CAMPAIGN_MAX_RECIPIENTS=5000
MESSAGING_RETRY_BASE_SECONDS=60
MESSAGING_PROVIDER_TIMEOUT_MS=10000
MESSAGING_STALE_LOCK_MINUTES=10
OPERATIONS_REPORT_SECRET=$OperationsReportSecret
PAYMENT_GATEWAY_MODE=disabled
SSLCOMMERZ_ENVIRONMENT=sandbox
SSLCOMMERZ_STORE_ID=
SSLCOMMERZ_STORE_PASSWORD=
PAYMENT_RECONCILE_SECRET=$PaymentReconcileSecret
PAYMENT_GATEWAY_TIMEOUT_MS=12000
PAYMENT_GATEWAY_ATTEMPT_TTL_MINUTES=30
PAYMENT_RECONCILE_BATCH_SIZE=25
SESSION_DAYS=14
MAX_ACTIVE_SESSIONS=8
LOGIN_MAX_ATTEMPTS=5
LOGIN_WINDOW_MINUTES=15
LOGIN_LOCK_MINUTES=15
VERIFICATION_TTL_MINUTES=15
VERIFICATION_RESEND_SECONDS=60
PASSWORD_RESET_TTL_MINUTES=30
INITIAL_SUPER_ADMIN_NAME=$OwnerNameEnv
INITIAL_SUPER_ADMIN_EMAIL=$OwnerEmailEnv
INITIAL_SUPER_ADMIN_PASSWORD=$OwnerPassword
INITIAL_MEMBER_NAME=$InitialMemberNameEnv
INITIAL_MEMBER_EMAIL=
INITIAL_MEMBER_PHONE=
INITIAL_MEMBER_PASSWORD=
"@
$EnvironmentB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($EnvironmentText))
$RemoteEnvCommand = "printf '%s' '$EnvironmentB64' | base64 -d > '$AppDirectory/.env.production' && chmod 600 '$AppDirectory/.env.production'"
Invoke-Checked -FailureMessage "Production environment upload failed" -Command {
    ssh.exe -i $KeyPath -p $VpsPort "$DeployUser@$VpsHost" $RemoteEnvCommand
}

Write-Host "Logging the VPS into GHCR using the authenticated GitHub CLI token..." -ForegroundColor Cyan
$TokenB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($GitHubToken))
$GitHubUser = gh api user --jq .login
$RemoteRegistryLogin = "printf '%s' '$TokenB64' | base64 -d | docker login ghcr.io -u '$GitHubUser' --password-stdin"
Invoke-Checked -FailureMessage "VPS GHCR login failed" -Command {
    ssh.exe -i $KeyPath -p $VpsPort "$DeployUser@$VpsHost" $RemoteRegistryLogin
}

Write-Host "Creating GitHub deployment environment and secrets..." -ForegroundColor Cyan
gh api --method PUT "repos/$Repository/environments/$EnvironmentName" *> $null

$PrivateKey = Get-Content $KeyPath -Raw
$PrivateKey | gh secret set VPS_SSH_PRIVATE_KEY --repo $Repository --env $EnvironmentName
$VpsHost | gh secret set VPS_HOST --repo $Repository --env $EnvironmentName
$DeployUser | gh secret set VPS_USER --repo $Repository --env $EnvironmentName
"$VpsPort" | gh secret set VPS_SSH_PORT --repo $Repository --env $EnvironmentName
$GitHubToken | gh secret set TERRAFORM_GITHUB_TOKEN --repo $Repository --env $EnvironmentName

$Credentials = @"
Holy Life initial deployment credentials
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
URL: https://$Domain
Owner: $OwnerName
Owner email: $OwnerEmail
Owner password: $OwnerPassword

Store this securely and change the owner email/password after first login.
"@
[IO.File]::WriteAllText($CredentialFile, $Credentials, [Text.UTF8Encoding]::new($false))

Write-Host "Running Terraform validation and optional apply..." -ForegroundColor Cyan
& (Join-Path $PSScriptRoot "CONFIGURE_TERRAFORM.ps1") -Repository $Repository -EnvironmentName $EnvironmentName -VpsHost $VpsHost -VpsUser $DeployUser -VpsPort $VpsPort -Domain $Domain -ReconcileEnvironmentVariables

Write-Host "Committing and pushing Phase 3 directly to main..." -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
    if (-not (Test-Path (Join-Path $ProjectRoot ".git"))) {
        git init
        git remote add origin "https://github.com/$Repository.git"
        git fetch origin main 2>$null
        if ($LASTEXITCODE -eq 0) {
            git symbolic-ref HEAD refs/heads/main
            git reset --mixed origin/main
        }
        else {
            git branch -M main
        }
    }
    else {
        git remote get-url origin *> $null
        if ($LASTEXITCODE -ne 0) { git remote add origin "https://github.com/$Repository.git" }
    }

    $gitName = git config user.name
    if ([string]::IsNullOrWhiteSpace($gitName)) { git config user.name "TechTeam Holy Life Automation" }
    $gitEmail = git config user.email
    if ([string]::IsNullOrWhiteSpace($gitEmail)) { git config user.email "automation@techteamlead.com" }

    git add -A
    git diff --cached --quiet
    if ($LASTEXITCODE -ne 0) {
        git commit -m "feat: complete Phase 3 RBAC and VPS CI/CD"
    }
    git branch -M main
    git push --set-upstream origin main
}
finally {
    Pop-Location
}

Write-Host "Waiting for GitHub Actions workflow..." -ForegroundColor Cyan
Start-Sleep -Seconds 8
gh run list --repo $Repository --workflow "Holy Life CI and Demo Deployment" --limit 5

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "SETUP COMPLETED AND MAIN PUSHED" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Credentials file: $CredentialFile" -ForegroundColor Yellow
Write-Host "Live URL after workflow success: https://$Domain" -ForegroundColor Green
Write-Host "Use: gh run watch --repo $Repository" -ForegroundColor Cyan
