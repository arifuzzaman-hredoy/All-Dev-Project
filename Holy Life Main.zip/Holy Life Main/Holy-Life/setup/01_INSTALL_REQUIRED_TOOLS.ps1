$ErrorActionPreference = "Stop"

function Ensure-WingetPackage {
    param(
        [Parameter(Mandatory)] [string] $Command,
        [Parameter(Mandatory)] [string] $PackageId
    )

    if (Get-Command $Command -ErrorAction SilentlyContinue) {
        Write-Host "$Command is already installed." -ForegroundColor Green
        return
    }

    if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
        throw "winget is required. Install Microsoft App Installer first."
    }

    Write-Host "Installing $PackageId..." -ForegroundColor Cyan
    winget install --id $PackageId --exact --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "Installation failed: $PackageId (exit $LASTEXITCODE)"
    }
}

Ensure-WingetPackage -Command "git.exe" -PackageId "Git.Git"
Ensure-WingetPackage -Command "gh.exe" -PackageId "GitHub.cli"
Ensure-WingetPackage -Command "terraform.exe" -PackageId "Hashicorp.Terraform"

if (-not (Get-Command ssh.exe -ErrorAction SilentlyContinue)) {
    Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0 | Out-Null
}

Write-Host "Required tools are ready. Restart the terminal if a newly installed command is not found." -ForegroundColor Green
