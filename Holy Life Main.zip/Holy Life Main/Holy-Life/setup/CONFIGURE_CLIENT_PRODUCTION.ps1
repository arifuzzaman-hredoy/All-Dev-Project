param(
    [string] $Repository = "techtemlead-lab/Holy_Life"
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$EnvironmentName = "client-production"

function Invoke-Checked {
    param([scriptblock] $Command, [string] $Message)
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Message (exit $LASTEXITCODE)" }
}
function New-RandomSecret([int] $Bytes = 42) {
    $buffer = New-Object byte[] $Bytes
    [Security.Cryptography.RandomNumberGenerator]::Fill($buffer)
    [Convert]::ToBase64String($buffer).TrimEnd("=").Replace("+", "-").Replace("/", "_")
}
function ConvertTo-DotEnvValue([string] $Value) {
    if ($null -eq $Value) { $Value = "" }
    '"' + $Value.Replace("\", "\\").Replace('"', '\"').Replace("`r", "\r").Replace("`n", "\n") + '"'
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HOLY LIFE CLIENT PRODUCTION TERMINAL INSTALLER" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

& (Join-Path $PSScriptRoot "01_INSTALL_REQUIRED_TOOLS.ps1")
gh auth status *> $null
if ($LASTEXITCODE -ne 0) { gh auth login --hostname github.com --web --git-protocol https }
gh auth refresh --hostname github.com --scopes repo,workflow,read:packages,write:packages
$GitHubToken = gh auth token
$GitHubUser = gh api user --jq .login
$ReviewerId = gh api user --jq .id

$VpsHost = Read-Host "Client VPS public IP"
$Domain = Read-Host "Client production domain"
$RootUser = Read-Host "Initial VPS administrator user (default: root)"
if ([string]::IsNullOrWhiteSpace($RootUser)) { $RootUser = "root" }
$PortText = Read-Host "SSH port (default: 22)"
$SshPort = if ([string]::IsNullOrWhiteSpace($PortText)) { 22 } else { [int]$PortText }
$OwnerName = Read-Host "Client primary owner name"
$OwnerEmail = Read-Host "Client primary owner email"
if (@($VpsHost, $Domain, $OwnerName, $OwnerEmail) | Where-Object { [string]::IsNullOrWhiteSpace($_) }) {
    throw "VPS IP, domain, owner name, and owner email are required."
}

$KeyPath = Join-Path $HOME ".ssh\holy_life_client_production_ed25519"
New-Item -ItemType Directory -Path (Split-Path $KeyPath -Parent) -Force | Out-Null
if (-not (Test-Path $KeyPath)) {
    Invoke-Checked -Message "Client deploy key generation failed" -Command {
        ssh-keygen.exe -t ed25519 -a 64 -N "" -C "holy-life-client-production" -f $KeyPath
    }
}
$PublicKey = (Get-Content "$KeyPath.pub" -Raw).Trim()
$PublicKeyB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($PublicKey))
$BootstrapB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((Get-Content (Join-Path $ProjectRoot "deploy\bootstrap-vps.sh") -Raw))
$BootstrapCommand = "printf '%s' '$BootstrapB64' | base64 -d | bash -s -- '$Domain' '$PublicKeyB64'"

Write-Host "The new VPS administrator password may be requested once." -ForegroundColor Yellow
Invoke-Checked -Message "Client VPS bootstrap failed" -Command {
    ssh.exe -o StrictHostKeyChecking=accept-new -p $SshPort "${RootUser}@${VpsHost}" $BootstrapCommand
}
Invoke-Checked -Message "Client deploy-key verification failed" -Command {
    ssh.exe -i $KeyPath -o BatchMode=yes -p $SshPort "holydeploy@$VpsHost" "whoami && docker compose version"
}

$PostgresPassword = New-RandomSecret 42
$AuthSecret = New-RandomSecret 48
$MessagingWebhookSecret = New-RandomSecret 48
$MessagingCallbackSecret = New-RandomSecret 48
$MessagingDispatchSecret = New-RandomSecret 48
$PaymentReconcileSecret = New-RandomSecret 48
$OperationsReportSecret = New-RandomSecret 48
$OwnerPassword = New-RandomSecret 24
$EnvironmentText = @"
TZ=Asia/Dhaka
APP_URL=https://$Domain
APP_BIND_PORT=3100
HOLY_LIFE_IMAGE=ghcr.io/techtemlead-lab/holy-life-app:demo-latest
HOLY_LIFE_MIGRATOR_IMAGE=ghcr.io/techtemlead-lab/holy-life-migrator:demo-latest
POSTGRES_DB=holy_life
POSTGRES_USER=holy_life_app
POSTGRES_PASSWORD=$PostgresPassword
AUTH_SECRET=$AuthSecret
AUTH_REQUIRE_VERIFIED_CONTACT=true
TRUST_PROXY=true
AUTH_DELIVERY_MODE=disabled
MESSAGING_MODE=disabled
MESSAGING_WEBHOOK_URL=
MESSAGING_WEBHOOK_SECRET=$MessagingWebhookSecret
MESSAGING_CALLBACK_SECRET=$MessagingCallbackSecret
MESSAGING_DISPATCH_SECRET=$MessagingDispatchSecret
MESSAGING_AUTO_CHANNELS=
MESSAGING_MAX_ATTEMPTS=5
MESSAGING_DISPATCH_BATCH_SIZE=50
MESSAGING_CAMPAIGN_MAX_RECIPIENTS=5000
MESSAGING_RETRY_BASE_SECONDS=60
MESSAGING_PROVIDER_TIMEOUT_MS=10000
MESSAGING_STALE_LOCK_MINUTES=10
OPERATIONS_REPORT_SECRET=$OperationsReportSecret
PAYMENT_GATEWAY_MODE=disabled
SSLCOMMERZ_ENVIRONMENT=sandbox
SSLCOMMERZ_STORE_ID=
SSLCOMMERZ_STORE_PASSWORD=
PAYMENT_RECONCILE_SECRET=$PaymentReconcileSecret
PAYMENT_GATEWAY_TIMEOUT_MS=12000
PAYMENT_GATEWAY_ATTEMPT_TTL_MINUTES=30
PAYMENT_RECONCILE_BATCH_SIZE=25
SESSION_DAYS=14
MAX_ACTIVE_SESSIONS=8
LOGIN_MAX_ATTEMPTS=5
LOGIN_WINDOW_MINUTES=15
LOGIN_LOCK_MINUTES=15
VERIFICATION_TTL_MINUTES=15
VERIFICATION_RESEND_SECONDS=60
PASSWORD_RESET_TTL_MINUTES=30
INITIAL_SUPER_ADMIN_NAME=$(ConvertTo-DotEnvValue $OwnerName)
INITIAL_SUPER_ADMIN_EMAIL=$(ConvertTo-DotEnvValue $OwnerEmail)
INITIAL_SUPER_ADMIN_PASSWORD=$OwnerPassword
INITIAL_MEMBER_NAME=""
INITIAL_MEMBER_EMAIL=""
INITIAL_MEMBER_PHONE=""
INITIAL_MEMBER_PASSWORD=""
"@
$EnvironmentB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($EnvironmentText))
Invoke-Checked -Message "Client environment upload failed" -Command {
    ssh.exe -i $KeyPath -p $SshPort "holydeploy@$VpsHost" "printf '%s' '$EnvironmentB64' | base64 -d > /opt/holy-life/.env.production && chmod 600 /opt/holy-life/.env.production"
}

$TokenB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($GitHubToken))
Invoke-Checked -Message "Client VPS GHCR authentication failed" -Command {
    ssh.exe -i $KeyPath -p $SshPort "holydeploy@$VpsHost" "printf '%s' '$TokenB64' | base64 -d | docker login ghcr.io -u '$GitHubUser' --password-stdin"
}

gh api --method PUT "repos/$Repository/environments/$EnvironmentName" *> $null
(Get-Content $KeyPath -Raw) | gh secret set VPS_SSH_PRIVATE_KEY --repo $Repository --env $EnvironmentName
$VpsHost | gh secret set VPS_HOST --repo $Repository --env $EnvironmentName
"holydeploy" | gh secret set VPS_USER --repo $Repository --env $EnvironmentName
"$SshPort" | gh secret set VPS_SSH_PORT --repo $Repository --env $EnvironmentName
gh variable set APP_DOMAIN --repo $Repository --env $EnvironmentName --body $Domain
gh variable set DEPLOY_PATH --repo $Repository --env $EnvironmentName --body "/opt/holy-life"

$ProtectionBody = @{
    wait_timer = 0
    prevent_self_review = $false
    reviewers = @(@{ type = "User"; id = [int64]$ReviewerId })
    deployment_branch_policy = $null
} | ConvertTo-Json -Depth 10
try {
    $ProtectionBody | gh api --method PUT "repos/$Repository/environments/$EnvironmentName" --input - *> $null
    Write-Host "Production environment reviewer protection configured." -ForegroundColor Green
}
catch {
    Write-Warning "GitHub plan/repository settings did not accept required-reviewer protection. The workflow still requires explicit DEPLOY_PRODUCTION confirmation."
}

Write-Host "Installing client off-site backup, monitoring, restore tests, and SSH hardening..." -ForegroundColor Cyan
& (Join-Path $PSScriptRoot "RUN_PHASE4_AND_HARDENING.ps1") `
    -Repository $Repository -VpsHost $VpsHost -Domain $Domain -SshPort $SshPort -RootUser $RootUser -SkipGitPushAndCi

$OpsKey = Join-Path $HOME ".ssh\holy_life_ops_ed25519"
if (-not (Test-Path $OpsKey)) { throw "Operations key was not created." }
(Get-Content $OpsKey -Raw) | gh secret set VPS_SSH_PRIVATE_KEY --repo $Repository --env $EnvironmentName
"holyops" | gh secret set VPS_USER --repo $Repository --env $EnvironmentName

Push-Location $ProjectRoot
try { $ReleaseSha = (git rev-parse HEAD).Trim() }
finally { Pop-Location }

gh workflow run "Holy Life Client Production Deployment" --repo $Repository `
    -f "release_sha=$ReleaseSha" -f "confirmation=DEPLOY_PRODUCTION"
Start-Sleep -Seconds 6
$RunJson = gh run list --repo $Repository --workflow "Holy Life Client Production Deployment" --limit 1 --json databaseId | ConvertFrom-Json
$RunId = $RunJson[0].databaseId
Invoke-Checked -Message "Client production deployment failed" -Command { gh run watch $RunId --repo $Repository --exit-status }

$CredentialPath = Join-Path $HOME "Downloads\Holy-Life-Client-Initial-Credentials.txt"
$Text = @"
Holy Life client production initial credentials
URL: https://$Domain
Owner: $OwnerName
Owner email: $OwnerEmail
Owner password: $OwnerPassword
Client deploy private key: $KeyPath

Change the owner password after the first login and move this file into an encrypted vault.
"@
[IO.File]::WriteAllText($CredentialPath, $Text, [Text.UTF8Encoding]::new($false))
Write-Host "CLIENT PRODUCTION DEPLOYMENT COMPLETED" -ForegroundColor Green
Write-Host "Live URL: https://$Domain" -ForegroundColor Green
Write-Host "Credentials: $CredentialPath" -ForegroundColor Yellow
