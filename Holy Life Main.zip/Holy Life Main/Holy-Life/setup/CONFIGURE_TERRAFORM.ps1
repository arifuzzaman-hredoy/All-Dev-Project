param(
    [string] $Repository = "techtemlead-lab/Holy_Life",
    [string] $EnvironmentName = "demo",
    [string] $VpsHost = "198.54.121.88",
    [string] $VpsUser = "holydeploy",
    [int] $VpsPort = 22,
    [string] $Domain = "holylife.techteamlead.com",
    [switch] $AutoApply,
    [switch] $ReconcileEnvironmentVariables
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$TerraformDirectory = Join-Path $ProjectRoot "infrastructure\terraform\github-environment"

function Invoke-NativeChecked {
    param(
        [Parameter(Mandatory)] [scriptblock] $Command,
        [Parameter(Mandatory)] [string] $FailureMessage
    )

    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$FailureMessage (exit $LASTEXITCODE)"
    }
}

if (-not (Get-Command terraform.exe -ErrorAction SilentlyContinue)) {
    & (Join-Path $PSScriptRoot "01_INSTALL_REQUIRED_TOOLS.ps1")
}
if (-not (Get-Command gh.exe -ErrorAction SilentlyContinue)) {
    throw "GitHub CLI is not installed."
}

& gh.exe auth status *> $null
if ($LASTEXITCODE -ne 0) {
    Invoke-NativeChecked -FailureMessage "GitHub authentication failed" -Command {
        & gh.exe auth login --hostname github.com --web --git-protocol https
    }
}

$token = & gh.exe auth token
if ([string]::IsNullOrWhiteSpace($token)) {
    throw "GitHub token could not be read from GitHub CLI."
}

$parts = $Repository.Split("/", 2)
if ($parts.Count -ne 2) {
    throw "Repository must use owner/name format."
}

$managedVariableNames = @(
    "APP_BIND_PORT",
    "APP_DOMAIN",
    "DEPLOY_PATH",
    "TIMEZONE",
    "VPS_HOST",
    "VPS_SSH_PORT",
    "VPS_USER"
)

$env:TF_VAR_github_token = $token
Push-Location $TerraformDirectory
try {
    Invoke-NativeChecked -FailureMessage "Terraform initialization failed" -Command {
        & terraform.exe init
    }

    Invoke-NativeChecked -FailureMessage "Terraform formatting failed" -Command {
        & terraform.exe fmt -recursive
    }

    Invoke-NativeChecked -FailureMessage "Terraform validation failed" -Command {
        & terraform.exe validate
    }

    if ($ReconcileEnvironmentVariables) {
        Write-Host "Reconciling non-secret GitHub environment variables..." -ForegroundColor Cyan
        foreach ($variableName in $managedVariableNames) {
            & gh.exe api `
                --method DELETE `
                "repos/$Repository/environments/$EnvironmentName/variables/$variableName" `
                *> $null

            if ($LASTEXITCODE -eq 0) {
                Write-Host "Removed pre-existing variable for Terraform adoption: $variableName" -ForegroundColor DarkGray
            }
        }
    }

    Invoke-NativeChecked -FailureMessage "Terraform plan failed" -Command {
        & terraform.exe plan `
            -var "github_owner=$($parts[0])" `
            -var "repository=$($parts[1])" `
            -var "environment_name=$EnvironmentName" `
            -var "vps_host=$VpsHost" `
            -var "vps_user=$VpsUser" `
            -var "vps_ssh_port=$VpsPort" `
            -var "app_domain=$Domain" `
            -out "holy-life-demo.tfplan"
    }

    $shouldApply = $AutoApply
    if (-not $shouldApply) {
        $apply = Read-Host "Terraform plan is ready. Type APPLY to create/update the GitHub environment"
        $shouldApply = $apply -ceq "APPLY"
    }

    if ($shouldApply) {
        Invoke-NativeChecked -FailureMessage "Terraform apply failed" -Command {
            & terraform.exe apply "holy-life-demo.tfplan"
        }
        Write-Host "Terraform environment configuration is synchronized." -ForegroundColor Green
    }
    else {
        Write-Host "Terraform apply skipped. The plan file remains local and is gitignored." -ForegroundColor Yellow
    }
}
finally {
    Pop-Location
    Remove-Item Env:\TF_VAR_github_token -ErrorAction SilentlyContinue
}
