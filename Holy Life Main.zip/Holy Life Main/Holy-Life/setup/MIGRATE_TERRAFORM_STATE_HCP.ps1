param(
    [string] $TerraformDirectory = "",
    [string] $Organization = "",
    [string] $Workspace = "holy-life-demo",
    [switch] $NonInteractive
)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($TerraformDirectory)) {
    $TerraformDirectory = Join-Path (Split-Path -Parent $PSScriptRoot) "infrastructure\terraform\github-environment"
}

function ConvertTo-PlainText([Security.SecureString] $Value) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

if ([string]::IsNullOrWhiteSpace($Organization)) {
    $Organization = Read-Host "HCP Terraform organization name"
}
if ([string]::IsNullOrWhiteSpace($Organization)) { throw "HCP Terraform organization is required." }
if ([string]::IsNullOrWhiteSpace($Workspace)) { throw "HCP Terraform workspace is required." }

$TokenSecure = Read-Host "HCP Terraform user/team token" -AsSecureString
$Token = ConvertTo-PlainText $TokenSecure
if ([string]::IsNullOrWhiteSpace($Token)) { throw "HCP Terraform token is required." }

$Headers = @{
    Authorization = "Bearer $Token"
    "Content-Type" = "application/vnd.api+json"
}
$WorkspaceUri = "https://app.terraform.io/api/v2/organizations/$Organization/workspaces/$Workspace"
try {
    $null = Invoke-RestMethod -Method Get -Uri $WorkspaceUri -Headers $Headers
    Write-Host "HCP workspace already exists: $Organization/$Workspace" -ForegroundColor Cyan
}
catch {
    if ($_.Exception.Response.StatusCode.value__ -ne 404) { throw }
    $Body = @{
        data = @{
            type = "workspaces"
            attributes = @{
                name = $Workspace
                "execution-mode" = "local"
                "auto-apply" = $false
            }
        }
    } | ConvertTo-Json -Depth 10
    $CreateUri = "https://app.terraform.io/api/v2/organizations/$Organization/workspaces"
    $null = Invoke-RestMethod -Method Post -Uri $CreateUri -Headers $Headers -Body $Body
    Write-Host "Created HCP workspace: $Organization/$Workspace" -ForegroundColor Green
}

$CloudFile = Join-Path $TerraformDirectory "cloud.auto.tf"
$BackupDirectory = Join-Path $TerraformDirectory (".state-migration-backup\" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
foreach ($name in @("terraform.tfstate", "terraform.tfstate.backup", "cloud.auto.tf")) {
    $path = Join-Path $TerraformDirectory $name
    if (Test-Path -LiteralPath $path) { Copy-Item $path $BackupDirectory -Force }
}

$CloudConfig = @"
terraform {
  cloud {
    organization = "$Organization"

    workspaces {
      name = "$Workspace"
    }
  }
}
"@
[IO.File]::WriteAllText($CloudFile, $CloudConfig, [Text.UTF8Encoding]::new($false))

$oldToken = $env:TF_TOKEN_app_terraform_io
$oldGitHubToken = $env:TF_VAR_github_token
$env:TF_TOKEN_app_terraform_io = $Token
if ([string]::IsNullOrWhiteSpace($env:TF_VAR_github_token)) {
    $env:TF_VAR_github_token = (gh auth token).Trim()
}
Push-Location $TerraformDirectory
try {
    terraform fmt cloud.auto.tf
    terraform init -migrate-state -force-copy
    if ($LASTEXITCODE -ne 0) { throw "Terraform state migration failed." }
    terraform state list
    if ($LASTEXITCODE -ne 0) { throw "Remote state verification failed." }
    terraform plan -lock-timeout=5m -out=remote-state-verification.tfplan
    if ($LASTEXITCODE -ne 0) { throw "Remote-state Terraform plan failed." }
    Remove-Item remote-state-verification.tfplan -Force -ErrorAction SilentlyContinue
}
finally {
    Pop-Location
    $env:TF_TOKEN_app_terraform_io = $oldToken
    $env:TF_VAR_github_token = $oldGitHubToken
    $Token = $null
}

Write-Host "" 
Write-Host "HCP TERRAFORM REMOTE STATE MIGRATION COMPLETED" -ForegroundColor Green
Write-Host "Workspace: $Organization/$Workspace"
Write-Host "Local safety backup: $BackupDirectory"
Write-Host "The HCP token was not written to the repository." -ForegroundColor Yellow
