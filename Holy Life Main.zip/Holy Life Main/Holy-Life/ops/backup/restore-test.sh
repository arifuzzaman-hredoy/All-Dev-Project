#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
STATE_DIR="${STATE_DIR:-/var/lib/holy-life-ops}"
LOCK_FILE="$STATE_DIR/restore-test.lock"
SUCCESS_FILE="$STATE_DIR/last-restore-test-success"
REPORTER="$APP_DIR/ops/operations/report-run.sh"
TMP_DIR="$(mktemp -d /var/tmp/holy-life-restore-test.XXXXXX)"
TEST_DB="holy_life_restore_test_$(date +%s)"
HOST="$(hostname -f 2>/dev/null || hostname)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
RUN_KEY="restore-test-${HOST}-${STAMP}"
RELEASE="$(awk -F= '$1=="RELEASE_SHA"{print $2}' "$APP_DIR/releases/current.env" 2>/dev/null || true)"
FINAL_STATUS="FAILED"
FINAL_SUMMARY="Restore verification interrupted."
SNAPSHOT_ID=""

umask 077
mkdir -p "$STATE_DIR"
exec 9>"$LOCK_FILE"
flock -n 9 || { echo "Another restore test is running."; exit 75; }

# shellcheck disable=SC1090
source "$OPS_ENV"
export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-auto}"
export AWS_REGION="$AWS_DEFAULT_REGION"
export RESTIC_CACHE_DIR="${RESTIC_CACHE_DIR:-/var/cache/holy-life-restic}"

POSTGRES_USER="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_USER)"
POSTGRES_DB="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_DB)"

cleanup_db() {
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
    psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d postgres \
    -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='$TEST_DB' AND pid <> pg_backend_pid();" \
    -c "DROP DATABASE IF EXISTS \"$TEST_DB\";" >/dev/null 2>&1 || true
}

report_final() {
  local exit_code=$?
  local finished_at
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  cleanup_db

  if [[ "$exit_code" -eq 0 && "$FINAL_STATUS" == "SUCCEEDED" ]]; then
    "$REPORTER" --run-key "$RUN_KEY" --kind RESTORE_TEST --status SUCCEEDED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --snapshot-id "$SNAPSHOT_ID" --summary "$FINAL_SUMMARY" || true
  else
    "$REPORTER" --run-key "$RUN_KEY" --kind RESTORE_TEST --status FAILED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --snapshot-id "$SNAPSHOT_ID" --summary "$FINAL_SUMMARY" \
      --metadata-json "{\"exitCode\":$exit_code}" || true
  fi

  rm -rf "$TMP_DIR"
  return "$exit_code"
}
trap report_final EXIT

printf '[restore-test] Reading latest snapshot identity...\n'
SNAPSHOT_ID="$(restic snapshots --json --tag holy-life | python3 -c '
import json,sys
rows=json.load(sys.stdin)
rows=sorted(rows,key=lambda item:item.get("time",""))
print(rows[-1]["id"] if rows else "")
')"
[[ -n "$SNAPSHOT_ID" ]] || { FINAL_SUMMARY="No Holy Life backup snapshot is available."; exit 4; }

printf '[restore-test] Downloading database dump and manifest from snapshot %s...\n' "$SNAPSHOT_ID"
restic dump "$SNAPSHOT_ID" database.dump > "$TMP_DIR/database.dump" 2>/dev/null || \
  restic dump "$SNAPSHOT_ID" /database.dump > "$TMP_DIR/database.dump"
restic dump "$SNAPSHOT_ID" manifest.json > "$TMP_DIR/manifest.json" 2>/dev/null || \
  restic dump "$SNAPSHOT_ID" /manifest.json > "$TMP_DIR/manifest.json"
test -s "$TMP_DIR/database.dump"
test -s "$TMP_DIR/manifest.json"

EXPECTED_SHA="$(python3 - "$TMP_DIR/manifest.json" <<'PY'
import json,sys
data=json.load(open(sys.argv[1], encoding="utf-8"))
print(data.get("databaseSha256",""))
PY
)"
if [[ -n "$EXPECTED_SHA" ]]; then
  ACTUAL_SHA="$(sha256sum "$TMP_DIR/database.dump" | awk '{print $1}')"
  [[ "$ACTUAL_SHA" == "$EXPECTED_SHA" ]] || {
    FINAL_SUMMARY="Restored dump checksum does not match backup manifest."
    exit 4
  }
fi

printf '[restore-test] Verifying archive table of contents...\n'
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_restore --list < "$TMP_DIR/database.dump" > "$TMP_DIR/database.list"
test -s "$TMP_DIR/database.list"

cleanup_db
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  createdb -U "$POSTGRES_USER" -T template0 "$TEST_DB"
cat "$TMP_DIR/database.dump" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_restore --exit-on-error --no-owner --no-privileges -U "$POSTGRES_USER" -d "$TEST_DB"

MIGRATIONS="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -At -U "$POSTGRES_USER" -d "$TEST_DB" -c 'SELECT count(*) FROM "_prisma_migrations" WHERE "finished_at" IS NOT NULL;')"
TABLES="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -At -U "$POSTGRES_USER" -d "$TEST_DB" -c "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';")"

for critical_table in WebsitePage PaymentAccount Appointment Prescription PatientClinicalProfile CommerceOrder CourseEnrollment; do
  present="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
    psql -At -U "$POSTGRES_USER" -d "$TEST_DB" \
    -c "SELECT to_regclass('\"$critical_table\"') IS NOT NULL;")"
  [[ "$present" == "t" ]] || {
    FINAL_SUMMARY="Restore test failed: critical table $critical_table is missing."
    exit 4
  }
done

[[ "${MIGRATIONS:-0}" -gt 0 ]] || { FINAL_SUMMARY="Restore test found no completed Prisma migrations."; exit 4; }
[[ "${TABLES:-0}" -gt 20 ]] || { FINAL_SUMMARY="Restore test found too few public tables."; exit 4; }

cleanup_db
date -u +%Y-%m-%dT%H:%M:%SZ > "$SUCCESS_FILE"
chmod 600 "$SUCCESS_FILE"
FINAL_STATUS="SUCCEEDED"
FINAL_SUMMARY="Isolated restore passed with checksum, schema, migration, and critical-table verification."
printf '[restore-test] Restore verification passed. Snapshot: %s, tables: %s, migrations: %s.\n' "$SNAPSHOT_ID" "$TABLES" "$MIGRATIONS"
