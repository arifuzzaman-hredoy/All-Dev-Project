#!/usr/bin/env bash
set -Eeuo pipefail

[[ "${CONFIRM_RESTORE:-}" == "YES_RESTORE_HOLY_LIFE" ]] || {
  echo "Refusing destructive restore. Set CONFIRM_RESTORE=YES_RESTORE_HOLY_LIFE." >&2
  exit 64
}

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
REPORTER="$APP_DIR/ops/operations/report-run.sh"
TMP_DIR="$(mktemp -d /var/tmp/holy-life-disaster-restore.XXXXXX)"
HOST="$(hostname -f 2>/dev/null || hostname)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
RUN_KEY="restore-${HOST}-${STAMP}"
RELEASE="$(awk -F= '$1=="RELEASE_SHA"{print $2}' "$APP_DIR/releases/current.env" 2>/dev/null || true)"
FINAL_STATUS="FAILED"
FINAL_SUMMARY="Disaster restore interrupted."
SNAPSHOT_ID=""

# shellcheck disable=SC1090
source "$OPS_ENV"
export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-auto}"
export AWS_REGION="$AWS_DEFAULT_REGION"
export RESTIC_CACHE_DIR="${RESTIC_CACHE_DIR:-/var/cache/holy-life-restic}"

POSTGRES_USER="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_USER)"
POSTGRES_DB="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_DB)"

report_final() {
  local exit_code=$?
  local finished_at
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

  if [[ "$exit_code" -eq 0 && "$FINAL_STATUS" == "SUCCEEDED" ]]; then
    "$REPORTER" --run-key "$RUN_KEY" --kind RESTORE --status SUCCEEDED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --snapshot-id "$SNAPSHOT_ID" --summary "$FINAL_SUMMARY" || true
  else
    "$REPORTER" --run-key "$RUN_KEY" --kind RESTORE --status FAILED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --snapshot-id "$SNAPSHOT_ID" --summary "$FINAL_SUMMARY" \
      --metadata-json "{\"exitCode\":$exit_code}" || true
  fi

  rm -rf "$TMP_DIR"
  return "$exit_code"
}
trap report_final EXIT

"$APP_DIR/deploy/backup-database.sh" || true

SNAPSHOT_ID="$(restic snapshots --json --tag holy-life | python3 -c '
import json,sys
rows=json.load(sys.stdin)
rows=sorted(rows,key=lambda item:item.get("time",""))
print(rows[-1]["id"] if rows else "")
')"
[[ -n "$SNAPSHOT_ID" ]] || { FINAL_SUMMARY="No Holy Life backup snapshot is available."; exit 4; }

restic dump "$SNAPSHOT_ID" database.dump > "$TMP_DIR/database.dump" 2>/dev/null || \
  restic dump "$SNAPSHOT_ID" /database.dump > "$TMP_DIR/database.dump"
restic dump "$SNAPSHOT_ID" manifest.json > "$TMP_DIR/manifest.json" 2>/dev/null || \
  restic dump "$SNAPSHOT_ID" /manifest.json > "$TMP_DIR/manifest.json"
test -s "$TMP_DIR/database.dump"

EXPECTED_SHA="$(python3 - "$TMP_DIR/manifest.json" <<'PY'
import json,sys
data=json.load(open(sys.argv[1], encoding="utf-8"))
print(data.get("databaseSha256",""))
PY
)"
if [[ -n "$EXPECTED_SHA" ]]; then
  ACTUAL_SHA="$(sha256sum "$TMP_DIR/database.dump" | awk '{print $1}')"
  [[ "$ACTUAL_SHA" == "$EXPECTED_SHA" ]] || {
    FINAL_SUMMARY="Disaster restore aborted: backup dump checksum mismatch."
    exit 4
  }
fi

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_restore --list < "$TMP_DIR/database.dump" > "$TMP_DIR/database.list"
test -s "$TMP_DIR/database.list"

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" stop app
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d postgres \
  -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='$POSTGRES_DB' AND pid <> pg_backend_pid();" \
  -c "DROP DATABASE IF EXISTS \"$POSTGRES_DB\";" \
  -c "CREATE DATABASE \"$POSTGRES_DB\" OWNER \"$POSTGRES_USER\";"
cat "$TMP_DIR/database.dump" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_restore --exit-on-error --no-owner --no-privileges -U "$POSTGRES_USER" -d "$POSTGRES_DB"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --no-deps --wait app
"$APP_DIR/deploy/health-check.sh" "http://127.0.0.1:$(python3 "$DOTENV_READER" "$ENV_FILE" APP_BIND_PORT 3100)/api/health"

FINAL_STATUS="SUCCEEDED"
FINAL_SUMMARY="Latest encrypted off-site snapshot restored and application health verified."
echo "Snapshot $SNAPSHOT_ID restored successfully."
