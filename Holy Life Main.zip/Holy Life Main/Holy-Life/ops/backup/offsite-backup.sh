#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
STATE_DIR="${STATE_DIR:-/var/lib/holy-life-ops}"
STAGE_ROOT="$STATE_DIR/backup-stage"
LOCK_FILE="$STATE_DIR/offsite-backup.lock"
SUCCESS_FILE="$STATE_DIR/last-backup-success"
REPORTER="$APP_DIR/ops/operations/report-run.sh"

umask 077
mkdir -p "$STATE_DIR" "$STAGE_ROOT"
exec 9>"$LOCK_FILE"
flock -n 9 || { echo "Another off-site backup is already running."; exit 75; }

[[ -r "$OPS_ENV" ]] || { echo "Missing $OPS_ENV" >&2; exit 2; }
[[ -r "$ENV_FILE" && -r "$COMPOSE_FILE" && -x "$DOTENV_READER" ]] || {
  echo "Holy Life deployment files are incomplete." >&2
  exit 2
}

# shellcheck disable=SC1090
source "$OPS_ENV"
: "${RESTIC_REPOSITORY:?RESTIC_REPOSITORY is required}"
: "${RESTIC_PASSWORD:?RESTIC_PASSWORD is required}"
: "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID is required}"
: "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY is required}"

export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-auto}"
export AWS_REGION="$AWS_DEFAULT_REGION"
export RESTIC_CACHE_DIR="${RESTIC_CACHE_DIR:-/var/cache/holy-life-restic}"
mkdir -p "$RESTIC_CACHE_DIR"

POSTGRES_USER="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_USER)"
POSTGRES_DB="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_DB)"
RELEASE="$(awk -F= '$1=="RELEASE_SHA"{print $2}' "$APP_DIR/releases/current.env" 2>/dev/null || true)"
HOST="$(hostname -f 2>/dev/null || hostname)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
RUN_KEY="backup-${HOST}-${STAMP}"
STAGE="$STAGE_ROOT/$STAMP"
RESTIC_OUTPUT="$STATE_DIR/restic-backup-${STAMP}.jsonl"
FINAL_STATUS="FAILED"
FINAL_SUMMARY="Backup interrupted."
SNAPSHOT_ID=""

mkdir -p "$STAGE/release"

report_final() {
  local exit_code=$?
  local finished_at
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

  if [[ "$exit_code" -eq 0 && "$FINAL_STATUS" == "SUCCEEDED" ]]; then
    "$REPORTER" \
      --run-key "$RUN_KEY" \
      --kind BACKUP \
      --status SUCCEEDED \
      --started-at "$STARTED_AT" \
      --finished-at "$finished_at" \
      --host "$HOST" \
      --release "$RELEASE" \
      --snapshot-id "$SNAPSHOT_ID" \
      --summary "$FINAL_SUMMARY" \
      --metadata-json "{\"database\":\"$POSTGRES_DB\"}" || true
  else
    "$REPORTER" \
      --run-key "$RUN_KEY" \
      --kind BACKUP \
      --status FAILED \
      --started-at "$STARTED_AT" \
      --finished-at "$finished_at" \
      --host "$HOST" \
      --release "$RELEASE" \
      --summary "$FINAL_SUMMARY" \
      --metadata-json "{\"database\":\"$POSTGRES_DB\",\"exitCode\":$exit_code}" || true
  fi

  rm -rf "$STAGE"
  rm -f "$RESTIC_OUTPUT"
  return "$exit_code"
}
trap report_final EXIT

DB_ID="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps -q db)"
[[ -n "$DB_ID" ]] || { FINAL_SUMMARY="Database container is unavailable."; exit 3; }
[[ "$(docker inspect --format '{{.State.Running}}' "$DB_ID")" == "true" ]] || {
  FINAL_SUMMARY="Database container is not running."
  exit 3
}

printf '[backup] Creating PostgreSQL custom-format dump...\n'
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_dump -Fc --no-owner --no-privileges -U "$POSTGRES_USER" "$POSTGRES_DB" \
  > "$STAGE/database.dump"
test -s "$STAGE/database.dump"

printf '[backup] Verifying archive table of contents...\n'
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_restore --list < "$STAGE/database.dump" > "$STAGE/database.list"
test -s "$STAGE/database.list"

DB_SHA256="$(sha256sum "$STAGE/database.dump" | awk '{print $1}')"
DB_BYTES="$(stat -c '%s' "$STAGE/database.dump")"
printf '%s  database.dump\n' "$DB_SHA256" > "$STAGE/database.dump.sha256"

cp --preserve=mode,timestamps "$ENV_FILE" "$STAGE/release/.env.production"
cp --preserve=mode,timestamps "$COMPOSE_FILE" "$STAGE/release/compose.production.yml"
[[ -f "$APP_DIR/releases/current.env" ]] && cp "$APP_DIR/releases/current.env" "$STAGE/release/current.env"
[[ -f "$APP_DIR/releases/previous.env" ]] && cp "$APP_DIR/releases/previous.env" "$STAGE/release/previous.env"

cat > "$STAGE/manifest.json" <<JSON
{
  "application": "Holy Life",
  "createdAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "hostname": "$HOST",
  "database": "$POSTGRES_DB",
  "databaseSha256": "$DB_SHA256",
  "databaseBytes": $DB_BYTES,
  "release": "$RELEASE"
}
JSON

if ! restic snapshots --json >/dev/null 2>&1; then
  printf '[backup] Initializing encrypted restic repository...\n'
  restic init
fi

printf '[backup] Uploading encrypted snapshot to off-site object storage...\n'
(
  cd "$STAGE"
  restic backup . \
    --json \
    --tag holy-life \
    --tag database \
    --host "$(hostname -s)" \
    --exclude-caches
) | tee "$RESTIC_OUTPUT"

SNAPSHOT_ID="$(python3 - "$RESTIC_OUTPUT" <<'PY'
import json
import sys
snapshot = ""
for line in open(sys.argv[1], encoding="utf-8"):
    try:
        payload = json.loads(line)
    except json.JSONDecodeError:
        continue
    if payload.get("message_type") == "summary":
        snapshot = payload.get("snapshot_id") or snapshot
print(snapshot)
PY
)"
[[ -n "$SNAPSHOT_ID" ]] || { FINAL_SUMMARY="Restic did not return a snapshot ID."; exit 5; }

printf '[backup] Applying retention policy...\n'
restic forget \
  --tag holy-life \
  --keep-last "${RESTIC_KEEP_LAST:-2}" \
  --keep-daily "${RESTIC_KEEP_DAILY:-7}" \
  --keep-weekly "${RESTIC_KEEP_WEEKLY:-4}" \
  --keep-monthly "${RESTIC_KEEP_MONTHLY:-6}" \
  --keep-yearly "${RESTIC_KEEP_YEARLY:-2}"

if [[ "$(date -u +%u)" == "7" ]]; then
  restic prune
fi

date -u +%Y-%m-%dT%H:%M:%SZ > "$SUCCESS_FILE"
chmod 600 "$SUCCESS_FILE"
FINAL_STATUS="SUCCEEDED"
FINAL_SUMMARY="Encrypted off-site backup completed and archive structure verified."
printf '[backup] Off-site backup completed at %s. Snapshot: %s\n' "$(cat "$SUCCESS_FILE")" "$SNAPSHOT_ID"
