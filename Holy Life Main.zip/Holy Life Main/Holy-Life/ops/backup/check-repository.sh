#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
STATE_DIR="${STATE_DIR:-/var/lib/holy-life-ops}"
LOCK_FILE="$STATE_DIR/restic-check.lock"
SUCCESS_FILE="$STATE_DIR/last-repository-check-success"
REPORTER="$APP_DIR/ops/operations/report-run.sh"
HOST="$(hostname -f 2>/dev/null || hostname)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
RUN_KEY="repository-check-${HOST}-${STAMP}"
RELEASE="$(awk -F= '$1=="RELEASE_SHA"{print $2}' "$APP_DIR/releases/current.env" 2>/dev/null || true)"
FINAL_STATUS="FAILED"
FINAL_SUMMARY="Repository integrity check interrupted."

umask 077
mkdir -p "$STATE_DIR"
exec 9>"$LOCK_FILE"
flock -n 9 || { echo "Another repository check is running."; exit 75; }

# shellcheck disable=SC1090
source "$OPS_ENV"

if [[ "${CHECK_REPOSITORY_INTEGRITY:-true}" != "true" ]]; then
  printf '[restic-check] Repository integrity checks are disabled by operations mode.\n'
  exit 0
fi

: "${RESTIC_REPOSITORY:?RESTIC_REPOSITORY is required when repository integrity checks are enabled}"
: "${RESTIC_PASSWORD:?RESTIC_PASSWORD is required when repository integrity checks are enabled}"
if [[ "$RESTIC_REPOSITORY" == s3:* ]]; then
  : "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID is required for an S3 restic repository}"
  : "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY is required for an S3 restic repository}"
fi

export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-auto}"
export AWS_REGION="$AWS_DEFAULT_REGION"
export RESTIC_CACHE_DIR="${RESTIC_CACHE_DIR:-/var/cache/holy-life-restic}"

report_final() {
  local exit_code=$?
  local finished_at
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

  if [[ "$exit_code" -eq 0 && "$FINAL_STATUS" == "SUCCEEDED" ]]; then
    "$REPORTER" --run-key "$RUN_KEY" --kind REPOSITORY_CHECK --status SUCCEEDED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --summary "$FINAL_SUMMARY" || true
  else
    "$REPORTER" --run-key "$RUN_KEY" --kind REPOSITORY_CHECK --status FAILED \
      --started-at "$STARTED_AT" --finished-at "$finished_at" --host "$HOST" \
      --release "$RELEASE" --summary "$FINAL_SUMMARY" \
      --metadata-json "{\"exitCode\":$exit_code}" || true
  fi

  return "$exit_code"
}
trap report_final EXIT

SUBSET="${RESTIC_CHECK_DATA_SUBSET:-10%}"
printf '[restic-check] Checking repository metadata and %s of stored data...\n' "$SUBSET"
restic check --read-data-subset="$SUBSET"

date -u +%Y-%m-%dT%H:%M:%SZ > "$SUCCESS_FILE"
chmod 600 "$SUCCESS_FILE"
FINAL_STATUS="SUCCEEDED"
FINAL_SUMMARY="Restic repository metadata and rotating data subset verified."
printf '[restic-check] Repository integrity check passed at %s.\n' "$(cat "$SUCCESS_FILE")"
