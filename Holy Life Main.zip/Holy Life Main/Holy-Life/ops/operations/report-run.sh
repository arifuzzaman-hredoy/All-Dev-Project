#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
ENV_FILE="$APP_DIR/.env.production"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"

[[ -r "$OPS_ENV" ]] || exit 0
# shellcheck disable=SC1090
set -a
source "$OPS_ENV"
set +a

[[ -n "${OPERATIONS_REPORT_SECRET:-}" ]] || exit 0

APP_BIND_PORT="$(python3 "$DOTENV_READER" "$ENV_FILE" APP_BIND_PORT 3100)"
REPORT_URL="${OPERATIONS_REPORT_URL:-http://127.0.0.1:${APP_BIND_PORT}/api/internal/operations/report}"

exec python3 "$APP_DIR/ops/operations/report-run.py" --url "$REPORT_URL" "$@"
