#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--run-key", required=True)
    parser.add_argument("--kind", required=True)
    parser.add_argument("--status", required=True)
    parser.add_argument("--started-at", required=True)
    parser.add_argument("--finished-at")
    parser.add_argument("--host")
    parser.add_argument("--release")
    parser.add_argument("--snapshot-id")
    parser.add_argument("--summary")
    parser.add_argument("--metadata-json")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    report_key = os.environ.get("OPERATIONS_REPORT_SECRET", "").strip()
    if not report_key:
        print("Operational reporting secret is not configured; telemetry was skipped.", file=sys.stderr)
        return 0

    metadata = None
    if args.metadata_json:
        metadata = json.loads(args.metadata_json)
        if not isinstance(metadata, dict):
            raise ValueError("metadata must be a JSON object")

    payload = {
        "runKey": args.run_key,
        "kind": args.kind,
        "status": args.status,
        "startedAt": args.started_at,
        "finishedAt": args.finished_at,
        "host": args.host,
        "release": args.release,
        "snapshotId": args.snapshot_id,
        "summary": args.summary,
        "metadata": metadata,
    }
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(
        args.url,
        data=body,
        headers={
            "Authorization": f"Bearer {report_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            if response.status < 200 or response.status >= 300:
                raise RuntimeError(f"report endpoint returned HTTP {response.status}")
    except urllib.error.HTTPError as exc:
        print(f"Operational report endpoint rejected telemetry: HTTP {exc.code}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Operational report endpoint is unavailable: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
