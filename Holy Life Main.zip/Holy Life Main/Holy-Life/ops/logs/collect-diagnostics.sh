#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/opt/holy-life}"
OUT_DIR="${OUT_DIR:-$APP_DIR/diagnostics}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
mkdir -p "$OUT_DIR"
chmod 700 "$OUT_DIR"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
out="$OUT_DIR/holy-life-diagnostics-$stamp.txt"
{
  echo "Holy Life diagnostics - $(date -Is)"
  echo; echo '== HOST =='; uname -a; uptime; free -h; df -hT
  echo; echo '== SERVICES =='; systemctl --failed --no-pager || true
  echo; echo '== FIREWALL =='; ufw status verbose || true
  echo; echo '== FAIL2BAN =='; fail2ban-client status sshd || true
  echo; echo '== DOCKER =='; docker version || true; docker system df || true
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps || true
  echo; echo '== APP LOGS (last 500) =='; journalctl CONTAINER_TAG='holy-life-holy-life-app-1' -n 500 --no-pager || journalctl -t holy-life-monitor -n 500 --no-pager || true
  echo; echo '== HOLY LIFE SYSTEMD TIMERS =='; systemctl list-timers 'holy-life-*' --all --no-pager || true
  echo; echo '== BACKUP SNAPSHOTS =='; /opt/holy-life/ops/logs/restic-snapshot-summary.sh || true
} > "$out" 2>&1
find "$OUT_DIR" -type f -name 'holy-life-diagnostics-*.txt' -mtime +14 -delete
printf '%s\n' "$out"
