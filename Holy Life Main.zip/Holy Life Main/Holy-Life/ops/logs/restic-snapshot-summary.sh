#!/usr/bin/env bash
set -Eeuo pipefail
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
[[ -r "$OPS_ENV" ]] || exit 0
# shellcheck disable=SC1090
source "$OPS_ENV"
export RESTIC_REPOSITORY RESTIC_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-auto}"
export AWS_REGION="$AWS_DEFAULT_REGION"
restic snapshots --tag holy-life --latest 10
