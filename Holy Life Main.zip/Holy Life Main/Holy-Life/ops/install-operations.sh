#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"

[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 77; }
[[ -d "$APP_DIR/ops" ]] || { echo "Missing $APP_DIR/ops." >&2; exit 2; }
[[ -s "$OPS_ENV" ]] || { echo "Missing $OPS_ENV." >&2; exit 2; }

chmod 600 "$OPS_ENV"

# shellcheck disable=SC1090
set -a
source "$OPS_ENV"
set +a

normalize_bool() {
  case "${1,,}" in
    true|1|yes|on) printf 'true' ;;
    false|0|no|off|"") printf 'false' ;;
    *) echo "Invalid boolean value in operations configuration: $1" >&2; exit 2 ;;
  esac
}

CHECK_OFFSITE_BACKUP="$(normalize_bool "${CHECK_OFFSITE_BACKUP:-true}")"
CHECK_RESTORE_TEST="$(normalize_bool "${CHECK_RESTORE_TEST:-true}")"

if [[ -n "${CHECK_REPOSITORY_INTEGRITY+x}" ]]; then
  CHECK_REPOSITORY_INTEGRITY="$(normalize_bool "$CHECK_REPOSITORY_INTEGRITY")"
elif [[ "$CHECK_OFFSITE_BACKUP" == "true" || "$CHECK_RESTORE_TEST" == "true" ]]; then
  CHECK_REPOSITORY_INTEGRITY="true"
else
  CHECK_REPOSITORY_INTEGRITY="false"
fi

RESTIC_REQUIRED="false"
if [[ "$CHECK_OFFSITE_BACKUP" == "true" || "$CHECK_RESTORE_TEST" == "true" || "$CHECK_REPOSITORY_INTEGRITY" == "true" ]]; then
  RESTIC_REQUIRED="true"
fi

if [[ "$RESTIC_REQUIRED" == "true" ]]; then
  : "${RESTIC_REPOSITORY:?RESTIC_REPOSITORY is required when backup/restore/repository checks are enabled}"
  : "${RESTIC_PASSWORD:?RESTIC_PASSWORD is required when backup/restore/repository checks are enabled}"

  if [[ "$RESTIC_REPOSITORY" == s3:* ]]; then
    : "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID is required for an S3 restic repository}"
    : "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY is required for an S3 restic repository}"
  fi
fi

install -d -m 700 /var/lib/holy-life-ops /var/cache/holy-life-restic "$APP_DIR/diagnostics"
chmod +x "$APP_DIR"/ops/backup/*.sh "$APP_DIR"/ops/monitor/* "$APP_DIR"/ops/logs/*.sh \
  "$APP_DIR"/ops/messaging/*.sh "$APP_DIR"/ops/payments/*.sh \
  "$APP_DIR"/ops/operations/*.sh "$APP_DIR"/ops/operations/*.py

for unit in holy-life-offsite-backup.service holy-life-offsite-backup.timer \
            holy-life-restore-test.service holy-life-restore-test.timer \
            holy-life-monitor.service holy-life-monitor.timer \
            holy-life-diagnostics.service holy-life-diagnostics.timer \
            holy-life-messaging-dispatch.service holy-life-messaging-dispatch.timer \
            holy-life-payment-reconcile.service holy-life-payment-reconcile.timer \
            holy-life-restic-check.service holy-life-restic-check.timer; do
  install -m 644 "$APP_DIR/ops/systemd/$unit" "/etc/systemd/system/$unit"
done

systemctl daemon-reload

systemctl enable --now \
  holy-life-monitor.timer \
  holy-life-diagnostics.timer \
  holy-life-messaging-dispatch.timer \
  holy-life-payment-reconcile.timer

configure_optional_timer() {
  local enabled="$1"
  local timer="$2"
  local service="$3"

  if [[ "$enabled" == "true" ]]; then
    systemctl enable --now "$timer"
  else
    systemctl disable --now "$timer" "$service" >/dev/null 2>&1 || true
    systemctl reset-failed "$service" >/dev/null 2>&1 || true
  fi
}

configure_optional_timer \
  "$CHECK_OFFSITE_BACKUP" \
  holy-life-offsite-backup.timer \
  holy-life-offsite-backup.service

configure_optional_timer \
  "$CHECK_RESTORE_TEST" \
  holy-life-restore-test.timer \
  holy-life-restore-test.service

configure_optional_timer \
  "$CHECK_REPOSITORY_INTEGRITY" \
  holy-life-restic-check.timer \
  holy-life-restic-check.service

# Monitoring alerts are evidence, not an installer failure. A real resource alert
# (for example disk pressure) must remain visible without blocking timer installation.
systemctl start holy-life-monitor.service || true

printf 'Operations mode: offsite-backup=%s restore-test=%s repository-check=%s\n' \
  "$CHECK_OFFSITE_BACKUP" \
  "$CHECK_RESTORE_TEST" \
  "$CHECK_REPOSITORY_INTEGRITY"

systemctl list-timers 'holy-life-*' --all --no-pager
