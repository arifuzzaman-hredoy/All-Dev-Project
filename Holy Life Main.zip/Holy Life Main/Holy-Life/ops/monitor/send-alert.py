#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import smtplib
import ssl
import sys
import urllib.parse
import urllib.request
from email.message import EmailMessage


def send_telegram(subject: str, body: str) -> bool:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return False
    payload = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": f"{subject}\n\n{body}", "disable_web_page_preview": "true"}
    ).encode()
    request = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage", data=payload, method="POST"
    )
    with urllib.request.urlopen(request, timeout=15) as response:
        data = json.loads(response.read().decode("utf-8"))
    return bool(data.get("ok"))


def send_email(subject: str, body: str) -> bool:
    host = os.getenv("ALERT_SMTP_HOST", "").strip()
    to_addr = os.getenv("ALERT_EMAIL_TO", "").strip()
    if not host or not to_addr:
        return False
    port = int(os.getenv("ALERT_SMTP_PORT", "587"))
    user = os.getenv("ALERT_SMTP_USER", "").strip()
    password = os.getenv("ALERT_SMTP_PASSWORD", "")
    from_addr = os.getenv("ALERT_EMAIL_FROM", user or "holy-life-monitor@localhost")
    use_ssl = os.getenv("ALERT_SMTP_SSL", "false").lower() == "true"
    starttls = os.getenv("ALERT_SMTP_STARTTLS", "true").lower() == "true"

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = from_addr
    message["To"] = to_addr
    message.set_content(body)

    if use_ssl:
        client: smtplib.SMTP = smtplib.SMTP_SSL(host, port, timeout=20, context=ssl.create_default_context())
    else:
        client = smtplib.SMTP(host, port, timeout=20)
    try:
        client.ehlo()
        if starttls and not use_ssl:
            client.starttls(context=ssl.create_default_context())
            client.ehlo()
        if user:
            client.login(user, password)
        client.send_message(message)
    finally:
        client.quit()
    return True


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: send-alert.py SUBJECT BODY", file=sys.stderr)
        return 64
    subject, body = sys.argv[1], sys.argv[2]
    delivered = False
    errors: list[str] = []
    for sender in (send_telegram, send_email):
        try:
            delivered = sender(subject, body) or delivered
        except Exception as exc:  # alert fallback must continue
            errors.append(f"{sender.__name__}: {exc}")
    if errors:
        print("; ".join(errors), file=sys.stderr)
    if not delivered:
        print(f"ALERT (no remote channel configured): {subject}\n{body}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
