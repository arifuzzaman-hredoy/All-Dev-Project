#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
OPS_ENV="${OPS_ENV:-/etc/holy-life/ops.env}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
STATE_DIR="${STATE_DIR:-/var/lib/holy-life-ops/monitor}"
ALERT_SCRIPT="$APP_DIR/ops/monitor/send-alert.py"
mkdir -p "$STATE_DIR"

[[ -r "$OPS_ENV" ]] && { set -a; source "$OPS_ENV"; set +a; }
DOMAIN="${APP_DOMAIN:-$(python3 "$DOTENV_READER" "$ENV_FILE" APP_URL | sed -E 's#^https?://##; s#/.*$##')}"
HEALTH_URL="${HEALTH_URL:-https://$DOMAIN/api/health}"
DISK_WARN_PERCENT="${DISK_WARN_PERCENT:-85}"
MEMORY_WARN_PERCENT="${MEMORY_WARN_PERCENT:-90}"
LOAD_WARN_MULTIPLIER="${LOAD_WARN_MULTIPLIER:-2}"
BACKUP_MAX_AGE_HOURS="${BACKUP_MAX_AGE_HOURS:-30}"
RESTORE_TEST_MAX_AGE_HOURS="${RESTORE_TEST_MAX_AGE_HOURS:-192}"
REPOSITORY_CHECK_MAX_AGE_HOURS="${REPOSITORY_CHECK_MAX_AGE_HOURS:-192}"
CHECK_OFFSITE_BACKUP="${CHECK_OFFSITE_BACKUP:-true}"
CHECK_RESTORE_TEST="${CHECK_RESTORE_TEST:-true}"
if [[ -n "${CHECK_REPOSITORY_INTEGRITY+x}" ]]; then
  CHECK_REPOSITORY_INTEGRITY="${CHECK_REPOSITORY_INTEGRITY}"
elif [[ "$CHECK_OFFSITE_BACKUP" == "true" || "$CHECK_RESTORE_TEST" == "true" ]]; then
  CHECK_REPOSITORY_INTEGRITY="true"
else
  CHECK_REPOSITORY_INTEGRITY="false"
fi

problems=()

if ! curl --fail --silent --show-error --max-time 15 "$HEALTH_URL" >/dev/null; then
  problems+=("Public health endpoint failed: $HEALTH_URL")
fi

for service in db app; do
  cid="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps -q "$service" 2>/dev/null || true)"
  if [[ -z "$cid" ]] || [[ "$(docker inspect --format '{{.State.Running}}' "$cid" 2>/dev/null || true)" != "true" ]]; then
    problems+=("Docker service is not running: $service")
  fi
done

disk_used="$(df -P / | awk 'NR==2 {gsub(/%/,"",$5); print $5}')"
if (( disk_used >= DISK_WARN_PERCENT )); then
  problems+=("Root disk usage is ${disk_used}% (threshold ${DISK_WARN_PERCENT}%)")
fi

mem_used="$(free | awk '/Mem:/ {printf "%.0f", (($2-$7)/$2)*100}')"
if (( mem_used >= MEMORY_WARN_PERCENT )); then
  problems+=("Memory usage is ${mem_used}% (threshold ${MEMORY_WARN_PERCENT}%)")
fi

cpu_count="$(nproc)"
load_5="$(awk '{print $2}' /proc/loadavg)"
if awk -v l="$load_5" -v c="$cpu_count" -v m="$LOAD_WARN_MULTIPLIER" 'BEGIN{exit !(l > c*m)}'; then
  problems+=("5-minute load average is $load_5 on $cpu_count CPUs")
fi

if command -v openssl >/dev/null 2>&1 && [[ -n "$DOMAIN" ]]; then
  expiry="$(timeout 15 bash -c "echo | openssl s_client -servername '$DOMAIN' -connect '$DOMAIN:443' 2>/dev/null | openssl x509 -noout -enddate" | cut -d= -f2- || true)"
  if [[ -z "$expiry" ]]; then
    problems+=("Could not read TLS certificate for $DOMAIN")
  else
    expiry_epoch="$(date -d "$expiry" +%s)"
    days_left="$(( (expiry_epoch - $(date +%s)) / 86400 ))"
    (( days_left < 21 )) && problems+=("TLS certificate expires in ${days_left} days")
  fi
fi

check_stamp() {
  local path="$1" max_hours="$2" label="$3"
  if [[ ! -s "$path" ]]; then
    problems+=("$label success marker is missing")
    return
  fi
  local epoch age
  epoch="$(date -d "$(cat "$path")" +%s 2>/dev/null || echo 0)"
  age="$(( ($(date +%s) - epoch) / 3600 ))"
  (( age > max_hours )) && problems+=("$label is stale (${age}h, maximum ${max_hours}h)")
}
if [[ "$CHECK_OFFSITE_BACKUP" == "true" ]]; then
  check_stamp /var/lib/holy-life-ops/last-backup-success "$BACKUP_MAX_AGE_HOURS" "Off-site backup"
fi
if [[ "$CHECK_RESTORE_TEST" == "true" ]]; then
  check_stamp /var/lib/holy-life-ops/last-restore-test-success "$RESTORE_TEST_MAX_AGE_HOURS" "Restore test"
fi
if [[ "$CHECK_REPOSITORY_INTEGRITY" == "true" ]]; then
  check_stamp /var/lib/holy-life-ops/last-repository-check-success "$REPOSITORY_CHECK_MAX_AGE_HOURS" "Repository integrity check"
fi

state_key="$(printf '%s\n' "${problems[@]:-healthy}" | sha256sum | cut -d' ' -f1)"
old_key="$(cat "$STATE_DIR/last-state" 2>/dev/null || true)"
printf '%s' "$state_key" > "$STATE_DIR/last-state"

if ((${#problems[@]} > 0)); then
  body="Host: $(hostname -f 2>/dev/null || hostname)\nTime: $(date -Is)\n\n$(printf '• %s\n' "${problems[@]}")"
  logger -p daemon.err -t holy-life-monitor -- "$body"
  if [[ "$state_key" != "$old_key" ]]; then
    "$ALERT_SCRIPT" "[Holy Life] Production alert" "$body"
  fi
  exit 1
fi

logger -p daemon.info -t holy-life-monitor -- "All production checks passed."
if [[ -n "$old_key" && "$state_key" != "$old_key" ]]; then
  "$ALERT_SCRIPT" "[Holy Life] Production recovered" "All checks passed on $(hostname -f 2>/dev/null || hostname) at $(date -Is)."
fi
