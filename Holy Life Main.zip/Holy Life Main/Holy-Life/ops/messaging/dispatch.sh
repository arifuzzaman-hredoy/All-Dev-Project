#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="$APP_DIR/.env.production"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"

[[ -r "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 2; }
[[ -x "$DOTENV_READER" || -r "$DOTENV_READER" ]] || { echo "Missing $DOTENV_READER" >&2; exit 2; }

MODE="$(python3 "$DOTENV_READER" "$ENV_FILE" MESSAGING_MODE disabled)"
if [[ "$MODE" == "disabled" ]]; then
  exit 0
fi
if [[ "$MODE" != "webhook" ]]; then
  echo "Unsupported MESSAGING_MODE: $MODE" >&2
  exit 2
fi

SECRET="$(python3 "$DOTENV_READER" "$ENV_FILE" MESSAGING_DISPATCH_SECRET)"
PORT="$(python3 "$DOTENV_READER" "$ENV_FILE" APP_BIND_PORT 3100)"
[[ -n "$SECRET" ]] || { echo "MESSAGING_DISPATCH_SECRET is required." >&2; exit 2; }

CURL_CONFIG="$(mktemp)"
trap 'rm -f "$CURL_CONFIG"' EXIT
chmod 600 "$CURL_CONFIG"
printf 'header = "Authorization: Bearer %s"\n' "$SECRET" > "$CURL_CONFIG"

curl --fail --silent --show-error \
  --config "$CURL_CONFIG" \
  --max-time 45 \
  -X POST \
  "http://127.0.0.1:${PORT}/api/internal/messaging/dispatch" >/dev/null
