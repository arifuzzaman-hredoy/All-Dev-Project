#!/usr/bin/env bash
set -Eeuo pipefail

PHASE="${1:-prepare}"
OPS_USER="${OPS_USER:-holyops}"
SSH_PORT="${SSH_PORT:-22}"
OPS_PUBLIC_KEY_B64="${OPS_PUBLIC_KEY_B64:-}"

require_root() { [[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 77; }; }
require_root

prepare() {
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    fail2ban unattended-upgrades apt-listchanges auditd restic jq python3 curl ca-certificates openssl ufw

  if ! id "$OPS_USER" >/dev/null 2>&1; then
    useradd --create-home --shell /bin/bash "$OPS_USER"
  fi
  usermod -aG docker "$OPS_USER"
  install -d -m 700 -o "$OPS_USER" -g "$OPS_USER" "/home/$OPS_USER/.ssh"
  if [[ -n "$OPS_PUBLIC_KEY_B64" ]]; then
    printf '%s' "$OPS_PUBLIC_KEY_B64" | base64 -d > "/home/$OPS_USER/.ssh/authorized_keys"
    chown "$OPS_USER:$OPS_USER" "/home/$OPS_USER/.ssh/authorized_keys"
    chmod 600 "/home/$OPS_USER/.ssh/authorized_keys"
  fi
  cat > "/etc/sudoers.d/90-$OPS_USER" <<SUDO
$OPS_USER ALL=(ALL) NOPASSWD: ALL
SUDO
  chmod 440 "/etc/sudoers.d/90-$OPS_USER"
  visudo -cf "/etc/sudoers.d/90-$OPS_USER"

  install -d -m 700 /etc/holy-life /var/lib/holy-life-ops /var/cache/holy-life-restic
  chown root:root /etc/holy-life /var/lib/holy-life-ops /var/cache/holy-life-restic

  cat > /etc/fail2ban/jail.d/holy-life-sshd.local <<FAIL2BAN
[sshd]
enabled = true
port = $SSH_PORT
backend = systemd
maxretry = 5
findtime = 10m
bantime = 1h
bantime.increment = true
FAIL2BAN
  systemctl enable --now fail2ban
  fail2ban-client reload || systemctl restart fail2ban

  ufw allow 80/tcp comment 'HTTP' || true
  ufw allow 443/tcp comment 'HTTPS' || true
  ufw limit "$SSH_PORT/tcp" comment 'Rate-limited SSH' || true
  ufw --force enable

  cat > /etc/apt/apt.conf.d/20auto-upgrades <<'APT'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
APT
  cat > /etc/apt/apt.conf.d/52holy-life-unattended-upgrades <<'APT'
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
APT
  systemctl enable --now unattended-upgrades.service || true

  install -d -m 755 /etc/systemd/journald.conf.d
  cat > /etc/systemd/journald.conf.d/20-holy-life-retention.conf <<'JOURNAL'
[Journal]
Storage=persistent
Compress=yes
SystemMaxUse=1G
RuntimeMaxUse=256M
MaxRetentionSec=14day
RateLimitIntervalSec=30s
RateLimitBurst=10000
JOURNAL
  systemctl restart systemd-journald

  cat > /etc/sysctl.d/99-holy-life-security.conf <<'SYSCTL'
net.ipv4.tcp_syncookies=1
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.icmp_echo_ignore_broadcasts=1
kernel.dmesg_restrict=1
kernel.kptr_restrict=2
fs.protected_hardlinks=1
fs.protected_symlinks=1
SYSCTL
  sysctl --system >/dev/null

  systemctl enable --now auditd || true
  echo "VPS hardening preparation completed. Test $OPS_USER key login before lock phase."
}

lock_ssh() {
  getent passwd "$OPS_USER" >/dev/null
  [[ -s "/home/$OPS_USER/.ssh/authorized_keys" ]] || { echo "Operations user key is missing." >&2; exit 2; }
  install -d -m 755 /etc/ssh/sshd_config.d
  cat > /etc/ssh/sshd_config.d/99-holy-life-hardening.conf <<'SSH'
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
ChallengeResponseAuthentication no
PubkeyAuthentication yes
PermitEmptyPasswords no
X11Forwarding no
AllowTcpForwarding yes
ClientAliveInterval 300
ClientAliveCountMax 2
MaxAuthTries 4
LoginGraceTime 30
SSH
  sshd -t
  systemctl reload ssh || systemctl reload sshd
  echo "SSH root/password login disabled after verified key access."
}

case "$PHASE" in
  prepare) prepare ;;
  lock) lock_ssh ;;
  *) echo "Usage: $0 prepare|lock" >&2; exit 64 ;;
esac
