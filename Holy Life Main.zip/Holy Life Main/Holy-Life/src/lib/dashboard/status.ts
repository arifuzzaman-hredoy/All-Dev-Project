export type DashboardTone =
  "neutral" | "success" | "warning" | "danger" | "info";

export type DashboardActivityItem = {
  id: string;
  department: "HEALTHCARE" | "COMMERCE" | "LEARNING" | "SYSTEM";
  title: string;
  description: string;
  href: string;
  occurredAt: Date;
  status?: string | null;
};

export function titleCaseStatus(value: string): string {
  return value
    .toLowerCase()
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function dashboardStatusTone(value: string): DashboardTone {
  const status = value.toUpperCase();
  if (
    [
      "COMPLETED",
      "DELIVERED",
      "PAID",
      "ISSUED",
      "PUBLISHED",
      "CONFIRMED",
    ].includes(status)
  ) {
    return "success";
  }
  if (
    [
      "CANCELLED",
      "REFUNDED",
      "REJECTED",
      "REVOKED",
      "NO_SHOW",
      "FAILED",
    ].includes(status)
  ) {
    return "danger";
  }
  if (
    [
      "PENDING",
      "UNPAID",
      "PARTIAL",
      "PENDING_VERIFICATION",
      "REQUESTED",
    ].includes(status)
  ) {
    return "warning";
  }
  if (
    [
      "ACTIVE",
      "PROCESSING",
      "SHIPPED",
      "IN_PROGRESS",
      "CHECKED_IN",
      "IN_CONSULTATION",
    ].includes(status)
  ) {
    return "info";
  }
  return "neutral";
}

export function greetingForHour(hour: number): string {
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

export function mergeDashboardActivity(
  groups: DashboardActivityItem[][],
  limit = 20,
): DashboardActivityItem[] {
  return groups
    .flat()
    .sort(
      (left, right) => right.occurredAt.getTime() - left.occurredAt.getTime(),
    )
    .slice(0, Math.max(0, limit));
}

export function profileCompletion(input: {
  name?: string | null;
  email?: string | null;
  phone?: string | null;
  bloodGroup?: string | null;
  dateOfBirth?: Date | null;
  emergencyContactPhone?: string | null;
  address?: string | null;
}): number {
  const checks = [
    input.name,
    input.email,
    input.phone,
    input.bloodGroup,
    input.dateOfBirth,
    input.emergencyContactPhone,
    input.address,
  ];
  const complete = checks.filter(Boolean).length;
  return Math.round((complete / checks.length) * 100);
}
