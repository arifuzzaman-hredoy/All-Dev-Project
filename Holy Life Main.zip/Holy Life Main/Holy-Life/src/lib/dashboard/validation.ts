import type { SavedItemType } from "@/generated/prisma/client";
import { isValidBangladeshPhone, normalizePhone } from "@/lib/auth/normalize";
import { isDateInput } from "@/lib/appointments/time";

const SAVED_ITEM_TYPES = ["DOCTOR", "PRODUCT", "COURSE"] as const;

export type DashboardProfileInput = {
  name: string;
  patientPhone: string;
  gender: "MALE" | "FEMALE" | "OTHER" | "PREFER_NOT_TO_SAY" | null;
  dateOfBirth: string | null;
  bloodGroup: string | null;
  address: string | null;
  emergencyContactName: string | null;
  emergencyContactPhone: string | null;
  allergies: string | null;
};

export type DashboardAddressInput = {
  label: string;
  recipientName: string;
  phone: string;
  addressLine1: string;
  addressLine2: string | null;
  area: string | null;
  city: string;
  district: string | null;
  postalCode: string | null;
  isDefault: boolean;
};

function singleLine(value: FormDataEntryValue | null, maximum: number): string {
  return String(value ?? "")
    .trim()
    .replace(/\s+/g, " ")
    .slice(0, maximum);
}

function multiline(value: FormDataEntryValue | null, maximum: number): string {
  return String(value ?? "")
    .trim()
    .replace(/\r\n/g, "\n")
    .slice(0, maximum);
}

export function parseSavedItemType(
  value: FormDataEntryValue | null,
): SavedItemType | null {
  const normalized = String(value ?? "").toUpperCase();
  return SAVED_ITEM_TYPES.includes(
    normalized as (typeof SAVED_ITEM_TYPES)[number],
  )
    ? (normalized as SavedItemType)
    : null;
}

export function readDashboardProfile(form: FormData): DashboardProfileInput {
  const genderRaw = singleLine(form.get("gender"), 30);
  const allowedGenders = [
    "MALE",
    "FEMALE",
    "OTHER",
    "PREFER_NOT_TO_SAY",
  ] as const;
  const gender = allowedGenders.includes(
    genderRaw as (typeof allowedGenders)[number],
  )
    ? (genderRaw as DashboardProfileInput["gender"])
    : null;
  const dateOfBirthRaw = singleLine(form.get("dateOfBirth"), 10);
  const emergencyPhoneRaw = singleLine(form.get("emergencyContactPhone"), 30);

  return {
    name: singleLine(form.get("name"), 120),
    patientPhone: normalizePhone(singleLine(form.get("patientPhone"), 30)),
    gender,
    dateOfBirth: dateOfBirthRaw || null,
    bloodGroup: singleLine(form.get("bloodGroup"), 10) || null,
    address: multiline(form.get("address"), 500) || null,
    emergencyContactName:
      singleLine(form.get("emergencyContactName"), 120) || null,
    emergencyContactPhone: emergencyPhoneRaw
      ? normalizePhone(emergencyPhoneRaw)
      : null,
    allergies: multiline(form.get("allergies"), 1000) || null,
  };
}

export function validateDashboardProfile(
  input: DashboardProfileInput,
): string | null {
  if (input.name.length < 2) return "Enter your full name.";
  if (!isValidBangladeshPhone(input.patientPhone))
    return "Enter a valid Bangladesh patient phone number.";
  if (input.dateOfBirth && !isDateInput(input.dateOfBirth))
    return "Enter a valid date of birth.";
  if (
    input.emergencyContactPhone &&
    !isValidBangladeshPhone(input.emergencyContactPhone)
  ) {
    return "Enter a valid Bangladesh emergency contact number.";
  }
  return null;
}

export function readDashboardAddress(form: FormData): DashboardAddressInput {
  return {
    label: singleLine(form.get("label"), 40) || "Home",
    recipientName: singleLine(form.get("recipientName"), 120),
    phone: normalizePhone(singleLine(form.get("phone"), 30)),
    addressLine1: singleLine(form.get("addressLine1"), 250),
    addressLine2: singleLine(form.get("addressLine2"), 250) || null,
    area: singleLine(form.get("area"), 100) || null,
    city: singleLine(form.get("city"), 100),
    district: singleLine(form.get("district"), 100) || null,
    postalCode: singleLine(form.get("postalCode"), 20) || null,
    isDefault: ["on", "true", "1"].includes(
      String(form.get("isDefault") ?? ""),
    ),
  };
}

export function validateDashboardAddress(
  input: DashboardAddressInput,
): string | null {
  if (input.recipientName.length < 2) return "Enter the recipient name.";
  if (!isValidBangladeshPhone(input.phone))
    return "Enter a valid Bangladesh mobile number.";
  if (input.addressLine1.length < 5) return "Enter a complete street address.";
  if (input.city.length < 2) return "Enter the city or upazila.";
  return null;
}
