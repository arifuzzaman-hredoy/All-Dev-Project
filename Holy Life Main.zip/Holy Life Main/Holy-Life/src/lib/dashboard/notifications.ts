import type {
  DashboardNotificationKind,
  DepartmentCode,
} from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { queueAutomaticMessaging } from "@/lib/messaging/service";

export async function createDashboardNotification(input: {
  userId?: string | null;
  dedupeKey: string;
  kind?: DashboardNotificationKind;
  department?: DepartmentCode | null;
  title: string;
  message?: string | null;
  href?: string | null;
}): Promise<void> {
  if (!input.userId) return;

  try {
    await db.dashboardNotification.upsert({
      where: {
        userId_dedupeKey: {
          userId: input.userId,
          dedupeKey: input.dedupeKey,
        },
      },
      update: {
        kind: input.kind ?? "INFO",
        department: input.department ?? null,
        title: input.title,
        message: input.message ?? null,
        href: input.href ?? null,
      },
      create: {
        userId: input.userId,
        dedupeKey: input.dedupeKey,
        kind: input.kind ?? "INFO",
        department: input.department ?? null,
        title: input.title,
        message: input.message ?? null,
        href: input.href ?? null,
      },
    });
    try {
      await queueAutomaticMessaging({
        userId: input.userId,
        dedupeKey: input.dedupeKey,
        department: input.department ?? null,
        title: input.title,
        message: input.message ?? null,
        href: input.href ?? null,
      });
    } catch (error) {
      console.error("External messaging queue failed", error);
    }
  } catch (error) {
    // Notifications are supplemental. A failed inbox write must never undo a
    // successful appointment, order, enrollment, or certificate operation.
    console.error("Dashboard notification write failed", error);
  }
}
