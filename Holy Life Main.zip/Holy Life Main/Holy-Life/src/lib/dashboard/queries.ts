import type { SavedItemType } from "@/generated/prisma/client";
import type { NavigationItem } from "@/config/navigation";
import { dateInputToUtc, todayInDhaka } from "@/lib/appointments/time";
import { db } from "@/lib/db";
import {
  mergeDashboardActivity,
  profileCompletion,
  type DashboardActivityItem,
} from "@/lib/dashboard/status";

const activeAppointmentStatuses = [
  "PENDING",
  "CONFIRMED",
  "CHECKED_IN",
  "IN_CONSULTATION",
] as const;
const activeOrderStatuses = [
  "PENDING",
  "CONFIRMED",
  "PROCESSING",
  "SHIPPED",
] as const;

export async function dashboardUnreadCount(userId: string): Promise<number> {
  return db.dashboardNotification.count({ where: { userId, isRead: false } });
}

export async function dashboardOverview(userId: string) {
  const today = dateInputToUtc(todayInDhaka());
  const [
    nextAppointment,
    upcomingAppointments,
    recentAppointments,
    activeOrderCount,
    recentOrders,
    activeEnrollmentCount,
    activeEnrollment,
    unreadNotifications,
    notifications,
    savedCount,
    patient,
  ] = await Promise.all([
    db.appointment.findFirst({
      where: {
        userId,
        appointmentDate: { gte: today },
        status: { in: [...activeAppointmentStatuses] },
      },
      include: { doctor: true, department: true },
      orderBy: [{ appointmentDate: "asc" }, { startTime: "asc" }],
    }),
    db.appointment.count({
      where: {
        userId,
        appointmentDate: { gte: today },
        status: { in: [...activeAppointmentStatuses] },
      },
    }),
    db.appointment.findMany({
      where: { userId },
      include: { doctor: true },
      orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
      take: 3,
    }),
    db.commerceOrder.count({
      where: { userId, status: { in: [...activeOrderStatuses] } },
    }),
    db.commerceOrder.findMany({
      where: { userId },
      include: {
        items: { take: 2, orderBy: { createdAt: "asc" } },
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 3,
    }),
    db.courseEnrollment.count({ where: { userId, status: "ACTIVE" } }),
    db.courseEnrollment.findFirst({
      where: { userId, status: "ACTIVE" },
      include: {
        course: {
          include: {
            category: true,
            instructor: true,
            modules: {
              where: { isPublished: true },
              include: {
                lessons: {
                  where: { isPublished: true },
                  orderBy: { position: "asc" },
                  select: { id: true },
                },
              },
              orderBy: { position: "asc" },
            },
          },
        },
      },
      orderBy: { updatedAt: "desc" },
    }),
    db.dashboardNotification.count({ where: { userId, isRead: false } }),
    db.dashboardNotification.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 4,
    }),
    db.savedItem.count({ where: { userId } }),
    db.patientProfile.findUnique({ where: { userId } }),
  ]);

  const account = await db.user.findUnique({
    where: { id: userId },
    select: { name: true, email: true, phone: true },
  });

  const completion = profileCompletion({
    name: account?.name,
    email: account?.email,
    phone: account?.phone ?? patient?.phone,
    bloodGroup: patient?.bloodGroup,
    dateOfBirth: patient?.dateOfBirth,
    emergencyContactPhone: patient?.emergencyContactPhone,
    address: patient?.address,
  });

  return {
    nextAppointment,
    upcomingAppointments,
    recentAppointments,
    activeOrderCount,
    recentOrders,
    activeEnrollmentCount,
    activeEnrollment,
    unreadNotifications,
    notifications,
    savedCount,
    patient,
    profileCompletion: completion,
  };
}

export async function listDashboardNotifications(
  userId: string,
  mode: "all" | "unread" = "all",
) {
  return db.dashboardNotification.findMany({
    where: { userId, ...(mode === "unread" ? { isRead: false } : {}) },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
}

export async function listDashboardActivity(
  userId: string,
  limit = 30,
): Promise<DashboardActivityItem[]> {
  const [appointments, orders, enrollments, certificates] = await Promise.all([
    db.appointment.findMany({
      where: { userId },
      include: { doctor: { select: { name: true } } },
      orderBy: { updatedAt: "desc" },
      take: limit,
    }),
    db.commerceOrder.findMany({
      where: { userId },
      orderBy: { updatedAt: "desc" },
      take: limit,
    }),
    db.courseEnrollment.findMany({
      where: { userId },
      include: { course: { select: { title: true, slug: true } } },
      orderBy: { updatedAt: "desc" },
      take: limit,
    }),
    db.courseCertificate.findMany({
      where: { userId },
      include: { course: { select: { title: true } } },
      orderBy: { issuedAt: "desc" },
      take: limit,
    }),
  ]);

  const healthcare: DashboardActivityItem[] = appointments.map(
    (appointment) => ({
      id: `appointment-${appointment.id}`,
      department: "HEALTHCARE",
      title: `${appointment.doctor.name} appointment`,
      description: `${appointment.code} · ${appointment.serviceType}`,
      href: `/dashboard/healthcare/appointments/${appointment.id}`,
      occurredAt: appointment.updatedAt,
      status: appointment.status,
    }),
  );

  const commerce: DashboardActivityItem[] = orders.map((order) => ({
    id: `order-${order.id}`,
    department: "COMMERCE",
    title: `Order ${order.code}`,
    description: `${order.currency} ${Number(order.grandTotal).toLocaleString("en-BD")}`,
    href: `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
    occurredAt: order.updatedAt,
    status: order.status,
  }));

  const learning: DashboardActivityItem[] = enrollments.map((enrollment) => ({
    id: `enrollment-${enrollment.id}`,
    department: "LEARNING",
    title: enrollment.course.title,
    description: `Course progress ${enrollment.progressPercent}%`,
    href: `/courses/${enrollment.course.slug}`,
    occurredAt: enrollment.updatedAt,
    status: enrollment.status,
  }));

  const credentials: DashboardActivityItem[] = certificates.map(
    (certificate) => ({
      id: `certificate-${certificate.id}`,
      department: "LEARNING",
      title: `Certificate issued`,
      description: `${certificate.course.title} · ${certificate.code}`,
      href: "/dashboard/learning/certificates",
      occurredAt: certificate.issuedAt,
      status: certificate.status,
    }),
  );

  return mergeDashboardActivity(
    [healthcare, commerce, learning, credentials],
    limit,
  );
}

export type UnifiedPaymentRecord = {
  id: string;
  department: "HEALTHCARE" | "COMMERCE" | "LEARNING";
  reference: string;
  description: string;
  amount: number;
  currency: string;
  status: string;
  method: string;
  occurredAt: Date;
  href: string;
};

export async function listUnifiedPayments(
  userId: string,
): Promise<UnifiedPaymentRecord[]> {
  const [appointments, orders, enrollments] = await Promise.all([
    db.appointment.findMany({
      where: { userId },
      include: { doctor: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.commerceOrder.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.courseEnrollment.findMany({
      where: { userId, course: { price: { gt: 0 } } },
      include: {
        course: { select: { title: true, price: true, currency: true } },
      },
      orderBy: { enrolledAt: "desc" },
      take: 100,
    }),
  ]);

  const records: UnifiedPaymentRecord[] = [
    ...appointments.map((appointment) => ({
      id: `appointment-${appointment.id}`,
      department: "HEALTHCARE" as const,
      reference: appointment.code,
      description: `${appointment.doctor.name} consultation`,
      amount: Number(appointment.fee),
      currency: "BDT",
      status: appointment.paymentStatus,
      method: "Appointment fee",
      occurredAt: appointment.createdAt,
      href: `/dashboard/healthcare/appointments/${appointment.id}`,
    })),
    ...orders.map((order) => ({
      id: `order-${order.id}`,
      department: "COMMERCE" as const,
      reference: order.code,
      description: "Holy Life shop order",
      amount: Number(order.grandTotal),
      currency: order.currency,
      status: order.paymentStatus,
      method: order.paymentMethod,
      occurredAt: order.createdAt,
      href: `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
    })),
    ...enrollments.map((enrollment) => ({
      id: `course-${enrollment.id}`,
      department: "LEARNING" as const,
      reference: enrollment.id,
      description: enrollment.course.title,
      amount: Number(enrollment.course.price),
      currency: enrollment.course.currency,
      status: enrollment.status === "CANCELLED" ? "CANCELLED" : "ENROLLED",
      method: "Course enrollment",
      occurredAt: enrollment.enrolledAt,
      href: "/dashboard/learning/courses",
    })),
  ];

  return records.sort(
    (left, right) => right.occurredAt.getTime() - left.occurredAt.getTime(),
  );
}

export type SavedDashboardItem = {
  id: string;
  itemType: SavedItemType;
  referenceId: string;
  title: string;
  description: string;
  href: string;
  imageUrl: string | null;
  createdAt: Date;
};

export async function listSavedDashboardItems(
  userId: string,
): Promise<SavedDashboardItem[]> {
  const saved = await db.savedItem.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });

  const doctorIds = saved
    .filter((item) => item.itemType === "DOCTOR")
    .map((item) => item.referenceId);
  const productIds = saved
    .filter((item) => item.itemType === "PRODUCT")
    .map((item) => item.referenceId);
  const courseIds = saved
    .filter((item) => item.itemType === "COURSE")
    .map((item) => item.referenceId);

  const [doctors, products, courses] = await Promise.all([
    doctorIds.length
      ? db.doctorProfile.findMany({
          where: { id: { in: doctorIds }, status: "ACTIVE" },
          include: { department: true },
        })
      : [],
    productIds.length
      ? db.product.findMany({
          where: { id: { in: productIds }, status: "ACTIVE" },
          include: {
            category: true,
            images: {
              orderBy: [{ isPrimary: "desc" }, { position: "asc" }],
              take: 1,
            },
          },
        })
      : [],
    courseIds.length
      ? db.course.findMany({
          where: { id: { in: courseIds }, status: "PUBLISHED" },
          include: { category: true, instructor: true },
        })
      : [],
  ]);

  const doctorMap = new Map(doctors.map((doctor) => [doctor.id, doctor]));
  const productMap = new Map(products.map((product) => [product.id, product]));
  const courseMap = new Map(courses.map((course) => [course.id, course]));

  return saved.flatMap((item): SavedDashboardItem[] => {
    if (item.itemType === "DOCTOR") {
      const doctor = doctorMap.get(item.referenceId);
      return doctor
        ? [
            {
              id: item.id,
              itemType: item.itemType,
              referenceId: item.referenceId,
              title: doctor.name,
              description: `${doctor.department.name} · ${doctor.specialization}`,
              href: `/doctors/${doctor.slug}`,
              imageUrl: doctor.imageUrl,
              createdAt: item.createdAt,
            },
          ]
        : [];
    }

    if (item.itemType === "PRODUCT") {
      const product = productMap.get(item.referenceId);
      return product
        ? [
            {
              id: item.id,
              itemType: item.itemType,
              referenceId: item.referenceId,
              title: product.name,
              description: product.category.name,
              href: `/shop/${product.slug}`,
              imageUrl: product.images[0]?.url ?? null,
              createdAt: item.createdAt,
            },
          ]
        : [];
    }

    const course = courseMap.get(item.referenceId);
    return course
      ? [
          {
            id: item.id,
            itemType: item.itemType,
            referenceId: item.referenceId,
            title: course.title,
            description: `${course.category.name} · ${course.instructor?.name ?? "Holy Life Academy"}`,
            href: `/courses/${course.slug}`,
            imageUrl: course.thumbnailUrl,
            createdAt: item.createdAt,
          },
        ]
      : [];
  });
}

export async function isSavedItem(
  userId: string,
  itemType: SavedItemType,
  referenceId: string,
): Promise<boolean> {
  const item = await db.savedItem.findUnique({
    where: { userId_itemType_referenceId: { userId, itemType, referenceId } },
    select: { id: true },
  });
  return Boolean(item);
}

export async function addressBook(userId: string) {
  return db.commerceAddress.findMany({
    where: { userId },
    orderBy: [{ isDefault: "desc" }, { updatedAt: "desc" }],
  });
}

export async function dashboardProfile(userId: string) {
  return db.user.findUnique({
    where: { id: userId },
    include: { patientProfile: true },
  });
}

export function dashboardNavigationWithUnread(
  navigation: NavigationItem[],
  unread: number,
): NavigationItem[] {
  return navigation.map((item) => ({
    ...item,
    ...(item.id === "dashboard-notifications"
      ? { badge: unread > 99 ? "99+" : unread > 0 ? String(unread) : undefined }
      : {}),
    ...(item.children
      ? { children: dashboardNavigationWithUnread(item.children, unread) }
      : {}),
  }));
}

export async function savedReferenceExists(
  itemType: SavedItemType,
  referenceId: string,
): Promise<boolean> {
  if (itemType === "DOCTOR") {
    return Boolean(
      await db.doctorProfile.findFirst({
        where: { id: referenceId, status: "ACTIVE" },
        select: { id: true },
      }),
    );
  }
  if (itemType === "PRODUCT") {
    return Boolean(
      await db.product.findFirst({
        where: { id: referenceId, status: "ACTIVE" },
        select: { id: true },
      }),
    );
  }
  return Boolean(
    await db.course.findFirst({
      where: { id: referenceId, status: "PUBLISHED" },
      select: { id: true },
    }),
  );
}
