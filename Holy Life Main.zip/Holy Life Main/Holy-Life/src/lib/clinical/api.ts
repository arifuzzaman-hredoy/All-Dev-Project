import { NextRequest, NextResponse } from "next/server";
import { ClinicalError } from "@/lib/clinical/service";
import { ClinicalValidationError } from "@/lib/clinical/validation";

export function clinicalRedirect(
  request: NextRequest,
  path: string,
  key: "success" | "error",
  message: string,
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(key, message);
  return NextResponse.redirect(url, 303);
}

export function clinicalErrorMessage(error: unknown, fallback: string): string {
  if (
    error instanceof ClinicalError ||
    error instanceof ClinicalValidationError
  )
    return error.message;
  return fallback;
}
