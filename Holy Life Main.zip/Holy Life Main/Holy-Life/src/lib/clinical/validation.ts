import { isDateInput } from "@/lib/appointments/time";

export class ClinicalValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ClinicalValidationError";
  }
}

export type ClinicalProfileInput = {
  chronicConditions: string | null;
  currentMedications: string | null;
  pastMedicalHistory: string | null;
  surgicalHistory: string | null;
  familyHistory: string | null;
  socialHistory: string | null;
  clinicalNotes: string | null;
};

export type EncounterInput = {
  symptoms: string | null;
  diagnosis: string | null;
  clinicalNotes: string | null;
  advice: string | null;
  followUpDate: string | null;
};

export type VitalInput = {
  appointmentId: string | null;
  heightCm: number | null;
  weightKg: number | null;
  temperatureC: number | null;
  pulseBpm: number | null;
  systolicMmHg: number | null;
  diastolicMmHg: number | null;
  respiratoryRate: number | null;
  oxygenSaturation: number | null;
  bloodGlucoseMgDl: number | null;
  notes: string | null;
};

export type PrescriptionItemInput = {
  medicineName: string;
  genericName: string | null;
  strength: string | null;
  dose: string;
  route: string | null;
  frequency: string;
  duration: string;
  quantity: string | null;
  instructions: string | null;
};

export type PrescriptionInput = EncounterInput & {
  appointmentId: string;
  items: PrescriptionItemInput[];
};

function enforceLength(
  value: string,
  maxLength: number,
  field = "Input",
): string {
  if (value.length > maxLength)
    throw new ClinicalValidationError(
      `${field} exceeds the ${maxLength}-character limit.`,
    );
  return value;
}

function single(
  value: FormDataEntryValue | null,
  maxLength: number,
  field = "Input",
): string {
  return enforceLength(
    String(value ?? "")
      .trim()
      .replace(/\s+/g, " "),
    maxLength,
    field,
  );
}

function multiline(
  value: FormDataEntryValue | null,
  maxLength: number,
  field = "Input",
): string {
  return enforceLength(
    String(value ?? "")
      .trim()
      .replace(/\r\n/g, "\n"),
    maxLength,
    field,
  );
}

function optionalText(
  value: FormDataEntryValue | null,
  maxLength: number,
): string | null {
  return multiline(value, maxLength) || null;
}

function optionalNumber(
  form: FormData,
  key: string,
  min: number,
  max: number,
): number | null {
  const raw = single(form.get(key), 32);
  if (!raw) return null;
  const value = Number(raw);
  if (!Number.isFinite(value) || value < min || value > max) {
    throw new ClinicalValidationError(
      `${key} is outside the accepted input range.`,
    );
  }
  return Math.round(value * 100) / 100;
}

function optionalInteger(
  form: FormData,
  key: string,
  min: number,
  max: number,
): number | null {
  const value = optionalNumber(form, key, min, max);
  if (value === null) return null;
  if (!Number.isInteger(value))
    throw new ClinicalValidationError(`${key} must be a whole number.`);
  return value;
}

export function readClinicalProfileForm(form: FormData): ClinicalProfileInput {
  return {
    chronicConditions: optionalText(form.get("chronicConditions"), 5000),
    currentMedications: optionalText(form.get("currentMedications"), 5000),
    pastMedicalHistory: optionalText(form.get("pastMedicalHistory"), 8000),
    surgicalHistory: optionalText(form.get("surgicalHistory"), 5000),
    familyHistory: optionalText(form.get("familyHistory"), 5000),
    socialHistory: optionalText(form.get("socialHistory"), 5000),
    clinicalNotes: optionalText(form.get("clinicalNotes"), 8000),
  };
}

export function readEncounterForm(form: FormData): EncounterInput {
  const followUpRaw = single(form.get("followUpDate"), 10);
  if (followUpRaw && !isDateInput(followUpRaw))
    throw new ClinicalValidationError("Follow-up date is invalid.");
  return {
    symptoms: optionalText(form.get("symptoms"), 8000),
    diagnosis: optionalText(form.get("diagnosis"), 8000),
    clinicalNotes: optionalText(form.get("clinicalNotes"), 12000),
    advice: optionalText(form.get("advice"), 8000),
    followUpDate: followUpRaw || null,
  };
}

export function readVitalForm(form: FormData): VitalInput {
  const appointmentId = single(form.get("appointmentId"), 100) || null;
  const result: VitalInput = {
    appointmentId,
    heightCm: optionalNumber(form, "heightCm", 20, 300),
    weightKg: optionalNumber(form, "weightKg", 0.5, 500),
    temperatureC: optionalNumber(form, "temperatureC", 25, 50),
    pulseBpm: optionalInteger(form, "pulseBpm", 10, 300),
    systolicMmHg: optionalInteger(form, "systolicMmHg", 20, 300),
    diastolicMmHg: optionalInteger(form, "diastolicMmHg", 20, 250),
    respiratoryRate: optionalInteger(form, "respiratoryRate", 1, 100),
    oxygenSaturation: optionalInteger(form, "oxygenSaturation", 0, 100),
    bloodGlucoseMgDl: optionalNumber(form, "bloodGlucoseMgDl", 1, 2000),
    notes: optionalText(form.get("notes"), 3000),
  };
  const measurements = Object.entries(result).filter(
    ([key, value]) =>
      !["appointmentId", "notes"].includes(key) && value !== null,
  );
  if (measurements.length === 0 && !result.notes)
    throw new ClinicalValidationError(
      "Enter at least one vital measurement or note.",
    );
  return result;
}

function fieldArray(form: FormData, key: string, maxLength: number): string[] {
  return form.getAll(key).map((value) => single(value, maxLength));
}

export function readPrescriptionItems(form: FormData): PrescriptionItemInput[] {
  const medicineNames = fieldArray(form, "medicineName", 160);
  const genericNames = fieldArray(form, "genericName", 160);
  const strengths = fieldArray(form, "strength", 80);
  const doses = fieldArray(form, "dose", 120);
  const routes = fieldArray(form, "route", 80);
  const frequencies = fieldArray(form, "frequency", 160);
  const durations = fieldArray(form, "duration", 120);
  const quantities = fieldArray(form, "quantity", 80);
  const instructions = form
    .getAll("instructions")
    .map((value) => multiline(value, 1000));
  const count = Math.max(
    medicineNames.length,
    doses.length,
    frequencies.length,
    durations.length,
  );
  const items: PrescriptionItemInput[] = [];

  for (let index = 0; index < count; index += 1) {
    const medicineName = medicineNames[index] ?? "";
    const dose = doses[index] ?? "";
    const frequency = frequencies[index] ?? "";
    const duration = durations[index] ?? "";
    if (!medicineName && !dose && !frequency && !duration) continue;
    if (medicineName.length < 2 || !dose || !frequency || !duration) {
      throw new ClinicalValidationError(
        `Medicine row ${index + 1} requires medicine, dose, frequency, and duration.`,
      );
    }
    items.push({
      medicineName,
      genericName: genericNames[index] || null,
      strength: strengths[index] || null,
      dose,
      route: routes[index] || null,
      frequency,
      duration,
      quantity: quantities[index] || null,
      instructions: instructions[index] || null,
    });
  }

  if (items.length === 0)
    throw new ClinicalValidationError("Add at least one medicine.");
  if (items.length > 12)
    throw new ClinicalValidationError(
      "A prescription can contain at most 12 medicine rows.",
    );
  return items;
}

export function readPrescriptionForm(form: FormData): PrescriptionInput {
  const appointmentId = single(form.get("appointmentId"), 100);
  if (!appointmentId)
    throw new ClinicalValidationError("Select an appointment.");
  return {
    appointmentId,
    ...readEncounterForm(form),
    items: readPrescriptionItems(form),
  };
}

export function readVoidReason(form: FormData): string {
  const reason = multiline(form.get("voidReason"), 1000);
  if (reason.length < 5)
    throw new ClinicalValidationError(
      "Enter a clear reason before voiding a signed prescription.",
    );
  return reason;
}
