import { Prisma } from "@/generated/prisma/client";
import type { AuthenticatedUser } from "@/lib/auth/session";
import { dateInputToUtc } from "@/lib/appointments/time";
import {
  clinicalAppointmentAccessWhere,
  clinicalPatientAccessWhere,
  prescriptionAccessWhere,
} from "@/lib/clinical/access";
import { generatePrescriptionCode } from "@/lib/clinical/code";
import type {
  ClinicalProfileInput,
  EncounterInput,
  PrescriptionInput,
  VitalInput,
} from "@/lib/clinical/validation";
import { db } from "@/lib/db";

export class ClinicalError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ClinicalError";
  }
}

const CLINICAL_APPOINTMENT_STATUSES = [
  "CHECKED_IN",
  "IN_CONSULTATION",
  "COMPLETED",
] as const;

async function withSerializableRetry<T>(
  operation: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await db.$transaction(operation, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2034" &&
        attempt < 3
      )
        continue;
      throw error;
    }
  }
  throw new ClinicalError(
    "Clinical record update could not be completed safely.",
  );
}

export async function updatePatientClinicalProfile(
  user: AuthenticatedUser,
  patientId: string,
  input: ClinicalProfileInput,
) {
  const patient = await db.patientProfile.findFirst({
    where: {
      AND: [
        { id: patientId },
        clinicalPatientAccessWhere(
          user,
          "healthcare.patients.clinical-record.edit",
        ),
      ],
    },
    select: { id: true },
  });
  if (!patient)
    throw new ClinicalError(
      "Patient clinical record is not available in your data scope.",
    );
  return db.patientClinicalProfile.upsert({
    where: { patientId },
    update: { ...input, updatedById: user.id },
    create: { patientId, ...input, updatedById: user.id },
  });
}

export async function saveClinicalEncounter(
  user: AuthenticatedUser,
  appointmentId: string,
  input: EncounterInput,
) {
  const appointment = await db.appointment.findFirst({
    where: {
      AND: [
        { id: appointmentId },
        clinicalAppointmentAccessWhere(
          user,
          "healthcare.patients.clinical-record.edit",
        ),
      ],
    },
    select: { id: true, patientId: true, doctorId: true, status: true },
  });
  if (!appointment)
    throw new ClinicalError(
      "Appointment is not available in your clinical data scope.",
    );
  if (
    !CLINICAL_APPOINTMENT_STATUSES.includes(
      appointment.status as (typeof CLINICAL_APPOINTMENT_STATUSES)[number],
    )
  ) {
    throw new ClinicalError(
      "Clinical encounter notes can be recorded only after patient check-in.",
    );
  }
  return db.clinicalEncounter.upsert({
    where: { appointmentId },
    update: {
      symptoms: input.symptoms,
      diagnosis: input.diagnosis,
      clinicalNotes: input.clinicalNotes,
      advice: input.advice,
      followUpDate: input.followUpDate
        ? dateInputToUtc(input.followUpDate)
        : null,
      updatedById: user.id,
    },
    create: {
      appointmentId,
      patientId: appointment.patientId,
      doctorId: appointment.doctorId,
      symptoms: input.symptoms,
      diagnosis: input.diagnosis,
      clinicalNotes: input.clinicalNotes,
      advice: input.advice,
      followUpDate: input.followUpDate
        ? dateInputToUtc(input.followUpDate)
        : null,
      createdById: user.id,
      updatedById: user.id,
    },
  });
}

export async function recordPatientVital(
  user: AuthenticatedUser,
  patientId: string,
  input: VitalInput,
) {
  const patient = await db.patientProfile.findFirst({
    where: {
      AND: [
        { id: patientId },
        clinicalPatientAccessWhere(
          user,
          "healthcare.patients.clinical-record.edit",
        ),
      ],
    },
    select: { id: true },
  });
  if (!patient)
    throw new ClinicalError(
      "Patient clinical record is not available in your data scope.",
    );

  if (input.appointmentId) {
    const appointment = await db.appointment.findFirst({
      where: {
        AND: [
          { id: input.appointmentId, patientId },
          clinicalAppointmentAccessWhere(
            user,
            "healthcare.patients.clinical-record.edit",
          ),
        ],
      },
      select: { id: true },
    });
    if (!appointment)
      throw new ClinicalError(
        "Selected appointment does not belong to this accessible patient.",
      );
  }

  return db.patientVital.create({
    data: {
      patientId,
      appointmentId: input.appointmentId,
      recordedById: user.id,
      heightCm: input.heightCm,
      weightKg: input.weightKg,
      temperatureC: input.temperatureC,
      pulseBpm: input.pulseBpm,
      systolicMmHg: input.systolicMmHg,
      diastolicMmHg: input.diastolicMmHg,
      respiratoryRate: input.respiratoryRate,
      oxygenSaturation: input.oxygenSaturation,
      bloodGlucoseMgDl: input.bloodGlucoseMgDl,
      notes: input.notes,
    },
  });
}

async function createPrescriptionWithCode(
  tx: Prisma.TransactionClient,
  data: Prisma.PrescriptionCreateInput,
) {
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      return await tx.prescription.create({
        data,
        include: { items: { orderBy: { sortOrder: "asc" } } },
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002" &&
        attempt < 3
      ) {
        const target = String(error.meta?.target ?? "");
        if (target.includes("code")) {
          data = { ...data, code: generatePrescriptionCode() };
          continue;
        }
      }
      throw error;
    }
  }
  throw new ClinicalError("Could not allocate a unique prescription code.");
}

export async function createPrescriptionDraft(
  user: AuthenticatedUser,
  input: PrescriptionInput,
) {
  return withSerializableRetry(async (tx) => {
    const appointment = await tx.appointment.findFirst({
      where: {
        AND: [
          { id: input.appointmentId },
          clinicalAppointmentAccessWhere(
            user,
            "healthcare.prescriptions.prescription.create",
          ),
        ],
      },
      include: { clinicalEncounter: true },
    });
    if (!appointment)
      throw new ClinicalError(
        "Appointment is not available for prescription creation.",
      );
    if (
      !CLINICAL_APPOINTMENT_STATUSES.includes(
        appointment.status as (typeof CLINICAL_APPOINTMENT_STATUSES)[number],
      )
    ) {
      throw new ClinicalError(
        "A prescription can be created only after patient check-in.",
      );
    }
    const existing = await tx.prescription.findFirst({
      where: { appointmentId: appointment.id },
      orderBy: { version: "desc" },
      select: { id: true, status: true },
    });
    if (existing)
      throw new ClinicalError(
        "This appointment already has a prescription. Open it and create a revision if needed.",
      );

    if (
      input.symptoms ||
      input.diagnosis ||
      input.clinicalNotes ||
      input.advice ||
      input.followUpDate
    ) {
      await tx.clinicalEncounter.upsert({
        where: { appointmentId: appointment.id },
        update: {
          symptoms: input.symptoms,
          diagnosis: input.diagnosis,
          clinicalNotes: input.clinicalNotes,
          advice: input.advice,
          followUpDate: input.followUpDate
            ? dateInputToUtc(input.followUpDate)
            : null,
          updatedById: user.id,
        },
        create: {
          appointmentId: appointment.id,
          patientId: appointment.patientId,
          doctorId: appointment.doctorId,
          symptoms: input.symptoms,
          diagnosis: input.diagnosis,
          clinicalNotes: input.clinicalNotes,
          advice: input.advice,
          followUpDate: input.followUpDate
            ? dateInputToUtc(input.followUpDate)
            : null,
          createdById: user.id,
          updatedById: user.id,
        },
      });
    }

    return createPrescriptionWithCode(tx, {
      code: generatePrescriptionCode(),
      appointment: { connect: { id: appointment.id } },
      patient: { connect: { id: appointment.patientId } },
      doctor: { connect: { id: appointment.doctorId } },
      diagnosis: input.diagnosis,
      notes: input.clinicalNotes,
      advice: input.advice,
      followUpDate: input.followUpDate
        ? dateInputToUtc(input.followUpDate)
        : null,
      createdBy: { connect: { id: user.id } },
      items: {
        create: input.items.map((item, index) => ({
          ...item,
          sortOrder: index,
        })),
      },
    });
  });
}

export async function updatePrescriptionDraft(
  user: AuthenticatedUser,
  prescriptionId: string,
  input: PrescriptionInput,
) {
  return withSerializableRetry(async (tx) => {
    const prescription = await tx.prescription.findFirst({
      where: {
        AND: [
          { id: prescriptionId },
          prescriptionAccessWhere(
            user,
            "healthcare.prescriptions.prescription.edit",
          ),
        ],
      },
      select: {
        id: true,
        appointmentId: true,
        patientId: true,
        doctorId: true,
        status: true,
      },
    });
    if (!prescription)
      throw new ClinicalError(
        "Prescription is not available in your data scope.",
      );
    if (prescription.status !== "DRAFT")
      throw new ClinicalError(
        "Signed or voided prescriptions are immutable. Create a revision instead.",
      );
    if (input.appointmentId !== prescription.appointmentId)
      throw new ClinicalError(
        "A prescription cannot be moved to another appointment.",
      );

    await tx.clinicalEncounter.upsert({
      where: { appointmentId: prescription.appointmentId },
      update: {
        symptoms: input.symptoms,
        diagnosis: input.diagnosis,
        clinicalNotes: input.clinicalNotes,
        advice: input.advice,
        followUpDate: input.followUpDate
          ? dateInputToUtc(input.followUpDate)
          : null,
        updatedById: user.id,
      },
      create: {
        appointmentId: prescription.appointmentId,
        patientId: prescription.patientId,
        doctorId: prescription.doctorId,
        symptoms: input.symptoms,
        diagnosis: input.diagnosis,
        clinicalNotes: input.clinicalNotes,
        advice: input.advice,
        followUpDate: input.followUpDate
          ? dateInputToUtc(input.followUpDate)
          : null,
        createdById: user.id,
        updatedById: user.id,
      },
    });

    await tx.prescriptionItem.deleteMany({ where: { prescriptionId } });
    return tx.prescription.update({
      where: { id: prescriptionId },
      data: {
        diagnosis: input.diagnosis,
        notes: input.clinicalNotes,
        advice: input.advice,
        followUpDate: input.followUpDate
          ? dateInputToUtc(input.followUpDate)
          : null,
        items: {
          create: input.items.map((item, index) => ({
            ...item,
            sortOrder: index,
          })),
        },
      },
      include: { items: { orderBy: { sortOrder: "asc" } } },
    });
  });
}

function canClinicallySign(
  user: AuthenticatedUser,
  doctorUserId: string | null,
): boolean {
  return user.isSuperAdmin || doctorUserId === user.id;
}

export async function signPrescription(
  user: AuthenticatedUser,
  prescriptionId: string,
) {
  return withSerializableRetry(async (tx) => {
    const prescription = await tx.prescription.findFirst({
      where: {
        AND: [
          { id: prescriptionId },
          prescriptionAccessWhere(
            user,
            "healthcare.prescriptions.prescription.sign",
          ),
        ],
      },
      include: {
        doctor: { select: { userId: true } },
        items: { select: { id: true } },
        appointment: { select: { status: true } },
      },
    });
    if (!prescription)
      throw new ClinicalError(
        "Prescription is not available in your data scope.",
      );
    if (prescription.status !== "DRAFT")
      throw new ClinicalError("Only a draft prescription can be signed.");
    if (!canClinicallySign(user, prescription.doctor.userId))
      throw new ClinicalError(
        "Only the assigned doctor or primary Super Admin can sign this prescription.",
      );
    if (prescription.items.length === 0)
      throw new ClinicalError("Add at least one medicine before signing.");
    if (
      prescription.appointment.status === "CANCELLED" ||
      prescription.appointment.status === "NO_SHOW"
    ) {
      throw new ClinicalError(
        "A prescription cannot be signed for a cancelled or no-show appointment.",
      );
    }
    return tx.prescription.update({
      where: { id: prescription.id },
      data: { status: "SIGNED", signedById: user.id, signedAt: new Date() },
    });
  });
}

export async function createPrescriptionRevision(
  user: AuthenticatedUser,
  prescriptionId: string,
) {
  return withSerializableRetry(async (tx) => {
    const current = await tx.prescription.findFirst({
      where: {
        AND: [
          { id: prescriptionId },
          prescriptionAccessWhere(
            user,
            "healthcare.prescriptions.prescription.edit",
          ),
        ],
      },
      include: { items: { orderBy: { sortOrder: "asc" } } },
    });
    if (!current)
      throw new ClinicalError(
        "Prescription is not available in your data scope.",
      );
    if (current.status !== "SIGNED" && current.status !== "VOIDED")
      throw new ClinicalError(
        "Only a signed or voided prescription can start a revision.",
      );
    const existingRevision = await tx.prescription.findUnique({
      where: { supersedesId: current.id },
      select: { id: true },
    });
    if (existingRevision)
      throw new ClinicalError(
        "A revision already exists for this prescription.",
      );
    const latest = await tx.prescription.aggregate({
      where: { appointmentId: current.appointmentId },
      _max: { version: true },
    });
    const version = (latest._max.version ?? current.version) + 1;

    return createPrescriptionWithCode(tx, {
      code: generatePrescriptionCode(),
      appointment: { connect: { id: current.appointmentId } },
      patient: { connect: { id: current.patientId } },
      doctor: { connect: { id: current.doctorId } },
      version,
      diagnosis: current.diagnosis,
      notes: current.notes,
      advice: current.advice,
      followUpDate: current.followUpDate,
      supersedes: { connect: { id: current.id } },
      createdBy: { connect: { id: user.id } },
      items: {
        create: current.items.map((item, index) => ({
          sortOrder: index,
          medicineName: item.medicineName,
          genericName: item.genericName,
          strength: item.strength,
          dose: item.dose,
          route: item.route,
          frequency: item.frequency,
          duration: item.duration,
          quantity: item.quantity,
          instructions: item.instructions,
        })),
      },
    });
  });
}

export async function voidPrescription(
  user: AuthenticatedUser,
  prescriptionId: string,
  reason: string,
) {
  return withSerializableRetry(async (tx) => {
    const prescription = await tx.prescription.findFirst({
      where: {
        AND: [
          { id: prescriptionId },
          prescriptionAccessWhere(
            user,
            "healthcare.prescriptions.prescription.sign",
          ),
        ],
      },
      include: { doctor: { select: { userId: true } } },
    });
    if (!prescription)
      throw new ClinicalError(
        "Prescription is not available in your data scope.",
      );
    if (prescription.status !== "SIGNED")
      throw new ClinicalError("Only a signed prescription can be voided.");
    if (!canClinicallySign(user, prescription.doctor.userId))
      throw new ClinicalError(
        "Only the assigned doctor or primary Super Admin can void this signed prescription.",
      );
    return tx.prescription.update({
      where: { id: prescription.id },
      data: {
        status: "VOIDED",
        voidedById: user.id,
        voidedAt: new Date(),
        voidReason: reason,
      },
    });
  });
}
