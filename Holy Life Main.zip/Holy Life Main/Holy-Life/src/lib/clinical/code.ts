import { randomBytes } from "node:crypto";

export function generatePrescriptionCode(now = new Date()): string {
  const date = now.toISOString().slice(0, 10).replaceAll("-", "");
  return `HLP-RX-${date}-${randomBytes(3).toString("hex").toUpperCase()}`;
}
