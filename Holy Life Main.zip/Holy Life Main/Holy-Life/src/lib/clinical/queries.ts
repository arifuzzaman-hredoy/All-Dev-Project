import type { AuthenticatedUser } from "@/lib/auth/session";
import { db } from "@/lib/db";
import {
  clinicalPatientAccessWhere,
  prescriptionAccessWhere,
} from "@/lib/clinical/access";

export async function getAdminPatientClinicalRecord(
  user: AuthenticatedUser,
  patientId: string,
) {
  return db.patientProfile.findFirst({
    where: { AND: [{ id: patientId }, clinicalPatientAccessWhere(user)] },
    include: {
      clinicalProfile: { include: { updatedBy: { select: { name: true } } } },
      vitals: {
        include: {
          recordedBy: { select: { name: true } },
          appointment: { select: { code: true } },
        },
        orderBy: { recordedAt: "desc" },
        take: 50,
      },
      appointments: {
        include: {
          doctor: { select: { name: true, specialization: true } },
          clinicalEncounter: true,
          prescriptions: {
            where: { status: { not: "VOIDED" } },
            select: { id: true, code: true, status: true, version: true },
          },
        },
        orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
        take: 100,
      },
      prescriptions: {
        where: prescriptionAccessWhere(user),
        include: {
          doctor: { select: { name: true } },
          items: { orderBy: { sortOrder: "asc" } },
        },
        orderBy: [{ createdAt: "desc" }, { version: "desc" }],
        take: 100,
      },
    },
  });
}

export async function getAdminPrescription(
  user: AuthenticatedUser,
  prescriptionId: string,
) {
  return db.prescription.findFirst({
    where: { AND: [{ id: prescriptionId }, prescriptionAccessWhere(user)] },
    include: {
      appointment: { include: { department: true } },
      patient: true,
      doctor: { include: { department: true } },
      items: { orderBy: { sortOrder: "asc" } },
      signedBy: { select: { name: true } },
      voidedBy: { select: { name: true } },
      supersedes: {
        select: { id: true, code: true, version: true, status: true },
      },
      revisions: {
        select: { id: true, code: true, version: true, status: true },
        orderBy: { version: "asc" },
      },
    },
  });
}

export async function getUserPatientProfile(userId: string) {
  return db.patientProfile.findUnique({ where: { userId } });
}
