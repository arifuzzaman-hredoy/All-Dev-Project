import type { Prisma } from "@/generated/prisma/client";
import type { AuthenticatedUser } from "@/lib/auth/session";
import {
  appointmentAccessWhere,
  dataScopeForPermission,
  patientAccessWhere,
} from "@/lib/appointments/access";

export function clinicalPatientAccessWhere(
  user: AuthenticatedUser,
  permissionKey = "healthcare.patients.clinical-record.view",
): Prisma.PatientProfileWhereInput {
  return patientAccessWhere(user, permissionKey);
}

export function clinicalAppointmentAccessWhere(
  user: AuthenticatedUser,
  permissionKey = "healthcare.patients.clinical-record.view",
): Prisma.AppointmentWhereInput {
  return appointmentAccessWhere(user, permissionKey);
}

export function prescriptionAccessWhere(
  user: AuthenticatedUser,
  permissionKey = "healthcare.prescriptions.prescription.view",
): Prisma.PrescriptionWhereInput {
  const scope = dataScopeForPermission(user, permissionKey);
  if (scope === "ALL" || scope === "BRANCH" || scope === "DEPARTMENT")
    return {};
  if (scope === "ASSIGNED") return { doctor: { userId: user.id } };
  return {
    OR: [
      { patient: { userId: user.id } },
      { doctor: { userId: user.id } },
      { createdById: user.id },
    ],
  };
}
