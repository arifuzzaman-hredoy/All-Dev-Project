import type { PrescriptionStatus } from "@/generated/prisma/client";

export function prescriptionStatusLabel(status: PrescriptionStatus): string {
  if (status === "SIGNED") return "Signed";
  if (status === "VOIDED") return "Voided";
  return "Draft";
}

export function prescriptionStatusTone(
  status: PrescriptionStatus,
): "neutral" | "success" | "danger" {
  if (status === "SIGNED") return "success";
  if (status === "VOIDED") return "danger";
  return "neutral";
}
