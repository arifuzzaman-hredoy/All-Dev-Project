export const PAYMENT_ACCOUNT_STATUSES = [
  "UNPAID",
  "PENDING_VERIFICATION",
  "PARTIAL",
  "PAID",
  "FAILED",
  "REFUNDED",
] as const;

export type PaymentAccountStatusValue =
  (typeof PAYMENT_ACCOUNT_STATUSES)[number];

export type PaymentBalanceInput = {
  amountDue: number;
  openingPaidAmount?: number;
  openingRefundedAmount?: number;
  verifiedPayments?: number;
  verifiedRefunds?: number;
  pendingPayments?: number;
  rejectedPayments?: number;
};

function money(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function calculatePaymentBalance(input: PaymentBalanceInput) {
  const amountDue = Math.max(0, money(input.amountDue));
  const grossPaid = money(
    Math.max(0, input.openingPaidAmount ?? 0) +
      Math.max(0, input.verifiedPayments ?? 0),
  );
  const refunded = money(
    Math.max(0, input.openingRefundedAmount ?? 0) +
      Math.max(0, input.verifiedRefunds ?? 0),
  );
  const netPaid = money(Math.max(0, grossPaid - refunded));
  const outstanding = money(Math.max(0, amountDue - netPaid));

  let status: PaymentAccountStatusValue = "UNPAID";

  if (grossPaid > 0 && refunded >= grossPaid) {
    status = "REFUNDED";
  } else if (amountDue === 0 || netPaid >= amountDue) {
    status = "PAID";
  } else if ((input.pendingPayments ?? 0) > 0) {
    status = "PENDING_VERIFICATION";
  } else if (netPaid > 0) {
    status = "PARTIAL";
  } else if ((input.rejectedPayments ?? 0) > 0) {
    status = "FAILED";
  }

  return {
    amountDue,
    grossPaid,
    refunded,
    netPaid,
    outstanding,
    status,
  };
}

export function paymentStatusLabel(status: string): string {
  return status
    .toLowerCase()
    .replace(/_/g, " ")
    .replace(/\b\w/g, (value) => value.toUpperCase());
}
