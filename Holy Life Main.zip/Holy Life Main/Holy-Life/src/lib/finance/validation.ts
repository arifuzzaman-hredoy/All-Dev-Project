import type {
  ManualPaymentMethod,
  PaymentDomain,
  PaymentTransactionStatus,
  PaymentTransactionType,
} from "@/generated/prisma/client";

export const MANUAL_PAYMENT_METHODS = [
  "CASH",
  "BKASH",
  "NAGAD",
  "ROCKET",
  "BANK_TRANSFER",
  "OTHER",
] as const satisfies readonly ManualPaymentMethod[];

export const PAYMENT_DOMAINS = [
  "HEALTHCARE",
  "COMMERCE",
  "LEARNING",
] as const satisfies readonly PaymentDomain[];

export const PAYMENT_TRANSACTION_TYPES = [
  "PAYMENT",
  "REFUND",
  "ADJUSTMENT",
] as const satisfies readonly PaymentTransactionType[];

export const PAYMENT_TRANSACTION_STATUSES = [
  "PENDING",
  "VERIFIED",
  "REJECTED",
] as const satisfies readonly PaymentTransactionStatus[];

export function positiveMoney(
  value: FormDataEntryValue | string | null,
  field = "amount",
): number {
  const raw = typeof value === "string" ? value.trim() : "";
  if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) {
    throw new Error(
      `${field} must be a positive amount with up to two decimal places.`,
    );
  }
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed <= 0 || parsed > 100_000_000) {
    throw new Error(`${field} is outside the allowed range.`);
  }
  return Math.round(parsed * 100) / 100;
}

export function optionalFinanceText(
  value: FormDataEntryValue | string | null,
  maxLength: number,
): string | null {
  const raw = typeof value === "string" ? value.trim() : "";
  if (!raw) return null;
  if (raw.length > maxLength)
    throw new Error(`Text cannot exceed ${maxLength} characters.`);
  return raw;
}

export function dashboardHref(
  value: FormDataEntryValue | string | null,
): string | null {
  const href = optionalFinanceText(value, 300);
  if (!href) return null;
  if (!href.startsWith("/") || href.startsWith("//")) {
    throw new Error(
      "Dashboard link must be an internal path beginning with /.",
    );
  }
  return href;
}

export function requiredFinanceText(
  value: FormDataEntryValue | string | null,
  maxLength: number,
  field: string,
): string {
  const result = optionalFinanceText(value, maxLength);
  if (!result) throw new Error(`${field} is required.`);
  return result;
}

export function manualPaymentMethod(
  value: FormDataEntryValue | string | null,
): ManualPaymentMethod {
  const raw = typeof value === "string" ? value : "";
  if (!MANUAL_PAYMENT_METHODS.includes(raw as ManualPaymentMethod)) {
    throw new Error("Manual payment method is invalid.");
  }
  return raw as ManualPaymentMethod;
}

export function reportDate(
  value: string | undefined,
  endOfDay = false,
): Date | null {
  if (!value) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value))
    throw new Error("Report date is invalid.");

  const [year, month, day] = value.split("-").map(Number);
  const calendarProbe = new Date(Date.UTC(year, month - 1, day));
  if (
    calendarProbe.getUTCFullYear() !== year ||
    calendarProbe.getUTCMonth() !== month - 1 ||
    calendarProbe.getUTCDate() !== day
  ) {
    throw new Error("Report date is invalid.");
  }

  return new Date(
    `${value}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}+06:00`,
  );
}
