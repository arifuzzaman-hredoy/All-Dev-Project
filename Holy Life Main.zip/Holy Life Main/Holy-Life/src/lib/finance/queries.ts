import type {
  PaymentAccountStatus,
  PaymentDomain,
  Prisma,
} from "@/generated/prisma/client";
import { db } from "@/lib/db";

export type FinanceDateRange = {
  from?: Date | null;
  to?: Date | null;
};

function createdAtWhere(
  range?: FinanceDateRange,
): Prisma.DateTimeFilter | undefined {
  if (!range?.from && !range?.to) return undefined;
  return {
    ...(range.from ? { gte: range.from } : {}),
    ...(range.to ? { lte: range.to } : {}),
  };
}

export async function listUserPaymentAccounts(userId: string) {
  const accounts = await db.paymentAccount.findMany({
    where: { userId },
    include: {
      transactions: {
        orderBy: { createdAt: "desc" },
        take: 20,
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return accounts.map((account) => {
    const amountDue = Number(account.amountDue);
    const grossPaid = Number(account.paidAmount);
    const refunded = Number(account.refundedAmount);
    const netPaid = Math.max(0, grossPaid - refunded);
    const outstanding = Math.max(0, amountDue - netPaid);

    return {
      ...account,
      balance: {
        amountDue,
        grossPaid,
        refunded,
        netPaid,
        outstanding,
        status: account.status,
      },
    };
  });
}

export async function listFinanceAccounts(input?: {
  domain?: PaymentDomain | null;
  status?: PaymentAccountStatus | null;
  search?: string | null;
  take?: number;
}) {
  const search = input?.search?.trim() || null;
  return db.paymentAccount.findMany({
    where: {
      ...(input?.domain ? { domain: input.domain } : {}),
      ...(input?.status ? { status: input.status } : {}),
      ...(search
        ? {
            OR: [
              { referenceCode: { contains: search, mode: "insensitive" } },
              { description: { contains: search, mode: "insensitive" } },
              {
                user: {
                  is: { name: { contains: search, mode: "insensitive" } },
                },
              },
              {
                user: {
                  is: { email: { contains: search, mode: "insensitive" } },
                },
              },
              {
                user: {
                  is: { phone: { contains: search, mode: "insensitive" } },
                },
              },
            ],
          }
        : {}),
    },
    include: {
      user: { select: { id: true, name: true, email: true, phone: true } },
      transactions: {
        orderBy: { createdAt: "desc" },
        take: 8,
        include: {
          submittedBy: { select: { name: true } },
          verifiedBy: { select: { name: true } },
        },
      },
    },
    orderBy: { updatedAt: "desc" },
    take: Math.min(500, Math.max(1, input?.take ?? 150)),
  });
}

export async function financeReportSummary(range?: FinanceDateRange) {
  const [periodAccounts, currentAccounts, transactions] = await Promise.all([
    db.paymentAccount.findMany({
      where: { createdAt: createdAtWhere(range) },
      select: {
        domain: true,
        openingPaidAmount: true,
        openingRefundedAmount: true,
      },
    }),
    db.paymentAccount.findMany({
      select: {
        amountDue: true,
        paidAmount: true,
        refundedAmount: true,
        status: true,
      },
    }),
    db.paymentTransaction.findMany({
      where: { createdAt: createdAtWhere(range), status: "VERIFIED" },
      select: {
        type: true,
        amount: true,
        account: { select: { domain: true } },
      },
    }),
  ]);

  const revenueByDomain: Record<PaymentDomain, number> = {
    HEALTHCARE: 0,
    COMMERCE: 0,
    LEARNING: 0,
  };
  let verifiedPayments = 0;
  let verifiedRefunds = 0;

  for (const account of periodAccounts) {
    const openingNet =
      Number(account.openingPaidAmount) - Number(account.openingRefundedAmount);
    revenueByDomain[account.domain] += openingNet;
  }

  for (const transaction of transactions) {
    const amount = Number(transaction.amount);
    if (transaction.type === "PAYMENT") {
      verifiedPayments += amount;
      revenueByDomain[transaction.account.domain] += amount;
    } else if (transaction.type === "REFUND") {
      verifiedRefunds += amount;
      revenueByDomain[transaction.account.domain] -= amount;
    }
  }

  const historicalNet = periodAccounts.reduce(
    (sum, account) =>
      sum +
      Number(account.openingPaidAmount) -
      Number(account.openingRefundedAmount),
    0,
  );
  const transactionNet = verifiedPayments - verifiedRefunds;
  const netRevenue = historicalNet + transactionNet;
  const currentOutstanding = currentAccounts.reduce((sum, account) => {
    const netPaid = Math.max(
      0,
      Number(account.paidAmount) - Number(account.refundedAmount),
    );
    return sum + Math.max(0, Number(account.amountDue) - netPaid);
  }, 0);

  return {
    accountCount: periodAccounts.length,
    verifiedPayments,
    verifiedRefunds,
    netRevenue,
    outstandingApprox: currentOutstanding,
    revenueByDomain,
    pendingVerification: currentAccounts.filter(
      (account) => account.status === "PENDING_VERIFICATION",
    ).length,
    unpaid: currentAccounts.filter((account) => account.status === "UNPAID")
      .length,
    partial: currentAccounts.filter((account) => account.status === "PARTIAL")
      .length,
  };
}

export async function listFinanceTransactions(
  range?: FinanceDateRange,
  take = 300,
) {
  return db.paymentTransaction.findMany({
    where: { createdAt: createdAtWhere(range) },
    include: {
      account: {
        include: { user: { select: { name: true, email: true, phone: true } } },
      },
      submittedBy: { select: { name: true } },
      verifiedBy: { select: { name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: Math.min(1000, Math.max(1, take)),
  });
}
