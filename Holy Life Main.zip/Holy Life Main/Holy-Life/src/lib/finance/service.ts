import { randomUUID } from "node:crypto";
import {
  Prisma,
  type ManualPaymentMethod,
  type PaymentAccountStatus,
  type PaymentDomain,
  type PaymentTransactionStatus,
  type PaymentTransactionType,
} from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { calculatePaymentBalance } from "@/lib/finance/status";

type DbClient = Prisma.TransactionClient | typeof db;

export class FinanceError extends Error {}

function transactionCode(type: PaymentTransactionType): string {
  const prefix =
    type === "REFUND" ? "RFD" : type === "ADJUSTMENT" ? "ADJ" : "PAY";
  return `${prefix}-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`;
}

function decimal(value: number): Prisma.Decimal {
  return new Prisma.Decimal(value);
}

export async function ensurePaymentAccount(input: {
  userId?: string | null;
  domain: PaymentDomain;
  referenceType: string;
  referenceId: string;
  referenceCode: string;
  description: string;
  amountDue: number | string | { toString(): string };
  currency?: string;
}) {
  const amountDue = Number(input.amountDue.toString());
  if (!Number.isFinite(amountDue) || amountDue < 0)
    throw new FinanceError("Payment amount due is invalid.");

  return db.paymentAccount.upsert({
    where: {
      domain_referenceType_referenceId: {
        domain: input.domain,
        referenceType: input.referenceType,
        referenceId: input.referenceId,
      },
    },
    update: {
      userId: input.userId ?? null,
      referenceCode: input.referenceCode,
      description: input.description,
      amountDue: decimal(amountDue),
      currency: input.currency ?? "BDT",
    },
    create: {
      userId: input.userId ?? null,
      domain: input.domain,
      referenceType: input.referenceType,
      referenceId: input.referenceId,
      referenceCode: input.referenceCode,
      description: input.description,
      amountDue: decimal(amountDue),
      currency: input.currency ?? "BDT",
    },
  });
}

export async function reconcilePaymentAccountForReference(input: {
  domain: PaymentDomain;
  referenceType: "Appointment" | "CommerceOrder" | "CourseEnrollment";
  referenceId: string;
}) {
  if (input.referenceType === "Appointment") {
    const appointment = await db.appointment.findUnique({
      where: { id: input.referenceId },
      include: { doctor: { select: { name: true } } },
    });
    if (!appointment) throw new FinanceError("Appointment was not found.");
    return ensurePaymentAccount({
      userId: appointment.userId,
      domain: "HEALTHCARE",
      referenceType: "Appointment",
      referenceId: appointment.id,
      referenceCode: appointment.code,
      description: `${appointment.doctor.name} consultation`,
      amountDue: appointment.fee,
      currency: "BDT",
    });
  }

  if (input.referenceType === "CommerceOrder") {
    const order = await db.commerceOrder.findUnique({
      where: { id: input.referenceId },
    });
    if (!order) throw new FinanceError("Order was not found.");
    return ensurePaymentAccount({
      userId: order.userId,
      domain: "COMMERCE",
      referenceType: "CommerceOrder",
      referenceId: order.id,
      referenceCode: order.code,
      description: "Holy Life shop order",
      amountDue: order.grandTotal,
      currency: order.currency,
    });
  }

  const enrollment = await db.courseEnrollment.findUnique({
    where: { id: input.referenceId },
    include: {
      course: { select: { title: true, price: true, currency: true } },
    },
  });
  if (!enrollment) throw new FinanceError("Enrollment was not found.");
  if (Number(enrollment.course.price) <= 0) return null;

  return ensurePaymentAccount({
    userId: enrollment.userId,
    domain: "LEARNING",
    referenceType: "CourseEnrollment",
    referenceId: enrollment.id,
    referenceCode: enrollment.id,
    description: enrollment.course.title,
    amountDue: enrollment.course.price,
    currency: enrollment.course.currency,
  });
}

async function accountTotals(client: DbClient, accountId: string) {
  const account = await client.paymentAccount.findUnique({
    where: { id: accountId },
    include: { transactions: true },
  });
  if (!account) throw new FinanceError("Payment account was not found.");

  let verifiedPayments = 0;
  let verifiedRefunds = 0;
  let pendingPayments = 0;
  let rejectedPayments = 0;

  for (const transaction of account.transactions) {
    const amount = Number(transaction.amount);
    if (transaction.status === "VERIFIED" && transaction.type === "PAYMENT") {
      verifiedPayments += amount;
    } else if (
      transaction.status === "VERIFIED" &&
      transaction.type === "REFUND"
    ) {
      verifiedRefunds += amount;
    } else if (
      transaction.status === "PENDING" &&
      transaction.type === "PAYMENT"
    ) {
      pendingPayments += amount;
    } else if (
      transaction.status === "REJECTED" &&
      transaction.type === "PAYMENT"
    ) {
      rejectedPayments += amount;
    }
  }

  return {
    account,
    ...calculatePaymentBalance({
      amountDue: Number(account.amountDue),
      openingPaidAmount: Number(account.openingPaidAmount),
      openingRefundedAmount: Number(account.openingRefundedAmount),
      verifiedPayments,
      verifiedRefunds,
      pendingPayments,
      rejectedPayments,
    }),
    pendingPayments,
  };
}

async function syncLegacyStatus(
  client: Prisma.TransactionClient,
  account: {
    domain: PaymentDomain;
    referenceType: string;
    referenceId: string;
  },
  status: PaymentAccountStatus,
  actorId?: string | null,
) {
  if (
    account.domain === "HEALTHCARE" &&
    account.referenceType === "Appointment"
  ) {
    const legacy =
      status === "PAID"
        ? "PAID"
        : status === "PARTIAL"
          ? "PARTIAL"
          : status === "REFUNDED"
            ? "REFUNDED"
            : "UNPAID";
    await client.appointment.updateMany({
      where: { id: account.referenceId },
      data: { paymentStatus: legacy, updatedById: actorId ?? undefined },
    });
  }

  if (
    account.domain === "COMMERCE" &&
    account.referenceType === "CommerceOrder"
  ) {
    const legacy =
      status === "PENDING_VERIFICATION"
        ? "PENDING_VERIFICATION"
        : status === "PAID"
          ? "PAID"
          : status === "PARTIAL"
            ? "PARTIAL"
            : status === "REFUNDED"
              ? "REFUNDED"
              : "UNPAID";
    await client.commerceOrder.updateMany({
      where: { id: account.referenceId },
      data: { paymentStatus: legacy, updatedById: actorId ?? undefined },
    });
  }
}

async function refreshPaymentAccountInTransaction(
  tx: Prisma.TransactionClient,
  accountId: string,
  actorId?: string | null,
) {
  const totals = await accountTotals(tx, accountId);
  const updated = await tx.paymentAccount.update({
    where: { id: accountId },
    data: {
      status: totals.status,
      paidAmount: decimal(totals.grossPaid),
      refundedAmount: decimal(totals.refunded),
    },
  });
  await syncLegacyStatus(tx, updated, totals.status, actorId);
  return { ...totals, account: updated };
}

async function runFinanceTransaction<T>(
  operation: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await db.$transaction(operation, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 20_000,
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2034" &&
        attempt < 3
      ) {
        continue;
      }
      throw error;
    }
  }

  throw new FinanceError("Finance transaction could not be completed.");
}

export async function refreshPaymentAccount(
  accountId: string,
  actorId?: string | null,
) {
  return runFinanceTransaction((tx) =>
    refreshPaymentAccountInTransaction(tx, accountId, actorId),
  );
}

export async function submitManualPayment(input: {
  accountId: string;
  userId: string;
  amount: number;
  method: ManualPaymentMethod;
  transactionReference?: string | null;
  note?: string | null;
}) {
  return runFinanceTransaction(async (tx) => {
    const totals = await accountTotals(tx, input.accountId);
    if (totals.account.userId !== input.userId) {
      throw new FinanceError("Payment account access denied.");
    }
    if (totals.account.status === "REFUNDED") {
      throw new FinanceError("A refunded account cannot accept a payment.");
    }

    if (input.transactionReference) {
      const existing = await tx.paymentTransaction.findFirst({
        where: {
          accountId: input.accountId,
          type: "PAYMENT",
          transactionReference: input.transactionReference,
        },
        orderBy: { createdAt: "asc" },
      });
      if (existing) {
        if (
          existing.submittedById !== input.userId ||
          Number(existing.amount) !== input.amount ||
          existing.method !== input.method
        ) {
          throw new FinanceError(
            "This payment reference has already been submitted with different details.",
          );
        }
        return existing;
      }
    }

    const available = Math.max(0, totals.outstanding - totals.pendingPayments);
    if (input.amount > available + 0.001) {
      throw new FinanceError("Payment exceeds the outstanding balance.");
    }

    const transaction = await tx.paymentTransaction.create({
      data: {
        code: transactionCode("PAYMENT"),
        accountId: input.accountId,
        type: "PAYMENT",
        amount: decimal(input.amount),
        method: input.method,
        status: "PENDING",
        transactionReference: input.transactionReference ?? null,
        note: input.note ?? null,
        submittedById: input.userId,
      },
    });

    await refreshPaymentAccountInTransaction(tx, input.accountId, input.userId);
    return transaction;
  });
}

export async function recordVerifiedTransactionInTransaction(
  tx: Prisma.TransactionClient,
  input: {
    accountId: string;
    actorId: string;
    code?: string;
    type: Extract<PaymentTransactionType, "PAYMENT" | "REFUND">;
    amount: number;
    method?: ManualPaymentMethod | null;
    transactionReference?: string | null;
    note?: string | null;
  },
) {
  const totals = await accountTotals(tx, input.accountId);

  if (input.type === "PAYMENT" && input.amount > totals.outstanding + 0.001) {
    throw new FinanceError("Payment exceeds the outstanding balance.");
  }
  if (input.type === "REFUND" && input.amount > totals.netPaid + 0.001) {
    throw new FinanceError("Refund exceeds the verified net paid amount.");
  }

  const transaction = await tx.paymentTransaction.create({
    data: {
      code: input.code ?? transactionCode(input.type),
      accountId: input.accountId,
      type: input.type,
      amount: decimal(input.amount),
      method: input.method ?? null,
      status: "VERIFIED",
      transactionReference: input.transactionReference ?? null,
      note: input.note ?? null,
      submittedById: input.actorId,
      verifiedById: input.actorId,
      verifiedAt: new Date(),
    },
    include: { account: true },
  });

  const refreshed = await refreshPaymentAccountInTransaction(
    tx,
    input.accountId,
    input.actorId,
  );

  return { transaction, refreshed };
}

export async function recordVerifiedGatewayPaymentInTransaction(
  tx: Prisma.TransactionClient,
  input: {
    accountId: string;
    userId: string;
    gatewayAttemptId: string;
    amount: number;
    transactionReference: string;
    note?: string | null;
  },
) {
  const existing = await tx.paymentTransaction.findUnique({
    where: { gatewayAttemptId: input.gatewayAttemptId },
    include: { account: true },
  });
  if (existing) {
    return { transaction: existing, conflict: null as string | null };
  }

  const totals = await accountTotals(tx, input.accountId);
  if (totals.account.userId !== input.userId) {
    throw new FinanceError("Gateway payment account access denied.");
  }
  if (input.amount > totals.outstanding + 0.001) {
    return { transaction: null, conflict: "AMOUNT_EXCEEDS_OUTSTANDING" };
  }

  const transaction = await tx.paymentTransaction.create({
    data: {
      code: transactionCode("PAYMENT"),
      accountId: input.accountId,
      type: "PAYMENT",
      amount: decimal(input.amount),
      method: null,
      status: "VERIFIED",
      transactionReference: input.transactionReference,
      note:
        input.note ??
        "Verified automatically through the online payment gateway.",
      submittedById: input.userId,
      verifiedAt: new Date(),
      gatewayAttemptId: input.gatewayAttemptId,
    },
    include: { account: true },
  });

  await refreshPaymentAccountInTransaction(tx, input.accountId, input.userId);

  if (
    transaction.account.domain === "COMMERCE" &&
    transaction.account.referenceType === "CommerceOrder"
  ) {
    await tx.commerceOrder.updateMany({
      where: { id: transaction.account.referenceId },
      data: { paymentMethod: "ONLINE_GATEWAY", updatedById: input.userId },
    });
  }

  return { transaction, conflict: null as string | null };
}

export async function recordVerifiedTransaction(input: {
  accountId: string;
  actorId: string;
  type: Extract<PaymentTransactionType, "PAYMENT" | "REFUND">;
  amount: number;
  method?: ManualPaymentMethod | null;
  transactionReference?: string | null;
  note?: string | null;
}) {
  const result = await runFinanceTransaction((tx) =>
    recordVerifiedTransactionInTransaction(tx, input),
  );

  await createDashboardNotification({
    userId: result.transaction.account.userId,
    dedupeKey: `payment:${result.transaction.id}:verified`,
    kind: input.type === "REFUND" ? "WARNING" : "SUCCESS",
    department:
      result.transaction.account.domain === "HEALTHCARE"
        ? "HEALTHCARE"
        : result.transaction.account.domain === "COMMERCE"
          ? "COMMERCE"
          : "LEARNING",
    title:
      input.type === "REFUND"
        ? "Manual refund recorded"
        : "Manual payment recorded",
    message: `${result.transaction.code} · ${result.transaction.account.currency} ${input.amount.toFixed(2)}`,
    href: "/dashboard/payments",
  });

  return result;
}

export async function reviewPendingTransaction(input: {
  transactionId: string;
  actorId: string;
  status: Extract<PaymentTransactionStatus, "VERIFIED" | "REJECTED">;
  note?: string | null;
}) {
  const result = await runFinanceTransaction(async (tx) => {
    const current = await tx.paymentTransaction.findUnique({
      where: { id: input.transactionId },
      include: { account: true },
    });
    if (!current) throw new FinanceError("Payment transaction was not found.");
    if (current.status !== "PENDING") {
      throw new FinanceError("Only pending transactions can be reviewed.");
    }

    if (input.status === "VERIFIED" && current.type === "PAYMENT") {
      const totals = await accountTotals(tx, current.accountId);
      const otherPending = Math.max(
        0,
        totals.pendingPayments - Number(current.amount),
      );
      const available = Math.max(0, totals.outstanding - otherPending);
      if (Number(current.amount) > available + 0.001) {
        throw new FinanceError(
          "Verified amount would exceed the outstanding balance.",
        );
      }
    }

    const transaction = await tx.paymentTransaction.update({
      where: { id: current.id },
      data: {
        status: input.status,
        verifiedById: input.actorId,
        verifiedAt: new Date(),
        note: input.note ?? current.note,
      },
    });

    await refreshPaymentAccountInTransaction(
      tx,
      current.accountId,
      input.actorId,
    );
    return { transaction, account: current.account };
  });

  await createDashboardNotification({
    userId: result.account.userId,
    dedupeKey: `payment:${result.transaction.id}:review:${input.status}`,
    kind: input.status === "VERIFIED" ? "SUCCESS" : "WARNING",
    department:
      result.account.domain === "HEALTHCARE"
        ? "HEALTHCARE"
        : result.account.domain === "COMMERCE"
          ? "COMMERCE"
          : "LEARNING",
    title:
      input.status === "VERIFIED" ? "Payment verified" : "Payment rejected",
    message: `${result.transaction.code} · ${result.account.referenceCode}`,
    href: "/dashboard/payments",
  });

  return result.transaction;
}

export async function paymentAccountSnapshot(accountId: string) {
  return accountTotals(db, accountId);
}
