import type { Locale } from "@/lib/i18n/config";

// Only the known Holy Life system-default CMS copy is localized here. Content that an
// authorized editor enters in the CMS is preserved verbatim until a dedicated Bangla
// value is stored for that content. This prevents silent machine translation of real copy.
const bnDefaults: Record<string, string> = {
  "Health, fitness & wellness—connected":
    "চিকিৎসা, ফিটনেস ও সুস্থতা—একসঙ্গে সংযুক্ত",
  "One simple place to care, learn, and live healthier.":
    "চিকিৎসা নিন, শিখুন এবং আরও সুস্থভাবে বাঁচুন—একটি সহজ জায়গা থেকে।",
  "Holy Life brings doctor appointments, wellness learning, and healthy shopping into one clear experience for every member.":
    "Holy Life-এ ডাক্তারের অ্যাপয়েন্টমেন্ট, স্বাস্থ্যশিক্ষা এবং সুস্থ জীবনধারার প্রয়োজনীয় কেনাকাটা—সবকিছু এক সদস্য অ্যাকাউন্টে পরিষ্কারভাবে পরিচালনা করা যায়।",
  "Book an appointment": "অ্যাপয়েন্টমেন্ট নিন",
  "Open member dashboard": "সদস্য ড্যাশবোর্ড খুলুন",
  "Connected departments": "সংযুক্ত বিভাগ",
  "Unified member account": "একীভূত সদস্য অ্যাকাউন্ট",
  "Dashboard access": "ড্যাশবোর্ড ব্যবহার",
  "Permission-aware admin control": "অনুমতিভিত্তিক অ্যাডমিন নিয়ন্ত্রণ",
  "Everything works together": "সব সেবা সমন্বিতভাবে কাজ করে",
  "Three focused departments. One easy member journey.":
    "তিনটি বিশেষায়িত বিভাগ। সদস্যের জন্য একটি সহজ অভিজ্ঞতা।",
  "Each department stays clearly separated, while your profile, notifications, and history remain connected.":
    "প্রতিটি বিভাগ আলাদাভাবে পরিচালিত হলেও আপনার প্রোফাইল, নোটিফিকেশন ও কার্যক্রমের ইতিহাস একই অ্যাকাউন্টে সংযুক্ত থাকে।",
  "Doctor appointments and guided wellness care":
    "ডাক্তারের অ্যাপয়েন্টমেন্ট ও নির্দেশনাভিত্তিক সুস্থতা সেবা",
  "Find the right doctor, request an appointment, access prescriptions, and follow your wellness journey.":
    "উপযুক্ত ডাক্তার খুঁজুন, অ্যাপয়েন্টমেন্ট নিন, প্রেসক্রিপশন দেখুন এবং আপনার স্বাস্থ্যসেবার অগ্রগতি অনুসরণ করুন।",
  "Explore healthcare": "স্বাস্থ্যসেবা দেখুন",
  "Practical health courses for daily decisions":
    "দৈনন্দিন জীবনের জন্য ব্যবহারিক স্বাস্থ্যবিষয়ক কোর্স",
  "Learn from structured lessons and useful resources designed for real lifestyle change.":
    "সুশৃঙ্খল পাঠ ও প্রয়োজনীয় রিসোর্সের মাধ্যমে স্বাস্থ্যকর জীবনযাপনের বাস্তব দক্ষতা শিখুন।",
  "Browse courses": "কোর্স দেখুন",
  "Trusted products for healthier routines":
    "সুস্থ জীবনযাপনের জন্য নির্বাচিত প্রয়োজনীয় পণ্য",
  "Browse selected wellness products and track delivery from your Holy Life dashboard.":
    "নির্বাচিত সুস্থতা ও দৈনন্দিন প্রয়োজনের পণ্য দেখুন এবং Holy Life ড্যাশবোর্ড থেকে অর্ডার ও ডেলিভারি অনুসরণ করুন।",
  "Visit shop": "শপ দেখুন",
  "Designed around real tasks": "বাস্তব প্রয়োজনকে কেন্দ্র করে তৈরি",
  "Simple for members. Controlled for your team.":
    "সদস্যের জন্য সহজ, পরিচালনা দলের জন্য নিয়ন্ত্রিত।",
  "Public users get one dashboard while admins only see the departments and actions allowed by the owner.":
    "সদস্য একটি একীভূত ড্যাশবোর্ড ব্যবহার করেন, আর অ্যাডমিনরা মালিকের নির্ধারিত অনুমতি অনুযায়ী কেবল প্রয়োজনীয় বিভাগ ও কাজ দেখতে পারেন।",
  "Create one account": "একটি অ্যাকাউন্ট তৈরি করুন",
  "Use the same profile across appointments, courses, and orders.":
    "অ্যাপয়েন্টমেন্ট, কোর্স ও অর্ডার—সব জায়গায় একই প্রোফাইল ব্যবহার করুন।",
  "Choose what you need": "আপনার প্রয়োজনীয় সেবা বেছে নিন",
  "Book care, continue learning, or shop without a confusing workflow.":
    "জটিলতা ছাড়াই চিকিৎসা নিন, শেখা চালিয়ে যান অথবা প্রয়োজনীয় পণ্য কিনুন।",
  "Track everything clearly": "সব কার্যক্রম পরিষ্কারভাবে দেখুন",
  "See upcoming tasks, current progress, payments, and notifications together.":
    "আসন্ন কাজ, বর্তমান অগ্রগতি, পেমেন্ট ও নোটিফিকেশন এক জায়গায় দেখুন।",
  "Start your Holy Life journey": "আপনার Holy Life যাত্রা শুরু করুন",
  "Better health starts with one clear next step.":
    "সুস্থ জীবনের পথে পরবর্তী প্রয়োজনীয় কাজটি সহজে শুরু করুন।",
  "Book appointment": "অ্যাপয়েন্টমেন্ট নিন",
  "Explore courses": "কোর্স দেখুন",
  "About Holy Life": "Holy Life সম্পর্কে",
  "Doctor-led guidance with a simpler digital experience.":
    "ডাক্তারের পেশাদার নির্দেশনার সঙ্গে সহজ ডিজিটাল অভিজ্ঞতা।",
  "We connect care, practical learning, and selected wellness products through one secure member account.":
    "একটি নিরাপদ সদস্য অ্যাকাউন্টের মাধ্যমে চিকিৎসা, ব্যবহারিক স্বাস্থ্যশিক্ষা ও নির্বাচিত সুস্থতা পণ্যকে আমরা একসঙ্গে যুক্ত করি।",
  "Meet our doctors": "আমাদের ডাক্তারদের দেখুন",
  "Contact us": "যোগাযোগ করুন",
  "Our mission": "আমাদের লক্ষ্য",
  "Make better health decisions easier to take and easier to sustain.":
    "সঠিক স্বাস্থ্যসংক্রান্ত সিদ্ধান্ত নেওয়া এবং তা নিয়মিত অনুসরণ করা আরও সহজ করা।",
  "How we work": "আমরা যেভাবে কাজ করি",
  "Trust, clarity, and responsible access.":
    "আস্থা, স্বচ্ছতা এবং দায়িত্বশীল তথ্যপ্রবেশ।",
  "Doctor-led": "ডাক্তারের নির্দেশনাভিত্তিক",
  "Healthcare content and decisions remain grounded in professional guidance.":
    "স্বাস্থ্যসেবা সম্পর্কিত কনটেন্ট ও সিদ্ধান্ত পেশাদার নির্দেশনার ভিত্তিতে পরিচালিত হয়।",
  "Privacy-aware": "গোপনীয়তা-সচেতন",
  "Sensitive information is protected through role and record-level access.":
    "সংবেদনশীল তথ্য ভূমিকা ও রেকর্ডভিত্তিক অনুমতির মাধ্যমে সুরক্ষিত থাকে।",
  Practical: "ব্যবহারিক",
  "Every workflow is designed around a clear next action.":
    "প্রতিটি কাজের ধাপ এমনভাবে সাজানো যাতে পরবর্তী করণীয় সহজে বোঝা যায়।",
  "Our doctors": "আমাদের ডাক্তাররা",
  "Choose a professional who understands your goal.":
    "আপনার প্রয়োজন বুঝতে পারেন এমন উপযুক্ত চিকিৎসক বেছে নিন।",
  "Explore doctor profiles and continue to appointment booking when you are ready.":
    "ডাক্তারের প্রোফাইল দেখুন এবং প্রস্তুত হলে অ্যাপয়েন্টমেন্ট নিন।",
  "Healthcare team": "স্বাস্থ্যসেবা দল",
  "Professionals supporting your journey":
    "আপনার স্বাস্থ্যযাত্রায় সহায়তাকারী পেশাজীবীরা",
  "Doctor & appointment": "ডাক্তার ও অ্যাপয়েন্টমেন্ট",
  "Book the right care without a complicated process.":
    "জটিলতা ছাড়াই প্রয়োজনীয় স্বাস্থ্যসেবার জন্য অ্যাপয়েন্টমেন্ট নিন।",
  "Choose a doctor, select your preferred time, and track every appointment from your Holy Life dashboard.":
    "ডাক্তার ও সুবিধাজনক সময় বেছে নিন, তারপর Holy Life ড্যাশবোর্ড থেকে প্রতিটি অ্যাপয়েন্টমেন্ট অনুসরণ করুন।",
  "Open dashboard": "ড্যাশবোর্ড খুলুন",
  "Meet doctors": "ডাক্তার দেখুন",
  "How booking works": "অ্যাপয়েন্টমেন্ট নেওয়ার ধাপ",
  "A clear appointment request journey":
    "অ্যাপয়েন্টমেন্ট নেওয়ার সহজ ও পরিষ্কার প্রক্রিয়া",
  "Choose a doctor": "ডাক্তার বেছে নিন",
  "Review the available professional and service.":
    "উপলভ্য চিকিৎসক ও সেবার তথ্য দেখুন।",
  "Request a suitable time": "সুবিধাজনক সময় বেছে নিন",
  "Select your preferred date and time.":
    "আপনার সুবিধাজনক তারিখ ও সময় নির্বাচন করুন।",
  "Track confirmation": "নিশ্চিতকরণের অবস্থা দেখুন",
  "Follow appointment status from your dashboard.":
    "ড্যাশবোর্ড থেকে অ্যাপয়েন্টমেন্টের বর্তমান অবস্থা দেখুন।",
  "Member appointment tools": "সদস্যের অ্যাপয়েন্টমেন্ট সুবিধা",
  "Sign in to request and track your appointment.":
    "অ্যাপয়েন্টমেন্ট নিতে ও অবস্থা দেখতে সাইন ইন করুন।",
  "Sign in": "সাইন ইন",
  "Create account": "অ্যাকাউন্ট তৈরি করুন",
  "Holy Life learning": "Holy Life শিক্ষা",
  "Learn healthier habits through clear, structured lessons.":
    "পরিষ্কার ও সুশৃঙ্খল পাঠের মাধ্যমে স্বাস্থ্যকর অভ্যাস শিখুন।",
  "Explore practical courses designed to turn health knowledge into daily action.":
    "স্বাস্থ্যবিষয়ক জ্ঞানকে দৈনন্দিন অভ্যাসে রূপ দিতে তৈরি ব্যবহারিক কোর্সগুলো দেখুন।",
  "Open learning dashboard": "শেখার ড্যাশবোর্ড খুলুন",
  "Featured learning": "নির্বাচিত কোর্স",
  "Build useful knowledge at your own pace":
    "নিজের সুবিধামতো গতিতে প্রয়োজনীয় জ্ঞান অর্জন করুন",
  "Holy Life shop": "Holy Life শপ",
  "Trusted products for healthier everyday routines.":
    "দৈনন্দিন সুস্থ জীবনযাপনের জন্য নির্বাচিত প্রয়োজনীয় পণ্য।",
  "Browse selected wellness products and manage future orders through one member dashboard.":
    "নির্বাচিত পণ্য দেখুন এবং সদস্য ড্যাশবোর্ড থেকে বর্তমান ও ভবিষ্যৎ অর্ডার পরিচালনা করুন।",
  "Open my orders": "আমার অর্ডার দেখুন",
  "Shop by purpose": "প্রয়োজন অনুযায়ী পণ্য দেখুন",
  "Simple categories, useful products": "সহজ বিভাগে সাজানো প্রয়োজনীয় পণ্য",
  "Contact Holy Life": "Holy Life-এর সঙ্গে যোগাযোগ",
  "We are here to help.": "আপনার সহায়তায় আমরা আছি।",
  "Use the details below for general questions and support.":
    "সাধারণ প্রশ্ন ও সহায়তার জন্য নিচের যোগাযোগের তথ্য ব্যবহার করুন।",
  "Before you contact us": "যোগাযোগের আগে",
  "Common questions": "সাধারণ প্রশ্ন",
  "Can I manage appointments, courses, and orders from one account?":
    "একটি অ্যাকাউন্ট থেকে কি অ্যাপয়েন্টমেন্ট, কোর্স ও অর্ডার পরিচালনা করা যাবে?",
  "Yes. Holy Life uses one member account across all three departments.":
    "হ্যাঁ। Holy Life-এর তিনটি বিভাগেই একই সদস্য অ্যাকাউন্ট ব্যবহার করা যায়।",
  "Where can I see my activity?": "আমার কার্যক্রম কোথায় দেখব?",
  "Sign in and open your member dashboard to see current and historical activity.":
    "বর্তমান ও আগের কার্যক্রম দেখতে সাইন ইন করে সদস্য ড্যাশবোর্ড খুলুন।",
  "Complete Healthcare, Shopping & Learning Platform":
    "চিকিৎসা, কেনাকাটা ও স্বাস্থ্যশিক্ষার সমন্বিত প্ল্যাটফর্ম",
  "Live Healthy, Stay Fit": "সুস্থ থাকুন, সক্রিয় থাকুন",
  "Rangpur, Bangladesh": "রংপুর, বাংলাদেশ",
  "Every day, 8:00 AM - 10:00 PM": "প্রতিদিন, সকাল ৮টা–রাত ১০টা",
};

export function localizeDefaultCmsText(locale: Locale, value: string): string {
  if (locale !== "bn") return value;
  return bnDefaults[value] ?? value;
}
