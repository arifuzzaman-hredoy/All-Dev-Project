import { cookies } from "next/headers";
import {
  DEFAULT_LOCALE,
  DEFAULT_THEME_PREFERENCE,
  LOCALE_COOKIE,
  THEME_COOKIE,
  normalizeLocale,
  normalizeThemePreference,
  type Locale,
  type ThemePreference,
} from "@/lib/i18n/config";

export type UiPreferences = {
  locale: Locale;
  themePreference: ThemePreference;
};

export async function getUiPreferences(): Promise<UiPreferences> {
  const cookieStore = await cookies();
  return {
    locale: normalizeLocale(
      cookieStore.get(LOCALE_COOKIE)?.value ?? DEFAULT_LOCALE,
    ),
    themePreference: normalizeThemePreference(
      cookieStore.get(THEME_COOKIE)?.value ?? DEFAULT_THEME_PREFERENCE,
    ),
  };
}

export async function getLocale(): Promise<Locale> {
  return (await getUiPreferences()).locale;
}
