export type Locale = "bn" | "en";
export type ThemePreference = "light" | "dark" | "system";

export const DEFAULT_LOCALE: Locale = "bn";
export const DEFAULT_THEME_PREFERENCE: ThemePreference = "system";

export const LOCALE_COOKIE = "holy_life_locale";
export const THEME_COOKIE = "holy_life_theme";
export const LOCALE_STORAGE_KEY = "holy-life-locale";
export const THEME_STORAGE_KEY = "holy-life-theme";

export function normalizeLocale(value: string | null | undefined): Locale {
  return value === "bn" ? "bn" : "en";
}

export function normalizeThemePreference(
  value: string | null | undefined,
): ThemePreference {
  return value === "light" || value === "dark" ? value : "system";
}

export function htmlLanguage(locale: Locale): string {
  return locale === "bn" ? "bn-BD" : "en";
}

export function intlLocale(locale: Locale): string {
  return locale === "bn" ? "bn-BD" : "en-BD";
}
