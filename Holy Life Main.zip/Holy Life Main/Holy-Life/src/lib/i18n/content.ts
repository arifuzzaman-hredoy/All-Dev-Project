import type { Locale } from "@/lib/i18n/config";

function clean(value: string | null | undefined): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.trim();
  return normalized ? normalized : null;
}

export function localizedText(
  locale: Locale,
  english: string | null | undefined,
  bangla: string | null | undefined,
  fallback = "",
): string {
  if (locale === "bn") return clean(bangla) ?? clean(english) ?? fallback;
  return clean(english) ?? clean(bangla) ?? fallback;
}

export function localizedOptionalText(
  locale: Locale,
  english: string | null | undefined,
  bangla: string | null | undefined,
): string | null {
  const value = localizedText(locale, english, bangla);
  return value || null;
}

export function localizedList(
  locale: Locale,
  english: readonly string[] | null | undefined,
  bangla: readonly string[] | null | undefined,
): string[] {
  const preferred = locale === "bn" ? bangla : english;
  const fallback = locale === "bn" ? english : bangla;
  const chosen = preferred?.filter((item) => clean(item)) ?? [];
  if (chosen.length) return [...chosen];
  return fallback?.filter((item) => clean(item)) ?? [];
}

export function courseLevelLabel(locale: Locale, level: string): string {
  const normalized = level.trim().toUpperCase();
  if (locale === "bn") {
    const labels: Record<string, string> = {
      BEGINNER: "প্রাথমিক",
      INTERMEDIATE: "মধ্যম",
      ADVANCED: "উন্নত",
      ALL_LEVELS: "সব স্তর",
    };
    return labels[normalized] ?? level.replaceAll("_", " ");
  }
  const labels: Record<string, string> = {
    BEGINNER: "Beginner",
    INTERMEDIATE: "Intermediate",
    ADVANCED: "Advanced",
    ALL_LEVELS: "All levels",
  };
  return labels[normalized] ?? level.replaceAll("_", " ");
}

export function languageLabel(locale: Locale, language: string): string {
  if (locale !== "bn") return language;
  const normalized = language.trim().toLowerCase();
  if (["bangla", "bengali", "bn"].includes(normalized)) return "বাংলা";
  if (["english", "en"].includes(normalized)) return "ইংরেজি";
  return language;
}
