import { appOrigin } from "@/lib/auth/config";

export type PaymentGatewayMode = "disabled" | "sslcommerz";
export type SslCommerzEnvironment = "sandbox" | "live";

function integerFromEnv(
  name: string,
  fallback: number,
  minimum: number,
  maximum: number,
): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(
      `${name} must be an integer between ${minimum} and ${maximum}.`,
    );
  }
  return value;
}

function modeFromEnv(): PaymentGatewayMode {
  const value = (process.env.PAYMENT_GATEWAY_MODE ?? "disabled")
    .trim()
    .toLowerCase();
  if (value !== "disabled" && value !== "sslcommerz") {
    throw new Error(
      "PAYMENT_GATEWAY_MODE must be either 'disabled' or 'sslcommerz'.",
    );
  }
  return value;
}

function environmentFromEnv(): SslCommerzEnvironment {
  const value = (process.env.SSLCOMMERZ_ENVIRONMENT ?? "sandbox")
    .trim()
    .toLowerCase();
  if (value !== "sandbox" && value !== "live") {
    throw new Error(
      "SSLCOMMERZ_ENVIRONMENT must be either 'sandbox' or 'live'.",
    );
  }
  return value;
}

export const paymentGatewayConfig = {
  mode: modeFromEnv(),
  sslCommerzEnvironment: environmentFromEnv(),
  sslCommerzStoreId: process.env.SSLCOMMERZ_STORE_ID?.trim(),
  sslCommerzStorePassword: process.env.SSLCOMMERZ_STORE_PASSWORD?.trim(),
  reconcileSecret: process.env.PAYMENT_RECONCILE_SECRET?.trim(),
  providerTimeoutMs: integerFromEnv(
    "PAYMENT_GATEWAY_TIMEOUT_MS",
    12_000,
    2_000,
    60_000,
  ),
  attemptTtlMinutes: integerFromEnv(
    "PAYMENT_GATEWAY_ATTEMPT_TTL_MINUTES",
    30,
    5,
    180,
  ),
  reconcileBatchSize: integerFromEnv(
    "PAYMENT_RECONCILE_BATCH_SIZE",
    25,
    1,
    100,
  ),
} as const;

export function paymentGatewayEnabled(): boolean {
  return paymentGatewayConfig.mode === "sslcommerz";
}

export function paymentGatewayAvailable(): boolean {
  if (
    paymentGatewayConfig.mode !== "sslcommerz" ||
    !paymentGatewayConfig.sslCommerzStoreId ||
    !paymentGatewayConfig.sslCommerzStorePassword
  ) {
    return false;
  }

  try {
    const origin = new URL(appOrigin());
    return (
      origin.protocol === "https:" ||
      origin.hostname === "localhost" ||
      origin.hostname === "127.0.0.1"
    );
  } catch {
    return false;
  }
}

export function requireSslCommerzConfig() {
  if (paymentGatewayConfig.mode !== "sslcommerz") {
    throw new Error("Online payment gateway is disabled.");
  }

  if (
    !paymentGatewayConfig.sslCommerzStoreId ||
    !paymentGatewayConfig.sslCommerzStorePassword
  ) {
    throw new Error("SSLCOMMERZ credentials are not configured.");
  }

  const origin = new URL(appOrigin());
  const isLocalDevelopment =
    origin.hostname === "localhost" || origin.hostname === "127.0.0.1";
  if (origin.protocol !== "https:" && !isLocalDevelopment) {
    throw new Error(
      "Online payment gateway requires an HTTPS APP_URL outside local development.",
    );
  }

  return {
    environment: paymentGatewayConfig.sslCommerzEnvironment,
    storeId: paymentGatewayConfig.sslCommerzStoreId,
    storePassword: paymentGatewayConfig.sslCommerzStorePassword,
    appOrigin: origin.origin,
    timeoutMs: paymentGatewayConfig.providerTimeoutMs,
    attemptTtlMinutes: paymentGatewayConfig.attemptTtlMinutes,
  } as const;
}
