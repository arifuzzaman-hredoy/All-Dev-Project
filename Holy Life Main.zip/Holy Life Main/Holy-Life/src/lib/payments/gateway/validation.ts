export const SSLCOMMERZ_MIN_BDT = 10;
export const SSLCOMMERZ_MAX_BDT = 500_000;

export class GatewayValidationError extends Error {}

export function gatewayAmount(value: unknown): number {
  const amount =
    typeof value === "number" ? value : Number(String(value ?? ""));
  if (!Number.isFinite(amount))
    throw new GatewayValidationError("Payment amount is invalid.");
  const rounded = Math.round((amount + Number.EPSILON) * 100) / 100;
  if (Math.abs(amount - rounded) > 0.000001) {
    throw new GatewayValidationError(
      "Online payment amount cannot have more than two decimal places.",
    );
  }
  if (rounded < SSLCOMMERZ_MIN_BDT || rounded > SSLCOMMERZ_MAX_BDT) {
    throw new GatewayValidationError(
      `Online payment amount must be between BDT ${SSLCOMMERZ_MIN_BDT.toFixed(2)} and BDT ${SSLCOMMERZ_MAX_BDT.toFixed(2)}.`,
    );
  }
  return rounded;
}

export function requiredGatewayText(
  value: unknown,
  name: string,
  maxLength: number,
): string {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text) throw new GatewayValidationError(`${name} is required.`);
  if (text.length > maxLength)
    throw new GatewayValidationError(`${name} is too long.`);
  return text;
}

export function optionalGatewayText(
  value: unknown,
  maxLength: number,
): string | null {
  if (value == null) return null;
  const text = String(value).trim();
  if (!text) return null;
  if (text.length > maxLength)
    throw new GatewayValidationError("A payment field is too long.");
  return text;
}

export function amountsEqual(
  left: number | string,
  right: number | string,
): boolean {
  const a = Math.round(Number(left) * 100);
  const b = Math.round(Number(right) * 100);
  return Number.isFinite(a) && Number.isFinite(b) && a === b;
}

export function normalizedCurrency(value: unknown): string {
  return typeof value === "string" ? value.trim().toUpperCase() : "";
}

export type GatewayEvidence = {
  status: string;
  transactionId: string;
  amount: string | number;
  currency?: string | null;
  attemptReference?: string | null;
  accountReference?: string | null;
  riskLevel?: string | number | null;
};

export function gatewayEvidenceIssue(
  expected: {
    attemptId: string;
    accountId: string;
    transactionId: string;
    amount: string | number;
    currency: string;
  },
  evidence: GatewayEvidence,
): string | null {
  if (!(evidence.status === "VALID" || evidence.status === "VALIDATED")) {
    return `PROVIDER_STATUS_${evidence.status || "UNKNOWN"}`;
  }
  if (evidence.transactionId !== expected.transactionId)
    return "TRANSACTION_ID_MISMATCH";
  if (!amountsEqual(evidence.amount, expected.amount)) return "AMOUNT_MISMATCH";
  const currency = normalizedCurrency(evidence.currency);
  if (!currency) return "CURRENCY_MISSING";
  if (currency !== normalizedCurrency(expected.currency))
    return "CURRENCY_MISMATCH";
  if (
    evidence.attemptReference &&
    evidence.attemptReference !== expected.attemptId
  )
    return "ATTEMPT_REFERENCE_MISMATCH";
  if (
    evidence.accountReference &&
    evidence.accountReference !== expected.accountId
  )
    return "ACCOUNT_REFERENCE_MISMATCH";

  if (evidence.riskLevel == null || String(evidence.riskLevel).trim() === "")
    return "RISK_LEVEL_MISSING";
  const riskLevel = Number(evidence.riskLevel);
  if (!Number.isFinite(riskLevel) || ![0, 1].includes(riskLevel))
    return "RISK_LEVEL_INVALID";
  return riskLevel === 1 ? "RISK_LEVEL_HIGH" : null;
}
