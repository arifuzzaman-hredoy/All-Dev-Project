import { requireSslCommerzConfig } from "@/lib/payments/gateway/config";

export type SslCommerzSessionInput = {
  transactionId: string;
  amount: number;
  currency: string;
  attemptId: string;
  accountId: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    addressLine1: string;
    city: string;
    district?: string | null;
    postalCode?: string | null;
  };
  product: {
    name: string;
    category: string;
    profile: "general" | "physical-goods" | "non-physical-goods";
  };
};

export type SslCommerzValidation = {
  status: string;
  tran_id: string;
  val_id: string;
  amount: string;
  currency?: string;
  currency_type?: string;
  currency_amount?: string;
  bank_tran_id?: string;
  card_type?: string;
  risk_level?: string | number;
  risk_title?: string;
  value_a?: string;
  value_b?: string;
  APIConnect?: string;
  error?: string;
};

type SslCommerzSessionResponse = {
  status?: string;
  failedreason?: string;
  sessionkey?: string;
  GatewayPageURL?: string;
  redirectGatewayURL?: string;
};

type SslCommerzTransactionQueryResponse = {
  APIConnect?: string;
  no_of_trans_found?: number;
  element?: SslCommerzValidation[];
};

function endpoints(environment: "sandbox" | "live") {
  const origin =
    environment === "live"
      ? "https://securepay.sslcommerz.com"
      : "https://sandbox.sslcommerz.com";
  return {
    session: `${origin}/gwprocess/v4/api.php`,
    validation: `${origin}/validator/api/validationserverAPI.php`,
    transactionQuery: `${origin}/validator/api/merchantTransIDvalidationAPI.php`,
  } as const;
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
      cache: "no-store",
    });
  } finally {
    clearTimeout(timer);
  }
}

function callbackUrl(
  origin: string,
  action: "success" | "fail" | "cancel" | "ipn",
): string {
  return `${origin}/api/payments/gateway/sslcommerz/${action}`;
}

export async function createSslCommerzSession(input: SslCommerzSessionInput) {
  const config = requireSslCommerzConfig();
  const params = new URLSearchParams({
    store_id: config.storeId,
    store_passwd: config.storePassword,
    total_amount: input.amount.toFixed(2),
    currency: input.currency,
    tran_id: input.transactionId,
    success_url: callbackUrl(config.appOrigin, "success"),
    fail_url: callbackUrl(config.appOrigin, "fail"),
    cancel_url: callbackUrl(config.appOrigin, "cancel"),
    ipn_url: callbackUrl(config.appOrigin, "ipn"),
    cus_name: input.customer.name.slice(0, 50),
    cus_email: input.customer.email.slice(0, 50),
    cus_add1: input.customer.addressLine1.slice(0, 50),
    cus_city: input.customer.city.slice(0, 50),
    cus_state: (input.customer.district ?? input.customer.city).slice(0, 50),
    cus_postcode: (input.customer.postalCode ?? "0000").slice(0, 30),
    cus_country: "Bangladesh",
    cus_phone: input.customer.phone.slice(0, 20),
    shipping_method: "NO",
    product_name: input.product.name.slice(0, 255),
    product_category: input.product.category.slice(0, 100),
    product_profile: input.product.profile,
    value_a: input.attemptId,
    value_b: input.accountId,
  });

  const response = await fetchWithTimeout(
    endpoints(config.environment).session,
    {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: params,
    },
    config.timeoutMs,
  );

  if (!response.ok)
    throw new Error(`SSLCOMMERZ session API returned HTTP ${response.status}.`);
  const data = (await response.json()) as SslCommerzSessionResponse;
  const gatewayUrl = data.GatewayPageURL ?? data.redirectGatewayURL;
  if (data.status !== "SUCCESS" || !data.sessionkey || !gatewayUrl) {
    throw new Error(
      data.failedreason?.slice(0, 250) ||
        "SSLCOMMERZ did not create a payment session.",
    );
  }

  const parsedGatewayUrl = new URL(gatewayUrl);
  if (parsedGatewayUrl.protocol !== "https:") {
    throw new Error("SSLCOMMERZ returned an insecure gateway URL.");
  }
  const host = parsedGatewayUrl.hostname.toLowerCase();
  if (host !== "sslcommerz.com" && !host.endsWith(".sslcommerz.com")) {
    throw new Error("SSLCOMMERZ returned an unexpected gateway host.");
  }

  return {
    sessionKey: data.sessionkey,
    gatewayUrl: parsedGatewayUrl.toString(),
  };
}

export async function validateSslCommerzTransaction(
  validationId: string,
): Promise<SslCommerzValidation> {
  const config = requireSslCommerzConfig();
  const url = new URL(endpoints(config.environment).validation);
  url.searchParams.set("val_id", validationId);
  url.searchParams.set("store_id", config.storeId);
  url.searchParams.set("store_passwd", config.storePassword);
  url.searchParams.set("v", "1");
  url.searchParams.set("format", "json");

  const response = await fetchWithTimeout(
    url.toString(),
    { method: "GET" },
    config.timeoutMs,
  );
  if (!response.ok)
    throw new Error(
      `SSLCOMMERZ validation API returned HTTP ${response.status}.`,
    );
  return (await response.json()) as SslCommerzValidation;
}

export async function querySslCommerzTransaction(
  transactionId: string,
): Promise<SslCommerzValidation | null> {
  const config = requireSslCommerzConfig();
  const url = new URL(endpoints(config.environment).transactionQuery);
  url.searchParams.set("tran_id", transactionId);
  url.searchParams.set("store_id", config.storeId);
  url.searchParams.set("store_passwd", config.storePassword);
  url.searchParams.set("v", "1");
  url.searchParams.set("format", "json");

  const response = await fetchWithTimeout(
    url.toString(),
    { method: "GET" },
    config.timeoutMs,
  );
  if (!response.ok)
    throw new Error(
      `SSLCOMMERZ transaction query returned HTTP ${response.status}.`,
    );
  const data = (await response.json()) as SslCommerzTransactionQueryResponse;
  if (data.APIConnect !== "DONE" || !Array.isArray(data.element)) return null;
  return (
    data.element.find(
      (item) => item.status === "VALID" || item.status === "VALIDATED",
    ) ?? null
  );
}
