import { db } from "@/lib/db";

export async function listUserGatewayAttempts(userId: string, take = 30) {
  return db.paymentGatewayAttempt.findMany({
    where: { userId },
    include: {
      account: {
        select: { referenceCode: true, description: true, domain: true },
      },
      transaction: true,
    },
    orderBy: { createdAt: "desc" },
    take,
  });
}

export async function getUserGatewayAttemptByCode(
  userId: string,
  code: string,
) {
  return db.paymentGatewayAttempt.findFirst({
    where: { userId, code },
    include: { account: true, transaction: true },
  });
}

export async function listAdminGatewayAttempts(take = 100) {
  return db.paymentGatewayAttempt.findMany({
    include: {
      account: {
        select: { referenceCode: true, description: true, domain: true },
      },
      user: { select: { name: true, email: true, phone: true } },
      transaction: { select: { code: true, transactionReference: true } },
    },
    orderBy: { createdAt: "desc" },
    take,
  });
}
