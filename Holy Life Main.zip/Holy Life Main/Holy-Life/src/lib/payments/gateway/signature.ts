import { createHash, timingSafeEqual } from "node:crypto";

function md5(value: string): string {
  return createHash("md5").update(value, "utf8").digest("hex");
}

export function verifySslCommerzIpnSignature(
  form: FormData,
  storePassword: string,
): boolean {
  const verifySign = String(form.get("verify_sign") ?? "")
    .trim()
    .toLowerCase();
  const verifyKey = String(form.get("verify_key") ?? "").trim();
  if (!/^[a-f0-9]{32}$/.test(verifySign) || !verifyKey) return false;

  const pairs: Array<[string, string]> = [];
  for (const rawKey of verifyKey.split(",")) {
    const key = rawKey.trim();
    if (!key || key === "store_passwd") continue;
    const value = form.get(key);
    if (typeof value === "string") pairs.push([key, value]);
  }
  pairs.push(["store_passwd", md5(storePassword)]);
  pairs.sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0));

  const calculated = md5(
    pairs.map(([key, value]) => `${key}=${value}`).join("&"),
  );
  const actual = Buffer.from(calculated, "hex");
  const expected = Buffer.from(verifySign, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
