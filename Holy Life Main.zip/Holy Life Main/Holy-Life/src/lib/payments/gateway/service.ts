import { randomUUID } from "node:crypto";
import {
  Prisma,
  type PaymentGatewayAttemptStatus,
} from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { recordVerifiedGatewayPaymentInTransaction } from "@/lib/finance/service";
import {
  paymentGatewayConfig,
  requireSslCommerzConfig,
} from "@/lib/payments/gateway/config";
import {
  createSslCommerzSession,
  querySslCommerzTransaction,
  type SslCommerzValidation,
  validateSslCommerzTransaction,
} from "@/lib/payments/gateway/sslcommerz";
import {
  gatewayAmount,
  gatewayEvidenceIssue,
  normalizedCurrency,
} from "@/lib/payments/gateway/validation";

export class PaymentGatewayError extends Error {}

type BillingInput = {
  addressLine1: string;
  city: string;
  district?: string | null;
  postalCode?: string | null;
};

function gatewayCode(): string {
  return `GW-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`;
}

function providerTransactionId(): string {
  return `HL${Date.now().toString(36).toUpperCase()}${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`.slice(
    0,
    30,
  );
}

function decimal(value: number): Prisma.Decimal {
  return new Prisma.Decimal(value.toFixed(2));
}

async function serializable<T>(
  operation: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await db.$transaction(operation, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 20_000,
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2034" &&
        attempt < 3
      ) {
        continue;
      }
      throw error;
    }
  }
  throw new PaymentGatewayError(
    "Payment gateway operation could not be completed.",
  );
}

function productProfile(domain: "HEALTHCARE" | "COMMERCE" | "LEARNING") {
  if (domain === "COMMERCE") {
    return { category: "health-commerce", profile: "physical-goods" as const };
  }
  if (domain === "LEARNING") {
    return { category: "education", profile: "non-physical-goods" as const };
  }
  return { category: "healthcare", profile: "non-physical-goods" as const };
}

export async function createPaymentGatewayAttempt(input: {
  accountId: string;
  userId: string;
  amount: number;
  idempotencyKey: string;
  billing: BillingInput;
}) {
  const config = requireSslCommerzConfig();
  const amount = gatewayAmount(input.amount);

  const prepareAttempt = () =>
    serializable(async (tx) => {
      const duplicate = await tx.paymentGatewayAttempt.findUnique({
        where: {
          userId_idempotencyKey: {
            userId: input.userId,
            idempotencyKey: input.idempotencyKey,
          },
        },
      });
      if (duplicate) return { attempt: duplicate, created: false as const };

      const account = await tx.paymentAccount.findFirst({
        where: { id: input.accountId, userId: input.userId },
        include: {
          user: {
            select: {
              name: true,
              email: true,
              emailVerifiedAt: true,
              phone: true,
              phoneVerifiedAt: true,
            },
          },
          transactions: { select: { amount: true, type: true, status: true } },
        },
      });
      if (!account)
        throw new PaymentGatewayError("Payment account was not found.");
      if (account.status === "REFUNDED")
        throw new PaymentGatewayError(
          "A refunded account cannot accept payment.",
        );
      if (normalizedCurrency(account.currency) !== "BDT") {
        throw new PaymentGatewayError(
          "SSLCOMMERZ payments are enabled only for BDT accounts.",
        );
      }

      const accountUser = account.user;
      if (!accountUser) {
        throw new PaymentGatewayError(
          "Online payment requires a user-owned payment account.",
        );
      }
      if (!accountUser.email || !accountUser.emailVerifiedAt) {
        throw new PaymentGatewayError(
          "A verified email address is required for online payment.",
        );
      }
      if (!accountUser.phone || !accountUser.phoneVerifiedAt) {
        throw new PaymentGatewayError(
          "A verified phone number is required for online payment.",
        );
      }

      const customer = {
        name: accountUser.name,
        email: accountUser.email,
        phone: accountUser.phone,
      };

      let verifiedPayments = Number(account.openingPaidAmount);
      let verifiedRefunds = Number(account.openingRefundedAmount);
      let pendingPayments = 0;
      for (const transaction of account.transactions) {
        const value = Number(transaction.amount);
        if (transaction.type === "PAYMENT" && transaction.status === "VERIFIED")
          verifiedPayments += value;
        if (transaction.type === "REFUND" && transaction.status === "VERIFIED")
          verifiedRefunds += value;
        if (transaction.type === "PAYMENT" && transaction.status === "PENDING")
          pendingPayments += value;
      }
      const outstanding = Math.max(
        0,
        Number(account.amountDue) -
          Math.max(0, verifiedPayments - verifiedRefunds),
      );
      const available = Math.max(0, outstanding - pendingPayments);
      if (amount > available + 0.001) {
        throw new PaymentGatewayError(
          "Online payment exceeds the available outstanding balance.",
        );
      }

      const existingActive = await tx.paymentGatewayAttempt.findFirst({
        where: {
          accountId: account.id,
          status: {
            in: ["CREATED", "SESSION_CREATED", "VALIDATING", "REVIEW_REQUIRED"],
          },
        },
        orderBy: { createdAt: "desc" },
      });
      if (existingActive) {
        throw new PaymentGatewayError(
          existingActive.status === "REVIEW_REQUIRED"
            ? "A previous online payment requires finance review before another payment can be started."
            : "Another online payment attempt is still being reconciled for this account.",
        );
      }

      const attempt = await tx.paymentGatewayAttempt.create({
        data: {
          code: gatewayCode(),
          accountId: account.id,
          userId: input.userId,
          provider: "SSLCOMMERZ",
          status: "CREATED",
          idempotencyKey: input.idempotencyKey,
          providerTransactionId: providerTransactionId(),
          amount: decimal(amount),
          currency: "BDT",
          expiresAt: new Date(Date.now() + config.attemptTtlMinutes * 60_000),
        },
      });

      return { attempt, created: true as const, account, customer };
    });

  let prepared: Awaited<ReturnType<typeof prepareAttempt>>;
  try {
    prepared = await prepareAttempt();
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      const duplicate = await db.paymentGatewayAttempt.findUnique({
        where: {
          userId_idempotencyKey: {
            userId: input.userId,
            idempotencyKey: input.idempotencyKey,
          },
        },
      });
      if (duplicate) {
        prepared = { attempt: duplicate, created: false as const };
      } else {
        throw error;
      }
    } else {
      throw error;
    }
  }

  if (!prepared.created) {
    if (
      prepared.attempt.status === "SESSION_CREATED" &&
      prepared.attempt.gatewayUrl
    ) {
      return prepared.attempt;
    }
    throw new PaymentGatewayError(
      "This payment request has already been used. Refresh and try again.",
    );
  }

  try {
    const session = await createSslCommerzSession({
      transactionId: prepared.attempt.providerTransactionId,
      amount,
      currency: "BDT",
      attemptId: prepared.attempt.id,
      accountId: prepared.account.id,
      customer: {
        ...prepared.customer,
        addressLine1: input.billing.addressLine1,
        city: input.billing.city,
        district: input.billing.district,
        postalCode: input.billing.postalCode,
      },
      product: {
        name: prepared.account.description,
        ...productProfile(prepared.account.domain),
      },
    });

    return await db.paymentGatewayAttempt.update({
      where: { id: prepared.attempt.id },
      data: {
        status: "SESSION_CREATED",
        sessionKey: session.sessionKey,
        gatewayUrl: session.gatewayUrl,
        failureReason: null,
      },
    });
  } catch (error) {
    await db.paymentGatewayAttempt.update({
      where: { id: prepared.attempt.id },
      data: {
        status: "FAILED",
        failureReason:
          error instanceof Error
            ? error.message.slice(0, 500)
            : "Gateway session creation failed.",
        completedAt: new Date(),
        sessionKey: null,
        gatewayUrl: null,
      },
    });
    throw new PaymentGatewayError(
      error instanceof Error
        ? error.message
        : "Online payment session could not be created.",
    );
  }
}

export async function applySslCommerzValidation(input: {
  providerTransactionId: string;
  validation: SslCommerzValidation;
}) {
  const result = await serializable(async (tx) => {
    const attempt = await tx.paymentGatewayAttempt.findUnique({
      where: { providerTransactionId: input.providerTransactionId },
      include: { account: true },
    });
    if (!attempt)
      throw new PaymentGatewayError("Gateway payment attempt was not found.");
    if (attempt.status === "SUCCEEDED")
      return { attempt, credited: false, alreadyComplete: true };

    const rawRiskLevel = input.validation.risk_level;
    const parsedRiskLevel =
      rawRiskLevel == null || String(rawRiskLevel).trim() === ""
        ? null
        : Number(rawRiskLevel);
    const mismatch = gatewayEvidenceIssue(
      {
        attemptId: attempt.id,
        accountId: attempt.accountId,
        transactionId: attempt.providerTransactionId,
        amount: attempt.amount.toString(),
        currency: attempt.currency,
      },
      {
        status: input.validation.status,
        transactionId: input.validation.tran_id,
        amount: input.validation.amount,
        currency: input.validation.currency_type || input.validation.currency,
        attemptReference: input.validation.value_a,
        accountReference: input.validation.value_b,
        riskLevel: input.validation.risk_level,
      },
    );
    const validationData = {
      validationId: input.validation.val_id || attempt.validationId,
      bankTransactionId:
        input.validation.bank_tran_id || attempt.bankTransactionId,
      providerStatus: input.validation.status || null,
      riskLevel:
        parsedRiskLevel != null && Number.isFinite(parsedRiskLevel)
          ? parsedRiskLevel
          : null,
      riskTitle: input.validation.risk_title?.slice(0, 100) || null,
      validatedAt: new Date(),
    } as const;

    if (mismatch) {
      const updated = await tx.paymentGatewayAttempt.update({
        where: { id: attempt.id },
        data: {
          ...validationData,
          status: "REVIEW_REQUIRED",
          reviewReason: mismatch,
          failureReason: null,
          sessionKey: null,
          gatewayUrl: null,
        },
      });
      return { attempt: updated, credited: false, alreadyComplete: false };
    }

    const reference =
      input.validation.bank_tran_id ||
      input.validation.val_id ||
      attempt.providerTransactionId;
    const finance = await recordVerifiedGatewayPaymentInTransaction(tx, {
      accountId: attempt.accountId,
      userId: attempt.userId,
      gatewayAttemptId: attempt.id,
      amount: Number(attempt.amount),
      transactionReference: reference,
      note: `SSLCOMMERZ ${attempt.providerTransactionId}`,
    });

    if (finance.conflict) {
      const updated = await tx.paymentGatewayAttempt.update({
        where: { id: attempt.id },
        data: {
          ...validationData,
          status: "REVIEW_REQUIRED",
          reviewReason: finance.conflict,
          sessionKey: null,
          gatewayUrl: null,
        },
      });
      return { attempt: updated, credited: false, alreadyComplete: false };
    }

    const updated = await tx.paymentGatewayAttempt.update({
      where: { id: attempt.id },
      data: {
        ...validationData,
        status: "SUCCEEDED",
        reviewReason: null,
        failureReason: null,
        completedAt: new Date(),
        sessionKey: null,
        gatewayUrl: null,
      },
    });
    return {
      attempt: updated,
      credited: Boolean(finance.transaction),
      alreadyComplete: false,
    };
  });

  if (result.attempt.status === "SUCCEEDED") {
    await createDashboardNotification({
      userId: result.attempt.userId,
      dedupeKey: `gateway:${result.attempt.id}:succeeded`,
      kind: "SUCCESS",
      department: "SYSTEM",
      title: "Online payment verified",
      message: `${result.attempt.code} · BDT ${Number(result.attempt.amount).toFixed(2)}`,
      href: "/dashboard/payments",
    });
  } else if (result.attempt.status === "REVIEW_REQUIRED") {
    await createDashboardNotification({
      userId: result.attempt.userId,
      dedupeKey: `gateway:${result.attempt.id}:review`,
      kind: "WARNING",
      department: "SYSTEM",
      title: "Payment is under review",
      message:
        "The gateway reported a payment that requires finance review before crediting your account.",
      href: "/dashboard/payments",
    });
  }

  return result;
}

export async function validateAndApplySslCommerz(input: {
  providerTransactionId: string;
  validationId: string;
}) {
  await db.paymentGatewayAttempt.updateMany({
    where: {
      providerTransactionId: input.providerTransactionId,
      status: {
        in: ["CREATED", "SESSION_CREATED", "VALIDATING", "REVIEW_REQUIRED"],
      },
    },
    data: { status: "VALIDATING" },
  });
  const validation = await validateSslCommerzTransaction(input.validationId);
  return applySslCommerzValidation({
    providerTransactionId: input.providerTransactionId,
    validation,
  });
}

export async function markGatewayAttemptTerminal(input: {
  providerTransactionId: string;
  status: Extract<PaymentGatewayAttemptStatus, "FAILED" | "CANCELLED">;
  reason: string;
}) {
  return db.paymentGatewayAttempt.updateMany({
    where: {
      providerTransactionId: input.providerTransactionId,
      status: { notIn: ["SUCCEEDED", "REVIEW_REQUIRED"] },
    },
    data: {
      status: input.status,
      providerStatus: input.status,
      failureReason: input.reason.slice(0, 500),
      completedAt: new Date(),
      sessionKey: null,
      gatewayUrl: null,
    },
  });
}

export async function revalidateGatewayAttempt(attemptId: string) {
  const attempt = await db.paymentGatewayAttempt.findUnique({
    where: { id: attemptId },
  });
  if (!attempt)
    throw new PaymentGatewayError("Gateway payment attempt was not found.");
  if (attempt.status === "SUCCEEDED")
    return { attempt, credited: false, alreadyComplete: true };

  let validation: SslCommerzValidation | null = null;
  if (attempt.validationId) {
    validation = await validateSslCommerzTransaction(attempt.validationId);
  } else {
    validation = await querySslCommerzTransaction(
      attempt.providerTransactionId,
    );
  }
  if (!validation?.val_id)
    throw new PaymentGatewayError(
      "SSLCOMMERZ does not report a completed transaction yet.",
    );
  return applySslCommerzValidation({
    providerTransactionId: attempt.providerTransactionId,
    validation,
  });
}

export async function reconcileGatewayAttempts() {
  if (paymentGatewayConfig.mode !== "sslcommerz") {
    return { scanned: 0, completed: 0, review: 0, expired: 0, failed: 0 };
  }

  const now = new Date();
  const attempts = await db.paymentGatewayAttempt.findMany({
    where: {
      provider: "SSLCOMMERZ",
      status: { in: ["CREATED", "SESSION_CREATED", "VALIDATING"] },
      updatedAt: { lt: new Date(now.getTime() - 60_000) },
    },
    orderBy: { updatedAt: "asc" },
    take: paymentGatewayConfig.reconcileBatchSize,
  });

  let completed = 0;
  let review = 0;
  let expired = 0;
  let failed = 0;

  for (const attempt of attempts) {
    try {
      const validation = await querySslCommerzTransaction(
        attempt.providerTransactionId,
      );
      if (validation?.val_id) {
        const result = await applySslCommerzValidation({
          providerTransactionId: attempt.providerTransactionId,
          validation,
        });
        if (result.attempt.status === "SUCCEEDED") completed += 1;
        if (result.attempt.status === "REVIEW_REQUIRED") review += 1;
        continue;
      }

      if (attempt.expiresAt <= now) {
        const update = await db.paymentGatewayAttempt.updateMany({
          where: {
            id: attempt.id,
            status: { in: ["CREATED", "SESSION_CREATED", "VALIDATING"] },
          },
          data: {
            status: "EXPIRED",
            completedAt: now,
            failureReason:
              "Payment attempt expired after provider reconciliation found no completed transaction.",
            sessionKey: null,
            gatewayUrl: null,
          },
        });
        expired += update.count;
      }
    } catch (error) {
      failed += 1;
      console.error("Gateway reconciliation attempt failed", attempt.id, error);
    }
  }

  return { scanned: attempts.length, completed, review, expired, failed };
}
