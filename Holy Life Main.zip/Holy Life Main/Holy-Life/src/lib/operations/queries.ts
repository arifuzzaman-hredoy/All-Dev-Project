import type { OperationalRunKind } from "@/generated/prisma/client";
import { db } from "@/lib/db";

export async function operationsSnapshot() {
  const [
    latestBackup,
    latestRestoreTest,
    latestRepositoryCheck,
    recentFailures,
    recentRuns,
  ] = await Promise.all([
    db.operationalRun.findFirst({
      where: { kind: "BACKUP", status: "SUCCEEDED" },
      orderBy: { finishedAt: "desc" },
    }),
    db.operationalRun.findFirst({
      where: { kind: "RESTORE_TEST", status: "SUCCEEDED" },
      orderBy: { finishedAt: "desc" },
    }),
    db.operationalRun.findFirst({
      where: { kind: "REPOSITORY_CHECK", status: "SUCCEEDED" },
      orderBy: { finishedAt: "desc" },
    }),
    db.operationalRun.count({
      where: {
        status: "FAILED",
        createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
      },
    }),
    db.operationalRun.findMany({
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
  ]);

  return {
    latestBackup,
    latestRestoreTest,
    latestRepositoryCheck,
    recentFailures,
    recentRuns,
  };
}

export async function listOperationalRuns(
  kind?: OperationalRunKind | null,
  take = 100,
) {
  return db.operationalRun.findMany({
    where: kind ? { kind } : undefined,
    orderBy: { createdAt: "desc" },
    take: Math.min(Math.max(1, take), 500),
  });
}
