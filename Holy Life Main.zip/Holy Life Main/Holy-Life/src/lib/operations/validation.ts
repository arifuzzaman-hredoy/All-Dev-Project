export const OPERATIONAL_RUN_KINDS = [
  "BACKUP",
  "RESTORE",
  "RESTORE_TEST",
  "REPOSITORY_CHECK",
  "DIAGNOSTICS",
  "SECURITY_SCAN",
] as const;

export const OPERATIONAL_RUN_STATUSES = [
  "RUNNING",
  "SUCCEEDED",
  "FAILED",
] as const;

type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
type JsonObject = { [key: string]: JsonValue };

type UnknownObject = Record<string, unknown>;

function objectValue(value: unknown): UnknownObject {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Operational report payload must be an object.");
  }
  return value as UnknownObject;
}

function requiredText(
  value: unknown,
  field: string,
  maxLength: number,
): string {
  if (typeof value !== "string" || !value.trim())
    throw new Error(`${field} is required.`);
  const result = value.trim();
  if (result.length > maxLength)
    throw new Error(`${field} exceeds ${maxLength} characters.`);
  return result;
}

function optionalText(
  value: unknown,
  field: string,
  maxLength: number,
): string | null {
  if (value == null || value === "") return null;
  if (typeof value !== "string") throw new Error(`${field} must be text.`);
  const result = value.trim();
  if (!result) return null;
  if (result.length > maxLength)
    throw new Error(`${field} exceeds ${maxLength} characters.`);
  return result;
}

function enumValue<T extends string>(
  value: unknown,
  values: readonly T[],
  field: string,
): T {
  const result = requiredText(value, field, 64);
  if (!values.includes(result as T)) throw new Error(`${field} is invalid.`);
  return result as T;
}

function timestamp(value: unknown, field: string): Date {
  const raw = requiredText(value, field, 64);
  const parsed = new Date(raw);
  if (!Number.isFinite(parsed.getTime()))
    throw new Error(`${field} is invalid.`);
  return parsed;
}

function jsonValue(value: unknown, depth = 0): JsonValue {
  if (depth > 12) throw new Error("metadata is too deeply nested.");
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value))
      throw new Error("metadata contains a non-finite number.");
    return value;
  }
  if (Array.isArray(value))
    return value.map((item) => jsonValue(item, depth + 1));
  if (typeof value === "object") {
    const result: JsonObject = {};
    for (const [key, item] of Object.entries(value))
      result[key] = jsonValue(item, depth + 1);
    return result;
  }
  throw new Error("metadata contains an unsupported value.");
}

function optionalMetadata(value: unknown): JsonObject | undefined {
  if (value == null) return undefined;
  if (typeof value !== "object" || Array.isArray(value)) {
    throw new Error("metadata must be a JSON object.");
  }

  const normalized = jsonValue(value);
  if (
    Array.isArray(normalized) ||
    normalized === null ||
    typeof normalized !== "object"
  ) {
    throw new Error("metadata must be a JSON object.");
  }

  const serialized = JSON.stringify(normalized);
  if (serialized.length > 8_000) throw new Error("metadata is too large.");

  return normalized;
}

export function parseOperationalReport(value: unknown) {
  const body = objectValue(value);
  const status = enumValue(body.status, OPERATIONAL_RUN_STATUSES, "status");
  const startedAt = timestamp(body.startedAt, "startedAt");
  const finishedAt = body.finishedAt
    ? timestamp(body.finishedAt, "finishedAt")
    : null;

  if (finishedAt && finishedAt < startedAt) {
    throw new Error("finishedAt cannot be earlier than startedAt.");
  }

  if (status === "RUNNING" && finishedAt) {
    throw new Error("Running operation cannot have finishedAt.");
  }

  if (status !== "RUNNING" && !finishedAt) {
    throw new Error("Completed operation requires finishedAt.");
  }

  return {
    runKey: requiredText(body.runKey, "runKey", 160),
    kind: enumValue(body.kind, OPERATIONAL_RUN_KINDS, "kind"),
    status,
    startedAt,
    finishedAt,
    host: optionalText(body.host, "host", 200),
    release: optionalText(body.release, "release", 100),
    snapshotId: optionalText(body.snapshotId, "snapshotId", 128),
    summary: optionalText(body.summary, "summary", 1_000),
    metadata: optionalMetadata(body.metadata),
  };
}
