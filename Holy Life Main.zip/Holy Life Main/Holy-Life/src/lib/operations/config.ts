export const operationsConfig = {
  reportSecret: process.env.OPERATIONS_REPORT_SECRET?.trim(),
};
