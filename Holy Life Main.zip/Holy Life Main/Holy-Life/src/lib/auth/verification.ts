import type {
  VerificationChannel,
  VerificationPurpose,
} from "@/generated/prisma/client";
import { authConfig } from "@/lib/auth/config";
import {
  createNumericCode,
  createOpaqueToken,
  hashOpaqueToken,
  hashSensitiveValue,
} from "@/lib/auth/crypto";
import { deliverAuthChallenge } from "@/lib/auth/delivery";
import { db } from "@/lib/db";

export class VerificationCooldownError extends Error {
  constructor(public readonly retryAfterSeconds: number) {
    super(`Wait ${retryAfterSeconds} seconds before requesting another code.`);
    this.name = "VerificationCooldownError";
  }
}

export async function createVerificationChallenge(input: {
  userId?: string | null;
  target: string;
  channel: VerificationChannel;
  purpose: VerificationPurpose;
}): Promise<{ id: string }> {
  const now = new Date();
  const latest = await db.verificationChallenge.findFirst({
    where: {
      target: input.target,
      purpose: input.purpose,
      consumedAt: null,
      expiresAt: { gt: now },
    },
    orderBy: { createdAt: "desc" },
    select: { createdAt: true },
  });

  if (latest) {
    const elapsedSeconds = Math.floor(
      (now.getTime() - latest.createdAt.getTime()) / 1000,
    );
    if (elapsedSeconds < authConfig.verificationResendSeconds) {
      throw new VerificationCooldownError(
        authConfig.verificationResendSeconds - elapsedSeconds,
      );
    }
  }

  const ttl =
    input.purpose === "PASSWORD_RESET"
      ? authConfig.passwordResetTtlMinutes
      : authConfig.verificationTtlMinutes;
  const code = createNumericCode();
  const token = createOpaqueToken();

  await db.verificationChallenge.updateMany({
    where: {
      target: input.target,
      purpose: input.purpose,
      consumedAt: null,
      expiresAt: { gt: now },
    },
    data: { consumedAt: now },
  });

  const challenge = await db.verificationChallenge.create({
    data: {
      userId: input.userId ?? null,
      target: input.target,
      channel: input.channel,
      purpose: input.purpose,
      tokenHash: hashOpaqueToken(token),
      codeHash: hashSensitiveValue(code),
      expiresAt: new Date(now.getTime() + ttl * 60_000),
    },
    select: { id: true },
  });

  try {
    await deliverAuthChallenge({
      channel: input.channel,
      target: input.target,
      purpose: input.purpose,
      code,
      token,
    });
  } catch (error) {
    await db.verificationChallenge
      .update({ where: { id: challenge.id }, data: { consumedAt: new Date() } })
      .catch(() => undefined);
    throw error;
  }

  return challenge;
}

export async function consumeChallenge(input: {
  token?: string | null;
  code?: string | null;
  userId?: string | null;
  purpose: VerificationPurpose;
}): Promise<{
  userId: string | null;
  target: string;
  channel: VerificationChannel;
  challengeId: string;
} | null> {
  const now = new Date();
  const challenge = input.token
    ? await db.verificationChallenge.findUnique({
        where: { tokenHash: hashOpaqueToken(input.token) },
      })
    : input.userId
      ? await db.verificationChallenge.findFirst({
          where: {
            userId: input.userId,
            purpose: input.purpose,
            consumedAt: null,
            expiresAt: { gt: now },
          },
          orderBy: { createdAt: "desc" },
        })
      : null;

  if (
    !challenge ||
    challenge.purpose !== input.purpose ||
    challenge.consumedAt ||
    challenge.expiresAt <= now ||
    challenge.attempts >= challenge.maxAttempts
  ) {
    return null;
  }

  if (
    !input.token &&
    (!input.code || hashSensitiveValue(input.code) !== challenge.codeHash)
  ) {
    await db.verificationChallenge.updateMany({
      where: {
        id: challenge.id,
        consumedAt: null,
        attempts: { lt: challenge.maxAttempts },
      },
      data: { attempts: { increment: 1 } },
    });
    return null;
  }

  const consumed = await db.verificationChallenge.updateMany({
    where: {
      id: challenge.id,
      consumedAt: null,
      expiresAt: { gt: now },
      attempts: { lt: challenge.maxAttempts },
    },
    data: { consumedAt: now },
  });
  if (consumed.count !== 1) return null;

  return {
    userId: challenge.userId,
    target: challenge.target,
    channel: challenge.channel,
    challengeId: challenge.id,
  };
}
