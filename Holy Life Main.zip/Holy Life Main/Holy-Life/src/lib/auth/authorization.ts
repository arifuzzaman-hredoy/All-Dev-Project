import { redirect } from "next/navigation";
import { authConfig } from "@/lib/auth/config";
import {
  getCurrentSession,
  hasPermission,
  hasGlobalPermission,
  hasVerifiedContact,
  isAdminUser,
  type AuthSession,
} from "@/lib/auth/session";

export async function requireAuthenticatedSession(
  returnTo = "/dashboard",
): Promise<AuthSession> {
  const session = await getCurrentSession();
  if (!session) redirect(`/login?returnTo=${encodeURIComponent(returnTo)}`);
  if (authConfig.requireVerifiedContact && !hasVerifiedContact(session.user))
    redirect("/verify");
  return session;
}

export async function requireAdminSession(
  returnTo = "/admin",
): Promise<AuthSession> {
  const session = await getCurrentSession();
  if (!session)
    redirect(`/admin-login?returnTo=${encodeURIComponent(returnTo)}`);
  if (!isAdminUser(session.user))
    redirect("/dashboard?error=admin-access-required");
  if (authConfig.requireVerifiedContact && !hasVerifiedContact(session.user)) {
    redirect(`/verify?returnTo=${encodeURIComponent(returnTo)}`);
  }
  return session;
}

export async function requireSuperAdminSession(
  returnTo = "/super-admin",
): Promise<AuthSession> {
  const session = await getCurrentSession();
  if (!session)
    redirect(`/super-admin?returnTo=${encodeURIComponent(returnTo)}`);
  if (!session.user.isSuperAdmin) {
    redirect(
      isAdminUser(session.user)
        ? "/admin?error=owner-access-required"
        : "/dashboard?error=owner-access-required",
    );
  }
  if (authConfig.requireVerifiedContact && !hasVerifiedContact(session.user)) {
    redirect("/verify?returnTo=%2Fsuper-admin");
  }
  return session;
}

export async function requirePermission(
  permissionKey: string,
  returnTo = "/admin",
): Promise<AuthSession> {
  const session = await requireAdminSession(returnTo);
  if (!hasPermission(session.user, permissionKey))
    redirect("/admin?error=permission-denied");
  return session;
}

export async function requireGlobalPermission(
  permissionKey: string,
  returnTo = "/admin",
): Promise<AuthSession> {
  const session = await requireAdminSession(returnTo);
  if (!hasGlobalPermission(session.user, permissionKey))
    redirect("/admin?error=global-scope-required");
  return session;
}

export function assertPermission(
  session: AuthSession,
  permissionKey: string,
): void {
  if (!hasPermission(session.user, permissionKey)) {
    throw new Error(`Permission denied: ${permissionKey}`);
  }
}
