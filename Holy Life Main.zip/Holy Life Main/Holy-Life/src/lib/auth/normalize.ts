export function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

export function normalizePhone(value: string): string {
  const compact = value.trim().replace(/[\s()-]/g, "");
  if (compact.startsWith("+880")) return `0${compact.slice(4)}`;
  if (compact.startsWith("880")) return `0${compact.slice(3)}`;
  return compact;
}

export function normalizeIdentifier(value: string): string {
  const trimmed = value.trim();
  return trimmed.includes("@")
    ? normalizeEmail(trimmed)
    : normalizePhone(trimmed);
}

export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 254;
}

export function isValidBangladeshPhone(value: string): boolean {
  return /^01[3-9]\d{8}$/.test(normalizePhone(value));
}

export function validatePassword(value: string): string | null {
  if (value.length < 6) return "Password must be at least 6 characters.";
  if (value.length > 128) return "Password must be 128 characters or fewer.";
  if (!/[a-z]/.test(value)) return "Password must contain a lowercase letter.";
  if (!/[A-Z]/.test(value)) return "Password must contain an uppercase letter.";
  if (!/\d/.test(value)) return "Password must contain a number.";
  return null;
}
