const integerFromEnv = (
  name: string,
  fallback: number,
  minimum = 1,
): number => {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isFinite(value) || value < minimum) {
    throw new Error(
      `${name} must be an integer greater than or equal to ${minimum}.`,
    );
  }
  return value;
};

export const authConfig = {
  cookieName: "holy_life_session",
  sessionDays: integerFromEnv("SESSION_DAYS", 14),
  maxActiveSessions: integerFromEnv("MAX_ACTIVE_SESSIONS", 8),
  loginMaxAttempts: integerFromEnv("LOGIN_MAX_ATTEMPTS", 5),
  loginWindowMinutes: integerFromEnv("LOGIN_WINDOW_MINUTES", 15),
  loginLockMinutes: integerFromEnv("LOGIN_LOCK_MINUTES", 15),
  verificationTtlMinutes: integerFromEnv("VERIFICATION_TTL_MINUTES", 15),
  verificationResendSeconds: integerFromEnv("VERIFICATION_RESEND_SECONDS", 60),
  passwordResetTtlMinutes: integerFromEnv("PASSWORD_RESET_TTL_MINUTES", 30),
  trustProxy: process.env.TRUST_PROXY === "true",
  requireVerifiedContact: process.env.AUTH_REQUIRE_VERIFIED_CONTACT !== "false",
  deliveryMode: process.env.AUTH_DELIVERY_MODE ?? "log",
  deliveryWebhookUrl: process.env.AUTH_DELIVERY_WEBHOOK_URL,
  deliveryWebhookSecret: process.env.AUTH_DELIVERY_WEBHOOK_SECRET,
  smtpHost: process.env.SMTP_HOST,
  smtpPort: integerFromEnv("SMTP_PORT", 587),
  smtpSecure: process.env.SMTP_SECURE === "true",
  smtpUser: process.env.SMTP_USER,
  smtpPassword: process.env.SMTP_PASSWORD,
  smtpFromName: process.env.SMTP_FROM_NAME ?? "Holy Life",
  smtpFromEmail: process.env.SMTP_FROM_EMAIL,
  smtpReplyTo: process.env.SMTP_REPLY_TO,
} as const;

export function appOrigin(): string {
  const value = process.env.APP_URL ?? "http://localhost:3000";
  try {
    return new URL(value).origin;
  } catch {
    throw new Error("APP_URL must be a valid absolute URL.");
  }
}
