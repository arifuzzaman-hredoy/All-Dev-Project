import { authConfig } from "@/lib/auth/config";
import { hashSensitiveValue } from "@/lib/auth/crypto";
import { db } from "@/lib/db";

export type ThrottleState = { locked: boolean; retryAfterSeconds: number };

export async function getLoginThrottle(
  identifier: string,
): Promise<ThrottleState> {
  const identifierHash = hashSensitiveValue(identifier);
  const record = await db.loginThrottle.findUnique({
    where: { identifierHash },
  });
  if (!record?.lockedUntil) return { locked: false, retryAfterSeconds: 0 };

  const remainingMs = record.lockedUntil.getTime() - Date.now();
  if (remainingMs <= 0) return { locked: false, retryAfterSeconds: 0 };
  return { locked: true, retryAfterSeconds: Math.ceil(remainingMs / 1000) };
}

export async function recordLoginFailure(
  identifier: string,
): Promise<{ locked: boolean }> {
  const identifierHash = hashSensitiveValue(identifier);
  const now = new Date();
  const windowMs = authConfig.loginWindowMinutes * 60_000;
  const lockMs = authConfig.loginLockMinutes * 60_000;

  return db.$transaction(async (tx) => {
    const existing = await tx.loginThrottle.findUnique({
      where: { identifierHash },
    });
    const insideWindow =
      existing &&
      now.getTime() - existing.windowStartedAt.getTime() <= windowMs;
    const nextCount = insideWindow ? existing.failureCount + 1 : 1;
    const locked = nextCount >= authConfig.loginMaxAttempts;

    await tx.loginThrottle.upsert({
      where: { identifierHash },
      update: {
        failureCount: nextCount,
        windowStartedAt: insideWindow ? existing.windowStartedAt : now,
        lastFailureAt: now,
        lockedUntil: locked ? new Date(now.getTime() + lockMs) : null,
      },
      create: {
        identifierHash,
        failureCount: nextCount,
        windowStartedAt: now,
        lastFailureAt: now,
        lockedUntil: locked ? new Date(now.getTime() + lockMs) : null,
      },
    });

    return { locked };
  });
}

export async function clearLoginThrottle(identifier: string): Promise<void> {
  await db.loginThrottle
    .delete({ where: { identifierHash: hashSensitiveValue(identifier) } })
    .catch(() => undefined);
}
