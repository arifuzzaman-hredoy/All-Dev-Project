import nodemailer from "nodemailer";
import { authConfig, appOrigin } from "@/lib/auth/config";

export type AuthDelivery = {
  channel: "EMAIL" | "PHONE";
  target: string;
  purpose: "EMAIL_VERIFY" | "PHONE_VERIFY" | "PASSWORD_RESET" | "ADMIN_INVITE";
  code: string;
  token: string;
};

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function emailContent(input: AuthDelivery, verificationUrl: string) {
  const copy =
    input.purpose === "PASSWORD_RESET"
      ? {
          subject: "Reset your Holy Life password",
          eyebrow: "Password recovery",
          title: "Reset your password",
          description:
            "Use the code below or the secure button to choose a new Holy Life password.",
          button: "Reset password",
        }
      : input.purpose === "ADMIN_INVITE"
        ? {
            subject: "Your Holy Life admin invitation",
            eyebrow: "Admin invitation",
            title: "You have been invited to Holy Life",
            description:
              "Use the secure button below to accept your invitation and set your password.",
            button: "Accept invitation",
          }
        : {
            subject: "Verify your Holy Life account",
            eyebrow: "Account verification",
            title: "Welcome to Holy Life",
            description:
              "Use the 6-digit code below or the secure button to verify your email address.",
            button: "Verify email",
          };

  const showCode = input.purpose !== "ADMIN_INVITE";
  const expiry =
    input.purpose === "PASSWORD_RESET"
      ? `${authConfig.passwordResetTtlMinutes} minutes`
      : `${authConfig.verificationTtlMinutes} minutes`;
  const safeUrl = escapeHtml(verificationUrl);
  const safeCode = escapeHtml(input.code);

  const html = `<!doctype html>
<html><body style="margin:0;background:#f3f7f6;font-family:Arial,sans-serif;color:#172624">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:28px 12px;background:#f3f7f6"><tr><td align="center">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:620px;background:#fff;border:1px solid #dfe9e6;border-radius:18px;overflow:hidden">
<tr><td style="padding:28px 32px;background:#13272b;color:#fff"><div style="font-size:22px;font-weight:700">Holy Life</div><div style="margin-top:5px;color:#bfe2d9;font-size:13px">Complete Healthcare, Shopping &amp; Learning Platform</div></td></tr>
<tr><td style="padding:34px 32px">
<div style="color:#16705d;font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase">${copy.eyebrow}</div>
<h1 style="margin:10px 0 12px;font-size:28px;line-height:1.25">${copy.title}</h1>
<p style="margin:0 0 24px;color:#526360;line-height:1.65">${copy.description}</p>
${showCode ? `<div style="margin:0 0 22px;padding:18px;text-align:center;background:#eef8f5;border-radius:12px"><div style="font-size:12px;color:#61736f;text-transform:uppercase;letter-spacing:.08em">Your 6-digit code</div><div style="margin-top:7px;font-size:32px;font-weight:800;letter-spacing:.22em;color:#143d35">${safeCode}</div></div>` : ""}
<a href="${safeUrl}" style="display:block;padding:14px 18px;background:#16705d;color:#fff;text-align:center;text-decoration:none;border-radius:10px;font-weight:700">${copy.button}</a>
<p style="margin:20px 0 0;color:#687874;font-size:13px;line-height:1.6">This secure request expires in ${expiry}. If you did not request this action, you can safely ignore this email.</p>
</td></tr>
<tr><td style="padding:20px 32px;border-top:1px solid #e4ecea;color:#71817e;font-size:12px;line-height:1.6">Holy Life · Rangpur, Bangladesh<br>Support: techtemlead@gmail.com · +8801790789691</td></tr>
</table></td></tr></table></body></html>`;

  const text = [
    "Holy Life",
    copy.title,
    "",
    copy.description,
    showCode ? `Verification code: ${input.code}` : "",
    `Secure link: ${verificationUrl}`,
    `Expires in ${expiry}.`,
    "",
    "Support: techtemlead@gmail.com | +8801790789691",
  ]
    .filter(Boolean)
    .join("\n");

  return { subject: copy.subject, html, text };
}

async function deliverBySmtp(
  input: AuthDelivery,
  verificationUrl: string,
): Promise<void> {
  if (input.channel !== "EMAIL") {
    throw new Error(
      "SMTP auth delivery supports email only. Configure an SMS provider for phone verification.",
    );
  }
  if (
    !authConfig.smtpHost ||
    !authConfig.smtpUser ||
    !authConfig.smtpPassword ||
    !authConfig.smtpFromEmail
  ) {
    throw new Error("SMTP auth delivery is missing required configuration.");
  }

  const transporter = nodemailer.createTransport({
    host: authConfig.smtpHost,
    port: authConfig.smtpPort,
    secure: authConfig.smtpSecure,
    requireTLS: !authConfig.smtpSecure,
    auth: {
      user: authConfig.smtpUser,
      pass: authConfig.smtpPassword,
    },
  });
  const content = emailContent(input, verificationUrl);
  const info = await transporter.sendMail({
    from: { name: authConfig.smtpFromName, address: authConfig.smtpFromEmail },
    to: input.target,
    replyTo: authConfig.smtpReplyTo || authConfig.smtpFromEmail,
    subject: content.subject,
    text: content.text,
    html: content.html,
  });

  if (
    !info.accepted
      .map(String)
      .some((address) => address.toLowerCase() === input.target.toLowerCase())
  ) {
    throw new Error(
      "SMTP provider did not accept the authentication email recipient.",
    );
  }
}

export async function deliverAuthChallenge(input: AuthDelivery): Promise<void> {
  const verificationUrl =
    input.purpose === "PASSWORD_RESET"
      ? `${appOrigin()}/reset-password?token=${encodeURIComponent(input.token)}`
      : input.purpose === "ADMIN_INVITE"
        ? `${appOrigin()}/admin-invitation?token=${encodeURIComponent(input.token)}`
        : `${appOrigin()}/verify?token=${encodeURIComponent(input.token)}`;

  if (authConfig.deliveryMode === "log") {
    const hostname = new URL(appOrigin()).hostname;
    if (
      hostname !== "localhost" &&
      hostname !== "127.0.0.1" &&
      hostname !== "::1"
    ) {
      throw new Error(
        "AUTH_DELIVERY_MODE=log is allowed only for localhost. Configure SMTP or webhook delivery before deployment.",
      );
    }
    console.info("[Holy Life auth delivery]", {
      channel: input.channel,
      target: input.target,
      purpose: input.purpose,
      code: input.code,
      url: verificationUrl,
    });
    return;
  }

  if (authConfig.deliveryMode === "smtp") {
    await deliverBySmtp(input, verificationUrl);
    return;
  }

  if (authConfig.deliveryMode === "webhook") {
    if (!authConfig.deliveryWebhookUrl)
      throw new Error(
        "AUTH_DELIVERY_WEBHOOK_URL is required for webhook delivery.",
      );
    const response = await fetch(authConfig.deliveryWebhookUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(authConfig.deliveryWebhookSecret
          ? { authorization: `Bearer ${authConfig.deliveryWebhookSecret}` }
          : {}),
      },
      body: JSON.stringify({ ...input, url: verificationUrl }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!response.ok)
      throw new Error(
        `Auth delivery webhook failed with status ${response.status}.`,
      );
    return;
  }

  throw new Error(
    "Authentication delivery is disabled. Configure AUTH_DELIVERY_MODE.",
  );
}
