import type { NextRequest } from "next/server";
import { appOrigin, authConfig } from "@/lib/auth/config";

export function assertSameOrigin(request: NextRequest): void {
  const fetchSite = request.headers.get("sec-fetch-site");
  if (fetchSite === "cross-site") {
    throw new Error("Cross-origin request rejected.");
  }

  const requestOrigin = new URL(request.url).origin;
  const configuredOrigin = appOrigin();
  const origin = request.headers.get("origin");
  if (origin && origin !== requestOrigin && origin !== configuredOrigin) {
    throw new Error("Cross-origin request rejected.");
  }

  if (!origin) {
    const referer = request.headers.get("referer");
    if (referer) {
      const refererOrigin = new URL(referer).origin;
      if (
        refererOrigin !== requestOrigin &&
        refererOrigin !== configuredOrigin
      ) {
        throw new Error("Cross-origin request rejected.");
      }
    }
  }
}

export function clientIp(request: NextRequest): string | null {
  if (!authConfig.trustProxy) return null;
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]?.trim() || null;
  return request.headers.get("x-real-ip");
}

export function userAgent(request: NextRequest): string | null {
  return request.headers.get("user-agent")?.slice(0, 512) ?? null;
}

export function deviceLabelFromUserAgent(value: string | null): string {
  if (!value) return "Unknown device";
  const browser = value.includes("Edg/")
    ? "Edge"
    : value.includes("Chrome/")
      ? "Chrome"
      : value.includes("Firefox/")
        ? "Firefox"
        : value.includes("Safari/")
          ? "Safari"
          : "Browser";
  const platform = value.includes("Android")
    ? "Android"
    : value.includes("iPhone") || value.includes("iPad")
      ? "iOS"
      : value.includes("Windows")
        ? "Windows"
        : value.includes("Mac OS")
          ? "macOS"
          : value.includes("Linux")
            ? "Linux"
            : "device";
  return `${browser} on ${platform}`;
}

export function safeReturnTo(
  value: FormDataEntryValue | string | null,
  fallback = "/dashboard",
): string {
  if (
    typeof value !== "string" ||
    !value.startsWith("/") ||
    value.startsWith("//")
  ) {
    return fallback;
  }

  try {
    const base = appOrigin();
    const parsed = new URL(value, base);
    if (parsed.origin !== base) return fallback;
    return `${parsed.pathname}${parsed.search}${parsed.hash}`;
  } catch {
    return fallback;
  }
}

function isPathWithin(path: string, root: string): boolean {
  return (
    path === root ||
    path.startsWith(`${root}/`) ||
    path.startsWith(`${root}?`) ||
    path.startsWith(`${root}#`)
  );
}

export function safeMemberReturnTo(
  value: FormDataEntryValue | string | null,
  fallback = "/dashboard",
): string {
  const path = safeReturnTo(value, fallback);
  if (
    isPathWithin(path, "/admin") ||
    isPathWithin(path, "/admin-login") ||
    isPathWithin(path, "/super-admin")
  ) {
    return fallback;
  }
  return path;
}

export function safeAdminReturnTo(
  value: FormDataEntryValue | string | null,
  fallback = "/admin",
): string {
  const path = safeReturnTo(value, fallback);
  if (isPathWithin(path, "/admin-login")) return fallback;
  return isPathWithin(path, "/admin") ? path : fallback;
}

export async function readForm(request: NextRequest): Promise<FormData> {
  const contentType = request.headers.get("content-type") ?? "";
  if (
    !contentType.includes("application/x-www-form-urlencoded") &&
    !contentType.includes("multipart/form-data")
  ) {
    throw new Error("Unsupported form content type.");
  }
  return request.formData();
}
