import type {
  AuditAction,
  DepartmentCode,
  Prisma,
} from "@/generated/prisma/client";
import { db } from "@/lib/db";

export async function writeAuditLog(input: {
  actorId?: string | null;
  action: AuditAction;
  department?: DepartmentCode | null;
  targetType: string;
  targetId?: string | null;
  metadata?: Prisma.InputJsonValue;
  ipAddress?: string | null;
  userAgent?: string | null;
}): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        actorId: input.actorId ?? null,
        action: input.action,
        department: input.department ?? null,
        targetType: input.targetType,
        targetId: input.targetId ?? null,
        metadata: input.metadata,
        ipAddress: input.ipAddress ?? null,
        userAgent: input.userAgent ?? null,
      },
    });
  } catch (error) {
    console.error("Failed to write audit log", error);
  }
}
