import { cookies } from "next/headers";
import type { NextResponse } from "next/server";
import { appOrigin, authConfig } from "@/lib/auth/config";
import { createOpaqueToken, hashOpaqueToken } from "@/lib/auth/crypto";
import { db } from "@/lib/db";

export type AuthenticatedUser = {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  status: "INVITED" | "ACTIVE" | "SUSPENDED" | "ARCHIVED";
  isSuperAdmin: boolean;
  emailVerifiedAt: Date | null;
  phoneVerifiedAt: Date | null;
  roles: Array<{
    code: string;
    name: string;
    isAdminRole: boolean;
    isMasterAdmin: boolean;
    status: "ACTIVE" | "ARCHIVED";
    dataScope: "OWN" | "ASSIGNED" | "DEPARTMENT" | "BRANCH" | "ALL";
    permissions: string[];
  }>;
};

export type AuthSession = {
  id: string;
  user: AuthenticatedUser;
  expiresAt: Date;
  currentTokenHash: string;
};

const userInclude = {
  roles: {
    where: { role: { status: "ACTIVE" } },
    include: {
      role: {
        include: {
          permissions: {
            where: { allowed: true },
            include: { permission: true },
          },
        },
      },
    },
  },
} as const;

function mapUser(
  user: Awaited<ReturnType<typeof loadUserById>>,
): AuthenticatedUser | null {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    status: user.status,
    isSuperAdmin: user.isSuperAdmin,
    emailVerifiedAt: user.emailVerifiedAt,
    phoneVerifiedAt: user.phoneVerifiedAt,
    roles: user.roles.map(({ role, dataScope }) => ({
      code: role.code,
      name: role.name,
      isAdminRole: role.isAdminRole,
      isMasterAdmin: role.isMasterAdmin,
      status: role.status,
      dataScope,
      permissions: role.permissions.map(({ permission }) => permission.key),
    })),
  };
}

async function loadUserById(userId: string) {
  return db.user.findUnique({ where: { id: userId }, include: userInclude });
}

export function hasVerifiedContact(user: AuthenticatedUser): boolean {
  return Boolean(user.emailVerifiedAt || user.phoneVerifiedAt);
}

export function isAdminUser(user: AuthenticatedUser): boolean {
  return user.isSuperAdmin || user.roles.some((role) => role.isAdminRole);
}

export function hasPermission(
  user: AuthenticatedUser,
  permissionKey: string,
): boolean {
  if (user.isSuperAdmin) return true;
  return user.roles.some((role) => role.permissions.includes(permissionKey));
}

export function hasGlobalPermission(
  user: AuthenticatedUser,
  permissionKey: string,
): boolean {
  if (user.isSuperAdmin) return true;
  return user.roles.some(
    (role) =>
      role.dataScope === "ALL" && role.permissions.includes(permissionKey),
  );
}

export async function createSession(input: {
  userId: string;
  sessionVersion: number;
  ipAddress?: string | null;
  userAgent?: string | null;
  deviceLabel?: string | null;
}): Promise<{ rawToken: string; expiresAt: Date; sessionId: string }> {
  const now = new Date();
  const expiresAt = new Date(
    now.getTime() + authConfig.sessionDays * 86_400_000,
  );
  const rawToken = createOpaqueToken();
  const tokenHash = hashOpaqueToken(rawToken);

  const activeSessions = await db.session.findMany({
    where: { userId: input.userId, revokedAt: null, expiresAt: { gt: now } },
    orderBy: { lastSeenAt: "asc" },
    select: { id: true },
  });

  const overflow = activeSessions.length - authConfig.maxActiveSessions + 1;
  if (overflow > 0) {
    await db.session.updateMany({
      where: {
        id: {
          in: activeSessions.slice(0, overflow).map((session) => session.id),
        },
      },
      data: { revokedAt: now },
    });
  }

  const session = await db.session.create({
    data: {
      userId: input.userId,
      tokenHash,
      sessionVersion: input.sessionVersion,
      expiresAt,
      ipAddress: input.ipAddress ?? null,
      userAgent: input.userAgent ?? null,
      deviceLabel: input.deviceLabel ?? null,
    },
    select: { id: true },
  });

  return { rawToken, expiresAt, sessionId: session.id };
}

export function setSessionCookie(
  response: NextResponse,
  rawToken: string,
  expiresAt: Date,
): void {
  response.cookies.set(authConfig.cookieName, rawToken, {
    httpOnly: true,
    secure: new URL(appOrigin()).protocol === "https:",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
    priority: "high",
  });
}

export function clearSessionCookie(response: NextResponse): void {
  response.cookies.set(authConfig.cookieName, "", {
    httpOnly: true,
    secure: new URL(appOrigin()).protocol === "https:",
    sameSite: "lax",
    path: "/",
    expires: new Date(0),
  });
}

export async function getCurrentSession(): Promise<AuthSession | null> {
  const cookieStore = await cookies();
  const rawToken = cookieStore.get(authConfig.cookieName)?.value;
  if (!rawToken) return null;

  const tokenHash = hashOpaqueToken(rawToken);
  const now = new Date();
  const session = await db.session.findUnique({
    where: { tokenHash },
    include: { user: { include: userInclude } },
  });

  if (
    !session ||
    session.revokedAt ||
    session.expiresAt <= now ||
    session.user.status !== "ACTIVE" ||
    session.sessionVersion !== session.user.sessionVersion
  ) {
    if (session && !session.revokedAt) {
      await db.session
        .update({ where: { id: session.id }, data: { revokedAt: now } })
        .catch(() => undefined);
    }
    return null;
  }

  if (now.getTime() - session.lastSeenAt.getTime() > 5 * 60_000) {
    await db.session
      .update({ where: { id: session.id }, data: { lastSeenAt: now } })
      .catch(() => undefined);
  }

  const user = mapUser(session.user);
  if (!user) return null;
  return {
    id: session.id,
    user,
    expiresAt: session.expiresAt,
    currentTokenHash: tokenHash,
  };
}

export async function revokeSessionByToken(
  rawToken: string,
): Promise<string | null> {
  const session = await db.session.findUnique({
    where: { tokenHash: hashOpaqueToken(rawToken) },
    select: { id: true },
  });
  if (!session) return null;
  await db.session.updateMany({
    where: { id: session.id, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return session.id;
}

export async function revokeAllUserSessions(userId: string): Promise<void> {
  await db.$transaction([
    db.user.update({
      where: { id: userId },
      data: { sessionVersion: { increment: 1 } },
    }),
    db.session.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    }),
  ]);
}
