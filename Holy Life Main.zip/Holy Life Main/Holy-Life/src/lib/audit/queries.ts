import type { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { analyticsDateWhere } from "@/lib/analytics/validation";
import type { AuditFilters } from "@/lib/audit/validation";

function auditWhere(filters: AuditFilters): Prisma.AuditLogWhereInput {
  const createdAt = analyticsDateWhere(filters.range);
  const search = filters.search;

  return {
    ...(createdAt ? { createdAt } : {}),
    ...(filters.action ? { action: filters.action } : {}),
    ...(filters.department ? { department: filters.department } : {}),
    ...(search
      ? {
          OR: [
            { targetType: { contains: search, mode: "insensitive" } },
            { targetId: { contains: search, mode: "insensitive" } },
            {
              actor: {
                is: { name: { contains: search, mode: "insensitive" } },
              },
            },
            {
              actor: {
                is: { email: { contains: search, mode: "insensitive" } },
              },
            },
          ],
        }
      : {}),
  };
}

export async function auditSummary(filters: AuditFilters) {
  const where = auditWhere(filters);
  const [total, sensitiveViews, loginEvents, permissionChanges] =
    await Promise.all([
      db.auditLog.count({ where }),
      db.auditLog.count({
        where: { AND: [where, { action: "VIEW_SENSITIVE_DATA" }] },
      }),
      db.auditLog.count({
        where: {
          AND: [
            where,
            { action: { in: ["LOGIN", "LOGOUT", "ACCOUNT_LOCKED"] } },
          ],
        },
      }),
      db.auditLog.count({
        where: {
          AND: [
            where,
            {
              action: {
                in: ["PERMISSION_CHANGE", "ROLE_ASSIGN", "ROLE_CHANGE"],
              },
            },
          ],
        },
      }),
    ]);

  return { total, sensitiveViews, loginEvents, permissionChanges };
}

export async function listAuditEvents(filters: AuditFilters, take = 200) {
  return db.auditLog.findMany({
    where: auditWhere(filters),
    include: {
      actor: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: Math.min(Math.max(1, take), 1000),
  });
}
