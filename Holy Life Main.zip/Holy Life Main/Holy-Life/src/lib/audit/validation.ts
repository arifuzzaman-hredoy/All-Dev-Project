import type { AuditAction, DepartmentCode } from "@/generated/prisma/client";
import {
  analyticsRange,
  type AnalyticsRange,
} from "@/lib/analytics/validation";

export const AUDIT_ACTIONS = [
  "CREATE",
  "UPDATE",
  "DELETE",
  "LOGIN",
  "LOGOUT",
  "REGISTER",
  "VERIFY",
  "PASSWORD_CHANGE",
  "SESSION_REVOKE",
  "STATUS_CHANGE",
  "PERMISSION_CHANGE",
  "ROLE_ASSIGN",
  "ROLE_CHANGE",
  "INVITE",
  "ARCHIVE",
  "VIEW_SENSITIVE_DATA",
  "EXPORT",
  "ACCOUNT_LOCKED",
] as const satisfies readonly AuditAction[];

export const AUDIT_DEPARTMENTS = [
  "HEALTHCARE",
  "COMMERCE",
  "LEARNING",
  "WEBSITE",
  "SYSTEM",
] as const satisfies readonly DepartmentCode[];

export type AuditFilters = {
  range: AnalyticsRange;
  action: AuditAction | null;
  department: DepartmentCode | null;
  search: string | null;
};

function optionalEnum<T extends string>(
  value: string | undefined,
  values: readonly T[],
  field: string,
): T | null {
  if (!value) return null;
  if (!values.includes(value as T))
    throw new Error(`${field} filter is invalid.`);
  return value as T;
}

export function auditFilters(input: {
  from?: string;
  to?: string;
  action?: string;
  department?: string;
  search?: string;
}): AuditFilters {
  const search = input.search?.trim() || null;
  if (search && search.length > 120)
    throw new Error("Audit search cannot exceed 120 characters.");

  return {
    range: analyticsRange(input.from, input.to),
    action: optionalEnum(input.action, AUDIT_ACTIONS, "Audit action"),
    department: optionalEnum(input.department, AUDIT_DEPARTMENTS, "Department"),
    search,
  };
}
