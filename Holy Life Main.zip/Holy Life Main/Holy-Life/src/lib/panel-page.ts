export function humanizeSegment(segment: string): string {
  return segment
    .split("-")
    .filter(Boolean)
    .map((word) => `${word.charAt(0).toUpperCase()}${word.slice(1)}`)
    .join(" ");
}

export function pageTitleFromSegments(segments: string[]): string {
  return humanizeSegment(segments.at(-1) ?? "Overview");
}

export function breadcrumbsFromSegments(
  rootLabel: string,
  rootHref: string,
  segments: string[],
): Array<{ label: string; href?: string }> {
  const breadcrumbs: Array<{ label: string; href?: string }> = [
    { label: rootLabel, href: rootHref },
  ];

  segments.forEach((segment, index) => {
    const isLast = index === segments.length - 1;
    breadcrumbs.push({
      label: humanizeSegment(segment),
      href: isLast
        ? undefined
        : `${rootHref}/${segments.slice(0, index + 1).join("/")}`,
    });
  });

  return breadcrumbs;
}
