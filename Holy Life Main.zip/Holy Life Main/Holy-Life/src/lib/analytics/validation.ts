export type AnalyticsRange = {
  from: Date | null;
  to: Date | null;
};

function parseCalendarDate(value: string, endOfDay: boolean): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new Error("Analytics date must use YYYY-MM-DD.");
  }

  const [year, month, day] = value.split("-").map(Number);
  const probe = new Date(Date.UTC(year, month - 1, day));

  if (
    probe.getUTCFullYear() !== year ||
    probe.getUTCMonth() !== month - 1 ||
    probe.getUTCDate() !== day
  ) {
    throw new Error("Analytics date is invalid.");
  }

  return new Date(
    `${value}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}+06:00`,
  );
}

export function analyticsRange(from?: string, to?: string): AnalyticsRange {
  const parsed = {
    from: from ? parseCalendarDate(from, false) : null,
    to: to ? parseCalendarDate(to, true) : null,
  };

  if (parsed.from && parsed.to && parsed.from > parsed.to) {
    throw new Error("Analytics start date cannot be after end date.");
  }

  const maxRangeMs = 366 * 24 * 60 * 60 * 1000;
  if (
    parsed.from &&
    parsed.to &&
    parsed.to.getTime() - parsed.from.getTime() > maxRangeMs
  ) {
    throw new Error("Analytics range cannot exceed 366 days.");
  }

  return parsed;
}

export function analyticsDateWhere(
  range: AnalyticsRange,
): { gte?: Date; lte?: Date } | undefined {
  if (!range.from && !range.to) return undefined;
  return {
    ...(range.from ? { gte: range.from } : {}),
    ...(range.to ? { lte: range.to } : {}),
  };
}
