import type { PaymentDomain, Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import type { AnalyticsRange } from "@/lib/analytics/validation";
import { analyticsDateWhere } from "@/lib/analytics/validation";

async function verifiedDomainNet(
  domain: PaymentDomain,
  range: AnalyticsRange,
): Promise<number> {
  const createdAt = analyticsDateWhere(range);
  const [payments, refunds] = await Promise.all([
    db.paymentTransaction.aggregate({
      where: {
        status: "VERIFIED",
        type: "PAYMENT",
        ...(createdAt ? { createdAt } : {}),
        account: { is: { domain } },
      },
      _sum: { amount: true },
    }),
    db.paymentTransaction.aggregate({
      where: {
        status: "VERIFIED",
        type: "REFUND",
        ...(createdAt ? { createdAt } : {}),
        account: { is: { domain } },
      },
      _sum: { amount: true },
    }),
  ]);

  return Math.max(
    0,
    Number(payments._sum.amount ?? 0) - Number(refunds._sum.amount ?? 0),
  );
}

export async function platformAnalytics(range: AnalyticsRange) {
  const createdAt = analyticsDateWhere(range);
  const appointmentDate = createdAt;
  const enrolledAt = createdAt;

  const [
    users,
    patients,
    appointments,
    completedAppointments,
    noShows,
    signedPrescriptions,
    orders,
    deliveredOrders,
    enrollments,
    completions,
    certificates,
    auditEvents,
    sensitiveViews,
    healthcareRevenue,
    commerceRevenue,
    learningRevenue,
    topProductsRaw,
    topCoursesRaw,
    topDoctorsRaw,
  ] = await Promise.all([
    db.user.count({ where: createdAt ? { createdAt } : undefined }),
    db.patientProfile.count({ where: createdAt ? { createdAt } : undefined }),
    db.appointment.count({
      where: appointmentDate ? { appointmentDate } : undefined,
    }),
    db.appointment.count({
      where: {
        status: "COMPLETED",
        ...(appointmentDate ? { appointmentDate } : {}),
      },
    }),
    db.appointment.count({
      where: {
        status: "NO_SHOW",
        ...(appointmentDate ? { appointmentDate } : {}),
      },
    }),
    db.prescription.count({
      where: {
        status: "SIGNED",
        ...(createdAt ? { signedAt: createdAt } : {}),
      },
    }),
    db.commerceOrder.count({ where: createdAt ? { createdAt } : undefined }),
    db.commerceOrder.count({
      where: {
        status: "DELIVERED",
        ...(createdAt ? { createdAt } : {}),
      },
    }),
    db.courseEnrollment.count({
      where: enrolledAt ? { enrolledAt } : undefined,
    }),
    db.courseEnrollment.count({
      where: {
        status: "COMPLETED",
        ...(createdAt ? { completedAt: createdAt } : {}),
      },
    }),
    db.courseCertificate.count({
      where: createdAt ? { issuedAt: createdAt } : undefined,
    }),
    db.auditLog.count({ where: createdAt ? { createdAt } : undefined }),
    db.auditLog.count({
      where: {
        action: "VIEW_SENSITIVE_DATA",
        ...(createdAt ? { createdAt } : {}),
      },
    }),
    verifiedDomainNet("HEALTHCARE", range),
    verifiedDomainNet("COMMERCE", range),
    verifiedDomainNet("LEARNING", range),
    db.commerceOrderItem.groupBy({
      by: ["productId", "productName"],
      where: {
        order: {
          is: {
            status: { notIn: ["CANCELLED", "REFUNDED"] },
            ...(createdAt ? { createdAt } : {}),
          },
        },
      },
      _sum: { quantity: true, lineTotal: true },
      orderBy: { _sum: { lineTotal: "desc" } },
      take: 5,
    }),
    db.courseEnrollment.groupBy({
      by: ["courseId"],
      where: {
        status: { not: "CANCELLED" },
        ...(enrolledAt ? { enrolledAt } : {}),
      },
      _count: { _all: true },
      orderBy: { _count: { courseId: "desc" } },
      take: 5,
    }),
    db.appointment.groupBy({
      by: ["doctorId"],
      where: appointmentDate ? { appointmentDate } : undefined,
      _count: { _all: true },
      orderBy: { _count: { doctorId: "desc" } },
      take: 5,
    }),
  ]);

  const [courseNames, doctorNames] = await Promise.all([
    db.course.findMany({
      where: { id: { in: topCoursesRaw.map((item) => item.courseId) } },
      select: { id: true, title: true },
    }),
    db.doctorProfile.findMany({
      where: { id: { in: topDoctorsRaw.map((item) => item.doctorId) } },
      select: { id: true, name: true, specialization: true },
    }),
  ]);

  const courseNameMap = new Map(
    courseNames.map((item) => [item.id, item.title]),
  );
  const doctorNameMap = new Map(doctorNames.map((item) => [item.id, item]));

  const totalRevenue = healthcareRevenue + commerceRevenue + learningRevenue;

  return {
    users,
    patients,
    appointments,
    completedAppointments,
    noShows,
    signedPrescriptions,
    orders,
    deliveredOrders,
    enrollments,
    completions,
    certificates,
    auditEvents,
    sensitiveViews,
    revenue: {
      total: totalRevenue,
      healthcare: healthcareRevenue,
      commerce: commerceRevenue,
      learning: learningRevenue,
    },
    topProducts: topProductsRaw.map((item) => ({
      id: item.productId,
      name: item.productName,
      quantity: item._sum.quantity ?? 0,
      revenue: Number(item._sum.lineTotal ?? 0),
    })),
    topCourses: topCoursesRaw.map((item) => ({
      id: item.courseId,
      title: courseNameMap.get(item.courseId) ?? "Unknown course",
      enrollments: item._count._all,
    })),
    topDoctors: topDoctorsRaw.map((item) => ({
      id: item.doctorId,
      name: doctorNameMap.get(item.doctorId)?.name ?? "Unknown doctor",
      specialization: doctorNameMap.get(item.doctorId)?.specialization ?? "",
      appointments: item._count._all,
    })),
  };
}

export type PlatformAnalytics = Awaited<ReturnType<typeof platformAnalytics>>;
