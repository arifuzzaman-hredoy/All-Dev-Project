import type { LaunchAcceptanceState } from "@/lib/launch/validation";
import { LAUNCH_ACCEPTANCE_GATES } from "@/lib/launch/validation";

export type LaunchCheckStatus = "PASS" | "WARN" | "BLOCK";

export type LaunchCheck = {
  key: string;
  label: string;
  detail: string;
  status: LaunchCheckStatus;
  group: "CONFIGURATION" | "CONTENT" | "OPERATIONS";
};

export function readinessSummary(
  checks: readonly LaunchCheck[],
  acceptance: LaunchAcceptanceState,
) {
  const blockers = checks.filter((check) => check.status === "BLOCK").length;
  const warnings = checks.filter((check) => check.status === "WARN").length;
  const accepted = LAUNCH_ACCEPTANCE_GATES.filter(
    (gate) => acceptance[gate.key].status === "PASSED",
  ).length;
  const manualPending = LAUNCH_ACCEPTANCE_GATES.length - accepted;

  return {
    blockers,
    warnings,
    accepted,
    manualPending,
    ready: blockers === 0 && manualPending === 0,
  };
}

export function ageInHours(
  date: Date | null | undefined,
  now = new Date(),
): number | null {
  if (!date) return null;
  return Math.max(0, (now.getTime() - date.getTime()) / 3_600_000);
}

export function evidenceCheck(input: {
  key: string;
  label: string;
  date: Date | null | undefined;
  maxAgeHours: number;
  missingDetail: string;
  staleDetail: (hours: number) => string;
}): LaunchCheck {
  const age = ageInHours(input.date);
  if (age == null) {
    return {
      key: input.key,
      label: input.label,
      detail: input.missingDetail,
      status: "BLOCK",
      group: "OPERATIONS",
    };
  }
  if (age > input.maxAgeHours) {
    return {
      key: input.key,
      label: input.label,
      detail: input.staleDetail(Math.floor(age)),
      status: "BLOCK",
      group: "OPERATIONS",
    };
  }
  return {
    key: input.key,
    label: input.label,
    detail: `Verified ${Math.max(0, Math.floor(age))}h ago.`,
    status: "PASS",
    group: "OPERATIONS",
  };
}
