export class LaunchAcceptanceError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LaunchAcceptanceError";
  }
}

export const LAUNCH_ACCEPTANCE_GATES = [
  {
    key: "paymentSandbox",
    label: "Phase 11 payment sandbox acceptance",
    description:
      "Complete a real SSLCOMMERZ sandbox checkout, IPN validation, replay check, and ledger verification.",
  },
  {
    key: "clinicalBrowser",
    label: "Phase 12 clinical browser acceptance",
    description:
      "Verify clinical profile, vitals, prescription sign/lock, revision, patient visibility, and access isolation.",
  },
  {
    key: "insightsBrowser",
    label: "Phase 13 analytics/audit/backup browser acceptance",
    description:
      "Verify analytics, audit filters/exports, backup assurance visibility, and permission boundaries.",
  },
  {
    key: "publicContent",
    label: "Public website content acceptance",
    description:
      "Confirm branding, contact details, doctors, courses, shop content, mobile layout, and public navigation.",
  },
  {
    key: "legalReview",
    label: "Privacy and terms legal review",
    description:
      "Qualified counsel or the client-approved legal owner has reviewed the production privacy policy and terms.",
  },
  {
    key: "rollbackReview",
    label: "Rollback readiness review",
    description:
      "Confirm current and previous immutable app/migrator images are retained and rollback procedure is understood.",
  },
  {
    key: "ownerSignoff",
    label: "Primary owner launch sign-off",
    description:
      "The Primary Super Admin confirms the remaining launch checklist has been reviewed.",
  },
] as const;

export type LaunchAcceptanceKey =
  (typeof LAUNCH_ACCEPTANCE_GATES)[number]["key"];
export type LaunchAcceptanceStatus = "PENDING" | "PASSED";

export type LaunchAcceptanceEntry = {
  status: LaunchAcceptanceStatus;
  updatedAt: string | null;
  updatedBy: string | null;
  note: string | null;
};

export type LaunchAcceptanceState = Record<
  LaunchAcceptanceKey,
  LaunchAcceptanceEntry
>;

const emptyEntry = (): LaunchAcceptanceEntry => ({
  status: "PENDING",
  updatedAt: null,
  updatedBy: null,
  note: null,
});

function recordValue(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function cleanText(value: unknown, maxLength: number): string | null {
  if (typeof value !== "string") return null;
  const result = value.trim();
  if (!result) return null;
  return result.slice(0, maxLength);
}

export function parseLaunchAcceptance(value: unknown): LaunchAcceptanceState {
  const source = recordValue(value);
  const state = {} as LaunchAcceptanceState;

  for (const gate of LAUNCH_ACCEPTANCE_GATES) {
    const entry = recordValue(source?.[gate.key]);
    const status: LaunchAcceptanceStatus =
      entry?.status === "PASSED" ? "PASSED" : "PENDING";
    state[gate.key] = {
      status,
      updatedAt: cleanText(entry?.updatedAt, 64),
      updatedBy: cleanText(entry?.updatedBy, 120),
      note: cleanText(entry?.note, 500),
    };
  }

  return state;
}

export function launchAcceptanceKey(value: unknown): LaunchAcceptanceKey {
  if (typeof value !== "string")
    throw new LaunchAcceptanceError("Launch acceptance gate is required.");
  const key = value.trim() as LaunchAcceptanceKey;
  if (!LAUNCH_ACCEPTANCE_GATES.some((gate) => gate.key === key)) {
    throw new LaunchAcceptanceError("Launch acceptance gate is invalid.");
  }
  return key;
}

export function launchAcceptanceStatus(value: unknown): LaunchAcceptanceStatus {
  if (value === "PASSED" || value === "PENDING") return value;
  throw new LaunchAcceptanceError(
    "Launch acceptance status must be PASSED or PENDING.",
  );
}

export function launchAcceptanceNote(value: unknown): string | null {
  if (value == null || value === "") return null;
  if (typeof value !== "string")
    throw new LaunchAcceptanceError("Launch acceptance note must be text.");
  const result = value.trim();
  if (!result) return null;
  if (result.length > 500)
    throw new LaunchAcceptanceError(
      "Launch acceptance note cannot exceed 500 characters.",
    );
  return result;
}

export function withLaunchAcceptanceUpdate(
  current: LaunchAcceptanceState,
  input: {
    key: LaunchAcceptanceKey;
    status: LaunchAcceptanceStatus;
    updatedAt: string;
    updatedBy: string;
    note: string | null;
  },
): LaunchAcceptanceState {
  return {
    ...current,
    [input.key]: {
      status: input.status,
      updatedAt: input.updatedAt,
      updatedBy: input.updatedBy,
      note: input.note,
    },
  };
}

export function acceptedLaunchGateCount(state: LaunchAcceptanceState): number {
  return LAUNCH_ACCEPTANCE_GATES.filter(
    (gate) => state[gate.key].status === "PASSED",
  ).length;
}
