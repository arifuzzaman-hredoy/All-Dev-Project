import { authConfig, appOrigin } from "@/lib/auth/config";
import { getWebsiteBranding } from "@/lib/cms/queries";
import { db } from "@/lib/db";
import {
  LAUNCH_ACCEPTANCE_GATES,
  parseLaunchAcceptance,
} from "@/lib/launch/validation";
import {
  evidenceCheck,
  readinessSummary,
  type LaunchCheck,
} from "@/lib/launch/status";
import { messagingConfig } from "@/lib/messaging/config";
import { operationsConfig } from "@/lib/operations/config";
import { operationsSnapshot } from "@/lib/operations/queries";
import {
  paymentGatewayAvailable,
  paymentGatewayConfig,
} from "@/lib/payments/gateway/config";

const LEGAL_PLACEHOLDER =
  "must be reviewed by qualified legal counsel before client production launch";

function pass(
  key: string,
  label: string,
  detail: string,
  group: LaunchCheck["group"],
): LaunchCheck {
  return { key, label, detail, status: "PASS", group };
}

function block(
  key: string,
  label: string,
  detail: string,
  group: LaunchCheck["group"],
): LaunchCheck {
  return { key, label, detail, status: "BLOCK", group };
}

function warn(
  key: string,
  label: string,
  detail: string,
  group: LaunchCheck["group"],
): LaunchCheck {
  return { key, label, detail, status: "WARN", group };
}

export async function launchReadinessSnapshot() {
  const [
    branding,
    legalPages,
    acceptanceSetting,
    operations,
    gatewayReviewRequired,
  ] = await Promise.all([
    getWebsiteBranding(),
    db.websitePage.findMany({
      where: { slug: { in: ["privacy", "terms"] }, status: "PUBLISHED" },
      include: {
        sections: {
          where: { isEnabled: true },
          select: { content: true },
        },
      },
    }),
    db.systemSetting.findUnique({
      where: { key: "launch.acceptance" },
      select: { value: true },
    }),
    operationsSnapshot(),
    db.paymentGatewayAttempt.count({
      where: { status: "REVIEW_REQUIRED" },
    }),
  ]);

  const acceptance = parseLaunchAcceptance(acceptanceSetting?.value);
  const checks: LaunchCheck[] = [];

  const origin = appOrigin();
  const originUrl = new URL(origin);
  checks.push(
    originUrl.protocol === "https:"
      ? pass(
          "https-origin",
          "Production HTTPS origin",
          `${originUrl.origin} uses HTTPS.`,
          "CONFIGURATION",
        )
      : block(
          "https-origin",
          "Production HTTPS origin",
          "APP_URL must use HTTPS before launch.",
          "CONFIGURATION",
        ),
  );

  checks.push(
    authConfig.requireVerifiedContact
      ? pass(
          "verified-contact",
          "Verified contact enforcement",
          "Member contact verification is required.",
          "CONFIGURATION",
        )
      : block(
          "verified-contact",
          "Verified contact enforcement",
          "AUTH_REQUIRE_VERIFIED_CONTACT must be enabled.",
          "CONFIGURATION",
        ),
  );

  const authDeliveryReady =
    (authConfig.deliveryMode === "webhook" &&
      Boolean(authConfig.deliveryWebhookUrl)) ||
    (authConfig.deliveryMode === "smtp" &&
      Boolean(authConfig.smtpHost) &&
      Boolean(authConfig.smtpUser) &&
      Boolean(authConfig.smtpPassword) &&
      Boolean(authConfig.smtpFromEmail));
  checks.push(
    authDeliveryReady
      ? pass(
          "auth-delivery",
          "Authentication delivery",
          "Verification and reset delivery is configured.",
          "CONFIGURATION",
        )
      : block(
          "auth-delivery",
          "Authentication delivery",
          "Configure SMTP or webhook verification/reset delivery before launch.",
          "CONFIGURATION",
        ),
  );

  if (
    paymentGatewayConfig.mode !== "sslcommerz" ||
    !paymentGatewayAvailable()
  ) {
    checks.push(
      block(
        "payment-gateway",
        "Online payment gateway",
        "SSLCOMMERZ is disabled or credentials are not configured.",
        "CONFIGURATION",
      ),
    );
  } else if (paymentGatewayConfig.sslCommerzEnvironment !== "live") {
    checks.push(
      block(
        "payment-gateway",
        "Online payment gateway",
        "SSLCOMMERZ is configured but still uses sandbox mode.",
        "CONFIGURATION",
      ),
    );
  } else {
    checks.push(
      pass(
        "payment-gateway",
        "Online payment gateway",
        "SSLCOMMERZ live mode is configured.",
        "CONFIGURATION",
      ),
    );
  }

  checks.push(
    messagingConfig.mode === "webhook" && Boolean(messagingConfig.webhookUrl)
      ? pass(
          "external-messaging",
          "External messaging",
          "Provider webhook messaging is configured.",
          "CONFIGURATION",
        )
      : warn(
          "external-messaging",
          "External messaging",
          "External email/SMS/WhatsApp automation remains disabled.",
          "CONFIGURATION",
        ),
  );

  checks.push(
    operationsConfig.reportSecret
      ? pass(
          "operations-telemetry",
          "Operations telemetry",
          "Operations reporting secret is configured.",
          "CONFIGURATION",
        )
      : block(
          "operations-telemetry",
          "Operations telemetry",
          "OPERATIONS_REPORT_SECRET is not configured.",
          "CONFIGURATION",
        ),
  );

  const brandingLooksReal =
    Boolean(branding.supportEmail) &&
    !branding.supportEmail.toLowerCase().endsWith(".example") &&
    !branding.supportEmail.toLowerCase().includes("@holylife.example") &&
    !/[xX]{3,}/.test(branding.supportPhone);

  checks.push(
    brandingLooksReal
      ? pass(
          "branding",
          "Production branding & contact",
          "Public support contact details no longer use starter placeholders.",
          "CONTENT",
        )
      : block(
          "branding",
          "Production branding & contact",
          "Replace starter support email/phone placeholders in Website settings.",
          "CONTENT",
        ),
  );

  const legalText = JSON.stringify(legalPages).toLowerCase();
  const hasPrivacy = legalPages.some((page) => page.slug === "privacy");
  const hasTerms = legalPages.some((page) => page.slug === "terms");
  const legalReady =
    hasPrivacy && hasTerms && !legalText.includes(LEGAL_PLACEHOLDER);

  checks.push(
    legalReady
      ? pass(
          "legal-content",
          "Published privacy & terms",
          "Published legal pages no longer contain the launch placeholder.",
          "CONTENT",
        )
      : block(
          "legal-content",
          "Published privacy & terms",
          "Publish reviewed privacy/terms and remove the starter legal-review placeholder.",
          "CONTENT",
        ),
  );

  checks.push(
    evidenceCheck({
      key: "backup-evidence",
      label: "Encrypted off-site backup evidence",
      date: operations.latestBackup?.finishedAt,
      maxAgeHours: 36,
      missingDetail:
        "No successful off-site backup telemetry is available. Local-only mode is not launch-ready.",
      staleDetail: (hours) =>
        `Latest successful off-site backup is stale (${hours}h).`,
    }),
  );

  checks.push(
    evidenceCheck({
      key: "restore-evidence",
      label: "Restore verification evidence",
      date: operations.latestRestoreTest?.finishedAt,
      maxAgeHours: 216,
      missingDetail:
        "No successful isolated restore-test telemetry is available.",
      staleDetail: (hours) =>
        `Latest restore verification is stale (${hours}h).`,
    }),
  );

  checks.push(
    evidenceCheck({
      key: "repository-evidence",
      label: "Backup repository integrity",
      date: operations.latestRepositoryCheck?.finishedAt,
      maxAgeHours: 216,
      missingDetail:
        "No successful repository-integrity telemetry is available.",
      staleDetail: (hours) =>
        `Latest repository integrity evidence is stale (${hours}h).`,
    }),
  );

  checks.push(
    operations.recentFailures === 0
      ? pass(
          "operations-failures",
          "Recent operations failures",
          "No failed operational jobs were recorded in the last 30 days.",
          "OPERATIONS",
        )
      : warn(
          "operations-failures",
          "Recent operations failures",
          `${operations.recentFailures} failed operational run(s) are recorded in the last 30 days.`,
          "OPERATIONS",
        ),
  );

  checks.push(
    gatewayReviewRequired === 0
      ? pass(
          "gateway-review",
          "Gateway review queue",
          "No gateway attempts are waiting for manual review.",
          "OPERATIONS",
        )
      : warn(
          "gateway-review",
          "Gateway review queue",
          `${gatewayReviewRequired} payment gateway attempt(s) require review.`,
          "OPERATIONS",
        ),
  );

  const summary = readinessSummary(checks, acceptance);

  return {
    checks,
    acceptance,
    summary,
    acceptanceGates: LAUNCH_ACCEPTANCE_GATES,
    context: {
      appOrigin: originUrl.origin,
      paymentMode: paymentGatewayConfig.mode,
      paymentEnvironment: paymentGatewayConfig.sslCommerzEnvironment,
      messagingMode: messagingConfig.mode,
      authDeliveryMode: authConfig.deliveryMode,
    },
  };
}
