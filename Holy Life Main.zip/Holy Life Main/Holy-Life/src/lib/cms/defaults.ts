import type {
  PublicWebsitePage,
  WebsiteBranding,
  WebsiteSectionTypeValue,
} from "./types";

export type WebsitePageSeed = {
  slug: string;
  title: string;
  navigationLabel?: string;
  excerpt: string;
  showInHeader?: boolean;
  showInFooter?: boolean;
  headerOrder?: number;
  footerOrder?: number;
  isSystem?: boolean;
  seoTitle?: string;
  seoDescription?: string;
  sections: Array<{
    key: string;
    type: WebsiteSectionTypeValue;
    title: string;
    position: number;
    content: Record<string, unknown>;
  }>;
};

export const DEFAULT_WEBSITE_BRANDING: WebsiteBranding = {
  name: "Holy Life",
  tagline: "Complete Healthcare, Shopping & Learning Platform",
  supportEmail: "techtemlead@gmail.com",
  supportPhone: "+8801790789691",
  address: "Rangpur, Bangladesh",
  hours: "Every day, 8:00 AM–10:00 PM",
};

export const DEFAULT_WEBSITE_PAGES: WebsitePageSeed[] = [
  {
    slug: "home",
    title: "Home",
    navigationLabel: "Home",
    excerpt:
      "Holy Life brings healthcare, wellness learning, and healthy shopping into one member experience.",
    showInHeader: true,
    showInFooter: false,
    headerOrder: 10,
    isSystem: true,
    seoTitle: "Holy Life — Healthcare, Learning and Wellness Shop",
    seoDescription:
      "Book doctor appointments, learn healthier habits, and shop trusted wellness products from one Holy Life account.",
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Home hero",
        position: 10,
        content: {
          eyebrow: "Health, fitness & wellness—connected",
          title: "One simple place to care, learn, and live healthier.",
          description:
            "Holy Life brings doctor appointments, wellness learning, and healthy shopping into one clear experience for every member.",
          primaryLabel: "Book an appointment",
          primaryHref: "/appointment",
          secondaryLabel: "Open member dashboard",
          secondaryHref: "/dashboard",
          tone: "health",
        },
      },
      {
        key: "trust",
        type: "STATS",
        title: "Trust metrics",
        position: 20,
        content: {
          items: [
            { value: "3", label: "Connected departments" },
            { value: "1", label: "Unified member account" },
            { value: "24/7", label: "Dashboard access" },
            { value: "100%", label: "Permission-aware admin control" },
          ],
        },
      },
      {
        key: "departments",
        type: "FEATURE_GRID",
        title: "Core departments",
        position: 30,
        content: {
          eyebrow: "Everything works together",
          title: "Three focused departments. One easy member journey.",
          description:
            "Each department stays clearly separated, while your profile, notifications, and history remain connected.",
          items: [
            {
              title: "Doctor appointments and guided wellness care",
              description:
                "Find the right doctor, request an appointment, access prescriptions, and follow your wellness journey.",
              href: "/appointment",
              label: "Explore healthcare",
              icon: "doctor",
              tone: "health",
            },
            {
              title: "Practical health courses for daily decisions",
              description:
                "Learn from structured lessons and useful resources designed for real lifestyle change.",
              href: "/courses",
              label: "Browse courses",
              icon: "learning",
              tone: "learning",
            },
            {
              title: "Trusted products for healthier routines",
              description:
                "Browse selected wellness products and track delivery from your Holy Life dashboard.",
              href: "/shop",
              label: "Visit shop",
              icon: "shop",
              tone: "commerce",
            },
          ],
        },
      },
      {
        key: "journey",
        type: "CARD_GRID",
        title: "Member journey",
        position: 40,
        content: {
          eyebrow: "Designed around real tasks",
          title: "Simple for members. Controlled for your team.",
          description:
            "Public users get one dashboard while admins only see the departments and actions allowed by the owner.",
          items: [
            {
              title: "Create one account",
              description:
                "Use the same profile across appointments, courses, and orders.",
            },
            {
              title: "Choose what you need",
              description:
                "Book care, continue learning, or shop without a confusing workflow.",
            },
            {
              title: "Track everything clearly",
              description:
                "See upcoming tasks, current progress, payments, and notifications together.",
            },
          ],
        },
      },
      {
        key: "cta",
        type: "CTA",
        title: "Home call to action",
        position: 50,
        content: {
          eyebrow: "Start your Holy Life journey",
          title: "Better health starts with one clear next step.",
          primaryLabel: "Book appointment",
          primaryHref: "/appointment",
          secondaryLabel: "Explore courses",
          secondaryHref: "/courses",
        },
      },
    ],
  },
  {
    slug: "about",
    title: "About Holy Life",
    navigationLabel: "About",
    excerpt:
      "A doctor-led platform designed to make healthier living easier to understand and manage.",
    showInHeader: true,
    showInFooter: true,
    headerOrder: 20,
    footerOrder: 10,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "About hero",
        position: 10,
        content: {
          eyebrow: "About Holy Life",
          title: "Doctor-led guidance with a simpler digital experience.",
          description:
            "We connect care, practical learning, and selected wellness products through one secure member account.",
          primaryLabel: "Meet our doctors",
          primaryHref: "/doctors",
          secondaryLabel: "Contact us",
          secondaryHref: "/contact",
          tone: "health",
        },
      },
      {
        key: "mission",
        type: "RICH_TEXT",
        title: "Mission",
        position: 20,
        content: {
          eyebrow: "Our mission",
          title:
            "Make better health decisions easier to take and easier to sustain.",
          body: "Holy Life is built around clear guidance, trusted professionals, and practical daily action.\n\nThe platform keeps healthcare, learning, and commerce separate where they should be, while giving every member one clear place to manage their journey.",
        },
      },
      {
        key: "values",
        type: "FEATURE_GRID",
        title: "Values",
        position: 30,
        content: {
          eyebrow: "How we work",
          title: "Trust, clarity, and responsible access.",
          items: [
            {
              title: "Doctor-led",
              description:
                "Healthcare content and decisions remain grounded in professional guidance.",
              icon: "doctor",
              tone: "health",
            },
            {
              title: "Privacy-aware",
              description:
                "Sensitive information is protected through role and record-level access.",
              icon: "shield",
              tone: "health",
            },
            {
              title: "Practical",
              description:
                "Every workflow is designed around a clear next action.",
              icon: "check",
              tone: "learning",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "doctors",
    title: "Doctors",
    navigationLabel: "Doctors",
    excerpt:
      "Meet the healthcare professionals who support the Holy Life community.",
    showInHeader: true,
    showInFooter: true,
    headerOrder: 30,
    footerOrder: 20,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Doctors hero",
        position: 10,
        content: {
          eyebrow: "Our doctors",
          title: "Choose a professional who understands your goal.",
          description:
            "Explore doctor profiles and continue to appointment booking when you are ready.",
          primaryLabel: "Book appointment",
          primaryHref: "/appointment",
          tone: "health",
        },
      },
      {
        key: "doctor-grid",
        type: "CARD_GRID",
        title: "Doctor profiles",
        position: 20,
        content: {
          eyebrow: "Healthcare team",
          title: "Professionals supporting your journey",
          items: [
            {
              title: "Dr. Kawsar Ahmed",
              description: "Lifestyle medicine and wellness consultation.",
              label: "Book appointment",
              href: "/appointment",
              icon: "doctor",
              tone: "health",
            },
            {
              title: "Dr. Nusrat Jahan",
              description: "Nutrition and weight management.",
              label: "Book appointment",
              href: "/appointment",
              icon: "doctor",
              tone: "health",
            },
            {
              title: "Dr. Farhan Kabir",
              description: "Fitness and preventive care.",
              label: "Book appointment",
              href: "/appointment",
              icon: "doctor",
              tone: "health",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "appointment",
    title: "Doctor & Appointment",
    navigationLabel: "Appointment",
    excerpt:
      "Choose a doctor and begin an appointment request from one clear flow.",
    showInHeader: true,
    showInFooter: true,
    headerOrder: 40,
    footerOrder: 30,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Appointment hero",
        position: 10,
        content: {
          eyebrow: "Doctor & appointment",
          title: "Book the right care without a complicated process.",
          description:
            "Choose a doctor, select your preferred time, and track every appointment from your Holy Life dashboard.",
          primaryLabel: "Open dashboard",
          primaryHref: "/dashboard/healthcare/appointments",
          secondaryLabel: "Meet doctors",
          secondaryHref: "/doctors",
          tone: "health",
        },
      },
      {
        key: "steps",
        type: "FEATURE_GRID",
        title: "Booking steps",
        position: 20,
        content: {
          eyebrow: "How booking works",
          title: "A clear appointment request journey",
          items: [
            {
              title: "Choose a doctor",
              description: "Review the available professional and service.",
            },
            {
              title: "Request a suitable time",
              description: "Select your preferred date and time.",
            },
            {
              title: "Track confirmation",
              description: "Follow appointment status from your dashboard.",
            },
          ],
        },
      },
      {
        key: "cta",
        type: "CTA",
        title: "Appointment CTA",
        position: 30,
        content: {
          eyebrow: "Member appointment tools",
          title: "Sign in to request and track your appointment.",
          primaryLabel: "Sign in",
          primaryHref: "/login",
          secondaryLabel: "Create account",
          secondaryHref: "/register",
        },
      },
    ],
  },
  {
    slug: "programs",
    title: "Wellness Programs",
    navigationLabel: "Programs",
    excerpt:
      "Structured wellness programs that connect professional guidance with practical habits.",
    showInHeader: false,
    showInFooter: true,
    footerOrder: 40,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Programs hero",
        position: 10,
        content: {
          eyebrow: "Wellness programs",
          title: "Structured support for healthier routines.",
          description:
            "Programs will connect assigned professionals, progress notes, diet guidance, exercise plans, and member tracking.",
          primaryLabel: "Create account",
          primaryHref: "/register",
          tone: "learning",
        },
      },
      {
        key: "programs",
        type: "CARD_GRID",
        title: "Program list",
        position: 20,
        content: {
          eyebrow: "Program areas",
          title: "Support built around real goals",
          items: [
            {
              title: "Healthy weight",
              description: "Guided nutrition, activity, and progress tracking.",
            },
            {
              title: "Lifestyle foundations",
              description:
                "Practical routines for sleep, food, movement, and stress.",
            },
            {
              title: "Preventive wellness",
              description:
                "Doctor-guided habits and follow-up for long-term health.",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "courses",
    title: "Courses",
    navigationLabel: "Courses",
    excerpt: "Practical health learning designed for steady, useful progress.",
    showInHeader: true,
    showInFooter: true,
    headerOrder: 50,
    footerOrder: 50,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Courses hero",
        position: 10,
        content: {
          eyebrow: "Holy Life learning",
          title: "Learn healthier habits through clear, structured lessons.",
          description:
            "Explore practical courses designed to turn health knowledge into daily action.",
          primaryLabel: "Open learning dashboard",
          primaryHref: "/dashboard/learning/courses",
          tone: "learning",
        },
      },
      {
        key: "course-grid",
        type: "CARD_GRID",
        title: "Course cards",
        position: 20,
        content: {
          eyebrow: "Featured learning",
          title: "Build useful knowledge at your own pace",
          items: [
            {
              title: "Healthy Lifestyle Foundations",
              description:
                "Core habits for food, sleep, movement, and consistency.",
              icon: "learning",
              tone: "learning",
            },
            {
              title: "Nutrition Basics",
              description: "Understand balanced meals and practical portions.",
              icon: "learning",
              tone: "learning",
            },
            {
              title: "Everyday Fitness",
              description:
                "Simple movement strategies for sustainable progress.",
              icon: "learning",
              tone: "learning",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "shop",
    title: "Wellness Shop",
    navigationLabel: "Shop",
    excerpt: "Selected wellness products with clear ordering and tracking.",
    showInHeader: true,
    showInFooter: true,
    headerOrder: 60,
    footerOrder: 60,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Shop hero",
        position: 10,
        content: {
          eyebrow: "Holy Life shop",
          title: "Trusted products for healthier everyday routines.",
          description:
            "Browse selected wellness products and manage future orders through one member dashboard.",
          primaryLabel: "Open my orders",
          primaryHref: "/dashboard/shopping/orders",
          tone: "commerce",
        },
      },
      {
        key: "categories",
        type: "FEATURE_GRID",
        title: "Shop categories",
        position: 20,
        content: {
          eyebrow: "Shop by purpose",
          title: "Simple categories, useful products",
          items: [
            {
              title: "Healthy kitchen",
              description: "Practical tools and products for meal routines.",
              icon: "shop",
              tone: "commerce",
            },
            {
              title: "Fitness essentials",
              description: "Selected items that support safe movement.",
              icon: "package",
              tone: "commerce",
            },
            {
              title: "Wellness resources",
              description: "Useful materials for healthier daily planning.",
              icon: "clipboard",
              tone: "commerce",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "blog",
    title: "Health Articles",
    navigationLabel: "Blog",
    excerpt: "Doctor-informed articles and practical wellness guidance.",
    showInHeader: false,
    showInFooter: true,
    footerOrder: 70,
    isSystem: true,
    sections: [
      {
        key: "hero",
        type: "HERO",
        title: "Blog hero",
        position: 10,
        content: {
          eyebrow: "Health articles",
          title: "Clear guidance for better everyday decisions.",
          description:
            "Publish doctor-informed articles, updates, and useful resources from the Holy Life CMS.",
          tone: "learning",
        },
      },
      {
        key: "articles",
        type: "CARD_GRID",
        title: "Article cards",
        position: 20,
        content: {
          eyebrow: "Latest resources",
          title: "Start with practical topics",
          items: [
            {
              title: "Building a consistent sleep routine",
              description:
                "Simple ideas for creating a healthier evening pattern.",
            },
            {
              title: "Balanced meals without confusion",
              description: "A practical way to think about everyday portions.",
            },
            {
              title: "Movement that fits a busy day",
              description: "Small activity choices that are easier to repeat.",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "contact",
    title: "Contact",
    navigationLabel: "Contact",
    excerpt: "Contact Holy Life for support and general information.",
    showInHeader: false,
    showInFooter: true,
    footerOrder: 80,
    isSystem: true,
    sections: [
      {
        key: "contact",
        type: "CONTACT",
        title: "Contact details",
        position: 10,
        content: {
          eyebrow: "Contact Holy Life",
          title: "We are here to help.",
          description:
            "Use the details below for general questions and support.",
          email: "techtemlead@gmail.com",
          phone: "+8801790789691",
          address: "Rangpur, Bangladesh",
          hours: "Every day, 8:00 AM–10:00 PM",
        },
      },
      {
        key: "faq",
        type: "FAQ",
        title: "Contact FAQ",
        position: 20,
        content: {
          eyebrow: "Before you contact us",
          title: "Common questions",
          items: [
            {
              question:
                "Can I manage appointments, courses, and orders from one account?",
              answer:
                "Yes. Holy Life uses one member account across all three departments.",
            },
            {
              question: "Where can I see my activity?",
              answer:
                "Sign in and open your member dashboard to see current and historical activity.",
            },
          ],
        },
      },
    ],
  },
  {
    slug: "privacy",
    title: "Privacy Policy",
    navigationLabel: "Privacy",
    excerpt: "Holy Life privacy and data handling information.",
    showInFooter: true,
    footerOrder: 90,
    isSystem: true,
    sections: [
      {
        key: "content",
        type: "RICH_TEXT",
        title: "Privacy policy",
        position: 10,
        content: {
          eyebrow: "Privacy",
          title: "Your information deserves responsible protection.",
          body: "This starter policy must be reviewed by qualified legal counsel before client production launch.\n\nHoly Life uses role-based access, session controls, and audit records to limit access to protected information. Business modules must apply record-level authorization before sensitive data becomes live.",
        },
      },
    ],
  },
  {
    slug: "terms",
    title: "Terms of Use",
    navigationLabel: "Terms",
    excerpt: "Holy Life terms of use.",
    showInFooter: true,
    footerOrder: 100,
    isSystem: true,
    sections: [
      {
        key: "content",
        type: "RICH_TEXT",
        title: "Terms",
        position: 10,
        content: {
          eyebrow: "Terms",
          title: "Clear expectations for using Holy Life.",
          body: "These starter terms must be reviewed by qualified legal counsel before client production launch.\n\nMedical information shown through the platform does not replace emergency care. Users should follow instructions from qualified healthcare professionals.",
        },
      },
    ],
  },
];

export function defaultPublicPage(slug: string): PublicWebsitePage | null {
  const seed = DEFAULT_WEBSITE_PAGES.find((page) => page.slug === slug);
  if (!seed) return null;
  return {
    id: `default-${seed.slug}`,
    slug: seed.slug,
    title: seed.title,
    navigationLabel: seed.navigationLabel ?? null,
    excerpt: seed.excerpt,
    seoTitle: seed.seoTitle ?? null,
    seoDescription: seed.seoDescription ?? seed.excerpt,
    canonicalPath: seed.slug === "home" ? "/" : `/${seed.slug}`,
    sections: seed.sections.map((section) => ({
      id: `default-${seed.slug}-${section.key}`,
      key: section.key,
      type: section.type,
      title: section.title,
      position: section.position,
      isEnabled: true,
      content: section.content,
    })),
  };
}
