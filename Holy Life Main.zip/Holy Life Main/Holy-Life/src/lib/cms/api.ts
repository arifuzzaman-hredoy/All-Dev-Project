import { NextRequest, NextResponse } from "next/server";

export function cmsRedirect(
  request: NextRequest,
  path: string,
  key: "error" | "success",
  message: string,
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(key, message);
  return NextResponse.redirect(url, 303);
}

export function formString(
  form: FormData,
  key: string,
  maxLength = 500,
): string {
  return String(form.get(key) ?? "")
    .trim()
    .replace(/\s+/g, " ")
    .slice(0, maxLength);
}

export function formMultiline(
  form: FormData,
  key: string,
  maxLength = 4000,
): string {
  return String(form.get(key) ?? "")
    .trim()
    .slice(0, maxLength);
}

export function formInt(form: FormData, key: string, fallback = 0): number {
  const value = Number.parseInt(String(form.get(key) ?? ""), 10);
  return Number.isFinite(value)
    ? Math.max(-10_000, Math.min(10_000, value))
    : fallback;
}

export function formBoolean(form: FormData, key: string): boolean {
  return (
    form.get(key) === "on" || form.get(key) === "true" || form.get(key) === "1"
  );
}

export function safeCanonicalPath(value: string, fallback: string): string {
  if (!value) return fallback;
  return value.startsWith("/") && !value.startsWith("//")
    ? value.slice(0, 160)
    : fallback;
}
