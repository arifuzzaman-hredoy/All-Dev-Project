import { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";

export async function createWebsitePageRevision(
  pageId: string,
  actorId: string | null,
  note: string,
): Promise<number> {
  return db.$transaction(async (tx) => {
    const page = await tx.websitePage.findUniqueOrThrow({
      where: { id: pageId },
      include: {
        sections: { orderBy: [{ position: "asc" }, { createdAt: "asc" }] },
      },
    });
    const claimed = await tx.websitePage.updateMany({
      where: { id: pageId, version: page.version },
      data: { version: { increment: 1 }, updatedById: actorId },
    });
    if (claimed.count !== 1) {
      throw new Error(
        "The website page changed while the revision was being created. Reload and try again.",
      );
    }
    await tx.websitePageRevision.create({
      data: {
        pageId,
        version: page.version,
        note: note.slice(0, 200),
        createdById: actorId,
        snapshot: {
          page: {
            slug: page.slug,
            title: page.title,
            navigationLabel: page.navigationLabel,
            excerpt: page.excerpt,
            status: page.status,
            isSystem: page.isSystem,
            showInHeader: page.showInHeader,
            showInFooter: page.showInFooter,
            headerOrder: page.headerOrder,
            footerOrder: page.footerOrder,
            seoTitle: page.seoTitle,
            seoDescription: page.seoDescription,
            canonicalPath: page.canonicalPath,
            publishedAt: page.publishedAt?.toISOString() ?? null,
            archivedAt: page.archivedAt?.toISOString() ?? null,
          },
          sections: page.sections.map((section) => ({
            key: section.key,
            type: section.type,
            title: section.title,
            position: section.position,
            isEnabled: section.isEnabled,
            content: section.content,
          })),
        } as Prisma.InputJsonValue,
      },
    });
    return page.version + 1;
  });
}
