import { requirePermission } from "@/lib/auth/authorization";
import type { AuthSession } from "@/lib/auth/session";

export async function requireWebsitePermission(
  permissionKey: string,
  returnTo = "/admin/website",
): Promise<AuthSession> {
  return requirePermission(permissionKey, returnTo);
}
