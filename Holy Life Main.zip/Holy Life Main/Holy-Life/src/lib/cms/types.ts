export const WEBSITE_SECTION_TYPES = [
  "HERO",
  "RICH_TEXT",
  "FEATURE_GRID",
  "STATS",
  "CTA",
  "FAQ",
  "CARD_GRID",
  "CONTACT",
] as const;

export type WebsiteSectionTypeValue = (typeof WEBSITE_SECTION_TYPES)[number];

export type CmsLink = {
  label: string;
  href: string;
};

export type CmsItem = {
  title: string;
  description?: string;
  value?: string;
  label?: string;
  href?: string;
  icon?: string;
  tone?: string;
  question?: string;
  answer?: string;
};

export type CmsSectionContent = Record<string, unknown>;

export type PublicWebsiteSection = {
  id: string;
  key: string;
  type: WebsiteSectionTypeValue;
  title: string;
  position: number;
  isEnabled: boolean;
  content: CmsSectionContent;
};

export type PublicWebsitePage = {
  id: string;
  slug: string;
  title: string;
  navigationLabel: string | null;
  excerpt: string | null;
  seoTitle: string | null;
  seoDescription: string | null;
  canonicalPath: string | null;
  sections: PublicWebsiteSection[];
};

export type WebsiteBranding = {
  name: string;
  tagline: string;
  supportEmail: string;
  supportPhone: string;
  address: string;
  hours: string;
};
