import { db } from "@/lib/db";
import {
  DEFAULT_WEBSITE_BRANDING,
  defaultPublicPage,
} from "@/lib/cms/defaults";
import type { PublicWebsitePage, WebsiteBranding } from "@/lib/cms/types";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function readBranding(value: unknown): WebsiteBranding {
  if (!isRecord(value)) return DEFAULT_WEBSITE_BRANDING;
  return {
    name:
      typeof value.name === "string"
        ? value.name
        : DEFAULT_WEBSITE_BRANDING.name,
    tagline:
      typeof value.tagline === "string"
        ? value.tagline
        : DEFAULT_WEBSITE_BRANDING.tagline,
    supportEmail:
      typeof value.supportEmail === "string"
        ? value.supportEmail
        : DEFAULT_WEBSITE_BRANDING.supportEmail,
    supportPhone:
      typeof value.supportPhone === "string"
        ? value.supportPhone
        : DEFAULT_WEBSITE_BRANDING.supportPhone,
    address:
      typeof value.address === "string"
        ? value.address
        : DEFAULT_WEBSITE_BRANDING.address,
    hours:
      typeof value.hours === "string"
        ? value.hours
        : DEFAULT_WEBSITE_BRANDING.hours,
  };
}

export async function getWebsiteBranding(): Promise<WebsiteBranding> {
  try {
    const setting = await db.systemSetting.findUnique({
      where: { key: "website.branding" },
      select: { value: true },
    });
    return readBranding(setting?.value);
  } catch (error) {
    console.error("Website branding query failed", error);
    return DEFAULT_WEBSITE_BRANDING;
  }
}

export async function getPublishedWebsitePage(
  slug: string,
): Promise<PublicWebsitePage | null> {
  try {
    const page = await db.websitePage.findUnique({
      where: { slug },
      include: {
        sections: {
          where: { isEnabled: true },
          orderBy: [{ position: "asc" }, { createdAt: "asc" }],
        },
      },
    });
    if (!page) return defaultPublicPage(slug);
    if (page.status !== "PUBLISHED") return null;
    return {
      id: page.id,
      slug: page.slug,
      title: page.title,
      navigationLabel: page.navigationLabel,
      excerpt: page.excerpt,
      seoTitle: page.seoTitle,
      seoDescription: page.seoDescription,
      canonicalPath: page.canonicalPath,
      sections: page.sections.map((section) => ({
        id: section.id,
        key: section.key,
        type: section.type,
        title: section.title,
        position: section.position,
        isEnabled: section.isEnabled,
        content: isRecord(section.content) ? section.content : {},
      })),
    };
  } catch (error) {
    console.error(`Website page query failed for ${slug}`, error);
    return defaultPublicPage(slug);
  }
}

export async function getWebsiteNavigation(): Promise<{
  header: Array<{ href: string; label: string }>;
  footer: Array<{ href: string; label: string }>;
}> {
  try {
    const pages = await db.websitePage.findMany({
      where: {
        status: "PUBLISHED",
        OR: [{ showInHeader: true }, { showInFooter: true }],
      },
      orderBy: [
        { headerOrder: "asc" },
        { footerOrder: "asc" },
        { title: "asc" },
      ],
      select: {
        slug: true,
        title: true,
        navigationLabel: true,
        showInHeader: true,
        showInFooter: true,
        headerOrder: true,
        footerOrder: true,
      },
    });
    if (pages.length === 0)
      throw new Error("No published CMS navigation records are available.");
    const href = (slug: string) => (slug === "home" ? "/" : `/${slug}`);
    return {
      header: pages
        .filter((page) => page.showInHeader)
        .sort((a, b) => a.headerOrder - b.headerOrder)
        .map((page) => ({
          href: href(page.slug),
          label: page.navigationLabel ?? page.title,
        })),
      footer: pages
        .filter((page) => page.showInFooter)
        .sort((a, b) => a.footerOrder - b.footerOrder)
        .map((page) => ({
          href: href(page.slug),
          label: page.navigationLabel ?? page.title,
        })),
    };
  } catch (error) {
    console.error("Website navigation query failed", error);
    return {
      header: [
        { href: "/", label: "Home" },
        { href: "/about", label: "About" },
        { href: "/doctors", label: "Doctors" },
        { href: "/appointment", label: "Appointment" },
        { href: "/courses", label: "Courses" },
        { href: "/shop", label: "Shop" },
      ],
      footer: [
        { href: "/about", label: "About" },
        { href: "/doctors", label: "Doctors" },
        { href: "/appointment", label: "Appointment" },
        { href: "/programs", label: "Programs" },
        { href: "/courses", label: "Courses" },
        { href: "/shop", label: "Shop" },
        { href: "/blog", label: "Blog" },
        { href: "/contact", label: "Contact" },
        { href: "/privacy", label: "Privacy" },
        { href: "/terms", label: "Terms" },
      ],
    };
  }
}
