import {
  WEBSITE_SECTION_TYPES,
  type CmsSectionContent,
  type WebsiteSectionTypeValue,
} from "@/lib/cms/types";

export const RESERVED_WEBSITE_SLUGS = new Set([
  "api",
  "admin",
  "super-admin",
  "dashboard",
  "login",
  "register",
  "verify",
  "forgot-password",
  "reset-password",
  "admin-invitation",
  "website-preview",
  "_next",
]);

export function normalizeWebsiteSlug(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

export function validateWebsiteSlug(value: string): string | null {
  const normalized = normalizeWebsiteSlug(value);
  if (!normalized) return "Enter a page slug.";
  if (RESERVED_WEBSITE_SLUGS.has(normalized))
    return "This slug is reserved by the application.";
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(normalized))
    return "Use lowercase letters, numbers, and hyphens only.";
  return null;
}

export function isWebsiteSectionType(
  value: string,
): value is WebsiteSectionTypeValue {
  return WEBSITE_SECTION_TYPES.includes(value as WebsiteSectionTypeValue);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function validateContentTree(value: unknown, depth = 0): void {
  if (depth > 8) throw new Error("Section content is nested too deeply.");
  if (typeof value === "string") {
    if (value.length > 12_000)
      throw new Error("A section text value is too long.");
    return;
  }
  if (value === null || typeof value === "number" || typeof value === "boolean")
    return;
  if (Array.isArray(value)) {
    if (value.length > 100)
      throw new Error("A section list contains too many items.");
    for (const item of value) validateContentTree(item, depth + 1);
    return;
  }
  if (isRecord(value)) {
    const entries = Object.entries(value);
    if (entries.length > 100)
      throw new Error("A section object contains too many fields.");
    for (const [key, child] of entries) {
      if (["__proto__", "prototype", "constructor"].includes(key))
        throw new Error("Unsafe section field name.");
      if (key.length > 100)
        throw new Error("A section field name is too long.");
      validateContentTree(child, depth + 1);
    }
    return;
  }
  throw new Error("Section content contains an unsupported value.");
}

export function parseSectionContent(value: string): CmsSectionContent {
  if (value.length > 100_000)
    throw new Error("Section content exceeds the 100 KB limit.");
  const parsed: unknown = JSON.parse(value);
  if (!isRecord(parsed))
    throw new Error("Section content must be a JSON object.");
  validateContentTree(parsed);
  return parsed;
}

export function readString(
  content: CmsSectionContent,
  key: string,
  fallback = "",
): string {
  const value = content[key];
  return typeof value === "string" ? value : fallback;
}

export function readBoolean(
  content: CmsSectionContent,
  key: string,
  fallback = false,
): boolean {
  const value = content[key];
  return typeof value === "boolean" ? value : fallback;
}

export function readItems(
  content: CmsSectionContent,
): Array<Record<string, unknown>> {
  const value = content.items;
  if (!Array.isArray(value)) return [];
  return value.filter(isRecord);
}

export function contentTemplate(
  type: WebsiteSectionTypeValue,
): CmsSectionContent {
  switch (type) {
    case "HERO":
      return {
        eyebrow: "Health, fitness & wellness—connected",
        title: "One simple place to care, learn, and live healthier.",
        description: "Add a clear summary for this public page.",
        primaryLabel: "Get started",
        primaryHref: "/register",
        secondaryLabel: "Learn more",
        secondaryHref: "/about",
        tone: "health",
      };
    case "RICH_TEXT":
      return {
        eyebrow: "Our approach",
        title: "A clear section heading",
        body: "Write the first paragraph here.\n\nWrite another paragraph after a blank line.",
      };
    case "FEATURE_GRID":
    case "CARD_GRID":
      return {
        eyebrow: "What we offer",
        title: "A focused collection of services",
        description: "Explain why these items matter.",
        items: [
          {
            title: "First item",
            description: "Short supporting description.",
            href: "/appointment",
            label: "Learn more",
            icon: "doctor",
            tone: "health",
          },
          {
            title: "Second item",
            description: "Short supporting description.",
            href: "/courses",
            label: "Explore",
            icon: "learning",
            tone: "learning",
          },
          {
            title: "Third item",
            description: "Short supporting description.",
            href: "/shop",
            label: "Visit",
            icon: "shop",
            tone: "commerce",
          },
        ],
      };
    case "STATS":
      return {
        items: [
          { value: "3", label: "Connected departments" },
          { value: "1", label: "Unified account" },
          { value: "24/7", label: "Dashboard access" },
        ],
      };
    case "CTA":
      return {
        eyebrow: "Take the next step",
        title: "Start your Holy Life journey today.",
        description: "Choose a clear primary action.",
        primaryLabel: "Create account",
        primaryHref: "/register",
        secondaryLabel: "Book appointment",
        secondaryHref: "/appointment",
      };
    case "FAQ":
      return {
        eyebrow: "Common questions",
        title: "Frequently asked questions",
        items: [
          {
            question: "How does it work?",
            answer: "Add a helpful answer here.",
          },
        ],
      };
    case "CONTACT":
      return {
        eyebrow: "Contact Holy Life",
        title: "We are here to help.",
        description: "Send a message or use the contact information below.",
        email: "support@holylife.example",
        phone: "+880 1XXX-XXXXXX",
        address: "Rangpur, Bangladesh",
        hours: "Every day, 8:00 AM–10:00 PM",
      };
  }
}

export function prettyContent(value: unknown): string {
  return JSON.stringify(value, null, 2);
}
