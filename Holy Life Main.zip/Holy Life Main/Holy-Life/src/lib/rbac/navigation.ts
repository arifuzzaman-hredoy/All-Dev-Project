import type { NavigationItem } from "@/config/navigation";

const ADMIN_PATH_PERMISSIONS: Array<[string, string]> = [
  [
    "/admin/healthcare/appointments",
    "healthcare.appointments.appointment.view",
  ],
  ["/admin/healthcare/departments", "healthcare.doctors.department.view"],
  ["/admin/healthcare/schedules", "healthcare.doctors.schedule.manage"],
  ["/admin/healthcare/doctors", "healthcare.doctors.doctor.view"],
  [
    "/admin/healthcare/patients/records",
    "healthcare.patients.clinical-record.view",
  ],
  [
    "/admin/healthcare/patients/history",
    "healthcare.patients.clinical-record.view",
  ],
  ["/admin/healthcare/patients", "healthcare.patients.patient.view"],
  [
    "/admin/healthcare/prescriptions",
    "healthcare.prescriptions.prescription.view",
  ],
  ["/admin/healthcare/programs", "healthcare.wellness.program.view"],
  ["/admin/commerce/products/inventory", "commerce.inventory.stock.view"],
  ["/admin/commerce/products/categories", "commerce.catalog.category.manage"],
  ["/admin/commerce/products/create", "commerce.catalog.product.create"],
  ["/admin/commerce/orders/returns", "commerce.orders.refund.approve"],
  ["/admin/commerce/orders", "commerce.orders.order.view"],
  ["/admin/commerce/payments", "commerce.orders.order.view"],
  ["/admin/commerce/coupons", "commerce.catalog.coupon.manage"],
  ["/admin/commerce/settings", "commerce.shipping.shipping.manage"],
  ["/admin/commerce/reviews", "commerce.catalog.product.edit"],
  ["/admin/commerce/reports", "commerce.reports.commerce-report.view"],
  ["/admin/commerce/products", "commerce.catalog.product.view"],
  ["/admin/learning/courses", "learning.courses.course.view"],
  ["/admin/learning/enrollments", "learning.enrollments.enrollment.view"],
  ["/admin/learning/assessments", "learning.assessments.quiz.manage"],
  ["/admin/learning/certificates", "learning.certificates.certificate.issue"],
  ["/admin/website", "website.cms.content.view"],
  ["/admin/finance/gateways", "system.finance.gateway.view"],
  ["/admin/finance/payments", "system.finance.payment.view"],
  ["/admin/finance/transactions", "system.finance.payment.view"],
  ["/admin/reports", "system.reports.financial-report.view"],
  ["/admin/analytics", "system.analytics.platform.view"],
  ["/admin/audit", "system.audit.audit-log.view"],
  ["/admin/operations/backups", "system.operations.backup.view"],
  ["/admin/launch-readiness", "system.operations.launch-readiness.view"],
  ["/admin/messages", "system.messaging.campaign.view"],
  ["/admin/notifications", "system.notifications.notification.manage"],
  ["/admin/settings", "system.settings.setting.manage"],
];

export function permissionForAdminPath(pathname: string): string | null {
  const match = ADMIN_PATH_PERMISSIONS.find(
    ([prefix]) => pathname === prefix || pathname.startsWith(`${prefix}/`),
  );
  return match?.[1] ?? null;
}

export function filterNavigation(
  items: readonly NavigationItem[],
  can: (permissionKey: string) => boolean,
): NavigationItem[] {
  const filtered: NavigationItem[] = [];
  for (const item of items) {
    const children = item.children
      ? filterNavigation(item.children, can)
      : undefined;
    const ownPermission = item.href ? permissionForAdminPath(item.href) : null;
    const allowed = !ownPermission || can(ownPermission);
    if (
      allowed &&
      (!item.children || (children?.length ?? 0) > 0 || Boolean(item.href))
    ) {
      filtered.push({ ...item, ...(children ? { children } : {}) });
    } else if (!item.href && (children?.length ?? 0) > 0) {
      filtered.push({ ...item, children });
    }
  }
  return filtered;
}
