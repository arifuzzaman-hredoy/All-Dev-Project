import type { DataScopeValue } from "@/lib/rbac/catalog";

const SCOPE_WEIGHT: Record<DataScopeValue, number> = {
  OWN: 1,
  ASSIGNED: 2,
  DEPARTMENT: 3,
  BRANCH: 4,
  ALL: 5,
};

export function broaderDataScope(
  a: DataScopeValue,
  b: DataScopeValue,
): DataScopeValue {
  return SCOPE_WEIGHT[a] >= SCOPE_WEIGHT[b] ? a : b;
}

export function effectiveDataScope(
  scopes: readonly DataScopeValue[],
): DataScopeValue {
  return scopes.reduce<DataScopeValue>(
    (current, next) => broaderDataScope(current, next),
    "OWN",
  );
}
