export function normalizeRoleCode(value: string): string {
  return value
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 64);
}

export function validateRoleCode(value: string): boolean {
  return /^[A-Z][A-Z0-9_]{1,63}$/.test(value);
}
