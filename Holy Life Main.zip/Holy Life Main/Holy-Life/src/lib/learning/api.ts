import { NextRequest, NextResponse } from "next/server";

export function learningRedirect(
  request: NextRequest,
  path: string,
  kind: "success" | "error",
  message: string,
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(kind, message);
  return NextResponse.redirect(url, 303);
}
