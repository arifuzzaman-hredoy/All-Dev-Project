export type LessonProgressInput = {
  status: "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED";
  progressPercent: number;
};

export function normalizeLessonProgress(input: {
  completed?: boolean;
  progressPercent?: number;
}): LessonProgressInput {
  const raw = Number.isFinite(input.progressPercent)
    ? Math.round(input.progressPercent ?? 0)
    : 0;
  const progressPercent = Math.min(
    100,
    Math.max(0, input.completed ? 100 : raw),
  );
  const status =
    progressPercent >= 100
      ? "COMPLETED"
      : progressPercent > 0
        ? "IN_PROGRESS"
        : "NOT_STARTED";
  return { status, progressPercent };
}

export function calculateCourseProgress(
  totalLessons: number,
  completedLessons: number,
): number {
  if (totalLessons <= 0) return 0;
  return Math.min(
    100,
    Math.max(0, Math.round((completedLessons / totalLessons) * 100)),
  );
}

export function isCourseComplete(
  totalLessons: number,
  completedLessons: number,
): boolean {
  return totalLessons > 0 && completedLessons >= totalLessons;
}
