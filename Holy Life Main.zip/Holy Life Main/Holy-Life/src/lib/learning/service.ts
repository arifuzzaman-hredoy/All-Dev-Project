import { db } from "@/lib/db";
import { createCertificateCode } from "@/lib/learning/code";
import {
  calculateCourseProgress,
  normalizeLessonProgress,
} from "@/lib/learning/progress";

export class LearningError extends Error {}

export async function enrollStudent(input: {
  courseId: string;
  userId: string;
  managedById?: string | null;
  note?: string | null;
}) {
  const course = await db.course.findFirst({
    where: { id: input.courseId, status: "PUBLISHED" },
    select: { id: true, allowSelfEnrollment: true },
  });
  if (!course) throw new LearningError("Course is unavailable.");
  if (!input.managedById && !course.allowSelfEnrollment)
    throw new LearningError("Self-enrollment is disabled for this course.");
  return db.courseEnrollment.upsert({
    where: {
      courseId_userId: { courseId: input.courseId, userId: input.userId },
    },
    update: {
      status: "ACTIVE",
      managedById: input.managedById ?? undefined,
      note: input.note ?? undefined,
    },
    create: {
      courseId: input.courseId,
      userId: input.userId,
      managedById: input.managedById ?? null,
      note: input.note ?? null,
    },
  });
}

export async function updateLessonProgress(input: {
  userId: string;
  enrollmentId: string;
  lessonId: string;
  completed?: boolean;
  progressPercent?: number;
  lastPositionSec?: number;
}) {
  return db.$transaction(async (tx) => {
    const enrollment = await tx.courseEnrollment.findFirst({
      where: { id: input.enrollmentId, userId: input.userId, status: "ACTIVE" },
      include: {
        course: {
          include: {
            modules: {
              where: { isPublished: true },
              include: {
                lessons: { where: { isPublished: true }, select: { id: true } },
              },
            },
          },
        },
      },
    });
    if (!enrollment)
      throw new LearningError("Active enrollment was not found.");
    const lessonIds = enrollment.course.modules.flatMap((module) =>
      module.lessons.map((lesson) => lesson.id),
    );
    if (!lessonIds.includes(input.lessonId))
      throw new LearningError("Lesson does not belong to this course.");
    const normalized = normalizeLessonProgress(input);
    const now = new Date();
    await tx.lessonProgress.upsert({
      where: {
        enrollmentId_lessonId: {
          enrollmentId: enrollment.id,
          lessonId: input.lessonId,
        },
      },
      update: {
        status: normalized.status,
        progressPercent: normalized.progressPercent,
        lastPositionSec: Math.max(0, Math.round(input.lastPositionSec ?? 0)),
        startedAt: now,
        completedAt: normalized.status === "COMPLETED" ? now : null,
      },
      create: {
        enrollmentId: enrollment.id,
        lessonId: input.lessonId,
        userId: input.userId,
        status: normalized.status,
        progressPercent: normalized.progressPercent,
        lastPositionSec: Math.max(0, Math.round(input.lastPositionSec ?? 0)),
        startedAt: now,
        completedAt: normalized.status === "COMPLETED" ? now : null,
      },
    });
    const completedLessons = await tx.lessonProgress.count({
      where: {
        enrollmentId: enrollment.id,
        status: "COMPLETED",
        lessonId: { in: lessonIds },
      },
    });
    const progressPercent = calculateCourseProgress(
      lessonIds.length,
      completedLessons,
    );
    const completed = progressPercent >= 100 && lessonIds.length > 0;
    return tx.courseEnrollment.update({
      where: { id: enrollment.id },
      data: {
        progressPercent,
        startedAt: enrollment.startedAt ?? now,
        status: completed ? "COMPLETED" : "ACTIVE",
        completedAt: completed ? now : null,
      },
    });
  });
}

export async function issueCertificate(input: {
  enrollmentId: string;
  issuedById?: string | null;
}) {
  return db.$transaction(async (tx) => {
    const enrollment = await tx.courseEnrollment.findUnique({
      where: { id: input.enrollmentId },
      include: { course: true },
    });
    if (
      !enrollment ||
      enrollment.status !== "COMPLETED" ||
      enrollment.progressPercent < 100
    )
      throw new LearningError(
        "Only completed enrollments can receive certificates.",
      );
    if (!enrollment.course.certificateEnabled)
      throw new LearningError("Certificates are disabled for this course.");
    return tx.courseCertificate.upsert({
      where: { enrollmentId: enrollment.id },
      update: {
        status: "ISSUED",
        issuedById: input.issuedById ?? null,
        revokedAt: null,
        revokeReason: null,
      },
      create: {
        code: createCertificateCode(),
        courseId: enrollment.courseId,
        enrollmentId: enrollment.id,
        userId: enrollment.userId,
        issuedById: input.issuedById ?? null,
      },
    });
  });
}
