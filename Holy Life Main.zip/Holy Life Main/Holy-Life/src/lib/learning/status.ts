export const ENROLLMENT_TRANSITIONS = {
  ACTIVE: ["COMPLETED", "CANCELLED", "SUSPENDED"],
  COMPLETED: [],
  CANCELLED: ["ACTIVE"],
  SUSPENDED: ["ACTIVE", "CANCELLED"],
} as const;

export type EnrollmentStatusValue = keyof typeof ENROLLMENT_TRANSITIONS;

export function canTransitionEnrollment(
  from: EnrollmentStatusValue,
  to: EnrollmentStatusValue,
): boolean {
  if (from === to) {
    return true;
  }

  return (ENROLLMENT_TRANSITIONS[from] as readonly string[]).includes(to);
}

export function enrollmentStatusLabel(status: string): string {
  return status
    .toLowerCase()
    .replace(/_/g, " ")
    .replace(/\b\w/g, (value) => value.toUpperCase());
}
