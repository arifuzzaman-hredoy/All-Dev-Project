export function requiredText(form: FormData, key: string, max = 200): string {
  const value = String(form.get(key) ?? "").trim();
  if (!value) throw new Error(`${key} is required.`);
  if (value.length > max) throw new Error(`${key} is too long.`);
  return value;
}

export function optionalText(
  form: FormData,
  key: string,
  max = 2000,
): string | null {
  const value = String(form.get(key) ?? "").trim();
  if (!value) return null;
  if (value.length > max) throw new Error(`${key} is too long.`);
  return value;
}

export function integerValue(
  form: FormData,
  key: string,
  min: number,
  max: number,
  fallback = min,
): number {
  const raw = String(form.get(key) ?? "").trim();
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isInteger(value) || value < min || value > max)
    throw new Error(`${key} is invalid.`);
  return value;
}

export function decimalValue(form: FormData, key: string, min = 0): number {
  const raw = String(form.get(key) ?? "0").trim();
  const value = Number(raw);
  if (!Number.isFinite(value) || value < min)
    throw new Error(`${key} is invalid.`);
  return Math.round(value * 100) / 100;
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
}

export function listValue(value: string | null): string[] {
  return (value ?? "")
    .split(/\r?\n|,/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 30);
}
