import { db } from "@/lib/db";

export async function listPublishedCourses(
  input: { category?: string | null; q?: string | null } = {},
) {
  return db.course.findMany({
    where: {
      status: "PUBLISHED",
      category: {
        isActive: true,
        ...(input.category ? { slug: input.category } : {}),
      },
      ...(input.q
        ? {
            OR: [
              { title: { contains: input.q, mode: "insensitive" } },
              { titleBn: { contains: input.q, mode: "insensitive" } },
              { shortDescription: { contains: input.q, mode: "insensitive" } },
              {
                shortDescriptionBn: { contains: input.q, mode: "insensitive" },
              },
              {
                instructor: {
                  OR: [
                    { name: { contains: input.q, mode: "insensitive" } },
                    { nameBn: { contains: input.q, mode: "insensitive" } },
                  ],
                },
              },
            ],
          }
        : {}),
    },
    include: {
      category: true,
      instructor: true,
      modules: {
        where: { isPublished: true },
        include: {
          lessons: {
            where: { isPublished: true },
            select: { id: true, durationMinutes: true },
          },
        },
      },
      reviews: { where: { status: "PUBLISHED" }, select: { rating: true } },
      _count: { select: { enrollments: true } },
    },
    orderBy: [
      { isFeatured: "desc" },
      { displayOrder: "asc" },
      { title: "asc" },
    ],
  });
}

export async function getPublishedCourse(slug: string) {
  return db.course.findFirst({
    where: { slug, status: "PUBLISHED", category: { isActive: true } },
    include: {
      category: true,
      instructor: true,
      modules: {
        where: { isPublished: true },
        include: {
          lessons: {
            where: { isPublished: true },
            include: { resources: { orderBy: { position: "asc" } } },
            orderBy: { position: "asc" },
          },
          quizzes: {
            where: { status: "PUBLISHED" },
            orderBy: { position: "asc" },
          },
        },
        orderBy: { position: "asc" },
      },
      reviews: {
        where: { status: "PUBLISHED" },
        include: { user: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        take: 20,
      },
      _count: { select: { enrollments: true } },
    },
  });
}

export async function listStudentEnrollments(
  userId: string,
  mode: "all" | "active" | "completed" = "all",
) {
  return db.courseEnrollment.findMany({
    where: {
      userId,
      ...(mode === "active"
        ? { status: "ACTIVE" }
        : mode === "completed"
          ? { status: "COMPLETED" }
          : {}),
    },
    include: {
      course: {
        include: {
          category: true,
          instructor: true,
          modules: {
            include: {
              lessons: { where: { isPublished: true }, select: { id: true } },
            },
          },
        },
      },
      certificate: true,
    },
    orderBy: { updatedAt: "desc" },
  });
}

export async function learningSummary() {
  const [courses, published, students, active, completed, certificates] =
    await Promise.all([
      db.course.count({ where: { status: { not: "ARCHIVED" } } }),
      db.course.count({ where: { status: "PUBLISHED" } }),
      db.courseEnrollment.groupBy({ by: ["userId"] }),
      db.courseEnrollment.count({ where: { status: "ACTIVE" } }),
      db.courseEnrollment.count({ where: { status: "COMPLETED" } }),
      db.courseCertificate.count({ where: { status: "ISSUED" } }),
    ]);
  return {
    courses,
    published,
    students: students.length,
    active,
    completed,
    certificates,
  };
}
