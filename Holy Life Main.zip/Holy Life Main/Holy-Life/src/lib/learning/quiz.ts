export type QuizQuestionResult = {
  points: number;
  selectedOptionId: string | null;
  correctOptionId: string;
};

export function scoreQuiz(questions: readonly QuizQuestionResult[]): {
  earnedPoints: number;
  totalPoints: number;
  score: number;
} {
  const totalPoints = questions.reduce(
    (sum, item) => sum + Math.max(0, item.points),
    0,
  );
  const earnedPoints = questions.reduce(
    (sum, item) =>
      sum +
      (item.selectedOptionId === item.correctOptionId
        ? Math.max(0, item.points)
        : 0),
    0,
  );
  const score =
    totalPoints <= 0 ? 0 : Math.round((earnedPoints / totalPoints) * 100);
  return { earnedPoints, totalPoints, score };
}
