import { randomBytes } from "node:crypto";

export function createCertificateCode(now = new Date()): string {
  const date = now.toISOString().slice(0, 10).replaceAll("-", "");
  return `HLC-${date}-${randomBytes(4).toString("hex").toUpperCase()}`;
}
