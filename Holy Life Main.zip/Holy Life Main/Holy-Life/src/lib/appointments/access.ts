import type { Prisma } from "@/generated/prisma/client";
import type { AuthenticatedUser } from "@/lib/auth/session";
import { effectiveDataScope } from "@/lib/rbac/scope";

const APPOINTMENT_VIEW_PERMISSION = "healthcare.appointments.appointment.view";
const DOCTOR_VIEW_PERMISSION = "healthcare.doctors.doctor.view";
const PATIENT_VIEW_PERMISSION = "healthcare.patients.patient.view";

type Scope = "OWN" | "ASSIGNED" | "DEPARTMENT" | "BRANCH" | "ALL";

export function dataScopeForPermission(
  user: AuthenticatedUser,
  permissionKey: string,
): Scope {
  if (user.isSuperAdmin) return "ALL";
  const scopes = user.roles
    .filter((role) => role.permissions.includes(permissionKey))
    .map((role) => role.dataScope);
  return effectiveDataScope(scopes);
}

export function appointmentAccessWhere(
  user: AuthenticatedUser,
  permissionKey = APPOINTMENT_VIEW_PERMISSION,
): Prisma.AppointmentWhereInput {
  const scope = dataScopeForPermission(user, permissionKey);
  if (scope === "ALL" || scope === "BRANCH" || scope === "DEPARTMENT")
    return {};
  if (scope === "ASSIGNED") return { doctor: { userId: user.id } };
  return {
    OR: [
      { userId: user.id },
      { createdById: user.id },
      { doctor: { userId: user.id } },
    ],
  };
}

export function doctorAccessWhere(
  user: AuthenticatedUser,
  permissionKey = DOCTOR_VIEW_PERMISSION,
): Prisma.DoctorProfileWhereInput {
  const scope = dataScopeForPermission(user, permissionKey);
  if (scope === "ALL" || scope === "BRANCH" || scope === "DEPARTMENT")
    return {};
  return { userId: user.id };
}

export function patientAccessWhere(
  user: AuthenticatedUser,
  permissionKey = PATIENT_VIEW_PERMISSION,
): Prisma.PatientProfileWhereInput {
  const scope = dataScopeForPermission(user, permissionKey);
  if (scope === "ALL" || scope === "BRANCH" || scope === "DEPARTMENT")
    return {};
  if (scope === "ASSIGNED")
    return { appointments: { some: { doctor: { userId: user.id } } } };
  return {
    OR: [
      { userId: user.id },
      { appointments: { some: { createdById: user.id } } },
      { appointments: { some: { doctor: { userId: user.id } } } },
    ],
  };
}
