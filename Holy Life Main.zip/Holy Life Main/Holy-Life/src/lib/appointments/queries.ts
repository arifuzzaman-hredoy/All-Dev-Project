import { AppointmentStatus, Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { buildAppointmentSlots } from "@/lib/appointments/availability";
import {
  dateInputToUtc,
  todayInDhaka,
  utcDateToInput,
} from "@/lib/appointments/time";

export async function listActiveDoctors(
  department?: string | null,
  accessWhere: Prisma.DoctorProfileWhereInput = {},
) {
  return db.doctorProfile.findMany({
    where: {
      AND: [
        accessWhere,
        {
          status: "ACTIVE",
          department: {
            isActive: true,
            ...(department ? { slug: department } : {}),
          },
        },
      ],
    },
    include: { department: true },
    orderBy: [{ isFeatured: "desc" }, { displayOrder: "asc" }, { name: "asc" }],
  });
}

export async function getDoctorAvailability(doctorId: string, date: string) {
  const appointmentDate = dateInputToUtc(date);
  const doctor = await db.doctorProfile.findFirst({
    where: { id: doctorId, status: "ACTIVE", department: { isActive: true } },
    include: {
      department: true,
      schedules: {
        where: { isActive: true },
        orderBy: [{ weekday: "asc" }, { startTime: "asc" }],
      },
      availability: {
        where: { date: appointmentDate },
        orderBy: { createdAt: "asc" },
      },
      appointments: {
        where: { appointmentDate },
        select: { startTime: true, status: true },
      },
    },
  });
  if (!doctor) return null;
  const slots = buildAppointmentSlots({
    date,
    schedules: doctor.schedules,
    overrides: doctor.availability,
    bookings: doctor.appointments,
  });
  return { doctor, slots };
}

export async function dashboardAppointments(
  userId: string,
  mode: "all" | "upcoming" | "history" = "all",
) {
  const today = dateInputToUtc(todayInDhaka());
  const where: Prisma.AppointmentWhereInput = { userId };
  if (mode === "upcoming") {
    where.appointmentDate = { gte: today };
    where.status = {
      notIn: [
        AppointmentStatus.COMPLETED,
        AppointmentStatus.CANCELLED,
        AppointmentStatus.NO_SHOW,
      ],
    };
  } else if (mode === "history") {
    where.OR = [
      { appointmentDate: { lt: today } },
      {
        status: {
          in: [
            AppointmentStatus.COMPLETED,
            AppointmentStatus.CANCELLED,
            AppointmentStatus.NO_SHOW,
          ],
        },
      },
    ];
  }
  return db.appointment.findMany({
    where,
    include: { doctor: { include: { department: true } } },
    orderBy: [
      { appointmentDate: mode === "history" ? "desc" : "asc" },
      { startTime: "asc" },
    ],
    take: 100,
  });
}

export function dateValue(value: Date): string {
  return utcDateToInput(value);
}
