import {
  isValidBangladeshPhone,
  isValidEmail,
  normalizeEmail,
  normalizePhone,
} from "@/lib/auth/normalize";
import {
  addDaysToDateInput,
  compareDateInputs,
  isDateInput,
  isTimeValue,
  todayInDhaka,
} from "@/lib/appointments/time";

export type AppointmentFormInput = {
  doctorId: string;
  date: string;
  startTime: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string | null;
  serviceType: string;
  reason: string | null;
};

function cleanSingleLine(
  value: FormDataEntryValue | null,
  maxLength: number,
): string {
  return String(value ?? "")
    .trim()
    .replace(/\s+/g, " ")
    .slice(0, maxLength);
}

function cleanMultiline(
  value: FormDataEntryValue | null,
  maxLength: number,
): string {
  return String(value ?? "")
    .trim()
    .replace(/\r\n/g, "\n")
    .slice(0, maxLength);
}

export function readAppointmentForm(form: FormData): AppointmentFormInput {
  const emailRaw = cleanSingleLine(form.get("patientEmail"), 254);
  return {
    doctorId: cleanSingleLine(form.get("doctorId"), 100),
    date: cleanSingleLine(form.get("date"), 10),
    startTime: cleanSingleLine(form.get("startTime"), 5),
    patientName: cleanSingleLine(form.get("patientName"), 100),
    patientPhone: normalizePhone(cleanSingleLine(form.get("patientPhone"), 30)),
    patientEmail: emailRaw ? normalizeEmail(emailRaw) : null,
    serviceType: cleanSingleLine(form.get("serviceType"), 80) || "Consultation",
    reason: cleanMultiline(form.get("reason"), 1000) || null,
  };
}

export function validateAppointmentForm(
  input: AppointmentFormInput,
  options?: { allowToday?: boolean; maxAdvanceDays?: number },
): string | null {
  if (!input.doctorId) return "Select a doctor.";
  if (!isDateInput(input.date)) return "Select a valid appointment date.";
  if (!isTimeValue(input.startTime))
    return "Select an available appointment time.";
  if (input.patientName.length < 2) return "Enter the patient name.";
  if (!isValidBangladeshPhone(input.patientPhone))
    return "Enter a valid Bangladesh mobile number.";
  if (input.patientEmail && !isValidEmail(input.patientEmail))
    return "Enter a valid email address.";
  const today = todayInDhaka();
  const minimum =
    options?.allowToday === false ? addDaysToDateInput(today, 1) : today;
  if (compareDateInputs(input.date, minimum) < 0)
    return "The appointment date cannot be in the past.";
  const maximum = addDaysToDateInput(today, options?.maxAdvanceDays ?? 90);
  if (compareDateInputs(input.date, maximum) > 0)
    return `Appointments can be booked up to ${options?.maxAdvanceDays ?? 90} days ahead.`;
  return null;
}

export function formText(form: FormData, key: string, maxLength = 255): string {
  return cleanSingleLine(form.get(key), maxLength);
}

export function formLongText(
  form: FormData,
  key: string,
  maxLength = 5000,
): string {
  return cleanMultiline(form.get(key), maxLength);
}

export function formInteger(
  form: FormData,
  key: string,
  fallback = 0,
  minimum = 0,
  maximum = 100000,
): number {
  const value = Number(form.get(key));
  if (!Number.isFinite(value)) return fallback;
  return Math.min(maximum, Math.max(minimum, Math.trunc(value)));
}

export function formMoney(form: FormData, key: string, fallback = 0): number {
  const value = Number(form.get(key));
  if (!Number.isFinite(value)) return fallback;
  return Math.max(0, Math.min(10_000_000, Math.round(value * 100) / 100));
}

export function formCheckbox(form: FormData, key: string): boolean {
  return (
    form.get(key) === "on" || form.get(key) === "true" || form.get(key) === "1"
  );
}
