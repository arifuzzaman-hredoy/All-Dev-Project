import { NextRequest, NextResponse } from "next/server";

export function appointmentRedirect(
  request: NextRequest,
  path: string,
  key: "success" | "error",
  message: string,
  values?: Record<string, string | null | undefined>,
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(key, message);
  for (const [name, value] of Object.entries(values ?? {})) {
    if (value) url.searchParams.set(name, value);
  }
  return NextResponse.redirect(url, 303);
}
