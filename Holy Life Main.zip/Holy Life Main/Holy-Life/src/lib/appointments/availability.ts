import {
  addMinutes,
  timeToMinutes,
  weekdayForDateInput,
} from "@/lib/appointments/time";

export type ScheduleWindow = {
  id: string;
  weekday: number;
  startTime: string;
  endTime: string;
  slotMinutes: number;
  maxPatients: number;
  breakStart?: string | null;
  breakEnd?: string | null;
  isActive: boolean;
};

export type AvailabilityOverride = {
  kind: "AVAILABLE" | "BLOCKED" | "LEAVE";
  startTime?: string | null;
  endTime?: string | null;
  slotMinutes?: number | null;
  maxPatients?: number | null;
};

export type ExistingBooking = {
  startTime: string;
  status:
    | "PENDING"
    | "CONFIRMED"
    | "CHECKED_IN"
    | "IN_CONSULTATION"
    | "COMPLETED"
    | "CANCELLED"
    | "NO_SHOW";
};

export type AppointmentSlot = {
  startTime: string;
  endTime: string;
  capacity: number;
  booked: number;
  available: number;
};

const OCCUPYING_STATUSES = new Set<ExistingBooking["status"]>([
  "PENDING",
  "CONFIRMED",
  "CHECKED_IN",
  "IN_CONSULTATION",
  "COMPLETED",
]);

function overlapsBreak(
  start: number,
  end: number,
  breakStart?: string | null,
  breakEnd?: string | null,
): boolean {
  if (!breakStart || !breakEnd) return false;
  const breakStartMinutes = timeToMinutes(breakStart);
  const breakEndMinutes = timeToMinutes(breakEnd);
  return start < breakEndMinutes && end > breakStartMinutes;
}

function normalizeCapacity(value: number | null | undefined): number {
  return Math.max(1, Math.min(20, Math.trunc(value ?? 1)));
}

function normalizeSlotMinutes(value: number | null | undefined): number {
  return Math.max(5, Math.min(240, Math.trunc(value ?? 30)));
}

export function buildAppointmentSlots(input: {
  date: string;
  schedules: ScheduleWindow[];
  overrides?: AvailabilityOverride[];
  bookings?: ExistingBooking[];
}): AppointmentSlot[] {
  const overrides = input.overrides ?? [];
  const blockingOverride = overrides.find(
    (item) =>
      item.kind === "LEAVE" || (item.kind === "BLOCKED" && !item.startTime),
  );
  if (blockingOverride) return [];

  const availableOverrides = overrides.filter(
    (
      item,
    ): item is AvailabilityOverride & { startTime: string; endTime: string } =>
      item.kind === "AVAILABLE" && Boolean(item.startTime && item.endTime),
  );
  const windows: ScheduleWindow[] = availableOverrides.length
    ? availableOverrides.map((item, index) => ({
        id: `override-${index}`,
        weekday: weekdayForDateInput(input.date),
        startTime: item.startTime,
        endTime: item.endTime,
        slotMinutes: normalizeSlotMinutes(item.slotMinutes),
        maxPatients: normalizeCapacity(item.maxPatients),
        breakStart: null,
        breakEnd: null,
        isActive: true,
      }))
    : input.schedules.filter(
        (item) =>
          item.isActive && item.weekday === weekdayForDateInput(input.date),
      );

  const blockedRanges = overrides
    .filter(
      (
        item,
      ): item is AvailabilityOverride & {
        startTime: string;
        endTime: string;
      } => item.kind === "BLOCKED" && Boolean(item.startTime && item.endTime),
    )
    .map((item) => ({
      start: timeToMinutes(item.startTime),
      end: timeToMinutes(item.endTime),
    }));

  const bookingCounts = new Map<string, number>();
  for (const booking of input.bookings ?? []) {
    if (!OCCUPYING_STATUSES.has(booking.status)) continue;
    bookingCounts.set(
      booking.startTime,
      (bookingCounts.get(booking.startTime) ?? 0) + 1,
    );
  }

  const slots = new Map<string, AppointmentSlot>();
  for (const window of windows) {
    const start = timeToMinutes(window.startTime);
    const end = timeToMinutes(window.endTime);
    const slotMinutes = normalizeSlotMinutes(window.slotMinutes);
    const capacity = normalizeCapacity(window.maxPatients);
    if (end <= start) continue;

    for (
      let cursor = start;
      cursor + slotMinutes <= end;
      cursor += slotMinutes
    ) {
      const slotEnd = cursor + slotMinutes;
      if (overlapsBreak(cursor, slotEnd, window.breakStart, window.breakEnd))
        continue;
      if (
        blockedRanges.some(
          (range) => cursor < range.end && slotEnd > range.start,
        )
      )
        continue;
      const startTime = addMinutes("00:00", cursor);
      const endTime = addMinutes("00:00", slotEnd);
      const booked = bookingCounts.get(startTime) ?? 0;
      const existing = slots.get(startTime);
      const nextCapacity = Math.max(existing?.capacity ?? 0, capacity);
      slots.set(startTime, {
        startTime,
        endTime,
        capacity: nextCapacity,
        booked,
        available: Math.max(0, nextCapacity - booked),
      });
    }
  }

  return [...slots.values()].sort((left, right) =>
    left.startTime.localeCompare(right.startTime),
  );
}

export function findSlot(
  slots: AppointmentSlot[],
  startTime: string,
): AppointmentSlot | null {
  return slots.find((slot) => slot.startTime === startTime) ?? null;
}
