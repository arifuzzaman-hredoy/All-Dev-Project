import { randomInt } from "node:crypto";

export function generateAppointmentCode(
  date: Date,
  randomValue = randomInt(0, 1_000_000),
): string {
  const datePart = date.toISOString().slice(0, 10).replaceAll("-", "");
  return `HL-${datePart}-${String(randomValue).padStart(6, "0")}`;
}

export function generatePatientCode(
  randomValue = randomInt(0, 100_000_000),
): string {
  return `HLP-${String(randomValue).padStart(8, "0")}`;
}
