export const APPOINTMENT_STATUSES = [
  "PENDING",
  "CONFIRMED",
  "CHECKED_IN",
  "IN_CONSULTATION",
  "COMPLETED",
  "CANCELLED",
  "NO_SHOW",
] as const;

export type AppointmentStatusValue = (typeof APPOINTMENT_STATUSES)[number];

const TRANSITIONS: Record<AppointmentStatusValue, AppointmentStatusValue[]> = {
  PENDING: ["CONFIRMED", "CANCELLED"],
  CONFIRMED: ["CHECKED_IN", "CANCELLED", "NO_SHOW"],
  CHECKED_IN: ["IN_CONSULTATION", "CANCELLED", "NO_SHOW"],
  IN_CONSULTATION: ["COMPLETED", "CANCELLED"],
  COMPLETED: [],
  CANCELLED: [],
  NO_SHOW: [],
};

export function canTransitionAppointment(
  from: AppointmentStatusValue,
  to: AppointmentStatusValue,
): boolean {
  return from === to || TRANSITIONS[from].includes(to);
}

export function availableAppointmentTransitions(
  status: AppointmentStatusValue,
): AppointmentStatusValue[] {
  return TRANSITIONS[status];
}

export function appointmentStatusLabel(status: AppointmentStatusValue): string {
  return status
    .toLowerCase()
    .split("_")
    .map((part) => `${part[0]?.toUpperCase() ?? ""}${part.slice(1)}`)
    .join(" ");
}

export function appointmentStatusTone(
  status: AppointmentStatusValue,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "COMPLETED") return "success";
  if (status === "CANCELLED" || status === "NO_SHOW") return "danger";
  if (status === "PENDING") return "warning";
  if (
    status === "CONFIRMED" ||
    status === "CHECKED_IN" ||
    status === "IN_CONSULTATION"
  )
    return "info";
  return "neutral";
}
