const TIME_PATTERN = /^([01]\d|2[0-3]):([0-5]\d)$/;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

export function isTimeValue(value: string): boolean {
  return TIME_PATTERN.test(value);
}

export function timeToMinutes(value: string): number {
  const match = TIME_PATTERN.exec(value);
  if (!match) throw new Error(`Invalid time value: ${value}`);
  return Number(match[1]) * 60 + Number(match[2]);
}

export function minutesToTime(value: number): string {
  const normalized = Math.max(0, Math.min(23 * 60 + 59, Math.trunc(value)));
  return `${String(Math.floor(normalized / 60)).padStart(2, "0")}:${String(normalized % 60).padStart(2, "0")}`;
}

export function addMinutes(value: string, minutes: number): string {
  return minutesToTime(timeToMinutes(value) + minutes);
}

export function isDateInput(value: string): boolean {
  if (!DATE_PATTERN.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return (
    !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value
  );
}

export function dateInputToUtc(value: string): Date {
  if (!isDateInput(value)) throw new Error(`Invalid date value: ${value}`);
  return new Date(`${value}T00:00:00.000Z`);
}

export function utcDateToInput(value: Date): string {
  return value.toISOString().slice(0, 10);
}

export function weekdayForDateInput(value: string): number {
  return dateInputToUtc(value).getUTCDay();
}

export function todayInDhaka(now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
}

export function addDaysToDateInput(value: string, days: number): string {
  const date = dateInputToUtc(value);
  date.setUTCDate(date.getUTCDate() + days);
  return utcDateToInput(date);
}

export function compareDateInputs(left: string, right: string): number {
  return left.localeCompare(right);
}

export function formatDisplayDate(
  value: Date | string,
  locale = "en-GB",
): string {
  const date = typeof value === "string" ? dateInputToUtc(value) : value;
  return new Intl.DateTimeFormat(locale, {
    timeZone: "UTC",
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function formatDisplayTime(value: string, locale = "en-BD"): string {
  const minutes = timeToMinutes(value);
  const date = new Date(
    Date.UTC(2026, 0, 1, Math.floor(minutes / 60), minutes % 60),
  );
  return new Intl.DateTimeFormat(locale, {
    timeZone: "UTC",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(date);
}
