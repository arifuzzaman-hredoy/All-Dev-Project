import { Prisma } from "@/generated/prisma/client";
import {
  buildAppointmentSlots,
  findSlot,
} from "@/lib/appointments/availability";
import {
  generateAppointmentCode,
  generatePatientCode,
} from "@/lib/appointments/code";
import { dateInputToUtc } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export type CreateAppointmentInput = {
  doctorId: string;
  date: string;
  startTime: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string | null;
  serviceType: string;
  reason: string | null;
  notes?: string | null;
  userId?: string | null;
  actorId?: string | null;
  source: "PUBLIC" | "ADMIN";
  initialStatus: "PENDING" | "CONFIRMED";
};

export class AppointmentBookingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AppointmentBookingError";
  }
}

async function createWithinTransaction(
  tx: Prisma.TransactionClient,
  input: CreateAppointmentInput,
) {
  const appointmentDate = dateInputToUtc(input.date);
  const doctor = await tx.doctorProfile.findFirst({
    where: {
      id: input.doctorId,
      status: "ACTIVE",
      department: { isActive: true },
    },
    include: {
      department: true,
      schedules: { where: { isActive: true } },
      availability: { where: { date: appointmentDate } },
      appointments: {
        where: { appointmentDate },
        select: { startTime: true, status: true, slotNumber: true },
      },
    },
  });
  if (!doctor)
    throw new AppointmentBookingError("The selected doctor is not available.");

  const slots = buildAppointmentSlots({
    date: input.date,
    schedules: doctor.schedules,
    overrides: doctor.availability,
    bookings: doctor.appointments,
  });
  const slot = findSlot(slots, input.startTime);
  if (!slot || slot.available <= 0)
    throw new AppointmentBookingError(
      "That appointment slot is no longer available.",
    );

  const occupiedNumbers = new Set(
    doctor.appointments
      .filter(
        (appointment) =>
          appointment.startTime === input.startTime &&
          appointment.status !== "CANCELLED" &&
          appointment.status !== "NO_SHOW",
      )
      .map((appointment) => appointment.slotNumber),
  );
  let slotNumber = 1;
  while (slotNumber <= slot.capacity && occupiedNumbers.has(slotNumber))
    slotNumber += 1;
  if (slotNumber > slot.capacity)
    throw new AppointmentBookingError("That appointment slot is already full.");

  let patient = input.userId
    ? await tx.patientProfile.findUnique({ where: { userId: input.userId } })
    : await tx.patientProfile.findFirst({
        where: {
          phone: input.patientPhone,
          name: { equals: input.patientName, mode: "insensitive" },
          status: "ACTIVE",
        },
        orderBy: { updatedAt: "desc" },
      });

  if (patient) {
    patient = await tx.patientProfile.update({
      where: { id: patient.id },
      data: {
        name: input.patientName,
        phone: input.patientPhone,
        email: input.patientEmail,
        ...(input.userId ? { userId: input.userId } : {}),
        status: "ACTIVE",
      },
    });
  } else {
    patient = await tx.patientProfile.create({
      data: {
        userId: input.userId ?? null,
        patientCode: generatePatientCode(),
        name: input.patientName,
        phone: input.patientPhone,
        email: input.patientEmail,
      },
    });
  }

  const serialNumber = await tx.appointment.count({
    where: {
      doctorId: doctor.id,
      appointmentDate,
      status: { notIn: ["CANCELLED", "NO_SHOW"] },
    },
  });

  return tx.appointment.create({
    data: {
      code: generateAppointmentCode(appointmentDate),
      patientId: patient.id,
      userId: input.userId ?? null,
      doctorId: doctor.id,
      departmentId: doctor.departmentId,
      appointmentDate,
      startTime: slot.startTime,
      endTime: slot.endTime,
      slotNumber,
      serialNumber: serialNumber + 1,
      serviceType: input.serviceType,
      reason: input.reason,
      notes: input.notes ?? null,
      patientName: input.patientName,
      patientPhone: input.patientPhone,
      patientEmail: input.patientEmail,
      status: input.initialStatus,
      source: input.source,
      fee: doctor.consultationFee,
      createdById: input.actorId ?? null,
      updatedById: input.actorId ?? null,
    },
    include: { doctor: true, department: true },
  });
}

export async function createAppointment(input: CreateAppointmentInput) {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await db.$transaction((tx) => createWithinTransaction(tx, input), {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      });
    } catch (error) {
      if (error instanceof AppointmentBookingError) throw error;
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        ["P2002", "P2034"].includes(error.code) &&
        attempt < 3
      ) {
        continue;
      }
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      ) {
        throw new AppointmentBookingError(
          "That appointment slot was just booked. Select another time.",
        );
      }
      throw error;
    }
  }
  throw new AppointmentBookingError(
    "The appointment could not be reserved. Please try again.",
  );
}
