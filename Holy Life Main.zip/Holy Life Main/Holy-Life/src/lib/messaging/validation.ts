import type {
  MessagingChannel,
  MessagingPurpose,
} from "@/generated/prisma/client";

export const MESSAGING_CHANNELS = ["EMAIL", "SMS", "WHATSAPP"] as const;
export const MESSAGING_PURPOSES = ["SERVICE", "MARKETING"] as const;

export function messagingText(
  value: FormDataEntryValue | string | null,
  maxLength: number,
  label: string,
): string {
  const text = String(value ?? "").trim();
  if (!text) throw new Error(`${label} is required.`);
  if (text.length > maxLength)
    throw new Error(`${label} cannot exceed ${maxLength} characters.`);
  return text;
}

export function optionalMessagingText(
  value: FormDataEntryValue | string | null,
  maxLength: number,
): string | null {
  const text = String(value ?? "").trim();
  if (!text) return null;
  if (text.length > maxLength)
    throw new Error(`Value cannot exceed ${maxLength} characters.`);
  return text;
}

export function messagingChannel(
  value: FormDataEntryValue | string | null,
): MessagingChannel {
  const channel = String(value ?? "").toUpperCase();
  if (
    !MESSAGING_CHANNELS.includes(channel as (typeof MESSAGING_CHANNELS)[number])
  )
    throw new Error("Messaging channel is invalid.");
  return channel as MessagingChannel;
}

export function messagingPurpose(
  value: FormDataEntryValue | string | null,
): MessagingPurpose {
  const purpose = String(value ?? "SERVICE").toUpperCase();
  if (
    !MESSAGING_PURPOSES.includes(purpose as (typeof MESSAGING_PURPOSES)[number])
  )
    throw new Error("Messaging purpose is invalid.");
  return purpose as MessagingPurpose;
}

export function templateCode(
  value: FormDataEntryValue | string | null,
): string {
  const code = String(value ?? "")
    .trim()
    .toUpperCase();
  if (!/^[A-Z][A-Z0-9_]{2,79}$/.test(code)) {
    throw new Error(
      "Template code must be 3-80 characters using A-Z, 0-9, and underscore, starting with a letter.",
    );
  }
  return code;
}

export function scheduledDate(
  value: FormDataEntryValue | string | null,
): Date | null {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  const date = new Date(raw);
  if (Number.isNaN(date.getTime()))
    throw new Error("Scheduled time is invalid.");
  if (date.getTime() < Date.now() - 60_000)
    throw new Error("Scheduled time cannot be in the past.");
  return date;
}

export function maskedTarget(value: string): string {
  if (value.includes("@")) {
    const [local, domain] = value.split("@", 2);
    return `${local.slice(0, 2)}***@${domain ?? ""}`;
  }
  if (value.length <= 4) return "****";
  return `${"*".repeat(Math.max(4, value.length - 4))}${value.slice(-4)}`;
}
