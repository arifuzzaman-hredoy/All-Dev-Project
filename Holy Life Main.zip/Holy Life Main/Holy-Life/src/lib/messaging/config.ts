export type MessagingMode = "disabled" | "webhook";
export type ConfiguredMessagingChannel = "EMAIL" | "SMS" | "WHATSAPP";

function integerFromEnv(
  name: string,
  fallback: number,
  minimum: number,
  maximum: number,
): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(
      `${name} must be an integer between ${minimum} and ${maximum}.`,
    );
  }
  return value;
}

export function parseConfiguredChannels(
  raw = process.env.MESSAGING_AUTO_CHANNELS ?? "",
): ConfiguredMessagingChannel[] {
  const allowed = new Set<ConfiguredMessagingChannel>([
    "EMAIL",
    "SMS",
    "WHATSAPP",
  ]);
  const values = raw
    .split(",")
    .map((value) => value.trim().toUpperCase())
    .filter(Boolean);
  const result: ConfiguredMessagingChannel[] = [];
  for (const value of values) {
    if (!allowed.has(value as ConfiguredMessagingChannel)) {
      throw new Error(
        `MESSAGING_AUTO_CHANNELS contains unsupported channel '${value}'.`,
      );
    }
    if (!result.includes(value as ConfiguredMessagingChannel))
      result.push(value as ConfiguredMessagingChannel);
  }
  return result;
}

const mode = (process.env.MESSAGING_MODE ?? "disabled").toLowerCase();
if (!(["disabled", "webhook"] as const).includes(mode as MessagingMode)) {
  throw new Error("MESSAGING_MODE must be either 'disabled' or 'webhook'.");
}

export const messagingConfig = {
  mode: mode as MessagingMode,
  webhookUrl: process.env.MESSAGING_WEBHOOK_URL,
  webhookSecret: process.env.MESSAGING_WEBHOOK_SECRET,
  callbackSecret: process.env.MESSAGING_CALLBACK_SECRET,
  dispatchSecret: process.env.MESSAGING_DISPATCH_SECRET,
  autoChannels: parseConfiguredChannels(),
  maxAttempts: integerFromEnv("MESSAGING_MAX_ATTEMPTS", 5, 1, 12),
  dispatchBatchSize: integerFromEnv(
    "MESSAGING_DISPATCH_BATCH_SIZE",
    50,
    1,
    250,
  ),
  campaignMaxRecipients: integerFromEnv(
    "MESSAGING_CAMPAIGN_MAX_RECIPIENTS",
    5000,
    1,
    50000,
  ),
  retryBaseSeconds: integerFromEnv("MESSAGING_RETRY_BASE_SECONDS", 60, 5, 3600),
  providerTimeoutMs: integerFromEnv(
    "MESSAGING_PROVIDER_TIMEOUT_MS",
    10000,
    1000,
    60000,
  ),
  staleLockMinutes: integerFromEnv("MESSAGING_STALE_LOCK_MINUTES", 10, 1, 120),
} as const;
