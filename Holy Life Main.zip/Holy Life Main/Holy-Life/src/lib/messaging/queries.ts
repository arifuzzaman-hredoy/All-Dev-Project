import { db } from "@/lib/db";

export async function messagingAdminSnapshot(input: {
  includeTemplates: boolean;
  includeDeliveries: boolean;
}) {
  const templates = input.includeTemplates
    ? await db.messagingTemplate.findMany({
        orderBy: { updatedAt: "desc" },
        take: 30,
      })
    : [];
  const campaigns = await db.messagingCampaign.findMany({
    include: { template: { select: { code: true, name: true } } },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  const deliveries = input.includeDeliveries
    ? await db.messagingDelivery.findMany({
        include: {
          user: { select: { name: true } },
          campaign: { select: { code: true, name: true } },
        },
        orderBy: { createdAt: "desc" },
        take: 50,
      })
    : [];
  const queued = input.includeDeliveries
    ? await db.messagingDelivery.count({ where: { status: "QUEUED" } })
    : 0;
  const failed = input.includeDeliveries
    ? await db.messagingDelivery.count({ where: { status: "FAILED" } })
    : 0;
  return { templates, campaigns, deliveries, queued, failed };
}
