import { createHmac, timingSafeEqual } from "node:crypto";

function digest(secret: string, timestamp: string, body: string): Buffer {
  return createHmac("sha256", secret)
    .update(`${timestamp}.${body}`, "utf8")
    .digest();
}

export function signMessagingPayload(
  secret: string,
  timestamp: string,
  body: string,
): string {
  return `sha256=${digest(secret, timestamp, body).toString("hex")}`;
}

export function verifyMessagingSignature(input: {
  secret: string;
  timestamp: string;
  body: string;
  signature: string;
  nowMs?: number;
  toleranceSeconds?: number;
}): boolean {
  if (!/^\d{10,13}$/.test(input.timestamp)) return false;
  if (!input.signature.startsWith("sha256=")) return false;

  const numeric = Number(input.timestamp);
  const timestampMs = input.timestamp.length === 13 ? numeric : numeric * 1000;
  const toleranceMs = (input.toleranceSeconds ?? 300) * 1000;
  if (
    !Number.isFinite(timestampMs) ||
    Math.abs((input.nowMs ?? Date.now()) - timestampMs) > toleranceMs
  )
    return false;

  let supplied: Buffer;
  try {
    supplied = Buffer.from(input.signature.slice("sha256=".length), "hex");
  } catch {
    return false;
  }
  const expected = digest(input.secret, input.timestamp, input.body);
  return (
    supplied.length === expected.length && timingSafeEqual(supplied, expected)
  );
}
