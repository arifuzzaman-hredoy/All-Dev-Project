import { NextRequest, NextResponse } from "next/server";

export function messagingRedirect(
  request: NextRequest,
  path: string,
  key: "success" | "error",
  message: string,
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(key, message);
  return NextResponse.redirect(url, 303);
}
