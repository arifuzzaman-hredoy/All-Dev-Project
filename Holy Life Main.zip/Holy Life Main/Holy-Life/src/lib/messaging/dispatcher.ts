import type { MessagingDeliveryStatus } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { messagingConfig } from "@/lib/messaging/config";
import { signMessagingPayload } from "@/lib/messaging/signature";

function providerUrl(): URL {
  if (!messagingConfig.webhookUrl)
    throw new Error(
      "MESSAGING_WEBHOOK_URL is required when messaging webhook mode is enabled.",
    );
  const url = new URL(messagingConfig.webhookUrl);
  if (process.env.NODE_ENV === "production" && url.protocol !== "https:") {
    throw new Error("MESSAGING_WEBHOOK_URL must use HTTPS in production.");
  }
  return url;
}

function retryAt(attempt: number): Date {
  const seconds = Math.min(
    3600,
    messagingConfig.retryBaseSeconds * 2 ** Math.max(0, attempt - 1),
  );
  return new Date(Date.now() + seconds * 1000);
}

async function refreshCampaign(campaignId: string): Promise<void> {
  const campaign = await db.messagingCampaign.findUnique({
    where: { id: campaignId },
    select: { status: true },
  });
  if (!campaign) return;

  const grouped = await db.messagingDelivery.groupBy({
    by: ["status"],
    where: { campaignId },
    _count: { _all: true },
  });
  const counts = new Map(
    grouped.map((item) => [item.status, item._count._all]),
  );
  const queued = (counts.get("QUEUED") ?? 0) + (counts.get("SENDING") ?? 0);
  const sent = counts.get("SENT") ?? 0;
  const delivered = counts.get("DELIVERED") ?? 0;
  const failed = counts.get("FAILED") ?? 0;
  const canceled = counts.get("CANCELED") ?? 0;
  const terminal = sent + delivered + failed + canceled;
  const total = [...counts.values()].reduce((sum, count) => sum + count, 0);

  const isCanceled = campaign.status === "CANCELED";
  await db.messagingCampaign.update({
    where: { id: campaignId },
    data: {
      status: isCanceled ? "CANCELED" : queued > 0 ? "PROCESSING" : "COMPLETED",
      sentCount: sent + delivered,
      deliveredCount: delivered,
      failedCount: failed,
      completedAt:
        isCanceled || (total > 0 && terminal === total) ? new Date() : null,
    },
  });
}

async function deliverWebhook(delivery: {
  id: string;
  channel: "EMAIL" | "SMS" | "WHATSAPP";
  purpose: "SERVICE" | "MARKETING";
  target: string;
  subject: string | null;
  body: string;
  campaignId: string | null;
}) {
  if (!messagingConfig.webhookSecret)
    throw new Error(
      "MESSAGING_WEBHOOK_SECRET is required when messaging webhook mode is enabled.",
    );
  const body = JSON.stringify({
    deliveryId: delivery.id,
    campaignId: delivery.campaignId,
    channel: delivery.channel,
    purpose: delivery.purpose,
    target: delivery.target,
    subject: delivery.subject,
    body: delivery.body,
  });
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const response = await fetch(providerUrl(), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-holy-life-timestamp": timestamp,
      "x-holy-life-signature": signMessagingPayload(
        messagingConfig.webhookSecret,
        timestamp,
        body,
      ),
    },
    body,
    signal: AbortSignal.timeout(messagingConfig.providerTimeoutMs),
  });
  if (!response.ok)
    throw new Error(`Messaging provider returned HTTP ${response.status}.`);

  const raw = await response.text();
  if (!raw)
    return {
      status: "SENT" as const,
      providerMessageId: null,
      providerStatus: null,
    };
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Messaging provider returned invalid JSON.");
  }
  if (!data || typeof data !== "object")
    throw new Error("Messaging provider response is invalid.");
  const record = data as Record<string, unknown>;
  const status: MessagingDeliveryStatus =
    record.status === "DELIVERED" ? "DELIVERED" : "SENT";
  const providerMessageId =
    typeof record.providerMessageId === "string"
      ? record.providerMessageId.slice(0, 500)
      : null;
  const providerStatus =
    typeof record.status === "string" ? record.status.slice(0, 100) : null;
  return { status, providerMessageId, providerStatus };
}

export async function dispatchMessagingBatch(
  limit = messagingConfig.dispatchBatchSize,
) {
  if (messagingConfig.mode === "disabled") {
    return {
      disabled: true,
      processed: 0,
      sent: 0,
      delivered: 0,
      failed: 0,
      retried: 0,
    };
  }
  if (messagingConfig.mode !== "webhook")
    throw new Error("Unsupported messaging mode.");
  if (!messagingConfig.webhookSecret)
    throw new Error(
      "MESSAGING_WEBHOOK_SECRET is required when messaging webhook mode is enabled.",
    );
  providerUrl();

  const staleBefore = new Date(
    Date.now() - messagingConfig.staleLockMinutes * 60_000,
  );
  await db.messagingDelivery.updateMany({
    where: { status: "SENDING", lockedAt: { lt: staleBefore } },
    data: {
      status: "QUEUED",
      lockedAt: null,
      lastError: "Recovered from stale delivery lock.",
    },
  });

  const due = await db.messagingDelivery.findMany({
    where: { status: "QUEUED", nextAttemptAt: { lte: new Date() } },
    select: {
      id: true,
      campaignId: true,
      channel: true,
      purpose: true,
      target: true,
      subject: true,
      body: true,
      attemptCount: true,
      maxAttempts: true,
    },
    orderBy: [{ nextAttemptAt: "asc" }, { createdAt: "asc" }],
    take: Math.min(Math.max(1, limit), messagingConfig.dispatchBatchSize),
  });

  let sent = 0;
  let delivered = 0;
  let failed = 0;
  let retried = 0;
  const campaignIds = new Set<string>();

  for (const delivery of due) {
    const claimed = await db.messagingDelivery.updateMany({
      where: { id: delivery.id, status: "QUEUED" },
      data: { status: "SENDING", lockedAt: new Date() },
    });
    if (!claimed.count) continue;
    if (delivery.campaignId) campaignIds.add(delivery.campaignId);

    const attempt = delivery.attemptCount + 1;
    try {
      const result = await deliverWebhook(delivery);
      const now = new Date();
      await db.messagingDelivery.update({
        where: { id: delivery.id },
        data: {
          status: result.status,
          attemptCount: attempt,
          lockedAt: null,
          providerMessageId: result.providerMessageId,
          providerStatus: result.providerStatus,
          lastError: null,
          sentAt: now,
          deliveredAt: result.status === "DELIVERED" ? now : null,
          failedAt: null,
        },
      });
      if (result.status === "DELIVERED") delivered += 1;
      else sent += 1;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message.slice(0, 1000)
          : "Messaging provider delivery failed.";
      const terminal = attempt >= delivery.maxAttempts;
      const status: MessagingDeliveryStatus = terminal ? "FAILED" : "QUEUED";
      await db.messagingDelivery.update({
        where: { id: delivery.id },
        data: {
          status,
          attemptCount: attempt,
          lockedAt: null,
          lastError: message,
          nextAttemptAt: terminal ? new Date() : retryAt(attempt),
          failedAt: terminal ? new Date() : null,
        },
      });
      if (terminal) failed += 1;
      else retried += 1;
    }
  }

  for (const campaignId of campaignIds) await refreshCampaign(campaignId);
  return {
    disabled: false,
    processed: sent + delivered + failed + retried,
    sent,
    delivered,
    failed,
    retried,
  };
}

export async function applyProviderStatus(input: {
  deliveryId: string;
  providerMessageId?: string | null;
  status: "SENT" | "DELIVERED" | "FAILED";
  providerStatus?: string | null;
  error?: string | null;
}) {
  const delivery = await db.messagingDelivery.findUnique({
    where: { id: input.deliveryId },
    select: {
      id: true,
      campaignId: true,
      providerMessageId: true,
      status: true,
    },
  });
  if (!delivery) throw new Error("Messaging delivery was not found.");
  if (
    delivery.providerMessageId &&
    input.providerMessageId &&
    delivery.providerMessageId !== input.providerMessageId
  ) {
    throw new Error(
      "Provider message identifier does not match the delivery record.",
    );
  }
  if (delivery.status === "CANCELED" || delivery.status === "DELIVERED")
    return delivery;
  if (delivery.status === "FAILED" && input.status === "SENT") return delivery;

  const now = new Date();
  const updated = await db.messagingDelivery.update({
    where: { id: delivery.id },
    data: {
      status: input.status,
      providerMessageId: input.providerMessageId ?? delivery.providerMessageId,
      providerStatus: input.providerStatus?.slice(0, 100) ?? input.status,
      lastError:
        input.status === "FAILED"
          ? (input.error?.slice(0, 1000) ?? "Provider reported failure.")
          : null,
      lockedAt: null,
      sentAt:
        input.status === "SENT" || input.status === "DELIVERED"
          ? now
          : undefined,
      deliveredAt: input.status === "DELIVERED" ? now : undefined,
      failedAt: input.status === "FAILED" ? now : null,
    },
  });
  if (delivery.campaignId) await refreshCampaign(delivery.campaignId);
  return updated;
}
