const TOKEN = /\{\{\s*([a-zA-Z][a-zA-Z0-9_.-]{0,63})\s*\}\}/g;

export function templateVariables(text: string): string[] {
  return [...new Set(Array.from(text.matchAll(TOKEN), (match) => match[1]))];
}

export function renderMessageTemplate(
  text: string,
  variables: Record<string, string | null | undefined>,
): string {
  return text.replace(TOKEN, (_match, key: string) => {
    const value = variables[key];
    if (value === undefined || value === null)
      throw new Error(`Template variable '${key}' is not available.`);
    return value;
  });
}
