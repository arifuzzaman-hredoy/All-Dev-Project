import { randomUUID } from "node:crypto";
import type {
  DepartmentCode,
  MessagingAudience,
  MessagingChannel,
  MessagingPurpose,
} from "@/generated/prisma/client";
import { appOrigin } from "@/lib/auth/config";
import { db } from "@/lib/db";
import { messagingConfig } from "@/lib/messaging/config";
import { renderMessageTemplate } from "@/lib/messaging/template";

const PUBLIC_USER_WHERE = {
  status: "ACTIVE" as const,
  isSuperAdmin: false,
  roles: { none: { role: { isAdminRole: true } } },
};

type Recipient = {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  emailVerifiedAt: Date | null;
  phoneVerifiedAt: Date | null;
  messagingPreference: {
    emailEnabled: boolean;
    smsEnabled: boolean;
    whatsappEnabled: boolean;
    marketingEnabled: boolean;
  } | null;
};

function targetForChannel(
  user: Recipient,
  channel: MessagingChannel,
): string | null {
  if (channel === "EMAIL")
    return user.email && user.emailVerifiedAt ? user.email : null;
  if (channel === "SMS" || channel === "WHATSAPP")
    return user.phone && user.phoneVerifiedAt ? user.phone : null;
  return null;
}

function channelAllowed(
  user: Recipient,
  channel: MessagingChannel,
  purpose: MessagingPurpose,
): boolean {
  const preference = user.messagingPreference;
  if (purpose === "MARKETING" && preference?.marketingEnabled !== true)
    return false;
  if (channel === "EMAIL") return preference?.emailEnabled ?? true;
  if (channel === "SMS") return preference?.smsEnabled ?? true;
  return preference?.whatsappEnabled ?? false;
}

function variablesFor(user: Recipient): Record<string, string> {
  return {
    name: user.name,
    email: user.email ?? "",
    phone: user.phone ?? "",
    appUrl: appOrigin(),
  };
}

function campaignCode(): string {
  return `MSG-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`;
}

async function loadRecipientByIdentifier(
  identifier: string,
): Promise<Recipient | null> {
  const normalized = identifier.trim();
  if (!normalized) return null;
  return db.user.findFirst({
    where: {
      ...PUBLIC_USER_WHERE,
      OR: [{ email: normalized.toLowerCase() }, { phone: normalized }],
    },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      emailVerifiedAt: true,
      phoneVerifiedAt: true,
      messagingPreference: {
        select: {
          emailEnabled: true,
          smsEnabled: true,
          whatsappEnabled: true,
          marketingEnabled: true,
        },
      },
    },
  });
}

async function loadAudience(
  audience: MessagingAudience,
  recipient: string | null,
): Promise<Recipient[]> {
  if (audience === "USER") {
    const user = await loadRecipientByIdentifier(recipient ?? "");
    return user ? [user] : [];
  }

  const users = await db.user.findMany({
    where: PUBLIC_USER_WHERE,
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      emailVerifiedAt: true,
      phoneVerifiedAt: true,
      messagingPreference: {
        select: {
          emailEnabled: true,
          smsEnabled: true,
          whatsappEnabled: true,
          marketingEnabled: true,
        },
      },
    },
    orderBy: { createdAt: "asc" },
    take: messagingConfig.campaignMaxRecipients + 1,
  });

  if (users.length > messagingConfig.campaignMaxRecipients) {
    throw new Error(
      `Campaign exceeds the configured recipient limit of ${messagingConfig.campaignMaxRecipients}.`,
    );
  }
  return users;
}

export async function queueMessagingCampaign(input: {
  actorId: string;
  name: string;
  channel: MessagingChannel;
  purpose: MessagingPurpose;
  audience: MessagingAudience;
  recipient?: string | null;
  department?: DepartmentCode | null;
  templateId?: string | null;
  subject?: string | null;
  body?: string | null;
  scheduledAt?: Date | null;
}) {
  const template = input.templateId
    ? await db.messagingTemplate.findFirst({
        where: { id: input.templateId, status: "ACTIVE" },
        select: { id: true, channel: true, subject: true, body: true },
      })
    : null;

  if (input.templateId && !template)
    throw new Error("The selected template is not active or no longer exists.");
  if (template && template.channel !== input.channel)
    throw new Error("Template channel does not match the campaign channel.");

  const subjectSource = template?.subject ?? input.subject ?? null;
  const bodySource = template?.body ?? input.body ?? null;
  if (!bodySource)
    throw new Error("A message body or active template is required.");
  if (input.channel === "EMAIL" && !subjectSource)
    throw new Error("Email campaigns require a subject.");

  const audienceUsers = await loadAudience(
    input.audience,
    input.recipient ?? null,
  );
  const recipients = audienceUsers
    .map((user) => ({ user, target: targetForChannel(user, input.channel) }))
    .filter((item): item is { user: Recipient; target: string } =>
      Boolean(item.target),
    )
    .filter(({ user }) => channelAllowed(user, input.channel, input.purpose));

  if (!recipients.length) {
    throw new Error(
      "No eligible verified recipient is opted in for this channel and purpose.",
    );
  }

  const campaign = await db.$transaction(async (tx) => {
    const created = await tx.messagingCampaign.create({
      data: {
        code: campaignCode(),
        name: input.name,
        channel: input.channel,
        purpose: input.purpose,
        audience: input.audience,
        department: input.department ?? null,
        templateId: template?.id ?? null,
        recipient: input.audience === "USER" ? (input.recipient ?? null) : null,
        subject: template ? null : (input.subject ?? null),
        body: template ? null : (input.body ?? null),
        scheduledAt: input.scheduledAt ?? null,
        recipientCount: recipients.length,
        createdById: input.actorId,
      },
    });

    const nextAttemptAt = input.scheduledAt ?? new Date();
    for (let index = 0; index < recipients.length; index += 500) {
      const batch = recipients
        .slice(index, index + 500)
        .map(({ user, target }) => {
          const variables = variablesFor(user);
          return {
            campaignId: created.id,
            templateId: template?.id ?? null,
            userId: user.id,
            channel: input.channel,
            purpose: input.purpose,
            target,
            subject: subjectSource
              ? renderMessageTemplate(subjectSource, variables)
              : null,
            body: renderMessageTemplate(bodySource, variables),
            dedupeKey: `campaign:${created.id}:${user.id}:${input.channel}`,
            maxAttempts: messagingConfig.maxAttempts,
            nextAttemptAt,
          };
        });
      await tx.messagingDelivery.createMany({ data: batch });
    }

    return created;
  });

  return { campaign, recipients: recipients.length };
}

export async function queueAutomaticMessaging(input: {
  userId: string;
  dedupeKey: string;
  department?: DepartmentCode | null;
  title: string;
  message?: string | null;
  href?: string | null;
}): Promise<void> {
  if (!messagingConfig.autoChannels.length) return;

  const user = await db.user.findFirst({
    where: { id: input.userId, status: "ACTIVE" },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      emailVerifiedAt: true,
      phoneVerifiedAt: true,
      messagingPreference: {
        select: {
          emailEnabled: true,
          smsEnabled: true,
          whatsappEnabled: true,
          marketingEnabled: true,
        },
      },
    },
  });
  if (!user) return;

  const bodyParts = [input.title];
  if (input.message) bodyParts.push(input.message);
  if (input.href)
    bodyParts.push(
      `${appOrigin()}${input.href.startsWith("/") ? input.href : `/${input.href}`}`,
    );
  const body = bodyParts.join("\n\n");

  for (const channel of messagingConfig.autoChannels) {
    if (!channelAllowed(user, channel, "SERVICE")) continue;
    const target = targetForChannel(user, channel);
    if (!target) continue;

    await db.messagingDelivery.upsert({
      where: { dedupeKey: `auto:${channel}:${user.id}:${input.dedupeKey}` },
      update: {},
      create: {
        userId: user.id,
        channel,
        purpose: "SERVICE",
        target,
        subject: channel === "EMAIL" ? input.title : null,
        body,
        dedupeKey: `auto:${channel}:${user.id}:${input.dedupeKey}`,
        maxAttempts: messagingConfig.maxAttempts,
      },
    });
  }
}

export async function saveMessagingPreference(input: {
  userId: string;
  emailEnabled: boolean;
  smsEnabled: boolean;
  whatsappEnabled: boolean;
  marketingEnabled: boolean;
}) {
  return db.messagingPreference.upsert({
    where: { userId: input.userId },
    update: {
      emailEnabled: input.emailEnabled,
      smsEnabled: input.smsEnabled,
      whatsappEnabled: input.whatsappEnabled,
      marketingEnabled: input.marketingEnabled,
    },
    create: input,
  });
}

export async function retryMessagingDelivery(deliveryId: string) {
  const delivery = await db.messagingDelivery.findUnique({
    where: { id: deliveryId },
    select: { status: true, campaign: { select: { status: true } } },
  });
  if (!delivery || delivery.status !== "FAILED")
    throw new Error("Only failed deliveries can be retried.");
  if (delivery.campaign?.status === "CANCELED")
    throw new Error("Canceled campaign deliveries cannot be retried.");

  const result = await db.messagingDelivery.updateMany({
    where: { id: deliveryId, status: "FAILED" },
    data: {
      status: "QUEUED",
      nextAttemptAt: new Date(),
      lockedAt: null,
      failedAt: null,
      lastError: null,
      maxAttempts: { increment: 1 },
    },
  });
  if (!result.count) throw new Error("Only failed deliveries can be retried.");
}
