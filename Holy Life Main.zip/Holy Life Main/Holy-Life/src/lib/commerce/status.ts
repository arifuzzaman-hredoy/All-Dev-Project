export type CommerceOrderState =
  | "PENDING"
  | "CONFIRMED"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED"
  | "REFUNDED";
const transitions: Record<CommerceOrderState, CommerceOrderState[]> = {
  PENDING: ["CONFIRMED", "CANCELLED"],
  CONFIRMED: ["PROCESSING", "CANCELLED"],
  PROCESSING: ["SHIPPED", "CANCELLED"],
  SHIPPED: ["DELIVERED"],
  DELIVERED: ["REFUNDED"],
  CANCELLED: [],
  REFUNDED: [],
};
export function canTransitionOrder(
  from: CommerceOrderState,
  to: CommerceOrderState,
): boolean {
  return transitions[from].includes(to);
}
export function assertOrderTransition(
  from: CommerceOrderState,
  to: CommerceOrderState,
): void {
  if (!canTransitionOrder(from, to))
    throw new Error(`Order cannot move from ${from} to ${to}.`);
}
export function canCustomerCancel(status: CommerceOrderState): boolean {
  return status === "PENDING" || status === "CONFIRMED";
}
export function orderStatusLabel(status: CommerceOrderState): string {
  return status
    .toLowerCase()
    .replaceAll("_", " ")
    .replace(/\b\w/g, (value) => value.toUpperCase());
}

export type RefundState = "REQUESTED" | "APPROVED" | "REJECTED" | "COMPLETED";
const refundTransitions: Record<RefundState, RefundState[]> = {
  REQUESTED: ["APPROVED", "REJECTED"],
  APPROVED: ["COMPLETED", "REJECTED"],
  REJECTED: [],
  COMPLETED: [],
};
export function canTransitionRefund(
  from: RefundState,
  to: RefundState,
): boolean {
  return refundTransitions[from].includes(to);
}
export function assertRefundTransition(
  from: RefundState,
  to: RefundState,
): void {
  if (!canTransitionRefund(from, to))
    throw new Error(`Refund cannot move from ${from} to ${to}.`);
}
