import { Prisma } from "@/generated/prisma/client";
import { generateOrderCode } from "@/lib/commerce/code";
import { couponDiscount, lineTotal, money } from "@/lib/commerce/money";
import { applyStockDelta, availableStock } from "@/lib/commerce/stock";
import {
  assertOrderTransition,
  canCustomerCancel,
  type CommerceOrderState,
} from "@/lib/commerce/status";
import { db } from "@/lib/db";
import {
  gatewayAmount,
  GatewayValidationError,
} from "@/lib/payments/gateway/validation";

export class CommerceError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CommerceError";
  }
}

export async function addCartItem(
  userId: string,
  variantId: string,
  quantity: number,
) {
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100)
    throw new CommerceError("Quantity is invalid.");
  return db.$transaction(
    async (tx) => {
      const variant = await tx.productVariant.findFirst({
        where: {
          id: variantId,
          isActive: true,
          product: { status: "ACTIVE", category: { isActive: true } },
        },
      });
      if (!variant) throw new CommerceError("Product option is unavailable.");
      const cart = await tx.commerceCart.upsert({
        where: { userId },
        update: {},
        create: { userId },
      });
      const existing = await tx.commerceCartItem.findUnique({
        where: { cartId_variantId: { cartId: cart.id, variantId } },
      });
      const nextQuantity = (existing?.quantity ?? 0) + quantity;
      if (
        nextQuantity >
        availableStock(variant.stockOnHand, variant.reservedStock)
      )
        throw new CommerceError("Requested quantity is not available.");
      return tx.commerceCartItem.upsert({
        where: { cartId_variantId: { cartId: cart.id, variantId } },
        update: { quantity: nextQuantity },
        create: { cartId: cart.id, variantId, quantity },
      });
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}

export async function updateCartItem(
  userId: string,
  itemId: string,
  quantity: number,
) {
  return db.$transaction(
    async (tx) => {
      const item = await tx.commerceCartItem.findFirst({
        where: { id: itemId, cart: { userId } },
        include: { variant: true },
      });
      if (!item) throw new CommerceError("Cart item was not found.");
      if (quantity <= 0) {
        await tx.commerceCartItem.delete({ where: { id: item.id } });
        return null;
      }
      if (!Number.isInteger(quantity) || quantity > 100)
        throw new CommerceError("Quantity is invalid.");
      if (
        quantity >
        availableStock(item.variant.stockOnHand, item.variant.reservedStock)
      )
        throw new CommerceError("Requested quantity is not available.");
      return tx.commerceCartItem.update({
        where: { id: item.id },
        data: { quantity },
      });
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}

export type CheckoutInput = {
  userId: string;
  checkoutKey: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string | null;
  addressLine1: string;
  addressLine2: string | null;
  area: string | null;
  city: string;
  district: string | null;
  postalCode: string | null;
  shippingMethodId: string;
  couponCode: string | null;
  paymentMethod: "CASH_ON_DELIVERY" | "MANUAL_PAYMENT" | "ONLINE_GATEWAY";
  manualPaymentReference: string | null;
  customerNote: string | null;
};

async function checkoutTransaction(
  tx: Prisma.TransactionClient,
  input: CheckoutInput,
) {
  const duplicate = await tx.commerceOrder.findUnique({
    where: { checkoutKey: input.checkoutKey },
    include: { items: true },
  });
  if (duplicate) {
    if (duplicate.userId !== input.userId)
      throw new CommerceError("Checkout key is invalid.");
    return duplicate;
  }
  const cart = await tx.commerceCart.findUnique({
    where: { userId: input.userId },
    include: {
      items: { include: { variant: { include: { product: true } } } },
    },
  });
  if (!cart || cart.items.length === 0)
    throw new CommerceError("Your cart is empty.");
  const shipping = await tx.shippingMethod.findFirst({
    where: { id: input.shippingMethodId, isActive: true },
  });
  if (!shipping) throw new CommerceError("Shipping method is unavailable.");

  let subtotal = 0;
  for (const item of cart.items) {
    if (!item.variant.isActive || item.variant.product.status !== "ACTIVE")
      throw new CommerceError(`${item.variant.product.name} is unavailable.`);
    if (
      item.quantity >
      availableStock(item.variant.stockOnHand, item.variant.reservedStock)
    )
      throw new CommerceError(
        `${item.variant.product.name} does not have enough stock.`,
      );
    subtotal += lineTotal(item.variant.price.toString(), item.quantity);
  }
  subtotal = money(subtotal);

  let coupon: Awaited<ReturnType<typeof tx.coupon.findFirst>> = null;
  let discountTotal = 0;
  const now = new Date();
  if (input.couponCode) {
    coupon = await tx.coupon.findFirst({
      where: {
        code: input.couponCode.toUpperCase(),
        isActive: true,
        AND: [
          { OR: [{ startsAt: null }, { startsAt: { lte: now } }] },
          { OR: [{ endsAt: null }, { endsAt: { gte: now } }] },
        ],
      },
    });
    if (!coupon) throw new CommerceError("Coupon is invalid or expired.");
    if (coupon.minimumSubtotal && subtotal < Number(coupon.minimumSubtotal))
      throw new CommerceError(
        "Order subtotal does not meet the coupon minimum.",
      );
    const totalUses = await tx.couponRedemption.count({
      where: { couponId: coupon.id },
    });
    const userUses = await tx.couponRedemption.count({
      where: { couponId: coupon.id, userId: input.userId },
    });
    if (coupon.usageLimit != null && totalUses >= coupon.usageLimit)
      throw new CommerceError("Coupon usage limit has been reached.");
    if (userUses >= coupon.perUserLimit)
      throw new CommerceError("You have already used this coupon.");
    discountTotal = couponDiscount({
      subtotal,
      type: coupon.type,
      value: coupon.value.toString(),
      maximumDiscount: coupon.maximumDiscount?.toString(),
    });
  }
  const shippingTotal =
    shipping.freeAbove && subtotal >= Number(shipping.freeAbove)
      ? 0
      : Number(shipping.fee);
  const taxTotal = money(
    cart.items.reduce(
      (sum, item) =>
        sum +
        lineTotal(item.variant.price.toString(), item.quantity) *
          (Number(item.variant.product.taxRate) / 100),
      0,
    ),
  );
  const grandTotal = money(subtotal - discountTotal + shippingTotal + taxTotal);

  if (input.paymentMethod === "ONLINE_GATEWAY") {
    try {
      gatewayAmount(grandTotal);
    } catch (error) {
      if (error instanceof GatewayValidationError)
        throw new CommerceError(error.message);
      throw error;
    }
  }

  const address = await tx.commerceAddress.create({
    data: {
      userId: input.userId,
      recipientName: input.customerName,
      phone: input.customerPhone,
      addressLine1: input.addressLine1,
      addressLine2: input.addressLine2,
      area: input.area,
      city: input.city,
      district: input.district,
      postalCode: input.postalCode,
    },
  });
  const order = await tx.commerceOrder.create({
    data: {
      code: generateOrderCode(),
      checkoutKey: input.checkoutKey,
      userId: input.userId,
      addressId: address.id,
      shippingMethodId: shipping.id,
      couponId: coupon?.id ?? null,
      paymentMethod: input.paymentMethod,
      paymentStatus:
        input.paymentMethod === "MANUAL_PAYMENT"
          ? "PENDING_VERIFICATION"
          : "UNPAID",
      manualPaymentReference: input.manualPaymentReference,
      subtotal,
      discountTotal,
      shippingTotal,
      taxTotal,
      grandTotal,
      customerName: input.customerName,
      customerPhone: input.customerPhone,
      customerEmail: input.customerEmail,
      shippingAddress: {
        addressLine1: input.addressLine1,
        addressLine2: input.addressLine2,
        area: input.area,
        city: input.city,
        district: input.district,
        postalCode: input.postalCode,
      },
      customerNote: input.customerNote,
      items: {
        create: cart.items.map((item) => ({
          productId: item.variant.productId,
          variantId: item.variantId,
          productName: item.variant.product.name,
          variantName: item.variant.name,
          sku: item.variant.sku,
          unitPrice: item.variant.price,
          quantity: item.quantity,
          lineTotal: lineTotal(item.variant.price.toString(), item.quantity),
          attributes:
            item.variant.attributes == null
              ? undefined
              : (item.variant.attributes as Prisma.InputJsonValue),
        })),
      },
      statusHistory: {
        create: {
          toStatus: "PENDING",
          actorId: input.userId,
          note: "Order submitted by customer.",
        },
      },
    },
    include: { items: true },
  });

  for (const item of cart.items) {
    const balanceAfter = applyStockDelta(
      item.variant.stockOnHand,
      -item.quantity,
    );
    await tx.productVariant.update({
      where: { id: item.variantId },
      data: { stockOnHand: balanceAfter },
    });
    await tx.stockMovement.create({
      data: {
        variantId: item.variantId,
        type: "SALE",
        quantity: -item.quantity,
        balanceAfter,
        referenceType: "CommerceOrder",
        referenceId: order.id,
        note: `Order ${order.code}`,
        createdById: input.userId,
      },
    });
  }
  if (coupon)
    await tx.couponRedemption.create({
      data: {
        couponId: coupon.id,
        userId: input.userId,
        orderId: order.id,
        amount: discountTotal,
      },
    });
  await tx.commerceCartItem.deleteMany({ where: { cartId: cart.id } });
  return order;
}

export async function checkout(input: CheckoutInput) {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await db.$transaction((tx) => checkoutTransaction(tx, input), {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 20_000,
      });
    } catch (error) {
      if (error instanceof CommerceError) throw error;
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        ["P2002", "P2034"].includes(error.code) &&
        attempt < 3
      )
        continue;
      throw error;
    }
  }
  throw new CommerceError("Checkout could not be completed. Please try again.");
}

export async function adjustStock(input: {
  variantId: string;
  quantity: number;
  type:
    | "PURCHASE"
    | "ADJUSTMENT_IN"
    | "ADJUSTMENT_OUT"
    | "RETURN_IN"
    | "DAMAGE_OUT";
  note: string | null;
  actorId: string;
}) {
  return db.$transaction(
    async (tx) => {
      const variant = await tx.productVariant.findUnique({
        where: { id: input.variantId },
      });
      if (!variant) throw new CommerceError("Variant not found.");
      const delta = ["ADJUSTMENT_OUT", "DAMAGE_OUT"].includes(input.type)
        ? -input.quantity
        : input.quantity;
      const balanceAfter = applyStockDelta(variant.stockOnHand, delta);
      await tx.productVariant.update({
        where: { id: variant.id },
        data: { stockOnHand: balanceAfter },
      });
      return tx.stockMovement.create({
        data: {
          variantId: variant.id,
          type: input.type,
          quantity: delta,
          balanceAfter,
          note: input.note,
          createdById: input.actorId,
        },
      });
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}

export async function transitionOrderStatus(input: {
  orderId: string;
  nextStatus: CommerceOrderState;
  actorId: string;
  note: string | null;
  customerUserId?: string;
}) {
  return db.$transaction(
    async (tx) => {
      const order = await tx.commerceOrder.findFirst({
        where: {
          id: input.orderId,
          ...(input.customerUserId ? { userId: input.customerUserId } : {}),
        },
        include: { items: true },
      });
      if (!order) throw new CommerceError("Order was not found.");
      if (order.status === input.nextStatus) {
        return { order, changed: false, previousStatus: order.status };
      }
      if (
        input.customerUserId &&
        (!canCustomerCancel(order.status) || input.nextStatus !== "CANCELLED")
      ) {
        throw new CommerceError("This order can no longer be cancelled.");
      }
      if (input.nextStatus === "REFUNDED") {
        throw new CommerceError(
          "Complete an approved refund request instead of changing the order directly.",
        );
      }
      assertOrderTransition(order.status, input.nextStatus);

      if (input.nextStatus === "CANCELLED") {
        const existing = await tx.stockMovement.count({
          where: {
            referenceType: "CommerceOrderCancellation",
            referenceId: order.id,
          },
        });
        if (existing === 0) {
          for (const item of order.items) {
            const variant = await tx.productVariant.findUnique({
              where: { id: item.variantId },
            });
            if (!variant)
              throw new CommerceError(
                `Variant ${item.sku} was not found while returning stock.`,
              );
            const balanceAfter = applyStockDelta(
              variant.stockOnHand,
              item.quantity,
            );
            await tx.productVariant.update({
              where: { id: variant.id },
              data: { stockOnHand: balanceAfter },
            });
            await tx.stockMovement.create({
              data: {
                variantId: variant.id,
                type: "SALE_REVERSAL",
                quantity: item.quantity,
                balanceAfter,
                referenceType: "CommerceOrderCancellation",
                referenceId: order.id,
                note: `Stock returned for ${order.code}`,
                createdById: input.actorId,
              },
            });
          }
        }
      }

      const now = new Date();
      const updated = await tx.commerceOrder.update({
        where: { id: order.id },
        data: {
          status: input.nextStatus,
          updatedById: input.actorId,
          confirmedAt:
            input.nextStatus === "CONFIRMED" ? now : order.confirmedAt,
          shippedAt: input.nextStatus === "SHIPPED" ? now : order.shippedAt,
          deliveredAt:
            input.nextStatus === "DELIVERED" ? now : order.deliveredAt,
          cancelledAt:
            input.nextStatus === "CANCELLED" ? now : order.cancelledAt,
          cancellationReason:
            input.nextStatus === "CANCELLED"
              ? input.note
              : order.cancellationReason,
        },
      });
      await tx.orderStatusHistory.create({
        data: {
          orderId: order.id,
          fromStatus: order.status,
          toStatus: input.nextStatus,
          actorId: input.actorId,
          note: input.note,
        },
      });
      return { order: updated, changed: true, previousStatus: order.status };
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}
