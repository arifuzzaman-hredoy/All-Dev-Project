export function requiredText(form: FormData, key: string, max = 200): string {
  const value = String(form.get(key) ?? "").trim();
  if (!value || value.length > max) throw new Error(`${key} is required.`);
  return value;
}
export function optionalText(
  form: FormData,
  key: string,
  max = 1000,
): string | null {
  const value = String(form.get(key) ?? "").trim();
  if (!value) return null;
  if (value.length > max) throw new Error(`${key} is too long.`);
  return value;
}
export function positiveInteger(
  form: FormData,
  key: string,
  fallback = 1,
  max = 100000,
): number {
  const raw = String(form.get(key) ?? "").trim();
  const value = raw ? Number(raw) : fallback;
  if (!Number.isInteger(value) || value < 1 || value > max)
    throw new Error(`${key} is invalid.`);
  return value;
}
export function nonNegativeInteger(
  form: FormData,
  key: string,
  fallback = 0,
  max = 1000000,
): number {
  const raw = String(form.get(key) ?? "").trim();
  const value = raw ? Number(raw) : fallback;
  if (!Number.isInteger(value) || value < 0 || value > max)
    throw new Error(`${key} is invalid.`);
  return value;
}
export function nonNegativeMoney(
  form: FormData,
  key: string,
  fallback = 0,
): number {
  const raw = String(form.get(key) ?? "").trim();
  const value = raw ? Number(raw) : fallback;
  if (!Number.isFinite(value) || value < 0 || value > 100000000)
    throw new Error(`${key} is invalid.`);
  return Math.round(value * 100) / 100;
}
export function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 100);
}
