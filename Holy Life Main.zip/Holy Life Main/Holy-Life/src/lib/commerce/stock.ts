export function availableStock(
  stockOnHand: number,
  reservedStock: number,
): number {
  return Math.max(0, stockOnHand - reservedStock);
}
export function applyStockDelta(current: number, delta: number): number {
  if (!Number.isInteger(current) || !Number.isInteger(delta))
    throw new Error("Stock values must be integers.");
  const next = current + delta;
  if (next < 0) throw new Error("Stock cannot become negative.");
  return next;
}
export function stockMovementDelta(
  type:
    | "OPENING"
    | "PURCHASE"
    | "SALE"
    | "SALE_REVERSAL"
    | "ADJUSTMENT_IN"
    | "ADJUSTMENT_OUT"
    | "RETURN_IN"
    | "DAMAGE_OUT",
  quantity: number,
): number {
  if (!Number.isInteger(quantity) || quantity < 1)
    throw new Error("Movement quantity must be positive.");
  return ["SALE", "ADJUSTMENT_OUT", "DAMAGE_OUT"].includes(type)
    ? -quantity
    : quantity;
}
