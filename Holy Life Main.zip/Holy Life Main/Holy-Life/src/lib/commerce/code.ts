import { randomBytes } from "node:crypto";
export function generateOrderCode(now = new Date()): string {
  const date = now.toISOString().slice(0, 10).replaceAll("-", "");
  return `HL-${date}-${randomBytes(3).toString("hex").toUpperCase()}`;
}
export function generateCheckoutKey(userId: string): string {
  return `${userId}:${Date.now()}:${randomBytes(8).toString("hex")}`;
}
