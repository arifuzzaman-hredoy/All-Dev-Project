export type MoneyInput = number | string | { toString(): string };

export function money(value: MoneyInput): number {
  const parsed = typeof value === "number" ? value : Number(value.toString());
  if (!Number.isFinite(parsed)) throw new Error("Invalid money value.");
  return Math.round((parsed + Number.EPSILON) * 100) / 100;
}

export function formatMoney(
  value: MoneyInput,
  currency = "BDT",
  locale = "en-BD",
): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    maximumFractionDigits: 2,
  }).format(money(value));
}

export function lineTotal(unitPrice: MoneyInput, quantity: number): number {
  if (!Number.isInteger(quantity) || quantity < 1)
    throw new Error("Quantity must be a positive integer.");
  return money(money(unitPrice) * quantity);
}

export function couponDiscount(input: {
  subtotal: MoneyInput;
  type: "FIXED" | "PERCENTAGE";
  value: MoneyInput;
  maximumDiscount?: MoneyInput | null;
}): number {
  const subtotal = money(input.subtotal);
  if (subtotal <= 0) return 0;
  const raw =
    input.type === "PERCENTAGE"
      ? subtotal * (money(input.value) / 100)
      : money(input.value);
  const capped =
    input.maximumDiscount == null
      ? raw
      : Math.min(raw, money(input.maximumDiscount));
  return money(Math.max(0, Math.min(subtotal, capped)));
}
