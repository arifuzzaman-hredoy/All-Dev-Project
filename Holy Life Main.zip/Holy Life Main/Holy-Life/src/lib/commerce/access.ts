import { Prisma } from "@/generated/prisma/client";
import type { AuthenticatedUser } from "@/lib/auth/session";
import { effectiveDataScope } from "@/lib/rbac/scope";

export function commerceOrderAccessWhere(
  user: AuthenticatedUser,
): Prisma.CommerceOrderWhereInput {
  if (user.isSuperAdmin) return {};
  const scope = effectiveDataScope(user.roles.map((role) => role.dataScope));
  if (["ALL", "BRANCH", "DEPARTMENT"].includes(scope)) return {};
  return { updatedById: user.id };
}
