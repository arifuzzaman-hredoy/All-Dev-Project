import { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";

export async function listStoreProducts(
  input: {
    category?: string | null;
    q?: string | null;
    featured?: boolean;
  } = {},
) {
  const where: Prisma.ProductWhereInput = {
    status: "ACTIVE",
    category: {
      isActive: true,
      ...(input.category ? { slug: input.category } : {}),
    },
    ...(input.featured ? { isFeatured: true } : {}),
    ...(input.q
      ? {
          OR: [
            { name: { contains: input.q, mode: "insensitive" } },
            { nameBn: { contains: input.q, mode: "insensitive" } },
            { shortDescription: { contains: input.q, mode: "insensitive" } },
            { shortDescriptionBn: { contains: input.q, mode: "insensitive" } },
            {
              variants: {
                some: {
                  sku: { contains: input.q, mode: "insensitive" },
                  isActive: true,
                },
              },
            },
          ],
        }
      : {}),
  };
  return db.product.findMany({
    where,
    include: {
      category: true,
      brand: true,
      images: {
        orderBy: [{ isPrimary: "desc" }, { position: "asc" }],
        take: 1,
      },
      variants: {
        where: { isActive: true },
        orderBy: [{ isDefault: "desc" }, { price: "asc" }],
      },
      reviews: { where: { status: "PUBLISHED" }, select: { rating: true } },
    },
    orderBy: [{ isFeatured: "desc" }, { displayOrder: "asc" }, { name: "asc" }],
  });
}

export async function getStoreProduct(slug: string) {
  return db.product.findFirst({
    where: { slug, status: "ACTIVE", category: { isActive: true } },
    include: {
      category: true,
      brand: true,
      images: { orderBy: [{ isPrimary: "desc" }, { position: "asc" }] },
      variants: {
        where: { isActive: true },
        orderBy: [{ isDefault: "desc" }, { price: "asc" }],
      },
      reviews: {
        where: { status: "PUBLISHED" },
        include: { user: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        take: 20,
      },
    },
  });
}

export async function getCart(userId: string) {
  return db.commerceCart.findUnique({
    where: { userId },
    include: {
      items: {
        include: {
          variant: {
            include: {
              product: {
                include: {
                  images: {
                    orderBy: [{ isPrimary: "desc" }, { position: "asc" }],
                    take: 1,
                  },
                },
              },
            },
          },
        },
        orderBy: { createdAt: "asc" },
      },
    },
  });
}

export async function listCustomerOrders(
  userId: string,
  mode: "all" | "active" | "history" = "all",
) {
  const where: Prisma.CommerceOrderWhereInput = { userId };
  if (mode === "active")
    where.status = { in: ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED"] };
  if (mode === "history")
    where.status = { in: ["DELIVERED", "CANCELLED", "REFUNDED"] };
  return db.commerceOrder.findMany({
    where,
    include: { items: true },
    orderBy: { createdAt: "desc" },
  });
}

export async function getCustomerOrder(userId: string, code: string) {
  return db.commerceOrder.findFirst({
    where: { userId, code },
    include: {
      items: { include: { product: true } },
      statusHistory: { orderBy: { createdAt: "asc" } },
      refundRequests: true,
    },
  });
}

export async function commerceSummary() {
  const [
    products,
    activeProducts,
    lowStock,
    pendingOrders,
    totalOrders,
    revenue,
  ] = await Promise.all([
    db.product.count({ where: { status: { not: "ARCHIVED" } } }),
    db.product.count({ where: { status: "ACTIVE" } }),
    db.productVariant.count({
      where: { isActive: true, stockOnHand: { lte: 5 } },
    }),
    db.commerceOrder.count({
      where: { status: { in: ["PENDING", "CONFIRMED", "PROCESSING"] } },
    }),
    db.commerceOrder.count(),
    db.commerceOrder.aggregate({
      where: {
        status: { in: ["DELIVERED", "SHIPPED", "PROCESSING", "CONFIRMED"] },
      },
      _sum: { grandTotal: true },
    }),
  ]);
  return {
    products,
    activeProducts,
    lowStock,
    pendingOrders,
    totalOrders,
    revenue: Number(revenue._sum.grandTotal ?? 0),
  };
}
