import type { IconName } from "@/components/ui/icon";

export type NavigationItem = {
  id: string;
  label: string;
  href?: string;
  icon?: IconName;
  badge?: string;
  children?: NavigationItem[];
};

export const dashboardNavigation: NavigationItem[] = [
  {
    id: "dashboard-overview",
    label: "Overview",
    href: "/dashboard",
    icon: "dashboard",
  },
  {
    id: "dashboard-healthcare",
    label: "Healthcare",
    icon: "heart",
    children: [
      {
        id: "dashboard-appointments",
        label: "Appointments",
        href: "/dashboard/healthcare/appointments",
        children: [
          {
            id: "dashboard-upcoming-appointments",
            label: "Upcoming",
            href: "/dashboard/healthcare/appointments/upcoming",
          },
          {
            id: "dashboard-appointment-history",
            label: "History",
            href: "/dashboard/healthcare/appointments/history",
          },
        ],
      },
      {
        id: "dashboard-prescriptions",
        label: "Prescriptions",
        href: "/dashboard/healthcare/prescriptions",
      },
      {
        id: "dashboard-health-records",
        label: "Health records",
        href: "/dashboard/healthcare/records",
      },
      {
        id: "dashboard-wellness",
        label: "Wellness programs",
        href: "/dashboard/healthcare/programs",
      },
    ],
  },
  {
    id: "dashboard-learning",
    label: "Learning",
    icon: "learning",
    children: [
      {
        id: "dashboard-my-courses",
        label: "My courses",
        href: "/dashboard/learning/courses",
        children: [
          {
            id: "dashboard-active-courses",
            label: "In progress",
            href: "/dashboard/learning/courses/active",
          },
          {
            id: "dashboard-completed-courses",
            label: "Completed",
            href: "/dashboard/learning/courses/completed",
          },
        ],
      },
      {
        id: "dashboard-resources",
        label: "Resources",
        href: "/dashboard/learning/resources",
      },
      {
        id: "dashboard-certificates",
        label: "Certificates",
        href: "/dashboard/learning/certificates",
      },
    ],
  },
  {
    id: "dashboard-shopping",
    label: "Shopping",
    icon: "shop",
    children: [
      {
        id: "dashboard-orders",
        label: "My orders",
        href: "/dashboard/shopping/orders",
        children: [
          {
            id: "dashboard-active-orders",
            label: "Active orders",
            href: "/dashboard/shopping/orders/active",
          },
          {
            id: "dashboard-order-history",
            label: "Order history",
            href: "/dashboard/shopping/orders/history",
          },
        ],
      },
      {
        id: "dashboard-payments",
        label: "Payments",
        href: "/dashboard/shopping/payments",
      },
      {
        id: "dashboard-refunds",
        label: "Refund requests",
        href: "/dashboard/shopping/refunds",
      },
    ],
  },
  {
    id: "dashboard-activity",
    label: "Activity",
    href: "/dashboard/activity",
    icon: "activity",
  },
  {
    id: "dashboard-payments-unified",
    label: "Payments",
    href: "/dashboard/payments",
    icon: "file",
  },
  {
    id: "dashboard-saved",
    label: "Saved items",
    href: "/dashboard/saved",
    icon: "heart",
  },
  {
    id: "dashboard-notifications",
    label: "Notifications",
    href: "/dashboard/notifications",
    icon: "bell",
  },
  {
    id: "dashboard-support",
    label: "Support",
    href: "/dashboard/support",
    icon: "message",
  },
  {
    id: "dashboard-profile",
    label: "Profile & security",
    href: "/dashboard/profile",
    icon: "profile",
    children: [
      {
        id: "dashboard-profile-overview",
        label: "Profile",
        href: "/dashboard/profile",
      },
      {
        id: "dashboard-profile-addresses",
        label: "Address book",
        href: "/dashboard/profile/addresses",
      },
      {
        id: "dashboard-profile-security",
        label: "Security & sessions",
        href: "/dashboard/profile/security",
      },
    ],
  },
];

export const adminNavigation: NavigationItem[] = [
  {
    id: "admin-overview",
    label: "Dashboard",
    href: "/admin",
    icon: "dashboard",
  },
  {
    id: "admin-healthcare",
    label: "Doctor & appointment",
    icon: "doctor",
    children: [
      {
        id: "admin-doctors",
        label: "Doctors",
        href: "/admin/healthcare/doctors",
        children: [
          {
            id: "admin-doctor-list",
            label: "Doctor profiles",
            href: "/admin/healthcare/doctors",
          },
          {
            id: "admin-doctor-create",
            label: "Add doctor",
            href: "/admin/healthcare/doctors/create",
          },
          {
            id: "admin-medical-departments",
            label: "Departments",
            href: "/admin/healthcare/departments",
          },
          {
            id: "admin-doctor-schedules",
            label: "Schedules",
            href: "/admin/healthcare/schedules",
          },
        ],
      },
      {
        id: "admin-appointments",
        label: "Appointment management",
        href: "/admin/healthcare/appointments",
        children: [
          {
            id: "admin-all-appointments",
            label: "All appointments",
            href: "/admin/healthcare/appointments/all",
          },
          {
            id: "admin-pending-appointments",
            label: "Pending requests",
            href: "/admin/healthcare/appointments/pending",
            badge: "8",
          },
          {
            id: "admin-appointment-schedule",
            label: "Schedule",
            href: "/admin/healthcare/appointments/schedule",
          },
        ],
      },
      {
        id: "admin-patients",
        label: "Patient management",
        href: "/admin/healthcare/patients",
        children: [
          {
            id: "admin-patient-list",
            label: "Patient list",
            href: "/admin/healthcare/patients",
          },
          {
            id: "admin-patient-history",
            label: "Visit history",
            href: "/admin/healthcare/patients/history",
          },
          {
            id: "admin-health-records",
            label: "Health records",
            href: "/admin/healthcare/patients/records",
          },
        ],
      },
      {
        id: "admin-prescriptions",
        label: "Prescription",
        href: "/admin/healthcare/prescriptions",
        children: [
          {
            id: "admin-create-prescription",
            label: "Create prescription",
            href: "/admin/healthcare/prescriptions/create",
          },
          {
            id: "admin-prescription-history",
            label: "Prescription history",
            href: "/admin/healthcare/prescriptions/history",
          },
        ],
      },
      {
        id: "admin-wellness",
        label: "Wellness programs",
        href: "/admin/healthcare/programs",
      },
    ],
  },
  {
    id: "admin-commerce",
    label: "E-commerce",
    icon: "shop",
    children: [
      {
        id: "admin-products",
        label: "Product management",
        href: "/admin/commerce/products",
        children: [
          {
            id: "admin-product-list",
            label: "Products",
            href: "/admin/commerce/products",
          },
          {
            id: "admin-product-create",
            label: "Add product",
            href: "/admin/commerce/products/create",
          },
          {
            id: "admin-product-categories",
            label: "Categories & brands",
            href: "/admin/commerce/products/categories",
          },
          {
            id: "admin-inventory",
            label: "Inventory",
            href: "/admin/commerce/products/inventory",
          },
        ],
      },
      {
        id: "admin-orders",
        label: "Order management",
        href: "/admin/commerce/orders",
        children: [
          {
            id: "admin-all-orders",
            label: "All orders",
            href: "/admin/commerce/orders",
          },
          {
            id: "admin-pending-orders",
            label: "Pending orders",
            href: "/admin/commerce/orders/pending",
          },
          {
            id: "admin-returns",
            label: "Returns & refunds",
            href: "/admin/commerce/orders/returns",
          },
        ],
      },
      {
        id: "admin-commerce-payments",
        label: "Payments",
        href: "/admin/commerce/payments",
      },
      {
        id: "admin-coupons",
        label: "Coupons",
        href: "/admin/commerce/coupons",
      },
      {
        id: "admin-commerce-settings",
        label: "Shipping settings",
        href: "/admin/commerce/settings",
      },
      {
        id: "admin-reviews",
        label: "Reviews",
        href: "/admin/commerce/reviews",
      },
      {
        id: "admin-commerce-reports",
        label: "Reports",
        href: "/admin/commerce/reports",
      },
    ],
  },
  {
    id: "admin-learning",
    label: "Course management",
    icon: "learning",
    children: [
      {
        id: "admin-courses",
        label: "Courses",
        href: "/admin/learning/courses",
        children: [
          {
            id: "admin-course-list",
            label: "All courses",
            href: "/admin/learning/courses/all",
          },
          {
            id: "admin-course-create",
            label: "Create course",
            href: "/admin/learning/courses/create",
          },
          {
            id: "admin-course-categories",
            label: "Categories",
            href: "/admin/learning/courses/categories",
          },
          {
            id: "admin-course-content",
            label: "Lessons & content",
            href: "/admin/learning/courses/content",
          },
        ],
      },
      {
        id: "admin-enrollments",
        label: "Enrollments",
        href: "/admin/learning/enrollments",
        children: [
          {
            id: "admin-students",
            label: "Students",
            href: "/admin/learning/enrollments/students",
          },
          {
            id: "admin-progress",
            label: "Progress",
            href: "/admin/learning/enrollments/progress",
          },
          {
            id: "admin-completion",
            label: "Completion",
            href: "/admin/learning/enrollments/completion",
          },
        ],
      },
      {
        id: "admin-assessments",
        label: "Assessments",
        href: "/admin/learning/assessments",
      },
      {
        id: "admin-certificates",
        label: "Certificates",
        href: "/admin/learning/certificates",
      },
    ],
  },
  {
    id: "admin-website",
    label: "Website management",
    href: "/admin/website",
    icon: "globe",
  },
  {
    id: "admin-messages",
    label: "Communications",
    href: "/admin/messages",
    icon: "message",
  },
  {
    id: "admin-finance",
    label: "Finance & reports",
    icon: "reports",
    children: [
      {
        id: "admin-finance-gateways",
        label: "Online gateway",
        href: "/admin/finance/gateways",
      },
      {
        id: "admin-finance-payments",
        label: "Manual payments",
        href: "/admin/finance/payments",
      },
      {
        id: "admin-finance-transactions",
        label: "Transactions",
        href: "/admin/finance/transactions",
      },
      {
        id: "admin-finance-reports",
        label: "Revenue reports",
        href: "/admin/reports",
      },
    ],
  },
  {
    id: "admin-notifications",
    label: "Notifications",
    href: "/admin/notifications",
    icon: "bell",
  },
  {
    id: "admin-insights",
    label: "Insights & operations",
    icon: "dashboard",
    children: [
      {
        id: "admin-platform-analytics",
        label: "Platform analytics",
        href: "/admin/analytics",
      },
      {
        id: "admin-audit-trail",
        label: "Audit trail",
        href: "/admin/audit",
      },
      {
        id: "admin-backup-assurance",
        label: "Backup assurance",
        href: "/admin/operations/backups",
      },
      {
        id: "admin-launch-readiness",
        label: "Launch readiness",
        href: "/admin/launch-readiness",
      },
    ],
  },
  {
    id: "admin-settings",
    label: "Settings",
    href: "/admin/settings",
    icon: "settings",
  },
];

export const superAdminNavigation: NavigationItem[] = [
  {
    id: "super-admin-overview",
    label: "System overview",
    href: "/super-admin",
    icon: "dashboard",
  },
  {
    id: "super-admin-administration",
    label: "Administration",
    icon: "users",
    children: [
      {
        id: "super-admin-admins",
        label: "Admin management",
        href: "/super-admin/administration/admins",
        children: [
          {
            id: "super-admin-admin-list",
            label: "All admins",
            href: "/super-admin/administration/admins",
          },
          {
            id: "super-admin-create-admin",
            label: "Create admin",
            href: "/super-admin/administration/admins/create",
          },
          {
            id: "super-admin-admin-sessions",
            label: "Sessions",
            href: "/super-admin/security",
          },
        ],
      },
      {
        id: "super-admin-roles",
        label: "Roles & permissions",
        href: "/super-admin/administration/roles",
        children: [
          {
            id: "super-admin-role-presets",
            label: "All roles",
            href: "/super-admin/administration/roles",
          },
          {
            id: "super-admin-permission-matrix",
            label: "Create custom role",
            href: "/super-admin/administration/roles/create",
          },
        ],
      },
    ],
  },
  {
    id: "super-admin-control",
    label: "Platform control",
    icon: "settings",
    children: [
      {
        id: "super-admin-departments",
        label: "Departments",
        href: "/super-admin/control/departments",
      },
      {
        id: "super-admin-dashboard-control",
        label: "User dashboard",
        href: "/super-admin/control/dashboard",
      },
      {
        id: "super-admin-admin-control",
        label: "Admin panel",
        href: "/super-admin/control/admin-panel",
      },
      {
        id: "super-admin-public-site",
        label: "Public website",
        href: "/super-admin/control/public-site",
      },
      {
        id: "super-admin-navigation",
        label: "Navigation",
        href: "/super-admin/control/navigation",
      },
    ],
  },
  {
    id: "super-admin-department-data",
    label: "Department control",
    icon: "inventory",
    children: [
      {
        id: "super-admin-healthcare",
        label: "Healthcare",
        href: "/super-admin/departments/healthcare",
      },
      {
        id: "super-admin-commerce",
        label: "E-commerce",
        href: "/super-admin/departments/commerce",
      },
      {
        id: "super-admin-learning",
        label: "Course & learning",
        href: "/super-admin/departments/learning",
      },
    ],
  },
  {
    id: "super-admin-audit",
    label: "Audit logs",
    href: "/super-admin/audit",
    icon: "clipboard",
  },
  {
    id: "super-admin-security",
    label: "Security",
    href: "/super-admin/security",
    icon: "shield",
  },
  {
    id: "super-admin-backup",
    label: "Backup",
    href: "/super-admin/backup",
    icon: "file",
  },
  {
    id: "super-admin-settings",
    label: "Global settings",
    href: "/super-admin/settings",
    icon: "settings",
  },
];
