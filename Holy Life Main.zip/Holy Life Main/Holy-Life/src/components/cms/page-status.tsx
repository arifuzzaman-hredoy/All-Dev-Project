import { StatusBadge } from "@/components/ui/panel-ui";

export function WebsitePageStatusBadge({
  status,
}: {
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
}) {
  const tone =
    status === "PUBLISHED"
      ? "success"
      : status === "ARCHIVED"
        ? "neutral"
        : "warning";
  return <StatusBadge tone={tone}>{status}</StatusBadge>;
}
