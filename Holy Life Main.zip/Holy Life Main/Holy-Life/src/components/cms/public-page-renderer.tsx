import Link from "next/link";
import { Fragment, type ReactNode } from "react";
import { Icon, type IconName } from "@/components/ui/icon";
import { readItems, readString } from "@/lib/cms/content";
import type {
  CmsSectionContent,
  PublicWebsitePage,
  PublicWebsiteSection,
} from "@/lib/cms/types";
import { localizeDefaultCmsText } from "@/lib/i18n/default-cms";
import { uiText } from "@/lib/i18n/dictionary";
import type { Locale } from "@/lib/i18n/config";
import { getUiPreferences } from "@/lib/i18n/server";

const ICONS = new Set<IconName>([
  "activity",
  "appointment",
  "arrow-left",
  "arrow-right",
  "bell",
  "book",
  "calendar",
  "cart",
  "chevron-down",
  "chevron-right",
  "clipboard",
  "close",
  "dashboard",
  "doctor",
  "file",
  "globe",
  "heart",
  "home",
  "inventory",
  "learning",
  "lock",
  "logout",
  "menu",
  "message",
  "monitor",
  "moon",
  "package",
  "permission",
  "profile",
  "reports",
  "search",
  "settings",
  "shield",
  "shop",
  "sun",
  "users",
]);

function iconName(value: unknown): IconName {
  return typeof value === "string" && ICONS.has(value as IconName)
    ? (value as IconName)
    : "heart";
}

function safeHref(value: unknown, fallback = "#"): string {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  if (trimmed.startsWith("/") && !trimmed.startsWith("//")) return trimmed;
  if (
    trimmed.startsWith("https://") ||
    trimmed.startsWith("mailto:") ||
    trimmed.startsWith("tel:")
  )
    return trimmed;
  return fallback;
}

function localize(locale: Locale, value: string): string {
  return localizeDefaultCmsText(locale, value);
}

function localizedString(
  locale: Locale,
  content: CmsSectionContent,
  key: string,
  fallback = "",
): string {
  return localize(locale, readString(content, key, fallback));
}

function SectionHeading({
  content,
  locale,
}: {
  content: CmsSectionContent;
  locale: Locale;
}) {
  const eyebrow = localizedString(locale, content, "eyebrow");
  const title = localizedString(locale, content, "title");
  const description = localizedString(locale, content, "description");
  if (!eyebrow && !title && !description) return null;
  return (
    <div className="public-section-heading">
      {eyebrow ? <span>{eyebrow}</span> : null}
      {title ? <h2>{title}</h2> : null}
      {description ? <p>{description}</p> : null}
    </div>
  );
}

type HeroVisualVariant =
  "health" | "doctors" | "appointment" | "learning" | "commerce" | "about";

function heroVariant(section: PublicWebsiteSection): HeroVisualVariant {
  const content = section.content;
  const tone = readString(content, "tone", "health").toLowerCase();
  const haystack =
    `${section.title} ${readString(content, "title")} ${readString(content, "eyebrow")}`.toLowerCase();
  if (haystack.includes("appointment") || haystack.includes("booking"))
    return "appointment";
  if (haystack.includes("doctor") || haystack.includes("clinical"))
    return "doctors";
  if (
    tone === "learning" ||
    haystack.includes("course") ||
    haystack.includes("learning")
  )
    return "learning";
  if (
    tone === "commerce" ||
    haystack.includes("shop") ||
    haystack.includes("product")
  )
    return "commerce";
  if (haystack.includes("about") || haystack.includes("mission"))
    return "about";
  return "health";
}

function HeroVisual({
  variant,
  locale,
}: {
  variant: HeroVisualVariant;
  locale: Locale;
}) {
  const variants: Record<
    HeroVisualVariant,
    {
      icon: IconName;
      titleKey: Parameters<typeof uiText>[1];
      descriptionKey: Parameters<typeof uiText>[1];
      points: Array<{ icon: IconName; en: string; bn: string }>;
    }
  > = {
    health: {
      icon: "heart",
      titleKey: "hero.healthTitle",
      descriptionKey: "hero.healthDescription",
      points: [
        {
          icon: "doctor",
          en: "Doctor-led guidance",
          bn: "চিকিৎসকের নির্দেশনা",
        },
        {
          icon: "learning",
          en: "Practical learning",
          bn: "ব্যবহারিক স্বাস্থ্যশিক্ষা",
        },
        { icon: "shop", en: "Wellness choices", bn: "সুস্থতার প্রয়োজনীয় পণ্য" },
      ],
    },
    doctors: {
      icon: "doctor",
      titleKey: "hero.doctorsTitle",
      descriptionKey: "hero.doctorsDescription",
      points: [
        { icon: "profile", en: "Clear profiles", bn: "পরিষ্কার প্রোফাইল" },
        {
          icon: "activity",
          en: "Specialty & experience",
          bn: "বিশেষত্ব ও অভিজ্ঞতা",
        },
        { icon: "appointment", en: "Booking path", bn: "সহজ অ্যাপয়েন্টমেন্ট" },
      ],
    },
    appointment: {
      icon: "appointment",
      titleKey: "hero.appointmentTitle",
      descriptionKey: "hero.appointmentDescription",
      points: [
        { icon: "calendar", en: "Live schedule", bn: "হালনাগাদ সময়সূচি" },
        { icon: "doctor", en: "Doctor selection", bn: "ডাক্তার নির্বাচন" },
        { icon: "shield", en: "Protected history", bn: "সুরক্ষিত ইতিহাস" },
      ],
    },
    learning: {
      icon: "learning",
      titleKey: "hero.learningTitle",
      descriptionKey: "hero.learningDescription",
      points: [
        { icon: "book", en: "Structured lessons", bn: "গোছানো পাঠ" },
        { icon: "activity", en: "Progress tracking", bn: "অগ্রগতি অনুসরণ" },
        {
          icon: "file",
          en: "Assessments & certificates",
          bn: "মূল্যায়ন ও সনদ",
        },
      ],
    },
    commerce: {
      icon: "shop",
      titleKey: "hero.commerceTitle",
      descriptionKey: "hero.commerceDescription",
      points: [
        { icon: "inventory", en: "Controlled stock", bn: "নিয়ন্ত্রিত স্টক" },
        { icon: "cart", en: "Clear checkout", bn: "সহজ চেকআউট" },
        { icon: "package", en: "Order tracking", bn: "অর্ডার অনুসরণ" },
      ],
    },
    about: {
      icon: "globe",
      titleKey: "hero.aboutTitle",
      descriptionKey: "hero.aboutDescription",
      points: [
        { icon: "heart", en: "Healthcare", bn: "স্বাস্থ্যসেবা" },
        { icon: "learning", en: "Learning", bn: "স্বাস্থ্যশিক্ষা" },
        { icon: "shop", en: "Commerce", bn: "কেনাকাটা" },
      ],
    },
  };
  const item = variants[variant];
  return (
    <div
      className={`cms-hero-visual cms-hero-visual-${variant}`}
      aria-hidden="true"
    >
      <div className="cms-hero-visual-head">
        <span>
          <Icon name={item.icon} size={28} />
        </span>
        <div>
          <small>Holy Life</small>
          <strong>{uiText(locale, item.titleKey)}</strong>
        </div>
      </div>
      <p>{uiText(locale, item.descriptionKey)}</p>
      <div className="cms-hero-visual-list">
        {item.points.map((point) => (
          <div key={point.en}>
            <span>
              <Icon name={point.icon} size={17} />
            </span>
            <strong>{locale === "bn" ? point.bn : point.en}</strong>
          </div>
        ))}
      </div>
      <div className="cms-hero-visual-orbit">
        <i />
        <i />
        <i />
      </div>
    </div>
  );
}

function HeroSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const content = section.content;
  const tone = readString(content, "tone", "health");
  const primaryLabel = localizedString(locale, content, "primaryLabel");
  const secondaryLabel = localizedString(locale, content, "secondaryLabel");
  const variant = heroVariant(section);
  return (
    <section
      className={`cms-hero cms-hero-${tone} cms-hero-context-${variant}`}
    >
      <div className="public-container cms-hero-grid">
        <div className="cms-hero-copy">
          {readString(content, "eyebrow") ? (
            <span className="public-eyebrow">
              {localizedString(locale, content, "eyebrow")}
            </span>
          ) : null}
          <h1>{localizedString(locale, content, "title", section.title)}</h1>
          {readString(content, "description") ? (
            <p>{localizedString(locale, content, "description")}</p>
          ) : null}
          {primaryLabel || secondaryLabel ? (
            <div className="public-hero-actions">
              {primaryLabel ? (
                <Link
                  className="public-primary-button public-primary-button-large"
                  href={safeHref(content.primaryHref, "/register")}
                >
                  {primaryLabel}
                  <Icon name="arrow-right" size={18} />
                </Link>
              ) : null}
              {secondaryLabel ? (
                <Link
                  className="public-secondary-button"
                  href={safeHref(content.secondaryHref, "/about")}
                >
                  {secondaryLabel}
                </Link>
              ) : null}
            </div>
          ) : null}
        </div>
        <HeroVisual locale={locale} variant={variant} />
      </div>
    </section>
  );
}

function RichTextSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const content = section.content;
  const paragraphs = readString(content, "body")
    .split(/\n\s*\n/)
    .map((value) => localize(locale, value.trim()))
    .filter(Boolean);
  return (
    <section className="public-section cms-rich-section">
      <div className="public-container cms-rich-grid">
        <SectionHeading content={content} locale={locale} />
        <div className="cms-rich-copy">
          {paragraphs.map((paragraph, index) => (
            <p key={`${section.id}-${index}`}>{paragraph}</p>
          ))}
        </div>
      </div>
    </section>
  );
}

function GridSection({
  section,
  locale,
  cards = false,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
  cards?: boolean;
}) {
  const items = readItems(section.content);
  const journeyLike =
    items.length === 3 && items.every((item) => typeof item.title === "string");
  return (
    <section className={`public-section ${cards ? "public-section-soft" : ""}`}>
      <div className="public-container">
        <SectionHeading content={section.content} locale={locale} />
        <div
          className={`${cards ? "cms-card-grid" : "public-department-grid"} ${journeyLike ? "cms-card-grid-journey" : ""}`}
        >
          {items.map((item, index) => {
            const title = localize(
              locale,
              typeof item.title === "string"
                ? item.title
                : locale === "bn"
                  ? `আইটেম ${index + 1}`
                  : `Item ${index + 1}`,
            );
            const description = localize(
              locale,
              typeof item.description === "string" ? item.description : "",
            );
            const label = localize(
              locale,
              typeof item.label === "string" ? item.label : "",
            );
            const href = safeHref(item.href);
            const tone =
              typeof item.tone === "string"
                ? item.tone
                : index === 1
                  ? "learning"
                  : index === 2
                    ? "commerce"
                    : "health";
            return (
              <article
                className={`${cards ? "cms-content-card" : "public-department-card"} cms-tone-${tone}`}
                key={`${section.id}-${index}`}
              >
                <span
                  className={
                    cards ? "cms-content-card-icon" : "public-department-icon"
                  }
                >
                  <Icon name={iconName(item.icon)} size={23} />
                </span>
                <h3>{title}</h3>
                {description ? <p>{description}</p> : null}
                {label && href !== "#" ? (
                  <Link href={href}>
                    {label}
                    <Icon name="arrow-right" size={17} />
                  </Link>
                ) : null}
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function StatsSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const items = readItems(section.content);
  return (
    <section className="public-trust-strip">
      <div className="public-container public-trust-grid">
        {items.map((item, index) => (
          <div key={`${section.id}-${index}`}>
            <strong>{typeof item.value === "string" ? item.value : "—"}</strong>
            <span>
              {localize(
                locale,
                typeof item.label === "string"
                  ? item.label
                  : locale === "bn"
                    ? "তথ্য"
                    : "Metric",
              )}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

function CtaSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const content = section.content;
  const primaryLabel = localizedString(locale, content, "primaryLabel");
  const secondaryLabel = localizedString(locale, content, "secondaryLabel");
  return (
    <section className="public-cta-section">
      <div className="public-container public-cta-card">
        <div>
          {readString(content, "eyebrow") ? (
            <span>{localizedString(locale, content, "eyebrow")}</span>
          ) : null}
          <h2>{localizedString(locale, content, "title", section.title)}</h2>
          {readString(content, "description") ? (
            <p>{localizedString(locale, content, "description")}</p>
          ) : null}
        </div>
        <div className="public-hero-actions">
          {primaryLabel ? (
            <Link
              className="public-primary-button public-primary-button-light"
              href={safeHref(content.primaryHref, "/register")}
            >
              {primaryLabel}
            </Link>
          ) : null}
          {secondaryLabel ? (
            <Link
              className="public-secondary-button public-secondary-button-dark"
              href={safeHref(content.secondaryHref, "/about")}
            >
              {secondaryLabel}
            </Link>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function FaqSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const items = readItems(section.content);
  return (
    <section className="public-section public-section-soft">
      <div className="public-container cms-faq-wrap">
        <SectionHeading content={section.content} locale={locale} />
        <div className="cms-faq-list">
          {items.map((item, index) => (
            <details key={`${section.id}-${index}`}>
              <summary>
                {localize(
                  locale,
                  typeof item.question === "string"
                    ? item.question
                    : locale === "bn"
                      ? "প্রশ্ন"
                      : "Question",
                )}
              </summary>
              <p>
                {localize(
                  locale,
                  typeof item.answer === "string" ? item.answer : "",
                )}
              </p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection({
  section,
  locale,
}: {
  section: PublicWebsiteSection;
  locale: Locale;
}) {
  const content = section.content;
  const contactItems = [
    {
      icon: "message" as IconName,
      label: locale === "bn" ? "ইমেইল" : "Email",
      value: readString(content, "email"),
      href: `mailto:${readString(content, "email")}`,
    },
    {
      icon: "appointment" as IconName,
      label: locale === "bn" ? "ফোন" : "Phone",
      value: readString(content, "phone"),
      href: `tel:${readString(content, "phone").replace(/\s/g, "")}`,
    },
    {
      icon: "home" as IconName,
      label: locale === "bn" ? "ঠিকানা" : "Address",
      value: localize(locale, readString(content, "address")),
      href: "#",
    },
    {
      icon: "calendar" as IconName,
      label: locale === "bn" ? "সময়" : "Hours",
      value: localize(locale, readString(content, "hours")),
      href: "#",
    },
  ];
  return (
    <section className="public-section cms-contact-section">
      <div className="public-container cms-contact-grid">
        <SectionHeading content={content} locale={locale} />
        <div className="cms-contact-list">
          {contactItems
            .filter((item) => item.value)
            .map((item) => (
              <div key={item.label}>
                <span>
                  <Icon name={item.icon} size={21} />
                </span>
                <div>
                  <strong>{item.label}</strong>
                  {item.href === "#" ? (
                    <p>{item.value}</p>
                  ) : (
                    <Link href={item.href}>{item.value}</Link>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>
    </section>
  );
}

function renderSection(section: PublicWebsiteSection, locale: Locale) {
  switch (section.type) {
    case "HERO":
      return <HeroSection key={section.id} locale={locale} section={section} />;
    case "RICH_TEXT":
      return (
        <RichTextSection key={section.id} locale={locale} section={section} />
      );
    case "FEATURE_GRID":
      return <GridSection key={section.id} locale={locale} section={section} />;
    case "CARD_GRID":
      return (
        <GridSection cards key={section.id} locale={locale} section={section} />
      );
    case "STATS":
      return (
        <StatsSection key={section.id} locale={locale} section={section} />
      );
    case "CTA":
      return <CtaSection key={section.id} locale={locale} section={section} />;
    case "FAQ":
      return <FaqSection key={section.id} locale={locale} section={section} />;
    case "CONTACT":
      return (
        <ContactSection key={section.id} locale={locale} section={section} />
      );
  }
}

export async function PublicPageRenderer({
  page,
  insertBeforeFinalCta,
  hideFinalCta = false,
}: {
  page: PublicWebsitePage;
  insertBeforeFinalCta?: ReactNode;
  hideFinalCta?: boolean;
}) {
  const { locale } = await getUiPreferences();
  const sections = page.sections
    .filter((section) => section.isEnabled)
    .sort((a, b) => a.position - b.position);
  const finalCtaIndex = sections
    .map((section) => section.type)
    .lastIndexOf("CTA");

  return (
    <>
      {sections.map((section, index) => (
        <Fragment key={section.id}>
          {insertBeforeFinalCta && index === finalCtaIndex
            ? insertBeforeFinalCta
            : null}
          {hideFinalCta && index === finalCtaIndex
            ? null
            : renderSection(section, locale)}
        </Fragment>
      ))}
      {insertBeforeFinalCta && finalCtaIndex === -1
        ? insertBeforeFinalCta
        : null}
    </>
  );
}
