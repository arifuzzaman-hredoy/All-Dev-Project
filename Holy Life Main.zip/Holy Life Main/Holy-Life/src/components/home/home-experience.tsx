import Link from "next/link";
import { Icon, type IconName } from "@/components/ui/icon";
import { uiText, type UiTextKey } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

const quickActions: Array<{
  href: string;
  icon: IconName;
  eyebrow: UiTextKey;
  title: UiTextKey;
  description: UiTextKey;
  tone: string;
}> = [
  {
    href: "/appointment",
    icon: "appointment",
    eyebrow: "home.healthEyebrow",
    title: "home.healthTitle",
    description: "home.healthDescription",
    tone: "health",
  },
  {
    href: "/courses",
    icon: "learning",
    eyebrow: "home.learningEyebrow",
    title: "home.learningTitle",
    description: "home.learningDescription",
    tone: "learning",
  },
  {
    href: "/shop",
    icon: "shop",
    eyebrow: "home.shopEyebrow",
    title: "home.shopTitle",
    description: "home.shopDescription",
    tone: "commerce",
  },
  {
    href: "/dashboard",
    icon: "dashboard",
    eyebrow: "home.dashboardEyebrow",
    title: "home.dashboardTitle",
    description: "home.dashboardDescription",
    tone: "dashboard",
  },
];

const confidenceItems: Array<{
  icon: IconName;
  title: UiTextKey;
  description: UiTextKey;
}> = [
  {
    icon: "doctor",
    title: "home.doctorLed",
    description: "home.doctorLedDescription",
  },
  {
    icon: "shield",
    title: "home.permissionPrivacy",
    description: "home.permissionPrivacyDescription",
  },
  {
    icon: "bell",
    title: "home.notificationCenter",
    description: "home.notificationCenterDescription",
  },
  {
    icon: "profile",
    title: "home.memberIdentity",
    description: "home.memberIdentityDescription",
  },
];

export async function HomeExperience() {
  const { locale } = await getUiPreferences();
  return (
    <>
      <section
        className="home-quick-section"
        aria-labelledby="home-quick-title"
      >
        <div className="public-container">
          <div className="home-section-heading">
            <div>
              <span>{uiText(locale, "home.quickAccess")}</span>
              <h2 id="home-quick-title">{uiText(locale, "home.quickTitle")}</h2>
            </div>
            <p>{uiText(locale, "home.quickDescription")}</p>
          </div>

          <div className="home-quick-grid">
            {quickActions.map((item) => (
              <Link
                className={`home-quick-card home-tone-${item.tone}`}
                href={item.href}
                key={item.href}
              >
                <span className="home-quick-icon">
                  <Icon name={item.icon} size={23} />
                </span>
                <span className="home-quick-copy">
                  <small>{uiText(locale, item.eyebrow)}</small>
                  <strong>{uiText(locale, item.title)}</strong>
                  <span>{uiText(locale, item.description)}</span>
                </span>
                <span className="home-quick-arrow">
                  <Icon name="arrow-right" size={18} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section
        className="home-confidence-section"
        aria-labelledby="home-confidence-title"
      >
        <div className="public-container home-confidence-grid">
          <div className="home-confidence-copy">
            <span className="public-eyebrow">
              {uiText(locale, "home.confidenceEyebrow")}
            </span>
            <h2 id="home-confidence-title">
              {uiText(locale, "home.confidenceTitle")}
            </h2>
            <p>{uiText(locale, "home.confidenceDescription")}</p>
            <div className="home-confidence-actions">
              <Link className="public-primary-button" href="/register">
                {uiText(locale, "home.createMyAccount")}{" "}
                <Icon name="arrow-right" size={17} />
              </Link>
              <Link className="public-secondary-button" href="/about">
                {uiText(locale, "home.whyHolyLife")}
              </Link>
            </div>
          </div>

          <div className="home-confidence-board">
            <div className="home-board-head">
              <div>
                <small>{uiText(locale, "home.myHolyLife")}</small>
                <strong>{uiText(locale, "home.activityAtGlance")}</strong>
              </div>
              <span>
                <Icon name="heart" size={21} />
              </span>
            </div>
            <div className="home-board-list">
              {confidenceItems.map((item) => (
                <article key={item.title}>
                  <span>
                    <Icon name={item.icon} size={19} />
                  </span>
                  <div>
                    <strong>{uiText(locale, item.title)}</strong>
                    <p>{uiText(locale, item.description)}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
