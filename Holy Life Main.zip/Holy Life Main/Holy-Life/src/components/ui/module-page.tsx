import {
  ButtonLink,
  EmptyState,
  PageHeader,
  SectionCard,
  TabBar,
} from "@/components/ui/panel-ui";
import { uiText } from "@/lib/i18n/dictionary";
import { localizeNavigationLabel } from "@/lib/i18n/navigation";
import { getUiPreferences } from "@/lib/i18n/server";

type ModulePageProps = {
  title: string;
  description: string;
  breadcrumbs: Array<{ label: string; href?: string }>;
  baseHref: string;
  activePath: string;
  tabs: Array<{ label: string; href: string }>;
  actionLabel?: string;
  actionHref?: string;
  emptyTitle?: string;
  emptyDescription?: string;
};

export async function ModulePage({
  title,
  description,
  breadcrumbs,
  baseHref,
  activePath,
  tabs,
  actionLabel,
  actionHref = `${baseHref}/create`,
  emptyTitle,
  emptyDescription,
}: ModulePageProps) {
  const { locale } = await getUiPreferences();
  const normalizedPath = activePath.replace(/\/$/, "");
  const translatedTitle = localizeNavigationLabel(locale, title);
  const translatedAction = actionLabel
    ? localizeNavigationLabel(locale, actionLabel)
    : uiText(locale, "module.createNew");

  return (
    <>
      <PageHeader
        breadcrumbs={breadcrumbs.map((item) => ({
          ...item,
          label: localizeNavigationLabel(locale, item.label),
        }))}
        description={
          locale === "bn"
            ? uiText(locale, "module.sectionDescription")
            : description
        }
        title={translatedTitle}
        actions={
          <ButtonLink href={actionHref} icon="arrow-right">
            {translatedAction}
          </ButtonLink>
        }
      />

      {tabs.length > 1 ? (
        <TabBar
          items={tabs.map((tab, index) => ({
            ...tab,
            label: localizeNavigationLabel(locale, tab.label),
            active:
              normalizedPath === tab.href ||
              (index === 0 && normalizedPath === baseHref) ||
              normalizedPath.startsWith(`${tab.href}/`),
          }))}
        />
      ) : null}

      <section
        className="filter-panel"
        aria-label={uiText(locale, "common.filters")}
      >
        <div className="filter-search-field">
          <span aria-hidden="true">⌕</span>
          <input
            aria-label={`${uiText(locale, "common.search")} ${translatedTitle}`}
            placeholder={`${uiText(locale, "common.search")} ${translatedTitle}`}
          />
        </div>
        <select aria-label="Status filter" defaultValue="all">
          <option value="all">{uiText(locale, "common.allStatuses")}</option>
          <option value="active">{uiText(locale, "common.active")}</option>
          <option value="pending">{uiText(locale, "common.pending")}</option>
          <option value="archived">{uiText(locale, "common.archived")}</option>
        </select>
        <select aria-label="Date filter" defaultValue="30-days">
          <option value="30-days">{uiText(locale, "common.last30Days")}</option>
          <option value="7-days">{uiText(locale, "common.last7Days")}</option>
          <option value="today">{uiText(locale, "common.today")}</option>
        </select>
        <button className="ui-button ui-button-secondary" type="button">
          {uiText(locale, "common.reset")}
        </button>
      </section>

      <SectionCard
        title={translatedTitle}
        description={uiText(locale, "module.sectionDescription")}
      >
        <EmptyState
          action={
            <ButtonLink href={actionHref} variant="secondary">
              {translatedAction}
            </ButtonLink>
          }
          description={
            emptyDescription ?? uiText(locale, "module.noRecordsDescription")
          }
          icon="file"
          title={emptyTitle ?? uiText(locale, "module.noRecords")}
        />
      </SectionCard>
    </>
  );
}
