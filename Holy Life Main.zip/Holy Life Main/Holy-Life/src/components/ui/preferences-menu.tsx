"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Icon } from "@/components/ui/icon";
import {
  LOCALE_COOKIE,
  LOCALE_STORAGE_KEY,
  THEME_COOKIE,
  THEME_STORAGE_KEY,
  type Locale,
  type ThemePreference,
} from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";

function writePreferenceCookie(name: string, value: string) {
  const secure =
    typeof window !== "undefined" && window.location.protocol === "https:"
      ? "; Secure"
      : "";
  document.cookie = `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=31536000; SameSite=Lax${secure}`;
}

function resolveTheme(preference: ThemePreference): "light" | "dark" {
  if (preference === "light" || preference === "dark") return preference;
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

function themeIcon(preference: ThemePreference): "sun" | "moon" | "monitor" {
  if (preference === "light") return "sun";
  if (preference === "dark") return "moon";
  return "monitor";
}

export function PreferencesMenu({
  locale: initialLocale,
  themePreference: initialThemePreference,
  placement = "default",
}: {
  locale: Locale;
  themePreference: ThemePreference;
  placement?: "default" | "mobile" | "auth";
}) {
  const router = useRouter();
  const rootRef = useRef<HTMLDivElement>(null);
  const [locale, setLocale] = useState<Locale>(initialLocale);
  const [themePreference, setThemePreference] = useState<ThemePreference>(
    initialThemePreference,
  );
  const [themeOpen, setThemeOpen] = useState(false);

  useEffect(() => {
    document.documentElement.dataset.locale = locale;
    document.documentElement.lang = locale === "bn" ? "bn-BD" : "en";
  }, [locale]);

  useEffect(() => {
    const applyResolvedTheme = () => {
      document.documentElement.dataset.themePreference = themePreference;
      document.documentElement.dataset.theme = resolveTheme(themePreference);
    };

    applyResolvedTheme();
    if (themePreference !== "system") return;

    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyResolvedTheme();
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, [themePreference]);

  useEffect(() => {
    if (!themeOpen) return;

    const onPointerDown = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setThemeOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setThemeOpen(false);
    };

    document.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [themeOpen]);

  const changeLocale = (nextLocale: Locale) => {
    if (nextLocale === locale) return;
    setLocale(nextLocale);
    window.localStorage.setItem(LOCALE_STORAGE_KEY, nextLocale);
    writePreferenceCookie(LOCALE_COOKIE, nextLocale);
    router.refresh();
  };

  const changeTheme = (nextTheme: ThemePreference) => {
    setThemePreference(nextTheme);
    setThemeOpen(false);
    window.localStorage.setItem(THEME_STORAGE_KEY, nextTheme);
    writePreferenceCookie(THEME_COOKIE, nextTheme);
  };

  const themeLabel = uiText(
    locale,
    `common.${themePreference}` as
      "common.light" | "common.dark" | "common.system",
  );

  return (
    <div
      className={`preferences-controls preferences-controls-${placement}`}
      ref={rootRef}
    >
      <div
        className="locale-switcher"
        aria-label={uiText(locale, "common.language")}
        role="group"
      >
        <button
          aria-pressed={locale === "bn"}
          className={locale === "bn" ? "is-active" : ""}
          onClick={() => changeLocale("bn")}
          type="button"
        >
          BN
        </button>
        <button
          aria-pressed={locale === "en"}
          className={locale === "en" ? "is-active" : ""}
          onClick={() => changeLocale("en")}
          type="button"
        >
          EN
        </button>
      </div>

      <div className={`theme-selector ${themeOpen ? "is-open" : ""}`}>
        <button
          aria-expanded={themeOpen}
          aria-haspopup="menu"
          className="theme-selector-trigger"
          onClick={() => setThemeOpen((current) => !current)}
          type="button"
        >
          <Icon name={themeIcon(themePreference)} size={16} />
          <span>{themeLabel}</span>
          <Icon name="chevron-down" size={14} />
        </button>

        {themeOpen ? (
          <div
            className="theme-selector-menu"
            role="menu"
            aria-label={uiText(locale, "common.appearance")}
          >
            {(["light", "dark", "system"] as const).map((option) => (
              <button
                aria-checked={themePreference === option}
                className={themePreference === option ? "is-active" : ""}
                key={option}
                onClick={() => changeTheme(option)}
                role="menuitemradio"
                type="button"
              >
                <Icon name={themeIcon(option)} size={17} />
                <span>
                  {uiText(
                    locale,
                    `common.${option}` as
                      "common.light" | "common.dark" | "common.system",
                  )}
                </span>
                {themePreference === option ? (
                  <Icon name="check" size={15} />
                ) : (
                  <span className="theme-selector-check-placeholder" />
                )}
              </button>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}
