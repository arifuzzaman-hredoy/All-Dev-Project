import Link from "next/link";
import type { ReactNode } from "react";
import { Icon, type IconName } from "@/components/ui/icon";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  breadcrumbs,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  breadcrumbs?: Array<{ label: string; href?: string }>;
}) {
  return (
    <header className="page-header">
      {breadcrumbs?.length ? (
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          {breadcrumbs.map((item, index) => (
            <span className="breadcrumb-item" key={`${item.label}-${index}`}>
              {index > 0 ? (
                <span className="breadcrumb-separator">/</span>
              ) : null}
              {item.href ? (
                <Link href={item.href}>{item.label}</Link>
              ) : (
                <span>{item.label}</span>
              )}
            </span>
          ))}
        </nav>
      ) : null}
      <div className="page-header-row">
        <div className="page-header-copy">
          {eyebrow ? <span className="page-eyebrow">{eyebrow}</span> : null}
          <h1>{title}</h1>
          {description ? <p>{description}</p> : null}
        </div>
        {actions ? <div className="page-header-actions">{actions}</div> : null}
      </div>
    </header>
  );
}

export function ButtonLink({
  href,
  children,
  icon,
  variant = "primary",
}: {
  href: string;
  children: ReactNode;
  icon?: IconName;
  variant?: "primary" | "secondary" | "quiet";
}) {
  return (
    <Link className={`ui-button ui-button-${variant}`} href={href}>
      {icon ? <Icon name={icon} size={17} /> : null}
      <span>{children}</span>
    </Link>
  );
}

export function MetricCard({
  label,
  value,
  helper,
  icon,
  tone = "neutral",
}: {
  label: string;
  value: string;
  helper: string;
  icon: IconName;
  tone?: "neutral" | "health" | "learning" | "commerce" | "success" | "warning";
}) {
  return (
    <article className={`metric-card metric-tone-${tone}`}>
      <div className="metric-card-top">
        <span className="metric-icon">
          <Icon name={icon} size={20} />
        </span>
        <span className="metric-helper">{helper}</span>
      </div>
      <strong className="metric-value">{value}</strong>
      <span className="metric-label">{label}</span>
    </article>
  );
}

export function SectionCard({
  title,
  description,
  action,
  children,
  className = "",
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`section-card ${className}`.trim()}>
      <header className="section-card-header">
        <div>
          <h2>{title}</h2>
          {description ? <p>{description}</p> : null}
        </div>
        {action ? <div className="section-card-action">{action}</div> : null}
      </header>
      <div className="section-card-body">{children}</div>
    </section>
  );
}

export function StatusBadge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning" | "danger" | "info";
}) {
  return <span className={`status-badge status-${tone}`}>{children}</span>;
}

export type TabItem = {
  label: string;
  href: string;
  active?: boolean;
  count?: string;
};

export function TabBar({
  items,
  ariaLabel = "Page sections",
}: {
  items: TabItem[];
  ariaLabel?: string;
}) {
  return (
    <nav className="tab-bar" aria-label={ariaLabel}>
      {items.map((item) => (
        <Link
          aria-current={item.active ? "page" : undefined}
          className={`tab-link ${item.active ? "is-active" : ""}`}
          href={item.href}
          key={item.href}
        >
          <span>{item.label}</span>
          {item.count ? <span className="tab-count">{item.count}</span> : null}
        </Link>
      ))}
    </nav>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: IconName;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="empty-state-icon">
        <Icon name={icon} size={23} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action ? <div>{action}</div> : null}
    </div>
  );
}

export function ProgressBar({
  value,
  label,
}: {
  value: number;
  label: string;
}) {
  const normalizedValue = Math.min(100, Math.max(0, value));
  return (
    <div className="progress-block">
      <div className="progress-label-row">
        <span>{label}</span>
        <strong>{normalizedValue}%</strong>
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={normalizedValue}
      >
        <span style={{ width: `${normalizedValue}%` }} />
      </div>
    </div>
  );
}
