import Link from "next/link";
import type { ReactNode } from "react";
import { PublicMobileMenu } from "@/components/layout/public-mobile-menu";
import { Icon } from "@/components/ui/icon";
import { PreferencesMenu } from "@/components/ui/preferences-menu";
import { getCurrentSession, isAdminUser } from "@/lib/auth/session";
import { getWebsiteBranding, getWebsiteNavigation } from "@/lib/cms/queries";
import { localizeDefaultCmsText } from "@/lib/i18n/default-cms";
import { localizePublicNavigationLabel } from "@/lib/i18n/navigation";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";
import type { Locale, ThemePreference } from "@/lib/i18n/config";

function accountDestination(
  session: Awaited<ReturnType<typeof getCurrentSession>>,
): string {
  if (!session) return "/login";
  if (session.user.isSuperAdmin) return "/super-admin";
  if (isAdminUser(session.user)) return "/admin";
  return "/dashboard";
}

async function PublicHeader({
  locale,
  themePreference,
}: {
  locale: Locale;
  themePreference: ThemePreference;
}) {
  const [navigation, branding, session] = await Promise.all([
    getWebsiteNavigation(),
    getWebsiteBranding(),
    getCurrentSession(),
  ]);
  const accountHref = accountDestination(session);
  const localizedNavigation = navigation.header.map((item) => ({
    ...item,
    label: localizePublicNavigationLabel(locale, item.label),
  }));

  return (
    <header className="public-header">
      <div className="public-container public-nav-row">
        <Link className="public-brand" href="/">
          <span className="public-brand-mark">
            <Icon name="heart" size={21} />
          </span>
          <span>
            <strong>{branding.name}</strong>
            <small>{localizeDefaultCmsText(locale, branding.tagline)}</small>
          </span>
        </Link>
        <nav className="public-nav-links" aria-label="Public navigation">
          {localizedNavigation.map((item) => (
            <Link href={item.href} key={item.href}>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="public-nav-actions">
          <div className="public-desktop-preferences">
            <PreferencesMenu
              locale={locale}
              themePreference={themePreference}
            />
          </div>
          {session ? (
            <Link className="public-account-button" href={accountHref}>
              <span className="public-account-avatar" aria-hidden="true">
                {session.user.name.trim().charAt(0).toUpperCase()}
              </span>
              <span className="public-account-copy">
                <small>{uiText(locale, "public.signedIn")}</small>
                <strong>{uiText(locale, "public.myAccount")}</strong>
              </span>
              <Icon name="chevron-right" size={16} />
            </Link>
          ) : (
            <>
              <Link className="public-login-link" href="/login">
                {uiText(locale, "public.signIn")}
              </Link>
              <Link className="public-primary-button" href="/register">
                {uiText(locale, "public.createAccount")}
              </Link>
            </>
          )}
        </div>
        <PublicMobileMenu
          accountHref={accountHref}
          locale={locale}
          navigation={localizedNavigation}
          signedIn={Boolean(session)}
          themePreference={themePreference}
          userName={session?.user.name}
        />
      </div>
    </header>
  );
}

async function PublicFooter({ locale }: { locale: Locale }) {
  const [navigation, branding] = await Promise.all([
    getWebsiteNavigation(),
    getWebsiteBranding(),
  ]);
  const localizedFooter = navigation.footer.map((item) => ({
    ...item,
    label: localizePublicNavigationLabel(locale, item.label),
  }));
  const columns = [localizedFooter.slice(0, 5), localizedFooter.slice(5)];

  return (
    <footer className="public-footer">
      <div className="public-container public-footer-grid">
        <div className="public-footer-brand">
          <Link className="public-brand" href="/">
            <span className="public-brand-mark">
              <Icon name="heart" size={21} />
            </span>
            <span>
              <strong>{branding.name}</strong>
              <small>{localizeDefaultCmsText(locale, branding.tagline)}</small>
            </span>
          </Link>
          <p>{uiText(locale, "public.footerDescription")}</p>
        </div>
        {columns.map((column, index) => (
          <div key={`footer-column-${index}`}>
            <h3>
              {index === 0
                ? uiText(locale, "public.explore")
                : uiText(locale, "public.resourcesLegal")}
            </h3>
            {column.map((item) => (
              <Link href={item.href} key={item.href}>
                {item.label}
              </Link>
            ))}
          </div>
        ))}
        <div>
          <h3>{uiText(locale, "public.support")}</h3>
          <span>{localizeDefaultCmsText(locale, branding.address)}</span>
          <Link href={`mailto:${branding.supportEmail}`}>
            {branding.supportEmail}
          </Link>
          <Link href={`tel:${branding.supportPhone.replace(/\s/g, "")}`}>
            {branding.supportPhone}
          </Link>
          <span>{localizeDefaultCmsText(locale, branding.hours)}</span>
        </div>
      </div>
      <div className="public-container public-footer-bottom">
        <span>
          © {new Date().getFullYear()} {branding.name}.{" "}
          {uiText(locale, "public.rights")}
        </span>
        <div>
          <Link href="/privacy">{uiText(locale, "public.privacy")}</Link>
          <Link href="/terms">{uiText(locale, "public.terms")}</Link>
        </div>
      </div>
    </footer>
  );
}

export async function PublicShell({ children }: { children: ReactNode }) {
  const { locale, themePreference } = await getUiPreferences();
  return (
    <div className="public-site">
      <PublicHeader locale={locale} themePreference={themePreference} />
      <main>{children}</main>
      <PublicFooter locale={locale} />
    </div>
  );
}
