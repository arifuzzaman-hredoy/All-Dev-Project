"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { type ReactNode, useEffect, useState } from "react";
import { Icon } from "@/components/ui/icon";
import { PreferencesMenu } from "@/components/ui/preferences-menu";
import type { NavigationItem } from "@/config/navigation";
import { localizeNavigationLabel } from "@/lib/i18n/navigation";
import { uiText } from "@/lib/i18n/dictionary";
import type { Locale, ThemePreference } from "@/lib/i18n/config";

type PanelSurface = "dashboard" | "admin" | "super-admin";

type PanelShellProps = {
  children: ReactNode;
  navigation: NavigationItem[];
  surface: PanelSurface;
  title: string;
  subtitle: string;
  userName: string;
  userRole: string;
  locale: Locale;
  themePreference: ThemePreference;
};

function pathMatches(pathname: string, href?: string): boolean {
  if (!href) return false;
  if (href === "/dashboard" || href === "/admin" || href === "/super-admin") {
    return pathname === href;
  }
  return pathname === href || pathname.startsWith(`${href}/`);
}

function itemContainsPath(item: NavigationItem, pathname: string): boolean {
  return (
    pathMatches(pathname, item.href) ||
    Boolean(item.children?.some((child) => itemContainsPath(child, pathname)))
  );
}

function SidebarItem({
  item,
  depth,
  pathname,
  openIds,
  onToggle,
  onNavigate,
  locale,
}: {
  item: NavigationItem;
  depth: number;
  pathname: string;
  openIds: Set<string>;
  onToggle: (id: string) => void;
  onNavigate: () => void;
  locale: Locale;
}) {
  const hasChildren = Boolean(item.children?.length);
  const isBranchActive = itemContainsPath(item, pathname);
  const isExactActive = Boolean(item.href && pathname === item.href);
  const isOpen = openIds.has(item.id) || isBranchActive;
  const label = localizeNavigationLabel(locale, item.label);
  const className = [
    "sidebar-link",
    `sidebar-link-depth-${depth}`,
    isExactActive ? "is-active" : "",
    isBranchActive && !isExactActive ? "is-branch-active" : "",
  ]
    .filter(Boolean)
    .join(" ");

  const content = (
    <>
      {depth === 0 && item.icon ? (
        <span className="sidebar-link-icon">
          <Icon name={item.icon} size={19} />
        </span>
      ) : (
        <span className="sidebar-link-marker" aria-hidden="true" />
      )}
      <span className="sidebar-link-label">{label}</span>
      {item.badge ? <span className="sidebar-badge">{item.badge}</span> : null}
      {hasChildren ? (
        <span className={`sidebar-chevron ${isOpen ? "is-open" : ""}`}>
          <Icon name="chevron-right" size={16} />
        </span>
      ) : null}
    </>
  );

  return (
    <li className="sidebar-item">
      <div className="sidebar-link-row">
        {item.href ? (
          <Link className={className} href={item.href} onClick={onNavigate}>
            {content}
          </Link>
        ) : (
          <button
            className={className}
            type="button"
            aria-expanded={isOpen}
            onClick={() => onToggle(item.id)}
          >
            {content}
          </button>
        )}

        {item.href && hasChildren ? (
          <button
            className={`sidebar-expand-button ${isOpen ? "is-open" : ""}`}
            type="button"
            aria-label={`${isOpen ? uiText(locale, "common.collapse") : uiText(locale, "common.expand")} ${label}`}
            aria-expanded={isOpen}
            onClick={() => onToggle(item.id)}
          >
            <Icon name="chevron-right" size={16} />
          </button>
        ) : null}
      </div>

      {hasChildren && isOpen ? (
        <ul className={`sidebar-submenu sidebar-submenu-depth-${depth + 1}`}>
          {item.children?.map((child) => (
            <SidebarItem
              depth={depth + 1}
              item={child}
              key={child.id}
              locale={locale}
              onNavigate={onNavigate}
              onToggle={onToggle}
              openIds={openIds}
              pathname={pathname}
            />
          ))}
        </ul>
      ) : null}
    </li>
  );
}

export function PanelShell({
  children,
  navigation,
  surface,
  title,
  subtitle,
  userName,
  userRole,
  locale,
  themePreference,
}: PanelShellProps) {
  const pathname = usePathname();
  const [openIds, setOpenIds] = useState<Set<string>>(() => new Set());
  const [mobileOpenPath, setMobileOpenPath] = useState<string | null>(null);
  const [compact, setCompact] = useState(false);
  const mobileOpen = mobileOpenPath === pathname;
  const closeMobileNavigation = () => setMobileOpenPath(null);

  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeMobileNavigation();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [mobileOpen]);

  const toggleGroup = (id: string) => {
    setOpenIds((current: Set<string>) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div
      className={`panel-app panel-surface-${surface} ${compact ? "is-compact" : ""}`}
    >
      <button
        aria-label={`${uiText(locale, "common.close")} navigation`}
        className={`sidebar-backdrop ${mobileOpen ? "is-visible" : ""}`}
        onClick={closeMobileNavigation}
        tabIndex={mobileOpen ? 0 : -1}
        type="button"
      />

      <aside className={`panel-sidebar ${mobileOpen ? "is-mobile-open" : ""}`}>
        <div className="sidebar-brand-row">
          <Link
            className="sidebar-brand"
            href="/"
            onClick={closeMobileNavigation}
          >
            <span className="brand-mark" aria-hidden="true">
              <Icon name="heart" size={20} />
            </span>
            <span className="sidebar-brand-copy">
              <strong>Holy Life</strong>
              <small>{title}</small>
            </span>
          </Link>
          <button
            aria-label={`${uiText(locale, "common.close")} sidebar`}
            className="icon-button sidebar-mobile-close"
            onClick={closeMobileNavigation}
            type="button"
          >
            <Icon name="close" size={20} />
          </button>
        </div>

        <div className="sidebar-context">
          <span className="sidebar-context-label">
            {uiText(locale, "common.workspace")}
          </span>
          <strong>{subtitle}</strong>
        </div>

        <nav className="sidebar-navigation" aria-label={`${title} navigation`}>
          <ul className="sidebar-menu">
            {navigation.map((item) => (
              <SidebarItem
                depth={0}
                item={item}
                key={item.id}
                locale={locale}
                onNavigate={closeMobileNavigation}
                onToggle={toggleGroup}
                openIds={openIds}
                pathname={pathname}
              />
            ))}
          </ul>
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user-avatar" aria-hidden="true">
            {userName
              .split(" ")
              .slice(0, 2)
              .map((part) => part[0])
              .join("")}
          </div>
          <div className="sidebar-user-copy">
            <strong>{userName}</strong>
            <span>{userRole}</span>
          </div>
          <form action="/api/auth/logout" method="post">
            <button
              className="icon-button sidebar-logout-button"
              type="submit"
              aria-label={uiText(locale, "common.signOut")}
            >
              <Icon name="logout" size={17} />
            </button>
          </form>
        </div>
      </aside>

      <div className="panel-main">
        <header className="panel-topbar">
          <div className="topbar-leading">
            <button
              aria-label={`${uiText(locale, "common.open")} navigation`}
              className="icon-button topbar-mobile-menu"
              onClick={() => setMobileOpenPath(pathname)}
              type="button"
            >
              <Icon name="menu" size={21} />
            </button>
            <button
              aria-label={
                compact
                  ? `${uiText(locale, "common.expand")} sidebar`
                  : `${uiText(locale, "common.collapse")} sidebar`
              }
              className="icon-button topbar-desktop-menu"
              onClick={() => setCompact((current: boolean) => !current)}
              type="button"
            >
              <Icon name="menu" size={21} />
            </button>
            <div className="topbar-search">
              <Icon name="search" size={18} />
              <input
                aria-label={uiText(locale, "common.search")}
                placeholder={uiText(locale, "common.searchWorkspace")}
              />
              <kbd>⌘ K</kbd>
            </div>
          </div>

          <div className="topbar-actions">
            <PreferencesMenu
              locale={locale}
              themePreference={themePreference}
            />
            <Link className="topbar-public-link" href="/">
              <Icon name="globe" size={17} />
              <span>{uiText(locale, "common.publicSite")}</span>
            </Link>
            <button
              className="icon-button notification-button"
              type="button"
              aria-label={uiText(locale, "common.notifications")}
            >
              <Icon name="bell" size={20} />
              <span className="notification-dot" />
            </button>
            <Link
              className="topbar-user-avatar"
              href="/dashboard/profile"
              aria-label={uiText(locale, "public.myAccount")}
            >
              {userName.charAt(0)}
            </Link>
          </div>
        </header>

        <main className="panel-content">{children}</main>
      </div>
    </div>
  );
}
