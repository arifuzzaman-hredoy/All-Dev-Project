"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Icon } from "@/components/ui/icon";
import { PreferencesMenu } from "@/components/ui/preferences-menu";
import { uiText } from "@/lib/i18n/dictionary";
import type { Locale, ThemePreference } from "@/lib/i18n/config";

type PublicNavItem = {
  href: string;
  label: string;
};

export function PublicMobileMenu({
  navigation,
  accountHref,
  signedIn,
  userName,
  locale,
  themePreference,
}: {
  navigation: PublicNavItem[];
  accountHref: string;
  signedIn: boolean;
  userName?: string;
  locale: Locale;
  themePreference: ThemePreference;
}) {
  const pathname = usePathname();
  const [openPath, setOpenPath] = useState<string | null>(null);
  const open = openPath === pathname;
  const close = () => setOpenPath(null);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className="public-mobile-menu-wrap">
      <button
        aria-controls="public-mobile-drawer"
        aria-expanded={open}
        aria-label={
          open
            ? `${uiText(locale, "common.close")} navigation`
            : `${uiText(locale, "common.open")} navigation`
        }
        className="public-mobile-menu-button"
        onClick={() =>
          setOpenPath((current) => (current === pathname ? null : pathname))
        }
        type="button"
      >
        <Icon name={open ? "close" : "menu"} size={22} />
      </button>

      <button
        aria-label={`${uiText(locale, "common.close")} navigation`}
        className={`public-mobile-backdrop ${open ? "is-visible" : ""}`}
        onClick={close}
        tabIndex={open ? 0 : -1}
        type="button"
      />

      <aside
        aria-hidden={!open}
        className={`public-mobile-drawer ${open ? "is-open" : ""}`}
        id="public-mobile-drawer"
        inert={!open ? true : undefined}
      >
        <div className="public-mobile-drawer-head">
          <div>
            <span>Holy Life</span>
            <strong>{uiText(locale, "public.explorePlatform")}</strong>
          </div>
          <button
            aria-label={`${uiText(locale, "common.close")} navigation`}
            className="icon-button"
            onClick={close}
            type="button"
          >
            <Icon name="close" size={21} />
          </button>
        </div>

        <nav
          className="public-mobile-links"
          aria-label="Mobile public navigation"
        >
          {navigation.map((item) => (
            <Link href={item.href} key={item.href} onClick={close}>
              <span>{item.label}</span>
              <Icon name="chevron-right" size={17} />
            </Link>
          ))}
        </nav>

        <div className="public-mobile-preferences">
          <PreferencesMenu
            locale={locale}
            placement="mobile"
            themePreference={themePreference}
          />
        </div>

        <div className="public-mobile-account">
          {signedIn ? (
            <Link
              className="public-mobile-account-card"
              href={accountHref}
              onClick={close}
            >
              <span className="public-account-avatar" aria-hidden="true">
                {(userName ?? "H").trim().charAt(0).toUpperCase()}
              </span>
              <span>
                <small>{uiText(locale, "public.signedInAs")}</small>
                <strong>{userName ?? "Holy Life member"}</strong>
              </span>
              <Icon name="chevron-right" size={18} />
            </Link>
          ) : (
            <div className="public-mobile-auth-actions">
              <Link
                className="public-secondary-button"
                href="/login"
                onClick={close}
              >
                {uiText(locale, "public.signIn")}
              </Link>
              <Link
                className="public-primary-button"
                href="/register"
                onClick={close}
              >
                {uiText(locale, "public.createAccount")}
              </Link>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
