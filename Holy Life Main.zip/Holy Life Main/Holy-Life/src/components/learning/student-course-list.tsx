import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  ProgressBar,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { listStudentEnrollments } from "@/lib/learning/queries";

export async function StudentCourseList({
  userId,
  mode,
}: {
  userId: string;
  mode: "all" | "active" | "completed";
}) {
  const enrollments = await listStudentEnrollments(userId, mode);
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Learning"
        title={
          mode === "active"
            ? "Courses in progress"
            : mode === "completed"
              ? "Completed courses"
              : "My courses"
        }
        description="Continue lessons, track progress and collect certificates."
        actions={
          <Link className="ui-button ui-button-primary" href="/courses">
            Browse courses
          </Link>
        }
      />
      <TabBar
        items={[
          {
            label: "All",
            href: "/dashboard/learning/courses",
            active: mode === "all",
          },
          {
            label: "In progress",
            href: "/dashboard/learning/courses/active",
            active: mode === "active",
          },
          {
            label: "Completed",
            href: "/dashboard/learning/courses/completed",
            active: mode === "completed",
          },
        ]}
      />
      <SectionCard
        title="Enrollments"
        description={`${enrollments.length} course${enrollments.length === 1 ? "" : "s"}`}
      >
        {enrollments.length === 0 ? (
          <EmptyState
            icon="learning"
            title="No courses here"
            description="Your matching enrollments will appear here."
          />
        ) : (
          <div className="learning-enrollment-grid">
            {enrollments.map((item) => {
              const firstLesson = item.course.modules.flatMap(
                (module) => module.lessons,
              )[0];
              return (
                <article className="learning-enrollment-card" key={item.id}>
                  <div>
                    <span className="page-eyebrow">
                      {item.course.category.name}
                    </span>
                    <h2>{item.course.title}</h2>
                    <p>{item.course.instructor?.name ?? "Holy Life Academy"}</p>
                  </div>
                  <StatusBadge
                    tone={
                      item.status === "COMPLETED"
                        ? "success"
                        : item.status === "ACTIVE"
                          ? "info"
                          : "neutral"
                    }
                  >
                    {item.status}
                  </StatusBadge>
                  <ProgressBar
                    value={item.progressPercent}
                    label="Course progress"
                  />
                  <div className="learning-card-actions">
                    {firstLesson ? (
                      <Link
                        className="ui-button ui-button-primary"
                        href={`/courses/${item.course.slug}/learn/${firstLesson.id}`}
                      >
                        {item.status === "COMPLETED"
                          ? "Review course"
                          : "Continue learning"}
                      </Link>
                    ) : null}
                    {item.certificate ? (
                      <Link
                        className="ui-button ui-button-secondary"
                        href="/dashboard/learning/certificates"
                      >
                        Certificate
                      </Link>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </SectionCard>
    </div>
  );
}
