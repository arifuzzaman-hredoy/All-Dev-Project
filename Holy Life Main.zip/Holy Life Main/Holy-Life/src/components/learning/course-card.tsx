import Link from "next/link";
import { intlLocale, type Locale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import {
  courseLevelLabel,
  localizedOptionalText,
  localizedText,
} from "@/lib/i18n/content";

export function CourseCard({
  course,
  locale = "en",
  featured = false,
}: {
  course: {
    slug: string;
    title: string;
    titleBn: string | null;
    shortDescription: string | null;
    shortDescriptionBn: string | null;
    thumbnailUrl: string | null;
    level: string;
    price: unknown;
    currency: string;
    category: { name: string; nameBn: string | null };
    instructor: { name: string; nameBn: string | null } | null;
    modules: Array<{ lessons: Array<{ id: string; durationMinutes: number }> }>;
    reviews: Array<{ rating: number }>;
    _count: { enrollments: number };
  };
  locale?: Locale;
  featured?: boolean;
}) {
  const numberLocale = intlLocale(locale);
  const lessons = course.modules.reduce(
    (sum, module) => sum + module.lessons.length,
    0,
  );
  const minutes = course.modules.reduce(
    (sum, module) =>
      sum +
      module.lessons.reduce(
        (inner, lesson) => inner + lesson.durationMinutes,
        0,
      ),
    0,
  );
  const rating = course.reviews.length
    ? (
        course.reviews.reduce((sum, review) => sum + review.rating, 0) /
        course.reviews.length
      ).toFixed(1)
    : uiText(locale, "learning.new");
  const title = localizedText(locale, course.title, course.titleBn);
  const description =
    localizedOptionalText(
      locale,
      course.shortDescription,
      course.shortDescriptionBn,
    ) ?? uiText(locale, "learning.defaultDescription");
  const categoryName = localizedText(
    locale,
    course.category.name,
    course.category.nameBn,
  );
  const instructorName = course.instructor
    ? localizedText(locale, course.instructor.name, course.instructor.nameBn)
    : "Holy Life Academy";
  return (
    <article
      className={`learning-course-card ${featured ? "is-featured" : ""}`}
    >
      <Link
        className="learning-course-cover"
        href={`/courses/${course.slug}`}
        style={
          course.thumbnailUrl
            ? { backgroundImage: `url(${course.thumbnailUrl})` }
            : undefined
        }
      >
        <span>{categoryName}</span>
      </Link>
      <div className="learning-course-body">
        <div className="learning-course-meta">
          <span>{courseLevelLabel(locale, course.level)}</span>
          <span>{rating} ★</span>
        </div>
        <h2>
          <Link href={`/courses/${course.slug}`}>{title}</Link>
        </h2>
        <p>{description}</p>
        <div className="learning-course-stats">
          <span>
            {new Intl.NumberFormat(numberLocale).format(lessons)}{" "}
            {uiText(locale, "learning.lessons")}
          </span>
          <span>
            {new Intl.NumberFormat(numberLocale).format(
              Math.max(1, Math.round(minutes / 60)),
            )}
            h
          </span>
          <span>
            {new Intl.NumberFormat(numberLocale).format(
              course._count.enrollments,
            )}{" "}
            {uiText(locale, "learning.learners")}
          </span>
        </div>
        <div className="learning-course-footer">
          <span>{instructorName}</span>
          <strong>
            {Number(course.price) === 0
              ? uiText(locale, "learning.free")
              : `${course.currency} ${Number(course.price).toLocaleString(numberLocale)}`}
          </strong>
        </div>
      </div>
    </article>
  );
}
