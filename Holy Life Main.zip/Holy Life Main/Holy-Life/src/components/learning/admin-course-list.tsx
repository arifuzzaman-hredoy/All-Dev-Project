import Link from "next/link";
import {
  ButtonLink,
  EmptyState,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { learningSummary } from "@/lib/learning/queries";
import { db } from "@/lib/db";

export async function AdminCourseList({
  error,
  success,
}: {
  error?: string;
  success?: string;
}) {
  const [summary, courses] = await Promise.all([
    learningSummary(),
    db.course.findMany({
      where: { status: { not: "ARCHIVED" } },
      include: {
        category: true,
        instructor: true,
        _count: { select: { modules: true, enrollments: true } },
      },
      orderBy: { updatedAt: "desc" },
      take: 100,
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Course management"
        description="Build courses, modules, lessons, assessments and completion paths."
        actions={
          <ButtonLink href="/admin/learning/courses/create" icon="learning">
            Create course
          </ButtonLink>
        }
      />
      <div className="metric-grid">
        <MetricCard
          icon="learning"
          label="Courses"
          value={String(summary.courses)}
          helper="Not archived"
          tone="learning"
        />
        <MetricCard
          icon="globe"
          label="Published"
          value={String(summary.published)}
          helper="Public catalog"
          tone="success"
        />
        <MetricCard
          icon="users"
          label="Students"
          value={String(summary.students)}
          helper="Unique learners"
          tone="neutral"
        />
        <MetricCard
          icon="clipboard"
          label="Active enrollments"
          value={String(summary.active)}
          helper="In progress"
          tone="warning"
        />
      </div>
      <TabBar
        items={[
          { label: "Courses", href: "/admin/learning/courses", active: true },
          { label: "Categories", href: "/admin/learning/courses/categories" },
          { label: "Enrollments", href: "/admin/learning/enrollments" },
          { label: "Assessments", href: "/admin/learning/assessments" },
        ]}
      />
      {error ? <div className="form-alert error">{error}</div> : null}
      {success ? <div className="form-alert success">{success}</div> : null}
      <SectionCard
        title="Course catalog"
        description={`${courses.length} course record${courses.length === 1 ? "" : "s"}`}
      >
        {courses.length === 0 ? (
          <EmptyState
            icon="learning"
            title="No courses"
            description="Create the first course and curriculum."
            action={
              <ButtonLink href="/admin/learning/courses/create">
                Create course
              </ButtonLink>
            }
          />
        ) : (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Course</th>
                  <th>Category</th>
                  <th>Curriculum</th>
                  <th>Students</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {courses.map((course) => (
                  <tr key={course.id}>
                    <td>
                      <strong>{course.title}</strong>
                      <span>{course.instructor?.name ?? "No instructor"}</span>
                    </td>
                    <td>{course.category.name}</td>
                    <td>{course._count.modules} module(s)</td>
                    <td>{course._count.enrollments}</td>
                    <td>
                      <StatusBadge
                        tone={
                          course.status === "PUBLISHED"
                            ? "success"
                            : course.status === "DRAFT"
                              ? "warning"
                              : "neutral"
                        }
                      >
                        {course.status}
                      </StatusBadge>
                    </td>
                    <td>
                      <Link href={`/admin/learning/courses/${course.id}`}>
                        Manage
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>
    </div>
  );
}
