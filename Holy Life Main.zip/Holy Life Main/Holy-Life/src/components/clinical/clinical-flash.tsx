export function ClinicalFlash({
  success,
  error,
}: {
  success?: string;
  error?: string;
}) {
  if (!success && !error) return null;
  return (
    <div className={`notice-box ${error ? "notice-danger" : ""}`} role="status">
      <strong>{error ? "Action required" : "Saved"}</strong>
      <p>{error ?? success}</p>
    </div>
  );
}
