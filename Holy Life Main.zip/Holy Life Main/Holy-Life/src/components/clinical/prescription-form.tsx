import type { PrescriptionItem } from "@/generated/prisma/client";

const EMPTY_ROWS = 5;

export function PrescriptionFormFields({
  appointmentId,
  diagnosis,
  notes,
  advice,
  followUpDate,
  items = [],
}: {
  appointmentId: string;
  diagnosis?: string | null;
  notes?: string | null;
  advice?: string | null;
  followUpDate?: string | null;
  items?: PrescriptionItem[];
}) {
  const rows = Array.from(
    { length: Math.max(EMPTY_ROWS, items.length) },
    (_, index) => items[index],
  );
  return (
    <>
      <input name="appointmentId" type="hidden" value={appointmentId} />
      <div className="admin-form-grid">
        <label className="form-field">
          <span>Diagnosis</span>
          <textarea
            defaultValue={diagnosis ?? ""}
            maxLength={8000}
            name="diagnosis"
            rows={4}
          />
        </label>
        <label className="form-field">
          <span>Clinical notes</span>
          <textarea
            defaultValue={notes ?? ""}
            maxLength={12000}
            name="clinicalNotes"
            rows={4}
          />
        </label>
        <label className="form-field">
          <span>Advice</span>
          <textarea
            defaultValue={advice ?? ""}
            maxLength={8000}
            name="advice"
            rows={4}
          />
        </label>
        <label className="form-field">
          <span>Follow-up date</span>
          <input
            defaultValue={followUpDate ?? ""}
            name="followUpDate"
            type="date"
          />
        </label>
      </div>
      <div className="prescription-editor-table data-table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Medicine *</th>
              <th>Generic / strength</th>
              <th>Dose *</th>
              <th>Frequency *</th>
              <th>Duration *</th>
              <th>Route / quantity</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((item, index) => (
              <tr key={item?.id ?? `new-${index}`}>
                <td>
                  <input
                    defaultValue={item?.medicineName ?? ""}
                    maxLength={160}
                    name="medicineName"
                    placeholder="Medicine"
                  />
                </td>
                <td>
                  <input
                    defaultValue={item?.genericName ?? ""}
                    maxLength={160}
                    name="genericName"
                    placeholder="Generic"
                  />
                  <input
                    defaultValue={item?.strength ?? ""}
                    maxLength={80}
                    name="strength"
                    placeholder="Strength"
                  />
                </td>
                <td>
                  <input
                    defaultValue={item?.dose ?? ""}
                    maxLength={120}
                    name="dose"
                    placeholder="1 tablet"
                  />
                </td>
                <td>
                  <input
                    defaultValue={item?.frequency ?? ""}
                    maxLength={160}
                    name="frequency"
                    placeholder="Twice daily"
                  />
                </td>
                <td>
                  <input
                    defaultValue={item?.duration ?? ""}
                    maxLength={120}
                    name="duration"
                    placeholder="5 days"
                  />
                </td>
                <td>
                  <input
                    defaultValue={item?.route ?? ""}
                    maxLength={80}
                    name="route"
                    placeholder="Oral"
                  />
                  <input
                    defaultValue={item?.quantity ?? ""}
                    maxLength={80}
                    name="quantity"
                    placeholder="Qty"
                  />
                  <textarea
                    defaultValue={item?.instructions ?? ""}
                    maxLength={1000}
                    name="instructions"
                    placeholder="Instructions"
                    rows={2}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="muted-copy">
        Leave unused rows empty. Signed prescriptions are immutable; corrections
        create a new revision.
      </p>
    </>
  );
}
