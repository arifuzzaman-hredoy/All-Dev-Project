import { PermissionMatrix } from "@/components/rbac/permission-matrix";
import { DATA_SCOPES } from "@/lib/rbac/catalog";

export function RoleForm({
  action,
  role,
  selectedPermissions,
  submitLabel,
}: {
  action: string;
  role?: {
    name: string;
    code: string;
    description: string | null;
    defaultDataScope: string;
    isMasterAdmin: boolean;
    isSystem: boolean;
  };
  selectedPermissions: ReadonlySet<string>;
  submitLabel: string;
}) {
  return (
    <form action={action} className="rbac-form" method="post">
      <div className="rbac-form-grid">
        <label>
          <span>Role name</span>
          <input defaultValue={role?.name ?? ""} name="name" required />
        </label>
        <label>
          <span>Role code</span>
          <input
            defaultValue={role?.code ?? ""}
            disabled={role?.isSystem}
            name="code"
            placeholder="EXAMPLE_ROLE"
            required={!role?.isSystem}
          />
        </label>
        <label>
          <span>Default data scope</span>
          <select
            defaultValue={role?.defaultDataScope ?? "DEPARTMENT"}
            name="defaultDataScope"
          >
            {DATA_SCOPES.map((scope) => (
              <option key={scope} value={scope}>
                {scope}
              </option>
            ))}
          </select>
        </label>
        <label className="rbac-form-span">
          <span>Description</span>
          <textarea
            defaultValue={role?.description ?? ""}
            name="description"
            rows={3}
          />
        </label>
      </div>
      {role?.isMasterAdmin ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          Master Admin starts with all operational permissions, but the primary
          owner can customize this matrix. Owner-only controls remain protected.
        </div>
      ) : null}
      <fieldset className="permission-fieldset">
        <legend>Department → module → resource → action</legend>
        <PermissionMatrix selected={selectedPermissions} />
      </fieldset>
      <div className="rbac-form-actions">
        <button className="ui-button ui-button-primary" type="submit">
          {submitLabel}
        </button>
      </div>
    </form>
  );
}
