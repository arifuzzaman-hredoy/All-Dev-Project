import { groupPermissionCatalog } from "@/lib/rbac/catalog";

const labels: Record<string, string> = {
  HEALTHCARE: "Doctor & appointment",
  COMMERCE: "E-commerce",
  LEARNING: "Course & learning",
  WEBSITE: "Website",
  SYSTEM: "System",
};

function title(value: string): string {
  return value
    .replaceAll("-", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function PermissionMatrix({
  selected,
}: {
  selected: ReadonlySet<string>;
}) {
  const departments = groupPermissionCatalog();
  return (
    <div className="permission-matrix">
      {[...departments.entries()].map(([department, modules]) => (
        <section className="permission-department" key={department}>
          <header>
            <strong>{labels[department] ?? title(department)}</strong>
            <span>
              {[...modules.values()].reduce(
                (sum, resources) =>
                  sum +
                  [...resources.values()].reduce(
                    (inner, items) => inner + items.length,
                    0,
                  ),
                0,
              )}{" "}
              permissions
            </span>
          </header>
          {[...modules.entries()].map(([module, resources]) => (
            <div className="permission-module" key={`${department}-${module}`}>
              <h3>{title(module)}</h3>
              {[...resources.entries()].map(([resource, permissions]) => (
                <div
                  className="permission-resource"
                  key={`${department}-${module}-${resource}`}
                >
                  <div>
                    <strong>{title(resource)}</strong>
                    <small>{permissions[0]?.description}</small>
                  </div>
                  <div className="permission-action-grid">
                    {permissions.map((item) => (
                      <label key={item.key} title={item.description}>
                        <input
                          defaultChecked={selected.has(item.key)}
                          name="permissionKey"
                          type="checkbox"
                          value={item.key}
                        />
                        <span>{title(item.action)}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </section>
      ))}
    </div>
  );
}
