import Link from "next/link";
import {
  ButtonLink,
  EmptyState,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { formatMoney } from "@/lib/commerce/money";
import { commerceSummary } from "@/lib/commerce/queries";
import { db } from "@/lib/db";
export async function AdminProductList({
  error,
  success,
}: {
  error?: string;
  success?: string;
}) {
  const [summary, products] = await Promise.all([
    commerceSummary(),
    db.product.findMany({
      where: { status: { not: "ARCHIVED" } },
      include: {
        category: true,
        brand: true,
        variants: { orderBy: [{ isDefault: "desc" }, { price: "asc" }] },
      },
      orderBy: { updatedAt: "desc" },
      take: 100,
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="E-commerce"
        title="Product management"
        description="Catalog, variants, pricing and inventory are managed together."
        actions={
          <ButtonLink href="/admin/commerce/products/create" icon="package">
            Add product
          </ButtonLink>
        }
      />
      <div className="metric-grid">
        <MetricCard
          icon="package"
          label="Products"
          value={String(summary.products)}
          helper="Not archived"
          tone="commerce"
        />
        <MetricCard
          icon="shop"
          label="Active"
          value={String(summary.activeProducts)}
          helper="Visible in shop"
          tone="success"
        />
        <MetricCard
          icon="inventory"
          label="Low stock"
          value={String(summary.lowStock)}
          helper="Needs attention"
          tone="warning"
        />
        <MetricCard
          icon="cart"
          label="Orders"
          value={String(summary.totalOrders)}
          helper="All time"
          tone="neutral"
        />
      </div>
      <TabBar
        items={[
          { label: "Products", href: "/admin/commerce/products", active: true },
          { label: "Categories", href: "/admin/commerce/products/categories" },
          { label: "Inventory", href: "/admin/commerce/products/inventory" },
        ]}
      />
      {error ? <div className="form-alert error">{error}</div> : null}
      {success ? <div className="form-alert success">{success}</div> : null}
      <SectionCard
        title="Catalog"
        description={`${products.length} product record${products.length === 1 ? "" : "s"}`}
      >
        {products.length === 0 ? (
          <EmptyState
            icon="package"
            title="No products"
            description="Create the first product and default variant."
            action={
              <ButtonLink href="/admin/commerce/products/create">
                Create product
              </ButtonLink>
            }
          />
        ) : (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Default price</th>
                  <th>Stock</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => {
                  const variant = product.variants[0];
                  return (
                    <tr key={product.id}>
                      <td>
                        <strong>{product.name}</strong>
                        <span>{variant?.sku ?? "No SKU"}</span>
                      </td>
                      <td>
                        {product.category.name}
                        {product.brand ? (
                          <span>{product.brand.name}</span>
                        ) : null}
                      </td>
                      <td>
                        {variant ? formatMoney(variant.price.toString()) : "—"}
                      </td>
                      <td>
                        {product.variants.reduce(
                          (sum, item) => sum + item.stockOnHand,
                          0,
                        )}
                      </td>
                      <td>
                        <StatusBadge
                          tone={
                            product.status === "ACTIVE"
                              ? "success"
                              : product.status === "DRAFT"
                                ? "warning"
                                : "neutral"
                          }
                        >
                          {product.status}
                        </StatusBadge>
                      </td>
                      <td>
                        <Link href={`/admin/commerce/products/${product.id}`}>
                          Manage
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>
    </div>
  );
}
