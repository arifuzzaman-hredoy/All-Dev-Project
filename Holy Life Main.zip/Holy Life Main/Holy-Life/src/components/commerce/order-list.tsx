import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { formatMoney } from "@/lib/commerce/money";
import { listCustomerOrders } from "@/lib/commerce/queries";
import { orderStatusLabel } from "@/lib/commerce/status";

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "DELIVERED") return "success";
  if (["CANCELLED", "REFUNDED"].includes(status)) return "danger";
  if (["PENDING", "CONFIRMED"].includes(status)) return "warning";
  return "info";
}
export async function CustomerOrderList({
  userId,
  mode,
  error,
  success,
}: {
  userId: string;
  mode: "all" | "active" | "history";
  error?: string;
  success?: string;
}) {
  const orders = await listCustomerOrders(userId, mode);
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Shopping"
        title={
          mode === "all"
            ? "My orders"
            : mode === "active"
              ? "Active orders"
              : "Order history"
        }
        description="Track order, payment, delivery and refund status."
        actions={
          <Link className="ui-button ui-button-primary" href="/shop">
            Shop now
          </Link>
        }
      />
      <TabBar
        items={[
          {
            label: "All",
            href: "/dashboard/shopping/orders",
            active: mode === "all",
          },
          {
            label: "Active",
            href: "/dashboard/shopping/orders/active",
            active: mode === "active",
          },
          {
            label: "History",
            href: "/dashboard/shopping/orders/history",
            active: mode === "history",
          },
        ]}
      />
      {error ? <div className="form-alert error">{error}</div> : null}
      {success ? <div className="form-alert success">{success}</div> : null}
      <SectionCard
        title="Orders"
        description={`${orders.length} order${orders.length === 1 ? "" : "s"}`}
      >
        {orders.length === 0 ? (
          <EmptyState
            icon="package"
            title="No orders here"
            description="Your matching orders will appear here."
          />
        ) : (
          <div className="commerce-order-list">
            {orders.map((order) => (
              <Link
                className="commerce-order-row"
                href={`/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`}
                key={order.id}
              >
                <div>
                  <strong>{order.code}</strong>
                  <span>
                    {order.createdAt.toLocaleDateString("en-BD")} ·{" "}
                    {order.items.length} item(s)
                  </span>
                </div>
                <StatusBadge tone={tone(order.status)}>
                  {orderStatusLabel(order.status)}
                </StatusBadge>
                <strong>{formatMoney(order.grandTotal.toString())}</strong>
              </Link>
            ))}
          </div>
        )}
      </SectionCard>
    </div>
  );
}
