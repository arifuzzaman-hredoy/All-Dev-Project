/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { EmptyState, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { formatMoney, lineTotal } from "@/lib/commerce/money";
import { getCart } from "@/lib/commerce/queries";
import { intlLocale } from "@/lib/i18n/config";
import { localizedText } from "@/lib/i18n/content";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export async function CartView({
  userId,
  error,
  success,
}: {
  userId: string;
  error?: string;
  success?: string;
}) {
  const [{ locale }, cart] = await Promise.all([
    getUiPreferences(),
    getCart(userId),
  ]);
  const numberLocale = intlLocale(locale);
  const items = cart?.items ?? [];
  const subtotal = items.reduce(
    (sum, item) =>
      sum + lineTotal(item.variant.price.toString(), item.quantity),
    0,
  );

  return (
    <div className="dashboard-page commerce-dashboard-page">
      <PageHeader
        eyebrow={uiText(locale, "cart.eyebrow")}
        title={uiText(locale, "cart.title")}
        description={uiText(locale, "cart.description")}
        actions={
          <Link className="ui-button ui-button-secondary" href="/shop">
            {uiText(locale, "cart.continueShopping")}
          </Link>
        }
      />
      {error ? <div className="form-alert error">{error}</div> : null}
      {success ? <div className="form-alert success">{success}</div> : null}
      {items.length === 0 ? (
        <SectionCard title={uiText(locale, "cart.section")}>
          <EmptyState
            icon="cart"
            title={uiText(locale, "cart.emptyTitle")}
            description={uiText(locale, "cart.emptyDescription")}
            action={
              <Link className="ui-button ui-button-primary" href="/shop">
                {uiText(locale, "cart.browseProducts")}
              </Link>
            }
          />
        </SectionCard>
      ) : (
        <div className="commerce-cart-layout">
          <SectionCard
            title={uiText(locale, "cart.items")}
            description={`${new Intl.NumberFormat(numberLocale).format(items.length)} ${uiText(locale, "cart.productOptions")}`}
          >
            <div className="commerce-cart-items">
              {items.map((item) => {
                const image = item.variant.product.images[0];
                const productName = localizedText(
                  locale,
                  item.variant.product.name,
                  item.variant.product.nameBn,
                );
                const variantName = localizedText(
                  locale,
                  item.variant.name,
                  item.variant.nameBn,
                );
                const imageAlt = image
                  ? localizedText(
                      locale,
                      image.altText ?? productName,
                      image.altTextBn,
                      productName,
                    )
                  : productName;
                return (
                  <article className="commerce-cart-item" key={item.id}>
                    <div className="commerce-cart-image">
                      {image ? (
                        <img alt={imageAlt} src={image.url} />
                      ) : (
                        <span>HL</span>
                      )}
                    </div>
                    <div>
                      <h3>{productName}</h3>
                      <p>
                        {variantName} · {item.variant.sku}
                      </p>
                      <strong>
                        {formatMoney(
                          item.variant.price.toString(),
                          "BDT",
                          numberLocale,
                        )}
                      </strong>
                    </div>
                    <form
                      action="/api/commerce/cart/update"
                      method="post"
                      className="commerce-quantity-form"
                    >
                      <input name="itemId" type="hidden" value={item.id} />
                      <label>
                        {uiText(locale, "cart.quantity")}
                        <input
                          max="100"
                          min="0"
                          name="quantity"
                          type="number"
                          defaultValue={item.quantity}
                        />
                      </label>
                      <button
                        className="ui-button ui-button-secondary"
                        type="submit"
                      >
                        {uiText(locale, "cart.update")}
                      </button>
                    </form>
                    <strong>
                      {formatMoney(
                        lineTotal(item.variant.price.toString(), item.quantity),
                        "BDT",
                        numberLocale,
                      )}
                    </strong>
                  </article>
                );
              })}
            </div>
          </SectionCard>
          <aside className="commerce-order-summary">
            <h2>{uiText(locale, "cart.orderSummary")}</h2>
            <div>
              <span>{uiText(locale, "cart.subtotal")}</span>
              <strong>{formatMoney(subtotal, "BDT", numberLocale)}</strong>
            </div>
            <p>{uiText(locale, "cart.checkoutNote")}</p>
            <Link className="ui-button ui-button-primary" href="/checkout">
              {uiText(locale, "cart.proceed")}
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
}
