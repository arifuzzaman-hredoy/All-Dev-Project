import Link from "next/link";
import {
  EmptyState,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { formatMoney } from "@/lib/commerce/money";
import { commerceSummary } from "@/lib/commerce/queries";
import { orderStatusLabel } from "@/lib/commerce/status";
import { db } from "@/lib/db";
function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "DELIVERED") return "success";
  if (["CANCELLED", "REFUNDED"].includes(status)) return "danger";
  if (["PENDING", "CONFIRMED"].includes(status)) return "warning";
  return "info";
}
export async function AdminOrderList({
  mode = "all",
  error,
  success,
}: {
  mode?: "all" | "pending";
  error?: string;
  success?: string;
}) {
  const [summary, orders] = await Promise.all([
    commerceSummary(),
    db.commerceOrder.findMany({
      where:
        mode === "pending"
          ? { status: { in: ["PENDING", "CONFIRMED", "PROCESSING"] } }
          : {},
      include: { items: true },
      orderBy: { createdAt: "desc" },
      take: 150,
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="E-commerce"
        title={mode === "pending" ? "Pending orders" : "Order management"}
        description="Process orders with audited status and payment transitions."
      />
      <div className="metric-grid">
        <MetricCard
          icon="cart"
          label="Pending work"
          value={String(summary.pendingOrders)}
          helper="Open workflow"
          tone="warning"
        />
        <MetricCard
          icon="package"
          label="All orders"
          value={String(summary.totalOrders)}
          helper="Lifetime"
          tone="commerce"
        />
        <MetricCard
          icon="reports"
          label="Order value"
          value={formatMoney(summary.revenue)}
          helper="Non-cancelled"
          tone="success"
        />
      </div>
      <TabBar
        items={[
          {
            label: "All orders",
            href: "/admin/commerce/orders",
            active: mode === "all",
          },
          {
            label: "Pending",
            href: "/admin/commerce/orders/pending",
            active: mode === "pending",
          },
          {
            label: "Returns & refunds",
            href: "/admin/commerce/orders/returns",
          },
        ]}
      />
      {error ? <div className="form-alert error">{error}</div> : null}
      {success ? <div className="form-alert success">{success}</div> : null}
      <SectionCard
        title="Orders"
        description={`${orders.length} order${orders.length === 1 ? "" : "s"}`}
      >
        {orders.length === 0 ? (
          <EmptyState
            icon="cart"
            title="No matching orders"
            description="New customer orders will appear here."
          />
        ) : (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Status</th>
                  <th>Payment</th>
                  <th>Total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id}>
                    <td>
                      <strong>{order.code}</strong>
                      <span>{order.createdAt.toLocaleString("en-BD")}</span>
                    </td>
                    <td>
                      {order.customerName}
                      <span>{order.customerPhone}</span>
                    </td>
                    <td>
                      <StatusBadge tone={tone(order.status)}>
                        {orderStatusLabel(order.status)}
                      </StatusBadge>
                    </td>
                    <td>{order.paymentStatus.replaceAll("_", " ")}</td>
                    <td>{formatMoney(order.grandTotal.toString())}</td>
                    <td>
                      <Link href={`/admin/commerce/orders/${order.id}`}>
                        Open
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>
    </div>
  );
}
