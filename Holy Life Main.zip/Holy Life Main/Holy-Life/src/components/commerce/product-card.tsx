/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { formatMoney } from "@/lib/commerce/money";
import { availableStock } from "@/lib/commerce/stock";
import { intlLocale, type Locale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedOptionalText, localizedText } from "@/lib/i18n/content";

type StoreProduct = {
  id: string;
  slug: string;
  name: string;
  nameBn: string | null;
  shortDescription: string | null;
  shortDescriptionBn: string | null;
  category: { name: string; nameBn: string | null };
  brand: { name: string; nameBn: string | null } | null;
  images: Array<{
    url: string;
    altText: string | null;
    altTextBn: string | null;
  }>;
  variants: Array<{
    id: string;
    name: string;
    nameBn: string | null;
    price: { toString(): string };
    compareAtPrice: { toString(): string } | null;
    stockOnHand: number;
    reservedStock: number;
  }>;
  reviews: Array<{ rating: number }>;
};

export function ProductCard({
  product,
  locale = "en",
}: {
  product: StoreProduct;
  locale?: Locale;
}) {
  const variant = product.variants[0];
  if (!variant) return null;
  const numberLocale = intlLocale(locale);
  const image = product.images[0];
  const average = product.reviews.length
    ? product.reviews.reduce((sum, item) => sum + item.rating, 0) /
      product.reviews.length
    : 0;
  const stock = availableStock(variant.stockOnHand, variant.reservedStock);
  const name = localizedText(locale, product.name, product.nameBn);
  const description =
    localizedOptionalText(
      locale,
      product.shortDescription,
      product.shortDescriptionBn,
    ) ?? uiText(locale, "commerce.defaultDescription");
  const categoryName = localizedText(
    locale,
    product.category.name,
    product.category.nameBn,
  );
  const brandName = product.brand
    ? localizedText(locale, product.brand.name, product.brand.nameBn)
    : null;
  const imageAlt = image
    ? (localizedOptionalText(locale, image.altText, image.altTextBn) ?? name)
    : name;
  return (
    <article className="commerce-product-card">
      <Link className="commerce-product-media" href={`/shop/${product.slug}`}>
        {image ? (
          <img alt={imageAlt} loading="lazy" src={image.url} />
        ) : (
          <span>HL</span>
        )}
        {stock <= 0 ? <em>{uiText(locale, "commerce.outOfStock")}</em> : null}
      </Link>
      <div className="commerce-product-copy">
        <span className="commerce-kicker">
          {categoryName}
          {brandName ? ` · ${brandName}` : ""}
        </span>
        <h2>
          <Link href={`/shop/${product.slug}`}>{name}</Link>
        </h2>
        <p>{description}</p>
        <div
          className="commerce-rating"
          aria-label={`${average.toFixed(1)} out of 5`}
        >
          {average
            ? `★ ${average.toFixed(1)} (${new Intl.NumberFormat(numberLocale).format(product.reviews.length)})`
            : uiText(locale, "commerce.newProduct")}
        </div>
        <div className="commerce-price-row">
          <strong>
            {formatMoney(variant.price.toString(), "BDT", numberLocale)}
          </strong>
          {variant.compareAtPrice ? (
            <del>
              {formatMoney(
                variant.compareAtPrice.toString(),
                "BDT",
                numberLocale,
              )}
            </del>
          ) : null}
        </div>
        <Link className="public-primary-button" href={`/shop/${product.slug}`}>
          {uiText(locale, "commerce.viewProduct")}
        </Link>
      </div>
    </article>
  );
}
