"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/icon";

type PasswordInputProps = {
  name: string;
  label: string;
  autoComplete: "current-password" | "new-password";
  placeholder?: string;
  required?: boolean;
  minLength?: number;
  maxLength?: number;
};

export function PasswordInput({
  name,
  label,
  autoComplete,
  placeholder,
  required = true,
  minLength = 6,
  maxLength = 128,
}: PasswordInputProps) {
  const [visible, setVisible] = useState(false);

  return (
    <label className="auth-field">
      <span>{label}</span>
      <span className="auth-password-control">
        <input
          autoComplete={autoComplete}
          maxLength={maxLength}
          minLength={minLength}
          name={name}
          placeholder={placeholder}
          required={required}
          type={visible ? "text" : "password"}
        />
        <button
          aria-label={
            visible
              ? `Hide ${label.toLowerCase()}`
              : `Show ${label.toLowerCase()}`
          }
          aria-pressed={visible}
          className="auth-password-toggle"
          onClick={() => setVisible((current) => !current)}
          type="button"
        >
          <Icon name={visible ? "eye-off" : "eye"} size={19} />
        </button>
      </span>
    </label>
  );
}
