import Link from "next/link";
import type { ReactNode } from "react";
import { Icon } from "@/components/ui/icon";
import { PreferencesMenu } from "@/components/ui/preferences-menu";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export async function AuthShell({
  eyebrow,
  title,
  description,
  children,
  footer,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const { locale, themePreference } = await getUiPreferences();

  return (
    <main className="auth-page">
      <div className="auth-preferences">
        <PreferencesMenu
          locale={locale}
          placement="auth"
          themePreference={themePreference}
        />
      </div>
      <div className="auth-grid">
        <section className="auth-brand-panel">
          <Link className="public-brand auth-brand" href="/">
            <span className="public-brand-mark">
              <Icon name="heart" size={21} />
            </span>
            <span>
              <strong>Holy Life</strong>
              <small>Live Healthy, Stay Fit</small>
            </span>
          </Link>
          <div className="auth-brand-copy">
            <span className="auth-eyebrow">
              {uiText(locale, "auth.oneSecureAccount")}
            </span>
            <h1>{uiText(locale, "auth.brandTitle")}</h1>
            <p>{uiText(locale, "auth.brandDescription")}</p>
          </div>
          <div className="auth-feature-list">
            <div>
              <Icon name="shield" size={18} />
              <span>{uiText(locale, "auth.featureSecure")}</span>
            </div>
            <div>
              <Icon name="appointment" size={18} />
              <span>{uiText(locale, "auth.featureAppointments")}</span>
            </div>
            <div>
              <Icon name="learning" size={18} />
              <span>{uiText(locale, "auth.featureLearning")}</span>
            </div>
            <div>
              <Icon name="package" size={18} />
              <span>{uiText(locale, "auth.featureOrders")}</span>
            </div>
          </div>
        </section>

        <section className="auth-form-panel">
          <div className="auth-card">
            <div className="auth-card-heading">
              <span>{eyebrow}</span>
              <h2>{title}</h2>
              <p>{description}</p>
            </div>
            {children}
            {footer ? <div className="auth-card-footer">{footer}</div> : null}
          </div>
          <Link className="auth-back-link" href="/">
            <Icon name="arrow-left" size={16} />{" "}
            {uiText(locale, "auth.backPublic")}
          </Link>
        </section>
      </div>
    </main>
  );
}

export function AuthAlert({
  type,
  children,
}: {
  type: "error" | "success" | "info";
  children: ReactNode;
}) {
  return (
    <div
      className={`auth-alert auth-alert-${type}`}
      role={type === "error" ? "alert" : "status"}
    >
      {children}
    </div>
  );
}

export async function PasswordRequirements() {
  const { locale } = await getUiPreferences();
  return (
    <p className="auth-field-help">
      {uiText(locale, "auth.passwordRequirements")}
    </p>
  );
}
