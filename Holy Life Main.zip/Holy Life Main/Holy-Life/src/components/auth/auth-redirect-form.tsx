import type { ReactNode } from "react";

export function AuthRedirectForm({
  action,
  className,
  children,
}: {
  action: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <form
      action={action}
      className={`${className ?? ""} auth-redirect-form`.trim()}
      method="post"
    >
      {children}
    </form>
  );
}
