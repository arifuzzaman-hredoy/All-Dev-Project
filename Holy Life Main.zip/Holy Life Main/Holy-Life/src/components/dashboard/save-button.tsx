export function SaveButton({
  itemType,
  referenceId,
  returnTo,
  saved,
  className = "ui-button ui-button-secondary",
}: {
  itemType: "DOCTOR" | "PRODUCT" | "COURSE";
  referenceId: string;
  returnTo: string;
  saved: boolean;
  className?: string;
}) {
  return (
    <form action="/api/dashboard/saved/toggle" method="post">
      <input name="itemType" type="hidden" value={itemType} />
      <input name="referenceId" type="hidden" value={referenceId} />
      <input name="returnTo" type="hidden" value={returnTo} />
      <button className={className} type="submit">
        {saved ? "Remove from saved" : "Save for later"}
      </button>
    </form>
  );
}
