import Link from "next/link";
import { Icon } from "@/components/ui/icon";
import { StatusBadge } from "@/components/ui/panel-ui";
import {
  dashboardStatusTone,
  titleCaseStatus,
  type DashboardActivityItem,
} from "@/lib/dashboard/status";

const dateFormatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

export function DashboardActivityList({
  items,
}: {
  items: DashboardActivityItem[];
}) {
  return (
    <div className="unified-activity-list">
      {items.map((item) => (
        <Link href={item.href} key={item.id}>
          <span
            className={`unified-activity-icon activity-${item.department.toLowerCase()}`}
          >
            <Icon
              name={
                item.department === "HEALTHCARE"
                  ? "appointment"
                  : item.department === "COMMERCE"
                    ? "package"
                    : item.department === "LEARNING"
                      ? "learning"
                      : "activity"
              }
              size={18}
            />
          </span>
          <span className="unified-activity-copy">
            <strong>{item.title}</strong>
            <small>{item.description}</small>
          </span>
          <span className="unified-activity-meta">
            <time dateTime={item.occurredAt.toISOString()}>
              {dateFormatter.format(item.occurredAt)}
            </time>
            {item.status ? (
              <StatusBadge tone={dashboardStatusTone(item.status)}>
                {titleCaseStatus(item.status)}
              </StatusBadge>
            ) : null}
          </span>
        </Link>
      ))}
    </div>
  );
}
