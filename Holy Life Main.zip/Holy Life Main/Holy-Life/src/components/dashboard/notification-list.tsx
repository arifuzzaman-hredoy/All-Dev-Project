import Link from "next/link";
import type { DashboardNotification } from "@/generated/prisma/client";
import { Icon } from "@/components/ui/icon";
import { StatusBadge } from "@/components/ui/panel-ui";
import { dashboardStatusTone, titleCaseStatus } from "@/lib/dashboard/status";

const dateFormatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

export function NotificationList({
  notifications,
}: {
  notifications: DashboardNotification[];
}) {
  return (
    <div className="unified-notification-list">
      {notifications.map((notification) => (
        <article
          className={notification.isRead ? "is-read" : "is-unread"}
          key={notification.id}
        >
          <span className="unified-notification-icon" aria-hidden="true">
            <Icon
              name={
                notification.department === "HEALTHCARE"
                  ? "heart"
                  : notification.department === "COMMERCE"
                    ? "shop"
                    : notification.department === "LEARNING"
                      ? "learning"
                      : "bell"
              }
              size={19}
            />
          </span>
          <div className="unified-notification-copy">
            <div>
              <strong>{notification.title}</strong>
              {!notification.isRead ? (
                <span className="unified-unread-dot" aria-label="Unread" />
              ) : null}
            </div>
            {notification.message ? <p>{notification.message}</p> : null}
            <span>{dateFormatter.format(notification.createdAt)}</span>
          </div>
          <div className="unified-notification-actions">
            <StatusBadge tone={dashboardStatusTone(notification.kind)}>
              {titleCaseStatus(notification.kind)}
            </StatusBadge>
            {notification.href ? (
              <Link
                className="ui-button ui-button-quiet"
                href={notification.href}
              >
                Open
              </Link>
            ) : null}
            {!notification.isRead ? (
              <form
                action={`/api/dashboard/notifications/${notification.id}/read`}
                method="post"
              >
                <input
                  name="returnTo"
                  type="hidden"
                  value="/dashboard/notifications"
                />
                <button className="ui-button ui-button-secondary" type="submit">
                  Mark read
                </button>
              </form>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}
