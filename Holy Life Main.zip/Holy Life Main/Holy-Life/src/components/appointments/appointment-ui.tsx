import Link from "next/link";
import type { ReactNode } from "react";
import { Icon } from "@/components/ui/icon";
import { StatusBadge } from "@/components/ui/panel-ui";
import {
  appointmentStatusLabel,
  appointmentStatusTone,
  type AppointmentStatusValue,
} from "@/lib/appointments/status";
import { formatDisplayTime } from "@/lib/appointments/time";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedOptionalText, localizedText } from "@/lib/i18n/content";
import { intlLocale, type Locale } from "@/lib/i18n/config";

export function AppointmentStatusBadge({
  status,
}: {
  status: AppointmentStatusValue;
}) {
  return (
    <StatusBadge tone={appointmentStatusTone(status)}>
      {appointmentStatusLabel(status)}
    </StatusBadge>
  );
}

export function AppointmentFlash({
  success,
  error,
}: {
  success?: string | null;
  error?: string | null;
}) {
  if (!success && !error) return null;
  return (
    <div
      className={`appointment-flash ${error ? "is-error" : "is-success"}`}
      role={error ? "alert" : "status"}
    >
      <Icon name={error ? "shield" : "activity"} size={18} />
      <span>{error ?? success}</span>
    </div>
  );
}

export function DoctorAvatar({
  name,
  imageUrl,
  size = "large",
}: {
  name: string;
  imageUrl?: string | null;
  size?: "small" | "large";
}) {
  const initials = name
    .replace(/^Dr\.?\s+/i, "")
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  return imageUrl ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      alt={name}
      className={`doctor-avatar doctor-avatar-${size}`}
      src={imageUrl}
    />
  ) : (
    <span
      aria-label={name}
      className={`doctor-avatar doctor-avatar-${size} doctor-avatar-fallback`}
    >
      {initials || "DR"}
    </span>
  );
}

export function DoctorCard({
  doctor,
  selectedDate,
  locale = "en",
}: {
  doctor: {
    id: string;
    slug: string;
    name: string;
    nameBn: string | null;
    designation: string;
    designationBn: string | null;
    specialization: string;
    specializationBn: string | null;
    qualifications: string | null;
    qualificationsBn: string | null;
    experienceYears: number;
    consultationFee: { toString(): string } | number | string;
    imageUrl: string | null;
    location: string | null;
    locationBn: string | null;
    roomLabel: string | null;
    roomLabelBn: string | null;
    isFeatured: boolean;
    department: { name: string; nameBn: string | null };
  };
  selectedDate: string;
  locale?: Locale;
}) {
  const numberLocale = intlLocale(locale);
  const name = localizedText(locale, doctor.name, doctor.nameBn);
  const departmentName = localizedText(
    locale,
    doctor.department.name,
    doctor.department.nameBn,
  );
  const designation = localizedText(
    locale,
    doctor.designation,
    doctor.designationBn,
  );
  const specialization = localizedText(
    locale,
    doctor.specialization,
    doctor.specializationBn,
  );
  const qualifications = localizedOptionalText(
    locale,
    doctor.qualifications,
    doctor.qualificationsBn,
  );
  const location = localizedOptionalText(
    locale,
    doctor.location,
    doctor.locationBn,
  );
  const roomLabel = localizedOptionalText(
    locale,
    doctor.roomLabel,
    doctor.roomLabelBn,
  );
  return (
    <article className="doctor-card">
      <div className="doctor-card-top">
        <DoctorAvatar imageUrl={doctor.imageUrl} name={name} />
        <div className="doctor-card-copy">
          <div className="doctor-card-heading">
            <div>
              <span className="content-kicker">{departmentName}</span>
              <h3>{name}</h3>
            </div>
            {doctor.isFeatured ? (
              <span className="doctor-featured">
                {uiText(locale, "appointment.featured")}
              </span>
            ) : null}
          </div>
          <p className="doctor-specialization">
            {designation} · {specialization}
          </p>
          {qualifications ? (
            <p className="doctor-qualification">{qualifications}</p>
          ) : null}
        </div>
      </div>
      <div className="doctor-facts">
        <span>
          <Icon name="activity" size={16} />
          {new Intl.NumberFormat(numberLocale).format(
            doctor.experienceYears,
          )}{" "}
          {uiText(locale, "appointment.yearsExperience")}
        </span>
        <span>
          <Icon name="appointment" size={16} />৳
          {Number(doctor.consultationFee).toLocaleString(numberLocale)}
        </span>
        {location || roomLabel ? (
          <span>
            <Icon name="home" size={16} />
            {[location, roomLabel].filter(Boolean).join(" · ")}
          </span>
        ) : null}
      </div>
      <div className="doctor-card-actions">
        <Link
          className="public-secondary-button"
          href={`/doctors/${doctor.slug}`}
        >
          {uiText(locale, "appointment.viewProfile")}
        </Link>
        <Link
          className="public-primary-button"
          href={`/appointment?doctorId=${encodeURIComponent(doctor.id)}&date=${selectedDate}#book`}
        >
          {uiText(locale, "appointment.checkAvailability")}
        </Link>
      </div>
    </article>
  );
}

export function SlotPicker({
  slots,
  selected,
  name = "startTime",
  locale = "en",
}: {
  slots: Array<{
    startTime: string;
    endTime: string;
    available: number;
    capacity: number;
  }>;
  selected?: string | null;
  name?: string;
  locale?: Locale;
}) {
  const numberLocale = intlLocale(locale);
  if (!slots.length) {
    return (
      <div className="appointment-empty-inline">
        <Icon name="calendar" size={21} />
        <div>
          <strong>{uiText(locale, "appointment.noSlots")}</strong>
          <span>{uiText(locale, "appointment.selectAnother")}</span>
        </div>
      </div>
    );
  }
  return (
    <div
      className="slot-grid"
      role="radiogroup"
      aria-label={uiText(locale, "appointment.availability")}
    >
      {slots.map((slot) => (
        <label
          className={`slot-option ${slot.available <= 0 ? "is-full" : ""}`}
          key={slot.startTime}
        >
          <input
            defaultChecked={selected === slot.startTime}
            disabled={slot.available <= 0}
            name={name}
            required
            type="radio"
            value={slot.startTime}
          />
          <span>
            <strong>{formatDisplayTime(slot.startTime, numberLocale)}</strong>
            <small>
              {slot.available > 0
                ? `${new Intl.NumberFormat(numberLocale).format(slot.available)} ${uiText(locale, "appointment.available")}`
                : uiText(locale, "appointment.full")}
            </small>
          </span>
        </label>
      ))}
    </div>
  );
}

export function AppointmentMeta({ children }: { children: ReactNode }) {
  return <div className="appointment-meta-grid">{children}</div>;
}

export function AppointmentMetaItem({
  icon,
  label,
  value,
}: {
  icon: "calendar" | "appointment" | "doctor" | "home" | "users" | "activity";
  label: string;
  value: ReactNode;
}) {
  return (
    <div className="appointment-meta-item">
      <Icon name={icon} size={18} />
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
    </div>
  );
}
