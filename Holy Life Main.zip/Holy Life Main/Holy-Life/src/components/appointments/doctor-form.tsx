import type {
  DoctorProfile,
  MedicalDepartment,
} from "@/generated/prisma/client";

export function DoctorForm({
  action,
  doctor,
  departments,
  submitLabel,
}: {
  action: string;
  doctor?: DoctorProfile | null;
  departments: MedicalDepartment[];
  submitLabel: string;
}) {
  return (
    <form action={action} className="admin-form-stack" method="post">
      <div className="admin-form-section">
        <div className="admin-form-section-heading">
          <strong>Identity & public profile</strong>
          <span>
            English and Bangla values are stored independently and shown
            according to the member language.
          </span>
        </div>
        <div className="admin-form-grid admin-form-grid-three">
          <label className="form-field">
            <span>Doctor code</span>
            <input
              defaultValue={doctor?.code ?? ""}
              maxLength={30}
              name="code"
              placeholder="DOC-0004"
              required
            />
          </label>
          <label className="form-field">
            <span>Full name (English)</span>
            <input
              defaultValue={doctor?.name ?? ""}
              maxLength={100}
              name="name"
              placeholder="Dr. Full Name"
              required
            />
          </label>
          <label className="form-field">
            <span>পূর্ণ নাম (বাংলা)</span>
            <input
              defaultValue={doctor?.nameBn ?? ""}
              maxLength={100}
              name="nameBn"
              placeholder="ডা. পূর্ণ নাম"
            />
          </label>
          <label className="form-field">
            <span>Public slug</span>
            <input
              defaultValue={doctor?.slug ?? ""}
              maxLength={80}
              name="slug"
              placeholder="dr-full-name"
            />
          </label>
          <label className="form-field">
            <span>Department</span>
            <select
              defaultValue={doctor?.departmentId ?? ""}
              name="departmentId"
              required
            >
              <option disabled value="">
                Select department
              </option>
              {departments.map((department) => (
                <option key={department.id} value={department.id}>
                  {department.name}
                  {department.nameBn ? ` / ${department.nameBn}` : ""}
                </option>
              ))}
            </select>
          </label>
          <label className="form-field">
            <span>Display order</span>
            <input
              defaultValue={doctor?.displayOrder ?? 100}
              min={0}
              name="displayOrder"
              type="number"
            />
          </label>
          <label className="form-field">
            <span>Designation (English)</span>
            <input
              defaultValue={doctor?.designation ?? "Consultant"}
              maxLength={100}
              name="designation"
              required
            />
          </label>
          <label className="form-field">
            <span>পদবি (বাংলা)</span>
            <input
              defaultValue={doctor?.designationBn ?? ""}
              maxLength={100}
              name="designationBn"
            />
          </label>
          <label className="form-field">
            <span>Experience (years)</span>
            <input
              defaultValue={doctor?.experienceYears ?? 0}
              max={80}
              min={0}
              name="experienceYears"
              type="number"
            />
          </label>
          <label className="form-field">
            <span>Specialization (English)</span>
            <input
              defaultValue={doctor?.specialization ?? ""}
              maxLength={160}
              name="specialization"
              required
            />
          </label>
          <label className="form-field">
            <span>বিশেষায়ন (বাংলা)</span>
            <input
              defaultValue={doctor?.specializationBn ?? ""}
              maxLength={160}
              name="specializationBn"
            />
          </label>
          <label className="form-field">
            <span>Profile image URL</span>
            <input
              defaultValue={doctor?.imageUrl ?? ""}
              maxLength={1000}
              name="imageUrl"
              type="url"
              placeholder="https://..."
            />
          </label>
          <label className="form-field">
            <span>Qualifications (English)</span>
            <input
              defaultValue={doctor?.qualifications ?? ""}
              maxLength={300}
              name="qualifications"
            />
          </label>
          <label className="form-field">
            <span>যোগ্যতা (বাংলা)</span>
            <input
              defaultValue={doctor?.qualificationsBn ?? ""}
              maxLength={300}
              name="qualificationsBn"
            />
          </label>
          <label className="form-field">
            <span>Status</span>
            {doctor ? (
              <select defaultValue={doctor.status} name="status">
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            ) : (
              <input disabled value="Active after creation" />
            )}
          </label>
        </div>
      </div>

      <div className="admin-form-section">
        <div className="admin-form-section-heading">
          <strong>Contact, chamber & fees</strong>
          <span>
            Only publish contact/chamber information approved for public use.
          </span>
        </div>
        <div className="admin-form-grid admin-form-grid-three">
          <label className="form-field">
            <span>Email</span>
            <input
              defaultValue={doctor?.email ?? ""}
              maxLength={254}
              name="email"
              type="email"
            />
          </label>
          <label className="form-field">
            <span>Mobile number</span>
            <input
              defaultValue={doctor?.phone ?? ""}
              inputMode="tel"
              maxLength={20}
              name="phone"
              placeholder="01XXXXXXXXX"
            />
          </label>
          <label className="form-field">
            <span>Consultation fee (BDT)</span>
            <input
              defaultValue={doctor ? Number(doctor.consultationFee) : 0}
              min={0}
              name="consultationFee"
              step="0.01"
              type="number"
            />
          </label>
          <label className="form-field">
            <span>Follow-up fee (BDT)</span>
            <input
              defaultValue={doctor ? Number(doctor.followUpFee) : 0}
              min={0}
              name="followUpFee"
              step="0.01"
              type="number"
            />
          </label>
          <label className="form-field">
            <span>Room / chamber (English)</span>
            <input
              defaultValue={doctor?.roomLabel ?? ""}
              maxLength={100}
              name="roomLabel"
            />
          </label>
          <label className="form-field">
            <span>কক্ষ / চেম্বার (বাংলা)</span>
            <input
              defaultValue={doctor?.roomLabelBn ?? ""}
              maxLength={100}
              name="roomLabelBn"
            />
          </label>
          <label className="form-field">
            <span>Location (English)</span>
            <input
              defaultValue={doctor?.location ?? "Holy Life, Rangpur"}
              maxLength={200}
              name="location"
            />
          </label>
          <label className="form-field">
            <span>স্থান (বাংলা)</span>
            <input
              defaultValue={doctor?.locationBn ?? "Holy Life, রংপুর"}
              maxLength={200}
              name="locationBn"
            />
          </label>
        </div>
      </div>

      <div className="admin-form-grid admin-form-grid-two">
        <label className="form-field">
          <span>Professional bio (English)</span>
          <textarea
            defaultValue={doctor?.bio ?? ""}
            maxLength={3000}
            name="bio"
            rows={7}
          />
        </label>
        <label className="form-field">
          <span>পেশাগত পরিচিতি (বাংলা)</span>
          <textarea
            defaultValue={doctor?.bioBn ?? ""}
            maxLength={3000}
            name="bioBn"
            rows={7}
          />
        </label>
      </div>
      <label className="form-check">
        <input
          defaultChecked={doctor?.isFeatured ?? false}
          name="isFeatured"
          type="checkbox"
        />
        <span>
          <strong>Featured doctor</strong>
          <small>
            Show this doctor earlier on public doctor and appointment listings.
          </small>
        </span>
      </label>
      <div className="admin-form-actions">
        <button className="ui-button ui-button-primary" type="submit">
          {submitLabel}
        </button>
      </div>
    </form>
  );
}
