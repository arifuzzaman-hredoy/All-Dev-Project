import Link from "next/link";
import {
  AppointmentFlash,
  AppointmentStatusBadge,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  TabBar,
} from "@/components/ui/panel-ui";
import { dashboardAppointments } from "@/lib/appointments/queries";
import { formatDisplayDate, formatDisplayTime } from "@/lib/appointments/time";

export async function DashboardAppointmentList({
  userId,
  mode,
  success,
  error,
}: {
  userId: string;
  mode: "all" | "upcoming" | "history";
  success?: string | null;
  error?: string | null;
}) {
  const appointments = await dashboardAppointments(userId, mode);
  const activePath =
    mode === "all"
      ? "/dashboard/healthcare/appointments"
      : `/dashboard/healthcare/appointments/${mode}`;
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Healthcare" },
          { label: "Appointments" },
        ]}
        description="Track every request, confirmed consultation, cancellation, and completed visit linked to your Holy Life account."
        eyebrow="My healthcare"
        title="My appointments"
        actions={
          <ButtonLink href="/appointment" icon="appointment">
            Book appointment
          </ButtonLink>
        }
      />
      <AppointmentFlash error={error} success={success} />
      <TabBar
        items={[
          {
            label: "All",
            href: "/dashboard/healthcare/appointments",
            active: mode === "all",
          },
          {
            label: "Upcoming",
            href: "/dashboard/healthcare/appointments/upcoming",
            active: mode === "upcoming",
          },
          {
            label: "History",
            href: "/dashboard/healthcare/appointments/history",
            active: mode === "history",
          },
        ]}
      />
      <SectionCard
        description={`${appointments.length} appointment${appointments.length === 1 ? "" : "s"} in this view.`}
        title={
          mode === "upcoming"
            ? "Upcoming appointments"
            : mode === "history"
              ? "Appointment history"
              : "All appointments"
        }
      >
        <div className="dashboard-appointment-list">
          {appointments.map((appointment) => (
            <Link
              className="dashboard-appointment-card"
              href={`/dashboard/healthcare/appointments/${appointment.id}`}
              key={appointment.id}
            >
              <DoctorAvatar
                imageUrl={appointment.doctor.imageUrl}
                name={appointment.doctor.name}
                size="small"
              />
              <div className="dashboard-appointment-main">
                <span className="content-kicker">{appointment.code}</span>
                <h3>{appointment.doctor.name}</h3>
                <p>
                  {appointment.doctor.specialization} ·{" "}
                  {appointment.serviceType}
                </p>
              </div>
              <div className="dashboard-appointment-date">
                <strong>
                  {formatDisplayDate(appointment.appointmentDate)}
                </strong>
                <span>{formatDisplayTime(appointment.startTime)}</span>
              </div>
              <AppointmentStatusBadge status={appointment.status} />
            </Link>
          ))}
          {appointments.length === 0 ? (
            <div className="appointment-empty-inline">
              <div>
                <strong>No appointments in this view</strong>
                <span>
                  Book a doctor consultation to start your patient history.
                </span>
              </div>
              <ButtonLink href="/appointment" variant="secondary">
                Browse doctors
              </ButtonLink>
            </div>
          ) : null}
        </div>
      </SectionCard>
      <span className="sr-only">Active path: {activePath}</span>
    </>
  );
}
