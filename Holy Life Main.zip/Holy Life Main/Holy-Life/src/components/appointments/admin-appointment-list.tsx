import Link from "next/link";
import { AppointmentStatus, Prisma } from "@/generated/prisma/client";
import {
  AppointmentFlash,
  AppointmentStatusBadge,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
} from "@/components/ui/panel-ui";
import {
  appointmentAccessWhere,
  doctorAccessWhere,
} from "@/lib/appointments/access";
import {
  dateInputToUtc,
  formatDisplayDate,
  formatDisplayTime,
  todayInDhaka,
} from "@/lib/appointments/time";
import { db } from "@/lib/db";
import type { AuthSession } from "@/lib/auth/session";

export type AppointmentListSearch = {
  status?: string;
  doctorId?: string;
  date?: string;
  q?: string;
  success?: string;
  error?: string;
};

export async function AdminAppointmentList({
  params,
  preset,
  session,
}: {
  params: AppointmentListSearch;
  preset?: "all" | "pending" | "today";
  session: AuthSession;
}) {
  const today = todayInDhaka();
  const statusValues = [
    "PENDING",
    "CONFIRMED",
    "CHECKED_IN",
    "IN_CONSULTATION",
    "COMPLETED",
    "CANCELLED",
    "NO_SHOW",
  ] as const;
  const status = statusValues.includes(
    params.status as (typeof statusValues)[number],
  )
    ? (params.status as (typeof statusValues)[number])
    : preset === "pending"
      ? AppointmentStatus.PENDING
      : undefined;
  const selectedDate = params.date || (preset === "today" ? today : "");
  const q = params.q?.trim().slice(0, 100) ?? "";
  const filters: Prisma.AppointmentWhereInput = {};
  if (status) filters.status = status;
  if (params.doctorId) filters.doctorId = params.doctorId;
  if (selectedDate) filters.appointmentDate = dateInputToUtc(selectedDate);
  if (q) {
    filters.OR = [
      { code: { contains: q, mode: "insensitive" } },
      { patientName: { contains: q, mode: "insensitive" } },
      { patientPhone: { contains: q } },
    ];
  }
  const scopeWhere = appointmentAccessWhere(session.user);
  const where: Prisma.AppointmentWhereInput = { AND: [scopeWhere, filters] };
  const [appointments, doctors, todayCounts] = await Promise.all([
    db.appointment.findMany({
      where,
      include: { doctor: true, department: true },
      orderBy: [{ appointmentDate: "desc" }, { startTime: "asc" }],
      take: 300,
    }),
    db.doctorProfile.findMany({
      where: {
        AND: [
          doctorAccessWhere(
            session.user,
            "healthcare.appointments.appointment.view",
          ),
          { status: { not: "ARCHIVED" } },
        ],
      },
      orderBy: { name: "asc" },
      select: { id: true, name: true },
    }),
    db.appointment.groupBy({
      where: { AND: [scopeWhere, { appointmentDate: dateInputToUtc(today) }] },
      by: ["status"],
      _count: { _all: true },
    }),
  ]);
  const count = (value: string) =>
    todayCounts.find((item) => item.status === value)?._count._all ?? 0;
  const activeQueue =
    count("PENDING") +
    count("CONFIRMED") +
    count("CHECKED_IN") +
    count("IN_CONSULTATION");
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Appointments" },
        ]}
        description="Manage live appointment requests, confirmation, check-in, consultation flow, completion, cancellation, and rescheduling."
        eyebrow="Appointment operations"
        title="Appointment management"
        actions={
          <ButtonLink
            href="/admin/healthcare/appointments/create"
            icon="appointment"
          >
            New appointment
          </ButtonLink>
        }
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <section className="metric-grid metric-grid-four">
        <MetricCard
          helper={`${count("PENDING")} pending`}
          icon="appointment"
          label="Today's queue"
          tone="health"
          value={String(activeQueue)}
        />
        <MetricCard
          helper="Ready for reception"
          icon="calendar"
          label="Confirmed"
          tone="success"
          value={String(count("CONFIRMED"))}
        />
        <MetricCard
          helper="Patient arrived"
          icon="users"
          label="Checked in"
          tone="warning"
          value={String(count("CHECKED_IN"))}
        />
        <MetricCard
          helper="Finished today"
          icon="activity"
          label="Completed"
          value={String(count("COMPLETED"))}
        />
      </section>
      <section className="filter-panel">
        <form className="filter-inline-form" method="get">
          <div className="filter-search-field">
            <span>⌕</span>
            <input
              defaultValue={q}
              name="q"
              placeholder="Code, patient, phone"
            />
          </div>
          <select defaultValue={status ?? ""} name="status">
            <option value="">All statuses</option>
            {statusValues.map((value) => (
              <option key={value} value={value}>
                {value.replaceAll("_", " ")}
              </option>
            ))}
          </select>
          <select defaultValue={params.doctorId ?? ""} name="doctorId">
            <option value="">All doctors</option>
            {doctors.map((doctor) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name}
              </option>
            ))}
          </select>
          <input defaultValue={selectedDate} name="date" type="date" />
          <button className="ui-button ui-button-secondary" type="submit">
            Apply
          </button>
          <Link
            className="ui-button ui-button-quiet"
            href="/admin/healthcare/appointments"
          >
            Reset
          </Link>
        </form>
      </section>
      <SectionCard
        description={`${appointments.length} appointment${appointments.length === 1 ? "" : "s"} in the current result.`}
        title="Appointment queue"
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Appointment</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date & time</th>
                <th>Serial</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {appointments.map((appointment) => (
                <tr key={appointment.id}>
                  <td>
                    <strong>{appointment.code}</strong>
                    <span>
                      {appointment.serviceType} · {appointment.source}
                    </span>
                  </td>
                  <td>
                    <strong>{appointment.patientName}</strong>
                    <span>{appointment.patientPhone}</span>
                  </td>
                  <td>
                    <strong>{appointment.doctor.name}</strong>
                    <span>{appointment.department.name}</span>
                  </td>
                  <td>
                    <strong>
                      {formatDisplayDate(appointment.appointmentDate)}
                    </strong>
                    <span>
                      {formatDisplayTime(appointment.startTime)}–
                      {formatDisplayTime(appointment.endTime)}
                    </span>
                  </td>
                  <td>
                    {appointment.serialNumber
                      ? `#${appointment.serialNumber}`
                      : "—"}
                  </td>
                  <td>
                    <AppointmentStatusBadge status={appointment.status} />
                  </td>
                  <td>
                    <Link
                      className="table-action-link"
                      href={`/admin/healthcare/appointments/${appointment.id}`}
                    >
                      Open
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {appointments.length === 0 ? (
            <div className="table-empty">
              No appointment matches the current filters.
            </div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
