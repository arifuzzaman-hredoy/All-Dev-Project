import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Holy Life",
    short_name: "Holy Life",
    description:
      "Doctor appointments, wellness learning, and selected healthy products in one member experience.",
    start_url: "/",
    display: "standalone",
    background_color: "#f5f7f8",
    theme_color: "#16705d",
    icons: [
      {
        src: "/brand-mark.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
