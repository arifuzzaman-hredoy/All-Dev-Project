import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import { AuthAlert, AuthShell } from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import { authConfig } from "@/lib/auth/config";
import { safeAdminReturnTo } from "@/lib/auth/request";
import {
  getCurrentSession,
  hasVerifiedContact,
  isAdminUser,
} from "@/lib/auth/session";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    success?: string;
    returnTo?: string;
  }>;
}) {
  const [params, preferences] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  const returnTo = safeAdminReturnTo(params.returnTo ?? null);
  const session = await getCurrentSession();
  const { locale } = preferences;

  if (session) {
    if (session.user.isSuperAdmin) redirect("/super-admin");
    if (!isAdminUser(session.user))
      redirect("/dashboard?error=admin-access-required");
    if (
      authConfig.requireVerifiedContact &&
      !hasVerifiedContact(session.user)
    ) {
      redirect(`/verify?returnTo=${encodeURIComponent(returnTo)}`);
    }
    redirect(returnTo);
  }

  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.adminOnly")}
      title={uiText(locale, "auth.adminSignInTitle")}
      description={uiText(locale, "auth.adminSignInDescription")}
      footer={
        <p>
          {uiText(locale, "auth.memberAccount")}{" "}
          <Link href="/login">{uiText(locale, "auth.memberSignIn")}</Link>
          {" · "}
          <Link href="/super-admin">
            {uiText(locale, "auth.superAdminSignIn")}
          </Link>
        </p>
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      {params.success ? (
        <AuthAlert type="success">{params.success}</AuthAlert>
      ) : null}
      <AuthRedirectForm action="/api/admin/login" className="auth-form">
        <input name="returnTo" type="hidden" value={returnTo} />
        <label className="auth-field">
          <span>{uiText(locale, "auth.emailOrPhone")}</span>
          <input
            autoComplete="username"
            maxLength={254}
            name="identifier"
            placeholder="admin@example.com or 01XXXXXXXXX"
            required
          />
        </label>
        <PasswordInput
          autoComplete="current-password"
          label={uiText(locale, "auth.password")}
          name="password"
          placeholder={uiText(locale, "auth.enterPassword")}
        />
        <p className="auth-field-help">
          {uiText(locale, "auth.adminCredentialHelp")}
        </p>
        <button className="public-primary-button auth-submit" type="submit">
          {uiText(locale, "auth.openAdmin")}
        </button>
      </AuthRedirectForm>
    </AuthShell>
  );
}
