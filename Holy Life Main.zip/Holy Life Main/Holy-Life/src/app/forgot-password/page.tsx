import Link from "next/link";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import { AuthAlert, AuthShell } from "@/components/auth/auth-shell";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function ForgotPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const [params, { locale }] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.accountRecovery")}
      title={uiText(locale, "auth.resetPasswordTitle")}
      description={uiText(locale, "auth.resetPasswordDescription")}
      footer={
        <p>
          {uiText(locale, "auth.rememberedPassword")}{" "}
          <Link href="/login">{uiText(locale, "auth.returnSignIn")}</Link>
        </p>
      }
    >
      {params.success ? (
        <AuthAlert type="success">{params.success}</AuthAlert>
      ) : null}
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      <AuthRedirectForm
        action="/api/auth/forgot-password"
        className="auth-form"
      >
        <label className="auth-field">
          <span>{uiText(locale, "auth.emailOrPhone")}</span>
          <input
            autoComplete="username"
            maxLength={254}
            name="identifier"
            placeholder="name@example.com or 01XXXXXXXXX"
            required
          />
        </label>
        <button className="public-primary-button auth-submit" type="submit">
          {uiText(locale, "auth.sendReset")}
        </button>
      </AuthRedirectForm>
    </AuthShell>
  );
}
