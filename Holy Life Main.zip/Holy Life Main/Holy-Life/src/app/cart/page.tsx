import { CartView } from "@/components/commerce/cart-view";
import { PublicShell } from "@/components/layout/public-shell";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";

export const dynamic = "force-dynamic";

export default async function CartPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const session = await requireAuthenticatedSession("/cart");
  const query = await searchParams;
  return (
    <PublicShell>
      <div className="public-container commerce-public-account-page">
        <CartView
          userId={session.user.id}
          error={query.error}
          success={query.success}
        />
      </div>
    </PublicShell>
  );
}
