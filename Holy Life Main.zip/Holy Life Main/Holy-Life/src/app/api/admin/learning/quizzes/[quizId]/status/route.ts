import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
const statuses = ["DRAFT", "PUBLISHED", "ARCHIVED"] as const;
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ quizId: string }> },
): Promise<NextResponse> {
  const { quizId } = await params;
  const path = `/admin/learning/assessments/${quizId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.assessments.quiz.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Quiz permission is required.",
      );
    const form = await readForm(request);
    const raw = String(form.get("status") ?? "");
    if (!statuses.includes(raw as (typeof statuses)[number]))
      return learningRedirect(
        request,
        path,
        "error",
        "Quiz status is invalid.",
      );
    await db.quiz.update({
      where: { id: quizId },
      data: { status: raw as (typeof statuses)[number] },
    });
    return learningRedirect(request, path, "success", "Quiz status updated.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Quiz status could not be updated.",
    );
  }
}
