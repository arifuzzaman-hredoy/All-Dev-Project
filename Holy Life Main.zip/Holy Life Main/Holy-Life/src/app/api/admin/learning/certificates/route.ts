import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { learningRedirect } from "@/lib/learning/api";
import { issueCertificate, LearningError } from "@/lib/learning/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/enrollments";

  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.certificates.certificate.issue")
    ) {
      return learningRedirect(
        request,
        path,
        "error",
        "Certificate permission is required.",
      );
    }

    const form = await readForm(request);
    const certificate = await issueCertificate({
      enrollmentId: String(form.get("enrollmentId") ?? ""),
      issuedById: session.user.id,
    });

    await createDashboardNotification({
      userId: certificate.userId,
      dedupeKey: `certificate:${certificate.id}:issued`,
      kind: "SUCCESS",
      department: "LEARNING",
      title: "Course certificate issued",
      message: certificate.code,
      href: "/dashboard/learning/certificates",
    });

    return learningRedirect(request, path, "success", "Certificate issued.");
  } catch (error) {
    return learningRedirect(
      request,
      path,
      "error",
      error instanceof LearningError
        ? error.message
        : "Certificate could not be issued.",
    );
  }
}
