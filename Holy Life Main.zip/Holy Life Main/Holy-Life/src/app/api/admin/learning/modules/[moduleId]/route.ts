import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  integerValue,
  optionalText,
  requiredText,
} from "@/lib/learning/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ moduleId: string }> },
): Promise<NextResponse> {
  const { moduleId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    const form = await readForm(request);
    const courseId = requiredText(form, "courseId", 100);
    const path = `/admin/learning/courses/${courseId}`;
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.module.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Module permission is required.",
      );
    const exists = await db.courseModule.findFirst({
      where: { id: moduleId, courseId },
      select: { id: true },
    });
    if (!exists)
      return learningRedirect(request, path, "error", "Module not found.");
    await db.courseModule.update({
      where: { id: moduleId },
      data: {
        title: requiredText(form, "title", 160),
        titleBn: optionalText(form, "titleBn", 160),
        description: optionalText(form, "description", 1000),
        descriptionBn: optionalText(form, "descriptionBn", 1000),
        position: integerValue(form, "position", 1, 1000, 1),
        isPublished: String(form.get("isPublished")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Module updated.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      "/admin/learning/courses",
      "error",
      "Module could not be updated. Check position.",
    );
  }
}
