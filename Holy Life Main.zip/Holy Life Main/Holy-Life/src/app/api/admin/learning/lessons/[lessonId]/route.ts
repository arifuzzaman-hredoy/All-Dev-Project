import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  integerValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

const types = ["VIDEO", "ARTICLE", "DOCUMENT", "LIVE"] as const;

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ lessonId: string }> },
): Promise<NextResponse> {
  const { lessonId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    const form = await readForm(request);
    const courseId = requiredText(form, "courseId", 100);
    const moduleId = requiredText(form, "moduleId", 100);
    const path = `/admin/learning/courses/${courseId}`;
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.lesson.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Lesson permission is required.",
      );
    const exists = await db.courseLesson.findFirst({
      where: { id: lessonId, moduleId, module: { courseId } },
      select: { id: true },
    });
    if (!exists)
      return learningRedirect(request, path, "error", "Lesson not found.");
    const title = requiredText(form, "title", 180);
    const rawType = String(form.get("type") ?? "ARTICLE");
    const type = types.includes(rawType as (typeof types)[number])
      ? (rawType as (typeof types)[number])
      : "ARTICLE";
    await db.courseLesson.update({
      where: { id: lessonId },
      data: {
        title,
        titleBn: optionalText(form, "titleBn", 180),
        slug: slugify(title),
        type,
        summary: optionalText(form, "summary", 1000),
        summaryBn: optionalText(form, "summaryBn", 1000),
        content: optionalText(form, "content", 20000),
        contentBn: optionalText(form, "contentBn", 20000),
        videoUrl: optionalText(form, "videoUrl", 1000),
        documentUrl: optionalText(form, "documentUrl", 1000),
        durationMinutes: integerValue(form, "durationMinutes", 0, 10000, 0),
        position: integerValue(form, "position", 1, 1000, 1),
        isPreview: String(form.get("isPreview")) === "true",
        isPublished: String(form.get("isPublished")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Lesson updated.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      "/admin/learning/courses",
      "error",
      "Lesson could not be updated. Check position or slug.",
    );
  }
}
