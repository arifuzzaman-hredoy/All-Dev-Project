import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  decimalValue,
  integerValue,
  listValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

const statuses = ["DRAFT", "PUBLISHED", "UNPUBLISHED", "ARCHIVED"] as const;
const levels = ["BEGINNER", "INTERMEDIATE", "ADVANCED", "ALL_LEVELS"] as const;

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ courseId: string }> },
): Promise<NextResponse> {
  const { courseId } = await params;
  const path = `/admin/learning/courses/${courseId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    const form = await readForm(request);
    const intent = String(form.get("intent") ?? "status");

    if (intent === "status") {
      if (
        !session ||
        !hasPermission(session.user, "learning.courses.course.publish")
      )
        return learningRedirect(
          request,
          path,
          "error",
          "Publishing permission is required.",
        );
      const raw = String(form.get("status") ?? "");
      if (!statuses.includes(raw as (typeof statuses)[number]))
        return learningRedirect(
          request,
          path,
          "error",
          "Invalid course status.",
        );
      const status = raw as (typeof statuses)[number];
      await db.course.update({
        where: { id: courseId },
        data: {
          status,
          publishedAt: status === "PUBLISHED" ? new Date() : undefined,
          archivedAt: status === "ARCHIVED" ? new Date() : null,
          updatedById: session.user.id,
        },
      });
      return learningRedirect(
        request,
        path,
        "success",
        "Course status updated.",
      );
    }

    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.edit")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Course edit permission is required.",
      );
    const rawLevel = String(form.get("level") ?? "ALL_LEVELS");
    const level = levels.includes(rawLevel as (typeof levels)[number])
      ? (rawLevel as (typeof levels)[number])
      : "ALL_LEVELS";
    const compareAt = optionalText(form, "compareAtPrice", 50);
    await db.course.update({
      where: { id: courseId },
      data: {
        title: requiredText(form, "title", 160),
        titleBn: optionalText(form, "titleBn", 160),
        slug: slugify(requiredText(form, "slug", 120)),
        categoryId: requiredText(form, "categoryId", 100),
        instructorId: optionalText(form, "instructorId", 100),
        shortDescription: optionalText(form, "shortDescription", 500),
        shortDescriptionBn: optionalText(form, "shortDescriptionBn", 500),
        description: optionalText(form, "description", 10000),
        descriptionBn: optionalText(form, "descriptionBn", 10000),
        learningOutcomes: listValue(
          optionalText(form, "learningOutcomes", 3000),
        ),
        learningOutcomesBn: listValue(
          optionalText(form, "learningOutcomesBn", 3000),
        ),
        requirements: listValue(optionalText(form, "requirements", 3000)),
        requirementsBn: listValue(optionalText(form, "requirementsBn", 3000)),
        level,
        language: optionalText(form, "language", 60) ?? "Bangla",
        thumbnailUrl: optionalText(form, "thumbnailUrl", 1000),
        trailerUrl: optionalText(form, "trailerUrl", 1000),
        price: decimalValue(form, "price"),
        compareAtPrice: compareAt ? decimalValue(form, "compareAtPrice") : null,
        estimatedMinutes: integerValue(form, "estimatedMinutes", 0, 100000, 0),
        isFeatured: String(form.get("isFeatured")) === "true",
        allowSelfEnrollment: String(form.get("allowSelfEnrollment")) === "true",
        certificateEnabled: String(form.get("certificateEnabled")) === "true",
        updatedById: session.user.id,
      },
    });
    return learningRedirect(
      request,
      path,
      "success",
      "Course details updated.",
    );
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Course could not be updated. Check slug, category and field values.",
    );
  }
}
