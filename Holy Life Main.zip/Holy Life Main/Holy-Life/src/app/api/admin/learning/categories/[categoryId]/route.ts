import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  integerValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ categoryId: string }> },
): Promise<NextResponse> {
  const path = "/admin/learning/courses/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.edit")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Category permission is required.",
      );
    const { categoryId } = await params;
    const form = await readForm(request);
    await db.courseCategory.update({
      where: { id: categoryId },
      data: {
        name: requiredText(form, "name", 100),
        nameBn: optionalText(form, "nameBn", 100),
        slug: slugify(requiredText(form, "slug", 120)),
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        displayOrder: integerValue(form, "displayOrder", 0, 100000, 0),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Category updated.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Category could not be updated. Check the slug and field values.",
    );
  }
}
