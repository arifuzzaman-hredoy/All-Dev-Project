import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  decimalValue,
  integerValue,
  listValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

const levels = ["BEGINNER", "INTERMEDIATE", "ADVANCED", "ALL_LEVELS"] as const;

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/courses/create";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.create")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Course creation permission is required.",
      );
    const form = await readForm(request);
    const title = requiredText(form, "title", 160);
    const rawLevel = String(form.get("level") ?? "ALL_LEVELS");
    const level = levels.includes(rawLevel as (typeof levels)[number])
      ? (rawLevel as (typeof levels)[number])
      : "ALL_LEVELS";
    const compareAt = optionalText(form, "compareAtPrice", 50);
    const course = await db.course.create({
      data: {
        title,
        titleBn: optionalText(form, "titleBn", 160),
        slug: slugify(optionalText(form, "slug", 120) ?? title),
        categoryId: requiredText(form, "categoryId", 100),
        instructorId: optionalText(form, "instructorId", 100),
        shortDescription: optionalText(form, "shortDescription", 500),
        shortDescriptionBn: optionalText(form, "shortDescriptionBn", 500),
        description: optionalText(form, "description", 10000),
        descriptionBn: optionalText(form, "descriptionBn", 10000),
        learningOutcomes: listValue(
          optionalText(form, "learningOutcomes", 3000),
        ),
        learningOutcomesBn: listValue(
          optionalText(form, "learningOutcomesBn", 3000),
        ),
        requirements: listValue(optionalText(form, "requirements", 3000)),
        requirementsBn: listValue(optionalText(form, "requirementsBn", 3000)),
        level,
        language: optionalText(form, "language", 60) ?? "Bangla",
        thumbnailUrl: optionalText(form, "thumbnailUrl", 1000),
        trailerUrl: optionalText(form, "trailerUrl", 1000),
        price: decimalValue(form, "price"),
        compareAtPrice: compareAt ? decimalValue(form, "compareAtPrice") : null,
        estimatedMinutes: integerValue(form, "estimatedMinutes", 0, 100000, 0),
        isFeatured: String(form.get("isFeatured")) === "true",
        allowSelfEnrollment: String(form.get("allowSelfEnrollment")) === "true",
        certificateEnabled: String(form.get("certificateEnabled")) === "true",
        createdById: session.user.id,
        updatedById: session.user.id,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "LEARNING",
      targetType: "Course",
      targetId: course.id,
      metadata: { title: course.title, slug: course.slug },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return NextResponse.redirect(
      new URL(
        `/admin/learning/courses/${course.id}?success=${encodeURIComponent("Course created.")}`,
        request.url,
      ),
      303,
    );
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Course could not be created. Check category and duplicate slug.",
    );
  }
}
