import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  listValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ instructorId: string }> },
): Promise<NextResponse> {
  const path = "/admin/learning/courses/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.edit")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Instructor permission is required.",
      );
    const { instructorId } = await params;
    const form = await readForm(request);
    await db.instructorProfile.update({
      where: { id: instructorId },
      data: {
        name: requiredText(form, "name", 120),
        nameBn: optionalText(form, "nameBn", 120),
        slug: slugify(requiredText(form, "slug", 120)),
        title: optionalText(form, "title", 160),
        titleBn: optionalText(form, "titleBn", 160),
        bio: optionalText(form, "bio", 2000),
        bioBn: optionalText(form, "bioBn", 2000),
        expertise: listValue(optionalText(form, "expertise", 500)),
        expertiseBn: listValue(optionalText(form, "expertiseBn", 500)),
        photoUrl: optionalText(form, "photoUrl", 1000),
        email: optionalText(form, "email", 200),
        phone: optionalText(form, "phone", 30),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Instructor updated.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Instructor could not be updated. Check slug and field values.",
    );
  }
}
