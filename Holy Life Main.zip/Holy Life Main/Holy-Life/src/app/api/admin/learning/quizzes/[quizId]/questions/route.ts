import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  integerValue,
  optionalText,
  requiredText,
} from "@/lib/learning/validation";
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ quizId: string }> },
): Promise<NextResponse> {
  const { quizId } = await params;
  const path = `/admin/learning/assessments/${quizId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.assessments.quiz.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Quiz permission is required.",
      );
    const form = await readForm(request);
    const correctOption = String(form.get("correctOption") ?? "A");
    const labels = ["A", "B", "C", "D"] as const;
    if (!labels.includes(correctOption as (typeof labels)[number]))
      return learningRedirect(
        request,
        path,
        "error",
        "Correct option is invalid.",
      );
    const count = await db.quizQuestion.count({ where: { quizId } });
    await db.quizQuestion.create({
      data: {
        quizId,
        prompt: requiredText(form, "prompt", 500),
        explanation: optionalText(form, "explanation", 2000),
        points: integerValue(form, "points", 1, 100, 1),
        position: count + 1,
        options: {
          create: labels.map((label, index) => ({
            label: requiredText(form, `option${label}`, 300),
            position: index + 1,
            isCorrect: label === correctOption,
          })),
        },
      },
    });
    return learningRedirect(request, path, "success", "Question added.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Question could not be added.",
    );
  }
}
