import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import { integerValue, requiredText } from "@/lib/learning/validation";
export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/assessments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.assessments.quiz.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Quiz permission is required.",
      );
    const form = await readForm(request);
    await db.quiz.create({
      data: {
        courseId: requiredText(form, "courseId", 100),
        title: requiredText(form, "title", 160),
        passingScore: integerValue(form, "passingScore", 0, 100, 60),
      },
    });
    return learningRedirect(request, path, "success", "Quiz created.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Quiz could not be created.",
    );
  }
}
