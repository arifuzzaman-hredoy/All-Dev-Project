import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  listValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/courses/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.edit")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Instructor permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 120);
    await db.instructorProfile.create({
      data: {
        name,
        nameBn: optionalText(form, "nameBn", 120),
        slug: slugify(name),
        title: optionalText(form, "title", 160),
        titleBn: optionalText(form, "titleBn", 160),
        bio: optionalText(form, "bio", 2000),
        bioBn: optionalText(form, "bioBn", 2000),
        expertise: listValue(optionalText(form, "expertise", 500)),
        expertiseBn: listValue(optionalText(form, "expertiseBn", 500)),
        photoUrl: optionalText(form, "photoUrl", 1000),
        email: optionalText(form, "email", 200),
        phone: optionalText(form, "phone", 30),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Instructor created.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Instructor could not be created. Check name and contact values.",
    );
  }
}
