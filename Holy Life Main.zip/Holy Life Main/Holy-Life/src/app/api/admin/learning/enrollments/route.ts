import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { learningRedirect } from "@/lib/learning/api";
import { enrollStudent, LearningError } from "@/lib/learning/service";
export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/enrollments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.enrollments.enrollment.manage")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Enrollment permission is required.",
      );
    const form = await readForm(request);
    await enrollStudent({
      courseId: String(form.get("courseId") ?? ""),
      userId: String(form.get("userId") ?? ""),
      managedById: session.user.id,
    });
    return learningRedirect(request, path, "success", "Student enrolled.");
  } catch (error) {
    return learningRedirect(
      request,
      path,
      "error",
      error instanceof LearningError
        ? error.message
        : "Student could not be enrolled.",
    );
  }
}
