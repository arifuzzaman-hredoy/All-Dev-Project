import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import {
  integerValue,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/learning/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/learning/courses/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "learning.courses.course.edit")
    )
      return learningRedirect(
        request,
        path,
        "error",
        "Category permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 100);
    const slug = slugify(optionalText(form, "slug", 120) ?? name);
    await db.courseCategory.create({
      data: {
        name,
        nameBn: optionalText(form, "nameBn", 100),
        slug,
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        displayOrder: integerValue(form, "displayOrder", 0, 100000, 0),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    return learningRedirect(request, path, "success", "Category created.");
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      path,
      "error",
      "Category could not be created. Check the slug and field values.",
    );
  }
}
