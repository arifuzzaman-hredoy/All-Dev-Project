import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { messagingRedirect } from "@/lib/messaging/api";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ campaignId: string }> },
): Promise<NextResponse> {
  const path = "/admin/messages";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.messaging.campaign.cancel")
    ) {
      return messagingRedirect(
        request,
        path,
        "error",
        "Campaign cancellation permission is required.",
      );
    }
    const { campaignId } = await params;
    const campaign = await db.$transaction(async (tx) => {
      const current = await tx.messagingCampaign.findUnique({
        where: { id: campaignId },
      });
      if (!current) throw new Error("Messaging campaign was not found.");
      if (current.status === "COMPLETED" || current.status === "CANCELED") {
        throw new Error("Only queued or processing campaigns can be canceled.");
      }
      await tx.messagingDelivery.updateMany({
        where: { campaignId, status: "QUEUED" },
        data: { status: "CANCELED", lockedAt: null },
      });
      return tx.messagingCampaign.update({
        where: { id: campaignId },
        data: { status: "CANCELED", completedAt: new Date() },
      });
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "SYSTEM",
      targetType: "MessagingCampaign",
      targetId: campaign.id,
      metadata: { code: campaign.code, status: campaign.status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return messagingRedirect(
      request,
      path,
      "success",
      `Campaign ${campaign.code} canceled. In-flight provider requests cannot be recalled.`,
    );
  } catch (error) {
    console.error("Messaging campaign cancellation failed", error);
    return messagingRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Campaign could not be canceled.",
    );
  }
}
