import { NextRequest, NextResponse } from "next/server";
import type {
  DepartmentCode,
  MessagingTemplateStatus,
} from "@/generated/prisma/client";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { messagingRedirect } from "@/lib/messaging/api";
import {
  messagingChannel,
  messagingText,
  optionalMessagingText,
  templateCode,
} from "@/lib/messaging/validation";

const DEPARTMENTS = [
  "HEALTHCARE",
  "COMMERCE",
  "LEARNING",
  "WEBSITE",
  "SYSTEM",
] as const;
const STATUSES = ["DRAFT", "ACTIVE"] as const;

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/messages";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.messaging.template.manage")
    ) {
      return messagingRedirect(
        request,
        path,
        "error",
        "Template management permission is required.",
      );
    }

    const form = await readForm(request);
    const code = templateCode(form.get("code"));
    const name = messagingText(form.get("name"), 120, "Template name");
    const channel = messagingChannel(form.get("channel"));
    const subject = optionalMessagingText(form.get("subject"), 240);
    const body = messagingText(form.get("body"), 4000, "Template body");
    const departmentRaw = String(form.get("department") ?? "SYSTEM");
    const statusRaw = String(form.get("status") ?? "DRAFT");
    if (!DEPARTMENTS.includes(departmentRaw as (typeof DEPARTMENTS)[number]))
      throw new Error("Department is invalid.");
    if (!STATUSES.includes(statusRaw as (typeof STATUSES)[number]))
      throw new Error("Template status is invalid.");
    if (channel === "EMAIL" && !subject)
      throw new Error("Email templates require a subject.");
    const existing = await db.messagingTemplate.findUnique({
      where: { code },
      select: { id: true },
    });
    if (existing) throw new Error("Template code already exists.");

    const template = await db.messagingTemplate.create({
      data: {
        code,
        name,
        channel,
        department: departmentRaw as DepartmentCode,
        subject,
        body,
        status: statusRaw as MessagingTemplateStatus,
        createdById: session.user.id,
        updatedById: session.user.id,
      },
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: "MessagingTemplate",
      targetId: template.id,
      metadata: {
        code: template.code,
        channel: template.channel,
        status: template.status,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return messagingRedirect(
      request,
      path,
      "success",
      `Template ${template.code} created.`,
    );
  } catch (error) {
    console.error("Messaging template creation failed", error);
    return messagingRedirect(
      request,
      path,
      "error",
      error instanceof Error ? error.message : "Template could not be created.",
    );
  }
}
