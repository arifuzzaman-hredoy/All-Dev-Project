import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { messagingRedirect } from "@/lib/messaging/api";
import { retryMessagingDelivery } from "@/lib/messaging/service";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ deliveryId: string }> },
): Promise<NextResponse> {
  const path = "/admin/messages";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.messaging.delivery.retry")
    ) {
      return messagingRedirect(
        request,
        path,
        "error",
        "Delivery retry permission is required.",
      );
    }
    const { deliveryId } = await params;
    await retryMessagingDelivery(deliveryId);
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "SYSTEM",
      targetType: "MessagingDelivery",
      targetId: deliveryId,
      metadata: { status: "QUEUED", reason: "manual-retry" },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return messagingRedirect(
      request,
      path,
      "success",
      "Failed delivery queued for retry.",
    );
  } catch (error) {
    console.error("Messaging delivery retry failed", error);
    return messagingRedirect(
      request,
      path,
      "error",
      error instanceof Error ? error.message : "Delivery could not be retried.",
    );
  }
}
