import { NextRequest, NextResponse } from "next/server";
import type {
  DepartmentCode,
  MessagingAudience,
} from "@/generated/prisma/client";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { messagingRedirect } from "@/lib/messaging/api";
import { queueMessagingCampaign } from "@/lib/messaging/service";
import {
  messagingChannel,
  messagingPurpose,
  messagingText,
  optionalMessagingText,
  scheduledDate,
} from "@/lib/messaging/validation";

const AUDIENCES = ["USER", "ALL_ACTIVE"] as const;
const DEPARTMENTS = [
  "HEALTHCARE",
  "COMMERCE",
  "LEARNING",
  "WEBSITE",
  "SYSTEM",
] as const;

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/messages";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.messaging.campaign.send")
    ) {
      return messagingRedirect(
        request,
        path,
        "error",
        "Messaging send permission is required.",
      );
    }

    const form = await readForm(request);
    const name = messagingText(form.get("name"), 140, "Campaign name");
    const channel = messagingChannel(form.get("channel"));
    const purpose = messagingPurpose(form.get("purpose"));
    const audienceRaw = String(form.get("audience") ?? "USER");
    if (!AUDIENCES.includes(audienceRaw as (typeof AUDIENCES)[number]))
      throw new Error("Audience is invalid.");
    const audience = audienceRaw as MessagingAudience;
    const recipient = optionalMessagingText(form.get("recipient"), 320);
    if (audience === "USER" && !recipient)
      throw new Error(
        "Recipient email or phone is required for a single-user campaign.",
      );

    const departmentRaw = String(form.get("department") ?? "SYSTEM");
    if (!DEPARTMENTS.includes(departmentRaw as (typeof DEPARTMENTS)[number]))
      throw new Error("Department is invalid.");

    const result = await queueMessagingCampaign({
      actorId: session.user.id,
      name,
      channel,
      purpose,
      audience,
      recipient,
      department: departmentRaw as DepartmentCode,
      templateId: optionalMessagingText(form.get("templateId"), 80),
      subject: optionalMessagingText(form.get("subject"), 240),
      body: optionalMessagingText(form.get("body"), 4000),
      scheduledAt: scheduledDate(form.get("scheduledAt")),
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: "MessagingCampaign",
      targetId: result.campaign.id,
      metadata: {
        code: result.campaign.code,
        channel: result.campaign.channel,
        purpose: result.campaign.purpose,
        audience: result.campaign.audience,
        recipients: result.recipients,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return messagingRedirect(
      request,
      path,
      "success",
      `${result.recipients} delivery${result.recipients === 1 ? "" : "ies"} queued.`,
    );
  } catch (error) {
    console.error("Messaging campaign creation failed", error);
    return messagingRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Message campaign could not be queued.",
    );
  }
}
