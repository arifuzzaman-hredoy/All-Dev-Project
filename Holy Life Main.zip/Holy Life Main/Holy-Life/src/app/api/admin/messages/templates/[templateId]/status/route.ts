import { NextRequest, NextResponse } from "next/server";
import type { MessagingTemplateStatus } from "@/generated/prisma/client";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { messagingRedirect } from "@/lib/messaging/api";

const STATUSES = ["DRAFT", "ACTIVE", "ARCHIVED"] as const;

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ templateId: string }> },
): Promise<NextResponse> {
  const path = "/admin/messages";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.messaging.template.manage")
    ) {
      return messagingRedirect(
        request,
        path,
        "error",
        "Template management permission is required.",
      );
    }
    const form = await readForm(request);
    const statusRaw = String(form.get("status") ?? "");
    if (!STATUSES.includes(statusRaw as (typeof STATUSES)[number]))
      throw new Error("Template status is invalid.");
    const { templateId } = await params;
    const template = await db.messagingTemplate.update({
      where: { id: templateId },
      data: {
        status: statusRaw as MessagingTemplateStatus,
        updatedById: session.user.id,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "SYSTEM",
      targetType: "MessagingTemplate",
      targetId: template.id,
      metadata: { code: template.code, status: template.status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return messagingRedirect(
      request,
      path,
      "success",
      `Template ${template.code} is now ${template.status.toLowerCase()}.`,
    );
  } catch (error) {
    console.error("Messaging template status update failed", error);
    return messagingRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Template status could not be updated.",
    );
  }
}
