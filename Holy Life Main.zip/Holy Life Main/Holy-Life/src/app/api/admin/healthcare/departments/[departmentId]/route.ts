import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import {
  formInteger,
  formLongText,
  formText,
} from "@/lib/appointments/validation";
import { db } from "@/lib/db";

function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ departmentId: string }> },
): Promise<NextResponse> {
  const { departmentId } = await params;
  const path = "/admin/healthcare/departments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.department.edit")
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Department edit permission is required.",
      );
    const form = await readForm(request);
    const name = formText(form, "name", 100);
    const code = formText(form, "code", 40)
      .toUpperCase()
      .replace(/[^A-Z0-9_]/g, "_")
      .replace(/^_+|_+$/g, "");
    const slug = slugify(formText(form, "slug", 80) || name);
    if (name.length < 2 || code.length < 2 || slug.length < 2)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Name, code, and a valid slug are required.",
      );
    const duplicate = await db.medicalDepartment.findFirst({
      where: { id: { not: departmentId }, OR: [{ code }, { slug }] },
      select: { id: true },
    });
    if (duplicate)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Department code or slug already exists.",
      );
    const department = await db.medicalDepartment.update({
      where: { id: departmentId },
      data: {
        name,
        nameBn: formText(form, "nameBn", 100) || null,
        code,
        slug,
        description: formLongText(form, "description", 500) || null,
        descriptionBn: formLongText(form, "descriptionBn", 500) || null,
        displayOrder: formInteger(form, "displayOrder", 100, 0, 10000),
        isActive: true,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "MedicalDepartment",
      targetId: department.id,
      metadata: { code, slug, name },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      path,
      "success",
      "Medical department updated.",
    );
  } catch (error) {
    console.error("Medical department update failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Medical department could not be updated.",
    );
  }
}
