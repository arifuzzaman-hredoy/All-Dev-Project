import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import { appointmentAccessWhere } from "@/lib/appointments/access";
import {
  APPOINTMENT_STATUSES,
  canTransitionAppointment,
  type AppointmentStatusValue,
} from "@/lib/appointments/status";
import { formLongText, formText } from "@/lib/appointments/validation";
import { db } from "@/lib/db";
import { createDashboardNotification } from "@/lib/dashboard/notifications";

const PERMISSION_BY_STATUS: Partial<Record<AppointmentStatusValue, string>> = {
  CONFIRMED: "healthcare.appointments.appointment.confirm",
  CHECKED_IN: "healthcare.appointments.appointment.edit",
  IN_CONSULTATION: "healthcare.appointments.appointment.edit",
  COMPLETED: "healthcare.appointments.appointment.complete",
  CANCELLED: "healthcare.appointments.appointment.cancel",
  NO_SHOW: "healthcare.appointments.appointment.edit",
};

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ appointmentId: string }> },
): Promise<NextResponse> {
  const { appointmentId } = await params;
  const path = `/admin/healthcare/appointments/${appointmentId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Sign in is required.",
      );
    const form = await readForm(request);
    const statusRaw = formText(form, "status", 30) as AppointmentStatusValue;
    if (!APPOINTMENT_STATUSES.includes(statusRaw))
      return appointmentRedirect(
        request,
        path,
        "error",
        "Invalid appointment status.",
      );
    const permission =
      PERMISSION_BY_STATUS[statusRaw] ??
      "healthcare.appointments.appointment.edit";
    if (!hasPermission(session.user, permission))
      return appointmentRedirect(
        request,
        path,
        "error",
        "You do not have permission for this status change.",
      );
    const appointment = await db.appointment.findFirst({
      where: {
        AND: [
          { id: appointmentId },
          appointmentAccessWhere(session.user, permission),
        ],
      },
      select: { status: true, userId: true, code: true },
    });
    if (!appointment)
      return appointmentRedirect(
        request,
        "/admin/healthcare/appointments",
        "error",
        "Appointment not found.",
      );
    if (!canTransitionAppointment(appointment.status, statusRaw))
      return appointmentRedirect(
        request,
        path,
        "error",
        `Cannot move an appointment from ${appointment.status} to ${statusRaw}.`,
      );
    const now = new Date();
    const cancellationReason =
      formLongText(form, "cancellationReason", 500) || null;
    if (statusRaw === "CANCELLED" && !cancellationReason)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Enter a cancellation reason before cancelling.",
      );
    await db.appointment.update({
      where: { id: appointmentId },
      data: {
        status: statusRaw,
        updatedById: session.user.id,
        ...(statusRaw === "CHECKED_IN" ? { checkedInAt: now } : {}),
        ...(statusRaw === "IN_CONSULTATION"
          ? { consultationStartedAt: now }
          : {}),
        ...(statusRaw === "COMPLETED" ? { completedAt: now } : {}),
        ...(statusRaw === "CANCELLED"
          ? { cancelledAt: now, cancellationReason }
          : {}),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "HEALTHCARE",
      targetType: "Appointment",
      targetId: appointmentId,
      metadata: { from: appointment.status, to: statusRaw, cancellationReason },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    await createDashboardNotification({
      userId: appointment.userId,
      dedupeKey: `appointment:${appointmentId}:status:${statusRaw}`,
      kind:
        statusRaw === "CANCELLED"
          ? "WARNING"
          : statusRaw === "COMPLETED"
            ? "SUCCESS"
            : "INFO",
      department: "HEALTHCARE",
      title: `Appointment ${statusRaw.replaceAll("_", " ").toLowerCase()}`,
      message: appointment.code,
      href: `/dashboard/healthcare/appointments/${appointmentId}`,
    });
    return appointmentRedirect(
      request,
      path,
      "success",
      `Appointment status changed to ${statusRaw.replaceAll("_", " ").toLowerCase()}.`,
    );
  } catch (error) {
    console.error("Appointment status update failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Appointment status could not be updated.",
    );
  }
}
