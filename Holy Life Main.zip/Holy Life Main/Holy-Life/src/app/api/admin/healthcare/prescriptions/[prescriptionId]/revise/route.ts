import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { createPrescriptionRevision } from "@/lib/clinical/service";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ prescriptionId: string }> },
): Promise<NextResponse> {
  const { prescriptionId } = await params;
  const path = `/admin/healthcare/prescriptions/${prescriptionId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.prescriptions.prescription.edit")
    )
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to revise prescriptions.",
      );
    const revision = await createPrescriptionRevision(
      session.user,
      prescriptionId,
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "PrescriptionRevision",
      targetId: revision.id,
      metadata: { supersedesId: prescriptionId, version: revision.version },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      `/admin/healthcare/prescriptions/${revision.id}`,
      "success",
      "New prescription revision created as a draft.",
    );
  } catch (error) {
    console.error("Prescription revision failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(
        error,
        "Prescription revision could not be created.",
      ),
    );
  }
}
