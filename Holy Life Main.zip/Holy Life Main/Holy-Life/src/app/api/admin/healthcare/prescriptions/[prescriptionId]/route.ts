import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { updatePrescriptionDraft } from "@/lib/clinical/service";
import { readPrescriptionForm } from "@/lib/clinical/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ prescriptionId: string }> },
): Promise<NextResponse> {
  const { prescriptionId } = await params;
  const path = `/admin/healthcare/prescriptions/${prescriptionId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.prescriptions.prescription.edit")
    )
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to edit prescriptions.",
      );
    const prescription = await updatePrescriptionDraft(
      session.user,
      prescriptionId,
      readPrescriptionForm(await readForm(request)),
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "Prescription",
      targetId: prescription.id,
      metadata: { version: prescription.version },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      path,
      "success",
      "Prescription draft updated.",
    );
  } catch (error) {
    console.error("Prescription update failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Prescription could not be updated."),
    );
  }
}
