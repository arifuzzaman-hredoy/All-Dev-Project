import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { clientIp, assertSameOrigin, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ doctorId: string }> },
): Promise<NextResponse> {
  const { doctorId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.doctor.archive")
    )
      return appointmentRedirect(
        request,
        `/admin/healthcare/doctors/${doctorId}`,
        "error",
        "Doctor archive permission is required.",
      );
    const doctor = await db.doctorProfile.findFirst({
      where: {
        AND: [
          { id: doctorId },
          doctorAccessWhere(session.user, "healthcare.doctors.doctor.archive"),
        ],
      },
      select: { id: true },
    });
    if (!doctor)
      return appointmentRedirect(
        request,
        "/admin/healthcare/doctors",
        "error",
        "Doctor profile not found or outside your data scope.",
      );
    await db.doctorProfile.update({
      where: { id: doctor.id },
      data: { status: "ARCHIVED", isFeatured: false },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "ARCHIVE",
      department: "HEALTHCARE",
      targetType: "DoctorProfile",
      targetId: doctorId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      "/admin/healthcare/doctors",
      "success",
      "Doctor profile archived. Existing appointment history is preserved.",
    );
  } catch (error) {
    console.error("Doctor archive failed", error);
    return appointmentRedirect(
      request,
      "/admin/healthcare/doctors",
      "error",
      "Doctor profile could not be archived.",
    );
  }
}
