import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import {
  formCheckbox,
  formInteger,
  formLongText,
  formMoney,
  formText,
} from "@/lib/appointments/validation";
import {
  isValidBangladeshPhone,
  isValidEmail,
  normalizeEmail,
  normalizePhone,
} from "@/lib/auth/normalize";
import { db } from "@/lib/db";

function normalizeSlug(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/healthcare/doctors/create";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.doctor.create")
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Doctor create permission is required.",
      );
    const form = await readForm(request);
    const name = formText(form, "name", 100);
    const code = formText(form, "code", 30)
      .toUpperCase()
      .replace(/[^A-Z0-9-]/g, "");
    const slug = normalizeSlug(formText(form, "slug", 80) || name);
    const departmentId = formText(form, "departmentId", 100);
    const emailRaw = formText(form, "email", 254);
    const email = emailRaw ? normalizeEmail(emailRaw) : null;
    const phoneRaw = formText(form, "phone", 30);
    const phone = phoneRaw ? normalizePhone(phoneRaw) : null;
    const specialization = formText(form, "specialization", 160);
    if (
      name.length < 2 ||
      code.length < 3 ||
      slug.length < 3 ||
      !departmentId ||
      specialization.length < 2
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Name, code, slug, department, and specialization are required.",
      );
    if (email && !isValidEmail(email))
      return appointmentRedirect(
        request,
        path,
        "error",
        "Enter a valid email address.",
      );
    if (phone && !isValidBangladeshPhone(phone))
      return appointmentRedirect(
        request,
        path,
        "error",
        "Enter a valid Bangladesh mobile number.",
      );
    const department = await db.medicalDepartment.findFirst({
      where: { id: departmentId, isActive: true },
      select: { id: true },
    });
    if (!department)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Select an active medical department.",
      );
    const duplicate = await db.doctorProfile.findFirst({
      where: { OR: [{ code }, { slug }] },
      select: { id: true },
    });
    if (duplicate)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Doctor code or slug already exists.",
      );

    const doctor = await db.doctorProfile.create({
      data: {
        code,
        slug,
        departmentId,
        name,
        nameBn: formText(form, "nameBn", 100) || null,
        email,
        phone,
        designation: formText(form, "designation", 100) || "Consultant",
        designationBn: formText(form, "designationBn", 100) || null,
        specialization,
        specializationBn: formText(form, "specializationBn", 160) || null,
        qualifications: formText(form, "qualifications", 300) || null,
        qualificationsBn: formText(form, "qualificationsBn", 300) || null,
        experienceYears: formInteger(form, "experienceYears", 0, 0, 80),
        bio: formLongText(form, "bio", 3000) || null,
        bioBn: formLongText(form, "bioBn", 3000) || null,
        consultationFee: formMoney(form, "consultationFee", 0),
        followUpFee: formMoney(form, "followUpFee", 0),
        imageUrl: formText(form, "imageUrl", 1000) || null,
        roomLabel: formText(form, "roomLabel", 100) || null,
        roomLabelBn: formText(form, "roomLabelBn", 100) || null,
        location: formText(form, "location", 200) || null,
        locationBn: formText(form, "locationBn", 200) || null,
        isFeatured: formCheckbox(form, "isFeatured"),
        displayOrder: formInteger(form, "displayOrder", 100, 0, 10000),
        status: "ACTIVE",
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "DoctorProfile",
      targetId: doctor.id,
      metadata: { code, slug, name, departmentId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      `/admin/healthcare/doctors/${doctor.id}`,
      "success",
      "Doctor profile created. Add the weekly schedule next.",
    );
  } catch (error) {
    console.error("Doctor creation failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Doctor profile could not be created.",
    );
  }
}
