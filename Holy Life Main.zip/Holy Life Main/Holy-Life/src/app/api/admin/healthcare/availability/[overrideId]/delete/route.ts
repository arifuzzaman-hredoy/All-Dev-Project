import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { clientIp, assertSameOrigin, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ overrideId: string }> },
): Promise<NextResponse> {
  const { overrideId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.schedule.manage")
    )
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Schedule management permission is required.",
      );
    const override = await db.doctorAvailabilityOverride.findFirst({
      where: {
        id: overrideId,
        doctor: doctorAccessWhere(
          session.user,
          "healthcare.doctors.schedule.manage",
        ),
      },
      select: { doctorId: true },
    });
    if (!override)
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Availability override not found.",
      );
    await db.doctorAvailabilityOverride.delete({ where: { id: overrideId } });
    await writeAuditLog({
      actorId: session.user.id,
      action: "DELETE",
      department: "HEALTHCARE",
      targetType: "DoctorAvailabilityOverride",
      targetId: overrideId,
      metadata: { doctorId: override.doctorId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      `/admin/healthcare/schedules?doctorId=${encodeURIComponent(override.doctorId)}`,
      "success",
      "Availability override removed.",
    );
  } catch (error) {
    console.error("Availability override delete failed", error);
    return appointmentRedirect(
      request,
      "/admin/healthcare/schedules",
      "error",
      "Availability override could not be removed.",
    );
  }
}
