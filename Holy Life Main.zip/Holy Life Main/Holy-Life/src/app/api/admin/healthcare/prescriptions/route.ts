import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { createPrescriptionDraft } from "@/lib/clinical/service";
import { readPrescriptionForm } from "@/lib/clinical/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(
        session.user,
        "healthcare.prescriptions.prescription.create",
      )
    ) {
      return clinicalRedirect(
        request,
        "/admin/healthcare/prescriptions",
        "error",
        "You do not have permission to create prescriptions.",
      );
    }
    const prescription = await createPrescriptionDraft(
      session.user,
      readPrescriptionForm(await readForm(request)),
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "Prescription",
      targetId: prescription.id,
      metadata: {
        appointmentId: prescription.appointmentId,
        patientId: prescription.patientId,
        version: prescription.version,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      `/admin/healthcare/prescriptions/${prescription.id}`,
      "success",
      "Prescription draft created.",
    );
  } catch (error) {
    console.error("Prescription creation failed", error);
    return clinicalRedirect(
      request,
      "/admin/healthcare/prescriptions/create",
      "error",
      clinicalErrorMessage(error, "Prescription could not be created."),
    );
  }
}
