import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { updatePatientClinicalProfile } from "@/lib/clinical/service";
import { readClinicalProfileForm } from "@/lib/clinical/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ patientId: string }> },
): Promise<NextResponse> {
  const { patientId } = await params;
  const path = `/admin/healthcare/patients/${patientId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.patients.clinical-record.edit")
    ) {
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to edit clinical history.",
      );
    }
    const profile = await updatePatientClinicalProfile(
      session.user,
      patientId,
      readClinicalProfileForm(await readForm(request)),
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "PatientClinicalProfile",
      targetId: profile.id,
      metadata: { patientId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      path,
      "success",
      "Clinical history updated.",
    );
  } catch (error) {
    console.error("Clinical profile update failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Clinical history could not be updated."),
    );
  }
}
