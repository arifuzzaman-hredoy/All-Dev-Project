import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import { isTimeValue, timeToMinutes } from "@/lib/appointments/time";
import {
  formCheckbox,
  formInteger,
  formText,
} from "@/lib/appointments/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.schedule.manage")
    )
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Schedule management permission is required.",
      );
    const form = await readForm(request);
    const doctorId = formText(form, "doctorId", 100);
    const weekday = formInteger(form, "weekday", -1, -1, 6);
    const startTime = formText(form, "startTime", 5);
    const endTime = formText(form, "endTime", 5);
    const breakStart = formText(form, "breakStart", 5) || null;
    const breakEnd = formText(form, "breakEnd", 5) || null;
    const slotMinutes = formInteger(form, "slotMinutes", 30, 5, 240);
    const maxPatients = formInteger(form, "maxPatients", 1, 1, 20);
    const returnPath = `/admin/healthcare/schedules?doctorId=${encodeURIComponent(doctorId)}`;
    if (
      !doctorId ||
      weekday < 0 ||
      !isTimeValue(startTime) ||
      !isTimeValue(endTime) ||
      timeToMinutes(endTime) <= timeToMinutes(startTime)
    )
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "Select a doctor, weekday, and valid start/end times.",
      );
    if (
      (breakStart || breakEnd) &&
      (!breakStart ||
        !breakEnd ||
        !isTimeValue(breakStart) ||
        !isTimeValue(breakEnd) ||
        timeToMinutes(breakEnd) <= timeToMinutes(breakStart))
    )
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "Enter a valid break range or leave both break fields empty.",
      );
    if (
      breakStart &&
      breakEnd &&
      (timeToMinutes(breakStart) < timeToMinutes(startTime) ||
        timeToMinutes(breakEnd) > timeToMinutes(endTime))
    )
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "The break must stay inside the consultation window.",
      );
    const doctor = await db.doctorProfile.findFirst({
      where: {
        AND: [
          { id: doctorId },
          doctorAccessWhere(session.user, "healthcare.doctors.schedule.manage"),
        ],
      },
      select: { id: true },
    });
    if (!doctor)
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Doctor profile not found.",
      );
    const schedule = await db.doctorSchedule.upsert({
      where: {
        doctorId_weekday_startTime_endTime: {
          doctorId,
          weekday,
          startTime,
          endTime,
        },
      },
      update: {
        slotMinutes,
        maxPatients,
        breakStart,
        breakEnd,
        isActive: formCheckbox(form, "isActive"),
      },
      create: {
        doctorId,
        weekday,
        startTime,
        endTime,
        slotMinutes,
        maxPatients,
        breakStart,
        breakEnd,
        isActive: formCheckbox(form, "isActive"),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "DoctorSchedule",
      targetId: schedule.id,
      metadata: {
        doctorId,
        weekday,
        startTime,
        endTime,
        slotMinutes,
        maxPatients,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      returnPath,
      "success",
      "Weekly schedule saved.",
    );
  } catch (error) {
    console.error("Doctor schedule save failed", error);
    return appointmentRedirect(
      request,
      "/admin/healthcare/schedules",
      "error",
      "Weekly schedule could not be saved.",
    );
  }
}
