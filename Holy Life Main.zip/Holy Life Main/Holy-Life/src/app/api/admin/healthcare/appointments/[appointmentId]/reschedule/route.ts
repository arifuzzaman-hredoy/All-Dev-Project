import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import { appointmentAccessWhere } from "@/lib/appointments/access";
import {
  buildAppointmentSlots,
  findSlot,
} from "@/lib/appointments/availability";
import {
  dateInputToUtc,
  isDateInput,
  isTimeValue,
  todayInDhaka,
} from "@/lib/appointments/time";
import { formText } from "@/lib/appointments/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ appointmentId: string }> },
): Promise<NextResponse> {
  const { appointmentId } = await params;
  const path = `/admin/healthcare/appointments/${appointmentId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(
        session.user,
        "healthcare.appointments.appointment.reschedule",
      )
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Appointment reschedule permission is required.",
      );
    const form = await readForm(request);
    const date = formText(form, "date", 10);
    const startTime = formText(form, "startTime", 5);
    if (!isDateInput(date) || date < todayInDhaka() || !isTimeValue(startTime))
      return appointmentRedirect(
        request,
        path,
        "error",
        "Select a valid future date and available time.",
      );
    const updated = await db.$transaction(
      async (tx) => {
        const current = await tx.appointment.findFirst({
          where: {
            AND: [
              { id: appointmentId },
              appointmentAccessWhere(
                session.user,
                "healthcare.appointments.appointment.reschedule",
              ),
            ],
          },
        });
        if (!current) throw new Error("NOT_FOUND");
        if (!["PENDING", "CONFIRMED"].includes(current.status))
          throw new Error("FINAL_STATUS");
        const appointmentDate = dateInputToUtc(date);
        const doctor = await tx.doctorProfile.findUnique({
          where: { id: current.doctorId },
          include: {
            schedules: { where: { isActive: true } },
            availability: { where: { date: appointmentDate } },
            appointments: {
              where: { appointmentDate, id: { not: current.id } },
              select: { startTime: true, status: true, slotNumber: true },
            },
          },
        });
        if (!doctor || doctor.status !== "ACTIVE")
          throw new Error("DOCTOR_UNAVAILABLE");
        const slots = buildAppointmentSlots({
          date,
          schedules: doctor.schedules,
          overrides: doctor.availability,
          bookings: doctor.appointments,
        });
        const slot = findSlot(slots, startTime);
        if (!slot || slot.available <= 0) throw new Error("SLOT_UNAVAILABLE");
        const used = new Set(
          doctor.appointments
            .filter(
              (item) =>
                item.startTime === startTime &&
                item.status !== "CANCELLED" &&
                item.status !== "NO_SHOW",
            )
            .map((item) => item.slotNumber),
        );
        let slotNumber = 1;
        while (slotNumber <= slot.capacity && used.has(slotNumber))
          slotNumber += 1;
        if (slotNumber > slot.capacity) throw new Error("SLOT_UNAVAILABLE");
        const serialNumber = await tx.appointment.count({
          where: {
            doctorId: current.doctorId,
            appointmentDate,
            id: { not: current.id },
            status: { notIn: ["CANCELLED", "NO_SHOW"] },
          },
        });
        return tx.appointment.update({
          where: { id: current.id },
          data: {
            appointmentDate,
            startTime: slot.startTime,
            endTime: slot.endTime,
            slotNumber,
            serialNumber: serialNumber + 1,
            status: current.status === "PENDING" ? "PENDING" : "CONFIRMED",
            updatedById: session.user.id,
            checkedInAt: null,
            consultationStartedAt: null,
          },
        });
      },
      { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "Appointment",
      targetId: appointmentId,
      metadata: { date, startTime, action: "RESCHEDULE" },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      path,
      "success",
      `Appointment rescheduled to ${updated.appointmentDate.toISOString().slice(0, 10)} at ${updated.startTime}.`,
    );
  } catch (error) {
    const message =
      error instanceof Error && error.message === "SLOT_UNAVAILABLE"
        ? "The selected slot is no longer available."
        : error instanceof Error && error.message === "FINAL_STATUS"
          ? "Only pending or confirmed appointments can be rescheduled."
          : "Appointment could not be rescheduled.";
    console.error("Appointment reschedule failed", error);
    return appointmentRedirect(request, path, "error", message);
  }
}
