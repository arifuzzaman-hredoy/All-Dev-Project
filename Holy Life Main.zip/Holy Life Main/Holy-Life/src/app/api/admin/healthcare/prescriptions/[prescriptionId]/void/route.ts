import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { voidPrescription } from "@/lib/clinical/service";
import { readVoidReason } from "@/lib/clinical/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ prescriptionId: string }> },
): Promise<NextResponse> {
  const { prescriptionId } = await params;
  const path = `/admin/healthcare/prescriptions/${prescriptionId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.prescriptions.prescription.sign")
    )
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to void signed prescriptions.",
      );
    const reason = readVoidReason(await readForm(request));
    const prescription = await voidPrescription(
      session.user,
      prescriptionId,
      reason,
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "HEALTHCARE",
      targetType: "Prescription",
      targetId: prescription.id,
      metadata: { from: "SIGNED", to: "VOIDED", reason },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      path,
      "success",
      "Prescription voided. The signed record remains in version history.",
    );
  } catch (error) {
    console.error("Prescription void failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Prescription could not be voided."),
    );
  }
}
