import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import {
  dateInputToUtc,
  isDateInput,
  isTimeValue,
  timeToMinutes,
  todayInDhaka,
} from "@/lib/appointments/time";
import { formInteger, formText } from "@/lib/appointments/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.schedule.manage")
    )
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Schedule management permission is required.",
      );
    const form = await readForm(request);
    const doctorId = formText(form, "doctorId", 100);
    const date = formText(form, "date", 10);
    const kindRaw = formText(form, "kind", 20);
    const kind =
      kindRaw === "AVAILABLE" || kindRaw === "BLOCKED" ? kindRaw : "LEAVE";
    const startTime = formText(form, "startTime", 5) || null;
    const endTime = formText(form, "endTime", 5) || null;
    const returnPath = `/admin/healthcare/schedules?doctorId=${encodeURIComponent(doctorId)}`;
    if (!doctorId || !isDateInput(date) || date < todayInDhaka())
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "Select a doctor and a valid current or future override date.",
      );
    const doctor = await db.doctorProfile.findFirst({
      where: {
        AND: [
          { id: doctorId },
          doctorAccessWhere(session.user, "healthcare.doctors.schedule.manage"),
        ],
      },
      select: { id: true },
    });
    if (!doctor)
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Doctor profile not found or outside your data scope.",
      );
    if (
      (startTime || endTime) &&
      (!startTime ||
        !endTime ||
        !isTimeValue(startTime) ||
        !isTimeValue(endTime) ||
        timeToMinutes(endTime) <= timeToMinutes(startTime))
    )
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "Enter a valid override time range or leave both time fields empty.",
      );
    if (kind === "AVAILABLE" && (!startTime || !endTime))
      return appointmentRedirect(
        request,
        returnPath,
        "error",
        "Special availability requires a start and end time.",
      );
    const override = await db.doctorAvailabilityOverride.create({
      data: {
        doctorId,
        date: dateInputToUtc(date),
        kind,
        startTime,
        endTime,
        slotMinutes:
          kind === "AVAILABLE"
            ? formInteger(form, "slotMinutes", 30, 5, 240)
            : null,
        maxPatients:
          kind === "AVAILABLE"
            ? formInteger(form, "maxPatients", 1, 1, 20)
            : null,
        reason: formText(form, "reason", 300) || null,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "DoctorAvailabilityOverride",
      targetId: override.id,
      metadata: { doctorId, date, kind, startTime, endTime },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      returnPath,
      "success",
      "Availability override added.",
    );
  } catch (error) {
    console.error("Availability override creation failed", error);
    return appointmentRedirect(
      request,
      "/admin/healthcare/schedules",
      "error",
      "Availability override could not be added.",
    );
  }
}
