import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { clientIp, assertSameOrigin, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ departmentId: string }> },
): Promise<NextResponse> {
  const { departmentId } = await params;
  const path = "/admin/healthcare/departments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.department.archive")
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Department archive permission is required.",
      );
    const department = await db.medicalDepartment.findUnique({
      where: { id: departmentId },
      include: { _count: { select: { doctors: true } } },
    });
    if (!department)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Medical department not found.",
      );
    if (department._count.doctors > 0)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Move or archive the department's doctor profiles before archiving it.",
      );
    await db.medicalDepartment.update({
      where: { id: department.id },
      data: { isActive: false },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "ARCHIVE",
      department: "HEALTHCARE",
      targetType: "MedicalDepartment",
      targetId: department.id,
      metadata: { code: department.code },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      path,
      "success",
      "Medical department archived.",
    );
  } catch (error) {
    console.error("Medical department archive failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Medical department could not be archived.",
    );
  }
}
