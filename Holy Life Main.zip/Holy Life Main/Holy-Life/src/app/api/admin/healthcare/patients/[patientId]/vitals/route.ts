import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { recordPatientVital } from "@/lib/clinical/service";
import { readVitalForm } from "@/lib/clinical/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ patientId: string }> },
): Promise<NextResponse> {
  const { patientId } = await params;
  const path = `/admin/healthcare/patients/${patientId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.patients.clinical-record.edit")
    ) {
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to record vitals.",
      );
    }
    const vital = await recordPatientVital(
      session.user,
      patientId,
      readVitalForm(await readForm(request)),
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "PatientVital",
      targetId: vital.id,
      metadata: { patientId, appointmentId: vital.appointmentId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(request, path, "success", "Vitals recorded.");
  } catch (error) {
    console.error("Vital recording failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Vitals could not be recorded."),
    );
  }
}
