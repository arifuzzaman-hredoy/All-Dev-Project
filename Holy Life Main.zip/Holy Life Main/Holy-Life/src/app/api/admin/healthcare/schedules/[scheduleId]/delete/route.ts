import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { clientIp, assertSameOrigin, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ scheduleId: string }> },
): Promise<NextResponse> {
  const { scheduleId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.doctors.schedule.manage")
    )
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Schedule management permission is required.",
      );
    const schedule = await db.doctorSchedule.findFirst({
      where: {
        id: scheduleId,
        doctor: doctorAccessWhere(
          session.user,
          "healthcare.doctors.schedule.manage",
        ),
      },
      select: { doctorId: true },
    });
    if (!schedule)
      return appointmentRedirect(
        request,
        "/admin/healthcare/schedules",
        "error",
        "Schedule not found.",
      );
    await db.doctorSchedule.delete({ where: { id: scheduleId } });
    await writeAuditLog({
      actorId: session.user.id,
      action: "DELETE",
      department: "HEALTHCARE",
      targetType: "DoctorSchedule",
      targetId: scheduleId,
      metadata: { doctorId: schedule.doctorId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      `/admin/healthcare/schedules?doctorId=${encodeURIComponent(schedule.doctorId)}`,
      "success",
      "Schedule removed.",
    );
  } catch (error) {
    console.error("Doctor schedule delete failed", error);
    return appointmentRedirect(
      request,
      "/admin/healthcare/schedules",
      "error",
      "Schedule could not be removed.",
    );
  }
}
