import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { appointmentRedirect } from "@/lib/appointments/api";
import {
  AppointmentBookingError,
  createAppointment,
} from "@/lib/appointments/service";
import {
  readAppointmentForm,
  validateAppointmentForm,
  formLongText,
} from "@/lib/appointments/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/healthcare/appointments/create";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "healthcare.appointments.appointment.create")
    )
      return appointmentRedirect(
        request,
        path,
        "error",
        "Appointment create permission is required.",
      );
    const form = await readForm(request);
    const input = readAppointmentForm(form);
    const validationError = validateAppointmentForm(input);
    if (validationError)
      return appointmentRedirect(request, path, "error", validationError, {
        doctorId: input.doctorId,
        date: input.date,
      });
    const allowedDoctor = await db.doctorProfile.findFirst({
      where: {
        AND: [
          { id: input.doctorId, status: "ACTIVE" },
          doctorAccessWhere(
            session.user,
            "healthcare.appointments.appointment.create",
          ),
        ],
      },
      select: { id: true },
    });
    if (!allowedDoctor)
      return appointmentRedirect(
        request,
        path,
        "error",
        "Doctor profile not found or outside your data scope.",
        { date: input.date },
      );
    const appointment = await createAppointment({
      ...input,
      notes: formLongText(form, "notes", 2000) || null,
      actorId: session.user.id,
      source: "ADMIN",
      initialStatus: "CONFIRMED",
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "Appointment",
      targetId: appointment.id,
      metadata: {
        code: appointment.code,
        source: "ADMIN",
        doctorId: appointment.doctorId,
        date: appointment.appointmentDate.toISOString().slice(0, 10),
        startTime: appointment.startTime,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      `/admin/healthcare/appointments/${appointment.id}`,
      "success",
      "Appointment created and confirmed.",
    );
  } catch (error) {
    if (error instanceof AppointmentBookingError)
      return appointmentRedirect(request, path, "error", error.message);
    console.error("Admin appointment creation failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Appointment could not be created.",
    );
  }
}
