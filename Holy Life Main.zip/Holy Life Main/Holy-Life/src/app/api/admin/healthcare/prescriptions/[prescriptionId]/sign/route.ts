import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { signPrescription } from "@/lib/clinical/service";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ prescriptionId: string }> },
): Promise<NextResponse> {
  const { prescriptionId } = await params;
  const path = `/admin/healthcare/prescriptions/${prescriptionId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.prescriptions.prescription.sign")
    )
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to sign prescriptions.",
      );
    const prescription = await signPrescription(session.user, prescriptionId);
    await writeAuditLog({
      actorId: session.user.id,
      action: "VERIFY",
      department: "HEALTHCARE",
      targetType: "Prescription",
      targetId: prescription.id,
      metadata: { version: prescription.version, status: prescription.status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    const linked = await db.patientProfile.findUnique({
      where: { id: prescription.patientId },
      select: { userId: true },
    });
    await createDashboardNotification({
      userId: linked?.userId,
      dedupeKey: `prescription:${prescription.id}:signed`,
      kind: "SUCCESS",
      department: "HEALTHCARE",
      title: "Prescription signed",
      message: `${prescription.code} is ready in your health dashboard.`,
      href: `/dashboard/healthcare/prescriptions/${prescription.id}`,
    });
    return clinicalRedirect(
      request,
      path,
      "success",
      "Prescription signed and locked.",
    );
  } catch (error) {
    console.error("Prescription signing failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Prescription could not be signed."),
    );
  }
}
