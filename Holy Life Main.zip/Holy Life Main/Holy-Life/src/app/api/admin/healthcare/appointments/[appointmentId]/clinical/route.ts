import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { clinicalErrorMessage, clinicalRedirect } from "@/lib/clinical/api";
import { saveClinicalEncounter } from "@/lib/clinical/service";
import { readEncounterForm } from "@/lib/clinical/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ appointmentId: string }> },
): Promise<NextResponse> {
  const { appointmentId } = await params;
  const path = `/admin/healthcare/appointments/${appointmentId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return clinicalRedirect(
        request,
        "/login",
        "error",
        "Sign in is required.",
      );
    if (
      !hasPermission(session.user, "healthcare.patients.clinical-record.edit")
    ) {
      return clinicalRedirect(
        request,
        path,
        "error",
        "You do not have permission to edit clinical notes.",
      );
    }
    const encounter = await saveClinicalEncounter(
      session.user,
      appointmentId,
      readEncounterForm(await readForm(request)),
    );
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "HEALTHCARE",
      targetType: "ClinicalEncounter",
      targetId: encounter.id,
      metadata: { appointmentId, patientId: encounter.patientId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return clinicalRedirect(
      request,
      path,
      "success",
      "Clinical encounter saved.",
    );
  } catch (error) {
    console.error("Clinical encounter update failed", error);
    return clinicalRedirect(
      request,
      path,
      "error",
      clinicalErrorMessage(error, "Clinical encounter could not be saved."),
    );
  }
}
