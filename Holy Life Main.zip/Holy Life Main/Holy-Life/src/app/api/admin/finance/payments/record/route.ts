import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import { recordVerifiedTransaction } from "@/lib/finance/service";
import {
  manualPaymentMethod,
  optionalFinanceText,
  positiveMoney,
  requiredFinanceText,
} from "@/lib/finance/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/finance/payments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.finance.payment.record")
    ) {
      return financeRedirect(
        request,
        path,
        "error",
        "Finance payment record permission is required.",
      );
    }

    const form = await readForm(request);
    const accountId = requiredFinanceText(
      form.get("accountId"),
      120,
      "Payment account",
    );
    const type =
      String(form.get("type") ?? "PAYMENT") === "REFUND" ? "REFUND" : "PAYMENT";
    const permission =
      type === "REFUND"
        ? "system.finance.payment.refund"
        : "system.finance.payment.record";
    if (!hasPermission(session.user, permission)) {
      return financeRedirect(
        request,
        path,
        "error",
        "You do not have permission for this transaction.",
      );
    }

    const amount = positiveMoney(
      form.get("amount"),
      type === "REFUND" ? "Refund amount" : "Payment amount",
    );
    const method =
      type === "PAYMENT" ? manualPaymentMethod(form.get("method")) : null;
    const transactionReference = optionalFinanceText(
      form.get("transactionReference"),
      160,
    );
    const note = optionalFinanceText(form.get("note"), 500);

    const result = await recordVerifiedTransaction({
      accountId,
      actorId: session.user.id,
      type,
      amount,
      method,
      transactionReference,
      note,
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: type === "REFUND" ? "PaymentRefund" : "PaymentTransaction",
      targetId: result.transaction.id,
      metadata: {
        code: result.transaction.code,
        accountId,
        amount,
        type,
        status: result.refreshed.status,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return financeRedirect(
      request,
      path,
      "success",
      type === "REFUND"
        ? "Manual refund recorded."
        : "Manual payment recorded.",
    );
  } catch (error) {
    console.error("Admin finance transaction failed", error);
    return financeRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Finance transaction could not be recorded.",
    );
  }
}
