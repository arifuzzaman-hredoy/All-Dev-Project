import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import { reviewPendingTransaction } from "@/lib/finance/service";
import { optionalFinanceText } from "@/lib/finance/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ transactionId: string }> },
): Promise<NextResponse> {
  const path = "/admin/finance/payments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.finance.payment.verify")
    ) {
      return financeRedirect(
        request,
        path,
        "error",
        "Payment verification permission is required.",
      );
    }

    const { transactionId } = await params;
    const form = await readForm(request);
    const raw = String(form.get("status") ?? "");
    if (!["VERIFIED", "REJECTED"].includes(raw)) {
      return financeRedirect(
        request,
        path,
        "error",
        "Review status is invalid.",
      );
    }

    const transaction = await reviewPendingTransaction({
      transactionId,
      actorId: session.user.id,
      status: raw as "VERIFIED" | "REJECTED",
      note: optionalFinanceText(form.get("note"), 500),
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "SYSTEM",
      targetType: "PaymentTransaction",
      targetId: transaction.id,
      metadata: { code: transaction.code, status: transaction.status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return financeRedirect(
      request,
      path,
      "success",
      `Payment ${transaction.status.toLowerCase()}.`,
    );
  } catch (error) {
    console.error("Payment review failed", error);
    return financeRedirect(
      request,
      path,
      "error",
      error instanceof Error ? error.message : "Payment could not be reviewed.",
    );
  }
}
