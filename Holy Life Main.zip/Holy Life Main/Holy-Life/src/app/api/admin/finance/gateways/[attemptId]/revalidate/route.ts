import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import {
  PaymentGatewayError,
  revalidateGatewayAttempt,
} from "@/lib/payments/gateway/service";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> },
): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.finance.gateway.manage")
    ) {
      return financeRedirect(request, "/admin", "error", "Permission denied.");
    }

    const { attemptId } = await params;
    const result = await revalidateGatewayAttempt(attemptId);

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "SYSTEM",
      targetType: "PaymentGatewayAttempt",
      targetId: attemptId,
      metadata: { action: "REVALIDATE", status: result.attempt.status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return financeRedirect(
      request,
      "/admin/finance/gateways",
      "success",
      `Gateway attempt is ${result.attempt.status.toLowerCase().replaceAll("_", " ")}.`,
    );
  } catch (error) {
    console.error("Gateway attempt revalidation failed", error);
    return financeRedirect(
      request,
      "/admin/finance/gateways",
      "error",
      error instanceof PaymentGatewayError
        ? error.message
        : "Gateway attempt could not be revalidated.",
    );
  }
}
