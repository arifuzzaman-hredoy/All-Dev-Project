import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import { revalidatePath } from "next/cache";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { isWebsiteSectionType } from "@/lib/cms/content";
import { db } from "@/lib/db";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string; revisionId: string }> },
): Promise<NextResponse> {
  const { pageId, revisionId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website edit permission is required.",
      );
    const revision = await db.websitePageRevision.findFirst({
      where: { id: revisionId, pageId },
    });
    if (!revision || !isRecord(revision.snapshot))
      return cmsRedirect(
        request,
        path,
        "error",
        "Revision snapshot is invalid.",
      );
    const snapshotPage = revision.snapshot.page;
    const snapshotSections = revision.snapshot.sections;
    if (!isRecord(snapshotPage) || !Array.isArray(snapshotSections))
      return cmsRedirect(
        request,
        path,
        "error",
        "Revision snapshot is incomplete.",
      );
    const current = await db.websitePage.findUnique({
      where: { id: pageId },
      select: { slug: true, isSystem: true },
    });
    if (!current)
      return cmsRedirect(request, "/admin/website", "error", "Page not found.");
    await createWebsitePageRevision(
      pageId,
      session.user.id,
      `Before restoring revision v${revision.version}`,
    );
    const restoredSlug = current.isSystem
      ? current.slug
      : typeof snapshotPage.slug === "string"
        ? snapshotPage.slug
        : current.slug;
    await db.$transaction(async (tx) => {
      await tx.websiteSection.deleteMany({ where: { pageId } });
      await tx.websitePage.update({
        where: { id: pageId },
        data: {
          slug: restoredSlug,
          title:
            typeof snapshotPage.title === "string"
              ? snapshotPage.title
              : "Restored page",
          navigationLabel:
            typeof snapshotPage.navigationLabel === "string"
              ? snapshotPage.navigationLabel
              : null,
          excerpt:
            typeof snapshotPage.excerpt === "string"
              ? snapshotPage.excerpt
              : null,
          showInHeader: snapshotPage.showInHeader === true,
          showInFooter: snapshotPage.showInFooter === true,
          headerOrder:
            typeof snapshotPage.headerOrder === "number"
              ? snapshotPage.headerOrder
              : 0,
          footerOrder:
            typeof snapshotPage.footerOrder === "number"
              ? snapshotPage.footerOrder
              : 0,
          seoTitle:
            typeof snapshotPage.seoTitle === "string"
              ? snapshotPage.seoTitle
              : null,
          seoDescription:
            typeof snapshotPage.seoDescription === "string"
              ? snapshotPage.seoDescription
              : null,
          canonicalPath:
            typeof snapshotPage.canonicalPath === "string"
              ? snapshotPage.canonicalPath
              : null,
          updatedById: session.user.id,
        },
      });
      for (const raw of snapshotSections) {
        if (
          !isRecord(raw) ||
          typeof raw.key !== "string" ||
          typeof raw.type !== "string" ||
          !isWebsiteSectionType(raw.type)
        )
          continue;
        await tx.websiteSection.create({
          data: {
            pageId,
            key: raw.key,
            type: raw.type,
            title: typeof raw.title === "string" ? raw.title : raw.key,
            position: typeof raw.position === "number" ? raw.position : 0,
            isEnabled: raw.isEnabled !== false,
            content: (isRecord(raw.content)
              ? raw.content
              : {}) as Prisma.InputJsonValue,
          },
        });
      }
    });
    revalidatePath("/");
    revalidatePath(restoredSlug === "home" ? "/" : `/${restoredSlug}`);
    return cmsRedirect(
      request,
      path,
      "success",
      `Revision v${revision.version} restored.`,
    );
  } catch (error) {
    console.error("Website revision restore failed", error);
    return cmsRedirect(
      request,
      path,
      "error",
      "Revision could not be restored.",
    );
  }
}
