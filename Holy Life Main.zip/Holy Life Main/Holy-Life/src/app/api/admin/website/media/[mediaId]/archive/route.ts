import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ mediaId: string }> },
): Promise<NextResponse> {
  const { mediaId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.archive"))
      return cmsRedirect(
        request,
        "/admin/website/media",
        "error",
        "Website archive permission is required.",
      );
    await db.websiteMedia.update({
      where: { id: mediaId },
      data: { isArchived: true },
    });
    return cmsRedirect(
      request,
      "/admin/website/media",
      "success",
      "Media record archived.",
    );
  } catch (error) {
    console.error("Website media archive failed", error);
    return cmsRedirect(
      request,
      "/admin/website/media",
      "error",
      "Media record could not be archived.",
    );
  }
}
