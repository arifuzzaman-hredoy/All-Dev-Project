import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import { revalidatePath } from "next/cache";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect, formBoolean, formInt, formString } from "@/lib/cms/api";
import {
  isWebsiteSectionType,
  normalizeWebsiteSlug,
  parseSectionContent,
} from "@/lib/cms/content";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string; sectionId: string }> },
): Promise<NextResponse> {
  const { pageId, sectionId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website edit permission is required.",
      );
    const section = await db.websiteSection.findFirst({
      where: { id: sectionId, pageId },
      include: { page: { select: { slug: true } } },
    });
    if (!section)
      return cmsRedirect(request, path, "error", "Section not found.");
    const form = await readForm(request);
    const title = formString(form, "title", 120);
    const key = normalizeWebsiteSlug(formString(form, "key", 80));
    const type = formString(form, "type", 30);
    if (!title || !key || !isWebsiteSectionType(type))
      return cmsRedirect(
        request,
        path,
        "error",
        "Enter a valid section title, key, and type.",
      );
    const content = parseSectionContent(String(form.get("content") ?? "{}"));
    await createWebsitePageRevision(
      pageId,
      session.user.id,
      `Section ${section.key} updated`,
    );
    await db.websiteSection.update({
      where: { id: sectionId },
      data: {
        title,
        key,
        type,
        position: formInt(form, "position"),
        isEnabled: formBoolean(form, "isEnabled"),
        content: content as Prisma.InputJsonValue,
      },
    });
    await db.websitePage.update({
      where: { id: pageId },
      data: { updatedById: session.user.id },
    });
    revalidatePath(
      section.page.slug === "home" ? "/" : `/${section.page.slug}`,
    );
    return cmsRedirect(request, path, "success", "Section saved.");
  } catch (error) {
    console.error("Website section update failed", error);
    return cmsRedirect(
      request,
      path,
      "error",
      "Section could not be saved. Check the key and JSON content.",
    );
  }
}
