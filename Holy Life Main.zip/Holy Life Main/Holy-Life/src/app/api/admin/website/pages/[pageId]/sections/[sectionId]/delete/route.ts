import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string; sectionId: string }> },
): Promise<NextResponse> {
  const { pageId, sectionId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website edit permission is required.",
      );
    const section = await db.websiteSection.findFirst({
      where: { id: sectionId, pageId },
      include: { page: { select: { slug: true } } },
    });
    if (!section)
      return cmsRedirect(request, path, "error", "Section not found.");
    await createWebsitePageRevision(
      pageId,
      session.user.id,
      `Section ${section.key} removed`,
    );
    await db.websiteSection.delete({ where: { id: sectionId } });
    await db.websitePage.update({
      where: { id: pageId },
      data: { updatedById: session.user.id },
    });
    revalidatePath(
      section.page.slug === "home" ? "/" : `/${section.page.slug}`,
    );
    return cmsRedirect(request, path, "success", "Section removed.");
  } catch (error) {
    console.error("Website section deletion failed", error);
    return cmsRedirect(request, path, "error", "Section could not be removed.");
  }
}
