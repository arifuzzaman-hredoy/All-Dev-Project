import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import {
  cmsRedirect,
  formBoolean,
  formInt,
  formMultiline,
  formString,
  safeCanonicalPath,
} from "@/lib/cms/api";
import { normalizeWebsiteSlug, validateWebsiteSlug } from "@/lib/cms/content";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string }> },
): Promise<NextResponse> {
  const { pageId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website edit permission is required.",
      );
    const existing = await db.websitePage.findUnique({
      where: { id: pageId },
      select: { slug: true, isSystem: true },
    });
    if (!existing)
      return cmsRedirect(request, "/admin/website", "error", "Page not found.");
    const form = await readForm(request);
    const title = formString(form, "title", 120);
    const slug = existing.isSystem
      ? existing.slug
      : normalizeWebsiteSlug(formString(form, "slug", 80));
    const slugError = validateWebsiteSlug(slug);
    if (title.length < 2)
      return cmsRedirect(request, path, "error", "Enter a valid page title.");
    if (!existing.isSystem && slugError)
      return cmsRedirect(request, path, "error", slugError);
    const duplicate = await db.websitePage.findFirst({
      where: { slug, id: { not: pageId } },
      select: { id: true },
    });
    if (duplicate)
      return cmsRedirect(
        request,
        path,
        "error",
        "Another page already uses this slug.",
      );
    await createWebsitePageRevision(
      pageId,
      session.user.id,
      "Page metadata updated",
    );
    const excerpt = formMultiline(form, "excerpt", 300) || null;
    await db.websitePage.update({
      where: { id: pageId },
      data: {
        title,
        slug,
        navigationLabel: formString(form, "navigationLabel", 60) || null,
        excerpt,
        showInHeader: formBoolean(form, "showInHeader"),
        showInFooter: formBoolean(form, "showInFooter"),
        headerOrder: formInt(form, "headerOrder"),
        footerOrder: formInt(form, "footerOrder"),
        seoTitle: formString(form, "seoTitle", 70) || null,
        seoDescription: formString(form, "seoDescription", 170) || excerpt,
        canonicalPath: safeCanonicalPath(
          formString(form, "canonicalPath", 160),
          slug === "home" ? "/" : `/${slug}`,
        ),
        updatedById: session.user.id,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "WEBSITE",
      targetType: "WebsitePage",
      targetId: pageId,
      metadata: { slug, title },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    revalidatePath("/");
    revalidatePath(slug === "home" ? "/" : `/${slug}`);
    return cmsRedirect(request, path, "success", "Page metadata saved.");
  } catch (error) {
    console.error("Website page update failed", error);
    return cmsRedirect(
      request,
      path,
      "error",
      "Page metadata could not be saved.",
    );
  }
}
