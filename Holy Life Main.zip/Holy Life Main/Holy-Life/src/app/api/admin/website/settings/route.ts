import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import { revalidatePath } from "next/cache";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect, formString } from "@/lib/cms/api";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        "/admin/website/settings",
        "error",
        "Website edit permission is required.",
      );
    const form = await readForm(request);
    const value = {
      name: formString(form, "name", 80),
      tagline: formString(form, "tagline", 120),
      supportEmail: formString(form, "supportEmail", 160),
      supportPhone: formString(form, "supportPhone", 80),
      address: formString(form, "address", 240),
      hours: formString(form, "hours", 120),
    };
    if (Object.values(value).some((item) => !item))
      return cmsRedirect(
        request,
        "/admin/website/settings",
        "error",
        "Complete every brand setting.",
      );
    await db.systemSetting.upsert({
      where: { key: "website.branding" },
      update: { value: value as Prisma.InputJsonValue },
      create: {
        key: "website.branding",
        value: value as Prisma.InputJsonValue,
      },
    });
    revalidatePath("/");
    return cmsRedirect(
      request,
      "/admin/website/settings",
      "success",
      "Brand settings saved.",
    );
  } catch (error) {
    console.error("Website settings update failed", error);
    return cmsRedirect(
      request,
      "/admin/website/settings",
      "error",
      "Brand settings could not be saved.",
    );
  }
}
