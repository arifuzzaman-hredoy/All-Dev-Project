import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string }> },
): Promise<NextResponse> {
  const { pageId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.edit"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website edit permission is required.",
      );
    const page = await db.websitePage.findUnique({
      where: { id: pageId },
      select: { slug: true },
    });
    if (!page)
      return cmsRedirect(request, "/admin/website", "error", "Page not found.");
    await createWebsitePageRevision(
      pageId,
      session.user.id,
      "Page moved to draft",
    );
    await db.websitePage.update({
      where: { id: pageId },
      data: {
        status: "DRAFT",
        publishedAt: null,
        updatedById: session.user.id,
      },
    });
    revalidatePath("/");
    revalidatePath(page.slug === "home" ? "/" : `/${page.slug}`);
    return cmsRedirect(request, path, "success", "Page moved to draft.");
  } catch (error) {
    console.error("Website draft transition failed", error);
    return cmsRedirect(
      request,
      path,
      "error",
      "Page status could not be changed.",
    );
  }
}
