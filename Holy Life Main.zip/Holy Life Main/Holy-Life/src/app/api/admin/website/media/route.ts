import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect, formInt, formString } from "@/lib/cms/api";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.create"))
      return cmsRedirect(
        request,
        "/admin/website/media",
        "error",
        "Website create permission is required.",
      );
    const form = await readForm(request);
    const name = formString(form, "name", 120);
    const url = formString(form, "url", 2000);
    const altText = formString(form, "altText", 180);
    if (!name || !altText || !url.startsWith("https://"))
      return cmsRedirect(
        request,
        "/admin/website/media",
        "error",
        "Name, alt text, and an HTTPS URL are required.",
      );
    await db.websiteMedia.create({
      data: {
        name,
        url,
        altText,
        mimeType: formString(form, "mimeType", 80) || null,
        width: formInt(form, "width", 0) || null,
        height: formInt(form, "height", 0) || null,
        createdById: session.user.id,
      },
    });
    return cmsRedirect(
      request,
      "/admin/website/media",
      "success",
      "Media URL added.",
    );
  } catch (error) {
    console.error("Website media creation failed", error);
    return cmsRedirect(
      request,
      "/admin/website/media",
      "error",
      "Media URL could not be added.",
    );
  }
}
