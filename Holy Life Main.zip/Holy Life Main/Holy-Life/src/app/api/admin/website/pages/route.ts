import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import {
  cmsRedirect,
  formBoolean,
  formInt,
  formMultiline,
  formString,
} from "@/lib/cms/api";
import { normalizeWebsiteSlug, validateWebsiteSlug } from "@/lib/cms/content";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.create"))
      return cmsRedirect(
        request,
        "/admin/website",
        "error",
        "Website create permission is required.",
      );
    const form = await readForm(request);
    const title = formString(form, "title", 120);
    const slug = normalizeWebsiteSlug(formString(form, "slug", 80));
    const slugError = validateWebsiteSlug(slug);
    if (title.length < 2)
      return cmsRedirect(
        request,
        "/admin/website/pages/create",
        "error",
        "Enter a valid page title.",
      );
    if (slugError)
      return cmsRedirect(
        request,
        "/admin/website/pages/create",
        "error",
        slugError,
      );
    const duplicate = await db.websitePage.findUnique({
      where: { slug },
      select: { id: true },
    });
    if (duplicate)
      return cmsRedirect(
        request,
        "/admin/website/pages/create",
        "error",
        "A page already uses this slug.",
      );
    const excerpt = formMultiline(form, "excerpt", 300) || null;
    const page = await db.websitePage.create({
      data: {
        slug,
        title,
        navigationLabel: formString(form, "navigationLabel", 60) || null,
        excerpt,
        status: "DRAFT",
        showInHeader: formBoolean(form, "showInHeader"),
        showInFooter: formBoolean(form, "showInFooter"),
        headerOrder: formInt(form, "headerOrder", 100),
        footerOrder: formInt(form, "footerOrder", 100),
        seoTitle: formString(form, "seoTitle", 70) || title,
        seoDescription: excerpt,
        canonicalPath: `/${slug}`,
        createdById: session.user.id,
        updatedById: session.user.id,
      },
      select: { id: true },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "WEBSITE",
      targetType: "WebsitePage",
      targetId: page.id,
      metadata: { slug, title },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    revalidatePath("/");
    return cmsRedirect(
      request,
      `/admin/website/pages/${page.id}`,
      "success",
      "Draft page created. Add sections before publishing.",
    );
  } catch (error) {
    console.error("Website page creation failed", error);
    return cmsRedirect(
      request,
      "/admin/website/pages/create",
      "error",
      "Page could not be created.",
    );
  }
}
