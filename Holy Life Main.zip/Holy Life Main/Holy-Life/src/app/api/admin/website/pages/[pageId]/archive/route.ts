import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string }> },
): Promise<NextResponse> {
  const { pageId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.archive"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website archive permission is required.",
      );
    const page = await db.websitePage.findUnique({
      where: { id: pageId },
      select: { slug: true, isSystem: true },
    });
    if (!page)
      return cmsRedirect(request, "/admin/website", "error", "Page not found.");
    if (page.isSystem)
      return cmsRedirect(
        request,
        path,
        "error",
        "System pages cannot be archived.",
      );
    await createWebsitePageRevision(pageId, session.user.id, "Page archived");
    await db.websitePage.update({
      where: { id: pageId },
      data: {
        status: "ARCHIVED",
        archivedAt: new Date(),
        showInHeader: false,
        showInFooter: false,
        updatedById: session.user.id,
      },
    });
    revalidatePath("/");
    revalidatePath(`/${page.slug}`);
    return cmsRedirect(
      request,
      "/admin/website",
      "success",
      "Custom page archived.",
    );
  } catch (error) {
    console.error("Website archive failed", error);
    return cmsRedirect(request, path, "error", "Page could not be archived.");
  }
}
