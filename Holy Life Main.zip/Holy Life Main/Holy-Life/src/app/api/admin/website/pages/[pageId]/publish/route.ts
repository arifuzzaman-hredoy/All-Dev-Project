import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { writeAuditLog } from "@/lib/auth/audit";
import { clientIp, assertSameOrigin, userAgent } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { cmsRedirect } from "@/lib/cms/api";
import { createWebsitePageRevision } from "@/lib/cms/revisions";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ pageId: string }> },
): Promise<NextResponse> {
  const { pageId } = await params;
  const path = `/admin/website/pages/${pageId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session || !hasPermission(session.user, "website.cms.content.publish"))
      return cmsRedirect(
        request,
        path,
        "error",
        "Website publish permission is required.",
      );
    const page = await db.websitePage.findUnique({
      where: { id: pageId },
      include: { _count: { select: { sections: true } } },
    });
    if (!page)
      return cmsRedirect(request, "/admin/website", "error", "Page not found.");
    if (page._count.sections === 0)
      return cmsRedirect(
        request,
        path,
        "error",
        "Add at least one section before publishing.",
      );
    await createWebsitePageRevision(pageId, session.user.id, "Page published");
    await db.websitePage.update({
      where: { id: pageId },
      data: {
        status: "PUBLISHED",
        publishedAt: new Date(),
        archivedAt: null,
        updatedById: session.user.id,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "WEBSITE",
      targetType: "WebsitePage",
      targetId: pageId,
      metadata: { status: "PUBLISHED", slug: page.slug },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    revalidatePath("/");
    revalidatePath(page.slug === "home" ? "/" : `/${page.slug}`);
    return cmsRedirect(
      request,
      path,
      "success",
      "Page published successfully.",
    );
  } catch (error) {
    console.error("Website publish failed", error);
    return cmsRedirect(request, path, "error", "Page could not be published.");
  }
}
