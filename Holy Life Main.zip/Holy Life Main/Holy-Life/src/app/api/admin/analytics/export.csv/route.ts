import { NextRequest, NextResponse } from "next/server";
import { getCurrentSession, hasGlobalPermission } from "@/lib/auth/session";
import { platformAnalytics } from "@/lib/analytics/queries";
import { analyticsRange } from "@/lib/analytics/validation";
import { csvRows } from "@/lib/finance/csv";
import { writeAuditLog } from "@/lib/auth/audit";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (
    !session ||
    !hasGlobalPermission(session.user, "system.analytics.platform.export")
  ) {
    return new NextResponse("Forbidden", { status: 403 });
  }

  try {
    const url = new URL(request.url);
    const range = analyticsRange(
      url.searchParams.get("from") ?? undefined,
      url.searchParams.get("to") ?? undefined,
    );
    const data = await platformAnalytics(range);

    const rows = [
      ["Metric", "Value"],
      ["Verified net revenue", data.revenue.total],
      ["Healthcare revenue", data.revenue.healthcare],
      ["Commerce revenue", data.revenue.commerce],
      ["Learning revenue", data.revenue.learning],
      ["New users", data.users],
      ["Patient records", data.patients],
      ["Appointments", data.appointments],
      ["Completed appointments", data.completedAppointments],
      ["No shows", data.noShows],
      ["Signed prescriptions", data.signedPrescriptions],
      ["Orders", data.orders],
      ["Delivered orders", data.deliveredOrders],
      ["Enrollments", data.enrollments],
      ["Completed enrollments", data.completions],
      ["Certificates", data.certificates],
      ["Audit events", data.auditEvents],
      ["Sensitive data views", data.sensitiveViews],
    ];

    await writeAuditLog({
      actorId: session.user.id,
      action: "EXPORT",
      department: "SYSTEM",
      targetType: "PlatformAnalyticsExport",
      metadata: {
        from: url.searchParams.get("from") ?? null,
        to: url.searchParams.get("to") ?? null,
      },
    });

    return new NextResponse(csvRows(rows), {
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="holy-life-platform-analytics-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (error) {
    console.error("Analytics export failed", error);
    return new NextResponse("Invalid analytics request", { status: 400 });
  }
}
