import { NextRequest, NextResponse } from "next/server";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { listFinanceTransactions } from "@/lib/finance/queries";
import { reportDate } from "@/lib/finance/validation";

import { csvRows } from "@/lib/finance/csv";
import { writeAuditLog } from "@/lib/auth/audit";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (
    !session ||
    !hasPermission(session.user, "system.reports.financial-report.export")
  ) {
    return new NextResponse("Forbidden", { status: 403 });
  }

  try {
    const url = new URL(request.url);
    const from = reportDate(url.searchParams.get("from") ?? undefined);
    const to = reportDate(url.searchParams.get("to") ?? undefined, true);
    const transactions = await listFinanceTransactions({ from, to }, 1000);

    const rows = [
      [
        "Code",
        "Date",
        "Domain",
        "Reference",
        "Customer",
        "Type",
        "Method",
        "Status",
        "Amount",
        "Currency",
        "Transaction Reference",
        "Verified By",
      ],
      ...transactions.map((transaction) => [
        transaction.code,
        transaction.createdAt.toISOString(),
        transaction.account.domain,
        transaction.account.referenceCode,
        transaction.account.user?.name ?? "",
        transaction.type,
        transaction.method ?? "",
        transaction.status,
        transaction.amount.toString(),
        transaction.account.currency,
        transaction.transactionReference ?? "",
        transaction.verifiedBy?.name ?? "",
      ]),
    ];

    const body = csvRows(rows);
    await writeAuditLog({
      actorId: session.user.id,
      action: "EXPORT",
      department: "SYSTEM",
      targetType: "FinanceReportExport",
      metadata: { resultCount: transactions.length },
    });
    return new NextResponse(body, {
      status: 200,
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="holy-life-finance-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (error) {
    console.error("Finance CSV export failed", error);
    return new NextResponse("Invalid report request", { status: 400 });
  }
}
