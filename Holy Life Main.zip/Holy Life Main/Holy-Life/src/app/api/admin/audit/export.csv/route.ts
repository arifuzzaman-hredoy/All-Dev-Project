import { NextRequest, NextResponse } from "next/server";
import { getCurrentSession, hasGlobalPermission } from "@/lib/auth/session";
import { listAuditEvents } from "@/lib/audit/queries";
import { auditFilters } from "@/lib/audit/validation";
import { csvRows } from "@/lib/finance/csv";
import { writeAuditLog } from "@/lib/auth/audit";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (
    !session ||
    !hasGlobalPermission(session.user, "system.audit.audit-log.export")
  ) {
    return new NextResponse("Forbidden", { status: 403 });
  }

  try {
    const url = new URL(request.url);
    const filters = auditFilters({
      from: url.searchParams.get("from") ?? undefined,
      to: url.searchParams.get("to") ?? undefined,
      action: url.searchParams.get("action") ?? undefined,
      department: url.searchParams.get("department") ?? undefined,
      search: url.searchParams.get("search") ?? undefined,
    });
    const events = await listAuditEvents(filters, 1000);

    const rows = [
      [
        "Timestamp",
        "Action",
        "Department",
        "Actor",
        "Actor email",
        "Target type",
        "Target ID",
        "IP address",
        "User agent",
      ],
      ...events.map((event) => [
        event.createdAt.toISOString(),
        event.action,
        event.department ?? "",
        event.actor?.name ?? "",
        event.actor?.email ?? "",
        event.targetType,
        event.targetId ?? "",
        event.ipAddress ?? "",
        event.userAgent ?? "",
      ]),
    ];

    await writeAuditLog({
      actorId: session.user.id,
      action: "EXPORT",
      department: "SYSTEM",
      targetType: "AuditLogExport",
      metadata: { resultCount: events.length },
    });

    return new NextResponse(csvRows(rows), {
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="holy-life-audit-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (error) {
    console.error("Audit export failed", error);
    return new NextResponse("Invalid audit request", { status: 400 });
  }
}
