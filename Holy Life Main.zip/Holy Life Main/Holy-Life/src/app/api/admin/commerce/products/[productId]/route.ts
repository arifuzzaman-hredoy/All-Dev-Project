import { ProductStatus } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { optionalText, requiredText, slugify } from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ productId: string }> },
): Promise<NextResponse> {
  const { productId } = await params;
  const path = `/admin/commerce/products/${productId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.product.edit")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Product edit permission is required.",
      );
    const form = await readForm(request);
    const status = requiredText(form, "status", 20);
    if (!Object.values(ProductStatus).includes(status as ProductStatus))
      return commerceRedirect(request, path, "error", "Status is invalid.");
    const name = requiredText(form, "name", 160);
    const slug = slugify(requiredText(form, "slug", 100));
    const categoryId = requiredText(form, "categoryId", 100);
    const imageUrl = optionalText(form, "imageUrl", 1000);
    const removePrimaryImage = String(form.get("removePrimaryImage")) === "on";

    const product = await db.$transaction(async (tx) => {
      const updated = await tx.product.update({
        where: { id: productId },
        data: {
          name,
          nameBn: optionalText(form, "nameBn", 160),
          slug,
          categoryId,
          brandId: optionalText(form, "brandId", 100),
          status: status as ProductStatus,
          isFeatured: String(form.get("isFeatured")) === "true",
          shortDescription: optionalText(form, "shortDescription", 300),
          shortDescriptionBn: optionalText(form, "shortDescriptionBn", 300),
          description: optionalText(form, "description", 5000),
          descriptionBn: optionalText(form, "descriptionBn", 5000),
        },
      });

      const currentPrimary = await tx.productImage.findFirst({
        where: { productId, isPrimary: true },
        orderBy: { position: "asc" },
      });
      if (removePrimaryImage && currentPrimary) {
        await tx.productImage.delete({ where: { id: currentPrimary.id } });
      } else if (imageUrl) {
        const imageData = {
          url: imageUrl,
          altText: optionalText(form, "imageAlt", 200) ?? name,
          altTextBn: optionalText(form, "imageAltBn", 200),
          isPrimary: true,
          position: 0,
        };
        if (currentPrimary)
          await tx.productImage.update({
            where: { id: currentPrimary.id },
            data: imageData,
          });
        else
          await tx.productImage.create({ data: { productId, ...imageData } });
      }
      return updated;
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "Product",
      targetId: product.id,
      metadata: { status: product.status, slug, categoryId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Product updated.");
  } catch (error) {
    console.error("Product update failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Product could not be updated. Check slug, category and image URL.",
    );
  }
}
