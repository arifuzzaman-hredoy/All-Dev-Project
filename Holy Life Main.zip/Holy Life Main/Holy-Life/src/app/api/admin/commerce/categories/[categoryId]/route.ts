import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ categoryId: string }> },
): Promise<NextResponse> {
  const { categoryId } = await params;
  const path = "/admin/commerce/products/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.category.manage")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Category permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 100);
    const category = await db.productCategory.update({
      where: { id: categoryId },
      data: {
        name,
        nameBn: optionalText(form, "nameBn", 100),
        slug: slugify(requiredText(form, "slug", 100)),
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        imageUrl: optionalText(form, "imageUrl", 1000),
        displayOrder: nonNegativeInteger(form, "displayOrder", 100),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "ProductCategory",
      targetId: category.id,
      metadata: { name: category.name, isActive: category.isActive },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Category updated.");
  } catch (error) {
    console.error("Category update failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Category could not be updated. Check duplicate slug.",
    );
  }
}
