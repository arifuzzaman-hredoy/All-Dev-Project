import { ProductStatus } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  nonNegativeMoney,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/products/create";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.product.create")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Product create permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 160);
    const slug = slugify(optionalText(form, "slug", 100) || name);
    const status = requiredText(form, "status", 20);
    if (!Object.values(ProductStatus).includes(status as ProductStatus))
      return commerceRedirect(
        request,
        path,
        "error",
        "Product status is invalid.",
      );
    const categoryId = requiredText(form, "categoryId", 100);
    const sku = requiredText(form, "sku", 80).toUpperCase();
    const stock = nonNegativeInteger(form, "stockOnHand", 0);
    const imageUrl = optionalText(form, "imageUrl", 1000);

    const product = await db.$transaction(async (tx) => {
      const created = await tx.product.create({
        data: {
          name,
          nameBn: optionalText(form, "nameBn", 160),
          slug,
          categoryId,
          brandId: optionalText(form, "brandId", 100),
          shortDescription: optionalText(form, "shortDescription", 300),
          shortDescriptionBn: optionalText(form, "shortDescriptionBn", 300),
          description: optionalText(form, "description", 5000),
          descriptionBn: optionalText(form, "descriptionBn", 5000),
          status: status as ProductStatus,
          isFeatured: String(form.get("isFeatured")) === "on",
          variants: {
            create: {
              sku,
              name: requiredText(form, "variantName", 100),
              nameBn: optionalText(form, "variantNameBn", 100),
              price: nonNegativeMoney(form, "price"),
              compareAtPrice: optionalText(form, "compareAtPrice", 50)
                ? nonNegativeMoney(form, "compareAtPrice")
                : null,
              stockOnHand: stock,
              lowStockAt: nonNegativeInteger(form, "lowStockAt", 5),
              isDefault: true,
            },
          },
          ...(imageUrl
            ? {
                images: {
                  create: {
                    url: imageUrl,
                    altText: optionalText(form, "imageAlt", 200) ?? name,
                    altTextBn: optionalText(form, "imageAltBn", 200),
                    isPrimary: true,
                  },
                },
              }
            : {}),
        },
        include: { variants: true },
      });
      if (stock > 0) {
        await tx.stockMovement.create({
          data: {
            variantId: created.variants[0]!.id,
            type: "OPENING",
            quantity: stock,
            balanceAfter: stock,
            note: "Opening stock",
            createdById: session.user.id,
          },
        });
      }
      return created;
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "Product",
      targetId: product.id,
      metadata: { name, slug, sku },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      `/admin/commerce/products/${product.id}`,
      "success",
      "Product created.",
    );
  } catch (error) {
    console.error("Product creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Product could not be created. Check category, slug and SKU.",
    );
  }
}
