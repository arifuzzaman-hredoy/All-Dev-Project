import { Prisma, RefundStatus } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  assertRefundTransition,
  type RefundState,
} from "@/lib/commerce/status";
import { optionalText, requiredText } from "@/lib/commerce/validation";
import { db } from "@/lib/db";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { recordVerifiedTransactionInTransaction } from "@/lib/finance/service";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ refundId: string }> },
): Promise<NextResponse> {
  const { refundId } = await params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.orders.refund.approve")
    ) {
      return commerceRedirect(
        request,
        "/admin/commerce/orders/returns",
        "error",
        "Refund approval permission is required.",
      );
    }
    const form = await readForm(request);
    const status = requiredText(form, "status", 30);
    if (!Object.values(RefundStatus).includes(status as RefundStatus)) {
      return commerceRedirect(
        request,
        "/admin/commerce/orders/returns",
        "error",
        "Refund status is invalid.",
      );
    }
    const resolutionNote = optionalText(form, "resolutionNote", 1000);
    const result = await db.$transaction(
      async (tx) => {
        const existing = await tx.refundRequest.findUnique({
          where: { id: refundId },
          include: { order: true },
        });
        if (!existing) throw new Error("Refund request was not found.");
        const next = status as RefundState;
        if (existing.status === next) {
          return {
            refund: existing,
            orderId: existing.orderId,
            userId: existing.userId,
            code: existing.order.code,
            financeTransactionId: null,
            changed: false,
          };
        }
        assertRefundTransition(existing.status as RefundState, next);
        if (Number(existing.amount) > Number(existing.order.grandTotal)) {
          throw new Error("Refund exceeds the paid order total.");
        }
        if (next === "COMPLETED") {
          if (
            existing.order.status !== "DELIVERED" ||
            existing.order.paymentStatus !== "PAID"
          ) {
            throw new Error(
              "Only a fully paid delivered order can be refunded.",
            );
          }
          const completedCount = await tx.refundRequest.count({
            where: {
              orderId: existing.orderId,
              status: "COMPLETED",
              id: { not: existing.id },
            },
          });
          if (completedCount > 0)
            throw new Error("This order has already been refunded.");
        }
        let financeTransactionId: string | null = null;
        if (next === "COMPLETED") {
          const paymentAccount = await tx.paymentAccount.findUnique({
            where: {
              domain_referenceType_referenceId: {
                domain: "COMMERCE",
                referenceType: "CommerceOrder",
                referenceId: existing.orderId,
              },
            },
            select: { id: true },
          });
          if (!paymentAccount) {
            throw new Error(
              "The unified finance account for this order is missing.",
            );
          }

          const financeResult = await recordVerifiedTransactionInTransaction(
            tx,
            {
              accountId: paymentAccount.id,
              actorId: session.user.id,
              code: `RFD-REQUEST-${existing.id}`,
              type: "REFUND",
              amount: Number(existing.amount),
              transactionReference: `REFUND:${existing.id}`,
              note: resolutionNote || "Commerce refund request completed.",
            },
          );
          financeTransactionId = financeResult.transaction.id;
        }

        const refund = await tx.refundRequest.update({
          where: { id: refundId },
          data: {
            status: next,
            resolutionNote,
            resolvedById: session.user.id,
            resolvedAt: next === "REQUESTED" ? null : new Date(),
          },
        });
        if (next === "COMPLETED") {
          await tx.commerceOrder.update({
            where: { id: existing.orderId },
            data: {
              status: "REFUNDED",
              paymentStatus: "REFUNDED",
              updatedById: session.user.id,
            },
          });
          await tx.orderStatusHistory.create({
            data: {
              orderId: existing.orderId,
              fromStatus: existing.order.status,
              toStatus: "REFUNDED",
              actorId: session.user.id,
              note: resolutionNote || "Full refund completed.",
            },
          });
        }
        return {
          refund,
          orderId: existing.orderId,
          userId: existing.userId,
          code: existing.order.code,
          financeTransactionId,
          changed: true,
        };
      },
      {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 20_000,
      },
    );

    if (result.financeTransactionId) {
      await createDashboardNotification({
        userId: result.userId,
        dedupeKey: `commerce-refund:${result.refund.id}:completed`,
        kind: "WARNING",
        department: "COMMERCE",
        title: "Order refund completed",
        message: `${result.code} · BDT ${Number(result.refund.amount).toFixed(2)}`,
        href: "/dashboard/payments",
      });
    }

    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "COMMERCE",
      targetType: "RefundRequest",
      targetId: result.refund.id,
      metadata: {
        status,
        orderId: result.orderId,
        amount: result.refund.amount.toString(),
        financeTransactionId: result.financeTransactionId,
        changed: result.changed,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      `/admin/commerce/orders/${result.orderId}`,
      "success",
      "Refund request updated.",
    );
  } catch (error) {
    console.error("Refund resolution failed", error);
    return commerceRedirect(
      request,
      "/admin/commerce/orders/returns",
      "error",
      error instanceof Error ? error.message : "Refund could not be updated.",
    );
  }
}
