import { CouponType } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeMoney,
  optionalText,
  positiveInteger,
  requiredText,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";
export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/coupons";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.coupon.manage")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Coupon permission is required.",
      );
    const form = await readForm(request);
    const type = requiredText(form, "type", 20);
    if (!Object.values(CouponType).includes(type as CouponType))
      return commerceRedirect(
        request,
        path,
        "error",
        "Coupon type is invalid.",
      );
    const value = nonNegativeMoney(form, "value");
    if (type === "PERCENTAGE" && value > 100)
      return commerceRedirect(
        request,
        path,
        "error",
        "Percentage cannot exceed 100.",
      );
    const coupon = await db.coupon.create({
      data: {
        code: requiredText(form, "code", 50)
          .toUpperCase()
          .replace(/[^A-Z0-9_-]/g, ""),
        name: requiredText(form, "name", 120),
        type: type as CouponType,
        value,
        minimumSubtotal: optionalText(form, "minimumSubtotal", 50)
          ? nonNegativeMoney(form, "minimumSubtotal")
          : null,
        maximumDiscount: optionalText(form, "maximumDiscount", 50)
          ? nonNegativeMoney(form, "maximumDiscount")
          : null,
        usageLimit: optionalText(form, "usageLimit", 20)
          ? positiveInteger(form, "usageLimit", 1, 1000000)
          : null,
        perUserLimit: positiveInteger(form, "perUserLimit", 1, 100),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "Coupon",
      targetId: coupon.id,
      metadata: { code: coupon.code, type: coupon.type },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Coupon created.");
  } catch (error) {
    console.error("Coupon creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Coupon could not be created. Check duplicate code.",
    );
  }
}
