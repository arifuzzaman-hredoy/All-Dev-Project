import { CommerceOrderStatus } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { transitionOrderStatus } from "@/lib/commerce/service";
import { type CommerceOrderState } from "@/lib/commerce/status";
import { optionalText, requiredText } from "@/lib/commerce/validation";
import { createDashboardNotification } from "@/lib/dashboard/notifications";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> },
): Promise<NextResponse> {
  const { orderId } = await params;
  const path = `/admin/commerce/orders/${orderId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.orders.order.update-status")
    ) {
      return commerceRedirect(
        request,
        path,
        "error",
        "Order status permission is required.",
      );
    }
    const form = await readForm(request);
    const next = requiredText(form, "status", 30);
    if (
      !Object.values(CommerceOrderStatus).includes(next as CommerceOrderStatus)
    ) {
      return commerceRedirect(
        request,
        path,
        "error",
        "Order status is invalid.",
      );
    }
    const note = optionalText(form, "note", 500);
    const result = await transitionOrderStatus({
      orderId,
      nextStatus: next as CommerceOrderState,
      actorId: session.user.id,
      note,
    });
    if (!result.changed)
      return commerceRedirect(
        request,
        path,
        "success",
        "Order status is unchanged.",
      );
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "COMMERCE",
      targetType: "CommerceOrder",
      targetId: result.order.id,
      metadata: { from: result.previousStatus, to: next },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    await createDashboardNotification({
      userId: result.order.userId,
      dedupeKey: `order:${result.order.id}:status:${next}`,
      kind:
        next === "CANCELLED"
          ? "WARNING"
          : next === "DELIVERED"
            ? "SUCCESS"
            : "INFO",
      department: "COMMERCE",
      title: `Order ${next.replaceAll("_", " ").toLowerCase()}`,
      message: result.order.code,
      href: `/dashboard/shopping/orders/detail?code=${encodeURIComponent(result.order.code)}`,
    });
    return commerceRedirect(
      request,
      path,
      "success",
      `Order moved to ${next}.`,
    );
  } catch (error) {
    console.error("Order status update failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Order status could not be updated.",
    );
  }
}
