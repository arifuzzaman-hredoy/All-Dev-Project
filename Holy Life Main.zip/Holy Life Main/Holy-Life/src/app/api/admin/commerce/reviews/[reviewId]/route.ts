import { ReviewStatus } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { requiredText } from "@/lib/commerce/validation";
import { db } from "@/lib/db";
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ reviewId: string }> },
): Promise<NextResponse> {
  const path = "/admin/commerce/reviews";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.product.edit")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Product edit permission is required.",
      );
    const form = await readForm(request);
    const status = requiredText(form, "status", 30);
    if (!Object.values(ReviewStatus).includes(status as ReviewStatus))
      return commerceRedirect(
        request,
        path,
        "error",
        "Review status is invalid.",
      );
    const { reviewId } = await params;
    const review = await db.productReview.update({
      where: { id: reviewId },
      data: { status: status as ReviewStatus, moderatedAt: new Date() },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "COMMERCE",
      targetType: "ProductReview",
      targetId: review.id,
      metadata: { status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      path,
      "success",
      "Review moderation saved.",
    );
  } catch (error) {
    console.error("Review moderation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Review could not be updated.",
    );
  }
}
