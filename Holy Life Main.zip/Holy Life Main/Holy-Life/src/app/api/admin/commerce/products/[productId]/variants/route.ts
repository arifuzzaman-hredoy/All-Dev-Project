import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  nonNegativeMoney,
  optionalText,
  requiredText,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ productId: string }> },
): Promise<NextResponse> {
  const { productId } = await params;
  const path = `/admin/commerce/products/${productId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.product.edit")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Product edit permission is required.",
      );
    const form = await readForm(request);
    const stock = nonNegativeInteger(form, "stockOnHand", 0);
    const variant = await db.$transaction(async (tx) => {
      const created = await tx.productVariant.create({
        data: {
          productId,
          name: requiredText(form, "name", 100),
          nameBn: optionalText(form, "nameBn", 100),
          sku: requiredText(form, "sku", 80).toUpperCase(),
          price: nonNegativeMoney(form, "price"),
          compareAtPrice: optionalText(form, "compareAtPrice", 50)
            ? nonNegativeMoney(form, "compareAtPrice")
            : null,
          stockOnHand: stock,
          lowStockAt: nonNegativeInteger(form, "lowStockAt", 5),
        },
      });
      if (stock > 0)
        await tx.stockMovement.create({
          data: {
            variantId: created.id,
            type: "OPENING",
            quantity: stock,
            balanceAfter: stock,
            note: "Opening stock",
            createdById: session.user.id,
          },
        });
      return created;
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "ProductVariant",
      targetId: variant.id,
      metadata: { productId, sku: variant.sku },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Variant added.");
  } catch (error) {
    console.error("Variant creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Variant could not be added. Check SKU.",
    );
  }
}
