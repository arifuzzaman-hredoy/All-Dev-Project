import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> },
): Promise<NextResponse> {
  assertSameOrigin(request);
  const session = await getCurrentSession();
  if (!session || !hasPermission(session.user, "system.finance.payment.view")) {
    return financeRedirect(
      request,
      "/admin/finance/payments?domain=COMMERCE",
      "error",
      "Unified finance access is required.",
    );
  }

  const { orderId } = await params;
  return financeRedirect(
    request,
    `/admin/finance/payments?domain=COMMERCE&search=${encodeURIComponent(orderId)}`,
    "error",
    "Direct order payment-status changes are disabled. Record or verify the payment in the auditable finance ledger.",
  );
}
