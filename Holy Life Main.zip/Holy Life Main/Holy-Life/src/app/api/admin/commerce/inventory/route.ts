import { NextRequest, NextResponse } from "next/server";

import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { adjustStock, CommerceError } from "@/lib/commerce/service";
import {
  optionalText,
  positiveInteger,
  requiredText,
} from "@/lib/commerce/validation";

const adjustableStockMovementTypes = [
  "PURCHASE",
  "ADJUSTMENT_IN",
  "ADJUSTMENT_OUT",
  "RETURN_IN",
  "DAMAGE_OUT",
] as const;

type AdjustableStockMovementType =
  (typeof adjustableStockMovementTypes)[number];

function isAdjustableStockMovementType(
  value: string,
): value is AdjustableStockMovementType {
  return adjustableStockMovementTypes.some((candidate) => candidate === value);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/products/inventory";

  try {
    assertSameOrigin(request);

    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.inventory.stock.update")
    ) {
      return commerceRedirect(
        request,
        path,
        "error",
        "Stock update permission is required.",
      );
    }

    const form = await readForm(request);
    const type = requiredText(form, "type", 40);

    if (!isAdjustableStockMovementType(type)) {
      return commerceRedirect(
        request,
        path,
        "error",
        "Movement type is invalid.",
      );
    }

    const movement = await adjustStock({
      variantId: requiredText(form, "variantId", 100),
      quantity: positiveInteger(form, "quantity", 1, 100000),
      type,
      note: optionalText(form, "note", 500),
      actorId: session.user.id,
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "StockMovement",
      targetId: movement.id,
      metadata: {
        type: movement.type,
        quantity: movement.quantity,
        balanceAfter: movement.balanceAfter,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return commerceRedirect(request, path, "success", "Stock movement posted.");
  } catch (error) {
    return commerceRedirect(
      request,
      path,
      "error",
      error instanceof CommerceError
        ? error.message
        : "Stock could not be updated.",
    );
  }
}
