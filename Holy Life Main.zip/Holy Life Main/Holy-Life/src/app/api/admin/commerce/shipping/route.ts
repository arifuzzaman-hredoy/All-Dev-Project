import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  nonNegativeMoney,
  optionalText,
  requiredText,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/settings";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.shipping.shipping.manage")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Shipping permission is required.",
      );
    const form = await readForm(request);
    const method = await db.shippingMethod.create({
      data: {
        code: requiredText(form, "code", 50)
          .toUpperCase()
          .replace(/[^A-Z0-9_]/g, "_"),
        name: requiredText(form, "name", 120),
        nameBn: optionalText(form, "nameBn", 120),
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        fee: nonNegativeMoney(form, "fee"),
        freeAbove: optionalText(form, "freeAbove", 50)
          ? nonNegativeMoney(form, "freeAbove")
          : null,
        estimatedDays: optionalText(form, "estimatedDays", 100),
        estimatedDaysBn: optionalText(form, "estimatedDaysBn", 100),
        displayOrder: nonNegativeInteger(form, "displayOrder", 0, 100000),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "ShippingMethod",
      targetId: method.id,
      metadata: { code: method.code, fee: method.fee.toString() },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      path,
      "success",
      "Shipping method created.",
    );
  } catch (error) {
    console.error("Shipping creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Shipping method could not be created.",
    );
  }
}
