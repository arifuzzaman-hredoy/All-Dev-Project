import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  nonNegativeMoney,
  optionalText,
  requiredText,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ productId: string; variantId: string }> },
): Promise<NextResponse> {
  const { productId, variantId } = await params;
  const path = `/admin/commerce/products/${productId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.product.edit")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Product edit permission is required.",
      );
    const form = await readForm(request);
    const exists = await db.productVariant.findFirst({
      where: { id: variantId, productId },
      select: { id: true },
    });
    if (!exists)
      return commerceRedirect(request, path, "error", "Variant not found.");
    const variant = await db.productVariant.update({
      where: { id: variantId },
      data: {
        name: requiredText(form, "name", 100),
        nameBn: optionalText(form, "nameBn", 100),
        price: nonNegativeMoney(form, "price"),
        compareAtPrice: optionalText(form, "compareAtPrice", 50)
          ? nonNegativeMoney(form, "compareAtPrice")
          : null,
        lowStockAt: nonNegativeInteger(form, "lowStockAt", 5),
        isActive: String(form.get("isActive")) === "true",
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "ProductVariant",
      targetId: variant.id,
      metadata: { productId, isActive: variant.isActive },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Variant updated.");
  } catch (error) {
    console.error("Variant update failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Variant could not be updated.",
    );
  }
}
