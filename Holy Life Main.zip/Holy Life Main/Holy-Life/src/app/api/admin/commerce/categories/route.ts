import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  nonNegativeInteger,
  optionalText,
  requiredText,
  slugify,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/products/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.category.manage")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Category permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 100);
    const slug = slugify(optionalText(form, "slug", 100) || name);
    if (!slug)
      return commerceRedirect(
        request,
        path,
        "error",
        "A valid slug is required.",
      );
    const category = await db.productCategory.create({
      data: {
        name,
        nameBn: optionalText(form, "nameBn", 100),
        slug,
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        imageUrl: optionalText(form, "imageUrl", 1000),
        displayOrder: nonNegativeInteger(form, "displayOrder", 100),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "ProductCategory",
      targetId: category.id,
      metadata: { name, slug },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Category created.");
  } catch (error) {
    console.error("Category creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Category could not be created. Check duplicate slug.",
    );
  }
}
