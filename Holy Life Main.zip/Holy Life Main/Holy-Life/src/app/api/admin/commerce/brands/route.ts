import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { optionalText, requiredText, slugify } from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/commerce/products/categories";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "commerce.catalog.category.manage")
    )
      return commerceRedirect(
        request,
        path,
        "error",
        "Category permission is required.",
      );
    const form = await readForm(request);
    const name = requiredText(form, "name", 100);
    const slug = slugify(optionalText(form, "slug", 100) || name);
    const brand = await db.productBrand.create({
      data: {
        name,
        nameBn: optionalText(form, "nameBn", 100),
        slug,
        description: optionalText(form, "description", 500),
        descriptionBn: optionalText(form, "descriptionBn", 500),
        logoUrl: optionalText(form, "logoUrl", 1000),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "ProductBrand",
      targetId: brand.id,
      metadata: { name, slug },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(request, path, "success", "Brand created.");
  } catch (error) {
    console.error("Brand creation failed", error);
    return commerceRedirect(
      request,
      path,
      "error",
      "Brand could not be created. Check duplicate slug.",
    );
  }
}
