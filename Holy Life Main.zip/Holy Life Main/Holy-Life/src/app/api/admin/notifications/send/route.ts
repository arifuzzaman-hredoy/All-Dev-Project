import { randomUUID } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import type {
  DashboardNotificationKind,
  DepartmentCode,
} from "@/generated/prisma/client";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasPermission } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import {
  dashboardHref,
  optionalFinanceText,
  requiredFinanceText,
} from "@/lib/finance/validation";
import { db } from "@/lib/db";

const KINDS = ["INFO", "SUCCESS", "WARNING", "ACTION"] as const;
const DEPARTMENTS = ["HEALTHCARE", "COMMERCE", "LEARNING", "SYSTEM"] as const;

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/admin/notifications";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (
      !session ||
      !hasPermission(session.user, "system.notifications.notification.manage")
    ) {
      return financeRedirect(
        request,
        path,
        "error",
        "Notification management permission is required.",
      );
    }

    const form = await readForm(request);
    const title = requiredFinanceText(form.get("title"), 160, "Title");
    const message = optionalFinanceText(form.get("message"), 1000);
    const href = dashboardHref(form.get("href"));
    const target = String(form.get("target") ?? "ALL");
    if (!["ALL", "USER"].includes(target))
      throw new Error("Notification target is invalid.");
    const kindRaw = String(form.get("kind") ?? "INFO");
    const departmentRaw = String(form.get("department") ?? "SYSTEM");
    if (!KINDS.includes(kindRaw as (typeof KINDS)[number]))
      throw new Error("Notification kind is invalid.");
    if (!DEPARTMENTS.includes(departmentRaw as (typeof DEPARTMENTS)[number]))
      throw new Error("Notification department is invalid.");

    const publicUserWhere = {
      status: "ACTIVE" as const,
      isSuperAdmin: false,
      roles: { none: { role: { isAdminRole: true } } },
    };

    const users =
      target === "USER"
        ? await db.user.findMany({
            where: {
              ...publicUserWhere,
              OR: [
                {
                  email:
                    String(form.get("recipient") ?? "")
                      .trim()
                      .toLowerCase() || "__missing__",
                },
                {
                  phone:
                    String(form.get("recipient") ?? "").trim() || "__missing__",
                },
              ],
            },
            select: { id: true },
            take: 1,
          })
        : await db.user.findMany({
            where: publicUserWhere,
            select: { id: true },
          });

    if (!users.length) throw new Error("No active recipient was found.");

    const batch = randomUUID().replaceAll("-", "").slice(0, 16);
    await db.dashboardNotification.createMany({
      data: users.map((user) => ({
        userId: user.id,
        kind: kindRaw as DashboardNotificationKind,
        department: departmentRaw as DepartmentCode,
        dedupeKey: `admin:${batch}:${user.id}`,
        title,
        message,
        href,
      })),
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: "DashboardNotificationBroadcast",
      targetId: batch,
      metadata: {
        target,
        recipients: users.length,
        title,
        kind: kindRaw,
        department: departmentRaw,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return financeRedirect(
      request,
      path,
      "success",
      `In-app notification sent to ${users.length} user${users.length === 1 ? "" : "s"}.`,
    );
  } catch (error) {
    console.error("Admin notification send failed", error);
    return financeRedirect(
      request,
      path,
      "error",
      error instanceof Error
        ? error.message
        : "Notification could not be sent.",
    );
  }
}
