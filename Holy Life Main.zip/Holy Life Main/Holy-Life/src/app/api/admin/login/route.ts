import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { appOrigin, authConfig } from "@/lib/auth/config";
import { verifyPassword } from "@/lib/auth/crypto";
import { normalizeIdentifier } from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  deviceLabelFromUserAgent,
  readForm,
  safeAdminReturnTo,
  userAgent,
} from "@/lib/auth/request";
import { createSession, setSessionCookie } from "@/lib/auth/session";
import {
  clearLoginThrottle,
  getLoginThrottle,
  recordLoginFailure,
} from "@/lib/auth/throttle";
import { db } from "@/lib/db";

const DUMMY_PASSWORD_HASH =
  "scrypt$32768$8$1$QNj8VGIqGMiHL_lR0fcfLw$gA-AoPtgVGRvQIHwygwwoVxicey2dQDzAy60QDBOF0d4pqUMmWtNzqT_QSrkSoEMd9IkZ68hWm0mJ6JTfjckcQ";

function adminLoginUrl(error: string, returnTo: string): URL {
  const url = new URL("/admin-login", appOrigin());
  url.searchParams.set("error", error);
  url.searchParams.set("returnTo", returnTo);
  return url;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  let identifier = "";
  let returnTo = "/admin";
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    identifier = normalizeIdentifier(String(form.get("identifier") ?? ""));
    const password = String(form.get("password") ?? "");
    returnTo = safeAdminReturnTo(form.get("returnTo"));

    if (!identifier || !password) {
      return NextResponse.redirect(
        adminLoginUrl(
          "Enter your admin email or phone and password.",
          returnTo,
        ),
        303,
      );
    }

    const ip = clientIp(request);
    const throttleKey = `admin-login:${identifier}:${ip ?? "unknown"}`;
    const throttle = await getLoginThrottle(throttleKey);
    if (throttle.locked) {
      return NextResponse.redirect(
        adminLoginUrl(
          `Too many attempts. Try again in ${Math.ceil(throttle.retryAfterSeconds / 60)} minute(s).`,
          returnTo,
        ),
        303,
      );
    }

    const user = await db.user.findFirst({
      where: identifier.includes("@")
        ? { email: identifier }
        : { phone: identifier },
      include: {
        roles: {
          where: { role: { status: "ACTIVE" } },
          include: { role: true },
        },
      },
    });
    const passwordValid = await verifyPassword(
      password,
      user?.passwordHash ?? DUMMY_PASSWORD_HASH,
    );
    const hasAdminRole = Boolean(
      user?.roles.some(({ role }) => role.isAdminRole),
    );

    if (user?.isSuperAdmin && passwordValid) {
      return NextResponse.redirect(
        new URL(
          "/super-admin?error=Use+the+dedicated+Super+Admin+sign-in.",
          appOrigin(),
        ),
        303,
      );
    }

    if (!user || !passwordValid || !hasAdminRole) {
      const result = await recordLoginFailure(throttleKey);
      if (result.locked) {
        await writeAuditLog({
          action: "ACCOUNT_LOCKED",
          targetType: "AdminLoginIdentifier",
          metadata: { identifierHashOnly: true },
          ipAddress: ip,
          userAgent: userAgent(request),
        });
      }

      return NextResponse.redirect(
        adminLoginUrl(
          "Admin credentials are incorrect or this account does not have admin access.",
          returnTo,
        ),
        303,
      );
    }

    if (user.status !== "ACTIVE") {
      return NextResponse.redirect(
        adminLoginUrl(
          "This admin account is not active. Contact the Super Admin.",
          returnTo,
        ),
        303,
      );
    }

    await clearLoginThrottle(throttleKey);
    const agent = userAgent(request);
    const session = await createSession({
      userId: user.id,
      sessionVersion: user.sessionVersion,
      ipAddress: ip,
      userAgent: agent,
      deviceLabel: deviceLabelFromUserAgent(agent),
    });

    await db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });
    await writeAuditLog({
      actorId: user.id,
      action: "LOGIN",
      targetType: "Session",
      targetId: session.sessionId,
      ipAddress: ip,
      userAgent: agent,
      metadata: { surface: "ADMIN" },
    });

    const verified = Boolean(user.emailVerifiedAt || user.phoneVerifiedAt);
    const destination =
      authConfig.requireVerifiedContact && !verified
        ? `/verify?returnTo=${encodeURIComponent(returnTo)}`
        : returnTo;
    const response = NextResponse.redirect(
      new URL(destination, appOrigin()),
      303,
    );
    setSessionCookie(response, session.rawToken, session.expiresAt);
    return response;
  } catch (error) {
    console.error("Admin login failed", error);
    return NextResponse.redirect(
      adminLoginUrl(
        "Admin sign in could not be completed. Please try again.",
        returnTo,
      ),
      303,
    );
  }
}
