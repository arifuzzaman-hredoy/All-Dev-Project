import { Prisma } from "@/generated/prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import {
  LaunchAcceptanceError,
  launchAcceptanceKey,
  launchAcceptanceNote,
  launchAcceptanceStatus,
  parseLaunchAcceptance,
  withLaunchAcceptanceUpdate,
} from "@/lib/launch/validation";

function redirectWithMessage(
  request: NextRequest,
  kind: "success" | "error",
  message: string,
): NextResponse {
  const url = new URL("/admin/launch-readiness", request.url);
  url.searchParams.set(kind, message);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin) {
      return redirectWithMessage(
        request,
        "error",
        "Primary Super Admin access is required to change launch acceptance.",
      );
    }

    const form = await readForm(request);
    const key = launchAcceptanceKey(form.get("gate"));
    const status = launchAcceptanceStatus(form.get("status"));
    const note = launchAcceptanceNote(form.get("note"));

    const currentSetting = await db.systemSetting.findUnique({
      where: { key: "launch.acceptance" },
      select: { value: true },
    });
    const current = parseLaunchAcceptance(currentSetting?.value);
    const updatedAt = new Date().toISOString();
    const value = withLaunchAcceptanceUpdate(current, {
      key,
      status,
      updatedAt,
      updatedBy: session.user.name,
      note,
    });

    await db.systemSetting.upsert({
      where: { key: "launch.acceptance" },
      update: { value: value as unknown as Prisma.InputJsonValue },
      create: {
        key: "launch.acceptance",
        value: value as unknown as Prisma.InputJsonValue,
      },
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "SYSTEM",
      targetType: "LaunchAcceptance",
      targetId: key,
      metadata: {
        gate: key,
        status,
        noteProvided: Boolean(note),
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return redirectWithMessage(
      request,
      "success",
      status === "PASSED"
        ? "Launch acceptance gate recorded."
        : "Launch acceptance gate returned to pending.",
    );
  } catch (error) {
    console.error("Launch acceptance update failed", error);
    const message =
      error instanceof LaunchAcceptanceError
        ? error.message
        : "Launch acceptance could not be updated.";
    return redirectWithMessage(request, "error", message);
  }
}
