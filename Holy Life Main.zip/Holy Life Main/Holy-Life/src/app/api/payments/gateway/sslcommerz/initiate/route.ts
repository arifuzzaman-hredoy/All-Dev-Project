import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession, hasVerifiedContact } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import {
  createPaymentGatewayAttempt,
  PaymentGatewayError,
} from "@/lib/payments/gateway/service";
import {
  GatewayValidationError,
  gatewayAmount,
  optionalGatewayText,
  requiredGatewayText,
} from "@/lib/payments/gateway/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return financeRedirect(
        request,
        "/login",
        "error",
        "Sign in before starting an online payment.",
      );
    if (!hasVerifiedContact(session.user)) {
      return financeRedirect(
        request,
        "/verify",
        "error",
        "Verify your contact before starting an online payment.",
      );
    }

    const form = await readForm(request);
    const attempt = await createPaymentGatewayAttempt({
      accountId: requiredGatewayText(
        form.get("accountId"),
        "Payment account",
        80,
      ),
      userId: session.user.id,
      amount: gatewayAmount(form.get("amount")),
      idempotencyKey: requiredGatewayText(
        form.get("requestKey"),
        "Payment request key",
        200,
      ),
      billing: {
        addressLine1: requiredGatewayText(
          form.get("addressLine1"),
          "Billing address",
          120,
        ),
        city: requiredGatewayText(form.get("city"), "Billing city", 80),
        district: optionalGatewayText(form.get("district"), 80),
        postalCode: optionalGatewayText(form.get("postalCode"), 30),
      },
    });

    if (!attempt.gatewayUrl)
      throw new PaymentGatewayError(
        "Payment gateway did not return a redirect URL.",
      );
    return NextResponse.redirect(attempt.gatewayUrl, 303);
  } catch (error) {
    console.error("Online payment initiation failed", error);
    const message =
      error instanceof PaymentGatewayError ||
      error instanceof GatewayValidationError
        ? error.message
        : "Online payment could not be started.";
    return financeRedirect(request, "/dashboard/payments", "error", message);
  }
}
