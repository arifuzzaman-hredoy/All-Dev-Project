import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { validateAndApplySslCommerz } from "@/lib/payments/gateway/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  let code = "";
  try {
    const form = await request.formData();
    const transactionId = String(form.get("tran_id") ?? "").trim();
    const validationId = String(form.get("val_id") ?? "").trim();
    if (
      !transactionId ||
      !validationId ||
      transactionId.length > 64 ||
      validationId.length > 200
    ) {
      throw new Error("Gateway success callback is incomplete.");
    }

    const attempt = await db.paymentGatewayAttempt.findUnique({
      where: { providerTransactionId: transactionId },
      select: { code: true, status: true },
    });
    if (!attempt)
      throw new Error(
        "Gateway success callback references an unknown transaction.",
      );
    code = attempt.code;
    if (attempt.status !== "SUCCEEDED") {
      await validateAndApplySslCommerz({
        providerTransactionId: transactionId,
        validationId,
      });
    }
  } catch (error) {
    console.error("SSLCOMMERZ success callback validation failed", error);
  }

  const url = new URL("/payment/gateway/result", request.url);
  if (code) url.searchParams.set("attempt", code);
  return NextResponse.redirect(url, 303);
}
