import { NextRequest, NextResponse } from "next/server";
import { requireSslCommerzConfig } from "@/lib/payments/gateway/config";
import {
  markGatewayAttemptTerminal,
  validateAndApplySslCommerz,
} from "@/lib/payments/gateway/service";
import { verifySslCommerzIpnSignature } from "@/lib/payments/gateway/signature";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const config = requireSslCommerzConfig();
    const form = await request.formData();
    if (!verifySslCommerzIpnSignature(form, config.storePassword)) {
      return NextResponse.json(
        { success: false, message: "Invalid IPN signature." },
        { status: 401 },
      );
    }

    const transactionId = String(form.get("tran_id") ?? "").trim();
    const status = String(form.get("status") ?? "")
      .trim()
      .toUpperCase();
    if (!transactionId || transactionId.length > 64) {
      return NextResponse.json(
        { success: false, message: "Transaction id is invalid." },
        { status: 400 },
      );
    }

    if (["VALID", "VALIDATED"].includes(status)) {
      const validationId = String(form.get("val_id") ?? "").trim();
      if (!validationId || validationId.length > 200) {
        return NextResponse.json(
          { success: false, message: "Validation id is invalid." },
          { status: 400 },
        );
      }
      const result = await validateAndApplySslCommerz({
        providerTransactionId: transactionId,
        validationId,
      });
      return NextResponse.json({
        success: true,
        status: result.attempt.status,
      });
    }

    if (["FAILED", "EXPIRED", "UNATTEMPTED"].includes(status)) {
      await markGatewayAttemptTerminal({
        providerTransactionId: transactionId,
        status: "FAILED",
        reason: `SSLCOMMERZ status: ${status}`,
      });
    } else if (status === "CANCELLED") {
      await markGatewayAttemptTerminal({
        providerTransactionId: transactionId,
        status: "CANCELLED",
        reason: "Customer cancelled the SSLCOMMERZ payment.",
      });
    }

    return NextResponse.json({ success: true, status });
  } catch (error) {
    console.error("SSLCOMMERZ IPN processing failed", error);
    return NextResponse.json(
      { success: false, message: "IPN could not be processed." },
      { status: 503 },
    );
  }
}
