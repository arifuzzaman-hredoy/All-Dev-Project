import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const form = await request.formData();
  const transactionId = String(form.get("tran_id") ?? "").trim();
  const attempt =
    transactionId && transactionId.length <= 64
      ? await db.paymentGatewayAttempt.findUnique({
          where: { providerTransactionId: transactionId },
          select: { code: true },
        })
      : null;

  // Browser redirects are not trusted payment evidence. Signed IPN or server-side
  // provider validation owns terminal/credited state; this route only returns the user.
  const url = new URL("/payment/gateway/result", request.url);
  if (attempt?.code) url.searchParams.set("attempt", attempt.code);
  url.searchParams.set("return", "cancelled");
  return NextResponse.redirect(url, 303);
}
