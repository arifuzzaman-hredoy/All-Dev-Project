import { NextRequest, NextResponse } from "next/server";
import { messagingConfig } from "@/lib/messaging/config";
import { applyProviderStatus } from "@/lib/messaging/dispatcher";
import { verifyMessagingSignature } from "@/lib/messaging/signature";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const callbackSigningKey = messagingConfig.callbackSecret;
    if (!callbackSigningKey)
      return NextResponse.json(
        { success: false, message: "Messaging callback is disabled." },
        { status: 503 },
      );
    const rawBody = await request.text();
    const timestamp = request.headers.get("x-holy-life-timestamp") ?? "";
    const signature = request.headers.get("x-holy-life-signature") ?? "";
    if (
      !verifyMessagingSignature({
        secret: callbackSigningKey,
        timestamp,
        signature,
        body: rawBody,
      })
    ) {
      return NextResponse.json(
        { success: false, message: "Invalid callback signature." },
        { status: 401 },
      );
    }

    const data = JSON.parse(rawBody) as Record<string, unknown>;
    const deliveryId =
      typeof data.deliveryId === "string" ? data.deliveryId : "";
    const status = typeof data.status === "string" ? data.status : "";
    if (!deliveryId || !["SENT", "DELIVERED", "FAILED"].includes(status)) {
      return NextResponse.json(
        { success: false, message: "Callback payload is invalid." },
        { status: 400 },
      );
    }

    const updated = await applyProviderStatus({
      deliveryId,
      status: status as "SENT" | "DELIVERED" | "FAILED",
      providerMessageId:
        typeof data.providerMessageId === "string"
          ? data.providerMessageId
          : null,
      providerStatus:
        typeof data.providerStatus === "string" ? data.providerStatus : null,
      error: typeof data.error === "string" ? data.error : null,
    });
    return NextResponse.json({
      success: true,
      data: { id: updated.id, status: updated.status },
    });
  } catch (error) {
    console.error("Messaging status callback failed", error);
    return NextResponse.json(
      { success: false, message: "Callback could not be processed." },
      { status: 400 },
    );
  }
}
