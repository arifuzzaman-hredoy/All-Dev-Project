import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  safeReturnTo,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";
import { savedReferenceExists } from "@/lib/dashboard/queries";
import { parseSavedItemType } from "@/lib/dashboard/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const returnTo = safeReturnTo(form.get("returnTo"), "/dashboard/saved");
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(returnTo)}`, request.url),
        303,
      );

    const itemType = parseSavedItemType(form.get("itemType"));
    const referenceId = String(form.get("referenceId") ?? "")
      .trim()
      .slice(0, 120);
    if (!itemType || !referenceId)
      return dashboardRedirect(
        request,
        returnTo,
        "error",
        "Saved item data is invalid.",
      );
    if (!(await savedReferenceExists(itemType, referenceId)))
      return dashboardRedirect(
        request,
        returnTo,
        "error",
        "This item is no longer available.",
      );

    const existing = await db.savedItem.findUnique({
      where: {
        userId_itemType_referenceId: {
          userId: session.user.id,
          itemType,
          referenceId,
        },
      },
    });

    if (existing) {
      await db.savedItem.delete({ where: { id: existing.id } });
      await writeAuditLog({
        actorId: session.user.id,
        action: "DELETE",
        department: "SYSTEM",
        targetType: "SavedItem",
        targetId: existing.id,
        metadata: { itemType, referenceId },
        ipAddress: clientIp(request),
        userAgent: userAgent(request),
      });
      return dashboardRedirect(
        request,
        returnTo,
        "success",
        "Removed from saved items.",
      );
    }

    const saved = await db.savedItem.create({
      data: { userId: session.user.id, itemType, referenceId },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: "SavedItem",
      targetId: saved.id,
      metadata: { itemType, referenceId },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return dashboardRedirect(request, returnTo, "success", "Saved for later.");
  } catch (error) {
    console.error("Saved item toggle failed", error);
    return dashboardRedirect(
      request,
      "/dashboard/saved",
      "error",
      "Saved item could not be updated.",
    );
  }
}
