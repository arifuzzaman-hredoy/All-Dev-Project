import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { dateInputToUtc } from "@/lib/appointments/time";
import { generatePatientCode } from "@/lib/appointments/code";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";
import {
  readDashboardProfile,
  validateDashboardProfile,
} from "@/lib/dashboard/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/dashboard/profile";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );

    const form = await readForm(request);
    const input = readDashboardProfile(form);
    const validationError = validateDashboardProfile(input);
    if (validationError)
      return dashboardRedirect(request, path, "error", validationError);

    const conflict = await db.patientProfile.findFirst({
      where: { phone: input.patientPhone, NOT: { userId: session.user.id } },
      select: { id: true },
    });
    if (conflict)
      return dashboardRedirect(
        request,
        path,
        "error",
        "This patient phone is already linked to another profile.",
      );

    const existingPatient = await db.patientProfile.findUnique({
      where: { userId: session.user.id },
      select: { id: true },
    });

    await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: session.user.id },
        data: { name: input.name },
      });

      const patientData = {
        name: input.name,
        phone: input.patientPhone,
        email: session.user.email,
        gender: input.gender,
        dateOfBirth: input.dateOfBirth
          ? dateInputToUtc(input.dateOfBirth)
          : null,
        bloodGroup: input.bloodGroup,
        address: input.address,
        emergencyContactName: input.emergencyContactName,
        emergencyContactPhone: input.emergencyContactPhone,
        allergies: input.allergies,
        status: "ACTIVE" as const,
      };

      if (existingPatient) {
        await tx.patientProfile.update({
          where: { id: existingPatient.id },
          data: patientData,
        });
      } else {
        await tx.patientProfile.create({
          data: {
            ...patientData,
            userId: session.user.id,
            patientCode: generatePatientCode(),
          },
        });
      }
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "SYSTEM",
      targetType: "UserProfile",
      targetId: session.user.id,
      metadata: { healthProfile: true },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return dashboardRedirect(
      request,
      path,
      "success",
      "Profile details saved.",
    );
  } catch (error) {
    console.error("Dashboard profile update failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Profile details could not be saved.",
    );
  }
}
