import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { dashboardRedirect } from "@/lib/dashboard/api";
import { saveMessagingPreference } from "@/lib/messaging/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/dashboard/notifications";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );
    const form = await readForm(request);
    await saveMessagingPreference({
      userId: session.user.id,
      emailEnabled: form.get("emailEnabled") === "on",
      smsEnabled: form.get("smsEnabled") === "on",
      whatsappEnabled: form.get("whatsappEnabled") === "on",
      marketingEnabled: form.get("marketingEnabled") === "on",
    });
    return dashboardRedirect(
      request,
      path,
      "success",
      "Messaging preferences updated.",
    );
  } catch (error) {
    console.error("Messaging preference update failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Messaging preferences could not be updated.",
    );
  }
}
