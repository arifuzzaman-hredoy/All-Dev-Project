import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/dashboard/notifications";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );
    const now = new Date();
    await db.dashboardNotification.updateMany({
      where: { userId: session.user.id, isRead: false },
      data: { isRead: true, readAt: now },
    });
    return dashboardRedirect(
      request,
      path,
      "success",
      "All notifications marked as read.",
    );
  } catch (error) {
    console.error("Notification mark-all failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Notifications could not be updated.",
    );
  }
}
