import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm, safeReturnTo } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ notificationId: string }> },
): Promise<NextResponse> {
  const fallback = "/dashboard/notifications";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(fallback)}`, request.url),
        303,
      );
    const form = await readForm(request);
    const returnTo = safeReturnTo(form.get("returnTo"), fallback);
    const { notificationId } = await params;
    const result = await db.dashboardNotification.updateMany({
      where: { id: notificationId, userId: session.user.id },
      data: { isRead: true, readAt: new Date() },
    });
    if (!result.count)
      return dashboardRedirect(
        request,
        returnTo,
        "error",
        "Notification not found.",
      );
    return dashboardRedirect(
      request,
      returnTo,
      "success",
      "Notification marked as read.",
    );
  } catch (error) {
    console.error("Notification read update failed", error);
    return dashboardRedirect(
      request,
      fallback,
      "error",
      "Notification could not be updated.",
    );
  }
}
