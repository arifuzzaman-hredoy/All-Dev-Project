import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ addressId: string }> },
): Promise<NextResponse> {
  const path = "/dashboard/profile/addresses";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );
    const { addressId } = await params;
    const address = await db.commerceAddress.findFirst({
      where: { id: addressId, userId: session.user.id },
    });
    if (!address)
      return dashboardRedirect(request, path, "error", "Address not found.");

    await db.$transaction([
      db.commerceAddress.updateMany({
        where: { userId: session.user.id },
        data: { isDefault: false },
      }),
      db.commerceAddress.update({
        where: { id: address.id },
        data: { isDefault: true },
      }),
    ]);

    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "CommerceAddress",
      targetId: address.id,
      metadata: { isDefault: true },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return dashboardRedirect(
      request,
      path,
      "success",
      "Default address updated.",
    );
  } catch (error) {
    console.error("Default address update failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Default address could not be updated.",
    );
  }
}
