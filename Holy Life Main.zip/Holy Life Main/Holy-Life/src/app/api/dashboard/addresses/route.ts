import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";
import {
  readDashboardAddress,
  validateDashboardAddress,
} from "@/lib/dashboard/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/dashboard/profile/addresses";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );

    const form = await readForm(request);
    const input = readDashboardAddress(form);
    const validationError = validateDashboardAddress(input);
    if (validationError)
      return dashboardRedirect(request, path, "error", validationError);

    const existingCount = await db.commerceAddress.count({
      where: { userId: session.user.id },
    });
    if (existingCount >= 10) {
      return dashboardRedirect(
        request,
        path,
        "error",
        "You can save up to 10 addresses.",
      );
    }
    const shouldBeDefault = input.isDefault || existingCount === 0;

    const address = await db.$transaction(async (tx) => {
      if (shouldBeDefault) {
        await tx.commerceAddress.updateMany({
          where: { userId: session.user.id },
          data: { isDefault: false },
        });
      }
      return tx.commerceAddress.create({
        data: {
          userId: session.user.id,
          label: input.label,
          recipientName: input.recipientName,
          phone: input.phone,
          addressLine1: input.addressLine1,
          addressLine2: input.addressLine2,
          area: input.area,
          city: input.city,
          district: input.district,
          postalCode: input.postalCode,
          isDefault: shouldBeDefault,
        },
      });
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "CommerceAddress",
      targetId: address.id,
      metadata: { label: address.label, isDefault: address.isDefault },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return dashboardRedirect(request, path, "success", "Address saved.");
  } catch (error) {
    console.error("Dashboard address create failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Address could not be saved.",
    );
  }
}
