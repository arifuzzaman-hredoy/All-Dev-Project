import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { dashboardRedirect } from "@/lib/dashboard/api";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ addressId: string }> },
): Promise<NextResponse> {
  const path = "/dashboard/profile/addresses";

  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session) {
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(path)}`, request.url),
        303,
      );
    }

    const { addressId } = await params;
    const address = await db.commerceAddress.findFirst({
      where: { id: addressId, userId: session.user.id },
    });
    if (!address) {
      return dashboardRedirect(request, path, "error", "Address not found.");
    }

    await db.$transaction(async (tx) => {
      await tx.commerceAddress.delete({ where: { id: address.id } });

      if (address.isDefault) {
        const replacement = await tx.commerceAddress.findFirst({
          where: { userId: session.user.id },
          orderBy: { updatedAt: "desc" },
        });
        if (replacement) {
          await tx.commerceAddress.update({
            where: { id: replacement.id },
            data: { isDefault: true },
          });
        }
      }
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "DELETE",
      department: "COMMERCE",
      targetType: "CommerceAddress",
      targetId: address.id,
      metadata: { label: address.label },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return dashboardRedirect(request, path, "success", "Address deleted.");
  } catch (error) {
    console.error("Dashboard address delete failed", error);
    return dashboardRedirect(
      request,
      path,
      "error",
      "Address could not be deleted.",
    );
  }
}
