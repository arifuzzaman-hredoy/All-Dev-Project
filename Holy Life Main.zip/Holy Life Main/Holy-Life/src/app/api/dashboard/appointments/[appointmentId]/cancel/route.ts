import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import { formLongText } from "@/lib/appointments/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ appointmentId: string }> },
): Promise<NextResponse> {
  const { appointmentId } = await params;
  const path = `/dashboard/healthcare/appointments/${appointmentId}`;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return appointmentRedirect(
        request,
        "/login",
        "error",
        "Sign in to manage your appointment.",
      );
    const form = await readForm(request);
    const reason = formLongText(form, "reason", 500) || "Cancelled by patient";
    const appointment = await db.appointment.findFirst({
      where: { id: appointmentId, userId: session.user.id },
    });
    if (!appointment)
      return appointmentRedirect(
        request,
        "/dashboard/healthcare/appointments",
        "error",
        "Appointment not found.",
      );
    if (!["PENDING", "CONFIRMED"].includes(appointment.status))
      return appointmentRedirect(
        request,
        path,
        "error",
        "Only pending or confirmed appointments can be cancelled online.",
      );
    await db.appointment.update({
      where: { id: appointment.id },
      data: {
        status: "CANCELLED",
        cancelledAt: new Date(),
        cancellationReason: reason,
        updatedById: session.user.id,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "HEALTHCARE",
      targetType: "Appointment",
      targetId: appointment.id,
      metadata: {
        from: appointment.status,
        to: "CANCELLED",
        reason,
        source: "PATIENT_DASHBOARD",
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return appointmentRedirect(
      request,
      path,
      "success",
      "Appointment cancelled. Holy Life staff can still view the preserved history.",
    );
  } catch (error) {
    console.error("Patient appointment cancellation failed", error);
    return appointmentRedirect(
      request,
      path,
      "error",
      "Appointment could not be cancelled.",
    );
  }
}
