import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import {
  optionalText,
  positiveInteger,
  requiredText,
} from "@/lib/commerce/validation";
import { db } from "@/lib/db";
export async function POST(request: NextRequest): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (!session)
    return NextResponse.redirect(
      new URL("/login?returnTo=/dashboard/shopping/orders", request.url),
      303,
    );
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const orderId = requiredText(form, "orderId", 100);
    const productId = requiredText(form, "productId", 100);
    const order = await db.commerceOrder.findFirst({
      where: {
        id: orderId,
        userId: session.user.id,
        status: "DELIVERED",
        items: { some: { productId } },
      },
    });
    if (!order)
      return commerceRedirect(
        request,
        "/dashboard/shopping/orders",
        "error",
        "Only delivered products can be reviewed.",
      );
    const review = await db.productReview.upsert({
      where: {
        productId_orderId_userId: {
          productId,
          orderId,
          userId: session.user.id,
        },
      },
      update: {
        rating: positiveInteger(form, "rating", 5, 5),
        title: optionalText(form, "title", 120),
        body: optionalText(form, "body", 1000),
        status: "PENDING",
      },
      create: {
        productId,
        orderId,
        userId: session.user.id,
        rating: positiveInteger(form, "rating", 5, 5),
        title: optionalText(form, "title", 120),
        body: optionalText(form, "body", 1000),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "ProductReview",
      targetId: review.id,
      metadata: { productId, orderId, rating: review.rating },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
      "success",
      "Review submitted for moderation.",
    );
  } catch (error) {
    console.error("Review failed", error);
    return commerceRedirect(
      request,
      "/dashboard/shopping/orders",
      "error",
      "Review could not be submitted.",
    );
  }
}
