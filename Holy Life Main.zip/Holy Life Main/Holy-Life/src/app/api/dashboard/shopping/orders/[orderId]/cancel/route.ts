import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { CommerceError, transitionOrderStatus } from "@/lib/commerce/service";
import { optionalText } from "@/lib/commerce/validation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> },
): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (!session)
    return NextResponse.redirect(
      new URL("/login?returnTo=/dashboard/shopping/orders", request.url),
      303,
    );
  try {
    assertSameOrigin(request);
    const { orderId } = await params;
    const form = await readForm(request);
    const reason = optionalText(form, "reason", 500);
    const result = await transitionOrderStatus({
      orderId,
      nextStatus: "CANCELLED",
      actorId: session.user.id,
      note: reason || "Cancelled by customer.",
      customerUserId: session.user.id,
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      department: "COMMERCE",
      targetType: "CommerceOrder",
      targetId: result.order.id,
      metadata: { from: result.previousStatus, to: "CANCELLED" },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      "/dashboard/shopping/orders",
      "success",
      `Order ${result.order.code} cancelled.`,
    );
  } catch (error) {
    console.error("Order cancellation failed", error);
    return commerceRedirect(
      request,
      "/dashboard/shopping/orders",
      "error",
      error instanceof CommerceError
        ? error.message
        : "Order could not be cancelled.",
    );
  }
}
