import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { requiredText } from "@/lib/commerce/validation";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> },
): Promise<NextResponse> {
  const session = await getCurrentSession();
  if (!session)
    return NextResponse.redirect(
      new URL("/login?returnTo=/dashboard/shopping/orders", request.url),
      303,
    );
  try {
    assertSameOrigin(request);
    const { orderId } = await params;
    const form = await readForm(request);
    const order = await db.commerceOrder.findFirst({
      where: {
        id: orderId,
        userId: session.user.id,
        status: "DELIVERED",
        paymentStatus: "PAID",
      },
      include: {
        refundRequests: {
          where: { status: { in: ["REQUESTED", "APPROVED", "COMPLETED"] } },
        },
      },
    });
    if (!order) {
      return commerceRedirect(
        request,
        "/dashboard/shopping/orders",
        "error",
        "A fully paid delivered order was not found.",
      );
    }
    if (order.refundRequests.length) {
      return commerceRedirect(
        request,
        `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
        "error",
        "A refund request already exists for this order.",
      );
    }
    const refund = await db.refundRequest.create({
      data: {
        orderId: order.id,
        userId: session.user.id,
        amount: order.grandTotal,
        reason: requiredText(form, "reason", 1000),
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "RefundRequest",
      targetId: refund.id,
      metadata: { orderId: order.id, amount: refund.amount.toString() },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
      "success",
      "Full refund request submitted.",
    );
  } catch (error) {
    console.error("Refund request failed", error);
    return commerceRedirect(
      request,
      "/dashboard/shopping/orders",
      "error",
      "Refund request could not be submitted.",
    );
  }
}
