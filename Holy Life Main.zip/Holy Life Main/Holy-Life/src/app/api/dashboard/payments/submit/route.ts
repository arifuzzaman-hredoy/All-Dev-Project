import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { financeRedirect } from "@/lib/finance/api";
import { submitManualPayment } from "@/lib/finance/service";
import {
  manualPaymentMethod,
  optionalFinanceText,
  positiveMoney,
  requiredFinanceText,
} from "@/lib/finance/validation";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const path = "/dashboard/payments";
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL("/login?returnTo=/dashboard/payments", request.url),
        303,
      );

    const form = await readForm(request);
    const accountId = requiredFinanceText(
      form.get("accountId"),
      120,
      "Payment account",
    );
    const amount = positiveMoney(form.get("amount"), "Payment amount");
    const method = manualPaymentMethod(form.get("method"));
    const transactionReference = optionalFinanceText(
      form.get("transactionReference"),
      160,
    );
    const note = optionalFinanceText(form.get("note"), 500);
    if (method !== "CASH" && !transactionReference) {
      return financeRedirect(
        request,
        path,
        "error",
        "A transaction/reference number is required for non-cash payments.",
      );
    }

    const transaction = await submitManualPayment({
      accountId,
      userId: session.user.id,
      amount,
      method,
      transactionReference,
      note,
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "SYSTEM",
      targetType: "PaymentTransaction",
      targetId: transaction.id,
      metadata: {
        code: transaction.code,
        accountId,
        amount,
        method,
        status: transaction.status,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    return financeRedirect(
      request,
      path,
      "success",
      "Payment reference submitted for manual verification.",
    );
  } catch (error) {
    console.error("Manual payment submission failed", error);
    return financeRedirect(
      request,
      path,
      "error",
      error instanceof Error ? error.message : "Payment submission failed.",
    );
  }
}
