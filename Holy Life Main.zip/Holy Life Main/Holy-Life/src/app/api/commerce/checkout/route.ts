import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasVerifiedContact } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { checkout, CommerceError } from "@/lib/commerce/service";
import { optionalText, requiredText } from "@/lib/commerce/validation";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import {
  ensurePaymentAccount,
  submitManualPayment,
} from "@/lib/finance/service";
import { manualPaymentMethod } from "@/lib/finance/validation";
import { paymentGatewayAvailable } from "@/lib/payments/gateway/config";
import {
  createPaymentGatewayAttempt,
  PaymentGatewayError,
} from "@/lib/payments/gateway/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL("/login?returnTo=/checkout", request.url),
        303,
      );
    if (!hasVerifiedContact(session.user))
      return commerceRedirect(
        request,
        "/verify",
        "error",
        "Verify your contact before checkout.",
      );

    const form = await readForm(request);
    const paymentMethod = requiredText(form, "paymentMethod", 40);
    if (
      !["CASH_ON_DELIVERY", "MANUAL_PAYMENT", "ONLINE_GATEWAY"].includes(
        paymentMethod,
      )
    ) {
      return commerceRedirect(
        request,
        "/checkout",
        "error",
        "Payment method is invalid.",
      );
    }

    const manualPaymentReference = optionalText(
      form,
      "manualPaymentReference",
      120,
    );
    const manualMethod =
      paymentMethod === "MANUAL_PAYMENT"
        ? manualPaymentMethod(form.get("manualPaymentMethod"))
        : null;
    if (paymentMethod === "MANUAL_PAYMENT" && !manualPaymentReference) {
      return commerceRedirect(
        request,
        "/checkout",
        "error",
        "Manual payment reference is required.",
      );
    }

    if (paymentMethod === "ONLINE_GATEWAY") {
      if (!paymentGatewayAvailable()) {
        return commerceRedirect(
          request,
          "/checkout",
          "error",
          "Online payment gateway is currently unavailable.",
        );
      }
      if (
        !session.user.email ||
        !session.user.emailVerifiedAt ||
        !session.user.phone ||
        !session.user.phoneVerifiedAt
      ) {
        return commerceRedirect(
          request,
          "/verify",
          "error",
          "Online payment requires both a verified email address and a verified phone number.",
        );
      }
    }

    const order = await checkout({
      userId: session.user.id,
      checkoutKey: requiredText(form, "checkoutKey", 200),
      customerName: requiredText(form, "customerName", 120),
      customerPhone: requiredText(form, "customerPhone", 30),
      customerEmail: optionalText(form, "customerEmail", 190),
      addressLine1: requiredText(form, "addressLine1", 250),
      addressLine2: optionalText(form, "addressLine2", 250),
      area: optionalText(form, "area", 100),
      city: requiredText(form, "city", 100),
      district: optionalText(form, "district", 100),
      postalCode: optionalText(form, "postalCode", 20),
      shippingMethodId: requiredText(form, "shippingMethodId", 100),
      couponCode: optionalText(form, "couponCode", 50),
      paymentMethod: paymentMethod as
        "CASH_ON_DELIVERY" | "MANUAL_PAYMENT" | "ONLINE_GATEWAY",
      manualPaymentReference,
      customerNote: optionalText(form, "customerNote", 1000),
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "CommerceOrder",
      targetId: order.id,
      metadata: {
        code: order.code,
        grandTotal: order.grandTotal.toString(),
        paymentMethod: order.paymentMethod,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    await createDashboardNotification({
      userId: session.user.id,
      dedupeKey: `order:${order.id}:created`,
      kind: "ACTION",
      department: "COMMERCE",
      title: "Order submitted",
      message: `${order.code} · ${order.currency} ${order.grandTotal.toString()}`,
      href: `/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`,
    });

    let paymentAccount: Awaited<
      ReturnType<typeof ensurePaymentAccount>
    > | null = null;
    try {
      paymentAccount = await ensurePaymentAccount({
        userId: session.user.id,
        domain: "COMMERCE",
        referenceType: "CommerceOrder",
        referenceId: order.id,
        referenceCode: order.code,
        description: "Holy Life shop order",
        amountDue: order.grandTotal,
        currency: order.currency,
      });

      if (
        paymentMethod === "MANUAL_PAYMENT" &&
        manualMethod &&
        manualPaymentReference
      ) {
        await submitManualPayment({
          accountId: paymentAccount.id,
          userId: session.user.id,
          amount: Number(order.grandTotal),
          method: manualMethod,
          transactionReference: manualPaymentReference,
          note: "Submitted during checkout.",
        });
      }
    } catch (financeError) {
      console.error("Order payment account sync failed", financeError);
    }

    if (paymentMethod === "ONLINE_GATEWAY" && paymentAccount) {
      try {
        const attempt = await createPaymentGatewayAttempt({
          accountId: paymentAccount.id,
          userId: session.user.id,
          amount: Number(order.grandTotal),
          idempotencyKey: `checkout:${order.id}`,
          billing: {
            addressLine1: requiredText(form, "addressLine1", 120),
            city: requiredText(form, "city", 80),
            district: optionalText(form, "district", 80),
            postalCode: optionalText(form, "postalCode", 30),
          },
        });
        if (attempt.gatewayUrl)
          return NextResponse.redirect(attempt.gatewayUrl, 303);
      } catch (gatewayError) {
        console.error("Checkout gateway initiation failed", gatewayError);
        const url = new URL("/dashboard/payments", request.url);
        url.searchParams.set(
          "error",
          gatewayError instanceof PaymentGatewayError
            ? `${gatewayError.message} Your order was still created; retry from Payments.`
            : "Online payment could not be started. Your order was still created; retry from Payments.",
        );
        return NextResponse.redirect(url, 303);
      }
    }

    const url = new URL("/order-success", request.url);
    url.searchParams.set("code", order.code);
    return NextResponse.redirect(url, 303);
  } catch (error) {
    console.error("Commerce checkout failed", error);
    return commerceRedirect(
      request,
      "/checkout",
      "error",
      error instanceof CommerceError
        ? error.message
        : "Checkout failed. Please try again.",
    );
  }
}
