import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { CommerceError, updateCartItem } from "@/lib/commerce/service";
import { nonNegativeInteger, requiredText } from "@/lib/commerce/validation";
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL("/login?returnTo=/cart", request.url),
        303,
      );
    const form = await readForm(request);
    const itemId = requiredText(form, "itemId", 100);
    const quantity = nonNegativeInteger(form, "quantity", 0, 100);
    await updateCartItem(session.user.id, itemId, quantity);
    await writeAuditLog({
      actorId: session.user.id,
      action: "UPDATE",
      department: "COMMERCE",
      targetType: "CommerceCartItem",
      targetId: itemId,
      metadata: { quantity },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      "/cart",
      "success",
      quantity ? "Cart updated." : "Product removed from cart.",
    );
  } catch (error) {
    return commerceRedirect(
      request,
      "/cart",
      "error",
      error instanceof CommerceError
        ? error.message
        : "Cart could not be updated.",
    );
  }
}
