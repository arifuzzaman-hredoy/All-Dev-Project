import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { commerceRedirect } from "@/lib/commerce/api";
import { addCartItem, CommerceError } from "@/lib/commerce/service";
import { positiveInteger, requiredText } from "@/lib/commerce/validation";
export async function POST(request: NextRequest): Promise<NextResponse> {
  let returnPath = "/shop";
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const slug = String(form.get("returnSlug") ?? "").replace(
      /[^a-z0-9-]/gi,
      "",
    );
    returnPath = slug ? `/shop/${slug}` : "/shop";
    const session = await getCurrentSession();
    if (!session) {
      const url = new URL("/login", request.url);
      url.searchParams.set("returnTo", returnPath);
      url.searchParams.set(
        "error",
        "Sign in before adding products to your cart.",
      );
      return NextResponse.redirect(url, 303);
    }
    const variantId = requiredText(form, "variantId", 100);
    const quantity = positiveInteger(form, "quantity", 1, 100);
    const item = await addCartItem(session.user.id, variantId, quantity);
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "COMMERCE",
      targetType: "CommerceCartItem",
      targetId: item.id,
      metadata: { variantId, quantity },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return commerceRedirect(
      request,
      returnPath,
      "success",
      "Product added to cart.",
    );
  } catch (error) {
    const message =
      error instanceof CommerceError
        ? error.message
        : "Product could not be added.";
    return commerceRedirect(request, returnPath, "error", message);
  }
}
