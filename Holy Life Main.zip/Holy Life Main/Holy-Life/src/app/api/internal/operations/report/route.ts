import { timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import type { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";
import { operationsConfig } from "@/lib/operations/config";
import { parseOperationalReport } from "@/lib/operations/validation";

function secretMatches(
  supplied: string | null,
  expected: string | undefined,
): boolean {
  if (!supplied || !expected || !supplied.startsWith("Bearer ")) return false;
  const actual = Buffer.from(supplied.slice("Bearer ".length), "utf8");
  const wanted = Buffer.from(expected, "utf8");
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const contentLength = Number(request.headers.get("content-length") ?? "0");
  if (Number.isFinite(contentLength) && contentLength > 16_384) {
    return NextResponse.json(
      { success: false, message: "Payload too large." },
      { status: 413 },
    );
  }

  if (
    !secretMatches(
      request.headers.get("authorization"),
      operationsConfig.reportSecret,
    )
  ) {
    return NextResponse.json(
      { success: false, message: "Unauthorized." },
      { status: 401 },
    );
  }

  try {
    const input = parseOperationalReport(await request.json());
    const metadata = input.metadata as Prisma.InputJsonValue | undefined;
    const run = await db.operationalRun.upsert({
      where: { runKey: input.runKey },
      create: {
        runKey: input.runKey,
        kind: input.kind,
        status: input.status,
        startedAt: input.startedAt,
        finishedAt: input.finishedAt,
        host: input.host,
        release: input.release,
        snapshotId: input.snapshotId,
        summary: input.summary,
        metadata,
      },
      update: {
        kind: input.kind,
        status: input.status,
        startedAt: input.startedAt,
        finishedAt: input.finishedAt,
        host: input.host,
        release: input.release,
        snapshotId: input.snapshotId,
        summary: input.summary,
        metadata,
      },
    });

    return NextResponse.json({
      success: true,
      data: { id: run.id, status: run.status },
    });
  } catch (error) {
    console.error("Operational report rejected", error);
    return NextResponse.json(
      { success: false, message: "Operational report is invalid." },
      { status: 400 },
    );
  }
}
