import { timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { paymentGatewayConfig } from "@/lib/payments/gateway/config";
import { reconcileGatewayAttempts } from "@/lib/payments/gateway/service";

function secretMatches(
  supplied: string | null,
  expected: string | undefined,
): boolean {
  if (!supplied || !expected || !supplied.startsWith("Bearer ")) return false;
  const actual = Buffer.from(supplied.slice(7), "utf8");
  const wanted = Buffer.from(expected, "utf8");
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  if (
    !secretMatches(
      request.headers.get("authorization"),
      paymentGatewayConfig.reconcileSecret,
    )
  ) {
    return NextResponse.json(
      { success: false, message: "Unauthorized." },
      { status: 401 },
    );
  }
  try {
    const result = await reconcileGatewayAttempts();
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error("Payment gateway reconciliation failed", error);
    return NextResponse.json(
      { success: false, message: "Gateway reconciliation failed." },
      { status: 503 },
    );
  }
}
