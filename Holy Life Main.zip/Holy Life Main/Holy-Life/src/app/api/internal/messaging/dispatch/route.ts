import { timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { messagingConfig } from "@/lib/messaging/config";
import { dispatchMessagingBatch } from "@/lib/messaging/dispatcher";

function secretMatches(
  supplied: string | null,
  expected: string | undefined,
): boolean {
  if (!supplied || !expected) return false;
  const prefix = "Bearer ";
  if (!supplied.startsWith(prefix)) return false;
  const actual = Buffer.from(supplied.slice(prefix.length), "utf8");
  const wanted = Buffer.from(expected, "utf8");
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  if (
    !secretMatches(
      request.headers.get("authorization"),
      messagingConfig.dispatchSecret,
    )
  ) {
    return NextResponse.json(
      { success: false, message: "Unauthorized." },
      { status: 401 },
    );
  }
  try {
    const result = await dispatchMessagingBatch();
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error("Messaging dispatch failed", error);
    return NextResponse.json(
      {
        success: false,
        message:
          error instanceof Error ? error.message : "Messaging dispatch failed.",
      },
      { status: 503 },
    );
  }
}
