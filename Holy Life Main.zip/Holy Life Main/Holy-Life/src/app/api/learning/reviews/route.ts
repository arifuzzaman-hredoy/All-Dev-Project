import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import { integerValue, optionalText } from "@/lib/learning/validation";
export async function POST(request: NextRequest): Promise<NextResponse> {
  const form = await readForm(request);
  const returnTo = String(
    form.get("returnTo") ?? "/dashboard/learning/courses",
  );
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(new URL("/login", request.url), 303);
    const courseId = String(form.get("courseId") ?? "");
    const enrollment = await db.courseEnrollment.findFirst({
      where: { courseId, userId: session.user.id, status: "COMPLETED" },
    });
    if (!enrollment)
      return learningRedirect(
        request,
        returnTo,
        "error",
        "Complete the course before reviewing it.",
      );
    await db.courseReview.upsert({
      where: { courseId_userId: { courseId, userId: session.user.id } },
      update: {
        rating: integerValue(form, "rating", 1, 5, 5),
        title: optionalText(form, "title", 160),
        comment: optionalText(form, "comment", 2000),
        status: "PENDING",
      },
      create: {
        courseId,
        enrollmentId: enrollment.id,
        userId: session.user.id,
        rating: integerValue(form, "rating", 1, 5, 5),
        title: optionalText(form, "title", 160),
        comment: optionalText(form, "comment", 2000),
      },
    });
    return learningRedirect(
      request,
      returnTo,
      "success",
      "Review submitted for moderation.",
    );
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      returnTo,
      "error",
      "Review could not be submitted.",
    );
  }
}
