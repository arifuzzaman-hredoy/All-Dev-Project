import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { learningRedirect } from "@/lib/learning/api";
import { scoreQuiz } from "@/lib/learning/quiz";
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ quizId: string }> },
): Promise<NextResponse> {
  const { quizId } = await params;
  const form = await readForm(request);
  const returnTo = String(
    form.get("returnTo") ?? "/dashboard/learning/courses",
  );
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(returnTo)}`, request.url),
        303,
      );
    const quiz = await db.quiz.findFirst({
      where: { id: quizId, status: "PUBLISHED" },
      include: {
        questions: { include: { options: true }, orderBy: { position: "asc" } },
      },
    });
    if (!quiz || quiz.questions.length === 0)
      return learningRedirect(
        request,
        returnTo,
        "error",
        "Quiz is unavailable.",
      );
    const enrollment = await db.courseEnrollment.findFirst({
      where: {
        courseId: quiz.courseId,
        userId: session.user.id,
        status: { in: ["ACTIVE", "COMPLETED"] },
      },
    });
    if (!enrollment)
      return learningRedirect(
        request,
        returnTo,
        "error",
        "Active enrollment is required.",
      );
    const previousAttempts = await db.quizAttempt.count({
      where: { quizId, enrollmentId: enrollment.id },
    });
    if (previousAttempts >= quiz.maxAttempts)
      return learningRedirect(
        request,
        returnTo,
        "error",
        "Maximum attempts reached.",
      );
    const answers = quiz.questions.map((question) => {
      const selectedOptionId =
        String(form.get(`question:${question.id}`) ?? "") || null;
      const correct = question.options.find((option) => option.isCorrect);
      if (!correct) throw new Error("Quiz question has no correct option.");
      return { question, selectedOptionId, correctOptionId: correct.id };
    });
    const result = scoreQuiz(
      answers.map((item) => ({
        points: item.question.points,
        selectedOptionId: item.selectedOptionId,
        correctOptionId: item.correctOptionId,
      })),
    );
    const passed = result.score >= quiz.passingScore;
    await db.quizAttempt.create({
      data: {
        quizId,
        enrollmentId: enrollment.id,
        userId: session.user.id,
        attemptNumber: previousAttempts + 1,
        status: passed ? "PASSED" : "FAILED",
        score: result.score,
        earnedPoints: result.earnedPoints,
        totalPoints: result.totalPoints,
        submittedAt: new Date(),
        answers: {
          create: answers.map((item) => ({
            questionId: item.question.id,
            selectedOptionId: item.selectedOptionId,
            isCorrect: item.selectedOptionId === item.correctOptionId,
            pointsAwarded:
              item.selectedOptionId === item.correctOptionId
                ? item.question.points
                : 0,
          })),
        },
      },
    });
    return learningRedirect(
      request,
      returnTo,
      passed ? "success" : "error",
      passed
        ? `Passed with ${result.score}%.`
        : `Score ${result.score}%. Try again.`,
    );
  } catch (error) {
    console.error(error);
    return learningRedirect(
      request,
      returnTo,
      "error",
      "Quiz could not be submitted.",
    );
  }
}
