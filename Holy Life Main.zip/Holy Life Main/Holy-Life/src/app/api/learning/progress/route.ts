import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { learningRedirect } from "@/lib/learning/api";
import { LearningError, updateLessonProgress } from "@/lib/learning/service";
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session)
      return NextResponse.redirect(new URL("/login", request.url), 303);
    const form = await readForm(request);
    const returnTo = String(
      form.get("returnTo") ?? "/dashboard/learning/courses",
    );
    await updateLessonProgress({
      userId: session.user.id,
      enrollmentId: String(form.get("enrollmentId") ?? ""),
      lessonId: String(form.get("lessonId") ?? ""),
      completed: String(form.get("completed")) === "true",
      progressPercent: Number(form.get("progressPercent") ?? 100),
    });
    return learningRedirect(
      request,
      returnTo,
      "success",
      "Lesson progress saved.",
    );
  } catch (error) {
    return learningRedirect(
      request,
      "/dashboard/learning/courses",
      "error",
      error instanceof LearningError
        ? error.message
        : "Progress could not be saved.",
    );
  }
}
