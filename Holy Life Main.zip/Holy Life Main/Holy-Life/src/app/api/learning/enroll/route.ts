import { NextRequest, NextResponse } from "next/server";
import { assertSameOrigin, readForm, safeReturnTo } from "@/lib/auth/request";
import { getCurrentSession, hasVerifiedContact } from "@/lib/auth/session";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import { learningRedirect } from "@/lib/learning/api";
import { enrollStudent, LearningError } from "@/lib/learning/service";
import { reconcilePaymentAccountForReference } from "@/lib/finance/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const returnTo = safeReturnTo(form.get("returnTo"), "/courses");
    const session = await getCurrentSession();

    if (!session) {
      return NextResponse.redirect(
        new URL(`/login?returnTo=${encodeURIComponent(returnTo)}`, request.url),
        303,
      );
    }

    if (!hasVerifiedContact(session.user)) {
      const verificationUrl = new URL("/verify", request.url);
      verificationUrl.searchParams.set("returnTo", returnTo);
      return NextResponse.redirect(verificationUrl, 303);
    }

    const enrollment = await enrollStudent({
      courseId: String(form.get("courseId") ?? ""),
      userId: session.user.id,
    });

    await createDashboardNotification({
      userId: session.user.id,
      dedupeKey: `course:${enrollment.courseId}:enrollment:${enrollment.id}`,
      kind: "SUCCESS",
      department: "LEARNING",
      title: "Course enrollment is active",
      message: "Continue learning from your dashboard.",
      href: "/dashboard/learning/courses",
    });

    try {
      await reconcilePaymentAccountForReference({
        domain: "LEARNING",
        referenceType: "CourseEnrollment",
        referenceId: enrollment.id,
      });
    } catch (financeError) {
      console.error("Course payment account sync failed", financeError);
    }

    return learningRedirect(
      request,
      returnTo,
      "success",
      "Enrollment is active.",
    );
  } catch (error) {
    return learningRedirect(
      request,
      "/courses",
      "error",
      error instanceof LearningError ? error.message : "Enrollment failed.",
    );
  }
}
