import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  clientIp,
  assertSameOrigin,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession, hasVerifiedContact } from "@/lib/auth/session";
import { appointmentRedirect } from "@/lib/appointments/api";
import {
  AppointmentBookingError,
  createAppointment,
} from "@/lib/appointments/service";
import { createDashboardNotification } from "@/lib/dashboard/notifications";
import {
  readAppointmentForm,
  validateAppointmentForm,
} from "@/lib/appointments/validation";
import { ensurePaymentAccount } from "@/lib/finance/service";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("returnTo", "/appointment");
      loginUrl.searchParams.set(
        "error",
        "Sign in before booking an appointment.",
      );
      return NextResponse.redirect(loginUrl, 303);
    }
    if (!hasVerifiedContact(session.user)) {
      return appointmentRedirect(
        request,
        "/verify",
        "error",
        "Verify your email or phone before booking.",
      );
    }

    const form = await readForm(request);
    const input = readAppointmentForm(form);
    const validationError = validateAppointmentForm(input);
    if (validationError) {
      return appointmentRedirect(
        request,
        "/appointment",
        "error",
        validationError,
        {
          doctorId: input.doctorId,
          date: input.date,
        },
      );
    }

    const appointment = await createAppointment({
      ...input,
      userId: session.user.id,
      actorId: session.user.id,
      source: "PUBLIC",
      initialStatus: "PENDING",
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      department: "HEALTHCARE",
      targetType: "Appointment",
      targetId: appointment.id,
      metadata: {
        code: appointment.code,
        doctorId: appointment.doctorId,
        appointmentDate: appointment.appointmentDate.toISOString().slice(0, 10),
        startTime: appointment.startTime,
        source: appointment.source,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    await createDashboardNotification({
      userId: session.user.id,
      dedupeKey: `appointment:${appointment.id}:created`,
      kind: "ACTION",
      department: "HEALTHCARE",
      title: "Appointment request submitted",
      message: `${appointment.doctor.name} · ${appointment.code}`,
      href: `/dashboard/healthcare/appointments/${appointment.id}`,
    });

    try {
      await ensurePaymentAccount({
        userId: session.user.id,
        domain: "HEALTHCARE",
        referenceType: "Appointment",
        referenceId: appointment.id,
        referenceCode: appointment.code,
        description: `${appointment.doctor.name} consultation`,
        amountDue: appointment.fee,
        currency: "BDT",
      });
    } catch (financeError) {
      console.error("Appointment payment account sync failed", financeError);
    }

    const successUrl = new URL("/appointment/success", request.url);
    successUrl.searchParams.set("code", appointment.code);
    return NextResponse.redirect(successUrl, 303);
  } catch (error) {
    if (error instanceof AppointmentBookingError) {
      return appointmentRedirect(
        request,
        "/appointment",
        "error",
        error.message,
      );
    }
    console.error("Public appointment booking failed", error);
    return appointmentRedirect(
      request,
      "/appointment",
      "error",
      "Appointment booking failed. Please try again.",
    );
  }
}
