import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

function redirectResult(
  request: NextRequest,
  key: "error" | "success",
  value: string,
): NextResponse {
  const url = new URL("/super-admin/security", request.url);
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> },
): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin) {
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    }

    const { userId } = await context.params;
    const form = await readForm(request);
    const status = String(form.get("status") ?? "");
    if (status !== "ACTIVE" && status !== "SUSPENDED") {
      return redirectResult(request, "error", "Invalid account status.");
    }
    if (userId === session.user.id) {
      return redirectResult(
        request,
        "error",
        "You cannot suspend your own owner account.",
      );
    }

    const target = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, status: true, isSuperAdmin: true },
    });
    if (!target)
      return redirectResult(request, "error", "Account was not found.");
    if (target.isSuperAdmin) {
      return redirectResult(
        request,
        "error",
        "Owner accounts cannot be changed from this screen.",
      );
    }

    const now = new Date();
    await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: target.id },
        data: {
          status,
          ...(status === "SUSPENDED"
            ? { sessionVersion: { increment: 1 } }
            : {}),
        },
      });
      if (status === "SUSPENDED") {
        await tx.session.updateMany({
          where: { userId: target.id, revokedAt: null },
          data: { revokedAt: now },
        });
      }
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "STATUS_CHANGE",
      targetType: "User",
      targetId: target.id,
      metadata: { previousStatus: target.status, newStatus: status },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      "success",
      status === "ACTIVE"
        ? "Account activated."
        : "Account suspended and sessions revoked.",
    );
  } catch (error) {
    console.error("Account status update failed", error);
    return redirectResult(
      request,
      "error",
      "Account status could not be updated.",
    );
  }
}
