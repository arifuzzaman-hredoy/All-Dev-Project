import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

function redirectResult(
  request: NextRequest,
  key: "error" | "success",
  value: string,
): NextResponse {
  const url = new URL("/super-admin/security", request.url);
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> },
): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin) {
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    }

    const { userId } = await context.params;
    if (userId === session.user.id) {
      return redirectResult(
        request,
        "error",
        "Use your own security page to revoke the current owner session.",
      );
    }
    const target = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, isSuperAdmin: true },
    });
    if (!target)
      return redirectResult(request, "error", "Account was not found.");
    if (target.isSuperAdmin) {
      return redirectResult(
        request,
        "error",
        "Owner sessions cannot be revoked from this screen.",
      );
    }

    const now = new Date();
    const result = await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: target.id },
        data: { sessionVersion: { increment: 1 } },
      });
      return tx.session.updateMany({
        where: { userId: target.id, revokedAt: null },
        data: { revokedAt: now },
      });
    });

    await writeAuditLog({
      actorId: session.user.id,
      action: "SESSION_REVOKE",
      targetType: "UserSessions",
      targetId: target.id,
      metadata: { revokedCount: result.count },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      "success",
      `${result.count} active session(s) revoked.`,
    );
  } catch (error) {
    console.error("Force logout failed", error);
    return redirectResult(request, "error", "Sessions could not be revoked.");
  }
}
