import { createHash, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { appOrigin } from "@/lib/auth/config";
import { normalizeEmail } from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  deviceLabelFromUserAgent,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { createSession, setSessionCookie } from "@/lib/auth/session";
import {
  clearLoginThrottle,
  getLoginThrottle,
  recordLoginFailure,
} from "@/lib/auth/throttle";
import { db } from "@/lib/db";

function configuredOwnerEmail(): string {
  const value = process.env.INITIAL_SUPER_ADMIN_EMAIL;
  return value ? normalizeEmail(value) : "";
}

function configuredOwnerPassword(): string {
  return process.env.INITIAL_SUPER_ADMIN_PASSWORD ?? "";
}

function constantTimeEqual(left: string, right: string): boolean {
  const leftHash = createHash("sha256").update(left, "utf8").digest();
  const rightHash = createHash("sha256").update(right, "utf8").digest();
  return timingSafeEqual(leftHash, rightHash);
}

function safeSuperAdminReturnTo(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") return "/super-admin";
  const trimmed = value.trim();
  if (!trimmed.startsWith("/super-admin") || trimmed.startsWith("//"))
    return "/super-admin";
  return trimmed;
}

function redirectToLogin(
  request: NextRequest,
  error: string,
  returnTo: string,
): NextResponse {
  const url = new URL("/super-admin", appOrigin());
  url.searchParams.set("error", error);
  if (returnTo !== "/super-admin") url.searchParams.set("returnTo", returnTo);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  let returnTo = "/super-admin";
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const email = normalizeEmail(String(form.get("email") ?? ""));
    const password = String(form.get("password") ?? "");
    returnTo = safeSuperAdminReturnTo(form.get("returnTo"));

    const expectedEmail = configuredOwnerEmail();
    const expectedPassword = configuredOwnerPassword();
    if (!expectedEmail || !expectedPassword) {
      console.error(
        "Super Admin login is not configured in INITIAL_SUPER_ADMIN_EMAIL/PASSWORD.",
      );
      return redirectToLogin(
        request,
        "Super Admin credentials are not configured on the server.",
        returnTo,
      );
    }

    const ip = clientIp(request);
    const throttleKey = `super-admin-login:${email}:${ip ?? "unknown"}`;
    const throttle = await getLoginThrottle(throttleKey);
    if (throttle.locked) {
      return redirectToLogin(
        request,
        `Too many attempts. Try again in ${Math.ceil(throttle.retryAfterSeconds / 60)} minute(s).`,
        returnTo,
      );
    }

    const credentialsValid =
      constantTimeEqual(email, expectedEmail) &&
      constantTimeEqual(password, expectedPassword);

    if (!credentialsValid) {
      await recordLoginFailure(throttleKey);
      return redirectToLogin(
        request,
        "Super Admin email or password is incorrect.",
        returnTo,
      );
    }

    const owner = await db.user.findFirst({
      where: { isSuperAdmin: true, status: "ACTIVE" },
      select: { id: true, email: true, sessionVersion: true },
    });

    if (!owner || normalizeEmail(owner.email ?? "") !== expectedEmail) {
      console.error(
        "Super Admin database identity is not synchronized with INITIAL_SUPER_ADMIN_EMAIL.",
      );
      return redirectToLogin(
        request,
        "Super Admin account is not synchronized with server configuration.",
        returnTo,
      );
    }

    await clearLoginThrottle(throttleKey);
    const agent = userAgent(request);
    const session = await createSession({
      userId: owner.id,
      sessionVersion: owner.sessionVersion,
      ipAddress: ip,
      userAgent: agent,
      deviceLabel: deviceLabelFromUserAgent(agent),
    });

    await db.user.update({
      where: { id: owner.id },
      data: { lastLoginAt: new Date() },
    });
    await writeAuditLog({
      actorId: owner.id,
      action: "LOGIN",
      targetType: "Session",
      targetId: session.sessionId,
      ipAddress: ip,
      userAgent: agent,
      metadata: { surface: "SUPER_ADMIN", credentialSource: "SERVER_ENV" },
    });

    const response = NextResponse.redirect(new URL(returnTo, appOrigin()), 303);
    setSessionCookie(response, session.rawToken, session.expiresAt);
    return response;
  } catch (error) {
    console.error("Super Admin login failed", error);
    return redirectToLogin(
      request,
      "Super Admin sign in could not be completed.",
      returnTo,
    );
  }
}
