import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ roleId: string }> },
): Promise<NextResponse> {
  const { roleId } = await context.params;
  const url = new URL("/super-admin/administration/roles", request.url);
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    const role = await db.role.findUnique({
      where: { id: roleId },
      include: { _count: { select: { users: true } } },
    });
    if (!role || role.isSystem || role.isMasterAdmin)
      throw new Error("Protected or missing role.");
    if (role._count.users > 0) throw new Error("Role is assigned to users.");
    await db.role.update({
      where: { id: roleId },
      data: { status: "ARCHIVED", archivedAt: new Date() },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "ARCHIVE",
      targetType: "Role",
      targetId: roleId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    url.searchParams.set("success", "Custom role archived.");
  } catch (error) {
    console.error("Role archive failed", error);
    url.searchParams.set(
      "error",
      "Role cannot be archived while protected or assigned.",
    );
  }
  return NextResponse.redirect(url, 303);
}
