import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ roleId: string }> },
): Promise<NextResponse> {
  const { roleId } = await context.params;
  const url = new URL("/super-admin/administration/roles", request.url);
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    const source = await db.role.findUnique({
      where: { id: roleId },
      include: { permissions: { where: { allowed: true } } },
    });
    if (!source || !source.isAdminRole) throw new Error("Role not found.");
    let suffix = 1;
    let code = `${source.code}_COPY`;
    while (
      await db.role.findUnique({ where: { code }, select: { id: true } })
    ) {
      suffix += 1;
      code = `${source.code}_COPY_${suffix}`;
    }
    const clone = await db.role.create({
      data: {
        code,
        name: `${source.name} Copy${suffix > 1 ? ` ${suffix}` : ""}`,
        description: source.description,
        defaultDataScope: source.defaultDataScope,
        isAdminRole: true,
        isSystem: false,
        isMasterAdmin: false,
        permissions: {
          create: source.permissions.map((item) => ({
            permissionId: item.permissionId,
            allowed: true,
            grantedById: session.user.id,
          })),
        },
      },
      select: { id: true },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      targetType: "RoleClone",
      targetId: clone.id,
      metadata: { sourceRoleId: roleId, code },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    url.searchParams.set("success", "Role cloned successfully.");
  } catch (error) {
    console.error("Role clone failed", error);
    url.searchParams.set("error", "Role could not be cloned.");
  }
  return NextResponse.redirect(url, 303);
}
