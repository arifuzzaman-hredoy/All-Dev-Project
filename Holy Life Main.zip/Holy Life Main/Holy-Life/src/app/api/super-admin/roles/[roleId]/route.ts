import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import {
  DATA_SCOPES,
  PERMISSION_KEYS,
  type DataScopeValue,
} from "@/lib/rbac/catalog";

function redirectResult(
  request: NextRequest,
  roleId: string,
  key: "error" | "success",
  value: string,
): NextResponse {
  const url = new URL(
    `/super-admin/administration/roles/${roleId}`,
    request.url,
  );
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ roleId: string }> },
): Promise<NextResponse> {
  const { roleId } = await context.params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    const form = await readForm(request);
    const role = await db.role.findUnique({
      where: { id: roleId },
      include: {
        users: { include: { user: { select: { isSuperAdmin: true } } } },
        permissions: { select: { permission: { select: { key: true } } } },
      },
    });
    if (!role || !role.isAdminRole)
      return redirectResult(request, roleId, "error", "Role was not found.");
    const name = String(form.get("name") ?? "")
      .trim()
      .replace(/\s+/g, " ");
    const description =
      String(form.get("description") ?? "")
        .trim()
        .slice(0, 500) || null;
    const defaultDataScope = String(
      form.get("defaultDataScope") ?? role.defaultDataScope,
    ) as DataScopeValue;
    if (name.length < 2 || name.length > 80)
      return redirectResult(
        request,
        roleId,
        "error",
        "Enter a valid role name.",
      );
    if (!DATA_SCOPES.includes(defaultDataScope))
      return redirectResult(request, roleId, "error", "Invalid data scope.");
    const nameDuplicate = await db.role.findFirst({
      where: {
        id: { not: roleId },
        name: { equals: name, mode: "insensitive" },
      },
      select: { id: true },
    });
    if (nameDuplicate)
      return redirectResult(
        request,
        roleId,
        "error",
        "Another role already uses this name.",
      );
    const requested = [
      ...new Set(
        form
          .getAll("permissionKey")
          .map(String)
          .filter((key) => PERMISSION_KEYS.has(key)),
      ),
    ];
    const permissions = await db.permission.findMany({
      where: { key: { in: requested } },
      select: { id: true, key: true },
    });
    const permissionIds = permissions.map((item) => item.id);
    const userIds = role.users
      .filter((item) => !item.user.isSuperAdmin)
      .map((item) => item.userId);
    const now = new Date();

    await db.$transaction(async (tx) => {
      await tx.role.update({
        where: { id: roleId },
        data: { name, description, defaultDataScope },
      });
      await tx.rolePermission.deleteMany({
        where: {
          roleId,
          permissionId: {
            notIn: permissionIds.length ? permissionIds : ["__none__"],
          },
        },
      });
      for (const permissionId of permissionIds) {
        await tx.rolePermission.upsert({
          where: { roleId_permissionId: { roleId, permissionId } },
          update: { allowed: true, grantedById: session.user.id },
          create: {
            roleId,
            permissionId,
            allowed: true,
            grantedById: session.user.id,
          },
        });
      }
      if (userIds.length > 0) {
        await tx.user.updateMany({
          where: { id: { in: userIds }, isSuperAdmin: false },
          data: { sessionVersion: { increment: 1 } },
        });
        await tx.session.updateMany({
          where: { userId: { in: userIds }, revokedAt: null },
          data: { revokedAt: now },
        });
      }
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "PERMISSION_CHANGE",
      targetType: "Role",
      targetId: roleId,
      metadata: {
        previousPermissionKeys: role.permissions.map(
          (item) => item.permission.key,
        ),
        permissionKeys: permissions.map((item) => item.key),
        affectedUserCount: userIds.length,
        defaultDataScope,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      roleId,
      "success",
      "Role saved. Affected admin sessions were revoked.",
    );
  } catch (error) {
    console.error("Role update failed", error);
    return redirectResult(
      request,
      roleId,
      "error",
      "Role could not be updated.",
    );
  }
}
