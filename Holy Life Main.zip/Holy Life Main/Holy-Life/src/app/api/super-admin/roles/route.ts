import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import {
  DATA_SCOPES,
  PERMISSION_KEYS,
  type DataScopeValue,
} from "@/lib/rbac/catalog";
import { normalizeRoleCode, validateRoleCode } from "@/lib/rbac/role-code";

function redirectResult(
  request: NextRequest,
  key: "error" | "success",
  value: string,
  path = "/super-admin/administration/roles/create",
): NextResponse {
  const url = new URL(path, request.url);
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    const form = await readForm(request);
    const name = String(form.get("name") ?? "")
      .trim()
      .replace(/\s+/g, " ");
    const code = normalizeRoleCode(String(form.get("code") ?? name));
    const description =
      String(form.get("description") ?? "")
        .trim()
        .slice(0, 500) || null;
    const defaultDataScope = String(
      form.get("defaultDataScope") ?? "DEPARTMENT",
    ) as DataScopeValue;
    const permissionKeys = [
      ...new Set(
        form
          .getAll("permissionKey")
          .map(String)
          .filter((key) => PERMISSION_KEYS.has(key)),
      ),
    ];
    if (name.length < 2 || name.length > 80)
      return redirectResult(request, "error", "Enter a valid role name.");
    if (!validateRoleCode(code))
      return redirectResult(
        request,
        "error",
        "Role code must start with a letter and use A-Z, 0-9, or underscore.",
      );
    if (!DATA_SCOPES.includes(defaultDataScope))
      return redirectResult(request, "error", "Invalid data scope.");
    const duplicate = await db.role.findFirst({
      where: {
        OR: [{ code }, { name: { equals: name, mode: "insensitive" } }],
      },
      select: { id: true },
    });
    if (duplicate)
      return redirectResult(
        request,
        "error",
        "A role already exists with this name or code.",
      );
    const permissions = await db.permission.findMany({
      where: { key: { in: permissionKeys } },
      select: { id: true },
    });
    const role = await db.role.create({
      data: {
        code,
        name,
        description,
        defaultDataScope,
        isAdminRole: true,
        isSystem: false,
        permissions: {
          create: permissions.map((item) => ({
            permissionId: item.id,
            allowed: true,
            grantedById: session.user.id,
          })),
        },
      },
      select: { id: true },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CREATE",
      targetType: "Role",
      targetId: role.id,
      metadata: { code, permissionCount: permissions.length, defaultDataScope },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      "success",
      "Custom role created.",
      "/super-admin/administration/roles",
    );
  } catch (error) {
    console.error("Role creation failed", error);
    return redirectResult(request, "error", "Role could not be created.");
  }
}
