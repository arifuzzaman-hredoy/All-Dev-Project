import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { isValidEmail, normalizeEmail } from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { DATA_SCOPES, type DataScopeValue } from "@/lib/rbac/catalog";

function redirectResult(
  request: NextRequest,
  userId: string,
  key: "error" | "success",
  value: string,
): NextResponse {
  const url = new URL(
    `/super-admin/administration/admins/${userId}`,
    request.url,
  );
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> },
): Promise<NextResponse> {
  const { userId } = await context.params;
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    if (userId === session.user.id)
      return redirectResult(
        request,
        userId,
        "error",
        "The primary owner cannot be modified here.",
      );
    const form = await readForm(request);
    const name = String(form.get("name") ?? "")
      .trim()
      .replace(/\s+/g, " ");
    const email = normalizeEmail(String(form.get("email") ?? ""));
    const status = String(form.get("status") ?? "ACTIVE");
    const roleIds = [
      ...new Set(form.getAll("roleId").map(String).filter(Boolean)),
    ];
    if (name.length < 2 || name.length > 100)
      return redirectResult(
        request,
        userId,
        "error",
        "Enter a valid full name.",
      );
    if (!isValidEmail(email))
      return redirectResult(
        request,
        userId,
        "error",
        "Enter a valid email address.",
      );
    if (status !== "ACTIVE" && status !== "SUSPENDED")
      return redirectResult(
        request,
        userId,
        "error",
        "Invalid account status.",
      );
    if (roleIds.length === 0)
      return redirectResult(
        request,
        userId,
        "error",
        "Select at least one role.",
      );

    const target = await db.user.findUnique({
      where: { id: userId },
      include: { roles: true },
    });
    if (!target || target.isSuperAdmin)
      return redirectResult(
        request,
        userId,
        "error",
        "Admin account was not found.",
      );
    const duplicate = await db.user.findFirst({
      where: { email, id: { not: userId } },
      select: { id: true },
    });
    if (duplicate)
      return redirectResult(
        request,
        userId,
        "error",
        "Another account already uses this email.",
      );
    const roles = await db.role.findMany({
      where: { id: { in: roleIds }, isAdminRole: true, status: "ACTIVE" },
      select: { id: true },
    });
    if (roles.length !== roleIds.length)
      return redirectResult(
        request,
        userId,
        "error",
        "One or more selected roles are unavailable.",
      );

    const assignments = roleIds.map((roleId) => {
      const rawScope = String(
        form.get(`scope_${roleId}`) ?? "DEPARTMENT",
      ) as DataScopeValue;
      const dataScope: DataScopeValue = DATA_SCOPES.includes(rawScope)
        ? rawScope
        : "DEPARTMENT";
      return { roleId, dataScope };
    });
    const now = new Date();
    await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: { name, email, status, sessionVersion: { increment: 1 } },
      });
      await tx.userRole.deleteMany({
        where: { userId, roleId: { notIn: roleIds } },
      });
      for (const assignment of assignments) {
        await tx.userRole.upsert({
          where: { userId_roleId: { userId, roleId: assignment.roleId } },
          update: {
            dataScope: assignment.dataScope,
            assignedById: session.user.id,
          },
          create: {
            userId,
            roleId: assignment.roleId,
            dataScope: assignment.dataScope,
            assignedById: session.user.id,
          },
        });
      }
      await tx.session.updateMany({
        where: { userId, revokedAt: null },
        data: { revokedAt: now },
      });
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "ROLE_CHANGE",
      targetType: "AdminUser",
      targetId: userId,
      metadata: {
        previousStatus: target.status,
        status,
        previousRoleIds: target.roles.map((item) => item.roleId),
        assignments,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      userId,
      "success",
      "Admin updated. Existing sessions were revoked so permissions refresh immediately.",
    );
  } catch (error) {
    console.error("Admin update failed", error);
    return redirectResult(
      request,
      userId,
      "error",
      "Admin account could not be updated.",
    );
  }
}
