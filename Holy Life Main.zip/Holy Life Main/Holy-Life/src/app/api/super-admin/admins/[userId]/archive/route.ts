import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> },
): Promise<NextResponse> {
  const { userId } = await context.params;
  const url = new URL("/super-admin/administration/admins", request.url);
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    if (userId === session.user.id)
      throw new Error("The primary owner cannot be archived.");
    const target = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, isSuperAdmin: true },
    });
    if (!target || target.isSuperAdmin)
      throw new Error("Protected or missing account.");
    const now = new Date();
    await db.$transaction([
      db.user.update({
        where: { id: userId },
        data: { status: "ARCHIVED", sessionVersion: { increment: 1 } },
      }),
      db.session.updateMany({
        where: { userId, revokedAt: null },
        data: { revokedAt: now },
      }),
    ]);
    await writeAuditLog({
      actorId: session.user.id,
      action: "ARCHIVE",
      targetType: "AdminUser",
      targetId: userId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    url.searchParams.set(
      "success",
      "Admin account archived and sessions revoked.",
    );
  } catch (error) {
    console.error("Admin archive failed", error);
    url.searchParams.set("error", "Admin account could not be archived.");
  }
  return NextResponse.redirect(url, 303);
}
