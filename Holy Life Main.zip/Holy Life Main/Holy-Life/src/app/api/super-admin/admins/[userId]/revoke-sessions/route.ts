import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> },
): Promise<NextResponse> {
  const { userId } = await context.params;
  const url = new URL("/super-admin/administration/admins", request.url);
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin || userId === session.user.id)
      throw new Error("Protected action.");
    const target = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, isSuperAdmin: true },
    });
    if (!target || target.isSuperAdmin)
      throw new Error("Protected or missing account.");
    const now = new Date();
    const result = await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: { sessionVersion: { increment: 1 } },
      });
      return tx.session.updateMany({
        where: { userId, revokedAt: null },
        data: { revokedAt: now },
      });
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "SESSION_REVOKE",
      targetType: "AdminUser",
      targetId: userId,
      metadata: { revokedCount: result.count },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    url.searchParams.set("success", `${result.count} session(s) revoked.`);
  } catch (error) {
    console.error("Admin session revoke failed", error);
    url.searchParams.set("error", "Sessions could not be revoked.");
  }
  return NextResponse.redirect(url, 303);
}
