import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  createOpaqueToken,
  hashOpaqueToken,
  hashPassword,
} from "@/lib/auth/crypto";
import { deliverAuthChallenge } from "@/lib/auth/delivery";
import {
  isValidEmail,
  normalizeEmail,
  validatePassword,
} from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { DATA_SCOPES, type DataScopeValue } from "@/lib/rbac/catalog";

function redirectResult(
  request: NextRequest,
  key: "error" | "success",
  value: string,
  invitation?: string,
): NextResponse {
  const url = new URL("/super-admin/administration/admins/create", request.url);
  url.searchParams.set(key, value);
  if (invitation) url.searchParams.set("invitation", invitation);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const session = await getCurrentSession();
    if (!session?.user.isSuperAdmin)
      return NextResponse.redirect(
        new URL("/login?error=Owner+access+required.", request.url),
        303,
      );
    const form = await readForm(request);
    const name = String(form.get("name") ?? "")
      .trim()
      .replace(/\s+/g, " ");
    const email = normalizeEmail(String(form.get("email") ?? ""));
    const mode = String(form.get("mode") ?? "DIRECT");
    const password = String(form.get("password") ?? "");
    const dataScope = String(
      form.get("dataScope") ?? "DEPARTMENT",
    ) as DataScopeValue;
    const roleIds = [
      ...new Set(form.getAll("roleId").map(String).filter(Boolean)),
    ];

    if (name.length < 2 || name.length > 100)
      return redirectResult(request, "error", "Enter a valid full name.");
    if (!isValidEmail(email))
      return redirectResult(request, "error", "Enter a valid email address.");
    if (mode !== "DIRECT" && mode !== "INVITATION")
      return redirectResult(request, "error", "Invalid account creation mode.");
    if (!DATA_SCOPES.includes(dataScope))
      return redirectResult(request, "error", "Invalid data scope.");
    if (roleIds.length === 0)
      return redirectResult(
        request,
        "error",
        "Select at least one admin role.",
      );
    if (mode === "DIRECT") {
      const passwordError = validatePassword(password);
      if (passwordError) return redirectResult(request, "error", passwordError);
    }

    const roles = await db.role.findMany({
      where: { id: { in: roleIds }, isAdminRole: true, status: "ACTIVE" },
      select: { id: true, name: true },
    });
    if (roles.length !== roleIds.length)
      return redirectResult(
        request,
        "error",
        "One or more selected roles are unavailable.",
      );

    const existing = await db.user.findUnique({
      where: { email },
      select: { id: true },
    });
    if (existing)
      return redirectResult(
        request,
        "error",
        "An account already exists with this email.",
      );

    if (mode === "DIRECT") {
      const now = new Date();
      const admin = await db.user.create({
        data: {
          name,
          email,
          passwordHash: await hashPassword(password),
          passwordChangedAt: now,
          emailVerifiedAt: now,
          status: "ACTIVE",
          roles: {
            create: roleIds.map((roleId) => ({
              roleId,
              dataScope,
              assignedById: session.user.id,
            })),
          },
        },
        select: { id: true },
      });
      await writeAuditLog({
        actorId: session.user.id,
        action: "CREATE",
        targetType: "AdminUser",
        targetId: admin.id,
        metadata: { mode, email, roleIds, dataScope },
        ipAddress: clientIp(request),
        userAgent: userAgent(request),
      });
      return redirectResult(
        request,
        "success",
        "Admin account created successfully.",
      );
    }

    const rawToken = createOpaqueToken(32);
    const tokenHash = hashOpaqueToken(rawToken);
    const expiresAt = new Date(Date.now() + 72 * 60 * 60 * 1000);
    await db.$transaction(async (tx) => {
      await tx.adminInvitation.updateMany({
        where: { email, consumedAt: null, revokedAt: null },
        data: { revokedAt: new Date() },
      });
      await tx.adminInvitation.create({
        data: {
          email,
          name,
          tokenHash,
          expiresAt,
          invitedById: session.user.id,
          roles: { create: roleIds.map((roleId) => ({ roleId, dataScope })) },
        },
      });
    });
    let delivered = false;
    try {
      await deliverAuthChallenge({
        channel: "EMAIL",
        target: email,
        purpose: "ADMIN_INVITE",
        code: "",
        token: rawToken,
      });
      delivered = true;
    } catch (deliveryError) {
      console.warn(
        "Admin invitation delivery is not configured; owner can copy the one-time link.",
        deliveryError,
      );
    }
    await writeAuditLog({
      actorId: session.user.id,
      action: "INVITE",
      targetType: "AdminInvitation",
      metadata: {
        email,
        roleIds,
        dataScope,
        expiresAt: expiresAt.toISOString(),
        delivered,
      },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      "success",
      delivered
        ? "Invitation created and delivered. The one-time URL is also shown below."
        : "Invitation created. Copy the one-time URL below.",
      rawToken,
    );
  } catch (error) {
    console.error("Admin creation failed", error);
    return redirectResult(
      request,
      "error",
      "Admin account or invitation could not be created.",
    );
  }
}
