import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { hashOpaqueToken, hashPassword } from "@/lib/auth/crypto";
import { validatePassword } from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { db } from "@/lib/db";

function redirectResult(
  request: NextRequest,
  token: string,
  key: "error" | "success",
  value: string,
  path = "/admin-invitation",
): NextResponse {
  const url = new URL(path, request.url);
  if (token && path === "/admin-invitation")
    url.searchParams.set("token", token);
  url.searchParams.set(key, value);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  let rawToken = "";
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    rawToken = String(form.get("token") ?? "");
    const password = String(form.get("password") ?? "");
    const confirmPassword = String(form.get("confirmPassword") ?? "");
    const passwordError = validatePassword(password);
    if (passwordError)
      return redirectResult(request, rawToken, "error", passwordError);
    if (password !== confirmPassword)
      return redirectResult(
        request,
        rawToken,
        "error",
        "Passwords do not match.",
      );

    const invitation = await db.adminInvitation.findUnique({
      where: { tokenHash: hashOpaqueToken(rawToken) },
      include: { roles: true },
    });
    if (
      !invitation ||
      invitation.consumedAt ||
      invitation.revokedAt ||
      invitation.expiresAt <= new Date()
    ) {
      return redirectResult(
        request,
        rawToken,
        "error",
        "Invitation is invalid, expired, used, or revoked.",
      );
    }
    if (invitation.roles.length === 0)
      return redirectResult(
        request,
        rawToken,
        "error",
        "Invitation has no role assignment.",
      );
    const existing = await db.user.findUnique({
      where: { email: invitation.email },
      select: { id: true },
    });
    if (existing)
      return redirectResult(
        request,
        rawToken,
        "error",
        "An account already exists for this email.",
      );

    const now = new Date();
    const user = await db.$transaction(async (tx) => {
      const created = await tx.user.create({
        data: {
          name: invitation.name,
          email: invitation.email,
          passwordHash: await hashPassword(password),
          passwordChangedAt: now,
          emailVerifiedAt: now,
          status: "ACTIVE",
          roles: {
            create: invitation.roles.map((item) => ({
              roleId: item.roleId,
              dataScope: item.dataScope,
              assignedById: invitation.invitedById,
            })),
          },
        },
        select: { id: true },
      });
      await tx.adminInvitation.update({
        where: { id: invitation.id },
        data: { consumedAt: now },
      });
      return created;
    });
    await writeAuditLog({
      actorId: user.id,
      action: "VERIFY",
      targetType: "AdminInvitation",
      targetId: invitation.id,
      metadata: { acceptedByUserId: user.id },
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return redirectResult(
      request,
      "",
      "success",
      "Invitation accepted. Sign in with your new password.",
      "/login",
    );
  } catch (error) {
    console.error("Admin invitation acceptance failed", error);
    return redirectResult(
      request,
      rawToken,
      "error",
      "Invitation could not be accepted.",
    );
  }
}
