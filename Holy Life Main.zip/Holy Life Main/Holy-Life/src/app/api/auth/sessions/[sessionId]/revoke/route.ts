import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { clearSessionCookie, getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ sessionId: string }> },
): Promise<NextResponse> {
  assertSameOrigin(request);
  const current = await getCurrentSession();
  if (!current)
    return NextResponse.redirect(new URL("/login", request.url), 303);
  const { sessionId } = await context.params;

  const target = await db.session.findFirst({
    where: { id: sessionId, userId: current.user.id, revokedAt: null },
    select: { id: true },
  });
  if (!target)
    return NextResponse.redirect(
      new URL(
        "/dashboard/profile/security?error=Session+was+not+found.",
        request.url,
      ),
      303,
    );

  await db.session.update({
    where: { id: target.id },
    data: { revokedAt: new Date() },
  });
  await writeAuditLog({
    actorId: current.user.id,
    action: "SESSION_REVOKE",
    targetType: "Session",
    targetId: target.id,
    ipAddress: clientIp(request),
    userAgent: userAgent(request),
  });

  const isCurrent = target.id === current.id;
  const response = NextResponse.redirect(
    new URL(
      isCurrent
        ? "/login?success=Session+revoked."
        : "/dashboard/profile/security?success=Session+revoked.",
      request.url,
    ),
    303,
  );
  if (isCurrent) clearSessionCookie(response);
  return response;
}
