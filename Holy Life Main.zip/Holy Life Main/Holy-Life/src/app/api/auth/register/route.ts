import { NextRequest, NextResponse } from "next/server";
import { hashPassword } from "@/lib/auth/crypto";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  normalizeEmail,
  normalizePhone,
  isValidEmail,
  isValidBangladeshPhone,
  validatePassword,
} from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  deviceLabelFromUserAgent,
  readForm,
  safeReturnTo,
  userAgent,
} from "@/lib/auth/request";
import { createSession, setSessionCookie } from "@/lib/auth/session";
import { createVerificationChallenge } from "@/lib/auth/verification";
import { db } from "@/lib/db";

function redirectWithError(
  request: NextRequest,
  message: string,
): NextResponse {
  const url = new URL("/register", request.url);
  url.searchParams.set("error", message);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const name = String(form.get("name") ?? "")
      .trim()
      .replace(/\s+/g, " ");
    const emailRaw = String(form.get("email") ?? "").trim();
    const phoneRaw = String(form.get("phone") ?? "").trim();
    const password = String(form.get("password") ?? "");
    const confirmPassword = String(form.get("confirmPassword") ?? "");
    const returnTo = safeReturnTo(form.get("returnTo"));

    if (name.length < 2 || name.length > 100)
      return redirectWithError(request, "Enter a valid full name.");
    if (!emailRaw && !phoneRaw)
      return redirectWithError(
        request,
        "Enter an email address or phone number.",
      );

    const email = emailRaw ? normalizeEmail(emailRaw) : null;
    const phone = phoneRaw ? normalizePhone(phoneRaw) : null;
    if (email && !isValidEmail(email))
      return redirectWithError(request, "Enter a valid email address.");
    if (phone && !isValidBangladeshPhone(phone))
      return redirectWithError(
        request,
        "Enter a valid Bangladesh mobile number.",
      );
    const passwordError = validatePassword(password);
    if (passwordError) return redirectWithError(request, passwordError);
    if (password !== confirmPassword)
      return redirectWithError(request, "Passwords do not match.");

    const duplicateConditions: Array<{ email: string } | { phone: string }> =
      [];
    if (email) duplicateConditions.push({ email });
    if (phone) duplicateConditions.push({ phone });
    const duplicate = await db.user.findFirst({
      where: { OR: duplicateConditions },
      select: { id: true },
    });
    if (duplicate)
      return redirectWithError(
        request,
        "An account already exists with that email or phone number.",
      );

    const memberRole = await db.role.findUnique({
      where: { code: "MEMBER" },
      select: { id: true },
    });
    if (!memberRole) throw new Error("MEMBER role has not been seeded.");

    const now = new Date();
    const user = await db.user.create({
      data: {
        name,
        email,
        phone,
        passwordHash: await hashPassword(password),
        passwordChangedAt: now,
        roles: { create: { roleId: memberRole.id, dataScope: "OWN" } },
      },
      select: { id: true, sessionVersion: true },
    });

    const agent = userAgent(request);
    const ip = clientIp(request);
    const session = await createSession({
      userId: user.id,
      sessionVersion: user.sessionVersion,
      ipAddress: ip,
      userAgent: agent,
      deviceLabel: deviceLabelFromUserAgent(agent),
    });

    const channel = email ? "EMAIL" : "PHONE";
    const target = email ?? phone;
    if (!target) throw new Error("Verification target is missing.");
    let deliveryFailed = false;
    try {
      await createVerificationChallenge({
        userId: user.id,
        target,
        channel,
        purpose: channel === "EMAIL" ? "EMAIL_VERIFY" : "PHONE_VERIFY",
      });
    } catch (error) {
      deliveryFailed = true;
      console.error("Initial verification delivery failed", error);
    }

    await writeAuditLog({
      actorId: user.id,
      action: "REGISTER",
      targetType: "User",
      targetId: user.id,
      ipAddress: ip,
      userAgent: agent,
      metadata: { verificationChannel: channel },
    });

    const url = new URL("/verify", request.url);
    if (deliveryFailed) {
      url.searchParams.set(
        "error",
        "Your account was created, but the verification message could not be delivered. Use resend after checking delivery settings.",
      );
    } else {
      url.searchParams.set("sent", channel.toLowerCase());
    }
    url.searchParams.set("channel", channel.toLowerCase());
    url.searchParams.set("returnTo", returnTo);
    const response = NextResponse.redirect(url, 303);
    setSessionCookie(response, session.rawToken, session.expiresAt);
    return response;
  } catch (error) {
    console.error("Registration failed", error);
    return redirectWithError(
      request,
      "Registration could not be completed. Please try again.",
    );
  }
}
