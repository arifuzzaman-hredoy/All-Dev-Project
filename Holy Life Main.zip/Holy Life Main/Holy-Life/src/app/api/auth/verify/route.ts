import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { hashOpaqueToken } from "@/lib/auth/crypto";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  safeReturnTo,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import { consumeChallenge } from "@/lib/auth/verification";
import { db } from "@/lib/db";

function verifyRedirect(
  request: NextRequest,
  key: "error" | "success",
  value: string,
  returnTo: string,
): NextResponse {
  const url = new URL("/verify", request.url);
  url.searchParams.set(key, value);
  url.searchParams.set("returnTo", returnTo);
  return NextResponse.redirect(url, 303);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const token = String(form.get("token") ?? "").trim() || null;
    const code = String(form.get("code") ?? "").trim() || null;
    const returnTo = safeReturnTo(form.get("returnTo"));
    const requestedChannel = String(form.get("channel") ?? "");
    const session = await getCurrentSession();

    let purpose: "EMAIL_VERIFY" | "PHONE_VERIFY";
    if (
      requestedChannel === "phone" &&
      session?.user.phone &&
      !session.user.phoneVerifiedAt
    )
      purpose = "PHONE_VERIFY";
    else if (
      requestedChannel === "email" &&
      session?.user.email &&
      !session.user.emailVerifiedAt
    )
      purpose = "EMAIL_VERIFY";
    else if (session?.user.email && !session.user.emailVerifiedAt)
      purpose = "EMAIL_VERIFY";
    else if (session?.user.phone && !session.user.phoneVerifiedAt)
      purpose = "PHONE_VERIFY";
    else if (token) {
      const challenge = await db.verificationChallenge.findUnique({
        where: { tokenHash: hashOpaqueToken(token) },
        select: { purpose: true },
      });
      if (
        !challenge ||
        (challenge.purpose !== "EMAIL_VERIFY" &&
          challenge.purpose !== "PHONE_VERIFY")
      ) {
        return verifyRedirect(
          request,
          "error",
          "Verification link is invalid or expired.",
          returnTo,
        );
      }
      purpose = challenge.purpose;
    } else {
      return verifyRedirect(
        request,
        "success",
        "Your contact information is already verified.",
        returnTo,
      );
    }

    const consumed = await consumeChallenge({
      token,
      code,
      userId: token ? null : session?.user.id,
      purpose,
    });
    if (!consumed?.userId)
      return verifyRedirect(
        request,
        "error",
        "The code or link is invalid, expired, or has too many attempts.",
        returnTo,
      );

    const now = new Date();
    const user = await db.user.findUnique({
      where: { id: consumed.userId },
      select: { email: true, phone: true },
    });
    if (!user)
      return verifyRedirect(
        request,
        "error",
        "Account could not be found.",
        returnTo,
      );

    if (consumed.channel === "EMAIL") {
      if (user.email !== consumed.target)
        return verifyRedirect(
          request,
          "error",
          "Verification target no longer matches the account.",
          returnTo,
        );
      await db.user.update({
        where: { id: consumed.userId },
        data: { emailVerifiedAt: now },
      });
    } else {
      if (user.phone !== consumed.target)
        return verifyRedirect(
          request,
          "error",
          "Verification target no longer matches the account.",
          returnTo,
        );
      await db.user.update({
        where: { id: consumed.userId },
        data: { phoneVerifiedAt: now },
      });
    }

    await writeAuditLog({
      actorId: consumed.userId,
      action: "VERIFY",
      targetType: consumed.channel === "EMAIL" ? "Email" : "Phone",
      targetId: consumed.challengeId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });

    const destination = session ? returnTo : "/login?success=verified";
    return NextResponse.redirect(new URL(destination, request.url), 303);
  } catch (error) {
    console.error("Verification failed", error);
    return verifyRedirect(
      request,
      "error",
      "Verification could not be completed.",
      "/dashboard",
    );
  }
}
