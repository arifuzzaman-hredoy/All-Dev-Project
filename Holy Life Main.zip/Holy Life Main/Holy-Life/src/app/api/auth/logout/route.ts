import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { hashOpaqueToken } from "@/lib/auth/crypto";
import { authConfig } from "@/lib/auth/config";
import { assertSameOrigin, clientIp, userAgent } from "@/lib/auth/request";
import { clearSessionCookie, revokeSessionByToken } from "@/lib/auth/session";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  assertSameOrigin(request);
  const token = request.cookies.get(authConfig.cookieName)?.value;
  let userId: string | null = null;
  let sessionId: string | null = null;
  if (token) {
    const session = await db.session.findUnique({
      where: { tokenHash: hashOpaqueToken(token) },
      select: { id: true, userId: true },
    });
    userId = session?.userId ?? null;
    sessionId = await revokeSessionByToken(token);
  }
  if (sessionId) {
    await writeAuditLog({
      actorId: userId,
      action: "LOGOUT",
      targetType: "Session",
      targetId: sessionId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
  }
  const response = NextResponse.redirect(
    new URL("/login?success=signed-out", request.url),
    303,
  );
  clearSessionCookie(response);
  return response;
}
