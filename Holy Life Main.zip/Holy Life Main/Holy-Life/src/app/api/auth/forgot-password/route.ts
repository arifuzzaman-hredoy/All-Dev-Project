import { NextRequest, NextResponse } from "next/server";
import { normalizeIdentifier } from "@/lib/auth/normalize";
import { assertSameOrigin, clientIp, readForm } from "@/lib/auth/request";
import { getLoginThrottle, recordLoginFailure } from "@/lib/auth/throttle";
import {
  createVerificationChallenge,
  VerificationCooldownError,
} from "@/lib/auth/verification";
import { db } from "@/lib/db";

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const identifier = normalizeIdentifier(
      String(form.get("identifier") ?? ""),
    );
    const throttleKey = `recovery:${identifier}:${clientIp(request) ?? "unknown"}`;

    if (identifier) {
      const throttle = await getLoginThrottle(throttleKey);
      if (!throttle.locked) {
        await recordLoginFailure(throttleKey);
        const user = await db.user.findFirst({
          where: identifier.includes("@")
            ? { email: identifier }
            : { phone: identifier },
          select: {
            id: true,
            email: true,
            phone: true,
            status: true,
            isSuperAdmin: true,
          },
        });
        if (user?.status === "ACTIVE" && !user.isSuperAdmin) {
          const channel = identifier.includes("@") ? "EMAIL" : "PHONE";
          const target = channel === "EMAIL" ? user.email : user.phone;
          if (target) {
            try {
              await createVerificationChallenge({
                userId: user.id,
                target,
                channel,
                purpose: "PASSWORD_RESET",
              });
            } catch (error) {
              if (!(error instanceof VerificationCooldownError)) throw error;
            }
          }
        }
      }
    }
  } catch (error) {
    console.error("Password reset request failed", error);
  }

  return NextResponse.redirect(
    new URL(
      "/forgot-password?success=If+the+account+exists%2C+reset+instructions+were+sent.",
      request.url,
    ),
    303,
  );
}
