import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import { hashPassword } from "@/lib/auth/crypto";
import { normalizeIdentifier, validatePassword } from "@/lib/auth/normalize";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { consumeChallenge } from "@/lib/auth/verification";
import { db } from "@/lib/db";

function resetUrl(request: NextRequest, token: string, error: string): URL {
  const url = new URL("/reset-password", request.url);
  if (token) url.searchParams.set("token", token);
  url.searchParams.set("error", error);
  return url;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const token = String(form.get("token") ?? "").trim();
    const identifier = normalizeIdentifier(
      String(form.get("identifier") ?? ""),
    );
    const code = String(form.get("code") ?? "").trim();
    const password = String(form.get("password") ?? "");
    const confirmPassword = String(form.get("confirmPassword") ?? "");

    if (!token && (!identifier || !/^\d{6}$/.test(code))) {
      return NextResponse.redirect(
        resetUrl(
          request,
          token,
          "Enter your email/phone and the 6-digit reset code.",
        ),
        303,
      );
    }
    const passwordError = validatePassword(password);
    if (passwordError)
      return NextResponse.redirect(
        resetUrl(request, token, passwordError),
        303,
      );
    if (password !== confirmPassword) {
      return NextResponse.redirect(
        resetUrl(request, token, "Passwords do not match."),
        303,
      );
    }

    let userId: string | null = null;
    if (!token) {
      const user = await db.user.findFirst({
        where: identifier.includes("@")
          ? { email: identifier }
          : { phone: identifier },
        select: { id: true },
      });
      userId = user?.id ?? null;
    }

    const consumed = await consumeChallenge({
      token: token || null,
      code: token ? null : code,
      userId,
      purpose: "PASSWORD_RESET",
    });
    if (!consumed?.userId) {
      return NextResponse.redirect(
        resetUrl(
          request,
          token,
          "Reset link or code is invalid, expired, or has too many attempts.",
        ),
        303,
      );
    }

    const targetUser = await db.user.findUnique({
      where: { id: consumed.userId },
      select: { isSuperAdmin: true },
    });
    if (targetUser?.isSuperAdmin) {
      return NextResponse.redirect(
        resetUrl(
          request,
          token,
          "Super Admin credentials are managed from the server environment.",
        ),
        303,
      );
    }

    const now = new Date();
    const passwordHash = await hashPassword(password);
    await db.$transaction([
      db.user.update({
        where: { id: consumed.userId },
        data: {
          passwordHash,
          passwordChangedAt: now,
          sessionVersion: { increment: 1 },
        },
      }),
      db.session.updateMany({
        where: { userId: consumed.userId, revokedAt: null },
        data: { revokedAt: now },
      }),
    ]);

    await writeAuditLog({
      actorId: consumed.userId,
      action: "PASSWORD_CHANGE",
      targetType: "User",
      targetId: consumed.userId,
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    return NextResponse.redirect(
      new URL(
        "/login?success=Password+updated.+Sign+in+with+your+new+password.",
        request.url,
      ),
      303,
    );
  } catch (error) {
    console.error("Password reset failed", error);
    return NextResponse.redirect(
      new URL(
        "/reset-password?error=Password+reset+could+not+be+completed.",
        request.url,
      ),
      303,
    );
  }
}
