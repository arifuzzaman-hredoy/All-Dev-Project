import { NextRequest, NextResponse } from "next/server";
import { writeAuditLog } from "@/lib/auth/audit";
import {
  assertSameOrigin,
  clientIp,
  readForm,
  userAgent,
} from "@/lib/auth/request";
import { getCurrentSession } from "@/lib/auth/session";
import {
  createVerificationChallenge,
  VerificationCooldownError,
} from "@/lib/auth/verification";

export async function POST(request: NextRequest): Promise<NextResponse> {
  let selectedChannel: "email" | "phone" = "email";
  try {
    assertSameOrigin(request);
    const form = await readForm(request);
    const requestedChannel = String(form.get("channel") ?? "");
    const session = await getCurrentSession();
    if (!session) {
      return NextResponse.redirect(
        new URL("/login?error=Sign+in+to+request+a+new+code.", request.url),
        303,
      );
    }

    const { user } = session;
    if (requestedChannel === "phone" && user.phone && !user.phoneVerifiedAt) {
      selectedChannel = "phone";
      await createVerificationChallenge({
        userId: user.id,
        target: user.phone,
        channel: "PHONE",
        purpose: "PHONE_VERIFY",
      });
    } else if (
      requestedChannel === "email" &&
      user.email &&
      !user.emailVerifiedAt
    ) {
      selectedChannel = "email";
      await createVerificationChallenge({
        userId: user.id,
        target: user.email,
        channel: "EMAIL",
        purpose: "EMAIL_VERIFY",
      });
    } else if (user.email && !user.emailVerifiedAt) {
      selectedChannel = "email";
      await createVerificationChallenge({
        userId: user.id,
        target: user.email,
        channel: "EMAIL",
        purpose: "EMAIL_VERIFY",
      });
    } else if (user.phone && !user.phoneVerifiedAt) {
      selectedChannel = "phone";
      await createVerificationChallenge({
        userId: user.id,
        target: user.phone,
        channel: "PHONE",
        purpose: "PHONE_VERIFY",
      });
    } else {
      return NextResponse.redirect(
        new URL("/verify?success=Already+verified.", request.url),
        303,
      );
    }

    await writeAuditLog({
      actorId: user.id,
      action: "CREATE",
      targetType: "VerificationChallenge",
      ipAddress: clientIp(request),
      userAgent: userAgent(request),
    });
    const url = new URL("/verify", request.url);
    url.searchParams.set("success", "A new verification code was sent.");
    url.searchParams.set("channel", selectedChannel);
    return NextResponse.redirect(url, 303);
  } catch (error) {
    if (error instanceof VerificationCooldownError) {
      const url = new URL("/verify", request.url);
      url.searchParams.set(
        "error",
        `Wait ${error.retryAfterSeconds} seconds before requesting another code.`,
      );
      url.searchParams.set("channel", selectedChannel);
      return NextResponse.redirect(url, 303);
    }
    console.error("Resend verification failed", error);
    const url = new URL("/verify", request.url);
    url.searchParams.set("error", "Could not send a new code.");
    url.searchParams.set("channel", selectedChannel);
    return NextResponse.redirect(url, 303);
  }
}
