import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { htmlLanguage } from "@/lib/i18n/config";
import { getUiPreferences } from "@/lib/i18n/server";

const productionOrigin =
  process.env.APP_URL ?? "https://holylife.techteamlead.com";

export const metadata: Metadata = {
  metadataBase: new URL(productionOrigin),
  applicationName: "Holy Life",
  title: {
    default: "Holy Life",
    template: "%s | Holy Life",
  },
  description:
    "Holy Life health, fitness, wellness, learning, and commerce platform.",
  icons: {
    icon: [{ url: "/brand-mark.svg", type: "image/svg+xml" }],
  },
  openGraph: {
    type: "website",
    siteName: "Holy Life",
    title: "Holy Life",
    description:
      "Doctor appointments, wellness learning, and selected healthy products in one member experience.",
  },
  twitter: {
    card: "summary",
    title: "Holy Life",
    description:
      "Doctor appointments, wellness learning, and selected healthy products in one member experience.",
  },
};

const themeBootScript = `(() => {
  try {
    const root = document.documentElement;
    const cookie = document.cookie.split('; ').reduce((acc, part) => {
      const index = part.indexOf('=');
      if (index > 0) acc[part.slice(0, index)] = decodeURIComponent(part.slice(index + 1));
      return acc;
    }, {});
    const storedTheme = localStorage.getItem('holy-life-theme');
    const storedLocale = localStorage.getItem('holy-life-locale');
    const preference = ['light', 'dark', 'system'].includes(storedTheme) ? storedTheme : (cookie.holy_life_theme || root.dataset.themePreference || 'system');
    const locale = ['bn', 'en'].includes(storedLocale) ? storedLocale : (cookie.holy_life_locale || root.dataset.locale || 'en');
    const resolved = preference === 'system'
      ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : preference;
    root.dataset.themePreference = preference;
    root.dataset.theme = resolved;
    root.dataset.locale = locale;
    root.lang = locale === 'bn' ? 'bn-BD' : 'en';
  } catch {}
})();`;

export default async function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  const { locale, themePreference } = await getUiPreferences();
  const serverTheme =
    themePreference === "system" ? undefined : themePreference;

  return (
    <html
      data-locale={locale}
      data-theme={serverTheme}
      data-theme-preference={themePreference}
      lang={htmlLanguage(locale)}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBootScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
