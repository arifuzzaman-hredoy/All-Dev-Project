import Link from "next/link";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { hasVerifiedContact } from "@/lib/auth/session";
import { generateCheckoutKey } from "@/lib/commerce/code";
import { formatMoney, lineTotal } from "@/lib/commerce/money";
import { getCart } from "@/lib/commerce/queries";
import { db } from "@/lib/db";
import { intlLocale } from "@/lib/i18n/config";
import { localizedText } from "@/lib/i18n/content";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";
import { paymentGatewayAvailable } from "@/lib/payments/gateway/config";

export const dynamic = "force-dynamic";

export default async function CheckoutPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const session = await requireAuthenticatedSession("/checkout");
  const [{ locale }, query] = await Promise.all([
    getUiPreferences(),
    searchParams,
  ]);
  const numberLocale = intlLocale(locale);

  if (!hasVerifiedContact(session.user)) {
    return (
      <div className="dashboard-page">
        <PageHeader
          title={uiText(locale, "checkout.verifyTitle")}
          description={uiText(locale, "checkout.verifyDescription")}
        />
        <SectionCard title={uiText(locale, "checkout.verificationRequired")}>
          <Link
            className="ui-button ui-button-primary"
            href="/verify?returnTo=/checkout"
          >
            {uiText(locale, "checkout.verifyContact")}
          </Link>
        </SectionCard>
      </div>
    );
  }

  const [cart, shipping] = await Promise.all([
    getCart(session.user.id),
    db.shippingMethod.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { fee: "asc" }],
    }),
  ]);
  const items = cart?.items ?? [];
  const subtotal = items.reduce(
    (sum, item) =>
      sum + lineTotal(item.variant.price.toString(), item.quantity),
    0,
  );
  const canUseOnlineGateway =
    paymentGatewayAvailable() &&
    Boolean(
      session.user.email &&
      session.user.emailVerifiedAt &&
      session.user.phone &&
      session.user.phoneVerifiedAt,
    );

  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow={uiText(locale, "checkout.eyebrow")}
        title={uiText(locale, "checkout.title")}
        description={uiText(locale, "checkout.description")}
        actions={
          <Link className="ui-button ui-button-secondary" href="/cart">
            {uiText(locale, "checkout.backToCart")}
          </Link>
        }
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      <div className="commerce-checkout-layout">
        <SectionCard title={uiText(locale, "checkout.details")}>
          <form
            action="/api/commerce/checkout"
            className="panel-form"
            method="post"
          >
            <input
              name="checkoutKey"
              type="hidden"
              value={generateCheckoutKey(session.user.id)}
            />
            <div className="form-grid two">
              <label>
                {uiText(locale, "checkout.recipient")}
                <input
                  name="customerName"
                  required
                  defaultValue={session.user.name}
                />
              </label>
              <label>
                {uiText(locale, "checkout.phone")}
                <input
                  name="customerPhone"
                  required
                  defaultValue={session.user.phone ?? ""}
                />
              </label>
              <label>
                {uiText(locale, "checkout.email")}
                <input
                  name="customerEmail"
                  type="email"
                  defaultValue={session.user.email ?? ""}
                />
              </label>
              <label>
                {uiText(locale, "checkout.city")}
                <input name="city" required defaultValue="Dhaka" />
              </label>
              <label className="span-2">
                {uiText(locale, "checkout.address")}
                <input
                  name="addressLine1"
                  required
                  placeholder={uiText(locale, "checkout.addressPlaceholder")}
                />
              </label>
              <label>
                {uiText(locale, "checkout.area")}
                <input name="area" />
              </label>
              <label>
                {uiText(locale, "checkout.district")}
                <input name="district" />
              </label>
              <label>
                {uiText(locale, "checkout.postalCode")}
                <input name="postalCode" />
              </label>
              <label>
                {uiText(locale, "checkout.shipping")}
                <select name="shippingMethodId" required>
                  {shipping.map((method) => (
                    <option key={method.id} value={method.id}>
                      {localizedText(locale, method.name, method.nameBn)} ·{" "}
                      {formatMoney(method.fee.toString(), "BDT", numberLocale)}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                {uiText(locale, "checkout.coupon")}
                <input
                  name="couponCode"
                  placeholder={uiText(locale, "checkout.optional")}
                />
              </label>
              <label>
                {uiText(locale, "checkout.paymentOption")}
                <select name="paymentMethod">
                  <option value="CASH_ON_DELIVERY">
                    {uiText(locale, "checkout.cod")}
                  </option>
                  <option value="MANUAL_PAYMENT">
                    {uiText(locale, "checkout.manualPayment")}
                  </option>
                  {canUseOnlineGateway ? (
                    <option value="ONLINE_GATEWAY">
                      {uiText(locale, "checkout.onlinePayment")}
                    </option>
                  ) : null}
                </select>
              </label>
              <label>
                {uiText(locale, "checkout.manualChannel")}
                <select defaultValue="BKASH" name="manualPaymentMethod">
                  <option value="BKASH">bKash</option>
                  <option value="NAGAD">Nagad</option>
                  <option value="ROCKET">Rocket</option>
                  <option value="BANK_TRANSFER">
                    {uiText(locale, "checkout.bankTransfer")}
                  </option>
                  <option value="OTHER">
                    {uiText(locale, "checkout.other")}
                  </option>
                </select>
              </label>
              <label>
                {uiText(locale, "checkout.paymentReference")}
                <input
                  name="manualPaymentReference"
                  placeholder={uiText(
                    locale,
                    "checkout.paymentReferencePlaceholder",
                  )}
                />
              </label>
              <label className="span-2">
                {uiText(locale, "checkout.orderNote")}
                <textarea name="customerNote" rows={3} />
              </label>
            </div>
            {!canUseOnlineGateway ? (
              <p className="muted-copy">
                {uiText(locale, "checkout.gatewayNote")}
              </p>
            ) : null}
            <button
              className="ui-button ui-button-primary"
              disabled={!items.length || !shipping.length}
              type="submit"
            >
              {uiText(locale, "checkout.placeOrder")}
            </button>
          </form>
        </SectionCard>
        <aside className="commerce-order-summary">
          <h2>{uiText(locale, "checkout.summary")}</h2>
          <div>
            <span>{uiText(locale, "checkout.items")}</span>
            <strong>
              {new Intl.NumberFormat(numberLocale).format(items.length)}
            </strong>
          </div>
          <div>
            <span>{uiText(locale, "cart.subtotal")}</span>
            <strong>{formatMoney(subtotal, "BDT", numberLocale)}</strong>
          </div>
          <p>{uiText(locale, "checkout.finalNote")}</p>
        </aside>
      </div>
    </div>
  );
}
