import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import { AuthAlert, AuthShell } from "@/components/auth/auth-shell";
import { getCurrentSession, hasVerifiedContact } from "@/lib/auth/session";
import { safeReturnTo } from "@/lib/auth/request";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

function mask(value: string): string {
  if (value.includes("@")) {
    const [local, domain] = value.split("@");
    return `${local?.slice(0, 2) ?? ""}***@${domain}`;
  }
  return `${value.slice(0, 3)}*****${value.slice(-3)}`;
}

export default async function VerifyPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    success?: string;
    sent?: string;
    token?: string;
    returnTo?: string;
    channel?: string;
  }>;
}) {
  const params = await searchParams;
  const { locale } = await getUiPreferences();
  const returnTo = safeReturnTo(params.returnTo ?? null);
  const session = await getCurrentSession();
  const requestedChannel =
    params.channel === "phone"
      ? "phone"
      : params.channel === "email"
        ? "email"
        : null;

  if (!session && !params.token)
    redirect("/login?error=Sign+in+to+verify+your+account.");

  const canVerifyEmail = Boolean(
    session?.user.email && !session.user.emailVerifiedAt,
  );
  const canVerifyPhone = Boolean(
    session?.user.phone && !session.user.phoneVerifiedAt,
  );
  const selectedChannel =
    requestedChannel === "phone" && canVerifyPhone
      ? "phone"
      : requestedChannel === "email" && canVerifyEmail
        ? "email"
        : canVerifyEmail
          ? "email"
          : canVerifyPhone
            ? "phone"
            : null;
  if (
    session &&
    hasVerifiedContact(session.user) &&
    !params.token &&
    !selectedChannel
  )
    redirect(returnTo);

  const target =
    selectedChannel === "email"
      ? (session?.user.email ?? "your email")
      : selectedChannel === "phone"
        ? (session?.user.phone ?? "your phone")
        : "the contact linked to this verification link";
  const description =
    locale === "bn"
      ? `${mask(target)}-এ পাঠানো ৬-digit code দিন অথবা secure verification link ব্যবহার করুন।`
      : `Enter the 6-digit code sent to ${mask(target)} or use the secure verification link.`;

  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.verificationEyebrow")}
      title={uiText(locale, "auth.verifyContact")}
      description={description}
      footer={
        <p>
          {uiText(locale, "auth.needHelp")}{" "}
          <Link href="/">{uiText(locale, "auth.contactSupport")}</Link>
        </p>
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      {params.success ? (
        <AuthAlert type="success">{params.success}</AuthAlert>
      ) : null}
      {params.sent ? (
        <AuthAlert type="info">{uiText(locale, "auth.codeSent")}</AuthAlert>
      ) : null}
      <AuthRedirectForm action="/api/auth/verify" className="auth-form">
        <input name="returnTo" type="hidden" value={returnTo} />
        {selectedChannel ? (
          <input name="channel" type="hidden" value={selectedChannel} />
        ) : null}
        {params.token ? (
          <input name="token" type="hidden" value={params.token} />
        ) : (
          <label className="auth-field">
            <span>{uiText(locale, "auth.verificationCode")}</span>
            <input
              autoComplete="one-time-code"
              inputMode="numeric"
              maxLength={6}
              minLength={6}
              name="code"
              pattern="[0-9]{6}"
              placeholder="000000"
              required
            />
          </label>
        )}
        <button className="public-primary-button auth-submit" type="submit">
          {params.token
            ? uiText(locale, "auth.verifyLink")
            : uiText(locale, "auth.verifyAccount")}
        </button>
      </AuthRedirectForm>
      {session && selectedChannel ? (
        <AuthRedirectForm
          action="/api/auth/resend-verification"
          className="auth-secondary-form"
        >
          <input name="channel" type="hidden" value={selectedChannel} />
          <button type="submit">{uiText(locale, "auth.sendNewCode")}</button>
        </AuthRedirectForm>
      ) : null}
    </AuthShell>
  );
}
