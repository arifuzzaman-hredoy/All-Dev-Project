import Link from "next/link";
import {
  AppointmentStatusBadge,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAdminSession } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import {
  appointmentAccessWhere,
  doctorAccessWhere,
  patientAccessWhere,
} from "@/lib/appointments/access";
import {
  dateInputToUtc,
  formatDisplayTime,
  todayInDhaka,
} from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const session = await requireAdminSession("/admin");
  const today = dateInputToUtc(todayInDhaka());
  const canViewAppointments = hasPermission(
    session.user,
    "healthcare.appointments.appointment.view",
  );
  const canViewDoctors = hasPermission(
    session.user,
    "healthcare.doctors.doctor.view",
  );
  const canViewPatients = hasPermission(
    session.user,
    "healthcare.patients.patient.view",
  );
  const appointmentScope = canViewAppointments
    ? appointmentAccessWhere(session.user)
    : { id: "__permission_denied__" };
  const doctorScope = canViewDoctors
    ? doctorAccessWhere(session.user)
    : { id: "__permission_denied__" };
  const patientScope = canViewPatients
    ? patientAccessWhere(session.user)
    : { id: "__permission_denied__" };
  const [appointments, activeDoctors, activePatients, pending, completed] =
    await Promise.all([
      db.appointment.findMany({
        where: { AND: [appointmentScope, { appointmentDate: today }] },
        include: { doctor: true },
        orderBy: { startTime: "asc" },
        take: 12,
      }),
      db.doctorProfile.count({
        where: { AND: [doctorScope, { status: "ACTIVE" }] },
      }),
      db.patientProfile.count({
        where: { AND: [patientScope, { status: "ACTIVE" }] },
      }),
      db.appointment.count({
        where: { AND: [appointmentScope, { status: "PENDING" }] },
      }),
      db.appointment.count({
        where: {
          AND: [
            appointmentScope,
            { appointmentDate: today, status: "COMPLETED" },
          ],
        },
      }),
    ]);
  const activeQueue = appointments.filter(
    (item) => !["COMPLETED", "CANCELLED", "NO_SHOW"].includes(item.status),
  ).length;

  return (
    <>
      <PageHeader
        breadcrumbs={[{ label: "Admin" }, { label: "Dashboard" }]}
        description="Live healthcare operations with doctor availability, appointment queue, patient records, and permission-aware actions."
        eyebrow="Operations workspace"
        title="Admin dashboard"
        actions={
          <ButtonLink
            href="/admin/healthcare/appointments/create"
            icon="appointment"
          >
            New appointment
          </ButtonLink>
        }
      />
      <section
        className="metric-grid metric-grid-four"
        aria-label="Operational summary"
      >
        <MetricCard
          label="Today's queue"
          value={String(activeQueue)}
          helper={`${pending} pending overall`}
          icon="appointment"
          tone="health"
        />
        <MetricCard
          label="Active doctors"
          value={String(activeDoctors)}
          helper="Publicly bookable"
          icon="doctor"
          tone="success"
        />
        <MetricCard
          label="Active patients"
          value={String(activePatients)}
          helper="Appointment records"
          icon="users"
          tone="neutral"
        />
        <MetricCard
          label="Completed today"
          value={String(completed)}
          helper="Consultations"
          icon="activity"
          tone="learning"
        />
      </section>
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            title="Today's appointment queue"
            description="Real appointment data ordered by consultation time."
            action={
              <ButtonLink
                href="/admin/healthcare/appointments/schedule"
                variant="quiet"
              >
                View full schedule
              </ButtonLink>
            }
          >
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Time</th>
                    <th>Serial</th>
                    <th>Status</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {appointments.map((appointment) => (
                    <tr key={appointment.id}>
                      <td>
                        <strong>{appointment.patientName}</strong>
                        <span>
                          {appointment.code} · {appointment.serviceType}
                        </span>
                      </td>
                      <td>
                        <div className="table-person">
                          <DoctorAvatar
                            imageUrl={appointment.doctor.imageUrl}
                            name={appointment.doctor.name}
                            size="small"
                          />
                          <div>
                            <strong>{appointment.doctor.name}</strong>
                            <span>{appointment.doctor.specialization}</span>
                          </div>
                        </div>
                      </td>
                      <td>{formatDisplayTime(appointment.startTime)}</td>
                      <td>
                        {appointment.serialNumber
                          ? `#${appointment.serialNumber}`
                          : "—"}
                      </td>
                      <td>
                        <AppointmentStatusBadge status={appointment.status} />
                      </td>
                      <td>
                        <Link
                          className="table-action-link"
                          href={`/admin/healthcare/appointments/${appointment.id}`}
                        >
                          Open
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {appointments.length === 0 ? (
                <div className="table-empty">
                  No appointment has been booked for today.
                </div>
              ) : null}
            </div>
          </SectionCard>
          <SectionCard
            title="Healthcare workflow"
            description="Healthcare operational readiness."
          >
            <div className="timeline-list">
              <article className="timeline-item">
                <span className="timeline-dot timeline-health" />
                <div>
                  <strong>Public booking is live</strong>
                  <p>
                    Authenticated patients can select real doctor availability
                    and request appointments.
                  </p>
                </div>
              </article>
              <article className="timeline-item">
                <span className="timeline-dot timeline-health" />
                <div>
                  <strong>Double booking is protected</strong>
                  <p>
                    Serializable database transactions and unique slot capacity
                    constraints guard every booking.
                  </p>
                </div>
              </article>
              <article className="timeline-item">
                <span className="timeline-dot timeline-health" />
                <div>
                  <strong>Patient history is linked</strong>
                  <p>
                    Dashboard users see upcoming appointments, history, and
                    cancellation state.
                  </p>
                </div>
              </article>
            </div>
          </SectionCard>
        </div>
        <div className="content-stack">
          <SectionCard
            title="Quick actions"
            description="Common healthcare operations."
          >
            <div className="quick-action-grid">
              <ButtonLink
                href="/admin/healthcare/appointments/create"
                icon="appointment"
                variant="secondary"
              >
                New appointment
              </ButtonLink>
              <ButtonLink
                href="/admin/healthcare/doctors/create"
                icon="doctor"
                variant="secondary"
              >
                Add doctor
              </ButtonLink>
              <ButtonLink
                href="/admin/healthcare/schedules"
                icon="calendar"
                variant="secondary"
              >
                Manage schedules
              </ButtonLink>
              <ButtonLink
                href="/admin/healthcare/patients"
                icon="users"
                variant="secondary"
              >
                Patient list
              </ButtonLink>
            </div>
          </SectionCard>
          <SectionCard
            title="System status"
            description="Live local-only production operations."
          >
            <div className="status-list">
              <div>
                <span>Application</span>
                <StatusBadge tone="success">Online</StatusBadge>
              </div>
              <div>
                <span>PostgreSQL</span>
                <StatusBadge tone="success">Connected</StatusBadge>
              </div>
              <div>
                <span>Appointment module</span>
                <StatusBadge tone="success">Live</StatusBadge>
              </div>
              <div>
                <span>Monitoring</span>
                <StatusBadge tone="success">Active</StatusBadge>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Needs attention">
            <div className="task-list">
              <article className="task-item">
                <div>
                  <strong>
                    {pending} pending appointment request
                    {pending === 1 ? "" : "s"}
                  </strong>
                  <span>Healthcare</span>
                </div>
                <StatusBadge tone={pending ? "warning" : "success"}>
                  {pending ? "Review" : "Clear"}
                </StatusBadge>
              </article>
              <article className="task-item">
                <div>
                  <strong>Doctor schedules</strong>
                  <span>Keep leave and special availability current.</span>
                </div>
                <Link
                  className="table-action-link"
                  href="/admin/healthcare/schedules"
                >
                  Manage
                </Link>
              </article>
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
