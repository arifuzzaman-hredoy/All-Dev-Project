import {
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireGlobalPermission } from "@/lib/auth/authorization";
import { operationsSnapshot } from "@/lib/operations/queries";

export const dynamic = "force-dynamic";

function ageLabel(date: Date | null | undefined): string {
  if (!date) return "Never reported";
  const hours = Math.max(
    0,
    Math.floor((Date.now() - date.getTime()) / 3_600_000),
  );
  if (hours < 1) return "Less than 1 hour ago";
  if (hours < 48) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function runTone(status: string): "success" | "danger" | "warning" | "neutral" {
  if (status === "SUCCEEDED") return "success";
  if (status === "FAILED") return "danger";
  if (status === "RUNNING") return "warning";
  return "neutral";
}

export default async function BackupOperationsPage() {
  await requireGlobalPermission(
    "system.operations.backup.view",
    "/admin/operations/backups",
  );
  const data = await operationsSnapshot();

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Disaster recovery"
        title="Backup & restore assurance"
        description="Runtime evidence reported by encrypted off-site backup, restore verification, and repository integrity jobs."
      />

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="file"
          label="Latest backup"
          value={ageLabel(data.latestBackup?.finishedAt)}
          helper={
            data.latestBackup?.snapshotId
              ? `Snapshot ${data.latestBackup.snapshotId.slice(0, 12)}`
              : "No telemetry yet"
          }
          tone={data.latestBackup ? "success" : "warning"}
        />
        <MetricCard
          icon="activity"
          label="Restore verification"
          value={ageLabel(data.latestRestoreTest?.finishedAt)}
          helper="Weekly isolated restore"
          tone={data.latestRestoreTest ? "success" : "warning"}
        />
        <MetricCard
          icon="shield"
          label="Repository check"
          value={ageLabel(data.latestRepositoryCheck?.finishedAt)}
          helper="Metadata + rotating data subset"
          tone={data.latestRepositoryCheck ? "success" : "warning"}
        />
        <MetricCard
          icon="reports"
          label="30-day failures"
          value={String(data.recentFailures)}
          helper="Operational jobs"
          tone={data.recentFailures ? "warning" : "success"}
        />
      </div>

      <div className="two-column-grid">
        <SectionCard title="Recovery policy">
          <div className="settings-list">
            <div>
              <span>
                <strong>Encrypted off-site backup</strong>
                <small>
                  Daily, PostgreSQL custom-format dump + release manifest.
                </small>
              </span>
            </div>
            <div>
              <span>
                <strong>Retention</strong>
                <small>
                  Last 2 + 7 daily + 4 weekly + 6 monthly + 2 yearly snapshots.
                </small>
              </span>
            </div>
            <div>
              <span>
                <strong>Restore verification</strong>
                <small>
                  Weekly restore into an isolated temporary database with
                  critical-table checks.
                </small>
              </span>
            </div>
            <div>
              <span>
                <strong>Repository integrity</strong>
                <small>
                  Weekly restic metadata check with rotating 10% data
                  verification.
                </small>
              </span>
            </div>
          </div>
        </SectionCard>
        <SectionCard title="Safety boundary">
          <p>
            Restore actions remain terminal-only and require the explicit
            destructive confirmation token. This admin page is intentionally
            read-only.
          </p>
          <p>
            Operational telemetry contains status, timestamps, snapshot
            identifiers, release SHA, and bounded metadata—not database
            contents, credentials, or backup encryption keys.
          </p>
        </SectionCard>
      </div>

      <SectionCard title="Recent operational runs">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Started</th>
                <th>Kind</th>
                <th>Status</th>
                <th>Host / release</th>
                <th>Summary</th>
              </tr>
            </thead>
            <tbody>
              {data.recentRuns.map((run) => (
                <tr key={run.id}>
                  <td>
                    <strong>{run.startedAt.toLocaleDateString("en-BD")}</strong>
                    <span>{run.startedAt.toLocaleTimeString("en-BD")}</span>
                  </td>
                  <td>{run.kind}</td>
                  <td>
                    <StatusBadge tone={runTone(run.status)}>
                      {run.status}
                    </StatusBadge>
                  </td>
                  <td>
                    <strong>{run.host ?? "—"}</strong>
                    <span>{run.release?.slice(0, 12) ?? ""}</span>
                  </td>
                  <td>
                    <strong>{run.summary ?? "—"}</strong>
                    <span>
                      {run.snapshotId
                        ? `Snapshot ${run.snapshotId.slice(0, 16)}`
                        : ""}
                    </span>
                  </td>
                </tr>
              ))}
              {!data.recentRuns.length ? (
                <tr>
                  <td colSpan={5}>
                    No operational backup telemetry has been reported yet.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
