import { AppointmentFlash } from "@/components/appointments/appointment-ui";
import {
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function MedicalDepartmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  await requirePermission(
    "healthcare.doctors.department.view",
    "/admin/healthcare/departments",
  );
  const [params, departments] = await Promise.all([
    searchParams,
    db.medicalDepartment.findMany({
      include: { _count: { select: { doctors: true, appointments: true } } },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
  ]);
  const active = departments.filter((item) => item.isActive).length;
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Departments" },
        ]}
        description="Create and order the clinical departments used by doctors, appointments, and public filters."
        eyebrow="Medical structure"
        title="Medical departments"
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <section className="metric-grid metric-grid-four">
        <MetricCard
          helper="Available for new doctors"
          icon="activity"
          label="Active"
          tone="health"
          value={String(active)}
        />
        <MetricCard
          helper="Hidden from public filters"
          icon="file"
          label="Archived"
          value={String(departments.length - active)}
        />
        <MetricCard
          helper="Across all departments"
          icon="doctor"
          label="Doctors"
          tone="success"
          value={String(
            departments.reduce((sum, item) => sum + item._count.doctors, 0),
          )}
        />
        <MetricCard
          helper="Preserved history"
          icon="appointment"
          label="Appointments"
          value={String(
            departments.reduce(
              (sum, item) => sum + item._count.appointments,
              0,
            ),
          )}
        />
      </section>
      <div className="content-grid content-grid-main">
        <SectionCard
          description="Codes and slugs are stable identifiers. Archive instead of deleting a department with history."
          title="Department directory"
        >
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Department</th>
                  <th>Code</th>
                  <th>Order</th>
                  <th>Doctors</th>
                  <th>Appointments</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {departments.map((department) => (
                  <tr key={department.id}>
                    <td>
                      <strong>{department.name}</strong>
                      <span>
                        {department.nameBn ?? "বাংলা নাম যোগ করা হয়নি"}
                      </span>
                      <span>
                        {department.description ?? "No English description"}
                      </span>
                      <span>
                        {department.descriptionBn ?? "বাংলা বিবরণ যোগ করা হয়নি"}
                      </span>
                    </td>
                    <td>
                      <strong>{department.code}</strong>
                      <span>/{department.slug}</span>
                    </td>
                    <td>{department.displayOrder}</td>
                    <td>{department._count.doctors}</td>
                    <td>{department._count.appointments}</td>
                    <td>
                      <StatusBadge
                        tone={department.isActive ? "success" : "neutral"}
                      >
                        {department.isActive ? "Active" : "Archived"}
                      </StatusBadge>
                    </td>
                    <td>
                      <details className="table-action-details">
                        <summary>Edit</summary>
                        <form
                          action={`/api/admin/healthcare/departments/${department.id}`}
                          className="admin-form-stack table-action-form"
                          method="post"
                        >
                          <label className="form-field">
                            <span>Name (English)</span>
                            <input
                              defaultValue={department.name}
                              maxLength={100}
                              name="name"
                              required
                            />
                          </label>
                          <label className="form-field">
                            <span>নাম (বাংলা)</span>
                            <input
                              defaultValue={department.nameBn ?? ""}
                              maxLength={100}
                              name="nameBn"
                            />
                          </label>
                          <label className="form-field">
                            <span>Code</span>
                            <input
                              defaultValue={department.code}
                              maxLength={40}
                              name="code"
                              required
                            />
                          </label>
                          <label className="form-field">
                            <span>Slug</span>
                            <input
                              defaultValue={department.slug}
                              maxLength={80}
                              name="slug"
                              required
                            />
                          </label>
                          <label className="form-field">
                            <span>Description (English)</span>
                            <textarea
                              defaultValue={department.description ?? ""}
                              maxLength={500}
                              name="description"
                              rows={3}
                            />
                          </label>
                          <label className="form-field">
                            <span>বিবরণ (বাংলা)</span>
                            <textarea
                              defaultValue={department.descriptionBn ?? ""}
                              maxLength={500}
                              name="descriptionBn"
                              rows={3}
                            />
                          </label>
                          <label className="form-field">
                            <span>Order</span>
                            <input
                              defaultValue={department.displayOrder}
                              min={0}
                              name="displayOrder"
                              type="number"
                            />
                          </label>
                          <button
                            className="ui-button ui-button-primary"
                            type="submit"
                          >
                            Save
                          </button>
                        </form>
                      </details>
                      {department.isActive ? (
                        <form
                          action={`/api/admin/healthcare/departments/${department.id}/archive`}
                          method="post"
                        >
                          <button
                            className="ui-button ui-button-quiet"
                            type="submit"
                          >
                            Archive
                          </button>
                        </form>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
        <SectionCard
          description="This form creates a public-filterable medical department."
          title="Add department"
        >
          <form
            action="/api/admin/healthcare/departments"
            className="admin-form-stack"
            method="post"
          >
            <label className="form-field">
              <span>Name (English)</span>
              <input maxLength={100} name="name" required />
            </label>
            <label className="form-field">
              <span>নাম (বাংলা)</span>
              <input maxLength={100} name="nameBn" />
            </label>
            <label className="form-field">
              <span>Code</span>
              <input
                maxLength={40}
                name="code"
                placeholder="CARDIOLOGY"
                required
              />
            </label>
            <label className="form-field">
              <span>Public slug</span>
              <input maxLength={80} name="slug" placeholder="cardiology" />
            </label>
            <label className="form-field">
              <span>Description (English)</span>
              <textarea maxLength={500} name="description" rows={4} />
            </label>
            <label className="form-field">
              <span>বিবরণ (বাংলা)</span>
              <textarea maxLength={500} name="descriptionBn" rows={4} />
            </label>
            <label className="form-field">
              <span>Display order</span>
              <input
                defaultValue={100}
                min={0}
                name="displayOrder"
                type="number"
              />
            </label>
            <button className="ui-button ui-button-primary" type="submit">
              Create department
            </button>
          </form>
        </SectionCard>
      </div>
    </>
  );
}
