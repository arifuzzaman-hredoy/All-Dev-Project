import { notFound } from "next/navigation";
import { writeAuditLog } from "@/lib/auth/audit";
import { requirePermission } from "@/lib/auth/authorization";
import { formatDisplayDate } from "@/lib/appointments/time";
import { getAdminPrescription } from "@/lib/clinical/queries";
import { prescriptionStatusLabel } from "@/lib/clinical/status";

export const dynamic = "force-dynamic";

export default async function PrescriptionPrintPage({
  params,
}: {
  params: Promise<{ prescriptionId: string }>;
}) {
  const session = await requirePermission(
    "healthcare.prescriptions.prescription.print",
    "/admin/healthcare/prescriptions",
  );
  const { prescriptionId } = await params;
  const prescription = await getAdminPrescription(session.user, prescriptionId);
  if (!prescription) notFound();
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "PrescriptionPrint",
    targetId: prescription.id,
    metadata: { status: prescription.status, version: prescription.version },
  });
  return (
    <main className="appointment-print-page">
      <section className="appointment-print-sheet prescription-print-sheet">
        <header>
          <div>
            <span>HOLY LIFE</span>
            <h1>Prescription</h1>
            <p>Doctor-led Health, Fitness & Wellness · Rangpur</p>
          </div>
          <div>
            <strong>{prescription.code}</strong>
            <span>
              Version {prescription.version} ·{" "}
              {prescriptionStatusLabel(prescription.status)}
            </span>
          </div>
        </header>
        {prescription.status !== "SIGNED" ? (
          <div className="notice-box">
            <strong>Not a finalized prescription</strong>
            <p>
              This copy is{" "}
              {prescriptionStatusLabel(prescription.status).toLowerCase()} and
              should not be treated as a signed clinical instruction.
            </p>
          </div>
        ) : null}
        <div className="appointment-print-grid">
          <div>
            <span>Patient</span>
            <strong>{prescription.patient.name}</strong>
            <p>{prescription.patient.patientCode}</p>
            <p>{prescription.patient.phone}</p>
          </div>
          <div>
            <span>Doctor</span>
            <strong>{prescription.doctor.name}</strong>
            <p>{prescription.doctor.specialization}</p>
            <p>
              {prescription.doctor.qualifications ??
                prescription.doctor.department.name}
            </p>
          </div>
          <div>
            <span>Visit</span>
            <strong>
              {formatDisplayDate(prescription.appointment.appointmentDate)}
            </strong>
            <p>{prescription.appointment.code}</p>
            <p>{prescription.appointment.serviceType}</p>
          </div>
          <div>
            <span>Follow-up</span>
            <strong>
              {prescription.followUpDate
                ? formatDisplayDate(prescription.followUpDate)
                : "As advised"}
            </strong>
            <p>
              Signed{" "}
              {prescription.signedAt
                ? prescription.signedAt.toLocaleString("en-GB", {
                    timeZone: "Asia/Dhaka",
                  })
                : "—"}
            </p>
          </div>
        </div>
        <div className="appointment-print-note">
          <span>Diagnosis</span>
          <p>{prescription.diagnosis ?? "Not recorded"}</p>
        </div>
        <table className="prescription-print-table">
          <thead>
            <tr>
              <th>Medicine</th>
              <th>Dose & route</th>
              <th>Frequency</th>
              <th>Duration</th>
              <th>Instructions</th>
            </tr>
          </thead>
          <tbody>
            {prescription.items.map((item) => (
              <tr key={item.id}>
                <td>
                  <strong>{item.medicineName}</strong>
                  <small>
                    {[item.genericName, item.strength]
                      .filter(Boolean)
                      .join(" · ")}
                  </small>
                </td>
                <td>
                  {item.dose}
                  {item.route ? ` · ${item.route}` : ""}
                </td>
                <td>{item.frequency}</td>
                <td>
                  {item.duration}
                  {item.quantity ? ` · Qty ${item.quantity}` : ""}
                </td>
                <td>{item.instructions ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="appointment-print-note">
          <span>Advice</span>
          <p>{prescription.advice ?? "—"}</p>
        </div>
        <footer>
          <p>
            {prescription.status === "SIGNED"
              ? `Signed in Holy Life by authenticated account: ${prescription.signedBy?.name ?? prescription.doctor.name}.`
              : "Draft/voided versions are retained for clinical audit history."}
          </p>
          <p>
            Printed{" "}
            {new Date().toLocaleString("en-GB", { timeZone: "Asia/Dhaka" })}
          </p>
        </footer>
      </section>
      <div className="appointment-print-actions">
        Use Ctrl+P to print or save as PDF.
      </div>
    </main>
  );
}
