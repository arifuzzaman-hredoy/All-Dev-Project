import { notFound } from "next/navigation";
import { ClinicalFlash } from "@/components/clinical/clinical-flash";
import { PrescriptionFormFields } from "@/components/clinical/prescription-form";
import { ButtonLink, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import {
  appointmentAccessWhere,
  patientAccessWhere,
} from "@/lib/appointments/access";
import { formatDisplayDate, utcDateToInput } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function CreatePrescriptionPage({
  searchParams,
}: {
  searchParams: Promise<{
    appointmentId?: string;
    patientId?: string;
    error?: string;
  }>;
}) {
  const session = await requirePermission(
    "healthcare.prescriptions.prescription.create",
    "/admin/healthcare/prescriptions",
  );
  const params = await searchParams;
  const patientId = params.patientId?.trim() || undefined;
  const appointments = await db.appointment.findMany({
    where: {
      AND: [
        appointmentAccessWhere(
          session.user,
          "healthcare.prescriptions.prescription.create",
        ),
        patientId
          ? {
              patientId,
              patient: patientAccessWhere(
                session.user,
                "healthcare.prescriptions.prescription.create",
              ),
            }
          : {},
        { status: { in: ["CHECKED_IN", "IN_CONSULTATION", "COMPLETED"] } },
      ],
    },
    include: {
      patient: true,
      doctor: true,
      clinicalEncounter: true,
      prescriptions: { select: { id: true } },
    },
    orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
    take: 100,
  });
  const available = appointments.filter(
    (appointment) => appointment.prescriptions.length === 0,
  );
  const selectedId = params.appointmentId ?? available[0]?.id;
  const selected = selectedId
    ? available.find((appointment) => appointment.id === selectedId)
    : undefined;
  if (params.appointmentId && !selected) notFound();
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Prescriptions", href: "/admin/healthcare/prescriptions" },
          { label: "Create" },
        ]}
        description="Start from a checked-in, in-consultation, or completed appointment. The assigned doctor remains the prescription author."
        eyebrow="Prescription draft"
        title="Create prescription"
        actions={
          <ButtonLink href="/admin/healthcare/prescriptions" variant="quiet">
            Back to prescriptions
          </ButtonLink>
        }
      />
      <ClinicalFlash error={params.error} />
      <SectionCard title="Select visit">
        <form className="filter-inline-form" method="get">
          <select
            defaultValue={selected?.id ?? ""}
            name="appointmentId"
            required
          >
            <option disabled value="">
              Select appointment
            </option>
            {available.map((appointment) => (
              <option key={appointment.id} value={appointment.id}>
                {appointment.code} · {appointment.patient.name} ·{" "}
                {formatDisplayDate(appointment.appointmentDate)} ·{" "}
                {appointment.doctor.name}
              </option>
            ))}
          </select>
          <button className="ui-button ui-button-secondary" type="submit">
            Load visit
          </button>
        </form>
      </SectionCard>
      {selected ? (
        <SectionCard
          description={`${selected.patient.name} · ${selected.patient.patientCode} · ${selected.doctor.name}`}
          title={selected.code}
        >
          <form
            action="/api/admin/healthcare/prescriptions"
            className="admin-form-stack"
            method="post"
          >
            <PrescriptionFormFields
              appointmentId={selected.id}
              advice={selected.clinicalEncounter?.advice}
              diagnosis={selected.clinicalEncounter?.diagnosis}
              followUpDate={
                selected.clinicalEncounter?.followUpDate
                  ? utcDateToInput(selected.clinicalEncounter.followUpDate)
                  : null
              }
              notes={selected.clinicalEncounter?.clinicalNotes}
            />
            <button className="ui-button ui-button-primary" type="submit">
              Create draft
            </button>
          </form>
        </SectionCard>
      ) : (
        <SectionCard title="No eligible visit">
          <p className="muted-copy">
            No accessible checked-in/completed appointment without an existing
            prescription is available.
          </p>
        </SectionCard>
      )}
    </>
  );
}
