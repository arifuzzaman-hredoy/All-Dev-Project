import Link from "next/link";
import { notFound } from "next/navigation";
import { ClinicalFlash } from "@/components/clinical/clinical-flash";
import { PrescriptionFormFields } from "@/components/clinical/prescription-form";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { formatDisplayDate, utcDateToInput } from "@/lib/appointments/time";
import { getAdminPrescription } from "@/lib/clinical/queries";
import {
  prescriptionStatusLabel,
  prescriptionStatusTone,
} from "@/lib/clinical/status";

export const dynamic = "force-dynamic";

export default async function PrescriptionDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ prescriptionId: string }>;
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.prescriptions.prescription.view",
    "/admin/healthcare/prescriptions",
  );
  const [{ prescriptionId }, query] = await Promise.all([params, searchParams]);
  const prescription = await getAdminPrescription(session.user, prescriptionId);
  if (!prescription) notFound();
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "Prescription",
    targetId: prescription.id,
    metadata: { status: prescription.status, version: prescription.version },
  });
  const canViewClinicalRecord = hasPermission(
    session.user,
    "healthcare.patients.clinical-record.view",
  );
  const canEdit =
    hasPermission(session.user, "healthcare.prescriptions.prescription.edit") &&
    prescription.status === "DRAFT";
  const canSign =
    hasPermission(session.user, "healthcare.prescriptions.prescription.sign") &&
    prescription.status === "DRAFT" &&
    (session.user.isSuperAdmin ||
      prescription.doctor.userId === session.user.id);
  const canRevise =
    hasPermission(session.user, "healthcare.prescriptions.prescription.edit") &&
    (prescription.status === "SIGNED" || prescription.status === "VOIDED");
  const canFinalizeSigned =
    hasPermission(session.user, "healthcare.prescriptions.prescription.sign") &&
    prescription.status === "SIGNED" &&
    (session.user.isSuperAdmin ||
      prescription.doctor.userId === session.user.id);
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Prescriptions", href: "/admin/healthcare/prescriptions" },
          { label: prescription.code },
        ]}
        description={`${prescription.patient.name} · ${prescription.doctor.name} · Version ${prescription.version}`}
        eyebrow="Prescription record"
        title={prescription.code}
        actions={
          <div className="page-action-group">
            <ButtonLink
              href={`/admin/healthcare/prescriptions/${prescription.id}/print`}
              icon="file"
              variant="secondary"
            >
              Print
            </ButtonLink>
            {canViewClinicalRecord ? (
              <ButtonLink
                href={`/admin/healthcare/patients/${prescription.patientId}`}
                icon="users"
                variant="quiet"
              >
                Patient record
              </ButtonLink>
            ) : null}
          </div>
        }
      />
      <ClinicalFlash error={query.error} success={query.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            action={
              <StatusBadge tone={prescriptionStatusTone(prescription.status)}>
                {prescriptionStatusLabel(prescription.status)}
              </StatusBadge>
            }
            description="Signed versions are locked. A correction must be created as a new revision."
            title={`Version ${prescription.version}`}
          >
            {canEdit ? (
              <form
                action={`/api/admin/healthcare/prescriptions/${prescription.id}`}
                className="admin-form-stack"
                method="post"
              >
                <PrescriptionFormFields
                  appointmentId={prescription.appointmentId}
                  advice={prescription.advice}
                  diagnosis={prescription.diagnosis}
                  followUpDate={
                    prescription.followUpDate
                      ? utcDateToInput(prescription.followUpDate)
                      : null
                  }
                  items={prescription.items}
                  notes={prescription.notes}
                />
                <button className="ui-button ui-button-primary" type="submit">
                  Save draft
                </button>
              </form>
            ) : (
              <>
                <div className="appointment-detail-copy">
                  <div>
                    <span>Diagnosis</span>
                    <p>{prescription.diagnosis ?? "Not recorded"}</p>
                  </div>
                  <div>
                    <span>Clinical notes</span>
                    <p>{prescription.notes ?? "Not recorded"}</p>
                  </div>
                  <div>
                    <span>Advice</span>
                    <p>{prescription.advice ?? "Not recorded"}</p>
                  </div>
                  <div>
                    <span>Follow-up</span>
                    <p>
                      {prescription.followUpDate
                        ? formatDisplayDate(prescription.followUpDate)
                        : "Not scheduled"}
                    </p>
                  </div>
                </div>
                <div className="data-table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Medicine</th>
                        <th>Dose</th>
                        <th>Frequency</th>
                        <th>Duration</th>
                        <th>Instructions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {prescription.items.map((item) => (
                        <tr key={item.id}>
                          <td>
                            <strong>{item.medicineName}</strong>
                            <span>
                              {[item.genericName, item.strength]
                                .filter(Boolean)
                                .join(" · ")}
                            </span>
                          </td>
                          <td>
                            {item.dose}
                            {item.route ? <span>{item.route}</span> : null}
                          </td>
                          <td>{item.frequency}</td>
                          <td>
                            {item.duration}
                            {item.quantity ? (
                              <span>Qty {item.quantity}</span>
                            ) : null}
                          </td>
                          <td>{item.instructions ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </SectionCard>
          {canSign ? (
            <SectionCard
              description="Signing permanently locks this version. Only the assigned doctor or primary Super Admin can perform this action."
              title="Clinical signature"
            >
              <form
                action={`/api/admin/healthcare/prescriptions/${prescription.id}/sign`}
                method="post"
              >
                <button className="ui-button ui-button-primary" type="submit">
                  Sign and lock prescription
                </button>
              </form>
            </SectionCard>
          ) : null}
          {canRevise ? (
            <SectionCard
              description="Signed and voided versions stay immutable. Create a new draft revision for corrections."
              title="Revision control"
            >
              <form
                action={`/api/admin/healthcare/prescriptions/${prescription.id}/revise`}
                method="post"
              >
                <button className="ui-button ui-button-secondary" type="submit">
                  Create revision
                </button>
              </form>
            </SectionCard>
          ) : null}
          {canFinalizeSigned ? (
            <SectionCard
              description="Voiding preserves the signed version and requires a clear audit reason."
              title="Signed-version control"
            >
              <form
                action={`/api/admin/healthcare/prescriptions/${prescription.id}/void`}
                className="admin-form-stack"
                method="post"
              >
                <label className="form-field">
                  <span>Void reason</span>
                  <textarea
                    maxLength={1000}
                    name="voidReason"
                    required
                    rows={3}
                  />
                </label>
                <button className="ui-button ui-button-quiet" type="submit">
                  Void signed version
                </button>
              </form>
            </SectionCard>
          ) : null}
        </div>
        <div className="content-stack">
          <SectionCard title="Visit">
            <div className="status-list">
              <div>
                <span>Appointment</span>
                <Link
                  href={`/admin/healthcare/appointments/${prescription.appointmentId}`}
                >
                  <strong>{prescription.appointment.code}</strong>
                </Link>
              </div>
              <div>
                <span>Date</span>
                <strong>
                  {formatDisplayDate(prescription.appointment.appointmentDate)}
                </strong>
              </div>
              <div>
                <span>Department</span>
                <strong>{prescription.appointment.department.name}</strong>
              </div>
              <div>
                <span>Doctor</span>
                <strong>{prescription.doctor.name}</strong>
              </div>
              <div>
                <span>Patient</span>
                <strong>{prescription.patient.name}</strong>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Version history">
            <div className="content-stack">
              {prescription.supersedes ? (
                <div className="notice-box">
                  <span>Supersedes</span>
                  <Link
                    href={`/admin/healthcare/prescriptions/${prescription.supersedes.id}`}
                  >
                    {prescription.supersedes.code} · v
                    {prescription.supersedes.version}
                  </Link>
                </div>
              ) : null}
              {prescription.revisions.map((revision) => (
                <div className="notice-box" key={revision.id}>
                  <span>Revision</span>
                  <Link href={`/admin/healthcare/prescriptions/${revision.id}`}>
                    {revision.code} · v{revision.version} ·{" "}
                    {prescriptionStatusLabel(revision.status)}
                  </Link>
                </div>
              ))}
              {!prescription.supersedes &&
              prescription.revisions.length === 0 ? (
                <p className="muted-copy">No revisions.</p>
              ) : null}
            </div>
          </SectionCard>
          <SectionCard title="Signature & audit">
            <div className="status-list">
              <div>
                <span>Signed</span>
                <strong>
                  {prescription.signedAt
                    ? prescription.signedAt.toLocaleString("en-GB", {
                        timeZone: "Asia/Dhaka",
                      })
                    : "—"}
                </strong>
              </div>
              <div>
                <span>Signed by</span>
                <strong>{prescription.signedBy?.name ?? "—"}</strong>
              </div>
              {prescription.voidedAt ? (
                <>
                  <div>
                    <span>Voided</span>
                    <strong>
                      {prescription.voidedAt.toLocaleString("en-GB", {
                        timeZone: "Asia/Dhaka",
                      })}
                    </strong>
                  </div>
                  <div>
                    <span>Void reason</span>
                    <strong>{prescription.voidReason ?? "—"}</strong>
                  </div>
                </>
              ) : null}
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
