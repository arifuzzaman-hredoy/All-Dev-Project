import { redirect } from "next/navigation";
export default function PrescriptionHistoryPage() {
  redirect("/admin/healthcare/prescriptions?status=SIGNED");
}
