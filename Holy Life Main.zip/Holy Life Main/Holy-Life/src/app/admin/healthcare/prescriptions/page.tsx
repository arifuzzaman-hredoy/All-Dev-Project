import Link from "next/link";
import { ClinicalFlash } from "@/components/clinical/clinical-flash";
import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { formatDisplayDate } from "@/lib/appointments/time";
import { prescriptionAccessWhere } from "@/lib/clinical/access";
import {
  prescriptionStatusLabel,
  prescriptionStatusTone,
} from "@/lib/clinical/status";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function PrescriptionsPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    status?: string;
    success?: string;
    error?: string;
  }>;
}) {
  const session = await requirePermission(
    "healthcare.prescriptions.prescription.view",
    "/admin/healthcare/prescriptions",
  );
  const params = await searchParams;
  const q = params.q?.trim().slice(0, 100) ?? "";
  const status = ["DRAFT", "SIGNED", "VOIDED"].includes(params.status ?? "")
    ? (params.status as "DRAFT" | "SIGNED" | "VOIDED")
    : undefined;
  const where = {
    AND: [
      prescriptionAccessWhere(session.user),
      status ? { status } : {},
      q
        ? {
            OR: [
              { code: { contains: q, mode: "insensitive" as const } },
              {
                patient: {
                  name: { contains: q, mode: "insensitive" as const },
                },
              },
              { patient: { phone: { contains: q } } },
              {
                doctor: { name: { contains: q, mode: "insensitive" as const } },
              },
            ],
          }
        : {},
    ],
  };
  const [prescriptions, total, signed, drafts] = await Promise.all([
    db.prescription.findMany({
      where,
      include: {
        patient: true,
        doctor: true,
        appointment: true,
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 300,
    }),
    db.prescription.count({ where: prescriptionAccessWhere(session.user) }),
    db.prescription.count({
      where: {
        AND: [prescriptionAccessWhere(session.user), { status: "SIGNED" }],
      },
    }),
    db.prescription.count({
      where: {
        AND: [prescriptionAccessWhere(session.user), { status: "DRAFT" }],
      },
    }),
  ]);
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Prescriptions" },
        ]}
        description="Versioned prescription drafts, signatures, print views, and immutable history."
        eyebrow="Clinical prescribing"
        title="Prescriptions"
        actions={
          hasPermission(
            session.user,
            "healthcare.prescriptions.prescription.create",
          ) ? (
            <ButtonLink
              href="/admin/healthcare/prescriptions/create"
              icon="file"
            >
              Create prescription
            </ButtonLink>
          ) : undefined
        }
      />
      <ClinicalFlash error={params.error} success={params.success} />
      <section className="metric-grid metric-grid-four">
        <MetricCard
          helper="Accessible"
          icon="file"
          label="Prescriptions"
          tone="health"
          value={String(total)}
        />
        <MetricCard
          helper="Clinically finalized"
          icon="shield"
          label="Signed"
          tone="success"
          value={String(signed)}
        />
        <MetricCard
          helper="Editable"
          icon="clipboard"
          label="Drafts"
          tone="warning"
          value={String(drafts)}
        />
        <MetricCard
          helper="Current filter"
          icon="search"
          label="Listed"
          value={String(prescriptions.length)}
        />
      </section>
      <section className="filter-panel">
        <form className="filter-inline-form" method="get">
          <div className="filter-search-field">
            <span>⌕</span>
            <input
              defaultValue={q}
              name="q"
              placeholder="Code, patient, phone, doctor"
            />
          </div>
          <select defaultValue={status ?? ""} name="status">
            <option value="">All statuses</option>
            <option value="DRAFT">Draft</option>
            <option value="SIGNED">Signed</option>
            <option value="VOIDED">Voided</option>
          </select>
          <button className="ui-button ui-button-secondary" type="submit">
            Filter
          </button>
          <Link
            className="ui-button ui-button-quiet"
            href="/admin/healthcare/prescriptions"
          >
            Reset
          </Link>
        </form>
      </section>
      <SectionCard title="Prescription register">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Prescription</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Visit</th>
                <th>Medicines</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map((prescription) => (
                <tr key={prescription.id}>
                  <td>
                    <Link
                      href={`/admin/healthcare/prescriptions/${prescription.id}`}
                    >
                      <strong>{prescription.code}</strong>
                      <span>Version {prescription.version}</span>
                    </Link>
                  </td>
                  <td>
                    <strong>{prescription.patient.name}</strong>
                    <span>{prescription.patient.patientCode}</span>
                  </td>
                  <td>{prescription.doctor.name}</td>
                  <td>
                    <strong>
                      {formatDisplayDate(
                        prescription.appointment.appointmentDate,
                      )}
                    </strong>
                    <span>{prescription.appointment.code}</span>
                  </td>
                  <td>{prescription._count.items}</td>
                  <td>
                    <StatusBadge
                      tone={prescriptionStatusTone(prescription.status)}
                    >
                      {prescriptionStatusLabel(prescription.status)}
                    </StatusBadge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {prescriptions.length === 0 ? (
            <div className="table-empty">
              No prescriptions match this filter.
            </div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
