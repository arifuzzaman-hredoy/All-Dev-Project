import {
  AppointmentFlash,
  DoctorAvatar,
  SlotPicker,
} from "@/components/appointments/appointment-ui";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { doctorAccessWhere } from "@/lib/appointments/access";
import {
  getDoctorAvailability,
  listActiveDoctors,
} from "@/lib/appointments/queries";
import {
  addDaysToDateInput,
  compareDateInputs,
  isDateInput,
  todayInDhaka,
} from "@/lib/appointments/time";

export const dynamic = "force-dynamic";

export default async function CreateAppointmentPage({
  searchParams,
}: {
  searchParams: Promise<{
    doctorId?: string;
    date?: string;
    success?: string;
    error?: string;
  }>;
}) {
  const session = await requirePermission(
    "healthcare.appointments.appointment.create",
    "/admin/healthcare/appointments/create",
  );
  const params = await searchParams;
  const today = todayInDhaka();
  const maximumDate = addDaysToDateInput(today, 90);
  const requestedDate = isDateInput(params.date ?? "") ? params.date! : today;
  const date =
    compareDateInputs(requestedDate, today) >= 0 &&
    compareDateInputs(requestedDate, maximumDate) <= 0
      ? requestedDate
      : today;
  const doctors = await listActiveDoctors(
    null,
    doctorAccessWhere(
      session.user,
      "healthcare.appointments.appointment.create",
    ),
  );
  const doctorId = doctors.some((doctor) => doctor.id === params.doctorId)
    ? params.doctorId!
    : (doctors[0]?.id ?? "");
  const availability = doctorId
    ? await getDoctorAvailability(doctorId, date)
    : null;
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Appointments", href: "/admin/healthcare/appointments" },
          { label: "Create" },
        ]}
        description="Create and immediately confirm an appointment for a patient from reception or phone support."
        eyebrow="Manual booking"
        title="New appointment"
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            description="Change doctor or date to calculate live capacity before saving."
            title="Doctor and availability"
          >
            <form className="schedule-doctor-selector" method="get">
              <label className="form-field">
                <span>Doctor</span>
                <select defaultValue={doctorId} name="doctorId" required>
                  {doctors.map((doctor) => (
                    <option key={doctor.id} value={doctor.id}>
                      {doctor.name} — {doctor.specialization}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Date</span>
                <input
                  defaultValue={date}
                  min={today}
                  max={maximumDate}
                  name="date"
                  required
                  type="date"
                />
              </label>
              <button className="ui-button ui-button-secondary" type="submit">
                Check slots
              </button>
            </form>
            {availability ? (
              <div className="schedule-doctor-heading">
                <DoctorAvatar
                  imageUrl={availability.doctor.imageUrl}
                  name={availability.doctor.name}
                  size="small"
                />
                <div>
                  <strong>{availability.doctor.name}</strong>
                  <span>
                    {availability.doctor.specialization} · ৳
                    {Number(availability.doctor.consultationFee).toLocaleString(
                      "en-BD",
                    )}
                  </span>
                </div>
              </div>
            ) : null}
          </SectionCard>
        </div>
        <div className="content-stack">
          <SectionCard
            description="The appointment starts as Confirmed and is visible in the live queue."
            title="Patient and appointment details"
          >
            {availability ? (
              <form
                action="/api/admin/healthcare/appointments"
                className="admin-form-stack"
                method="post"
              >
                <input
                  name="doctorId"
                  type="hidden"
                  value={availability.doctor.id}
                />
                <input name="date" type="hidden" value={date} />
                <div className="form-field">
                  <span>Available time</span>
                  <SlotPicker slots={availability.slots} />
                </div>
                <div className="admin-form-grid">
                  <label className="form-field">
                    <span>Patient name</span>
                    <input maxLength={100} name="patientName" required />
                  </label>
                  <label className="form-field">
                    <span>Mobile number</span>
                    <input
                      inputMode="tel"
                      maxLength={20}
                      name="patientPhone"
                      placeholder="01XXXXXXXXX"
                      required
                    />
                  </label>
                  <label className="form-field">
                    <span>Email</span>
                    <input maxLength={254} name="patientEmail" type="email" />
                  </label>
                  <label className="form-field">
                    <span>Service</span>
                    <select defaultValue="Consultation" name="serviceType">
                      <option>Consultation</option>
                      <option>Follow-up</option>
                      <option>Nutrition consultation</option>
                      <option>Fitness assessment</option>
                    </select>
                  </label>
                </div>
                <label className="form-field">
                  <span>Reason for visit</span>
                  <textarea maxLength={1000} name="reason" rows={4} />
                </label>
                <label className="form-field">
                  <span>Internal note</span>
                  <textarea maxLength={2000} name="notes" rows={3} />
                </label>
                <button
                  className="ui-button ui-button-primary"
                  disabled={
                    !availability.slots.some((slot) => slot.available > 0)
                  }
                  type="submit"
                >
                  Create confirmed appointment
                </button>
              </form>
            ) : (
              <div className="table-empty">
                Create an active doctor and schedule before booking.
              </div>
            )}
          </SectionCard>
        </div>
      </div>
    </>
  );
}
