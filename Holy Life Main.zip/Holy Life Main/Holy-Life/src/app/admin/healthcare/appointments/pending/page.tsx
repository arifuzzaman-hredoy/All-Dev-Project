import {
  AdminAppointmentList,
  type AppointmentListSearch,
} from "@/components/appointments/admin-appointment-list";
import { requirePermission } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function PendingAppointmentsPage({
  searchParams,
}: {
  searchParams: Promise<AppointmentListSearch>;
}) {
  const session = await requirePermission(
    "healthcare.appointments.appointment.view",
    "/admin/healthcare/appointments/pending",
  );
  return (
    <AdminAppointmentList
      params={await searchParams}
      session={session}
      preset="pending"
    />
  );
}
