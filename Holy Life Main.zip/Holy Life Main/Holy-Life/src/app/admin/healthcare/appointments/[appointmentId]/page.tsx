import { notFound } from "next/navigation";
import {
  AppointmentFlash,
  AppointmentMeta,
  AppointmentMetaItem,
  AppointmentStatusBadge,
  DoctorAvatar,
  SlotPicker,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { appointmentAccessWhere } from "@/lib/appointments/access";
import { getDoctorAvailability } from "@/lib/appointments/queries";
import {
  availableAppointmentTransitions,
  appointmentStatusLabel,
} from "@/lib/appointments/status";
import {
  formatDisplayDate,
  formatDisplayTime,
  isDateInput,
  todayInDhaka,
  utcDateToInput,
} from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AppointmentDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ appointmentId: string }>;
  searchParams: Promise<{ date?: string; success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.appointments.appointment.view",
    "/admin/healthcare/appointments",
  );
  const canViewFinance = hasPermission(
    session.user,
    "system.finance.payment.view",
  );
  const canViewClinical = hasPermission(
    session.user,
    "healthcare.patients.clinical-record.view",
  );
  const canEditClinical = hasPermission(
    session.user,
    "healthcare.patients.clinical-record.edit",
  );
  const canCreatePrescription = hasPermission(
    session.user,
    "healthcare.prescriptions.prescription.create",
  );
  const [{ appointmentId }, query] = await Promise.all([params, searchParams]);
  const appointment = await db.appointment.findFirst({
    where: {
      AND: [{ id: appointmentId }, appointmentAccessWhere(session.user)],
    },
    include: {
      doctor: { include: { department: true } },
      patient: true,
      clinicalEncounter: true,
      prescriptions: {
        orderBy: { version: "desc" },
        take: 1,
        select: { id: true, code: true, status: true, version: true },
      },
      createdBy: { select: { name: true } },
      updatedBy: { select: { name: true } },
    },
  });
  if (!appointment) notFound();
  const rescheduleDate = isDateInput(query.date ?? "")
    ? query.date!
    : utcDateToInput(appointment.appointmentDate) < todayInDhaka()
      ? todayInDhaka()
      : utcDateToInput(appointment.appointmentDate);
  const availability = await getDoctorAvailability(
    appointment.doctorId,
    rescheduleDate,
  );
  const transitions = availableAppointmentTransitions(appointment.status);
  const finalStatus = ["COMPLETED", "CANCELLED", "NO_SHOW"].includes(
    appointment.status,
  );
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Appointments", href: "/admin/healthcare/appointments" },
          { label: appointment.code },
        ]}
        description={`${appointment.patientName} · ${appointment.doctor.name}`}
        eyebrow="Appointment record"
        title={appointment.code}
        actions={
          <div className="page-action-group">
            <ButtonLink
              href={`/admin/healthcare/appointments/${appointment.id}/print`}
              icon="file"
            >
              Print slip
            </ButtonLink>
            {canViewClinical ? (
              <ButtonLink
                href={`/admin/healthcare/patients/${appointment.patientId}`}
                icon="users"
                variant="secondary"
              >
                Clinical record
              </ButtonLink>
            ) : null}
            {canCreatePrescription && appointment.prescriptions.length === 0 ? (
              <ButtonLink
                href={`/admin/healthcare/prescriptions/create?appointmentId=${appointment.id}`}
                icon="file"
              >
                Create prescription
              </ButtonLink>
            ) : null}
            {appointment.prescriptions[0] ? (
              <ButtonLink
                href={`/admin/healthcare/prescriptions/${appointment.prescriptions[0].id}`}
                icon="file"
              >
                Open Rx v{appointment.prescriptions[0].version}
              </ButtonLink>
            ) : null}
          </div>
        }
      />
      <AppointmentFlash error={query.error} success={query.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            action={<AppointmentStatusBadge status={appointment.status} />}
            description="Clinical schedule, patient identity, source, serial, fee, and current workflow state."
            title="Appointment overview"
          >
            <div className="appointment-detail-doctor">
              <DoctorAvatar
                imageUrl={appointment.doctor.imageUrl}
                name={appointment.doctor.name}
              />
              <div>
                <span className="content-kicker">
                  {appointment.doctor.department.name}
                </span>
                <h3>{appointment.doctor.name}</h3>
                <p>{appointment.doctor.specialization}</p>
              </div>
            </div>
            <AppointmentMeta>
              <AppointmentMetaItem
                icon="calendar"
                label="Date"
                value={formatDisplayDate(appointment.appointmentDate)}
              />
              <AppointmentMetaItem
                icon="appointment"
                label="Time"
                value={`${formatDisplayTime(appointment.startTime)}–${formatDisplayTime(appointment.endTime)}`}
              />
              <AppointmentMetaItem
                icon="users"
                label="Serial"
                value={
                  appointment.serialNumber
                    ? `#${appointment.serialNumber}`
                    : "Not assigned"
                }
              />
              <AppointmentMetaItem
                icon="activity"
                label="Service"
                value={appointment.serviceType}
              />
              <AppointmentMetaItem
                icon="home"
                label="Room"
                value={appointment.doctor.roomLabel ?? "Holy Life"}
              />
              <AppointmentMetaItem
                icon="doctor"
                label="Fee"
                value={`৳${Number(appointment.fee).toLocaleString("en-BD")}`}
              />
            </AppointmentMeta>
            <div className="appointment-detail-copy">
              <div>
                <span>Reason for visit</span>
                <p>{appointment.reason ?? "Not provided"}</p>
              </div>
              <div>
                <span>Internal notes</span>
                <p>{appointment.notes ?? "No internal note"}</p>
              </div>
            </div>
          </SectionCard>
          {!finalStatus ? (
            <SectionCard
              description="Only valid workflow transitions are accepted by the server."
              title="Update workflow status"
            >
              <form
                action={`/api/admin/healthcare/appointments/${appointment.id}/status`}
                className="admin-form-stack"
                method="post"
              >
                <label className="form-field">
                  <span>Next status</span>
                  <select defaultValue="" name="status" required>
                    <option disabled value="">
                      Select next status
                    </option>
                    {transitions.map((status) => (
                      <option key={status} value={status}>
                        {appointmentStatusLabel(status)}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>Cancellation reason (required when cancelling)</span>
                  <textarea
                    maxLength={500}
                    name="cancellationReason"
                    rows={3}
                  />
                </label>
                <button
                  className="ui-button ui-button-primary"
                  disabled={transitions.length === 0}
                  type="submit"
                >
                  Update status
                </button>
              </form>
            </SectionCard>
          ) : null}
          {!finalStatus ? (
            <SectionCard
              description="The current doctor remains assigned. Select another date to calculate exact live slots."
              title="Reschedule"
            >
              <form className="schedule-doctor-selector" method="get">
                <label className="form-field">
                  <span>New date</span>
                  <input
                    defaultValue={rescheduleDate}
                    min={todayInDhaka()}
                    name="date"
                    required
                    type="date"
                  />
                </label>
                <button className="ui-button ui-button-secondary" type="submit">
                  Check date
                </button>
              </form>
              <form
                action={`/api/admin/healthcare/appointments/${appointment.id}/reschedule`}
                className="admin-form-stack"
                method="post"
              >
                <input name="date" type="hidden" value={rescheduleDate} />
                <div className="form-field">
                  <span>Available time</span>
                  <SlotPicker
                    selected={
                      rescheduleDate ===
                      utcDateToInput(appointment.appointmentDate)
                        ? appointment.startTime
                        : null
                    }
                    slots={availability?.slots ?? []}
                  />
                </div>
                <button
                  className="ui-button ui-button-primary"
                  disabled={
                    !availability?.slots.some(
                      (slot) =>
                        slot.available > 0 ||
                        (rescheduleDate ===
                          utcDateToInput(appointment.appointmentDate) &&
                          slot.startTime === appointment.startTime),
                    )
                  }
                  type="submit"
                >
                  Reschedule appointment
                </button>
              </form>
            </SectionCard>
          ) : null}
          {canViewClinical ? (
            <SectionCard
              description="Sensitive consultation notes are access-scoped and audited. Notes can be recorded only after check-in."
              title="Clinical encounter"
            >
              {canEditClinical ? (
                <form
                  action={`/api/admin/healthcare/appointments/${appointment.id}/clinical`}
                  className="admin-form-stack"
                  method="post"
                >
                  <div className="admin-form-grid">
                    <label className="form-field">
                      <span>Symptoms / complaints</span>
                      <textarea
                        defaultValue={
                          appointment.clinicalEncounter?.symptoms ?? ""
                        }
                        maxLength={8000}
                        name="symptoms"
                        rows={4}
                      />
                    </label>
                    <label className="form-field">
                      <span>Diagnosis</span>
                      <textarea
                        defaultValue={
                          appointment.clinicalEncounter?.diagnosis ?? ""
                        }
                        maxLength={8000}
                        name="diagnosis"
                        rows={4}
                      />
                    </label>
                    <label className="form-field">
                      <span>Clinical notes</span>
                      <textarea
                        defaultValue={
                          appointment.clinicalEncounter?.clinicalNotes ?? ""
                        }
                        maxLength={12000}
                        name="clinicalNotes"
                        rows={4}
                      />
                    </label>
                    <label className="form-field">
                      <span>Advice</span>
                      <textarea
                        defaultValue={
                          appointment.clinicalEncounter?.advice ?? ""
                        }
                        maxLength={8000}
                        name="advice"
                        rows={4}
                      />
                    </label>
                    <label className="form-field">
                      <span>Follow-up date</span>
                      <input
                        defaultValue={
                          appointment.clinicalEncounter?.followUpDate
                            ? utcDateToInput(
                                appointment.clinicalEncounter.followUpDate,
                              )
                            : ""
                        }
                        name="followUpDate"
                        type="date"
                      />
                    </label>
                  </div>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save clinical encounter
                  </button>
                </form>
              ) : (
                <div className="appointment-detail-copy">
                  <div>
                    <span>Symptoms</span>
                    <p>
                      {appointment.clinicalEncounter?.symptoms ??
                        "Not recorded"}
                    </p>
                  </div>
                  <div>
                    <span>Diagnosis</span>
                    <p>
                      {appointment.clinicalEncounter?.diagnosis ??
                        "Not recorded"}
                    </p>
                  </div>
                  <div>
                    <span>Clinical notes</span>
                    <p>
                      {appointment.clinicalEncounter?.clinicalNotes ??
                        "Not recorded"}
                    </p>
                  </div>
                  <div>
                    <span>Advice</span>
                    <p>
                      {appointment.clinicalEncounter?.advice ?? "Not recorded"}
                    </p>
                  </div>
                </div>
              )}
            </SectionCard>
          ) : null}
        </div>
        <div className="content-stack">
          <SectionCard title="Patient">
            <div className="patient-summary-card">
              <span className="list-avatar list-avatar-health">
                {appointment.patientName
                  .split(/\s+/)
                  .slice(0, 2)
                  .map((part) => part[0])
                  .join("")}
              </span>
              <h3>{appointment.patientName}</h3>
              <p>{appointment.patient.patientCode}</p>
              <div>
                <span>
                  Phone<strong>{appointment.patientPhone}</strong>
                </span>
                <span>
                  Email
                  <strong>{appointment.patientEmail ?? "Not provided"}</strong>
                </span>
                <span>
                  Account
                  <strong>
                    {appointment.userId ? "Linked" : "Reception record"}
                  </strong>
                </span>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Operational record">
            <div className="status-list">
              <div>
                <span>Source</span>
                <StatusBadge tone="info">{appointment.source}</StatusBadge>
              </div>
              <div>
                <span>Payment</span>
                <StatusBadge
                  tone={
                    appointment.paymentStatus === "PAID"
                      ? "success"
                      : appointment.paymentStatus === "REFUNDED"
                        ? "neutral"
                        : "warning"
                  }
                >
                  {appointment.paymentStatus}
                </StatusBadge>
              </div>
              <div>
                <span>Created</span>
                <strong>
                  {appointment.createdAt.toLocaleString("en-GB", {
                    timeZone: "Asia/Dhaka",
                  })}
                </strong>
              </div>
              <div>
                <span>Created by</span>
                <strong>
                  {appointment.createdBy?.name ??
                    (appointment.source === "PUBLIC"
                      ? appointment.patientName
                      : "System")}
                </strong>
              </div>
              <div>
                <span>Last updated by</span>
                <strong>{appointment.updatedBy?.name ?? "—"}</strong>
              </div>
            </div>
            <div className="admin-form-stack appointment-payment-form">
              <p className="muted-copy">
                Payment changes use the auditable manual finance ledger.
              </p>
              {canViewFinance ? (
                <ButtonLink
                  href={`/admin/finance/payments?search=${encodeURIComponent(appointment.code)}`}
                  icon="file"
                  variant="secondary"
                >
                  Open finance ledger
                </ButtonLink>
              ) : (
                <p className="muted-copy">
                  A Finance Manager or another admin with finance-view
                  permission must record the payment.
                </p>
              )}
            </div>
          </SectionCard>
          {appointment.cancellationReason ? (
            <SectionCard title="Cancellation">
              <div className="notice-box">
                <strong>Reason</strong>
                <p>{appointment.cancellationReason}</p>
              </div>
            </SectionCard>
          ) : null}
        </div>
      </div>
    </>
  );
}
