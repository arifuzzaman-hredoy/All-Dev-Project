import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth/authorization";
import { appointmentAccessWhere } from "@/lib/appointments/access";
import { formatDisplayDate, formatDisplayTime } from "@/lib/appointments/time";
import { appointmentStatusLabel } from "@/lib/appointments/status";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AppointmentPrintPage({
  params,
}: {
  params: Promise<{ appointmentId: string }>;
}) {
  const session = await requirePermission(
    "healthcare.appointments.appointment.view",
    "/admin/healthcare/appointments",
  );
  const { appointmentId } = await params;
  const appointment = await db.appointment.findFirst({
    where: {
      AND: [{ id: appointmentId }, appointmentAccessWhere(session.user)],
    },
    include: { doctor: { include: { department: true } }, patient: true },
  });
  if (!appointment) notFound();
  return (
    <main className="appointment-print-page">
      <section className="appointment-print-sheet">
        <header>
          <div>
            <span>HOLY LIFE</span>
            <h1>Appointment Slip</h1>
            <p>Doctor-led Health, Fitness & Wellness · Rangpur</p>
          </div>
          <div>
            <strong>{appointment.code}</strong>
            <span>{appointmentStatusLabel(appointment.status)}</span>
          </div>
        </header>
        <div className="appointment-print-grid">
          <div>
            <span>Patient</span>
            <strong>{appointment.patientName}</strong>
            <p>{appointment.patientPhone}</p>
            <p>{appointment.patientEmail ?? appointment.patient.patientCode}</p>
          </div>
          <div>
            <span>Doctor</span>
            <strong>{appointment.doctor.name}</strong>
            <p>{appointment.doctor.specialization}</p>
            <p>{appointment.doctor.department.name}</p>
          </div>
          <div>
            <span>Date</span>
            <strong>{formatDisplayDate(appointment.appointmentDate)}</strong>
            <p>
              {formatDisplayTime(appointment.startTime)}–
              {formatDisplayTime(appointment.endTime)}
            </p>
            <p>
              Serial{" "}
              {appointment.serialNumber
                ? `#${appointment.serialNumber}`
                : "Pending"}
            </p>
          </div>
          <div>
            <span>Location</span>
            <strong>
              {appointment.doctor.location ?? "Holy Life, Rangpur"}
            </strong>
            <p>{appointment.doctor.roomLabel ?? "Reception will guide you"}</p>
            <p>
              Fee ৳{Number(appointment.fee).toLocaleString("en-BD")} ·{" "}
              {appointment.paymentStatus}
            </p>
          </div>
        </div>
        <div className="appointment-print-note">
          <span>Reason for visit</span>
          <p>{appointment.reason ?? "Not provided"}</p>
        </div>
        <footer>
          <p>
            Please arrive 15 minutes early and present this appointment code at
            reception.
          </p>
          <p>
            Printed{" "}
            {new Date().toLocaleString("en-GB", { timeZone: "Asia/Dhaka" })}
          </p>
        </footer>
      </section>
      <div className="appointment-print-actions">
        Use your browser Print command (Ctrl+P) to print or save this slip.
      </div>
    </main>
  );
}
