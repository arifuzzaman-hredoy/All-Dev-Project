import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AppointmentFlash,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import { DoctorForm } from "@/components/appointments/doctor-form";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { db } from "@/lib/db";
import { formatDisplayDate } from "@/lib/appointments/time";

export const dynamic = "force-dynamic";

export default async function DoctorDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ doctorId: string }>;
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.doctors.doctor.view",
    "/admin/healthcare/doctors",
  );
  const [{ doctorId }, query] = await Promise.all([params, searchParams]);
  const [doctor, departments] = await Promise.all([
    db.doctorProfile.findFirst({
      where: { AND: [{ id: doctorId }, doctorAccessWhere(session.user)] },
      include: {
        department: true,
        schedules: { orderBy: [{ weekday: "asc" }, { startTime: "asc" }] },
        appointments: {
          orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
          take: 5,
        },
      },
    }),
    db.medicalDepartment.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
  ]);
  if (!doctor) notFound();
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Doctors", href: "/admin/healthcare/doctors" },
          { label: doctor.name },
        ]}
        description={`${doctor.department.name} · ${doctor.specialization}`}
        eyebrow="Doctor profile"
        title={doctor.name}
        actions={
          <ButtonLink
            href={`/admin/healthcare/schedules?doctorId=${doctor.id}`}
            icon="calendar"
          >
            Manage schedule
          </ButtonLink>
        }
      />
      <AppointmentFlash error={query.error} success={query.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            description="Edit profile, public information, fee, order, and visibility."
            title="Profile details"
          >
            <DoctorForm
              action={`/api/admin/healthcare/doctors/${doctor.id}`}
              departments={departments}
              doctor={doctor}
              submitLabel="Save doctor profile"
            />
          </SectionCard>
        </div>
        <div className="content-stack">
          <SectionCard title="Profile summary">
            <div className="doctor-admin-summary">
              <DoctorAvatar imageUrl={doctor.imageUrl} name={doctor.name} />
              <h3>{doctor.name}</h3>
              <p>
                {doctor.designation} · {doctor.specialization}
              </p>
              <StatusBadge
                tone={
                  doctor.status === "ACTIVE"
                    ? "success"
                    : doctor.status === "INACTIVE"
                      ? "warning"
                      : "neutral"
                }
              >
                {doctor.status}
              </StatusBadge>
              <div>
                <span>
                  Weekly windows<strong>{doctor.schedules.length}</strong>
                </span>
                <span>
                  Consultation fee
                  <strong>
                    ৳{Number(doctor.consultationFee).toLocaleString("en-BD")}
                  </strong>
                </span>
                <span>
                  Public profile
                  <strong>
                    <Link href={`/doctors/${doctor.slug}`}>Open</Link>
                  </strong>
                </span>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Recent appointments">
            {doctor.appointments.length ? (
              <div className="compact-list">
                {doctor.appointments.map((appointment) => (
                  <Link
                    className="compact-list-item"
                    href={`/admin/healthcare/appointments/${appointment.id}`}
                    key={appointment.id}
                  >
                    <div>
                      <strong>{appointment.patientName}</strong>
                      <span>{appointment.code}</span>
                    </div>
                    <div>
                      <strong>
                        {formatDisplayDate(appointment.appointmentDate)}
                      </strong>
                      <span>{appointment.status}</span>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="table-empty">No appointments yet.</div>
            )}
          </SectionCard>
          {doctor.status !== "ARCHIVED" ? (
            <SectionCard
              description="Archiving hides the public profile but preserves schedule and appointment history."
              title="Archive doctor"
            >
              <form
                action={`/api/admin/healthcare/doctors/${doctor.id}/archive`}
                method="post"
              >
                <button className="ui-button ui-button-secondary" type="submit">
                  Archive profile
                </button>
              </form>
            </SectionCard>
          ) : null}
        </div>
      </div>
    </>
  );
}
