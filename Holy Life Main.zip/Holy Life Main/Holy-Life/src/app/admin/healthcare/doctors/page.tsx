import Link from "next/link";
import {
  AppointmentFlash,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { doctorAccessWhere } from "@/lib/appointments/access";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AdminDoctorsPage({
  searchParams,
}: {
  searchParams: Promise<{
    status?: string;
    q?: string;
    success?: string;
    error?: string;
  }>;
}) {
  const session = await requirePermission(
    "healthcare.doctors.doctor.view",
    "/admin/healthcare/doctors",
  );
  const params = await searchParams;
  const status =
    params.status === "ACTIVE" ||
    params.status === "INACTIVE" ||
    params.status === "ARCHIVED"
      ? params.status
      : undefined;
  const q = params.q?.trim().slice(0, 100) ?? "";
  const [doctors, counts] = await Promise.all([
    db.doctorProfile.findMany({
      where: {
        AND: [
          doctorAccessWhere(session.user),
          {
            ...(status ? { status } : {}),
            ...(q
              ? {
                  OR: [
                    { name: { contains: q, mode: "insensitive" } },
                    { code: { contains: q, mode: "insensitive" } },
                    { specialization: { contains: q, mode: "insensitive" } },
                  ],
                }
              : {}),
          },
        ],
      },
      include: {
        department: true,
        _count: { select: { appointments: true, schedules: true } },
      },
      orderBy: [{ status: "asc" }, { displayOrder: "asc" }, { name: "asc" }],
      take: 200,
    }),
    db.doctorProfile.groupBy({
      where: doctorAccessWhere(session.user),
      by: ["status"],
      _count: { _all: true },
    }),
  ]);
  const countFor = (value: string) =>
    counts.find((item) => item.status === value)?._count._all ?? 0;

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Doctors" },
        ]}
        description="Manage public doctor profiles, fees, status, and linked weekly schedules."
        eyebrow="Healthcare team"
        title="Doctor management"
        actions={
          <ButtonLink href="/admin/healthcare/doctors/create" icon="doctor">
            Add doctor
          </ButtonLink>
        }
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <section className="metric-grid metric-grid-four">
        <MetricCard
          helper="Available publicly"
          icon="doctor"
          label="Active doctors"
          tone="health"
          value={String(countFor("ACTIVE"))}
        />
        <MetricCard
          helper="Hidden temporarily"
          icon="activity"
          label="Inactive"
          tone="warning"
          value={String(countFor("INACTIVE"))}
        />
        <MetricCard
          helper="History preserved"
          icon="file"
          label="Archived"
          value={String(countFor("ARCHIVED"))}
        />
        <MetricCard
          helper="Current result"
          icon="search"
          label="Listed"
          value={String(doctors.length)}
        />
      </section>
      <section className="filter-panel">
        <form className="filter-inline-form" method="get">
          <div className="filter-search-field">
            <span>⌕</span>
            <input
              defaultValue={q}
              name="q"
              placeholder="Search name, code, specialization"
            />
          </div>
          <select defaultValue={status ?? ""} name="status">
            <option value="">All statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
            <option value="ARCHIVED">Archived</option>
          </select>
          <button className="ui-button ui-button-secondary" type="submit">
            Apply filters
          </button>
          <Link
            className="ui-button ui-button-quiet"
            href="/admin/healthcare/doctors"
          >
            Reset
          </Link>
        </form>
      </section>
      <SectionCard
        description="Every profile is connected to department, public visibility, schedule, and appointment history."
        title="Doctor directory"
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Doctor</th>
                <th>Department</th>
                <th>Fee</th>
                <th>Schedule</th>
                <th>Appointments</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {doctors.map((doctor) => (
                <tr key={doctor.id}>
                  <td>
                    <div className="table-person">
                      <DoctorAvatar
                        imageUrl={doctor.imageUrl}
                        name={doctor.name}
                        size="small"
                      />
                      <div>
                        <strong>{doctor.name}</strong>
                        <span>
                          {doctor.code} · {doctor.specialization}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td>{doctor.department.name}</td>
                  <td>
                    ৳{Number(doctor.consultationFee).toLocaleString("en-BD")}
                  </td>
                  <td>
                    {doctor._count.schedules} window
                    {doctor._count.schedules === 1 ? "" : "s"}
                  </td>
                  <td>{doctor._count.appointments}</td>
                  <td>
                    <StatusBadge
                      tone={
                        doctor.status === "ACTIVE"
                          ? "success"
                          : doctor.status === "INACTIVE"
                            ? "warning"
                            : "neutral"
                      }
                    >
                      {doctor.status}
                    </StatusBadge>
                  </td>
                  <td>
                    <Link
                      className="table-action-link"
                      href={`/admin/healthcare/doctors/${doctor.id}`}
                    >
                      Manage
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {doctors.length === 0 ? (
            <div className="table-empty">
              No doctor profile matches the current filters.
            </div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
