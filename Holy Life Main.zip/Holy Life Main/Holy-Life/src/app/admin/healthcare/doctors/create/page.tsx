import { AppointmentFlash } from "@/components/appointments/appointment-ui";
import { DoctorForm } from "@/components/appointments/doctor-form";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function CreateDoctorPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  await requirePermission(
    "healthcare.doctors.doctor.create",
    "/admin/healthcare/doctors/create",
  );
  const params = await searchParams;
  const departments = await db.medicalDepartment.findMany({
    where: { isActive: true },
    orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
  });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Doctors", href: "/admin/healthcare/doctors" },
          { label: "Add doctor" },
        ]}
        description="Create a public clinical profile. Weekly availability is configured after saving."
        eyebrow="Healthcare setup"
        title="Add doctor"
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <SectionCard
        description="Required fields are validated on the server and all changes are audited."
        title="Doctor profile"
      >
        <DoctorForm
          action="/api/admin/healthcare/doctors"
          departments={departments}
          submitLabel="Create doctor profile"
        />
      </SectionCard>
    </>
  );
}
