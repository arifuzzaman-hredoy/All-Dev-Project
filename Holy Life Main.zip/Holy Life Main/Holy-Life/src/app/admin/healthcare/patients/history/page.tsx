import Link from "next/link";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { clinicalAppointmentAccessWhere } from "@/lib/clinical/access";
import { formatDisplayDate } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function PatientHistoryPage() {
  const session = await requirePermission(
    "healthcare.patients.clinical-record.view",
    "/admin/healthcare/patients",
  );
  const visits = await db.appointment.findMany({
    where: clinicalAppointmentAccessWhere(session.user),
    include: {
      patient: true,
      doctor: true,
      clinicalEncounter: true,
      _count: { select: { prescriptions: true, vitals: true } },
    },
    orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
    take: 300,
  });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Patients", href: "/admin/healthcare/patients" },
          { label: "History" },
        ]}
        description="Chronological clinical visit history within your data scope."
        eyebrow="Clinical visit history"
        title="Patient visit history"
      />
      <SectionCard title="Recent visits">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Diagnosis</th>
                <th>Records</th>
              </tr>
            </thead>
            <tbody>
              {visits.map((visit) => (
                <tr key={visit.id}>
                  <td>
                    <Link href={`/admin/healthcare/appointments/${visit.id}`}>
                      <strong>
                        {formatDisplayDate(visit.appointmentDate)}
                      </strong>
                      <span>{visit.code}</span>
                    </Link>
                  </td>
                  <td>
                    <Link
                      href={`/admin/healthcare/patients/${visit.patientId}`}
                    >
                      <strong>{visit.patient.name}</strong>
                      <span>{visit.patient.patientCode}</span>
                    </Link>
                  </td>
                  <td>{visit.doctor.name}</td>
                  <td>{visit.clinicalEncounter?.diagnosis ?? "—"}</td>
                  <td>
                    {visit._count.vitals} vitals · {visit._count.prescriptions}{" "}
                    Rx
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {visits.length === 0 ? (
            <div className="table-empty">No visit history.</div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
