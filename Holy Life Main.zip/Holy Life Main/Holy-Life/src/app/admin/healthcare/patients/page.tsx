import Link from "next/link";
import { AppointmentFlash } from "@/components/appointments/appointment-ui";
import {
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { patientAccessWhere } from "@/lib/appointments/access";
import { formatDisplayDate } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function PatientsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.patients.patient.view",
    "/admin/healthcare/patients",
  );
  const params = await searchParams;
  const canViewClinical = hasPermission(
    session.user,
    "healthcare.patients.clinical-record.view",
  );
  const q = params.q?.trim().slice(0, 100) ?? "";
  const [patients, total, linked] = await Promise.all([
    db.patientProfile.findMany({
      where: {
        AND: [
          patientAccessWhere(session.user),
          q
            ? {
                OR: [
                  { name: { contains: q, mode: "insensitive" } },
                  { phone: { contains: q } },
                  { patientCode: { contains: q, mode: "insensitive" } },
                ],
              }
            : {},
        ],
      },
      include: {
        user: { select: { emailVerifiedAt: true, phoneVerifiedAt: true } },
        appointments: {
          orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
          take: 1,
        },
        _count: { select: { appointments: true } },
      },
      orderBy: { updatedAt: "desc" },
      take: 300,
    }),
    db.patientProfile.count({
      where: { AND: [patientAccessWhere(session.user), { status: "ACTIVE" }] },
    }),
    db.patientProfile.count({
      where: {
        AND: [
          patientAccessWhere(session.user),
          { userId: { not: null }, status: "ACTIVE" },
        ],
      },
    }),
  ]);
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Patients" },
        ]}
        description="Patient identity records are created from public or reception appointments and preserve visit history."
        eyebrow="Patient directory"
        title="Patient management"
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <section className="metric-grid metric-grid-four">
        <MetricCard
          helper="Active records"
          icon="users"
          label="Patients"
          tone="health"
          value={String(total)}
        />
        <MetricCard
          helper="Patient dashboard"
          icon="lock"
          label="Linked accounts"
          tone="success"
          value={String(linked)}
        />
        <MetricCard
          helper="Reception only"
          icon="profile"
          label="Unlinked records"
          value={String(Math.max(0, total - linked))}
        />
        <MetricCard
          helper="Current search"
          icon="search"
          label="Listed"
          value={String(patients.length)}
        />
      </section>
      <section className="filter-panel">
        <form className="filter-inline-form" method="get">
          <div className="filter-search-field">
            <span>⌕</span>
            <input
              defaultValue={q}
              name="q"
              placeholder="Name, phone, patient code"
            />
          </div>
          <button className="ui-button ui-button-secondary" type="submit">
            Search
          </button>
          <Link
            className="ui-button ui-button-quiet"
            href="/admin/healthcare/patients"
          >
            Reset
          </Link>
        </form>
      </section>
      <SectionCard
        description="Open a patient to review permission-scoped clinical history, vitals, visits, and prescriptions."
        title="Patient directory"
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Contact</th>
                <th>Account</th>
                <th>Appointments</th>
                <th>Last visit</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((patient) => (
                <tr key={patient.id}>
                  <td>
                    {canViewClinical ? (
                      <Link href={`/admin/healthcare/patients/${patient.id}`}>
                        <strong>{patient.name}</strong>
                        <span>{patient.patientCode}</span>
                      </Link>
                    ) : (
                      <>
                        <strong>{patient.name}</strong>
                        <span>{patient.patientCode}</span>
                      </>
                    )}
                  </td>
                  <td>
                    <strong>{patient.phone}</strong>
                    <span>{patient.email ?? "No email"}</span>
                  </td>
                  <td>
                    <StatusBadge tone={patient.userId ? "success" : "neutral"}>
                      {patient.userId ? "Linked" : "Reception"}
                    </StatusBadge>
                  </td>
                  <td>{patient._count.appointments}</td>
                  <td>
                    {patient.appointments[0] ? (
                      <>
                        <strong>
                          {formatDisplayDate(
                            patient.appointments[0].appointmentDate,
                          )}
                        </strong>
                        <span>{patient.appointments[0].code}</span>
                      </>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td>
                    <StatusBadge
                      tone={patient.status === "ACTIVE" ? "success" : "neutral"}
                    >
                      {patient.status}
                    </StatusBadge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {patients.length === 0 ? (
            <div className="table-empty">
              No patient matches the current search.
            </div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
