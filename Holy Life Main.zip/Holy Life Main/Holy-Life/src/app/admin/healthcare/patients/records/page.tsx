import Link from "next/link";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requirePermission } from "@/lib/auth/authorization";
import { clinicalPatientAccessWhere } from "@/lib/clinical/access";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function ClinicalRecordsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.patients.clinical-record.view",
    "/admin/healthcare/patients",
  );
  const query = (await searchParams).q?.trim().slice(0, 100) ?? "";
  const patients = await db.patientProfile.findMany({
    where: {
      AND: [
        clinicalPatientAccessWhere(session.user),
        query
          ? {
              OR: [
                { name: { contains: query, mode: "insensitive" } },
                { phone: { contains: query } },
                { patientCode: { contains: query, mode: "insensitive" } },
              ],
            }
          : {},
      ],
    },
    include: {
      clinicalProfile: true,
      _count: {
        select: { vitals: true, prescriptions: true, appointments: true },
      },
    },
    orderBy: { updatedAt: "desc" },
    take: 300,
  });
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "ClinicalRecordDirectory",
    metadata: { resultCount: patients.length },
  });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Clinical records" },
        ]}
        description="Permission-scoped access to sensitive patient history, vitals, visits, and prescriptions."
        eyebrow="Clinical records"
        title="Clinical records"
      />
      <section className="filter-panel">
        <form className="filter-inline-form" method="get">
          <div className="filter-search-field">
            <span>⌕</span>
            <input
              defaultValue={query}
              name="q"
              placeholder="Name, phone, patient code"
            />
          </div>
          <button className="ui-button ui-button-secondary" type="submit">
            Search
          </button>
          <Link
            className="ui-button ui-button-quiet"
            href="/admin/healthcare/patients/records"
          >
            Reset
          </Link>
        </form>
      </section>
      <SectionCard title="Accessible patients">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Clinical profile</th>
                <th>Visits</th>
                <th>Vitals</th>
                <th>Prescriptions</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((patient) => (
                <tr key={patient.id}>
                  <td>
                    <Link href={`/admin/healthcare/patients/${patient.id}`}>
                      <strong>{patient.name}</strong>
                      <span>
                        {patient.patientCode} · {patient.phone}
                      </span>
                    </Link>
                  </td>
                  <td>
                    <StatusBadge
                      tone={patient.clinicalProfile ? "success" : "neutral"}
                    >
                      {patient.clinicalProfile ? "Recorded" : "Empty"}
                    </StatusBadge>
                  </td>
                  <td>{patient._count.appointments}</td>
                  <td>{patient._count.vitals}</td>
                  <td>{patient._count.prescriptions}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {patients.length === 0 ? (
            <div className="table-empty">
              No accessible clinical records match this search.
            </div>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
