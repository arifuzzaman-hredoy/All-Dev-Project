import Link from "next/link";
import { notFound } from "next/navigation";
import { AppointmentStatusBadge } from "@/components/appointments/appointment-ui";
import { ClinicalFlash } from "@/components/clinical/clinical-flash";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { formatDisplayDate } from "@/lib/appointments/time";
import { getAdminPatientClinicalRecord } from "@/lib/clinical/queries";
import {
  prescriptionStatusLabel,
  prescriptionStatusTone,
} from "@/lib/clinical/status";

export const dynamic = "force-dynamic";

function display(value: string | null | undefined): string {
  return value?.trim() || "Not recorded";
}

export default async function PatientClinicalPage({
  params,
  searchParams,
}: {
  params: Promise<{ patientId: string }>;
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "healthcare.patients.clinical-record.view",
    "/admin/healthcare/patients",
  );
  const [{ patientId }, query] = await Promise.all([params, searchParams]);
  const patient = await getAdminPatientClinicalRecord(session.user, patientId);
  if (!patient) notFound();
  const canEdit = hasPermission(
    session.user,
    "healthcare.patients.clinical-record.edit",
  );
  const canCreatePrescription = hasPermission(
    session.user,
    "healthcare.prescriptions.prescription.create",
  );
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "PatientClinicalRecord",
    targetId: patient.id,
    metadata: { patientCode: patient.patientCode },
  });

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Patients", href: "/admin/healthcare/patients" },
          { label: patient.patientCode },
        ]}
        description={`${patient.name} · ${patient.phone}`}
        eyebrow="Sensitive clinical record"
        title={patient.patientCode}
        actions={
          <div className="page-action-group">
            <ButtonLink
              href="/admin/healthcare/prescriptions"
              icon="file"
              variant="secondary"
            >
              Prescriptions
            </ButtonLink>
            {canCreatePrescription ? (
              <ButtonLink
                href={`/admin/healthcare/prescriptions/create?patientId=${encodeURIComponent(patient.id)}`}
                icon="file"
              >
                New prescription
              </ButtonLink>
            ) : null}
          </div>
        }
      />
      <ClinicalFlash error={query.error} success={query.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            description="Longitudinal medical history. Changes are permission-gated and audited."
            title="Clinical profile"
          >
            {canEdit ? (
              <form
                action={`/api/admin/healthcare/patients/${patient.id}/clinical-profile`}
                className="admin-form-stack"
                method="post"
              >
                <div className="admin-form-grid">
                  <label className="form-field">
                    <span>Chronic conditions</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.chronicConditions ?? ""
                      }
                      maxLength={5000}
                      name="chronicConditions"
                      rows={4}
                    />
                  </label>
                  <label className="form-field">
                    <span>Current medications</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.currentMedications ?? ""
                      }
                      maxLength={5000}
                      name="currentMedications"
                      rows={4}
                    />
                  </label>
                  <label className="form-field">
                    <span>Past medical history</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.pastMedicalHistory ?? ""
                      }
                      maxLength={8000}
                      name="pastMedicalHistory"
                      rows={4}
                    />
                  </label>
                  <label className="form-field">
                    <span>Surgical history</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.surgicalHistory ?? ""
                      }
                      maxLength={5000}
                      name="surgicalHistory"
                      rows={4}
                    />
                  </label>
                  <label className="form-field">
                    <span>Family history</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.familyHistory ?? ""
                      }
                      maxLength={5000}
                      name="familyHistory"
                      rows={4}
                    />
                  </label>
                  <label className="form-field">
                    <span>Social history</span>
                    <textarea
                      defaultValue={
                        patient.clinicalProfile?.socialHistory ?? ""
                      }
                      maxLength={5000}
                      name="socialHistory"
                      rows={4}
                    />
                  </label>
                </div>
                <label className="form-field">
                  <span>Clinical notes</span>
                  <textarea
                    defaultValue={patient.clinicalProfile?.clinicalNotes ?? ""}
                    maxLength={8000}
                    name="clinicalNotes"
                    rows={5}
                  />
                </label>
                <button className="ui-button ui-button-primary" type="submit">
                  Save clinical profile
                </button>
              </form>
            ) : (
              <div className="appointment-detail-copy">
                <div>
                  <span>Chronic conditions</span>
                  <p>{display(patient.clinicalProfile?.chronicConditions)}</p>
                </div>
                <div>
                  <span>Current medications</span>
                  <p>{display(patient.clinicalProfile?.currentMedications)}</p>
                </div>
                <div>
                  <span>Past medical history</span>
                  <p>{display(patient.clinicalProfile?.pastMedicalHistory)}</p>
                </div>
                <div>
                  <span>Surgical history</span>
                  <p>{display(patient.clinicalProfile?.surgicalHistory)}</p>
                </div>
                <div>
                  <span>Family history</span>
                  <p>{display(patient.clinicalProfile?.familyHistory)}</p>
                </div>
                <div>
                  <span>Social history</span>
                  <p>{display(patient.clinicalProfile?.socialHistory)}</p>
                </div>
                <div>
                  <span>Clinical notes</span>
                  <p>{display(patient.clinicalProfile?.clinicalNotes)}</p>
                </div>
              </div>
            )}
          </SectionCard>

          <SectionCard
            description="Append-only observations. Existing measurements are preserved for auditability."
            title="Vitals & measurements"
          >
            {canEdit ? (
              <form
                action={`/api/admin/healthcare/patients/${patient.id}/vitals`}
                className="admin-form-stack"
                method="post"
              >
                <div className="admin-form-grid admin-form-grid-three">
                  <label className="form-field">
                    <span>Appointment</span>
                    <select defaultValue="" name="appointmentId">
                      <option value="">Not linked</option>
                      {patient.appointments.slice(0, 20).map((appointment) => (
                        <option key={appointment.id} value={appointment.id}>
                          {appointment.code} ·{" "}
                          {formatDisplayDate(appointment.appointmentDate)}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="form-field">
                    <span>Height (cm)</span>
                    <input
                      inputMode="decimal"
                      max="300"
                      min="20"
                      name="heightCm"
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Weight (kg)</span>
                    <input
                      inputMode="decimal"
                      max="500"
                      min="0.5"
                      name="weightKg"
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Temperature (°C)</span>
                    <input
                      inputMode="decimal"
                      max="50"
                      min="25"
                      name="temperatureC"
                      step="0.1"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Pulse (bpm)</span>
                    <input max="300" min="10" name="pulseBpm" type="number" />
                  </label>
                  <label className="form-field">
                    <span>Blood pressure</span>
                    <div className="filter-inline-form">
                      <input
                        max="300"
                        min="20"
                        name="systolicMmHg"
                        placeholder="Systolic"
                        type="number"
                      />
                      <input
                        max="250"
                        min="20"
                        name="diastolicMmHg"
                        placeholder="Diastolic"
                        type="number"
                      />
                    </div>
                  </label>
                  <label className="form-field">
                    <span>Respiratory rate</span>
                    <input
                      max="100"
                      min="1"
                      name="respiratoryRate"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>SpO₂ (%)</span>
                    <input
                      max="100"
                      min="0"
                      name="oxygenSaturation"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Blood glucose (mg/dL)</span>
                    <input
                      max="2000"
                      min="1"
                      name="bloodGlucoseMgDl"
                      step="0.01"
                      type="number"
                    />
                  </label>
                </div>
                <label className="form-field">
                  <span>Measurement note</span>
                  <textarea maxLength={3000} name="notes" rows={3} />
                </label>
                <button className="ui-button ui-button-secondary" type="submit">
                  Record vitals
                </button>
              </form>
            ) : null}
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Recorded</th>
                    <th>Appointment</th>
                    <th>Measurements</th>
                    <th>Recorder</th>
                  </tr>
                </thead>
                <tbody>
                  {patient.vitals.map((vital) => (
                    <tr key={vital.id}>
                      <td>
                        <strong>
                          {vital.recordedAt.toLocaleString("en-GB", {
                            timeZone: "Asia/Dhaka",
                          })}
                        </strong>
                        <span>{vital.notes ?? ""}</span>
                      </td>
                      <td>{vital.appointment?.code ?? "—"}</td>
                      <td>
                        <span>
                          {vital.heightCm ? `${Number(vital.heightCm)} cm` : ""}{" "}
                          {vital.weightKg
                            ? `· ${Number(vital.weightKg)} kg`
                            : ""}
                        </span>
                        <span>
                          {vital.temperatureC
                            ? `${Number(vital.temperatureC)} °C`
                            : ""}{" "}
                          {vital.pulseBpm ? `· Pulse ${vital.pulseBpm}` : ""}
                        </span>
                        <span>
                          {vital.systolicMmHg && vital.diastolicMmHg
                            ? `BP ${vital.systolicMmHg}/${vital.diastolicMmHg}`
                            : ""}{" "}
                          {vital.oxygenSaturation !== null
                            ? `· SpO₂ ${vital.oxygenSaturation}%`
                            : ""}
                        </span>
                      </td>
                      <td>{vital.recordedBy?.name ?? "System"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {patient.vitals.length === 0 ? (
                <div className="table-empty">No vitals recorded yet.</div>
              ) : null}
            </div>
          </SectionCard>

          <SectionCard
            title="Visit timeline"
            description="Appointments, encounter notes, and linked prescription versions."
          >
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Visit</th>
                    <th>Doctor</th>
                    <th>Status</th>
                    <th>Clinical summary</th>
                    <th>Prescription</th>
                  </tr>
                </thead>
                <tbody>
                  {patient.appointments.map((appointment) => (
                    <tr key={appointment.id}>
                      <td>
                        <Link
                          href={`/admin/healthcare/appointments/${appointment.id}`}
                        >
                          <strong>
                            {formatDisplayDate(appointment.appointmentDate)}
                          </strong>
                          <span>{appointment.code}</span>
                        </Link>
                      </td>
                      <td>
                        <strong>{appointment.doctor.name}</strong>
                        <span>{appointment.doctor.specialization}</span>
                      </td>
                      <td>
                        <AppointmentStatusBadge status={appointment.status} />
                      </td>
                      <td>
                        <strong>
                          {appointment.clinicalEncounter?.diagnosis ??
                            "No diagnosis recorded"}
                        </strong>
                        <span>
                          {appointment.clinicalEncounter?.followUpDate
                            ? `Follow-up ${formatDisplayDate(appointment.clinicalEncounter.followUpDate)}`
                            : ""}
                        </span>
                      </td>
                      <td>
                        {appointment.prescriptions.length
                          ? appointment.prescriptions.map((prescription) => (
                              <Link
                                href={`/admin/healthcare/prescriptions/${prescription.id}`}
                                key={prescription.id}
                              >
                                <span>
                                  {prescription.code} v{prescription.version}
                                </span>
                              </Link>
                            ))
                          : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {patient.appointments.length === 0 ? (
                <div className="table-empty">No appointment history.</div>
              ) : null}
            </div>
          </SectionCard>
        </div>

        <div className="content-stack">
          <SectionCard title="Patient identity">
            <div className="status-list">
              <div>
                <span>Name</span>
                <strong>{patient.name}</strong>
              </div>
              <div>
                <span>Phone</span>
                <strong>{patient.phone}</strong>
              </div>
              <div>
                <span>Email</span>
                <strong>{patient.email ?? "—"}</strong>
              </div>
              <div>
                <span>Date of birth</span>
                <strong>
                  {patient.dateOfBirth
                    ? formatDisplayDate(patient.dateOfBirth)
                    : "—"}
                </strong>
              </div>
              <div>
                <span>Gender</span>
                <strong>{patient.gender ?? "—"}</strong>
              </div>
              <div>
                <span>Blood group</span>
                <strong>{patient.bloodGroup ?? "—"}</strong>
              </div>
              <div>
                <span>Allergies</span>
                <strong>{patient.allergies ?? "Not recorded"}</strong>
              </div>
              <div>
                <span>Status</span>
                <StatusBadge
                  tone={patient.status === "ACTIVE" ? "success" : "neutral"}
                >
                  {patient.status}
                </StatusBadge>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Prescriptions">
            <div className="content-stack">
              {patient.prescriptions.map((prescription) => (
                <div className="notice-box" key={prescription.id}>
                  <div className="status-list">
                    <div>
                      <span>
                        {prescription.code} · v{prescription.version}
                      </span>
                      <StatusBadge
                        tone={prescriptionStatusTone(prescription.status)}
                      >
                        {prescriptionStatusLabel(prescription.status)}
                      </StatusBadge>
                    </div>
                  </div>
                  <p>
                    {prescription.doctor.name} · {prescription.items.length}{" "}
                    medicine(s)
                  </p>
                  <ButtonLink
                    href={`/admin/healthcare/prescriptions/${prescription.id}`}
                    variant="quiet"
                  >
                    Open
                  </ButtonLink>
                </div>
              ))}
              {patient.prescriptions.length === 0 ? (
                <p className="muted-copy">No prescriptions recorded.</p>
              ) : null}
            </div>
          </SectionCard>
          {patient.clinicalProfile?.updatedAt ? (
            <SectionCard title="Record audit">
              <div className="status-list">
                <div>
                  <span>Clinical profile updated</span>
                  <strong>
                    {patient.clinicalProfile.updatedAt.toLocaleString("en-GB", {
                      timeZone: "Asia/Dhaka",
                    })}
                  </strong>
                </div>
                <div>
                  <span>Updated by</span>
                  <strong>
                    {patient.clinicalProfile.updatedBy?.name ?? "System"}
                  </strong>
                </div>
              </div>
            </SectionCard>
          ) : null}
        </div>
      </div>
    </>
  );
}
