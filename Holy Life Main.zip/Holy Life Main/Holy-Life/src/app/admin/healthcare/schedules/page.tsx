import Link from "next/link";
import {
  AppointmentFlash,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { doctorAccessWhere } from "@/lib/appointments/access";
import {
  formatDisplayDate,
  formatDisplayTime,
  todayInDhaka,
} from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
const weekdayLabels = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export default async function DoctorSchedulesPage({
  searchParams,
}: {
  searchParams: Promise<{
    doctorId?: string;
    success?: string;
    error?: string;
  }>;
}) {
  const session = await requirePermission(
    "healthcare.doctors.schedule.manage",
    "/admin/healthcare/schedules",
  );
  const params = await searchParams;
  const doctors = await db.doctorProfile.findMany({
    where: {
      AND: [
        doctorAccessWhere(session.user, "healthcare.doctors.schedule.manage"),
        { status: { not: "ARCHIVED" } },
      ],
    },
    include: { department: true },
    orderBy: [{ status: "asc" }, { displayOrder: "asc" }, { name: "asc" }],
  });
  const selectedDoctorId = doctors.some(
    (doctor) => doctor.id === params.doctorId,
  )
    ? params.doctorId!
    : (doctors[0]?.id ?? "");
  const selectedDoctor = selectedDoctorId
    ? await db.doctorProfile.findFirst({
        where: {
          AND: [
            { id: selectedDoctorId },
            doctorAccessWhere(
              session.user,
              "healthcare.doctors.schedule.manage",
            ),
          ],
        },
        include: {
          department: true,
          schedules: { orderBy: [{ weekday: "asc" }, { startTime: "asc" }] },
          availability: {
            where: { date: { gte: new Date(`${todayInDhaka()}T00:00:00Z`) } },
            orderBy: [{ date: "asc" }, { startTime: "asc" }],
            take: 50,
          },
        },
      })
    : null;

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Healthcare" },
          { label: "Schedules" },
        ]}
        description="Configure recurring weekly windows, capacity, breaks, leave, blocked periods, and date-specific availability."
        eyebrow="Availability management"
        title="Doctor schedules"
        actions={
          selectedDoctor ? (
            <ButtonLink
              href={`/appointment?doctorId=${selectedDoctor.id}&date=${todayInDhaka()}#book`}
              icon="globe"
            >
              View public slots
            </ButtonLink>
          ) : undefined
        }
      />
      <AppointmentFlash error={params.error} success={params.success} />
      <SectionCard
        description="Select a doctor before editing weekly or date-specific availability."
        title="Doctor selector"
      >
        <form className="schedule-doctor-selector" method="get">
          <label className="form-field">
            <span>Doctor</span>
            <select defaultValue={selectedDoctorId} name="doctorId" required>
              {doctors.map((doctor) => (
                <option key={doctor.id} value={doctor.id}>
                  {doctor.name} — {doctor.department.name}
                </option>
              ))}
            </select>
          </label>
          <button className="ui-button ui-button-primary" type="submit">
            Open schedule
          </button>
        </form>
      </SectionCard>

      {selectedDoctor ? (
        <div className="content-grid content-grid-main">
          <div className="content-stack">
            <SectionCard
              description="Add one or more consultation windows for each weekday."
              title="Weekly schedule"
            >
              <div className="schedule-doctor-heading">
                <DoctorAvatar
                  imageUrl={selectedDoctor.imageUrl}
                  name={selectedDoctor.name}
                  size="small"
                />
                <div>
                  <strong>{selectedDoctor.name}</strong>
                  <span>{selectedDoctor.specialization}</span>
                </div>
                <StatusBadge
                  tone={
                    selectedDoctor.status === "ACTIVE" ? "success" : "warning"
                  }
                >
                  {selectedDoctor.status}
                </StatusBadge>
              </div>
              <form
                action="/api/admin/healthcare/schedules"
                className="admin-form-stack schedule-create-form"
                method="post"
              >
                <input
                  name="doctorId"
                  type="hidden"
                  value={selectedDoctor.id}
                />
                <div className="admin-form-grid admin-form-grid-three">
                  <label className="form-field">
                    <span>Weekday</span>
                    <select defaultValue="0" name="weekday">
                      {weekdayLabels.map((label, index) => (
                        <option key={label} value={index}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="form-field">
                    <span>Start time</span>
                    <input
                      defaultValue="09:00"
                      name="startTime"
                      required
                      type="time"
                    />
                  </label>
                  <label className="form-field">
                    <span>End time</span>
                    <input
                      defaultValue="14:00"
                      name="endTime"
                      required
                      type="time"
                    />
                  </label>
                  <label className="form-field">
                    <span>Slot duration</span>
                    <select defaultValue="30" name="slotMinutes">
                      <option value="15">15 minutes</option>
                      <option value="20">20 minutes</option>
                      <option value="30">30 minutes</option>
                      <option value="45">45 minutes</option>
                      <option value="60">60 minutes</option>
                    </select>
                  </label>
                  <label className="form-field">
                    <span>Capacity per slot</span>
                    <input
                      defaultValue="1"
                      max="20"
                      min="1"
                      name="maxPatients"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Break start</span>
                    <input name="breakStart" type="time" />
                  </label>
                  <label className="form-field">
                    <span>Break end</span>
                    <input name="breakEnd" type="time" />
                  </label>
                  <label className="form-check form-check-inline">
                    <input defaultChecked name="isActive" type="checkbox" />
                    <span>
                      <strong>Active</strong>
                      <small>Use this window for slot generation.</small>
                    </span>
                  </label>
                </div>
                <button className="ui-button ui-button-primary" type="submit">
                  Save weekly window
                </button>
              </form>
              <div className="schedule-window-list">
                {selectedDoctor.schedules.map((schedule) => (
                  <article className="schedule-window-item" key={schedule.id}>
                    <div>
                      <strong>
                        {weekdayLabels[schedule.weekday] ??
                          `Day ${schedule.weekday}`}
                      </strong>
                      <span>
                        {formatDisplayTime(schedule.startTime)} –{" "}
                        {formatDisplayTime(schedule.endTime)} ·{" "}
                        {schedule.slotMinutes} min · capacity{" "}
                        {schedule.maxPatients}
                      </span>
                      <small>
                        {schedule.breakStart && schedule.breakEnd
                          ? `Break ${formatDisplayTime(schedule.breakStart)}–${formatDisplayTime(schedule.breakEnd)}`
                          : "No break"}
                      </small>
                    </div>
                    <div>
                      <StatusBadge
                        tone={schedule.isActive ? "success" : "neutral"}
                      >
                        {schedule.isActive ? "Active" : "Disabled"}
                      </StatusBadge>
                      <form
                        action={`/api/admin/healthcare/schedules/${schedule.id}/delete`}
                        method="post"
                      >
                        <button className="table-action-button" type="submit">
                          Remove
                        </button>
                      </form>
                    </div>
                  </article>
                ))}
                {selectedDoctor.schedules.length === 0 ? (
                  <div className="table-empty">
                    No weekly schedule has been configured.
                  </div>
                ) : null}
              </div>
            </SectionCard>
          </div>

          <div className="content-stack">
            <SectionCard
              description="Create leave, block a time range, or add a special available window for one date."
              title="Date override"
            >
              <form
                action="/api/admin/healthcare/availability"
                className="admin-form-stack"
                method="post"
              >
                <input
                  name="doctorId"
                  type="hidden"
                  value={selectedDoctor.id}
                />
                <label className="form-field">
                  <span>Date</span>
                  <input
                    min={todayInDhaka()}
                    name="date"
                    required
                    type="date"
                  />
                </label>
                <label className="form-field">
                  <span>Override type</span>
                  <select defaultValue="LEAVE" name="kind">
                    <option value="LEAVE">Full-day leave</option>
                    <option value="BLOCKED">
                      Block full day or time range
                    </option>
                    <option value="AVAILABLE">Special available window</option>
                  </select>
                </label>
                <div className="admin-form-grid">
                  <label className="form-field">
                    <span>Start time (optional)</span>
                    <input name="startTime" type="time" />
                  </label>
                  <label className="form-field">
                    <span>End time (optional)</span>
                    <input name="endTime" type="time" />
                  </label>
                  <label className="form-field">
                    <span>Slot minutes</span>
                    <input
                      defaultValue="30"
                      min="5"
                      name="slotMinutes"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Capacity</span>
                    <input
                      defaultValue="1"
                      min="1"
                      name="maxPatients"
                      type="number"
                    />
                  </label>
                </div>
                <label className="form-field">
                  <span>Reason / note</span>
                  <input
                    maxLength={300}
                    name="reason"
                    placeholder="Conference, emergency leave, special clinic..."
                  />
                </label>
                <button className="ui-button ui-button-primary" type="submit">
                  Add override
                </button>
              </form>
              <div className="schedule-override-list">
                {selectedDoctor.availability.map((override) => (
                  <article key={override.id}>
                    <div>
                      <strong>{formatDisplayDate(override.date)}</strong>
                      <span>
                        {override.kind}
                        {override.startTime && override.endTime
                          ? ` · ${formatDisplayTime(override.startTime)}–${formatDisplayTime(override.endTime)}`
                          : " · full day"}
                      </span>
                      <small>{override.reason ?? "No note"}</small>
                    </div>
                    <form
                      action={`/api/admin/healthcare/availability/${override.id}/delete`}
                      method="post"
                    >
                      <button className="table-action-button" type="submit">
                        Remove
                      </button>
                    </form>
                  </article>
                ))}
                {selectedDoctor.availability.length === 0 ? (
                  <div className="table-empty">No upcoming overrides.</div>
                ) : null}
              </div>
            </SectionCard>
            <SectionCard
              description="Public booking uses schedule + override + existing appointment capacity in one server-side calculation."
              title="Availability rules"
            >
              <div className="status-list">
                <div>
                  <span>Timezone</span>
                  <StatusBadge tone="info">Asia/Dhaka</StatusBadge>
                </div>
                <div>
                  <span>Double booking</span>
                  <StatusBadge tone="success">Database protected</StatusBadge>
                </div>
                <div>
                  <span>Booking window</span>
                  <StatusBadge tone="neutral">90 days</StatusBadge>
                </div>
              </div>
              <Link
                className="ui-button ui-button-quiet"
                href={`/appointment?doctorId=${selectedDoctor.id}&date=${todayInDhaka()}#book`}
              >
                Open public availability
              </Link>
            </SectionCard>
          </div>
        </div>
      ) : (
        <SectionCard title="No doctors available">
          <div className="table-empty">
            Create a doctor profile before adding schedules.
          </div>
        </SectionCard>
      )}
    </>
  );
}
