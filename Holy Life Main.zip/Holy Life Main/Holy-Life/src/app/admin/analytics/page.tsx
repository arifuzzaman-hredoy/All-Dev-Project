import Link from "next/link";
import { MetricCard, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireGlobalPermission } from "@/lib/auth/authorization";
import { hasGlobalPermission } from "@/lib/auth/session";
import { formatMoney } from "@/lib/commerce/money";
import { platformAnalytics } from "@/lib/analytics/queries";
import { analyticsRange } from "@/lib/analytics/validation";

export const dynamic = "force-dynamic";

export default async function AnalyticsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const session = await requireGlobalPermission(
    "system.analytics.platform.view",
    "/admin/analytics",
  );
  const query = await searchParams;
  const range = analyticsRange(query.from, query.to);
  const data = await platformAnalytics(range);

  const exportQuery = new URLSearchParams();
  if (query.from) exportQuery.set("from", query.from);
  if (query.to) exportQuery.set("to", query.to);

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Platform insights"
        title="Platform analytics"
        description="Cross-module operational KPIs backed by healthcare, commerce, learning, finance, and audit records."
        actions={
          hasGlobalPermission(
            session.user,
            "system.analytics.platform.export",
          ) ? (
            <Link
              className="ui-button ui-button-primary"
              href={`/api/admin/analytics/export.csv?${exportQuery.toString()}`}
            >
              Export summary CSV
            </Link>
          ) : undefined
        }
      />

      <SectionCard
        title="Analytics period"
        description="Date filters are evaluated in Asia/Dhaka and limited to 366 days."
      >
        <form className="finance-filter-form" method="get">
          <label className="form-field">
            <span>From</span>
            <input defaultValue={query.from ?? ""} name="from" type="date" />
          </label>
          <label className="form-field">
            <span>To</span>
            <input defaultValue={query.to ?? ""} name="to" type="date" />
          </label>
          <button className="ui-button ui-button-secondary" type="submit">
            Apply range
          </button>
        </form>
      </SectionCard>

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="reports"
          label="Verified net revenue"
          value={formatMoney(data.revenue.total)}
          helper="Ledger-backed"
          tone="success"
        />
        <MetricCard
          icon="appointment"
          label="Appointments"
          value={String(data.appointments)}
          helper={`${data.completedAppointments} completed`}
          tone="health"
        />
        <MetricCard
          icon="cart"
          label="Orders"
          value={String(data.orders)}
          helper={`${data.deliveredOrders} delivered`}
          tone="commerce"
        />
        <MetricCard
          icon="learning"
          label="Enrollments"
          value={String(data.enrollments)}
          helper={`${data.completions} completed`}
          tone="learning"
        />
      </div>

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="users"
          label="New users"
          value={String(data.users)}
          helper={`${data.patients} patient records`}
        />
        <MetricCard
          icon="file"
          label="Signed prescriptions"
          value={String(data.signedPrescriptions)}
          helper="Authenticated sign-and-lock"
          tone="health"
        />
        <MetricCard
          icon="file"
          label="Certificates"
          value={String(data.certificates)}
          helper="Issued in range"
          tone="learning"
        />
        <MetricCard
          icon="shield"
          label="Sensitive views"
          value={String(data.sensitiveViews)}
          helper={`${data.auditEvents} audit events`}
          tone="warning"
        />
      </div>

      <div className="three-column-grid">
        <SectionCard title="Healthcare revenue">
          <strong className="finance-report-number">
            {formatMoney(data.revenue.healthcare)}
          </strong>
        </SectionCard>
        <SectionCard title="Commerce revenue">
          <strong className="finance-report-number">
            {formatMoney(data.revenue.commerce)}
          </strong>
        </SectionCard>
        <SectionCard title="Learning revenue">
          <strong className="finance-report-number">
            {formatMoney(data.revenue.learning)}
          </strong>
        </SectionCard>
      </div>

      <div className="three-column-grid">
        <SectionCard title="Top products">
          <ol className="commerce-ranked-list">
            {data.topProducts.length ? (
              data.topProducts.map((item) => (
                <li key={item.id}>
                  <strong>{item.name}</strong>
                  <span>
                    {item.quantity} sold · {formatMoney(item.revenue)}
                  </span>
                </li>
              ))
            ) : (
              <li>No product activity in this range.</li>
            )}
          </ol>
        </SectionCard>
        <SectionCard title="Top courses">
          <ol className="commerce-ranked-list">
            {data.topCourses.length ? (
              data.topCourses.map((item) => (
                <li key={item.id}>
                  <strong>{item.title}</strong>
                  <span>{item.enrollments} enrollments</span>
                </li>
              ))
            ) : (
              <li>No course enrollments in this range.</li>
            )}
          </ol>
        </SectionCard>
        <SectionCard title="Top doctors">
          <ol className="commerce-ranked-list">
            {data.topDoctors.length ? (
              data.topDoctors.map((item) => (
                <li key={item.id}>
                  <strong>{item.name}</strong>
                  <span>
                    {item.appointments} appointments · {item.specialization}
                  </span>
                </li>
              ))
            ) : (
              <li>No appointment activity in this range.</li>
            )}
          </ol>
        </SectionCard>
      </div>
    </div>
  );
}
