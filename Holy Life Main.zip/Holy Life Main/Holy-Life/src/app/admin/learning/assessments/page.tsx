import Link from "next/link";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  await requirePermission(
    "learning.assessments.quiz.manage",
    "/admin/learning/assessments",
  );
  const [quizzes, courses] = await Promise.all([
    db.quiz.findMany({
      include: {
        course: true,
        _count: { select: { questions: true, attempts: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
    db.course.findMany({
      where: { status: { not: "ARCHIVED" } },
      orderBy: { title: "asc" },
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Assessments"
        description="Create quizzes and configure passing rules."
      />
      <SectionCard title="Create quiz">
        <form
          action="/api/admin/learning/quizzes"
          className="inline-form"
          method="post"
        >
          <select name="courseId" required>
            <option value="">Course</option>
            {courses.map((item) => (
              <option value={item.id} key={item.id}>
                {item.title}
              </option>
            ))}
          </select>
          <input name="title" placeholder="Quiz title" required />
          <input
            name="passingScore"
            type="number"
            min="0"
            max="100"
            defaultValue="60"
          />
          <button className="ui-button ui-button-primary" type="submit">
            Create
          </button>
        </form>
      </SectionCard>
      <SectionCard title="Quizzes">
        <div className="compact-list">
          {quizzes.map((quiz) => (
            <div key={quiz.id}>
              <strong>
                <Link href={`/admin/learning/assessments/${quiz.id}`}>
                  {quiz.title}
                </Link>
              </strong>
              <span>
                {quiz.course.title} · {quiz._count.questions} questions ·{" "}
                {quiz._count.attempts} attempts
              </span>
              <StatusBadge
                tone={quiz.status === "PUBLISHED" ? "success" : "warning"}
              >
                {quiz.status}
              </StatusBadge>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
