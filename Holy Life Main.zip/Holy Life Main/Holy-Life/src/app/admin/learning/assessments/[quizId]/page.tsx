import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ quizId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "learning.assessments.quiz.manage",
    "/admin/learning/assessments",
  );
  const { quizId } = await params;
  const query = await searchParams;
  const quiz = await db.quiz.findUnique({
    where: { id: quizId },
    include: {
      course: true,
      questions: {
        include: { options: { orderBy: { position: "asc" } } },
        orderBy: { position: "asc" },
      },
      _count: { select: { attempts: true } },
    },
  });
  if (!quiz) notFound();
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning assessment"
        title={quiz.title}
        description={`${quiz.course.title} · Pass ${quiz.passingScore}% · ${quiz._count.attempts} attempt(s)`}
        actions={
          <StatusBadge
            tone={quiz.status === "PUBLISHED" ? "success" : "warning"}
          >
            {quiz.status}
          </StatusBadge>
        }
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}
      <div className="admin-two-column">
        <SectionCard
          title="Questions"
          description={`${quiz.questions.length} question(s)`}
        >
          <div className="learning-admin-modules">
            {quiz.questions.map((question) => (
              <article key={question.id}>
                <header>
                  <strong>
                    {question.position}. {question.prompt}
                  </strong>
                  <span>{question.points} point(s)</span>
                </header>
                {question.options.map((option) => (
                  <div key={option.id}>
                    {option.position}. {option.label}
                    <span>{option.isCorrect ? "Correct" : ""}</span>
                  </div>
                ))}
              </article>
            ))}
          </div>
        </SectionCard>
        <SectionCard title="Publish">
          <form
            action={`/api/admin/learning/quizzes/${quiz.id}/status`}
            method="post"
            className="panel-form"
          >
            <label>
              Status
              <select name="status" defaultValue={quiz.status}>
                <option>DRAFT</option>
                <option>PUBLISHED</option>
                <option>ARCHIVED</option>
              </select>
            </label>
            <button className="ui-button ui-button-primary" type="submit">
              Update quiz
            </button>
          </form>
        </SectionCard>
      </div>
      <SectionCard title="Add multiple-choice question">
        <form
          action={`/api/admin/learning/quizzes/${quiz.id}/questions`}
          method="post"
          className="panel-form"
        >
          <label className="form-span-2">
            Question
            <input name="prompt" required maxLength={500} />
          </label>
          <label>
            Points
            <input
              name="points"
              type="number"
              min="1"
              max="100"
              defaultValue="1"
            />
          </label>
          <label>
            Correct option
            <select name="correctOption" defaultValue="A">
              <option>A</option>
              <option>B</option>
              <option>C</option>
              <option>D</option>
            </select>
          </label>
          <label>
            Option A<input name="optionA" required />
          </label>
          <label>
            Option B<input name="optionB" required />
          </label>
          <label>
            Option C<input name="optionC" required />
          </label>
          <label>
            Option D<input name="optionD" required />
          </label>
          <label className="form-span-2">
            Explanation
            <textarea name="explanation" rows={3} />
          </label>
          <div className="form-span-2">
            <button className="ui-button ui-button-primary" type="submit">
              Add question
            </button>
          </div>
        </form>
      </SectionCard>
    </div>
  );
}
