import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "learning.enrollments.enrollment.view",
    "/admin/learning/enrollments",
  );
  const query = await searchParams;
  const [enrollments, courses, users] = await Promise.all([
    db.courseEnrollment.findMany({
      include: {
        course: true,
        user: { select: { name: true, email: true, phone: true } },
        certificate: true,
      },
      orderBy: { updatedAt: "desc" },
      take: 150,
    }),
    db.course.findMany({
      where: { status: { in: ["PUBLISHED", "UNPUBLISHED"] } },
      orderBy: { title: "asc" },
    }),
    db.user.findMany({
      where: { status: "ACTIVE" },
      select: { id: true, name: true, email: true, phone: true },
      orderBy: { name: "asc" },
      take: 200,
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Enrollments"
        description="Enroll students, monitor progress and manage completion."
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}
      <SectionCard title="Enroll a student">
        <form
          action="/api/admin/learning/enrollments"
          className="inline-form"
          method="post"
        >
          <select name="courseId" required>
            <option value="">Course</option>
            {courses.map((item) => (
              <option key={item.id} value={item.id}>
                {item.title}
              </option>
            ))}
          </select>
          <select name="userId" required>
            <option value="">Student</option>
            {users.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name} · {item.email ?? item.phone}
              </option>
            ))}
          </select>
          <button className="ui-button ui-button-primary" type="submit">
            Enroll
          </button>
        </form>
      </SectionCard>
      <SectionCard
        title="Student progress"
        description={`${enrollments.length} enrollment(s)`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Course</th>
                <th>Progress</th>
                <th>Status</th>
                <th>Certificate</th>
              </tr>
            </thead>
            <tbody>
              {enrollments.map((item) => (
                <tr key={item.id}>
                  <td>
                    <strong>{item.user.name}</strong>
                    <span>{item.user.email ?? item.user.phone}</span>
                  </td>
                  <td>{item.course.title}</td>
                  <td>{item.progressPercent}%</td>
                  <td>
                    <StatusBadge
                      tone={
                        item.status === "COMPLETED"
                          ? "success"
                          : item.status === "ACTIVE"
                            ? "info"
                            : "neutral"
                      }
                    >
                      {item.status}
                    </StatusBadge>
                  </td>
                  <td>
                    {item.certificate ? (
                      item.certificate.code
                    ) : item.status === "COMPLETED" ? (
                      <form
                        action="/api/admin/learning/certificates"
                        method="post"
                      >
                        <input
                          type="hidden"
                          name="enrollmentId"
                          value={item.id}
                        />
                        <button
                          className="ui-button ui-button-quiet"
                          type="submit"
                        >
                          Issue
                        </button>
                      </form>
                    ) : (
                      "—"
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
