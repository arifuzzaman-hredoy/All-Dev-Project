import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  await requirePermission(
    "learning.courses.course.edit",
    "/admin/learning/reviews",
  );
  const reviews = await db.courseReview.findMany({
    include: { course: true, user: { select: { name: true, email: true } } },
    orderBy: { createdAt: "desc" },
    take: 150,
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Course reviews"
        description="Moderation queue for student course feedback."
      />
      <SectionCard title="Reviews">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Course</th>
                <th>Rating</th>
                <th>Comment</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {reviews.map((item) => (
                <tr key={item.id}>
                  <td>
                    {item.user.name}
                    <span>{item.user.email}</span>
                  </td>
                  <td>{item.course.title}</td>
                  <td>{item.rating}/5</td>
                  <td>{item.comment ?? item.title ?? "—"}</td>
                  <td>
                    <StatusBadge
                      tone={
                        item.status === "PUBLISHED"
                          ? "success"
                          : item.status === "REJECTED"
                            ? "danger"
                            : "warning"
                      }
                    >
                      {item.status}
                    </StatusBadge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
