import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  await requirePermission(
    "learning.certificates.certificate.issue",
    "/admin/learning/certificates",
  );
  const certificates = await db.courseCertificate.findMany({
    include: { course: true, user: { select: { name: true, email: true } } },
    orderBy: { issuedAt: "desc" },
    take: 150,
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Certificates"
        description="Verified completion credentials issued from completed enrollments."
      />
      <SectionCard title="Issued certificates">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Student</th>
                <th>Course</th>
                <th>Issued</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {certificates.map((item) => (
                <tr key={item.id}>
                  <td>
                    <strong>{item.code}</strong>
                  </td>
                  <td>
                    {item.user.name}
                    <span>{item.user.email}</span>
                  </td>
                  <td>{item.course.title}</td>
                  <td>{item.issuedAt.toLocaleDateString("en-BD")}</td>
                  <td>
                    <StatusBadge
                      tone={item.status === "ISSUED" ? "success" : "danger"}
                    >
                      {item.status}
                    </StatusBadge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
