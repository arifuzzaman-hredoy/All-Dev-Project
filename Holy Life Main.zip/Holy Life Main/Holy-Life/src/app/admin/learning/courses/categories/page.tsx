import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "learning.courses.course.edit",
    "/admin/learning/courses/categories",
  );
  const query = await searchParams;
  const [categories, instructors] = await Promise.all([
    db.courseCategory.findMany({
      include: { _count: { select: { courses: true } } },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.instructorProfile.findMany({
      include: { _count: { select: { courses: true } } },
      orderBy: { name: "asc" },
    }),
  ]);

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning catalog"
        title="Categories & instructors"
        description="বাংলা ও English—দুই ভাষায় course catalog এবং instructor profile পরিচালনা করুন।"
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}

      <div className="admin-two-column admin-two-column-wide">
        <SectionCard
          title="Course categories"
          description="Public catalog-এর category label, order ও visibility এখান থেকে নিয়ন্ত্রণ করুন।"
        >
          <form
            action="/api/admin/learning/categories"
            className="panel-form"
            method="post"
          >
            <div className="admin-form-section">
              <div className="admin-form-section-heading">
                <strong>নতুন Category</strong>
                <span>English ও বাংলা নাম আলাদাভাবে দিন।</span>
              </div>
              <div className="panel-form-grid">
                <label>
                  নাম (English)
                  <input maxLength={100} name="name" required />
                </label>
                <label>
                  নাম (বাংলা)
                  <input maxLength={100} name="nameBn" />
                </label>
                <label>
                  Slug
                  <input
                    maxLength={120}
                    name="slug"
                    placeholder="healthy-living"
                  />
                </label>
                <label>
                  Display order
                  <input
                    defaultValue={0}
                    min={0}
                    max={100000}
                    name="displayOrder"
                    type="number"
                  />
                </label>
                <label className="form-span-2">
                  Description (English)
                  <textarea maxLength={500} name="description" rows={3} />
                </label>
                <label className="form-span-2">
                  বর্ণনা (বাংলা)
                  <textarea maxLength={500} name="descriptionBn" rows={3} />
                </label>
              </div>
              <label className="form-checkbox">
                <input
                  defaultChecked
                  name="isActive"
                  type="checkbox"
                  value="true"
                />
                <span>Active রাখুন</span>
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Category তৈরি করুন
            </button>
          </form>

          <div className="managed-record-list">
            {categories.map((item) => (
              <details className="managed-record" key={item.id}>
                <summary>
                  <span>
                    <strong>{item.nameBn || item.name}</strong>
                    <small>
                      {item.name} · {item._count.courses} course
                    </small>
                  </span>
                  <StatusBadge tone={item.isActive ? "success" : "neutral"}>
                    {item.isActive ? "ACTIVE" : "INACTIVE"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/learning/categories/${item.id}`}
                  className="panel-form managed-record-form"
                  method="post"
                >
                  <div className="panel-form-grid">
                    <label>
                      নাম (English)
                      <input
                        defaultValue={item.name}
                        maxLength={100}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={item.nameBn ?? ""}
                        maxLength={100}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Slug
                      <input
                        defaultValue={item.slug}
                        maxLength={120}
                        name="slug"
                        required
                      />
                    </label>
                    <label>
                      Display order
                      <input
                        defaultValue={item.displayOrder}
                        min={0}
                        max={100000}
                        name="displayOrder"
                        type="number"
                      />
                    </label>
                    <label className="form-span-2">
                      Description (English)
                      <textarea
                        defaultValue={item.description ?? ""}
                        maxLength={500}
                        name="description"
                        rows={3}
                      />
                    </label>
                    <label className="form-span-2">
                      বর্ণনা (বাংলা)
                      <textarea
                        defaultValue={item.descriptionBn ?? ""}
                        maxLength={500}
                        name="descriptionBn"
                        rows={3}
                      />
                    </label>
                  </div>
                  <label className="form-checkbox">
                    <input
                      defaultChecked={item.isActive}
                      name="isActive"
                      type="checkbox"
                      value="true"
                    />
                    <span>Active</span>
                  </label>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Category আপডেট করুন
                  </button>
                </form>
              </details>
            ))}
          </div>
        </SectionCard>

        <SectionCard
          title="Instructor profiles"
          description="Instructor পরিচিতি, ছবি, expertise ও public visibility পরিচালনা করুন।"
        >
          <form
            action="/api/admin/learning/instructors"
            className="panel-form"
            method="post"
          >
            <div className="admin-form-section">
              <div className="admin-form-section-heading">
                <strong>নতুন Instructor</strong>
                <span>
                  Public course page-এ যেসব তথ্য দেখাবেন সেগুলো পূরণ করুন।
                </span>
              </div>
              <div className="panel-form-grid">
                <label>
                  নাম (English)
                  <input maxLength={120} name="name" required />
                </label>
                <label>
                  নাম (বাংলা)
                  <input maxLength={120} name="nameBn" />
                </label>
                <label>
                  Title (English)
                  <input maxLength={160} name="title" />
                </label>
                <label>
                  Title (বাংলা)
                  <input maxLength={160} name="titleBn" />
                </label>
                <label>
                  Email
                  <input maxLength={200} name="email" type="email" />
                </label>
                <label>
                  Phone
                  <input maxLength={30} name="phone" />
                </label>
                <label className="form-span-2">
                  Photo URL
                  <input
                    maxLength={1000}
                    name="photoUrl"
                    placeholder="https://..."
                    type="url"
                  />
                </label>
                <label className="form-span-2">
                  Expertise (English)
                  <textarea
                    maxLength={500}
                    name="expertise"
                    placeholder="One item per line"
                    rows={3}
                  />
                </label>
                <label className="form-span-2">
                  Expertise (বাংলা)
                  <textarea
                    maxLength={500}
                    name="expertiseBn"
                    placeholder="প্রতি লাইনে একটি বিষয়"
                    rows={3}
                  />
                </label>
                <label className="form-span-2">
                  Bio (English)
                  <textarea maxLength={2000} name="bio" rows={4} />
                </label>
                <label className="form-span-2">
                  পরিচিতি (বাংলা)
                  <textarea maxLength={2000} name="bioBn" rows={4} />
                </label>
              </div>
              <label className="form-checkbox">
                <input
                  defaultChecked
                  name="isActive"
                  type="checkbox"
                  value="true"
                />
                <span>Active রাখুন</span>
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Instructor তৈরি করুন
            </button>
          </form>

          <div className="managed-record-list">
            {instructors.map((item) => (
              <details className="managed-record" key={item.id}>
                <summary>
                  <span>
                    <strong>{item.nameBn || item.name}</strong>
                    <small>
                      {item.titleBn || item.title || "Instructor"} ·{" "}
                      {item._count.courses} course
                    </small>
                  </span>
                  <StatusBadge tone={item.isActive ? "success" : "neutral"}>
                    {item.isActive ? "ACTIVE" : "INACTIVE"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/learning/instructors/${item.id}`}
                  className="panel-form managed-record-form"
                  method="post"
                >
                  {item.photoUrl ? (
                    <img
                      className="admin-media-preview admin-media-preview-avatar"
                      src={item.photoUrl}
                      alt={item.name}
                    />
                  ) : null}
                  <div className="panel-form-grid">
                    <label>
                      নাম (English)
                      <input
                        defaultValue={item.name}
                        maxLength={120}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={item.nameBn ?? ""}
                        maxLength={120}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Slug
                      <input
                        defaultValue={item.slug}
                        maxLength={120}
                        name="slug"
                        required
                      />
                    </label>
                    <label>
                      Title (English)
                      <input
                        defaultValue={item.title ?? ""}
                        maxLength={160}
                        name="title"
                      />
                    </label>
                    <label>
                      Title (বাংলা)
                      <input
                        defaultValue={item.titleBn ?? ""}
                        maxLength={160}
                        name="titleBn"
                      />
                    </label>
                    <label>
                      Email
                      <input
                        defaultValue={item.email ?? ""}
                        maxLength={200}
                        name="email"
                        type="email"
                      />
                    </label>
                    <label>
                      Phone
                      <input
                        defaultValue={item.phone ?? ""}
                        maxLength={30}
                        name="phone"
                      />
                    </label>
                    <label className="form-span-2">
                      Photo URL
                      <input
                        defaultValue={item.photoUrl ?? ""}
                        maxLength={1000}
                        name="photoUrl"
                        type="url"
                      />
                    </label>
                    <label className="form-span-2">
                      Expertise (English)
                      <textarea
                        defaultValue={item.expertise.join("\n")}
                        maxLength={500}
                        name="expertise"
                        rows={3}
                      />
                    </label>
                    <label className="form-span-2">
                      Expertise (বাংলা)
                      <textarea
                        defaultValue={item.expertiseBn.join("\n")}
                        maxLength={500}
                        name="expertiseBn"
                        rows={3}
                      />
                    </label>
                    <label className="form-span-2">
                      Bio (English)
                      <textarea
                        defaultValue={item.bio ?? ""}
                        maxLength={2000}
                        name="bio"
                        rows={4}
                      />
                    </label>
                    <label className="form-span-2">
                      পরিচিতি (বাংলা)
                      <textarea
                        defaultValue={item.bioBn ?? ""}
                        maxLength={2000}
                        name="bioBn"
                        rows={4}
                      />
                    </label>
                  </div>
                  <label className="form-checkbox">
                    <input
                      defaultChecked={item.isActive}
                      name="isActive"
                      type="checkbox"
                      value="true"
                    />
                    <span>Active</span>
                  </label>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Instructor আপডেট করুন
                  </button>
                </form>
              </details>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
