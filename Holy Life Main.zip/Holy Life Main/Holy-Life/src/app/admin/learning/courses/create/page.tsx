import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  await requirePermission(
    "learning.courses.course.create",
    "/admin/learning/courses/create",
  );
  const query = await searchParams;
  const [categories, instructors] = await Promise.all([
    db.courseCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.instructorProfile.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
    }),
  ]);

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title="Create course"
        description="Create a bilingual course record with real public media, pricing and enrollment controls."
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      <SectionCard title="Course details">
        <form
          action="/api/admin/learning/courses"
          className="panel-form"
          method="post"
        >
          <div className="admin-form-section">
            <div className="admin-form-section-heading">
              <strong>Identity & public copy</strong>
              <span>
                English and Bangla versions are managed independently.
              </span>
            </div>
            <div className="form-grid two">
              <label>
                Title (English)
                <input maxLength={160} name="title" required />
              </label>
              <label>
                শিরোনাম (বাংলা)
                <input maxLength={160} name="titleBn" />
              </label>
              <label>
                Slug
                <input
                  maxLength={120}
                  name="slug"
                  placeholder="generated-from-English-title"
                />
              </label>
              <label>
                Category
                <select name="categoryId" required>
                  <option value="">Select category</option>
                  {categories.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Instructor
                <select name="instructorId">
                  <option value="">Holy Life Academy</option>
                  {instructors.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Level
                <select defaultValue="ALL_LEVELS" name="level">
                  <option value="BEGINNER">Beginner</option>
                  <option value="INTERMEDIATE">Intermediate</option>
                  <option value="ADVANCED">Advanced</option>
                  <option value="ALL_LEVELS">All levels</option>
                </select>
              </label>
              <label className="span-2">
                Short description (English)
                <textarea maxLength={500} name="shortDescription" rows={3} />
              </label>
              <label className="span-2">
                সংক্ষিপ্ত বিবরণ (বাংলা)
                <textarea maxLength={500} name="shortDescriptionBn" rows={3} />
              </label>
              <label className="span-2">
                Full description (English)
                <textarea maxLength={10000} name="description" rows={5} />
              </label>
              <label className="span-2">
                বিস্তারিত বিবরণ (বাংলা)
                <textarea maxLength={10000} name="descriptionBn" rows={5} />
              </label>
            </div>
          </div>

          <div className="admin-form-section">
            <div className="admin-form-section-heading">
              <strong>Media & commercial settings</strong>
              <span>
                Use approved photography or illustration URLs; all values remain
                editable.
              </span>
            </div>
            <div className="form-grid two">
              <label className="span-2">
                Thumbnail image URL
                <input maxLength={1000} name="thumbnailUrl" type="url" />
              </label>
              <label className="span-2">
                Trailer / intro URL
                <input maxLength={1000} name="trailerUrl" type="url" />
              </label>
              <label>
                Teaching language
                <input defaultValue="Bangla" maxLength={60} name="language" />
              </label>
              <label>
                Estimated minutes
                <input
                  defaultValue="0"
                  min="0"
                  name="estimatedMinutes"
                  type="number"
                />
              </label>
              <label>
                Price (BDT)
                <input
                  defaultValue="0"
                  min="0"
                  name="price"
                  step="0.01"
                  type="number"
                />
              </label>
              <label>
                Compare-at price (BDT)
                <input
                  min="0"
                  name="compareAtPrice"
                  step="0.01"
                  type="number"
                />
              </label>
            </div>
          </div>

          <div className="admin-form-grid admin-form-grid-two">
            <label className="form-field">
              <span>Learning outcomes (English, one per line)</span>
              <textarea maxLength={3000} name="learningOutcomes" rows={5} />
            </label>
            <label className="form-field">
              <span>শেখার ফলাফল (বাংলা, প্রতি লাইনে একটি)</span>
              <textarea maxLength={3000} name="learningOutcomesBn" rows={5} />
            </label>
            <label className="form-field">
              <span>Requirements (English, one per line)</span>
              <textarea maxLength={3000} name="requirements" rows={4} />
            </label>
            <label className="form-field">
              <span>প্রয়োজনীয় প্রস্তুতি (বাংলা, প্রতি লাইনে একটি)</span>
              <textarea maxLength={3000} name="requirementsBn" rows={4} />
            </label>
          </div>

          <div className="form-grid three">
            <label className="form-check">
              <input name="isFeatured" type="checkbox" value="true" />
              <span>
                <strong>Featured course</strong>
              </span>
            </label>
            <label className="form-check">
              <input
                defaultChecked
                name="allowSelfEnrollment"
                type="checkbox"
                value="true"
              />
              <span>
                <strong>Allow self enrollment</strong>
              </span>
            </label>
            <label className="form-check">
              <input
                defaultChecked
                name="certificateEnabled"
                type="checkbox"
                value="true"
              />
              <span>
                <strong>Enable certificate</strong>
              </span>
            </label>
          </div>
          <button className="ui-button ui-button-primary" type="submit">
            Create course
          </button>
        </form>
      </SectionCard>
    </div>
  );
}
