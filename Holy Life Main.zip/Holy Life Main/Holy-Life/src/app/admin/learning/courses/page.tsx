import { AdminCourseList } from "@/components/learning/admin-course-list";
import { requirePermission } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "learning.courses.course.view",
    "/admin/learning/courses",
  );
  const query = await searchParams;
  return <AdminCourseList error={query.error} success={query.success} />;
}
